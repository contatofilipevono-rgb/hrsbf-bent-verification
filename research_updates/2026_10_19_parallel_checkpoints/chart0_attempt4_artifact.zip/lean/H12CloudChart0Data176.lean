import H12CloudChart0Data175

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans44583_44584 : H12AffineEnvironment.transform 13 13405 env44583 = env44584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env44583 == env44584) = true)

theorem identity44584 : scanCanonicalize (H12AffineFastState.compose env44584 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound44584 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env44585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,41051,46109,262144,1025,32769,36880,272392,65,41231,8193,64,10589,5441,45404,262145,34052,305241,257,8573,46092,513]

theorem envBound44585 : H12AffineFastState.Bounded env44585 := by
  intro p hp
  have h : env44585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44584_44585 : H12AffineEnvironment.transform 15 41051 env44584 = env44585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env44584 == env44585) = true)

theorem identity44585 : scanCanonicalize (H12AffineFastState.compose env44585 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound44585 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,32768,34099,37237,262144,1025,32769,36880,265568,65,33895,1385,64,3125,5441,37940,262145,34052,298289,257,1045,37220,513]

theorem envBound44586 : H12AffineFastState.Bounded env44586 := by
  intro p hp
  have h : env44586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44585_44586 : H12AffineEnvironment.transform 12 1384 env44585 = env44586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env44585 == env44586) = true)

theorem identity44586 : scanCanonicalize (H12AffineFastState.compose env44586 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 3393) := by decide +kernel

theorem selectedBound44586 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,32768,34099,37237,3393,1025,32769,36880,33,65,33895,1385,64,3125,5441,37940,3392,34052,32880,257,1045,37220,513]

theorem envBound44587 : H12AffineFastState.Bounded env44587 := by
  intro p hp
  have h : env44587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44586_44587 : H12AffineEnvironment.transform 17 3393 env44586 = env44587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3393 env44586 == env44587) = true)

theorem identity44587 : scanCanonicalize (H12AffineFastState.compose env44587 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 7505) := by decide +kernel

theorem selectedBound44587 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env44588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,7505,6242,3108,3393,1025,7504,3393,33,65,6454,1385,64,3125,5441,2405,3392,6229,7457,257,1045,3125,513]

theorem envBound44588 : H12AffineFastState.Bounded env44588 := by
  intro p hp
  have h : env44588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44587_44588 : H12AffineEnvironment.transform 14 7505 env44587 = env44588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7505 env44587 == env44588) = true)

theorem identity44588 : scanCanonicalize (H12AffineFastState.compose env44588 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound44588 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env44589 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,268,4405,6453,6242,2112,2341,101,6452,2341,33,65,6454,269,64,2129,4389,2405,2340,6229,6469,257,113,2129,513]

theorem envBound44589 : H12AffineFastState.Bounded env44589 := by
  intro p hp
  have h : env44589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44588_44589 : H12AffineEnvironment.transform 9 100 env44588 = env44589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env44588 == env44589) = true)

theorem identity44589 : scanCanonicalize (H12AffineFastState.compose env44589 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound44589 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44590 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2357,268,2048,0,343,2112,2341,101,1,2341,33,65,3,269,64,2129,2064,2405,2340,352,112,257,113,2129,513]

theorem envBound44590 : H12AffineFastState.Bounded env44590 := by
  intro p hp
  have h : env44590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44589_44590 : H12AffineEnvironment.transform 11 2357 env44589 = env44590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env44589 == env44590) = true)

theorem identity44590 : scanCanonicalize (H12AffineFastState.compose env44590 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44590 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44591 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2357,268,2048,0,263,2064,2341,53,1,2341,33,17,3,269,16,2049,2064,2357,2340,304,32,257,33,2049,513]

theorem envBound44591 : H12AffineFastState.Bounded env44591 := by
  intro p hp
  have h : env44591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44590_44591 : H12AffineEnvironment.transform 5 16 env44590 = env44591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44590 == env44591) = true)

theorem identity44591 : scanCanonicalize (H12AffineFastState.compose env44591 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound44591 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44592 : List Nat := [2,4,8,16,32,16,9,256,512,52,309,0,268,309,0,263,293,16,53,1,16,33,17,3,269,16,308,293,0,17,304,32,257,33,308,513]

theorem envBound44592 : H12AffineFastState.Bounded env44592 := by
  intro p hp
  have h : env44592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44591_44592 : H12AffineEnvironment.transform 10 309 env44591 = env44592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env44591 == env44592) = true)

theorem identity44592 : scanCanonicalize (H12AffineFastState.compose env44592 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound44592 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44593 : List Nat := [2,4,8,16,32,16,9,256,292,52,309,0,268,309,0,263,293,16,53,1,16,33,17,3,269,16,308,293,0,17,304,32,257,33,308,293]

theorem envBound44593 : H12AffineFastState.Bounded env44593 := by
  intro p hp
  have h : env44593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44592_44593 : H12AffineEnvironment.transform 8 292 env44592 = env44593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env44592 == env44593) = true)

theorem identity44593 : scanCanonicalize (H12AffineFastState.compose env44593 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44593 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44594 : List Nat := [2,4,8,16,32,16,9,36,0,52,17,0,40,17,0,35,1,16,53,1,16,33,17,3,41,16,16,1,0,17,20,32,37,33,16,1]

theorem envBound44594 : H12AffineFastState.Bounded env44594 := by
  intro p hp
  have h : env44594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44593_44594 : H12AffineEnvironment.transform 7 36 env44593 = env44594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44593 == env44594) = true)

theorem identity44594 : scanCanonicalize (H12AffineFastState.compose env44594 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44594 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44595 : List Nat := [2,4,8,10,32,10,9,36,0,46,11,0,40,11,0,35,1,10,47,1,10,33,11,3,41,10,10,1,0,11,14,32,37,33,10,1]

theorem envBound44595 : H12AffineFastState.Bounded env44595 := by
  intro p hp
  have h : env44595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44594_44595 : H12AffineEnvironment.transform 3 10 env44594 = env44595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44594 == env44595) = true)

def env44596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,8388608,8631561,8328,64,4486409,8393985,8548820,8830976,143640,12645452,257,21793,46212,202447]

theorem envBound44596 : H12AffineFastState.Bounded env44596 := by
  intro p hp
  have h : env44596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44485_44596 : H12AffineEnvironment.transform 23 8631561 env44485 = env44596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631561 env44485 == env44596) = true)

def env44597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,180224,95497,8328,64,4486409,185601,45524,262144,143640,4338764,257,21793,46212,202447]

theorem envBound44597 : H12AffineFastState.Bounded env44597 := by
  intro p hp
  have h : env44597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44596_44597 : H12AffineEnvironment.transform 22 180224 env44596 = env44597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env44596 == env44597) = true)

def env44598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272512,180224,95497,8328,64,23945,185601,45524,262144,143640,400588,257,21793,46212,202447]

theorem envBound44598 : H12AffineFastState.Bounded env44598 := by
  intro p hp
  have h : env44598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44597_44598 : H12AffineEnvironment.transform 21 272512 env44597 = env44598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44597 == env44598) = true)

theorem identity44598 : scanCanonicalize (H12AffineFastState.compose env44598 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound44598 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4160,272512,62660,95497,8328,64,23945,57797,45524,262144,1500,272392,257,21793,46212,74251]

theorem envBound44599 : H12AffineFastState.Bounded env44599 := by
  intro p hp
  have h : env44599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44598_44599 : H12AffineEnvironment.transform 16 13508 env44598 = env44599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env44598 == env44599) = true)

theorem identity44599 : scanCanonicalize (H12AffineFastState.compose env44599 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44599 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env44600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13508,262144,1025,32769,4160,272512,62660,21763,8328,64,23945,57797,45524,262144,1500,272392,257,21793,46212,513]

theorem envBound44600 : H12AffineFastState.Bounded env44600 := by
  intro p hp
  have h : env44600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44599_44600 : H12AffineEnvironment.transform 15 8202 env44599 = env44600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44599 == env44600) = true)

theorem identity44600 : scanCanonicalize (H12AffineFastState.compose env44600 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound44600 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env44601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13508,2557,1025,32769,4160,8573,62660,21763,8328,64,23945,57797,45524,2557,1500,8693,257,21793,46212,513]

theorem envBound44601 : H12AffineFastState.Bounded env44601 := by
  intro p hp
  have h : env44601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44600_44601 : H12AffineEnvironment.transform 17 2557 env44600 = env44601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env44600 == env44601) = true)

theorem identity44601 : scanCanonicalize (H12AffineFastState.compose env44601 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44601 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env44602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,13508,2557,1025,0,4160,8573,29893,21763,8328,64,23945,25028,12757,2557,1500,8693,257,21793,13445,513]

theorem envBound44602 : H12AffineFastState.Bounded env44602 := by
  intro p hp
  have h : env44602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44601_44602 : H12AffineEnvironment.transform 14 1 env44601 = env44602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44601 == env44602) = true)

theorem identity44602 : scanCanonicalize (H12AffineFastState.compose env44602 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44602 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env44603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,1,342,5528,2557,1025,0,4160,33,21913,21763,468,64,23945,16536,4233,2557,1500,169,257,21793,5593,513]

theorem envBound44603 : H12AffineFastState.Bounded env44603 := by
  intro p hp
  have h : env44603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44602_44603 : H12AffineEnvironment.transform 12 348 env44602 = env44603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44602 == env44603) = true)

theorem identity44603 : scanCanonicalize (H12AffineFastState.compose env44603 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound44603 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env44604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,4112,1,342,5528,2557,1025,0,4160,33,1417,1299,468,64,3481,4232,4233,2557,1500,169,257,1329,5593,513]

theorem envBound44604 : H12AffineFastState.Bounded env44604 := by
  intro p hp
  have h : env44604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44603_44604 : H12AffineEnvironment.transform 13 4112 env44603 = env44604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env44603 == env44604) = true)

theorem identity44604 : scanCanonicalize (H12AffineFastState.compose env44604 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 236) := by decide +kernel

theorem selectedBound44604 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44605 : List Nat := [2,4,8,16,32,64,128,236,512,1024,2048,4096,176,4112,1,186,5236,2065,1025,0,4160,33,1125,1279,56,64,3189,4232,4233,2065,1072,169,237,1245,5173,513]

theorem envBound44605 : H12AffineFastState.Bounded env44605 := by
  intro p hp
  have h : env44605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44604_44605 : H12AffineEnvironment.transform 7 236 env44604 = env44605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 236 env44604 == env44605) = true)

theorem identity44605 : scanCanonicalize (H12AffineFastState.compose env44605 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound44605 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44606 : List Nat := [2,4,8,16,32,64,128,236,512,116,2048,4096,176,4112,1,186,4096,2065,117,0,4160,33,17,139,56,64,2049,4232,4233,2065,68,169,237,169,4161,513]

theorem envBound44606 : H12AffineFastState.Bounded env44606 := by
  intro p hp
  have h : env44606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44605_44606 : H12AffineEnvironment.transform 9 116 env44605 = env44606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env44605 == env44606) = true)

theorem identity44606 : scanCanonicalize (H12AffineFastState.compose env44606 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2123) := by decide +kernel

theorem selectedBound44606 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44607 : List Nat := [2,4,8,16,32,64,128,236,512,116,2048,2123,176,2139,1,186,2123,2065,117,0,2059,33,17,139,56,64,2049,2243,2242,2065,68,169,237,169,2058,513]

theorem envBound44607 : H12AffineFastState.Bounded env44607 := by
  intro p hp
  have h : env44607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44606_44607 : H12AffineEnvironment.transform 11 2123 env44606 = env44607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2123 env44606 == env44607) = true)

theorem identity44607 : scanCanonicalize (H12AffineFastState.compose env44607 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 632) := by decide +kernel

theorem selectedBound44607 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env44608 : List Nat := [2,4,8,16,32,64,128,236,512,116,632,563,176,547,1,186,563,617,117,0,627,33,17,139,56,64,633,699,698,617,68,169,237,169,626,513]

theorem envBound44608 : H12AffineFastState.Bounded env44608 := by
  intro p hp
  have h : env44608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44607_44608 : H12AffineEnvironment.transform 10 632 env44607 = env44608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 632 env44607 == env44608) = true)

theorem identity44608 : scanCanonicalize (H12AffineFastState.compose env44608 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44608 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44609 : List Nat := [2,4,8,16,32,64,8,100,512,116,632,563,56,547,1,50,563,617,117,0,627,33,17,3,56,64,633,563,562,617,68,33,101,33,626,513]

theorem envBound44609 : H12AffineFastState.Bounded env44609 := by
  intro p hp
  have h : env44609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44608_44609 : H12AffineEnvironment.transform 6 8 env44608 = env44609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44608 == env44609) = true)

def env44610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272513,180224,95497,8328,64,23944,185601,45524,262144,143640,400589,257,21793,46212,202447]

theorem envBound44610 : H12AffineFastState.Bounded env44610 := by
  intro p hp
  have h : env44610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44597_44610 : H12AffineEnvironment.transform 21 272513 env44597 = env44610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44597 == env44610) = true)

theorem identity44610 : scanCanonicalize (H12AffineFastState.compose env44610 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound44610 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140420,272513,144597,95497,8328,64,23944,139732,17665,262144,143640,400589,257,21793,16465,202447]

theorem envBound44611 : H12AffineFastState.Bounded env44611 := by
  intro p hp
  have h : env44611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44610_44611 : H12AffineEnvironment.transform 14 29909 env44610 = env44611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env44610 == env44611) = true)

theorem identity44611 : scanCanonicalize (H12AffineFastState.compose env44611 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound44611 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env44612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,76158,1025,29908,140420,66047,144597,95497,8328,64,23944,139732,17665,76158,143640,210355,257,21793,16465,202447]

theorem envBound44612 : H12AffineFastState.Bounded env44612 := by
  intro p hp
  have h : env44612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44611_44612 : H12AffineEnvironment.transform 17 76158 env44611 = env44612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env44611 == env44612) = true)

def env44613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,76158,1025,29788,140300,65911,144477,95497,8192,64,23808,139612,17665,76158,143640,210235,257,21793,16465,202311]

theorem envBound44613 : H12AffineFastState.Bounded env44613 := by
  intro p hp
  have h : env44613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44612_44613 : H12AffineEnvironment.transform 6 8 env44612 = env44613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44612 == env44613) = true)

theorem identity44613 : scanCanonicalize (H12AffineFastState.compose env44613 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound44613 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,70726,76158,1025,29788,77898,65911,73755,95497,8192,64,23808,79130,17665,76158,75102,8573,257,21793,16465,513]

theorem envBound44614 : H12AffineFastState.Bounded env44614 := by
  intro p hp
  have h : env44614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44613_44614 : H12AffineEnvironment.transform 16 70726 env44613 = env44614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env44613 == env44614) = true)

theorem identity44614 : scanCanonicalize (H12AffineFastState.compose env44614 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound44614 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env44615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,16400,32040,1025,29788,25628,21793,29773,8543,8192,64,23808,24908,17665,32040,28936,8573,257,21793,16465,513]

theorem envBound44615 : H12AffineFastState.Bounded env44615 := by
  intro p hp
  have h : env44615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44614_44615 : H12AffineEnvironment.transform 15 21590 env44614 = env44615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env44614 == env44615) = true)

theorem identity44615 : scanCanonicalize (H12AffineFastState.compose env44615 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44615 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21590,16400,23669,1025,21761,17729,21793,21776,2,349,64,23808,16401,17665,23669,20565,32,257,21793,16465,513]

theorem envBound44616 : H12AffineFastState.Bounded env44616 := by
  intro p hp
  have h : env44616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44615_44616 : H12AffineEnvironment.transform 12 349 env44615 = env44616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44615 == env44616) = true)

theorem identity44616 : scanCanonicalize (H12AffineFastState.compose env44616 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound44616 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5392,2421,1025,1,4161,33,16,2,349,64,2048,5393,4097,2421,1365,32,257,33,5457,513]

theorem envBound44617 : H12AffineFastState.Bounded env44617 := by
  intro p hp
  have h : env44617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44616_44617 : H12AffineEnvironment.transform 13 5376 env44616 = env44617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44616 == env44617) = true)

theorem identity44617 : scanCanonicalize (H12AffineFastState.compose env44617 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44617 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44618 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,0,35,5221,2048,1025,1,4161,33,16,2,40,64,2048,5220,4097,2048,1056,32,116,33,5156,513]

theorem envBound44618 : H12AffineFastState.Bounded env44618 := by
  intro p hp
  have h : env44618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44617_44618 : H12AffineEnvironment.transform 7 117 env44617 = env44618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44617 == env44618) = true)

theorem identity44618 : scanCanonicalize (H12AffineFastState.compose env44618 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44618 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44619 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,0,35,5172,2048,1025,1,4112,33,16,2,40,17,2048,5173,4097,2048,1056,32,37,33,5156,513]

theorem envBound44619 : H12AffineFastState.Bounded env44619 := by
  intro p hp
  have h : env44619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44618_44619 : H12AffineEnvironment.transform 5 17 env44618 = env44619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44618 == env44619) = true)

def env44620 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,40,1044,0,35,1028,2048,1025,1,32,33,16,2,40,17,2048,1029,49,2048,1056,32,37,33,1044,513]

theorem envBound44620 : H12AffineFastState.Bounded env44620 := by
  intro p hp
  have h : env44620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44619_44620 : H12AffineEnvironment.transform 11 48 env44619 = env44620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44619 == env44620) = true)

theorem identity44620 : scanCanonicalize (H12AffineFastState.compose env44620 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44621 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,48,40,1044,0,35,1028,0,1025,1,32,33,16,2,40,17,0,1029,49,0,1056,32,37,33,1044,513]

theorem envBound44621 : H12AffineFastState.Bounded env44621 := by
  intro p hp
  have h : env44621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44620_44621 : H12AffineEnvironment.transform 10 0 env44620 = env44621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44620 == env44621) = true)

def env44622 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,48,40,32,0,35,48,0,53,1,32,33,16,2,40,17,0,49,49,0,20,32,37,33,32,513]

theorem envBound44622 : H12AffineFastState.Bounded env44622 := by
  intro p hp
  have h : env44622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44621_44622 : H12AffineEnvironment.transform 9 52 env44621 = env44622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44621 == env44622) = true)

theorem identity44622 : scanCanonicalize (H12AffineFastState.compose env44622 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound44622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44623 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,48,40,32,0,35,48,0,53,1,32,33,16,2,40,17,0,49,49,0,20,32,37,33,32,10]

theorem envBound44623 : H12AffineFastState.Bounded env44623 := by
  intro p hp
  have h : env44623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44622_44623 : H12AffineEnvironment.transform 8 11 env44622 = env44623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env44622 == env44623) = true)

def leafEnv44623 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,48,40,32,0,35,48,0,53,1,32,33,16,2,21,40,1,17,0,49,49,0,20,32,37,33,5,35,32,10,1,32,0]

def active44623 : List Nat := [0,1,2,3,4]

def tree44623 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44623 : H12WitnessSearch.Good tree44623 := H12GlobalWitnessIndex.good

theorem leafIdentity44623 : H12AffineFastState.composeSystem env44623 rootObs = leafEnv44623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44623 rootObs == leafEnv44623) = true)

theorem terminalChecked44623 : H12PackedTerminal.terminalCheckFast leafEnv44623 active44623 tree44623 = true := by decide +kernel

def env44624 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,40,33,0,35,49,0,52,1,32,33,16,2,40,17,0,48,49,0,21,32,37,33,33,513]

theorem envBound44624 : H12AffineFastState.Bounded env44624 := by
  intro p hp
  have h : env44624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44621_44624 : H12AffineEnvironment.transform 9 53 env44621 = env44624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44621 == env44624) = true)

theorem identity44624 : scanCanonicalize (H12AffineFastState.compose env44624 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44625 : List Nat := [2,4,8,16,0,17,8,4,512,21,0,16,8,1,0,3,17,0,20,1,0,1,16,2,8,17,0,16,17,0,21,0,5,1,1,513]

theorem envBound44625 : H12AffineFastState.Bounded env44625 := by
  intro p hp
  have h : env44625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44624_44625 : H12AffineEnvironment.transform 4 0 env44624 = env44625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44624 == env44625) = true)

def leafEnv44625 : List Nat := [2,4,8,16,0,17,8,4,512,21,0,16,8,1,0,3,17,0,20,1,0,1,16,2,20,8,1,17,0,16,17,0,21,0,5,1,5,3,1,513,1,0,0]

def active44625 : List Nat := [0,1,2,3,8]

def tree44625 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44625 : H12WitnessSearch.Good tree44625 := H12GlobalWitnessIndex.good

theorem leafIdentity44625 : H12AffineFastState.composeSystem env44625 rootObs = leafEnv44625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44625 rootObs == leafEnv44625) = true)

theorem terminalChecked44625 : H12PackedTerminal.terminalCheckFast leafEnv44625 active44625 tree44625 = true := by decide +kernel

def env44626 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1045,0,35,1029,2048,1025,1,33,33,16,2,40,17,2048,1028,48,2048,1056,32,37,33,1045,513]

theorem envBound44626 : H12AffineFastState.Bounded env44626 := by
  intro p hp
  have h : env44626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44619_44626 : H12AffineEnvironment.transform 11 49 env44619 = env44626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44619 == env44626) = true)

theorem identity44626 : scanCanonicalize (H12AffineFastState.compose env44626 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound44626 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44627 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,49,40,1045,0,35,1029,1076,1025,1,33,33,16,2,40,17,1076,1028,48,1076,1056,32,37,33,1045,513]

theorem envBound44627 : H12AffineFastState.Bounded env44627 := by
  intro p hp
  have h : env44627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44626_44627 : H12AffineEnvironment.transform 10 1076 env44626 = env44627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env44626 == env44627) = true)

def env44628 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,40,33,0,35,49,0,53,1,33,33,16,2,40,17,0,48,48,0,20,32,37,33,33,513]

theorem envBound44628 : H12AffineFastState.Bounded env44628 := by
  intro p hp
  have h : env44628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44627_44628 : H12AffineEnvironment.transform 9 52 env44627 = env44628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44627 == env44628) = true)

theorem identity44628 : scanCanonicalize (H12AffineFastState.compose env44628 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound44628 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44629 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,49,40,33,0,35,49,0,53,1,33,33,16,2,40,17,0,48,48,0,20,32,37,33,33,10]

theorem envBound44629 : H12AffineFastState.Bounded env44629 := by
  intro p hp
  have h : env44629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44628_44629 : H12AffineEnvironment.transform 8 11 env44628 = env44629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env44628 == env44629) = true)

def leafEnv44629 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,49,40,33,0,35,49,0,53,1,33,33,16,2,21,40,1,17,0,48,48,0,20,32,37,33,5,35,33,10,1,33,0]

def active44629 : List Nat := [0,1,2,3,4]

def tree44629 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44629 : H12WitnessSearch.Good tree44629 := H12GlobalWitnessIndex.good

theorem leafIdentity44629 : H12AffineFastState.composeSystem env44629 rootObs = leafEnv44629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44629 rootObs == leafEnv44629) = true)

theorem terminalChecked44629 : H12PackedTerminal.terminalCheckFast leafEnv44629 active44629 tree44629 = true := by decide +kernel

def env44630 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,49,40,32,0,35,48,1,52,1,33,33,16,2,40,17,1,49,48,1,21,32,37,33,32,513]

theorem envBound44630 : H12AffineFastState.Bounded env44630 := by
  intro p hp
  have h : env44630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44627_44630 : H12AffineEnvironment.transform 9 53 env44627 = env44630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44627 == env44630) = true)

theorem identity44630 : scanCanonicalize (H12AffineFastState.compose env44630 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44630 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44631 : List Nat := [2,4,8,16,0,17,8,4,512,21,1,17,8,0,0,3,16,1,20,1,1,1,16,2,8,17,1,17,16,1,21,0,5,1,0,513]

theorem envBound44631 : H12AffineFastState.Bounded env44631 := by
  intro p hp
  have h : env44631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44630_44631 : H12AffineEnvironment.transform 4 0 env44630 = env44631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44630 == env44631) = true)

def leafEnv44631 : List Nat := [2,4,8,16,0,17,8,4,512,21,1,17,8,0,0,3,16,1,20,1,1,1,16,2,20,8,1,17,1,17,16,1,21,0,5,1,5,3,0,513,1,1,0]

def active44631 : List Nat := [0,1,2,3,8]

def tree44631 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44631 : H12WitnessSearch.Good tree44631 := H12GlobalWitnessIndex.good

theorem leafIdentity44631 : H12AffineFastState.composeSystem env44631 rootObs = leafEnv44631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44631 rootObs == leafEnv44631) = true)

theorem terminalChecked44631 : H12PackedTerminal.terminalCheckFast leafEnv44631 active44631 tree44631 = true := by decide +kernel

def env44632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,76158,1025,29789,140301,65910,144476,95497,8193,64,23809,139613,17665,76158,143640,210234,257,21793,16465,202310]

theorem envBound44632 : H12AffineFastState.Bounded env44632 := by
  intro p hp
  have h : env44632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44612_44632 : H12AffineEnvironment.transform 6 9 env44612 = env44632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44612 == env44632) = true)

theorem identity44632 : scanCanonicalize (H12AffineFastState.compose env44632 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound44632 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,65536,131072,76158,1025,1,140301,65910,144476,65877,8193,64,10589,139613,12637,76158,143640,210234,257,8573,13325,202310]

theorem envBound44633 : H12AffineFastState.Bounded env44633 := by
  intro p hp
  have h : env44633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44632_44633 : H12AffineEnvironment.transform 13 13404 env44632 = env44633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env44632 == env44633) = true)

theorem identity44633 : scanCanonicalize (H12AffineFastState.compose env44633 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound44633 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,0,65536,131072,67926,1025,1,132133,65910,136308,65877,41,64,2421,131445,4469,67926,135472,202002,257,341,5157,202310]

theorem envBound44634 : H12AffineFastState.Bounded env44634 := by
  intro p hp
  have h : env44634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44633_44634 : H12AffineEnvironment.transform 12 40 env44633 = env44634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env44633 == env44634) = true)

theorem identity44634 : scanCanonicalize (H12AffineFastState.compose env44634 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound44634 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env44635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,0,115,131072,2341,1025,1,132133,261,136308,294,41,64,2421,131445,4469,2341,135472,136545,257,341,5157,136757]

theorem envBound44635 : H12AffineFastState.Bounded env44635 := by
  intro p hp
  have h : env44635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44634_44635 : H12AffineEnvironment.transform 15 115 env44634 = env44635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env44634 == env44635) = true)

theorem identity44635 : scanCanonicalize (H12AffineFastState.compose env44635 (packedSelected [1,8,12,15,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44635 : packedSelected [1,8,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env44636 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5236,0,115,131072,2048,1025,1,132133,32,136308,3,41,64,2128,131152,4176,2048,135189,136260,36,112,5157,136757]

theorem envBound44636 : H12AffineFastState.Bounded env44636 := by
  intro p hp
  have h : env44636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44635_44636 : H12AffineEnvironment.transform 7 37 env44635 = env44636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44635 == env44636) = true)

theorem identity44636 : scanCanonicalize (H12AffineFastState.compose env44636 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound44636 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44637 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5236,0,115,5172,2048,1025,1,4113,32,64,3,41,64,2128,5220,4176,2048,1057,112,36,112,5157,513]

theorem envBound44637 : H12AffineFastState.Bounded env44637 := by
  intro p hp
  have h : env44637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44636_44637 : H12AffineEnvironment.transform 16 5172 env44636 = env44637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env44636 == env44637) = true)

theorem identity44637 : scanCanonicalize (H12AffineFastState.compose env44637 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound44637 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env44638 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,1140,40,0,0,115,64,2048,1025,1,1125,32,64,3,41,64,2128,16,1060,2048,1057,112,36,112,81,513]

theorem envBound44638 : H12AffineFastState.Bounded env44638 := by
  intro p hp
  have h : env44638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44637_44638 : H12AffineEnvironment.transform 11 1140 env44637 = env44638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env44637 == env44638) = true)

theorem identity44638 : scanCanonicalize (H12AffineFastState.compose env44638 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound44638 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44639 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,16,40,0,0,115,64,2048,101,1,1,32,64,3,41,64,2128,16,64,2048,69,112,36,112,81,513]

theorem envBound44639 : H12AffineFastState.Bounded env44639 := by
  intro p hp
  have h : env44639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44638_44639 : H12AffineEnvironment.transform 9 100 env44638 = env44639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env44638 == env44639) = true)

theorem identity44639 : scanCanonicalize (H12AffineFastState.compose env44639 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound44639 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44640 : List Nat := [2,4,8,16,32,64,9,37,512,100,577,16,40,0,0,115,64,577,101,1,1,32,64,3,41,64,529,16,64,577,69,112,36,112,81,513]

theorem envBound44640 : H12AffineFastState.Bounded env44640 := by
  intro p hp
  have h : env44640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44639_44640 : H12AffineEnvironment.transform 10 577 env44639 = env44640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env44639 == env44640) = true)

theorem identity44640 : scanCanonicalize (H12AffineFastState.compose env44640 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound44640 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44641 : List Nat := [2,4,8,16,32,11,9,37,512,47,522,16,40,0,0,56,11,522,46,1,1,32,11,3,41,11,529,16,11,522,14,59,36,59,26,513]

theorem envBound44641 : H12AffineFastState.Bounded env44641 := by
  intro p hp
  have h : env44641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44640_44641 : H12AffineEnvironment.transform 5 11 env44640 = env44641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env44640 == env44641) = true)

theorem identity44641 : scanCanonicalize (H12AffineFastState.compose env44641 (packedSelected [0,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44641 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env44642 : List Nat := [2,4,8,16,32,11,9,37,17,47,27,16,40,0,0,56,11,27,46,1,1,32,11,3,41,11,0,16,11,27,14,59,36,59,26,16]

theorem envBound44642 : H12AffineFastState.Bounded env44642 := by
  intro p hp
  have h : env44642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44641_44642 : H12AffineEnvironment.transform 8 17 env44641 = env44642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44641 == env44642) = true)

def env44643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,180225,95496,8328,64,4486409,185600,45525,262145,143640,4338765,257,21793,46212,202447]

theorem envBound44643 : H12AffineFastState.Bounded env44643 := by
  intro p hp
  have h : env44643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44596_44643 : H12AffineEnvironment.transform 22 180225 env44596 = env44643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env44596 == env44643) = true)

def env44644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272512,180225,95496,8328,64,23945,185600,45525,262145,143640,400589,257,21793,46212,202447]

theorem envBound44644 : H12AffineFastState.Bounded env44644 := by
  intro p hp
  have h : env44644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44643_44644 : H12AffineEnvironment.transform 21 272512 env44643 = env44644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44643 == env44644) = true)

theorem identity44644 : scanCanonicalize (H12AffineFastState.compose env44644 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound44644 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58516,272512,17,95496,8328,64,23945,5392,45525,262145,61704,318685,257,21793,46212,120543]

theorem envBound44645 : H12AffineFastState.Bounded env44645 := by
  intro p hp
  have h : env44645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44644_44645 : H12AffineEnvironment.transform 16 49168 env44644 = env44645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env44644 == env44645) = true)

def env44646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272392,17,95496,8192,64,23809,5392,45405,262145,61704,318549,257,21793,46092,120407]

theorem envBound44646 : H12AffineFastState.Bounded env44646 := by
  intro p hp
  have h : env44646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44645_44646 : H12AffineEnvironment.transform 6 8 env44645 = env44646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44645 == env44646) = true)

theorem identity44646 : scanCanonicalize (H12AffineFastState.compose env44646 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44646 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,58396,32,17,95496,8192,64,23809,5392,45405,10281,61704,62589,257,21793,46092,120407]

theorem envBound44647 : H12AffineFastState.Bounded env44647 := by
  intro p hp
  have h : env44647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44646_44647 : H12AffineEnvironment.transform 17 10280 env44646 = env44647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44646 == env44647) = true)

theorem identity44647 : scanCanonicalize (H12AffineFastState.compose env44647 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound44647 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env44648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21510,49168,10280,1025,32769,58396,32,17,8462,8192,64,23809,5392,45405,10281,61704,62589,257,21793,46092,33361]

theorem envBound44648 : H12AffineFastState.Bounded env44648 := by
  intro p hp
  have h : env44648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44647_44648 : H12AffineEnvironment.transform 15 21510 env44647 = env44648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env44647 == env44648) = true)

theorem identity44648 : scanCanonicalize (H12AffineFastState.compose env44648 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44648 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env44649 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,21510,49168,10280,1025,32769,58396,32,17,8462,8192,17,23809,5392,45324,10281,61704,62508,257,21793,46092,33280]

theorem envBound44649 : H12AffineFastState.Bounded env44649 := by
  intro p hp
  have h : env44649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44648_44649 : H12AffineEnvironment.transform 5 17 env44648 = env44649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44648 == env44649) = true)

theorem identity44649 : scanCanonicalize (H12AffineFastState.compose env44649 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44649 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env44650 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,21510,16400,10280,1025,1,25628,32,17,8462,8192,17,23809,5392,12556,10281,28936,29740,257,21793,13324,512]

theorem envBound44650 : H12AffineFastState.Bounded env44650 := by
  intro p hp
  have h : env44650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44649_44650 : H12AffineEnvironment.transform 14 0 env44649 = env44650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44649 == env44650) = true)

theorem identity44650 : scanCanonicalize (H12AffineFastState.compose env44650 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound44650 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44651 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,301,16384,0,21510,16400,2309,1025,1,17713,32,17,35,301,17,23809,5392,4129,2308,20517,21761,257,21793,5409,512]

theorem envBound44651 : H12AffineFastState.Bounded env44651 := by
  intro p hp
  have h : env44651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44650_44651 : H12AffineEnvironment.transform 12 301 env44650 = env44651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env44650 == env44651) = true)

theorem identity44651 : scanCanonicalize (H12AffineFastState.compose env44651 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44651 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44652 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,301,5377,0,263,5393,2309,1025,1,4144,32,17,35,301,17,2048,5392,4129,2308,1316,0,257,32,5409,512]

theorem envBound44652 : H12AffineFastState.Bounded env44652 := by
  intro p hp
  have h : env44652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44651_44652 : H12AffineEnvironment.transform 13 5377 env44651 = env44652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44651 == env44652) = true)

theorem identity44652 : scanCanonicalize (H12AffineFastState.compose env44652 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound44652 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env44653 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1313,301,32,0,263,48,2309,1025,1,1297,32,17,35,301,17,2048,49,1280,2308,1316,0,257,32,0,512]

theorem envBound44653 : H12AffineFastState.Bounded env44653 := by
  intro p hp
  have h : env44653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44652_44653 : H12AffineEnvironment.transform 11 1313 env44652 = env44653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env44652 == env44653) = true)

theorem identity44653 : scanCanonicalize (H12AffineFastState.compose env44653 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound44653 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44654 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,17,301,32,0,263,48,2309,305,1,33,32,17,35,301,17,2048,49,48,2308,20,0,257,32,0,512]

theorem envBound44654 : H12AffineFastState.Bounded env44654 := by
  intro p hp
  have h : env44654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44653_44654 : H12AffineEnvironment.transform 9 304 env44653 = env44654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env44653 == env44654) = true)

theorem identity44654 : scanCanonicalize (H12AffineFastState.compose env44654 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound44654 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44655 : List Nat := [2,4,8,16,32,17,8,256,512,304,260,17,301,32,0,263,48,1,305,1,33,32,17,35,301,17,260,49,48,0,20,0,257,32,0,512]

theorem envBound44655 : H12AffineFastState.Bounded env44655 := by
  intro p hp
  have h : env44655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44654_44655 : H12AffineEnvironment.transform 10 260 env44654 = env44655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env44654 == env44655) = true)

theorem identity44655 : scanCanonicalize (H12AffineFastState.compose env44655 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44655 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44656 : List Nat := [2,4,8,16,32,17,8,4,512,52,0,17,41,32,0,3,48,1,53,1,33,32,17,35,41,17,0,49,48,0,20,0,5,32,0,512]

theorem envBound44656 : H12AffineFastState.Bounded env44656 := by
  intro p hp
  have h : env44656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44655_44656 : H12AffineEnvironment.transform 7 4 env44655 = env44656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44655 == env44656) = true)

theorem identity44656 : scanCanonicalize (H12AffineFastState.compose env44656 (packedSelected [12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44656 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env44657 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,17,8,1,0,3,17,1,20,1,0,1,17,2,8,17,0,16,17,0,20,0,5,1,0,512]

theorem envBound44657 : H12AffineFastState.Bounded env44657 := by
  intro p hp
  have h : env44657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44656_44657 : H12AffineEnvironment.transform 4 1 env44656 = env44657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44656 == env44657) = true)

theorem identity44657 : scanCanonicalize (H12AffineFastState.compose env44657 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound44657 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44658 : List Nat := [2,4,8,16,1,17,8,4,20,21,0,17,8,1,0,3,17,1,20,1,0,1,17,2,8,17,0,16,17,0,20,0,5,1,0,20]

theorem envBound44658 : H12AffineFastState.Bounded env44658 := by
  intro p hp
  have h : env44658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44657_44658 : H12AffineEnvironment.transform 8 20 env44657 = env44658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env44657 == env44658) = true)

theorem identity44658 : scanCanonicalize (H12AffineFastState.compose env44658 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound44658 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44659 : List Nat := [2,4,8,9,1,8,8,4,13,12,0,8,8,1,0,3,8,1,13,1,0,1,8,2,8,8,0,9,8,0,13,0,5,1,0,13]

theorem envBound44659 : H12AffineFastState.Bounded env44659 := by
  intro p hp
  have h : env44659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44658_44659 : H12AffineEnvironment.transform 3 9 env44658 = env44659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env44658 == env44659) = true)

theorem identity44659 : scanCanonicalize (H12AffineFastState.compose env44659 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44659 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44660 : List Nat := [2,3,8,9,1,8,8,3,10,11,0,8,8,1,0,3,8,1,10,1,0,1,8,2,8,8,0,9,8,0,10,0,2,1,0,10]

theorem envBound44660 : H12AffineFastState.Bounded env44660 := by
  intro p hp
  have h : env44660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44659_44660 : H12AffineEnvironment.transform 1 3 env44659 = env44660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44659 == env44660) = true)

theorem identity44660 : scanCanonicalize (H12AffineFastState.compose env44660 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44660 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44661 : List Nat := [2,3,2,3,1,2,2,3,0,1,0,2,2,1,0,3,2,1,0,1,0,1,2,2,2,2,0,3,2,0,0,0,2,1,0,0]

theorem envBound44661 : H12AffineFastState.Bounded env44661 := by
  intro p hp
  have h : env44661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44660_44661 : H12AffineEnvironment.transform 2 2 env44660 = env44661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44660 == env44661) = true)

theorem identity44661 : scanCanonicalize (H12AffineFastState.compose env44661 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44661 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env44662 : List Nat := [0,1,0,1,1,0,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0]

theorem envBound44662 : H12AffineFastState.Bounded env44662 := by
  intro p hp
  have h : env44662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44661_44662 : H12AffineEnvironment.transform 0 0 env44661 = env44662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44661 == env44662) = true)

def env44663 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272393,17,95496,8193,64,23808,5392,45404,262145,61704,318548,257,21793,46093,120406]

theorem envBound44663 : H12AffineFastState.Bounded env44663 := by
  intro p hp
  have h : env44663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44645_44663 : H12AffineEnvironment.transform 6 9 env44645 = env44663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44645 == env44663) = true)

theorem identity44663 : scanCanonicalize (H12AffineFastState.compose env44663 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound44663 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44664 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,58397,41341,17,95496,8193,64,23808,5392,45404,35189,61704,21792,257,21793,46093,120406]

theorem envBound44664 : H12AffineFastState.Bounded env44664 := by
  intro p hp
  have h : env44664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44663_44664 : H12AffineEnvironment.transform 17 35188 env44663 = env44664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env44663 == env44664) = true)

theorem identity44664 : scanCanonicalize (H12AffineFastState.compose env44664 (packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound44664 : packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,115,49168,35188,1025,32769,58397,41341,17,30075,8193,64,23808,5392,45404,35189,61704,21792,257,21793,46093,54821]

theorem envBound44665 : H12AffineFastState.Bounded env44665 := by
  intro p hp
  have h : env44665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44664_44665 : H12AffineEnvironment.transform 15 115 env44664 = env44665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env44664 == env44665) = true)

theorem identity44665 : scanCanonicalize (H12AffineFastState.compose env44665 (packedSelected [0,7,9,14,16,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound44665 : packedSelected [0,7,9,14,16,19,22,26] rootPS < 2^1333 := by decide +kernel

def env44666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,115,24632,10588,1025,8233,17461,341,17,30075,8193,64,23808,5392,4468,10589,20768,21792,257,21793,5157,30221]

theorem envBound44666 : H12AffineFastState.Bounded env44666 := by
  intro p hp
  have h : env44666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44665_44666 : H12AffineEnvironment.transform 14 8232 env44665 = env44666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env44665 == env44666) = true)

theorem identity44666 : scanCanonicalize (H12AffineFastState.compose env44666 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound44666 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env44667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8232,115,5220,10588,1025,8233,12393,341,17,295,8193,64,10588,5392,4468,10589,9596,8572,257,8573,5157,593]

theorem envBound44667 : H12AffineFastState.Bounded env44667 := by
  intro p hp
  have h : env44667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44666_44667 : H12AffineEnvironment.transform 13 13404 env44666 = env44667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env44666 == env44667) = true)

theorem identity44667 : scanCanonicalize (H12AffineFastState.compose env44667 (packedSelected [1,2,6,8,12,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44667 : packedSelected [1,2,6,8,12,18,19] rootPS < 2^1333 := by decide +kernel

def env44668 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,8232,115,4468,10588,273,8233,12393,341,17,295,8193,64,10588,4096,4468,10589,8300,8572,257,8573,4405,593]

theorem envBound44668 : H12AffineFastState.Bounded env44668 := by
  intro p hp
  have h : env44668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44667_44668 : H12AffineEnvironment.transform 9 272 env44667 = env44668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44667 == env44668) = true)

theorem identity44668 : scanCanonicalize (H12AffineFastState.compose env44668 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44668 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env44669 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,41,4453,1,115,4468,2421,273,0,4160,341,17,295,40,64,2421,4096,4468,2420,69,341,257,340,4405,593]

theorem envBound44669 : H12AffineFastState.Bounded env44669 := by
  intro p hp
  have h : env44669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44668_44669 : H12AffineEnvironment.transform 12 41 env44668 = env44669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44668 == env44669) = true)

theorem identity44669 : scanCanonicalize (H12AffineFastState.compose env44669 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44669 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44670 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,41,4112,1,115,4097,2048,100,0,4160,32,17,82,40,64,2048,4096,4097,2049,69,32,116,33,4160,593]

theorem envBound44670 : H12AffineFastState.Bounded env44670 := by
  intro p hp
  have h : env44670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44669_44670 : H12AffineEnvironment.transform 7 117 env44669 = env44670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44669 == env44670) = true)

theorem identity44670 : scanCanonicalize (H12AffineFastState.compose env44670 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound44670 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env44671 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2065,41,2049,1,115,2064,2048,100,0,2129,32,17,82,40,64,2048,2065,2064,2049,69,32,116,33,2129,593]

theorem envBound44671 : H12AffineFastState.Bounded env44671 := by
  intro p hp
  have h : env44671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44670_44671 : H12AffineEnvironment.transform 11 2065 env44670 = env44671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env44670 == env44671) = true)

theorem identity44671 : scanCanonicalize (H12AffineFastState.compose env44671 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44671 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env44672 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2065,41,2049,1,35,2064,2048,52,0,2049,32,17,2,40,16,2048,2065,2064,2049,21,32,36,33,2049,513]

theorem envBound44672 : H12AffineFastState.Bounded env44672 := by
  intro p hp
  have h : env44672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44671_44672 : H12AffineEnvironment.transform 5 16 env44671 = env44672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44671 == env44672) = true)

theorem identity44672 : scanCanonicalize (H12AffineFastState.compose env44672 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44673 : List Nat := [2,4,8,16,32,16,9,37,16,53,2048,2065,41,2049,1,35,2064,2048,52,0,2049,32,17,2,40,16,2048,2065,2064,2049,21,32,36,33,2049,17]

theorem envBound44673 : H12AffineFastState.Bounded env44673 := by
  intro p hp
  have h : env44673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44672_44673 : H12AffineEnvironment.transform 8 16 env44672 = env44673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44672 == env44673) = true)

theorem identity44673 : scanCanonicalize (H12AffineFastState.compose env44673 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound44673 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44674 : List Nat := [2,4,8,16,32,16,9,37,16,53,11,26,41,10,1,35,27,11,52,0,10,32,17,2,40,16,11,26,27,10,21,32,36,33,10,17]

theorem envBound44674 : H12AffineFastState.Bounded env44674 := by
  intro p hp
  have h : env44674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44673_44674 : H12AffineEnvironment.transform 10 11 env44673 = env44674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env44673 == env44674) = true)

theorem identity44674 : scanCanonicalize (H12AffineFastState.compose env44674 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44674 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44675 : List Nat := [2,4,2,16,32,16,3,37,16,53,1,16,35,0,1,35,17,1,52,0,0,32,17,2,34,16,1,16,17,0,21,32,36,33,0,17]

theorem envBound44675 : H12AffineFastState.Bounded env44675 := by
  intro p hp
  have h : env44675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44674_44675 : H12AffineEnvironment.transform 2 2 env44674 = env44675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44674 == env44675) = true)

def env44676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272513,180225,95496,8328,64,23944,185600,45525,262145,143640,400588,257,21793,46212,202447]

theorem envBound44676 : H12AffineFastState.Bounded env44676 := by
  intro p hp
  have h : env44676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44643_44676 : H12AffineEnvironment.transform 21 272513 env44643 = env44676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44643 == env44676) = true)

def env44677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272393,180225,95496,8192,64,23808,185600,45405,262145,143640,400452,257,21793,46092,202311]

theorem envBound44677 : H12AffineFastState.Bounded env44677 := by
  intro p hp
  have h : env44677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44676_44677 : H12AffineEnvironment.transform 6 8 env44676 = env44677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44676 == env44677) = true)

def env44678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272393,17,95496,8192,64,23808,5392,45405,262145,61704,318548,257,21793,46092,120407]

theorem envBound44678 : H12AffineFastState.Bounded env44678 := by
  intro p hp
  have h : env44678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44677_44678 : H12AffineEnvironment.transform 16 49168 env44677 = env44678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env44677 == env44678) = true)

theorem identity44678 : scanCanonicalize (H12AffineFastState.compose env44678 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44678 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,58396,33,17,95496,8192,64,23808,5392,45405,10281,61704,62588,257,21793,46092,120407]

theorem envBound44679 : H12AffineFastState.Bounded env44679 := by
  intro p hp
  have h : env44679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44678_44679 : H12AffineEnvironment.transform 17 10280 env44678 = env44679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44678 == env44679) = true)

theorem identity44679 : scanCanonicalize (H12AffineFastState.compose env44679 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound44679 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env44680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30043,49168,10280,1025,32769,58396,33,17,83,8192,64,23808,5392,45405,10281,61704,62588,257,21793,46092,41740]

theorem envBound44680 : H12AffineFastState.Bounded env44680 := by
  intro p hp
  have h : env44680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44679_44680 : H12AffineEnvironment.transform 15 30043 env44679 = env44680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env44679 == env44680) = true)

theorem identity44680 : scanCanonicalize (H12AffineFastState.compose env44680 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44680 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env44681 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,29963,49168,10280,1025,32769,58396,33,17,3,8192,16,23808,5392,45325,10281,61704,62508,257,21793,46092,41740]

theorem envBound44681 : H12AffineFastState.Bounded env44681 := by
  intro p hp
  have h : env44681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44680_44681 : H12AffineEnvironment.transform 5 16 env44680 = env44681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44680 == env44681) = true)

theorem identity44681 : scanCanonicalize (H12AffineFastState.compose env44681 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 14392) := by decide +kernel

theorem selectedBound44681 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env44682 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,14392,29963,30760,10280,1025,14393,23588,33,17,3,8192,16,23808,5392,2357,10281,18736,19476,257,21793,3124,6964]

theorem envBound44682 : H12AffineFastState.Bounded env44682 := by
  intro p hp
  have h : env44682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44681_44682 : H12AffineEnvironment.transform 14 14392 env44681 = env44682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14392 env44681 == env44682) = true)

theorem identity44682 : scanCanonicalize (H12AffineFastState.compose env44682 (packedSelected [2,3,5,6,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 7425) := by decide +kernel

theorem selectedBound44682 : packedSelected [2,3,5,6,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env44683 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,7425,14392,10250,9513,10280,1025,14393,293,33,17,3,8192,16,1,5392,2357,10281,5169,4373,257,2080,3124,6964]

theorem envBound44683 : H12AffineFastState.Bounded env44683 := by
  intro p hp
  have h : env44683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44682_44683 : H12AffineEnvironment.transform 13 7425 env44682 = env44683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7425 env44682 == env44683) = true)

theorem identity44683 : scanCanonicalize (H12AffineFastState.compose env44683 (packedSelected [0,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound44683 : packedSelected [0,7,11,14] rootPS < 2^1333 := by decide +kernel

def env44684 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,8192,3124,10509,10250,9513,10280,1025,10508,293,33,17,3,8192,16,1,1061,2357,10281,1284,32,257,2080,3124,2561]

theorem envBound44684 : H12AffineFastState.Bounded env44684 := by
  intro p hp
  have h : env44684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44683_44684 : H12AffineEnvironment.transform 11 309 env44683 = env44684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env44683 == env44684) = true)

theorem identity44684 : scanCanonicalize (H12AffineFastState.compose env44684 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44684 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env44685 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,309,8192,1077,8460,8203,9513,8233,1025,8461,293,33,17,3,8192,16,1,1061,308,8232,1284,32,257,33,1077,512]

theorem envBound44685 : H12AffineFastState.Bounded env44685 := by
  intro p hp
  have h : env44685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44684_44685 : H12AffineEnvironment.transform 10 1 env44684 = env44685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44684 == env44685) = true)

theorem identity44685 : scanCanonicalize (H12AffineFastState.compose env44685 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound44685 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44686 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,309,300,1077,32,295,1029,261,1025,33,293,33,17,3,300,16,1,1061,308,260,1284,32,257,33,1077,512]

theorem envBound44686 : H12AffineFastState.Bounded env44686 := by
  intro p hp
  have h : env44686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44685_44686 : H12AffineEnvironment.transform 12 300 env44685 = env44686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env44685 == env44686) = true)

theorem identity44686 : scanCanonicalize (H12AffineFastState.compose env44686 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44686 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44687 : List Nat := [2,4,8,16,32,16,8,256,512,52,1,309,300,1,32,295,49,261,53,33,293,33,17,3,300,16,1,17,308,260,304,32,257,33,1,512]

theorem envBound44687 : H12AffineFastState.Bounded env44687 := by
  intro p hp
  have h : env44687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44686_44687 : H12AffineEnvironment.transform 9 52 env44686 = env44687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44686 == env44687) = true)

theorem identity44687 : scanCanonicalize (H12AffineFastState.compose env44687 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44687 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44688 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,16,9,1,32,2,49,32,53,33,0,33,17,3,9,16,1,17,17,33,21,32,36,33,1,512]

theorem envBound44688 : H12AffineFastState.Bounded env44688 := by
  intro p hp
  have h : env44688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44687_44688 : H12AffineEnvironment.transform 7 37 env44687 = env44688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44687 == env44688) = true)

theorem identity44688 : scanCanonicalize (H12AffineFastState.compose env44688 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44688 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44689 : List Nat := [2,4,8,16,1,16,8,4,512,21,1,16,9,1,1,2,16,1,20,0,0,0,17,3,9,16,1,17,17,0,21,1,5,0,1,512]

theorem envBound44689 : H12AffineFastState.Bounded env44689 := by
  intro p hp
  have h : env44689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44688_44689 : H12AffineEnvironment.transform 4 1 env44688 = env44689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44688 == env44689) = true)

theorem identity44689 : scanCanonicalize (H12AffineFastState.compose env44689 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44690 : List Nat := [2,4,8,0,1,0,8,4,512,5,1,0,9,1,1,2,0,1,4,0,0,0,1,3,9,0,1,1,1,0,5,1,5,0,1,512]

theorem envBound44690 : H12AffineFastState.Bounded env44690 := by
  intro p hp
  have h : env44690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44689_44690 : H12AffineEnvironment.transform 3 0 env44689 = env44690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44689 == env44690) = true)

theorem identity44690 : scanCanonicalize (H12AffineFastState.compose env44690 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound44690 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44691 : List Nat := [2,0,8,0,1,0,8,0,512,1,1,0,9,1,1,2,0,1,0,0,0,0,1,3,9,0,1,1,1,0,1,1,1,0,1,512]

theorem envBound44691 : H12AffineFastState.Bounded env44691 := by
  intro p hp
  have h : env44691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44690_44691 : H12AffineEnvironment.transform 1 0 env44690 = env44691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env44690 == env44691) = true)

theorem identity44691 : scanCanonicalize (H12AffineFastState.compose env44691 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44691 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44692 : List Nat := [2,0,8,0,1,0,8,0,0,1,1,0,9,1,1,2,0,1,0,0,0,0,1,3,9,0,1,1,1,0,1,1,1,0,1,0]

theorem envBound44692 : H12AffineFastState.Bounded env44692 := by
  intro p hp
  have h : env44692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44691_44692 : H12AffineEnvironment.transform 8 0 env44691 = env44692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44691 == env44692) = true)

def env44693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272393,16,95496,8192,64,23808,5393,45405,262145,61705,318549,257,21793,46092,120406]

theorem envBound44693 : H12AffineFastState.Bounded env44693 := by
  intro p hp
  have h : env44693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44677_44693 : H12AffineEnvironment.transform 16 49169 env44677 = env44693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env44677 == env44693) = true)

theorem identity44693 : scanCanonicalize (H12AffineFastState.compose env44693 (packedSelected [0,1,3,4,8,10,12,14,16,18,22,23,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 64889) := by decide +kernel

theorem selectedBound44693 : packedSelected [0,1,3,4,8,10,12,14,16,18,22,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env44694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,64889,1025,32769,58397,54640,16,95496,8192,64,23808,5393,45405,64888,61705,8492,257,21793,46092,120406]

theorem envBound44694 : H12AffineFastState.Bounded env44694 := by
  intro p hp
  have h : env44694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44693_44694 : H12AffineEnvironment.transform 17 64889 env44693 = env44694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64889 env44693 == env44694) = true)

theorem identity44694 : scanCanonicalize (H12AffineFastState.compose env44694 (packedSelected [1,3,4,5,9,10,12,15,18,20,23,26,28,31,35] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44694 : packedSelected [1,3,4,5,9,10,12,15,18,20,23,26,28,31,35] rootPS < 2^1333 := by decide +kernel

def env44695 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,65536,49169,56437,1025,32769,50449,54640,16,87044,268,64,23808,5393,36945,56436,53253,32,257,21793,38144,120406]

theorem envBound44695 : H12AffineFastState.Bounded env44695 := by
  intro p hp
  have h : env44695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44694_44695 : H12AffineEnvironment.transform 12 268 env44694 = env44695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44694 == env44695) = true)

theorem identity44695 : scanCanonicalize (H12AffineFastState.compose env44695 (packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound44695 : packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env44696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,32768,65536,38208,35108,1025,32769,36928,32801,16,65877,268,64,2129,5393,36945,35109,34132,32,257,112,38144,99079]

theorem envBound44696 : H12AffineFastState.Bounded env44696 := by
  intro p hp
  have h : env44696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44695_44696 : H12AffineEnvironment.transform 13 5457 env44695 = env44696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env44695 == env44696) = true)

theorem identity44696 : scanCanonicalize (H12AffineFastState.compose env44696 (packedSelected [2,3,6,7,8,9,10,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 7505) := by decide +kernel

theorem selectedBound44696 : packedSelected [2,3,6,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env44697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,7505,65536,2065,5237,1025,7504,3345,7536,16,65877,268,64,2129,5393,3328,5236,6149,32,257,112,2129,73302]

theorem envBound44697 : H12AffineFastState.Bounded env44697 := by
  intro p hp
  have h : env44697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44696_44697 : H12AffineEnvironment.transform 14 7505 env44696 = env44697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7505 env44696 == env44697) = true)

theorem identity44697 : scanCanonicalize (H12AffineFastState.compose env44697 (packedSelected [3,4,7,8,11,14,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound44697 : packedSelected [3,4,7,8,11,14,16,19,20] rootPS < 2^1333 := by decide +kernel

def env44698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,7505,263,2065,5237,1025,7504,3345,7536,16,82,268,64,2129,5393,3328,5236,6149,32,257,112,2129,8017]

theorem envBound44698 : H12AffineFastState.Bounded env44698 := by
  intro p hp
  have h : env44698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44697_44698 : H12AffineEnvironment.transform 15 263 env44697 = env44698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env44697 == env44698) = true)

theorem identity44698 : scanCanonicalize (H12AffineFastState.compose env44698 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound44698 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env44699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,357,268,1076,3124,263,2065,1296,1025,3125,3345,3093,16,82,268,64,2129,1140,3328,1297,2400,32,257,112,2129,3636]

theorem envBound44699 : H12AffineFastState.Bounded env44699 := by
  intro p hp
  have h : env44699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44698_44699 : H12AffineEnvironment.transform 11 357 env44698 = env44699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env44698 == env44699) = true)

theorem identity44699 : scanCanonicalize (H12AffineFastState.compose env44699 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44699 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env44700 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,357,268,293,2341,263,2065,1,272,2340,2048,2308,16,82,268,64,2129,357,2065,0,2400,32,257,112,2129,2853]

theorem envBound44700 : H12AffineFastState.Bounded env44700 := by
  intro p hp
  have h : env44700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44699_44700 : H12AffineEnvironment.transform 9 273 env44699 = env44700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44699 == env44700) = true)

theorem identity44700 : scanCanonicalize (H12AffineFastState.compose env44700 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44700 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env44701 : List Nat := [2,4,8,16,32,64,8,256,512,273,0,357,268,293,293,263,17,1,272,292,0,260,16,82,268,64,81,357,17,0,352,32,257,112,81,805]

theorem envBound44701 : H12AffineFastState.Bounded env44701 := by
  intro p hp
  have h : env44701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44700_44701 : H12AffineEnvironment.transform 10 0 env44700 = env44701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44700 == env44701) = true)

theorem identity44701 : scanCanonicalize (H12AffineFastState.compose env44701 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44701 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44702 : List Nat := [2,4,8,16,32,64,8,116,512,101,0,17,120,81,81,115,17,1,100,80,0,112,16,82,120,64,81,17,17,0,20,32,117,112,81,593]

theorem envBound44702 : H12AffineFastState.Bounded env44702 := by
  intro p hp
  have h : env44702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44701_44702 : H12AffineEnvironment.transform 7 116 env44701 = env44702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44701 == env44702) = true)

theorem identity44702 : scanCanonicalize (H12AffineFastState.compose env44702 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44702 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env44703 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,40,1,1,35,17,1,52,0,0,32,16,2,40,16,1,17,17,0,20,32,37,32,1,513]

theorem envBound44703 : H12AffineFastState.Bounded env44703 := by
  intro p hp
  have h : env44703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44702_44703 : H12AffineEnvironment.transform 5 16 env44702 = env44703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44702 == env44703) = true)

theorem identity44703 : scanCanonicalize (H12AffineFastState.compose env44703 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44704 : List Nat := [2,4,8,1,32,1,8,36,512,36,0,0,40,1,1,35,0,1,37,0,0,32,1,2,40,1,1,0,0,0,5,32,37,32,1,513]

theorem envBound44704 : H12AffineFastState.Bounded env44704 := by
  intro p hp
  have h : env44704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44703_44704 : H12AffineEnvironment.transform 3 1 env44703 = env44704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44703 == env44704) = true)

theorem identity44704 : scanCanonicalize (H12AffineFastState.compose env44704 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44704 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44705 : List Nat := [2,4,8,1,10,1,8,14,512,14,0,0,2,1,1,9,0,1,15,0,0,10,1,2,2,1,1,0,0,0,5,10,15,10,1,513]

theorem envBound44705 : H12AffineFastState.Bounded env44705 := by
  intro p hp
  have h : env44705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44704_44705 : H12AffineEnvironment.transform 4 10 env44704 = env44705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44704 == env44705) = true)

def env44706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272392,180225,95496,8193,64,23809,185600,45404,262145,143640,400453,257,21793,46093,202310]

theorem envBound44706 : H12AffineFastState.Bounded env44706 := by
  intro p hp
  have h : env44706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44676_44706 : H12AffineEnvironment.transform 6 9 env44676 = env44706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44676 == env44706) = true)

def env44707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272392,17,95496,8193,64,23809,5392,45404,262145,61704,318549,257,21793,46093,120406]

theorem envBound44707 : H12AffineFastState.Bounded env44707 := by
  intro p hp
  have h : env44707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44706_44707 : H12AffineEnvironment.transform 16 49168 env44706 = env44707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env44706 == env44707) = true)

theorem identity44707 : scanCanonicalize (H12AffineFastState.compose env44707 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound44707 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,58397,41340,17,95496,8193,64,23809,5392,45404,35189,61704,21793,257,21793,46093,120406]

theorem envBound44708 : H12AffineFastState.Bounded env44708 := by
  intro p hp
  have h : env44708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44707_44708 : H12AffineEnvironment.transform 17 35188 env44707 = env44708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env44707 == env44708) = true)

theorem identity44708 : scanCanonicalize (H12AffineFastState.compose env44708 (packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound44708 : packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32802,49168,35188,1025,32769,58397,41340,17,62762,8193,64,23809,5392,45404,35189,61704,21793,257,21793,46093,22132]

theorem envBound44709 : H12AffineFastState.Bounded env44709 := by
  intro p hp
  have h : env44709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44708_44709 : H12AffineEnvironment.transform 15 32802 env44708 = env44709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env44708 == env44709) = true)

theorem identity44709 : scanCanonicalize (H12AffineFastState.compose env44709 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound44709 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env44710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,29963,13625,31837,1025,29992,4404,21589,17,3,8193,64,23809,5392,17525,31836,1057,21793,257,21793,16676,22132]

theorem envBound44710 : H12AffineFastState.Bounded env44710 := by
  intro p hp
  have h : env44710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44709_44710 : H12AffineEnvironment.transform 14 29993 env44709 = env44710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env44709 == env44710) = true)

theorem identity44710 : scanCanonicalize (H12AffineFastState.compose env44710 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound44710 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env44711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2404,8192,16384,27725,27759,11357,25913,1025,27724,2128,19761,17,3,8193,64,17509,3188,17525,25912,1057,19525,257,19525,16676,20240]

theorem envBound44711 : H12AffineFastState.Bounded env44711 := by
  intro p hp
  have h : env44711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44710_44711 : H12AffineEnvironment.transform 11 2404 env44710 = env44711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env44710 == env44711) = true)

theorem identity44711 : scanCanonicalize (H12AffineFastState.compose env44711 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound44711 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env44712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2404,2169,16384,17460,17430,1060,19776,1025,17461,2128,19761,17,3,2168,64,17509,3188,17525,19777,1057,19525,257,19525,16676,20240]

theorem envBound44712 : H12AffineFastState.Bounded env44712 := by
  intro p hp
  have h : env44712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44711_44712 : H12AffineEnvironment.transform 12 2169 env44711 = env44712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env44711 == env44712) = true)

def env44713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272392,16,95496,8193,64,23809,5393,45404,262145,61705,318548,257,21793,46093,120407]

theorem envBound44713 : H12AffineFastState.Bounded env44713 := by
  intro p hp
  have h : env44713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44706_44713 : H12AffineEnvironment.transform 16 49169 env44706 = env44713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env44706 == env44713) = true)

theorem identity44713 : scanCanonicalize (H12AffineFastState.compose env44713 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44713 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,262144,1025,8540,17729,272392,16,95496,8193,64,23809,5393,4097,262145,20564,294153,257,21793,5456,96010]

theorem envBound44714 : H12AffineFastState.Bounded env44714 := by
  intro p hp
  have h : env44714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44713_44714 : H12AffineEnvironment.transform 14 8541 env44713 = env44714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44713 == env44714) = true)

theorem identity44714 : scanCanonicalize (H12AffineFastState.compose env44714 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound44714 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env44715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,23669,1025,8540,17729,29821,16,95496,8193,64,23809,5393,4097,23668,20564,8572,257,21793,5456,96010]

theorem envBound44715 : H12AffineFastState.Bounded env44715 := by
  intro p hp
  have h : env44715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44714_44715 : H12AffineEnvironment.transform 17 23669 env44714 = env44715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env44714 == env44715) = true)

theorem identity44715 : scanCanonicalize (H12AffineFastState.compose env44715 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound44715 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,65536,5392,10281,1025,8540,12573,33,16,65876,8193,64,10589,5393,4097,10280,9224,8572,257,8573,5456,66390]

theorem envBound44716 : H12AffineFastState.Bounded env44716 := by
  intro p hp
  have h : env44716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44715_44716 : H12AffineEnvironment.transform 13 13404 env44715 = env44716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env44715 == env44716) = true)

theorem identity44716 : scanCanonicalize (H12AffineFastState.compose env44716 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44716 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44717 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,8541,65536,4096,10281,273,8540,12573,33,16,65876,8193,64,10589,4097,4097,10280,8472,8572,257,8573,4160,66390]

theorem envBound44717 : H12AffineFastState.Bounded env44717 := by
  intro p hp
  have h : env44717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44716_44717 : H12AffineEnvironment.transform 9 272 env44716 = env44717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44716 == env44717) = true)

theorem identity44717 : scanCanonicalize (H12AffineFastState.compose env44717 (packedSelected [4,9,11,12,14,15,16,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44717 : packedSelected [4,9,11,12,14,15,16,23] rootPS < 2^1333 := by decide +kernel

def env44718 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,1,65536,4096,2421,273,0,4161,33,16,65876,349,64,2049,4097,4097,2420,68,32,257,33,4160,66390]

theorem envBound44718 : H12AffineFastState.Bounded env44718 := by
  intro p hp
  have h : env44718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44717_44718 : H12AffineEnvironment.transform 12 348 env44717 = env44718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44717 == env44718) = true)

theorem identity44718 : scanCanonicalize (H12AffineFastState.compose env44718 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound44718 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44719 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,1,115,4096,2421,273,0,4161,33,16,295,349,64,2049,4097,4097,2420,68,32,257,33,4160,805]

theorem envBound44719 : H12AffineFastState.Bounded env44719 := by
  intro p hp
  have h : env44719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44718_44719 : H12AffineEnvironment.transform 15 115 env44718 = env44719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env44718 == env44719) = true)

theorem identity44719 : scanCanonicalize (H12AffineFastState.compose env44719 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound44719 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env44720 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2357,348,2341,1,115,2357,2421,273,0,2420,33,16,295,349,64,2049,2356,2356,2420,68,32,257,33,2421,805]

theorem envBound44720 : H12AffineFastState.Bounded env44720 := by
  intro p hp
  have h : env44720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44719_44720 : H12AffineEnvironment.transform 11 2357 env44719 = env44720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env44719 == env44720) = true)

theorem identity44720 : scanCanonicalize (H12AffineFastState.compose env44720 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44720 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44721 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2357,268,2341,1,35,2357,2341,273,0,2340,33,16,295,269,16,2049,2356,2356,2340,20,32,257,33,2341,805]

theorem envBound44721 : H12AffineFastState.Bounded env44721 := by
  intro p hp
  have h : env44721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44720_44721 : H12AffineEnvironment.transform 5 16 env44720 = env44721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44720 == env44721) = true)

theorem identity44721 : scanCanonicalize (H12AffineFastState.compose env44721 (packedSelected [2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44721 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env44722 : List Nat := [2,4,8,16,32,16,9,256,1,272,2048,2357,268,2341,1,35,2357,2341,273,0,2340,33,16,295,269,16,2049,2356,2356,2340,20,32,257,33,2341,292]

theorem envBound44722 : H12AffineFastState.Bounded env44722 := by
  intro p hp
  have h : env44722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44721_44722 : H12AffineEnvironment.transform 8 1 env44721 = env44722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44721 == env44722) = true)

theorem identity44722 : scanCanonicalize (H12AffineFastState.compose env44722 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44722 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env44723 : List Nat := [2,4,8,16,32,16,9,37,1,53,2048,2064,41,2048,1,35,2064,2048,52,0,2049,33,16,2,40,16,2049,2065,2065,2049,20,32,36,33,2048,1]

theorem envBound44723 : H12AffineFastState.Bounded env44723 := by
  intro p hp
  have h : env44723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44722_44723 : H12AffineEnvironment.transform 7 37 env44722 = env44723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44722 == env44723) = true)

theorem identity44723 : scanCanonicalize (H12AffineFastState.compose env44723 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 15) := by decide +kernel

theorem selectedBound44723 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44724 : List Nat := [2,4,8,16,32,16,9,37,1,53,15,31,41,15,1,35,31,15,52,0,14,33,16,2,40,16,14,30,30,14,20,32,36,33,15,1]

theorem envBound44724 : H12AffineFastState.Bounded env44724 := by
  intro p hp
  have h : env44724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44723_44724 : H12AffineEnvironment.transform 10 15 env44723 = env44724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 15 env44723 == env44724) = true)

theorem identity44724 : scanCanonicalize (H12AffineFastState.compose env44724 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44724 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44725 : List Nat := [2,4,8,1,32,1,9,37,1,36,15,14,41,15,1,35,14,15,37,0,14,33,1,2,40,1,14,15,15,14,5,32,36,33,15,1]

theorem envBound44725 : H12AffineFastState.Bounded env44725 := by
  intro p hp
  have h : env44725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44724_44725 : H12AffineEnvironment.transform 3 1 env44724 = env44725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44724 == env44725) = true)

theorem identity44725 : scanCanonicalize (H12AffineFastState.compose env44725 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44725 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44726 : List Nat := [2,4,8,1,1,1,9,4,1,5,15,14,8,15,1,2,14,15,4,0,14,0,1,2,9,1,14,15,15,14,5,1,5,0,15,1]

theorem envBound44726 : H12AffineFastState.Bounded env44726 := by
  intro p hp
  have h : env44726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44725_44726 : H12AffineEnvironment.transform 4 1 env44725 = env44726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44725 == env44726) = true)

theorem identity44726 : scanCanonicalize (H12AffineFastState.compose env44726 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound44726 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env44727 : List Nat := [2,4,7,1,1,1,6,4,1,5,0,1,7,0,1,2,1,0,4,0,1,0,1,2,6,1,1,0,0,1,5,1,5,0,0,1]

theorem envBound44727 : H12AffineFastState.Bounded env44727 := by
  intro p hp
  have h : env44727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44726_44727 : H12AffineEnvironment.transform 2 7 env44726 = env44727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env44726 == env44727) = true)

def env44728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254784,25265168,145662400,525568,140903596,27337993,25733063]

theorem envBound44728 : H12AffineFastState.Bounded env44728 := by
  intro p hp
  have h : env44728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43996_44728 : H12AffineEnvironment.transform 25 65 env43996 = env44728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env43996 == env44728) = true)

def env44729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356288,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound44729 : H12AffineFastState.Bounded env44729 := by
  intro p hp
  have h : env44729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44728_44729 : H12AffineEnvironment.transform 26 30393344 env44728 = env44729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env44728 == env44729) = true)

def env44730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound44730 : H12AffineFastState.Bounded env44730 := by
  intro p hp
  have h : env44730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44729_44730 : H12AffineEnvironment.transform 18 1024 env44729 = env44730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env44729 == env44730) = true)

theorem identity44730 : scanCanonicalize (H12AffineFastState.compose env44730 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 485860) := by decide +kernel

theorem selectedBound44730 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,485860,8328,65,12626404,2551145,10507601,8830976,8842740,6687780,256,10923336,10898669,8899107]

theorem envBound44731 : H12AffineFastState.Bounded env44731 := by
  intro p hp
  have h : env44731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44730_44731 : H12AffineEnvironment.transform 23 485860 env44730 = env44731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 485860 env44730 == env44731) = true)

def env44732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2553960,485860,8328,65,6705548,2551145,437561,2111592,2102684,6687780,256,21792,46213,2175563]

theorem envBound44732 : H12AffineFastState.Bounded env44732 := by
  intro p hp
  have h : env44732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44731_44732 : H12AffineEnvironment.transform 22 2553960 env44731 = env44732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2553960 env44731 == env44732) = true)

def env44733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101328,98780,8328,65,6338996,2098513,17665,2111592,2102684,6349852,256,21792,46213,2175563]

theorem envBound44733 : H12AffineFastState.Bounded env44733 := by
  intro p hp
  have h : env44733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44732_44733 : H12AffineEnvironment.transform 17 190520 env44732 = env44733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env44732 == env44733) = true)

def env44734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,98780,8328,65,4237812,5393,17665,10280,1500,4256860,256,21792,46213,74251]

theorem envBound44734 : H12AffineFastState.Bounded env44734 := by
  intro p hp
  have h : env44734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44733_44734 : H12AffineEnvironment.transform 20 4160 env44733 = env44734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44733 == env44734) = true)

def env44735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,98644,8192,65,4237692,5393,17665,10280,1364,4256860,256,21792,46093,74251]

theorem envBound44735 : H12AffineFastState.Bounded env44735 := by
  intro p hp
  have h : env44735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44734_44735 : H12AffineEnvironment.transform 6 8 env44734 = env44735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44734 == env44735) = true)

theorem identity44735 : scanCanonicalize (H12AffineFastState.compose env44735 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound44735 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,4194304,16,98644,8192,65,4237692,5393,17665,10280,1364,4256860,256,21792,46093,74251]

theorem envBound44736 : H12AffineFastState.Bounded env44736 := by
  intro p hp
  have h : env44736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44735_44736 : H12AffineEnvironment.transform 16 49168 env44735 = env44736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env44735 == env44736) = true)

theorem identity44736 : scanCanonicalize (H12AffineFastState.compose env44736 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound44736 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,65911,16,98644,8192,65,108555,5393,17665,10280,1364,128299,256,21792,46093,74251]

theorem envBound44737 : H12AffineFastState.Bounded env44737 := by
  intro p hp
  have h : env44737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44736_44737 : H12AffineEnvironment.transform 21 65911 env44736 = env44737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env44736 == env44737) = true)

theorem identity44737 : scanCanonicalize (H12AffineFastState.compose env44737 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44737 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10280,1024,32769,4160,8573,16,41310,8192,65,34817,5393,17665,10280,1364,54561,256,21792,46093,513]

theorem envBound44738 : H12AffineFastState.Bounded env44738 := by
  intro p hp
  have h : env44738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44737_44738 : H12AffineEnvironment.transform 15 8202 env44737 = env44738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44737 == env44738) = true)

theorem identity44738 : scanCanonicalize (H12AffineFastState.compose env44738 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44738 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,38161,10280,1024,32769,4160,8573,16,41310,8192,65,34817,5393,4096,10280,1364,32800,256,33,46093,513]

theorem envBound44739 : H12AffineFastState.Bounded env44739 := by
  intro p hp
  have h : env44739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44738_44739 : H12AffineEnvironment.transform 13 5377 env44738 = env44739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44738 == env44739) = true)

theorem identity44739 : scanCanonicalize (H12AffineFastState.compose env44739 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44739 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8202,5392,10280,1024,0,4160,8573,16,8543,8192,65,2048,5393,4096,10280,1364,33,256,33,13324,513]

theorem envBound44740 : H12AffineFastState.Bounded env44740 := by
  intro p hp
  have h : env44740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44739_44740 : H12AffineEnvironment.transform 14 1 env44739 = env44740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44739 == env44740) = true)

theorem identity44740 : scanCanonicalize (H12AffineFastState.compose env44740 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 3378) := by decide +kernel

theorem selectedBound44740 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3378,5377,1,3384,5392,1306,1024,0,4160,3151,16,3181,3378,65,2048,5393,4096,1306,1364,33,256,33,6462,513]

theorem envBound44741 : H12AffineFastState.Bounded env44741 := by
  intro p hp
  have h : env44741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44740_44741 : H12AffineEnvironment.transform 12 3378 env44740 = env44741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3378 env44740 == env44741) = true)

def env44742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,98645,8193,65,4237693,5393,17665,10280,1365,4256860,256,21792,46092,74251]

theorem envBound44742 : H12AffineFastState.Bounded env44742 := by
  intro p hp
  have h : env44742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44734_44742 : H12AffineEnvironment.transform 6 9 env44734 = env44742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44734 == env44742) = true)

theorem identity44742 : scanCanonicalize (H12AffineFastState.compose env44742 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound44742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1024,32769,4160,4194304,16,98645,8193,65,4237693,5393,17665,10280,1365,4256860,256,21792,46092,74251]

theorem envBound44743 : H12AffineFastState.Bounded env44743 := by
  intro p hp
  have h : env44743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44742_44743 : H12AffineEnvironment.transform 16 24908 env44742 = env44743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env44742 == env44743) = true)

theorem identity44743 : scanCanonicalize (H12AffineFastState.compose env44743 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound44743 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1024,32769,4160,21872,16,98645,8193,65,64525,5393,17665,10280,1365,41260,256,21792,46092,74251]

theorem envBound44744 : H12AffineFastState.Bounded env44744 := by
  intro p hp
  have h : env44744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44743_44744 : H12AffineEnvironment.transform 21 21872 env44743 = env44744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env44743 == env44744) = true)

theorem identity44744 : scanCanonicalize (H12AffineFastState.compose env44744 (packedSelected [0,1,5,8,9,10,16,20,22,24,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44744 : packedSelected [0,1,5,8,9,10,16,20,22,24,27,31] rootPS < 2^1333 := by decide +kernel

def env44745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10280,1024,8541,4160,21872,16,73737,8193,65,23889,5393,17665,10280,1365,112,256,21792,5456,74251]

theorem envBound44745 : H12AffineFastState.Bounded env44745 := by
  intro p hp
  have h : env44745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44744_44745 : H12AffineEnvironment.transform 14 8540 env44744 = env44745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44744 == env44745) = true)

theorem identity44745 : scanCanonicalize (H12AffineFastState.compose env44745 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound44745 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env44746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,114,24908,10280,1024,8541,4160,21872,16,8315,8193,65,23889,5393,17665,10280,1365,112,256,21792,5456,8825]

theorem envBound44746 : H12AffineFastState.Bounded env44746 := by
  intro p hp
  have h : env44746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44745_44746 : H12AffineEnvironment.transform 15 114 env44745 = env44746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env44745 == env44746) = true)

def env44747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,17,98780,8328,65,4237813,5392,17665,10281,1501,4256861,256,21792,46213,74250]

theorem envBound44747 : H12AffineFastState.Bounded env44747 := by
  intro p hp
  have h : env44747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44733_44747 : H12AffineEnvironment.transform 20 4161 env44733 = env44747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44733 == env44747) = true)

theorem identity44747 : scanCanonicalize (H12AffineFastState.compose env44747 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180409) := by decide +kernel

theorem selectedBound44747 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180409,17,98780,8328,65,158028,5392,17665,10281,1501,144612,256,21792,46213,74250]

theorem envBound44748 : H12AffineFastState.Bounded env44748 := by
  intro p hp
  have h : env44748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44747_44748 : H12AffineEnvironment.transform 21 180409 env44747 = env44748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env44747 == env44748) = true)

theorem identity44748 : scanCanonicalize (H12AffineFastState.compose env44748 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44748 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env44749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4161,180409,17,41431,8328,65,158028,5392,17665,10281,1501,144612,256,21792,46213,513]

theorem envBound44749 : H12AffineFastState.Bounded env44749 := by
  intro p hp
  have h : env44749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44748_44749 : H12AffineEnvironment.transform 15 8203 env44748 = env44749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44748 == env44749) = true)

theorem identity44749 : scanCanonicalize (H12AffineFastState.compose env44749 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound44749 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43049,1024,32769,4161,32936,17,41431,8328,65,10589,5392,17665,10281,1501,29941,256,21792,46213,513]

theorem envBound44750 : H12AffineFastState.Bounded env44750 := by
  intro p hp
  have h : env44750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44749_44750 : H12AffineEnvironment.transform 16 16401 env44749 = env44750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env44749 == env44750) = true)

theorem identity44750 : scanCanonicalize (H12AffineFastState.compose env44750 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound44750 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env44751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,16401,23588,1024,29708,4161,29861,17,21978,8328,65,10589,5392,17665,10281,1501,29941,256,21792,16520,513]

theorem envBound44751 : H12AffineFastState.Bounded env44751 := by
  intro p hp
  have h : env44751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44750_44751 : H12AffineEnvironment.transform 14 29709 env44750 = env44751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env44750 == env44751) = true)

theorem identity44751 : scanCanonicalize (H12AffineFastState.compose env44751 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound44751 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env44752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,1,8203,13341,10280,1024,0,4161,169,17,8662,8328,65,10589,5392,12557,10281,1501,249,256,8492,13444,513]

theorem envBound44752 : H12AffineFastState.Bounded env44752 := by
  intro p hp
  have h : env44752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44751_44752 : H12AffineEnvironment.transform 13 13324 env44751 = env44752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env44751 == env44752) = true)

theorem identity44752 : scanCanonicalize (H12AffineFastState.compose env44752 (packedSelected [0,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2540) := by decide +kernel

theorem selectedBound44752 : packedSelected [0,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env44753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2540,8192,11744,1,8203,11761,10280,1024,0,2477,169,17,8662,8328,65,10589,3324,10465,10281,1501,249,256,8492,11624,513]

theorem envBound44753 : H12AffineFastState.Bounded env44753 := by
  intro p hp
  have h : env44753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44752_44753 : H12AffineEnvironment.transform 11 2540 env44752 = env44753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2540 env44752 == env44753) = true)

theorem identity44753 : scanCanonicalize (H12AffineFastState.compose env44753 (packedSelected [1,6,7,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound44753 : packedSelected [1,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1297,1277,8192,8433,1,8203,8416,9529,1024,0,1212,169,17,8662,8328,65,9292,493,9712,9528,1501,249,256,8492,8313,513]

theorem envBound44754 : H12AffineFastState.Bounded env44754 := by
  intro p hp
  have h : env44754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44753_44754 : H12AffineEnvironment.transform 10 1297 env44753 = env44754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env44753 == env44754) = true)

theorem identity44754 : scanCanonicalize (H12AffineFastState.compose env44754 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound44754 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env44755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1297,1277,468,293,1,479,308,1261,1024,0,1212,169,17,2,348,65,1432,493,1060,1260,1501,249,256,248,429,513]

theorem envBound44755 : H12AffineFastState.Bounded env44755 := by
  intro p hp
  have h : env44755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44754_44755 : H12AffineEnvironment.transform 12 468 env44754 = env44755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env44754 == env44755) = true)

theorem identity44755 : scanCanonicalize (H12AffineFastState.compose env44755 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44756 : List Nat := [2,4,8,16,32,64,128,116,512,1024,1125,1277,160,81,1,171,64,1261,1024,0,1212,169,17,2,40,65,1260,153,1060,1260,1193,249,116,248,217,513]

theorem envBound44756 : H12AffineFastState.Bounded env44756 := by
  intro p hp
  have h : env44756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44755_44756 : H12AffineEnvironment.transform 7 116 env44755 = env44756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44755 == env44756) = true)

theorem identity44756 : scanCanonicalize (H12AffineFastState.compose env44756 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44756 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env44757 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1077,1197,160,1,1,171,16,1213,1024,0,1212,169,17,2,40,17,1212,153,1060,1212,1193,169,36,168,137,513]

theorem envBound44757 : H12AffineFastState.Bounded env44757 := by
  intro p hp
  have h : env44757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44756_44757 : H12AffineEnvironment.transform 5 16 env44756 = env44757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44756 == env44757) = true)

theorem identity44757 : scanCanonicalize (H12AffineFastState.compose env44757 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound44757 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44758 : List Nat := [2,4,8,16,32,16,128,36,512,189,136,16,160,1,1,171,16,0,189,0,1,169,17,2,40,17,1,153,153,1,20,169,36,168,137,513]

theorem envBound44758 : H12AffineFastState.Bounded env44758 := by
  intro p hp
  have h : env44758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44757_44758 : H12AffineEnvironment.transform 9 189 env44757 = env44758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env44757 == env44758) = true)

theorem identity44758 : scanCanonicalize (H12AffineFastState.compose env44758 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound44758 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44759 : List Nat := [2,4,8,16,32,16,128,36,131,189,136,16,160,1,1,171,16,0,189,0,1,169,17,2,40,17,1,153,153,1,20,169,36,168,137,130]

theorem envBound44759 : H12AffineFastState.Bounded env44759 := by
  intro p hp
  have h : env44759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44758_44759 : H12AffineEnvironment.transform 8 131 env44758 = env44759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env44758 == env44759) = true)

def env44760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101329,98781,8328,65,6338997,2098512,17664,2111592,2102684,6349853,256,21792,46213,2175563]

theorem envBound44760 : H12AffineFastState.Bounded env44760 := by
  intro p hp
  have h : env44760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44732_44760 : H12AffineEnvironment.transform 17 190521 env44732 = env44760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env44732 == env44760) = true)

def env44761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,17,98781,8328,65,4237813,5392,17664,10280,1500,4256861,256,21792,46213,74251]

theorem envBound44761 : H12AffineFastState.Bounded env44761 := by
  intro p hp
  have h : env44761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44760_44761 : H12AffineEnvironment.transform 20 4160 env44760 = env44761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44760 == env44761) = true)

theorem identity44761 : scanCanonicalize (H12AffineFastState.compose env44761 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound44761 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144492,17,98781,8328,65,171417,5392,17664,10280,1500,180273,256,21792,46213,74251]

theorem envBound44762 : H12AffineFastState.Bounded env44762 := by
  intro p hp
  have h : env44762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44761_44762 : H12AffineEnvironment.transform 21 144492 env44761 = env44762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env44761 == env44762) = true)

def env44763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144492,17,98645,8192,65,171281,5392,17664,10280,1364,180273,256,21792,46093,74251]

theorem envBound44763 : H12AffineFastState.Bounded env44763 := by
  intro p hp
  have h : env44763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44762_44763 : H12AffineEnvironment.transform 6 8 env44762 = env44763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44762 == env44763) = true)

theorem identity44763 : scanCanonicalize (H12AffineFastState.compose env44763 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound44763 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190521,1024,32769,4160,144492,17,3,8192,65,171281,5392,17664,10280,1364,180273,256,21792,46093,41821]

theorem envBound44764 : H12AffineFastState.Bounded env44764 := by
  intro p hp
  have h : env44764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44763_44764 : H12AffineEnvironment.transform 15 33110 env44763 = env44764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env44763 == env44764) = true)

theorem identity44764 : scanCanonicalize (H12AffineFastState.compose env44764 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44764 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env44765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,342,131072,157753,1024,1,4160,144492,17,3,8192,65,138513,5392,17664,10280,1364,147505,256,21792,13325,9053]

theorem envBound44765 : H12AffineFastState.Bounded env44765 := by
  intro p hp
  have h : env44765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44764_44765 : H12AffineEnvironment.transform 14 0 env44764 = env44765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44764 == env44765) = true)

theorem identity44765 : scanCanonicalize (H12AffineFastState.compose env44765 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound44765 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env44766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,342,24909,2420,1024,1,4160,21793,17,3,8192,65,31836,5392,17664,10280,1364,8572,256,21792,13325,9053]

theorem envBound44766 : H12AffineFastState.Bounded env44766 := by
  intro p hp
  have h : env44766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44765_44766 : H12AffineEnvironment.transform 16 24909 env44765 = env44766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env44765 == env44766) = true)

theorem identity44766 : scanCanonicalize (H12AffineFastState.compose env44766 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44766 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env44767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,0,342,16449,2420,1024,1,4160,21793,17,3,268,65,23888,5392,17664,2340,1364,112,256,21792,5377,593]

theorem envBound44767 : H12AffineFastState.Bounded env44767 := by
  intro p hp
  have h : env44767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44766_44767 : H12AffineEnvironment.transform 12 268 env44766 = env44767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44766 == env44767) = true)

theorem identity44767 : scanCanonicalize (H12AffineFastState.compose env44767 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44767 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44768 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,262,16401,2340,1024,1,4112,21793,17,3,268,17,23808,5392,17664,2340,1284,32,256,21792,5377,513]

theorem envBound44768 : H12AffineFastState.Bounded env44768 := by
  intro p hp
  have h : env44768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44767_44768 : H12AffineEnvironment.transform 5 16 env44767 = env44768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44767 == env44768) = true)

def env44769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144492,17,98644,8193,65,171280,5392,17664,10280,1365,180273,256,21792,46092,74251]

theorem envBound44769 : H12AffineFastState.Bounded env44769 := by
  intro p hp
  have h : env44769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44762_44769 : H12AffineEnvironment.transform 6 9 env44762 = env44769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44762 == env44769) = true)

theorem identity44769 : scanCanonicalize (H12AffineFastState.compose env44769 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44769 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4160,144492,17,73737,8193,65,146509,5392,17664,10280,1365,156012,256,21792,5457,74251]

theorem envBound44770 : H12AffineFastState.Bounded env44770 := by
  intro p hp
  have h : env44770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44769_44770 : H12AffineEnvironment.transform 14 8541 env44769 = env44770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44769 == env44770) = true)

theorem identity44770 : scanCanonicalize (H12AffineFastState.compose env44770 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound44770 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,5440,23588,1024,8540,4160,8492,17,73737,8193,65,10509,5392,17664,10280,1365,29740,256,21792,5457,74251]

theorem envBound44771 : H12AffineFastState.Bounded env44771 := by
  intro p hp
  have h : env44771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44770_44771 : H12AffineEnvironment.transform 16 5440 env44770 = env44771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env44770 == env44771) = true)

theorem identity44771 : scanCanonicalize (H12AffineFastState.compose env44771 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound44771 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env44772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8541,65536,5440,10508,1024,8540,4160,8492,17,73737,8193,65,10509,5392,12328,10280,1365,260,256,8200,5457,74251]

theorem envBound44772 : H12AffineFastState.Bounded env44772 := by
  intro p hp
  have h : env44772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44771_44772 : H12AffineEnvironment.transform 13 13608 env44771 = env44772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env44771 == env44772) = true)

theorem identity44772 : scanCanonicalize (H12AffineFastState.compose env44772 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound44772 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5456,293,65536,5440,2420,1024,292,4160,340,17,65649,121,65,2421,5392,4176,2128,1365,260,256,112,5457,66163]

theorem envBound44773 : H12AffineFastState.Bounded env44773 := by
  intro p hp
  have h : env44773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44772_44773 : H12AffineEnvironment.transform 12 120 env44772 = env44773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env44772 == env44773) = true)

theorem identity44773 : scanCanonicalize (H12AffineFastState.compose env44773 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44773 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env44774 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5157,80,65536,5173,2049,1024,81,4160,33,17,65649,121,65,2048,5221,4176,2128,1056,113,117,112,5156,66163]

theorem envBound44774 : H12AffineFastState.Bounded env44774 := by
  intro p hp
  have h : env44774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44773_44774 : H12AffineEnvironment.transform 7 117 env44773 = env44774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44773 == env44774) = true)

theorem identity44774 : scanCanonicalize (H12AffineFastState.compose env44774 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound44774 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44775 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,120,4160,80,65536,4176,2049,101,81,4160,33,17,65649,121,65,2048,4096,4176,2128,69,113,117,112,4161,66163]

theorem envBound44775 : H12AffineFastState.Bounded env44775 := by
  intro p hp
  have h : env44775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44774_44775 : H12AffineEnvironment.transform 9 101 env44774 = env44775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env44774 == env44775) = true)

def env44776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,98781,8328,65,4237812,5393,17664,10281,1501,4256860,256,21792,46213,74250]

theorem envBound44776 : H12AffineFastState.Bounded env44776 := by
  intro p hp
  have h : env44776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44760_44776 : H12AffineEnvironment.transform 20 4161 env44760 = env44776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44760 == env44776) = true)

theorem identity44776 : scanCanonicalize (H12AffineFastState.compose env44776 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound44776 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138477,1024,29909,4161,4194304,16,95497,8328,65,4218144,5393,17664,10281,1501,4194440,256,21792,16465,74250]

theorem envBound44777 : H12AffineFastState.Bounded env44777 := by
  intro p hp
  have h : env44777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44776_44777 : H12AffineEnvironment.transform 14 29908 env44776 = env44777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env44776 == env44777) = true)

def env44778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138477,1024,8661,4161,4194304,16,73737,8328,65,4196384,5393,4096,10281,1501,4194440,256,32,5457,74250]

theorem envBound44778 : H12AffineFastState.Bounded env44778 := by
  intro p hp
  have h : env44778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44777_44778 : H12AffineEnvironment.transform 13 5376 env44777 = env44778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44777 == env44778) = true)

theorem identity44778 : scanCanonicalize (H12AffineFastState.compose env44778 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound44778 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,10400,1024,8661,4161,4194304,16,73737,8328,65,4196384,5393,4096,10281,1501,4194440,256,32,5457,74250]

theorem envBound44779 : H12AffineFastState.Bounded env44779 := by
  intro p hp
  have h : env44779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44778_44779 : H12AffineEnvironment.transform 16 13389 env44778 = env44779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env44778 == env44779) = true)

theorem identity44779 : scanCanonicalize (H12AffineFastState.compose env44779 (packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS)) = affineNative (2^(21+1) ^^^ 66046) := by decide +kernel

theorem selectedBound44779 : packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env44780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,10400,1024,8661,4161,66046,16,73737,8328,65,68062,5393,4096,10281,1501,65910,256,32,5457,74250]

theorem envBound44780 : H12AffineFastState.Bounded env44780 := by
  intro p hp
  have h : env44780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44779_44780 : H12AffineEnvironment.transform 21 66046 env44779 = env44780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66046 env44779 == env44780) = true)

theorem identity44780 : scanCanonicalize (H12AffineFastState.compose env44780 (packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,18,19,28] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound44780 : packedSelected [0,1,2,3,4,5,6,7,9,11,12,14,15,18,19,28] rootPS < 2^1333 := by decide +kernel

def env44781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8323,13389,10400,1024,8661,4161,8573,16,138,8328,65,10589,5393,4096,10281,1501,8693,256,32,5457,649]

theorem envBound44781 : H12AffineFastState.Bounded env44781 := by
  intro p hp
  have h : env44781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44780_44781 : H12AffineEnvironment.transform 15 8323 env44780 = env44781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env44780 == env44781) = true)

theorem identity44781 : scanCanonicalize (H12AffineFastState.compose env44781 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44781 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13389,10280,1024,8541,4161,8573,16,2,8192,65,10589,5393,4096,10281,1365,8573,256,32,5457,513]

theorem envBound44782 : H12AffineFastState.Bounded env44782 := by
  intro p hp
  have h : env44782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44781_44782 : H12AffineEnvironment.transform 6 8 env44781 = env44782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44781 == env44782) = true)

theorem identity44782 : scanCanonicalize (H12AffineFastState.compose env44782 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44782 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44783 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8203,13341,10280,1024,8461,4113,8493,16,2,8192,17,10509,5393,4096,10281,1285,8493,256,32,5377,513]

theorem envBound44783 : H12AffineFastState.Bounded env44783 := by
  intro p hp
  have h : env44783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44782_44783 : H12AffineEnvironment.transform 5 16 env44782 = env44783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44782 == env44783) = true)

theorem identity44783 : scanCanonicalize (H12AffineFastState.compose env44783 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44783 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env44784 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5393,2340,1024,1,4113,33,16,2,268,17,2049,5393,4096,2341,1285,33,256,32,5377,513]

theorem envBound44784 : H12AffineFastState.Bounded env44784 := by
  intro p hp
  have h : env44784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44783_44784 : H12AffineEnvironment.transform 12 268 env44783 = env44784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44783 == env44784) = true)

theorem identity44784 : scanCanonicalize (H12AffineFastState.compose env44784 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound44784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44785 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,293,268,1061,0,263,1076,2340,1024,1,308,33,16,2,268,17,2049,1076,293,2341,1285,33,256,32,1060,513]

theorem envBound44785 : H12AffineFastState.Bounded env44785 := by
  intro p hp
  have h : env44785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44784_44785 : H12AffineEnvironment.transform 11 293 env44784 = env44785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env44784 == env44785) = true)

theorem identity44785 : scanCanonicalize (H12AffineFastState.compose env44785 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound44785 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44786 : List Nat := [2,4,8,16,32,16,8,256,512,565,2048,293,268,528,0,263,513,2340,565,1,308,33,16,2,268,17,2049,513,293,2341,816,33,256,32,529,513]

theorem envBound44786 : H12AffineFastState.Bounded env44786 := by
  intro p hp
  have h : env44786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44785_44786 : H12AffineEnvironment.transform 9 565 env44785 = env44786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env44785 == env44786) = true)

theorem identity44786 : scanCanonicalize (H12AffineFastState.compose env44786 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound44786 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44787 : List Nat := [2,4,8,16,32,16,8,256,512,565,820,293,268,528,0,263,513,528,565,1,308,33,16,2,268,17,821,513,293,529,816,33,256,32,529,513]

theorem envBound44787 : H12AffineFastState.Bounded env44787 := by
  intro p hp
  have h : env44787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44786_44787 : H12AffineEnvironment.transform 10 820 env44786 = env44787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env44786 == env44787) = true)

def env44788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138477,1024,8660,4161,4194304,16,73736,8328,65,4196385,5393,4097,10281,1501,4194440,256,33,5456,74250]

theorem envBound44788 : H12AffineFastState.Bounded env44788 := by
  intro p hp
  have h : env44788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44777_44788 : H12AffineEnvironment.transform 13 5377 env44777 = env44788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44777 == env44788) = true)

theorem identity44788 : scanCanonicalize (H12AffineFastState.compose env44788 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound44788 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13509,10280,1024,8660,4161,4194304,16,73736,8328,65,4196385,5393,4097,10281,1501,4194440,256,33,5456,74250]

theorem envBound44789 : H12AffineFastState.Bounded env44789 := by
  intro p hp
  have h : env44789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44788_44789 : H12AffineEnvironment.transform 16 13509 env44788 = env44789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env44788 == env44789) = true)

theorem identity44789 : scanCanonicalize (H12AffineFastState.compose env44789 (packedSelected [0,2,4,6,9,11,16,18,27] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound44789 : packedSelected [0,2,4,6,9,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env44790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13509,10280,1024,8660,4161,73890,16,73736,8328,65,75907,5393,4097,10281,1501,73770,256,33,5456,74250]

theorem envBound44790 : H12AffineFastState.Bounded env44790 := by
  intro p hp
  have h : env44790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44789_44790 : H12AffineEnvironment.transform 21 73890 env44789 = env44790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env44789 == env44790) = true)

theorem identity44790 : scanCanonicalize (H12AffineFastState.compose env44790 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44790 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env44791 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5236,8352,65536,13509,10280,1024,8353,4161,73890,16,73736,8328,65,75907,5220,4097,10281,1192,73770,117,33,5157,74250]

theorem envBound44791 : H12AffineFastState.Bounded env44791 := by
  intro p hp
  have h : env44791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44790_44791 : H12AffineEnvironment.transform 7 117 env44790 = env44791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44790 == env44791) = true)

theorem identity44791 : scanCanonicalize (H12AffineFastState.compose env44791 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound44791 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env44792 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5236,8352,171,13509,10280,1024,8353,4161,8201,16,8355,8328,65,10280,5220,4097,10281,1192,8321,117,33,5157,8865]

theorem envBound44792 : H12AffineFastState.Bounded env44792 := by
  intro p hp
  have h : env44792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44791_44792 : H12AffineEnvironment.transform 15 171 env44791 = env44792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env44791 == env44792) = true)

theorem identity44792 : scanCanonicalize (H12AffineFastState.compose env44792 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound44792 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env44793 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,160,5236,0,171,5221,2184,1024,1,4161,169,16,3,40,65,2184,5220,4097,2185,1192,33,117,33,5157,513]

theorem envBound44793 : H12AffineFastState.Bounded env44793 := by
  intro p hp
  have h : env44793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44792_44793 : H12AffineEnvironment.transform 12 160 env44792 = env44793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env44792 == env44793) = true)

theorem identity44793 : scanCanonicalize (H12AffineFastState.compose env44793 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44793 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44794 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,160,5156,0,171,5173,2184,1024,1,4113,169,16,3,40,17,2184,5172,4097,2185,1192,33,37,33,5157,513]

theorem envBound44794 : H12AffineFastState.Bounded env44794 := by
  intro p hp
  have h : env44794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44793_44794 : H12AffineEnvironment.transform 5 16 env44793 = env44794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44793 == env44794) = true)

theorem identity44794 : scanCanonicalize (H12AffineFastState.compose env44794 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound44794 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44795 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,2200,160,3260,0,171,3245,2184,1024,1,2185,169,16,3,40,17,2184,3244,2201,2185,1192,33,37,33,3261,513]

theorem envBound44795 : H12AffineFastState.Bounded env44795 := by
  intro p hp
  have h : env44795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44794_44795 : H12AffineEnvironment.transform 11 2200 env44794 = env44795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env44794 == env44795) = true)

theorem identity44795 : scanCanonicalize (H12AffineFastState.compose env44795 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 665) := by decide +kernel

theorem selectedBound44795 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env44796 : List Nat := [2,4,8,16,32,16,128,37,512,1024,665,513,160,1573,0,171,1588,529,1024,1,528,169,16,3,40,17,529,1589,512,528,1192,33,37,33,1572,513]

theorem envBound44796 : H12AffineFastState.Bounded env44796 := by
  intro p hp
  have h : env44796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44795_44796 : H12AffineEnvironment.transform 10 665 env44795 = env44796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 665 env44795 == env44796) = true)

theorem identity44796 : scanCanonicalize (H12AffineFastState.compose env44796 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound44796 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44797 : List Nat := [2,4,8,16,32,16,128,37,512,565,665,513,160,16,0,171,1,529,565,1,528,169,16,3,40,17,529,0,512,528,669,33,37,33,17,513]

theorem envBound44797 : H12AffineFastState.Bounded env44797 := by
  intro p hp
  have h : env44797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44796_44797 : H12AffineEnvironment.transform 9 565 env44796 = env44797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env44796 == env44797) = true)

theorem identity44797 : scanCanonicalize (H12AffineFastState.compose env44797 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44797 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env44798 : List Nat := [2,4,8,16,32,16,8,37,512,565,529,513,40,16,0,35,1,529,565,1,528,33,16,3,40,17,529,0,512,528,533,33,37,33,17,513]

theorem envBound44798 : H12AffineFastState.Bounded env44798 := by
  intro p hp
  have h : env44798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44797_44798 : H12AffineEnvironment.transform 6 8 env44797 = env44798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44797 == env44798) = true)

theorem identity44798 : scanCanonicalize (H12AffineFastState.compose env44798 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44798 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44799 : List Nat := [2,4,8,16,32,16,8,37,16,37,1,17,40,16,0,35,1,1,37,1,0,33,16,3,40,17,1,0,16,0,5,33,37,33,17,17]

theorem envBound44799 : H12AffineFastState.Bounded env44799 := by
  intro p hp
  have h : env44799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44798_44799 : H12AffineEnvironment.transform 8 16 env44798 = env44799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44798 == env44799) = true)

def env44800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2553961,485860,8328,65,6705549,2551145,437560,2111593,2102685,6687780,256,21793,46212,2175562]

theorem envBound44800 : H12AffineFastState.Bounded env44800 := by
  intro p hp
  have h : env44800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44731_44800 : H12AffineEnvironment.transform 22 2553961 env44731 = env44800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2553961 env44731 == env44800) = true)

def env44801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,2097152,4194304,2101329,98780,8328,65,6338997,2098513,17664,2111593,2102685,6349852,256,21793,46212,2175562]

theorem envBound44801 : H12AffineFastState.Bounded env44801 := by
  intro p hp
  have h : env44801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44800_44801 : H12AffineEnvironment.transform 17 190520 env44800 = env44801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env44800 == env44801) = true)

def env44802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,17,98780,8328,65,4237813,5393,17664,10281,1501,4256860,256,21793,46212,74250]

theorem envBound44802 : H12AffineFastState.Bounded env44802 := by
  intro p hp
  have h : env44802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44801_44802 : H12AffineEnvironment.transform 20 4160 env44801 = env44802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44801 == env44802) = true)

theorem identity44802 : scanCanonicalize (H12AffineFastState.compose env44802 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254130) := by decide +kernel

theorem selectedBound44802 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,254130,17,98780,8328,65,215367,5393,17664,10281,1501,201966,256,21793,46212,74250]

theorem envBound44803 : H12AffineFastState.Bounded env44803 := by
  intro p hp
  have h : env44803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44802_44803 : H12AffineEnvironment.transform 21 254130 env44802 = env44803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254130 env44802 == env44803) = true)

theorem identity44803 : scanCanonicalize (H12AffineFastState.compose env44803 (packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound44803 : packedSelected [3,10,11,12,15,16,17,18,20,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env44804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,100387,1024,32769,4160,32937,17,98780,8328,65,10588,5393,17664,10281,1501,29941,256,21793,46212,74250]

theorem envBound44804 : H12AffineFastState.Bounded env44804 := by
  intro p hp
  have h : env44804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44803_44804 : H12AffineEnvironment.transform 16 90139 env44803 = env44804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env44803 == env44804) = true)

theorem identity44804 : scanCanonicalize (H12AffineFastState.compose env44804 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound44804 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env44805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,97527,1024,29909,4160,29821,17,95496,8328,65,10588,5393,17664,10281,1501,29941,256,21793,16464,74250]

theorem envBound44805 : H12AffineFastState.Bounded env44805 := by
  intro p hp
  have h : env44805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44804_44805 : H12AffineEnvironment.transform 14 29908 env44804 = env44805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env44804 == env44805) = true)

theorem identity44805 : scanCanonicalize (H12AffineFastState.compose env44805 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44805 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env44806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16400,23804,1024,29909,4160,29821,17,21763,8328,65,10588,5393,17664,10281,1501,29941,256,21793,16464,513]

theorem envBound44806 : H12AffineFastState.Bounded env44806 := by
  intro p hp
  have h : env44806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44805_44806 : H12AffineEnvironment.transform 15 8203 env44805 = env44806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44805 == env44806) = true)

def env44807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,98780,8328,65,4237812,5392,17664,10280,1500,4256861,256,21793,46212,74251]

theorem envBound44807 : H12AffineFastState.Bounded env44807 := by
  intro p hp
  have h : env44807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44801_44807 : H12AffineEnvironment.transform 20 4161 env44801 = env44807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44801 == env44807) = true)

theorem identity44807 : scanCanonicalize (H12AffineFastState.compose env44807 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44807 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,4194304,16,41430,8328,65,4237812,5392,17664,10280,1500,4256861,256,21793,46212,513]

theorem envBound44808 : H12AffineFastState.Bounded env44808 := by
  intro p hp
  have h : env44808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44807_44808 : H12AffineEnvironment.transform 15 8202 env44807 = env44808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44807 == env44808) = true)

theorem identity44808 : scanCanonicalize (H12AffineFastState.compose env44808 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32937) := by decide +kernel

theorem selectedBound44808 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,32937,16,41430,8328,65,10589,5392,17664,10280,1500,29940,256,21793,46212,513]

theorem envBound44809 : H12AffineFastState.Bounded env44809 := by
  intro p hp
  have h : env44809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44808_44809 : H12AffineEnvironment.transform 21 32937 env44808 = env44809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32937 env44808 == env44809) = true)

theorem identity44809 : scanCanonicalize (H12AffineFastState.compose env44809 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44809 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env44810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,131072,149860,1024,8541,4161,8693,16,138,8328,65,10589,5392,17664,10280,1500,29940,256,21793,5592,513]

theorem envBound44810 : H12AffineFastState.Bounded env44810 := by
  intro p hp
  have h : env44810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44809_44810 : H12AffineEnvironment.transform 14 8540 env44809 = env44810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44809 == env44810) = true)

theorem identity44810 : scanCanonicalize (H12AffineFastState.compose env44810 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound44810 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,24908,10280,1024,8541,4161,8693,16,138,8328,65,10589,5392,17664,10280,1500,29940,256,21793,5592,513]

theorem envBound44811 : H12AffineFastState.Bounded env44811 := by
  intro p hp
  have h : env44811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44810_44811 : H12AffineEnvironment.transform 16 24908 env44810 = env44811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env44810 == env44811) = true)

def env44812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101328,98781,8328,65,6338996,2098512,17665,2111593,2102685,6349853,256,21793,46212,2175562]

theorem envBound44812 : H12AffineFastState.Bounded env44812 := by
  intro p hp
  have h : env44812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44800_44812 : H12AffineEnvironment.transform 17 190521 env44800 = env44812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env44800 == env44812) = true)

def env44813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,98781,8328,65,4237812,5392,17665,10281,1501,4256861,256,21793,46212,74250]

theorem envBound44813 : H12AffineFastState.Bounded env44813 := by
  intro p hp
  have h : env44813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44812_44813 : H12AffineEnvironment.transform 20 4160 env44812 = env44813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44812 == env44813) = true)

theorem identity44813 : scanCanonicalize (H12AffineFastState.compose env44813 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound44813 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,190521,1024,32769,4160,4194304,16,21763,8328,65,4237812,5392,17665,10281,1501,4256861,256,21793,46212,63188]

theorem envBound44814 : H12AffineFastState.Bounded env44814 := by
  intro p hp
  have h : env44814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44813_44814 : H12AffineEnvironment.transform 15 54494 env44813 = env44814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env44813 == env44814) = true)

def env44815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190521,1024,32769,4160,4194304,16,21763,8192,65,4237692,5392,17665,10281,1365,4256861,256,21793,46092,63068]

theorem envBound44815 : H12AffineFastState.Bounded env44815 := by
  intro p hp
  have h : env44815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44814_44815 : H12AffineEnvironment.transform 6 8 env44814 = env44815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44814 == env44815) = true)

theorem identity44815 : scanCanonicalize (H12AffineFastState.compose env44815 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound44815 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,10280,1024,32769,4160,4194304,16,21763,8192,65,4237692,5392,17665,10281,1365,4256861,256,21793,46092,63068]

theorem envBound44816 : H12AffineFastState.Bounded env44816 := by
  intro p hp
  have h : env44816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44815_44816 : H12AffineEnvironment.transform 16 49169 env44815 = env44816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env44815 == env44816) = true)

theorem identity44816 : scanCanonicalize (H12AffineFastState.compose env44816 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound44816 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,21510,16449,10280,1024,81,4160,4194304,16,21763,8192,65,4204844,5392,17665,10281,1365,4224013,256,21793,13404,30220]

theorem envBound44817 : H12AffineFastState.Bounded env44817 := by
  intro p hp
  have h : env44817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44816_44817 : H12AffineEnvironment.transform 14 80 env44816 = env44817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env44816 == env44817) = true)

theorem identity44817 : scanCanonicalize (H12AffineFastState.compose env44817 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44817 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env44818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,80,21510,16449,2420,1024,81,4160,4194304,16,21763,348,65,4196464,5392,17665,2421,1365,4216145,256,21793,5376,22352]

theorem envBound44818 : H12AffineFastState.Bounded env44818 := by
  intro p hp
  have h : env44818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44817_44818 : H12AffineEnvironment.transform 12 348 env44817 = env44818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44817 == env44818) = true)

theorem identity44818 : scanCanonicalize (H12AffineFastState.compose env44818 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44818 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,80,263,5440,2420,1024,81,4160,4194304,16,2,348,65,4196464,5392,4096,2421,1365,4194384,256,32,5376,593]

theorem envBound44819 : H12AffineFastState.Bounded env44819 := by
  intro p hp
  have h : env44819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44818_44819 : H12AffineEnvironment.transform 13 5377 env44818 = env44819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44818 == env44819) = true)

theorem identity44819 : scanCanonicalize (H12AffineFastState.compose env44819 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound44819 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,80,263,5440,2420,1024,81,4160,113,16,2,348,65,2049,5392,4096,2421,1365,33,256,32,5376,593]

theorem envBound44820 : H12AffineFastState.Bounded env44820 := by
  intro p hp
  have h : env44820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44819_44820 : H12AffineEnvironment.transform 21 113 env44819 = env44820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env44819 == env44820) = true)

theorem identity44820 : scanCanonicalize (H12AffineFastState.compose env44820 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound44820 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env44821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,348,2128,80,263,2065,2420,1024,81,3345,113,16,2,348,65,2049,2113,3409,2421,1365,33,256,32,2129,593]

theorem envBound44821 : H12AffineFastState.Bounded env44821 := by
  intro p hp
  have h : env44821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44820_44821 : H12AffineEnvironment.transform 11 3409 env44820 = env44821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env44820 == env44821) = true)

theorem identity44821 : scanCanonicalize (H12AffineFastState.compose env44821 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound44821 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env44822 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,2357,348,2128,80,263,2065,2420,100,81,2421,113,16,2,348,65,2049,2113,2357,2421,305,33,256,32,2129,593]

theorem envBound44822 : H12AffineFastState.Bounded env44822 := by
  intro p hp
  have h : env44822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44821_44822 : H12AffineEnvironment.transform 9 100 env44821 = env44822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env44821 == env44822) = true)

theorem identity44822 : scanCanonicalize (H12AffineFastState.compose env44822 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44822 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44823 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,2065,120,2128,80,35,2065,2128,100,81,2129,113,16,2,120,65,2049,2113,2065,2129,21,33,36,32,2129,593]

theorem envBound44823 : H12AffineFastState.Bounded env44823 := by
  intro p hp
  have h : env44823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44822_44823 : H12AffineEnvironment.transform 7 36 env44822 = env44823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44822 == env44823) = true)

theorem identity44823 : scanCanonicalize (H12AffineFastState.compose env44823 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound44823 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env44824 : List Nat := [2,4,8,16,32,64,8,36,512,100,64,81,120,16,80,35,81,16,100,81,17,113,16,2,120,65,65,1,81,17,21,33,36,32,17,593]

theorem envBound44824 : H12AffineFastState.Bounded env44824 := by
  intro p hp
  have h : env44824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44823_44824 : H12AffineEnvironment.transform 10 64 env44823 = env44824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env44823 == env44824) = true)

theorem identity44824 : scanCanonicalize (H12AffineFastState.compose env44824 (packedSelected [0,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44824 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env44825 : List Nat := [2,4,8,16,32,17,8,36,512,53,17,0,41,16,1,35,0,16,53,0,17,32,16,2,41,16,16,1,0,17,21,33,36,32,17,512]

theorem envBound44825 : H12AffineFastState.Bounded env44825 := by
  intro p hp
  have h : env44825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44824_44825 : H12AffineEnvironment.transform 5 17 env44824 = env44825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44824 == env44825) = true)

theorem identity44825 : scanCanonicalize (H12AffineFastState.compose env44825 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound44825 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44826 : List Nat := [2,4,8,16,20,17,8,16,512,1,17,0,29,16,1,23,0,16,1,0,17,20,16,2,29,16,16,1,0,17,21,21,16,20,17,512]

theorem envBound44826 : H12AffineFastState.Bounded env44826 := by
  intro p hp
  have h : env44826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44825_44826 : H12AffineEnvironment.transform 4 20 env44825 = env44826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env44825 == env44826) = true)

theorem identity44826 : scanCanonicalize (H12AffineFastState.compose env44826 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound44826 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44827 : List Nat := [2,4,8,16,20,17,8,16,25,1,17,0,29,16,1,23,0,16,1,0,17,20,16,2,29,16,16,1,0,17,21,21,16,20,17,25]

theorem envBound44827 : H12AffineFastState.Bounded env44827 := by
  intro p hp
  have h : env44827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44826_44827 : H12AffineEnvironment.transform 8 25 env44826 = env44827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env44826 == env44827) = true)

theorem identity44827 : scanCanonicalize (H12AffineFastState.compose env44827 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound44827 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44828 : List Nat := [2,0,8,16,16,17,8,16,25,1,17,0,25,16,1,19,0,16,1,0,17,16,16,2,25,16,16,1,0,17,17,17,16,16,17,25]

theorem envBound44828 : H12AffineFastState.Bounded env44828 := by
  intro p hp
  have h : env44828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44827_44828 : H12AffineEnvironment.transform 1 0 env44827 = env44828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env44827 == env44828) = true)

theorem identity44828 : scanCanonicalize (H12AffineFastState.compose env44828 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44828 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44829 : List Nat := [2,0,3,16,16,17,3,16,18,1,17,0,18,16,1,19,0,16,1,0,17,16,16,2,18,16,16,1,0,17,17,17,16,16,17,18]

theorem envBound44829 : H12AffineFastState.Bounded env44829 := by
  intro p hp
  have h : env44829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44828_44829 : H12AffineEnvironment.transform 2 3 env44828 = env44829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44828 == env44829) = true)

theorem identity44829 : scanCanonicalize (H12AffineFastState.compose env44829 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44829 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44830 : List Nat := [2,0,3,1,1,0,3,1,3,1,0,0,3,1,1,2,0,1,1,0,0,1,1,2,3,1,1,1,0,0,0,0,1,1,0,3]

theorem envBound44830 : H12AffineFastState.Bounded env44830 := by
  intro p hp
  have h : env44830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44829_44830 : H12AffineEnvironment.transform 3 1 env44829 = env44830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44829 == env44830) = true)

def env44831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4160,4194304,16,21763,8193,65,4237693,5392,17665,10281,1364,4256861,256,21793,46093,63069]

theorem envBound44831 : H12AffineFastState.Bounded env44831 := by
  intro p hp
  have h : env44831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44814_44831 : H12AffineEnvironment.transform 6 9 env44814 = env44831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44814 == env44831) = true)

theorem identity44831 : scanCanonicalize (H12AffineFastState.compose env44831 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound44831 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,35188,1024,32769,4160,4194304,16,21763,8193,65,4237693,5392,17665,10281,1364,4256861,256,21793,46093,63069]

theorem envBound44832 : H12AffineFastState.Bounded env44832 := by
  intro p hp
  have h : env44832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44831_44832 : H12AffineEnvironment.transform 16 24909 env44831 = env44832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env44831 == env44832) = true)

theorem identity44832 : scanCanonicalize (H12AffineFastState.compose env44832 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 29821) := by decide +kernel

theorem selectedBound44832 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,35188,1024,32769,4160,29821,16,21763,8193,65,56576,5392,17665,10281,1364,32800,256,21793,46093,63069]

theorem envBound44833 : H12AffineFastState.Bounded env44833 := by
  intro p hp
  have h : env44833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44832_44833 : H12AffineEnvironment.transform 21 29821 env44832 = env44833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29821 env44832 == env44833) = true)

theorem identity44833 : scanCanonicalize (H12AffineFastState.compose env44833 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound44833 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,343,24909,23668,1024,21761,4160,29821,16,21763,8193,65,2048,5392,17665,10281,1364,21792,256,21793,24845,9053]

theorem envBound44834 : H12AffineFastState.Bounded env44834 := by
  intro p hp
  have h : env44834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44833_44834 : H12AffineEnvironment.transform 14 21760 env44833 = env44834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env44833 == env44834) = true)

theorem identity44834 : scanCanonicalize (H12AffineFastState.compose env44834 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44834 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,343,13388,2421,1024,0,4160,8572,16,2,8193,65,2048,5392,4096,10281,1364,33,256,32,13324,9053]

theorem envBound44835 : H12AffineFastState.Bounded env44835 := by
  intro p hp
  have h : env44835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44834_44835 : H12AffineEnvironment.transform 13 5377 env44834 = env44835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44834 == env44835) = true)

theorem identity44835 : scanCanonicalize (H12AffineFastState.compose env44835 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44835 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44836 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8192,5377,1,343,13388,2389,1024,0,4160,8540,16,2,8193,65,2048,5392,4096,10249,1364,1,256,0,13324,9053]

theorem envBound44836 : H12AffineFastState.Bounded env44836 := by
  intro p hp
  have h : env44836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44835_44836 : H12AffineEnvironment.transform 4 0 env44835 = env44836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44835 == env44836) = true)

theorem identity44836 : scanCanonicalize (H12AffineFastState.compose env44836 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound44836 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env44837 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,9,5377,1,343,5189,2389,1024,0,4160,341,16,2,8,65,2048,5392,4096,2048,1364,1,256,0,5125,852]

theorem envBound44837 : H12AffineFastState.Bounded env44837 := by
  intro p hp
  have h : env44837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44836_44837 : H12AffineEnvironment.transform 12 9 env44836 = env44837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env44836 == env44837) = true)

theorem identity44837 : scanCanonicalize (H12AffineFastState.compose env44837 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound44837 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44838 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,3408,9,2129,1,343,2325,2389,1024,0,3344,341,16,2,8,65,2048,2112,3408,2048,1364,1,256,0,2389,852]

theorem envBound44838 : H12AffineFastState.Bounded env44838 := by
  intro p hp
  have h : env44838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0