import H12CloudChart0Data019

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env4944 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1024,32768,4097,46228,184,41002,8329,184,323713,16384,16552,22561,74795,17429,4,20480,1045,513]

theorem envBound4944 : H12AffineFastState.Bounded env4944 := by
  intro p hp
  have h : env4944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4943_4944 : H12AffineEnvironment.transform 7 4 env4943 = env4944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4943 == env4944) = true)

theorem identity4944 : scanCanonicalize (H12AffineFastState.compose env4944 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound4944 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env4945 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,25663,4265,262144,1024,32768,4097,46228,184,41002,8329,184,323713,16384,16552,22561,16404,17429,4,20480,1045,513]

theorem envBound4945 : H12AffineFastState.Bounded env4945 := by
  intro p hp
  have h : env4945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4944_4945 : H12AffineEnvironment.transform 15 25663 env4944 = env4945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env4944 == env4945) = true)

theorem identity4945 : scanCanonicalize (H12AffineFastState.compose env4945 (packedSelected [1,2,5,10,11,13,23] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4945 : packedSelected [1,2,5,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env4946 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,25663,4265,2080,1024,32768,4097,46228,184,41002,8329,184,63649,16384,16552,22561,16404,17429,4,20480,1045,513]

theorem envBound4946 : H12AffineFastState.Bounded env4946 := by
  intro p hp
  have h : env4946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4945_4946 : H12AffineEnvironment.transform 17 2080 env4945 = env4946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4945 == env4946) = true)

theorem identity4946 : scanCanonicalize (H12AffineFastState.compose env4946 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4946 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env4947 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,32768,25663,4097,2080,1024,32768,4097,46140,16,41002,8225,16,63497,16384,16384,22561,16404,17429,4,20480,1045,513]

theorem envBound4947 : H12AffineFastState.Bounded env4947 := by
  intro p hp
  have h : env4947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4946_4947 : H12AffineEnvironment.transform 6 40 env4946 = env4947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4946 == env4947) = true)

theorem identity4947 : scanCanonicalize (H12AffineFastState.compose env4947 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 27154) := by decide +kernel

theorem selectedBound4947 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env4948 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,27154,25663,4097,2080,1024,27154,4097,24110,16,19000,8225,16,4635,16384,16384,22561,16404,17429,4,20480,1045,513]

theorem envBound4948 : H12AffineFastState.Bounded env4948 := by
  intro p hp
  have h : env4948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4947_4948 : H12AffineEnvironment.transform 14 27154 env4947 = env4948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27154 env4947 == env4948) = true)

theorem identity4948 : scanCanonicalize (H12AffineFastState.compose env4948 (packedSelected [1,3,5,6,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4948 : packedSelected [1,3,5,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env4949 : List Nat := [2,4,8,16,32,16,40,4,33,1024,2048,4096,8192,16384,26675,25663,4097,2080,1024,26675,4097,23567,16,18457,8225,16,4154,16384,16384,22561,16404,17429,4,20480,1045,32]

theorem envBound4949 : H12AffineFastState.Bounded env4949 := by
  intro p hp
  have h : env4949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4948_4949 : H12AffineEnvironment.transform 8 33 env4948 = env4949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4948 == env4949) = true)

theorem identity4949 : scanCanonicalize (H12AffineFastState.compose env4949 (packedSelected [5,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound4949 : packedSelected [5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env4950 : List Nat := [2,4,8,16,32,16,40,4,33,1024,2048,1044,8192,16384,26675,25663,1045,2080,1024,26675,1045,18459,16,18457,8225,16,1070,16384,16384,19509,16404,17429,4,17428,1045,32]

theorem envBound4950 : H12AffineFastState.Bounded env4950 := by
  intro p hp
  have h : env4950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4949_4950 : H12AffineEnvironment.transform 11 1044 env4949 = env4950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env4949 == env4950) = true)

def env4951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,46529,493,41002,8329,445,323793,16384,16892,22641,74795,17681,256,20560,1344,512]

theorem envBound4951 : H12AffineFastState.Bounded env4951 := by
  intro p hp
  have h : env4951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4941_4951 : H12AffineEnvironment.transform 21 46529 env4941 = env4951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46529 env4941 == env4951) = true)

theorem identity4951 : scanCanonicalize (H12AffineFastState.compose env4951 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound4951 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,32768,65536,1464,262144,1024,32768,1092,41348,493,41002,8329,445,320660,16384,16892,19508,74795,17681,256,17429,1344,512]

theorem envBound4952 : H12AffineFastState.Bounded env4952 := by
  intro p hp
  have h : env4952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4951_4952 : H12AffineEnvironment.transform 11 1093 env4951 = env4952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env4951 == env4952) = true)

theorem identity4952 : scanCanonicalize (H12AffineFastState.compose env4952 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26309) := by decide +kernel

theorem selectedBound4952 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,26309,65536,1464,262144,1024,26309,1092,18241,493,18159,8329,445,262737,16384,16892,19508,74795,17681,256,17429,1344,512]

theorem envBound4953 : H12AffineFastState.Bounded env4953 := by
  intro p hp
  have h : env4953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4952_4953 : H12AffineEnvironment.transform 14 26309 env4952 = env4953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26309 env4952 == env4953) = true)

theorem identity4953 : scanCanonicalize (H12AffineFastState.compose env4953 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25798) := by decide +kernel

theorem selectedBound4953 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,26309,25798,1464,262144,1024,26309,1092,18241,493,18159,8329,445,262737,16384,16892,19508,16621,17681,256,17429,1344,512]

theorem envBound4954 : H12AffineFastState.Bounded env4954 := by
  intro p hp
  have h : env4954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4953_4954 : H12AffineEnvironment.transform 15 25798 env4953 = env4954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25798 env4953 == env4954) = true)

def env4955 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,1093,8192,16384,26173,25662,1344,262144,1024,26173,1092,18241,277,17943,8305,325,262737,16384,16644,19508,16405,17681,256,17429,1344,512]

theorem envBound4955 : H12AffineFastState.Bounded env4955 := by
  intro p hp
  have h : env4955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4954_4955 : H12AffineEnvironment.transform 6 120 env4954 = env4955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env4954 == env4955) = true)

def env4956 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,1093,8192,16384,26172,25663,1345,262144,1024,26172,1092,18241,276,17942,8304,324,262737,16384,16645,19508,16404,17681,256,17429,1344,512]

theorem envBound4956 : H12AffineFastState.Bounded env4956 := by
  intro p hp
  have h : env4956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4954_4956 : H12AffineEnvironment.transform 6 121 env4954 = env4956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env4954 == env4956) = true)

theorem identity4956 : scanCanonicalize (H12AffineFastState.compose env4956 (packedSelected [0,27] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4956 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env4957 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,1093,8192,16384,26172,25663,1093,262144,1024,26172,1092,17989,16,17942,8304,64,262737,16384,16385,19508,16404,17429,4,17429,1092,512]

theorem envBound4957 : H12AffineFastState.Bounded env4957 := by
  intro p hp
  have h : env4957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4956_4957 : H12AffineEnvironment.transform 7 4 env4956 = env4957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4956 == env4957) = true)

theorem identity4957 : scanCanonicalize (H12AffineFastState.compose env4957 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 16411) := by decide +kernel

theorem selectedBound4957 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4958 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,1093,8192,16384,26172,25663,1093,16411,1024,26172,1092,17989,16,17942,8304,64,16970,16384,16385,19508,16404,17429,4,17429,1092,512]

theorem envBound4958 : H12AffineFastState.Bounded env4958 := by
  intro p hp
  have h : env4958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4957_4958 : H12AffineEnvironment.transform 17 16411 env4957 = env4958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16411 env4957 == env4958) = true)

theorem identity4958 : scanCanonicalize (H12AffineFastState.compose env4958 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound4958 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4959 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,16384,26172,25663,1045,16411,1024,26172,1044,17941,16,17942,8224,16,16922,16384,16385,19508,16404,17429,4,17429,1044,512]

theorem envBound4959 : H12AffineFastState.Bounded env4959 := by
  intro p hp
  have h : env4959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4958_4959 : H12AffineEnvironment.transform 5 16 env4958 = env4959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4958 == env4959) = true)

theorem identity4959 : scanCanonicalize (H12AffineFastState.compose env4959 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 11804) := by decide +kernel

theorem selectedBound4959 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env4960 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,11804,2080,2595,1045,11783,1024,2080,1044,10249,16,10250,8224,16,11270,11804,11805,8744,11784,10761,4,10761,1044,512]

theorem envBound4960 : H12AffineFastState.Bounded env4960 := by
  intro p hp
  have h : env4960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4959_4960 : H12AffineEnvironment.transform 13 11804 env4959 = env4960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11804 env4959 == env4960) = true)

theorem identity4960 : scanCanonicalize (H12AffineFastState.compose env4960 (packedSelected [0,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound4960 : packedSelected [0,2,3,12] rootPS < 2^1333 := by decide +kernel

def env4961 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1045,1045,8192,8713,1077,1590,1045,8722,1024,1077,1044,9244,16,9247,8224,16,8211,8713,8712,8744,8733,9756,4,9756,1044,512]

theorem envBound4961 : H12AffineFastState.Bounded env4961 := by
  intro p hp
  have h : env4961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4960_4961 : H12AffineEnvironment.transform 10 1045 env4960 = env4961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env4960 == env4961) = true)

theorem identity4961 : scanCanonicalize (H12AffineFastState.compose env4961 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4961 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env4962 : List Nat := [2,4,8,10,32,10,41,4,512,1024,1039,1039,8192,8713,1071,1580,1039,8712,1024,1071,1038,9222,10,9221,8224,10,8201,8713,8712,8744,8711,9734,4,9734,1038,512]

theorem envBound4962 : H12AffineFastState.Bounded env4962 := by
  intro p hp
  have h : env4962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4961_4962 : H12AffineEnvironment.transform 3 10 env4961 = env4962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4961 == env4962) = true)

theorem identity4962 : scanCanonicalize (H12AffineFastState.compose env4962 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound4962 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env4963 : List Nat := [2,4,8,10,32,10,41,4,512,1024,1039,1039,521,0,1071,1580,1039,1,1024,1071,1038,1551,10,1548,553,10,512,0,1,33,14,1039,4,1039,1038,512]

theorem envBound4963 : H12AffineFastState.Bounded env4963 := by
  intro p hp
  have h : env4963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4962_4963 : H12AffineEnvironment.transform 12 521 env4962 = env4963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env4962 == env4963) = true)

theorem identity4963 : scanCanonicalize (H12AffineFastState.compose env4963 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4963 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env4964 : List Nat := [2,4,8,10,0,10,9,4,512,1024,1039,1039,521,0,1039,1548,1039,1,1024,1039,1038,1551,10,1548,521,10,512,0,1,1,14,1039,4,1039,1038,512]

theorem envBound4964 : H12AffineFastState.Bounded env4964 := by
  intro p hp
  have h : env4964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4963_4964 : H12AffineEnvironment.transform 4 0 env4963 = env4964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4963 == env4964) = true)

theorem identity4964 : scanCanonicalize (H12AffineFastState.compose env4964 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 527) := by decide +kernel

theorem selectedBound4964 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4965 : List Nat := [2,4,8,10,0,10,9,4,512,527,512,512,521,0,512,3,512,1,527,512,513,0,10,3,521,10,512,0,1,1,14,512,4,512,513,512]

theorem envBound4965 : H12AffineFastState.Bounded env4965 := by
  intro p hp
  have h : env4965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4964_4965 : H12AffineEnvironment.transform 9 527 env4964 = env4965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 527 env4964 == env4965) = true)

theorem identity4965 : scanCanonicalize (H12AffineFastState.compose env4965 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4965 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env4966 : List Nat := [2,4,8,10,0,10,9,4,1,14,1,1,8,0,1,3,1,1,14,1,0,0,10,3,8,10,1,0,1,1,14,1,4,1,0,1]

theorem envBound4966 : H12AffineFastState.Bounded env4966 := by
  intro p hp
  have h : env4966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4965_4966 : H12AffineEnvironment.transform 8 1 env4965 = env4966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4965 == env4966) = true)

def env4967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323792,16384,16892,22640,74794,12644669,257,20561,4239489,8389612]

theorem envBound4967 : H12AffineFastState.Bounded env4967 := by
  intro p hp
  have h : env4967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4939_4967 : H12AffineEnvironment.transform 18 1025 env4939 = env4967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4939 == env4967) = true)

theorem identity4967 : scanCanonicalize (H12AffineFastState.compose env4967 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 61740) := by decide +kernel

theorem selectedBound4967 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,61740,8388608,41002,8329,8388689,323792,16384,16892,22640,74794,8388625,257,20561,16813,8389612]

theorem envBound4968 : H12AffineFastState.Bounded env4968 := by
  intro p hp
  have h : env4968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4967_4968 : H12AffineEnvironment.transform 21 61740 env4967 = env4968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61740 env4967 == env4968) = true)

def env4969 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,61740,8388608,41002,8329,8388609,323712,16384,16812,22560,74794,8388625,257,20481,16813,8389564]

theorem envBound4969 : H12AffineFastState.Bounded env4969 := by
  intro p hp
  have h : env4969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4968_4969 : H12AffineEnvironment.transform 5 16 env4968 = env4969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4968 == env4969) = true)

theorem identity4969 : scanCanonicalize (H12AffineFastState.compose env4969 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4969 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4970 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,61740,444,41002,8329,445,323712,16384,16812,22560,74794,429,257,20481,16813,512]

theorem envBound4970 : H12AffineFastState.Bounded env4970 := by
  intro p hp
  have h : env4970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4969_4970 : H12AffineEnvironment.transform 22 444 env4969 = env4970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4969 == env4970) = true)

theorem identity4970 : scanCanonicalize (H12AffineFastState.compose env4970 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound4970 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4971 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1025,32768,4097,41349,444,41002,8329,445,303145,4265,4357,2185,74794,429,257,168,4356,512]

theorem envBound4971 : H12AffineFastState.Bounded env4971 := by
  intro p hp
  have h : env4971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4970_4971 : H12AffineEnvironment.transform 13 4265 env4970 = env4971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env4970 == env4971) = true)

theorem identity4971 : scanCanonicalize (H12AffineFastState.compose env4971 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound4971 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4972 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,65536,4525,262144,1025,13884,4097,6073,444,5654,8329,445,267797,4265,4357,2185,74794,429,257,168,4356,512]

theorem envBound4972 : H12AffineFastState.Bounded env4972 := by
  intro p hp
  have h : env4972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4971_4972 : H12AffineEnvironment.transform 14 13884 env4971 = env4972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env4971 == env4972) = true)

theorem identity4972 : scanCanonicalize (H12AffineFastState.compose env4972 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound4972 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4973 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,8234,4525,262144,1025,13884,4097,6073,444,5654,8329,445,267797,4265,4357,2185,1024,429,257,168,4356,512]

theorem envBound4973 : H12AffineFastState.Bounded env4973 := by
  intro p hp
  have h : env4973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4972_4973 : H12AffineEnvironment.transform 15 8234 env4972 = env4973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env4972 == env4973) = true)

theorem identity4973 : scanCanonicalize (H12AffineFastState.compose env4973 (packedSelected [0,1,5,8,18,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4973 : packedSelected [0,1,5,8,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env4974 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,8234,4525,2081,1025,13884,4097,6073,444,5654,8329,445,7732,4265,4357,2185,1024,429,257,168,4356,512]

theorem envBound4974 : H12AffineFastState.Bounded env4974 := by
  intro p hp
  have h : env4974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4973_4974 : H12AffineEnvironment.transform 17 2081 env4973 = env4974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4973 == env4974) = true)

theorem identity4974 : scanCanonicalize (H12AffineFastState.compose env4974 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1803) := by decide +kernel

theorem selectedBound4974 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env4975 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1803,8192,1954,8503,8234,1702,2081,1025,8503,1802,178,444,285,8329,445,2367,1954,1550,2185,1024,429,257,168,1551,512]

theorem envBound4975 : H12AffineFastState.Bounded env4975 := by
  intro p hp
  have h : env4975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4974_4975 : H12AffineEnvironment.transform 11 1803 env4974 = env4975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1803 env4974 == env4975) = true)

theorem identity4975 : scanCanonicalize (H12AffineFastState.compose env4975 (packedSelected [0,4,7,9,13,17,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4975 : packedSelected [0,4,7,9,13,17,18,23] rootPS < 2^1333 := by decide +kernel

def env4976 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1803,8192,1802,8503,8234,1550,2081,1025,8503,1802,26,276,285,8225,277,2367,1802,1550,2081,1024,261,257,0,1551,512]

theorem envBound4976 : H12AffineFastState.Bounded env4976 := by
  intro p hp
  have h : env4976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4975_4976 : H12AffineEnvironment.transform 6 40 env4975 = env4976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4975 == env4976) = true)

theorem identity4976 : scanCanonicalize (H12AffineFastState.compose env4976 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound4976 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4977 : List Nat := [2,4,8,16,32,16,40,62,512,1024,2048,1589,8192,1588,8201,8234,1550,2081,1025,8201,1588,26,42,35,8225,43,2049,1588,1550,2081,1024,59,63,0,1551,512]

theorem envBound4977 : H12AffineFastState.Bounded env4977 := by
  intro p hp
  have h : env4977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4976_4977 : H12AffineEnvironment.transform 7 62 env4976 = env4977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env4976 == env4977) = true)

theorem identity4977 : scanCanonicalize (H12AffineFastState.compose env4977 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound4977 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env4978 : List Nat := [2,4,8,16,32,16,40,62,512,1024,2048,1589,51,1588,58,25,1550,2081,1025,58,1588,26,42,35,18,43,2049,1588,1550,2081,1024,59,63,0,1551,512]

theorem envBound4978 : H12AffineFastState.Bounded env4978 := by
  intro p hp
  have h : env4978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4977_4978 : H12AffineEnvironment.transform 12 51 env4977 = env4978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env4977 == env4978) = true)

theorem identity4978 : scanCanonicalize (H12AffineFastState.compose env4978 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 571) := by decide +kernel

theorem selectedBound4978 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env4979 : List Nat := [2,4,8,16,32,16,40,62,512,1024,571,1589,51,1588,58,25,1550,538,1025,58,1588,26,42,35,18,43,570,1588,1550,538,1024,59,63,0,1551,512]

theorem envBound4979 : H12AffineFastState.Bounded env4979 := by
  intro p hp
  have h : env4979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4978_4979 : H12AffineEnvironment.transform 10 571 env4978 = env4979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 571 env4978 == env4979) = true)

theorem identity4979 : scanCanonicalize (H12AffineFastState.compose env4979 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4979 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env4980 : List Nat := [2,4,8,16,26,16,18,4,512,1024,513,1551,9,1550,0,25,1550,538,1025,0,1550,26,16,25,18,17,512,1550,1550,538,1024,1,5,0,1551,512]

theorem envBound4980 : H12AffineFastState.Bounded env4980 := by
  intro p hp
  have h : env4980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4979_4980 : H12AffineEnvironment.transform 4 26 env4979 = env4980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4979 == env4980) = true)

theorem identity4980 : scanCanonicalize (H12AffineFastState.compose env4980 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4980 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4981 : List Nat := [2,4,2,16,16,16,18,4,512,1024,513,1541,3,1540,0,19,1540,528,1025,0,1540,16,16,19,18,17,512,1540,1540,528,1024,1,5,0,1541,512]

theorem envBound4981 : H12AffineFastState.Bounded env4981 := by
  intro p hp
  have h : env4981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4980_4981 : H12AffineEnvironment.transform 2 2 env4980 = env4981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4980 == env4981) = true)

theorem identity4981 : scanCanonicalize (H12AffineFastState.compose env4981 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4981 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4982 : List Nat := [2,4,2,0,0,0,2,4,512,1024,513,1541,3,1540,0,3,1540,512,1025,0,1540,0,0,3,2,1,512,1540,1540,512,1024,1,5,0,1541,512]

theorem envBound4982 : H12AffineFastState.Bounded env4982 := by
  intro p hp
  have h : env4982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4981_4982 : H12AffineEnvironment.transform 3 0 env4981 = env4982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4981 == env4982) = true)

theorem identity4982 : scanCanonicalize (H12AffineFastState.compose env4982 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4982 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4983 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1029,3,1028,0,3,1028,0,1025,0,1028,0,0,3,2,1,0,1028,1028,0,1024,1,5,0,1029,0]

theorem envBound4983 : H12AffineFastState.Bounded env4983 := by
  intro p hp
  have h : env4983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4982_4983 : H12AffineEnvironment.transform 8 0 env4982 = env4983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4982 == env4983) = true)

def leafEnv4983 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1029,3,1028,0,3,1028,0,1025,0,1028,0,0,3,1025,2,1,1,0,1028,1028,0,1024,1,5,0,5,3,1029,0,1,1028,0]

def active4983 : List Nat := [0,1,9]

def tree4983 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4983 : H12WitnessSearch.Good tree4983 := H12GlobalWitnessIndex.good

theorem leafIdentity4983 : H12AffineFastState.composeSystem env4983 rootObs = leafEnv4983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4983 rootObs == leafEnv4983) = true)

theorem terminalChecked4983 : H12PackedTerminal.terminalCheckFast leafEnv4983 active4983 tree4983 = true := by decide +kernel

def env4984 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,61740,8388608,41002,8329,8388608,323713,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound4984 : H12AffineFastState.Bounded env4984 := by
  intro p hp
  have h : env4984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4968_4984 : H12AffineEnvironment.transform 5 17 env4968 = env4984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4968 == env4984) = true)

def env4985 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,262144,1025,8352,4097,20876,8388608,138,8329,8388608,282657,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound4985 : H12AffineFastState.Bounded env4985 := by
  intro p hp
  have h : env4985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4984_4985 : H12AffineEnvironment.transform 14 8352 env4984 = env4985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env4984 == env4985) = true)

theorem identity4985 : scanCanonicalize (H12AffineFastState.compose env4985 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 96267) := by decide +kernel

theorem selectedBound4985 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env4986 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,96267,1025,8352,4097,20876,8388608,138,8329,8388608,75818,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound4986 : H12AffineFastState.Bounded env4986 := by
  intro p hp
  have h : env4986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4985_4986 : H12AffineEnvironment.transform 17 96267 env4985 = env4986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96267 env4985 == env4986) = true)

theorem identity4986 : scanCanonicalize (H12AffineFastState.compose env4986 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 28714) := by decide +kernel

theorem selectedBound4986 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env4987 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,28714,4524,2081,1025,8352,4097,20876,8388608,138,8329,8388608,22528,16384,16813,22561,21504,8388625,257,20480,16813,8389565]

theorem envBound4987 : H12AffineFastState.Bounded env4987 := by
  intro p hp
  have h : env4987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4986_4987 : H12AffineEnvironment.transform 15 28714 env4986 = env4987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28714 env4986 == env4987) = true)

theorem identity4987 : scanCanonicalize (H12AffineFastState.compose env4987 (packedSelected [1,2,3,4,5,6,8,9,12,13,18] rootPS)) = affineNative (2^(13+1) ^^^ 7846) := by decide +kernel

theorem selectedBound4987 : packedSelected [1,2,3,4,5,6,8,9,12,13,18] rootPS < 2^1333 := by decide +kernel

def env4988 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,7846,8352,11916,4524,2081,1025,8352,4097,3882,8388608,138,8329,8388608,1702,7846,7947,1671,2726,8388625,257,3750,7947,8389565]

theorem envBound4988 : H12AffineFastState.Bounded env4988 := by
  intro p hp
  have h : env4988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4987_4988 : H12AffineEnvironment.transform 13 7846 env4987 = env4988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7846 env4987 == env4988) = true)

theorem identity4988 : scanCanonicalize (H12AffineFastState.compose env4988 (packedSelected [4,9,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4988 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env4989 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,7846,8352,11916,4265,2081,1025,8352,4097,3631,8388608,138,8329,8388608,1702,7846,7694,1671,2726,8388625,4,3750,7694,8389304]

theorem envBound4989 : H12AffineFastState.Bounded env4989 := by
  intro p hp
  have h : env4989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4988_4989 : H12AffineEnvironment.transform 7 5 env4988 = env4989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4988 == env4989) = true)

theorem identity4989 : scanCanonicalize (H12AffineFastState.compose env4989 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4989 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env4990 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,7694,8200,11812,4097,2081,1025,8200,4097,3631,8388608,34,8225,8388608,1550,7694,7694,1583,2574,8388625,4,3598,7694,8389136]

theorem envBound4990 : H12AffineFastState.Bounded env4990 := by
  intro p hp
  have h : env4990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4989_4990 : H12AffineEnvironment.transform 6 40 env4989 = env4990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4989 == env4990) = true)

theorem identity4990 : scanCanonicalize (H12AffineFastState.compose env4990 (packedSelected [2,6] rootPS)) = affineNative (2^(22+1) ^^^ 3588) := by decide +kernel

theorem selectedBound4990 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4991 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,7694,8200,11812,4097,2081,1025,8200,4097,3631,3588,34,8225,3588,1550,7694,7694,1583,2574,3605,4,3598,7694,3092]

theorem envBound4991 : H12AffineFastState.Bounded env4991 := by
  intro p hp
  have h : env4991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4990_4991 : H12AffineEnvironment.transform 22 3588 env4990 = env4991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 3588 env4990 == env4991) = true)

theorem identity4991 : scanCanonicalize (H12AffineFastState.compose env4991 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4991 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4992 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1589,8192,2107,8200,11812,1588,2081,1025,8200,1588,3631,3588,34,8225,3588,1550,2107,2107,1583,2574,3605,4,3598,2107,3092]

theorem envBound4992 : H12AffineFastState.Bounded env4992 := by
  intro p hp
  have h : env4992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4991_4992 : H12AffineEnvironment.transform 11 1589 env4991 = env4992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env4991 == env4992) = true)

theorem identity4992 : scanCanonicalize (H12AffineFastState.compose env4992 (packedSelected [1,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound4992 : packedSelected [1,8,11] rootPS < 2^1333 := by decide +kernel

def env4993 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1038,1589,8192,1077,8200,8746,1588,1071,1025,8200,1588,545,522,34,8225,522,1550,1077,1077,1583,1536,539,4,512,1077,26]

theorem envBound4993 : H12AffineFastState.Bounded env4993 := by
  intro p hp
  have h : env4993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4992_4993 : H12AffineEnvironment.transform 10 1038 env4992 = env4993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env4992 == env4993) = true)

theorem identity4993 : scanCanonicalize (H12AffineFastState.compose env4993 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1543) := by decide +kernel

theorem selectedBound4993 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4994 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1038,1589,1543,1077,1551,1069,1588,1071,1025,1551,1588,545,522,34,1574,522,1550,1077,1077,1583,1536,539,4,512,1077,26]

theorem envBound4994 : H12AffineFastState.Bounded env4994 := by
  intro p hp
  have h : env4994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4993_4994 : H12AffineEnvironment.transform 12 1543 env4993 = env4994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1543 env4993 == env4994) = true)

theorem identity4994 : scanCanonicalize (H12AffineFastState.compose env4994 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound4994 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4995 : List Nat := [2,4,8,16,32,17,40,5,512,564,570,1,51,513,59,537,0,539,565,59,0,545,522,34,18,522,58,513,513,27,52,539,4,512,513,26]

theorem envBound4995 : H12AffineFastState.Bounded env4995 := by
  intro p hp
  have h : env4995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4994_4995 : H12AffineEnvironment.transform 9 564 env4994 = env4995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env4994 == env4995) = true)

theorem identity4995 : scanCanonicalize (H12AffineFastState.compose env4995 (packedSelected [1,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4995 : packedSelected [1,5,7] rootPS < 2^1333 := by decide +kernel

def env4996 : List Nat := [2,4,8,11,32,10,40,5,512,559,545,1,40,513,32,514,0,512,558,32,0,545,522,34,9,522,33,513,513,0,47,512,4,512,513,1]

theorem envBound4996 : H12AffineFastState.Bounded env4996 := by
  intro p hp
  have h : env4996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4995_4996 : H12AffineEnvironment.transform 3 11 env4995 = env4996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4995 == env4996) = true)

def env4997 : List Nat := [2,4,8,11,32,10,40,5,0,47,33,1,40,1,32,2,0,0,46,32,0,33,10,34,9,10,33,1,1,0,47,0,4,0,1,1]

theorem envBound4997 : H12AffineFastState.Bounded env4997 := by
  intro p hp
  have h : env4997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4996_4997 : H12AffineEnvironment.transform 8 0 env4996 = env4997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4996 == env4997) = true)

theorem identity4997 : scanCanonicalize (H12AffineFastState.compose env4997 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound4997 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4998 : List Nat := [2,4,7,4,32,5,39,5,0,32,33,1,39,1,32,2,0,0,33,32,0,33,5,34,6,5,33,1,1,0,32,0,4,0,1,1]

theorem envBound4998 : H12AffineFastState.Bounded env4998 := by
  intro p hp
  have h : env4998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4997_4998 : H12AffineEnvironment.transform 2 7 env4997 = env4998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env4997 == env4998) = true)

theorem identity4998 : scanCanonicalize (H12AffineFastState.compose env4998 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4998 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4999 : List Nat := [2,0,3,0,32,1,35,1,0,32,33,1,35,1,32,2,0,0,33,32,0,33,1,34,2,1,33,1,1,0,32,0,0,0,1,1]

theorem envBound4999 : H12AffineFastState.Bounded env4999 := by
  intro p hp
  have h : env4999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4998_4999 : H12AffineEnvironment.transform 1 0 env4998 = env4999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4998 == env4999) = true)

def leafEnv4999 : List Nat := [2,0,3,0,32,1,35,1,0,32,33,1,35,1,32,2,0,0,33,32,0,33,1,34,33,2,1,1,33,1,1,0,32,0,0,0,1,35,1,1,1,0,0]

def active4999 : List Nat := [0,4]

def tree4999 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4999 : H12WitnessSearch.Good tree4999 := H12GlobalWitnessIndex.good

theorem leafIdentity4999 : H12AffineFastState.composeSystem env4999 rootObs = leafEnv4999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4999 rootObs == leafEnv4999) = true)

theorem terminalChecked4999 : H12PackedTerminal.terminalCheckFast leafEnv4999 active4999 tree4999 = true := by decide +kernel

def env5000 : List Nat := [2,4,8,11,32,10,40,5,1,46,32,1,40,0,32,3,0,1,47,32,0,32,11,34,9,11,33,0,0,0,47,1,4,1,0,1]

theorem envBound5000 : H12AffineFastState.Bounded env5000 := by
  intro p hp
  have h : env5000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4996_5000 : H12AffineEnvironment.transform 8 1 env4996 = env5000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4996 == env5000) = true)

def env5001 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,262144,1025,8353,4097,20877,8388608,139,8329,8388608,282656,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound5001 : H12AffineFastState.Bounded env5001 := by
  intro p hp
  have h : env5001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4984_5001 : H12AffineEnvironment.transform 14 8353 env4984 = env5001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env4984 == env5001) = true)

theorem identity5001 : scanCanonicalize (H12AffineFastState.compose env5001 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 96526) := by decide +kernel

theorem selectedBound5001 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env5002 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,96526,1025,8353,4097,20877,8388608,139,8329,8388608,76078,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound5002 : H12AffineFastState.Bounded env5002 := by
  intro p hp
  have h : env5002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5001_5002 : H12AffineEnvironment.transform 17 96526 env5001 = env5002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96526 env5001 == env5002) = true)

theorem identity5002 : scanCanonicalize (H12AffineFastState.compose env5002 (packedSelected [0,1,3,9,13,17,22,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 20925) := by decide +kernel

theorem selectedBound5002 : packedSelected [0,1,3,9,13,17,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env5003 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,96526,1025,8353,4097,20877,20925,139,8329,20925,76078,16384,16813,22561,74794,20908,257,20480,16813,20992]

theorem envBound5003 : H12AffineFastState.Bounded env5003 := by
  intro p hp
  have h : env5003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5002_5003 : H12AffineEnvironment.transform 22 20925 env5002 = env5003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20925 env5002 == env5003) = true)

theorem identity5003 : scanCanonicalize (H12AffineFastState.compose env5003 (packedSelected [0,4,7,11,13,17,18,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 29063) := by decide +kernel

theorem selectedBound5003 : packedSelected [0,4,7,11,13,17,18,22,23,32] rootPS < 2^1333 := by decide +kernel

def env5004 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,29063,4524,2185,1025,8353,4097,20877,20925,139,8329,20925,22697,16384,16813,22561,21933,20908,257,20480,16813,20992]

theorem envBound5004 : H12AffineFastState.Bounded env5004 := by
  intro p hp
  have h : env5004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5003_5004 : H12AffineEnvironment.transform 15 29063 env5003 = env5004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29063 env5003 == env5004) = true)

theorem identity5004 : scanCanonicalize (H12AffineFastState.compose env5004 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 10123) := by decide +kernel

theorem selectedBound5004 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env5005 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,10123,8353,5644,4524,2185,1025,8353,4097,13830,13878,139,8329,13878,16162,10123,9766,16298,12838,13863,257,14219,9766,13707]

theorem envBound5005 : H12AffineFastState.Bounded env5005 := by
  intro p hp
  have h : env5005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5004_5005 : H12AffineEnvironment.transform 13 10123 env5004 = env5005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10123 env5004 == env5005) = true)

theorem identity5005 : scanCanonicalize (H12AffineFastState.compose env5005 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound5005 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env5006 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,9782,8353,5644,4113,2185,1025,8353,4097,13830,13878,139,8329,13878,16031,9782,9766,15895,12838,13863,188,13878,9766,13366]

theorem envBound5006 : H12AffineFastState.Bounded env5006 := by
  intro p hp
  have h : env5006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5005_5006 : H12AffineEnvironment.transform 7 189 env5005 = env5006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5005 == env5006) = true)

theorem identity5006 : scanCanonicalize (H12AffineFastState.compose env5006 (packedSelected [0,1,2,5,6,7,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound5006 : packedSelected [0,1,2,5,6,7,10,13] rootPS < 2^1333 := by decide +kernel

def env5007 : List Nat := [2,4,8,16,32,17,128,189,512,1024,697,4096,8192,9782,8353,5644,4113,560,1025,8353,4097,13830,13878,139,8329,13878,13350,9782,9766,13486,12838,13863,188,13878,9766,13366]

theorem envBound5007 : H12AffineFastState.Bounded env5007 := by
  intro p hp
  have h : env5007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5006_5007 : H12AffineEnvironment.transform 10 697 env5006 = env5007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env5006 == env5007) = true)

theorem identity5007 : scanCanonicalize (H12AffineFastState.compose env5007 (packedSelected [0,1,2,3,6,7,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound5007 : packedSelected [0,1,2,3,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env5008 : List Nat := [2,4,8,16,32,17,128,189,512,1024,697,1582,8192,9782,8353,34,1599,560,1025,8353,1583,8232,8216,139,8329,8216,8712,9782,9766,8832,9224,8201,188,8216,9766,8728]

theorem envBound5008 : H12AffineFastState.Bounded env5008 := by
  intro p hp
  have h : env5008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5007_5008 : H12AffineEnvironment.transform 11 1582 env5007 = env5008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env5007 == env5008) = true)

theorem identity5008 : scanCanonicalize (H12AffineFastState.compose env5008 (packedSelected [0,1,2,5,6,7,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 177) := by decide +kernel

theorem selectedBound5008 : packedSelected [0,1,2,5,6,7,10,17] rootPS < 2^1333 := by decide +kernel

def env5009 : List Nat := [2,4,8,16,32,17,128,189,512,1024,697,1582,177,1671,16,34,1599,560,1025,16,1583,153,169,139,56,169,697,1671,1687,561,1209,184,188,169,1687,681]

theorem envBound5009 : H12AffineFastState.Bounded env5009 := by
  intro p hp
  have h : env5009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5008_5009 : H12AffineEnvironment.transform 12 177 env5008 = env5009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 177 env5008 == env5009) = true)

theorem identity5009 : scanCanonicalize (H12AffineFastState.compose env5009 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound5009 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env5010 : List Nat := [2,4,8,16,32,17,50,15,512,1024,523,1582,3,1589,16,34,1599,560,1025,16,1583,43,27,57,56,27,523,1589,1573,561,1035,10,14,27,1573,539]

theorem envBound5010 : H12AffineFastState.Bounded env5010 := by
  intro p hp
  have h : env5010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5009_5010 : H12AffineEnvironment.transform 6 50 env5009 = env5010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env5009 == env5010) = true)

theorem identity5010 : scanCanonicalize (H12AffineFastState.compose env5010 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5010 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5011 : List Nat := [2,4,8,0,32,1,34,15,512,1024,523,1582,3,1573,0,34,1583,544,1025,0,1583,43,11,41,40,11,523,1573,1573,545,1035,10,14,11,1573,523]

theorem envBound5011 : H12AffineFastState.Bounded env5011 := by
  intro p hp
  have h : env5011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5010_5011 : H12AffineEnvironment.transform 3 0 env5010 = env5011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5010 == env5011) = true)

theorem identity5011 : scanCanonicalize (H12AffineFastState.compose env5011 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5011 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5012 : List Nat := [2,4,8,0,11,1,9,15,512,1024,523,1541,3,1550,0,9,1540,523,1025,0,1540,0,11,2,3,11,523,1550,1550,522,1035,10,14,11,1550,523]

theorem envBound5012 : H12AffineFastState.Bounded env5012 := by
  intro p hp
  have h : env5012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5011_5012 : H12AffineEnvironment.transform 4 11 env5011 = env5012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5011 == env5012) = true)

theorem identity5012 : scanCanonicalize (H12AffineFastState.compose env5012 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5013 : List Nat := [2,4,3,0,0,1,2,4,512,1024,512,1541,3,1541,0,2,1540,512,1025,0,1540,0,0,2,3,0,512,1541,1541,513,1024,1,5,0,1541,512]

theorem envBound5013 : H12AffineFastState.Bounded env5013 := by
  intro p hp
  have h : env5013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5012_5013 : H12AffineEnvironment.transform 2 3 env5012 = env5013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5012 == env5013) = true)

theorem identity5013 : scanCanonicalize (H12AffineFastState.compose env5013 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5013 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5014 : List Nat := [2,4,3,0,0,1,2,4,0,1024,0,1029,3,1029,0,2,1028,0,1025,0,1028,0,0,2,3,0,0,1029,1029,1,1024,1,5,0,1029,0]

theorem envBound5014 : H12AffineFastState.Bounded env5014 := by
  intro p hp
  have h : env5014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5013_5014 : H12AffineEnvironment.transform 8 0 env5013 = env5014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5013 == env5014) = true)

def leafEnv5014 : List Nat := [2,4,3,0,0,1,2,4,0,1024,0,1029,3,1029,0,2,1028,0,1025,0,1028,0,0,2,1025,3,1,0,0,1029,1029,1,1024,1,5,0,5,3,1029,0,1,1029,0]

def active5014 : List Nat := [0,1,9]

def tree5014 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5014 : H12WitnessSearch.Good tree5014 := H12GlobalWitnessIndex.good

theorem leafIdentity5014 : H12AffineFastState.composeSystem env5014 rootObs = leafEnv5014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5014 rootObs == leafEnv5014) = true)

theorem terminalChecked5014 : H12PackedTerminal.terminalCheckFast leafEnv5014 active5014 tree5014 = true := by decide +kernel

def env5015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41002,8329,8914001,2942161,16385,16893,2641009,598058,14737725,525568,2638928,6332545,8914925]

theorem envBound5015 : H12AffineFastState.Bounded env5015 := by
  intro p hp
  have h : env5015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4829_5015 : H12AffineEnvironment.transform 25 8914001 env4829 = env5015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env4829 == env5015) = true)

def env5016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849105,16385,16893,547953,598058,12644669,525568,545872,4239489,8914925]

theorem envBound5016 : H12AffineFastState.Bounded env5016 := by
  intro p hp
  have h : env5016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5015_5016 : H12AffineEnvironment.transform 20 4096 env5015 = env5016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5015 == env5016) = true)

def env5017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323793,16385,16893,22641,74794,12644669,256,20560,4239489,8389613]

theorem envBound5017 : H12AffineFastState.Bounded env5017 := by
  intro p hp
  have h : env5017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5016_5017 : H12AffineEnvironment.transform 18 1024 env5016 = env5017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5016 == env5017) = true)

theorem identity5017 : scanCanonicalize (H12AffineFastState.compose env5017 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 20804) := by decide +kernel

theorem selectedBound5017 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,20804,41002,8329,20757,323793,16385,16893,22641,74794,4235385,256,20560,4239489,21161]

theorem envBound5018 : H12AffineFastState.Bounded env5018 := by
  intro p hp
  have h : env5018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5017_5018 : H12AffineEnvironment.transform 22 20804 env5017 = env5018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20804 env5017 == env5018) = true)

def env5019 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,20756,41002,8329,20757,323713,16385,16813,22561,74794,4235305,256,20480,4239489,21161]

theorem envBound5019 : H12AffineFastState.Bounded env5019 := by
  intro p hp
  have h : env5019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5018_5019 : H12AffineEnvironment.transform 5 16 env5018 = env5019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5018 == env5019) = true)

theorem identity5019 : scanCanonicalize (H12AffineFastState.compose env5019 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound5019 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5020 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1024,32768,4096,4194304,445,41002,8329,444,303144,4264,4356,2184,74794,4235305,256,169,4239489,512]

theorem envBound5020 : H12AffineFastState.Bounded env5020 := by
  intro p hp
  have h : env5020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5019_5020 : H12AffineEnvironment.transform 13 4265 env5019 = env5020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env5019 == env5020) = true)

theorem identity5020 : scanCanonicalize (H12AffineFastState.compose env5020 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound5020 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5021 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1024,32768,4096,41349,445,41002,8329,444,303144,4264,4356,2184,74794,428,256,169,4356,512]

theorem envBound5021 : H12AffineFastState.Bounded env5021 := by
  intro p hp
  have h : env5021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5020_5021 : H12AffineEnvironment.transform 21 41349 env5020 = env5021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env5020 == env5021) = true)

theorem identity5021 : scanCanonicalize (H12AffineFastState.compose env5021 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound5021 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5022 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,65536,4525,262144,1024,13884,4096,6073,445,5654,8329,444,267796,4264,4356,2184,74794,428,256,169,4356,512]

theorem envBound5022 : H12AffineFastState.Bounded env5022 := by
  intro p hp
  have h : env5022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5021_5022 : H12AffineEnvironment.transform 14 13884 env5021 = env5022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env5021 == env5022) = true)

theorem identity5022 : scanCanonicalize (H12AffineFastState.compose env5022 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound5022 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5023 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,8235,4525,262144,1024,13884,4096,6073,445,5654,8329,444,267796,4264,4356,2184,1025,428,256,169,4356,512]

theorem envBound5023 : H12AffineFastState.Bounded env5023 := by
  intro p hp
  have h : env5023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5022_5023 : H12AffineEnvironment.transform 15 8235 env5022 = env5023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env5022 == env5023) = true)

def env5024 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,20757,41002,8329,20757,323712,16385,16812,22560,74794,4235304,256,20481,4239489,21161]

theorem envBound5024 : H12AffineFastState.Bounded env5024 := by
  intro p hp
  have h : env5024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5018_5024 : H12AffineEnvironment.transform 5 17 env5018 = env5024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5018 == env5024) = true)

def env5025 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,20741,41002,8329,20741,323712,16385,16812,22560,74794,4235304,256,20481,4239489,21161]

theorem envBound5025 : H12AffineFastState.Bounded env5025 := by
  intro p hp
  have h : env5025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5024_5025 : H12AffineEnvironment.transform 3 0 env5024 = env5025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5024 == env5025) = true)

theorem identity5025 : scanCanonicalize (H12AffineFastState.compose env5025 (packedSelected [2,7,11,13,18,20,21,27] rootPS)) = affineNative (2^(21+1) ^^^ 362895) := by decide +kernel

theorem selectedBound5025 : packedSelected [2,7,11,13,18,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5026 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,362895,20741,41002,8329,20741,323712,16385,16812,22560,74794,338343,256,20481,342286,21161]

theorem envBound5026 : H12AffineFastState.Bounded env5026 := by
  intro p hp
  have h : env5026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5025_5026 : H12AffineEnvironment.transform 21 362895 env5025 = env5026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362895 env5025 == env5026) = true)

def env5027 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1024,32768,4096,362791,20741,41002,8225,20741,323624,16385,16644,22560,74794,338191,256,20481,342286,20993]

theorem envBound5027 : H12AffineFastState.Bounded env5027 := by
  intro p hp
  have h : env5027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5026_5027 : H12AffineEnvironment.transform 6 40 env5026 = env5027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5026 == env5027) = true)

theorem identity5027 : scanCanonicalize (H12AffineFastState.compose env5027 (packedSelected [3,4,5,9,10,17,18,20,21,23] rootPS)) = affineNative (2^(17+1) ^^^ 100614) := by decide +kernel

theorem selectedBound5027 : packedSelected [3,4,5,9,10,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env5028 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,100614,1024,32768,4096,33,20741,41002,8225,20741,96558,16385,16644,22560,74794,40969,256,20481,45064,20993]

theorem envBound5028 : H12AffineFastState.Bounded env5028 := by
  intro p hp
  have h : env5028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5027_5028 : H12AffineEnvironment.transform 17 100614 env5027 = env5028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100614 env5027 == env5028) = true)

theorem identity5028 : scanCanonicalize (H12AffineFastState.compose env5028 (packedSelected [0,2,3,4,5,7,10,11,17,18,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound5028 : packedSelected [0,2,3,4,5,7,10,11,17,18,21,22] rootPS < 2^1333 := by decide +kernel

def env5029 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,32803,4356,2341,1024,32768,4096,33,20741,41002,8225,20741,63757,16385,16644,22560,41993,40969,256,20481,45064,20993]

theorem envBound5029 : H12AffineFastState.Bounded env5029 := by
  intro p hp
  have h : env5029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5028_5029 : H12AffineEnvironment.transform 15 32803 env5028 = env5029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env5028 == env5029) = true)

theorem identity5029 : scanCanonicalize (H12AffineFastState.compose env5029 (packedSelected [3,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 7172) := by decide +kernel

theorem selectedBound5029 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env5030 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,7172,7207,4356,2341,1024,7172,4096,33,20741,15406,8225,20741,25865,16385,16644,22560,14349,15373,256,20481,11276,20993]

theorem envBound5030 : H12AffineFastState.Bounded env5030 := by
  intro p hp
  have h : env5030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5029_5030 : H12AffineEnvironment.transform 14 7172 env5029 = env5030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7172 env5029 == env5030) = true)

theorem identity5030 : scanCanonicalize (H12AffineFastState.compose env5030 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 8706) := by decide +kernel

theorem selectedBound5030 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5031 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,8706,7172,7207,4356,2341,1024,7172,4096,33,13063,15406,8225,13063,1803,8707,8966,14882,14349,15373,256,12803,11276,12291]

theorem envBound5031 : H12AffineFastState.Bounded env5031 := by
  intro p hp
  have h : env5031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5030_5031 : H12AffineEnvironment.transform 13 8706 env5030 = env5031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8706 env5030 == env5031) = true)

theorem identity5031 : scanCanonicalize (H12AffineFastState.compose env5031 (packedSelected [0,4,5,6,7,8,9,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5031 : packedSelected [0,4,5,6,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5032 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,4096,8192,8706,7172,7207,4097,2080,1024,7172,4096,33,12802,15406,8225,12802,1550,8707,8707,14882,14349,15373,5,12803,11276,12291]

theorem envBound5032 : H12AffineFastState.Bounded env5032 := by
  intro p hp
  have h : env5032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5031_5032 : H12AffineEnvironment.transform 7 5 env5031 = env5032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5031 == env5032) = true)

theorem identity5032 : scanCanonicalize (H12AffineFastState.compose env5032 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound5032 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5033 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1572,8192,8706,2592,2563,1573,2080,1024,2592,1572,33,9254,10762,8225,9254,1550,8707,8707,11270,11817,10793,5,9255,11276,9767]

theorem envBound5033 : H12AffineFastState.Bounded env5033 := by
  intro p hp
  have h : env5033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5032_5033 : H12AffineEnvironment.transform 11 1572 env5032 = env5033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env5032 == env5033) = true)

theorem identity5033 : scanCanonicalize (H12AffineFastState.compose env5033 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound5033 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5034 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1572,1062,1572,2592,2563,1573,2080,1024,2592,1572,33,0,3628,1031,0,1550,1573,1573,2080,2575,3599,5,1,2090,513]

theorem envBound5034 : H12AffineFastState.Bounded env5034 := by
  intro p hp
  have h : env5034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5033_5034 : H12AffineEnvironment.transform 12 1062 env5033 = env5034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env5033 == env5034) = true)

theorem identity5034 : scanCanonicalize (H12AffineFastState.compose env5034 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound5034 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env5035 : List Nat := [2,4,8,0,32,1,40,5,4,1024,2048,1056,1062,1056,2084,2055,1057,2080,1024,2084,1056,33,0,3112,1031,0,1034,1057,1057,2080,2059,3083,5,1,2090,5]

theorem envBound5035 : H12AffineFastState.Bounded env5035 := by
  intro p hp
  have h : env5035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5034_5035 : H12AffineEnvironment.transform 8 4 env5034 = env5035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env5034 == env5035) = true)

theorem identity5035 : scanCanonicalize (H12AffineFastState.compose env5035 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1034) := by decide +kernel

theorem selectedBound5035 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env5036 : List Nat := [2,4,8,0,32,1,40,5,4,1024,1034,1056,1062,1056,1070,1037,1057,1066,1024,1070,1056,33,0,34,1031,0,1034,1057,1057,1066,1025,1,5,1,1056,5]

theorem envBound5036 : H12AffineFastState.Bounded env5036 := by
  intro p hp
  have h : env5036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5035_5036 : H12AffineEnvironment.transform 10 1034 env5035 = env5036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1034 env5035 == env5036) = true)

theorem identity5036 : scanCanonicalize (H12AffineFastState.compose env5036 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5036 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5037 : List Nat := [2,4,8,0,11,1,3,5,4,1024,1034,1035,1037,1035,1029,1037,1034,1025,1024,1029,1035,10,0,9,1031,0,1034,1034,1034,1025,1025,1,5,1,1035,5]

theorem envBound5037 : H12AffineFastState.Bounded env5037 := by
  intro p hp
  have h : env5037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5036_5037 : H12AffineEnvironment.transform 4 11 env5036 = env5037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5036 == env5037) = true)

theorem identity5037 : scanCanonicalize (H12AffineFastState.compose env5037 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5037 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5038 : List Nat := [2,0,8,0,11,1,3,1,0,1024,1034,1035,1033,1035,1025,1033,1034,1025,1024,1025,1035,10,0,9,1027,0,1034,1034,1034,1025,1025,1,1,1,1035,1]

theorem envBound5038 : H12AffineFastState.Bounded env5038 := by
  intro p hp
  have h : env5038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5037_5038 : H12AffineEnvironment.transform 1 0 env5037 = env5038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5037 == env5038) = true)

theorem identity5038 : scanCanonicalize (H12AffineFastState.compose env5038 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound5038 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5039 : List Nat := [2,0,8,0,11,1,3,1,0,10,0,1,3,1,11,3,0,11,10,11,1,10,0,9,9,0,0,0,0,11,11,1,1,1,1,1]

theorem envBound5039 : H12AffineFastState.Bounded env5039 := by
  intro p hp
  have h : env5039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5038_5039 : H12AffineEnvironment.transform 9 10 env5038 = env5039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env5038 == env5039) = true)

def leafEnv5039 : List Nat := [2,0,8,0,11,1,3,1,0,10,0,1,3,1,11,3,0,11,10,11,1,10,0,9,11,9,1,0,0,0,0,11,11,1,1,1,0,9,1,1,1,1,0]

def active5039 : List Nat := [0,2]

def tree5039 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5039 : H12WitnessSearch.Good tree5039 := H12GlobalWitnessIndex.good

theorem leafIdentity5039 : H12AffineFastState.composeSystem env5039 rootObs = leafEnv5039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5039 rootObs == leafEnv5039) = true)

theorem terminalChecked5039 : H12PackedTerminal.terminalCheckFast leafEnv5039 active5039 tree5039 = true := by decide +kernel

def env5040 : List Nat := [2,4,8,0,32,1,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,362790,20741,41002,8224,20741,323625,16385,16645,22560,74794,338190,256,20481,342286,20992]

theorem envBound5040 : H12AffineFastState.Bounded env5040 := by
  intro p hp
  have h : env5040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5026_5040 : H12AffineEnvironment.transform 6 41 env5026 = env5040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5026 == env5040) = true)

theorem identity5040 : scanCanonicalize (H12AffineFastState.compose env5040 (packedSelected [3,4,5,9,10,17,18,20,21,23] rootPS)) = affineNative (2^(17+1) ^^^ 43309) := by decide +kernel

theorem selectedBound5040 : packedSelected [3,4,5,9,10,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env5041 : List Nat := [2,4,8,0,32,1,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,43309,1024,32768,4096,73739,20741,41002,8224,20741,22788,16385,16645,22560,74794,98339,256,20481,102435,20992]

theorem envBound5041 : H12AffineFastState.Bounded env5041 := by
  intro p hp
  have h : env5041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5040_5041 : H12AffineEnvironment.transform 17 43309 env5040 = env5041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43309 env5040 == env5041) = true)

theorem identity5041 : scanCanonicalize (H12AffineFastState.compose env5041 (packedSelected [6,11,12,13,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 28932) := by decide +kernel

theorem selectedBound5041 : packedSelected [6,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env5042 : List Nat := [2,4,8,0,32,1,41,256,512,1024,2048,4096,8192,16384,32768,28932,4357,43309,1024,32768,4096,20751,20741,41002,8224,20741,22788,16385,16645,22560,21806,61735,256,20481,57639,20992]

theorem envBound5042 : H12AffineFastState.Bounded env5042 := by
  intro p hp
  have h : env5042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5041_5042 : H12AffineEnvironment.transform 15 28932 env5041 = env5042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28932 env5041 == env5042) = true)

theorem identity5042 : scanCanonicalize (H12AffineFastState.compose env5042 (packedSelected [2,3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5042 : packedSelected [2,3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env5043 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,32768,28672,4097,43049,1024,32768,4096,20491,20481,41002,8224,20481,22528,16385,16385,22560,21546,61475,4,20481,57379,20992]

theorem envBound5043 : H12AffineFastState.Bounded env5043 := by
  intro p hp
  have h : env5043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5042_5043 : H12AffineEnvironment.transform 7 4 env5042 = env5043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5042 == env5043) = true)

theorem identity5043 : scanCanonicalize (H12AffineFastState.compose env5043 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5043 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5044 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,1551,32768,13839,4097,43049,1024,32768,4096,5636,5646,41002,8224,5646,7695,1550,1550,7727,4645,46636,4,5646,42540,5135]

theorem envBound5044 : H12AffineFastState.Bounded env5044 := by
  intro p hp
  have h : env5044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5043_5044 : H12AffineEnvironment.transform 13 1551 env5043 = env5044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1551 env5043 == env5044) = true)

theorem identity5044 : scanCanonicalize (H12AffineFastState.compose env5044 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 8226) := by decide +kernel

theorem selectedBound5044 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5045 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,1551,8226,13839,4097,2059,1024,8226,4096,5636,5646,8,8224,5646,7695,1550,1550,7727,4645,5646,4,5646,1550,5135]

theorem envBound5045 : H12AffineFastState.Bounded env5045 := by
  intro p hp
  have h : env5045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5044_5045 : H12AffineEnvironment.transform 14 8226 env5044 = env5045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8226 env5044 == env5045) = true)

theorem identity5045 : scanCanonicalize (H12AffineFastState.compose env5045 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5045 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5046 : List Nat := [2,4,8,0,10,1,3,4,512,1024,2048,4096,8192,1551,8200,13839,4097,2059,1024,8200,4096,5636,5646,8,8202,5646,7695,1550,1550,7685,4623,5646,4,5646,1550,5135]

theorem envBound5046 : H12AffineFastState.Bounded env5046 := by
  intro p hp
  have h : env5046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5045_5046 : H12AffineEnvironment.transform 4 10 env5045 = env5046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5045 == env5046) = true)

theorem identity5046 : scanCanonicalize (H12AffineFastState.compose env5046 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound5046 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5047 : List Nat := [2,4,8,0,10,1,3,4,512,1024,2048,4096,2562,1551,2570,7181,4097,2059,1024,2570,4096,5636,5646,8,2568,5646,7695,1550,1550,7685,4623,5646,4,5646,1550,5135]

theorem envBound5047 : H12AffineFastState.Bounded env5047 := by
  intro p hp
  have h : env5047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5046_5047 : H12AffineEnvironment.transform 12 2562 env5046 = env5047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env5046 == env5047) = true)

theorem identity5047 : scanCanonicalize (H12AffineFastState.compose env5047 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound5047 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5048 : List Nat := [2,4,8,0,10,1,3,4,512,516,2048,4096,2562,11,2570,6665,4097,2059,516,2570,4096,4096,4106,8,2568,4106,6155,10,10,6145,4623,4106,4,4106,10,4619]

theorem envBound5048 : H12AffineFastState.Bounded env5048 := by
  intro p hp
  have h : env5048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5047_5048 : H12AffineEnvironment.transform 9 516 env5047 = env5048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env5047 == env5048) = true)

theorem identity5048 : scanCanonicalize (H12AffineFastState.compose env5048 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound5048 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5049 : List Nat := [2,4,8,0,10,1,3,4,512,516,522,4096,8,11,0,4099,4097,513,516,0,4096,4096,4106,8,2,4106,4609,10,10,4619,4623,4106,4,4106,10,4619]

theorem envBound5049 : H12AffineFastState.Bounded env5049 := by
  intro p hp
  have h : env5049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5048_5049 : H12AffineEnvironment.transform 10 522 env5048 = env5049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env5048 == env5049) = true)

theorem identity5049 : scanCanonicalize (H12AffineFastState.compose env5049 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound5049 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5050 : List Nat := [2,4,8,0,10,1,3,4,512,516,522,0,8,11,0,3,1,513,516,0,0,0,10,8,2,10,513,10,10,523,527,10,4,10,10,523]

theorem envBound5050 : H12AffineFastState.Bounded env5050 := by
  intro p hp
  have h : env5050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5049_5050 : H12AffineEnvironment.transform 11 0 env5049 = env5050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env5049 == env5050) = true)

theorem identity5050 : scanCanonicalize (H12AffineFastState.compose env5050 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5050 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5051 : List Nat := [2,4,3,0,1,1,3,4,512,516,513,0,3,0,0,3,1,513,516,0,0,0,1,3,2,1,513,1,1,512,516,1,4,1,1,512]

theorem envBound5051 : H12AffineFastState.Bounded env5051 := by
  intro p hp
  have h : env5051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5050_5051 : H12AffineEnvironment.transform 2 3 env5050 = env5051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5050 == env5051) = true)

theorem identity5051 : scanCanonicalize (H12AffineFastState.compose env5051 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5051 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5052 : List Nat := [2,4,3,0,1,1,3,4,1,5,0,0,3,0,0,3,1,0,5,0,0,0,1,3,2,1,0,1,1,1,5,1,4,1,1,1]

theorem envBound5052 : H12AffineFastState.Bounded env5052 := by
  intro p hp
  have h : env5052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5051_5052 : H12AffineEnvironment.transform 8 1 env5051 = env5052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5051 == env5052) = true)

def env5053 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,20740,41002,8329,20740,323712,16385,16812,22560,74794,4235304,256,20481,4239489,21161]

theorem envBound5053 : H12AffineFastState.Bounded env5053 := by
  intro p hp
  have h : env5053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5024_5053 : H12AffineEnvironment.transform 3 1 env5024 = env5053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5024 == env5053) = true)

theorem identity5053 : scanCanonicalize (H12AffineFastState.compose env5053 (packedSelected [2,7,11,13,18,20,21,27] rootPS)) = affineNative (2^(17+1) ^^^ 2445) := by decide +kernel

theorem selectedBound5053 : packedSelected [2,7,11,13,18,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5054 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,2445,1024,32768,4096,4194304,20740,41002,8329,20740,63757,16385,16812,22560,74794,4235304,256,20481,4239489,21161]

theorem envBound5054 : H12AffineFastState.Bounded env5054 := by
  intro p hp
  have h : env5054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5053_5054 : H12AffineEnvironment.transform 17 2445 env5053 = env5054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2445 env5053 == env5054) = true)

def env5055 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,2341,1024,32768,4096,4194304,20740,41002,8225,20740,63757,16385,16644,22560,74794,4235304,256,20481,4239401,20993]

theorem envBound5055 : H12AffineFastState.Bounded env5055 := by
  intro p hp
  have h : env5055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5054_5055 : H12AffineEnvironment.transform 6 40 env5054 = env5055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5054 == env5055) = true)

theorem identity5055 : scanCanonicalize (H12AffineFastState.compose env5055 (packedSelected [0,3,4,5,7,10,13,17,18,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound5055 : packedSelected [0,3,4,5,7,10,13,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env5056 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,4096,8192,16384,32768,53282,4356,2341,1024,32768,4096,4194304,20740,41002,8225,20740,63757,16385,16644,22560,62472,4235304,256,20481,4239401,20993]

theorem envBound5056 : H12AffineFastState.Bounded env5056 := by
  intro p hp
  have h : env5056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5055_5056 : H12AffineEnvironment.transform 15 53282 env5055 = env5056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env5055 == env5056) = true)

theorem identity5056 : scanCanonicalize (H12AffineFastState.compose env5056 (packedSelected [2,3,4,5,9,10,11,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 20772) := by decide +kernel

theorem selectedBound5056 : packedSelected [2,3,4,5,9,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env5057 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,4096,8192,16384,32768,53282,4356,2341,1024,32768,4096,20772,20740,41002,8225,20740,63757,16385,16644,22560,62472,61708,256,20481,57613,20993]

theorem envBound5057 : H12AffineFastState.Bounded env5057 := by
  intro p hp
  have h : env5057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5056_5057 : H12AffineEnvironment.transform 21 20772 env5056 = env5057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20772 env5056 == env5057) = true)

theorem identity5057 : scanCanonicalize (H12AffineFastState.compose env5057 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 13100) := by decide +kernel

theorem selectedBound5057 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env5058 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,4096,8192,16384,13100,25358,4356,2341,1024,13100,4096,20772,20740,4870,8225,20740,18977,16385,16644,22560,18212,16928,256,20481,21025,20993]

theorem envBound5058 : H12AffineFastState.Bounded env5058 := by
  intro p hp
  have h : env5058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5057_5058 : H12AffineEnvironment.transform 14 13100 env5057 = env5058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13100 env5057 == env5058) = true)

theorem identity5058 : scanCanonicalize (H12AffineFastState.compose env5058 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound5058 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env5059 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,2048,8192,16384,11052,25358,2308,2341,1024,11052,2048,18724,18692,2822,8225,18692,18977,16385,16644,16416,18212,16928,256,18433,18977,18945]

theorem envBound5059 : H12AffineFastState.Bounded env5059 := by
  intro p hp
  have h : env5059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5058_5059 : H12AffineEnvironment.transform 11 2048 env5058 = env5059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env5058 == env5059) = true)

theorem identity5059 : scanCanonicalize (H12AffineFastState.compose env5059 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 1824) := by decide +kernel

theorem selectedBound5059 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env5060 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,2048,8192,1824,11052,9262,2308,2341,1024,11052,2048,3588,3620,2822,8225,3620,3329,1825,1572,1792,4,1280,256,3873,3329,3361]

theorem envBound5060 : H12AffineFastState.Bounded env5060 := by
  intro p hp
  have h : env5060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5059_5060 : H12AffineEnvironment.transform 13 1824 env5059 = env5060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1824 env5059 == env5060) = true)

theorem identity5060 : scanCanonicalize (H12AffineFastState.compose env5060 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound5060 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5061 : List Nat := [2,4,8,1,32,0,40,256,512,1024,1802,1802,8192,1824,9254,9262,1550,1583,1024,9254,1802,270,302,1036,8225,302,523,1825,1572,1792,4,1280,256,43,523,555]

theorem envBound5061 : H12AffineFastState.Bounded env5061 := by
  intro p hp
  have h : env5061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5060_5061 : H12AffineEnvironment.transform 10 1802 env5060 = env5061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env5060 == env5061) = true)

theorem identity5061 : scanCanonicalize (H12AffineFastState.compose env5061 (packedSelected [0,2,5,6,7,8,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound5061 : packedSelected [0,2,5,6,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env5062 : List Nat := [2,4,8,1,32,0,40,256,512,1024,1802,1802,1289,1824,303,295,1550,1583,1024,303,1802,270,302,1036,1320,302,523,1825,1572,1792,4,1280,256,43,523,555]

theorem envBound5062 : H12AffineFastState.Bounded env5062 := by
  intro p hp
  have h : env5062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5061_5062 : H12AffineEnvironment.transform 12 1289 env5061 = env5062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env5061 == env5062) = true)

def env5063 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,2340,1024,32768,4096,4194304,20740,41002,8224,20740,63757,16385,16645,22560,74794,4235304,256,20481,4239400,20992]

theorem envBound5063 : H12AffineFastState.Bounded env5063 := by
  intro p hp
  have h : env5063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5054_5063 : H12AffineEnvironment.transform 6 41 env5054 = env5063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5054 == env5063) = true)

theorem identity5063 : scanCanonicalize (H12AffineFastState.compose env5063 (packedSelected [0,3,4,5,7,10,13,17,18,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound5063 : packedSelected [0,3,4,5,7,10,13,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env5064 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,16384,28681,65536,4357,2340,1024,28681,4096,4194304,20740,20515,8224,20740,2308,16385,16645,22560,74794,4214817,256,20481,4210721,20992]

theorem envBound5064 : H12AffineFastState.Bounded env5064 := by
  intro p hp
  have h : env5064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5063_5064 : H12AffineEnvironment.transform 14 28681 env5063 = env5064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env5063 == env5064) = true)

theorem identity5064 : scanCanonicalize (H12AffineFastState.compose env5064 (packedSelected [0,7,9,13,17,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 73738) := by decide +kernel

theorem selectedBound5064 : packedSelected [0,7,9,13,17,20,22] rootPS < 2^1333 := by decide +kernel

def env5065 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,16384,28681,65536,4357,2340,1024,28681,4096,73738,20740,20515,8224,20740,2308,16385,16645,22560,74794,94251,256,20481,90155,20992]

theorem envBound5065 : H12AffineFastState.Bounded env5065 := by
  intro p hp
  have h : env5065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5064_5065 : H12AffineEnvironment.transform 21 73738 env5064 = env5065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73738 env5064 == env5065) = true)

theorem identity5065 : scanCanonicalize (H12AffineFastState.compose env5065 (packedSelected [2,3,5,6,10,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 41) := by decide +kernel

theorem selectedBound5065 : packedSelected [2,3,5,6,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5066 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,16384,28681,41,4357,2340,1024,28681,4096,8227,20740,20515,8224,20740,2308,16385,16645,22560,9219,28674,256,20481,24578,20992]

theorem envBound5066 : H12AffineFastState.Bounded env5066 := by
  intro p hp
  have h : env5066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5065_5066 : H12AffineEnvironment.transform 15 41 env5065 = env5066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41 env5065 == env5066) = true)

theorem identity5066 : scanCanonicalize (H12AffineFastState.compose env5066 (packedSelected [2,3,5,10,11,13,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound5066 : packedSelected [2,3,5,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5067 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,4357,8460,41,4357,2340,1024,8460,4096,8227,1,294,8224,1,2308,4356,4096,2341,9219,8455,256,260,12551,773]

theorem envBound5067 : H12AffineFastState.Bounded env5067 := by
  intro p hp
  have h : env5067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5066_5067 : H12AffineEnvironment.transform 13 4357 env5066 = env5067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env5066 == env5067) = true)

def env5068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323792,16385,16893,22640,74795,12644669,257,20561,4239489,8389612]

theorem envBound5068 : H12AffineFastState.Bounded env5068 := by
  intro p hp
  have h : env5068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5016_5068 : H12AffineEnvironment.transform 18 1025 env5016 = env5068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5016 == env5068) = true)

theorem identity5068 : scanCanonicalize (H12AffineFastState.compose env5068 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1092) := by decide +kernel

theorem selectedBound5068 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1092,8192,16384,32768,65536,1465,262144,1025,32768,1092,4194304,8388608,41002,8329,8388688,320660,16385,16893,19508,74795,12641657,257,17429,4236485,8389612]

theorem envBound5069 : H12AffineFastState.Bounded env5069 := by
  intro p hp
  have h : env5069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5068_5069 : H12AffineEnvironment.transform 11 1092 env5068 = env5069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1092 env5068 == env5069) = true)

def env5070 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,32768,65536,1465,262144,1025,32768,1044,4194304,8388608,41002,8329,8388608,320660,16385,16813,19508,74795,12641577,257,17429,4236437,8389564]

theorem envBound5070 : H12AffineFastState.Bounded env5070 := by
  intro p hp
  have h : env5070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5069_5070 : H12AffineEnvironment.transform 5 16 env5069 = env5070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5069 == env5070) = true)

def env5071 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,65536,1029,262144,1025,32768,1044,4194304,8388608,41002,8329,8388608,320660,16385,16401,19508,74795,12641429,189,17429,4236437,8389120]

theorem envBound5071 : H12AffineFastState.Bounded env5071 := by
  intro p hp
  have h : env5071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5070_5071 : H12AffineEnvironment.transform 7 188 env5070 = env5071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5070 == env5071) = true)

theorem identity5071 : scanCanonicalize (H12AffineFastState.compose env5071 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50318) := by decide +kernel

theorem selectedBound5071 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5072 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,50318,1029,262144,1025,32768,1044,4194304,8388608,41002,8329,8388608,320660,16385,16401,19508,57509,12641429,189,17429,4236437,8389120]

theorem envBound5072 : H12AffineFastState.Bounded env5072 := by
  intro p hp
  have h : env5072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5071_5072 : H12AffineEnvironment.transform 15 50318 env5071 = env5072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50318 env5071 == env5072) = true)

def env5073 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,50318,1029,262144,1025,32768,1044,4194304,4235392,41002,8329,4235392,320660,16385,16401,19508,57509,17429,189,17429,4236437,4235904]

theorem envBound5073 : H12AffineFastState.Bounded env5073 := by
  intro p hp
  have h : env5073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5072_5073 : H12AffineEnvironment.transform 22 4235392 env5072 = env5073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235392 env5072 == env5073) = true)

theorem identity5073 : scanCanonicalize (H12AffineFastState.compose env5073 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound5073 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5074 : List Nat := [2,4,8,16,32,16,56,4,512,1024,2048,1044,8192,16384,32768,50230,1029,262144,1025,32768,1044,4194304,4235320,41002,8241,4235320,320556,16385,16401,19508,57373,17429,5,17429,4236333,4235832]

theorem envBound5074 : H12AffineFastState.Bounded env5074 := by
  intro p hp
  have h : env5074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5073_5074 : H12AffineEnvironment.transform 6 56 env5073 = env5074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5073 == env5074) = true)

theorem identity5074 : scanCanonicalize (H12AffineFastState.compose env5074 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8216) := by decide +kernel

theorem selectedBound5074 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5075 : List Nat := [2,4,8,16,32,16,56,4,512,1024,2048,1044,8192,16384,8216,25646,1029,262144,1025,8216,1044,4194304,4194336,50,8241,4194336,279604,16385,16401,19508,16389,17429,5,17429,4195381,4194848]

theorem envBound5075 : H12AffineFastState.Bounded env5075 := by
  intro p hp
  have h : env5075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5074_5075 : H12AffineEnvironment.transform 14 8216 env5074 = env5075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8216 env5074 == env5075) = true)

theorem identity5075 : scanCanonicalize (H12AffineFastState.compose env5075 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,15] rootPS)) = affineNative (2^(17+1) ^^^ 26135) := by decide +kernel

theorem selectedBound5075 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env5076 : List Nat := [2,4,8,16,32,16,56,4,512,1024,2048,1044,8192,16384,8216,25646,1029,26135,1025,8216,1044,4194304,4194336,50,8241,4194336,8739,16385,16401,19508,16389,17429,5,17429,4195381,4194848]

theorem envBound5076 : H12AffineFastState.Bounded env5076 := by
  intro p hp
  have h : env5076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5075_5076 : H12AffineEnvironment.transform 17 26135 env5075 = env5076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26135 env5075 == env5076) = true)

theorem identity5076 : scanCanonicalize (H12AffineFastState.compose env5076 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5076 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5077 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,1029,8192,16384,8201,25646,1029,26118,1025,8201,1029,4194304,4194336,35,8224,4194336,8739,16385,16384,19493,16389,17412,5,17412,4195364,4194848]

theorem envBound5077 : H12AffineFastState.Bounded env5077 := by
  intro p hp
  have h : env5077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5076_5077 : H12AffineEnvironment.transform 3 1 env5076 = env5077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5076 == env5077) = true)

theorem identity5077 : scanCanonicalize (H12AffineFastState.compose env5077 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 10754) := by decide +kernel

theorem selectedBound5077 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5078 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,1029,8192,16384,8201,25646,1029,26118,1025,8201,1029,10754,10786,35,8224,10786,8739,16385,16384,19493,16389,17412,5,17412,11814,10274]

theorem envBound5078 : H12AffineFastState.Bounded env5078 := by
  intro p hp
  have h : env5078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5077_5078 : H12AffineEnvironment.transform 21 10754 env5077 = env5078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10754 env5077 == env5078) = true)

theorem identity5078 : scanCanonicalize (H12AffineFastState.compose env5078 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(13+1) ^^^ 11271) := by decide +kernel

theorem selectedBound5078 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env5079 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,1029,8192,11271,8201,2089,1029,2561,1025,8201,1029,10754,10786,35,8224,10786,8739,11270,11271,8226,11266,10243,5,10243,11814,10274]

theorem envBound5079 : H12AffineFastState.Bounded env5079 := by
  intro p hp
  have h : env5079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5078_5079 : H12AffineEnvironment.transform 13 11271 env5078 = env5079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11271 env5078 == env5079) = true)

theorem identity5079 : scanCanonicalize (H12AffineFastState.compose env5079 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound5079 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env5080 : List Nat := [2,4,8,1,32,1,41,4,512,36,2048,33,8192,10275,8201,2089,33,2561,37,8201,33,10754,10786,35,8224,10786,8739,10274,10275,8226,10278,10243,5,10243,10754,10274]

theorem envBound5080 : H12AffineFastState.Bounded env5080 := by
  intro p hp
  have h : env5080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5079_5080 : H12AffineEnvironment.transform 9 36 env5079 = env5080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env5079 == env5080) = true)

theorem identity5080 : scanCanonicalize (H12AffineFastState.compose env5080 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound5080 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env5081 : List Nat := [2,4,8,1,32,1,41,4,512,36,11,33,8192,8232,8201,34,33,522,37,8201,33,8713,8745,35,8224,8745,8739,8233,8232,8226,8237,8200,5,8200,8713,8233]

theorem envBound5081 : H12AffineFastState.Bounded env5081 := by
  intro p hp
  have h : env5081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5080_5081 : H12AffineEnvironment.transform 10 11 env5080 = env5081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env5080 == env5081) = true)

theorem identity5081 : scanCanonicalize (H12AffineFastState.compose env5081 (packedSelected [1,2,5,11] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5081 : packedSelected [1,2,5,11] rootPS < 2^1333 := by decide +kernel

def env5082 : List Nat := [2,4,8,1,32,1,41,4,32,36,11,33,8192,8232,8201,34,33,42,37,8201,33,8233,8201,35,8224,8201,8195,8233,8232,8226,8237,8200,5,8200,8233,8233]

theorem envBound5082 : H12AffineFastState.Bounded env5082 := by
  intro p hp
  have h : env5082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5081_5082 : H12AffineEnvironment.transform 8 32 env5081 = env5082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5081 == env5082) = true)

theorem identity5082 : scanCanonicalize (H12AffineFastState.compose env5082 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound5082 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5083 : List Nat := [2,4,8,1,32,1,41,4,32,36,11,33,2,42,11,34,33,42,37,11,33,43,11,35,34,11,1,43,42,32,47,10,5,10,43,43]

theorem envBound5083 : H12AffineFastState.Bounded env5083 := by
  intro p hp
  have h : env5083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5082_5083 : H12AffineEnvironment.transform 12 2 env5082 = env5083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env5082 == env5083) = true)

theorem identity5083 : scanCanonicalize (H12AffineFastState.compose env5083 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5084 : List Nat := [2,4,2,1,32,1,35,4,32,36,1,33,2,32,1,34,33,32,37,1,33,33,1,35,34,1,1,33,32,32,37,0,5,0,33,33]

theorem envBound5084 : H12AffineFastState.Bounded env5084 := by
  intro p hp
  have h : env5084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5083_5084 : H12AffineEnvironment.transform 2 2 env5083 = env5084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5083 == env5084) = true)

theorem identity5084 : scanCanonicalize (H12AffineFastState.compose env5084 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound5084 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5085 : List Nat := [2,4,2,1,5,1,6,4,5,1,1,4,2,5,1,7,4,5,0,1,4,4,1,6,7,1,1,4,5,5,0,0,5,0,4,4]

theorem envBound5085 : H12AffineFastState.Bounded env5085 := by
  intro p hp
  have h : env5085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5084_5085 : H12AffineEnvironment.transform 4 5 env5084 = env5085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env5084 == env5085) = true)

theorem identity5085 : scanCanonicalize (H12AffineFastState.compose env5085 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5085 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env5086 : List Nat := [2,0,2,1,1,1,2,0,1,1,1,0,2,1,1,3,0,1,0,1,0,0,1,2,3,1,1,0,1,1,0,0,1,0,0,0]

theorem envBound5086 : H12AffineFastState.Bounded env5086 := by
  intro p hp
  have h : env5086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5085_5086 : H12AffineEnvironment.transform 1 0 env5085 = env5086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5085 == env5086) = true)

def env5087 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,50318,1029,262144,1025,32768,1044,4194304,4235393,41002,8329,4235393,320660,16385,16401,19508,57509,17428,189,17429,4236437,4235905]

theorem envBound5087 : H12AffineFastState.Bounded env5087 := by
  intro p hp
  have h : env5087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5072_5087 : H12AffineEnvironment.transform 22 4235393 env5072 = env5087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235393 env5072 == env5087) = true)

theorem identity5087 : scanCanonicalize (H12AffineFastState.compose env5087 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5087 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5088 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50318,1029,262144,1025,32768,1029,4194304,4235393,41002,8329,4235393,320645,16385,16384,19493,57509,17413,172,17412,4236420,4235905]

theorem envBound5088 : H12AffineFastState.Bounded env5088 := by
  intro p hp
  have h : env5088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5087_5088 : H12AffineEnvironment.transform 3 1 env5087 = env5088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5087 == env5088) = true)

theorem identity5088 : scanCanonicalize (H12AffineFastState.compose env5088 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41001) := by decide +kernel

theorem selectedBound5088 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5089 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50318,1029,262144,1025,32768,1029,41001,168,41002,8329,168,320645,16385,16384,19493,57509,17413,172,17412,1197,680]

theorem envBound5089 : H12AffineFastState.Bounded env5089 := by
  intro p hp
  have h : env5089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5088_5089 : H12AffineEnvironment.transform 21 41001 env5088 = env5089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41001 env5088 == env5089) = true)

theorem identity5089 : scanCanonicalize (H12AffineFastState.compose env5089 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound5089 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env5090 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,1677,32768,33283,1029,262144,1025,32768,1029,41001,168,41002,8329,168,303624,1676,1677,2728,42536,648,172,649,1197,680]

theorem envBound5090 : H12AffineFastState.Bounded env5090 := by
  intro p hp
  have h : env5090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5089_5090 : H12AffineEnvironment.transform 13 1677 env5089 = env5090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env5089 == env5090) = true)

theorem identity5090 : scanCanonicalize (H12AffineFastState.compose env5090 (packedSelected [1,3,4,9,11,20,23] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5090 : packedSelected [1,3,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env5091 : List Nat := [2,4,8,1,32,1,128,173,1,1024,2048,1029,8192,1164,32768,32770,1029,262144,1025,32768,1029,41001,168,41002,8329,168,303113,1165,1164,2217,42025,137,172,136,1197,169]

theorem envBound5091 : H12AffineFastState.Bounded env5091 := by
  intro p hp
  have h : env5091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5090_5091 : H12AffineEnvironment.transform 8 1 env5090 = env5091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5090 == env5091) = true)

theorem identity5091 : scanCanonicalize (H12AffineFastState.compose env5091 (packedSelected [0,2,6,10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 41088) := by decide +kernel

theorem selectedBound5091 : packedSelected [0,2,6,10,12,13] rootPS < 2^1333 := by decide +kernel

def env5092 : List Nat := [2,4,8,1,32,1,128,173,1,1024,2048,1029,8192,1164,32768,32770,1029,41088,1025,32768,1029,41001,168,41002,8329,168,137,1165,1164,2217,42025,137,172,136,1197,169]

theorem envBound5092 : H12AffineFastState.Bounded env5092 := by
  intro p hp
  have h : env5092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5091_5092 : H12AffineEnvironment.transform 17 41088 env5091 = env5092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41088 env5091 == env5092) = true)

theorem identity5092 : scanCanonicalize (H12AffineFastState.compose env5092 (packedSelected [0,2,3,4,6,7,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 1158) := by decide +kernel

theorem selectedBound5092 : packedSelected [0,2,3,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env5093 : List Nat := [2,4,8,1,32,1,128,173,1,1024,2048,1029,8192,1164,1158,1156,1029,9222,1025,1158,1029,9391,168,9388,8329,168,137,1165,1164,2217,8367,137,172,136,1197,169]

theorem envBound5093 : H12AffineFastState.Bounded env5093 := by
  intro p hp
  have h : env5093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5092_5093 : H12AffineEnvironment.transform 14 1158 env5092 = env5093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1158 env5092 == env5093) = true)

theorem identity5093 : scanCanonicalize (H12AffineFastState.compose env5093 (packedSelected [0,1,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound5093 : packedSelected [0,1,6,8,15] rootPS < 2^1333 := by decide +kernel

def env5094 : List Nat := [2,4,8,1,32,1,128,173,1,1024,2048,1029,1063,1164,1158,1156,1029,33,1025,1158,1029,136,168,139,1198,168,137,1165,1164,2217,1160,137,172,136,1197,169]

theorem envBound5094 : H12AffineFastState.Bounded env5094 := by
  intro p hp
  have h : env5094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5093_5094 : H12AffineEnvironment.transform 12 1063 env5093 = env5094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env5093 == env5094) = true)

theorem identity5094 : scanCanonicalize (H12AffineFastState.compose env5094 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound5094 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5095 : List Nat := [2,4,8,1,32,1,128,173,1,1024,0,1029,1063,1164,1158,1156,1029,33,1025,1158,1029,136,168,139,1198,168,137,1165,1164,169,1160,137,172,136,1197,169]

theorem envBound5095 : H12AffineFastState.Bounded env5095 := by
  intro p hp
  have h : env5095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5094_5095 : H12AffineEnvironment.transform 10 0 env5094 = env5095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env5094 == env5095) = true)

def env5096 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,65536,1028,262144,1025,32768,1044,4194304,8388608,41002,8329,8388608,320660,16385,16400,19508,74795,12641428,188,17429,4236437,8389121]

theorem envBound5096 : H12AffineFastState.Bounded env5096 := by
  intro p hp
  have h : env5096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5070_5096 : H12AffineEnvironment.transform 7 189 env5070 = env5096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5070 == env5096) = true)

theorem identity5096 : scanCanonicalize (H12AffineFastState.compose env5096 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound5096 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5097 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,65536,1028,262144,1025,32768,1044,4194304,4194353,41002,8329,4194353,320660,16385,16400,19508,74795,58533,188,17429,4236437,4194864]

theorem envBound5097 : H12AffineFastState.Bounded env5097 := by
  intro p hp
  have h : env5097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5096_5097 : H12AffineEnvironment.transform 22 4194353 env5096 = env5097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env5096 == env5097) = true)

def env5098 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,32768,65536,1028,262144,1025,32768,1028,4194304,4194337,41002,8329,4194337,320644,16385,16384,19492,74795,58533,172,17413,4236421,4194848]

theorem envBound5098 : H12AffineFastState.Bounded env5098 := by
  intro p hp
  have h : env5098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5097_5098 : H12AffineEnvironment.transform 3 0 env5097 = env5098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5097 == env5098) = true)

theorem identity5098 : scanCanonicalize (H12AffineFastState.compose env5098 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5098 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5099 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,8192,16384,32768,65536,1028,262144,1025,32768,1028,4194304,4194337,41002,8225,4194337,320556,16385,16384,19492,74795,58381,4,17413,4236333,4194848]

theorem envBound5099 : H12AffineFastState.Bounded env5099 := by
  intro p hp
  have h : env5099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5098_5099 : H12AffineEnvironment.transform 6 40 env5098 = env5099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5098 == env5099) = true)

theorem identity5099 : scanCanonicalize (H12AffineFastState.compose env5099 (packedSelected [2,3,5,7,10,11,18,20,27] rootPS)) = affineNative (2^(17+1) ^^^ 117766) := by decide +kernel

theorem selectedBound5099 : packedSelected [2,3,5,7,10,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env5100 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,8192,16384,32768,65536,1028,117766,1025,32768,1028,4194304,4194337,41002,8225,4194337,75818,16385,16384,19492,74795,58381,4,17413,4236333,4194848]

theorem envBound5100 : H12AffineFastState.Bounded env5100 := by
  intro p hp
  have h : env5100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5099_5100 : H12AffineEnvironment.transform 17 117766 env5099 = env5100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 117766 env5099 == env5100) = true)

theorem identity5100 : scanCanonicalize (H12AffineFastState.compose env5100 (packedSelected [0,4,7,9,11,12,13,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound5100 : packedSelected [0,4,7,9,11,12,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5101 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2089,16384,32768,65536,1028,117766,1025,32768,1028,4194304,4194337,34819,2056,4194337,65539,16385,16384,19492,68610,52260,4,17413,4230148,4194848]

theorem envBound5101 : H12AffineFastState.Bounded env5101 := by
  intro p hp
  have h : env5101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5100_5101 : H12AffineEnvironment.transform 12 2089 env5100 = env5101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env5100 == env5101) = true)

theorem identity5101 : scanCanonicalize (H12AffineFastState.compose env5101 (packedSelected [0,1,3,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(21+1) ^^^ 98338) := by decide +kernel

theorem selectedBound5101 : packedSelected [0,1,3,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5102 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2089,16384,32768,65536,1028,117766,1025,32768,1028,98338,98307,34819,2056,98307,65539,16385,16384,19492,68610,52260,4,17413,68646,98818]

theorem envBound5102 : H12AffineFastState.Bounded env5102 := by
  intro p hp
  have h : env5102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5101_5102 : H12AffineEnvironment.transform 21 98338 env5101 = env5102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98338 env5101 == env5102) = true)

theorem identity5102 : scanCanonicalize (H12AffineFastState.compose env5102 (packedSelected [2,4,6,7,10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 1542) := by decide +kernel

theorem selectedBound5102 : packedSelected [2,4,6,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env5103 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2089,16384,32768,1542,1028,51712,1025,32768,1028,34340,34309,34819,2056,34309,1541,16385,16384,19492,2564,52260,4,17413,2592,33796]

theorem envBound5103 : H12AffineFastState.Bounded env5103 := by
  intro p hp
  have h : env5103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5102_5103 : H12AffineEnvironment.transform 15 1542 env5102 = env5103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1542 env5102 == env5103) = true)

theorem identity5103 : scanCanonicalize (H12AffineFastState.compose env5103 (packedSelected [0,1,3,6,7,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5103 : packedSelected [0,1,3,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env5104 : List Nat := [2,4,8,0,11,0,3,5,512,1024,2048,1028,2050,16384,32768,1542,1028,51712,1025,32768,1028,34319,34309,34819,2056,34309,1541,16385,16384,19471,2564,52239,4,17413,2571,33796]

theorem envBound5104 : H12AffineFastState.Bounded env5104 := by
  intro p hp
  have h : env5104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5103_5104 : H12AffineEnvironment.transform 4 11 env5103 = env5104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5103 == env5104) = true)

theorem identity5104 : scanCanonicalize (H12AffineFastState.compose env5104 (packedSelected [0,1,3,9,11,17] rootPS)) = affineNative (2^(13+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5104 : packedSelected [0,1,3,9,11,17] rootPS < 2^1333 := by decide +kernel

def env5105 : List Nat := [2,4,8,0,11,0,3,5,512,1024,2048,1028,2050,1038,32768,1542,1028,36366,1025,32768,1028,34319,34309,34819,2056,34309,1541,1039,1038,2049,2564,34817,4,11,2571,33796]

theorem envBound5105 : H12AffineFastState.Bounded env5105 := by
  intro p hp
  have h : env5105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5104_5105 : H12AffineEnvironment.transform 13 1038 env5104 = env5105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1038 env5104 == env5105) = true)

theorem identity5105 : scanCanonicalize (H12AffineFastState.compose env5105 (packedSelected [1,2,4,5,6,9] rootPS)) = affineNative (2^(14+1) ^^^ 1540) := by decide +kernel

theorem selectedBound5105 : packedSelected [1,2,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env5106 : List Nat := [2,4,8,0,11,0,3,5,512,1024,2048,1028,2050,1038,1540,1542,1028,2058,1025,1540,1028,11,1,3591,2056,1,1541,1039,1038,2049,2564,3589,4,11,2571,512]

theorem envBound5106 : H12AffineFastState.Bounded env5106 := by
  intro p hp
  have h : env5106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5105_5106 : H12AffineEnvironment.transform 14 1540 env5105 = env5106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1540 env5105 == env5106) = true)

theorem identity5106 : scanCanonicalize (H12AffineFastState.compose env5106 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound5106 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env5107 : List Nat := [2,4,8,0,11,0,3,5,512,1024,522,1028,520,1038,1540,1542,1028,512,1025,1540,1028,11,1,1037,514,1,1541,1039,1038,523,14,1039,4,11,1,512]

theorem envBound5107 : H12AffineFastState.Bounded env5107 := by
  intro p hp
  have h : env5107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5106_5107 : H12AffineEnvironment.transform 10 522 env5106 = env5107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env5106 == env5107) = true)

def env5108 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,32768,65536,1028,262144,1025,32768,1029,4194304,4194336,41002,8329,4194336,320645,16385,16385,19493,74795,58533,173,17412,4236420,4194849]

theorem envBound5108 : H12AffineFastState.Bounded env5108 := by
  intro p hp
  have h : env5108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5097_5108 : H12AffineEnvironment.transform 3 1 env5097 = env5108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5097 == env5108) = true)

theorem identity5108 : scanCanonicalize (H12AffineFastState.compose env5108 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 25734) := by decide +kernel

theorem selectedBound5108 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5109 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,32768,25734,1028,262144,1025,32768,1029,4194304,4194336,41002,8329,4194336,320645,16385,16385,19493,16557,58533,173,17412,4236420,4194849]

theorem envBound5109 : H12AffineFastState.Bounded env5109 := by
  intro p hp
  have h : env5109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5108_5109 : H12AffineEnvironment.transform 15 25734 env5108 = env5109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25734 env5108 == env5109) = true)

theorem identity5109 : scanCanonicalize (H12AffineFastState.compose env5109 (packedSelected [1,5,8,13,18,21,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5109 : packedSelected [1,5,8,13,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env5110 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,32768,25734,1028,2081,1025,32768,1029,4194304,4194336,41002,8329,4194336,60580,16385,16385,19493,16557,58533,173,17412,4236420,4194849]

theorem envBound5110 : H12AffineFastState.Bounded env5110 := by
  intro p hp
  have h : env5110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5109_5110 : H12AffineEnvironment.transform 17 2081 env5109 = env5110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5109 == env5110) = true)

theorem identity5110 : scanCanonicalize (H12AffineFastState.compose env5110 (packedSelected [1,2,6,8,11,17,21] rootPS)) = affineNative (2^(21+1) ^^^ 9871) := by decide +kernel

theorem selectedBound5110 : packedSelected [1,2,6,8,11,17,21] rootPS < 2^1333 := by decide +kernel

def env5111 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,32768,25734,1028,2081,1025,32768,1029,9871,9903,41002,8329,9903,60580,16385,16385,19493,16557,58533,173,17412,33291,9390]

theorem envBound5111 : H12AffineFastState.Bounded env5111 := by
  intro p hp
  have h : env5111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5110_5111 : H12AffineEnvironment.transform 21 9871 env5110 = env5111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9871 env5110 == env5111) = true)

theorem identity5111 : scanCanonicalize (H12AffineFastState.compose env5111 (packedSelected [3,4,5,7,9,10,13,17,27] rootPS)) = affineNative (2^(14+1) ^^^ 1702) := by decide +kernel

theorem selectedBound5111 : packedSelected [3,4,5,7,9,10,13,17,27] rootPS < 2^1333 := by decide +kernel

def env5112 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,1702,25734,1028,2081,1025,1702,1029,9871,9903,9868,8329,9903,27138,16385,16385,19493,16557,25091,173,17412,1197,9390]

theorem envBound5112 : H12AffineFastState.Bounded env5112 := by
  intro p hp
  have h : env5112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5111_5112 : H12AffineEnvironment.transform 14 1702 env5111 = env5112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1702 env5111 == env5112) = true)

theorem identity5112 : scanCanonicalize (H12AffineFastState.compose env5112 (packedSelected [0,1,2,4,6,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound5112 : packedSelected [0,1,2,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env5113 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,1063,16384,1702,16545,1028,2081,1025,1702,1029,680,648,683,1198,648,20005,16385,16385,19493,16557,17956,173,17412,1197,137]

theorem envBound5113 : H12AffineFastState.Bounded env5113 := by
  intro p hp
  have h : env5113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5112_5113 : H12AffineEnvironment.transform 12 1063 env5112 = env5113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env5112 == env5113) = true)

theorem identity5113 : scanCanonicalize (H12AffineFastState.compose env5113 (packedSelected [3,6,8,12,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound5113 : packedSelected [3,6,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env5114 : List Nat := [2,4,8,1,32,1,128,172,136,1024,2048,1029,1063,16384,1070,16545,1028,2081,1025,1070,1029,32,0,35,1198,0,19629,16385,16385,19493,16557,17580,173,17412,1197,137]

theorem envBound5114 : H12AffineFastState.Bounded env5114 := by
  intro p hp
  have h : env5114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5113_5114 : H12AffineEnvironment.transform 8 136 env5113 = env5114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env5113 == env5114) = true)

theorem identity5114 : scanCanonicalize (H12AffineFastState.compose env5114 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound5114 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5115 : List Nat := [2,4,8,1,32,1,128,172,136,1024,2048,1029,1063,2090,1070,2187,1028,2081,1025,1070,1029,32,0,35,1198,0,1159,2091,2091,1039,2183,3206,173,3118,1197,137]

theorem envBound5115 : H12AffineFastState.Bounded env5115 := by
  intro p hp
  have h : env5115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5114_5115 : H12AffineEnvironment.transform 13 2090 env5114 = env5115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env5114 == env5115) = true)

theorem identity5115 : scanCanonicalize (H12AffineFastState.compose env5115 (packedSelected [4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1066) := by decide +kernel

theorem selectedBound5115 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env5116 : List Nat := [2,4,8,1,32,1,128,172,136,1024,1066,1029,1063,1024,1070,1185,1028,1035,1025,1070,1029,32,0,35,1198,0,1159,1025,1025,1039,1197,172,173,4,1197,137]

theorem envBound5116 : H12AffineFastState.Bounded env5116 := by
  intro p hp
  have h : env5116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5115_5116 : H12AffineEnvironment.transform 10 1066 env5115 = env5116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1066 env5115 == env5116) = true)

theorem identity5116 : scanCanonicalize (H12AffineFastState.compose env5116 (packedSelected [1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 12) := by decide +kernel

theorem selectedBound5116 : packedSelected [1,2,7] rootPS < 2^1333 := by decide +kernel

def env5117 : List Nat := [2,4,8,1,32,1,12,32,4,1024,1066,1029,1063,1024,1070,1069,1028,1035,1025,1070,1029,32,0,35,1058,0,1035,1025,1025,1039,1057,32,33,4,1057,5]

theorem envBound5117 : H12AffineFastState.Bounded env5117 := by
  intro p hp
  have h : env5117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5116_5117 : H12AffineEnvironment.transform 6 12 env5116 = env5117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 12 env5116 == env5117) = true)

theorem identity5117 : scanCanonicalize (H12AffineFastState.compose env5117 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound5117 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5118 : List Nat := [2,4,8,1,32,1,12,32,4,15,37,10,40,15,33,34,11,4,14,33,10,32,0,35,45,0,4,14,14,0,46,32,33,4,46,5]

theorem envBound5118 : H12AffineFastState.Bounded env5118 := by
  intro p hp
  have h : env5118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5117_5118 : H12AffineEnvironment.transform 9 15 env5117 = env5118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env5117 == env5118) = true)

theorem identity5118 : scanCanonicalize (H12AffineFastState.compose env5118 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5118 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env5119 : List Nat := [2,4,8,1,11,1,12,11,4,15,14,10,3,15,10,9,11,4,14,10,10,11,0,8,6,0,4,14,14,0,5,11,10,4,5,5]

theorem envBound5119 : H12AffineFastState.Bounded env5119 := by
  intro p hp
  have h : env5119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5118_5119 : H12AffineEnvironment.transform 4 11 env5118 = env5119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5118 == env5119) = true)

theorem identity5119 : scanCanonicalize (H12AffineFastState.compose env5119 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound5119 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env5120 : List Nat := [2,4,7,1,4,1,3,4,4,0,1,5,3,0,5,6,4,4,1,5,5,4,0,7,6,0,4,1,1,0,5,4,5,4,5,5]

theorem envBound5120 : H12AffineFastState.Bounded env5120 := by
  intro p hp
  have h : env5120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5119_5120 : H12AffineEnvironment.transform 2 7 env5119 = env5120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env5119 == env5120) = true)

def leafEnv5120 : List Nat := [2,4,7,1,4,1,3,4,4,0,1,5,3,0,5,6,4,4,1,5,5,4,0,7,5,6,1,0,4,1,1,0,5,4,5,4,4,2,5,5,1,1,0]

def active5120 : List Nat := [0,1]

def tree5120 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5120 : H12WitnessSearch.Good tree5120 := H12GlobalWitnessIndex.good

theorem leafIdentity5120 : H12AffineFastState.composeSystem env5120 rootObs = leafEnv5120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5120 rootObs == leafEnv5120) = true)

theorem terminalChecked5120 : H12PackedTerminal.terminalCheckFast leafEnv5120 active5120 tree5120 = true := by decide +kernel

def env5121 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1465,262144,1025,32768,1045,4194304,8388608,41002,8329,8388609,320660,16385,16812,19508,74795,12641576,257,17429,4236436,8389565]

theorem envBound5121 : H12AffineFastState.Bounded env5121 := by
  intro p hp
  have h : env5121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5069_5121 : H12AffineEnvironment.transform 5 17 env5069 = env5121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5069 == env5121) = true)

theorem identity5121 : scanCanonicalize (H12AffineFastState.compose env5121 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound5121 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5122 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1465,262144,1025,32768,1045,4194304,445,41002,8329,444,320660,16385,16812,19508,74795,4252821,257,17429,4236436,512]

theorem envBound5122 : H12AffineFastState.Bounded env5122 := by
  intro p hp
  have h : env5122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5121_5122 : H12AffineEnvironment.transform 22 445 env5121 = env5122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env5121 == env5122) = true)

theorem identity5122 : scanCanonicalize (H12AffineFastState.compose env5122 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound5122 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5123 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1465,262144,1025,32768,1045,41348,445,41002,8329,444,320660,16385,16812,19508,74795,17681,257,17429,1296,512]

theorem envBound5123 : H12AffineFastState.Bounded env5123 := by
  intro p hp
  have h : env5123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5122_5123 : H12AffineEnvironment.transform 21 41348 env5122 = env5123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env5122 == env5123) = true)

theorem identity5123 : scanCanonicalize (H12AffineFastState.compose env5123 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5123 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5124 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,65536,1465,262144,1025,26260,1045,18192,445,18110,8329,444,262656,16385,16812,19508,74795,17681,257,17429,1296,512]

theorem envBound5124 : H12AffineFastState.Bounded env5124 := by
  intro p hp
  have h : env5124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5123_5124 : H12AffineEnvironment.transform 14 26260 env5123 = env5124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5123 == env5124) = true)

theorem identity5124 : scanCanonicalize (H12AffineFastState.compose env5124 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25751) := by decide +kernel

theorem selectedBound5124 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5125 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,25751,1465,262144,1025,26260,1045,18192,445,18110,8329,444,262656,16385,16812,19508,16572,17681,257,17429,1296,512]

theorem envBound5125 : H12AffineFastState.Bounded env5125 := by
  intro p hp
  have h : env5125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5124_5125 : H12AffineEnvironment.transform 15 25751 env5124 = env5125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25751 env5124 == env5125) = true)

theorem identity5125 : scanCanonicalize (H12AffineFastState.compose env5125 (packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound5125 : packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS < 2^1333 := by decide +kernel

def env5126 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,25751,1465,2341,1025,26260,1045,18192,445,18110,8329,444,2853,16385,16812,19508,16572,17681,257,17429,1296,512]

theorem envBound5126 : H12AffineFastState.Bounded env5126 := by
  intro p hp
  have h : env5126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5125_5126 : H12AffineEnvironment.transform 17 2341 env5125 = env5126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env5125 == env5126) = true)

theorem identity5126 : scanCanonicalize (H12AffineFastState.compose env5126 (packedSelected [1,3,4,7,9,12,13,15,17,27] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound5126 : packedSelected [1,3,4,7,9,12,13,15,17,27] rootPS < 2^1333 := by decide +kernel

def env5127 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,1840,8612,9127,1465,2341,1025,8612,1045,32,445,398,8329,444,2853,1841,1692,2820,1932,545,257,805,1296,512]

theorem envBound5127 : H12AffineFastState.Bounded env5127 := by
  intro p hp
  have h : env5127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5126_5127 : H12AffineEnvironment.transform 13 1840 env5126 = env5127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env5126 == env5127) = true)

theorem identity5127 : scanCanonicalize (H12AffineFastState.compose env5127 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5127 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5128 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1045,8192,1840,8461,8974,1296,2341,1025,8461,1045,32,276,295,8224,277,2853,1841,1589,2820,1829,545,257,805,1296,512]

theorem envBound5128 : H12AffineFastState.Bounded env5128 := by
  intro p hp
  have h : env5128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5127_5128 : H12AffineEnvironment.transform 6 41 env5127 = env5128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5127 == env5128) = true)

theorem identity5128 : scanCanonicalize (H12AffineFastState.compose env5128 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5128 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5129 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1045,8192,1589,8200,8715,1045,2080,1025,8200,1045,32,17,34,8224,16,2592,1588,1589,2561,1568,545,4,544,1045,512]

theorem envBound5129 : H12AffineFastState.Bounded env5129 := by
  intro p hp
  have h : env5129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5128_5129 : H12AffineEnvironment.transform 7 5 env5128 = env5129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5128 == env5129) = true)

theorem identity5129 : scanCanonicalize (H12AffineFastState.compose env5129 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5129 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5130 : List Nat := [2,4,8,16,32,17,41,5,1,1024,2048,1045,8192,1076,8200,8202,1045,2080,1025,8200,1045,32,17,34,8224,16,2081,1077,1076,2048,1057,32,4,33,1045,1]

theorem envBound5130 : H12AffineFastState.Bounded env5130 := by
  intro p hp
  have h : env5130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5129_5130 : H12AffineEnvironment.transform 8 1 env5129 = env5130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5129 == env5130) = true)

theorem identity5130 : scanCanonicalize (H12AffineFastState.compose env5130 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 3110) := by decide +kernel

theorem selectedBound5130 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5131 : List Nat := [2,4,8,16,32,17,41,5,1,1024,2048,1045,3110,1076,3118,3116,1045,2080,1025,3118,1045,32,17,34,3078,16,2081,1077,1076,2048,1057,32,4,33,1045,1]

theorem envBound5131 : H12AffineFastState.Bounded env5131 := by
  intro p hp
  have h : env5131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5130_5131 : H12AffineEnvironment.transform 12 3110 env5130 = env5131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3110 env5130 == env5131) = true)

theorem identity5131 : scanCanonicalize (H12AffineFastState.compose env5131 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound5131 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5132 : List Nat := [2,4,8,16,32,17,41,5,1,46,2048,59,2056,26,2048,2050,59,2080,47,2048,59,32,17,34,2088,16,2081,27,26,2048,15,32,4,33,59,1]

theorem envBound5132 : H12AffineFastState.Bounded env5132 := by
  intro p hp
  have h : env5132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5131_5132 : H12AffineEnvironment.transform 9 46 env5131 = env5132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env5131 == env5132) = true)

def env5133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849104,16385,16893,547952,598058,12644668,525568,545873,4239488,8914925]

theorem envBound5133 : H12AffineFastState.Bounded env5133 := by
  intro p hp
  have h : env5133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5015_5133 : H12AffineEnvironment.transform 20 4097 env5015 = env5133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5015 == env5133) = true)

def env5134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,323792,16385,16893,22640,74794,12644668,256,20561,4239488,8389613]

theorem envBound5134 : H12AffineFastState.Bounded env5134 := by
  intro p hp
  have h : env5134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5133_5134 : H12AffineEnvironment.transform 18 1024 env5133 = env5134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5133 == env5134) = true)

theorem identity5134 : scanCanonicalize (H12AffineFastState.compose env5134 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 61909) := by decide +kernel

theorem selectedBound5134 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,61909,8388608,41002,8329,8388689,323792,16385,16893,22640,74794,8388841,256,20561,16725,8389613]

theorem envBound5135 : H12AffineFastState.Bounded env5135 := by
  intro p hp
  have h : env5135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5134_5135 : H12AffineEnvironment.transform 21 61909 env5134 = env5135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61909 env5134 == env5135) = true)

def env5136 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,61829,8388608,41002,8329,8388609,323712,16385,16813,22560,74794,8388793,256,20481,16645,8389565]

theorem envBound5136 : H12AffineFastState.Bounded env5136 := by
  intro p hp
  have h : env5136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5135_5136 : H12AffineEnvironment.transform 5 16 env5135 = env5136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5135 == env5136) = true)

def env5137 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,262144,1024,8352,4097,20773,8388608,138,8329,8388609,282656,16385,16813,22560,74794,8388793,256,20481,16645,8389565]

theorem envBound5137 : H12AffineFastState.Bounded env5137 := by
  intro p hp
  have h : env5137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5136_5137 : H12AffineEnvironment.transform 14 8352 env5136 = env5137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5136 == env5137) = true)

theorem identity5137 : scanCanonicalize (H12AffineFastState.compose env5137 (packedSelected [0,9,13,17,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 284825) := by decide +kernel

theorem selectedBound5137 : packedSelected [0,9,13,17,22,27] rootPS < 2^1333 := by decide +kernel

def env5138 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,262144,1024,8352,4097,20773,284825,138,8329,284824,282656,16385,16813,22560,74794,284704,256,20481,16645,285476]

theorem envBound5138 : H12AffineFastState.Bounded env5138 := by
  intro p hp
  have h : env5138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5137_5138 : H12AffineEnvironment.transform 22 284825 env5137 = env5138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284825 env5137 == env5138) = true)

theorem identity5138 : scanCanonicalize (H12AffineFastState.compose env5138 (packedSelected [0,1,3,4,7,13,17,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 28715) := by decide +kernel

theorem selectedBound5138 : packedSelected [0,1,3,4,7,13,17,22,24,28] rootPS < 2^1333 := by decide +kernel

def env5139 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,28715,4525,262144,1024,8352,4097,20773,284825,138,8329,284824,282656,16385,16813,22560,21505,284704,256,20481,16645,285476]

theorem envBound5139 : H12AffineFastState.Bounded env5139 := by
  intro p hp
  have h : env5139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5138_5139 : H12AffineEnvironment.transform 15 28715 env5138 = env5139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28715 env5138 == env5139) = true)

theorem identity5139 : scanCanonicalize (H12AffineFastState.compose env5139 (packedSelected [17,21] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5139 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5140 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,8352,28715,4265,262144,1024,8352,4097,20513,284825,138,8329,284824,282656,16385,16553,22560,21505,284704,4,20481,16385,285216]

theorem envBound5140 : H12AffineFastState.Bounded env5140 := by
  intro p hp
  have h : env5140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5139_5140 : H12AffineEnvironment.transform 7 4 env5139 = env5140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5139 == env5140) = true)

theorem identity5140 : scanCanonicalize (H12AffineFastState.compose env5140 (packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 7694) := by decide +kernel

theorem selectedBound5140 : packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env5141 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,7694,8352,11813,4265,262144,1024,8352,4097,3631,263831,138,8329,263830,265774,7695,7847,1582,2575,263726,4,3599,7695,263214]

theorem envBound5141 : H12AffineFastState.Bounded env5141 := by
  intro p hp
  have h : env5141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5140_5141 : H12AffineEnvironment.transform 13 7694 env5140 = env5141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7694 env5140 == env5141) = true)

theorem identity5141 : scanCanonicalize (H12AffineFastState.compose env5141 (packedSelected [0,2,3,4,5,6,7,9,10,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5141 : packedSelected [0,2,3,4,5,6,7,9,10,17] rootPS < 2^1333 := by decide +kernel

def env5142 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,7694,8352,11813,4265,2081,1024,8352,4097,3631,3766,138,8329,3767,1551,7695,7847,1582,2575,3599,4,3599,7695,3087]

theorem envBound5142 : H12AffineFastState.Bounded env5142 := by
  intro p hp
  have h : env5142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5141_5142 : H12AffineEnvironment.transform 17 2081 env5141 = env5142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5141 == env5142) = true)

theorem identity5142 : scanCanonicalize (H12AffineFastState.compose env5142 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound5142 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5143 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,2195,8192,1693,8352,11813,2106,2081,1024,8352,2194,3631,3766,138,8329,3767,1551,1692,1588,1582,2575,3599,4,3599,1692,3087]

theorem envBound5143 : H12AffineFastState.Bounded env5143 := by
  intro p hp
  have h : env5143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5142_5143 : H12AffineEnvironment.transform 11 2195 env5142 = env5143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env5142 == env5143) = true)

theorem identity5143 : scanCanonicalize (H12AffineFastState.compose env5143 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5143 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env5144 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,2107,8192,1589,8200,11813,2106,2081,1024,8200,2106,3631,3614,34,8225,3615,1551,1588,1588,1582,2575,3599,4,3599,1588,3087]

theorem envBound5144 : H12AffineFastState.Bounded env5144 := by
  intro p hp
  have h : env5144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5143_5144 : H12AffineEnvironment.transform 6 40 env5143 = env5144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5143 == env5144) = true)

theorem identity5144 : scanCanonicalize (H12AffineFastState.compose env5144 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5144 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5145 : List Nat := [2,4,8,16,27,16,19,4,512,1024,2048,2048,8192,1550,8200,11806,2049,2074,1024,8200,2049,3604,3614,25,8218,3615,1551,1551,1551,1557,2575,3599,4,3599,1551,3087]

theorem envBound5145 : H12AffineFastState.Bounded env5145 := by
  intro p hp
  have h : env5145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5144_5145 : H12AffineEnvironment.transform 4 27 env5144 = env5145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5144 == env5145) = true)

theorem identity5145 : scanCanonicalize (H12AffineFastState.compose env5145 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound5145 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5146 : List Nat := [2,4,8,16,27,16,19,4,512,1024,2048,2048,1030,1550,1038,2584,2049,2074,1024,1038,2049,3604,3614,25,1052,3615,1551,1551,1551,1557,2575,3599,4,3599,1551,3087]

theorem envBound5146 : H12AffineFastState.Bounded env5146 := by
  intro p hp
  have h : env5146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5145_5146 : H12AffineEnvironment.transform 12 1030 env5145 = env5146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env5145 == env5146) = true)

theorem identity5146 : scanCanonicalize (H12AffineFastState.compose env5146 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5146 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5147 : List Nat := [2,4,8,16,27,16,19,4,0,1024,2048,2048,1030,1038,1038,2072,2049,2074,1024,1038,2049,3092,3102,25,1052,3103,1039,1039,1039,1045,2063,3087,4,3087,1039,3087]

theorem envBound5147 : H12AffineFastState.Bounded env5147 := by
  intro p hp
  have h : env5147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5146_5147 : H12AffineEnvironment.transform 8 0 env5146 = env5147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5146 == env5147) = true)

theorem identity5147 : scanCanonicalize (H12AffineFastState.compose env5147 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound5147 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5148 : List Nat := [2,4,8,16,27,16,19,4,0,15,2048,2048,9,1,1,2072,2049,2074,15,1,2049,2075,2065,25,19,2064,0,0,0,26,2063,2048,4,2048,0,2048]

theorem envBound5148 : H12AffineFastState.Bounded env5148 := by
  intro p hp
  have h : env5148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5147_5148 : H12AffineEnvironment.transform 9 15 env5147 = env5148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env5147 == env5148) = true)

def env5149 : List Nat := [2,4,8,16,27,16,19,4,0,15,0,0,9,1,1,24,1,26,15,1,1,27,17,25,19,16,0,0,0,26,15,0,4,0,0,0]

theorem envBound5149 : H12AffineFastState.Bounded env5149 := by
  intro p hp
  have h : env5149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5148_5149 : H12AffineEnvironment.transform 10 0 env5148 = env5149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env5148 == env5149) = true)

def env5150 : List Nat := [2,4,8,16,27,16,19,4,0,15,1,1,9,1,1,25,0,27,15,1,0,26,16,25,19,17,0,0,0,26,14,1,4,1,0,1]

theorem envBound5150 : H12AffineFastState.Bounded env5150 := by
  intro p hp
  have h : env5150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5148_5150 : H12AffineEnvironment.transform 10 1 env5148 = env5150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env5148 == env5150) = true)

theorem identity5150 : scanCanonicalize (H12AffineFastState.compose env5150 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound5150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5151 : List Nat := [2,4,8,5,14,5,6,4,0,15,1,1,9,1,1,12,0,14,15,1,0,15,5,12,6,4,0,0,0,15,14,1,4,1,0,1]

theorem envBound5151 : H12AffineFastState.Bounded env5151 := by
  intro p hp
  have h : env5151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5150_5151 : H12AffineEnvironment.transform 3 5 env5150 = env5151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env5150 == env5151) = true)

theorem identity5151 : scanCanonicalize (H12AffineFastState.compose env5151 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5151 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5152 : List Nat := [2,1,8,0,11,0,3,1,0,10,1,1,9,1,1,9,0,11,10,1,0,10,0,9,3,1,0,0,0,10,11,1,1,1,0,1]

theorem envBound5152 : H12AffineFastState.Bounded env5152 := by
  intro p hp
  have h : env5152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5151_5152 : H12AffineEnvironment.transform 1 1 env5151 = env5152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5151 == env5152) = true)

def leafEnv5152 : List Nat := [2,1,8,0,11,0,3,1,0,10,1,1,9,1,1,9,0,11,10,1,0,10,0,9,11,3,1,1,0,0,0,10,11,1,1,1,1,3,0,1,1,1,0]

def active5152 : List Nat := [0,2]

def tree5152 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5152 : H12WitnessSearch.Good tree5152 := H12GlobalWitnessIndex.good

theorem leafIdentity5152 : H12AffineFastState.composeSystem env5152 rootObs = leafEnv5152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5152 rootObs == leafEnv5152) = true)

theorem terminalChecked5152 : H12PackedTerminal.terminalCheckFast leafEnv5152 active5152 tree5152 = true := by decide +kernel

def env5153 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,262144,1024,8353,4097,20772,8388608,139,8329,8388609,282657,16385,16813,22560,74794,8388793,256,20481,16645,8389565]

theorem envBound5153 : H12AffineFastState.Bounded env5153 := by
  intro p hp
  have h : env5153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5136_5153 : H12AffineEnvironment.transform 14 8353 env5136 = env5153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env5136 == env5153) = true)

theorem identity5153 : scanCanonicalize (H12AffineFastState.compose env5153 (packedSelected [0,9,13,17,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 96679) := by decide +kernel

theorem selectedBound5153 : packedSelected [0,9,13,17,22,27] rootPS < 2^1333 := by decide +kernel

def env5154 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,96679,1024,8353,4097,20772,8388608,139,8329,8388609,76166,16385,16813,22560,74794,8388793,256,20481,16645,8389565]

theorem envBound5154 : H12AffineFastState.Bounded env5154 := by
  intro p hp
  have h : env5154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5153_5154 : H12AffineEnvironment.transform 17 96679 env5153 = env5154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96679 env5153 == env5154) = true)

theorem identity5154 : scanCanonicalize (H12AffineFastState.compose env5154 (packedSelected [0,1,3,4,7,11,13,17,18,22,23,24,28,32] rootPS)) = affineNative (2^(22+1) ^^^ 73874) := by decide +kernel

theorem selectedBound5154 : packedSelected [0,1,3,4,7,11,13,17,18,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5155 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,96679,1024,8353,4097,20772,73874,139,8329,73875,76166,16385,16813,22560,74794,73771,256,20481,16645,74543]

theorem envBound5155 : H12AffineFastState.Bounded env5155 := by
  intro p hp
  have h : env5155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5154_5155 : H12AffineEnvironment.transform 22 73874 env5154 = env5155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73874 env5154 == env5155) = true)

theorem identity5155 : scanCanonicalize (H12AffineFastState.compose env5155 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound5155 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5156 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,8353,65536,4525,76047,1024,8353,4097,396,73874,139,8329,73875,76166,4265,4357,2184,74794,73771,256,169,4525,74543]

theorem envBound5156 : H12AffineFastState.Bounded env5156 := by
  intro p hp
  have h : env5156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5155_5156 : H12AffineEnvironment.transform 13 4264 env5155 = env5156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env5155 == env5156) = true)

theorem identity5156 : scanCanonicalize (H12AffineFastState.compose env5156 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 11149) := by decide +kernel

theorem selectedBound5156 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5157 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,8353,11149,4525,642,1024,8353,4097,396,2847,139,8329,2846,523,4265,4357,2184,4007,2982,256,169,4525,2210]

theorem envBound5157 : H12AffineFastState.Bounded env5157 := by
  intro p hp
  have h : env5157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5156_5157 : H12AffineEnvironment.transform 15 11149 env5156 = env5157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11149 env5156 == env5157) = true)

theorem identity5157 : scanCanonicalize (H12AffineFastState.compose env5157 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 7475) := by decide +kernel

theorem selectedBound5157 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env5158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7475,4264,7570,5822,4525,642,1024,7570,4097,396,2847,139,7610,2846,523,4265,4357,2184,4007,2982,256,169,4525,2210]

theorem envBound5158 : H12AffineFastState.Bounded env5158 := by
  intro p hp
  have h : env5158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5157_5158 : H12AffineEnvironment.transform 12 7475 env5157 = env5158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7475 env5157 == env5158) = true)

theorem identity5158 : scanCanonicalize (H12AffineFastState.compose env5158 (packedSelected [0,1,3,5,7,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1599) := by decide +kernel

theorem selectedBound5158 : packedSelected [0,1,3,5,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env5159 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1599,2828,1687,2989,129,1938,642,1024,2989,1598,396,2847,139,2949,2846,523,1686,1850,2184,4007,2982,256,169,1938,2210]

theorem envBound5159 : H12AffineFastState.Bounded env5159 := by
  intro p hp
  have h : env5159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5158_5159 : H12AffineEnvironment.transform 11 1599 env5158 = env5159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1599 env5158 == env5159) = true)

theorem identity5159 : scanCanonicalize (H12AffineFastState.compose env5159 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound5159 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5160 : List Nat := [2,4,8,16,32,16,128,256,512,1024,798,1599,18,1687,179,129,1938,642,1024,179,1598,396,1,139,155,0,523,1686,1850,918,1209,184,256,169,1938,956]

theorem envBound5160 : H12AffineFastState.Bounded env5160 := by
  intro p hp
  have h : env5160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5159_5160 : H12AffineEnvironment.transform 10 798 env5159 = env5160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env5159 == env5160) = true)

theorem identity5160 : scanCanonicalize (H12AffineFastState.compose env5160 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5160 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5161 : List Nat := [2,4,8,0,32,0,128,256,512,1024,782,1583,2,1671,163,129,1922,642,1024,163,1582,396,1,139,139,0,523,1670,1834,902,1193,168,256,169,1922,940]

theorem envBound5161 : H12AffineFastState.Bounded env5161 := by
  intro p hp
  have h : env5161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5160_5161 : H12AffineEnvironment.transform 3 0 env5160 = env5161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5160 == env5161) = true)

theorem identity5161 : scanCanonicalize (H12AffineFastState.compose env5161 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5161 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5162 : List Nat := [2,4,8,0,11,0,128,256,512,1024,782,1540,2,1671,136,129,1922,642,1024,136,1541,396,1,139,139,0,523,1670,1793,902,1154,131,256,130,1922,903]

theorem envBound5162 : H12AffineFastState.Bounded env5162 := by
  intro p hp
  have h : env5162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5161_5162 : H12AffineEnvironment.transform 4 11 env5161 = env5162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5161 == env5162) = true)

theorem identity5162 : scanCanonicalize (H12AffineFastState.compose env5162 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound5162 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5163 : List Nat := [2,4,8,0,11,0,128,141,512,1024,643,1540,2,1671,136,129,1551,642,1024,136,1541,1,1,139,139,0,523,1670,1676,523,1154,131,141,130,1551,522]

theorem envBound5163 : H12AffineFastState.Bounded env5163 := by
  intro p hp
  have h : env5163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5162_5163 : H12AffineEnvironment.transform 7 141 env5162 = env5163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env5162 == env5163) = true)

theorem identity5163 : scanCanonicalize (H12AffineFastState.compose env5163 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound5163 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5164 : List Nat := [2,4,8,0,11,0,128,141,137,1024,10,1165,2,1038,136,129,1158,11,1024,136,1164,1,1,139,139,0,130,1039,1029,130,1154,131,141,130,1158,131]

theorem envBound5164 : H12AffineFastState.Bounded env5164 := by
  intro p hp
  have h : env5164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5163_5164 : H12AffineEnvironment.transform 8 137 env5163 = env5164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env5163 == env5164) = true)

theorem identity5164 : scanCanonicalize (H12AffineFastState.compose env5164 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound5164 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env5165 : List Nat := [2,4,8,0,11,0,2,15,11,1024,10,1039,2,1038,10,3,1028,11,1024,10,1038,1,1,9,9,0,0,1039,1029,0,1024,1,15,0,1028,1]

theorem envBound5165 : H12AffineFastState.Bounded env5165 := by
  intro p hp
  have h : env5165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5164_5165 : H12AffineEnvironment.transform 6 2 env5164 = env5165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env5164 == env5165) = true)

theorem identity5165 : scanCanonicalize (H12AffineFastState.compose env5165 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5166 : List Nat := [2,4,2,0,1,0,2,5,1,1024,0,1029,2,1028,0,3,1028,1,1024,0,1028,1,1,3,3,0,0,1029,1029,0,1024,1,5,0,1028,1]

theorem envBound5166 : H12AffineFastState.Bounded env5166 := by
  intro p hp
  have h : env5166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5165_5166 : H12AffineEnvironment.transform 2 2 env5165 = env5166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5165 == env5166) = true)

def leafEnv5166 : List Nat := [2,4,2,0,1,0,2,5,1,1024,0,1029,2,1028,0,3,1028,1,1024,0,1028,1,1,3,1024,3,1,0,0,1029,1029,0,1024,1,5,0,4,3,1028,1,1,1029,0]

def active5166 : List Nat := [0,1,9]

def tree5166 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5166 : H12WitnessSearch.Good tree5166 := H12GlobalWitnessIndex.good

theorem leafIdentity5166 : H12AffineFastState.composeSystem env5166 rootObs = leafEnv5166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5166 rootObs == leafEnv5166) = true)

theorem terminalChecked5166 : H12PackedTerminal.terminalCheckFast leafEnv5166 active5166 tree5166 = true := by decide +kernel

def env5167 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,61828,8388608,41002,8329,8388608,323713,16385,16812,22561,74794,8388792,256,20480,16644,8389564]

theorem envBound5167 : H12AffineFastState.Bounded env5167 := by
  intro p hp
  have h : env5167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5135_5167 : H12AffineEnvironment.transform 5 17 env5135 = env5167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5135 == env5167) = true)

theorem identity5167 : scanCanonicalize (H12AffineFastState.compose env5167 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound5167 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5168 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,61828,444,41002,8329,444,323713,16385,16812,22561,74794,260,256,20480,16644,512]

theorem envBound5168 : H12AffineFastState.Bounded env5168 := by
  intro p hp
  have h : env5168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5167_5168 : H12AffineEnvironment.transform 22 444 env5167 = env5168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env5167 == env5168) = true)

theorem identity5168 : scanCanonicalize (H12AffineFastState.compose env5168 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound5168 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5169 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1024,32768,4097,41348,444,41002,8329,444,303233,4097,4524,2081,74794,260,256,0,4356,512]

theorem envBound5169 : H12AffineFastState.Bounded env5169 := by
  intro p hp
  have h : env5169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5168_5169 : H12AffineEnvironment.transform 13 4096 env5168 = env5169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5168 == env5169) = true)

theorem identity5169 : scanCanonicalize (H12AffineFastState.compose env5169 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound5169 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5170 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,65536,4524,262144,1024,13972,4097,5904,444,5822,8329,444,267797,4097,4524,2081,74794,260,256,0,4356,512]

theorem envBound5170 : H12AffineFastState.Bounded env5170 := by
  intro p hp
  have h : env5170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5169_5170 : H12AffineEnvironment.transform 14 13972 env5169 = env5170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env5169 == env5170) = true)

theorem identity5170 : scanCanonicalize (H12AffineFastState.compose env5170 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound5170 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5171 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,8322,4524,262144,1024,13972,4097,5904,444,5822,8329,444,267797,4097,4524,2081,1192,260,256,0,4356,512]

theorem envBound5171 : H12AffineFastState.Bounded env5171 := by
  intro p hp
  have h : env5171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5170_5171 : H12AffineEnvironment.transform 15 8322 env5170 = env5171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env5170 == env5171) = true)

theorem identity5171 : scanCanonicalize (H12AffineFastState.compose env5171 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5171 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5172 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,8322,4524,2081,1024,13972,4097,5904,444,5822,8329,444,7732,4097,4524,2081,1192,260,256,0,4356,512]

theorem envBound5172 : H12AffineFastState.Bounded env5172 := by
  intro p hp
  have h : env5172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5171_5172 : H12AffineEnvironment.transform 17 2081 env5171 = env5172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5171 == env5172) = true)

theorem identity5172 : scanCanonicalize (H12AffineFastState.compose env5172 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound5172 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5173 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1693,8192,1693,8201,8322,1841,2081,1024,8201,1692,397,444,35,8329,444,2217,1692,1841,2081,1192,260,256,0,1945,512]

theorem envBound5173 : H12AffineFastState.Bounded env5173 := by
  intro p hp
  have h : env5173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5172_5173 : H12AffineEnvironment.transform 11 1693 env5172 = env5173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env5172 == env5173) = true)

theorem identity5173 : scanCanonicalize (H12AffineFastState.compose env5173 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5173 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5174 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1693,8192,1693,8201,8322,1692,2081,1024,8201,1692,32,17,35,8329,17,2217,1692,1692,2081,1192,169,173,0,1588,512]

theorem envBound5174 : H12AffineFastState.Bounded env5174 := by
  intro p hp
  have h : env5174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5173_5174 : H12AffineEnvironment.transform 7 173 env5173 = env5174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5173 == env5174) = true)

theorem identity5174 : scanCanonicalize (H12AffineFastState.compose env5174 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound5174 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5175 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,1693,8192,1693,8201,8322,1692,642,1024,8201,1692,32,17,35,8329,17,522,1692,1692,642,1192,169,173,0,1588,512]

theorem envBound5175 : H12AffineFastState.Bounded env5175 := by
  intro p hp
  have h : env5175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5174_5175 : H12AffineEnvironment.transform 10 675 env5174 = env5175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env5174 == env5175) = true)

theorem identity5175 : scanCanonicalize (H12AffineFastState.compose env5175 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound5175 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env5176 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,1693,35,1693,42,161,1692,642,1024,42,1692,32,17,35,170,17,522,1692,1692,642,1192,169,173,0,1588,512]

theorem envBound5176 : H12AffineFastState.Bounded env5176 := by
  intro p hp
  have h : env5176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5175_5176 : H12AffineEnvironment.transform 12 35 env5175 = env5176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env5175 == env5176) = true)

theorem identity5176 : scanCanonicalize (H12AffineFastState.compose env5176 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound5176 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env5177 : List Nat := [2,4,8,16,32,17,25,52,512,1024,570,1540,35,1540,42,56,1541,539,1024,42,1541,32,17,35,51,17,522,1541,1541,539,1073,48,52,0,1588,512]

theorem envBound5177 : H12AffineFastState.Bounded env5177 := by
  intro p hp
  have h : env5177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5176_5177 : H12AffineEnvironment.transform 6 25 env5176 = env5177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env5176 == env5177) = true)

theorem identity5177 : scanCanonicalize (H12AffineFastState.compose env5177 (packedSelected [2,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5177 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env5178 : List Nat := [2,4,3,16,32,17,18,52,512,1024,561,1540,35,1540,33,51,1541,528,1024,33,1541,32,17,35,51,17,513,1541,1541,528,1073,48,52,0,1588,512]

theorem envBound5178 : H12AffineFastState.Bounded env5178 := by
  intro p hp
  have h : env5178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5177_5178 : H12AffineEnvironment.transform 2 3 env5177 = env5178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5177 == env5178) = true)

theorem identity5178 : scanCanonicalize (H12AffineFastState.compose env5178 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5178 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5179 : List Nat := [2,4,3,16,1,17,18,21,512,1024,528,1540,2,1540,0,18,1541,528,1024,0,1541,1,17,2,18,17,513,1541,1541,528,1040,17,21,0,1557,512]

theorem envBound5179 : H12AffineFastState.Bounded env5179 := by
  intro p hp
  have h : env5179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5178_5179 : H12AffineEnvironment.transform 4 1 env5178 = env5179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5178 == env5179) = true)

theorem identity5179 : scanCanonicalize (H12AffineFastState.compose env5179 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5179 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5180 : List Nat := [2,4,3,16,1,17,18,21,1,1024,17,1029,2,1029,0,18,1028,17,1024,0,1028,1,17,2,18,17,0,1028,1028,17,1040,17,21,0,1044,1]

theorem envBound5180 : H12AffineFastState.Bounded env5180 := by
  intro p hp
  have h : env5180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5179_5180 : H12AffineEnvironment.transform 8 1 env5179 = env5180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5179 == env5180) = true)

theorem identity5180 : scanCanonicalize (H12AffineFastState.compose env5180 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5180 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5181 : List Nat := [2,4,3,0,1,1,2,5,1,1024,1,1029,2,1029,0,2,1028,1,1024,0,1028,1,1,2,2,1,0,1028,1028,1,1024,1,5,0,1028,1]

theorem envBound5181 : H12AffineFastState.Bounded env5181 := by
  intro p hp
  have h : env5181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5180_5181 : H12AffineEnvironment.transform 3 0 env5180 = env5181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5180 == env5181) = true)

def leafEnv5181 : List Nat := [2,4,3,0,1,1,2,5,1,1024,1,1029,2,1029,0,2,1028,1,1024,0,1028,1,1,2,1024,2,1,1,0,1028,1028,1,1024,1,5,0,4,3,1028,1,1,1028,0]

def active5181 : List Nat := [0,1,9]

def tree5181 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5181 : H12WitnessSearch.Good tree5181 := H12GlobalWitnessIndex.good

theorem leafIdentity5181 : H12AffineFastState.composeSystem env5181 rootObs = leafEnv5181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5181 rootObs == leafEnv5181) = true)

theorem terminalChecked5181 : H12PackedTerminal.terminalCheckFast leafEnv5181 active5181 tree5181 = true := by decide +kernel

def env5182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41002,8329,8388688,323793,16385,16893,22641,74795,12644668,257,20560,4239488,8389612]

theorem envBound5182 : H12AffineFastState.Bounded env5182 := by
  intro p hp
  have h : env5182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5133_5182 : H12AffineEnvironment.transform 18 1025 env5133 = env5182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5133 == env5182) = true)

theorem identity5182 : scanCanonicalize (H12AffineFastState.compose env5182 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4240596) := by decide +kernel

theorem selectedBound5182 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,4240596,41002,8329,4240516,323793,16385,16893,22641,74795,17896,257,20560,4239488,4241208]

theorem envBound5183 : H12AffineFastState.Bounded env5183 := by
  intro p hp
  have h : env5183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5182_5183 : H12AffineEnvironment.transform 22 4240596 env5182 = env5183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240596 env5182 == env5183) = true)

def env5184 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4240516,41002,8329,4240516,323713,16385,16813,22561,74795,17848,257,20480,4239488,4241208]

theorem envBound5184 : H12AffineFastState.Bounded env5184 := by
  intro p hp
  have h : env5184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5183_5184 : H12AffineEnvironment.transform 5 16 env5183 = env5184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5183 == env5184) = true)

theorem identity5184 : scanCanonicalize (H12AffineFastState.compose env5184 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 46392) := by decide +kernel

theorem selectedBound5184 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5185 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,46392,444,41002,8329,444,323713,16385,16813,22561,74795,17848,257,20480,1464,512]

theorem envBound5185 : H12AffineFastState.Bounded env5185 := by
  intro p hp
  have h : env5185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5184_5185 : H12AffineEnvironment.transform 21 46392 env5184 = env5185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46392 env5184 == env5185) = true)

theorem identity5185 : scanCanonicalize (H12AffineFastState.compose env5185 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound5185 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5186 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1025,32768,1212,41349,444,41002,8329,444,320572,16385,16813,19612,74795,17848,257,17597,1464,512]

theorem envBound5186 : H12AffineFastState.Bounded env5186 := by
  intro p hp
  have h : env5186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5185_5186 : H12AffineEnvironment.transform 11 1213 env5185 = env5186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env5185 == env5186) = true)

theorem identity5186 : scanCanonicalize (H12AffineFastState.compose env5186 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5186 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5187 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,65536,1296,262144,1025,26261,1212,18192,444,18111,8329,444,262825,16385,16813,19612,74795,17848,257,17597,1464,512]

theorem envBound5187 : H12AffineFastState.Bounded env5187 := by
  intro p hp
  have h : env5187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5186_5187 : H12AffineEnvironment.transform 14 26261 env5186 = env5187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5186 == env5187) = true)

theorem identity5187 : scanCanonicalize (H12AffineFastState.compose env5187 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound5187 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5188 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,25663,1296,262144,1025,26261,1212,18192,444,18111,8329,444,262825,16385,16813,19612,16404,17848,257,17597,1464,512]

theorem envBound5188 : H12AffineFastState.Bounded env5188 := by
  intro p hp
  have h : env5188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5187_5188 : H12AffineEnvironment.transform 15 25663 env5187 = env5188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env5187 == env5188) = true)

theorem identity5188 : scanCanonicalize (H12AffineFastState.compose env5188 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5188 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5189 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1044,8192,16384,26172,25663,1296,262144,1025,26172,1045,18192,277,17942,8224,277,262656,16385,16644,19509,16404,17681,257,17428,1297,512]

theorem envBound5189 : H12AffineFastState.Bounded env5189 := by
  intro p hp
  have h : env5189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5188_5189 : H12AffineEnvironment.transform 6 41 env5188 = env5189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5188 == env5189) = true)

def env5190 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16812,22560,74795,17849,257,20481,4239488,4241208]

theorem envBound5190 : H12AffineFastState.Bounded env5190 := by
  intro p hp
  have h : env5190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5183_5190 : H12AffineEnvironment.transform 5 17 env5183 = env5190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5183 == env5190) = true)

def env5191 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,4194304,4240517,41002,8329,4240516,323712,16385,16400,22560,74795,17413,189,20481,4239488,4241028]

end H12CloudChart0