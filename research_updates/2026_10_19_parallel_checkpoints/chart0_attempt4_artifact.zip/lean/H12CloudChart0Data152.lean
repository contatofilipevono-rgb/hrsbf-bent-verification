import H12CloudChart0Data151

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env38536 : List Nat := [2,4,8,16,32,16,9,256,512,1024,276,261,1288,16,276,1282,1,1077,1024,277,16,33,16,1299,1289,16,1297,1296,1044,1313,1284,32,256,1329,17,513]

theorem envBound38536 : H12AffineFastState.Bounded env38536 := by
  intro p hp
  have h : env38536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38535_38536 : H12AffineEnvironment.transform 10 276 env38535 = env38536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env38535 == env38536) = true)

theorem identity38536 : scanCanonicalize (H12AffineFastState.compose env38536 (packedSelected [1,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound38536 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env38537 : List Nat := [2,4,8,16,32,16,9,256,512,37,276,261,301,16,276,295,1,16,37,277,16,33,16,310,300,16,308,309,49,260,289,32,256,276,17,513]

theorem envBound38537 : H12AffineFastState.Bounded env38537 := by
  intro p hp
  have h : env38537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38536_38537 : H12AffineEnvironment.transform 9 37 env38536 = env38537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env38536 == env38537) = true)

theorem identity38537 : scanCanonicalize (H12AffineFastState.compose env38537 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38537 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38538 : List Nat := [2,4,8,16,32,16,9,4,512,37,16,1,41,16,16,35,1,16,37,17,16,33,16,50,40,16,48,49,49,0,37,32,4,16,17,513]

theorem envBound38538 : H12AffineFastState.Bounded env38538 := by
  intro p hp
  have h : env38538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38537_38538 : H12AffineEnvironment.transform 7 4 env38537 = env38538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38537 == env38538) = true)

theorem identity38538 : scanCanonicalize (H12AffineFastState.compose env38538 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound38538 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38539 : List Nat := [2,4,8,16,32,16,9,4,17,37,16,1,41,16,16,35,1,16,37,17,16,33,16,50,40,16,48,49,49,0,37,32,4,16,17,16]

theorem envBound38539 : H12AffineFastState.Bounded env38539 := by
  intro p hp
  have h : env38539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38538_38539 : H12AffineEnvironment.transform 8 17 env38538 = env38539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env38538 == env38539) = true)

theorem identity38539 : scanCanonicalize (H12AffineFastState.compose env38539 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38539 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38540 : List Nat := [2,4,8,16,17,16,9,4,17,20,16,1,24,16,16,18,1,16,20,17,16,16,16,3,25,16,1,0,0,0,20,17,4,16,17,16]

theorem envBound38540 : H12AffineFastState.Bounded env38540 := by
  intro p hp
  have h : env38540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38539_38540 : H12AffineEnvironment.transform 4 17 env38539 = env38540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38539 == env38540) = true)

def env38541 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8193,64,4677966,115015,45404,442385,75102,4268042,256,98678,90202,513]

theorem envBound38541 : H12AffineFastState.Bounded env38541 := by
  intro p hp
  have h : env38541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38504_38541 : H12AffineEnvironment.transform 20 58397 env38504 = env38541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env38504 == env38541) = true)

def env38542 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8193,16,4677918,114967,45324,442385,75022,4268042,256,98598,90122,513]

theorem envBound38542 : H12AffineFastState.Bounded env38542 := by
  intro p hp
  have h : env38542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38541_38542 : H12AffineEnvironment.transform 5 16 env38541 = env38542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38541 == env38542) = true)

def env38543 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41231,8193,16,4409654,114967,45324,190521,75022,4268042,256,98598,90122,513]

theorem envBound38543 : H12AffineFastState.Bounded env38543 := by
  intro p hp
  have h : env38543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38542_38543 : H12AffineEnvironment.transform 17 10280 env38542 = env38543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38542 == env38543) = true)

theorem identity38543 : scanCanonicalize (H12AffineFastState.compose env38543 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 65831) := by decide +kernel

theorem selectedBound38543 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env38544 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,65831,16,41231,8193,16,149521,114967,45324,190521,75022,8493,256,98598,90122,513]

theorem envBound38544 : H12AffineFastState.Bounded env38544 := by
  intro p hp
  have h : env38544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38543_38544 : H12AffineEnvironment.transform 21 65831 env38543 = env38544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65831 env38543 == env38544) = true)

theorem identity38544 : scanCanonicalize (H12AffineFastState.compose env38544 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound38544 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env38545 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1024,32769,58397,65831,16,41231,8193,16,108555,114967,45324,67619,75022,8493,256,98598,90122,513]

theorem envBound38545 : H12AffineFastState.Bounded env38545 := by
  intro p hp
  have h : env38545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38544_38545 : H12AffineEnvironment.transform 16 122906 env38544 = env38545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env38544 == env38545) = true)

theorem identity38545 : scanCanonicalize (H12AffineFastState.compose env38545 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound38545 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env38546 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10280,1024,32769,58397,41261,16,41231,8193,16,2049,24861,45324,43049,34052,8493,256,8492,49152,513]

theorem envBound38546 : H12AffineFastState.Bounded env38546 := by
  intro p hp
  have h : env38546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38545_38546 : H12AffineEnvironment.transform 15 40970 env38545 = env38546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env38545 == env38546) = true)

theorem identity38546 : scanCanonicalize (H12AffineFastState.compose env38546 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38546 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env38547 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,8203,16400,10280,1024,0,25628,8492,16,8462,8193,16,2049,24861,12557,10280,1285,8493,256,8492,16385,513]

theorem envBound38547 : H12AffineFastState.Bounded env38547 := by
  intro p hp
  have h : env38547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38546_38547 : H12AffineEnvironment.transform 14 1 env38546 = env38547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38546 == env38547) = true)

def env38548 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41231,8193,16,4409655,114967,45324,190520,75022,4268042,256,98598,90122,513]

theorem envBound38548 : H12AffineFastState.Bounded env38548 := by
  intro p hp
  have h : env38548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38542_38548 : H12AffineEnvironment.transform 17 10281 env38542 = env38548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38542 == env38548) = true)

theorem identity38548 : scanCanonicalize (H12AffineFastState.compose env38548 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 199939) := by decide +kernel

theorem selectedBound38548 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env38549 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,199939,16,41231,8193,16,17460,114967,45324,190520,75022,142601,256,98598,90122,513]

theorem envBound38549 : H12AffineFastState.Bounded env38549 := by
  intro p hp
  have h : env38549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38548_38549 : H12AffineEnvironment.transform 21 199939 env38548 = env38549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 199939 env38548 == env38549) = true)

theorem identity38549 : scanCanonicalize (H12AffineFastState.compose env38549 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound38549 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env38550 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,58397,27928,16,41231,8193,16,17460,114967,45324,100387,75022,85266,256,98598,90122,513]

theorem envBound38550 : H12AffineFastState.Bounded env38550 := by
  intro p hp
  have h : env38550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38549_38550 : H12AffineEnvironment.transform 16 90139 env38549 = env38550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env38549 == env38550) = true)

theorem identity38550 : scanCanonicalize (H12AffineFastState.compose env38550 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound38550 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env38551 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,3101,16384,32768,65536,84998,1076,1024,32769,51200,16645,16,36114,3100,16,17460,114967,40209,100387,67859,85266,256,98598,85015,513]

theorem envBound38551 : H12AffineFastState.Bounded env38551 := by
  intro p hp
  have h : env38551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38550_38551 : H12AffineEnvironment.transform 12 3101 env38550 = env38551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env38550 == env38551) = true)

theorem identity38551 : scanCanonicalize (H12AffineFastState.compose env38551 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 3094) := by decide +kernel

theorem selectedBound38551 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38552 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,3101,16384,32768,3094,16400,1076,1024,32769,51200,16645,16,36114,3100,16,17460,52481,40209,33845,1285,16644,256,36144,16385,513]

theorem envBound38552 : H12AffineFastState.Bounded env38552 := by
  intro p hp
  have h : env38552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38551_38552 : H12AffineEnvironment.transform 15 3094 env38551 = env38552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3094 env38551 == env38552) = true)

theorem identity38552 : scanCanonicalize (H12AffineFastState.compose env38552 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound38552 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38553 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,3101,4112,32768,3094,4096,1076,1024,32769,38928,4373,16,36114,3100,16,5156,40209,40209,33845,1285,4372,256,36144,4113,513]

theorem envBound38553 : H12AffineFastState.Bounded env38553 := by
  intro p hp
  have h : env38553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38552_38553 : H12AffineEnvironment.transform 13 4112 env38552 = env38553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env38552 == env38553) = true)

theorem identity38553 : scanCanonicalize (H12AffineFastState.compose env38553 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38553 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env38554 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,4096,1052,4112,32768,1047,4096,1076,1024,32769,36881,4373,16,34067,1053,16,5156,38160,38160,33845,1285,4372,256,34097,4113,513]

theorem envBound38554 : H12AffineFastState.Bounded env38554 := by
  intro p hp
  have h : env38554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38553_38554 : H12AffineEnvironment.transform 10 1 env38553 = env38554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38553 == env38554) = true)

theorem identity38554 : scanCanonicalize (H12AffineFastState.compose env38554 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound38554 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env38555 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,16,1052,0,32768,1047,16,1076,1024,32769,32769,261,16,34067,1053,16,1076,34048,34048,33845,1285,260,256,34097,1,513]

theorem envBound38555 : H12AffineFastState.Bounded env38555 := by
  intro p hp
  have h : env38555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38554_38555 : H12AffineEnvironment.transform 11 16 env38554 = env38555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env38554 == env38555) = true)

theorem identity38555 : scanCanonicalize (H12AffineFastState.compose env38555 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound38555 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38556 : List Nat := [2,4,8,16,32,16,9,256,292,1024,1,16,1052,0,32768,1047,16,1076,1024,32769,32769,261,16,34067,1053,16,1076,34048,34048,33845,1285,260,256,34097,1,293]

theorem envBound38556 : H12AffineFastState.Bounded env38556 := by
  intro p hp
  have h : env38556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38555_38556 : H12AffineEnvironment.transform 8 292 env38555 = env38556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env38555 == env38556) = true)

theorem identity38556 : scanCanonicalize (H12AffineFastState.compose env38556 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 1061) := by decide +kernel

theorem selectedBound38556 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env38557 : List Nat := [2,4,8,16,32,16,9,256,292,1024,1,16,1052,0,1061,1047,16,1076,1024,1060,1060,261,16,310,1053,16,1076,293,293,16,1285,260,256,276,1,293]

theorem envBound38557 : H12AffineFastState.Bounded env38557 := by
  intro p hp
  have h : env38557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38556_38557 : H12AffineEnvironment.transform 14 1061 env38556 = env38557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1061 env38556 == env38557) = true)

theorem identity38557 : scanCanonicalize (H12AffineFastState.compose env38557 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound38557 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38558 : List Nat := [2,4,8,16,32,16,9,256,292,256,1,16,284,0,293,279,16,308,256,292,292,261,16,310,285,16,308,293,293,16,5,260,256,276,1,293]

theorem envBound38558 : H12AffineFastState.Bounded env38558 := by
  intro p hp
  have h : env38558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38557_38558 : H12AffineEnvironment.transform 9 256 env38557 = env38558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env38557 == env38558) = true)

theorem identity38558 : scanCanonicalize (H12AffineFastState.compose env38558 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38558 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38559 : List Nat := [2,4,8,16,16,16,9,256,276,256,1,16,284,0,277,279,16,260,256,276,276,261,16,262,285,16,260,277,277,16,5,260,256,276,1,277]

theorem envBound38559 : H12AffineFastState.Bounded env38559 := by
  intro p hp
  have h : env38559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38558_38559 : H12AffineEnvironment.transform 4 16 env38558 = env38559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38558 == env38559) = true)

def env38560 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8193,17,4677919,114966,45325,442385,75023,4268042,256,98599,90123,513]

theorem envBound38560 : H12AffineFastState.Bounded env38560 := by
  intro p hp
  have h : env38560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38541_38560 : H12AffineEnvironment.transform 5 17 env38541 = env38560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38541 == env38560) = true)

theorem identity38560 : scanCanonicalize (H12AffineFastState.compose env38560 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38560 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env38561 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41230,8193,17,4409655,114966,45325,190521,75023,4268042,256,98599,90123,513]

theorem envBound38561 : H12AffineFastState.Bounded env38561 := by
  intro p hp
  have h : env38561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38560_38561 : H12AffineEnvironment.transform 17 10280 env38560 = env38561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38560 == env38561) = true)

theorem identity38561 : scanCanonicalize (H12AffineFastState.compose env38561 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound38561 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env38562 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,4194304,16,41230,8193,17,4204844,114966,45325,100386,75023,4268042,256,98599,90123,513]

theorem envBound38562 : H12AffineFastState.Bounded env38562 := by
  intro p hp
  have h : env38562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38561_38562 : H12AffineEnvironment.transform 16 90139 env38561 = env38562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env38561 == env38562) = true)

theorem identity38562 : scanCanonicalize (H12AffineFastState.compose env38562 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound38562 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env38563 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,32,16,41230,8193,17,10508,114966,45325,100386,75023,73770,256,98599,90123,513]

theorem envBound38563 : H12AffineFastState.Bounded env38563 := by
  intro p hp
  have h : env38563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38562_38563 : H12AffineEnvironment.transform 21 32 env38562 = env38563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env38562 == env38563) = true)

theorem identity38563 : scanCanonicalize (H12AffineFastState.compose env38563 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38563 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env38564 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,65536,90139,10280,1024,1,25629,32,16,8462,8193,17,10508,82198,12557,67618,75023,73770,256,65831,90123,513]

theorem envBound38564 : H12AffineFastState.Bounded env38564 := by
  intro p hp
  have h : env38564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38563_38564 : H12AffineEnvironment.transform 14 0 env38563 = env38564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38563 == env38564) = true)

theorem identity38564 : scanCanonicalize (H12AffineFastState.compose env38564 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38564 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38565 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,8203,16400,10280,1024,1,25629,32,16,8462,8193,17,10508,24861,12557,10281,1284,33,256,8492,16384,513]

theorem envBound38565 : H12AffineFastState.Bounded env38565 := by
  intro p hp
  have h : env38565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38564_38565 : H12AffineEnvironment.transform 15 8203 env38564 = env38565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38564 == env38565) = true)

theorem identity38565 : scanCanonicalize (H12AffineFastState.compose env38565 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound38565 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env38566 : List Nat := [2,4,8,16,32,17,9,256,512,1024,528,4096,8192,16384,0,8203,16400,8760,1024,1,25629,32,16,8462,8193,17,8988,24861,12557,8761,1284,33,256,8492,16384,513]

theorem envBound38566 : H12AffineFastState.Bounded env38566 := by
  intro p hp
  have h : env38566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38565_38566 : H12AffineEnvironment.transform 10 528 env38565 = env38566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env38565 == env38566) = true)

theorem identity38566 : scanCanonicalize (H12AffineFastState.compose env38566 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 8460) := by decide +kernel

theorem selectedBound38566 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env38567 : List Nat := [2,4,8,16,32,17,9,256,512,1024,528,4096,8192,8460,0,8203,8476,8760,1024,1,1297,32,16,8462,8193,17,8988,17,12557,8761,1284,33,256,8492,8460,513]

theorem envBound38567 : H12AffineFastState.Bounded env38567 := by
  intro p hp
  have h : env38567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38566_38567 : H12AffineEnvironment.transform 13 8460 env38566 = env38567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8460 env38566 == env38567) = true)

theorem identity38567 : scanCanonicalize (H12AffineFastState.compose env38567 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 1320) := by decide +kernel

theorem selectedBound38567 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env38568 : List Nat := [2,4,8,16,32,17,9,256,512,1024,528,4096,1320,1060,0,1315,1076,1808,1024,1,1297,32,16,1062,1321,17,1588,17,5157,1809,1284,33,256,1028,1060,513]

theorem envBound38568 : H12AffineFastState.Bounded env38568 := by
  intro p hp
  have h : env38568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38567_38568 : H12AffineEnvironment.transform 12 1320 env38567 = env38568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1320 env38567 == env38568) = true)

theorem identity38568 : scanCanonicalize (H12AffineFastState.compose env38568 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound38568 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env38569 : List Nat := [2,4,8,16,32,17,9,256,512,36,528,4096,268,0,0,263,16,820,36,1,309,32,16,2,269,17,528,17,4097,821,288,33,256,32,0,513]

theorem envBound38569 : H12AffineFastState.Bounded env38569 := by
  intro p hp
  have h : env38569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38568_38569 : H12AffineEnvironment.transform 9 36 env38568 = env38569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env38568 == env38569) = true)

theorem identity38569 : scanCanonicalize (H12AffineFastState.compose env38569 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound38569 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38570 : List Nat := [2,4,8,16,32,17,9,256,512,36,528,17,268,0,0,263,16,820,36,1,309,32,16,2,269,17,528,17,16,821,288,33,256,32,0,513]

theorem envBound38570 : H12AffineFastState.Bounded env38570 := by
  intro p hp
  have h : env38570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38569_38570 : H12AffineEnvironment.transform 11 17 env38569 = env38570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env38569 == env38570) = true)

theorem identity38570 : scanCanonicalize (H12AffineFastState.compose env38570 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound38570 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38571 : List Nat := [2,4,8,16,32,17,9,256,292,36,308,17,268,0,0,263,16,16,36,1,309,32,16,2,269,17,308,17,16,17,288,33,256,32,0,293]

theorem envBound38571 : H12AffineFastState.Bounded env38571 := by
  intro p hp
  have h : env38571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38570_38571 : H12AffineEnvironment.transform 8 292 env38570 = env38571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env38570 == env38571) = true)

theorem identity38571 : scanCanonicalize (H12AffineFastState.compose env38571 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound38571 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38572 : List Nat := [2,4,8,16,27,17,9,256,287,31,271,17,268,0,0,263,16,16,31,1,270,27,16,2,269,17,271,17,16,17,283,26,256,27,0,286]

theorem envBound38572 : H12AffineFastState.Bounded env38572 := by
  intro p hp
  have h : env38572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38571_38572 : H12AffineEnvironment.transform 4 27 env38571 = env38572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env38571 == env38572) = true)

theorem identity38572 : scanCanonicalize (H12AffineFastState.compose env38572 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound38572 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38573 : List Nat := [2,4,8,16,27,17,9,15,16,31,0,17,3,0,0,8,16,16,31,1,1,27,16,2,2,17,0,17,16,17,20,26,15,27,0,17]

theorem envBound38573 : H12AffineFastState.Bounded env38573 := by
  intro p hp
  have h : env38573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38572_38573 : H12AffineEnvironment.transform 7 15 env38572 = env38573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env38572 == env38573) = true)

def env38574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41310,8193,64,4677966,2172251,2118976,442384,75102,6407190,256,2188651,2196551,513]

theorem envBound38574 : H12AffineFastState.Bounded env38574 := by
  intro p hp
  have h : env38574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38503_38574 : H12AffineEnvironment.transform 22 17 env38503 = env38574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env38503 == env38574) = true)

theorem identity38574 : scanCanonicalize (H12AffineFastState.compose env38574 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound38574 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38575 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,41310,8193,64,4456789,2172251,2118976,368651,75102,6407190,256,2188651,2196551,513]

theorem envBound38575 : H12AffineFastState.Bounded env38575 := by
  intro p hp
  have h : env38575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38574_38575 : H12AffineEnvironment.transform 16 90139 env38574 = env38575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env38574 == env38575) = true)

theorem identity38575 : scanCanonicalize (H12AffineFastState.compose env38575 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound38575 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38576 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,262144,1024,32769,2097152,4194304,17,41310,8193,64,4456789,2139149,2118976,270685,41992,6309184,256,2155581,2098449,513]

theorem envBound38576 : H12AffineFastState.Bounded env38576 := by
  intro p hp
  have h : env38576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38575_38576 : H12AffineEnvironment.transform 15 33110 env38575 = env38576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env38575 == env38576) = true)

theorem identity38576 : scanCanonicalize (H12AffineFastState.compose env38576 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38576 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env38577 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,2097152,4194304,17,41310,8193,64,4204925,2139149,2118976,2421,41992,6309184,256,2155581,2098449,513]

theorem envBound38577 : H12AffineFastState.Bounded env38577 := by
  intro p hp
  have h : env38577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38576_38577 : H12AffineEnvironment.transform 17 10280 env38576 = env38577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38576 == env38577) = true)

theorem identity38577 : scanCanonicalize (H12AffineFastState.compose env38577 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound38577 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env38578 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,2097152,32,17,41310,8193,64,10589,2139149,2118976,2421,41992,2114912,256,2155581,2098449,513]

theorem envBound38578 : H12AffineFastState.Bounded env38578 := by
  intro p hp
  have h : env38578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38577_38578 : H12AffineEnvironment.transform 21 32 env38577 = env38578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env38577 == env38578) = true)

theorem identity38578 : scanCanonicalize (H12AffineFastState.compose env38578 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound38578 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,25629,32,17,41310,8193,64,10589,49168,12637,2421,41992,8573,256,32800,24844,513]

theorem envBound38579 : H12AffineFastState.Bounded env38579 := by
  intro p hp
  have h : env38579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38578_38579 : H12AffineEnvironment.transform 20 25629 env38578 = env38579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env38578 == env38579) = true)

theorem identity38579 : scanCanonicalize (H12AffineFastState.compose env38579 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38579 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,343,24908,10280,1024,0,25629,32,17,8543,8193,64,10589,16401,12637,2421,9225,8573,256,33,24844,513]

theorem envBound38580 : H12AffineFastState.Bounded env38580 := by
  intro p hp
  have h : env38580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38579_38580 : H12AffineEnvironment.transform 14 1 env38579 = env38580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38579 == env38580) = true)

theorem identity38580 : scanCanonicalize (H12AffineFastState.compose env38580 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38580 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,343,16401,2421,1024,0,17728,32,17,2,348,64,2048,16401,4096,2421,1364,32,256,33,16465,513]

theorem envBound38581 : H12AffineFastState.Bounded env38581 := by
  intro p hp
  have h : env38581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38580_38581 : H12AffineEnvironment.transform 12 349 env38580 = env38581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38580 == env38581) = true)

theorem identity38581 : scanCanonicalize (H12AffineFastState.compose env38581 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5749) := by decide +kernel

theorem selectedBound38581 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5749,1,343,5732,2421,1024,0,4917,32,17,2,348,64,2048,5732,4096,2421,1364,32,256,33,5668,513]

theorem envBound38582 : H12AffineFastState.Bounded env38582 := by
  intro p hp
  have h : env38582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38581_38582 : H12AffineEnvironment.transform 13 5749 env38581 = env38582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5749 env38581 == env38582) = true)

def env38583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound38583 : H12AffineFastState.Bounded env38583 := by
  intro p hp
  have h : env38583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38466_38583 : H12AffineEnvironment.transform 18 1025 env38466 = env38583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env38466 == env38583) = true)

theorem identity38583 : scanCanonicalize (H12AffineFastState.compose env38583 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound38583 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29655367,18973837,10507601,8749383,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound38584 : H12AffineFastState.Bounded env38584 := by
  intro p hp
  have h : env38584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38583_38584 : H12AffineEnvironment.transform 16 82247 env38583 = env38584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env38583 == env38584) = true)

def env38585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6623435,8393985,10507601,8749383,2102685,12645453,257,21792,46212,2175562]

theorem envBound38585 : H12AffineFastState.Bounded env38585 := by
  intro p hp
  have h : env38585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38584_38585 : H12AffineEnvironment.transform 23 10588556 env38584 = env38585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env38584 == env38585) = true)

def env38586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6623435,2098513,17665,2461975,2102685,6349853,257,21792,46212,2175562]

theorem envBound38586 : H12AffineFastState.Bounded env38586 := by
  intro p hp
  have h : env38586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38585_38586 : H12AffineEnvironment.transform 22 2101328 env38585 = env38586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env38585 == env38586) = true)

def env38587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2177099,2098513,17665,2461975,2102685,2411677,257,21792,46212,2175562]

theorem envBound38587 : H12AffineFastState.Bounded env38587 := by
  intro p hp
  have h : env38587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38586_38587 : H12AffineEnvironment.transform 21 272512 env38586 = env38587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38586 == env38587) = true)

theorem identity38587 : scanCanonicalize (H12AffineFastState.compose env38587 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound38587 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,272512,17,98780,8328,64,75786,5392,17665,360790,1500,318684,257,21792,46212,74251]

theorem envBound38588 : H12AffineFastState.Bounded env38588 := by
  intro p hp
  have h : env38588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38587_38588 : H12AffineEnvironment.transform 20 4161 env38587 = env38588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38587 == env38588) = true)

theorem identity38588 : scanCanonicalize (H12AffineFastState.compose env38588 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38588 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env38589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,262144,1025,32769,4161,272512,17,41430,8328,64,2048,5392,17665,303452,1500,318684,257,21792,46212,513]

theorem envBound38589 : H12AffineFastState.Bounded env38589 := by
  intro p hp
  have h : env38589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38588_38589 : H12AffineEnvironment.transform 15 8202 env38588 = env38589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38588 == env38589) = true)

theorem identity38589 : scanCanonicalize (H12AffineFastState.compose env38589 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound38589 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env38590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,35324,1025,32769,4161,41340,17,41430,8328,64,2048,5392,17665,10400,1500,21792,257,21792,46212,513]

theorem envBound38590 : H12AffineFastState.Bounded env38590 := by
  intro p hp
  have h : env38590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38589_38590 : H12AffineEnvironment.transform 17 35324 env38589 = env38590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env38589 == env38590) = true)

theorem identity38590 : scanCanonicalize (H12AffineFastState.compose env38590 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38590 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16400,35324,1025,32769,4161,32801,17,32907,469,64,2048,5392,17665,2557,1500,21792,257,21792,38361,513]

theorem envBound38591 : H12AffineFastState.Bounded env38591 := by
  intro p hp
  have h : env38591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38590_38591 : H12AffineEnvironment.transform 12 349 env38590 = env38591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38590 == env38591) = true)

theorem identity38591 : scanCanonicalize (H12AffineFastState.compose env38591 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38591 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,32768,343,5392,35324,1025,32769,4161,32801,17,32907,469,64,2048,5392,4097,2557,1500,32,257,32,38361,513]

theorem envBound38592 : H12AffineFastState.Bounded env38592 := by
  intro p hp
  have h : env38592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38591_38592 : H12AffineEnvironment.transform 13 5376 env38591 = env38592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38591 == env38592) = true)

theorem identity38592 : scanCanonicalize (H12AffineFastState.compose env38592 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 509) := by decide +kernel

theorem selectedBound38592 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env38593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,509,343,5392,2049,1025,508,4161,476,17,374,469,64,2048,5392,4097,2557,1500,32,257,32,5156,513]

theorem envBound38593 : H12AffineFastState.Bounded env38593 := by
  intro p hp
  have h : env38593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38592_38593 : H12AffineEnvironment.transform 14 509 env38592 = env38593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 509 env38592 == env38593) = true)

theorem identity38593 : scanCanonicalize (H12AffineFastState.compose env38593 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound38593 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38594 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,5372,1,171,5356,2049,1025,0,4161,32,17,138,41,64,2048,5356,4097,2049,1056,32,253,32,5156,513]

theorem envBound38594 : H12AffineFastState.Bounded env38594 := by
  intro p hp
  have h : env38594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38593_38594 : H12AffineEnvironment.transform 7 252 env38593 = env38594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env38593 == env38594) = true)

theorem identity38594 : scanCanonicalize (H12AffineFastState.compose env38594 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound38594 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38595 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,0,161,1276,1,171,1260,2049,1025,0,65,32,17,138,41,64,2048,1260,1,2049,1056,32,253,32,1060,513]

theorem envBound38595 : H12AffineFastState.Bounded env38595 := by
  intro p hp
  have h : env38595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38594_38595 : H12AffineEnvironment.transform 11 0 env38594 = env38595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38594 == env38595) = true)

theorem identity38595 : scanCanonicalize (H12AffineFastState.compose env38595 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound38595 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38596 : List Nat := [2,4,8,16,32,64,128,252,512,1024,217,0,161,1276,1,171,1260,216,1025,0,65,32,17,138,41,64,217,1260,1,216,1056,32,253,32,1060,513]

theorem envBound38596 : H12AffineFastState.Bounded env38596 := by
  intro p hp
  have h : env38596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38595_38596 : H12AffineEnvironment.transform 10 217 env38595 = env38596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env38595 == env38596) = true)

theorem identity38596 : scanCanonicalize (H12AffineFastState.compose env38596 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound38596 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env38597 : List Nat := [2,4,8,16,32,64,128,252,512,62,217,0,161,194,1,171,210,216,63,0,65,32,17,138,41,64,217,210,1,216,30,32,253,32,26,513]

theorem envBound38597 : H12AffineFastState.Bounded env38597 := by
  intro p hp
  have h : env38597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38596_38597 : H12AffineEnvironment.transform 9 62 env38596 = env38597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env38596 == env38597) = true)

theorem identity38597 : scanCanonicalize (H12AffineFastState.compose env38597 (packedSelected [1,2,3,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound38597 : packedSelected [1,2,3,11,12] rootPS < 2^1333 := by decide +kernel

def env38598 : List Nat := [2,4,8,16,32,64,88,36,512,62,1,0,121,26,1,115,10,0,63,0,65,32,17,82,41,64,1,10,1,0,30,32,37,32,26,513]

theorem envBound38598 : H12AffineFastState.Bounded env38598 := by
  intro p hp
  have h : env38598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38597_38598 : H12AffineEnvironment.transform 6 88 env38597 = env38598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env38597 == env38598) = true)

theorem identity38598 : scanCanonicalize (H12AffineFastState.compose env38598 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound38598 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38599 : List Nat := [2,4,8,16,32,0,24,36,512,62,1,0,57,26,1,51,10,0,63,0,1,32,17,18,41,0,1,10,1,0,30,32,37,32,26,513]

theorem envBound38599 : H12AffineFastState.Bounded env38599 := by
  intro p hp
  have h : env38599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38598_38599 : H12AffineEnvironment.transform 5 0 env38598 = env38599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38598 == env38599) = true)

theorem identity38599 : scanCanonicalize (H12AffineFastState.compose env38599 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38599 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env38600 : List Nat := [2,4,8,16,17,0,24,21,512,15,1,0,8,26,1,2,10,0,14,0,1,17,17,18,24,0,1,10,1,0,30,17,20,17,26,513]

theorem envBound38600 : H12AffineFastState.Bounded env38600 := by
  intro p hp
  have h : env38600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38599_38600 : H12AffineEnvironment.transform 4 17 env38599 = env38600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38599 == env38600) = true)

theorem identity38600 : scanCanonicalize (H12AffineFastState.compose env38600 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38600 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38601 : List Nat := [2,4,8,11,10,0,3,14,512,15,1,0,8,1,1,2,10,0,14,0,1,10,10,9,3,0,1,10,1,0,5,10,15,10,1,513]

theorem envBound38601 : H12AffineFastState.Bounded env38601 := by
  intro p hp
  have h : env38601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38600_38601 : H12AffineEnvironment.transform 3 11 env38600 = env38601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38600 == env38601) = true)

theorem identity38601 : scanCanonicalize (H12AffineFastState.compose env38601 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38601 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38602 : List Nat := [1,4,8,8,9,0,0,13,512,12,1,0,8,1,1,1,9,0,13,0,1,9,9,9,0,0,1,9,1,0,5,9,12,9,1,513]

theorem envBound38602 : H12AffineFastState.Bounded env38602 := by
  intro p hp
  have h : env38602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38601_38602 : H12AffineEnvironment.transform 0 1 env38601 = env38602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38601 == env38602) = true)

theorem identity38602 : scanCanonicalize (H12AffineFastState.compose env38602 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound38602 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38603 : List Nat := [1,4,0,0,1,0,0,5,512,4,1,0,0,1,1,1,1,0,5,0,1,1,1,1,0,0,1,1,1,0,5,1,4,1,1,513]

theorem envBound38603 : H12AffineFastState.Bounded env38603 := by
  intro p hp
  have h : env38603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38602_38603 : H12AffineEnvironment.transform 2 0 env38602 = env38603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env38602 == env38603) = true)

theorem identity38603 : scanCanonicalize (H12AffineFastState.compose env38603 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound38603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38604 : List Nat := [1,4,0,0,1,0,0,5,4,4,1,0,0,1,1,1,1,0,5,0,1,1,1,1,0,0,1,1,1,0,5,1,4,1,1,5]

theorem envBound38604 : H12AffineFastState.Bounded env38604 := by
  intro p hp
  have h : env38604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38603_38604 : H12AffineEnvironment.transform 8 4 env38603 = env38604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env38603 == env38604) = true)

def env38605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2177098,2098513,17665,2461975,2102685,2411676,257,21792,46212,2175562]

theorem envBound38605 : H12AffineFastState.Bounded env38605 := by
  intro p hp
  have h : env38605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38586_38605 : H12AffineEnvironment.transform 21 272513 env38586 = env38605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38586 == env38605) = true)

def env38606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272393,2101328,98644,8192,64,2177098,2098513,17665,2461975,2102549,2411540,257,21792,46092,2175562]

theorem envBound38606 : H12AffineFastState.Bounded env38606 := by
  intro p hp
  have h : env38606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38605_38606 : H12AffineEnvironment.transform 6 8 env38605 = env38606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38605 == env38606) = true)

def env38607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4160,272393,16,98644,8192,64,75786,5393,17665,360791,1365,318548,257,21792,46092,74250]

theorem envBound38607 : H12AffineFastState.Bounded env38607 := by
  intro p hp
  have h : env38607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38606_38607 : H12AffineEnvironment.transform 20 4160 env38606 = env38607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38606 == env38607) = true)

theorem identity38607 : scanCanonicalize (H12AffineFastState.compose env38607 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound38607 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env38608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,56357,1025,32769,4160,62508,16,98644,8192,64,75786,5393,17665,89458,1365,113,257,21792,46092,74250]

theorem envBound38608 : H12AffineFastState.Bounded env38608 := by
  intro p hp
  have h : env38608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38607_38608 : H12AffineEnvironment.transform 17 56357 env38607 = env38608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env38607 == env38608) = true)

theorem identity38608 : scanCanonicalize (H12AffineFastState.compose env38608 (packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound38608 : packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62811,46108,56357,1025,32769,4160,62508,16,29711,8192,64,56657,5393,17665,43049,1365,113,257,21792,46092,55121]

theorem envBound38609 : H12AffineFastState.Bounded env38609 := by
  intro p hp
  have h : env38609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38608_38609 : H12AffineEnvironment.transform 15 62811 env38608 = env38609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env38608 == env38609) = true)

theorem identity38609 : scanCanonicalize (H12AffineFastState.compose env38609 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound38609 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env38610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,8203,24908,2421,1025,21841,4160,8572,16,29711,8192,64,2049,5393,17665,32121,1365,113,257,21792,24924,513]

theorem envBound38610 : H12AffineFastState.Bounded env38610 := by
  intro p hp
  have h : env38610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38609_38610 : H12AffineEnvironment.transform 14 21840 env38609 = env38610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env38609 == env38610) = true)

theorem identity38610 : scanCanonicalize (H12AffineFastState.compose env38610 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38610 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21840,343,16400,2421,1025,21841,4160,32,16,21843,348,64,2049,5393,17665,23589,1365,113,257,21792,16384,513]

theorem envBound38611 : H12AffineFastState.Bounded env38611 := by
  intro p hp
  have h : env38611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38610_38611 : H12AffineEnvironment.transform 12 348 env38610 = env38611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38610 == env38611) = true)

theorem identity38611 : scanCanonicalize (H12AffineFastState.compose env38611 (packedSelected [3,4,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 3172) := by decide +kernel

theorem selectedBound38611 : packedSelected [3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env38612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,3172,6452,343,3188,2421,1025,6453,4160,32,16,6455,348,64,2049,5393,2405,4161,1365,113,257,6468,3172,513]

theorem envBound38612 : H12AffineFastState.Bounded env38612 := by
  intro p hp
  have h : env38612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38611_38612 : H12AffineEnvironment.transform 13 3172 env38611 = env38612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3172 env38611 == env38612) = true)

theorem identity38612 : scanCanonicalize (H12AffineFastState.compose env38612 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38612 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38613 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,348,2129,6452,343,2113,2421,52,6453,4160,32,16,6455,348,64,2049,4388,2405,4161,352,113,257,6468,2129,513]

theorem envBound38613 : H12AffineFastState.Bounded env38613 := by
  intro p hp
  have h : env38613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38612_38613 : H12AffineEnvironment.transform 9 53 env38612 = env38613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38612 == env38613) = true)

theorem identity38613 : scanCanonicalize (H12AffineFastState.compose env38613 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38613 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38614 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,41,2129,6209,34,2113,2048,52,6208,4160,32,16,6210,41,64,2049,4177,2064,4161,21,113,116,6193,2129,513]

theorem envBound38614 : H12AffineFastState.Bounded env38614 := by
  intro p hp
  have h : env38614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38613_38614 : H12AffineEnvironment.transform 7 117 env38613 = env38614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38613 == env38614) = true)

theorem identity38614 : scanCanonicalize (H12AffineFastState.compose env38614 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound38614 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38615 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,64,41,2129,2049,34,2113,2048,52,2048,0,32,16,2050,41,64,2049,17,2064,1,21,113,116,2161,2129,513]

theorem envBound38615 : H12AffineFastState.Bounded env38615 := by
  intro p hp
  have h : env38615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38614_38615 : H12AffineEnvironment.transform 11 64 env38614 = env38615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env38614 == env38615) = true)

theorem identity38615 : scanCanonicalize (H12AffineFastState.compose env38615 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38615 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38616 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,16,41,2049,2049,34,2065,2048,52,2048,0,32,16,2050,41,16,2049,17,2064,1,21,33,36,2081,2049,513]

theorem envBound38616 : H12AffineFastState.Bounded env38616 := by
  intro p hp
  have h : env38616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38615_38616 : H12AffineEnvironment.transform 5 16 env38615 = env38616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38615 == env38616) = true)

theorem identity38616 : scanCanonicalize (H12AffineFastState.compose env38616 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38617 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,16,41,0,0,34,16,1,52,1,0,32,16,3,41,16,0,17,17,1,21,33,36,32,0,513]

theorem envBound38617 : H12AffineFastState.Bounded env38617 := by
  intro p hp
  have h : env38617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38616_38617 : H12AffineEnvironment.transform 10 1 env38616 = env38617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38616 == env38617) = true)

theorem identity38617 : scanCanonicalize (H12AffineFastState.compose env38617 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound38617 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38618 : List Nat := [2,4,8,16,32,16,8,37,17,53,1,16,41,0,0,34,16,1,52,1,0,32,16,3,41,16,0,17,17,1,21,33,36,32,0,16]

theorem envBound38618 : H12AffineFastState.Bounded env38618 := by
  intro p hp
  have h : env38618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38617_38618 : H12AffineEnvironment.transform 8 17 env38617 = env38618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env38617 == env38618) = true)

theorem identity38618 : scanCanonicalize (H12AffineFastState.compose env38618 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38619 : List Nat := [2,4,8,10,32,10,8,37,11,47,1,10,41,0,0,34,10,1,46,1,0,32,10,3,41,10,0,11,11,1,15,33,36,32,0,10]

theorem envBound38619 : H12AffineFastState.Bounded env38619 := by
  intro p hp
  have h : env38619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38618_38619 : H12AffineEnvironment.transform 3 10 env38618 = env38619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38618 == env38619) = true)

def env38620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4161,272393,17,98644,8192,64,75787,5392,17665,360790,1364,318549,257,21792,46092,74251]

theorem envBound38620 : H12AffineFastState.Bounded env38620 := by
  intro p hp
  have h : env38620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38606_38620 : H12AffineEnvironment.transform 20 4161 env38606 = env38620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38606 == env38620) = true)

theorem identity38620 : scanCanonicalize (H12AffineFastState.compose env38620 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound38620 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,4161,33,17,98644,8192,64,75787,5392,17665,108926,1364,62589,257,21792,46092,74251]

theorem envBound38621 : H12AffineFastState.Bounded env38621 := by
  intro p hp
  have h : env38621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38620_38621 : H12AffineEnvironment.transform 17 10280 env38620 = env38621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38620 == env38621) = true)

theorem identity38621 : scanCanonicalize (H12AffineFastState.compose env38621 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38621 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env38622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,82247,2420,1025,32769,4161,33,17,98644,348,64,67927,5392,17665,100386,1364,54561,257,21792,38224,66391]

theorem envBound38622 : H12AffineFastState.Bounded env38622 := by
  intro p hp
  have h : env38622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38621_38622 : H12AffineEnvironment.transform 12 348 env38621 = env38622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38621 == env38622) = true)

theorem identity38622 : scanCanonicalize (H12AffineFastState.compose env38622 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound38622 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,16401,2420,1025,32769,4161,33,17,32770,348,64,2049,5392,17665,35188,1364,54561,257,21792,38224,513]

theorem envBound38623 : H12AffineFastState.Bounded env38623 := by
  intro p hp
  have h : env38623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38622_38623 : H12AffineEnvironment.transform 15 342 env38622 = env38623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env38622 == env38623) = true)

theorem identity38623 : scanCanonicalize (H12AffineFastState.compose env38623 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound38623 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,342,16401,2420,1025,21761,4161,33,17,21762,348,64,2049,5392,17665,23668,1364,33,257,21792,16464,513]

theorem envBound38624 : H12AffineFastState.Bounded env38624 := by
  intro p hp
  have h : env38624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38623_38624 : H12AffineEnvironment.transform 14 21760 env38623 = env38624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env38623 == env38624) = true)

theorem identity38624 : scanCanonicalize (H12AffineFastState.compose env38624 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38624 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env38625 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,262,16401,2340,1025,21761,4113,33,17,21762,268,16,2049,5392,17665,23588,1284,33,257,21792,16384,513]

theorem envBound38625 : H12AffineFastState.Bounded env38625 := by
  intro p hp
  have h : env38625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38624_38625 : H12AffineEnvironment.transform 5 16 env38624 = env38625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38624 == env38625) = true)

theorem identity38625 : scanCanonicalize (H12AffineFastState.compose env38625 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 5685) := by decide +kernel

theorem selectedBound38625 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38626 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5685,821,262,5668,2340,1025,820,4113,33,17,823,268,16,2049,5392,4916,2577,1284,33,257,789,5685,513]

theorem envBound38626 : H12AffineFastState.Bounded env38626 := by
  intro p hp
  have h : env38626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38625_38626 : H12AffineEnvironment.transform 13 5685 env38625 = env38626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5685 env38625 == env38626) = true)

theorem identity38626 : scanCanonicalize (H12AffineFastState.compose env38626 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3889) := by decide +kernel

theorem selectedBound38626 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env38627 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,268,2308,821,262,2325,2340,1025,820,3872,33,17,823,268,16,2049,2593,3077,2577,1284,33,257,789,2308,513]

theorem envBound38627 : H12AffineFastState.Bounded env38627 := by
  intro p hp
  have h : env38627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38626_38627 : H12AffineEnvironment.transform 11 3889 env38626 = env38627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env38626 == env38627) = true)

theorem identity38627 : scanCanonicalize (H12AffineFastState.compose env38627 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound38627 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env38628 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1029,820,268,1281,821,262,1296,1313,1025,820,805,33,17,823,268,16,1028,1572,0,1556,1284,33,257,789,1281,513]

theorem envBound38628 : H12AffineFastState.Bounded env38628 := by
  intro p hp
  have h : env38628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38627_38628 : H12AffineEnvironment.transform 10 1029 env38627 = env38628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env38627 == env38628) = true)

theorem identity38628 : scanCanonicalize (H12AffineFastState.compose env38628 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound38628 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env38629 : List Nat := [2,4,8,16,32,16,8,256,309,1024,1029,1,268,1281,0,262,1296,1313,1025,1,16,33,17,2,268,16,1028,1297,0,1313,1284,33,257,32,1281,308]

theorem envBound38629 : H12AffineFastState.Bounded env38629 := by
  intro p hp
  have h : env38629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38628_38629 : H12AffineEnvironment.transform 8 309 env38628 = env38629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env38628 == env38629) = true)

theorem identity38629 : scanCanonicalize (H12AffineFastState.compose env38629 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound38629 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38630 : List Nat := [2,4,8,16,32,16,8,21,32,1024,1029,1,25,1044,0,19,1029,1076,1025,1,16,33,17,2,25,16,1028,1028,0,1076,1041,33,20,32,1044,33]

theorem envBound38630 : H12AffineFastState.Bounded env38630 := by
  intro p hp
  have h : env38630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38629_38630 : H12AffineEnvironment.transform 7 21 env38629 = env38630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env38629 == env38630) = true)

theorem identity38630 : scanCanonicalize (H12AffineFastState.compose env38630 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound38630 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38631 : List Nat := [2,4,8,16,32,16,8,21,32,21,16,1,25,1,0,19,16,33,20,1,16,33,17,2,25,16,17,17,0,33,4,33,20,32,1,33]

theorem envBound38631 : H12AffineFastState.Bounded env38631 := by
  intro p hp
  have h : env38631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38630_38631 : H12AffineEnvironment.transform 9 21 env38630 = env38631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38630 == env38631) = true)

theorem identity38631 : scanCanonicalize (H12AffineFastState.compose env38631 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38631 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38632 : List Nat := [2,4,8,0,32,0,8,5,32,5,0,1,9,1,0,3,0,33,4,1,0,33,1,2,9,0,1,1,0,33,4,33,4,32,1,33]

theorem envBound38632 : H12AffineFastState.Bounded env38632 := by
  intro p hp
  have h : env38632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38631_38632 : H12AffineEnvironment.transform 3 0 env38631 = env38632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38631 == env38632) = true)

theorem identity38632 : scanCanonicalize (H12AffineFastState.compose env38632 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38632 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38633 : List Nat := [2,4,3,0,32,0,3,5,32,5,0,1,2,1,0,3,0,33,4,1,0,33,1,2,2,0,1,1,0,33,4,33,4,32,1,33]

theorem envBound38633 : H12AffineFastState.Bounded env38633 := by
  intro p hp
  have h : env38633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38632_38633 : H12AffineEnvironment.transform 2 3 env38632 = env38633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38632 == env38633) = true)

theorem identity38633 : scanCanonicalize (H12AffineFastState.compose env38633 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38633 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38634 : List Nat := [2,4,3,0,1,0,3,5,1,5,0,1,2,1,0,3,0,0,4,1,0,0,1,2,2,0,1,1,0,0,4,0,4,1,1,0]

theorem envBound38634 : H12AffineFastState.Bounded env38634 := by
  intro p hp
  have h : env38634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38633_38634 : H12AffineEnvironment.transform 4 1 env38633 = env38634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38633 == env38634) = true)

def env38635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272392,2101328,98645,8193,64,2177098,2098513,17665,2461975,2102548,2411541,257,21792,46093,2175562]

theorem envBound38635 : H12AffineFastState.Bounded env38635 := by
  intro p hp
  have h : env38635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38605_38635 : H12AffineEnvironment.transform 6 9 env38605 = env38635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38605 == env38635) = true)

theorem identity38635 : scanCanonicalize (H12AffineFastState.compose env38635 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound38635 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env38636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,12572,272392,8524,98645,8193,64,67926,13389,17665,368651,9224,326921,257,21792,46093,66390]

theorem envBound38636 : H12AffineFastState.Bounded env38636 := by
  intro p hp
  have h : env38636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38635_38636 : H12AffineEnvironment.transform 20 12572 env38635 = env38636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env38635 == env38636) = true)

theorem identity38636 : scanCanonicalize (H12AffineFastState.compose env38636 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound38636 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env38637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,57677,262144,1025,32769,12572,272392,8524,8543,8193,64,43356,13389,17665,262145,9224,326921,257,21792,46093,41820]

theorem envBound38637 : H12AffineFastState.Bounded env38637 := by
  intro p hp
  have h : env38637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38636_38637 : H12AffineEnvironment.transform 15 40970 env38636 = env38637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env38636 == env38637) = true)

theorem identity38637 : scanCanonicalize (H12AffineFastState.compose env38637 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound38637 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env38638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,57677,2421,1025,32769,12572,8573,8524,8543,8193,64,43356,13389,17665,2420,9224,62588,257,21792,46093,41820]

theorem envBound38638 : H12AffineFastState.Bounded env38638 := by
  intro p hp
  have h : env38638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38637_38638 : H12AffineEnvironment.transform 17 2421 env38637 = env38638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env38637 == env38638) = true)

theorem identity38638 : scanCanonicalize (H12AffineFastState.compose env38638 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38638 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,24908,2421,1025,0,12572,8573,8524,8543,8193,64,10589,13389,17665,2420,9224,29821,257,21792,13324,9053]

theorem envBound38639 : H12AffineFastState.Bounded env38639 := by
  intro p hp
  have h : env38639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38638_38639 : H12AffineEnvironment.transform 14 1 env38638 = env38639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38638 == env38639) = true)

theorem identity38639 : scanCanonicalize (H12AffineFastState.compose env38639 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound38639 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,1,115,16692,2421,1025,0,4452,261,308,295,121,64,2341,5173,17665,2420,1136,21509,257,21792,5236,805]

theorem envBound38640 : H12AffineFastState.Bounded env38640 := by
  intro p hp
  have h : env38640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38639_38640 : H12AffineEnvironment.transform 12 120 env38639 = env38640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env38639 == env38640) = true)

theorem identity38640 : scanCanonicalize (H12AffineFastState.compose env38640 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38640 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env38641 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,16384,1,115,16400,2129,1025,0,4160,33,16,3,121,64,2049,5173,17445,2128,1136,21509,37,21508,5236,513]

theorem envBound38641 : H12AffineFastState.Bounded env38641 := by
  intro p hp
  have h : env38641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38640_38641 : H12AffineEnvironment.transform 7 36 env38640 = env38641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38640 == env38641) = true)

theorem identity38641 : scanCanonicalize (H12AffineFastState.compose env38641 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound38641 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38642 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5236,1,115,5220,2129,1025,0,4160,33,16,3,121,64,2049,5173,4177,2128,1136,113,37,112,5236,513]

theorem envBound38642 : H12AffineFastState.Bounded env38642 := by
  intro p hp
  have h : env38642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38641_38642 : H12AffineEnvironment.transform 13 5236 env38641 = env38642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env38641 == env38642) = true)

theorem identity38642 : scanCanonicalize (H12AffineFastState.compose env38642 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38642 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38643 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,1,35,5172,2049,1025,0,4112,33,16,3,41,16,2049,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound38643 : H12AffineFastState.Bounded env38643 := by
  intro p hp
  have h : env38643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38642_38643 : H12AffineEnvironment.transform 5 16 env38642 = env38643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38642 == env38643) = true)

theorem identity38643 : scanCanonicalize (H12AffineFastState.compose env38643 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound38643 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38644 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1076,4096,40,5156,1,35,5172,1077,1025,0,4112,33,16,3,41,16,1077,5173,4097,1076,1056,33,37,32,5156,513]

theorem envBound38644 : H12AffineFastState.Bounded env38644 := by
  intro p hp
  have h : env38644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38643_38644 : H12AffineEnvironment.transform 10 1076 env38643 = env38644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env38643 == env38644) = true)

theorem identity38644 : scanCanonicalize (H12AffineFastState.compose env38644 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound38644 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38645 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1076,1061,40,1,1,35,17,1077,1025,0,1077,33,16,3,41,16,1077,16,1060,1076,1056,33,37,32,1,513]

theorem envBound38645 : H12AffineFastState.Bounded env38645 := by
  intro p hp
  have h : env38645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38644_38645 : H12AffineEnvironment.transform 11 1061 env38644 = env38645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env38644 == env38645) = true)

theorem identity38645 : scanCanonicalize (H12AffineFastState.compose env38645 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38645 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env38646 : List Nat := [2,4,8,16,32,16,9,36,512,52,0,17,40,1,1,35,17,1,53,0,1,33,16,3,41,16,1,16,16,0,20,33,37,32,1,513]

theorem envBound38646 : H12AffineFastState.Bounded env38646 := by
  intro p hp
  have h : env38646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38645_38646 : H12AffineEnvironment.transform 9 52 env38645 = env38646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38645 == env38646) = true)

theorem identity38646 : scanCanonicalize (H12AffineFastState.compose env38646 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound38646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38647 : List Nat := [2,4,8,16,32,16,9,36,16,52,0,17,40,1,1,35,17,1,53,0,1,33,16,3,41,16,1,16,16,0,20,33,37,32,1,17]

theorem envBound38647 : H12AffineFastState.Bounded env38647 := by
  intro p hp
  have h : env38647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38646_38647 : H12AffineEnvironment.transform 8 16 env38646 = env38647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env38646 == env38647) = true)

theorem identity38647 : scanCanonicalize (H12AffineFastState.compose env38647 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound38647 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38648 : List Nat := [2,4,8,16,26,16,9,30,16,14,0,17,18,1,1,25,17,1,15,0,1,27,16,3,19,16,1,16,16,0,20,27,31,26,1,17]

theorem envBound38648 : H12AffineFastState.Bounded env38648 := by
  intro p hp
  have h : env38648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38647_38648 : H12AffineEnvironment.transform 4 26 env38647 = env38648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env38647 == env38648) = true)

def env38649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6623435,2098512,17664,2461974,2102685,6349852,257,21792,46212,2175562]

theorem envBound38649 : H12AffineFastState.Bounded env38649 := by
  intro p hp
  have h : env38649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38585_38649 : H12AffineEnvironment.transform 22 2101329 env38585 = env38649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env38585 == env38649) = true)

def env38650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2177099,2098512,17664,2461974,2102685,2411676,257,21792,46212,2175562]

theorem envBound38650 : H12AffineFastState.Bounded env38650 := by
  intro p hp
  have h : env38650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38649_38650 : H12AffineEnvironment.transform 21 272512 env38649 = env38650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38649 == env38650) = true)

theorem identity38650 : scanCanonicalize (H12AffineFastState.compose env38650 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound38650 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,58516,272512,62661,98781,8328,64,122079,57796,17664,357762,61705,272392,257,21792,46212,120542]

theorem envBound38651 : H12AffineFastState.Bounded env38651 := by
  intro p hp
  have h : env38651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38650_38651 : H12AffineEnvironment.transform 20 58516 env38650 = env38651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env38650 == env38651) = true)

def env38652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,58516,168,62661,98781,8328,64,122079,57796,17664,89514,61705,32,257,21792,46212,120542]

theorem envBound38652 : H12AffineFastState.Bounded env38652 := by
  intro p hp
  have h : env38652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38651_38652 : H12AffineEnvironment.transform 17 10280 env38651 = env38652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38651 == env38652) = true)

theorem identity38652 : scanCanonicalize (H12AffineFastState.compose env38652 (packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound38652 : packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env38653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,70862,10280,1025,32769,45341,168,41292,98781,8328,64,100694,46157,4233,67619,42112,32,257,169,46212,99159]

theorem envBound38653 : H12AffineFastState.Bounded env38653 := by
  intro p hp
  have h : env38653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38652_38653 : H12AffineEnvironment.transform 13 5513 env38652 = env38653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env38652 == env38653) = true)

theorem identity38653 : scanCanonicalize (H12AffineFastState.compose env38653 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38653 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,70726,10280,1025,32769,45341,32,41292,98645,8192,64,100694,46157,4097,67619,41992,32,257,33,46092,99159]

theorem envBound38654 : H12AffineFastState.Bounded env38654 := by
  intro p hp
  have h : env38654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38653_38654 : H12AffineEnvironment.transform 6 8 env38653 = env38654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38653 == env38654) = true)

theorem identity38654 : scanCanonicalize (H12AffineFastState.compose env38654 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38654 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env38655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,13389,10280,1025,32769,45341,32,41292,41310,8192,64,43357,46157,4097,10280,41992,32,257,33,46092,41820]

theorem envBound38655 : H12AffineFastState.Bounded env38655 := by
  intro p hp
  have h : env38655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38654_38655 : H12AffineEnvironment.transform 15 8203 env38654 = env38655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38654 == env38655) = true)

theorem identity38655 : scanCanonicalize (H12AffineFastState.compose env38655 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound38655 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38656 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,8192,5377,32768,8203,13373,10280,1025,32769,45341,32,41276,41262,8192,48,43309,46141,4097,10280,41992,32,257,33,46092,41772]

theorem envBound38656 : H12AffineFastState.Bounded env38656 := by
  intro p hp
  have h : env38656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38655_38656 : H12AffineEnvironment.transform 5 48 env38655 = env38656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env38655 == env38656) = true)

theorem identity38656 : scanCanonicalize (H12AffineFastState.compose env38656 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound38656 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38657 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,8192,5377,33,8203,13373,10280,1025,32,12604,32,8477,8463,8192,48,10508,13340,4097,10280,9257,32,257,33,13357,8973]

theorem envBound38657 : H12AffineFastState.Bounded env38657 := by
  intro p hp
  have h : env38657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38656_38657 : H12AffineEnvironment.transform 14 33 env38656 = env38657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env38656 == env38657) = true)

theorem identity38657 : scanCanonicalize (H12AffineFastState.compose env38657 (packedSelected [3,4,5,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound38657 : packedSelected [3,4,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env38658 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,33,8192,1312,33,8203,9244,10280,1025,32,8477,32,8477,8463,8192,48,10508,9277,32,10280,9257,32,257,33,9228,8973]

theorem envBound38658 : H12AffineFastState.Bounded env38658 := by
  intro p hp
  have h : env38658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38657_38658 : H12AffineEnvironment.transform 11 33 env38657 = env38658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env38657 == env38658) = true)

theorem identity38658 : scanCanonicalize (H12AffineFastState.compose env38658 (packedSelected [0,1,4,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound38658 : packedSelected [0,1,4,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env38659 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,33,1337,1312,33,1330,293,3345,1025,32,1060,32,1060,1078,1337,48,3125,260,32,3345,272,32,257,33,309,1588]

theorem envBound38659 : H12AffineFastState.Bounded env38659 := by
  intro p hp
  have h : env38659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38658_38659 : H12AffineEnvironment.transform 12 1337 env38658 = env38659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env38658 == env38659) = true)

theorem identity38659 : scanCanonicalize (H12AffineFastState.compose env38659 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound38659 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env38660 : List Nat := [2,4,8,16,32,48,8,256,261,1024,2048,33,1337,1312,33,1330,293,3345,1025,32,1060,32,1060,1078,1337,48,3125,260,32,3345,272,32,257,33,309,1329]

theorem envBound38660 : H12AffineFastState.Bounded env38660 := by
  intro p hp
  have h : env38660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38659_38660 : H12AffineEnvironment.transform 8 261 env38659 = env38660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env38659 == env38660) = true)

theorem identity38660 : scanCanonicalize (H12AffineFastState.compose env38660 (packedSelected [2,14] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound38660 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env38661 : List Nat := [2,4,8,16,32,48,8,256,261,20,2048,33,301,308,33,294,293,2309,21,32,48,32,48,34,301,48,2081,260,32,2309,272,32,257,33,309,293]

theorem envBound38661 : H12AffineFastState.Bounded env38661 := by
  intro p hp
  have h : env38661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38660_38661 : H12AffineEnvironment.transform 9 20 env38660 = env38661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env38660 == env38661) = true)

theorem identity38661 : scanCanonicalize (H12AffineFastState.compose env38661 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38661 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env38662 : List Nat := [2,4,8,16,1,17,8,256,261,20,2048,0,268,277,0,263,260,2309,21,1,17,1,17,3,268,17,2048,260,1,2309,272,1,257,0,276,260]

theorem envBound38662 : H12AffineFastState.Bounded env38662 := by
  intro p hp
  have h : env38662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38661_38662 : H12AffineEnvironment.transform 4 1 env38661 = env38662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38661 == env38662) = true)

theorem identity38662 : scanCanonicalize (H12AffineFastState.compose env38662 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound38662 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38663 : List Nat := [2,4,8,16,1,17,8,256,261,20,271,0,268,277,0,263,260,10,21,1,17,1,17,3,268,17,271,260,1,10,272,1,257,0,276,260]

theorem envBound38663 : H12AffineFastState.Bounded env38663 := by
  intro p hp
  have h : env38663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38662_38663 : H12AffineEnvironment.transform 10 271 env38662 = env38663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env38662 == env38663) = true)

theorem identity38663 : scanCanonicalize (H12AffineFastState.compose env38663 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38663 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38664 : List Nat := [2,4,4,16,1,17,4,256,261,20,259,0,256,277,0,263,260,6,21,1,17,1,17,3,256,17,259,260,1,6,272,1,257,0,276,260]

theorem envBound38664 : H12AffineFastState.Bounded env38664 := by
  intro p hp
  have h : env38664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38663_38664 : H12AffineEnvironment.transform 2 4 env38663 = env38664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38663 == env38664) = true)

def env38665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,58516,169,62661,98781,8328,64,122079,57796,17664,89515,61705,33,257,21792,46212,120542]

theorem envBound38665 : H12AffineFastState.Bounded env38665 := by
  intro p hp
  have h : env38665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38651_38665 : H12AffineEnvironment.transform 17 10281 env38651 = env38665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38651 == env38665) = true)

theorem identity38665 : scanCanonicalize (H12AffineFastState.compose env38665 (packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 41463) := by decide +kernel

theorem selectedBound38665 : packedSelected [0,1,2,3,4,6,9,10,19,20,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env38666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41463,57520,10281,1025,32769,58516,169,62661,8234,8328,64,32040,57796,17664,64604,61705,33,257,21792,46212,30505]

theorem envBound38666 : H12AffineFastState.Bounded env38666 := by
  intro p hp
  have h : env38666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38665_38666 : H12AffineEnvironment.transform 15 41463 env38665 = env38666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41463 env38665 == env38666) = true)

theorem identity38666 : scanCanonicalize (H12AffineFastState.compose env38666 (packedSelected [4,5,8,9,10,12,14,15,17,19,20,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound38666 : packedSelected [4,5,8,9,10,12,14,15,17,19,20,24,28] rootPS < 2^1333 := by decide +kernel

def env38667 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,8192,16384,32768,41463,57520,10281,457,32769,57692,169,61709,8234,8328,64,30944,57796,16584,63892,61705,33,257,20712,45388,29409]

theorem envBound38667 : H12AffineFastState.Bounded env38667 := by
  intro p hp
  have h : env38667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38666_38667 : H12AffineEnvironment.transform 9 456 env38666 = env38667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env38666 == env38667) = true)

theorem identity38667 : scanCanonicalize (H12AffineFastState.compose env38667 (packedSelected [0,2,4,6,9,10,11,12,15,17,18,19,20,26,27,31] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound38667 : packedSelected [0,2,4,6,9,10,11,12,15,17,18,19,20,26,27,31] rootPS < 2^1333 := by decide +kernel

def env38668 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,161,16384,32768,33110,49169,2184,457,32769,49661,169,53676,139,41,64,22593,49509,16584,55605,53672,33,257,20712,37357,21056]

theorem envBound38668 : H12AffineFastState.Bounded env38668 := by
  intro p hp
  have h : env38668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38667_38668 : H12AffineEnvironment.transform 12 161 env38667 = env38668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env38667 == env38668) = true)

theorem identity38668 : scanCanonicalize (H12AffineFastState.compose env38668 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 4588) := by decide +kernel

theorem selectedBound38668 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env38669 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,161,4588,32768,33110,37373,2184,457,32769,36881,169,32832,139,41,64,2477,37001,4388,35033,32836,33,257,260,37357,940]

theorem envBound38669 : H12AffineFastState.Bounded env38669 := by
  intro p hp
  have h : env38669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38668_38669 : H12AffineEnvironment.transform 13 4588 env38668 = env38669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4588 env38668 == env38669) = true)

theorem identity38669 : scanCanonicalize (H12AffineFastState.compose env38669 (packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound38669 : packedSelected [0,2,3,5,6,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env38670 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,161,4588,292,114,4313,2184,457,293,4405,169,356,139,41,64,2477,4525,4388,2557,352,33,257,260,4297,940]

theorem envBound38670 : H12AffineFastState.Bounded env38670 := by
  intro p hp
  have h : env38670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38669_38670 : H12AffineEnvironment.transform 14 292 env38669 = env38670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env38669 == env38670) = true)

theorem identity38670 : scanCanonicalize (H12AffineFastState.compose env38670 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38670 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38671 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,161,4541,292,35,4232,2184,408,293,4405,169,309,139,41,17,2477,4525,4388,2476,305,33,257,260,4248,940]

theorem envBound38671 : H12AffineFastState.Bounded env38671 := by
  intro p hp
  have h : env38671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38670_38671 : H12AffineEnvironment.transform 5 17 env38670 = env38671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38670 == env38671) = true)

theorem identity38671 : scanCanonicalize (H12AffineFastState.compose env38671 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38671 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env38672 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,4096,161,4248,1,35,4232,2184,189,0,4112,169,16,139,41,17,2184,4232,4097,2185,20,33,36,33,4248,649]

theorem envBound38672 : H12AffineFastState.Bounded env38672 := by
  intro p hp
  have h : env38672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38671_38672 : H12AffineEnvironment.transform 7 37 env38671 = env38672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38671 == env38672) = true)

theorem identity38672 : scanCanonicalize (H12AffineFastState.compose env38672 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 173) := by decide +kernel

theorem selectedBound38672 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38673 : List Nat := [2,4,8,16,32,17,128,37,512,188,173,4096,161,4248,1,35,4232,37,189,0,4112,169,16,139,41,17,37,4232,4097,36,20,33,36,33,4248,649]

theorem envBound38673 : H12AffineFastState.Bounded env38673 := by
  intro p hp
  have h : env38673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38672_38673 : H12AffineEnvironment.transform 10 173 env38672 = env38673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 173 env38672 == env38673) = true)

theorem identity38673 : scanCanonicalize (H12AffineFastState.compose env38673 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound38673 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env38674 : List Nat := [2,4,8,16,32,17,128,37,512,188,173,539,161,643,1,35,659,37,189,0,523,169,16,139,41,17,37,659,538,36,20,33,36,33,643,649]

theorem envBound38674 : H12AffineFastState.Bounded env38674 := by
  intro p hp
  have h : env38674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38673_38674 : H12AffineEnvironment.transform 11 539 env38673 = env38674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env38673 == env38674) = true)

theorem identity38674 : scanCanonicalize (H12AffineFastState.compose env38674 (packedSelected [0,1,2,6] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound38674 : packedSelected [0,1,2,6] rootPS < 2^1333 := by decide +kernel

def env38675 : List Nat := [2,4,8,16,32,17,128,37,45,188,173,54,161,174,1,35,190,37,189,0,38,169,16,139,41,17,37,190,55,36,20,33,36,33,174,164]

theorem envBound38675 : H12AffineFastState.Bounded env38675 := by
  intro p hp
  have h : env38675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38674_38675 : H12AffineEnvironment.transform 8 45 env38674 = env38675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env38674 == env38675) = true)

theorem identity38675 : scanCanonicalize (H12AffineFastState.compose env38675 (packedSelected [1,2,3,7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38675 : packedSelected [1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env38676 : List Nat := [2,0,8,16,32,17,128,33,41,184,169,50,161,170,1,35,186,33,185,0,34,169,16,139,41,17,33,186,51,32,16,33,32,33,170,160]

theorem envBound38676 : H12AffineFastState.Bounded env38676 := by
  intro p hp
  have h : env38676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38675_38676 : H12AffineEnvironment.transform 1 0 env38675 = env38676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38675 == env38676) = true)

theorem identity38676 : scanCanonicalize (H12AffineFastState.compose env38676 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38676 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env38677 : List Nat := [2,0,8,16,32,17,8,33,41,48,33,50,41,34,1,35,50,33,49,0,34,33,16,3,41,17,33,50,51,32,16,33,32,33,34,40]

theorem envBound38677 : H12AffineFastState.Bounded env38677 := by
  intro p hp
  have h : env38677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38676_38677 : H12AffineEnvironment.transform 6 8 env38676 = env38677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38676 == env38677) = true)

theorem identity38677 : scanCanonicalize (H12AffineFastState.compose env38677 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound38677 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38678 : List Nat := [2,0,8,16,3,17,8,2,10,19,2,17,10,1,1,0,17,2,18,0,1,2,16,3,10,17,2,17,16,3,16,2,3,2,1,11]

theorem envBound38678 : H12AffineFastState.Bounded env38678 := by
  intro p hp
  have h : env38678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38677_38678 : H12AffineEnvironment.transform 4 3 env38677 = env38678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env38677 == env38678) = true)

def env38679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2177098,2098512,17664,2461974,2102685,2411677,257,21792,46212,2175562]

theorem envBound38679 : H12AffineFastState.Bounded env38679 := by
  intro p hp
  have h : env38679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38649_38679 : H12AffineEnvironment.transform 21 272513 env38649 = env38679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38649 == env38679) = true)

theorem identity38679 : scanCanonicalize (H12AffineFastState.compose env38679 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound38679 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,82247,262144,1025,29909,2097152,272513,2101329,95497,8328,64,2177098,2098512,17664,2450882,2102685,2373705,257,21792,16464,2175562]

theorem envBound38680 : H12AffineFastState.Bounded env38680 := by
  intro p hp
  have h : env38680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38679_38680 : H12AffineEnvironment.transform 14 29908 env38679 = env38680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env38679 == env38680) = true)

def env38681 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82199,262144,1025,29829,2097152,272513,2101249,95497,8328,16,2177050,2098432,17664,2450834,2102685,2373657,257,21792,16384,2175514]

theorem envBound38681 : H12AffineFastState.Bounded env38681 := by
  intro p hp
  have h : env38681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38680_38681 : H12AffineEnvironment.transform 5 16 env38680 = env38681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38680 == env38681) = true)

theorem identity38681 : scanCanonicalize (H12AffineFastState.compose env38681 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound38681 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38682 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82199,76198,1025,29829,2097152,65831,2101249,95497,8328,16,2177050,2098432,17664,2116660,2102685,2167231,257,21792,16384,2175514]

theorem envBound38682 : H12AffineFastState.Bounded env38682 := by
  intro p hp
  have h : env38682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38681_38682 : H12AffineEnvironment.transform 17 76198 env38681 = env38682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env38681 == env38682) = true)

theorem identity38682 : scanCanonicalize (H12AffineFastState.compose env38682 (packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38682 : packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS < 2^1333 := by decide +kernel

def env38683 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,82199,76079,1025,29708,2097152,65831,2101249,95497,8193,16,2177050,2098432,17664,2116660,2102548,2167094,257,21792,16384,2175514]

theorem envBound38683 : H12AffineFastState.Bounded env38683 := by
  intro p hp
  have h : env38683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38682_38683 : H12AffineEnvironment.transform 6 9 env38682 = env38683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38682 == env38683) = true)

theorem identity38683 : scanCanonicalize (H12AffineFastState.compose env38683 (packedSelected [1,4,8,9,12,14,15,17,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound38683 : packedSelected [1,4,8,9,12,14,15,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env38684 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,34,16693,10509,1025,29708,2097152,261,2101249,29995,8193,16,2111544,2098432,17664,2116660,2102548,2101524,257,21792,16384,2110008]

theorem envBound38684 : H12AffineFastState.Bounded env38684 := by
  intro p hp
  have h : env38684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38683_38684 : H12AffineEnvironment.transform 15 34 env38683 = env38684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env38683 == env38684) = true)

theorem identity38684 : scanCanonicalize (H12AffineFastState.compose env38684 (packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38684 : packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env38685 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,29709,34,16400,10280,1025,29708,2097152,32,2101249,29710,8193,16,2111544,2098213,17445,2116660,2102321,2101297,36,21509,16384,2110008]

theorem envBound38685 : H12AffineFastState.Bounded env38685 := by
  intro p hp
  have h : env38685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38684_38685 : H12AffineEnvironment.transform 7 37 env38684 = env38685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38684 == env38685) = true)

theorem identity38685 : scanCanonicalize (H12AffineFastState.compose env38685 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound38685 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38686 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,16384,21541,34,16400,2048,1025,21540,2097152,32,2101249,21542,41,16,2103312,2098213,17445,2116660,2102321,2101297,36,21509,16384,2101776]

theorem envBound38686 : H12AffineFastState.Bounded env38686 := by
  intro p hp
  have h : env38686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38685_38686 : H12AffineEnvironment.transform 12 40 env38685 = env38686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env38685 == env38686) = true)

theorem identity38686 : scanCanonicalize (H12AffineFastState.compose env38686 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound38686 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38687 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5172,2048,1025,0,2097152,32,2101249,2,41,16,2103312,2098213,4097,2103312,2102321,2101297,36,33,5156,2101776]

theorem envBound38687 : H12AffineFastState.Bounded env38687 := by
  intro p hp
  have h : env38687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38686_38687 : H12AffineEnvironment.transform 13 5156 env38686 = env38687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env38686 == env38687) = true)

theorem identity38687 : scanCanonicalize (H12AffineFastState.compose env38687 (packedSelected [6] rootPS)) = affineNative (2^(20+1) ^^^ 33) := by decide +kernel

theorem selectedBound38687 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38688 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5172,2048,1025,0,33,32,4128,2,41,16,6193,1028,4097,6193,5136,4112,36,33,5156,4657]

theorem envBound38688 : H12AffineFastState.Bounded env38688 := by
  intro p hp
  have h : env38688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38687_38688 : H12AffineEnvironment.transform 20 33 env38687 = env38688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 33 env38687 == env38688) = true)

theorem identity38688 : scanCanonicalize (H12AffineFastState.compose env38688 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3589) := by decide +kernel

theorem selectedBound38688 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env38689 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3589,40,2593,1,34,2609,2048,1025,0,33,32,3621,2,41,16,1588,1028,3588,1588,2581,3605,36,33,2593,3124]

theorem envBound38689 : H12AffineFastState.Bounded env38689 := by
  intro p hp
  have h : env38689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38688_38689 : H12AffineEnvironment.transform 11 3589 env38688 = env38689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3589 env38688 == env38689) = true)

theorem identity38689 : scanCanonicalize (H12AffineFastState.compose env38689 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38689 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38690 : List Nat := [2,4,8,16,32,16,9,37,512,1024,0,1541,40,545,1,34,561,0,1025,0,33,32,1573,2,41,16,1588,1028,1540,1588,533,1557,36,33,545,1076]

theorem envBound38690 : H12AffineFastState.Bounded env38690 := by
  intro p hp
  have h : env38690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38689_38690 : H12AffineEnvironment.transform 10 0 env38689 = env38690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38689 == env38690) = true)

theorem identity38690 : scanCanonicalize (H12AffineFastState.compose env38690 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound38690 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38691 : List Nat := [2,4,8,16,32,16,9,37,49,1024,0,1076,40,16,1,34,0,0,1025,0,33,32,1044,2,41,16,1029,1028,1077,1029,36,1060,36,33,16,1076]

theorem envBound38691 : H12AffineFastState.Bounded env38691 := by
  intro p hp
  have h : env38691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38690_38691 : H12AffineEnvironment.transform 8 49 env38690 = env38691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38690 == env38691) = true)

theorem identity38691 : scanCanonicalize (H12AffineFastState.compose env38691 (packedSelected [0,2,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound38691 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env38692 : List Nat := [2,4,8,16,32,16,9,37,49,37,0,17,40,16,1,34,0,0,36,0,33,32,49,2,41,16,32,33,16,32,36,1,36,33,16,17]

theorem envBound38692 : H12AffineFastState.Bounded env38692 := by
  intro p hp
  have h : env38692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38691_38692 : H12AffineEnvironment.transform 9 37 env38691 = env38692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env38691 == env38692) = true)

def env38693 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82198,262144,1025,29828,2097152,272513,2101248,95497,8328,17,2177051,2098433,17664,2450835,2102685,2373656,257,21792,16385,2175515]

theorem envBound38693 : H12AffineFastState.Bounded env38693 := by
  intro p hp
  have h : env38693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38680_38693 : H12AffineEnvironment.transform 5 17 env38680 = env38693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38680 == env38693) = true)

theorem identity38693 : scanCanonicalize (H12AffineFastState.compose env38693 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound38693 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38694 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82198,2477,1025,29828,2097152,8492,2101248,95497,8328,17,2177051,2098433,17664,2190398,2102685,2109877,257,21792,16385,2175515]

theorem envBound38694 : H12AffineFastState.Bounded env38694 := by
  intro p hp
  have h : env38694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38693_38694 : H12AffineEnvironment.transform 17 2477 env38693 = env38694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env38693 == env38694) = true)

theorem identity38694 : scanCanonicalize (H12AffineFastState.compose env38694 (packedSelected [0,4,7,10,11,16,18,20,22,23,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38694 : packedSelected [0,4,7,10,11,16,18,20,22,23,31,32] rootPS < 2^1333 := by decide +kernel

def env38695 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8203,24861,2477,1025,29828,2097152,8492,2101248,21762,8328,17,2103312,2098433,17664,2116661,2102685,2109877,257,21792,16385,2101776]

theorem envBound38695 : H12AffineFastState.Bounded env38695 := by
  intro p hp
  have h : env38695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38694_38695 : H12AffineEnvironment.transform 15 8203 env38694 = env38695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38694 == env38695) = true)

theorem identity38695 : scanCanonicalize (H12AffineFastState.compose env38695 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38695 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38696 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,8203,13341,2477,1025,8580,2097152,8492,2101248,2,8328,17,2103312,2098433,4096,2103605,2102685,2109877,257,32,5377,2101776]

theorem envBound38696 : H12AffineFastState.Bounded env38696 := by
  intro p hp
  have h : env38696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38695_38696 : H12AffineEnvironment.transform 13 5376 env38695 = env38696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38695 == env38696) = true)

theorem identity38696 : scanCanonicalize (H12AffineFastState.compose env38696 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 4112) := by decide +kernel

theorem selectedBound38696 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env38697 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,8203,13341,2477,1025,8580,4112,8492,16,2,8328,17,2048,5393,4096,2341,1421,8613,257,32,5377,512]

theorem envBound38697 : H12AffineFastState.Bounded env38697 := by
  intro p hp
  have h : env38697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38696_38697 : H12AffineEnvironment.transform 20 4112 env38696 = env38697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4112 env38696 == env38697) = true)

theorem identity38697 : scanCanonicalize (H12AffineFastState.compose env38697 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38697 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38698 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,5376,428,34,5172,2477,1025,429,4112,261,16,2,161,17,2048,5393,4096,2341,1421,396,257,32,5377,512]

theorem envBound38698 : H12AffineFastState.Bounded env38698 := by
  intro p hp
  have h : env38698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38697_38698 : H12AffineEnvironment.transform 12 41 env38697 = env38698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38697 == env38698) = true)

theorem identity38698 : scanCanonicalize (H12AffineFastState.compose env38698 (packedSelected [0,1,2,4,8,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound38698 : packedSelected [0,1,2,4,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env38699 : List Nat := [2,4,8,16,32,17,128,256,512,189,2048,4096,41,4541,428,34,4233,2477,188,429,4112,261,16,2,161,17,2048,4524,4096,2341,304,396,257,32,4540,512]

theorem envBound38699 : H12AffineFastState.Bounded env38699 := by
  intro p hp
  have h : env38699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38698_38699 : H12AffineEnvironment.transform 9 189 env38698 = env38699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env38698 == env38699) = true)

theorem identity38699 : scanCanonicalize (H12AffineFastState.compose env38699 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38699 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env38700 : List Nat := [2,4,8,16,1,17,128,256,512,156,2048,4096,8,4508,397,3,4233,2444,157,396,4112,261,16,2,128,17,2048,4493,4096,2308,273,396,257,1,4509,512]

theorem envBound38700 : H12AffineFastState.Bounded env38700 := by
  intro p hp
  have h : env38700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38699_38700 : H12AffineEnvironment.transform 4 1 env38699 = env38700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38699 == env38700) = true)

def env38701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6623434,8393984,10507601,8749383,2102684,12645452,257,21793,46213,2175563]

theorem envBound38701 : H12AffineFastState.Bounded env38701 := by
  intro p hp
  have h : env38701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38584_38701 : H12AffineEnvironment.transform 23 10588557 env38584 = env38701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env38584 == env38701) = true)

def env38702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6623434,2098512,17665,2461975,2102684,6349852,257,21793,46213,2175563]

theorem envBound38702 : H12AffineFastState.Bounded env38702 := by
  intro p hp
  have h : env38702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38701_38702 : H12AffineEnvironment.transform 22 2101328 env38701 = env38702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env38701 == env38702) = true)

def env38703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2177098,2098512,17665,2461975,2102684,2411676,257,21793,46213,2175563]

theorem envBound38703 : H12AffineFastState.Bounded env38703 := by
  intro p hp
  have h : env38703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38702_38703 : H12AffineEnvironment.transform 21 272512 env38702 = env38703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38702 == env38703) = true)

theorem identity38703 : scanCanonicalize (H12AffineFastState.compose env38703 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound38703 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38297,262144,1025,32769,2097152,272512,2101328,21763,8328,64,2157716,2098512,17665,2377161,2102684,2411676,257,21793,46213,2156181]

theorem envBound38704 : H12AffineFastState.Bounded env38704 := by
  intro p hp
  have h : env38704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38703_38704 : H12AffineEnvironment.transform 15 54494 env38703 = env38704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env38703 == env38704) = true)

def env38705 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,262144,1025,32769,2097152,272512,2101248,21763,8328,16,2157716,2098432,17665,2377113,2102684,2411676,257,21793,46213,2156181]

theorem envBound38705 : H12AffineFastState.Bounded env38705 := by
  intro p hp
  have h : env38705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38704_38705 : H12AffineEnvironment.transform 5 16 env38704 = env38705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38704 == env38705) = true)

def env38706 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,23808,1025,32769,2097152,30080,2101248,21763,8328,16,2157716,2098432,17665,2103449,2102684,2134428,257,21793,46213,2156181]

theorem envBound38706 : H12AffineFastState.Bounded env38706 := by
  intro p hp
  have h : env38706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38705_38706 : H12AffineEnvironment.transform 17 23808 env38705 = env38706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env38705 == env38706) = true)

theorem identity38706 : scanCanonicalize (H12AffineFastState.compose env38706 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 4540) := by decide +kernel

theorem selectedBound38706 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env38707 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,23808,1025,32769,4540,30080,444,21763,8328,16,64808,5308,17665,2341,1056,32800,257,21793,46213,63273]

theorem envBound38707 : H12AffineFastState.Bounded env38707 := by
  intro p hp
  have h : env38707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38706_38707 : H12AffineEnvironment.transform 20 4540 env38706 = env38707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4540 env38706 == env38707) = true)

theorem identity38707 : scanCanonicalize (H12AffineFastState.compose env38707 (packedSelected [1,4,5,8,9,14,16,18,19,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound38707 : packedSelected [1,4,5,8,9,14,16,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env38708 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,32768,40970,38297,10628,1025,32769,4540,260,444,8583,8328,16,35244,5308,12677,2341,1056,32800,257,8613,46213,33709]

theorem envBound38708 : H12AffineFastState.Bounded env38708 := by
  intro p hp
  have h : env38708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38707_38708 : H12AffineEnvironment.transform 13 13444 env38707 = env38708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env38707 == env38708) = true)

theorem identity38708 : scanCanonicalize (H12AffineFastState.compose env38708 (packedSelected [0,3,4,5,7,10,12,15,17,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound38708 : packedSelected [0,3,4,5,7,10,12,15,17,22] rootPS < 2^1333 := by decide +kernel

def env38709 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,13444,32768,40970,37940,10281,1025,32769,4113,169,17,8234,8328,16,34817,5308,12328,2184,1056,32800,172,8200,46213,33280]

theorem envBound38709 : H12AffineFastState.Bounded env38709 := by
  intro p hp
  have h : env38709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38708_38709 : H12AffineEnvironment.transform 7 173 env38708 = env38709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38708 == env38709) = true)

theorem identity38709 : scanCanonicalize (H12AffineFastState.compose env38709 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound38709 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env38710 : List Nat := [2,4,8,16,32,16,128,173,512,21,2048,4096,8192,12433,32768,40970,36897,10281,20,32769,4113,169,17,8234,8328,16,34817,4265,12328,2184,53,32800,172,8200,45200,33280]

theorem envBound38710 : H12AffineFastState.Bounded env38710 := by
  intro p hp
  have h : env38710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38709_38710 : H12AffineEnvironment.transform 9 21 env38709 = env38710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env38709 == env38710) = true)

theorem identity38710 : scanCanonicalize (H12AffineFastState.compose env38710 (packedSelected [0,2,7,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound38710 : packedSelected [0,2,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env38711 : List Nat := [2,4,8,16,32,16,128,173,512,21,2048,4096,8192,12433,8201,3,12328,10281,20,8200,4113,169,17,8234,8328,16,10248,4265,12328,2184,53,8233,172,8200,4249,8713]

theorem envBound38711 : H12AffineFastState.Bounded env38711 := by
  intro p hp
  have h : env38711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38710_38711 : H12AffineEnvironment.transform 14 8201 env38710 = env38711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env38710 == env38711) = true)

theorem identity38711 : scanCanonicalize (H12AffineFastState.compose env38711 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound38711 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env38712 : List Nat := [2,4,8,16,32,16,128,173,512,21,2048,4096,161,4144,168,3,4233,2184,20,169,4113,169,17,139,41,16,2217,4265,4233,2184,53,136,172,169,4249,680]

theorem envBound38712 : H12AffineFastState.Bounded env38712 := by
  intro p hp
  have h : env38712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38711_38712 : H12AffineEnvironment.transform 12 161 env38711 = env38712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env38711 == env38712) = true)

theorem identity38712 : scanCanonicalize (H12AffineFastState.compose env38712 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound38712 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env38713 : List Nat := [2,4,8,16,32,16,41,4,512,21,2048,4096,8,4144,1,3,4128,2081,20,0,4113,0,17,34,41,16,2048,4096,4128,2081,53,33,5,0,4144,513]

theorem envBound38713 : H12AffineFastState.Bounded env38713 := by
  intro p hp
  have h : env38713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38712_38713 : H12AffineEnvironment.transform 6 41 env38712 = env38713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env38712 == env38713) = true)

theorem identity38713 : scanCanonicalize (H12AffineFastState.compose env38713 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound38713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38714 : List Nat := [2,4,8,16,32,16,41,4,512,21,2048,33,8,17,1,3,1,2081,20,0,48,0,17,34,41,16,2048,33,1,2081,53,33,5,0,17,513]

theorem envBound38714 : H12AffineFastState.Bounded env38714 := by
  intro p hp
  have h : env38714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38713_38714 : H12AffineEnvironment.transform 11 33 env38713 = env38714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env38713 == env38714) = true)

theorem identity38714 : scanCanonicalize (H12AffineFastState.compose env38714 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound38714 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38715 : List Nat := [2,4,8,16,32,16,41,4,33,21,2048,33,8,17,1,3,1,2081,20,0,48,0,17,34,41,16,2048,33,1,2081,53,33,5,0,17,32]

theorem envBound38715 : H12AffineFastState.Bounded env38715 := by
  intro p hp
  have h : env38715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38714_38715 : H12AffineEnvironment.transform 8 33 env38714 = env38715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env38714 == env38715) = true)

theorem identity38715 : scanCanonicalize (H12AffineFastState.compose env38715 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38715 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38716 : List Nat := [2,4,8,16,1,16,8,4,0,21,2048,0,8,17,1,3,1,2048,20,0,17,0,17,3,8,16,2048,0,1,2048,20,0,5,0,17,1]

theorem envBound38716 : H12AffineFastState.Bounded env38716 := by
  intro p hp
  have h : env38716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38715_38716 : H12AffineEnvironment.transform 4 1 env38715 = env38716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38715 == env38716) = true)

theorem identity38716 : scanCanonicalize (H12AffineFastState.compose env38716 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound38716 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38717 : List Nat := [2,4,8,16,1,16,8,4,0,21,17,0,8,17,1,3,1,17,20,0,17,0,17,3,8,16,17,0,1,17,20,0,5,0,17,1]

theorem envBound38717 : H12AffineFastState.Bounded env38717 := by
  intro p hp
  have h : env38717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38716_38717 : H12AffineEnvironment.transform 10 17 env38716 = env38717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env38716 == env38717) = true)

theorem identity38717 : scanCanonicalize (H12AffineFastState.compose env38717 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38717 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38718 : List Nat := [2,4,8,10,1,10,8,4,0,15,11,0,8,11,1,3,1,11,14,0,11,0,11,3,8,10,11,0,1,11,14,0,5,0,11,1]

theorem envBound38718 : H12AffineFastState.Bounded env38718 := by
  intro p hp
  have h : env38718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38717_38718 : H12AffineEnvironment.transform 3 10 env38717 = env38718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38717 == env38718) = true)

def env38719 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,23809,1025,32769,2097152,30081,2101248,21763,8328,16,2157716,2098432,17665,2103448,2102684,2134429,257,21793,46213,2156181]

theorem envBound38719 : H12AffineFastState.Bounded env38719 := by
  intro p hp
  have h : env38719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38705_38719 : H12AffineEnvironment.transform 17 23809 env38705 = env38719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env38705 == env38719) = true)

theorem identity38719 : scanCanonicalize (H12AffineFastState.compose env38719 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 4405) := by decide +kernel

theorem selectedBound38719 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env38720 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38297,23809,1025,32769,4405,30081,309,21763,8328,16,64929,5173,17665,2477,1193,32936,257,21793,46213,63392]

theorem envBound38720 : H12AffineFastState.Bounded env38720 := by
  intro p hp
  have h : env38720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38719_38720 : H12AffineEnvironment.transform 20 4405 env38719 = env38720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4405 env38719 == env38720) = true)

theorem identity38720 : scanCanonicalize (H12AffineFastState.compose env38720 (packedSelected [0,4,5,7,12,15,18,22,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38720 : packedSelected [0,4,5,7,12,15,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env38721 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,32768,54414,38297,23809,1025,32769,4405,21644,309,21763,389,16,56492,5173,17665,2477,1193,32936,257,21793,38280,54957]

theorem envBound38721 : H12AffineFastState.Bounded env38721 := by
  intro p hp
  have h : env38721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38720_38721 : H12AffineEnvironment.transform 12 269 env38720 = env38721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38720 == env38721) = true)

theorem identity38721 : scanCanonicalize (H12AffineFastState.compose env38721 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound38721 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38722 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,136,21510,5393,23809,1025,137,4405,21644,309,21763,389,16,23588,5173,17665,2477,1193,32,257,21793,5376,22053]

theorem envBound38722 : H12AffineFastState.Bounded env38722 := by
  intro p hp
  have h : env38722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38721_38722 : H12AffineEnvironment.transform 14 136 env38721 = env38722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env38721 == env38722) = true)

theorem identity38722 : scanCanonicalize (H12AffineFastState.compose env38722 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38722 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env38723 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,16384,136,21510,5172,23588,1025,137,4112,21644,16,21542,160,16,23588,5173,17444,2184,1193,32,36,21508,5157,22053]

theorem envBound38723 : H12AffineFastState.Bounded env38723 := by
  intro p hp
  have h : env38723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38722_38723 : H12AffineEnvironment.transform 7 37 env38722 = env38723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38722 == env38723) = true)

theorem identity38723 : scanCanonicalize (H12AffineFastState.compose env38723 (packedSelected [1,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 3124) := by decide +kernel

theorem selectedBound38723 : packedSelected [1,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env38724 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,3124,136,6194,5172,4112,1025,137,4112,6328,16,6162,160,16,4112,5173,2064,2184,1193,32,36,6192,5157,6673]

theorem envBound38724 : H12AffineFastState.Bounded env38724 := by
  intro p hp
  have h : env38724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38723_38724 : H12AffineEnvironment.transform 13 3124 env38723 = env38724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3124 env38723 == env38724) = true)

theorem identity38724 : scanCanonicalize (H12AffineFastState.compose env38724 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38724 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env38725 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,3124,0,6194,5172,4112,1025,1,4112,6192,16,6162,40,16,4112,5173,2064,2048,1057,32,36,6192,5157,6673]

theorem envBound38725 : H12AffineFastState.Bounded env38725 := by
  intro p hp
  have h : env38725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38724_38725 : H12AffineEnvironment.transform 6 8 env38724 = env38725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38724 == env38725) = true)

def env38726 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,262144,1025,32769,2097152,272512,2101249,21763,8328,17,2157716,2098433,17665,2377112,2102684,2411676,257,21793,46213,2156181]

theorem envBound38726 : H12AffineFastState.Bounded env38726 := by
  intro p hp
  have h : env38726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38704_38726 : H12AffineEnvironment.transform 5 17 env38704 = env38726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38704 == env38726) = true)

theorem identity38726 : scanCanonicalize (H12AffineFastState.compose env38726 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound38726 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env38727 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,262144,1025,32769,58396,272512,62493,21763,8328,17,2184,57629,17665,303492,61824,272512,257,21793,46213,649]

theorem envBound38727 : H12AffineFastState.Bounded env38727 := by
  intro p hp
  have h : env38727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38726_38727 : H12AffineEnvironment.transform 20 58396 env38726 = env38727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env38726 == env38727) = true)

theorem identity38727 : scanCanonicalize (H12AffineFastState.compose env38727 (packedSelected [1,3,5,12,15,17,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound38727 : packedSelected [1,3,5,12,15,17,26,28] rootPS < 2^1333 := by decide +kernel

def env38728 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,32160,1025,32769,58396,21792,62493,21763,8328,17,2184,57629,17665,56356,61824,21792,257,21793,46213,649]

theorem envBound38728 : H12AffineFastState.Bounded env38728 := by
  intro p hp
  have h : env38728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38727_38728 : H12AffineEnvironment.transform 17 32160 env38727 = env38728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env38727 == env38728) = true)

theorem identity38728 : scanCanonicalize (H12AffineFastState.compose env38728 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound38728 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env38729 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21896,263,16401,32160,1025,21897,12692,21792,8597,21763,8328,17,2184,13461,17665,2476,9224,21792,257,21793,24845,649]

theorem envBound38729 : H12AffineFastState.Bounded env38729 := by
  intro p hp
  have h : env38729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38728_38729 : H12AffineEnvironment.transform 14 21896 env38728 = env38729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env38728 == env38729) = true)

theorem identity38729 : scanCanonicalize (H12AffineFastState.compose env38729 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38729 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env38730 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,136,263,5393,10400,1025,137,12692,32,8597,3,8328,17,2184,13461,4097,2476,9224,32,257,33,13325,649]

theorem envBound38730 : H12AffineFastState.Bounded env38730 := by
  intro p hp
  have h : env38730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38729_38730 : H12AffineEnvironment.transform 13 5376 env38729 = env38730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38729 == env38730) = true)

theorem identity38730 : scanCanonicalize (H12AffineFastState.compose env38730 (packedSelected [3,4,5,6,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound38730 : packedSelected [3,4,5,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env38731 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1212,8192,444,136,263,429,10400,1025,137,9512,32,8597,3,8328,17,2184,8233,1213,2476,9224,32,257,33,8369,649]

theorem envBound38731 : H12AffineFastState.Bounded env38731 := by
  intro p hp
  have h : env38731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38730_38731 : H12AffineEnvironment.transform 11 1212 env38730 = env38731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env38730 == env38731) = true)

theorem identity38731 : scanCanonicalize (H12AffineFastState.compose env38731 (packedSelected [0,2,4,7,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound38731 : packedSelected [0,2,4,7,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env38732 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1212,389,444,136,263,429,2341,1025,137,1197,32,16,3,269,17,2184,428,1213,2476,1421,32,257,33,308,649]

theorem envBound38732 : H12AffineFastState.Bounded env38732 := by
  intro p hp
  have h : env38732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38731_38732 : H12AffineEnvironment.transform 12 389 env38731 = env38732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env38731 == env38732) = true)

theorem identity38732 : scanCanonicalize (H12AffineFastState.compose env38732 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound38732 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38733 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1296,1212,389,444,136,263,429,1077,1025,137,1197,32,16,3,269,17,1432,428,1213,1212,1421,32,257,33,308,649]

theorem envBound38733 : H12AffineFastState.Bounded env38733 := by
  intro p hp
  have h : env38733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38732_38733 : H12AffineEnvironment.transform 10 1296 env38732 = env38733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env38732 == env38733) = true)

theorem identity38733 : scanCanonicalize (H12AffineFastState.compose env38733 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 153) := by decide +kernel

theorem selectedBound38733 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env38734 : List Nat := [2,4,8,16,32,17,128,256,153,1024,1296,1212,389,444,136,263,429,1077,1025,137,1197,32,16,3,269,17,1432,428,1213,1212,1421,32,257,33,308,16]

theorem envBound38734 : H12AffineFastState.Bounded env38734 := by
  intro p hp
  have h : env38734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38733_38734 : H12AffineEnvironment.transform 8 153 env38733 = env38734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 153 env38733 == env38734) = true)

theorem identity38734 : scanCanonicalize (H12AffineFastState.compose env38734 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound38734 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env38735 : List Nat := [2,4,8,16,32,17,128,189,153,1024,1197,1212,56,1,136,186,16,1077,1025,137,1197,32,16,3,176,17,1061,17,1213,1212,1072,32,188,33,137,16]

theorem envBound38735 : H12AffineFastState.Bounded env38735 := by
  intro p hp
  have h : env38735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38734_38735 : H12AffineEnvironment.transform 7 189 env38734 = env38735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env38734 == env38735) = true)

theorem identity38735 : scanCanonicalize (H12AffineFastState.compose env38735 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38735 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env38736 : List Nat := [2,4,8,16,32,17,8,53,17,1024,1061,1076,56,1,0,50,16,1077,1025,1,1061,32,16,3,56,17,1061,17,1077,1076,1072,32,52,33,1,16]

theorem envBound38736 : H12AffineFastState.Bounded env38736 := by
  intro p hp
  have h : env38736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38735_38736 : H12AffineEnvironment.transform 6 8 env38735 = env38736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38735 == env38736) = true)

theorem identity38736 : scanCanonicalize (H12AffineFastState.compose env38736 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound38736 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38737 : List Nat := [2,4,8,16,32,17,8,53,17,36,1,16,56,1,0,50,16,17,37,1,1,32,16,3,56,17,1,17,17,16,20,32,52,33,1,16]

theorem envBound38737 : H12AffineFastState.Bounded env38737 := by
  intro p hp
  have h : env38737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38736_38737 : H12AffineEnvironment.transform 9 36 env38736 = env38737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env38736 == env38737) = true)

theorem identity38737 : scanCanonicalize (H12AffineFastState.compose env38737 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38738 : List Nat := [2,4,8,16,10,17,8,31,17,14,1,16,18,1,0,24,16,17,15,1,1,10,16,3,18,17,1,17,17,16,20,10,30,11,1,16]

theorem envBound38738 : H12AffineFastState.Bounded env38738 := by
  intro p hp
  have h : env38738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38737_38738 : H12AffineEnvironment.transform 4 10 env38737 = env38738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38737 == env38738) = true)

def env38739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2177099,2098512,17665,2461975,2102684,2411677,257,21793,46213,2175563]

theorem envBound38739 : H12AffineFastState.Bounded env38739 := by
  intro p hp
  have h : env38739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38702_38739 : H12AffineEnvironment.transform 21 272513 env38702 = env38739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38702 == env38739) = true)

theorem identity38739 : scanCanonicalize (H12AffineFastState.compose env38739 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound38739 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115871,272513,120015,98781,8328,64,64724,115151,17665,284040,119043,329730,257,21793,46213,63188]

theorem envBound38740 : H12AffineFastState.Bounded env38740 := by
  intro p hp
  have h : env38740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38739_38740 : H12AffineEnvironment.transform 20 115871 env38739 = env38740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env38739 == env38740) = true)

def env38741 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115871,272513,119967,98701,8328,16,64644,115103,17665,284040,119043,329730,257,21793,46213,63108]

theorem envBound38741 : H12AffineFastState.Bounded env38741 := by
  intro p hp
  have h : env38741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38740_38741 : H12AffineEnvironment.transform 5 16 env38740 = env38741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38740 == env38741) = true)

theorem identity38741 : scanCanonicalize (H12AffineFastState.compose env38741 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound38741 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env38742 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,122147,1025,32769,115871,128418,119967,98701,8328,16,64644,115103,17665,100523,119043,54561,257,21793,46213,63108]

theorem envBound38742 : H12AffineFastState.Bounded env38742 := by
  intro p hp
  have h : env38742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38741_38742 : H12AffineEnvironment.transform 17 122147 env38741 = env38742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env38741 == env38742) = true)

theorem identity38742 : scanCanonicalize (H12AffineFastState.compose env38742 (packedSelected [4,5,7,8,9,17,19,24,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound38742 : packedSelected [4,5,7,8,9,17,19,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38743 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,82199,76199,1025,29829,77851,65830,73755,95497,8328,16,2048,79131,17665,97327,75143,8613,257,21793,16385,512]

theorem envBound38743 : H12AffineFastState.Bounded env38743 := by
  intro p hp
  have h : env38743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38742_38743 : H12AffineEnvironment.transform 14 29828 env38742 = env38743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env38742 == env38743) = true)

theorem identity38743 : scanCanonicalize (H12AffineFastState.compose env38743 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound38743 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38744 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,398,16537,10281,1025,29829,12693,168,8597,29831,8328,16,2048,13461,17665,32161,9225,8613,257,21793,16385,512]

theorem envBound38744 : H12AffineFastState.Bounded env38744 := by
  intro p hp
  have h : env38744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38743_38744 : H12AffineEnvironment.transform 15 398 env38743 = env38744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env38743 == env38744) = true)

theorem identity38744 : scanCanonicalize (H12AffineFastState.compose env38744 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound38744 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38745 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5124,8320,398,5277,10281,1025,8321,12693,168,8597,8323,8328,16,2048,13461,4357,10661,9225,8613,257,293,5125,512]

theorem envBound38745 : H12AffineFastState.Bounded env38745 := by
  intro p hp
  have h : env38745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38744_38745 : H12AffineEnvironment.transform 13 5124 env38744 = env38745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env38744 == env38745) = true)

theorem identity38745 : scanCanonicalize (H12AffineFastState.compose env38745 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1425) := by decide +kernel

theorem selectedBound38745 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env38746 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1425,5124,1297,398,5277,3512,1025,1296,5124,168,1028,1298,1305,16,2048,4356,4357,3124,408,1076,257,293,5125,512]

theorem envBound38746 : H12AffineFastState.Bounded env38746 := by
  intro p hp
  have h : env38746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38745_38746 : H12AffineEnvironment.transform 12 1425 env38745 = env38746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1425 env38745 == env38746) = true)

theorem identity38746 : scanCanonicalize (H12AffineFastState.compose env38746 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38746 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env38747 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,129,4372,1,398,4493,2216,273,0,4372,168,276,2,9,16,2048,4356,4357,2340,408,292,257,293,4373,512]

theorem envBound38747 : H12AffineFastState.Bounded env38747 := by
  intro p hp
  have h : env38747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38746_38747 : H12AffineEnvironment.transform 9 272 env38746 = env38747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38746 == env38747) = true)

theorem identity38747 : scanCanonicalize (H12AffineFastState.compose env38747 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38747 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38748 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8,4372,1,263,4356,2081,273,0,4372,33,276,2,9,16,2048,4356,4357,2340,273,292,257,293,4373,512]

theorem envBound38748 : H12AffineFastState.Bounded env38748 := by
  intro p hp
  have h : env38748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38747_38748 : H12AffineEnvironment.transform 6 9 env38747 = env38748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38747 == env38748) = true)

theorem identity38748 : scanCanonicalize (H12AffineFastState.compose env38748 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38748 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38749 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,8,4144,1,35,4128,2081,53,0,4144,33,48,2,9,16,2048,4128,4129,2048,53,0,37,1,4145,512]

theorem envBound38749 : H12AffineFastState.Bounded env38749 := by
  intro p hp
  have h : env38749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38748_38749 : H12AffineEnvironment.transform 7 36 env38748 = env38749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38748 == env38749) = true)

theorem identity38749 : scanCanonicalize (H12AffineFastState.compose env38749 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound38749 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env38750 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2065,8,2081,1,35,2097,2081,53,0,2081,33,48,2,9,16,2048,2097,2096,2048,53,0,37,1,2080,512]

theorem envBound38750 : H12AffineFastState.Bounded env38750 := by
  intro p hp
  have h : env38750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38749_38750 : H12AffineEnvironment.transform 11 2065 env38749 = env38750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env38749 == env38750) = true)

theorem identity38750 : scanCanonicalize (H12AffineFastState.compose env38750 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38750 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env38751 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,16,8,32,1,35,48,32,53,0,32,33,48,2,9,16,1,48,49,1,53,0,37,1,33,512]

theorem envBound38751 : H12AffineFastState.Bounded env38751 := by
  intro p hp
  have h : env38751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38750_38751 : H12AffineEnvironment.transform 10 1 env38750 = env38751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38750 == env38751) = true)

theorem identity38751 : scanCanonicalize (H12AffineFastState.compose env38751 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38751 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env38752 : List Nat := [2,4,8,1,32,1,9,36,512,37,1,1,8,32,1,35,33,32,36,0,32,33,33,2,9,1,1,33,32,1,36,0,37,1,33,512]

theorem envBound38752 : H12AffineFastState.Bounded env38752 := by
  intro p hp
  have h : env38752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38751_38752 : H12AffineEnvironment.transform 3 1 env38751 = env38752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38751 == env38752) = true)

theorem identity38752 : scanCanonicalize (H12AffineFastState.compose env38752 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38752 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38753 : List Nat := [2,4,8,1,0,1,9,4,512,5,1,1,8,0,1,3,1,0,4,0,0,1,1,2,9,1,1,1,0,1,4,0,5,1,1,512]

theorem envBound38753 : H12AffineFastState.Bounded env38753 := by
  intro p hp
  have h : env38753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38752_38753 : H12AffineEnvironment.transform 4 0 env38752 = env38753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38752 == env38753) = true)

theorem identity38753 : scanCanonicalize (H12AffineFastState.compose env38753 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38753 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38754 : List Nat := [2,0,8,1,0,1,9,0,512,1,1,1,8,0,1,3,1,0,0,0,0,1,1,2,9,1,1,1,0,1,0,0,1,1,1,512]

theorem envBound38754 : H12AffineFastState.Bounded env38754 := by
  intro p hp
  have h : env38754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38753_38754 : H12AffineEnvironment.transform 1 0 env38753 = env38754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38753 == env38754) = true)

theorem identity38754 : scanCanonicalize (H12AffineFastState.compose env38754 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38755 : List Nat := [1,0,8,1,0,1,9,0,512,1,1,1,8,0,1,0,1,0,0,0,0,1,1,1,9,1,1,1,0,1,0,0,1,1,1,512]

theorem envBound38755 : H12AffineFastState.Bounded env38755 := by
  intro p hp
  have h : env38755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38754_38755 : H12AffineEnvironment.transform 0 1 env38754 = env38755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38754 == env38755) = true)

theorem identity38755 : scanCanonicalize (H12AffineFastState.compose env38755 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound38755 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38756 : List Nat := [1,0,0,1,0,1,1,0,512,1,1,1,0,0,1,0,1,0,0,0,0,1,1,1,1,1,1,1,0,1,0,0,1,1,1,512]

theorem envBound38756 : H12AffineFastState.Bounded env38756 := by
  intro p hp
  have h : env38756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38755_38756 : H12AffineEnvironment.transform 2 0 env38755 = env38756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env38755 == env38756) = true)

def env38757 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,115871,272513,119966,98700,8328,17,64645,115102,17665,284040,119043,329730,257,21793,46213,63109]

theorem envBound38757 : H12AffineFastState.Bounded env38757 := by
  intro p hp
  have h : env38757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38740_38757 : H12AffineEnvironment.transform 5 17 env38740 = env38757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38740 == env38757) = true)

theorem identity38757 : scanCanonicalize (H12AffineFastState.compose env38757 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound38757 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env38758 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,64809,1025,32769,115871,54696,119966,98700,8328,17,64645,115102,17665,43169,119043,128299,257,21793,46213,63109]

theorem envBound38758 : H12AffineFastState.Bounded env38758 := by
  intro p hp
  have h : env38758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38757_38758 : H12AffineEnvironment.transform 17 64809 env38757 = env38758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env38757 == env38758) = true)

theorem identity38758 : scanCanonicalize (H12AffineFastState.compose env38758 (packedSelected [0,3,5,8,9,17,18,19,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound38758 : packedSelected [0,3,5,8,9,17,18,19,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38759 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,64809,1025,32769,4112,54696,17,21763,8328,17,64645,5393,17665,43169,1420,8612,257,21793,46213,63109]

theorem envBound38759 : H12AffineFastState.Bounded env38759 := by
  intro p hp
  have h : env38759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38758_38759 : H12AffineEnvironment.transform 15 54415 env38758 = env38759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env38758 == env38759) = true)

theorem identity38759 : scanCanonicalize (H12AffineFastState.compose env38759 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound38759 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env38760 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,136,21511,5393,32161,1025,137,4112,21792,17,21763,8328,17,31757,5393,17665,10281,1420,8612,257,21793,13325,30221]

theorem envBound38760 : H12AffineFastState.Bounded env38760 := by
  intro p hp
  have h : env38760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38759_38760 : H12AffineEnvironment.transform 14 136 env38759 = env38760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env38759 == env38760) = true)

theorem identity38760 : scanCanonicalize (H12AffineFastState.compose env38760 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38760 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env38761 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,136,21511,5393,23724,1025,137,4112,21792,17,21763,389,17,23808,5393,17665,2340,1420,169,257,21793,5376,22272]

theorem envBound38761 : H12AffineFastState.Bounded env38761 := by
  intro p hp
  have h : env38761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38760_38761 : H12AffineEnvironment.transform 12 269 env38760 = env38761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38760 == env38761) = true)

theorem identity38761 : scanCanonicalize (H12AffineFastState.compose env38761 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38761 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38762 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5376,136,263,5393,2476,1025,137,4112,32,17,3,389,17,2048,5393,4097,2340,1420,169,257,33,5376,512]

theorem envBound38762 : H12AffineFastState.Bounded env38762 := by
  intro p hp
  have h : env38762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38761_38762 : H12AffineEnvironment.transform 13 5376 env38761 = env38762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38761 == env38762) = true)

theorem identity38762 : scanCanonicalize (H12AffineFastState.compose env38762 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound38762 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38763 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,269,5376,32,263,5393,2308,1025,33,4112,32,17,3,301,17,2048,5393,4097,2340,1316,1,257,33,5376,512]

theorem envBound38763 : H12AffineFastState.Bounded env38763 := by
  intro p hp
  have h : env38763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38762_38763 : H12AffineEnvironment.transform 6 40 env38762 = env38763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env38762 == env38763) = true)

theorem identity38763 : scanCanonicalize (H12AffineFastState.compose env38763 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound38763 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env38764 : List Nat := [2,4,8,16,32,17,40,256,512,1024,1808,4096,269,5376,32,263,5393,1556,1025,33,4112,32,17,3,301,17,1808,5393,4097,1588,1316,1,257,33,5376,512]

theorem envBound38764 : H12AffineFastState.Bounded env38764 := by
  intro p hp
  have h : env38764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38763_38764 : H12AffineEnvironment.transform 10 1808 env38763 = env38764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env38763 == env38764) = true)

theorem identity38764 : scanCanonicalize (H12AffineFastState.compose env38764 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound38764 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38765 : List Nat := [2,4,8,16,32,17,40,256,512,62,814,4096,269,4414,32,263,4399,554,63,33,4112,32,17,3,301,17,814,4399,4097,522,282,1,257,33,4414,512]

theorem envBound38765 : H12AffineFastState.Bounded env38765 := by
  intro p hp
  have h : env38765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38764_38765 : H12AffineEnvironment.transform 9 62 env38764 = env38765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env38764 == env38765) = true)

theorem identity38765 : scanCanonicalize (H12AffineFastState.compose env38765 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound38765 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38766 : List Nat := [2,4,8,16,32,17,40,63,512,62,529,4096,50,4097,32,56,4112,554,63,33,4112,32,17,3,18,17,529,4112,4097,522,37,1,62,33,4097,512]

theorem envBound38766 : H12AffineFastState.Bounded env38766 := by
  intro p hp
  have h : env38766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38765_38766 : H12AffineEnvironment.transform 7 63 env38765 = env38766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env38765 == env38766) = true)

theorem identity38766 : scanCanonicalize (H12AffineFastState.compose env38766 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38766 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env38767 : List Nat := [2,4,8,11,32,10,40,36,512,37,522,4096,41,4097,32,35,4107,554,36,33,4107,32,10,3,9,10,522,4107,4097,522,37,1,37,33,4097,512]

theorem envBound38767 : H12AffineFastState.Bounded env38767 := by
  intro p hp
  have h : env38767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38766_38767 : H12AffineEnvironment.transform 3 11 env38766 = env38767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38766 == env38767) = true)

def env38768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6623434,2098513,17664,2461974,2102684,6349853,257,21793,46213,2175563]

theorem envBound38768 : H12AffineFastState.Bounded env38768 := by
  intro p hp
  have h : env38768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38701_38768 : H12AffineEnvironment.transform 22 2101329 env38701 = env38768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env38701 == env38768) = true)

def env38769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2177098,2098513,17664,2461974,2102684,2411677,257,21793,46213,2175563]

theorem envBound38769 : H12AffineFastState.Bounded env38769 := by
  intro p hp
  have h : env38769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38768_38769 : H12AffineEnvironment.transform 21 272512 env38768 = env38769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38768 == env38769) = true)

theorem identity38769 : scanCanonicalize (H12AffineFastState.compose env38769 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38769 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,262144,1025,32769,2097152,272512,2101329,41430,8328,64,2103360,2098513,17664,2404636,2102684,2411677,257,21793,46213,2101825]

theorem envBound38770 : H12AffineFastState.Bounded env38770 := by
  intro p hp
  have h : env38770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38769_38770 : H12AffineEnvironment.transform 15 8202 env38769 = env38770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38769 == env38770) = true)

theorem identity38770 : scanCanonicalize (H12AffineFastState.compose env38770 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 309473) := by decide +kernel

theorem selectedBound38770 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24909,262144,1025,32769,309473,272512,305328,41430,8328,64,303265,310704,17664,2557,306557,29820,257,21793,46213,305824]

theorem envBound38771 : H12AffineFastState.Bounded env38771 := by
  intro p hp
  have h : env38771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38770_38771 : H12AffineEnvironment.transform 20 309473 env38770 = env38771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309473 env38770 == env38771) = true)

theorem identity38771 : scanCanonicalize (H12AffineFastState.compose env38771 (packedSelected [3,5,8,11,17,18,23,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38771 : packedSelected [3,5,8,11,17,18,23,28,32] rootPS < 2^1333 := by decide +kernel

def env38772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,16400,262144,1025,32769,301500,264669,297453,32907,469,64,295420,302317,17664,2557,298016,21793,257,21793,38360,297981]

theorem envBound38772 : H12AffineFastState.Bounded env38772 := by
  intro p hp
  have h : env38772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38771_38772 : H12AffineEnvironment.transform 12 349 env38771 = env38772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38771 == env38772) = true)

theorem identity38772 : scanCanonicalize (H12AffineFastState.compose env38772 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38772 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,32768,343,5393,262144,1025,32769,301500,264669,297453,32907,469,64,295420,302317,4097,2557,298016,32,257,32,38360,297981]

theorem envBound38773 : H12AffineFastState.Bounded env38773 := by
  intro p hp
  have h : env38773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38772_38773 : H12AffineEnvironment.transform 13 5377 env38772 = env38773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38772 == env38773) = true)

theorem identity38773 : scanCanonicalize (H12AffineFastState.compose env38773 (packedSelected [0,2,7,9,11,16,17,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound38773 : packedSelected [0,2,7,9,11,16,17,18,22] rootPS < 2^1333 := by decide +kernel

def env38774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,372,343,5393,262144,1025,373,268488,264669,264345,511,469,64,262280,269721,4097,2557,265556,32,257,32,5292,264841]

theorem envBound38774 : H12AffineFastState.Bounded env38774 := by
  intro p hp
  have h : env38774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38773_38774 : H12AffineEnvironment.transform 14 372 env38773 = env38774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env38773 == env38774) = true)

theorem identity38774 : scanCanonicalize (H12AffineFastState.compose env38774 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound38774 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env38775 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,5236,1,34,5220,262144,1025,0,268488,264360,264345,138,160,64,262280,269548,4097,2184,265249,32,116,32,5292,264841]

theorem envBound38775 : H12AffineFastState.Bounded env38775 := by
  intro p hp
  have h : env38775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38774_38775 : H12AffineEnvironment.transform 7 117 env38774 = env38775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env38774 == env38775) = true)

theorem identity38775 : scanCanonicalize (H12AffineFastState.compose env38775 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38775 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env38776 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5156,1,34,5172,262144,1025,0,268440,264360,264345,138,160,16,262280,269500,4097,2184,265249,32,36,32,5292,264841]

theorem envBound38776 : H12AffineFastState.Bounded env38776 := by
  intro p hp
  have h : env38776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38775_38776 : H12AffineEnvironment.transform 5 16 env38775 = env38776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38775 == env38776) = true)

theorem identity38776 : scanCanonicalize (H12AffineFastState.compose env38776 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 137) := by decide +kernel

theorem selectedBound38776 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env38777 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5156,1,34,5172,137,1025,0,6161,2081,2064,138,160,16,1,7221,4097,2184,3240,32,36,32,5292,2560]

theorem envBound38777 : H12AffineFastState.Bounded env38777 := by
  intro p hp
  have h : env38777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38776_38777 : H12AffineEnvironment.transform 17 137 env38776 = env38777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137 env38776 == env38777) = true)

theorem identity38777 : scanCanonicalize (H12AffineFastState.compose env38777 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound38777 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env38778 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1180,4096,40,5156,1,34,5172,137,1025,0,5261,1213,1164,138,160,16,1,4265,4097,1044,52,32,36,32,5292,1692]

theorem envBound38778 : H12AffineFastState.Bounded env38778 := by
  intro p hp
  have h : env38778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38777_38778 : H12AffineEnvironment.transform 10 1180 env38777 = env38778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env38777 == env38778) = true)

theorem identity38778 : scanCanonicalize (H12AffineFastState.compose env38778 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1181) := by decide +kernel

theorem selectedBound38778 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env38779 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1180,1181,40,185,1,34,169,137,1025,0,16,1213,1164,138,160,16,1,1076,1180,1044,52,32,36,32,49,1692]

theorem envBound38779 : H12AffineFastState.Bounded env38779 := by
  intro p hp
  have h : env38779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38778_38779 : H12AffineEnvironment.transform 11 1181 env38778 = env38779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1181 env38778 == env38779) = true)

theorem identity38779 : scanCanonicalize (H12AffineFastState.compose env38779 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38779 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38780 : List Nat := [2,4,8,0,32,0,128,37,512,1024,1164,1165,40,169,1,34,169,137,1025,0,0,1197,1164,138,160,0,1,1060,1164,1028,36,32,36,32,33,1676]

theorem envBound38780 : H12AffineFastState.Bounded env38780 := by
  intro p hp
  have h : env38780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38779_38780 : H12AffineEnvironment.transform 3 0 env38779 = env38780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38779 == env38780) = true)

theorem identity38780 : scanCanonicalize (H12AffineFastState.compose env38780 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound38780 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38781 : List Nat := [2,4,8,0,32,0,128,37,512,37,169,168,40,169,1,34,169,137,36,0,0,136,169,138,160,0,1,1,169,33,36,32,36,32,33,681]

theorem envBound38781 : H12AffineFastState.Bounded env38781 := by
  intro p hp
  have h : env38781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38780_38781 : H12AffineEnvironment.transform 9 37 env38780 = env38781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env38780 == env38781) = true)

theorem identity38781 : scanCanonicalize (H12AffineFastState.compose env38781 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38781 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env38782 : List Nat := [2,4,8,0,32,0,8,37,512,37,33,32,40,33,1,34,33,1,36,0,0,0,33,2,40,0,1,1,33,33,36,32,36,32,33,545]

theorem envBound38782 : H12AffineFastState.Bounded env38782 := by
  intro p hp
  have h : env38782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38781_38782 : H12AffineEnvironment.transform 6 8 env38781 = env38782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38781 == env38782) = true)

theorem identity38782 : scanCanonicalize (H12AffineFastState.compose env38782 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38782 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38783 : List Nat := [2,4,8,0,0,0,8,5,512,5,1,0,8,1,1,2,1,1,4,0,0,0,1,2,8,0,1,1,1,1,4,0,4,0,1,513]

theorem envBound38783 : H12AffineFastState.Bounded env38783 := by
  intro p hp
  have h : env38783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38782_38783 : H12AffineEnvironment.transform 4 0 env38782 = env38783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38782 == env38783) = true)

theorem identity38783 : scanCanonicalize (H12AffineFastState.compose env38783 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound38783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38784 : List Nat := [2,1,8,0,0,0,8,0,512,0,1,0,8,1,1,2,1,1,1,0,0,0,1,2,8,0,1,1,1,1,1,0,1,0,1,513]

theorem envBound38784 : H12AffineFastState.Bounded env38784 := by
  intro p hp
  have h : env38784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38783_38784 : H12AffineEnvironment.transform 1 1 env38783 = env38784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env38783 == env38784) = true)

theorem identity38784 : scanCanonicalize (H12AffineFastState.compose env38784 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound38784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38785 : List Nat := [2,1,8,0,0,0,8,0,3,0,1,0,8,1,1,2,1,1,1,0,0,0,1,2,8,0,1,1,1,1,1,0,1,0,1,2]

theorem envBound38785 : H12AffineFastState.Bounded env38785 := by
  intro p hp
  have h : env38785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38784_38785 : H12AffineEnvironment.transform 8 3 env38784 = env38785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env38784 == env38785) = true)

theorem identity38785 : scanCanonicalize (H12AffineFastState.compose env38785 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38785 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38786 : List Nat := [2,1,2,0,0,0,2,0,3,0,1,0,2,1,1,2,1,1,1,0,0,0,1,2,2,0,1,1,1,1,1,0,1,0,1,2]

theorem envBound38786 : H12AffineFastState.Bounded env38786 := by
  intro p hp
  have h : env38786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38785_38786 : H12AffineEnvironment.transform 2 2 env38785 = env38786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38785 == env38786) = true)

def env38787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2177099,2098513,17664,2461974,2102684,2411676,257,21793,46213,2175563]

theorem envBound38787 : H12AffineFastState.Bounded env38787 := by
  intro p hp
  have h : env38787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38768_38787 : H12AffineEnvironment.transform 21 272513 env38768 = env38787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38768 == env38787) = true)

theorem identity38787 : scanCanonicalize (H12AffineFastState.compose env38787 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound38787 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272513,73755,98780,8328,64,2049,79131,17664,303452,75222,392406,257,21793,46213,513]

theorem envBound38788 : H12AffineFastState.Bounded env38788 := by
  intro p hp
  have h : env38788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38787_38788 : H12AffineEnvironment.transform 20 77898 env38787 = env38788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env38787 == env38788) = true)

theorem identity38788 : scanCanonicalize (H12AffineFastState.compose env38788 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound38788 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env38789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,67618,1025,32769,77898,73891,73755,98780,8328,64,2049,79131,17664,108926,75222,62708,257,21793,46213,513]

theorem envBound38789 : H12AffineFastState.Bounded env38789 := by
  intro p hp
  have h : env38789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38788_38789 : H12AffineEnvironment.transform 17 67618 env38788 = env38789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env38788 == env38789) = true)

theorem identity38789 : scanCanonicalize (H12AffineFastState.compose env38789 (packedSelected [1,3,7,14,15,16,24,27,28,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38789 : packedSelected [1,3,7,14,15,16,24,27,28,38] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0