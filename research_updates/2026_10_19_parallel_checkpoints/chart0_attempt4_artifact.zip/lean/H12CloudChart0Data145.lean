import H12CloudChart0Data144

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans36777_36778 : H12AffineEnvironment.transform 15 8202 env36777 = env36778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36777 == env36778) = true)

theorem identity36778 : scanCanonicalize (H12AffineFastState.compose env36778 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36778 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env36779 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10281,1024,8460,4113,33,17,2,8193,17,146461,5393,4096,138293,1285,32,256,32,5377,513]

theorem envBound36779 : H12AffineFastState.Bounded env36779 := by
  intro p hp
  have h : env36779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36778_36779 : H12AffineEnvironment.transform 5 17 env36778 = env36779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36778 == env36779) = true)

theorem identity36779 : scanCanonicalize (H12AffineFastState.compose env36779 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound36779 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36780 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8202,13341,10281,1024,8460,4113,33,17,2,8193,17,2048,5393,4096,10280,1285,32,256,32,5377,513]

theorem envBound36780 : H12AffineFastState.Bounded env36780 := by
  intro p hp
  have h : env36780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36779_36780 : H12AffineEnvironment.transform 16 13341 env36779 = env36780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env36779 == env36780) = true)

theorem identity36780 : scanCanonicalize (H12AffineFastState.compose env36780 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound36780 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36781 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,5377,8461,8202,13341,9245,1024,8460,4113,33,17,2,8193,17,1076,5393,4096,9244,1285,32,256,32,5377,513]

theorem envBound36781 : H12AffineFastState.Bounded env36781 := by
  intro p hp
  have h : env36781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36780_36781 : H12AffineEnvironment.transform 10 1076 env36780 = env36781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env36780 == env36781) = true)

theorem identity36781 : scanCanonicalize (H12AffineFastState.compose env36781 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound36781 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36782 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,16,8192,1297,8461,8202,9229,9245,1024,8460,1,33,17,2,8193,17,1076,1281,16,9244,1285,32,256,32,1297,513]

theorem envBound36782 : H12AffineFastState.Bounded env36782 := by
  intro p hp
  have h : env36782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36781_36782 : H12AffineEnvironment.transform 11 16 env36781 = env36782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36781 == env36782) = true)

theorem identity36782 : scanCanonicalize (H12AffineFastState.compose env36782 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36782 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env36783 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,16,41,1297,292,35,1060,1076,1024,293,1,33,17,2,40,17,1076,1281,16,1077,1285,32,256,32,1297,513]

theorem envBound36783 : H12AffineFastState.Bounded env36783 := by
  intro p hp
  have h : env36783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36782_36783 : H12AffineEnvironment.transform 12 41 env36782 = env36783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36782 == env36783) = true)

theorem identity36783 : scanCanonicalize (H12AffineFastState.compose env36783 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36783 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env36784 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1076,16,41,1076,1,35,1060,1076,1024,0,1,33,17,2,40,17,1076,1060,16,1077,1056,32,37,32,1076,513]

theorem envBound36784 : H12AffineFastState.Bounded env36784 := by
  intro p hp
  have h : env36784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36783_36784 : H12AffineEnvironment.transform 7 37 env36783 = env36784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36783 == env36784) = true)

theorem identity36784 : scanCanonicalize (H12AffineFastState.compose env36784 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36785 : List Nat := [2,4,8,1,32,0,9,37,512,1024,1061,1,41,1061,1,35,1060,1061,1024,0,1,33,0,2,40,0,1061,1060,1,1060,1056,32,37,32,1061,513]

theorem envBound36785 : H12AffineFastState.Bounded env36785 := by
  intro p hp
  have h : env36785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36784_36785 : H12AffineEnvironment.transform 3 1 env36784 = env36785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36784 == env36785) = true)

theorem identity36785 : scanCanonicalize (H12AffineFastState.compose env36785 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound36785 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36786 : List Nat := [2,4,8,1,32,0,9,37,512,549,512,1,41,512,1,35,513,512,549,0,1,33,0,2,40,0,512,513,1,513,517,32,37,32,512,513]

theorem envBound36786 : H12AffineFastState.Bounded env36786 := by
  intro p hp
  have h : env36786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36785_36786 : H12AffineEnvironment.transform 9 549 env36785 = env36786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env36785 == env36786) = true)

def env36787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,2175049,8328,64,2609267,46277,77955,2598354,119179,2101345,256,2199863,2191507,63069]

theorem envBound36787 : H12AffineFastState.Bounded env36787 := by
  intro p hp
  have h : env36787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36712_36787 : H12AffineEnvironment.transform 23 2175049 env36712 = env36787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175049 env36712 == env36787) = true)

def env36788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101481,2175187,2175049,8328,64,2590067,46277,77955,2598354,99467,2101345,256,2199863,2172307,41821]

theorem envBound36788 : H12AffineFastState.Bounded env36788 := by
  intro p hp
  have h : env36788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36787_36788 : H12AffineEnvironment.transform 13 5376 env36787 = env36788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36787 == env36788) = true)

theorem identity36788 : scanCanonicalize (H12AffineFastState.compose env36788 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36788 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,2097152,2101481,2175187,2175049,8328,64,2565167,5529,77955,2557070,75223,2101345,256,2175083,2172307,513]

theorem envBound36789 : H12AffineFastState.Bounded env36789 := by
  intro p hp
  have h : env36789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36788_36789 : H12AffineEnvironment.transform 14 8540 env36788 = env36789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36788 == env36789) = true)

def env36790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,2097152,2101481,2175187,2175049,8328,64,2296975,5529,77955,2305070,75223,2101345,256,2175083,2172307,513]

theorem envBound36790 : H12AffineFastState.Bounded env36790 := by
  intro p hp
  have h : env36790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36789_36790 : H12AffineEnvironment.transform 17 10400 env36789 = env36790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env36789 == env36790) = true)

def env36791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1024,8541,2097152,2101345,2175067,2175049,8192,64,2296839,5393,77835,2305070,75103,2101345,256,2175083,2172187,513]

theorem envBound36791 : H12AffineFastState.Bounded env36791 := by
  intro p hp
  have h : env36791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36790_36791 : H12AffineEnvironment.transform 6 8 env36790 = env36791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36790 == env36791) = true)

theorem identity36791 : scanCanonicalize (H12AffineFastState.compose env36791 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound36791 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,79130,10280,1024,8541,2097152,2101345,2175067,2175049,8192,64,2111773,5393,77835,2103604,75103,2101345,256,2175083,2172187,513]

theorem envBound36792 : H12AffineFastState.Bounded env36792 := by
  intro p hp
  have h : env36792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36791_36792 : H12AffineEnvironment.transform 16 79130 env36791 = env36792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env36791 == env36792) = true)

theorem identity36792 : scanCanonicalize (H12AffineFastState.compose env36792 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound36792 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,9498,4096,10280,1024,8541,2097152,2101345,2102593,2102611,8192,64,2111773,5393,5393,2103604,69,2101345,256,2102641,2097153,513]

theorem envBound36793 : H12AffineFastState.Bounded env36793 := by
  intro p hp
  have h : env36793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36792_36793 : H12AffineEnvironment.transform 15 9498 env36792 = env36793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env36792 == env36793) = true)

theorem identity36793 : scanCanonicalize (H12AffineFastState.compose env36793 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound36793 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env36794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,3344,8540,9498,2064,10280,1024,8541,2097152,2099313,2100561,2100547,8192,64,2105613,3329,3329,2097444,69,2099313,256,2100577,2097153,513]

theorem envBound36794 : H12AffineFastState.Bounded env36794 := by
  intro p hp
  have h : env36794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36793_36794 : H12AffineEnvironment.transform 11 2064 env36793 = env36794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env36793 == env36794) = true)

def env36795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,2097152,2101344,2175066,2175049,8193,64,2296838,5392,77834,2305070,75102,2101345,256,2175083,2172186,513]

theorem envBound36795 : H12AffineFastState.Bounded env36795 := by
  intro p hp
  have h : env36795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36790_36795 : H12AffineEnvironment.transform 6 9 env36790 = env36795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36790 == env36795) = true)

theorem identity36795 : scanCanonicalize (H12AffineFastState.compose env36795 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 77850) := by decide +kernel

theorem selectedBound36795 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env36796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,77850,73850,64,83,8193,64,146460,5392,77834,138292,75102,73851,256,113,5376,513]

theorem envBound36796 : H12AffineFastState.Bounded env36796 := by
  intro p hp
  have h : env36796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36795_36796 : H12AffineEnvironment.transform 20 77850 env36795 = env36796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77850 env36795 == env36796) = true)

theorem identity36796 : scanCanonicalize (H12AffineFastState.compose env36796 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36796 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env36797 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10281,1024,8541,4112,112,64,83,8193,64,146460,5392,4096,138292,1364,113,256,113,5376,513]

theorem envBound36797 : H12AffineFastState.Bounded env36797 := by
  intro p hp
  have h : env36797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36796_36797 : H12AffineEnvironment.transform 15 8202 env36796 = env36797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36796 == env36797) = true)

theorem identity36797 : scanCanonicalize (H12AffineFastState.compose env36797 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36797 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env36798 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,10281,1024,8460,4112,33,17,2,8193,17,146460,5392,4096,138292,1285,32,256,32,5376,513]

theorem envBound36798 : H12AffineFastState.Bounded env36798 := by
  intro p hp
  have h : env36798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36797_36798 : H12AffineEnvironment.transform 5 17 env36797 = env36798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36797 == env36798) = true)

theorem identity36798 : scanCanonicalize (H12AffineFastState.compose env36798 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound36798 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36799 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8202,13340,10281,1024,8460,4112,33,17,2,8193,17,2048,5392,4096,10280,1285,32,256,32,5376,513]

theorem envBound36799 : H12AffineFastState.Bounded env36799 := by
  intro p hp
  have h : env36799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36798_36799 : H12AffineEnvironment.transform 16 13340 env36798 = env36799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env36798 == env36799) = true)

theorem identity36799 : scanCanonicalize (H12AffineFastState.compose env36799 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 3385) := by decide +kernel

theorem selectedBound36799 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36800 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,3385,5376,3124,3379,6437,1296,1024,3125,4112,33,17,2,3384,17,2048,5392,4096,1297,1285,32,256,32,5376,513]

theorem envBound36800 : H12AffineFastState.Bounded env36800 := by
  intro p hp
  have h : env36800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36799_36800 : H12AffineEnvironment.transform 12 3385 env36799 = env36800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3385 env36799 == env36800) = true)

theorem identity36800 : scanCanonicalize (H12AffineFastState.compose env36800 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound36800 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36801 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,16,3385,1296,3124,3379,2357,1296,1024,3125,0,33,17,2,3384,17,2048,1280,16,1297,1285,32,256,32,1296,513]

theorem envBound36801 : H12AffineFastState.Bounded env36801 := by
  intro p hp
  have h : env36801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36800_36801 : H12AffineEnvironment.transform 11 16 env36800 = env36801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36800 == env36801) = true)

theorem identity36801 : scanCanonicalize (H12AffineFastState.compose env36801 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36801 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env36802 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,16,3100,1077,3124,3094,2064,1077,1024,3125,0,33,17,2,3101,17,2048,1061,16,1076,1056,32,37,32,1077,513]

theorem envBound36802 : H12AffineFastState.Bounded env36802 := by
  intro p hp
  have h : env36802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36801_36802 : H12AffineEnvironment.transform 7 37 env36801 = env36802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36801 == env36802) = true)

def env36803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,2097152,2101481,2175187,2175049,8328,64,2296974,5529,77955,2305071,75223,2101345,256,2175083,2172307,513]

theorem envBound36803 : H12AffineFastState.Bounded env36803 := by
  intro p hp
  have h : env36803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36789_36803 : H12AffineEnvironment.transform 17 10401 env36789 = env36803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env36789 == env36803) = true)

theorem identity36803 : scanCanonicalize (H12AffineFastState.compose env36803 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 78019) := by decide +kernel

theorem selectedBound36803 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,78019,73770,16,138,8328,64,146509,5529,77955,138476,75223,73890,256,168,5456,513]

theorem envBound36804 : H12AffineFastState.Bounded env36804 := by
  intro p hp
  have h : env36804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36803_36804 : H12AffineEnvironment.transform 20 78019 env36803 = env36804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78019 env36803 == env36804) = true)

theorem identity36804 : scanCanonicalize (H12AffineFastState.compose env36804 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound36804 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,79130,10401,1024,8541,78019,73770,16,138,8328,64,67927,5529,77955,76278,75223,73890,256,168,5456,513]

theorem envBound36805 : H12AffineFastState.Bounded env36805 := by
  intro p hp
  have h : env36805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36804_36805 : H12AffineEnvironment.transform 16 79130 env36804 = env36805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env36804 == env36805) = true)

theorem identity36805 : scanCanonicalize (H12AffineFastState.compose env36805 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound36805 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,9498,4096,10401,1024,8541,5593,1328,16,138,8328,64,11341,5529,5529,3308,205,1464,256,168,5456,513]

theorem envBound36806 : H12AffineFastState.Bounded env36806 := by
  intro p hp
  have h : env36806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36805_36806 : H12AffineEnvironment.transform 15 9498 env36805 = env36806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env36805 == env36806) = true)

theorem identity36806 : scanCanonicalize (H12AffineFastState.compose env36806 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound36806 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env36807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5376,428,1514,4096,2129,1024,429,5593,1328,16,138,120,64,3261,5529,5529,3308,205,1464,256,168,5456,513]

theorem envBound36807 : H12AffineFastState.Bounded env36807 := by
  intro p hp
  have h : env36807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36806_36807 : H12AffineEnvironment.transform 12 240 env36806 = env36807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env36806 == env36807) = true)

theorem identity36807 : scanCanonicalize (H12AffineFastState.compose env36807 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound36807 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36808 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,240,4588,428,262,4096,2129,236,429,4405,476,16,138,120,64,2129,4469,4469,2048,205,340,256,168,4540,513]

theorem envBound36808 : H12AffineFastState.Bounded env36808 := by
  intro p hp
  have h : env36808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36807_36808 : H12AffineEnvironment.transform 9 236 env36807 = env36808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env36807 == env36808) = true)

theorem identity36808 : scanCanonicalize (H12AffineFastState.compose env36808 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound36808 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env36809 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,2492,240,2128,428,262,2492,2129,236,429,2185,476,16,138,120,64,2129,2249,2249,2048,205,340,256,168,2048,513]

theorem envBound36809 : H12AffineFastState.Bounded env36809 := by
  intro p hp
  have h : env36809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36808_36809 : H12AffineEnvironment.transform 11 2492 env36808 = env36809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env36808 == env36809) = true)

theorem identity36809 : scanCanonicalize (H12AffineFastState.compose env36809 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound36809 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env36810 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,2112,240,2128,80,250,2112,2129,236,81,2185,32,16,138,120,64,2129,2249,2249,2048,205,168,252,168,2048,513]

theorem envBound36810 : H12AffineFastState.Bounded env36810 := by
  intro p hp
  have h : env36810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36809_36810 : H12AffineEnvironment.transform 7 252 env36809 = env36810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env36809 == env36810) = true)

theorem identity36810 : scanCanonicalize (H12AffineFastState.compose env36810 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound36810 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36811 : List Nat := [2,4,8,16,32,64,89,37,512,53,2048,2112,41,2128,80,35,2112,2129,53,81,2128,32,16,83,120,64,2129,2064,2064,2048,20,113,37,113,2048,513]

theorem envBound36811 : H12AffineFastState.Bounded env36811 := by
  intro p hp
  have h : env36811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36810_36811 : H12AffineEnvironment.transform 6 89 env36810 = env36811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env36810 == env36811) = true)

theorem identity36811 : scanCanonicalize (H12AffineFastState.compose env36811 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound36811 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36812 : List Nat := [2,4,8,16,32,64,89,37,49,53,2048,2112,41,2128,80,35,2112,2129,53,81,2128,32,16,83,120,64,2129,2064,2064,2048,20,113,37,113,2048,48]

theorem envBound36812 : H12AffineFastState.Bounded env36812 := by
  intro p hp
  have h : env36812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36811_36812 : H12AffineEnvironment.transform 8 49 env36811 = env36812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env36811 == env36812) = true)

theorem identity36812 : scanCanonicalize (H12AffineFastState.compose env36812 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound36812 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36813 : List Nat := [2,4,8,16,32,64,89,37,49,53,80,16,41,0,80,35,16,1,53,81,0,32,16,83,120,64,1,64,64,80,20,113,37,113,80,48]

theorem envBound36813 : H12AffineFastState.Bounded env36813 := by
  intro p hp
  have h : env36813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36812_36813 : H12AffineEnvironment.transform 10 80 env36812 = env36813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env36812 == env36813) = true)

theorem identity36813 : scanCanonicalize (H12AffineFastState.compose env36813 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36813 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36814 : List Nat := [2,4,8,16,32,16,9,37,49,53,0,16,41,0,0,35,16,1,53,1,0,32,16,3,40,16,1,16,16,0,20,33,37,33,0,48]

theorem envBound36814 : H12AffineFastState.Bounded env36814 := by
  intro p hp
  have h : env36814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36813_36814 : H12AffineEnvironment.transform 5 16 env36813 = env36814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36813 == env36814) = true)

theorem identity36814 : scanCanonicalize (H12AffineFastState.compose env36814 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36814 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36815 : List Nat := [2,4,8,0,32,0,9,37,33,37,0,0,41,0,0,35,0,1,37,1,0,32,0,3,40,0,1,0,0,0,4,33,37,33,0,32]

theorem envBound36815 : H12AffineFastState.Bounded env36815 := by
  intro p hp
  have h : env36815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36814_36815 : H12AffineEnvironment.transform 3 0 env36814 = env36815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36814 == env36815) = true)

def env36816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101480,2175186,2175049,8328,64,2590066,46277,77955,2598354,99466,2101345,256,2199863,2172306,41820]

theorem envBound36816 : H12AffineFastState.Bounded env36816 := by
  intro p hp
  have h : env36816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36787_36816 : H12AffineEnvironment.transform 13 5377 env36787 = env36816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36787 == env36816) = true)

theorem identity36816 : scanCanonicalize (H12AffineFastState.compose env36816 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45340) := by decide +kernel

theorem selectedBound36816 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45340,41460,98766,98645,8328,64,472174,46277,77955,464078,99466,41341,256,73771,103566,41820]

theorem envBound36817 : H12AffineFastState.Bounded env36817 := by
  intro p hp
  have h : env36817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36816_36817 : H12AffineEnvironment.transform 20 45340 env36816 = env36817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45340 env36816 == env36817) = true)

def env36818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45340,41340,98630,98645,8192,64,472174,46157,77835,463942,99330,41341,256,73771,103430,41820]

theorem envBound36818 : H12AffineFastState.Bounded env36818 := by
  intro p hp
  have h : env36818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36817_36818 : H12AffineEnvironment.transform 6 8 env36817 = env36818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36817 == env36818) = true)

theorem identity36818 : scanCanonicalize (H12AffineFastState.compose env36818 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound36818 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103494,262144,1024,32769,45340,41340,98630,98645,8192,64,303144,46157,77835,294912,99330,41341,256,73771,103430,41820]

theorem envBound36819 : H12AffineFastState.Bounded env36819 := by
  intro p hp
  have h : env36819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36818_36819 : H12AffineEnvironment.transform 16 103494 env36818 = env36819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env36818 == env36819) = true)

theorem identity36819 : scanCanonicalize (H12AffineFastState.compose env36819 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36819 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79131,262144,1024,8540,4161,33,73755,73736,8192,64,262517,5392,77835,270685,75103,32,256,73771,79195,513]

theorem envBound36820 : H12AffineFastState.Bounded env36820 := by
  intro p hp
  have h : env36820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36819_36820 : H12AffineEnvironment.transform 14 8541 env36819 = env36820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36819 == env36820) = true)

theorem identity36820 : scanCanonicalize (H12AffineFastState.compose env36820 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36820 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36821 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8312,65536,78910,262144,1024,8313,4161,33,73755,73736,8192,64,262224,5173,77835,270456,74874,32,37,73771,78974,513]

theorem envBound36821 : H12AffineFastState.Bounded env36821 := by
  intro p hp
  have h : env36821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36820_36821 : H12AffineEnvironment.transform 7 37 env36820 = env36821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36820 == env36821) = true)

theorem identity36821 : scanCanonicalize (H12AffineFastState.compose env36821 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound36821 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36822 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8312,9279,4097,262144,1024,8313,4161,33,1060,1079,8192,64,262224,5173,5172,270456,69,32,37,1044,4161,513]

theorem envBound36822 : H12AffineFastState.Bounded env36822 := by
  intro p hp
  have h : env36822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36821_36822 : H12AffineEnvironment.transform 15 9279 env36821 = env36822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env36821 == env36822) = true)

theorem identity36822 : scanCanonicalize (H12AffineFastState.compose env36822 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36822 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36823 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8312,9279,4097,10281,1024,8313,4161,33,1060,1079,8192,64,10361,5173,5172,2129,69,32,37,1044,4161,513]

theorem envBound36823 : H12AffineFastState.Bounded env36823 := by
  intro p hp
  have h : env36823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36822_36823 : H12AffineEnvironment.transform 17 10281 env36822 = env36823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36822 == env36823) = true)

theorem identity36823 : scanCanonicalize (H12AffineFastState.compose env36823 (packedSelected [0,1,3,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3684) := by decide +kernel

theorem selectedBound36823 : packedSelected [0,1,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env36824 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3684,8192,2624,8312,9279,3685,10281,1024,8313,3621,33,1060,1079,8192,64,10361,2641,2640,2129,69,32,37,1044,3621,513]

theorem envBound36824 : H12AffineFastState.Bounded env36824 := by
  intro p hp
  have h : env36824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36823_36824 : H12AffineEnvironment.transform 11 3684 env36823 = env36824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3684 env36823 == env36824) = true)

theorem identity36824 : scanCanonicalize (H12AffineFastState.compose env36824 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound36824 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env36825 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1077,593,8192,1653,8312,9279,592,9244,1024,8313,528,33,1060,1079,8192,64,9292,1636,1637,1124,69,32,37,1044,528,513]

theorem envBound36825 : H12AffineFastState.Bounded env36825 := by
  intro p hp
  have h : env36825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36824_36825 : H12AffineEnvironment.transform 10 1077 env36824 = env36825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env36824 == env36825) = true)

theorem identity36825 : scanCanonicalize (H12AffineFastState.compose env36825 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound36825 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env36826 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1077,593,105,1653,17,1110,592,1141,1024,16,528,33,1060,1079,105,64,1061,1636,1637,1124,69,32,37,1044,528,513]

theorem envBound36826 : H12AffineFastState.Bounded env36826 := by
  intro p hp
  have h : env36826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36825_36826 : H12AffineEnvironment.transform 12 105 env36825 = env36826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env36825 == env36826) = true)

theorem identity36826 : scanCanonicalize (H12AffineFastState.compose env36826 (packedSelected [0,1,2,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound36826 : packedSelected [0,1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env36827 : List Nat := [2,4,8,16,32,64,8,37,65,1024,1077,16,105,1076,17,1110,17,1141,1024,16,81,33,1060,1079,105,64,1061,1061,1060,1124,69,32,37,1044,81,64]

theorem envBound36827 : H12AffineFastState.Bounded env36827 := by
  intro p hp
  have h : env36827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36826_36827 : H12AffineEnvironment.transform 8 65 env36826 = env36827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env36826 == env36827) = true)

theorem identity36827 : scanCanonicalize (H12AffineFastState.compose env36827 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36827 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env36828 : List Nat := [2,4,8,16,32,64,8,37,65,53,0,16,105,1,17,99,17,64,53,16,81,33,17,2,105,64,16,16,17,81,69,32,37,33,81,64]

theorem envBound36828 : H12AffineFastState.Bounded env36828 := by
  intro p hp
  have h : env36828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36827_36828 : H12AffineEnvironment.transform 9 53 env36827 = env36828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36827 == env36828) = true)

theorem identity36828 : scanCanonicalize (H12AffineFastState.compose env36828 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36828 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36829 : List Nat := [2,4,8,16,1,64,8,4,65,20,0,16,72,1,17,66,17,64,20,16,81,0,17,2,72,64,16,16,17,81,69,1,4,0,81,64]

theorem envBound36829 : H12AffineFastState.Bounded env36829 := by
  intro p hp
  have h : env36829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36828_36829 : H12AffineEnvironment.transform 4 1 env36828 = env36829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36828 == env36829) = true)

theorem identity36829 : scanCanonicalize (H12AffineFastState.compose env36829 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36829 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36830 : List Nat := [2,4,8,16,1,17,8,4,16,20,0,16,25,1,17,19,17,17,20,16,0,0,17,2,25,17,16,16,17,0,20,1,4,0,0,17]

theorem envBound36830 : H12AffineFastState.Bounded env36830 := by
  intro p hp
  have h : env36830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36829_36830 : H12AffineEnvironment.transform 5 17 env36829 = env36830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36829 == env36830) = true)

def env36831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45340,41341,98631,98645,8193,64,472174,46156,77834,463943,99331,41341,256,73771,103431,41820]

theorem envBound36831 : H12AffineFastState.Bounded env36831 := by
  intro p hp
  have h : env36831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36817_36831 : H12AffineEnvironment.transform 6 9 env36817 = env36831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36817 == env36831) = true)

theorem identity36831 : scanCanonicalize (H12AffineFastState.compose env36831 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound36831 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,262144,1024,32769,45340,41341,98631,98645,8193,64,262517,46156,77834,270684,99331,41341,256,73771,103431,41820]

theorem envBound36832 : H12AffineFastState.Bounded env36832 := by
  intro p hp
  have h : env36832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36831_36832 : H12AffineEnvironment.transform 16 79131 env36831 = env36832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env36831 == env36832) = true)

theorem identity36832 : scanCanonicalize (H12AffineFastState.compose env36832 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36832 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env36833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,10281,1024,32769,45340,41341,98631,98645,8193,64,10588,46156,77834,2421,99331,41341,256,73771,103431,41820]

theorem envBound36833 : H12AffineFastState.Bounded env36833 := by
  intro p hp
  have h : env36833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36832_36833 : H12AffineEnvironment.transform 17 10281 env36832 = env36833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36832 == env36833) = true)

theorem identity36833 : scanCanonicalize (H12AffineFastState.compose env36833 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound36833 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,343,13388,10281,1024,32769,45340,41341,32784,32770,8193,64,10588,46156,12637,2421,34132,41341,256,8572,38224,41820]

theorem envBound36834 : H12AffineFastState.Bounded env36834 := by
  intro p hp
  have h : env36834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36833_36834 : H12AffineEnvironment.transform 15 343 env36833 = env36834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env36833 == env36834) = true)

theorem identity36834 : scanCanonicalize (H12AffineFastState.compose env36834 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36834 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env36835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,32768,343,5393,2420,1024,32769,36929,32800,32784,32770,348,64,2049,38161,4096,2421,34132,32800,256,33,38224,33281]

theorem envBound36835 : H12AffineFastState.Bounded env36835 := by
  intro p hp
  have h : env36835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36834_36835 : H12AffineEnvironment.transform 12 349 env36834 = env36835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36834 == env36835) = true)

theorem identity36835 : scanCanonicalize (H12AffineFastState.compose env36835 (packedSelected [2,4,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound36835 : packedSelected [2,4,9,12,15] rootPS < 2^1333 := by decide +kernel

def env36836 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,4096,349,4145,32768,343,4129,2420,304,32769,36929,32800,32784,32770,348,64,2049,36897,4096,2421,32868,32800,256,33,36960,33281]

theorem envBound36836 : H12AffineFastState.Bounded env36836 := by
  intro p hp
  have h : env36836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36835_36836 : H12AffineEnvironment.transform 9 304 env36835 = env36836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env36835 == env36836) = true)

def env36837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound36837 : H12AffineFastState.Bounded env36837 := by
  intro p hp
  have h : env36837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36621_36837 : H12AffineEnvironment.transform 18 1025 env36621 = env36837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env36621 == env36837) = true)

theorem identity36837 : scanCanonicalize (H12AffineFastState.compose env36837 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2262355) := by decide +kernel

theorem selectedBound36837 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2262355,8328,64,15025490,197086,10507600,8830976,10682690,4448402,257,8602111,8626266,10626709]

theorem envBound36838 : H12AffineFastState.Bounded env36838 := by
  intro p hp
  have h : env36838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36837_36838 : H12AffineEnvironment.transform 23 2262355 env36837 = env36838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2262355 env36837 == env36838) = true)

def env36839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15025490,115150,10507600,8650768,10600786,4268162,257,8487407,8478794,10544773]

theorem envBound36839 : H12AffineFastState.Bounded env36839 := by
  intro p hp
  have h : env36839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36838_36839 : H12AffineEnvironment.transform 16 49168 env36838 = env36839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env36838 == env36839) = true)

def env36840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4543746,115150,17664,2363456,119042,4268162,257,2199999,2191386,63189]

theorem envBound36840 : H12AffineFastState.Bounded env36840 := by
  intro p hp
  have h : env36840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36839_36840 : H12AffineEnvironment.transform 22 2101328 env36839 = env36840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env36839 == env36840) = true)

def env36841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,97666,115150,17664,2363456,119042,329730,257,2199999,2191386,63189]

theorem envBound36841 : H12AffineFastState.Bounded env36841 := by
  intro p hp
  have h : env36841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36840_36841 : H12AffineEnvironment.transform 21 272512 env36840 = env36841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env36840 == env36841) = true)

theorem identity36841 : scanCanonicalize (H12AffineFastState.compose env36841 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound36841 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115871,272512,120015,98780,8328,64,97666,115150,17664,382175,119042,329730,257,21792,46213,63189]

theorem envBound36842 : H12AffineFastState.Bounded env36842 := by
  intro p hp
  have h : env36842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36841_36842 : H12AffineEnvironment.transform 20 115871 env36841 = env36842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env36841 == env36842) = true)

def env36843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115735,272392,119879,98644,8192,64,97546,115014,17664,382039,119042,329730,257,21792,46093,63069]

theorem envBound36843 : H12AffineFastState.Bounded env36843 := by
  intro p hp
  have h : env36843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36842_36843 : H12AffineEnvironment.transform 6 8 env36842 = env36843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36842 == env36843) = true)

theorem identity36843 : scanCanonicalize (H12AffineFastState.compose env36843 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36843 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env36844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,65536,49168,262144,1025,32769,115735,264453,119879,98644,269,64,89095,115014,17664,382039,119042,329730,257,21792,38144,55120]

theorem envBound36844 : H12AffineFastState.Bounded env36844 := by
  intro p hp
  have h : env36844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36843_36844 : H12AffineEnvironment.transform 12 269 env36843 = env36844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36843 == env36844) = true)

theorem identity36844 : scanCanonicalize (H12AffineFastState.compose env36844 (packedSelected [1,10,26,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36844 : packedSelected [1,10,26,28] rootPS < 2^1333 := by decide +kernel

def env36845 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,65536,49168,262144,1025,32769,115735,264453,119830,98565,269,17,89095,114967,17664,381958,119042,329730,257,21792,38144,55041]

theorem envBound36845 : H12AffineFastState.Bounded env36845 := by
  intro p hp
  have h : env36845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36844_36845 : H12AffineEnvironment.transform 5 17 env36844 = env36845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36844 == env36845) = true)

theorem identity36845 : scanCanonicalize (H12AffineFastState.compose env36845 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,17,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound36845 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,17,22,24] rootPS < 2^1333 := by decide +kernel

def env36846 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21760,65536,5392,262144,1025,21761,69911,264453,65814,87045,269,17,89095,70679,17664,327942,66562,329730,257,21792,16384,513]

theorem envBound36846 : H12AffineFastState.Bounded env36846 := by
  intro p hp
  have h : env36846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36845_36846 : H12AffineEnvironment.transform 14 21760 env36845 = env36846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env36845 == env36846) = true)

theorem identity36846 : scanCanonicalize (H12AffineFastState.compose env36846 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound36846 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36847 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21760,262,5392,262144,1025,21761,4113,264453,16,21763,269,17,23809,5393,17664,262144,1284,264452,257,21792,16384,513]

theorem envBound36847 : H12AffineFastState.Bounded env36847 := by
  intro p hp
  have h : env36847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36846_36847 : H12AffineEnvironment.transform 15 262 env36846 = env36847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env36846 == env36847) = true)

theorem identity36847 : scanCanonicalize (H12AffineFastState.compose env36847 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound36847 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36848 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21760,262,5392,23589,1025,21761,4113,21792,16,21763,269,17,23809,5393,17664,23589,1284,21793,257,21792,16384,513]

theorem envBound36848 : H12AffineFastState.Bounded env36848 := by
  intro p hp
  have h : env36848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36847_36848 : H12AffineEnvironment.transform 17 23589 env36847 = env36848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env36847 == env36848) = true)

theorem identity36848 : scanCanonicalize (H12AffineFastState.compose env36848 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36848 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env36849 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5392,2340,1025,0,4113,33,16,2,269,17,2048,5393,4097,2340,1284,32,257,33,5377,513]

theorem envBound36849 : H12AffineFastState.Bounded env36849 := by
  intro p hp
  have h : env36849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36848_36849 : H12AffineEnvironment.transform 13 5377 env36848 = env36849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36848 == env36849) = true)

theorem identity36849 : scanCanonicalize (H12AffineFastState.compose env36849 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36850 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5157,1,34,5172,2048,1025,0,4113,33,16,2,41,17,2048,5173,4097,2048,1056,32,37,33,5157,513]

theorem envBound36850 : H12AffineFastState.Bounded env36850 := by
  intro p hp
  have h : env36850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36849_36850 : H12AffineEnvironment.transform 7 36 env36849 = env36850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36849 == env36850) = true)

def env36851 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,41,1045,1,34,1028,2048,1025,0,33,33,16,2,41,17,2048,1029,49,2048,1056,32,37,33,1045,513]

theorem envBound36851 : H12AffineFastState.Bounded env36851 := by
  intro p hp
  have h : env36851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36850_36851 : H12AffineEnvironment.transform 11 48 env36850 = env36851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36850 == env36851) = true)

theorem identity36851 : scanCanonicalize (H12AffineFastState.compose env36851 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36852 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,48,41,1045,1,34,1028,0,1025,0,33,33,16,2,41,17,0,1029,49,0,1056,32,37,33,1045,513]

theorem envBound36852 : H12AffineFastState.Bounded env36852 := by
  intro p hp
  have h : env36852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36851_36852 : H12AffineEnvironment.transform 10 0 env36851 = env36852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36851 == env36852) = true)

def env36853 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,48,41,33,1,34,48,0,53,0,33,33,16,2,41,17,0,49,49,0,20,32,37,33,33,513]

theorem envBound36853 : H12AffineFastState.Bounded env36853 := by
  intro p hp
  have h : env36853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36852_36853 : H12AffineEnvironment.transform 9 52 env36852 = env36853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36852 == env36853) = true)

theorem identity36853 : scanCanonicalize (H12AffineFastState.compose env36853 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound36853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36854 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,48,41,33,1,34,48,0,53,0,33,33,16,2,41,17,0,49,49,0,20,32,37,33,33,10]

theorem envBound36854 : H12AffineFastState.Bounded env36854 := by
  intro p hp
  have h : env36854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36853_36854 : H12AffineEnvironment.transform 8 11 env36853 = env36854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env36853 == env36854) = true)

def leafEnv36854 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,48,41,33,1,34,48,0,53,0,33,33,16,2,21,41,1,17,0,49,49,0,20,32,37,33,5,34,33,10,1,33,0]

def active36854 : List Nat := [0,1,2,3,4]

def tree36854 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36854 : H12WitnessSearch.Good tree36854 := H12GlobalWitnessIndex.good

theorem leafIdentity36854 : H12AffineFastState.composeSystem env36854 rootObs = leafEnv36854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36854 rootObs == leafEnv36854) = true)

theorem terminalChecked36854 : H12PackedTerminal.terminalCheckFast leafEnv36854 active36854 tree36854 = true := by decide +kernel

def env36855 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,41,32,1,34,49,0,52,0,33,33,16,2,41,17,0,48,49,0,21,32,37,33,32,513]

theorem envBound36855 : H12AffineFastState.Bounded env36855 := by
  intro p hp
  have h : env36855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36852_36855 : H12AffineEnvironment.transform 9 53 env36852 = env36855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36852 == env36855) = true)

theorem identity36855 : scanCanonicalize (H12AffineFastState.compose env36855 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36855 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36856 : List Nat := [2,4,8,16,0,17,8,4,512,21,0,16,9,0,1,2,17,0,20,0,1,1,16,2,9,17,0,16,17,0,21,0,5,1,0,513]

theorem envBound36856 : H12AffineFastState.Bounded env36856 := by
  intro p hp
  have h : env36856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36855_36856 : H12AffineEnvironment.transform 4 0 env36855 = env36856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36855 == env36856) = true)

def leafEnv36856 : List Nat := [2,4,8,16,0,17,8,4,512,21,0,16,9,0,1,2,17,0,20,0,1,1,16,2,20,9,1,17,0,16,17,0,21,0,5,1,5,2,0,513,1,1,0]

def active36856 : List Nat := [0,1,2,3,8]

def tree36856 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36856 : H12WitnessSearch.Good tree36856 := H12GlobalWitnessIndex.good

theorem leafIdentity36856 : H12AffineFastState.composeSystem env36856 rootObs = leafEnv36856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36856 rootObs == leafEnv36856) = true)

theorem terminalChecked36856 : H12PackedTerminal.terminalCheckFast leafEnv36856 active36856 tree36856 = true := by decide +kernel

def env36857 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,41,1044,1,34,1029,2048,1025,0,32,33,16,2,41,17,2048,1028,48,2048,1056,32,37,33,1044,513]

theorem envBound36857 : H12AffineFastState.Bounded env36857 := by
  intro p hp
  have h : env36857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36850_36857 : H12AffineEnvironment.transform 11 49 env36850 = env36857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36850 == env36857) = true)

theorem identity36857 : scanCanonicalize (H12AffineFastState.compose env36857 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound36857 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36858 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,49,41,1044,1,34,1029,1076,1025,0,32,33,16,2,41,17,1076,1028,48,1076,1056,32,37,33,1044,513]

theorem envBound36858 : H12AffineFastState.Bounded env36858 := by
  intro p hp
  have h : env36858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36857_36858 : H12AffineEnvironment.transform 10 1076 env36857 = env36858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env36857 == env36858) = true)

def env36859 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,41,32,1,34,49,0,53,0,32,33,16,2,41,17,0,48,48,0,20,32,37,33,32,513]

theorem envBound36859 : H12AffineFastState.Bounded env36859 := by
  intro p hp
  have h : env36859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36858_36859 : H12AffineEnvironment.transform 9 52 env36858 = env36859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36858 == env36859) = true)

theorem identity36859 : scanCanonicalize (H12AffineFastState.compose env36859 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound36859 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36860 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,49,41,32,1,34,49,0,53,0,32,33,16,2,41,17,0,48,48,0,20,32,37,33,32,10]

theorem envBound36860 : H12AffineFastState.Bounded env36860 := by
  intro p hp
  have h : env36860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36859_36860 : H12AffineEnvironment.transform 8 11 env36859 = env36860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env36859 == env36860) = true)

def leafEnv36860 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,49,41,32,1,34,49,0,53,0,32,33,16,2,21,41,1,17,0,48,48,0,20,32,37,33,5,34,32,10,1,32,0]

def active36860 : List Nat := [0,1,2,3,4]

def tree36860 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36860 : H12WitnessSearch.Good tree36860 := H12GlobalWitnessIndex.good

theorem leafIdentity36860 : H12AffineFastState.composeSystem env36860 rootObs = leafEnv36860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36860 rootObs == leafEnv36860) = true)

theorem terminalChecked36860 : H12PackedTerminal.terminalCheckFast leafEnv36860 active36860 tree36860 = true := by decide +kernel

def env36861 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,49,41,33,1,34,48,1,52,0,32,33,16,2,41,17,1,49,48,1,21,32,37,33,33,513]

theorem envBound36861 : H12AffineFastState.Bounded env36861 := by
  intro p hp
  have h : env36861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36858_36861 : H12AffineEnvironment.transform 9 53 env36858 = env36861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36858 == env36861) = true)

theorem identity36861 : scanCanonicalize (H12AffineFastState.compose env36861 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36861 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36862 : List Nat := [2,4,8,16,0,17,8,4,512,21,1,17,9,1,1,2,16,1,20,0,0,1,16,2,9,17,1,17,16,1,21,0,5,1,1,513]

theorem envBound36862 : H12AffineFastState.Bounded env36862 := by
  intro p hp
  have h : env36862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36861_36862 : H12AffineEnvironment.transform 4 0 env36861 = env36862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36861 == env36862) = true)

def leafEnv36862 : List Nat := [2,4,8,16,0,17,8,4,512,21,1,17,9,1,1,2,16,1,20,0,0,1,16,2,20,9,1,17,1,17,16,1,21,0,5,1,5,2,1,513,1,0,0]

def active36862 : List Nat := [0,1,2,3,8]

def tree36862 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36862 : H12WitnessSearch.Good tree36862 := H12GlobalWitnessIndex.good

theorem leafIdentity36862 : H12AffineFastState.composeSystem env36862 rootObs = leafEnv36862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36862 rootObs == leafEnv36862) = true)

theorem terminalChecked36862 : H12PackedTerminal.terminalCheckFast leafEnv36862 active36862 tree36862 = true := by decide +kernel

def env36863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115734,272393,119878,98645,8193,64,97547,115015,17664,382038,119042,329730,257,21792,46092,63068]

theorem envBound36863 : H12AffineFastState.Bounded env36863 := by
  intro p hp
  have h : env36863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36842_36863 : H12AffineEnvironment.transform 6 9 env36842 = env36863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36842 == env36863) = true)

theorem identity36863 : scanCanonicalize (H12AffineFastState.compose env36863 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 62511) := by decide +kernel

theorem selectedBound36863 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env36864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62511,49168,262144,1025,32769,12345,272393,8297,30074,8193,64,35108,13672,17664,270457,9517,326701,257,21792,46092,63068]

theorem envBound36864 : H12AffineFastState.Bounded env36864 := by
  intro p hp
  have h : env36864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36863_36864 : H12AffineEnvironment.transform 15 62511 env36863 = env36864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62511 env36863 == env36864) = true)

theorem identity36864 : scanCanonicalize (H12AffineFastState.compose env36864 (packedSelected [1,2,3,4,6,8,11,12,14,15,16,17,19,22,23,24,26,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound36864 : packedSelected [1,2,3,4,6,8,11,12,14,15,16,17,19,22,23,24,26,31,35] rootPS < 2^1333 := by decide +kernel

def env36865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,30043,16740,262144,1025,373,12345,272393,8297,30074,8193,64,2128,13672,17664,270457,9517,294233,257,21792,13688,30504]

theorem envBound36865 : H12AffineFastState.Bounded env36865 := by
  intro p hp
  have h : env36865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36864_36865 : H12AffineEnvironment.transform 14 372 env36864 = env36865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env36864 == env36865) = true)

theorem identity36865 : scanCanonicalize (H12AffineFastState.compose env36865 (packedSelected [0,2,3,5,6,7,10,11,12,15,17,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound36865 : packedSelected [0,2,3,5,6,7,10,11,12,15,17,20,23] rootPS < 2^1333 := by decide +kernel

def env36866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,30043,16740,23808,1025,373,12345,29961,8297,30074,8193,64,2128,13672,17664,32121,9517,8281,257,21792,13688,30504]

theorem envBound36866 : H12AffineFastState.Bounded env36866 := by
  intro p hp
  have h : env36866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36865_36866 : H12AffineEnvironment.transform 17 23808 env36865 = env36866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env36865 == env36866) = true)

theorem identity36866 : scanCanonicalize (H12AffineFastState.compose env36866 (packedSelected [2,3,5,6,11,12,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound36866 : packedSelected [2,3,5,6,11,12,14,16,19] rootPS < 2^1333 := by decide +kernel

def env36867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2128,372,15627,2356,5456,1025,373,12345,15705,8297,15658,8193,64,2128,13672,3408,13609,9517,8281,257,7536,13688,16248]

theorem envBound36867 : H12AffineFastState.Bounded env36867 := by
  intro p hp
  have h : env36867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36866_36867 : H12AffineEnvironment.transform 13 2128 env36866 = env36867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env36866 == env36867) = true)

theorem identity36867 : scanCanonicalize (H12AffineFastState.compose env36867 (packedSelected [0,1,2,4,6,7,8,9,10,14,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound36867 : packedSelected [0,1,2,4,6,7,8,9,10,14,15,17] rootPS < 2^1333 := by decide +kernel

def env36868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,4096,8192,1077,372,12654,1361,5456,1025,373,12345,12604,8297,12623,8193,64,1077,13672,309,13609,9517,8281,257,4373,13688,13085]

theorem envBound36868 : H12AffineFastState.Bounded env36868 := by
  intro p hp
  have h : env36868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36867_36868 : H12AffineEnvironment.transform 10 1125 env36867 = env36868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env36867 == env36868) = true)

theorem identity36868 : scanCanonicalize (H12AffineFastState.compose env36868 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound36868 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env36869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,16,8192,1077,372,8574,1361,1344,1025,373,8233,8492,8297,8543,8193,64,1077,9592,309,9529,9517,8281,257,261,9576,8973]

theorem envBound36869 : H12AffineFastState.Bounded env36869 := by
  intro p hp
  have h : env36869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36868_36869 : H12AffineEnvironment.transform 11 16 env36868 = env36869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36868 == env36869) = true)

theorem identity36869 : scanCanonicalize (H12AffineFastState.compose env36869 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound36869 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36870 : List Nat := [2,4,8,16,32,64,9,256,512,321,292,16,8192,372,372,8574,16,1,320,373,8233,8492,8297,8543,8193,64,372,8249,309,8312,8300,8281,257,261,8233,8973]

theorem envBound36870 : H12AffineFastState.Bounded env36870 := by
  intro p hp
  have h : env36870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36869_36870 : H12AffineEnvironment.transform 9 321 env36869 = env36870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36869 == env36870) = true)

theorem identity36870 : scanCanonicalize (H12AffineFastState.compose env36870 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36870 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env36871 : List Nat := [2,4,8,16,32,64,9,117,512,52,81,16,8192,1,1,8203,16,1,53,0,8233,8281,8297,8234,8193,64,1,8249,64,8312,8300,8281,116,112,8233,8824]

theorem envBound36871 : H12AffineFastState.Bounded env36871 := by
  intro p hp
  have h : env36871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36870_36871 : H12AffineEnvironment.transform 7 117 env36870 = env36871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36870 == env36871) = true)

theorem identity36871 : scanCanonicalize (H12AffineFastState.compose env36871 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound36871 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36872 : List Nat := [2,4,8,16,32,64,9,117,512,52,81,16,120,1,1,115,16,1,53,0,81,33,17,82,121,64,1,65,64,0,20,33,116,112,81,512]

theorem envBound36872 : H12AffineFastState.Bounded env36872 := by
  intro p hp
  have h : env36872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36871_36872 : H12AffineEnvironment.transform 12 120 env36871 = env36872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env36871 == env36872) = true)

theorem identity36872 : scanCanonicalize (H12AffineFastState.compose env36872 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound36872 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36873 : List Nat := [2,4,8,16,32,49,9,4,512,52,32,16,9,1,1,2,16,1,53,0,32,33,17,35,8,49,1,48,49,0,20,33,5,1,32,512]

theorem envBound36873 : H12AffineFastState.Bounded env36873 := by
  intro p hp
  have h : env36873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36872_36873 : H12AffineEnvironment.transform 5 49 env36872 = env36873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env36872 == env36873) = true)

theorem identity36873 : scanCanonicalize (H12AffineFastState.compose env36873 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound36873 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36874 : List Nat := [2,4,8,16,8,25,9,4,512,28,8,16,9,1,1,2,16,1,29,0,8,9,17,11,8,25,1,24,25,0,20,9,5,1,8,512]

theorem envBound36874 : H12AffineFastState.Bounded env36874 := by
  intro p hp
  have h : env36874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36873_36874 : H12AffineEnvironment.transform 4 8 env36873 = env36874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env36873 == env36874) = true)

theorem identity36874 : scanCanonicalize (H12AffineFastState.compose env36874 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound36874 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36875 : List Nat := [2,4,8,16,8,25,9,4,3,28,8,16,9,1,1,2,16,1,29,0,8,9,17,11,8,25,1,24,25,0,20,9,5,1,8,3]

theorem envBound36875 : H12AffineFastState.Bounded env36875 := by
  intro p hp
  have h : env36875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36874_36875 : H12AffineEnvironment.transform 8 3 env36874 = env36875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env36874 == env36875) = true)

theorem identity36875 : scanCanonicalize (H12AffineFastState.compose env36875 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound36875 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env36876 : List Nat := [2,4,1,16,1,16,0,4,3,21,1,16,0,1,1,2,16,1,20,0,1,0,17,2,1,16,1,17,16,0,20,0,5,1,1,3]

theorem envBound36876 : H12AffineFastState.Bounded env36876 := by
  intro p hp
  have h : env36876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36875_36876 : H12AffineEnvironment.transform 2 1 env36875 = env36876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env36875 == env36876) = true)

theorem identity36876 : scanCanonicalize (H12AffineFastState.compose env36876 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound36876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36877 : List Nat := [2,4,1,7,1,7,0,4,3,2,1,7,0,1,1,2,7,1,3,0,1,0,6,2,1,7,1,6,7,0,3,0,5,1,1,3]

theorem envBound36877 : H12AffineFastState.Bounded env36877 := by
  intro p hp
  have h : env36877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36876_36877 : H12AffineEnvironment.transform 3 7 env36876 = env36877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env36876 == env36877) = true)

def env36878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,97667,115150,17664,2363456,119042,329731,257,2199999,2191386,63189]

theorem envBound36878 : H12AffineFastState.Bounded env36878 := by
  intro p hp
  have h : env36878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36840_36878 : H12AffineEnvironment.transform 21 272513 env36840 = env36878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env36840 == env36878) = true)

theorem identity36878 : scanCanonicalize (H12AffineFastState.compose env36878 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound36878 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49168,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,43357,5392,17664,2363456,1500,318685,257,2114913,2139332,63189]

theorem envBound36879 : H12AffineFastState.Bounded env36879 := by
  intro p hp
  have h : env36879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36878_36879 : H12AffineEnvironment.transform 15 54494 env36878 = env36879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env36878 == env36879) = true)

theorem identity36879 : scanCanonicalize (H12AffineFastState.compose env36879 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound36879 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env36880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,13508,262144,1025,29909,2097152,272513,2101328,2114883,8328,64,23945,5392,17664,2363456,1500,272393,257,2114913,2117648,513]

theorem envBound36880 : H12AffineFastState.Bounded env36880 := by
  intro p hp
  have h : env36880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36879_36880 : H12AffineEnvironment.transform 14 29908 env36879 = env36880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env36879 == env36880) = true)

theorem identity36880 : scanCanonicalize (H12AffineFastState.compose env36880 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound36880 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,13508,23668,1025,29909,2097152,29941,2101328,2114883,8328,64,23945,5392,17664,2116660,1500,29821,257,2114913,2117648,513]

theorem envBound36881 : H12AffineFastState.Bounded env36881 := by
  intro p hp
  have h : env36881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36880_36881 : H12AffineEnvironment.transform 17 23668 env36880 = env36881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env36880 == env36881) = true)

theorem identity36881 : scanCanonicalize (H12AffineFastState.compose env36881 (packedSelected [1,2,5,6,8,12,15,17,24,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound36881 : packedSelected [1,2,5,6,8,12,15,17,24,38,41] rootPS < 2^1333 := by decide +kernel

def env36882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8580,8202,13508,2340,1025,8581,2097152,8613,2101328,2101267,8328,64,2265,5392,4176,2103652,1500,8493,257,2101297,2098496,513]

theorem envBound36882 : H12AffineFastState.Bounded env36882 := by
  intro p hp
  have h : env36882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36881_36882 : H12AffineEnvironment.transform 13 5456 env36881 = env36882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env36881 == env36882) = true)

theorem identity36882 : scanCanonicalize (H12AffineFastState.compose env36882 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36882 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env36883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5456,137,263,5577,2340,1025,136,2097152,168,2101328,2101267,389,64,2265,5392,4176,2103652,1500,32,257,2101297,2098496,513]

theorem envBound36883 : H12AffineFastState.Bounded env36883 := by
  intro p hp
  have h : env36883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36882_36883 : H12AffineEnvironment.transform 12 269 env36882 = env36883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36882 == env36883) = true)

theorem identity36883 : scanCanonicalize (H12AffineFastState.compose env36883 (packedSelected [3,4,5,9,10,14,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound36883 : packedSelected [3,4,5,9,10,14,16,17] rootPS < 2^1333 := by decide +kernel

def env36884 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5456,81,263,5393,2340,1025,80,2097152,112,2101328,2101267,349,64,2049,5392,4176,2103652,1284,32,257,2101297,2098496,513]

theorem envBound36884 : H12AffineFastState.Bounded env36884 := by
  intro p hp
  have h : env36884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36883_36884 : H12AffineEnvironment.transform 6 88 env36883 = env36884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env36883 == env36884) = true)

theorem identity36884 : scanCanonicalize (H12AffineFastState.compose env36884 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound36884 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36885 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5456,81,263,5393,2340,1025,80,4161,112,17,82,349,64,2049,5392,4176,2341,1284,32,257,112,5377,513]

theorem envBound36885 : H12AffineFastState.Bounded env36885 := by
  intro p hp
  have h : env36885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36884_36885 : H12AffineEnvironment.transform 20 4161 env36884 = env36885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36884 == env36885) = true)

theorem identity36885 : scanCanonicalize (H12AffineFastState.compose env36885 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound36885 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env36886 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1141,269,293,81,263,356,2340,1025,80,1076,112,17,82,349,64,2049,357,1061,2341,1284,32,257,112,372,513]

theorem envBound36886 : H12AffineFastState.Bounded env36886 := by
  intro p hp
  have h : env36886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36885_36886 : H12AffineEnvironment.transform 11 1141 env36885 = env36886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env36885 == env36886) = true)

theorem identity36886 : scanCanonicalize (H12AffineFastState.compose env36886 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound36886 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env36887 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1344,1141,269,293,81,263,356,1124,1025,80,1076,112,17,82,349,64,1345,357,1061,1125,1284,32,257,112,372,513]

theorem envBound36887 : H12AffineFastState.Bounded env36887 := by
  intro p hp
  have h : env36887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36886_36887 : H12AffineEnvironment.transform 10 1344 env36886 = env36887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env36886 == env36887) = true)

theorem identity36887 : scanCanonicalize (H12AffineFastState.compose env36887 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36887 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env36888 : List Nat := [2,4,8,16,32,64,88,117,512,1024,1077,1141,120,80,81,114,17,1124,1025,80,1076,112,17,82,40,64,1076,16,1061,1125,1137,32,116,112,1,513]

theorem envBound36888 : H12AffineFastState.Bounded env36888 := by
  intro p hp
  have h : env36888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36887_36888 : H12AffineEnvironment.transform 7 117 env36887 = env36888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36887 == env36888) = true)

def env36889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4543747,115150,17665,2363457,119043,4268162,257,2199998,2191387,63188]

theorem envBound36889 : H12AffineFastState.Bounded env36889 := by
  intro p hp
  have h : env36889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36839_36889 : H12AffineEnvironment.transform 22 2101329 env36839 = env36889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env36839 == env36889) = true)

def env36890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,97667,115150,17665,2363457,119043,329730,257,2199998,2191387,63188]

theorem envBound36890 : H12AffineFastState.Bounded env36890 := by
  intro p hp
  have h : env36890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36889_36890 : H12AffineEnvironment.transform 21 272512 env36889 = env36890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env36889 == env36890) = true)

theorem identity36890 : scanCanonicalize (H12AffineFastState.compose env36890 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound36890 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77898,272512,73755,95497,8328,64,97667,115150,17665,335883,119043,329730,257,41460,16465,63188]

theorem envBound36891 : H12AffineFastState.Bounded env36891 := by
  intro p hp
  have h : env36891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36890_36891 : H12AffineEnvironment.transform 20 77898 env36890 = env36891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env36890 == env36891) = true)

def env36892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10400,1025,32769,77898,32,73755,95497,8328,64,97667,115150,17665,67755,119043,73890,257,41460,16465,63188]

theorem envBound36892 : H12AffineFastState.Bounded env36892 := by
  intro p hp
  have h : env36892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36891_36892 : H12AffineEnvironment.transform 17 10400 env36891 = env36892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env36891 == env36892) = true)

theorem identity36892 : scanCanonicalize (H12AffineFastState.compose env36892 (packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound36892 : packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS < 2^1333 := by decide +kernel

def env36893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,32768,65536,49168,2184,1025,32769,69730,32,65587,87329,160,64,89515,115150,17665,67755,119043,65674,257,33244,16465,55036]

theorem envBound36893 : H12AffineFastState.Bounded env36893 := by
  intro p hp
  have h : env36893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36892_36893 : H12AffineEnvironment.transform 12 40 env36892 = env36893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env36892 == env36893) = true)

theorem identity36893 : scanCanonicalize (H12AffineFastState.compose env36893 (packedSelected [1,2,4,5,6,7,8,11,14,16,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound36893 : packedSelected [1,2,4,5,6,7,8,11,14,16,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5236,32768,65536,37988,2184,1025,32769,69730,32,65587,65877,160,64,68063,103866,4469,67755,99703,65674,257,33244,5157,33416]

theorem envBound36894 : H12AffineFastState.Bounded env36894 := by
  intro p hp
  have h : env36894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36893_36894 : H12AffineEnvironment.transform 13 5236 env36893 = env36894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env36893 == env36894) = true)

theorem identity36894 : scanCanonicalize (H12AffineFastState.compose env36894 (packedSelected [0,1,4,5,7,10,12,15,16,17,18,19,20,22,23,24,26,28] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound36894 : packedSelected [0,1,4,5,7,10,12,15,16,17,18,19,20,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env36895 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,32768,65536,37988,2184,1025,32769,69730,32,65587,65705,160,64,67619,103494,4233,67755,99467,65674,253,32800,5157,33416]

theorem envBound36895 : H12AffineFastState.Bounded env36895 := by
  intro p hp
  have h : env36895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36894_36895 : H12AffineEnvironment.transform 7 252 env36894 = env36895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env36894 == env36895) = true)

theorem identity36895 : scanCanonicalize (H12AffineFastState.compose env36895 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound36895 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36896 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,32768,171,37988,2184,1025,32769,4297,32,152,2,160,64,2184,38125,4233,2048,33824,33,253,32800,5157,33416]

theorem envBound36896 : H12AffineFastState.Bounded env36896 := by
  intro p hp
  have h : env36896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36895_36896 : H12AffineEnvironment.transform 15 171 env36895 = env36896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env36895 == env36896) = true)

theorem identity36896 : scanCanonicalize (H12AffineFastState.compose env36896 (packedSelected [2,3,4,5,6,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound36896 : packedSelected [2,3,4,5,6,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36897 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,136,171,5356,2184,1025,137,4297,32,152,2,160,64,2184,5221,4233,2048,1192,33,253,168,5157,512]

theorem envBound36897 : H12AffineFastState.Bounded env36897 := by
  intro p hp
  have h : env36897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36896_36897 : H12AffineEnvironment.transform 14 136 env36896 = env36897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env36896 == env36897) = true)

theorem identity36897 : scanCanonicalize (H12AffineFastState.compose env36897 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36897 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36898 : List Nat := [2,4,8,16,0,64,128,220,512,1024,2048,4096,8,5204,136,139,5324,2184,1025,137,4297,0,152,2,128,64,2184,5189,4233,2048,1160,1,221,136,5125,512]

theorem envBound36898 : H12AffineFastState.Bounded env36898 := by
  intro p hp
  have h : env36898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36897_36898 : H12AffineEnvironment.transform 4 0 env36897 = env36898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36897 == env36898) = true)

theorem identity36898 : scanCanonicalize (H12AffineFastState.compose env36898 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 205) := by decide +kernel

theorem selectedBound36898 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env36899 : List Nat := [2,4,8,16,0,64,128,220,512,205,2048,4096,8,4249,136,139,4097,2184,204,137,4297,0,152,2,128,64,2184,4232,4233,2048,69,1,221,136,4296,512]

theorem envBound36899 : H12AffineFastState.Bounded env36899 := by
  intro p hp
  have h : env36899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36898_36899 : H12AffineEnvironment.transform 9 205 env36898 = env36899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 205 env36898 == env36899) = true)

theorem identity36899 : scanCanonicalize (H12AffineFastState.compose env36899 (packedSelected [1,2,3,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36899 : packedSelected [1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env36900 : List Nat := [2,4,8,16,0,64,8,84,512,69,2048,4096,8,4113,0,3,4097,2048,68,1,4161,0,16,2,8,64,2048,4096,4097,2048,69,1,85,0,4160,512]

theorem envBound36900 : H12AffineFastState.Bounded env36900 := by
  intro p hp
  have h : env36900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36899_36900 : H12AffineEnvironment.transform 6 8 env36899 = env36900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36899 == env36900) = true)

theorem identity36900 : scanCanonicalize (H12AffineFastState.compose env36900 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36900 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36901 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,4096,8,4113,0,3,4097,2048,20,1,4113,0,16,2,8,16,2048,4096,4097,2048,21,1,5,0,4112,512]

theorem envBound36901 : H12AffineFastState.Bounded env36901 := by
  intro p hp
  have h : env36901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36900_36901 : H12AffineEnvironment.transform 5 16 env36900 = env36901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36900 == env36901) = true)

theorem identity36901 : scanCanonicalize (H12AffineFastState.compose env36901 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound36901 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36902 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,2065,8,2048,0,3,2064,2048,20,1,2048,0,16,2,8,16,2048,2065,2064,2048,21,1,5,0,2049,512]

theorem envBound36902 : H12AffineFastState.Bounded env36902 := by
  intro p hp
  have h : env36902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36901_36902 : H12AffineEnvironment.transform 11 2065 env36901 = env36902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env36901 == env36902) = true)

theorem identity36902 : scanCanonicalize (H12AffineFastState.compose env36902 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound36902 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36903 : List Nat := [2,4,8,16,0,16,8,4,512,21,5,20,8,5,0,3,21,5,20,1,5,0,16,2,8,16,5,20,21,5,21,1,5,0,4,512]

theorem envBound36903 : H12AffineFastState.Bounded env36903 := by
  intro p hp
  have h : env36903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36902_36903 : H12AffineEnvironment.transform 10 5 env36902 = env36903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env36902 == env36903) = true)

def env36904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10401,1025,32769,77898,33,73755,95497,8328,64,97667,115150,17665,67754,119043,73891,257,41460,16465,63188]

theorem envBound36904 : H12AffineFastState.Bounded env36904 := by
  intro p hp
  have h : env36904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36891_36904 : H12AffineEnvironment.transform 17 10401 env36891 = env36904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env36891 == env36904) = true)

theorem identity36904 : scanCanonicalize (H12AffineFastState.compose env36904 (packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound36904 : packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS < 2^1333 := by decide +kernel

def env36905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,398,49168,10401,1025,32769,12740,33,8597,29831,8328,64,31757,49216,17665,2340,53389,8493,257,41460,16465,63188]

theorem envBound36905 : H12AffineFastState.Bounded env36905 := by
  intro p hp
  have h : env36905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36904_36905 : H12AffineEnvironment.transform 15 398 env36904 = env36905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env36904 == env36905) = true)

theorem identity36905 : scanCanonicalize (H12AffineFastState.compose env36905 (packedSelected [2,3,4,5,6,7,10,11,12,14,15,19,22,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36905 : packedSelected [2,3,4,5,6,7,10,11,12,14,15,19,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env36906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,398,49168,2476,1025,32769,4297,33,152,21898,389,64,23808,49216,17665,2340,53389,32,257,33017,16465,55257]

theorem envBound36906 : H12AffineFastState.Bounded env36906 := by
  intro p hp
  have h : env36906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36905_36906 : H12AffineEnvironment.transform 12 269 env36905 = env36906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36905 == env36906) = true)

theorem identity36906 : scanCanonicalize (H12AffineFastState.compose env36906 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound36906 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env36907 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,32768,343,49168,2421,1025,32769,4112,33,65,21843,348,64,23808,49216,17665,2340,53332,32,257,32800,16465,55040]

theorem envBound36907 : H12AffineFastState.Bounded env36907 := by
  intro p hp
  have h : env36907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36906_36907 : H12AffineEnvironment.transform 6 89 env36906 = env36907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env36906 == env36907) = true)

theorem identity36907 : scanCanonicalize (H12AffineFastState.compose env36907 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound36907 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36908 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5457,32768,343,38209,2421,1025,32769,4112,33,65,2,348,64,2129,38161,4176,2340,34053,32,257,32800,5376,33361]

theorem envBound36908 : H12AffineFastState.Bounded env36908 := by
  intro p hp
  have h : env36908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36907_36908 : H12AffineEnvironment.transform 13 5457 env36907 = env36908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env36907 == env36908) = true)

theorem identity36908 : scanCanonicalize (H12AffineFastState.compose env36908 (packedSelected [2,3,4,5,6,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound36908 : packedSelected [2,3,4,5,6,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36909 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5457,373,343,5172,2421,1025,372,4112,33,65,2,348,64,2129,5220,4176,2340,1136,32,257,341,5376,804]

theorem envBound36909 : H12AffineFastState.Bounded env36909 := by
  intro p hp
  have h : env36909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36908_36909 : H12AffineEnvironment.transform 14 373 env36908 = env36909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env36908 == env36909) = true)

theorem identity36909 : scanCanonicalize (H12AffineFastState.compose env36909 (packedSelected [2,4,6,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36909 : packedSelected [2,4,6,9,14] rootPS < 2^1333 := by decide +kernel

def env36910 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,292,262,5172,2340,1025,293,4112,33,16,2,269,17,2048,5173,4097,2340,1057,32,257,260,5376,804]

theorem envBound36910 : H12AffineFastState.Bounded env36910 := by
  intro p hp
  have h : env36910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36909_36910 : H12AffineEnvironment.transform 5 17 env36909 = env36910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36909 == env36910) = true)

theorem identity36910 : scanCanonicalize (H12AffineFastState.compose env36910 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36910 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env36911 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,1,35,5172,2049,1025,0,4112,33,16,2,40,17,2048,5173,4097,2049,1057,32,36,33,5157,513]

theorem envBound36911 : H12AffineFastState.Bounded env36911 := by
  intro p hp
  have h : env36911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36910_36911 : H12AffineEnvironment.transform 7 37 env36910 = env36911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36910 == env36911) = true)

def env36912 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1045,1,35,1028,2049,1025,0,32,33,16,2,40,17,2048,1029,49,2049,1057,32,36,33,1045,513]

theorem envBound36912 : H12AffineFastState.Bounded env36912 := by
  intro p hp
  have h : env36912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36911_36912 : H12AffineEnvironment.transform 11 48 env36911 = env36912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36911 == env36912) = true)

theorem identity36912 : scanCanonicalize (H12AffineFastState.compose env36912 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound36912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36913 : List Nat := [2,4,8,16,32,17,8,37,512,548,2048,48,40,561,1,35,544,2049,549,0,32,33,16,2,40,17,2048,545,49,2049,517,32,36,33,561,513]

theorem envBound36913 : H12AffineFastState.Bounded env36913 := by
  intro p hp
  have h : env36913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36912_36913 : H12AffineEnvironment.transform 9 548 env36912 = env36913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env36912 == env36913) = true)

def env36914 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,48,40,33,1,35,48,2049,53,0,32,33,16,2,40,17,2048,49,49,2049,21,32,36,33,33,17]

theorem envBound36914 : H12AffineFastState.Bounded env36914 := by
  intro p hp
  have h : env36914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36913_36914 : H12AffineEnvironment.transform 8 16 env36913 = env36914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36913 == env36914) = true)

theorem identity36914 : scanCanonicalize (H12AffineFastState.compose env36914 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound36914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36915 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,48,40,33,1,35,48,27,53,0,32,33,16,2,40,17,26,49,49,27,21,32,36,33,33,17]

theorem envBound36915 : H12AffineFastState.Bounded env36915 := by
  intro p hp
  have h : env36915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36914_36915 : H12AffineEnvironment.transform 10 26 env36914 = env36915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env36914 == env36915) = true)

def leafEnv36915 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,48,40,33,1,35,48,27,53,0,32,33,16,2,20,40,1,17,26,49,49,27,21,32,36,33,5,35,33,17,1,32,0]

def active36915 : List Nat := [0,1,2,3,4]

def tree36915 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36915 : H12WitnessSearch.Good tree36915 := H12GlobalWitnessIndex.good

theorem leafIdentity36915 : H12AffineFastState.composeSystem env36915 rootObs = leafEnv36915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36915 rootObs == leafEnv36915) = true)

theorem terminalChecked36915 : H12PackedTerminal.terminalCheckFast leafEnv36915 active36915 tree36915 = true := by decide +kernel

def env36916 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,48,40,32,1,35,49,2049,52,0,32,33,16,2,40,17,2048,48,49,2049,20,32,36,33,32,16]

theorem envBound36916 : H12AffineFastState.Bounded env36916 := by
  intro p hp
  have h : env36916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36913_36916 : H12AffineEnvironment.transform 8 17 env36913 = env36916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36913 == env36916) = true)

theorem identity36916 : scanCanonicalize (H12AffineFastState.compose env36916 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound36916 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36917 : List Nat := [2,4,8,16,32,17,8,37,17,53,32,48,40,32,1,35,49,33,52,0,32,33,16,2,40,17,32,48,49,33,20,32,36,33,32,16]

theorem envBound36917 : H12AffineFastState.Bounded env36917 := by
  intro p hp
  have h : env36917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36916_36917 : H12AffineEnvironment.transform 10 32 env36916 = env36917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env36916 == env36917) = true)

def leafEnv36917 : List Nat := [2,4,8,16,32,17,8,37,17,53,32,48,40,32,1,35,49,33,52,0,32,33,16,2,21,40,1,17,32,48,49,33,20,32,36,33,5,35,32,16,1,32,0]

def active36917 : List Nat := [0,1,2,3,4]

def tree36917 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36917 : H12WitnessSearch.Good tree36917 := H12GlobalWitnessIndex.good

theorem leafIdentity36917 : H12AffineFastState.composeSystem env36917 rootObs = leafEnv36917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36917 rootObs == leafEnv36917) = true)

theorem terminalChecked36917 : H12PackedTerminal.terminalCheckFast leafEnv36917 active36917 tree36917 = true := by decide +kernel

def env36918 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1044,1,35,1029,2049,1025,0,33,33,16,2,40,17,2048,1028,48,2049,1057,32,36,33,1044,513]

theorem envBound36918 : H12AffineFastState.Bounded env36918 := by
  intro p hp
  have h : env36918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36911_36918 : H12AffineEnvironment.transform 11 49 env36911 = env36918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36911 == env36918) = true)

theorem identity36918 : scanCanonicalize (H12AffineFastState.compose env36918 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36918 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36919 : List Nat := [2,4,8,16,32,17,8,37,16,1024,2048,49,40,1044,1,35,1029,2049,1025,0,33,33,16,2,40,17,2048,1028,48,2049,1057,32,36,33,1044,17]

theorem envBound36919 : H12AffineFastState.Bounded env36919 := by
  intro p hp
  have h : env36919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36918_36919 : H12AffineEnvironment.transform 8 16 env36918 = env36919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36918 == env36919) = true)

def env36920 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,49,40,32,1,35,49,2049,53,0,33,33,16,2,40,17,2048,48,48,2049,21,32,36,33,32,17]

theorem envBound36920 : H12AffineFastState.Bounded env36920 := by
  intro p hp
  have h : env36920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36919_36920 : H12AffineEnvironment.transform 9 52 env36919 = env36920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36919 == env36920) = true)

theorem identity36920 : scanCanonicalize (H12AffineFastState.compose env36920 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound36920 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36921 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,49,40,32,1,35,49,27,53,0,33,33,16,2,40,17,26,48,48,27,21,32,36,33,32,17]

theorem envBound36921 : H12AffineFastState.Bounded env36921 := by
  intro p hp
  have h : env36921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36920_36921 : H12AffineEnvironment.transform 10 26 env36920 = env36921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env36920 == env36921) = true)

def leafEnv36921 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,49,40,32,1,35,49,27,53,0,33,33,16,2,20,40,1,17,26,48,48,27,21,32,36,33,5,35,32,17,1,33,0]

def active36921 : List Nat := [0,1,2,3,4]

def tree36921 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36921 : H12WitnessSearch.Good tree36921 := H12GlobalWitnessIndex.good

theorem leafIdentity36921 : H12AffineFastState.composeSystem env36921 rootObs = leafEnv36921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36921 rootObs == leafEnv36921) = true)

theorem terminalChecked36921 : H12PackedTerminal.terminalCheckFast leafEnv36921 active36921 tree36921 = true := by decide +kernel

def env36922 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,49,40,33,1,35,48,2049,52,0,33,33,16,2,40,17,2048,49,48,2049,20,32,36,33,33,17]

theorem envBound36922 : H12AffineFastState.Bounded env36922 := by
  intro p hp
  have h : env36922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36919_36922 : H12AffineEnvironment.transform 9 53 env36919 = env36922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36919 == env36922) = true)

theorem identity36922 : scanCanonicalize (H12AffineFastState.compose env36922 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound36922 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36923 : List Nat := [2,4,8,16,32,17,8,37,16,53,33,49,40,33,1,35,48,32,52,0,33,33,16,2,40,17,33,49,48,32,20,32,36,33,33,17]

theorem envBound36923 : H12AffineFastState.Bounded env36923 := by
  intro p hp
  have h : env36923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36922_36923 : H12AffineEnvironment.transform 10 33 env36922 = env36923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env36922 == env36923) = true)

def leafEnv36923 : List Nat := [2,4,8,16,32,17,8,37,16,53,33,49,40,33,1,35,48,32,52,0,33,33,16,2,21,40,1,17,33,49,48,32,20,32,36,33,5,35,33,17,1,33,0]

def active36923 : List Nat := [0,1,2,3,4]

def tree36923 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36923 : H12WitnessSearch.Good tree36923 := H12GlobalWitnessIndex.good

theorem leafIdentity36923 : H12AffineFastState.composeSystem env36923 rootObs = leafEnv36923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36923 rootObs == leafEnv36923) = true)

theorem terminalChecked36923 : H12PackedTerminal.terminalCheckFast leafEnv36923 active36923 tree36923 = true := by decide +kernel

def env36924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,97666,115150,17665,2363457,119043,329731,257,2199998,2191387,63188]

theorem envBound36924 : H12AffineFastState.Bounded env36924 := by
  intro p hp
  have h : env36924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36889_36924 : H12AffineEnvironment.transform 21 272513 env36889 = env36924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env36889 == env36924) = true)

theorem identity36924 : scanCanonicalize (H12AffineFastState.compose env36924 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36924 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,23944,57796,17665,2363457,61705,272393,257,2142644,2117649,63188]

theorem envBound36925 : H12AffineFastState.Bounded env36925 := by
  intro p hp
  have h : env36925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36924_36925 : H12AffineEnvironment.transform 15 8202 env36924 = env36925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36924 == env36925) = true)

def env36926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272393,2101329,2114883,8192,64,23808,57676,17665,2363457,61705,272393,257,2142524,2117649,63068]

theorem envBound36926 : H12AffineFastState.Bounded env36926 := by
  intro p hp
  have h : env36926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36925_36926 : H12AffineEnvironment.transform 6 8 env36925 = env36926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36925 == env36926) = true)

theorem identity36926 : scanCanonicalize (H12AffineFastState.compose env36926 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound36926 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,46156,262144,1025,32769,2097152,272393,2101329,2109727,8192,64,10588,38160,12637,2363457,34133,272393,257,2142524,2106445,33280]

theorem envBound36927 : H12AffineFastState.Bounded env36927 := by
  intro p hp
  have h : env36927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36926_36927 : H12AffineEnvironment.transform 13 13404 env36926 = env36927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env36926 == env36927) = true)

theorem identity36927 : scanCanonicalize (H12AffineFastState.compose env36927 (packedSelected [1,3,4,5,9,10,12,14,17,19,20,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 268596) := by decide +kernel

theorem selectedBound36927 : packedSelected [1,3,4,5,9,10,12,14,17,19,20,28,31,38] rootPS < 2^1333 := by decide +kernel

def env36928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,46156,262144,1025,32769,268596,272393,264549,272427,8192,64,10588,38160,12637,2421,34133,272393,257,305160,277881,33280]

theorem envBound36928 : H12AffineFastState.Bounded env36928 := by
  intro p hp
  have h : env36928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36927_36928 : H12AffineEnvironment.transform 20 268596 env36927 = env36928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268596 env36927 == env36928) = true)

theorem identity36928 : scanCanonicalize (H12AffineFastState.compose env36928 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 34817) := by decide +kernel

theorem selectedBound36928 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env36929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,46156,34817,1025,32769,37173,40968,33124,41002,8192,64,10588,38160,12637,2421,34133,40968,257,8201,46456,33280]

theorem envBound36929 : H12AffineFastState.Bounded env36929 := by
  intro p hp
  have h : env36929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36928_36929 : H12AffineEnvironment.transform 17 34817 env36928 = env36929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34817 env36928 == env36929) = true)

theorem identity36929 : scanCanonicalize (H12AffineFastState.compose env36929 (packedSelected [0,3,4,5,6,7,9,10,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound36929 : packedSelected [0,3,4,5,6,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env36930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,13389,2048,1025,0,4404,8201,357,8235,8192,64,10588,5393,12637,2421,1364,8201,257,8201,13689,513]

theorem envBound36930 : H12AffineFastState.Bounded env36930 := by
  intro p hp
  have h : env36930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36929_36930 : H12AffineEnvironment.transform 14 1 env36929 = env36930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env36929 == env36930) = true)

theorem identity36930 : scanCanonicalize (H12AffineFastState.compose env36930 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound36930 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5236,1,34,5221,2048,1025,0,4404,33,357,3,40,64,2420,5393,4469,2421,1364,33,257,33,5457,513]

theorem envBound36931 : H12AffineFastState.Bounded env36931 := by
  intro p hp
  have h : env36931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36930_36931 : H12AffineEnvironment.transform 12 40 env36930 = env36931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env36930 == env36931) = true)

theorem identity36931 : scanCanonicalize (H12AffineFastState.compose env36931 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound36931 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36932 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,40,4453,1,34,4468,2048,272,0,4404,33,357,3,40,64,2420,4096,4469,2421,69,33,257,33,4160,513]

theorem envBound36932 : H12AffineFastState.Bounded env36932 := by
  intro p hp
  have h : env36932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36931_36932 : H12AffineEnvironment.transform 9 273 env36931 = env36932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env36931 == env36932) = true)

theorem identity36932 : scanCanonicalize (H12AffineFastState.compose env36932 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 315) := by decide +kernel

theorem selectedBound36932 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env36933 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,315,40,94,1,34,79,2048,272,0,15,33,357,3,40,64,2420,315,78,2421,69,33,257,33,379,513]

theorem envBound36933 : H12AffineFastState.Bounded env36933 := by
  intro p hp
  have h : env36933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36932_36933 : H12AffineEnvironment.transform 11 315 env36932 = env36933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 315 env36932 == env36933) = true)

theorem identity36933 : scanCanonicalize (H12AffineFastState.compose env36933 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound36933 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36934 : List Nat := [2,4,8,16,32,64,8,256,512,273,14,315,40,94,1,34,79,14,272,0,15,33,357,3,40,64,378,315,78,379,69,33,257,33,379,513]

theorem envBound36934 : H12AffineFastState.Bounded env36934 := by
  intro p hp
  have h : env36934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36933_36934 : H12AffineEnvironment.transform 10 14 env36933 = env36934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env36933 == env36934) = true)

def env36935 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272392,2101329,2114883,8193,64,23809,57677,17665,2363457,61705,272393,257,2142525,2117649,63069]

theorem envBound36935 : H12AffineFastState.Bounded env36935 := by
  intro p hp
  have h : env36935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36925_36935 : H12AffineEnvironment.transform 6 9 env36925 = env36935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36925 == env36935) = true)

theorem identity36935 : scanCanonicalize (H12AffineFastState.compose env36935 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound36935 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36936 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,17728,272392,21777,3,8193,64,23809,57677,17665,283905,61705,272393,257,62589,5457,63069]

theorem envBound36936 : H12AffineFastState.Bounded env36936 := by
  intro p hp
  have h : env36936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36935_36936 : H12AffineEnvironment.transform 20 17728 env36935 = env36936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env36935 == env36936) = true)

theorem identity36936 : scanCanonicalize (H12AffineFastState.compose env36936 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound36936 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env36937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8202,16401,262144,1025,0,17728,272392,21777,3,8193,64,23809,24908,17665,283905,28936,272393,257,29820,5457,30300]

theorem envBound36937 : H12AffineFastState.Bounded env36937 := by
  intro p hp
  have h : env36937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36936_36937 : H12AffineEnvironment.transform 14 1 env36936 = env36937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env36936 == env36937) = true)

theorem identity36937 : scanCanonicalize (H12AffineFastState.compose env36937 (packedSelected [0,1,3,5,6,7,8,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound36937 : packedSelected [0,1,3,5,6,7,8,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env36938 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8202,13389,262144,1025,0,12572,272392,8525,3,8193,64,10589,5392,12637,270685,1364,272393,257,32,5457,512]

theorem envBound36938 : H12AffineFastState.Bounded env36938 := by
  intro p hp
  have h : env36938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36937_36938 : H12AffineEnvironment.transform 13 13404 env36937 = env36938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env36937 == env36938) = true)

theorem identity36938 : scanCanonicalize (H12AffineFastState.compose env36938 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound36938 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36939 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8202,13389,10589,1025,0,12572,341,8525,3,8193,64,10589,5392,12637,2048,1364,340,257,32,5457,512]

theorem envBound36939 : H12AffineFastState.Bounded env36939 := by
  intro p hp
  have h : env36939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36938_36939 : H12AffineEnvironment.transform 17 10589 env36938 = env36939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env36938 == env36939) = true)

theorem identity36939 : scanCanonicalize (H12AffineFastState.compose env36939 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound36939 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env36940 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5204,1,2,5189,2389,1025,0,4372,341,325,3,9,64,2389,5392,4437,2048,1364,340,257,32,5457,512]

theorem envBound36940 : H12AffineFastState.Bounded env36940 := by
  intro p hp
  have h : env36940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36939_36940 : H12AffineEnvironment.transform 12 8 env36939 = env36940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env36939 == env36940) = true)

theorem identity36940 : scanCanonicalize (H12AffineFastState.compose env36940 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound36940 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env36941 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,1,2,5189,2049,1025,0,4160,1,17,3,9,64,2049,5188,4097,2048,1024,0,85,32,5125,512]

theorem envBound36941 : H12AffineFastState.Bounded env36941 := by
  intro p hp
  have h : env36941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36940_36941 : H12AffineEnvironment.transform 7 84 env36940 = env36941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env36940 == env36941) = true)

theorem identity36941 : scanCanonicalize (H12AffineFastState.compose env36941 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound36941 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36942 : List Nat := [2,4,8,16,32,64,9,84,512,68,2048,4096,8,4112,1,2,4097,2049,69,0,4160,1,17,3,9,64,2049,4096,4097,2048,68,0,85,32,4161,512]

theorem envBound36942 : H12AffineFastState.Bounded env36942 := by
  intro p hp
  have h : env36942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36941_36942 : H12AffineEnvironment.transform 9 68 env36941 = env36942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env36941 == env36942) = true)

theorem identity36942 : scanCanonicalize (H12AffineFastState.compose env36942 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound36942 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36943 : List Nat := [2,4,8,16,32,64,9,84,512,68,2048,49,8,33,1,2,48,2049,69,0,113,1,17,3,9,64,2049,49,48,2048,68,0,85,32,112,512]

theorem envBound36943 : H12AffineFastState.Bounded env36943 := by
  intro p hp
  have h : env36943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36942_36943 : H12AffineEnvironment.transform 11 49 env36942 = env36943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36942 == env36943) = true)

theorem identity36943 : scanCanonicalize (H12AffineFastState.compose env36943 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound36943 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36944 : List Nat := [2,4,8,16,32,64,9,84,512,68,576,49,8,33,1,2,48,577,69,0,113,1,17,3,9,64,577,49,48,576,68,0,85,32,112,512]

theorem envBound36944 : H12AffineFastState.Bounded env36944 := by
  intro p hp
  have h : env36944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36943_36944 : H12AffineEnvironment.transform 10 576 env36943 = env36944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env36943 == env36944) = true)

theorem identity36944 : scanCanonicalize (H12AffineFastState.compose env36944 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound36944 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36945 : List Nat := [2,4,7,16,32,64,6,84,512,68,576,49,7,33,1,2,48,577,69,0,113,1,17,3,6,64,577,49,48,576,68,0,85,32,112,512]

theorem envBound36945 : H12AffineFastState.Bounded env36945 := by
  intro p hp
  have h : env36945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36944_36945 : H12AffineEnvironment.transform 2 7 env36944 = env36945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env36944 == env36945) = true)

def env36946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15025490,115151,10507600,8650769,10600787,4268163,257,8487406,8478795,10544772]

theorem envBound36946 : H12AffineFastState.Bounded env36946 := by
  intro p hp
  have h : env36946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36838_36946 : H12AffineEnvironment.transform 16 49169 env36838 = env36946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env36838 == env36946) = true)

def env36947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4543746,115151,17664,2363457,119043,4268163,257,2199998,2191387,63188]

theorem envBound36947 : H12AffineFastState.Bounded env36947 := by
  intro p hp
  have h : env36947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36946_36947 : H12AffineEnvironment.transform 22 2101328 env36946 = env36947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env36946 == env36947) = true)

def env36948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,97666,115151,17664,2363457,119043,329731,257,2199998,2191387,63188]

theorem envBound36948 : H12AffineFastState.Bounded env36948 := by
  intro p hp
  have h : env36948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36947_36948 : H12AffineEnvironment.transform 21 272512 env36947 = env36948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env36947 == env36948) = true)

def env36949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272392,2101328,2114882,8192,64,97546,115015,17664,2363457,119043,329731,257,2199862,2191387,63068]

theorem envBound36949 : H12AffineFastState.Bounded env36949 := by
  intro p hp
  have h : env36949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36948_36949 : H12AffineEnvironment.transform 6 8 env36948 = env36949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36948 == env36949) = true)

def env36950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,16,21762,8192,64,97546,115015,17664,262145,119043,329731,257,98678,90203,63068]

theorem envBound36950 : H12AffineFastState.Bounded env36950 := by
  intro p hp
  have h : env36950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36949_36950 : H12AffineEnvironment.transform 20 4160 env36949 = env36950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36949 == env36950) = true)

theorem identity36950 : scanCanonicalize (H12AffineFastState.compose env36950 (packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 89459) := by decide +kernel

theorem selectedBound36950 : packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env36951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,89459,1025,32769,4160,95611,16,21762,8192,64,97546,115015,17664,89458,119043,21872,257,98678,90203,63068]

theorem envBound36951 : H12AffineFastState.Bounded env36951 := by
  intro p hp
  have h : env36951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36950_36951 : H12AffineEnvironment.transform 17 89459 env36950 = env36951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89459 env36950 == env36951) = true)

theorem identity36951 : scanCanonicalize (H12AffineFastState.compose env36951 (packedSelected [0,1,3,9,11,15,18,22,23,24,27,28,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound36951 : packedSelected [0,1,3,9,11,15,18,22,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env36952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,65536,13340,89459,1025,29708,4160,95611,16,21762,8192,64,97546,79178,17664,89458,75022,21872,257,95611,90203,593]

theorem envBound36952 : H12AffineFastState.Bounded env36952 := by
  intro p hp
  have h : env36952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36951_36952 : H12AffineEnvironment.transform 14 29709 env36951 = env36952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env36951 == env36952) = true)

theorem identity36952 : scanCanonicalize (H12AffineFastState.compose env36952 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound36952 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env36953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8541,65536,13340,67619,1025,8540,4160,73771,16,82,8192,64,75866,79178,4176,67618,75022,32,257,73771,79115,593]

theorem envBound36953 : H12AffineFastState.Bounded env36953 := by
  intro p hp
  have h : env36953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36952_36953 : H12AffineEnvironment.transform 13 5456 env36952 = env36953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env36952 == env36953) = true)

theorem identity36953 : scanCanonicalize (H12AffineFastState.compose env36953 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36953 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36954 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,65536,13340,67619,1025,8460,4112,73771,16,2,8192,16,75786,79130,4096,67618,75022,32,257,73771,79115,513]

theorem envBound36954 : H12AffineFastState.Bounded env36954 := by
  intro p hp
  have h : env36954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36953_36954 : H12AffineEnvironment.transform 5 16 env36953 = env36954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36953 == env36954) = true)

theorem identity36954 : scanCanonicalize (H12AffineFastState.compose env36954 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36954 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36955 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,13340,10281,1025,8460,4112,33,16,2,8192,16,2048,5392,4096,10280,1284,32,257,33,5377,513]

theorem envBound36955 : H12AffineFastState.Bounded env36955 := by
  intro p hp
  have h : env36955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36954_36955 : H12AffineEnvironment.transform 15 8202 env36954 = env36955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36954 == env36955) = true)

theorem identity36955 : scanCanonicalize (H12AffineFastState.compose env36955 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound36955 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36956 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2097,8192,3377,8461,8202,11309,10281,1025,8460,2081,33,16,2,8192,16,2048,3361,2097,10280,1284,32,257,33,3376,513]

theorem envBound36956 : H12AffineFastState.Bounded env36956 := by
  intro p hp
  have h : env36956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36955_36956 : H12AffineEnvironment.transform 11 2097 env36955 = env36956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env36955 == env36956) = true)

theorem identity36956 : scanCanonicalize (H12AffineFastState.compose env36956 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound36956 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36957 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2097,1305,3377,1044,1299,2356,3376,1025,1045,2081,33,16,2,1305,16,2048,3361,2097,3377,1284,32,257,33,3376,513]

theorem envBound36957 : H12AffineFastState.Bounded env36957 := by
  intro p hp
  have h : env36957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36956_36957 : H12AffineEnvironment.transform 12 1305 env36956 = env36957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env36956 == env36957) = true)

theorem identity36957 : scanCanonicalize (H12AffineFastState.compose env36957 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36957 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env36958 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2097,300,2308,33,294,2356,2309,52,32,2081,33,16,2,300,16,2048,2324,2097,2308,305,32,257,33,2309,513]

theorem envBound36958 : H12AffineFastState.Bounded env36958 := by
  intro p hp
  have h : env36958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36957_36958 : H12AffineEnvironment.transform 9 53 env36957 = env36958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36957 == env36958) = true)

def env36959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,21763,8192,64,97546,115015,17664,262144,119043,329731,257,98679,90202,63068]

theorem envBound36959 : H12AffineFastState.Bounded env36959 := by
  intro p hp
  have h : env36959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36949_36959 : H12AffineEnvironment.transform 20 4161 env36949 = env36959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36949 == env36959) = true)

theorem identity36959 : scanCanonicalize (H12AffineFastState.compose env36959 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36959 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,33,17,21763,8192,64,97546,115015,17664,10281,119043,73770,257,98679,90202,63068]

theorem envBound36960 : H12AffineFastState.Bounded env36960 := by
  intro p hp
  have h : env36960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36959_36960 : H12AffineEnvironment.transform 17 10281 env36959 = env36960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36959 == env36960) = true)

theorem identity36960 : scanCanonicalize (H12AffineFastState.compose env36960 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound36960 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env36961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,49169,10281,1025,32769,4161,33,17,21763,8192,64,56576,24909,17664,10281,28937,32800,257,8573,49232,63068]

theorem envBound36961 : H12AffineFastState.Bounded env36961 := by
  intro p hp
  have h : env36961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36960_36961 : H12AffineEnvironment.transform 15 40970 env36960 = env36961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env36960 == env36961) = true)

theorem identity36961 : scanCanonicalize (H12AffineFastState.compose env36961 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound36961 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16400,10281,1025,0,4161,33,17,21763,8192,64,23809,24909,17664,10281,28937,33,257,8573,16465,30301]

theorem envBound36962 : H12AffineFastState.Bounded env36962 := by
  intro p hp
  have h : env36962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36961_36962 : H12AffineEnvironment.transform 14 1 env36961 = env36962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env36961 == env36962) = true)

theorem identity36962 : scanCanonicalize (H12AffineFastState.compose env36962 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36962 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,342,16400,2420,1025,0,4161,33,17,21763,349,64,23809,16400,17664,2420,20564,33,257,32,16465,22272]

theorem envBound36963 : H12AffineFastState.Bounded env36963 := by
  intro p hp
  have h : env36963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36962_36963 : H12AffineEnvironment.transform 12 349 env36962 = env36963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36962 == env36963) = true)

theorem identity36963 : scanCanonicalize (H12AffineFastState.compose env36963 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound36963 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,1,342,5441,2420,1025,0,4161,33,17,82,349,64,2128,5441,4177,2420,1285,33,257,32,5376,593]

theorem envBound36964 : H12AffineFastState.Bounded env36964 := by
  intro p hp
  have h : env36964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36963_36964 : H12AffineEnvironment.transform 13 5457 env36963 = env36964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env36963 == env36964) = true)

theorem identity36964 : scanCanonicalize (H12AffineFastState.compose env36964 (packedSelected [4,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36964 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env36965 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,5457,1,342,5441,2388,1025,0,4161,1,17,82,349,64,2128,5441,4177,2388,1285,1,257,0,5376,593]

theorem envBound36965 : H12AffineFastState.Bounded env36965 := by
  intro p hp
  have h : env36965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36964_36965 : H12AffineEnvironment.transform 4 0 env36964 = env36965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36964 == env36965) = true)

theorem identity36965 : scanCanonicalize (H12AffineFastState.compose env36965 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36965 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36966 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5377,1,262,5393,2308,1025,0,4113,1,17,2,269,16,2048,5393,4097,2308,1285,1,257,0,5376,513]

theorem envBound36966 : H12AffineFastState.Bounded env36966 := by
  intro p hp
  have h : env36966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36965_36966 : H12AffineEnvironment.transform 5 16 env36965 = env36966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36965 == env36966) = true)

theorem identity36966 : scanCanonicalize (H12AffineFastState.compose env36966 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36967 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,1,3,5140,2049,1025,0,4113,1,17,2,8,16,2048,5140,4097,2049,1024,1,4,0,5125,513]

theorem envBound36967 : H12AffineFastState.Bounded env36967 := by
  intro p hp
  have h : env36967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36966_36967 : H12AffineEnvironment.transform 7 5 env36966 = env36967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36966 == env36967) = true)

theorem identity36967 : scanCanonicalize (H12AffineFastState.compose env36967 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound36967 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36968 : List Nat := [2,4,8,16,0,16,8,5,512,1024,522,4096,8,5124,1,3,5140,523,1025,0,4113,1,17,2,8,16,522,5140,4097,523,1024,1,4,0,5125,513]

theorem envBound36968 : H12AffineFastState.Bounded env36968 := by
  intro p hp
  have h : env36968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36967_36968 : H12AffineEnvironment.transform 10 522 env36967 = env36968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env36967 == env36968) = true)

def env36969 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272393,2101328,2114882,8193,64,97547,115014,17664,2363457,119043,329731,257,2199863,2191387,63069]

theorem envBound36969 : H12AffineFastState.Bounded env36969 := by
  intro p hp
  have h : env36969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36948_36969 : H12AffineEnvironment.transform 6 9 env36948 = env36969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36948 == env36969) = true)

def env36970 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,16,21762,8193,64,97547,115014,17664,262145,119043,329731,257,98679,90203,63069]

theorem envBound36970 : H12AffineFastState.Bounded env36970 := by
  intro p hp
  have h : env36970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36969_36970 : H12AffineEnvironment.transform 20 4160 env36969 = env36970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36969 == env36970) = true)

theorem identity36970 : scanCanonicalize (H12AffineFastState.compose env36970 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36970 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36971 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,262144,1025,8540,4160,272393,16,21762,8193,64,97547,90139,17664,262145,94302,329731,257,73770,90203,22272]

theorem envBound36971 : H12AffineFastState.Bounded env36971 := by
  intro p hp
  have h : env36971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36970_36971 : H12AffineEnvironment.transform 14 8541 env36970 = env36971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36970 == env36971) = true)

theorem identity36971 : scanCanonicalize (H12AffineFastState.compose env36971 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound36971 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env36972 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24908,97407,1025,8540,4160,87158,16,21762,8193,64,97547,90139,17664,97406,94302,29820,257,73770,90203,22272]

theorem envBound36972 : H12AffineFastState.Bounded env36972 := by
  intro p hp
  have h : env36972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36971_36972 : H12AffineEnvironment.transform 17 97407 env36971 = env36972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env36971 == env36972) = true)

theorem identity36972 : scanCanonicalize (H12AffineFastState.compose env36972 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound36972 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36973 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21591,24908,10280,1025,8540,4160,33,16,21762,8193,64,10588,13388,17664,10281,9225,29820,257,29821,13324,22272]

theorem envBound36973 : H12AffineFastState.Bounded env36973 := by
  intro p hp
  have h : env36973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36972_36973 : H12AffineEnvironment.transform 15 21591 env36972 = env36973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env36972 == env36973) = true)

theorem identity36973 : scanCanonicalize (H12AffineFastState.compose env36973 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound36973 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env36974 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,8541,9499,4096,10280,1025,8540,4160,33,16,9294,8193,64,10588,13388,13388,10281,9225,1328,257,1329,13324,9804]

theorem envBound36974 : H12AffineFastState.Bounded env36974 := by
  intro p hp
  have h : env36974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36973_36974 : H12AffineEnvironment.transform 13 12620 env36973 = env36974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env36973 == env36974) = true)

theorem identity36974 : scanCanonicalize (H12AffineFastState.compose env36974 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound36974 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env36975 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,4404,293,1379,4096,2128,1025,292,4160,33,16,1078,121,64,2340,5172,5172,2129,1137,1328,257,1329,5236,1588]

theorem envBound36975 : H12AffineFastState.Bounded env36975 := by
  intro p hp
  have h : env36975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36974_36975 : H12AffineEnvironment.transform 12 120 env36974 = env36975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env36974 == env36975) = true)

theorem identity36975 : scanCanonicalize (H12AffineFastState.compose env36975 (packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36975 : packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env36976 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,120,4404,293,115,4096,2128,273,292,4160,33,16,294,121,64,2340,4388,4388,2129,353,32,257,33,4452,804]

theorem envBound36976 : H12AffineFastState.Bounded env36976 := by
  intro p hp
  have h : env36976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36975_36976 : H12AffineEnvironment.transform 9 272 env36975 = env36976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36975 == env36976) = true)

theorem identity36976 : scanCanonicalize (H12AffineFastState.compose env36976 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36976 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36977 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4113,0,115,4096,2128,52,1,4160,33,16,3,121,64,2049,4097,4097,2129,68,32,36,33,4161,513]

theorem envBound36977 : H12AffineFastState.Bounded env36977 := by
  intro p hp
  have h : env36977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36976_36977 : H12AffineEnvironment.transform 7 37 env36976 = env36977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36976 == env36977) = true)

def env36978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,21763,8193,64,97547,115014,17664,262144,119043,329731,257,98678,90202,63069]

theorem envBound36978 : H12AffineFastState.Bounded env36978 := by
  intro p hp
  have h : env36978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36969_36978 : H12AffineEnvironment.transform 20 4161 env36969 = env36978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36969 == env36978) = true)

theorem identity36978 : scanCanonicalize (H12AffineFastState.compose env36978 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound36978 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,4161,41340,17,21763,8193,64,97547,115014,17664,35189,119043,98678,257,98678,90202,63069]

theorem envBound36979 : H12AffineFastState.Bounded env36979 := by
  intro p hp
  have h : env36979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36978_36979 : H12AffineEnvironment.transform 17 35189 env36978 = env36979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env36978 == env36979) = true)

theorem identity36979 : scanCanonicalize (H12AffineFastState.compose env36979 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound36979 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env36980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,292,65536,16693,2129,1025,293,4161,8280,17,21763,8193,64,97547,82018,17664,2129,86055,65618,257,65618,90202,30585]

theorem envBound36980 : H12AffineFastState.Bounded env36980 := by
  intro p hp
  have h : env36980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36979_36980 : H12AffineEnvironment.transform 14 292 env36979 = env36980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env36979 == env36980) = true)

theorem identity36980 : scanCanonicalize (H12AffineFastState.compose env36980 (packedSelected [0,2,3,5,6,7,8,11,18,20,28] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound36980 : packedSelected [0,2,3,5,6,7,8,11,18,20,28] rootPS < 2^1333 := by decide +kernel

def env36981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,292,8575,16693,2129,1025,293,4161,8280,17,21763,8193,64,23668,24861,17664,2129,29016,8493,257,8493,16677,30585]

theorem envBound36981 : H12AffineFastState.Bounded env36981 := by
  intro p hp
  have h : env36981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36980_36981 : H12AffineEnvironment.transform 15 8575 env36980 = env36981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env36980 == env36981) = true)

theorem identity36981 : scanCanonicalize (H12AffineFastState.compose env36981 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36981 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env36982 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,80,8203,16449,2129,1025,81,4161,8280,17,21623,8193,64,23668,24681,17524,2129,28716,8281,117,8281,16465,30221]

theorem envBound36982 : H12AffineFastState.Bounded env36982 := by
  intro p hp
  have h : env36982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36981_36982 : H12AffineEnvironment.transform 7 116 env36981 = env36982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36981 == env36982) = true)

theorem identity36982 : scanCanonicalize (H12AffineFastState.compose env36982 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound36982 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36983 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13325,80,8203,13388,2129,1025,81,4161,8280,17,8314,8193,64,10361,5220,12409,2129,1057,8281,117,8281,13404,512]

theorem envBound36983 : H12AffineFastState.Bounded env36983 := by
  intro p hp
  have h : env36983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36982_36983 : H12AffineEnvironment.transform 13 13325 env36982 = env36983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env36982 == env36983) = true)

theorem identity36983 : scanCanonicalize (H12AffineFastState.compose env36983 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound36983 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env36984 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2144,8192,11373,80,8203,11308,2129,1025,81,2081,8280,17,8314,8193,64,10361,3076,10265,2129,1057,8281,117,8281,11324,512]

theorem envBound36984 : H12AffineFastState.Bounded env36984 := by
  intro p hp
  have h : env36984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36983_36984 : H12AffineEnvironment.transform 11 2144 env36983 = env36984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env36983 == env36984) = true)

theorem identity36984 : scanCanonicalize (H12AffineFastState.compose env36984 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36984 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36985 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,2113,8192,11340,80,8203,11277,2129,1025,81,2048,8280,17,8283,8193,64,10328,3076,10265,2129,1024,8281,84,8281,11293,512]

theorem envBound36985 : H12AffineFastState.Bounded env36985 := by
  intro p hp
  have h : env36985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36984_36985 : H12AffineEnvironment.transform 4 1 env36984 = env36985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36984 == env36985) = true)

theorem identity36985 : scanCanonicalize (H12AffineFastState.compose env36985 (packedSelected [0,2,3,4,5,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36985 : packedSelected [0,2,3,4,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36986 : List Nat := [2,4,8,16,1,64,9,85,512,1024,0,65,8192,9292,80,8203,9229,81,1025,81,0,8280,17,8283,8193,64,8280,1028,8217,81,1024,8281,84,8281,9245,512]

theorem envBound36986 : H12AffineFastState.Bounded env36986 := by
  intro p hp
  have h : env36986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36985_36986 : H12AffineEnvironment.transform 10 0 env36985 = env36986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36985 == env36986) = true)

theorem identity36986 : scanCanonicalize (H12AffineFastState.compose env36986 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound36986 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env36987 : List Nat := [2,4,8,16,1,64,9,85,512,1024,0,65,89,1045,80,82,1108,81,1025,81,0,1,17,2,88,64,1,1028,64,81,1024,0,84,0,1092,512]

theorem envBound36987 : H12AffineFastState.Bounded env36987 := by
  intro p hp
  have h : env36987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36986_36987 : H12AffineEnvironment.transform 12 89 env36986 = env36987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env36986 == env36987) = true)

theorem identity36987 : scanCanonicalize (H12AffineFastState.compose env36987 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36987 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env36988 : List Nat := [2,4,8,16,1,17,9,4,512,1024,0,16,8,1045,1,3,1029,0,1025,0,0,1,17,2,9,17,1,1028,17,0,1024,0,5,0,1045,512]

theorem envBound36988 : H12AffineFastState.Bounded env36988 := by
  intro p hp
  have h : env36988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36987_36988 : H12AffineEnvironment.transform 5 17 env36987 = env36988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36987 == env36988) = true)

theorem identity36988 : scanCanonicalize (H12AffineFastState.compose env36988 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36988 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36989 : List Nat := [2,4,8,1,1,0,9,4,512,1024,0,1,8,1028,1,3,1029,0,1025,0,0,1,0,2,9,0,1,1028,0,0,1024,0,5,0,1028,512]

theorem envBound36989 : H12AffineFastState.Bounded env36989 := by
  intro p hp
  have h : env36989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36988_36989 : H12AffineEnvironment.transform 3 1 env36988 = env36989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36988 == env36989) = true)

theorem identity36989 : scanCanonicalize (H12AffineFastState.compose env36989 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36989 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36990 : List Nat := [2,4,8,1,1,0,9,4,512,4,0,1,8,0,1,3,1,0,5,0,0,1,0,2,9,0,1,0,0,0,4,0,5,0,0,512]

theorem envBound36990 : H12AffineFastState.Bounded env36990 := by
  intro p hp
  have h : env36990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36989_36990 : H12AffineEnvironment.transform 9 4 env36989 = env36990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36989 == env36990) = true)

theorem identity36990 : scanCanonicalize (H12AffineFastState.compose env36990 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound36990 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36991 : List Nat := [2,4,8,1,1,0,9,4,4,4,0,1,8,0,1,3,1,0,5,0,0,1,0,2,9,0,1,0,0,0,4,0,5,0,0,4]

theorem envBound36991 : H12AffineFastState.Bounded env36991 := by
  intro p hp
  have h : env36991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36990_36991 : H12AffineEnvironment.transform 8 4 env36990 = env36991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env36990 == env36991) = true)

theorem identity36991 : scanCanonicalize (H12AffineFastState.compose env36991 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36991 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36992 : List Nat := [2,1,8,1,1,0,9,1,1,1,0,1,8,0,1,3,1,0,0,0,0,1,0,2,9,0,1,0,0,0,1,0,0,0,0,1]

theorem envBound36992 : H12AffineFastState.Bounded env36992 := by
  intro p hp
  have h : env36992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36991_36992 : H12AffineEnvironment.transform 1 1 env36991 = env36992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36991 == env36992) = true)

def env36993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,97667,115151,17664,2363457,119043,329730,257,2199998,2191387,63188]

theorem envBound36993 : H12AffineFastState.Bounded env36993 := by
  intro p hp
  have h : env36993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36947_36993 : H12AffineEnvironment.transform 21 272513 env36947 = env36993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env36947 == env36993) = true)

theorem identity36993 : scanCanonicalize (H12AffineFastState.compose env36993 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound36993 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272513,17,21763,8328,64,97667,115151,17664,262144,119043,329730,257,98815,90202,63188]

theorem envBound36994 : H12AffineFastState.Bounded env36994 := by
  intro p hp
  have h : env36994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36993_36994 : H12AffineEnvironment.transform 20 4161 env36993 = env36994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36993 == env36994) = true)

def env36995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,21763,8192,64,97547,115015,17664,262144,119043,329730,257,98679,90202,63068]

theorem envBound36995 : H12AffineFastState.Bounded env36995 := by
  intro p hp
  have h : env36995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36994_36995 : H12AffineEnvironment.transform 6 8 env36994 = env36995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36994 == env36995) = true)

theorem identity36995 : scanCanonicalize (H12AffineFastState.compose env36995 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36995 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,32,17,21763,8192,64,97547,115015,17664,10281,119043,73771,257,98679,90202,63068]

theorem envBound36996 : H12AffineFastState.Bounded env36996 := by
  intro p hp
  have h : env36996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36995_36996 : H12AffineEnvironment.transform 17 10281 env36995 = env36996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36995 == env36996) = true)

theorem identity36996 : scanCanonicalize (H12AffineFastState.compose env36996 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36996 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env36997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10281,1025,8541,4161,32,17,21763,8192,64,97547,90139,17664,10281,94303,73771,257,73771,90202,22272]

theorem envBound36997 : H12AffineFastState.Bounded env36997 := by
  intro p hp
  have h : env36997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36996_36997 : H12AffineEnvironment.transform 14 8540 env36996 = env36997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36996 == env36997) = true)

theorem identity36997 : scanCanonicalize (H12AffineFastState.compose env36997 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound36997 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env36998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,342,24909,10281,1025,8541,4161,32,17,21763,8192,64,31837,24909,17664,10281,28937,8573,257,8573,24844,22272]

theorem envBound36998 : H12AffineFastState.Bounded env36998 := by
  intro p hp
  have h : env36998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36997_36998 : H12AffineEnvironment.transform 15 342 env36997 = env36998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env36997 == env36998) = true)

theorem identity36998 : scanCanonicalize (H12AffineFastState.compose env36998 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36998 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,342,16400,2420,1025,0,4161,32,17,21763,349,64,23808,16400,17664,2420,20564,32,257,32,16465,22272]

theorem envBound36999 : H12AffineFastState.Bounded env36999 := by
  intro p hp
  have h : env36999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36998_36999 : H12AffineEnvironment.transform 12 349 env36998 = env36999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36998 == env36999) = true)

theorem identity36999 : scanCanonicalize (H12AffineFastState.compose env36999 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound36999 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5125,1,342,5141,2420,1025,0,4161,32,17,262,349,64,2309,5141,4357,2420,1105,32,257,32,5204,773]

theorem envBound37000 : H12AffineFastState.Bounded env37000 := by
  intro p hp
  have h : env37000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36999_37000 : H12AffineEnvironment.transform 13 5125 env36999 = env37000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env36999 == env37000) = true)

def env37001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,21763,8193,64,97546,115014,17664,262144,119043,329730,257,98678,90202,63069]

theorem envBound37001 : H12AffineFastState.Bounded env37001 := by
  intro p hp
  have h : env37001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36994_37001 : H12AffineEnvironment.transform 6 9 env36994 = env37001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36994 == env37001) = true)

theorem identity37001 : scanCanonicalize (H12AffineFastState.compose env37001 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound37001 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,4161,41341,17,21763,8193,64,97546,115014,17664,35189,119043,98679,257,98678,90202,63069]

theorem envBound37002 : H12AffineFastState.Bounded env37002 := by
  intro p hp
  have h : env37002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37001_37002 : H12AffineEnvironment.transform 17 35189 env37001 = env37002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env37001 == env37002) = true)

theorem identity37002 : scanCanonicalize (H12AffineFastState.compose env37002 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound37002 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env37003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,65536,13625,31837,1025,29993,4161,21589,17,21763,8193,64,97546,78958,17664,31837,74795,95327,257,95326,90202,885]

theorem envBound37003 : H12AffineFastState.Bounded env37003 := by
  intro p hp
  have h : env37003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37002_37003 : H12AffineEnvironment.transform 14 29992 env37002 = env37003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env37002 == env37003) = true)

theorem identity37003 : scanCanonicalize (H12AffineFastState.compose env37003 (packedSelected [0,3,4,5,7,10,12,15,16,18,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37003 : packedSelected [0,3,4,5,7,10,12,15,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env37004 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29709,65536,13340,31837,1025,29708,4161,21589,17,21542,8193,64,97327,78958,17445,31837,74795,95327,36,95326,90202,592]

theorem envBound37004 : H12AffineFastState.Bounded env37004 := by
  intro p hp
  have h : env37004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37003_37004 : H12AffineEnvironment.transform 7 37 env37003 = env37004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37003 == env37004) = true)

theorem identity37004 : scanCanonicalize (H12AffineFastState.compose env37004 (packedSelected [0,3,4,5,7,10,12,15,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound37004 : packedSelected [0,3,4,5,7,10,12,15,16,20,22] rootPS < 2^1333 := by decide +kernel

def env37005 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29709,115,13340,31837,1025,29708,4161,21589,17,21542,8193,64,31836,13341,17445,31837,9304,29740,36,29741,24617,592]

theorem envBound37005 : H12AffineFastState.Bounded env37005 := by
  intro p hp
  have h : env37005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37004_37005 : H12AffineEnvironment.transform 15 115 env37004 = env37005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env37004 == env37005) = true)

theorem identity37005 : scanCanonicalize (H12AffineFastState.compose env37005 (packedSelected [0,3,4,5,7,9,10,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound37005 : packedSelected [0,3,4,5,7,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env37006 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,16384,21620,115,5221,23588,1025,21621,4161,21589,17,21542,120,64,23589,5220,17445,23588,1057,21589,36,21588,16464,592]

theorem envBound37006 : H12AffineFastState.Bounded env37006 := by
  intro p hp
  have h : env37006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37005_37006 : H12AffineEnvironment.transform 12 121 env37005 = env37006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env37005 == env37006) = true)

theorem identity37006 : scanCanonicalize (H12AffineFastState.compose env37006 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound37006 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37007 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,5156,80,115,5221,2048,1025,81,4161,113,17,2,120,64,2049,5220,4097,2048,1057,113,36,112,5236,592]

theorem envBound37007 : H12AffineFastState.Bounded env37007 := by
  intro p hp
  have h : env37007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37006_37007 : H12AffineEnvironment.transform 13 5156 env37006 = env37007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env37006 == env37007) = true)

theorem identity37007 : scanCanonicalize (H12AffineFastState.compose env37007 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound37007 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env37008 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,17,121,1077,80,115,1140,2048,1025,81,80,113,17,2,120,64,2049,1141,16,2048,1057,113,36,112,1125,592]

theorem envBound37008 : H12AffineFastState.Bounded env37008 := by
  intro p hp
  have h : env37008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37007_37008 : H12AffineEnvironment.transform 11 17 env37007 = env37008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37007 == env37008) = true)

theorem identity37008 : scanCanonicalize (H12AffineFastState.compose env37008 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37008 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env37009 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1,17,121,1077,80,115,1140,1,1025,81,80,113,17,2,120,64,0,1141,16,1,1057,113,36,112,1125,592]

theorem envBound37009 : H12AffineFastState.Bounded env37009 := by
  intro p hp
  have h : env37009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37008_37009 : H12AffineEnvironment.transform 10 1 env37008 = env37009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37008 == env37009) = true)

theorem identity37009 : scanCanonicalize (H12AffineFastState.compose env37009 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37009 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env37010 : List Nat := [2,4,8,16,32,64,9,37,512,52,1,17,121,1,80,115,64,1,53,81,80,113,17,2,120,64,0,65,16,1,21,113,36,112,81,592]

theorem envBound37010 : H12AffineFastState.Bounded env37010 := by
  intro p hp
  have h : env37010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37009_37010 : H12AffineEnvironment.transform 9 52 env37009 = env37010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37009 == env37010) = true)

def env37011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4543747,115151,17665,2363456,119042,4268163,257,2199999,2191386,63189]

theorem envBound37011 : H12AffineFastState.Bounded env37011 := by
  intro p hp
  have h : env37011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36946_37011 : H12AffineEnvironment.transform 22 2101329 env36946 = env37011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env36946 == env37011) = true)

def env37012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,97667,115151,17665,2363456,119042,329731,257,2199999,2191386,63189]

theorem envBound37012 : H12AffineFastState.Bounded env37012 := by
  intro p hp
  have h : env37012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37011_37012 : H12AffineEnvironment.transform 21 272512 env37011 = env37012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37011 == env37012) = true)

theorem identity37012 : scanCanonicalize (H12AffineFastState.compose env37012 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound37012 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,262144,1025,29909,2097152,272512,2101329,2114882,8328,64,97667,79131,17665,2363456,75222,329731,257,2188651,2191386,513]

theorem envBound37013 : H12AffineFastState.Bounded env37013 := by
  intro p hp
  have h : env37013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37012_37013 : H12AffineEnvironment.transform 14 29908 env37012 = env37013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env37012 == env37013) = true)

def env37014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,10400,1025,29909,2097152,32,2101329,2114882,8328,64,97667,79131,17665,2111712,75222,73891,257,2188651,2191386,513]

theorem envBound37014 : H12AffineFastState.Bounded env37014 := by
  intro p hp
  have h : env37014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37013_37014 : H12AffineEnvironment.transform 17 10400 env37013 = env37014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37013 == env37014) = true)

theorem identity37014 : scanCanonicalize (H12AffineFastState.compose env37014 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21727) := by decide +kernel

theorem selectedBound37014 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21727,13509,10400,1025,29909,2097152,32,2101329,2114882,8328,64,10588,25028,17665,2111712,28937,29820,257,2109876,2106565,513]

theorem envBound37015 : H12AffineFastState.Bounded env37015 := by
  intro p hp
  have h : env37015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37014_37015 : H12AffineEnvironment.transform 15 21727 env37014 = env37015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21727 env37014 == env37015) = true)

theorem identity37015 : scanCanonicalize (H12AffineFastState.compose env37015 (packedSelected [0,4,8,9,10,12,15,17,18,20,27,28,32] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound37015 : packedSelected [0,4,8,9,10,12,15,17,18,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env37016 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,29908,21727,13509,10400,1025,29909,2097152,32,2101329,2114799,8328,64,10481,24681,17580,2111712,28836,29820,172,2109465,2106565,513]

theorem envBound37016 : H12AffineFastState.Bounded env37016 := by
  intro p hp
  have h : env37016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37015_37016 : H12AffineEnvironment.transform 7 173 env37015 = env37016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env37015 == env37016) = true)

theorem identity37016 : scanCanonicalize (H12AffineFastState.compose env37016 (packedSelected [1,4,5,9,10,12,14,15,17,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 12512) := by decide +kernel

theorem selectedBound37016 : packedSelected [1,4,5,9,10,12,14,15,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env37017 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,29908,21727,13509,10400,1025,29909,12512,32,8369,29711,8328,64,10481,24681,17580,2048,28836,29820,172,249,5157,513]

theorem envBound37017 : H12AffineFastState.Bounded env37017 := by
  intro p hp
  have h : env37017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37016_37017 : H12AffineEnvironment.transform 20 12512 env37016 = env37017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12512 env37016 == env37017) = true)

theorem identity37017 : scanCanonicalize (H12AffineFastState.compose env37017 (packedSelected [0,3,5,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound37017 : packedSelected [0,3,5,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env37018 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,5236,8352,171,13509,10400,1025,8353,12512,32,8369,8315,8328,64,10481,13341,4312,2048,9424,8200,172,249,5157,513]

theorem envBound37018 : H12AffineFastState.Bounded env37018 := by
  intro p hp
  have h : env37018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37017_37018 : H12AffineEnvironment.transform 13 5236 env37017 = env37018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env37017 == env37018) = true)

theorem identity37018 : scanCanonicalize (H12AffineFastState.compose env37018 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7381) := by decide +kernel

theorem selectedBound37018 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env37019 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,7381,5236,7285,171,2064,5237,1025,7284,3125,32,7268,7342,7261,64,5156,2248,4312,2048,6149,7389,172,249,5157,513]

theorem envBound37019 : H12AffineFastState.Bounded env37019 := by
  intro p hp
  have h : env37019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37018_37019 : H12AffineEnvironment.transform 12 7381 env37018 = env37019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7381 env37018 == env37019) = true)

theorem identity37019 : scanCanonicalize (H12AffineFastState.compose env37019 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound37019 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env37020 : List Nat := [2,4,8,16,32,64,128,173,512,1024,136,4096,5213,5236,5373,171,152,5237,1025,5372,1213,32,5356,5158,5333,64,5156,64,4312,136,4237,5205,172,249,5157,513]

theorem envBound37020 : H12AffineFastState.Bounded env37020 := by
  intro p hp
  have h : env37020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37019_37020 : H12AffineEnvironment.transform 10 136 env37019 = env37020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env37019 == env37020) = true)

theorem identity37020 : scanCanonicalize (H12AffineFastState.compose env37020 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound37020 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37021 : List Nat := [2,4,8,16,32,64,24,53,512,1024,16,4096,5213,5236,5221,51,0,5237,1025,5220,1061,32,5236,5158,5197,64,5156,64,4160,16,4117,5205,52,97,5157,513]

theorem envBound37021 : H12AffineFastState.Bounded env37021 := by
  intro p hp
  have h : env37021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37020_37021 : H12AffineEnvironment.transform 6 24 env37020 = env37021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env37020 == env37021) = true)

theorem identity37021 : scanCanonicalize (H12AffineFastState.compose env37021 (packedSelected [4,5,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound37021 : packedSelected [4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env37022 : List Nat := [2,4,8,16,32,64,24,53,512,1024,16,528,1613,1636,1653,51,0,1637,1025,1652,1061,32,1636,1590,1629,64,1588,64,592,16,517,1605,52,97,1589,513]

theorem envBound37022 : H12AffineFastState.Bounded env37022 := by
  intro p hp
  have h : env37022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37021_37022 : H12AffineEnvironment.transform 11 528 env37021 = env37022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env37021 == env37022) = true)

def env37023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,10401,1025,29909,2097152,33,2101329,2114882,8328,64,97667,79131,17665,2111713,75222,73890,257,2188651,2191386,513]

theorem envBound37023 : H12AffineFastState.Bounded env37023 := by
  intro p hp
  have h : env37023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37013_37023 : H12AffineEnvironment.transform 17 10401 env37013 = env37023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env37013 == env37023) = true)

def env37024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13509,10401,1025,8661,2097152,33,2101329,2101314,8328,64,75907,79131,4097,2111713,75222,73890,257,2175083,2172186,513]

theorem envBound37024 : H12AffineFastState.Bounded env37024 := by
  intro p hp
  have h : env37024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37023_37024 : H12AffineEnvironment.transform 13 5376 env37023 = env37024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37023 == env37024) = true)

theorem identity37024 : scanCanonicalize (H12AffineFastState.compose env37024 (packedSelected [16,20] rootPS)) = affineNative (2^(20+1) ^^^ 4296) := by decide +kernel

theorem selectedBound37024 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13509,10401,1025,8661,4296,33,153,138,8328,64,75907,79131,4097,10281,75222,73890,257,73891,79314,513]

theorem envBound37025 : H12AffineFastState.Bounded env37025 := by
  intro p hp
  have h : env37025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37024_37025 : H12AffineEnvironment.transform 20 4296 env37024 = env37025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4296 env37024 == env37025) = true)

theorem identity37025 : scanCanonicalize (H12AffineFastState.compose env37025 (packedSelected [0,1,7,8,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound37025 : packedSelected [0,1,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env37026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8323,13509,10401,1025,8661,4296,33,153,138,8328,64,2048,5528,4097,10281,1365,33,257,32,5457,513]

theorem envBound37026 : H12AffineFastState.Bounded env37026 := by
  intro p hp
  have h : env37026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37025_37026 : H12AffineEnvironment.transform 15 8323 env37025 = env37026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env37025 == env37026) = true)

theorem identity37026 : scanCanonicalize (H12AffineFastState.compose env37026 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37026 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,217,398,5576,2476,1025,216,4296,33,153,138,389,64,2048,5528,4097,2340,1365,33,257,32,5457,513]

theorem envBound37027 : H12AffineFastState.Bounded env37027 := by
  intro p hp
  have h : env37027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37026_37027 : H12AffineEnvironment.transform 12 269 env37026 = env37027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37026 == env37027) = true)

theorem identity37027 : scanCanonicalize (H12AffineFastState.compose env37027 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37027 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env37028 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,137,398,5528,2476,1025,136,4248,33,153,138,389,16,2048,5528,4097,2340,1285,33,257,32,5377,513]

theorem envBound37028 : H12AffineFastState.Bounded env37028 := by
  intro p hp
  have h : env37028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37027_37028 : H12AffineEnvironment.transform 5 16 env37027 = env37028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37027 == env37028) = true)

theorem identity37028 : scanCanonicalize (H12AffineFastState.compose env37028 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37028 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env37029 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5157,137,171,5309,2185,1025,136,4248,33,153,138,160,16,2048,5309,4097,2049,1056,33,36,32,5156,513]

theorem envBound37029 : H12AffineFastState.Bounded env37029 := by
  intro p hp
  have h : env37029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37028_37029 : H12AffineEnvironment.transform 7 37 env37028 = env37029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37028 == env37029) = true)

end H12CloudChart0