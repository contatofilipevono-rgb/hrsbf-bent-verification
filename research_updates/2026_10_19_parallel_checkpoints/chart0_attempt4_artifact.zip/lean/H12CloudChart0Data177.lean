import H12CloudChart0Data176

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans44837_44838 : H12AffineEnvironment.transform 11 3408 env44837 = env44838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env44837 == env44838) = true)

theorem identity44838 : scanCanonicalize (H12AffineFastState.compose env44838 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44838 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env44839 : List Nat := [2,4,8,16,0,64,9,4,512,1024,2048,3156,9,2129,1,83,2065,2129,1024,0,3092,81,16,2,8,65,2048,2112,3156,2048,1104,1,4,0,2129,592]

theorem envBound44839 : H12AffineFastState.Bounded env44839 := by
  intro p hp
  have h : env44839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44838_44839 : H12AffineEnvironment.transform 7 4 env44838 = env44839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44838 == env44839) = true)

theorem identity44839 : scanCanonicalize (H12AffineFastState.compose env44839 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44839 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44840 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,3076,9,2049,1,3,2065,2049,1024,0,3092,1,16,2,8,17,2048,2064,3076,2048,1024,1,4,0,2049,512]

theorem envBound44840 : H12AffineFastState.Bounded env44840 := by
  intro p hp
  have h : env44840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44839_44840 : H12AffineEnvironment.transform 5 16 env44839 = env44840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44839 == env44840) = true)

theorem identity44840 : scanCanonicalize (H12AffineFastState.compose env44840 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44840 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44841 : List Nat := [2,4,8,1,0,1,9,4,512,1024,2048,3076,9,2049,1,3,2048,2049,1024,0,3077,1,1,2,8,0,2048,2049,3076,2048,1024,1,4,0,2049,512]

theorem envBound44841 : H12AffineFastState.Bounded env44841 := by
  intro p hp
  have h : env44841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44840_44841 : H12AffineEnvironment.transform 3 1 env44840 = env44841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44840 == env44841) = true)

theorem identity44841 : scanCanonicalize (H12AffineFastState.compose env44841 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44841 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44842 : List Nat := [2,4,3,1,0,1,2,4,512,1024,2048,3076,2,2049,1,3,2048,2049,1024,0,3077,1,1,2,3,0,2048,2049,3076,2048,1024,1,4,0,2049,512]

theorem envBound44842 : H12AffineFastState.Bounded env44842 := by
  intro p hp
  have h : env44842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44841_44842 : H12AffineEnvironment.transform 2 3 env44841 = env44842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44841 == env44842) = true)

theorem identity44842 : scanCanonicalize (H12AffineFastState.compose env44842 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound44842 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44843 : List Nat := [2,4,3,1,0,1,2,4,512,1024,1028,0,2,1029,1,3,1028,1029,1024,0,1,1,1,2,3,0,1028,1029,0,1028,1024,1,4,0,1029,512]

theorem envBound44843 : H12AffineFastState.Bounded env44843 := by
  intro p hp
  have h : env44843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44842_44843 : H12AffineEnvironment.transform 10 1028 env44842 = env44843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env44842 == env44843) = true)

theorem identity44843 : scanCanonicalize (H12AffineFastState.compose env44843 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound44843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44844 : List Nat := [2,4,3,1,0,1,2,4,512,0,4,0,2,5,1,3,4,5,0,0,1,1,1,2,3,0,4,5,0,4,0,1,4,0,5,512]

theorem envBound44844 : H12AffineFastState.Bounded env44844 := by
  intro p hp
  have h : env44844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44843_44844 : H12AffineEnvironment.transform 9 0 env44843 = env44844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env44843 == env44844) = true)

theorem identity44844 : scanCanonicalize (H12AffineFastState.compose env44844 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44844 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env44845 : List Nat := [2,1,3,1,0,1,2,1,512,0,1,0,2,0,1,3,1,0,0,0,1,1,1,2,3,0,1,0,0,1,0,1,1,0,0,512]

theorem envBound44845 : H12AffineFastState.Bounded env44845 := by
  intro p hp
  have h : env44845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44844_44845 : H12AffineEnvironment.transform 1 1 env44844 = env44845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44844 == env44845) = true)

theorem identity44845 : scanCanonicalize (H12AffineFastState.compose env44845 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44845 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44846 : List Nat := [1,1,0,1,0,1,1,1,512,0,1,0,1,0,1,0,1,0,0,0,1,1,1,1,0,0,1,0,0,1,0,1,1,0,0,512]

theorem envBound44846 : H12AffineFastState.Bounded env44846 := by
  intro p hp
  have h : env44846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44845_44846 : H12AffineEnvironment.transform 0 1 env44845 = env44846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44845 == env44846) = true)

def env44847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,17,98781,8328,65,4237813,5393,17665,10280,1500,4256860,256,21793,46212,74251]

theorem envBound44847 : H12AffineFastState.Bounded env44847 := by
  intro p hp
  have h : env44847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44812_44847 : H12AffineEnvironment.transform 20 4161 env44812 = env44847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44812 == env44847) = true)

theorem identity44847 : scanCanonicalize (H12AffineFastState.compose env44847 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201831) := by decide +kernel

theorem selectedBound44847 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,201831,17,98781,8328,65,245138,5393,17665,10280,1500,254011,256,21793,46212,74251]

theorem envBound44848 : H12AffineFastState.Bounded env44848 := by
  intro p hp
  have h : env44848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44847_44848 : H12AffineEnvironment.transform 21 201831 env44847 = env44848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201831 env44847 == env44848) = true)

def env44849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,201831,17,98645,8192,65,245018,5393,17665,10280,1364,254011,256,21793,46092,74251]

theorem envBound44849 : H12AffineFastState.Bounded env44849 := by
  intro p hp
  have h : env44849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44848_44849 : H12AffineEnvironment.transform 6 8 env44848 = env44849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44848 == env44849) = true)

theorem identity44849 : scanCanonicalize (H12AffineFastState.compose env44849 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound44849 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190521,1024,32769,4161,169265,17,3,8192,65,146508,5393,17665,10280,1364,156013,256,21793,46092,41821]

theorem envBound44850 : H12AffineFastState.Bounded env44850 := by
  intro p hp
  have h : env44850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44849_44850 : H12AffineEnvironment.transform 15 33110 env44849 = env44850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env44849 == env44850) = true)

theorem identity44850 : scanCanonicalize (H12AffineFastState.compose env44850 (packedSelected [7,8,10,12,14,15,16,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound44850 : packedSelected [7,8,10,12,14,15,16,27,28] rootPS < 2^1333 := by decide +kernel

def env44851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,2420,1024,32769,4161,29820,17,3,8192,65,56577,5393,17665,10280,1364,32800,256,21793,46092,41821]

theorem envBound44851 : H12AffineFastState.Bounded env44851 := by
  intro p hp
  have h : env44851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44850_44851 : H12AffineEnvironment.transform 16 57677 env44850 = env44851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env44850 == env44851) = true)

theorem identity44851 : scanCanonicalize (H12AffineFastState.compose env44851 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound44851 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env44852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5393,2420,1024,29789,4161,29820,17,3,8192,65,10589,5393,17665,10280,1364,29820,256,21793,16464,22273]

theorem envBound44852 : H12AffineFastState.Bounded env44852 := by
  intro p hp
  have h : env44852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44851_44852 : H12AffineEnvironment.transform 14 29788 env44851 = env44852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env44851 == env44852) = true)

theorem identity44852 : scanCanonicalize (H12AffineFastState.compose env44852 (packedSelected [0,7,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound44852 : packedSelected [0,7,11,18] rootPS < 2^1333 := by decide +kernel

def env44853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,6161,11341,11547,5393,2420,1024,11340,4161,11373,17,3,8192,65,10589,5393,7440,10280,1364,11373,256,3376,6209,3856]

theorem envBound44853 : H12AffineFastState.Bounded env44853 := by
  intro p hp
  have h : env44853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44852_44853 : H12AffineEnvironment.transform 13 6161 env44852 = env44853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env44852 == env44853) = true)

theorem identity44853 : scanCanonicalize (H12AffineFastState.compose env44853 (packedSelected [0,1,2,4,6,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound44853 : packedSelected [0,1,2,4,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env44854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,6161,3425,3127,5393,2420,1024,3424,4161,3393,17,3,300,65,2161,5393,7440,2308,1364,3393,256,3376,6209,3856]

theorem envBound44854 : H12AffineFastState.Bounded env44854 := by
  intro p hp
  have h : env44854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44853_44854 : H12AffineEnvironment.transform 12 300 env44853 = env44854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env44853 == env44854) = true)

theorem identity44854 : scanCanonicalize (H12AffineFastState.compose env44854 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound44854 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,300,5457,33,375,5393,1076,1024,32,4161,1,17,3,300,65,1329,5393,4176,1092,1364,1,256,112,5377,592]

theorem envBound44855 : H12AffineFastState.Bounded env44855 := by
  intro p hp
  have h : env44855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44854_44855 : H12AffineEnvironment.transform 10 1344 env44854 = env44855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env44854 == env44855) = true)

theorem identity44855 : scanCanonicalize (H12AffineFastState.compose env44855 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44855 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44856 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1296,4096,300,5377,33,295,5393,1076,1024,32,4113,1,17,3,300,17,1329,5393,4096,1044,1284,1,256,32,5377,512]

theorem envBound44856 : H12AffineFastState.Bounded env44856 := by
  intro p hp
  have h : env44856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44855_44856 : H12AffineEnvironment.transform 5 16 env44855 = env44856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44855 == env44856) = true)

theorem identity44856 : scanCanonicalize (H12AffineFastState.compose env44856 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44856 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44857 : List Nat := [2,4,8,16,1,16,8,256,512,1024,1296,4096,269,5377,0,262,5393,1045,1024,1,4113,1,17,3,269,17,1296,5393,4096,1044,1284,1,256,1,5377,512]

theorem envBound44857 : H12AffineFastState.Bounded env44857 := by
  intro p hp
  have h : env44857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44856_44857 : H12AffineEnvironment.transform 4 1 env44856 = env44857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44856 == env44857) = true)

theorem identity44857 : scanCanonicalize (H12AffineFastState.compose env44857 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound44857 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44858 : List Nat := [2,4,8,16,1,16,8,256,512,1024,1296,1028,269,261,0,262,277,1045,1024,1,1045,1,17,3,269,17,1296,277,1028,1044,1284,1,256,1,261,512]

theorem envBound44858 : H12AffineFastState.Bounded env44858 := by
  intro p hp
  have h : env44858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44857_44858 : H12AffineEnvironment.transform 11 1028 env44857 = env44858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env44857 == env44858) = true)

theorem identity44858 : scanCanonicalize (H12AffineFastState.compose env44858 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound44858 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44859 : List Nat := [2,4,8,16,1,16,8,256,512,20,260,16,269,261,0,262,277,1,20,1,1,1,17,3,269,17,260,277,16,0,272,1,256,1,261,512]

theorem envBound44859 : H12AffineFastState.Bounded env44859 := by
  intro p hp
  have h : env44859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44858_44859 : H12AffineEnvironment.transform 9 20 env44858 = env44859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44858 == env44859) = true)

def env44860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,201831,17,98644,8193,65,245019,5393,17665,10280,1365,254011,256,21793,46093,74251]

theorem envBound44860 : H12AffineFastState.Bounded env44860 := by
  intro p hp
  have h : env44860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44848_44860 : H12AffineEnvironment.transform 6 9 env44848 = env44860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44848 == env44860) = true)

theorem identity44860 : scanCanonicalize (H12AffineFastState.compose env44860 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44860 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4161,201831,17,73737,8193,65,203846,5393,17665,10280,1365,213350,256,21793,5456,74251]

theorem envBound44861 : H12AffineFastState.Bounded env44861 := by
  intro p hp
  have h : env44861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44860_44861 : H12AffineEnvironment.transform 14 8541 env44860 = env44861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44860 == env44861) = true)

theorem identity44861 : scanCanonicalize (H12AffineFastState.compose env44861 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound44861 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,5441,23589,1024,8540,4161,65830,17,73737,8193,65,67847,5393,17665,10280,1365,87079,256,21793,5456,74251]

theorem envBound44862 : H12AffineFastState.Bounded env44862 := by
  intro p hp
  have h : env44862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44861_44862 : H12AffineEnvironment.transform 16 5441 env44861 = env44862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env44861 == env44862) = true)

theorem identity44862 : scanCanonicalize (H12AffineFastState.compose env44862 (packedSelected [0,1,5,8,9,22,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound44862 : packedSelected [0,1,5,8,9,22,24,27] rootPS < 2^1333 := by decide +kernel

def env44863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8541,65536,5441,10280,1024,8540,4161,65830,17,73737,8193,65,67847,5393,12556,10280,1365,73770,256,8492,5456,74251]

theorem envBound44863 : H12AffineFastState.Bounded env44863 := by
  intro p hp
  have h : env44863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44862_44863 : H12AffineEnvironment.transform 13 13325 env44862 = env44863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env44862 == env44863) = true)

theorem identity44863 : scanCanonicalize (H12AffineFastState.compose env44863 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound44863 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,293,65536,5441,2128,1024,292,4161,65830,17,65649,121,65,67847,5393,4468,2128,1365,65618,256,340,5456,66163]

theorem envBound44864 : H12AffineFastState.Bounded env44864 := by
  intro p hp
  have h : env44864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44863_44864 : H12AffineEnvironment.transform 12 120 env44863 = env44864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env44863 == env44864) = true)

theorem identity44864 : scanCanonicalize (H12AffineFastState.compose env44864 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44864 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env44865 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5237,1,65536,5221,2128,1024,0,4161,65538,17,65649,121,65,67619,5173,4176,2128,1137,65618,36,112,5236,66163]

theorem envBound44865 : H12AffineFastState.Bounded env44865 := by
  intro p hp
  have h : env44865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44864_44865 : H12AffineEnvironment.transform 7 36 env44864 = env44865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44864 == env44865) = true)

theorem identity44865 : scanCanonicalize (H12AffineFastState.compose env44865 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound44865 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env44866 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5237,1,34,5221,2128,1024,0,4161,32,17,83,121,65,2049,5173,4176,2128,1137,112,36,112,5236,593]

theorem envBound44866 : H12AffineFastState.Bounded env44866 := by
  intro p hp
  have h : env44866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44865_44866 : H12AffineEnvironment.transform 15 34 env44865 = env44866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env44865 == env44866) = true)

theorem identity44866 : scanCanonicalize (H12AffineFastState.compose env44866 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound44866 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44867 : List Nat := [2,4,8,16,32,64,9,36,512,69,2048,4096,120,4144,1,34,4128,2128,69,0,4161,32,17,83,121,65,2049,4208,4176,2128,52,112,36,112,4145,593]

theorem envBound44867 : H12AffineFastState.Bounded env44867 := by
  intro p hp
  have h : env44867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44866_44867 : H12AffineEnvironment.transform 9 69 env44866 = env44867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env44866 == env44867) = true)

theorem identity44867 : scanCanonicalize (H12AffineFastState.compose env44867 (packedSelected [1,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound44867 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env44868 : List Nat := [2,4,8,16,32,64,9,36,512,69,2048,2144,120,2128,1,34,2112,2128,69,0,2081,32,17,83,121,65,2049,2064,2096,2128,52,112,36,112,2129,593]

theorem envBound44868 : H12AffineFastState.Bounded env44868 := by
  intro p hp
  have h : env44868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44867_44868 : H12AffineEnvironment.transform 11 2144 env44867 = env44868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env44867 == env44868) = true)

theorem identity44868 : scanCanonicalize (H12AffineFastState.compose env44868 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44868 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env44869 : List Nat := [2,4,8,16,1,64,9,5,512,69,2048,2113,89,2128,1,3,2112,2128,69,0,2048,1,17,83,88,65,2049,2064,2065,2128,21,81,5,81,2129,593]

theorem envBound44869 : H12AffineFastState.Bounded env44869 := by
  intro p hp
  have h : env44869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44868_44869 : H12AffineEnvironment.transform 4 1 env44868 = env44869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44868 == env44869) = true)

theorem identity44869 : scanCanonicalize (H12AffineFastState.compose env44869 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound44869 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env44870 : List Nat := [2,4,8,16,1,64,9,5,512,69,512,577,89,592,1,3,576,592,69,0,512,1,17,83,88,65,513,528,529,592,21,81,5,81,593,593]

theorem envBound44870 : H12AffineFastState.Bounded env44870 := by
  intro p hp
  have h : env44870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44869_44870 : H12AffineEnvironment.transform 10 512 env44869 = env44870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env44869 == env44870) = true)

theorem identity44870 : scanCanonicalize (H12AffineFastState.compose env44870 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44870 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env44871 : List Nat := [2,4,8,16,1,17,9,5,512,20,512,528,8,513,1,3,529,513,20,0,512,1,17,2,9,16,513,528,529,513,21,0,5,0,512,512]

theorem envBound44871 : H12AffineFastState.Bounded env44871 := by
  intro p hp
  have h : env44871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44870_44871 : H12AffineEnvironment.transform 5 17 env44870 = env44871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44870 == env44871) = true)

def env44872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound44872 : H12AffineFastState.Bounded env44872 := by
  intro p hp
  have h : env44872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44729_44872 : H12AffineEnvironment.transform 18 1025 env44729 = env44872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env44729 == env44872) = true)

theorem identity44872 : scanCanonicalize (H12AffineFastState.compose env44872 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 297317) := by decide +kernel

theorem selectedBound44872 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,297317,16777216,8328,65,21186916,18973836,2415668,149860,17108341,23160256,257,19221960,19246188,17050275]

theorem envBound44873 : H12AffineFastState.Bounded env44873 := by
  intro p hp
  have h : env44873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44872_44873 : H12AffineEnvironment.transform 22 297317 env44872 = env44873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297317 env44872 == env44873) = true)

def env44874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182628,1025,32769,2097152,4194304,147457,16777216,8328,65,21186916,18973836,2233680,149860,17024017,23160256,257,19104940,19096840,16966599]

theorem envBound44874 : H12AffineFastState.Bounded env44874 := by
  intro p hp
  have h : env44874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44873_44874 : H12AffineEnvironment.transform 17 182628 env44873 = env44874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env44873 == env44874) = true)

theorem identity44874 : scanCanonicalize (H12AffineFastState.compose env44874 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound44874 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env44875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182628,1025,32769,2097152,4194304,147457,188870,8328,65,4303010,2319690,2233680,149860,75223,6521862,257,2188650,2196686,513]

theorem envBound44875 : H12AffineFastState.Bounded env44875 := by
  intro p hp
  have h : env44875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44874_44875 : H12AffineEnvironment.transform 23 188870 env44874 = env44875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env44874 == env44875) = true)

def env44876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35324,1025,32769,2097152,4194304,153,41310,8328,65,4303010,2172370,2119112,2556,75223,6407326,257,2188650,2196686,513]

theorem envBound44876 : H12AffineFastState.Bounded env44876 := by
  intro p hp
  have h : env44876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44875_44876 : H12AffineEnvironment.transform 16 16536 env44875 = env44876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env44875 == env44876) = true)

theorem identity44876 : scanCanonicalize (H12AffineFastState.compose env44876 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound44876 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16536,10280,1025,8661,2097152,4194304,153,138,8328,65,4262262,2172370,2119112,2556,75223,6382922,257,2188650,2172186,513]

theorem envBound44877 : H12AffineFastState.Bounded env44877 := by
  intro p hp
  have h : env44877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44876_44877 : H12AffineEnvironment.transform 14 8660 env44876 = env44877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env44876 == env44877) = true)

theorem identity44877 : scanCanonicalize (H12AffineFastState.compose env44877 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound44877 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env44878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16536,10280,1025,8661,2097152,4194304,153,138,8328,65,4205044,2098512,2119112,2556,1365,6309320,257,2115048,2098584,513]

theorem envBound44878 : H12AffineFastState.Bounded env44878 := by
  intro p hp
  have h : env44878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44877_44878 : H12AffineEnvironment.transform 15 8322 env44877 = env44878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env44877 == env44878) = true)

theorem identity44878 : scanCanonicalize (H12AffineFastState.compose env44878 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound44878 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env44879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16536,10280,1025,8661,2097152,168,153,138,8328,65,10588,2098512,2119112,2556,1365,2114912,257,2115048,2098584,513]

theorem envBound44879 : H12AffineFastState.Bounded env44879 := by
  intro p hp
  have h : env44879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44878_44879 : H12AffineEnvironment.transform 21 168 env44878 = env44879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env44878 == env44879) = true)

theorem identity44879 : scanCanonicalize (H12AffineFastState.compose env44879 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17817) := by decide +kernel

theorem selectedBound44879 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16536,10280,1025,8661,17817,168,153,138,8328,65,10588,16585,4177,2556,1365,249,257,113,16385,513]

theorem envBound44880 : H12AffineFastState.Bounded env44880 := by
  intro p hp
  have h : env44880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44879_44880 : H12AffineEnvironment.transform 20 17817 env44879 = env44880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17817 env44879 == env44880) = true)

theorem identity44880 : scanCanonicalize (H12AffineFastState.compose env44880 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44880 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,17681,32,17,2,8192,65,10588,16449,4177,2420,1365,113,257,113,16385,513]

theorem envBound44881 : H12AffineFastState.Bounded env44881 := by
  intro p hp
  have h : env44881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44880_44881 : H12AffineEnvironment.transform 6 8 env44880 = env44881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44880 == env44881) = true)

theorem identity44881 : scanCanonicalize (H12AffineFastState.compose env44881 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound44881 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,292,114,16400,2128,1025,293,17681,32,17,2,120,65,2340,16449,4177,2420,1365,113,257,113,16385,513]

theorem envBound44882 : H12AffineFastState.Bounded env44882 := by
  intro p hp
  have h : env44882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44881_44882 : H12AffineEnvironment.transform 12 120 env44881 = env44882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env44881 == env44882) = true)

theorem identity44882 : scanCanonicalize (H12AffineFastState.compose env44882 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44882 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44883 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,0,114,16400,2128,1025,1,17461,32,17,2,120,65,2048,16449,4177,2128,1137,113,37,113,16385,513]

theorem envBound44883 : H12AffineFastState.Bounded env44883 := by
  intro p hp
  have h : env44883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44882_44883 : H12AffineEnvironment.transform 7 36 env44882 = env44883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44882 == env44883) = true)

theorem identity44883 : scanCanonicalize (H12AffineFastState.compose env44883 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound44883 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44884 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,4096,120,16384,0,114,16400,2128,101,1,16465,32,17,2,120,65,2048,16449,4177,2128,21,113,37,113,16385,513]

theorem envBound44884 : H12AffineFastState.Bounded env44884 := by
  intro p hp
  have h : env44884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44883_44884 : H12AffineEnvironment.transform 9 100 env44883 = env44884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env44883 == env44884) = true)

theorem identity44884 : scanCanonicalize (H12AffineFastState.compose env44884 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound44884 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env44885 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,16,120,16384,0,114,16400,2128,101,1,16465,32,17,2,120,65,2048,16449,65,2128,21,113,37,113,16385,513]

theorem envBound44885 : H12AffineFastState.Bounded env44885 := by
  intro p hp
  have h : env44885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44884_44885 : H12AffineEnvironment.transform 11 16 env44884 = env44885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env44884 == env44885) = true)

theorem identity44885 : scanCanonicalize (H12AffineFastState.compose env44885 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44885 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44886 : List Nat := [2,4,8,16,32,64,8,36,512,100,0,16,120,16384,0,114,16400,80,101,1,16465,32,17,2,120,65,0,16449,65,80,21,113,37,113,16385,513]

theorem envBound44886 : H12AffineFastState.Bounded env44886 := by
  intro p hp
  have h : env44886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44885_44886 : H12AffineEnvironment.transform 10 0 env44885 = env44886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44885 == env44886) = true)

theorem identity44886 : scanCanonicalize (H12AffineFastState.compose env44886 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44886 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44887 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,16,40,16384,0,34,16400,0,53,1,16385,32,17,2,40,17,0,16401,17,0,21,33,37,33,16385,513]

theorem envBound44887 : H12AffineFastState.Bounded env44887 := by
  intro p hp
  have h : env44887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44886_44887 : H12AffineEnvironment.transform 5 16 env44886 = env44887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44886 == env44887) = true)

theorem identity44887 : scanCanonicalize (H12AffineFastState.compose env44887 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound44887 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44888 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,16,40,0,0,34,16,0,53,1,1,32,17,2,40,17,0,17,17,0,21,33,37,33,1,513]

theorem envBound44888 : H12AffineFastState.Bounded env44888 := by
  intro p hp
  have h : env44888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44887_44888 : H12AffineEnvironment.transform 13 0 env44887 = env44888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env44887 == env44888) = true)

theorem identity44888 : scanCanonicalize (H12AffineFastState.compose env44888 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44888 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44889 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,8,0,0,2,16,0,21,1,1,0,17,2,8,17,0,17,17,0,21,1,5,1,1,513]

theorem envBound44889 : H12AffineFastState.Bounded env44889 := by
  intro p hp
  have h : env44889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44888_44889 : H12AffineEnvironment.transform 4 0 env44888 = env44889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44888 == env44889) = true)

theorem identity44889 : scanCanonicalize (H12AffineFastState.compose env44889 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44890 : List Nat := [2,4,8,16,0,16,8,4,17,20,0,16,8,0,0,2,16,0,21,1,1,0,17,2,8,17,0,17,17,0,21,1,5,1,1,16]

theorem envBound44890 : H12AffineFastState.Bounded env44890 := by
  intro p hp
  have h : env44890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44889_44890 : H12AffineEnvironment.transform 8 17 env44889 = env44890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44889 == env44890) = true)

def env44891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35325,1025,32769,2097152,4194304,152,41311,8328,65,4303010,2172371,2119113,2557,75223,6407327,257,2188650,2196686,513]

theorem envBound44891 : H12AffineFastState.Bounded env44891 := by
  intro p hp
  have h : env44891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44875_44891 : H12AffineEnvironment.transform 16 16537 env44875 = env44891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env44875 == env44891) = true)

def env44892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,41311,8192,65,4302890,2172251,2118977,2421,75103,6407191,257,2188650,2196550,513]

theorem envBound44892 : H12AffineFastState.Bounded env44892 := by
  intro p hp
  have h : env44892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44891_44892 : H12AffineEnvironment.transform 6 8 env44891 = env44892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44891 == env44892) = true)

theorem identity44892 : scanCanonicalize (H12AffineFastState.compose env44892 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44892 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,2097152,4194304,16,41311,8192,65,4229153,2098512,2118977,2421,1364,6349852,257,2114913,2139213,513]

theorem envBound44893 : H12AffineFastState.Bounded env44893 := by
  intro p hp
  have h : env44893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44892_44893 : H12AffineEnvironment.transform 15 8203 env44892 = env44893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44892 == env44893) = true)

theorem identity44893 : scanCanonicalize (H12AffineFastState.compose env44893 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound44893 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,2097152,41340,16,41311,8192,65,10589,2098512,2118977,2421,1364,2114912,257,2114913,2139213,513]

theorem envBound44894 : H12AffineFastState.Bounded env44894 := by
  intro p hp
  have h : env44894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44893_44894 : H12AffineEnvironment.transform 21 41340 env44893 = env44894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env44893 == env44894) = true)

theorem identity44894 : scanCanonicalize (H12AffineFastState.compose env44894 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38145) := by decide +kernel

theorem selectedBound44894 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,38145,41340,16,41311,8192,65,10589,36945,49216,2421,1364,53345,257,53344,12620,513]

theorem envBound44895 : H12AffineFastState.Bounded env44895 := by
  intro p hp
  have h : env44895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44894_44895 : H12AffineEnvironment.transform 20 38145 env44894 = env44895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38145 env44894 == env44895) = true)

theorem identity44895 : scanCanonicalize (H12AffineFastState.compose env44895 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound44895 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16401,30776,1025,29004,25676,20529,16,20498,8192,65,10589,24860,12557,2421,1364,8492,257,8493,12620,513]

theorem envBound44896 : H12AffineFastState.Bounded env44896 := by
  intro p hp
  have h : env44896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44895_44896 : H12AffineEnvironment.transform 14 29005 env44895 = env44896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env44895 == env44896) = true)

theorem identity44896 : scanCanonicalize (H12AffineFastState.compose env44896 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound44896 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env44897 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,29005,8203,16401,30776,101,29004,24616,20529,16,20498,8192,65,10589,24860,12557,2421,304,8492,257,8493,12620,513]

theorem envBound44897 : H12AffineFastState.Bounded env44897 := by
  intro p hp
  have h : env44897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44896_44897 : H12AffineEnvironment.transform 9 100 env44896 = env44897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env44896 == env44897) = true)

theorem identity44897 : scanCanonicalize (H12AffineFastState.compose env44897 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 10589) := by decide +kernel

theorem selectedBound44897 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env44898 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,10589,6160,8203,10572,4453,101,6161,2421,14700,16,14671,8192,65,10589,2113,12557,2421,304,8492,257,8493,12620,513]

theorem envBound44898 : H12AffineFastState.Bounded env44898 := by
  intro p hp
  have h : env44898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44897_44898 : H12AffineEnvironment.transform 13 10589 env44897 = env44898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10589 env44897 == env44898) = true)

def env44899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41311,8193,65,4302891,2172250,2118976,2420,75102,6407190,257,2188650,2196551,513]

theorem envBound44899 : H12AffineFastState.Bounded env44899 := by
  intro p hp
  have h : env44899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44891_44899 : H12AffineEnvironment.transform 6 9 env44891 = env44899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44891 == env44899) = true)

theorem identity44899 : scanCanonicalize (H12AffineFastState.compose env44899 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound44899 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env44900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115735,4194304,17,41311,8193,65,4302891,57677,102743,2420,75102,4194305,257,41341,16464,513]

theorem envBound44900 : H12AffineFastState.Bounded env44900 := by
  intro p hp
  have h : env44900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44899_44900 : H12AffineEnvironment.transform 20 115735 env44899 = env44900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env44899 == env44900) = true)

def env44901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10588,1025,8233,91199,4194304,17,375,8193,65,4261891,16741,78207,2420,75102,4194305,257,341,16464,513]

theorem envBound44901 : H12AffineFastState.Bounded env44901 := by
  intro p hp
  have h : env44901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44900_44901 : H12AffineEnvironment.transform 14 8232 env44900 = env44901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env44900 == env44901) = true)

theorem identity44901 : scanCanonicalize (H12AffineFastState.compose env44901 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound44901 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env44902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,34,16400,10588,1025,8233,25629,4194304,17,375,8193,65,4196385,16741,12637,2420,9596,4194305,257,341,16464,513]

theorem envBound44902 : H12AffineFastState.Bounded env44902 := by
  intro p hp
  have h : env44902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44901_44902 : H12AffineEnvironment.transform 15 34 env44901 = env44902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env44901 == env44902) = true)

theorem identity44902 : scanCanonicalize (H12AffineFastState.compose env44902 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound44902 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env44903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,34,16400,10588,1025,8233,25629,8493,17,375,8193,65,10508,16741,12637,2420,9596,8492,257,341,16464,513]

theorem envBound44903 : H12AffineFastState.Bounded env44903 := by
  intro p hp
  have h : env44903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44902_44903 : H12AffineEnvironment.transform 21 8493 env44902 = env44903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env44902 == env44903) = true)

theorem identity44903 : scanCanonicalize (H12AffineFastState.compose env44903 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44903 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env44904 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,34,16400,10280,1025,8233,25629,8281,17,3,8193,65,10360,16401,12329,2048,9224,8280,117,33,16464,513]

theorem envBound44904 : H12AffineFastState.Bounded env44904 := by
  intro p hp
  have h : env44904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44903_44904 : H12AffineEnvironment.transform 7 116 env44903 = env44904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44903 == env44904) = true)

theorem identity44904 : scanCanonicalize (H12AffineFastState.compose env44904 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44904 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44905 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8232,34,16400,10280,1025,8233,25629,8201,17,3,8193,17,10280,16401,12329,2048,9224,8200,37,33,16384,513]

theorem envBound44905 : H12AffineFastState.Bounded env44905 := by
  intro p hp
  have h : env44905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44904_44905 : H12AffineEnvironment.transform 5 16 env44904 = env44905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44904 == env44905) = true)

theorem identity44905 : scanCanonicalize (H12AffineFastState.compose env44905 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound44905 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44906 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,5157,8232,34,5173,10280,1025,8233,12344,8201,17,3,8193,17,10280,5172,12329,2048,9224,8200,37,33,5157,513]

theorem envBound44906 : H12AffineFastState.Bounded env44906 := by
  intro p hp
  have h : env44906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44905_44906 : H12AffineEnvironment.transform 13 5157 env44905 = env44906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env44905 == env44906) = true)

theorem identity44906 : scanCanonicalize (H12AffineFastState.compose env44906 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound44906 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44907 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5157,0,34,5173,2048,1025,1,4112,33,17,3,41,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound44907 : H12AffineFastState.Bounded env44907 := by
  intro p hp
  have h : env44907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44906_44907 : H12AffineEnvironment.transform 12 40 env44906 = env44907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env44906 == env44907) = true)

def env44908 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1045,0,34,1029,2048,1025,1,32,33,17,3,41,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound44908 : H12AffineFastState.Bounded env44908 := by
  intro p hp
  have h : env44908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44907_44908 : H12AffineEnvironment.transform 11 48 env44907 = env44908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44907 == env44908) = true)

theorem identity44908 : scanCanonicalize (H12AffineFastState.compose env44908 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound44908 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44909 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1541,48,40,1045,0,34,1029,1541,1025,1,32,33,17,3,41,17,1541,1028,49,1541,1056,32,37,33,1045,513]

theorem envBound44909 : H12AffineFastState.Bounded env44909 := by
  intro p hp
  have h : env44909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44908_44909 : H12AffineEnvironment.transform 10 1541 env44908 = env44909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env44908 == env44909) = true)

def env44910 : List Nat := [2,4,8,16,32,16,9,36,512,52,561,48,40,33,0,34,49,561,53,1,32,33,17,3,41,17,561,48,49,561,20,32,37,33,33,513]

theorem envBound44910 : H12AffineFastState.Bounded env44910 := by
  intro p hp
  have h : env44910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44909_44910 : H12AffineEnvironment.transform 9 52 env44909 = env44910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44909 == env44910) = true)

theorem identity44910 : scanCanonicalize (H12AffineFastState.compose env44910 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound44910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44911 : List Nat := [2,4,8,16,26,16,9,30,512,14,523,10,18,27,0,24,11,523,15,1,26,27,17,3,19,17,523,10,11,523,20,26,31,27,27,513]

theorem envBound44911 : H12AffineFastState.Bounded env44911 := by
  intro p hp
  have h : env44911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44910_44911 : H12AffineEnvironment.transform 4 26 env44910 = env44911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env44910 == env44911) = true)

def leafEnv44911 : List Nat := [2,4,8,16,26,16,9,30,512,14,523,10,18,27,0,24,11,523,15,1,26,27,17,3,21,19,1,17,523,10,11,523,20,26,31,27,5,25,27,513,1,26,0]

def active44911 : List Nat := [0,1,2,3,8]

def tree44911 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44911 : H12WitnessSearch.Good tree44911 := H12GlobalWitnessIndex.good

theorem leafIdentity44911 : H12AffineFastState.composeSystem env44911 rootObs = leafEnv44911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44911 rootObs == leafEnv44911) = true)

theorem terminalChecked44911 : H12PackedTerminal.terminalCheckFast leafEnv44911 active44911 tree44911 = true := by decide +kernel

def env44912 : List Nat := [2,4,8,16,32,16,9,36,512,53,560,48,40,32,0,34,48,560,52,1,32,33,17,3,41,17,560,49,49,560,21,32,37,33,32,513]

theorem envBound44912 : H12AffineFastState.Bounded env44912 := by
  intro p hp
  have h : env44912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44909_44912 : H12AffineEnvironment.transform 9 53 env44909 = env44912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44909 == env44912) = true)

theorem identity44912 : scanCanonicalize (H12AffineFastState.compose env44912 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44913 : List Nat := [2,4,8,16,32,16,9,36,16,53,32,48,40,32,0,34,48,32,52,1,32,33,17,3,41,17,32,49,49,32,21,32,37,33,32,17]

theorem envBound44913 : H12AffineFastState.Bounded env44913 := by
  intro p hp
  have h : env44913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44912_44913 : H12AffineEnvironment.transform 8 16 env44912 = env44913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44912 == env44913) = true)

def leafEnv44913 : List Nat := [2,4,8,16,32,16,9,36,16,53,32,48,40,32,0,34,48,32,52,1,32,33,17,3,20,41,1,17,32,49,49,32,21,32,37,33,5,35,32,17,1,32,0]

def active44913 : List Nat := [0,1,2,3,4]

def tree44913 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44913 : H12WitnessSearch.Good tree44913 := H12GlobalWitnessIndex.good

theorem leafIdentity44913 : H12AffineFastState.composeSystem env44913 rootObs = leafEnv44913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44913 rootObs == leafEnv44913) = true)

theorem terminalChecked44913 : H12PackedTerminal.terminalCheckFast leafEnv44913 active44913 tree44913 = true := by decide +kernel

def env44914 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1044,0,34,1028,2048,1025,1,33,33,17,3,41,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound44914 : H12AffineFastState.Bounded env44914 := by
  intro p hp
  have h : env44914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44907_44914 : H12AffineEnvironment.transform 11 49 env44907 = env44914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44907 == env44914) = true)

theorem identity44914 : scanCanonicalize (H12AffineFastState.compose env44914 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound44914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44915 : List Nat := [2,4,8,16,32,16,9,36,512,1024,560,49,40,1044,0,34,1028,560,1025,1,33,33,17,3,41,17,560,1029,48,560,1056,32,37,33,1044,513]

theorem envBound44915 : H12AffineFastState.Bounded env44915 := by
  intro p hp
  have h : env44915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44914_44915 : H12AffineEnvironment.transform 10 560 env44914 = env44915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env44914 == env44915) = true)

def env44916 : List Nat := [2,4,8,16,32,16,9,36,512,52,560,49,40,32,0,34,48,560,53,1,33,33,17,3,41,17,560,49,48,560,20,32,37,33,32,513]

theorem envBound44916 : H12AffineFastState.Bounded env44916 := by
  intro p hp
  have h : env44916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44915_44916 : H12AffineEnvironment.transform 9 52 env44915 = env44916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44915 == env44916) = true)

theorem identity44916 : scanCanonicalize (H12AffineFastState.compose env44916 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound44916 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44917 : List Nat := [2,4,8,16,27,16,9,31,512,15,523,10,19,27,0,25,11,523,14,1,26,26,17,3,18,17,523,10,11,523,20,27,30,26,27,513]

theorem envBound44917 : H12AffineFastState.Bounded env44917 := by
  intro p hp
  have h : env44917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44916_44917 : H12AffineEnvironment.transform 4 27 env44916 = env44917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env44916 == env44917) = true)

def leafEnv44917 : List Nat := [2,4,8,16,27,16,9,31,512,15,523,10,19,27,0,25,11,523,14,1,26,26,17,3,21,18,1,17,523,10,11,523,20,27,30,26,5,24,27,513,1,26,0]

def active44917 : List Nat := [0,1,2,3,8]

def tree44917 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44917 : H12WitnessSearch.Good tree44917 := H12GlobalWitnessIndex.good

theorem leafIdentity44917 : H12AffineFastState.composeSystem env44917 rootObs = leafEnv44917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44917 rootObs == leafEnv44917) = true)

theorem terminalChecked44917 : H12PackedTerminal.terminalCheckFast leafEnv44917 active44917 tree44917 = true := by decide +kernel

def env44918 : List Nat := [2,4,8,16,32,16,9,36,512,53,560,49,40,33,0,34,49,560,52,1,33,33,17,3,41,17,560,48,48,560,21,32,37,33,33,513]

theorem envBound44918 : H12AffineFastState.Bounded env44918 := by
  intro p hp
  have h : env44918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44915_44918 : H12AffineEnvironment.transform 9 53 env44915 = env44918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44915 == env44918) = true)

theorem identity44918 : scanCanonicalize (H12AffineFastState.compose env44918 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44919 : List Nat := [2,4,8,16,32,16,9,36,17,53,33,49,40,33,0,34,49,33,52,1,33,33,17,3,41,17,33,48,48,33,21,32,37,33,33,16]

theorem envBound44919 : H12AffineFastState.Bounded env44919 := by
  intro p hp
  have h : env44919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44918_44919 : H12AffineEnvironment.transform 8 17 env44918 = env44919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44918 == env44919) = true)

def leafEnv44919 : List Nat := [2,4,8,16,32,16,9,36,17,53,33,49,40,33,0,34,49,33,52,1,33,33,17,3,20,41,1,17,33,48,48,33,21,32,37,33,5,35,33,16,1,33,0]

def active44919 : List Nat := [0,1,2,3,4]

def tree44919 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44919 : H12WitnessSearch.Good tree44919 := H12GlobalWitnessIndex.good

theorem leafIdentity44919 : H12AffineFastState.composeSystem env44919 rootObs = leafEnv44919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44919 rootObs == leafEnv44919) = true)

theorem terminalChecked44919 : H12PackedTerminal.terminalCheckFast leafEnv44919 active44919 tree44919 = true := by decide +kernel

def env44920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10589,1025,8232,91198,4194304,17,374,8193,65,4261890,16740,78206,2420,75102,4194305,257,340,16464,513]

theorem envBound44920 : H12AffineFastState.Bounded env44920 := by
  intro p hp
  have h : env44920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44900_44920 : H12AffineEnvironment.transform 14 8233 env44900 = env44920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env44900 == env44920) = true)

theorem identity44920 : scanCanonicalize (H12AffineFastState.compose env44920 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound44920 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env44921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,342,16400,10589,1025,8232,25960,4194304,17,374,8193,65,4196692,16740,12328,2420,9224,4194305,257,340,16464,513]

theorem envBound44921 : H12AffineFastState.Bounded env44921 := by
  intro p hp
  have h : env44921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44920_44921 : H12AffineEnvironment.transform 15 342 env44920 = env44921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env44920 == env44921) = true)

theorem identity44921 : scanCanonicalize (H12AffineFastState.compose env44921 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound44921 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env44922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,342,16400,10589,1025,8232,25960,8573,17,374,8193,65,10281,16740,12328,2420,9224,8572,257,340,16464,513]

theorem envBound44922 : H12AffineFastState.Bounded env44922 := by
  intro p hp
  have h : env44922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44921_44922 : H12AffineEnvironment.transform 21 8573 env44921 = env44922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env44921 == env44922) = true)

theorem identity44922 : scanCanonicalize (H12AffineFastState.compose env44922 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44922 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,0,342,16400,2420,1025,1,17729,340,17,374,40,65,2048,16740,4097,2420,1057,341,257,340,16464,513]

theorem envBound44923 : H12AffineFastState.Bounded env44923 := by
  intro p hp
  have h : env44923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44922_44923 : H12AffineEnvironment.transform 12 41 env44922 = env44923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44922 == env44923) = true)

theorem identity44923 : scanCanonicalize (H12AffineFastState.compose env44923 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44923 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44924 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,0,262,16400,2340,1025,1,17681,260,17,294,40,17,2048,16692,4097,2340,1057,261,257,260,16384,513]

theorem envBound44924 : H12AffineFastState.Bounded env44924 := by
  intro p hp
  have h : env44924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44923_44924 : H12AffineEnvironment.transform 5 16 env44923 = env44924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44923 == env44924) = true)

theorem identity44924 : scanCanonicalize (H12AffineFastState.compose env44924 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound44924 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env44925 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5157,0,262,5173,2340,1025,1,4404,260,17,294,40,17,2048,5393,4097,2340,1057,261,257,260,5157,513]

theorem envBound44925 : H12AffineFastState.Bounded env44925 := by
  intro p hp
  have h : env44925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44924_44925 : H12AffineEnvironment.transform 13 5157 env44924 = env44925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env44924 == env44925) = true)

theorem identity44925 : scanCanonicalize (H12AffineFastState.compose env44925 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44925 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env44926 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,0,35,5173,2049,1025,1,4113,33,17,3,40,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound44926 : H12AffineFastState.Bounded env44926 := by
  intro p hp
  have h : env44926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44925_44926 : H12AffineEnvironment.transform 7 37 env44925 = env44926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44925 == env44926) = true)

def env44927 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,0,35,1029,2049,1025,1,33,33,17,3,40,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound44927 : H12AffineFastState.Bounded env44927 := by
  intro p hp
  have h : env44927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44926_44927 : H12AffineEnvironment.transform 11 48 env44926 = env44927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44926 == env44927) = true)

theorem identity44927 : scanCanonicalize (H12AffineFastState.compose env44927 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44928 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,16,9,1045,0,3,1029,2049,1025,1,1,1,17,3,8,17,2048,1028,17,2049,1025,0,4,1,1045,513]

theorem envBound44928 : H12AffineFastState.Bounded env44928 := by
  intro p hp
  have h : env44928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44927_44928 : H12AffineEnvironment.transform 4 0 env44927 = env44928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44927 == env44928) = true)

def env44929 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,16,9,1,0,3,17,2049,21,1,1,1,17,3,8,17,2048,16,17,2049,21,0,4,1,1,513]

theorem envBound44929 : H12AffineFastState.Bounded env44929 := by
  intro p hp
  have h : env44929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44928_44929 : H12AffineEnvironment.transform 9 20 env44928 = env44929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44928 == env44929) = true)

theorem identity44929 : scanCanonicalize (H12AffineFastState.compose env44929 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound44929 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44930 : List Nat := [2,4,8,16,0,16,9,5,512,20,522,16,9,1,0,3,17,523,21,1,1,1,17,3,8,17,522,16,17,523,21,0,4,1,1,513]

theorem envBound44930 : H12AffineFastState.Bounded env44930 := by
  intro p hp
  have h : env44930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44929_44930 : H12AffineEnvironment.transform 10 522 env44929 = env44930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env44929 == env44930) = true)

def leafEnv44930 : List Nat := [2,4,8,16,0,16,9,5,512,20,522,16,9,1,0,3,17,523,21,1,1,1,17,3,20,8,1,17,522,16,17,523,21,0,4,1,5,2,1,513,1,1,0]

def active44930 : List Nat := [0,1,2,3,8]

def tree44930 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44930 : H12WitnessSearch.Good tree44930 := H12GlobalWitnessIndex.good

theorem leafIdentity44930 : H12AffineFastState.composeSystem env44930 rootObs = leafEnv44930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44930 rootObs == leafEnv44930) = true)

theorem terminalChecked44930 : H12PackedTerminal.terminalCheckFast leafEnv44930 active44930 tree44930 = true := by decide +kernel

def env44931 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,9,0,0,3,16,2049,20,1,1,1,17,3,8,17,2048,17,17,2049,20,0,4,1,0,513]

theorem envBound44931 : H12AffineFastState.Bounded env44931 := by
  intro p hp
  have h : env44931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44928_44931 : H12AffineEnvironment.transform 9 21 env44928 = env44931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env44928 == env44931) = true)

theorem identity44931 : scanCanonicalize (H12AffineFastState.compose env44931 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44932 : List Nat := [2,4,8,16,0,16,9,5,512,21,0,16,9,0,0,3,16,1,20,1,1,1,17,3,8,17,0,17,17,1,20,0,4,1,0,513]

theorem envBound44932 : H12AffineFastState.Bounded env44932 := by
  intro p hp
  have h : env44932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44931_44932 : H12AffineEnvironment.transform 10 0 env44931 = env44932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44931 == env44932) = true)

def leafEnv44932 : List Nat := [2,4,8,16,0,16,9,5,512,21,0,16,9,0,0,3,16,1,20,1,1,1,17,3,21,8,1,17,0,17,17,1,20,0,4,1,5,2,0,513,1,1,0]

def active44932 : List Nat := [0,1,2,3,8]

def tree44932 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44932 : H12WitnessSearch.Good tree44932 := H12GlobalWitnessIndex.good

theorem leafIdentity44932 : H12AffineFastState.composeSystem env44932 rootObs = leafEnv44932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44932 rootObs == leafEnv44932) = true)

theorem terminalChecked44932 : H12PackedTerminal.terminalCheckFast leafEnv44932 active44932 tree44932 = true := by decide +kernel

def env44933 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,0,35,1028,2049,1025,1,32,33,17,3,40,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound44933 : H12AffineFastState.Bounded env44933 := by
  intro p hp
  have h : env44933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44926_44933 : H12AffineEnvironment.transform 11 49 env44926 = env44933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44926 == env44933) = true)

theorem identity44933 : scanCanonicalize (H12AffineFastState.compose env44933 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound44933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44934 : List Nat := [2,4,8,16,32,16,9,37,512,21,2048,49,41,1,0,35,17,2049,20,1,32,33,17,3,40,17,2048,16,48,2049,52,32,36,33,1,513]

theorem envBound44934 : H12AffineFastState.Bounded env44934 := by
  intro p hp
  have h : env44934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44933_44934 : H12AffineEnvironment.transform 9 21 env44933 = env44934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env44933 == env44934) = true)

def env44935 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,17,9,1,0,3,17,2049,20,1,0,1,17,3,8,17,2048,16,16,2049,20,0,4,1,1,513]

theorem envBound44935 : H12AffineFastState.Bounded env44935 := by
  intro p hp
  have h : env44935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44934_44935 : H12AffineEnvironment.transform 4 0 env44934 = env44935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44934 == env44935) = true)

theorem identity44935 : scanCanonicalize (H12AffineFastState.compose env44935 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44935 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44936 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,17,9,1,0,3,17,0,20,1,0,1,17,3,8,17,1,16,16,0,20,0,4,1,1,513]

theorem envBound44936 : H12AffineFastState.Bounded env44936 := by
  intro p hp
  have h : env44936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44935_44936 : H12AffineEnvironment.transform 10 1 env44935 = env44936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44935 == env44936) = true)

def leafEnv44936 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,17,9,1,0,3,17,0,20,1,0,1,17,3,21,8,1,17,1,16,16,0,20,0,4,1,5,2,1,513,1,0,0]

def active44936 : List Nat := [0,1,2,3,8]

def tree44936 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44936 : H12WitnessSearch.Good tree44936 := H12GlobalWitnessIndex.good

theorem leafIdentity44936 : H12AffineFastState.composeSystem env44936 rootObs = leafEnv44936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44936 rootObs == leafEnv44936) = true)

theorem terminalChecked44936 : H12PackedTerminal.terminalCheckFast leafEnv44936 active44936 tree44936 = true := by decide +kernel

def env44937 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,1,0,2,17,2049,20,1,1,0,17,3,9,17,2048,16,17,2049,21,1,5,0,1,513]

theorem envBound44937 : H12AffineFastState.Bounded env44937 := by
  intro p hp
  have h : env44937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44934_44937 : H12AffineEnvironment.transform 4 1 env44934 = env44937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44934 == env44937) = true)

theorem identity44937 : scanCanonicalize (H12AffineFastState.compose env44937 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound44937 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44938 : List Nat := [2,4,8,16,1,16,9,4,512,21,522,16,8,1,0,2,17,523,20,1,1,0,17,3,9,17,522,16,17,523,21,1,5,0,1,513]

theorem envBound44938 : H12AffineFastState.Bounded env44938 := by
  intro p hp
  have h : env44938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44937_44938 : H12AffineEnvironment.transform 10 522 env44937 = env44938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env44937 == env44938) = true)

def leafEnv44938 : List Nat := [2,4,8,16,1,16,9,4,512,21,522,16,8,1,0,2,17,523,20,1,1,0,17,3,20,9,1,17,522,16,17,523,21,1,5,0,5,3,1,513,1,1,0]

def active44938 : List Nat := [0,1,2,3,8]

def tree44938 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44938 : H12WitnessSearch.Good tree44938 := H12GlobalWitnessIndex.good

theorem leafIdentity44938 : H12AffineFastState.composeSystem env44938 rootObs = leafEnv44938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44938 rootObs == leafEnv44938) = true)

theorem terminalChecked44938 : H12PackedTerminal.terminalCheckFast leafEnv44938 active44938 tree44938 = true := by decide +kernel

def env44939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182629,1025,32769,2097152,4194304,147456,16777216,8328,65,21186916,18973836,2233681,149860,17024016,23160256,257,19104941,19096841,16966598]

theorem envBound44939 : H12AffineFastState.Bounded env44939 := by
  intro p hp
  have h : env44939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44873_44939 : H12AffineEnvironment.transform 17 182629 env44873 = env44939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env44873 == env44939) = true)

def env44940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35325,1025,32769,2097152,4194304,152,16777216,8328,65,21039612,18973836,2119113,2556,16876680,23160256,257,18990133,18949521,16819038]

theorem envBound44940 : H12AffineFastState.Bounded env44940 := by
  intro p hp
  have h : env44940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44939_44940 : H12AffineEnvironment.transform 16 16536 env44939 = env44940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env44939 == env44940) = true)

def env44941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,16777216,8192,65,21039476,18973700,2118977,2420,16876544,23160136,257,18990133,18949401,16819038]

theorem envBound44941 : H12AffineFastState.Bounded env44941 := by
  intro p hp
  have h : env44941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44940_44941 : H12AffineEnvironment.transform 6 8 env44940 = env44941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44940 == env44941) = true)

theorem identity44941 : scanCanonicalize (H12AffineFastState.compose env44941 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound44941 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env44942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,16,98645,8192,65,4229153,2098513,2118977,2420,1365,6349853,257,2114912,2139212,74251]

theorem envBound44942 : H12AffineFastState.Bounded env44942 := by
  intro p hp
  have h : env44942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44941_44942 : H12AffineEnvironment.transform 23 98645 env44941 = env44942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env44941 == env44942) = true)

theorem identity44942 : scanCanonicalize (H12AffineFastState.compose env44942 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound44942 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env44943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,73770,16,98645,8192,65,108555,2098513,2118977,2420,1365,2212919,257,2114912,2139212,74251]

theorem envBound44943 : H12AffineFastState.Bounded env44943 := by
  intro p hp
  have h : env44943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44942_44943 : H12AffineEnvironment.transform 21 73770 env44942 = env44943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env44942 == env44943) = true)

theorem identity44943 : scanCanonicalize (H12AffineFastState.compose env44943 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 124187) := by decide +kernel

theorem selectedBound44943 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env44944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,124187,73770,16,98645,8192,65,108555,122954,110682,2420,1365,8492,257,106619,82263,74251]

theorem envBound44944 : H12AffineFastState.Bounded env44944 := by
  intro p hp
  have h : env44944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44943_44944 : H12AffineEnvironment.transform 20 124187 env44943 = env44944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124187 env44943 == env44944) = true)

theorem identity44944 : scanCanonicalize (H12AffineFastState.compose env44944 (packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound44944 : packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env44945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,262,16400,35189,1025,32769,58397,8492,16,32851,8192,65,43277,57676,45404,2420,1365,8492,257,41341,16465,8973]

theorem envBound44945 : H12AffineFastState.Bounded env44945 := by
  intro p hp
  have h : env44945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44944_44945 : H12AffineEnvironment.transform 15 262 env44944 = env44945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env44944 == env44945) = true)

theorem identity44945 : scanCanonicalize (H12AffineFastState.compose env44945 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44945 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,262,16400,10280,1025,8540,17728,8492,16,8462,8192,65,2128,16401,4097,2420,1365,8492,257,32,16465,8973]

theorem envBound44946 : H12AffineFastState.Bounded env44946 := by
  intro p hp
  have h : env44946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44945_44946 : H12AffineEnvironment.transform 14 8541 env44945 = env44946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44945 == env44946) = true)

theorem identity44946 : scanCanonicalize (H12AffineFastState.compose env44946 (packedSelected [0,1,3,5,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound44946 : packedSelected [0,1,3,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8541,262,5220,10280,1025,8540,4404,8492,16,8462,8192,65,2128,5221,4097,2420,1365,8492,257,32,5157,8973]

theorem envBound44947 : H12AffineFastState.Bounded env44947 := by
  intro p hp
  have h : env44947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44946_44947 : H12AffineEnvironment.transform 13 5236 env44946 = env44947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env44946 == env44947) = true)

theorem identity44947 : scanCanonicalize (H12AffineFastState.compose env44947 (packedSelected [1,3,4,5,6,7,8,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44947 : packedSelected [1,3,4,5,6,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env44948 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8233,114,5220,10280,1025,8232,4160,8280,16,8314,8192,65,2128,5221,4097,2048,1057,8280,117,32,5157,8825]

theorem envBound44948 : H12AffineFastState.Bounded env44948 := by
  intro p hp
  have h : env44948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44947_44948 : H12AffineEnvironment.transform 7 116 env44947 = env44948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44947 == env44948) = true)

theorem identity44948 : scanCanonicalize (H12AffineFastState.compose env44948 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound44948 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44949 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5236,80,114,5220,2129,1025,81,4160,33,16,3,121,65,2128,5221,4097,2048,1057,33,117,32,5157,512]

theorem envBound44949 : H12AffineFastState.Bounded env44949 := by
  intro p hp
  have h : env44949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44948_44949 : H12AffineEnvironment.transform 12 121 env44948 = env44949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env44948 == env44949) = true)

theorem identity44949 : scanCanonicalize (H12AffineFastState.compose env44949 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44949 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44950 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,88,5205,80,83,5189,2129,1025,81,4160,0,16,3,88,65,2128,5188,4097,2048,1024,0,84,1,5124,512]

theorem envBound44950 : H12AffineFastState.Bounded env44950 := by
  intro p hp
  have h : env44950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44949_44950 : H12AffineEnvironment.transform 4 1 env44949 = env44950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44949 == env44950) = true)

theorem identity44950 : scanCanonicalize (H12AffineFastState.compose env44950 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound44950 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44951 : List Nat := [2,4,8,16,1,64,8,85,512,1024,81,4096,88,5205,80,83,5189,0,1025,81,4160,0,16,3,88,65,1,5188,4097,81,1024,0,84,1,5124,512]

theorem envBound44951 : H12AffineFastState.Bounded env44951 := by
  intro p hp
  have h : env44951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44950_44951 : H12AffineEnvironment.transform 10 81 env44950 = env44951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env44950 == env44951) = true)

def env44952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,16777216,8193,65,21039477,18973701,2118976,2421,16876545,23160137,257,18990133,18949400,16819038]

theorem envBound44952 : H12AffineFastState.Bounded env44952 := by
  intro p hp
  have h : env44952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44940_44952 : H12AffineEnvironment.transform 6 9 env44940 = env44952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44940 == env44952) = true)

def env44953 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,16777216,8193,65,21039105,18973701,2118708,2049,16876545,23159869,117,18990133,18949228,16818730]

theorem envBound44953 : H12AffineFastState.Bounded env44953 := by
  intro p hp
  have h : env44953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44952_44953 : H12AffineEnvironment.transform 7 116 env44952 = env44953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44952 == env44953) = true)

theorem identity44953 : scanCanonicalize (H12AffineFastState.compose env44953 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2212884) := by decide +kernel

theorem selectedBound44953 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env44954 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,2212884,8193,65,6343701,16401,2118708,2049,2113557,4235305,117,33,57464,2188862]

theorem envBound44954 : H12AffineFastState.Bounded env44954 := by
  intro p hp
  have h : env44954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44953_44954 : H12AffineEnvironment.transform 23 2212884 env44953 = env44954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212884 env44953 == env44954) = true)

def env44955 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,2212884,8193,17,6343701,16401,2118708,2049,2113557,4235305,37,33,57384,2188862]

theorem envBound44955 : H12AffineFastState.Bounded env44955 := by
  intro p hp
  have h : env44955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44954_44955 : H12AffineEnvironment.transform 5 16 env44954 = env44955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44954 == env44955) = true)

theorem identity44955 : scanCanonicalize (H12AffineFastState.compose env44955 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound44955 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env44956 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8232,65536,16401,10280,1025,8233,2097152,4194304,17,2188348,8193,17,6319165,16401,2118708,2049,2113557,4194305,37,33,16384,2188862]

theorem envBound44956 : H12AffineFastState.Bounded env44956 := by
  intro p hp
  have h : env44956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44955_44956 : H12AffineEnvironment.transform 14 8232 env44955 = env44956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env44955 == env44956) = true)

theorem identity44956 : scanCanonicalize (H12AffineFastState.compose env44956 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 91199) := by decide +kernel

theorem selectedBound44956 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env44957 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8232,65536,16401,10280,1025,8233,91199,4194304,17,3,8193,17,4261890,16401,77835,2049,74794,4194305,37,33,16384,513]

theorem envBound44957 : H12AffineFastState.Bounded env44957 := by
  intro p hp
  have h : env44957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44956_44957 : H12AffineEnvironment.transform 20 91199 env44956 = env44957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91199 env44956 == env44957) = true)

theorem identity44957 : scanCanonicalize (H12AffineFastState.compose env44957 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44957 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44958 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8232,8202,16401,10280,1025,8233,17461,4194304,17,3,8193,17,4204552,16401,4097,2049,1056,4194305,37,33,16384,513]

theorem envBound44958 : H12AffineFastState.Bounded env44958 := by
  intro p hp
  have h : env44958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44957_44958 : H12AffineEnvironment.transform 15 8202 env44957 = env44958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44957 == env44958) = true)

def env44959 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,4194304,17,2212884,8193,16,6343701,16401,2118708,2049,2113557,4235305,36,33,57385,2188862]

theorem envBound44959 : H12AffineFastState.Bounded env44959 := by
  intro p hp
  have h : env44959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44954_44959 : H12AffineEnvironment.transform 5 17 env44954 = env44959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44954 == env44959) = true)

theorem identity44959 : scanCanonicalize (H12AffineFastState.compose env44959 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

theorem selectedBound44959 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env44960 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,2097152,65538,17,2212884,8193,16,2214935,16401,2118708,2049,2113557,106539,36,33,57385,2188862]

theorem envBound44960 : H12AffineFastState.Bounded env44960 := by
  intro p hp
  have h : env44960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44959_44960 : H12AffineEnvironment.transform 21 65538 env44959 = env44960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env44959 == env44960) = true)

theorem identity44960 : scanCanonicalize (H12AffineFastState.compose env44960 (packedSelected [0,1,3,5,7,8,9,10,14,17,18,19,20,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 123967) := by decide +kernel

theorem selectedBound44960 : packedSelected [0,1,3,5,7,8,9,10,14,17,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env44961 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,123967,65538,17,8235,8193,16,10280,16401,110603,2049,107562,106539,36,33,57385,33281]

theorem envBound44961 : H12AffineFastState.Bounded env44961 := by
  intro p hp
  have h : env44961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44960_44961 : H12AffineEnvironment.transform 20 123967 env44960 = env44961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 123967 env44960 == env44961) = true)

theorem identity44961 : scanCanonicalize (H12AffineFastState.compose env44961 (packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 21508) := by decide +kernel

theorem selectedBound44961 : packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env44962 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,21508,65536,16401,23556,1025,21509,77883,65538,17,8235,8193,16,10280,16401,91151,2049,94254,95279,36,33,13357,22021]

theorem envBound44962 : H12AffineFastState.Bounded env44962 := by
  intro p hp
  have h : env44962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44961_44962 : H12AffineEnvironment.transform 14 21508 env44961 = env44962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21508 env44961 == env44962) = true)

theorem identity44962 : scanCanonicalize (H12AffineFastState.compose env44962 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound44962 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44963 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,21508,34,16401,23556,1025,21509,12313,32,17,8235,8193,16,10280,16401,25645,2049,28684,29709,36,33,13357,22021]

theorem envBound44963 : H12AffineFastState.Bounded env44963 := by
  intro p hp
  have h : env44963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44962_44963 : H12AffineEnvironment.transform 15 34 env44962 = env44963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env44962 == env44963) = true)

theorem identity44963 : scanCanonicalize (H12AffineFastState.compose env44963 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound44963 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44964 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,16384,21508,34,16401,23556,1025,21509,4145,32,17,3,41,16,2048,16401,17413,2049,20516,21541,36,33,5125,22021]

theorem envBound44964 : H12AffineFastState.Bounded env44964 := by
  intro p hp
  have h : env44964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44963_44964 : H12AffineEnvironment.transform 12 40 env44963 = env44964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env44963 == env44964) = true)

theorem identity44964 : scanCanonicalize (H12AffineFastState.compose env44964 (packedSelected [1,2,8] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound44964 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44965 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,0,5124,34,17,7172,1025,5125,4145,32,17,3,41,16,2048,17,1029,2049,4132,5157,36,33,5125,5637]

theorem envBound44965 : H12AffineFastState.Bounded env44965 := by
  intro p hp
  have h : env44965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44964_44965 : H12AffineEnvironment.transform 13 0 env44964 = env44965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env44964 == env44965) = true)

def env44966 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,2097152,4194304,17,16777216,8193,65,21039104,18973701,2118709,2048,16876545,23159868,116,18990133,18949229,16818731]

theorem envBound44966 : H12AffineFastState.Bounded env44966 := by
  intro p hp
  have h : env44966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44952_44966 : H12AffineEnvironment.transform 7 117 env44952 = env44966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44952 == env44966) = true)

theorem identity44966 : scanCanonicalize (H12AffineFastState.compose env44966 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound44966 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env44967 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,16777216,8193,65,21039104,16834619,77835,2048,16876545,20971522,116,16818187,16793683,16818731]

theorem envBound44967 : H12AffineFastState.Bounded env44967 := by
  intro p hp
  have h : env44967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44966_44967 : H12AffineEnvironment.transform 20 91198 env44966 = env44967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env44966 == env44967) = true)

def env44968 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,16777216,8193,17,21039104,16834619,77835,2048,16876545,20971522,36,16818187,16793603,16818731]

theorem envBound44968 : H12AffineFastState.Bounded env44968 := by
  intro p hp
  have h : env44968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44967_44968 : H12AffineEnvironment.transform 5 16 env44967 = env44968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44967 == env44968) = true)

theorem identity44968 : scanCanonicalize (H12AffineFastState.compose env44968 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4292608) := by decide +kernel

theorem selectedBound44968 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44969 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,4292608,8193,17,34816,4284475,77835,2048,4195329,98306,36,4268043,4308995,4268587]

theorem envBound44969 : H12AffineFastState.Bounded env44969 := by
  intro p hp
  have h : env44969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44968_44969 : H12AffineEnvironment.transform 23 4292608 env44968 = env44969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292608 env44968 == env44969) = true)

theorem identity44969 : scanCanonicalize (H12AffineFastState.compose env44969 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound44969 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44970 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,8233,65536,16401,10280,1025,8232,91198,4194304,17,4268073,8193,17,10281,4284475,77835,2048,4195329,73771,36,4268043,4284458,4268587]

theorem envBound44970 : H12AffineFastState.Bounded env44970 := by
  intro p hp
  have h : env44970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44969_44970 : H12AffineEnvironment.transform 14 8233 env44969 = env44970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env44969 == env44970) = true)

theorem identity44970 : scanCanonicalize (H12AffineFastState.compose env44970 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 13357) := by decide +kernel

theorem selectedBound44970 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env44971 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13357,8233,65536,13372,10280,1025,8232,69651,4194304,17,4268073,8193,17,10281,4264982,77835,2048,4195329,73771,36,4268043,4264967,4268587]

theorem envBound44971 : H12AffineFastState.Bounded env44971 := by
  intro p hp
  have h : env44971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44970_44971 : H12AffineEnvironment.transform 13 13357 env44970 = env44971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13357 env44970 == env44971) = true)

theorem identity44971 : scanCanonicalize (H12AffineFastState.compose env44971 (packedSelected [2,11,12,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound44971 : packedSelected [2,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env44972 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13357,8233,65536,13372,10280,1025,8232,69651,8200,17,65569,8193,17,10281,78878,77835,2048,9225,73771,36,65539,78863,66083]

theorem envBound44972 : H12AffineFastState.Bounded env44972 := by
  intro p hp
  have h : env44972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44971_44972 : H12AffineEnvironment.transform 21 8200 env44971 = env44972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env44971 == env44972) = true)

theorem identity44972 : scanCanonicalize (H12AffineFastState.compose env44972 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44972 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env44973 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5124,0,65536,5141,2049,1025,1,69651,33,17,65569,40,17,2048,70711,69666,2048,1056,65538,36,65539,70694,66083]

theorem envBound44973 : H12AffineFastState.Bounded env44973 := by
  intro p hp
  have h : env44973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44972_44973 : H12AffineEnvironment.transform 12 41 env44972 = env44973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44972 == env44973) = true)

theorem identity44973 : scanCanonicalize (H12AffineFastState.compose env44973 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound44973 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env44974 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3076,41,2048,0,65536,2065,2049,1025,1,68631,33,17,65569,40,17,2048,67635,68646,2048,1056,65538,36,65539,67618,66083]

theorem envBound44974 : H12AffineFastState.Bounded env44974 := by
  intro p hp
  have h : env44974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44973_44974 : H12AffineEnvironment.transform 11 3076 env44973 = env44974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env44973 == env44974) = true)

theorem identity44974 : scanCanonicalize (H12AffineFastState.compose env44974 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound44974 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env44975 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3076,41,2048,0,35,2065,2049,1025,1,3124,33,17,2,40,17,2048,2064,3077,2048,1056,33,36,32,2049,512]

theorem envBound44975 : H12AffineFastState.Bounded env44975 := by
  intro p hp
  have h : env44975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44974_44975 : H12AffineEnvironment.transform 15 35 env44974 = env44975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env44974 == env44975) = true)

theorem identity44975 : scanCanonicalize (H12AffineFastState.compose env44975 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44975 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44976 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2097,41,2048,0,35,2065,2049,52,1,2049,33,17,2,40,17,2048,2064,2096,2048,21,33,36,32,2049,512]

theorem envBound44976 : H12AffineFastState.Bounded env44976 := by
  intro p hp
  have h : env44976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44975_44976 : H12AffineEnvironment.transform 9 53 env44975 = env44976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44975 == env44976) = true)

theorem identity44976 : scanCanonicalize (H12AffineFastState.compose env44976 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44976 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44977 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,48,41,1,0,35,16,0,52,1,0,33,17,2,40,17,1,17,49,1,21,33,36,32,0,512]

theorem envBound44977 : H12AffineFastState.Bounded env44977 := by
  intro p hp
  have h : env44977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44976_44977 : H12AffineEnvironment.transform 10 1 env44976 = env44977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44976 == env44977) = true)

theorem identity44977 : scanCanonicalize (H12AffineFastState.compose env44977 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44977 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44978 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,16,9,1,0,3,16,0,20,1,0,1,17,2,8,17,1,17,17,1,21,1,4,0,0,512]

theorem envBound44978 : H12AffineFastState.Bounded env44978 := by
  intro p hp
  have h : env44978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44977_44978 : H12AffineEnvironment.transform 4 0 env44977 = env44978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44977 == env44978) = true)

def env44979 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,16777216,8193,16,21039104,16834619,77835,2048,16876545,20971522,37,16818187,16793602,16818731]

theorem envBound44979 : H12AffineFastState.Bounded env44979 := by
  intro p hp
  have h : env44979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44967_44979 : H12AffineEnvironment.transform 5 17 env44967 = env44979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44967 == env44979) = true)

theorem identity44979 : scanCanonicalize (H12AffineFastState.compose env44979 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4235275) := by decide +kernel

theorem selectedBound44979 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44980 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,4194304,17,4235275,8193,16,108555,4210736,77835,2048,4269066,40969,37,4194304,4251657,4194848]

theorem envBound44980 : H12AffineFastState.Bounded env44980 := by
  intro p hp
  have h : env44980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44979_44980 : H12AffineEnvironment.transform 23 4235275 env44979 = env44980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4235275 env44979 == env44980) = true)

theorem identity44980 : scanCanonicalize (H12AffineFastState.compose env44980 (packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound44980 : packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env44981 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34817,1025,32769,91198,8201,17,32770,8193,16,108555,24633,77835,2048,66563,40969,37,8201,49152,8745]

theorem envBound44981 : H12AffineFastState.Bounded env44981 := by
  intro p hp
  have h : env44981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44980_44981 : H12AffineEnvironment.transform 21 8201 env44980 = env44981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env44980 == env44981) = true)

theorem identity44981 : scanCanonicalize (H12AffineFastState.compose env44981 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound44981 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env44982 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,8232,65536,16401,10281,1025,8233,91198,8201,17,8234,8193,16,67619,24633,77835,2048,66563,33,37,8201,24616,8745]

theorem envBound44982 : H12AffineFastState.Bounded env44982 := by
  intro p hp
  have h : env44982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44981_44982 : H12AffineEnvironment.transform 14 8232 env44981 = env44982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env44981 == env44982) = true)

theorem identity44982 : scanCanonicalize (H12AffineFastState.compose env44982 (packedSelected [12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound44982 : packedSelected [12,15,17] rootPS < 2^1333 := by decide +kernel

def env44983 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,1052,16384,1076,65536,16401,3125,1025,1077,81954,1045,17,1078,1053,16,67619,17445,70679,2048,66563,33,37,1045,17460,1589]

theorem envBound44983 : H12AffineFastState.Bounded env44983 := by
  intro p hp
  have h : env44983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44982_44983 : H12AffineEnvironment.transform 12 1052 env44982 = env44983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env44982 == env44983) = true)

theorem identity44983 : scanCanonicalize (H12AffineFastState.compose env44983 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44983 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44984 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,16384,1,65536,16401,2048,52,0,81954,32,17,3,40,16,67619,16400,69666,2048,65590,33,37,32,16385,512]

theorem envBound44984 : H12AffineFastState.Bounded env44984 := by
  intro p hp
  have h : env44984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44983_44984 : H12AffineEnvironment.transform 9 53 env44983 = env44984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44983 == env44984) = true)

theorem identity44984 : scanCanonicalize (H12AffineFastState.compose env44984 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound44984 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44985 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,16384,1,2,16401,2048,52,0,16416,32,17,3,40,16,2081,16400,4128,2048,52,33,37,32,16385,512]

theorem envBound44985 : H12AffineFastState.Bounded env44985 := by
  intro p hp
  have h : env44985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44984_44985 : H12AffineEnvironment.transform 15 2 env44984 = env44985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env44984 == env44985) = true)

theorem identity44985 : scanCanonicalize (H12AffineFastState.compose env44985 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound44985 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44986 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4145,1,2,4128,2048,52,0,4113,32,17,3,40,16,2081,4129,4128,2048,52,33,37,32,4144,512]

theorem envBound44986 : H12AffineFastState.Bounded env44986 := by
  intro p hp
  have h : env44986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44985_44986 : H12AffineEnvironment.transform 13 4145 env44985 = env44986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env44985 == env44986) = true)

theorem identity44986 : scanCanonicalize (H12AffineFastState.compose env44986 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound44986 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env44987 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2097,41,2048,1,2,2065,2048,52,0,2080,32,17,3,40,16,2081,2064,2065,2048,52,33,37,32,2049,512]

theorem envBound44987 : H12AffineFastState.Bounded env44987 := by
  intro p hp
  have h : env44987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44986_44987 : H12AffineEnvironment.transform 11 2097 env44986 = env44987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env44986 == env44987) = true)

theorem identity44987 : scanCanonicalize (H12AffineFastState.compose env44987 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44987 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env44988 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2064,8,2048,1,2,2065,2048,21,0,2049,1,17,3,9,16,2048,2064,2065,2048,21,0,4,1,2049,512]

theorem envBound44988 : H12AffineFastState.Bounded env44988 := by
  intro p hp
  have h : env44988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44987_44988 : H12AffineEnvironment.transform 4 1 env44987 = env44988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44987 == env44988) = true)

theorem identity44988 : scanCanonicalize (H12AffineFastState.compose env44988 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44988 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44989 : List Nat := [2,4,8,16,1,17,9,5,0,20,2048,2064,8,2048,1,2,2065,2048,21,0,2049,1,17,3,9,16,2048,2064,2065,2048,21,0,4,1,2049,0]

theorem envBound44989 : H12AffineFastState.Bounded env44989 := by
  intro p hp
  have h : env44989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44988_44989 : H12AffineEnvironment.transform 8 0 env44988 = env44989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44988 == env44989) = true)

theorem identity44989 : scanCanonicalize (H12AffineFastState.compose env44989 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound44989 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44990 : List Nat := [2,4,8,16,1,17,9,5,0,20,30,14,8,30,1,2,15,30,21,0,31,1,17,3,9,16,30,14,15,30,21,0,4,1,31,0]

theorem envBound44990 : H12AffineFastState.Bounded env44990 := by
  intro p hp
  have h : env44990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44989_44990 : H12AffineEnvironment.transform 10 30 env44989 = env44990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env44989 == env44990) = true)

def leafEnv44990 : List Nat := [2,4,8,16,1,17,9,5,0,20,30,14,8,30,1,2,15,30,21,0,31,1,17,3,20,9,1,16,30,14,15,30,21,0,4,1,5,3,31,0,1,30,0]

def active44990 : List Nat := [0,1,2,3]

def tree44990 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44990 : H12WitnessSearch.Good tree44990 := H12GlobalWitnessIndex.good

theorem leafIdentity44990 : H12AffineFastState.composeSystem env44990 rootObs = leafEnv44990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44990 rootObs == leafEnv44990) = true)

theorem terminalChecked44990 : H12PackedTerminal.terminalCheckFast leafEnv44990 active44990 tree44990 = true := by decide +kernel

def env44991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35324,1025,32769,2097152,4194304,153,16777216,8328,65,21039613,18973836,2119112,2557,16876681,23160256,257,18990132,18949520,16819039]

theorem envBound44991 : H12AffineFastState.Bounded env44991 := by
  intro p hp
  have h : env44991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44939_44991 : H12AffineEnvironment.transform 16 16537 env44939 = env44991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env44939 == env44991) = true)

theorem identity44991 : scanCanonicalize (H12AffineFastState.compose env44991 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound44991 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10280,1025,8661,2097152,4194304,153,16777216,8328,65,21039613,18949464,2119112,2557,16852317,23160256,257,18965984,18949520,16777867]

theorem envBound44992 : H12AffineFastState.Bounded env44992 := by
  intro p hp
  have h : env44992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44991_44992 : H12AffineEnvironment.transform 14 8660 env44991 = env44992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env44991 == env44992) = true)

def env44993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,2097152,4194304,17,16777216,8192,65,21039477,18949464,2118976,2421,16852317,23160136,257,18965864,18949400,16777731]

theorem envBound44993 : H12AffineFastState.Bounded env44993 := by
  intro p hp
  have h : env44993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44992_44993 : H12AffineEnvironment.transform 6 8 env44992 = env44993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44992 == env44993) = true)

theorem identity44993 : scanCanonicalize (H12AffineFastState.compose env44993 (packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 2188349) := by decide +kernel

theorem selectedBound44993 : packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env44994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,2097152,4194304,17,2188349,8192,65,6319432,16741,2118976,2421,2113888,4194677,257,341,16677,2188862]

theorem envBound44994 : H12AffineFastState.Bounded env44994 := by
  intro p hp
  have h : env44994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44993_44994 : H12AffineEnvironment.transform 23 2188349 env44993 = env44994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188349 env44993 == env44994) = true)

theorem identity44994 : scanCanonicalize (H12AffineFastState.compose env44994 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44994 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env44995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,2097152,4194304,17,2114614,8192,65,6319432,16741,2118976,2421,2113888,4194677,257,341,16677,2115125]

theorem envBound44995 : H12AffineFastState.Bounded env44995 := by
  intro p hp
  have h : env44995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44994_44995 : H12AffineEnvironment.transform 15 8203 env44994 = env44995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44994 == env44995) = true)

theorem identity44995 : scanCanonicalize (H12AffineFastState.compose env44995 (packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound44995 : packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env44996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,2097152,32,17,2114614,8192,65,2125160,16741,2118976,2421,2113888,341,257,341,16677,2115125]

theorem envBound44996 : H12AffineFastState.Bounded env44996 := by
  intro p hp
  have h : env44996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44995_44996 : H12AffineEnvironment.transform 21 32 env44995 = env44996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44995 == env44996) = true)

theorem identity44996 : scanCanonicalize (H12AffineFastState.compose env44996 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound44996 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env44997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8540,8203,13625,10280,1025,8541,2097152,32,17,2109726,8192,65,2103360,13389,2105448,2421,2110536,341,257,341,13325,2110237]

theorem envBound44997 : H12AffineFastState.Bounded env44997 := by
  intro p hp
  have h : env44997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44996_44997 : H12AffineEnvironment.transform 13 13608 env44996 = env44997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env44996 == env44997) = true)

theorem identity44997 : scanCanonicalize (H12AffineFastState.compose env44997 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 12605) := by decide +kernel

theorem selectedBound44997 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8540,8203,13625,10280,1025,8541,12605,32,17,35,8192,65,10621,13389,4437,2421,1397,341,257,341,13325,544]

theorem envBound44998 : H12AffineFastState.Bounded env44998 := by
  intro p hp
  have h : env44998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44997_44998 : H12AffineEnvironment.transform 20 12605 env44997 = env44998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12605 env44997 == env44998) = true)

theorem identity44998 : scanCanonicalize (H12AffineFastState.compose env44998 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44998 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env44999 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13405,8233,8203,13388,10280,1025,8232,12360,32,17,35,8192,65,10248,13389,4128,2048,1024,32,116,32,13325,544]

theorem envBound44999 : H12AffineFastState.Bounded env44999 := by
  intro p hp
  have h : env44999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44998_44999 : H12AffineEnvironment.transform 7 117 env44998 = env44999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44998 == env44999) = true)

def env45000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1025,8540,2097152,4194304,16,16777216,8193,65,21039476,18949464,2118977,2420,16852317,23160137,257,18965865,18949401,16777730]

theorem envBound45000 : H12AffineFastState.Bounded env45000 := by
  intro p hp
  have h : env45000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44992_45000 : H12AffineEnvironment.transform 6 9 env44992 = env45000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44992 == env45000) = true)

theorem identity45000 : scanCanonicalize (H12AffineFastState.compose env45000 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound45000 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1025,8540,2097152,4194304,16,3,8193,65,4262263,2172251,2118977,2420,75102,6382922,257,2188650,2172186,513]

theorem envBound45001 : H12AffineFastState.Bounded env45001 := by
  intro p hp
  have h : env45001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45000_45001 : H12AffineEnvironment.transform 23 3 env45000 = env45001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env45000 == env45001) = true)

theorem identity45001 : scanCanonicalize (H12AffineFastState.compose env45001 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45001 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,2097152,4194304,16,3,8193,65,4204925,2098513,2118977,2420,1364,6309184,257,2114912,2098448,513]

theorem envBound45002 : H12AffineFastState.Bounded env45002 := by
  intro p hp
  have h : env45002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45001_45002 : H12AffineEnvironment.transform 15 8202 env45001 = env45002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45001 == env45002) = true)

theorem identity45002 : scanCanonicalize (H12AffineFastState.compose env45002 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound45002 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,2097152,2114913,16,3,8193,65,2124828,2098513,2118977,2420,1364,33,257,2114912,2098448,513]

theorem envBound45003 : H12AffineFastState.Bounded env45003 := by
  intro p hp
  have h : env45003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45002_45003 : H12AffineEnvironment.transform 21 2114913 env45002 = env45003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env45002 == env45003) = true)

theorem identity45003 : scanCanonicalize (H12AffineFastState.compose env45003 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound45003 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,17728,33,16,3,8193,65,10588,16401,4097,2420,1364,33,257,32,16464,513]

theorem envBound45004 : H12AffineFastState.Bounded env45004 := by
  intro p hp
  have h : env45004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45003_45004 : H12AffineEnvironment.transform 20 17728 env45003 = env45004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env45003 == env45004) = true)

theorem identity45004 : scanCanonicalize (H12AffineFastState.compose env45004 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound45004 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,8202,13340,10280,1025,8540,12620,33,16,3,8193,65,10588,13341,4097,2420,1364,33,257,32,13404,513]

theorem envBound45005 : H12AffineFastState.Bounded env45005 := by
  intro p hp
  have h : env45005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45004_45005 : H12AffineEnvironment.transform 13 13324 env45004 = env45005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env45004 == env45005) = true)

theorem identity45005 : scanCanonicalize (H12AffineFastState.compose env45005 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45005 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env45006 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,0,343,5441,2421,1025,1,4113,33,16,3,348,65,2049,5440,4097,2420,1364,33,257,32,5377,513]

theorem envBound45006 : H12AffineFastState.Bounded env45006 := by
  intro p hp
  have h : env45006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45005_45006 : H12AffineEnvironment.transform 12 349 env45005 = env45006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45005 == env45006) = true)

theorem identity45006 : scanCanonicalize (H12AffineFastState.compose env45006 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound45006 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45007 : List Nat := [2,4,8,16,32,64,9,256,512,785,2048,4096,349,4672,0,343,4688,2421,784,1,4113,33,16,3,348,65,2049,4689,4097,2420,581,33,257,32,4624,513]

theorem envBound45007 : H12AffineFastState.Bounded env45007 := by
  intro p hp
  have h : env45007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45006_45007 : H12AffineEnvironment.transform 9 785 env45006 = env45007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env45006 == env45007) = true)

theorem identity45007 : scanCanonicalize (H12AffineFastState.compose env45007 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound45007 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45008 : List Nat := [2,4,8,16,32,64,9,256,512,785,2048,80,349,528,0,343,512,2421,784,1,65,33,16,3,348,65,2049,513,81,2420,581,33,257,32,576,513]

theorem envBound45008 : H12AffineFastState.Bounded env45008 := by
  intro p hp
  have h : env45008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45007_45008 : H12AffineEnvironment.transform 11 80 env45007 = env45008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env45007 == env45008) = true)

def env45009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356289,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound45009 : H12AffineFastState.Bounded env45009 := by
  intro p hp
  have h : env45009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44728_45009 : H12AffineEnvironment.transform 26 30393345 env44728 = env45009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env44728 == env45009) = true)

def env45010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound45010 : H12AffineFastState.Bounded env45010 := by
  intro p hp
  have h : env45010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45009_45010 : H12AffineEnvironment.transform 18 1024 env45009 = env45010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env45009 == env45010) = true)

theorem identity45010 : scanCanonicalize (H12AffineFastState.compose env45010 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 396324) := by decide +kernel

theorem selectedBound45010 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,8388608,16777216,8328,65,29868033,17270953,8804725,8830977,25265168,21457381,256,25675913,25635117,25207751]

theorem envBound45011 : H12AffineFastState.Bounded env45011 := by
  intro p hp
  have h : env45011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45010_45011 : H12AffineEnvironment.transform 20 396324 env45010 = env45011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 396324 env45010 == env45011) = true)

def env45012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,8388608,8887720,8328,65,4218281,8393985,8804725,8830977,399800,12645453,256,21793,46213,474735]

theorem envBound45012 : H12AffineFastState.Bounded env45012 := by
  intro p hp
  have h : env45012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45011_45012 : H12AffineEnvironment.transform 23 8887720 env45011 = env45012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887720 env45011 == env45012) = true)

def env45013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,452768,95496,8328,65,4218281,458145,45525,10401,399800,4594925,256,21793,46213,474735]

theorem envBound45013 : H12AffineFastState.Bounded env45013 := by
  intro p hp
  have h : env45013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45012_45013 : H12AffineEnvironment.transform 22 452768 env45012 = env45013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env45012 == env45013) = true)

def env45014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272512,452768,95496,8328,65,292137,458145,45525,10401,399800,144493,256,21793,46213,474735]

theorem envBound45014 : H12AffineFastState.Bounded env45014 := by
  intro p hp
  have h : env45014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45013_45014 : H12AffineEnvironment.transform 21 272512 env45013 = env45014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45013 == env45014) = true)

theorem identity45014 : scanCanonicalize (H12AffineFastState.compose env45014 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound45014 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,115871,254011,73755,95496,8328,65,245138,79130,45525,10401,119043,144493,256,21793,46213,63188]

theorem envBound45015 : H12AffineFastState.Bounded env45015 := by
  intro p hp
  have h : env45015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45014_45015 : H12AffineEnvironment.transform 17 247995 env45014 = env45015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env45014 == env45015) = true)

def env45016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,67755,1024,32769,115871,73771,73755,95496,8328,65,97666,79130,45525,10401,119043,62589,256,21793,46213,63188]

theorem envBound45016 : H12AffineFastState.Bounded env45016 := by
  intro p hp
  have h : env45016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45015_45016 : H12AffineEnvironment.transform 16 49168 env45015 = env45016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45015 == env45016) = true)

theorem identity45016 : scanCanonicalize (H12AffineFastState.compose env45016 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound45016 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env45017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25028,67755,1024,8661,91467,73771,73755,95496,8328,65,97666,79130,4097,10401,94423,21929,256,21793,5457,22272]

theorem envBound45017 : H12AffineFastState.Bounded env45017 := by
  intro p hp
  have h : env45017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45016_45017 : H12AffineEnvironment.transform 14 8660 env45016 = env45017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env45016 == env45017) = true)

theorem identity45017 : scanCanonicalize (H12AffineFastState.compose env45017 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound45017 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8323,25028,10280,1024,8661,17864,168,152,21899,8328,65,23809,5529,4097,10401,20564,21929,256,21793,5457,22272]

theorem envBound45018 : H12AffineFastState.Bounded env45018 := by
  intro p hp
  have h : env45018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45017_45018 : H12AffineEnvironment.transform 15 8323 env45017 = env45018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env45017 == env45018) = true)

theorem identity45018 : scanCanonicalize (H12AffineFastState.compose env45018 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound45018 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env45019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,0,343,16400,2556,1024,1,17864,168,152,21899,348,65,23809,5529,4097,2421,20564,21929,256,21793,5457,22272]

theorem envBound45019 : H12AffineFastState.Bounded env45019 := by
  intro p hp
  have h : env45019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45018_45019 : H12AffineEnvironment.transform 12 468 env45018 = env45019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env45018 == env45019) = true)

theorem identity45019 : scanCanonicalize (H12AffineFastState.compose env45019 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45019 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,0,343,5393,2556,1024,1,4297,168,152,138,348,65,2048,5529,4097,2421,1365,168,256,32,5457,513]

theorem envBound45020 : H12AffineFastState.Bounded env45020 := by
  intro p hp
  have h : env45020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45019_45020 : H12AffineEnvironment.transform 13 5377 env45019 = env45020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45019 == env45020) = true)

theorem identity45020 : scanCanonicalize (H12AffineFastState.compose env45020 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45020 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env45021 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5393,2421,1024,1,4160,33,17,3,348,65,2048,5392,4097,2421,1365,33,256,32,5457,513]

theorem envBound45021 : H12AffineFastState.Bounded env45021 := by
  intro p hp
  have h : env45021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45020_45021 : H12AffineEnvironment.transform 6 9 env45020 = env45021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45020 == env45021) = true)

theorem identity45021 : scanCanonicalize (H12AffineFastState.compose env45021 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45021 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45022 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,0,34,5220,2048,1024,1,4160,33,17,3,41,65,2048,5221,4097,2048,1056,33,117,32,5156,513]

theorem envBound45022 : H12AffineFastState.Bounded env45022 := by
  intro p hp
  have h : env45022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45021_45022 : H12AffineEnvironment.transform 7 117 env45021 = env45022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45021 == env45022) = true)

theorem identity45022 : scanCanonicalize (H12AffineFastState.compose env45022 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45022 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45023 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5172,2048,1024,1,4112,33,17,3,41,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound45023 : H12AffineFastState.Bounded env45023 := by
  intro p hp
  have h : env45023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45022_45023 : H12AffineEnvironment.transform 5 16 env45022 = env45023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45022 == env45023) = true)

def env45024 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1044,0,34,1028,2048,1024,1,32,33,17,3,41,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound45024 : H12AffineFastState.Bounded env45024 := by
  intro p hp
  have h : env45024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45023_45024 : H12AffineEnvironment.transform 11 48 env45023 = env45024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45023 == env45024) = true)

theorem identity45024 : scanCanonicalize (H12AffineFastState.compose env45024 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound45024 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45025 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1540,48,40,1044,0,34,1028,1540,1024,1,32,33,17,3,41,17,1540,1029,49,1540,1056,33,37,32,1044,513]

theorem envBound45025 : H12AffineFastState.Bounded env45025 := by
  intro p hp
  have h : env45025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45024_45025 : H12AffineEnvironment.transform 10 1540 env45024 = env45025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env45024 == env45025) = true)

def env45026 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,48,40,32,0,34,48,560,52,1,32,33,17,3,41,17,560,49,49,560,20,33,37,32,32,513]

theorem envBound45026 : H12AffineFastState.Bounded env45026 := by
  intro p hp
  have h : env45026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45025_45026 : H12AffineEnvironment.transform 9 52 env45025 = env45026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45025 == env45026) = true)

theorem identity45026 : scanCanonicalize (H12AffineFastState.compose env45026 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound45026 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45027 : List Nat := [2,4,8,16,27,16,9,30,512,15,523,11,19,27,0,25,11,523,15,1,27,26,17,3,18,17,523,10,10,523,20,26,30,27,27,513]

theorem envBound45027 : H12AffineFastState.Bounded env45027 := by
  intro p hp
  have h : env45027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45026_45027 : H12AffineEnvironment.transform 4 27 env45026 = env45027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env45026 == env45027) = true)

def leafEnv45027 : List Nat := [2,4,8,16,27,16,9,30,512,15,523,11,19,27,0,25,11,523,15,1,27,26,17,3,20,18,1,17,523,10,10,523,20,26,30,27,4,24,27,513,1,27,0]

def active45027 : List Nat := [0,1,2,3,8]

def tree45027 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45027 : H12WitnessSearch.Good tree45027 := H12GlobalWitnessIndex.good

theorem leafIdentity45027 : H12AffineFastState.composeSystem env45027 rootObs = leafEnv45027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45027 rootObs == leafEnv45027) = true)

theorem terminalChecked45027 : H12PackedTerminal.terminalCheckFast leafEnv45027 active45027 tree45027 = true := by decide +kernel

def env45028 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,48,40,33,0,34,49,561,53,1,32,33,17,3,41,17,561,48,49,561,21,33,37,32,33,513]

theorem envBound45028 : H12AffineFastState.Bounded env45028 := by
  intro p hp
  have h : env45028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45025_45028 : H12AffineEnvironment.transform 9 53 env45025 = env45028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45025 == env45028) = true)

theorem identity45028 : scanCanonicalize (H12AffineFastState.compose env45028 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45029 : List Nat := [2,4,8,16,32,16,9,37,17,53,32,48,40,33,0,34,49,32,53,1,32,33,17,3,41,17,32,48,49,32,21,33,37,32,33,16]

theorem envBound45029 : H12AffineFastState.Bounded env45029 := by
  intro p hp
  have h : env45029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45028_45029 : H12AffineEnvironment.transform 8 17 env45028 = env45029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45028 == env45029) = true)

def leafEnv45029 : List Nat := [2,4,8,16,32,16,9,37,17,53,32,48,40,33,0,34,49,32,53,1,32,33,17,3,21,41,1,17,32,48,49,32,21,33,37,32,4,35,33,16,1,32,0]

def active45029 : List Nat := [0,1,2,3,4]

def tree45029 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45029 : H12WitnessSearch.Good tree45029 := H12GlobalWitnessIndex.good

theorem leafIdentity45029 : H12AffineFastState.composeSystem env45029 rootObs = leafEnv45029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45029 rootObs == leafEnv45029) = true)

theorem terminalChecked45029 : H12PackedTerminal.terminalCheckFast leafEnv45029 active45029 tree45029 = true := by decide +kernel

def env45030 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1045,0,34,1029,2048,1024,1,33,33,17,3,41,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound45030 : H12AffineFastState.Bounded env45030 := by
  intro p hp
  have h : env45030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45023_45030 : H12AffineEnvironment.transform 11 49 env45023 = env45030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45023 == env45030) = true)

theorem identity45030 : scanCanonicalize (H12AffineFastState.compose env45030 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound45030 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45031 : List Nat := [2,4,8,16,32,16,9,37,512,1024,561,49,40,1045,0,34,1029,561,1024,1,33,33,17,3,41,17,561,1028,48,561,1056,33,37,32,1045,513]

theorem envBound45031 : H12AffineFastState.Bounded env45031 := by
  intro p hp
  have h : env45031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45030_45031 : H12AffineEnvironment.transform 10 561 env45030 = env45031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env45030 == env45031) = true)

def env45032 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,49,40,33,0,34,49,561,52,1,33,33,17,3,41,17,561,48,48,561,20,33,37,32,33,513]

theorem envBound45032 : H12AffineFastState.Bounded env45032 := by
  intro p hp
  have h : env45032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45031_45032 : H12AffineEnvironment.transform 9 52 env45031 = env45032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45031 == env45032) = true)

theorem identity45032 : scanCanonicalize (H12AffineFastState.compose env45032 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound45032 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45033 : List Nat := [2,4,8,16,26,16,9,31,512,14,523,11,18,27,0,24,11,523,14,1,27,27,17,3,19,17,523,10,10,523,20,27,31,26,27,513]

theorem envBound45033 : H12AffineFastState.Bounded env45033 := by
  intro p hp
  have h : env45033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45032_45033 : H12AffineEnvironment.transform 4 26 env45032 = env45033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env45032 == env45033) = true)

def leafEnv45033 : List Nat := [2,4,8,16,26,16,9,31,512,14,523,11,18,27,0,24,11,523,14,1,27,27,17,3,20,19,1,17,523,10,10,523,20,27,31,26,4,25,27,513,1,27,0]

def active45033 : List Nat := [0,1,2,3,8]

def tree45033 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45033 : H12WitnessSearch.Good tree45033 := H12GlobalWitnessIndex.good

theorem leafIdentity45033 : H12AffineFastState.composeSystem env45033 rootObs = leafEnv45033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45033 rootObs == leafEnv45033) = true)

theorem terminalChecked45033 : H12PackedTerminal.terminalCheckFast leafEnv45033 active45033 tree45033 = true := by decide +kernel

def env45034 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,49,40,32,0,34,48,561,53,1,33,33,17,3,41,17,561,49,48,561,21,33,37,32,32,513]

theorem envBound45034 : H12AffineFastState.Bounded env45034 := by
  intro p hp
  have h : env45034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45031_45034 : H12AffineEnvironment.transform 9 53 env45031 = env45034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45031 == env45034) = true)

theorem identity45034 : scanCanonicalize (H12AffineFastState.compose env45034 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45035 : List Nat := [2,4,8,16,32,16,9,37,16,53,33,49,40,32,0,34,48,33,53,1,33,33,17,3,41,17,33,49,48,33,21,33,37,32,32,17]

theorem envBound45035 : H12AffineFastState.Bounded env45035 := by
  intro p hp
  have h : env45035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45034_45035 : H12AffineEnvironment.transform 8 16 env45034 = env45035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45034 == env45035) = true)

def leafEnv45035 : List Nat := [2,4,8,16,32,16,9,37,16,53,33,49,40,32,0,34,48,33,53,1,33,33,17,3,21,41,1,17,33,49,48,33,21,33,37,32,4,35,32,17,1,33,0]

def active45035 : List Nat := [0,1,2,3,4]

def tree45035 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45035 : H12WitnessSearch.Good tree45035 := H12GlobalWitnessIndex.good

theorem leafIdentity45035 : H12AffineFastState.composeSystem env45035 rootObs = leafEnv45035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45035 rootObs == leafEnv45035) = true)

theorem terminalChecked45035 : H12PackedTerminal.terminalCheckFast leafEnv45035 active45035 tree45035 = true := by decide +kernel

def env45036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,67754,1024,32769,115871,73770,73755,95496,8328,65,97667,79130,45525,10401,119043,62588,256,21793,46213,63188]

theorem envBound45036 : H12AffineFastState.Bounded env45036 := by
  intro p hp
  have h : env45036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45015_45036 : H12AffineEnvironment.transform 16 49169 env45015 = env45036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45015 == env45036) = true)

theorem identity45036 : scanCanonicalize (H12AffineFastState.compose env45036 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound45036 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env45037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,5393,67754,1024,21761,70047,73770,73755,95496,8328,65,97667,79130,25813,10401,66563,8572,256,21793,24965,9172]

theorem envBound45037 : H12AffineFastState.Bounded env45037 := by
  intro p hp
  have h : env45037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45036_45037 : H12AffineEnvironment.transform 14 21760 env45036 = env45037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env45036 == env45037) = true)

theorem identity45037 : scanCanonicalize (H12AffineFastState.compose env45037 (packedSelected [3,4,7,9,10,14,24,26,27,35] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45037 : packedSelected [3,4,7,9,10,14,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env45038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21760,65536,5393,67754,1024,21761,70047,65910,65863,87124,468,65,89311,70726,17801,2557,66563,32,256,21793,16601,648]

theorem envBound45038 : H12AffineFastState.Bounded env45038 := by
  intro p hp
  have h : env45038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45037_45038 : H12AffineEnvironment.transform 12 348 env45037 = env45038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45037 == env45038) = true)

theorem identity45038 : scanCanonicalize (H12AffineFastState.compose env45038 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45038 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45039 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,5393,67619,1024,21761,69910,65910,65863,87124,349,65,89174,70726,17664,2420,66563,32,256,21793,16464,513]

theorem envBound45039 : H12AffineFastState.Bounded env45039 := by
  intro p hp
  have h : env45039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45038_45039 : H12AffineEnvironment.transform 6 9 env45038 = env45039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45038 == env45039) = true)

def env45040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272513,452768,95496,8328,65,292136,458145,45525,10401,399800,144492,256,21793,46213,474735]

theorem envBound45040 : H12AffineFastState.Bounded env45040 := by
  intro p hp
  have h : env45040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45013_45040 : H12AffineEnvironment.transform 21 272513 env45013 = env45040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45013 == env45040) = true)

theorem identity45040 : scanCanonicalize (H12AffineFastState.compose env45040 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45040 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396324,272513,452768,21763,8328,65,292136,458145,45525,10401,399800,144492,256,21793,46213,400996]

theorem envBound45041 : H12AffineFastState.Bounded env45041 := by
  intro p hp
  have h : env45041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45040_45041 : H12AffineEnvironment.transform 15 8203 env45040 = env45041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45040 == env45041) = true)

def env45042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396324,272393,452648,21763,8192,65,292136,458025,45405,10281,399664,144492,256,21793,46093,400996]

theorem envBound45042 : H12AffineFastState.Bounded env45042 := by
  intro p hp
  have h : env45042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45041_45042 : H12AffineEnvironment.transform 6 8 env45041 = env45042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45041 == env45042) = true)

theorem identity45042 : scanCanonicalize (H12AffineFastState.compose env45042 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46393) := by decide +kernel

theorem selectedBound45042 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,46393,262144,1024,32769,309533,272393,285969,21763,8192,65,292136,280592,45405,10281,306185,33109,256,21793,46093,306013]

theorem envBound45043 : H12AffineFastState.Bounded env45043 := by
  intro p hp
  have h : env45043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45042_45043 : H12AffineEnvironment.transform 16 46393 env45042 = env45043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46393 env45042 == env45043) = true)

theorem identity45043 : scanCanonicalize (H12AffineFastState.compose env45043 (packedSelected [0,2,4,7,8,10,11,12,14,15,17,22,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound45043 : packedSelected [0,2,4,7,8,10,11,12,14,15,17,22,23,28] rootPS < 2^1333 := by decide +kernel

def env45044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,8203,5393,262144,1024,8233,268597,272393,285969,21763,8192,65,292136,280592,4469,10281,265249,8573,256,21793,5157,265077]

theorem envBound45044 : H12AffineFastState.Bounded env45044 := by
  intro p hp
  have h : env45044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45043_45044 : H12AffineEnvironment.transform 14 8232 env45043 = env45044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env45043 == env45044) = true)

theorem identity45044 : scanCanonicalize (H12AffineFastState.compose env45044 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45044 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env45045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,8203,5393,10280,1024,8233,12573,33,30009,21763,8192,65,23808,24632,4469,10281,9225,8573,256,21793,5157,9053]

theorem envBound45045 : H12AffineFastState.Bounded env45045 := by
  intro p hp
  have h : env45045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45044_45045 : H12AffineEnvironment.transform 17 10280 env45044 = env45045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45044 == env45045) = true)

theorem identity45045 : scanCanonicalize (H12AffineFastState.compose env45045 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound45045 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8232,8203,5393,10280,1024,8233,12573,33,356,8542,8192,65,10589,5221,4469,10281,9225,8573,256,8572,5157,9053]

theorem envBound45046 : H12AffineFastState.Bounded env45046 := by
  intro p hp
  have h : env45046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45045_45046 : H12AffineEnvironment.transform 13 13405 env45045 = env45046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env45045 == env45046) = true)

theorem identity45046 : scanCanonicalize (H12AffineFastState.compose env45046 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45046 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45047 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,8232,8203,5221,10280,1024,8233,12393,33,16,8234,8192,65,10281,5221,4097,10281,9225,8201,116,8200,5157,8745]

theorem envBound45047 : H12AffineFastState.Bounded env45047 := by
  intro p hp
  have h : env45047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45046_45047 : H12AffineEnvironment.transform 7 116 env45046 = env45047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45046 == env45047) = true)

theorem identity45047 : scanCanonicalize (H12AffineFastState.compose env45047 (packedSelected [0,1,2,3,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound45047 : packedSelected [0,1,2,3,6,7,12] rootPS < 2^1333 := by decide +kernel

def env45048 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2059,8192,11350,8232,8203,3182,10280,1024,8233,10338,33,16,8234,8192,65,10281,3182,2058,10281,9225,8201,116,8200,3118,8745]

theorem envBound45048 : H12AffineFastState.Bounded env45048 := by
  intro p hp
  have h : env45048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45047_45048 : H12AffineEnvironment.transform 11 2059 env45047 = env45048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env45047 == env45048) = true)

theorem identity45048 : scanCanonicalize (H12AffineFastState.compose env45048 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound45048 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env45049 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2059,1031,2129,1071,1036,3182,3119,1024,1070,3173,33,16,1069,1031,65,3118,3182,2058,3118,14,1038,116,1039,3118,1582]

theorem envBound45049 : H12AffineFastState.Bounded env45049 := by
  intro p hp
  have h : env45049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45048_45049 : H12AffineEnvironment.transform 12 1031 env45048 = env45049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env45048 == env45049) = true)

theorem identity45049 : scanCanonicalize (H12AffineFastState.compose env45049 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45049 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env45050 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2059,1031,2048,1071,1036,3135,3119,1024,1070,3124,33,16,1069,1031,16,3118,3135,2058,3118,14,1038,37,1039,3118,1582]

theorem envBound45050 : H12AffineFastState.Bounded env45050 := by
  intro p hp
  have h : env45050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45049_45050 : H12AffineEnvironment.transform 5 17 env45049 = env45050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45049 == env45050) = true)

theorem identity45050 : scanCanonicalize (H12AffineFastState.compose env45050 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound45050 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45051 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1028,1039,1031,1028,1071,1036,59,43,1024,1070,48,33,16,1069,1031,16,42,59,1038,42,14,1038,37,1039,42,1582]

theorem envBound45051 : H12AffineFastState.Bounded env45051 := by
  intro p hp
  have h : env45051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45050_45051 : H12AffineEnvironment.transform 10 1028 env45050 = env45051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env45050 == env45051) = true)

theorem identity45051 : scanCanonicalize (H12AffineFastState.compose env45051 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45051 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env45052 : List Nat := [2,4,8,10,32,11,8,37,512,1024,1028,1039,1031,1028,1071,1036,33,43,1024,1070,42,33,10,1069,1031,10,42,33,1038,42,14,1038,37,1039,42,1582]

theorem envBound45052 : H12AffineFastState.Bounded env45052 := by
  intro p hp
  have h : env45052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45051_45052 : H12AffineEnvironment.transform 3 10 env45051 = env45052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45051 == env45052) = true)

theorem identity45052 : scanCanonicalize (H12AffineFastState.compose env45052 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound45052 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env45053 : List Nat := [2,4,8,10,32,11,8,37,4,1024,1028,1039,1031,1028,1071,1036,33,43,1024,1070,42,33,10,1069,1031,10,42,33,1038,42,14,1038,37,1039,42,1066]

theorem envBound45053 : H12AffineFastState.Bounded env45053 := by
  intro p hp
  have h : env45053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45052_45053 : H12AffineEnvironment.transform 8 4 env45052 = env45053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env45052 == env45053) = true)

theorem identity45053 : scanCanonicalize (H12AffineFastState.compose env45053 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45053 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45054 : List Nat := [2,4,3,1,32,0,3,37,4,1024,1028,1028,1031,1028,1060,1031,33,32,1024,1061,33,33,1,1062,1031,1,33,33,1029,33,5,1029,37,1028,33,1057]

theorem envBound45054 : H12AffineFastState.Bounded env45054 := by
  intro p hp
  have h : env45054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45053_45054 : H12AffineEnvironment.transform 2 3 env45053 = env45054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45053 == env45054) = true)

theorem identity45054 : scanCanonicalize (H12AffineFastState.compose env45054 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound45054 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45055 : List Nat := [2,4,3,1,32,0,3,37,4,5,1,1,2,1,33,2,33,32,5,32,33,33,1,35,2,1,33,33,0,33,5,0,37,1,33,36]

theorem envBound45055 : H12AffineFastState.Bounded env45055 := by
  intro p hp
  have h : env45055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45054_45055 : H12AffineEnvironment.transform 9 5 env45054 = env45055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env45054 == env45055) = true)

theorem identity45055 : scanCanonicalize (H12AffineFastState.compose env45055 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45055 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env45056 : List Nat := [2,4,3,1,1,0,3,4,4,5,1,1,2,1,0,2,0,1,5,1,0,0,1,2,2,1,0,0,0,0,5,0,4,1,0,5]

theorem envBound45056 : H12AffineFastState.Bounded env45056 := by
  intro p hp
  have h : env45056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45055_45056 : H12AffineEnvironment.transform 4 1 env45055 = env45056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45055 == env45056) = true)

theorem identity45056 : scanCanonicalize (H12AffineFastState.compose env45056 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45056 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45057 : List Nat := [2,3,3,1,1,0,3,3,3,2,1,1,2,1,0,2,0,1,2,1,0,0,1,2,2,1,0,0,0,0,2,0,3,1,0,2]

theorem envBound45057 : H12AffineFastState.Bounded env45057 := by
  intro p hp
  have h : env45057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45056_45057 : H12AffineEnvironment.transform 1 3 env45056 = env45057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45056 == env45057) = true)

def env45058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396324,272392,452649,21763,8193,65,292136,458024,45404,10280,399665,144492,256,21793,46092,400996]

theorem envBound45058 : H12AffineFastState.Bounded env45058 := by
  intro p hp
  have h : env45058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45041_45058 : H12AffineEnvironment.transform 6 9 env45041 = env45058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45041 == env45058) = true)

theorem identity45058 : scanCanonicalize (H12AffineFastState.compose env45058 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound45058 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,23669,1024,32769,151633,29821,177244,21763,8193,65,10589,172381,45404,10280,148804,144492,256,21793,46092,147985]

theorem envBound45059 : H12AffineFastState.Bounded env45059 := by
  intro p hp
  have h : env45059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45058_45059 : H12AffineEnvironment.transform 17 23669 env45058 = env45059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env45058 == env45059) = true)

theorem identity45059 : scanCanonicalize (H12AffineFastState.compose env45059 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound45059 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env45060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,131072,23669,1024,21760,151633,29821,155997,21763,8193,65,10589,160860,25693,10280,148804,144492,256,21793,24845,147985]

theorem envBound45060 : H12AffineFastState.Bounded env45060 := by
  intro p hp
  have h : env45060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45059_45060 : H12AffineEnvironment.transform 14 21761 env45059 = env45060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env45059 == env45060) = true)

theorem identity45060 : scanCanonicalize (H12AffineFastState.compose env45060 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound45060 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env45061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,24908,23669,1024,21760,12573,29821,17,21763,8193,65,10589,5392,25693,10280,9224,21792,256,21793,24845,9053]

theorem envBound45061 : H12AffineFastState.Bounded env45061 := by
  intro p hp
  have h : env45061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45060_45061 : H12AffineEnvironment.transform 16 24908 env45060 = env45061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env45060 == env45061) = true)

theorem identity45061 : scanCanonicalize (H12AffineFastState.compose env45061 (packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 4887) := by decide +kernel

theorem selectedBound45061 : packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env45062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,4887,16384,21761,4892,21083,23669,1024,21760,522,18282,17,21763,4886,65,6730,5392,22346,6975,5919,21792,256,21793,21018,4170]

theorem envBound45062 : H12AffineFastState.Bounded env45062 := by
  intro p hp
  have h : env45062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45061_45062 : H12AffineEnvironment.transform 12 4887 env45061 = env45062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4887 env45061 == env45062) = true)

def env45063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,452769,95497,8328,65,4218281,458144,45524,10400,399800,4594924,256,21793,46213,474735]

theorem envBound45063 : H12AffineFastState.Bounded env45063 := by
  intro p hp
  have h : env45063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45012_45063 : H12AffineEnvironment.transform 22 452769 env45012 = env45063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env45012 == env45063) = true)

def env45064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272512,452769,95497,8328,65,292137,458144,45524,10400,399800,144492,256,21793,46213,474735]

theorem envBound45064 : H12AffineFastState.Bounded env45064 := by
  intro p hp
  have h : env45064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45063_45064 : H12AffineEnvironment.transform 21 272512 env45063 = env45064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45063 == env45064) = true)

theorem identity45064 : scanCanonicalize (H12AffineFastState.compose env45064 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212078) := by decide +kernel

theorem selectedBound45064 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77898,201966,120015,95497,8328,65,215367,115150,45524,10400,75222,144492,256,21793,46213,513]

theorem envBound45065 : H12AffineFastState.Bounded env45065 := by
  intro p hp
  have h : env45065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45064_45065 : H12AffineEnvironment.transform 17 212078 env45064 = env45065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212078 env45064 == env45065) = true)

def env45066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77898,201830,119879,95497,8192,65,215367,115014,45404,10280,75102,144492,256,21793,46093,513]

theorem envBound45066 : H12AffineFastState.Bounded env45066 := by
  intro p hp
  have h : env45066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45065_45066 : H12AffineEnvironment.transform 6 8 env45065 = env45066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45065 == env45066) = true)

theorem identity45066 : scanCanonicalize (H12AffineFastState.compose env45066 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound45066 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,23668,1024,32769,77898,29820,119879,95497,8192,65,10589,115014,45404,10280,75102,87158,256,21793,46093,513]

theorem envBound45067 : H12AffineFastState.Bounded env45067 := by
  intro p hp
  have h : env45067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45066_45067 : H12AffineEnvironment.transform 16 90138 env45066 = env45067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env45066 == env45067) = true)

theorem identity45067 : scanCanonicalize (H12AffineFastState.compose env45067 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound45067 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env45068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54278,46108,23668,1024,32769,58444,29820,65,41231,8192,65,10589,5440,45404,10280,61784,32880,256,21793,46093,513]

theorem envBound45068 : H12AffineFastState.Bounded env45068 := by
  intro p hp
  have h : env45068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45067_45068 : H12AffineEnvironment.transform 15 54278 env45067 = env45068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env45067 == env45068) = true)

theorem identity45068 : scanCanonicalize (H12AffineFastState.compose env45068 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound45068 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env45069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21510,13340,23668,1024,1,25676,29820,65,8463,8192,65,10589,5440,12636,10280,29016,112,256,21793,13325,513]

theorem envBound45069 : H12AffineFastState.Bounded env45069 := by
  intro p hp
  have h : env45069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45068_45069 : H12AffineEnvironment.transform 14 0 env45068 = env45069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env45068 == env45069) = true)

theorem identity45069 : scanCanonicalize (H12AffineFastState.compose env45069 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45069 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env45070 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,21510,13340,23588,1024,1,25628,29740,17,8463,8192,17,10509,5392,12556,10280,28936,32,256,21793,13325,513]

theorem envBound45070 : H12AffineFastState.Bounded env45070 := by
  intro p hp
  have h : env45070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45069_45070 : H12AffineEnvironment.transform 5 16 env45069 = env45070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45069 == env45070) = true)

theorem identity45070 : scanCanonicalize (H12AffineFastState.compose env45070 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45070 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45071 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,21510,5393,23588,1024,1,17681,21793,17,2,269,17,2048,5392,4097,2341,20485,32,256,21793,5376,513]

theorem envBound45071 : H12AffineFastState.Bounded env45071 := by
  intro p hp
  have h : env45071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45070_45071 : H12AffineEnvironment.transform 12 269 env45070 = env45071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45070 == env45071) = true)

theorem identity45071 : scanCanonicalize (H12AffineFastState.compose env45071 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound45071 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env45072 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3329,269,16384,0,18695,2064,16677,1024,1,17681,18464,17,2,269,17,2048,2065,3328,2341,19716,32,256,18464,2049,513]

theorem envBound45072 : H12AffineFastState.Bounded env45072 := by
  intro p hp
  have h : env45072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45071_45072 : H12AffineEnvironment.transform 11 3329 env45071 = env45072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env45071 == env45072) = true)

theorem identity45072 : scanCanonicalize (H12AffineFastState.compose env45072 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound45072 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env45073 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3329,269,3344,0,1047,2064,3125,1024,1,2049,1328,17,2,269,17,2048,2065,3328,2341,20,32,256,1328,2049,513]

theorem envBound45073 : H12AffineFastState.Bounded env45073 := by
  intro p hp
  have h : env45073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45072_45073 : H12AffineEnvironment.transform 13 3344 env45072 = env45073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env45072 == env45073) = true)

theorem identity45073 : scanCanonicalize (H12AffineFastState.compose env45073 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45073 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env45074 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2064,269,2049,0,262,2064,2340,273,1,2049,33,17,2,269,17,2048,2065,2065,2341,20,32,256,33,2049,513]

theorem envBound45074 : H12AffineFastState.Bounded env45074 := by
  intro p hp
  have h : env45074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45073_45074 : H12AffineEnvironment.transform 9 273 env45073 = env45074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45073 == env45074) = true)

theorem identity45074 : scanCanonicalize (H12AffineFastState.compose env45074 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45074 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45075 : List Nat := [2,4,8,16,17,16,8,256,512,273,2048,2064,269,2049,0,262,2064,2325,273,1,2049,16,17,2,269,17,2048,2065,2065,2324,20,17,256,16,2049,513]

theorem envBound45075 : H12AffineFastState.Bounded env45075 := by
  intro p hp
  have h : env45075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45074_45075 : H12AffineEnvironment.transform 4 17 env45074 = env45075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45074 == env45075) = true)

theorem identity45075 : scanCanonicalize (H12AffineFastState.compose env45075 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound45075 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45076 : List Nat := [2,4,8,16,17,16,8,256,512,273,788,772,269,789,0,262,772,513,273,1,789,16,17,2,269,17,788,773,773,512,20,17,256,16,789,513]

theorem envBound45076 : H12AffineFastState.Bounded env45076 := by
  intro p hp
  have h : env45076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45075_45076 : H12AffineEnvironment.transform 10 788 env45075 = env45076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env45075 == env45076) = true)

theorem identity45076 : scanCanonicalize (H12AffineFastState.compose env45076 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45076 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45077 : List Nat := [2,4,8,16,17,16,8,256,17,273,261,277,269,260,0,262,277,16,273,1,260,16,17,2,269,17,261,276,276,17,20,17,256,16,260,16]

theorem envBound45077 : H12AffineFastState.Bounded env45077 := by
  intro p hp
  have h : env45077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45076_45077 : H12AffineEnvironment.transform 8 17 env45076 = env45077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45076 == env45077) = true)

theorem identity45077 : scanCanonicalize (H12AffineFastState.compose env45077 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45077 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45078 : List Nat := [2,4,8,16,17,16,8,5,17,20,0,16,8,1,0,3,16,16,20,1,1,16,17,2,8,17,0,17,17,17,20,17,5,16,1,16]

theorem envBound45078 : H12AffineFastState.Bounded env45078 := by
  intro p hp
  have h : env45078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45077_45078 : H12AffineEnvironment.transform 7 5 env45077 = env45078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45077 == env45078) = true)

theorem identity45078 : scanCanonicalize (H12AffineFastState.compose env45078 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45078 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45079 : List Nat := [2,4,8,10,11,10,8,5,11,14,0,10,8,1,0,3,10,10,14,1,1,10,11,2,8,11,0,11,11,11,14,11,5,10,1,10]

theorem envBound45079 : H12AffineFastState.Bounded env45079 := by
  intro p hp
  have h : env45079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45078_45079 : H12AffineEnvironment.transform 3 10 env45078 = env45079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45078 == env45079) = true)

def env45080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77898,201831,119878,95497,8193,65,215367,115015,45405,10281,75103,144492,256,21793,46092,513]

theorem envBound45080 : H12AffineFastState.Bounded env45080 := by
  intro p hp
  have h : env45080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45065_45080 : H12AffineEnvironment.transform 6 9 env45065 = env45080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45065 == env45080) = true)

theorem identity45080 : scanCanonicalize (H12AffineFastState.compose env45080 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound45080 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env45081 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10280,1024,32769,77898,33,119878,95497,8193,65,23809,115015,45405,10281,75103,73770,256,21793,46092,513]

theorem envBound45081 : H12AffineFastState.Bounded env45081 := by
  intro p hp
  have h : env45081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45080_45081 : H12AffineEnvironment.transform 16 70726 env45080 = env45081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env45080 == env45081) = true)

theorem identity45081 : scanCanonicalize (H12AffineFastState.compose env45081 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound45081 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env45082 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,57676,10280,1024,32769,50496,33,8524,32771,8193,65,23809,13389,45405,10281,53333,54560,256,21793,46092,513]

theorem envBound45082 : H12AffineFastState.Bounded env45082 := by
  intro p hp
  have h : env45082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45081_45082 : H12AffineEnvironment.transform 15 62730 env45081 = env45082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env45081 == env45082) = true)

theorem identity45082 : scanCanonicalize (H12AffineFastState.compose env45082 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45082 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env45083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,54279,49217,2341,1024,32769,50496,33,65,32771,268,65,23809,5440,36944,2340,53333,54560,256,21793,38145,513]

theorem envBound45083 : H12AffineFastState.Bounded env45083 := by
  intro p hp
  have h : env45083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45082_45083 : H12AffineEnvironment.transform 12 269 env45082 = env45083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45082 == env45083) = true)

theorem identity45083 : scanCanonicalize (H12AffineFastState.compose env45083 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45083 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env45084 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,33030,38208,2341,1024,32769,36929,33,65,32771,268,65,2048,5440,36944,2340,34132,32801,256,32,38145,513]

theorem envBound45084 : H12AffineFastState.Bounded env45084 := by
  intro p hp
  have h : env45084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45083_45084 : H12AffineEnvironment.transform 13 5377 env45083 = env45084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45083 == env45084) = true)

def env45085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272513,452769,95497,8328,65,292136,458144,45524,10400,399800,144493,256,21793,46213,474735]

theorem envBound45085 : H12AffineFastState.Bounded env45085 := by
  intro p hp
  have h : env45085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45063_45085 : H12AffineEnvironment.transform 21 272513 env45063 = env45085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45063 == env45085) = true)

end H12CloudChart0