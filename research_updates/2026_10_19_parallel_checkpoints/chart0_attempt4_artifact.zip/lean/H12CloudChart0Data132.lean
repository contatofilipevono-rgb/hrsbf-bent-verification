import H12CloudChart0Data131

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound33498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33499 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2609,40,2592,0,34,2609,2048,53,1,2593,32,16,3,41,16,2048,2608,2608,2048,21,33,37,32,2593,512]

theorem envBound33499 : H12AffineFastState.Bounded env33499 := by
  intro p hp
  have h : env33499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33498_33499 : H12AffineEnvironment.transform 11 2609 env33498 = env33499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env33498 == env33499) = true)

theorem identity33499 : scanCanonicalize (H12AffineFastState.compose env33499 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound33499 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33500 : List Nat := [2,4,8,16,32,16,9,37,21,53,2048,2084,40,2101,0,34,2084,2048,53,1,2100,32,16,3,41,16,2048,2085,2085,2048,21,33,37,32,2100,21]

theorem envBound33500 : H12AffineFastState.Bounded env33500 := by
  intro p hp
  have h : env33500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33499_33500 : H12AffineEnvironment.transform 8 21 env33499 = env33500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env33499 == env33500) = true)

theorem identity33500 : scanCanonicalize (H12AffineFastState.compose env33500 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33500 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33501 : List Nat := [2,4,8,16,0,16,9,5,21,21,2048,2052,8,2069,0,2,2052,2048,21,1,2068,0,16,3,9,16,2048,2053,2053,2048,21,1,5,0,2068,21]

theorem envBound33501 : H12AffineFastState.Bounded env33501 := by
  intro p hp
  have h : env33501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33500_33501 : H12AffineEnvironment.transform 4 0 env33500 = env33501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33500 == env33501) = true)

theorem identity33501 : scanCanonicalize (H12AffineFastState.compose env33501 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound33501 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33502 : List Nat := [2,4,8,5,0,5,9,5,0,0,2048,2052,8,2048,0,2,2052,2048,0,1,2049,0,5,3,9,5,2048,2053,2053,2048,0,1,5,0,2049,0]

theorem envBound33502 : H12AffineFastState.Bounded env33502 := by
  intro p hp
  have h : env33502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33501_33502 : H12AffineEnvironment.transform 3 5 env33501 = env33502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env33501 == env33502) = true)

def leafEnv33502 : List Nat := [2,4,8,5,0,5,9,5,0,0,2048,2052,8,2048,0,2,2052,2048,0,1,2049,0,5,3,0,9,1,5,2048,2053,2053,2048,0,1,5,0,4,3,2049,0,1,2048,0]

def active33502 : List Nat := [0,1,2,10]

def tree33502 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33502 : H12WitnessSearch.Good tree33502 := H12GlobalWitnessIndex.good

theorem leafIdentity33502 : H12AffineFastState.composeSystem env33502 rootObs = leafEnv33502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33502 rootObs == leafEnv33502) = true)

theorem terminalChecked33502 : H12PackedTerminal.terminalCheckFast leafEnv33502 active33502 tree33502 = true := by decide +kernel

def env33503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,147475,8328,64,4702362,2344095,2233817,295048,99467,6497747,256,2212918,2172307,41821]

theorem envBound33503 : H12AffineFastState.Bounded env33503 := by
  intro p hp
  have h : env33503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33456_33503 : H12AffineEnvironment.transform 22 147593 env33456 = env33503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env33456 == env33503) = true)

def env33504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147593,147475,8328,64,4450362,2344095,2233817,43048,99467,6497747,256,2212918,2172307,41821]

theorem envBound33504 : H12AffineFastState.Bounded env33504 := by
  intro p hp
  have h : env33504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33503_33504 : H12AffineEnvironment.transform 17 10400 env33503 = env33504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33503 == env33504) = true)

theorem identity33504 : scanCanonicalize (H12AffineFastState.compose env33504 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33504 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147593,147475,8328,64,4409702,2319811,2233817,2420,75223,6497747,256,2188650,2172307,513]

theorem envBound33505 : H12AffineFastState.Bounded env33505 := by
  intro p hp
  have h : env33505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33504_33505 : H12AffineEnvironment.transform 14 8540 env33504 = env33505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33504 == env33505) = true)

def env33506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1024,8541,2097152,4194304,147457,147475,8192,64,4409702,2319691,2233681,2420,75103,6497627,256,2188650,2172187,513]

theorem envBound33506 : H12AffineFastState.Bounded env33506 := by
  intro p hp
  have h : env33506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33505_33506 : H12AffineEnvironment.transform 6 8 env33505 = env33506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33505 == env33506) = true)

theorem identity33506 : scanCanonicalize (H12AffineFastState.compose env33506 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound33506 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env33507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1024,8541,2097152,4194304,73755,73737,8192,64,4204924,2098513,2192715,2420,75103,6309185,256,2188650,2172187,513]

theorem envBound33507 : H12AffineFastState.Bounded env33507 := by
  intro p hp
  have h : env33507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33506_33507 : H12AffineEnvironment.transform 16 90138 env33506 = env33507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env33506 == env33507) = true)

theorem identity33507 : scanCanonicalize (H12AffineFastState.compose env33507 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 79195) := by decide +kernel

theorem selectedBound33507 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env33508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1024,8541,79195,4194304,73755,73737,8192,64,4204924,77834,16400,2420,75103,4288538,256,20529,4160,513]

theorem envBound33508 : H12AffineFastState.Bounded env33508 := by
  intro p hp
  have h : env33508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33507_33508 : H12AffineEnvironment.transform 20 79195 env33507 = env33508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79195 env33507 == env33508) = true)

theorem identity33508 : scanCanonicalize (H12AffineFastState.compose env33508 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 73042) := by decide +kernel

theorem selectedBound33508 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env33509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10280,1024,8541,79195,73042,73755,73737,8192,64,78894,77834,16400,2420,75103,27976,256,20529,4160,513]

theorem envBound33509 : H12AffineFastState.Bounded env33509 := by
  intro p hp
  have h : env33509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33508_33509 : H12AffineEnvironment.transform 21 73042 env33508 = env33509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73042 env33508 == env33509) = true)

theorem identity33509 : scanCanonicalize (H12AffineFastState.compose env33509 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 10589) := by decide +kernel

theorem selectedBound33509 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env33510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10589,8540,65536,67911,10280,1024,8541,79195,73042,73755,73737,8192,64,78894,77834,10573,2420,75103,1045,256,14700,4160,513]

theorem envBound33510 : H12AffineFastState.Bounded env33510 := by
  intro p hp
  have h : env33510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33509_33510 : H12AffineEnvironment.transform 13 10589 env33509 = env33510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10589 env33509 == env33510) = true)

theorem identity33510 : scanCanonicalize (H12AffineFastState.compose env33510 (packedSelected [0,3,7,8,10,11,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 5939) := by decide +kernel

theorem selectedBound33510 : packedSelected [0,3,7,8,10,11,14,15,20] rootPS < 2^1333 := by decide +kernel

def env33511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10589,8540,5939,7796,10280,1024,8541,8808,2657,14120,14138,8192,64,8989,10041,10573,2420,12908,1045,256,14700,4160,513]

theorem envBound33511 : H12AffineFastState.Bounded env33511 := by
  intro p hp
  have h : env33511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33510_33511 : H12AffineEnvironment.transform 15 5939 env33510 = env33511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5939 env33510 == env33511) = true)

theorem identity33511 : scanCanonicalize (H12AffineFastState.compose env33511 (packedSelected [0,4,9,11,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 3960) := by decide +kernel

theorem selectedBound33511 : packedSelected [0,4,9,11,14,27] rootPS < 2^1333 := by decide +kernel

def env33512 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3960,1573,3620,5939,7796,1872,1024,3621,3344,2657,6224,6210,3960,64,3173,2113,1589,2420,7444,1045,256,5652,4160,513]

theorem envBound33512 : H12AffineFastState.Bounded env33512 := by
  intro p hp
  have h : env33512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33511_33512 : H12AffineEnvironment.transform 12 3960 env33511 = env33512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3960 env33511 == env33512) = true)

theorem identity33512 : scanCanonicalize (H12AffineFastState.compose env33512 (packedSelected [0,5,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound33512 : packedSelected [0,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env33513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,3960,1573,3620,3954,1589,1872,1024,3621,3344,2657,17,3,3960,64,3173,2113,1589,2420,1365,1045,256,3669,2049,513]

theorem envBound33513 : H12AffineFastState.Bounded env33513 := by
  intro p hp
  have h : env33513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33512_33513 : H12AffineEnvironment.transform 11 2113 env33512 = env33513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env33512 == env33513) = true)

theorem identity33513 : scanCanonicalize (H12AffineFastState.compose env33513 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1652) := by decide +kernel

theorem selectedBound33513 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env33514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1652,1589,268,1573,80,262,1589,1872,1024,81,868,1045,17,3,268,64,529,1589,1589,1792,1365,1045,256,33,1653,513]

theorem envBound33514 : H12AffineFastState.Bounded env33514 := by
  intro p hp
  have h : env33514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33513_33514 : H12AffineEnvironment.transform 10 1652 env33513 = env33514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1652 env33513 == env33514) = true)

theorem identity33514 : scanCanonicalize (H12AffineFastState.compose env33514 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33514 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33515 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1573,1589,268,1573,1,262,1589,1793,1024,0,821,1045,17,3,268,17,529,1589,1589,1792,1284,1045,256,33,1572,513]

theorem envBound33515 : H12AffineFastState.Bounded env33515 := by
  intro p hp
  have h : env33515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33514_33515 : H12AffineEnvironment.transform 5 17 env33514 = env33515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33514 == env33515) = true)

theorem identity33515 : scanCanonicalize (H12AffineFastState.compose env33515 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound33515 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env33516 : List Nat := [2,4,8,16,32,17,8,256,512,784,309,293,268,309,1,262,293,17,784,0,821,773,17,3,268,17,529,293,293,16,532,773,256,33,308,513]

theorem envBound33516 : H12AffineFastState.Bounded env33516 := by
  intro p hp
  have h : env33516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33515_33516 : H12AffineEnvironment.transform 9 784 env33515 = env33516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env33515 == env33516) = true)

theorem identity33516 : scanCanonicalize (H12AffineFastState.compose env33516 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound33516 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33517 : List Nat := [2,4,8,16,32,17,8,62,512,558,11,27,50,11,1,56,27,17,558,0,523,571,17,3,50,17,529,27,27,16,532,571,62,33,10,513]

theorem envBound33517 : H12AffineFastState.Bounded env33517 := by
  intro p hp
  have h : env33517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33516_33517 : H12AffineEnvironment.transform 7 62 env33516 = env33517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env33516 == env33517) = true)

theorem identity33517 : scanCanonicalize (H12AffineFastState.compose env33517 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound33517 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33518 : List Nat := [2,4,8,16,32,17,8,62,26,52,11,27,50,11,1,56,27,17,52,0,17,33,17,3,50,17,11,27,27,16,14,33,62,33,10,27]

theorem envBound33518 : H12AffineFastState.Bounded env33518 := by
  intro p hp
  have h : env33518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33517_33518 : H12AffineEnvironment.transform 8 26 env33517 = env33518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env33517 == env33518) = true)

theorem identity33518 : scanCanonicalize (H12AffineFastState.compose env33518 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33518 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33519 : List Nat := [2,4,8,0,32,1,8,46,10,36,11,11,34,11,1,40,11,1,36,0,1,33,1,3,34,1,11,11,11,0,14,33,46,33,10,11]

theorem envBound33519 : H12AffineFastState.Bounded env33519 := by
  intro p hp
  have h : env33519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33518_33519 : H12AffineEnvironment.transform 3 0 env33518 = env33519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33518 == env33519) = true)

def env33520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147456,147475,8193,64,4409702,2319690,2233680,2420,75102,6497626,256,2188650,2172186,513]

theorem envBound33520 : H12AffineFastState.Bounded env33520 := by
  intro p hp
  have h : env33520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33505_33520 : H12AffineEnvironment.transform 6 9 env33505 = env33520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33505 == env33520) = true)

theorem identity33520 : scanCanonicalize (H12AffineFastState.compose env33520 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound33520 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env33521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,91467,4194304,147456,147475,8193,64,4409702,131073,225307,2420,75102,4341777,256,33,16465,513]

theorem envBound33521 : H12AffineFastState.Bounded env33521 := by
  intro p hp
  have h : env33521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33520_33521 : H12AffineEnvironment.transform 20 91467 env33520 = env33521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env33520 == env33521) = true)

theorem identity33521 : scanCanonicalize (H12AffineFastState.compose env33521 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound33521 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,91467,4194304,16,3,8193,64,4262262,16401,77835,2420,75102,4194305,256,33,16465,513]

theorem envBound33522 : H12AffineFastState.Bounded env33522 := by
  intro p hp
  have h : env33522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33521_33522 : H12AffineEnvironment.transform 16 16400 env33521 = env33522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env33521 == env33522) = true)

theorem identity33522 : scanCanonicalize (H12AffineFastState.compose env33522 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound33522 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env33523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,91467,73771,16,3,8193,64,10589,16401,77835,2420,75102,73770,256,33,16465,513]

theorem envBound33523 : H12AffineFastState.Bounded env33523 := by
  intro p hp
  have h : env33523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33522_33523 : H12AffineEnvironment.transform 21 73771 env33522 = env33523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env33522 == env33523) = true)

theorem identity33523 : scanCanonicalize (H12AffineFastState.compose env33523 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound33523 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8283,16400,10281,1024,8541,17680,112,16,3,8193,64,10589,16401,4176,2420,1285,113,256,33,16465,513]

theorem envBound33524 : H12AffineFastState.Bounded env33524 := by
  intro p hp
  have h : env33524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33523_33524 : H12AffineEnvironment.transform 15 8283 env33523 = env33524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env33523 == env33524) = true)

theorem identity33524 : scanCanonicalize (H12AffineFastState.compose env33524 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33524 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,262,16400,2420,1024,0,17680,112,16,3,348,64,2048,16401,4176,2420,1285,113,256,33,16465,513]

theorem envBound33525 : H12AffineFastState.Bounded env33525 := by
  intro p hp
  have h : env33525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33524_33525 : H12AffineEnvironment.transform 12 349 env33524 = env33525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33524 == env33525) = true)

theorem identity33525 : scanCanonicalize (H12AffineFastState.compose env33525 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound33525 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5237,1,262,5221,2420,1024,0,4453,112,16,3,348,64,2048,5220,4176,2420,1285,113,256,33,5156,513]

theorem envBound33526 : H12AffineFastState.Bounded env33526 := by
  intro p hp
  have h : env33526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33525_33526 : H12AffineEnvironment.transform 13 5237 env33525 = env33526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env33525 == env33526) = true)

theorem identity33526 : scanCanonicalize (H12AffineFastState.compose env33526 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33526 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env33527 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5156,1,262,5172,2341,1024,0,4404,33,16,3,269,17,2048,5173,4097,2341,1285,32,256,33,5156,513]

theorem envBound33527 : H12AffineFastState.Bounded env33527 := by
  intro p hp
  have h : env33527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33526_33527 : H12AffineEnvironment.transform 5 17 env33526 = env33527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33526 == env33527) = true)

def env33528 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,268,2836,1,262,2820,2341,1024,0,3588,33,16,3,269,17,2048,2821,3889,2341,1285,32,256,33,2836,513]

theorem envBound33528 : H12AffineFastState.Bounded env33528 := by
  intro p hp
  have h : env33528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33527_33528 : H12AffineEnvironment.transform 11 3888 env33527 = env33528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env33527 == env33528) = true)

def env33529 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,268,1044,1,262,1028,1573,1024,0,260,33,16,3,269,17,1792,1029,49,1573,1285,32,256,33,1044,513]

theorem envBound33529 : H12AffineFastState.Bounded env33529 := by
  intro p hp
  have h : env33529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33528_33529 : H12AffineEnvironment.transform 10 1792 env33528 = env33529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env33528 == env33529) = true)

theorem identity33529 : scanCanonicalize (H12AffineFastState.compose env33529 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound33529 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33530 : List Nat := [2,4,8,16,32,17,9,256,512,273,529,48,268,261,1,262,277,820,273,0,260,33,16,3,269,17,529,276,49,820,20,32,256,33,261,513]

theorem envBound33530 : H12AffineFastState.Bounded env33530 := by
  intro p hp
  have h : env33530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33529_33530 : H12AffineEnvironment.transform 9 273 env33529 = env33530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env33529 == env33530) = true)

def env33531 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,40,33,1,34,49,528,53,0,32,33,16,3,41,17,529,48,49,528,20,32,36,33,33,513]

theorem envBound33531 : H12AffineFastState.Bounded env33531 := by
  intro p hp
  have h : env33531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33530_33531 : H12AffineEnvironment.transform 7 36 env33530 = env33531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33530 == env33531) = true)

theorem identity33531 : scanCanonicalize (H12AffineFastState.compose env33531 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33532 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,48,40,33,1,34,49,58,53,0,32,33,16,3,41,17,59,48,49,58,20,32,36,33,33,43]

theorem envBound33532 : H12AffineFastState.Bounded env33532 := by
  intro p hp
  have h : env33532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33531_33532 : H12AffineEnvironment.transform 8 42 env33531 = env33532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33531 == env33532) = true)

def leafEnv33532 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,48,40,33,1,34,49,58,53,0,32,33,16,3,20,41,1,17,59,48,49,58,20,32,36,33,4,35,33,43,1,32,0]

def active33532 : List Nat := [0,1,2,3,4]

def tree33532 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33532 : H12WitnessSearch.Good tree33532 := H12GlobalWitnessIndex.good

theorem leafIdentity33532 : H12AffineFastState.composeSystem env33532 rootObs = leafEnv33532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33532 rootObs == leafEnv33532) = true)

theorem terminalChecked33532 : H12PackedTerminal.terminalCheckFast leafEnv33532 active33532 tree33532 = true := by decide +kernel

def env33533 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,48,41,32,1,35,48,529,52,0,33,33,16,3,40,17,529,49,49,529,20,32,37,33,32,513]

theorem envBound33533 : H12AffineFastState.Bounded env33533 := by
  intro p hp
  have h : env33533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33530_33533 : H12AffineEnvironment.transform 7 37 env33530 = env33533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33530 == env33533) = true)

def env33534 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,268,1045,1,262,1029,1572,1024,0,261,33,16,3,269,17,1793,1028,48,1572,1285,32,256,33,1045,513]

theorem envBound33534 : H12AffineFastState.Bounded env33534 := by
  intro p hp
  have h : env33534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33528_33534 : H12AffineEnvironment.transform 10 1793 env33528 = env33534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env33528 == env33534) = true)

def env33535 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,49,268,33,1,262,49,528,52,0,261,33,16,3,269,17,821,48,48,528,305,32,256,33,33,513]

theorem envBound33535 : H12AffineFastState.Bounded env33535 := by
  intro p hp
  have h : env33535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33534_33535 : H12AffineEnvironment.transform 9 52 env33534 = env33535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33534 == env33535) = true)

def env33536 : List Nat := [2,4,8,16,32,17,9,256,512,53,820,49,268,32,1,262,48,529,53,0,261,33,16,3,269,17,820,49,48,529,304,32,256,33,32,513]

theorem envBound33536 : H12AffineFastState.Bounded env33536 := by
  intro p hp
  have h : env33536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33534_33536 : H12AffineEnvironment.transform 9 53 env33534 = env33536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33534 == env33536) = true)

theorem identity33536 : scanCanonicalize (H12AffineFastState.compose env33536 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound33536 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33537 : List Nat := [2,4,8,16,32,17,9,256,271,53,59,49,268,32,1,262,48,286,53,0,261,33,16,3,269,17,59,49,48,286,304,32,256,33,32,270]

theorem envBound33537 : H12AffineFastState.Bounded env33537 := by
  intro p hp
  have h : env33537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33536_33537 : H12AffineEnvironment.transform 8 271 env33536 = env33537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env33536 == env33537) = true)

def leafEnv33537 : List Nat := [2,4,8,16,32,17,9,256,271,53,59,49,268,32,1,262,48,286,53,0,261,33,16,3,304,269,1,17,59,49,48,286,304,32,256,33,4,263,32,270,1,261,0]

def active33537 : List Nat := [0,1,2,3,4,7]

def tree33537 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33537 : H12WitnessSearch.Good tree33537 := H12GlobalWitnessIndex.good

theorem leafIdentity33537 : H12AffineFastState.composeSystem env33537 rootObs = leafEnv33537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33537 rootObs == leafEnv33537) = true)

theorem terminalChecked33537 : H12PackedTerminal.terminalCheckFast leafEnv33537 active33537 tree33537 = true := by decide +kernel

def env33538 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,268,2837,1,262,2821,2341,1024,0,3589,33,16,3,269,17,2048,2820,3888,2341,1285,32,256,33,2837,513]

theorem envBound33538 : H12AffineFastState.Bounded env33538 := by
  intro p hp
  have h : env33538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33527_33538 : H12AffineEnvironment.transform 11 3889 env33527 = env33538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env33527 == env33538) = true)

def env33539 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,268,1045,1,262,1029,1573,1024,0,261,33,16,3,269,17,1792,1028,48,1573,1285,32,256,33,1045,513]

theorem envBound33539 : H12AffineFastState.Bounded env33539 := by
  intro p hp
  have h : env33539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33538_33539 : H12AffineEnvironment.transform 10 1792 env33538 = env33539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env33538 == env33539) = true)

theorem identity33539 : scanCanonicalize (H12AffineFastState.compose env33539 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33539 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33540 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,49,40,1045,1,34,1029,1573,1024,0,33,33,16,3,41,17,1572,1028,48,1573,1057,32,36,33,1045,513]

theorem envBound33540 : H12AffineFastState.Bounded env33540 := by
  intro p hp
  have h : env33540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33539_33540 : H12AffineEnvironment.transform 7 36 env33539 = env33540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33539 == env33540) = true)

def env33541 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,40,33,1,34,49,529,52,0,33,33,16,3,41,17,528,48,48,529,21,32,36,33,33,513]

theorem envBound33541 : H12AffineFastState.Bounded env33541 := by
  intro p hp
  have h : env33541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33540_33541 : H12AffineEnvironment.transform 9 52 env33540 = env33541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33540 == env33541) = true)

def env33542 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,40,32,1,34,48,528,53,0,33,33,16,3,41,17,529,49,48,528,20,32,36,33,32,513]

theorem envBound33542 : H12AffineFastState.Bounded env33542 := by
  intro p hp
  have h : env33542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33540_33542 : H12AffineEnvironment.transform 9 53 env33540 = env33542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33540 == env33542) = true)

theorem identity33542 : scanCanonicalize (H12AffineFastState.compose env33542 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound33542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33543 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,49,40,32,1,34,48,59,53,0,33,33,16,3,41,17,58,49,48,59,20,32,36,33,32,42]

theorem envBound33543 : H12AffineFastState.Bounded env33543 := by
  intro p hp
  have h : env33543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33542_33543 : H12AffineEnvironment.transform 8 43 env33542 = env33543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env33542 == env33543) = true)

def leafEnv33543 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,49,40,32,1,34,48,59,53,0,33,33,16,3,20,41,1,17,58,49,48,59,20,32,36,33,4,35,32,42,1,33,0]

def active33543 : List Nat := [0,1,2,3,4]

def tree33543 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33543 : H12WitnessSearch.Good tree33543 := H12GlobalWitnessIndex.good

theorem leafIdentity33543 : H12AffineFastState.composeSystem env33543 rootObs = leafEnv33543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33543 rootObs == leafEnv33543) = true)

theorem terminalChecked33543 : H12PackedTerminal.terminalCheckFast leafEnv33543 active33543 tree33543 = true := by decide +kernel

def env33544 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,268,1044,1,262,1028,1572,1024,0,260,33,16,3,269,17,1793,1029,49,1572,1285,32,256,33,1044,513]

theorem envBound33544 : H12AffineFastState.Bounded env33544 := by
  intro p hp
  have h : env33544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33538_33544 : H12AffineEnvironment.transform 10 1793 env33538 = env33544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env33538 == env33544) = true)

theorem identity33544 : scanCanonicalize (H12AffineFastState.compose env33544 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33545 : List Nat := [2,4,8,16,32,17,9,256,512,53,820,48,268,33,1,262,49,529,53,0,260,33,16,3,269,17,820,48,49,529,304,32,256,33,33,513]

theorem envBound33545 : H12AffineFastState.Bounded env33545 := by
  intro p hp
  have h : env33545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33544_33545 : H12AffineEnvironment.transform 9 53 env33544 = env33545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33544 == env33545) = true)

theorem identity33545 : scanCanonicalize (H12AffineFastState.compose env33545 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound33545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33546 : List Nat := [2,4,8,16,32,17,9,256,270,53,58,48,268,33,1,262,49,287,53,0,260,33,16,3,269,17,58,48,49,287,304,32,256,33,33,271]

theorem envBound33546 : H12AffineFastState.Bounded env33546 := by
  intro p hp
  have h : env33546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33545_33546 : H12AffineEnvironment.transform 8 270 env33545 = env33546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env33545 == env33546) = true)

def leafEnv33546 : List Nat := [2,4,8,16,32,17,9,256,270,53,58,48,268,33,1,262,49,287,53,0,260,33,16,3,304,269,1,17,58,48,49,287,304,32,256,33,4,263,33,271,1,260,0]

def active33546 : List Nat := [0,1,2,3,4,7]

def tree33546 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33546 : H12WitnessSearch.Good tree33546 := H12GlobalWitnessIndex.good

theorem leafIdentity33546 : H12AffineFastState.composeSystem env33546 rootObs = leafEnv33546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33546 rootObs == leafEnv33546) = true)

theorem terminalChecked33546 : H12PackedTerminal.terminalCheckFast leafEnv33546 active33546 tree33546 = true := by decide +kernel

def env33547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147593,147475,8328,64,4450363,2344095,2233817,43049,99467,6497747,256,2212918,2172307,41821]

theorem envBound33547 : H12AffineFastState.Bounded env33547 := by
  intro p hp
  have h : env33547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33503_33547 : H12AffineEnvironment.transform 17 10401 env33503 = env33547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env33503 == env33547) = true)

theorem identity33547 : scanCanonicalize (H12AffineFastState.compose env33547 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57797) := by decide +kernel

theorem selectedBound33547 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,10401,1024,32769,2097152,4194304,41292,41430,8328,64,4262398,2172250,2159644,43049,99467,6407190,256,2212918,2172307,41821]

theorem envBound33548 : H12AffineFastState.Bounded env33548 := by
  intro p hp
  have h : env33548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33547_33548 : H12AffineEnvironment.transform 16 57797 env33547 = env33548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env33547 == env33548) = true)

theorem identity33548 : scanCanonicalize (H12AffineFastState.compose env33548 (packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound33548 : packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env33549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,57797,10401,1024,32769,2097152,4194304,41292,41430,8328,64,4204925,2098649,2159644,43049,41992,6349973,256,2155701,2098448,41821]

theorem envBound33549 : H12AffineFastState.Bounded env33549 := by
  intro p hp
  have h : env33549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33548_33549 : H12AffineEnvironment.transform 15 8323 env33548 = env33549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env33548 == env33549) = true)

theorem identity33549 : scanCanonicalize (H12AffineFastState.compose env33549 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound33549 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env33550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,57797,10401,1024,32769,2097152,41340,41292,41430,8328,64,34817,2098649,2159644,43049,41992,2115049,256,2155701,2098448,41821]

theorem envBound33550 : H12AffineFastState.Bounded env33550 := by
  intro p hp
  have h : env33550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33549_33550 : H12AffineEnvironment.transform 21 41340 env33549 = env33550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env33549 == env33550) = true)

theorem identity33550 : scanCanonicalize (H12AffineFastState.compose env33550 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound33550 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env33551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,57797,10401,1024,32769,50448,41340,41292,41430,8328,64,34817,49353,12556,43049,41992,33017,256,8613,49152,41821]

theorem envBound33551 : H12AffineFastState.Bounded env33551 := by
  intro p hp
  have h : env33551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33550_33551 : H12AffineEnvironment.transform 20 50448 env33550 = env33551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env33550 == env33551) = true)

theorem identity33551 : scanCanonicalize (H12AffineFastState.compose env33551 (packedSelected [4,9,10,11,12,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound33551 : packedSelected [4,9,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env33552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8323,16400,10401,1024,8660,25797,169,153,3,8328,64,10708,24860,12556,2556,1501,8492,256,8613,25045,648]

theorem envBound33552 : H12AffineFastState.Bounded env33552 := by
  intro p hp
  have h : env33552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33551_33552 : H12AffineEnvironment.transform 14 8661 env33551 = env33552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env33551 == env33552) = true)

theorem identity33552 : scanCanonicalize (H12AffineFastState.compose env33552 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound33552 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,80,262,16400,2340,1024,81,17728,169,153,3,269,64,2129,16537,4233,2556,1501,169,256,32,16464,648]

theorem envBound33553 : H12AffineFastState.Bounded env33553 := by
  intro p hp
  have h : env33553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33552_33553 : H12AffineEnvironment.transform 12 389 env33552 = env33553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env33552 == env33553) = true)

theorem identity33553 : scanCanonicalize (H12AffineFastState.compose env33553 (packedSelected [0,4,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound33553 : packedSelected [0,4,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5372,80,262,5356,2340,1024,81,4540,169,153,3,269,64,2129,5221,4233,2556,1501,169,256,32,5292,648]

theorem envBound33554 : H12AffineFastState.Bounded env33554 := by
  intro p hp
  have h : env33554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33553_33554 : H12AffineEnvironment.transform 13 5372 env33553 = env33554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env33553 == env33554) = true)

theorem identity33554 : scanCanonicalize (H12AffineFastState.compose env33554 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33554 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env33555 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,241,5372,80,114,5356,2128,1024,81,4296,169,153,3,121,64,2129,5221,4233,2184,1193,169,116,32,5292,648]

theorem envBound33555 : H12AffineFastState.Bounded env33555 := by
  intro p hp
  have h : env33555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33554_33555 : H12AffineEnvironment.transform 7 116 env33554 = env33555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33554 == env33555) = true)

theorem identity33555 : scanCanonicalize (H12AffineFastState.compose env33555 (packedSelected [2,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33555 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env33556 : List Nat := [2,4,8,16,32,64,128,116,512,1024,1,4096,241,5372,80,114,5356,81,1024,81,4296,169,153,3,121,64,80,5221,4233,137,1193,169,116,32,5292,648]

theorem envBound33556 : H12AffineFastState.Bounded env33556 := by
  intro p hp
  have h : env33556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33555_33556 : H12AffineEnvironment.transform 10 1 env33555 = env33556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33555 == env33556) = true)

theorem identity33556 : scanCanonicalize (H12AffineFastState.compose env33556 (packedSelected [0,1,2,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound33556 : packedSelected [0,1,2,5,7,10] rootPS < 2^1333 := by decide +kernel

def env33557 : List Nat := [2,4,8,16,32,64,88,116,512,1024,1,4096,41,5156,80,114,5172,81,1024,81,4112,113,65,3,121,64,80,5221,4177,81,1137,113,116,32,5236,592]

theorem envBound33557 : H12AffineFastState.Bounded env33557 := by
  intro p hp
  have h : env33557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33556_33557 : H12AffineEnvironment.transform 6 88 env33556 = env33557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env33556 == env33557) = true)

theorem identity33557 : scanCanonicalize (H12AffineFastState.compose env33557 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound33557 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env33558 : List Nat := [2,4,8,16,32,64,88,116,512,1024,1,1141,41,81,80,114,65,81,1024,81,1125,113,65,3,121,64,80,16,1060,81,1137,113,116,32,1,592]

theorem envBound33558 : H12AffineFastState.Bounded env33558 := by
  intro p hp
  have h : env33558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33557_33558 : H12AffineEnvironment.transform 11 1141 env33557 = env33558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env33557 == env33558) = true)

theorem identity33558 : scanCanonicalize (H12AffineFastState.compose env33558 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33558 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env33559 : List Nat := [2,4,8,16,32,64,88,116,512,53,1,64,41,81,80,114,65,81,53,81,80,113,65,3,121,64,80,16,17,81,68,113,116,32,1,592]

theorem envBound33559 : H12AffineFastState.Bounded env33559 := by
  intro p hp
  have h : env33559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33558_33559 : H12AffineEnvironment.transform 9 53 env33558 = env33559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33558 == env33559) = true)

def env33560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound33560 : H12AffineFastState.Bounded env33560 := by
  intro p hp
  have h : env33560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33454_33560 : H12AffineEnvironment.transform 18 1025 env33454 = env33560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env33454 == env33560) = true)

theorem identity33560 : scanCanonicalize (H12AffineFastState.compose env33560 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound33560 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29630491,18973837,10507600,8724506,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound33561 : H12AffineFastState.Bounded env33561 := by
  intro p hp
  have h : env33561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33560_33561 : H12AffineEnvironment.transform 16 122906 env33560 = env33561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env33560 == env33561) = true)

def env33562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6664599,8393985,10507600,8724506,2102685,12645452,257,21793,46213,2175562]

theorem envBound33562 : H12AffineFastState.Bounded env33562 := by
  intro p hp
  have h : env33562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33561_33562 : H12AffineEnvironment.transform 23 10588556 env33561 = env33562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env33561 == env33562) = true)

def env33563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6664599,2098513,17664,2437194,2102685,6349852,257,21793,46213,2175562]

theorem envBound33563 : H12AffineFastState.Bounded env33563 := by
  intro p hp
  have h : env33563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33562_33563 : H12AffineEnvironment.transform 22 2101328 env33562 = env33563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env33562 == env33563) = true)

def env33564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2201879,2098513,17664,2437194,2102685,2411676,257,21793,46213,2175562]

theorem envBound33564 : H12AffineFastState.Bounded env33564 := by
  intro p hp
  have h : env33564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33563_33564 : H12AffineEnvironment.transform 21 272512 env33563 = env33564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33563 == env33564) = true)

theorem identity33564 : scanCanonicalize (H12AffineFastState.compose env33564 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound33564 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77899,272512,73755,98780,8328,64,43356,79130,17664,262145,75222,392407,257,21793,46213,513]

theorem envBound33565 : H12AffineFastState.Bounded env33565 := by
  intro p hp
  have h : env33565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33564_33565 : H12AffineEnvironment.transform 20 77899 env33564 = env33565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env33564 == env33565) = true)

theorem identity33565 : scanCanonicalize (H12AffineFastState.compose env33565 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound33565 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env33566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67619,1025,32769,77899,73891,73755,98780,8328,64,43356,79130,17664,67618,75222,62708,257,21793,46213,513]

theorem envBound33566 : H12AffineFastState.Bounded env33566 := by
  intro p hp
  have h : env33566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33565_33566 : H12AffineEnvironment.transform 17 67619 env33565 = env33566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env33565 == env33566) = true)

theorem identity33566 : scanCanonicalize (H12AffineFastState.compose env33566 (packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound33566 : packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env33567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90138,67619,1025,1,77899,73891,73755,66012,8328,64,10588,79130,17664,67618,75222,29940,257,21793,13445,513]

theorem envBound33567 : H12AffineFastState.Bounded env33567 := by
  intro p hp
  have h : env33567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33566_33567 : H12AffineEnvironment.transform 14 0 env33566 = env33567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env33566 == env33567) = true)

def env33568 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,90138,67619,1025,1,77899,73771,73755,65876,8192,64,10588,79130,17664,67618,75102,29820,257,21793,13325,513]

theorem envBound33568 : H12AffineFastState.Bounded env33568 := by
  intro p hp
  have h : env33568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33567_33568 : H12AffineEnvironment.transform 6 8 env33567 = env33568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33567 == env33568) = true)

theorem identity33568 : scanCanonicalize (H12AffineFastState.compose env33568 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33568 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env33569 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8203,16401,10280,1025,1,4160,32,16,8543,8192,64,10588,5393,17664,10281,1365,29820,257,21793,13325,513]

theorem envBound33569 : H12AffineFastState.Bounded env33569 := by
  intro p hp
  have h : env33569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33568_33569 : H12AffineEnvironment.transform 15 8203 env33568 = env33569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33568 == env33569) = true)

theorem identity33569 : scanCanonicalize (H12AffineFastState.compose env33569 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound33569 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,0,1094,16401,3173,1025,1,4160,32,16,1298,1101,64,3345,5393,17664,3172,1365,20529,257,21793,4160,513]

theorem envBound33570 : H12AffineFastState.Bounded env33570 := by
  intro p hp
  have h : env33570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33569_33570 : H12AffineEnvironment.transform 12 1101 env33569 = env33570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env33569 == env33570) = true)

theorem identity33570 : scanCanonicalize (H12AffineFastState.compose env33570 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33570 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33571 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,16384,0,34,16401,2049,101,1,4160,32,16,374,41,64,2421,4469,16740,2048,305,20529,257,20805,4160,513]

theorem envBound33571 : H12AffineFastState.Bounded env33571 := by
  intro p hp
  have h : env33571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33570_33571 : H12AffineEnvironment.transform 9 100 env33570 = env33571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33570 == env33571) = true)

theorem identity33571 : scanCanonicalize (H12AffineFastState.compose env33571 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound33571 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33572 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,4404,0,34,4389,2049,101,1,4160,32,16,374,41,64,2421,4469,4176,2048,305,261,257,113,4160,513]

theorem envBound33572 : H12AffineFastState.Bounded env33572 := by
  intro p hp
  have h : env33572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33571_33572 : H12AffineEnvironment.transform 13 4404 env33571 = env33572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env33571 == env33572) = true)

theorem identity33572 : scanCanonicalize (H12AffineFastState.compose env33572 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound33572 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env33573 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,4096,41,4404,0,34,4389,292,101,1,4160,32,16,374,41,64,80,4469,4176,293,305,261,257,113,4160,513]

theorem envBound33573 : H12AffineFastState.Bounded env33573 := by
  intro p hp
  have h : env33573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33572_33573 : H12AffineEnvironment.transform 10 293 env33572 = env33573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env33572 == env33573) = true)

theorem identity33573 : scanCanonicalize (H12AffineFastState.compose env33573 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound33573 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33574 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,65,41,373,0,34,356,292,101,1,1,32,16,374,41,64,80,308,17,293,305,261,257,113,1,513]

theorem envBound33574 : H12AffineFastState.Bounded env33574 := by
  intro p hp
  have h : env33574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33573_33574 : H12AffineEnvironment.transform 11 65 env33573 = env33574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env33573 == env33574) = true)

theorem identity33574 : scanCanonicalize (H12AffineFastState.compose env33574 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33574 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33575 : List Nat := [2,4,8,16,32,16,8,256,512,52,293,17,41,293,0,34,308,292,53,1,1,32,16,294,41,16,0,308,17,293,305,261,257,33,1,513]

theorem envBound33575 : H12AffineFastState.Bounded env33575 := by
  intro p hp
  have h : env33575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33574_33575 : H12AffineEnvironment.transform 5 16 env33574 = env33575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33574 == env33575) = true)

theorem identity33575 : scanCanonicalize (H12AffineFastState.compose env33575 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33575 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33576 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,17,41,0,0,34,17,1,53,1,1,32,16,3,41,16,0,17,17,0,20,32,36,33,1,513]

theorem envBound33576 : H12AffineFastState.Bounded env33576 := by
  intro p hp
  have h : env33576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33575_33576 : H12AffineEnvironment.transform 7 37 env33575 = env33576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33575 == env33576) = true)

theorem identity33576 : scanCanonicalize (H12AffineFastState.compose env33576 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound33576 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33577 : List Nat := [2,4,8,16,32,16,8,37,16,52,0,17,41,0,0,34,17,1,53,1,1,32,16,3,41,16,0,17,17,0,20,32,36,33,1,17]

theorem envBound33577 : H12AffineFastState.Bounded env33577 := by
  intro p hp
  have h : env33577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33576_33577 : H12AffineEnvironment.transform 8 16 env33576 = env33577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env33576 == env33577) = true)

theorem identity33577 : scanCanonicalize (H12AffineFastState.compose env33577 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound33577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33578 : List Nat := [2,4,8,16,27,16,8,30,16,15,0,17,18,0,0,25,17,1,14,1,1,27,16,3,18,16,0,17,17,0,20,27,31,26,1,17]

theorem envBound33578 : H12AffineFastState.Bounded env33578 := by
  intro p hp
  have h : env33578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33577_33578 : H12AffineEnvironment.transform 4 27 env33577 = env33578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env33577 == env33578) = true)

def env33579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,67619,1025,1,77899,73770,73755,65877,8193,64,10588,79130,17664,67618,75103,29821,257,21793,13324,513]

theorem envBound33579 : H12AffineFastState.Bounded env33579 := by
  intro p hp
  have h : env33579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33567_33579 : H12AffineEnvironment.transform 6 9 env33567 = env33579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33567 == env33579) = true)

theorem identity33579 : scanCanonicalize (H12AffineFastState.compose env33579 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound33579 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,342,24908,2421,1025,1,12573,8572,8525,3,8193,64,10588,13388,17664,2420,9225,29821,257,21793,13324,513]

theorem envBound33580 : H12AffineFastState.Bounded env33580 := by
  intro p hp
  have h : env33580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33579_33580 : H12AffineEnvironment.transform 15 342 env33579 = env33580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env33579 == env33580) = true)

theorem identity33580 : scanCanonicalize (H12AffineFastState.compose env33580 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound33580 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env33581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12393,0,342,4389,2421,1025,1,12573,8572,8525,3,8193,64,10588,13388,13673,2420,9225,1044,257,9544,13324,513]

theorem envBound33581 : H12AffineFastState.Bounded env33581 := by
  intro p hp
  have h : env33581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33580_33581 : H12AffineEnvironment.transform 13 12393 env33580 = env33581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env33580 == env33581) = true)

theorem identity33581 : scanCanonicalize (H12AffineFastState.compose env33581 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound33581 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,8192,11625,0,342,3109,2421,1025,1,11293,8572,8525,3,8193,64,10588,10572,10345,2420,9225,1044,257,9544,10508,513]

theorem envBound33582 : H12AffineFastState.Bounded env33582 := by
  intro p hp
  have h : env33582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33581_33582 : H12AffineEnvironment.transform 11 3328 env33581 = env33582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env33581 == env33582) = true)

theorem identity33582 : scanCanonicalize (H12AffineFastState.compose env33582 (packedSelected [0,1,7,8,10,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33582 : packedSelected [0,1,7,8,10,18] rootPS < 2^1333 := by decide +kernel

def env33583 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3109,8192,11340,0,115,3109,2128,1025,1,11293,8281,8296,3,8193,64,10361,10345,10345,2129,9225,1044,36,9325,10281,513]

theorem envBound33583 : H12AffineFastState.Bounded env33583 := by
  intro p hp
  have h : env33583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33582_33583 : H12AffineEnvironment.transform 7 37 env33582 = env33583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33582 == env33583) = true)

theorem identity33583 : scanCanonicalize (H12AffineFastState.compose env33583 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound33583 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33584 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3109,120,3124,0,115,3109,2128,1025,1,3173,33,16,3,121,64,2049,2065,2065,2129,1137,1044,36,1045,2129,513]

theorem envBound33584 : H12AffineFastState.Bounded env33584 := by
  intro p hp
  have h : env33584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33583_33584 : H12AffineEnvironment.transform 12 120 env33583 = env33584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env33583 == env33584) = true)

theorem identity33584 : scanCanonicalize (H12AffineFastState.compose env33584 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33584 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33585 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2064,120,2049,0,115,2064,2128,52,1,2128,33,16,3,121,64,2049,2065,2065,2129,68,33,36,32,2129,513]

theorem envBound33585 : H12AffineFastState.Bounded env33585 := by
  intro p hp
  have h : env33585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33584_33585 : H12AffineEnvironment.transform 9 53 env33584 = env33585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33584 == env33585) = true)

def env33586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2201878,2098513,17664,2437194,2102685,2411677,257,21793,46213,2175562]

theorem envBound33586 : H12AffineFastState.Bounded env33586 := by
  intro p hp
  have h : env33586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33563_33586 : H12AffineEnvironment.transform 21 272513 env33563 = env33586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33563 == env33586) = true)

theorem identity33586 : scanCanonicalize (H12AffineFastState.compose env33586 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33586 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272513,2101328,41430,8328,64,2144540,2098513,17664,2363456,2102685,2411677,257,21793,46213,2101824]

theorem envBound33587 : H12AffineFastState.Bounded env33587 := by
  intro p hp
  have h : env33587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33586_33587 : H12AffineEnvironment.transform 15 8202 env33586 = env33587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33586 == env33587) = true)

theorem identity33587 : scanCanonicalize (H12AffineFastState.compose env33587 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 309472) := by decide +kernel

theorem selectedBound33587 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env33588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,309472,272513,305328,41430,8328,64,262652,310705,17664,43168,306557,29821,257,21793,46213,305824]

theorem envBound33588 : H12AffineFastState.Bounded env33588 := by
  intro p hp
  have h : env33588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33587_33588 : H12AffineEnvironment.transform 20 309472 env33587 = env33588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309472 env33587 == env33588) = true)

theorem identity33588 : scanCanonicalize (H12AffineFastState.compose env33588 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound33588 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16401,262144,1025,0,276705,272513,272561,8663,8328,64,262652,277936,17664,10401,273788,29821,257,21793,13444,273057]

theorem envBound33589 : H12AffineFastState.Bounded env33589 := by
  intro p hp
  have h : env33589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33588_33589 : H12AffineEnvironment.transform 14 1 env33588 = env33589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env33588 == env33589) = true)

theorem identity33589 : scanCanonicalize (H12AffineFastState.compose env33589 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound33589 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,8202,13509,262144,1025,0,276705,272513,272561,8663,8328,64,262652,277936,12756,10401,273788,169,257,8693,13444,273057]

theorem envBound33590 : H12AffineFastState.Bounded env33590 := by
  intro p hp
  have h : env33590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33589_33590 : H12AffineEnvironment.transform 13 13524 env33589 = env33590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env33589 == env33590) = true)

theorem identity33590 : scanCanonicalize (H12AffineFastState.compose env33590 (packedSelected [1,8,9,10,11,15,16,22] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound33590 : packedSelected [1,8,9,10,11,15,16,22] rootPS < 2^1333 := by decide +kernel

def env33591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2113,8192,11413,1,8202,11396,262144,1025,0,270496,272513,272561,8663,8328,64,262652,271857,10645,10401,273788,169,257,8693,11461,273057]

theorem envBound33591 : H12AffineFastState.Bounded env33591 := by
  intro p hp
  have h : env33591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33590_33591 : H12AffineEnvironment.transform 11 2113 env33590 = env33591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env33590 == env33591) = true)

theorem identity33591 : scanCanonicalize (H12AffineFastState.compose env33591 (packedSelected [2,3,4,5,6,9,10,12,15,17,23] rootPS)) = affineNative (2^(17+1) ^^^ 80) := by decide +kernel

theorem selectedBound33591 : packedSelected [2,3,4,5,6,9,10,12,15,17,23] rootPS < 2^1333 := by decide +kernel

def env33592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2113,8192,11413,1,8202,11396,80,1025,0,8432,10449,10465,8663,8328,64,428,9633,10645,10401,11564,169,257,8693,11461,10993]

theorem envBound33592 : H12AffineFastState.Bounded env33592 := by
  intro p hp
  have h : env33592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33591_33592 : H12AffineEnvironment.transform 17 80 env33591 = env33592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 80 env33591 == env33592) = true)

theorem identity33592 : scanCanonicalize (H12AffineFastState.compose env33592 (packedSelected [0,2,4,7,9,11,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 3400) := by decide +kernel

theorem selectedBound33592 : packedSelected [0,2,4,7,9,11,17,18,19] rootPS < 2^1333 := by decide +kernel

def env33593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2113,3400,477,1,3394,460,80,1025,0,3512,1433,1449,3231,3520,64,428,2281,1245,1513,100,169,257,3261,397,1977]

theorem envBound33593 : H12AffineFastState.Bounded env33593 := by
  intro p hp
  have h : env33593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33592_33593 : H12AffineEnvironment.transform 12 3400 env33592 = env33593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3400 env33592 == env33593) = true)

theorem identity33593 : scanCanonicalize (H12AffineFastState.compose env33593 (packedSelected [2,3,5,7,9,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound33593 : packedSelected [2,3,5,7,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env33594 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,2113,3301,112,1,3311,97,80,1025,0,3093,1076,1028,3231,3181,64,1,2281,1245,1092,100,169,172,3261,32,1556]

theorem envBound33594 : H12AffineFastState.Bounded env33594 := by
  intro p hp
  have h : env33594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33593_33594 : H12AffineEnvironment.transform 7 173 env33593 = env33594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33593 == env33594) = true)

theorem identity33594 : scanCanonicalize (H12AffineFastState.compose env33594 (packedSelected [1,4,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound33594 : packedSelected [1,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33595 : List Nat := [2,4,8,16,32,64,128,173,512,221,2048,2113,2104,112,1,2098,97,80,220,0,2248,233,217,2114,2224,64,1,2281,0,153,100,169,172,2144,32,713]

theorem envBound33595 : H12AffineFastState.Bounded env33595 := by
  intro p hp
  have h : env33595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33594_33595 : H12AffineEnvironment.transform 9 221 env33594 = env33595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env33594 == env33595) = true)

theorem identity33595 : scanCanonicalize (H12AffineFastState.compose env33595 (packedSelected [1,2,4,6,8,9,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 249) := by decide +kernel

theorem selectedBound33595 : packedSelected [1,2,4,6,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env33596 : List Nat := [2,4,8,16,32,64,128,173,512,221,249,184,193,112,1,203,97,80,220,0,49,233,217,187,73,64,1,16,0,153,100,169,172,153,32,713]

theorem envBound33596 : H12AffineFastState.Bounded env33596 := by
  intro p hp
  have h : env33596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33595_33596 : H12AffineEnvironment.transform 10 249 env33595 = env33596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 249 env33595 == env33596) = true)

theorem identity33596 : scanCanonicalize (H12AffineFastState.compose env33596 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33596 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33597 : List Nat := [2,4,8,16,32,64,9,36,512,84,112,49,72,112,1,66,97,80,85,0,49,96,80,50,73,64,1,16,0,16,100,32,37,16,32,576]

theorem envBound33597 : H12AffineFastState.Bounded env33597 := by
  intro p hp
  have h : env33597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33596_33597 : H12AffineEnvironment.transform 6 9 env33596 = env33597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33596 == env33597) = true)

theorem identity33597 : scanCanonicalize (H12AffineFastState.compose env33597 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33597 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33598 : List Nat := [2,4,8,16,32,1,9,36,512,21,49,49,9,49,1,3,32,17,20,0,49,33,17,50,8,1,1,16,0,16,37,32,37,16,32,513]

theorem envBound33598 : H12AffineFastState.Bounded env33598 := by
  intro p hp
  have h : env33598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33597_33598 : H12AffineEnvironment.transform 5 1 env33597 = env33598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33597 == env33598) = true)

theorem identity33598 : scanCanonicalize (H12AffineFastState.compose env33598 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33598 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env33599 : List Nat := [2,4,8,11,32,1,9,36,512,14,42,42,9,42,1,3,32,10,15,0,42,33,10,41,8,1,1,11,0,11,37,32,37,11,32,513]

theorem envBound33599 : H12AffineFastState.Bounded env33599 := by
  intro p hp
  have h : env33599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33598_33599 : H12AffineEnvironment.transform 3 11 env33598 = env33599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33598 == env33599) = true)

theorem identity33599 : scanCanonicalize (H12AffineFastState.compose env33599 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound33599 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33600 : List Nat := [2,4,8,11,7,1,9,3,512,14,13,13,9,13,1,3,7,10,15,0,13,6,10,14,8,1,1,11,0,11,2,7,2,11,7,513]

theorem envBound33600 : H12AffineFastState.Bounded env33600 := by
  intro p hp
  have h : env33600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33599_33600 : H12AffineEnvironment.transform 4 7 env33599 = env33600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env33599 == env33600) = true)

theorem identity33600 : scanCanonicalize (H12AffineFastState.compose env33600 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33600 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env33601 : List Nat := [2,4,2,1,7,1,3,3,512,4,7,7,3,7,1,3,7,0,5,0,7,6,0,4,2,1,1,1,0,1,2,7,2,1,7,513]

theorem envBound33601 : H12AffineFastState.Bounded env33601 := by
  intro p hp
  have h : env33601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33600_33601 : H12AffineEnvironment.transform 2 2 env33600 = env33601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33600 == env33601) = true)

theorem identity33601 : scanCanonicalize (H12AffineFastState.compose env33601 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33601 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33602 : List Nat := [0,4,0,1,5,1,1,1,512,4,5,5,1,5,1,1,5,0,5,0,5,4,0,4,0,1,1,1,0,1,0,5,0,1,5,513]

theorem envBound33602 : H12AffineFastState.Bounded env33602 := by
  intro p hp
  have h : env33602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33601_33602 : H12AffineEnvironment.transform 0 0 env33601 = env33602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33601 == env33602) = true)

theorem identity33602 : scanCanonicalize (H12AffineFastState.compose env33602 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33602 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33603 : List Nat := [0,1,0,1,0,1,1,1,512,1,0,0,1,0,1,1,0,0,0,0,0,1,0,1,0,1,1,1,0,1,0,0,0,1,0,513]

theorem envBound33603 : H12AffineFastState.Bounded env33603 := by
  intro p hp
  have h : env33603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33602_33603 : H12AffineEnvironment.transform 1 1 env33602 = env33603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33602 == env33603) = true)

def env33604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6664599,2098512,17665,2437195,2102685,6349853,257,21793,46213,2175562]

theorem envBound33604 : H12AffineFastState.Bounded env33604 := by
  intro p hp
  have h : env33604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33562_33604 : H12AffineEnvironment.transform 22 2101329 env33562 = env33604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env33562 == env33604) = true)

def env33605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2201879,2098512,17665,2437195,2102685,2411677,257,21793,46213,2175562]

theorem envBound33605 : H12AffineFastState.Bounded env33605 := by
  intro p hp
  have h : env33605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33604_33605 : H12AffineEnvironment.transform 21 272512 env33604 = env33605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33604 == env33605) = true)

theorem identity33605 : scanCanonicalize (H12AffineFastState.compose env33605 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound33605 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,115870,272512,120015,98781,8328,64,23945,115150,17665,324821,119043,329731,257,21793,46213,63188]

theorem envBound33606 : H12AffineFastState.Bounded env33606 := by
  intro p hp
  have h : env33606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33605_33606 : H12AffineEnvironment.transform 20 115870 env33605 = env33606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env33605 == env33606) = true)

def env33607 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,115870,272512,119967,98701,8328,16,23945,115102,17665,324741,119043,329731,257,21793,46213,63108]

theorem envBound33607 : H12AffineFastState.Bounded env33607 := by
  intro p hp
  have h : env33607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33606_33607 : H12AffineEnvironment.transform 5 16 env33606 = env33607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33606 == env33607) = true)

theorem identity33607 : scanCanonicalize (H12AffineFastState.compose env33607 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound33607 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env33608 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,122147,1025,32769,115870,128419,119967,98701,8328,16,23945,115102,17665,76198,119043,54560,257,21793,46213,63108]

theorem envBound33608 : H12AffineFastState.Bounded env33608 := by
  intro p hp
  have h : env33608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33607_33608 : H12AffineEnvironment.transform 17 122147 env33607 = env33608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env33607 == env33608) = true)

theorem identity33608 : scanCanonicalize (H12AffineFastState.compose env33608 (packedSelected [0,3,5,8,9,10,11,16,17,20,22,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound33608 : packedSelected [0,3,5,8,9,10,11,16,17,20,22,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33609 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62730,5392,10281,1025,32769,12692,169,8597,29831,8328,16,23945,13460,17665,56492,9225,54560,257,21793,46213,63108]

theorem envBound33609 : H12AffineFastState.Bounded env33609 := by
  intro p hp
  have h : env33609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33608_33609 : H12AffineEnvironment.transform 15 62730 env33608 = env33609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env33608 == env33609) = true)

def env33610 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,115870,272512,119966,98700,8328,17,23945,115103,17665,324740,119043,329731,257,21793,46213,63109]

theorem envBound33610 : H12AffineFastState.Bounded env33610 := by
  intro p hp
  have h : env33610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33606_33610 : H12AffineEnvironment.transform 5 17 env33606 = env33610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33606 == env33610) = true)

theorem identity33610 : scanCanonicalize (H12AffineFastState.compose env33610 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound33610 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env33611 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,64809,1025,32769,115870,54697,119966,98700,8328,17,23945,115103,17665,2477,119043,128298,257,21793,46213,63109]

theorem envBound33611 : H12AffineFastState.Bounded env33611 := by
  intro p hp
  have h : env33611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33610_33611 : H12AffineEnvironment.transform 17 64809 env33610 = env33611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env33610 == env33611) = true)

theorem identity33611 : scanCanonicalize (H12AffineFastState.compose env33611 (packedSelected [0,1,9,16,18,20,22,23,26,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound33611 : packedSelected [0,1,9,16,18,20,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env33612 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,32768,65536,103583,35244,1025,32769,110619,41260,106523,98700,8328,17,10508,111898,12676,2477,107910,98735,257,8612,46213,33280]

theorem envBound33612 : H12AffineFastState.Bounded env33612 := by
  intro p hp
  have h : env33612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33611_33612 : H12AffineEnvironment.transform 13 13445 env33611 = env33612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env33611 == env33612) = true)

theorem identity33612 : scanCanonicalize (H12AffineFastState.compose env33612 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound33612 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env33613 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,8581,65536,79130,10281,1025,8580,70046,169,65950,73737,8328,17,10508,70815,12676,2477,66563,73770,257,8612,5376,9093]

theorem envBound33613 : H12AffineFastState.Bounded env33613 := by
  intro p hp
  have h : env33613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33612_33613 : H12AffineEnvironment.transform 14 8581 env33612 = env33613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env33612 == env33613) = true)

theorem identity33613 : scanCanonicalize (H12AffineFastState.compose env33613 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33613 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env33614 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,8461,65536,79130,10281,1025,8460,69910,33,65814,73737,8192,17,10508,70679,12556,2341,66563,73770,257,8492,5376,8973]

theorem envBound33614 : H12AffineFastState.Bounded env33614 := by
  intro p hp
  have h : env33614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33613_33614 : H12AffineEnvironment.transform 6 8 env33613 = env33614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33613 == env33614) = true)

theorem identity33614 : scanCanonicalize (H12AffineFastState.compose env33614 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound33614 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env33615 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,8461,263,13341,10281,1025,8460,4113,33,17,8462,8192,17,10508,5392,12556,2341,1284,8493,257,8492,5376,8973]

theorem envBound33615 : H12AffineFastState.Bounded env33615 := by
  intro p hp
  have h : env33615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33614_33615 : H12AffineEnvironment.transform 15 263 env33614 = env33615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env33614 == env33615) = true)

theorem identity33615 : scanCanonicalize (H12AffineFastState.compose env33615 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 2822) := by decide +kernel

theorem selectedBound33615 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33616 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,2822,7947,2571,263,7963,815,1025,2570,4113,33,17,2568,2822,17,522,5392,6666,2341,1284,2603,257,2602,5376,2059]

theorem envBound33616 : H12AffineFastState.Bounded env33616 := by
  intro p hp
  have h : env33616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33615_33616 : H12AffineEnvironment.transform 12 2822 env33615 = env33616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2822 env33615 == env33616) = true)

theorem identity33616 : scanCanonicalize (H12AffineFastState.compose env33616 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound33616 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env33617 : List Nat := [2,4,8,16,32,17,8,256,512,1024,522,4096,268,5377,1,263,5393,815,1025,0,4113,33,17,2,268,17,522,5392,4096,815,1284,33,257,32,5376,513]

theorem envBound33617 : H12AffineFastState.Bounded env33617 := by
  intro p hp
  have h : env33617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33616_33617 : H12AffineEnvironment.transform 10 522 env33616 = env33617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env33616 == env33617) = true)

theorem identity33617 : scanCanonicalize (H12AffineFastState.compose env33617 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33617 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33618 : List Nat := [2,4,8,16,32,17,8,37,512,1024,522,4096,41,5156,1,34,5172,522,1025,0,4113,33,17,2,41,17,522,5173,4096,522,1057,33,36,32,5157,513]

theorem envBound33618 : H12AffineFastState.Bounded env33618 := by
  intro p hp
  have h : env33618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33617_33618 : H12AffineEnvironment.transform 7 37 env33617 = env33618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33617 == env33618) = true)

theorem identity33618 : scanCanonicalize (H12AffineFastState.compose env33618 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33618 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33619 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,4096,9,5124,1,2,5140,522,1025,0,4113,1,17,2,9,17,522,5141,4096,522,1025,1,4,0,5125,513]

theorem envBound33619 : H12AffineFastState.Bounded env33619 := by
  intro p hp
  have h : env33619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33618_33619 : H12AffineEnvironment.transform 4 0 env33618 = env33619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33618 == env33619) = true)

def env33620 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,16,9,1044,1,2,1028,522,1025,0,1,1,17,2,9,17,522,1029,16,522,1025,1,4,0,1045,513]

theorem envBound33620 : H12AffineFastState.Bounded env33620 := by
  intro p hp
  have h : env33620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33619_33620 : H12AffineEnvironment.transform 11 16 env33619 = env33620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env33619 == env33620) = true)

theorem identity33620 : scanCanonicalize (H12AffineFastState.compose env33620 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 523) := by decide +kernel

theorem selectedBound33620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33621 : List Nat := [2,4,8,16,0,17,8,5,512,523,522,16,9,543,1,2,527,522,522,0,1,1,17,2,9,17,522,526,16,522,522,1,4,0,542,513]

theorem envBound33621 : H12AffineFastState.Bounded env33621 := by
  intro p hp
  have h : env33621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33620_33621 : H12AffineEnvironment.transform 9 523 env33620 = env33621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 523 env33620 == env33621) = true)

def env33622 : List Nat := [2,4,8,4,0,5,8,5,512,523,522,4,9,523,1,2,527,522,522,0,1,1,5,2,9,5,522,526,4,522,522,1,4,0,522,513]

theorem envBound33622 : H12AffineFastState.Bounded env33622 := by
  intro p hp
  have h : env33622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33621_33622 : H12AffineEnvironment.transform 3 4 env33621 = env33622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env33621 == env33622) = true)

theorem identity33622 : scanCanonicalize (H12AffineFastState.compose env33622 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound33622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33623 : List Nat := [2,4,8,4,0,5,8,5,9,2,3,4,9,2,1,2,6,3,3,0,1,1,5,2,9,5,3,7,4,3,3,1,4,0,3,8]

theorem envBound33623 : H12AffineFastState.Bounded env33623 := by
  intro p hp
  have h : env33623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33622_33623 : H12AffineEnvironment.transform 8 9 env33622 = env33623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env33622 == env33623) = true)

def leafEnv33623 : List Nat := [2,4,8,4,0,5,8,5,9,2,3,4,9,2,1,2,6,3,3,0,1,1,5,2,3,9,1,5,3,7,4,3,3,1,4,0,4,2,3,8,1,0,0]

def active33623 : List Nat := [0,1,2]

def tree33623 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33623 : H12WitnessSearch.Good tree33623 := H12GlobalWitnessIndex.good

theorem leafIdentity33623 : H12AffineFastState.composeSystem env33623 rootObs = leafEnv33623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33623 rootObs == leafEnv33623) = true)

theorem terminalChecked33623 : H12PackedTerminal.terminalCheckFast leafEnv33623 active33623 tree33623 = true := by decide +kernel

def env33624 : List Nat := [2,4,8,5,0,4,8,5,512,523,522,5,9,522,1,2,527,522,522,0,1,1,4,2,9,4,522,526,5,522,522,1,4,0,523,513]

theorem envBound33624 : H12AffineFastState.Bounded env33624 := by
  intro p hp
  have h : env33624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33621_33624 : H12AffineEnvironment.transform 3 5 env33621 = env33624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env33621 == env33624) = true)

theorem identity33624 : scanCanonicalize (H12AffineFastState.compose env33624 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33625 : List Nat := [0,4,8,5,0,4,8,5,512,521,520,5,9,520,1,0,525,520,520,0,1,1,4,0,9,4,520,524,5,520,520,1,4,0,521,513]

theorem envBound33625 : H12AffineFastState.Bounded env33625 := by
  intro p hp
  have h : env33625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33624_33625 : H12AffineEnvironment.transform 0 0 env33624 = env33625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33624 == env33625) = true)

def leafEnv33625 : List Nat := [0,4,8,5,0,4,8,5,512,521,520,5,9,520,1,0,525,520,520,0,1,1,4,0,520,9,1,4,520,524,5,520,520,1,4,0,4,0,521,513,1,0,0]

def active33625 : List Nat := [1,2,8]

def tree33625 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33625 : H12WitnessSearch.Good tree33625 := H12GlobalWitnessIndex.good

theorem leafIdentity33625 : H12AffineFastState.composeSystem env33625 rootObs = leafEnv33625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33625 rootObs == leafEnv33625) = true)

theorem terminalChecked33625 : H12PackedTerminal.terminalCheckFast leafEnv33625 active33625 tree33625 = true := by decide +kernel

def env33626 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,17,9,1045,1,2,1029,522,1025,0,0,1,17,2,9,17,522,1028,17,522,1025,1,4,0,1044,513]

theorem envBound33626 : H12AffineFastState.Bounded env33626 := by
  intro p hp
  have h : env33626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33619_33626 : H12AffineEnvironment.transform 11 17 env33619 = env33626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env33619 == env33626) = true)

theorem identity33626 : scanCanonicalize (H12AffineFastState.compose env33626 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound33626 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33627 : List Nat := [2,4,8,16,0,17,8,5,30,1024,20,17,9,1045,1,2,1029,20,1025,0,0,1,17,2,9,17,20,1028,17,20,1025,1,4,0,1044,31]

theorem envBound33627 : H12AffineFastState.Bounded env33627 := by
  intro p hp
  have h : env33627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33626_33627 : H12AffineEnvironment.transform 8 30 env33626 = env33627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env33626 == env33627) = true)

def env33628 : List Nat := [2,4,8,16,0,17,8,5,30,0,20,17,9,21,1,2,5,20,1,0,0,1,17,2,9,17,20,4,17,20,1,1,4,0,20,31]

theorem envBound33628 : H12AffineFastState.Bounded env33628 := by
  intro p hp
  have h : env33628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33627_33628 : H12AffineEnvironment.transform 9 0 env33627 = env33628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env33627 == env33628) = true)

theorem identity33628 : scanCanonicalize (H12AffineFastState.compose env33628 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33628 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33629 : List Nat := [0,4,8,16,0,17,8,5,28,0,20,17,9,21,1,0,5,20,1,0,0,1,17,0,9,17,20,4,17,20,1,1,4,0,20,29]

theorem envBound33629 : H12AffineFastState.Bounded env33629 := by
  intro p hp
  have h : env33629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33628_33629 : H12AffineEnvironment.transform 0 0 env33628 = env33629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33628 == env33629) = true)

def leafEnv33629 : List Nat := [0,4,8,16,0,17,8,5,28,0,20,17,9,21,1,0,5,20,1,0,0,1,17,0,1,9,1,17,20,4,17,20,1,1,4,0,4,0,20,29,1,1,0]

def active33629 : List Nat := [1,2,3]

def tree33629 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33629 : H12WitnessSearch.Good tree33629 := H12GlobalWitnessIndex.good

theorem leafIdentity33629 : H12AffineFastState.composeSystem env33629 rootObs = leafEnv33629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33629 rootObs == leafEnv33629) = true)

theorem terminalChecked33629 : H12PackedTerminal.terminalCheckFast leafEnv33629 active33629 tree33629 = true := by decide +kernel

def env33630 : List Nat := [2,4,8,16,0,17,8,5,30,1,20,17,9,20,1,2,4,20,0,0,0,1,17,2,9,17,20,5,17,20,0,1,4,0,21,31]

theorem envBound33630 : H12AffineFastState.Bounded env33630 := by
  intro p hp
  have h : env33630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33627_33630 : H12AffineEnvironment.transform 9 1 env33627 = env33630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env33627 == env33630) = true)

theorem identity33630 : scanCanonicalize (H12AffineFastState.compose env33630 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound33630 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33631 : List Nat := [2,4,8,7,0,6,8,5,9,1,3,6,9,3,1,2,4,3,0,0,0,1,6,2,9,6,3,5,6,3,0,1,4,0,2,8]

theorem envBound33631 : H12AffineFastState.Bounded env33631 := by
  intro p hp
  have h : env33631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33630_33631 : H12AffineEnvironment.transform 3 7 env33630 = env33631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env33630 == env33631) = true)

def leafEnv33631 : List Nat := [2,4,8,7,0,6,8,5,9,1,3,6,9,3,1,2,4,3,0,0,0,1,6,2,0,9,1,6,3,5,6,3,0,1,4,0,4,2,2,8,1,1,0]

def active33631 : List Nat := [0,1,2]

def tree33631 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33631 : H12WitnessSearch.Good tree33631 := H12GlobalWitnessIndex.good

theorem leafIdentity33631 : H12AffineFastState.composeSystem env33631 rootObs = leafEnv33631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33631 rootObs == leafEnv33631) = true)

theorem terminalChecked33631 : H12PackedTerminal.terminalCheckFast leafEnv33631 active33631 tree33631 = true := by decide +kernel

def env33632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2201878,2098512,17665,2437195,2102685,2411676,257,21793,46213,2175562]

theorem envBound33632 : H12AffineFastState.Bounded env33632 := by
  intro p hp
  have h : env33632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33604_33632 : H12AffineEnvironment.transform 21 272513 env33604 = env33632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33604 == env33632) = true)

theorem identity33632 : scanCanonicalize (H12AffineFastState.compose env33632 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound33632 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,13508,262144,1025,32769,2097152,272513,2101329,21763,8328,64,2117064,2098512,17665,2417813,2102685,2411676,257,21793,46213,2156180]

theorem envBound33633 : H12AffineFastState.Bounded env33633 := by
  intro p hp
  have h : env33633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33632_33633 : H12AffineEnvironment.transform 15 54494 env33632 = env33633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env33632 == env33633) = true)

def env33634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,262144,1025,32769,2097152,272393,2101329,21763,8192,64,2116928,2098512,17665,2417693,2102549,2411540,257,21793,46093,2156060]

theorem envBound33634 : H12AffineFastState.Bounded env33634 := by
  intro p hp
  have h : env33634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33633_33634 : H12AffineEnvironment.transform 6 8 env33633 = env33634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33633 == env33634) = true)

theorem identity33634 : scanCanonicalize (H12AffineFastState.compose env33634 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound33634 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env33635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,10281,1025,32769,2097152,32,2101329,21763,8192,64,2116928,2098512,17665,2149428,2102549,2155581,257,21793,46093,2156060]

theorem envBound33635 : H12AffineFastState.Bounded env33635 := by
  intro p hp
  have h : env33635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33634_33635 : H12AffineEnvironment.transform 17 10281 env33634 = env33635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33634 == env33635) = true)

theorem identity33635 : scanCanonicalize (H12AffineFastState.compose env33635 (packedSelected [0,1,3,7,9,12,14,15,16,22,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound33635 : packedSelected [0,1,3,7,9,12,14,15,16,22,24,28] rootPS < 2^1333 := by decide +kernel

def env33636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,10281,1025,32769,25628,32,29773,21763,8192,64,10588,24908,17665,43048,28937,32801,257,21793,46093,33280]

theorem envBound33636 : H12AffineFastState.Bounded env33636 := by
  intro p hp
  have h : env33636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33635_33636 : H12AffineEnvironment.transform 20 25628 env33635 = env33636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env33635 == env33636) = true)

theorem identity33636 : scanCanonicalize (H12AffineFastState.compose env33636 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33636 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,13388,10281,1025,32769,12573,32,8524,2,8192,64,10588,13389,4096,43048,9224,32801,257,32,46093,33280]

theorem envBound33637 : H12AffineFastState.Bounded env33637 := by
  intro p hp
  have h : env33637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33636_33637 : H12AffineEnvironment.transform 13 5377 env33636 = env33637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33636 == env33637) = true)

theorem identity33637 : scanCanonicalize (H12AffineFastState.compose env33637 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33637 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env33638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,13388,10281,1025,8540,12573,32,8524,2,8192,64,10588,13389,4096,2421,9224,8572,257,32,5456,9053]

theorem envBound33638 : H12AffineFastState.Bounded env33638 := by
  intro p hp
  have h : env33638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33637_33638 : H12AffineEnvironment.transform 14 8541 env33637 = env33638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33637 == env33638) = true)

theorem identity33638 : scanCanonicalize (H12AffineFastState.compose env33638 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33638 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env33639 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8232,8202,13388,10281,1025,8233,12392,32,8249,2,8192,64,10281,13389,4096,2048,9224,8201,116,32,5157,8744]

theorem envBound33639 : H12AffineFastState.Bounded env33639 := by
  intro p hp
  have h : env33639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33638_33639 : H12AffineEnvironment.transform 7 117 env33638 = env33639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33638 == env33639) = true)

theorem identity33639 : scanCanonicalize (H12AffineFastState.compose env33639 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound33639 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33640 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,4096,8192,5236,8232,8202,13388,8233,1025,8233,12392,32,8249,2,8192,64,8233,13389,4096,0,9224,8201,116,32,5157,8744]

theorem envBound33640 : H12AffineFastState.Bounded env33640 := by
  intro p hp
  have h : env33640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33639_33640 : H12AffineEnvironment.transform 10 0 env33639 = env33640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env33639 == env33640) = true)

def env33641 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,262144,1025,32769,2097152,272392,2101329,21763,8193,64,2116929,2098512,17665,2417692,2102548,2411541,257,21793,46092,2156061]

theorem envBound33641 : H12AffineFastState.Bounded env33641 := by
  intro p hp
  have h : env33641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33633_33641 : H12AffineEnvironment.transform 6 9 env33633 = env33641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33633 == env33641) = true)

theorem identity33641 : scanCanonicalize (H12AffineFastState.compose env33641 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 309352) := by decide +kernel

theorem selectedBound33641 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env33642 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,262144,1025,32769,309352,272392,305209,21763,8193,64,324905,310584,17665,23668,306556,29821,257,21793,46092,286325]

theorem envBound33642 : H12AffineFastState.Bounded env33642 := by
  intro p hp
  have h : env33642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33641_33642 : H12AffineEnvironment.transform 20 309352 env33641 = env33642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309352 env33641 == env33642) = true)

theorem identity33642 : scanCanonicalize (H12AffineFastState.compose env33642 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound33642 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env33643 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,10280,1025,32769,36928,32,32785,21763,8193,64,56577,38160,17665,23668,34132,29821,257,21793,46092,30301]

theorem envBound33643 : H12AffineFastState.Bounded env33643 := by
  intro p hp
  have h : env33643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33642_33643 : H12AffineEnvironment.transform 17 10280 env33642 = env33643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33642 == env33643) = true)

theorem identity33643 : scanCanonicalize (H12AffineFastState.compose env33643 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33643 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,13389,10280,1025,8540,12573,32,8524,21763,8193,64,31836,13389,17665,23668,9225,29821,257,21793,5457,30301]

theorem envBound33644 : H12AffineFastState.Bounded env33644 := by
  intro p hp
  have h : env33644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33643_33644 : H12AffineEnvironment.transform 14 8541 env33643 = env33644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33643 == env33644) = true)

theorem identity33644 : scanCanonicalize (H12AffineFastState.compose env33644 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound33644 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env33645 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,16384,8541,28990,12409,10280,53,8540,12573,32,8524,20791,8193,64,30824,12409,16693,22592,8253,28745,257,20757,4453,29289]

theorem envBound33645 : H12AffineFastState.Bounded env33645 := by
  intro p hp
  have h : env33645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33644_33645 : H12AffineEnvironment.transform 9 52 env33644 = env33645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33644 == env33645) = true)

theorem identity33645 : scanCanonicalize (H12AffineFastState.compose env33645 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound33645 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33646 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,40,16384,373,20758,4177,2048,53,372,4405,32,356,20791,41,64,22592,4177,16693,22592,21,20577,257,20757,4453,21057]

theorem envBound33646 : H12AffineFastState.Bounded env33646 := by
  intro p hp
  have h : env33646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33645_33646 : H12AffineEnvironment.transform 12 40 env33645 = env33646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env33645 == env33646) = true)

theorem identity33646 : scanCanonicalize (H12AffineFastState.compose env33646 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33646 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env33647 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,40,16384,0,20579,4177,2048,53,1,4160,32,17,20546,41,64,22592,4177,16448,22592,21,20577,116,20576,4112,21057]

theorem envBound33647 : H12AffineFastState.Bounded env33647 := by
  intro p hp
  have h : env33647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33646_33647 : H12AffineEnvironment.transform 7 117 env33646 = env33647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33646 == env33647) = true)

theorem identity33647 : scanCanonicalize (H12AffineFastState.compose env33647 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound33647 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33648 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,40,17,0,4210,4177,2048,53,1,4160,32,17,4179,41,64,6225,4177,81,6225,21,4208,116,4209,4112,4688]

theorem envBound33648 : H12AffineFastState.Bounded env33648 := by
  intro p hp
  have h : env33648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33647_33648 : H12AffineEnvironment.transform 13 17 env33647 = env33648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env33647 == env33648) = true)

theorem identity33648 : scanCanonicalize (H12AffineFastState.compose env33648 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound33648 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env33649 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,113,40,17,0,3,32,2048,53,1,49,32,17,34,41,64,2080,32,81,2080,21,1,116,0,97,545]

theorem envBound33649 : H12AffineFastState.Bounded env33649 := by
  intro p hp
  have h : env33649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33648_33649 : H12AffineEnvironment.transform 11 113 env33648 = env33649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env33648 == env33649) = true)

theorem identity33649 : scanCanonicalize (H12AffineFastState.compose env33649 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33649 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33650 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,32,40,17,0,3,32,2048,53,1,49,32,17,34,41,17,2080,32,0,2080,21,1,37,0,48,545]

theorem envBound33650 : H12AffineFastState.Bounded env33650 := by
  intro p hp
  have h : env33650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33649_33650 : H12AffineEnvironment.transform 5 17 env33649 = env33650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33649 == env33650) = true)

theorem identity33650 : scanCanonicalize (H12AffineFastState.compose env33650 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33650 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33651 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,0,8,17,0,3,0,2048,21,1,17,0,17,2,9,17,2048,0,0,2048,21,1,5,0,16,513]

theorem envBound33651 : H12AffineFastState.Bounded env33651 := by
  intro p hp
  have h : env33651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33650_33651 : H12AffineEnvironment.transform 4 0 env33650 = env33651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33650 == env33651) = true)

theorem identity33651 : scanCanonicalize (H12AffineFastState.compose env33651 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound33651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33652 : List Nat := [2,4,8,16,0,17,9,4,512,20,512,0,8,17,0,3,0,512,21,1,17,0,17,2,9,17,512,0,0,512,21,1,5,0,16,513]

theorem envBound33652 : H12AffineFastState.Bounded env33652 := by
  intro p hp
  have h : env33652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33651_33652 : H12AffineEnvironment.transform 10 512 env33651 = env33652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env33651 == env33652) = true)

def env33653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6664598,8393984,10507600,8724506,2102684,12645453,257,21792,46212,2175563]

theorem envBound33653 : H12AffineFastState.Bounded env33653 := by
  intro p hp
  have h : env33653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33561_33653 : H12AffineEnvironment.transform 23 10588557 env33561 = env33653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env33561 == env33653) = true)

def env33654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6664598,2098512,17664,2437194,2102684,6349853,257,21792,46212,2175563]

theorem envBound33654 : H12AffineFastState.Bounded env33654 := by
  intro p hp
  have h : env33654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33653_33654 : H12AffineEnvironment.transform 22 2101328 env33653 = env33654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env33653 == env33654) = true)

def env33655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2201878,2098512,17664,2437194,2102684,2411677,257,21792,46212,2175563]

theorem envBound33655 : H12AffineFastState.Bounded env33655 := by
  intro p hp
  have h : env33655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33654_33655 : H12AffineEnvironment.transform 21 272512 env33654 = env33655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33654 == env33655) = true)

theorem identity33655 : scanCanonicalize (H12AffineFastState.compose env33655 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound33655 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,70862,262144,1025,29909,2097152,272512,2101328,95497,8328,64,2190786,2098512,17664,2437194,2102684,2373705,257,21792,16464,2175563]

theorem envBound33656 : H12AffineFastState.Bounded env33656 := by
  intro p hp
  have h : env33656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33655_33656 : H12AffineEnvironment.transform 14 29908 env33655 = env33656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env33655 == env33656) = true)

def env33657 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70814,262144,1025,29829,2097152,272512,2101248,95497,8328,16,2190738,2098432,17664,2437146,2102684,2373657,257,21792,16384,2175515]

theorem envBound33657 : H12AffineFastState.Bounded env33657 := by
  intro p hp
  have h : env33657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33656_33657 : H12AffineEnvironment.transform 5 16 env33656 = env33657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33656 == env33657) = true)

theorem identity33657 : scanCanonicalize (H12AffineFastState.compose env33657 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound33657 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33658 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70814,76198,1025,29829,2097152,65830,2101248,95497,8328,16,2190738,2098432,17664,2103740,2102684,2167231,257,21792,16384,2175515]

theorem envBound33658 : H12AffineFastState.Bounded env33658 := by
  intro p hp
  have h : env33658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33657_33658 : H12AffineEnvironment.transform 17 76198 env33657 = env33658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env33657 == env33658) = true)

theorem identity33658 : scanCanonicalize (H12AffineFastState.compose env33658 (packedSelected [0,1,3,4,7,10,16,20,22,24,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound33658 : packedSelected [0,1,3,4,7,10,16,20,22,24,28,31] rootPS < 2^1333 := by decide +kernel

def env33659 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70814,76198,1025,29829,12572,65830,8476,95497,8328,16,89230,13340,17664,10400,9344,73891,257,21792,16384,66311]

theorem envBound33659 : H12AffineFastState.Bounded env33659 := by
  intro p hp
  have h : env33659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33658_33659 : H12AffineEnvironment.transform 20 12572 env33658 = env33659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env33658 == env33659) = true)

theorem identity33659 : scanCanonicalize (H12AffineFastState.compose env33659 (packedSelected [1,8,9,10,11,15,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound33659 : packedSelected [1,8,9,10,11,15,20,22] rootPS < 2^1333 := by decide +kernel

def env33660 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2201,8192,16384,27677,65536,68615,76198,1025,27676,10629,65830,8476,93584,8328,16,82967,11397,17664,10400,9344,73891,257,19897,16384,66311]

theorem envBound33660 : H12AffineFastState.Bounded env33660 := by
  intro p hp
  have h : env33660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33659_33660 : H12AffineEnvironment.transform 11 2201 env33659 = env33660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env33659 == env33660) = true)

theorem identity33660 : scanCanonicalize (H12AffineFastState.compose env33660 (packedSelected [0,1,2,3,5,6,7,8,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound33660 : packedSelected [0,1,2,3,5,6,7,8,15,16,17] rootPS < 2^1333 := by decide +kernel

def env33661 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2201,3101,16384,16384,65536,68615,67003,1025,16385,1432,65830,3329,82317,3221,16,82967,152,17664,1213,2205,68798,257,19897,16384,66311]

theorem envBound33661 : H12AffineFastState.Bounded env33661 := by
  intro p hp
  have h : env33661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33660_33661 : H12AffineEnvironment.transform 12 3101 env33660 = env33661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env33660 == env33661) = true)

theorem identity33661 : scanCanonicalize (H12AffineFastState.compose env33661 (packedSelected [0,4,7,9,10,11,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 1183) := by decide +kernel

theorem selectedBound33661 : packedSelected [0,4,7,9,10,11,16,19] rootPS < 2^1333 := by decide +kernel

def env33662 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2201,3101,16384,16384,1183,2200,292,1025,16385,1432,1465,3329,17682,3221,16,16520,152,17664,1213,2205,2081,257,19897,16384,1944]

theorem envBound33662 : H12AffineFastState.Bounded env33662 := by
  intro p hp
  have h : env33662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33661_33662 : H12AffineEnvironment.transform 15 1183 env33661 = env33662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1183 env33661 == env33662) = true)

theorem identity33662 : scanCanonicalize (H12AffineFastState.compose env33662 (packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 2476) := by decide +kernel

theorem selectedBound33662 : packedSelected [0,1,3,4,5,7,8,9,12,18,20] rootPS < 2^1333 := by decide +kernel

def env33663 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2201,3101,2476,2476,1183,2200,292,1025,2477,1432,1465,3329,3262,3221,16,2340,152,3244,1213,2205,2081,257,1045,2476,1944]

theorem envBound33663 : H12AffineFastState.Bounded env33663 := by
  intro p hp
  have h : env33663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33662_33663 : H12AffineEnvironment.transform 13 2476 env33662 = env33663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2476 env33662 == env33663) = true)

theorem identity33663 : scanCanonicalize (H12AffineFastState.compose env33663 (packedSelected [0,2,4,6,7,9,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33663 : packedSelected [0,2,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env33664 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1076,1197,41,1432,1432,1183,1196,292,1025,1433,1432,1465,309,138,161,16,1296,152,152,1213,1193,1045,257,1045,1432,1944]

theorem envBound33664 : H12AffineFastState.Bounded env33664 := by
  intro p hp
  have h : env33664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33663_33664 : H12AffineEnvironment.transform 10 1076 env33663 = env33664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env33663 == env33664) = true)

theorem identity33664 : scanCanonicalize (H12AffineFastState.compose env33664 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33664 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33665 : List Nat := [2,4,8,16,32,16,128,256,512,272,292,445,41,136,136,399,444,292,273,137,136,169,309,138,161,16,0,152,152,429,441,261,257,261,136,648]

theorem envBound33665 : H12AffineFastState.Bounded env33665 := by
  intro p hp
  have h : env33665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33664_33665 : H12AffineEnvironment.transform 9 272 env33664 = env33665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33664 == env33665) = true)

theorem identity33665 : scanCanonicalize (H12AffineFastState.compose env33665 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound33665 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env33666 : List Nat := [2,4,8,16,32,16,128,172,512,188,136,17,41,136,136,35,16,136,189,137,136,169,153,138,161,16,0,152,152,1,21,169,173,169,136,648]

theorem envBound33666 : H12AffineFastState.Bounded env33666 := by
  intro p hp
  have h : env33666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33665_33666 : H12AffineEnvironment.transform 7 172 env33665 = env33666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33665 == env33666) = true)

theorem identity33666 : scanCanonicalize (H12AffineFastState.compose env33666 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 157) := by decide +kernel

theorem selectedBound33666 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33667 : List Nat := [2,4,8,16,32,16,128,172,157,188,136,17,41,136,136,35,16,136,189,137,136,169,153,138,161,16,0,152,152,1,21,169,173,169,136,21]

theorem envBound33667 : H12AffineFastState.Bounded env33667 := by
  intro p hp
  have h : env33667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33666_33667 : H12AffineEnvironment.transform 8 157 env33666 = env33667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 157 env33666 == env33667) = true)

theorem identity33667 : scanCanonicalize (H12AffineFastState.compose env33667 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound33667 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env33668 : List Nat := [2,4,8,16,16,16,128,156,157,140,136,17,25,136,136,19,16,136,141,137,136,153,153,138,145,16,0,152,152,1,21,153,157,153,136,21]

theorem envBound33668 : H12AffineFastState.Bounded env33668 := by
  intro p hp
  have h : env33668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33667_33668 : H12AffineEnvironment.transform 4 16 env33667 = env33668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env33667 == env33668) = true)

theorem identity33668 : scanCanonicalize (H12AffineFastState.compose env33668 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33669 : List Nat := [2,4,8,0,0,0,128,140,141,140,136,1,9,136,136,3,0,136,141,137,136,137,137,138,129,0,0,136,136,1,5,137,141,137,136,5]

theorem envBound33669 : H12AffineFastState.Bounded env33669 := by
  intro p hp
  have h : env33669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33668_33669 : H12AffineEnvironment.transform 3 0 env33668 = env33669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33668 == env33669) = true)

theorem identity33669 : scanCanonicalize (H12AffineFastState.compose env33669 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33669 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33670 : List Nat := [2,0,8,0,0,0,128,136,137,136,136,1,9,136,136,3,0,136,137,137,136,137,137,138,129,0,0,136,136,1,1,137,137,137,136,1]

theorem envBound33670 : H12AffineFastState.Bounded env33670 := by
  intro p hp
  have h : env33670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33669_33670 : H12AffineEnvironment.transform 1 0 env33669 = env33670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33669 == env33670) = true)

theorem identity33670 : scanCanonicalize (H12AffineFastState.compose env33670 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound33670 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33671 : List Nat := [2,0,8,0,0,0,3,11,10,11,11,1,9,11,11,3,0,11,10,10,11,10,10,9,2,0,0,11,11,1,1,10,10,10,11,1]

theorem envBound33671 : H12AffineFastState.Bounded env33671 := by
  intro p hp
  have h : env33671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33670_33671 : H12AffineEnvironment.transform 6 3 env33670 = env33671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env33670 == env33671) = true)

theorem identity33671 : scanCanonicalize (H12AffineFastState.compose env33671 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound33671 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33672 : List Nat := [2,0,0,0,0,0,3,3,2,3,3,1,1,3,3,3,0,3,2,2,3,2,2,1,2,0,0,3,3,1,1,2,2,2,3,1]

theorem envBound33672 : H12AffineFastState.Bounded env33672 := by
  intro p hp
  have h : env33672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33671_33672 : H12AffineEnvironment.transform 2 0 env33671 = env33672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env33671 == env33672) = true)

theorem identity33672 : scanCanonicalize (H12AffineFastState.compose env33672 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33672 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33673 : List Nat := [1,0,0,0,0,0,0,0,1,0,0,1,1,0,0,0,0,0,1,1,0,1,1,1,1,0,0,0,0,1,1,1,1,1,0,1]

theorem envBound33673 : H12AffineFastState.Bounded env33673 := by
  intro p hp
  have h : env33673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33672_33673 : H12AffineEnvironment.transform 0 1 env33672 = env33673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33672 == env33673) = true)

def env33674 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70815,262144,1025,29828,2097152,272512,2101249,95497,8328,17,2190739,2098433,17664,2437147,2102684,2373656,257,21792,16385,2175514]

theorem envBound33674 : H12AffineFastState.Bounded env33674 := by
  intro p hp
  have h : env33674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33656_33674 : H12AffineEnvironment.transform 5 17 env33656 = env33674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33656 == env33674) = true)

theorem identity33674 : scanCanonicalize (H12AffineFastState.compose env33674 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound33674 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33675 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70815,2477,1025,29828,2097152,8493,2101249,95497,8328,17,2190739,2098433,17664,2177462,2102684,2109877,257,21792,16385,2175514]

theorem envBound33675 : H12AffineFastState.Bounded env33675 := by
  intro p hp
  have h : env33675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33674_33675 : H12AffineEnvironment.transform 17 2477 env33674 = env33675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env33674 == env33675) = true)

theorem identity33675 : scanCanonicalize (H12AffineFastState.compose env33675 (packedSelected [1,10,11,17,26,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound33675 : packedSelected [1,10,11,17,26,28,32] rootPS < 2^1333 := by decide +kernel

def env33676 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70815,2477,1025,29828,17816,8493,21913,95497,8328,17,75787,16537,17664,97326,20484,29741,257,21792,16385,96130]

theorem envBound33676 : H12AffineFastState.Bounded env33676 := by
  intro p hp
  have h : env33676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33675_33676 : H12AffineEnvironment.transform 20 17816 env33675 = env33676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env33675 == env33676) = true)

theorem identity33676 : scanCanonicalize (H12AffineFastState.compose env33676 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound33676 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env33677 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,30083,24860,2477,1025,29828,17816,8493,21913,138,8328,17,23944,16537,17664,2477,20484,29741,257,21792,16385,513]

theorem envBound33677 : H12AffineFastState.Bounded env33677 := by
  intro p hp
  have h : env33677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33676_33677 : H12AffineEnvironment.transform 15 30083 env33676 = env33677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env33676 == env33677) = true)

theorem identity33677 : scanCanonicalize (H12AffineFastState.compose env33677 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33677 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env33678 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,29963,24860,2341,1025,29708,17680,8493,21777,2,8192,17,23808,16401,17664,2341,20484,29741,257,21792,16385,513]

theorem envBound33678 : H12AffineFastState.Bounded env33678 := by
  intro p hp
  have h : env33678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33677_33678 : H12AffineEnvironment.transform 6 8 env33677 = env33678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33677 == env33678) = true)

theorem identity33678 : scanCanonicalize (H12AffineFastState.compose env33678 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound33678 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33679 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21761,21511,16400,2341,1025,21760,17680,33,21777,2,268,17,23808,16401,17664,2341,20484,21793,257,21792,16385,513]

theorem envBound33679 : H12AffineFastState.Bounded env33679 := by
  intro p hp
  have h : env33679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33678_33679 : H12AffineEnvironment.transform 12 268 env33678 = env33679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env33678 == env33679) = true)

theorem identity33679 : scanCanonicalize (H12AffineFastState.compose env33679 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33679 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env33680 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1025,0,4112,33,17,2,268,17,2048,5393,4096,2341,1284,33,257,32,5377,513]

theorem envBound33680 : H12AffineFastState.Bounded env33680 := by
  intro p hp
  have h : env33680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33679_33680 : H12AffineEnvironment.transform 13 5376 env33679 = env33680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33679 == env33680) = true)

theorem identity33680 : scanCanonicalize (H12AffineFastState.compose env33680 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33681 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,1,35,5172,2049,1025,0,4112,33,17,2,40,17,2048,5173,4096,2049,1056,33,37,32,5157,513]

theorem envBound33681 : H12AffineFastState.Bounded env33681 := by
  intro p hp
  have h : env33681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33680_33681 : H12AffineEnvironment.transform 7 36 env33680 = env33681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33680 == env33681) = true)

theorem identity33681 : scanCanonicalize (H12AffineFastState.compose env33681 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound33681 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33682 : List Nat := [2,4,8,16,32,17,8,36,512,1024,522,4096,40,5156,1,35,5172,523,1025,0,4112,33,17,2,40,17,522,5173,4096,523,1056,33,37,32,5157,513]

theorem envBound33682 : H12AffineFastState.Bounded env33682 := by
  intro p hp
  have h : env33682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33681_33682 : H12AffineEnvironment.transform 10 522 env33681 = env33682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env33681 == env33682) = true)

theorem identity33682 : scanCanonicalize (H12AffineFastState.compose env33682 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33682 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33683 : List Nat := [2,4,8,16,0,17,8,4,512,1024,522,4096,8,5124,1,3,5140,523,1025,0,4112,1,17,2,8,17,522,5141,4096,523,1024,1,5,0,5125,513]

theorem envBound33683 : H12AffineFastState.Bounded env33683 := by
  intro p hp
  have h : env33683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33682_33683 : H12AffineEnvironment.transform 4 0 env33682 = env33683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33682 == env33683) = true)

def env33684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2201879,2098512,17664,2437194,2102684,2411676,257,21792,46212,2175563]

theorem envBound33684 : H12AffineFastState.Bounded env33684 := by
  intro p hp
  have h : env33684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33654_33684 : H12AffineEnvironment.transform 21 272513 env33654 = env33684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33654 == env33684) = true)

theorem identity33684 : scanCanonicalize (H12AffineFastState.compose env33684 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound33684 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,58517,272513,62661,98781,8328,64,97666,57797,17664,382175,61705,272393,257,21792,46212,120542]

theorem envBound33685 : H12AffineFastState.Bounded env33685 := by
  intro p hp
  have h : env33685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33684_33685 : H12AffineEnvironment.transform 20 58517 env33684 = env33685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env33684 == env33685) = true)

def env33686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1025,32769,58517,169,62661,98781,8328,64,97666,57797,17664,130295,61705,33,257,21792,46212,120542]

theorem envBound33686 : H12AffineFastState.Bounded env33686 := by
  intro p hp
  have h : env33686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33685_33686 : H12AffineEnvironment.transform 17 10280 env33685 = env33686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33685 == env33686) = true)

theorem identity33686 : scanCanonicalize (H12AffineFastState.compose env33686 (packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound33686 : packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env33687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,16384,32768,65536,115798,3172,1025,32769,49369,169,53385,98781,1220,64,88526,50569,17664,121019,54597,33,257,21792,37064,120542]

theorem envBound33687 : H12AffineFastState.Bounded env33687 := by
  intro p hp
  have h : env33687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33686_33687 : H12AffineEnvironment.transform 12 1100 env33686 = env33687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env33686 == env33687) = true)

theorem identity33687 : scanCanonicalize (H12AffineFastState.compose env33687 (packedSelected [1,3,8,15,16,19,20,24,26,31,38] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound33687 : packedSelected [1,3,8,15,16,19,20,24,26,31,38] rootPS < 2^1333 := by decide +kernel

def env33688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,16384,32768,20759,38209,3172,1025,32769,49369,169,53385,53450,1220,64,2265,50569,17664,35244,54597,33,257,21792,37064,34761]

theorem envBound33688 : H12AffineFastState.Bounded env33688 := by
  intro p hp
  have h : env33688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33687_33688 : H12AffineEnvironment.transform 15 20759 env33687 = env33688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env33687 == env33688) = true)

theorem identity33688 : scanCanonicalize (H12AffineFastState.compose env33688 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound33688 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33689 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,161,16384,32768,20759,37292,2185,236,32769,49369,169,53385,53450,41,64,2265,49508,16877,35244,53672,33,257,20941,37064,33572]

theorem envBound33689 : H12AffineFastState.Bounded env33689 := by
  intro p hp
  have h : env33689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33688_33689 : H12AffineEnvironment.transform 9 237 env33688 = env33689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env33688 == env33689) = true)

theorem identity33689 : scanCanonicalize (H12AffineFastState.compose env33689 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound33689 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33690 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,161,16384,217,20759,4469,2185,236,216,16384,169,20560,20499,41,64,2265,16829,16877,2421,20849,33,257,20941,4113,1021]

theorem envBound33690 : H12AffineFastState.Bounded env33690 := by
  intro p hp
  have h : env33690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33689_33690 : H12AffineEnvironment.transform 14 217 env33689 = env33690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env33689 == env33690) = true)

theorem identity33690 : scanCanonicalize (H12AffineFastState.compose env33690 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33690 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env33691 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,41,16384,81,20759,4469,2049,100,80,16384,33,20560,20499,41,64,2129,16693,16741,2421,20849,33,257,20805,4113,885]

theorem envBound33691 : H12AffineFastState.Bounded env33691 := by
  intro p hp
  have h : env33691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33690_33691 : H12AffineEnvironment.transform 6 8 env33690 = env33691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33690 == env33691) = true)

theorem identity33691 : scanCanonicalize (H12AffineFastState.compose env33691 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33691 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33692 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,41,16384,1,20759,4389,2049,52,0,16384,33,20480,20499,41,16,2049,16693,16693,2341,20769,33,257,20757,4113,805]

theorem envBound33692 : H12AffineFastState.Bounded env33692 := by
  intro p hp
  have h : env33692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33691_33692 : H12AffineEnvironment.transform 5 16 env33691 = env33692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33691 == env33692) = true)

theorem identity33692 : scanCanonicalize (H12AffineFastState.compose env33692 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound33692 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33693 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,41,4112,1,263,4389,2049,52,0,4112,33,16,3,41,16,2049,4389,4389,2341,305,33,257,261,4113,805]

theorem envBound33693 : H12AffineFastState.Bounded env33693 := by
  intro p hp
  have h : env33693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33692_33693 : H12AffineEnvironment.transform 13 4112 env33692 = env33693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env33692 == env33693) = true)

def env33694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,58517,168,62661,98781,8328,64,97666,57797,17664,130294,61705,32,257,21792,46212,120542]

theorem envBound33694 : H12AffineFastState.Bounded env33694 := by
  intro p hp
  have h : env33694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33685_33694 : H12AffineEnvironment.transform 17 10281 env33685 = env33694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33685 == env33694) = true)

theorem identity33694 : scanCanonicalize (H12AffineFastState.compose env33694 (packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound33694 : packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env33695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,5528,10281,1025,32769,58517,168,62661,29791,8328,64,34816,57797,17664,2420,61705,32,257,21792,46212,9052]

theorem envBound33695 : H12AffineFastState.Bounded env33695 := by
  intro p hp
  have h : env33695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33694_33695 : H12AffineEnvironment.transform 15 62850 env33694 = env33695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env33694 == env33695) = true)

theorem identity33695 : scanCanonicalize (H12AffineFastState.compose env33695 (packedSelected [0,1,3,4,7,8,10,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound33695 : packedSelected [0,1,3,4,7,8,10,22,24] rootPS < 2^1333 := by decide +kernel

def env33696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,54359,5528,2556,1025,32769,50496,168,54544,21898,349,64,34816,49168,17664,2420,53468,32,257,21792,38225,649]

theorem envBound33696 : H12AffineFastState.Bounded env33696 := by
  intro p hp
  have h : env33696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33695_33696 : H12AffineEnvironment.transform 12 469 env33695 = env33696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env33695 == env33696) = true)

theorem identity33696 : scanCanonicalize (H12AffineFastState.compose env33696 (packedSelected [0,1,2,6,7,8,10,12,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33696 : packedSelected [0,1,2,6,7,8,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env33697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,32768,33110,5528,2556,1025,32769,36929,168,32785,139,349,64,34816,38161,4097,2420,34269,32,257,33,38225,649]

theorem envBound33697 : H12AffineFastState.Bounded env33697 := by
  intro p hp
  have h : env33697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33696_33697 : H12AffineEnvironment.transform 13 5377 env33696 = env33697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33696 == env33697) = true)

theorem identity33697 : scanCanonicalize (H12AffineFastState.compose env33697 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33697 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33110,5393,2421,1025,32769,36929,33,32785,2,349,64,34816,38161,4097,2420,34132,32,257,33,38225,512]

theorem envBound33698 : H12AffineFastState.Bounded env33698 := by
  intro p hp
  have h : env33698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33697_33698 : H12AffineEnvironment.transform 6 9 env33697 = env33698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33697 == env33698) = true)

theorem identity33698 : scanCanonicalize (H12AffineFastState.compose env33698 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound33698 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33699 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,33,375,5393,2421,1025,32,4192,33,48,2,349,64,2081,5424,4097,2420,1397,32,257,33,5488,512]

theorem envBound33699 : H12AffineFastState.Bounded env33699 := by
  intro p hp
  have h : env33699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33698_33699 : H12AffineEnvironment.transform 14 33 env33698 = env33699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env33698 == env33699) = true)

def env33700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6664598,2098513,17665,2437195,2102684,6349852,257,21792,46212,2175563]

theorem envBound33700 : H12AffineFastState.Bounded env33700 := by
  intro p hp
  have h : env33700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33653_33700 : H12AffineEnvironment.transform 22 2101329 env33653 = env33700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env33653 == env33700) = true)

def env33701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2201878,2098513,17665,2437195,2102684,2411676,257,21792,46212,2175563]

theorem envBound33701 : H12AffineFastState.Bounded env33701 := by
  intro p hp
  have h : env33701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33700_33701 : H12AffineEnvironment.transform 21 272512 env33700 = env33701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33700 == env33701) = true)

def env33702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272392,2101329,98644,8192,64,2201878,2098513,17665,2437195,2102548,2411540,257,21792,46092,2175563]

theorem envBound33702 : H12AffineFastState.Bounded env33702 := by
  intro p hp
  have h : env33702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33701_33702 : H12AffineEnvironment.transform 6 8 env33701 = env33702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33701 == env33702) = true)

def env33703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,272392,17,98644,8192,64,100694,5393,17665,335883,1364,318548,257,21792,46092,74251]

theorem envBound33703 : H12AffineFastState.Bounded env33703 := by
  intro p hp
  have h : env33703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33702_33703 : H12AffineEnvironment.transform 20 4160 env33702 = env33703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33702 == env33703) = true)

theorem identity33703 : scanCanonicalize (H12AffineFastState.compose env33703 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound33703 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,4160,33,17,98644,8192,64,100694,5393,17665,67618,1364,62589,257,21792,46092,74251]

theorem envBound33704 : H12AffineFastState.Bounded env33704 := by
  intro p hp
  have h : env33704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33703_33704 : H12AffineEnvironment.transform 17 10281 env33703 = env33704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33703 == env33704) = true)

theorem identity33704 : scanCanonicalize (H12AffineFastState.compose env33704 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound33704 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env33705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,90138,10281,1025,1,4160,33,17,65876,8192,64,67926,5393,17665,67618,1364,29821,257,21792,13324,74251]

theorem envBound33705 : H12AffineFastState.Bounded env33705 := by
  intro p hp
  have h : env33705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33704_33705 : H12AffineEnvironment.transform 14 0 env33704 = env33705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env33704 == env33705) = true)

theorem identity33705 : scanCanonicalize (H12AffineFastState.compose env33705 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33705 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,16400,10281,1025,1,4160,33,17,8542,8192,64,10588,5393,17665,10280,1364,29821,257,21792,13324,513]

theorem envBound33706 : H12AffineFastState.Bounded env33706 := by
  intro p hp
  have h : env33706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33705_33706 : H12AffineEnvironment.transform 15 8202 env33705 = env33706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33705 == env33706) = true)

theorem identity33706 : scanCanonicalize (H12AffineFastState.compose env33706 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33706 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,343,16400,2420,1025,1,4160,33,17,3,349,64,2049,5393,17665,2421,1364,21792,257,21792,5457,513]

theorem envBound33707 : H12AffineFastState.Bounded env33707 := by
  intro p hp
  have h : env33707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33706_33707 : H12AffineEnvironment.transform 12 349 env33706 = env33707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33706 == env33707) = true)

theorem identity33707 : scanCanonicalize (H12AffineFastState.compose env33707 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound33707 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,0,343,4096,2420,1025,1,4160,33,17,3,349,64,2049,5393,5393,2421,1364,1328,257,1328,5457,513]

theorem envBound33708 : H12AffineFastState.Bounded env33708 := by
  intro p hp
  have h : env33708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33707_33708 : H12AffineEnvironment.transform 13 4112 env33707 = env33708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env33707 == env33708) = true)

theorem identity33708 : scanCanonicalize (H12AffineFastState.compose env33708 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound33708 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env33709 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8,4112,0,2,4096,2081,1025,1,4160,33,17,3,8,64,2049,5188,5188,2080,1025,1125,84,1125,5124,513]

theorem envBound33709 : H12AffineFastState.Bounded env33709 := by
  intro p hp
  have h : env33709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33708_33709 : H12AffineEnvironment.transform 7 85 env33708 = env33709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env33708 == env33709) = true)

theorem identity33709 : scanCanonicalize (H12AffineFastState.compose env33709 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33709 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env33710 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8,4112,0,2,4096,2081,1025,1,4113,33,17,3,8,17,2049,5141,5141,2080,1025,1076,5,1076,5124,513]

theorem envBound33710 : H12AffineFastState.Bounded env33710 := by
  intro p hp
  have h : env33710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33709_33710 : H12AffineEnvironment.transform 5 17 env33709 = env33710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33709 == env33710) = true)

theorem identity33710 : scanCanonicalize (H12AffineFastState.compose env33710 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound33710 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33711 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,1061,8,1077,0,2,1061,2081,1025,1,1076,33,17,3,8,17,2049,48,48,2080,1025,1076,5,1076,33,513]

theorem envBound33711 : H12AffineFastState.Bounded env33711 := by
  intro p hp
  have h : env33711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33710_33711 : H12AffineEnvironment.transform 11 1061 env33710 = env33711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env33710 == env33711) = true)

theorem identity33711 : scanCanonicalize (H12AffineFastState.compose env33711 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound33711 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env33712 : List Nat := [2,4,8,16,32,17,8,4,512,1024,545,1061,8,1077,0,2,1061,512,1025,1,1076,33,17,3,8,17,544,48,48,513,1025,1076,5,1076,33,513]

theorem envBound33712 : H12AffineFastState.Bounded env33712 := by
  intro p hp
  have h : env33712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33711_33712 : H12AffineEnvironment.transform 10 545 env33711 = env33712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env33711 == env33712) = true)

theorem identity33712 : scanCanonicalize (H12AffineFastState.compose env33712 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound33712 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33713 : List Nat := [2,4,8,16,32,17,8,4,512,565,545,528,8,512,0,2,528,512,564,1,513,33,17,3,8,17,544,48,48,513,564,513,5,513,33,513]

theorem envBound33713 : H12AffineFastState.Bounded env33713 := by
  intro p hp
  have h : env33713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33712_33713 : H12AffineEnvironment.transform 9 565 env33712 = env33713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env33712 == env33713) = true)

theorem identity33713 : scanCanonicalize (H12AffineFastState.compose env33713 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound33713 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33714 : List Nat := [2,4,8,16,16,17,8,4,512,517,529,528,8,512,0,2,528,512,516,1,513,17,17,3,8,17,528,0,0,513,516,513,5,513,17,513]

theorem envBound33714 : H12AffineFastState.Bounded env33714 := by
  intro p hp
  have h : env33714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33713_33714 : H12AffineEnvironment.transform 4 16 env33713 = env33714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env33713 == env33714) = true)

theorem identity33714 : scanCanonicalize (H12AffineFastState.compose env33714 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound33714 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33715 : List Nat := [2,4,8,16,16,17,8,4,17,20,0,1,8,17,0,2,1,17,21,1,16,17,17,3,8,17,1,0,0,16,21,16,5,16,17,16]

theorem envBound33715 : H12AffineFastState.Bounded env33715 := by
  intro p hp
  have h : env33715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33714_33715 : H12AffineEnvironment.transform 8 17 env33714 = env33715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env33714 == env33715) = true)

def env33716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,272392,16,98644,8192,64,100695,5392,17665,335882,1365,318549,257,21792,46092,74250]

theorem envBound33716 : H12AffineFastState.Bounded env33716 := by
  intro p hp
  have h : env33716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33702_33716 : H12AffineEnvironment.transform 20 4161 env33702 = env33716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33702 == env33716) = true)

theorem identity33716 : scanCanonicalize (H12AffineFastState.compose env33716 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 130095) := by decide +kernel

theorem selectedBound33716 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,130095,1025,32769,4161,119847,16,98644,8192,64,100695,5392,17665,56357,1365,73850,257,21792,46092,74250]

theorem envBound33717 : H12AffineFastState.Bounded env33717 := by
  intro p hp
  have h : env33717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33716_33717 : H12AffineEnvironment.transform 17 130095 env33716 = env33717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130095 env33716 == env33717) = true)

theorem identity33717 : scanCanonicalize (H12AffineFastState.compose env33717 (packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound33717 : packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,65536,103446,100387,1025,32769,4161,106539,16,98644,8192,64,100695,5392,12557,43049,1365,73850,257,8492,46092,74250]

theorem envBound33718 : H12AffineFastState.Bounded env33718 := by
  intro p hp
  have h : env33718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33717_33718 : H12AffineEnvironment.transform 13 13324 env33717 = env33718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env33717 == env33718) = true)

theorem identity33718 : scanCanonicalize (H12AffineFastState.compose env33718 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33718 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env33719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,8203,46109,43048,1025,32769,4161,32800,16,41311,8192,64,43356,5392,12557,43049,1365,113,257,8492,46092,513]

theorem envBound33719 : H12AffineFastState.Bounded env33719 := by
  intro p hp
  have h : env33719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33718_33719 : H12AffineEnvironment.transform 15 8203 env33718 = env33719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33718 == env33719) = true)

theorem identity33719 : scanCanonicalize (H12AffineFastState.compose env33719 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33719 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,32768,342,38208,35189,1025,32769,4161,32800,16,32770,349,64,34817,5392,4176,35188,1365,113,257,113,38225,513]

theorem envBound33720 : H12AffineFastState.Bounded env33720 := by
  intro p hp
  have h : env33720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33719_33720 : H12AffineEnvironment.transform 12 349 env33719 = env33720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33719 == env33720) = true)

theorem identity33720 : scanCanonicalize (H12AffineFastState.compose env33720 (packedSelected [0,2,3,4,5,7,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 3124) := by decide +kernel

theorem selectedBound33720 : packedSelected [0,2,3,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env33721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,3124,342,6516,1345,1025,3125,4161,3092,16,3126,349,64,1077,5392,4176,1344,1365,113,257,113,6501,513]

theorem envBound33721 : H12AffineFastState.Bounded env33721 := by
  intro p hp
  have h : env33721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33720_33721 : H12AffineEnvironment.transform 14 3124 env33720 = env33721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3124 env33720 == env33721) = true)

theorem identity33721 : scanCanonicalize (H12AffineFastState.compose env33721 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound33721 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env33722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,349,5457,293,342,5221,1345,1025,292,4161,261,16,295,349,64,1077,5392,4176,1344,1365,113,257,113,5236,513]

theorem envBound33722 : H12AffineFastState.Bounded env33722 := by
  intro p hp
  have h : env33722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33721_33722 : H12AffineEnvironment.transform 10 1297 env33721 = env33722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env33721 == env33722) = true)

theorem identity33722 : scanCanonicalize (H12AffineFastState.compose env33722 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33722 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33723 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1125,4096,41,5157,81,34,5221,1077,1025,80,4161,113,16,83,41,64,1077,5220,4176,1076,1057,113,117,113,5236,513]

theorem envBound33723 : H12AffineFastState.Bounded env33723 := by
  intro p hp
  have h : env33723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33722_33723 : H12AffineEnvironment.transform 7 116 env33722 = env33723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33722 == env33723) = true)

theorem identity33723 : scanCanonicalize (H12AffineFastState.compose env33723 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33723 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33724 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,4096,41,5157,0,34,5172,1077,1025,1,4112,32,16,2,41,17,1077,5173,4097,1076,1057,32,36,32,5157,513]

theorem envBound33724 : H12AffineFastState.Bounded env33724 := by
  intro p hp
  have h : env33724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33723_33724 : H12AffineEnvironment.transform 5 17 env33723 = env33724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33723 == env33724) = true)

def env33725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272393,2101329,98645,8193,64,2201878,2098513,17665,2437195,2102549,2411541,257,21792,46093,2175563]

theorem envBound33725 : H12AffineFastState.Bounded env33725 := by
  intro p hp
  have h : env33725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33701_33725 : H12AffineEnvironment.transform 6 9 env33701 = env33725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33701 == env33725) = true)

theorem identity33725 : scanCanonicalize (H12AffineFastState.compose env33725 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 36929) := by decide +kernel

theorem selectedBound33725 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env33726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,36929,272393,32784,98645,8193,64,67927,38160,17665,368650,34132,285780,257,21792,46093,107018]

theorem envBound33726 : H12AffineFastState.Bounded env33726 := by
  intro p hp
  have h : env33726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33725_33726 : H12AffineEnvironment.transform 20 36929 env33725 = env33726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36929 env33725 == env33726) = true)

theorem identity33726 : scanCanonicalize (H12AffineFastState.compose env33726 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound33726 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57676,262144,1025,32769,36929,272393,32784,32771,8193,64,2049,38160,17665,303452,34132,285780,257,21792,46093,41820]

theorem envBound33727 : H12AffineFastState.Bounded env33727 := by
  intro p hp
  have h : env33727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33726_33727 : H12AffineEnvironment.transform 15 342 env33726 = env33727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env33726 == env33727) = true)

theorem identity33727 : scanCanonicalize (H12AffineFastState.compose env33727 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound33727 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env33728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57676,43048,1025,32769,36929,32801,32784,32771,8193,64,2049,38160,17665,2420,34132,62588,257,21792,46093,41820]

theorem envBound33728 : H12AffineFastState.Bounded env33728 := by
  intro p hp
  have h : env33728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33727_33728 : H12AffineEnvironment.transform 17 43048 env33727 = env33728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env33727 == env33728) = true)

theorem identity33728 : scanCanonicalize (H12AffineFastState.compose env33728 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33728 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,342,49169,35189,1025,32769,36929,32801,32784,32771,348,64,2049,38160,17665,2420,34132,54561,257,21792,38224,33281]

theorem envBound33729 : H12AffineFastState.Bounded env33729 := by
  intro p hp
  have h : env33729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33728_33729 : H12AffineEnvironment.transform 12 349 env33728 = env33729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33728 == env33729) = true)

theorem identity33729 : scanCanonicalize (H12AffineFastState.compose env33729 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound33729 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,292,342,16693,2129,1025,293,4453,261,308,295,348,64,2049,5172,17665,2420,1136,21509,257,21792,5236,805]

theorem envBound33730 : H12AffineFastState.Bounded env33730 := by
  intro p hp
  have h : env33730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33729_33730 : H12AffineEnvironment.transform 14 292 env33729 = env33730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env33729 == env33730) = true)

theorem identity33730 : scanCanonicalize (H12AffineFastState.compose env33730 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33730 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env33731 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,16384,0,114,16401,2129,1025,1,4161,33,16,3,120,64,2049,5172,17445,2128,1136,21509,37,21508,5236,513]

theorem envBound33731 : H12AffineFastState.Bounded env33731 := by
  intro p hp
  have h : env33731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33730_33731 : H12AffineEnvironment.transform 7 36 env33730 = env33731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33730 == env33731) = true)

theorem identity33731 : scanCanonicalize (H12AffineFastState.compose env33731 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound33731 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33732 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5236,0,114,5221,2129,1025,1,4161,33,16,3,120,64,2049,5172,4177,2128,1136,113,37,112,5236,513]

theorem envBound33732 : H12AffineFastState.Bounded env33732 := by
  intro p hp
  have h : env33732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33731_33732 : H12AffineEnvironment.transform 13 5236 env33731 = env33732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env33731 == env33732) = true)

theorem identity33732 : scanCanonicalize (H12AffineFastState.compose env33732 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33733 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,0,34,5173,2049,1025,1,4113,33,16,3,40,16,2049,5172,4097,2048,1056,33,37,32,5156,513]

theorem envBound33733 : H12AffineFastState.Bounded env33733 := by
  intro p hp
  have h : env33733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33732_33733 : H12AffineEnvironment.transform 5 16 env33732 = env33733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33732 == env33733) = true)

theorem identity33733 : scanCanonicalize (H12AffineFastState.compose env33733 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound33733 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33734 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,4096,41,5156,0,34,5173,1076,1025,1,4113,33,16,3,40,16,1076,5172,4097,1077,1056,33,37,32,5156,513]

theorem envBound33734 : H12AffineFastState.Bounded env33734 := by
  intro p hp
  have h : env33734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33733_33734 : H12AffineEnvironment.transform 10 1077 env33733 = env33734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env33733 == env33734) = true)

theorem identity33734 : scanCanonicalize (H12AffineFastState.compose env33734 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound33734 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33735 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,1061,41,1,0,34,16,1076,1025,1,1076,33,16,3,40,16,1076,17,1060,1077,1056,33,37,32,1,513]

theorem envBound33735 : H12AffineFastState.Bounded env33735 := by
  intro p hp
  have h : env33735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33734_33735 : H12AffineEnvironment.transform 11 1061 env33734 = env33735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env33734 == env33735) = true)

theorem identity33735 : scanCanonicalize (H12AffineFastState.compose env33735 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33735 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33736 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,16,41,1,0,34,16,1,52,1,1,33,16,3,40,16,1,17,17,0,21,33,37,32,1,513]

theorem envBound33736 : H12AffineFastState.Bounded env33736 := by
  intro p hp
  have h : env33736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33735_33736 : H12AffineEnvironment.transform 9 53 env33735 = env33736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33735 == env33736) = true)

theorem identity33736 : scanCanonicalize (H12AffineFastState.compose env33736 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound33736 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33737 : List Nat := [2,4,8,16,32,16,9,36,16,53,0,16,41,1,0,34,16,1,52,1,1,33,16,3,40,16,1,17,17,0,21,33,37,32,1,17]

theorem envBound33737 : H12AffineFastState.Bounded env33737 := by
  intro p hp
  have h : env33737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33736_33737 : H12AffineEnvironment.transform 8 16 env33736 = env33737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env33736 == env33737) = true)

theorem identity33737 : scanCanonicalize (H12AffineFastState.compose env33737 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound33737 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33738 : List Nat := [2,4,8,16,27,16,9,31,16,14,0,16,18,1,0,25,16,1,15,1,1,26,16,3,19,16,1,17,17,0,21,26,30,27,1,17]

theorem envBound33738 : H12AffineFastState.Bounded env33738 := by
  intro p hp
  have h : env33738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33737_33738 : H12AffineEnvironment.transform 4 27 env33737 = env33738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env33737 == env33738) = true)

def env33739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2201879,2098513,17665,2437195,2102684,2411677,257,21792,46212,2175563]

theorem envBound33739 : H12AffineFastState.Bounded env33739 := by
  intro p hp
  have h : env33739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33700_33739 : H12AffineEnvironment.transform 21 272513 env33700 = env33739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env33700 == env33739) = true)

theorem identity33739 : scanCanonicalize (H12AffineFastState.compose env33739 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound33739 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,272513,17,98780,8328,64,100695,5393,17665,335883,1500,318685,257,21792,46212,74251]

theorem envBound33740 : H12AffineFastState.Bounded env33740 := by
  intro p hp
  have h : env33740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33739_33740 : H12AffineEnvironment.transform 20 4160 env33739 = env33740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33739 == env33740) = true)

theorem identity33740 : scanCanonicalize (H12AffineFastState.compose env33740 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33740 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env33741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4160,272513,17,41430,8328,64,43357,5393,17665,262145,1500,318685,257,21792,46212,513]

theorem envBound33741 : H12AffineFastState.Bounded env33741 := by
  intro p hp
  have h : env33741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33740_33741 : H12AffineEnvironment.transform 15 8202 env33740 = env33741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33740 == env33741) = true)

theorem identity33741 : scanCanonicalize (H12AffineFastState.compose env33741 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound33741 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env33742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10400,1025,32769,4160,33,17,41430,8328,64,43357,5393,17665,10401,1500,62589,257,21792,46212,513]

theorem envBound33742 : H12AffineFastState.Bounded env33742 := by
  intro p hp
  have h : env33742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33741_33742 : H12AffineEnvironment.transform 17 10400 env33741 = env33742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33741 == env33742) = true)

theorem identity33742 : scanCanonicalize (H12AffineFastState.compose env33742 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound33742 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env33743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16400,10400,1025,1,4160,33,17,8662,8328,64,10589,5393,17665,10401,1500,29821,257,21792,13444,513]

theorem envBound33743 : H12AffineFastState.Bounded env33743 := by
  intro p hp
  have h : env33743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33742_33743 : H12AffineEnvironment.transform 14 0 env33742 = env33743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env33742 == env33743) = true)

theorem identity33743 : scanCanonicalize (H12AffineFastState.compose env33743 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound33743 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env33744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,16384,0,1230,16400,3172,1025,1,4160,33,17,1298,1100,64,3481,5393,17665,3173,1500,20665,257,21792,4160,513]

theorem envBound33744 : H12AffineFastState.Bounded env33744 := by
  intro p hp
  have h : env33744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33743_33744 : H12AffineEnvironment.transform 12 1220 env33743 = env33744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env33743 == env33744) = true)

theorem identity33744 : scanCanonicalize (H12AffineFastState.compose env33744 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound33744 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env33745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,1212,0,1230,1196,3172,1025,1,4160,33,17,1298,1100,64,3481,5393,445,3173,1500,5125,257,4508,4160,513]

theorem envBound33745 : H12AffineFastState.Bounded env33745 := by
  intro p hp
  have h : env33745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33744_33745 : H12AffineEnvironment.transform 13 1212 env33744 = env33745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env33744 == env33745) = true)

theorem identity33745 : scanCanonicalize (H12AffineFastState.compose env33745 (packedSelected [0,1,3,4,5,8,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound33745 : packedSelected [0,1,3,4,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env33746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,64,1220,1212,0,1230,1196,3172,1025,1,0,33,17,1298,1100,64,3481,1361,445,3173,1500,1093,257,476,0,513]

theorem envBound33746 : H12AffineFastState.Bounded env33746 := by
  intro p hp
  have h : env33746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33745_33746 : H12AffineEnvironment.transform 11 64 env33745 = env33746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env33745 == env33746) = true)

theorem identity33746 : scanCanonicalize (H12AffineFastState.compose env33746 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound33746 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env33747 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,64,388,508,0,398,492,2340,321,1,0,33,17,82,268,64,2265,17,445,2341,156,261,257,476,0,513]

theorem envBound33747 : H12AffineFastState.Bounded env33747 := by
  intro p hp
  have h : env33747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33746_33747 : H12AffineEnvironment.transform 9 320 env33746 = env33747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33746 == env33747) = true)

theorem identity33747 : scanCanonicalize (H12AffineFastState.compose env33747 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound33747 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env33748 : List Nat := [2,4,8,16,32,64,128,256,512,320,81,64,388,508,0,398,492,373,321,1,0,33,17,82,268,64,136,17,445,372,156,261,257,476,0,513]

theorem envBound33748 : H12AffineFastState.Bounded env33748 := by
  intro p hp
  have h : env33748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33747_33748 : H12AffineEnvironment.transform 10 81 env33747 = env33748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env33747 == env33748) = true)

def env33749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356288,25265169,23160257,525568,27902125,27337993,25733063]

end H12CloudChart0