import H12CloudChart0Data162

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound41318 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41319 : List Nat := [2,4,4,16,0,17,5,256,0,20,6,261,256,16,0,262,0,259,21,1,276,1,17,2,257,17,6,0,260,259,272,0,257,0,17,1]

theorem envBound41319 : H12AffineFastState.Bounded env41319 := by
  intro p hp
  have h : env41319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41318_41319 : H12AffineEnvironment.transform 2 4 env41318 = env41319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41318 == env41319) = true)

def env41320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356289,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound41320 : H12AffineFastState.Bounded env41320 := by
  intro p hp
  have h : env41320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41013_41320 : H12AffineEnvironment.transform 26 30393345 env41013 = env41320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env41013 == env41320) = true)

def env41321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound41321 : H12AffineFastState.Bounded env41321 := by
  intro p hp
  have h : env41321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41320_41321 : H12AffineEnvironment.transform 18 1024 env41320 = env41321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env41320 == env41321) = true)

theorem identity41321 : scanCanonicalize (H12AffineFastState.compose env41321 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2213006) := by decide +kernel

theorem selectedBound41321 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2213006,16777216,8328,64,23463055,18973836,102879,2557071,18890911,23160256,256,16777250,16834950,18966345]

theorem envBound41322 : H12AffineFastState.Bounded env41322 := by
  intro p hp
  have h : env41322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41321_41322 : H12AffineEnvironment.transform 22 2213006 env41321 = env41322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2213006 env41321 == env41322) = true)

def env41323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2411540,2213006,16777216,8328,64,16959643,18973836,102879,2557071,18890911,17148372,256,16777250,16834950,18966345]

theorem envBound41323 : H12AffineFastState.Bounded env41323 := by
  intro p hp
  have h : env41323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41322_41323 : H12AffineEnvironment.transform 21 2411540 env41322 = env41323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2411540 env41322 == env41323) = true)

theorem identity41323 : scanCanonicalize (H12AffineFastState.compose env41323 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound41323 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env41324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,329866,16,16777216,8328,64,16959643,16793618,102879,442385,16876545,17148372,256,16777250,16834950,16819159]

theorem envBound41324 : H12AffineFastState.Bounded env41324 := by
  intro p hp
  have h : env41324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41323_41324 : H12AffineEnvironment.transform 20 115870 env41323 = env41324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env41323 == env41324) = true)

def env41325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,329866,16,95496,8328,64,245139,79130,102879,442385,61705,318684,256,95530,103566,120543]

theorem envBound41325 : H12AffineFastState.Bounded env41325 := by
  intro p hp
  have h : env41325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41324_41325 : H12AffineEnvironment.transform 23 95496 env41324 = env41325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env41324 == env41325) = true)

def env41326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,329730,16,95496,8192,64,245019,79130,102743,442385,61705,318548,256,95530,103430,120407]

theorem envBound41326 : H12AffineFastState.Bounded env41326 := by
  intro p hp
  have h : env41326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41325_41326 : H12AffineEnvironment.transform 6 8 env41325 = env41326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41325 == env41326) = true)

theorem identity41326 : scanCanonicalize (H12AffineFastState.compose env41326 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41326 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,91466,329730,16,95496,8192,64,203847,79130,77835,418125,20565,294152,256,95530,79194,96011]

theorem envBound41327 : H12AffineFastState.Bounded env41327 := by
  intro p hp
  have h : env41327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41326_41327 : H12AffineEnvironment.transform 14 8540 env41326 = env41327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41326 == env41327) = true)

def env41328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,262144,1024,8541,91466,329730,16,95496,8192,64,89175,79130,77835,270685,20565,294152,256,95530,79194,96011]

theorem envBound41328 : H12AffineFastState.Bounded env41328 := by
  intro p hp
  have h : env41328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41327_41328 : H12AffineEnvironment.transform 16 16400 env41327 = env41328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41327 == env41328) = true)

theorem identity41328 : scanCanonicalize (H12AffineFastState.compose env41328 (packedSelected [0,1,7,8,9,12,14,16,19,22,38] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound41328 : packedSelected [0,1,7,8,9,12,14,16,19,22,38] rootPS < 2^1333 := by decide +kernel

def env41329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29822,16400,262144,1024,8541,4404,294012,16,374,8192,64,10281,16740,17525,270685,20565,294152,256,340,16676,885]

theorem envBound41329 : H12AffineFastState.Bounded env41329 := by
  intro p hp
  have h : env41329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41328_41329 : H12AffineEnvironment.transform 15 29822 env41328 = env41329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env41328 == env41329) = true)

theorem identity41329 : scanCanonicalize (H12AffineFastState.compose env41329 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41329 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env41330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8575,5393,262144,1024,8541,4404,272765,16,374,8192,64,10281,5221,4468,270685,1364,272393,256,340,5157,885]

theorem envBound41330 : H12AffineFastState.Bounded env41330 := by
  intro p hp
  have h : env41330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41329_41330 : H12AffineEnvironment.transform 13 5377 env41329 = env41330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41329 == env41330) = true)

theorem identity41330 : scanCanonicalize (H12AffineFastState.compose env41330 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41330 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env41331 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5237,8232,8203,5221,262144,1024,8233,4160,272393,16,2,8192,64,10281,5221,4096,270377,1056,272393,116,32,5157,513]

theorem envBound41331 : H12AffineFastState.Bounded env41331 := by
  intro p hp
  have h : env41331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41330_41331 : H12AffineEnvironment.transform 7 116 env41330 = env41331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41330 == env41331) = true)

theorem identity41331 : scanCanonicalize (H12AffineFastState.compose env41331 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41331 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41332 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5237,8232,8203,5221,10280,1024,8233,4160,33,16,2,8192,64,10281,5221,4096,2049,1056,33,116,32,5157,513]

theorem envBound41332 : H12AffineFastState.Bounded env41332 := by
  intro p hp
  have h : env41332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41331_41332 : H12AffineEnvironment.transform 17 10280 env41331 = env41332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41331 == env41332) = true)

theorem identity41332 : scanCanonicalize (H12AffineFastState.compose env41332 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound41332 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41333 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1,8192,1140,8232,8203,1124,10280,1024,8233,65,33,16,2,8192,64,10281,1124,1,2049,1056,33,116,32,1060,513]

theorem envBound41333 : H12AffineFastState.Bounded env41333 := by
  intro p hp
  have h : env41333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41332_41333 : H12AffineEnvironment.transform 11 1 env41332 = env41333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env41332 == env41333) = true)

theorem identity41333 : scanCanonicalize (H12AffineFastState.compose env41333 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2680) := by decide +kernel

theorem selectedBound41333 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41334 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1,2680,1140,2640,2675,1124,592,1024,2641,65,33,16,2,2680,64,593,1124,1,2049,1056,33,116,32,1060,513]

theorem envBound41334 : H12AffineFastState.Bounded env41334 := by
  intro p hp
  have h : env41334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41333_41334 : H12AffineEnvironment.transform 12 2680 env41333 = env41334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2680 env41333 == env41334) = true)

theorem identity41334 : scanCanonicalize (H12AffineFastState.compose env41334 (packedSelected [2,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound41334 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env41335 : List Nat := [2,4,8,16,32,64,8,116,512,1024,592,1,40,1140,0,35,1124,592,1024,1,65,33,16,2,40,64,593,1124,1,593,1056,33,116,32,1060,513]

theorem envBound41335 : H12AffineFastState.Bounded env41335 := by
  intro p hp
  have h : env41335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41334_41335 : H12AffineEnvironment.transform 10 592 env41334 = env41335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env41334 == env41335) = true)

theorem identity41335 : scanCanonicalize (H12AffineFastState.compose env41335 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound41335 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41336 : List Nat := [2,4,8,16,32,64,8,116,512,565,592,1,40,577,0,35,593,592,565,1,65,33,16,2,40,64,593,593,1,593,533,33,116,32,529,513]

theorem envBound41336 : H12AffineFastState.Bounded env41336 := by
  intro p hp
  have h : env41336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41335_41336 : H12AffineEnvironment.transform 9 565 env41335 = env41336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env41335 == env41336) = true)

theorem identity41336 : scanCanonicalize (H12AffineFastState.compose env41336 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41336 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41337 : List Nat := [2,4,8,16,32,64,8,116,1,52,81,1,40,64,0,35,80,81,52,1,65,33,16,2,40,64,80,80,1,80,20,33,116,32,16,0]

theorem envBound41337 : H12AffineFastState.Bounded env41337 := by
  intro p hp
  have h : env41337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41336_41337 : H12AffineEnvironment.transform 8 1 env41336 = env41337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41336 == env41337) = true)

theorem identity41337 : scanCanonicalize (H12AffineFastState.compose env41337 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41337 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41338 : List Nat := [2,4,8,1,32,64,8,101,1,37,64,1,40,64,0,35,65,64,37,1,65,33,1,2,40,64,65,65,1,65,5,33,101,32,1,0]

theorem envBound41338 : H12AffineFastState.Bounded env41338 := by
  intro p hp
  have h : env41338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41337_41338 : H12AffineEnvironment.transform 3 1 env41337 = env41338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41337 == env41338) = true)

theorem identity41338 : scanCanonicalize (H12AffineFastState.compose env41338 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound41338 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41339 : List Nat := [2,4,8,1,32,0,8,37,1,37,0,1,40,0,0,35,1,0,37,1,1,33,1,2,40,0,1,1,1,1,5,33,37,32,1,0]

theorem envBound41339 : H12AffineFastState.Bounded env41339 := by
  intro p hp
  have h : env41339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41338_41339 : H12AffineEnvironment.transform 5 0 env41338 = env41339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41338 == env41339) = true)

theorem identity41339 : scanCanonicalize (H12AffineFastState.compose env41339 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41340 : List Nat := [2,4,8,1,0,0,8,5,1,5,0,1,8,0,0,3,1,0,5,1,1,1,1,2,8,0,1,1,1,1,5,1,5,0,1,0]

theorem envBound41340 : H12AffineFastState.Bounded env41340 := by
  intro p hp
  have h : env41340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41339_41340 : H12AffineEnvironment.transform 4 0 env41339 = env41340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41339 == env41340) = true)

def env41341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,262144,1024,8541,91466,329730,16,95496,8192,64,89174,79130,77835,270684,20565,294152,256,95530,79194,96011]

theorem envBound41341 : H12AffineFastState.Bounded env41341 := by
  intro p hp
  have h : env41341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41327_41341 : H12AffineEnvironment.transform 16 16401 env41327 = env41341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41327 == env41341) = true)

theorem identity41341 : scanCanonicalize (H12AffineFastState.compose env41341 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound41341 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env41342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,16401,262144,1024,8541,4160,294152,16,2,8192,64,10588,16400,17665,270684,20565,294152,256,32,16464,513]

theorem envBound41342 : H12AffineFastState.Bounded env41342 := by
  intro p hp
  have h : env41342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41341_41342 : H12AffineEnvironment.transform 15 29962 env41341 = env41342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env41341 == env41342) = true)

theorem identity41342 : scanCanonicalize (H12AffineFastState.compose env41342 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 22885) := by decide +kernel

theorem selectedBound41342 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,16401,22885,1024,8541,4160,9325,16,2,8192,64,10588,16400,17665,30777,20565,9325,256,32,16464,513]

theorem envBound41343 : H12AffineFastState.Bounded env41343 := by
  intro p hp
  have h : env41343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41342_41343 : H12AffineEnvironment.transform 17 22885 env41342 = env41343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22885 env41342 == env41343) = true)

theorem identity41343 : scanCanonicalize (H12AffineFastState.compose env41343 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41343 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41344 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8540,28699,16401,22885,273,8541,4160,8572,16,2,8192,64,10588,16400,16400,30777,20565,8572,256,32,16464,513]

theorem envBound41344 : H12AffineFastState.Bounded env41344 := by
  intro p hp
  have h : env41344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41343_41344 : H12AffineEnvironment.transform 9 273 env41343 = env41344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41343 == env41344) = true)

theorem identity41344 : scanCanonicalize (H12AffineFastState.compose env41344 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound41344 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env41345 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8540,8202,4096,2420,273,8541,4160,8572,16,2,8192,64,10588,4097,4097,10280,68,8572,256,32,4161,513]

theorem envBound41345 : H12AffineFastState.Bounded env41345 := by
  intro p hp
  have h : env41345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41344_41345 : H12AffineEnvironment.transform 13 4113 env41344 = env41345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env41344 == env41345) = true)

theorem identity41345 : scanCanonicalize (H12AffineFastState.compose env41345 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41345 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41346 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4113,80,262,4096,2420,273,81,4160,112,16,2,268,64,2128,4097,4097,2340,68,112,256,32,4161,513]

theorem envBound41346 : H12AffineFastState.Bounded env41346 := by
  intro p hp
  have h : env41346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41345_41346 : H12AffineEnvironment.transform 12 268 env41345 = env41346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41345 == env41346) = true)

theorem identity41346 : scanCanonicalize (H12AffineFastState.compose env41346 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41346 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41347 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,120,4113,80,114,4096,2048,101,81,4160,112,16,2,120,64,2128,4097,4097,2128,68,112,116,32,4161,513]

theorem envBound41347 : H12AffineFastState.Bounded env41347 := by
  intro p hp
  have h : env41347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41346_41347 : H12AffineEnvironment.transform 7 116 env41346 = env41347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41346 == env41347) = true)

theorem identity41347 : scanCanonicalize (H12AffineFastState.compose env41347 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41347 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env41348 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,40,4113,0,34,4096,2048,53,1,4112,32,16,2,40,16,2048,4097,4097,2048,20,32,36,32,4113,513]

theorem envBound41348 : H12AffineFastState.Bounded env41348 := by
  intro p hp
  have h : env41348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41347_41348 : H12AffineEnvironment.transform 5 16 env41347 = env41348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41347 == env41348) = true)

theorem identity41348 : scanCanonicalize (H12AffineFastState.compose env41348 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound41348 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41349 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2096,40,2081,0,34,2096,2048,53,1,2080,32,16,2,40,16,2048,2097,2097,2048,20,32,36,32,2081,513]

theorem envBound41349 : H12AffineFastState.Bounded env41349 := by
  intro p hp
  have h : env41349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41348_41349 : H12AffineEnvironment.transform 11 2096 env41348 = env41349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env41348 == env41349) = true)

theorem identity41349 : scanCanonicalize (H12AffineFastState.compose env41349 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound41349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41350 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,2096,40,2081,0,34,2096,2048,53,1,2080,32,16,2,40,16,2048,2097,2097,2048,20,32,36,32,2081,48]

theorem envBound41350 : H12AffineFastState.Bounded env41350 := by
  intro p hp
  have h : env41350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41349_41350 : H12AffineEnvironment.transform 8 49 env41349 = env41350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env41349 == env41350) = true)

def env41351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,329731,16,95496,8193,64,245018,79130,102742,442385,61705,318549,256,95530,103431,120406]

theorem envBound41351 : H12AffineFastState.Bounded env41351 := by
  intro p hp
  have h : env41351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41325_41351 : H12AffineEnvironment.transform 6 9 env41325 = env41351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41325 == env41351) = true)

def env41352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,329731,16,95496,8193,64,130314,79130,102742,294913,61705,318549,256,95530,103431,120406]

theorem envBound41352 : H12AffineFastState.Bounded env41352 := by
  intro p hp
  have h : env41352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41351_41352 : H12AffineEnvironment.transform 16 16400 env41351 = env41352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41351 == env41352) = true)

def env41353 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,329731,16,95356,8193,64,130174,78958,102434,294913,61565,318549,116,95326,103431,120406]

theorem envBound41353 : H12AffineFastState.Bounded env41353 := by
  intro p hp
  have h : env41353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41352_41353 : H12AffineEnvironment.transform 7 116 env41352 = env41353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41352 == env41353) = true)

theorem identity41353 : scanCanonicalize (H12AffineFastState.compose env41353 (packedSelected [0,1,2,3,5,7,8,9,10,11,18,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound41353 : packedSelected [0,1,2,3,5,7,8,9,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env41354 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,54359,16400,262144,1024,32769,4160,318548,16,41003,8193,64,10281,57401,17525,294913,61565,318549,116,40969,16464,513]

theorem envBound41354 : H12AffineFastState.Bounded env41354 := by
  intro p hp
  have h : env41354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41353_41354 : H12AffineEnvironment.transform 15 54359 env41353 = env41354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env41353 == env41354) = true)

theorem identity41354 : scanCanonicalize (H12AffineFastState.compose env41354 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound41354 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env41355 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,54359,16400,43049,1024,32769,4160,29821,16,41003,8193,64,10281,57401,17525,10280,61565,29820,116,40969,16464,513]

theorem envBound41355 : H12AffineFastState.Bounded env41355 := by
  intro p hp
  have h : env41355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41354_41355 : H12AffineEnvironment.transform 17 43049 env41354 = env41355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env41354 == env41355) = true)

theorem identity41355 : scanCanonicalize (H12AffineFastState.compose env41355 (packedSelected [11,18] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound41355 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env41356 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29789,8202,16400,23668,1024,29788,4160,29821,16,21622,8193,64,10281,5220,17525,10280,1056,29820,116,21588,16464,513]

theorem envBound41356 : H12AffineFastState.Bounded env41356 := by
  intro p hp
  have h : env41356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41355_41356 : H12AffineEnvironment.transform 14 29789 env41355 = env41356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env41355 == env41356) = true)

theorem identity41356 : scanCanonicalize (H12AffineFastState.compose env41356 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound41356 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env41357 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,120,16384,21541,114,16400,23668,1024,21540,4160,21509,16,21622,121,64,2129,5220,17525,2128,1056,21508,116,21588,16464,513]

theorem envBound41357 : H12AffineFastState.Bounded env41357 := by
  intro p hp
  have h : env41357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41356_41357 : H12AffineEnvironment.transform 12 120 env41356 = env41357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env41356 == env41357) = true)

theorem identity41357 : scanCanonicalize (H12AffineFastState.compose env41357 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41357 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41358 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,4096,120,16384,20497,114,16400,22592,52,20496,4160,20529,16,20546,121,64,2129,4176,16449,2128,20,20528,116,20576,16464,513]

theorem envBound41358 : H12AffineFastState.Bounded env41358 := by
  intro p hp
  have h : env41358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41357_41358 : H12AffineEnvironment.transform 9 52 env41357 = env41358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41357 == env41358) = true)

theorem identity41358 : scanCanonicalize (H12AffineFastState.compose env41358 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound41358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41359 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,80,120,16384,16449,114,16400,18448,52,16448,16,16481,16,16402,121,64,2129,0,16449,2128,20,16480,116,16432,16464,513]

theorem envBound41359 : H12AffineFastState.Bounded env41359 := by
  intro p hp
  have h : env41359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41358_41359 : H12AffineEnvironment.transform 11 80 env41358 = env41359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env41358 == env41359) = true)

theorem identity41359 : scanCanonicalize (H12AffineFastState.compose env41359 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2075) := by decide +kernel

theorem selectedBound41359 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41360 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,80,120,2075,2138,114,2059,11,52,2139,16,2170,16,2057,121,64,2129,0,2138,2128,20,2171,116,2091,2123,513]

theorem envBound41360 : H12AffineFastState.Bounded env41360 := by
  intro p hp
  have h : env41360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41359_41360 : H12AffineEnvironment.transform 13 2075 env41359 = env41360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2075 env41359 == env41360) = true)

theorem identity41360 : scanCanonicalize (H12AffineFastState.compose env41360 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41360 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41361 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,0,40,2075,2058,34,2059,11,52,2059,16,2090,16,2057,41,16,2049,0,2058,2048,20,2091,36,2091,2075,513]

theorem envBound41361 : H12AffineFastState.Bounded env41361 := by
  intro p hp
  have h : env41361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41360_41361 : H12AffineEnvironment.transform 5 16 env41360 = env41361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41360 == env41361) = true)

theorem identity41361 : scanCanonicalize (H12AffineFastState.compose env41361 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound41361 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env41362 : List Nat := [2,4,8,16,32,16,9,36,512,52,48,0,40,43,58,34,59,11,52,59,16,26,16,57,41,16,49,0,58,48,20,27,36,27,43,513]

theorem envBound41362 : H12AffineFastState.Bounded env41362 := by
  intro p hp
  have h : env41362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41361_41362 : H12AffineEnvironment.transform 10 48 env41361 = env41362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env41361 == env41362) = true)

theorem identity41362 : scanCanonicalize (H12AffineFastState.compose env41362 (packedSelected [0,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41362 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env41363 : List Nat := [2,2,8,16,32,16,9,34,512,50,48,0,40,43,58,34,59,11,50,59,16,26,16,57,41,16,49,0,58,48,18,27,34,27,43,513]

theorem envBound41363 : H12AffineFastState.Bounded env41363 := by
  intro p hp
  have h : env41363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41362_41363 : H12AffineEnvironment.transform 1 2 env41362 = env41363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41362 == env41363) = true)

theorem identity41363 : scanCanonicalize (H12AffineFastState.compose env41363 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound41363 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41364 : List Nat := [2,2,8,16,26,16,9,24,512,8,10,0,18,17,0,24,1,11,8,1,16,26,16,3,19,16,11,0,0,10,18,27,24,27,17,513]

theorem envBound41364 : H12AffineFastState.Bounded env41364 := by
  intro p hp
  have h : env41364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41363_41364 : H12AffineEnvironment.transform 4 26 env41363 = env41364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env41363 == env41364) = true)

theorem identity41364 : scanCanonicalize (H12AffineFastState.compose env41364 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound41364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41365 : List Nat := [2,2,8,16,26,16,9,24,9,8,10,0,18,17,0,24,1,11,8,1,16,26,16,3,19,16,11,0,0,10,18,27,24,27,17,8]

theorem envBound41365 : H12AffineFastState.Bounded env41365 := by
  intro p hp
  have h : env41365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41364_41365 : H12AffineEnvironment.transform 8 9 env41364 = env41365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env41364 == env41365) = true)

theorem identity41365 : scanCanonicalize (H12AffineFastState.compose env41365 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41365 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env41366 : List Nat := [2,2,2,16,16,16,3,18,3,2,0,0,18,17,0,18,1,1,2,1,16,16,16,3,19,16,1,0,0,0,18,17,18,17,17,2]

theorem envBound41366 : H12AffineFastState.Bounded env41366 := by
  intro p hp
  have h : env41366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41365_41366 : H12AffineEnvironment.transform 2 2 env41365 = env41366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41365 == env41366) = true)

theorem identity41366 : scanCanonicalize (H12AffineFastState.compose env41366 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41366 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env41367 : List Nat := [2,2,2,1,1,1,3,3,3,2,0,0,3,0,0,3,1,1,2,1,1,1,1,3,2,1,1,0,0,0,3,0,3,0,0,2]

theorem envBound41367 : H12AffineFastState.Bounded env41367 := by
  intro p hp
  have h : env41367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41366_41367 : H12AffineEnvironment.transform 3 1 env41366 = env41367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41366 == env41367) = true)

def env41368 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,329731,16,95357,8193,64,130175,78959,102435,294913,61564,318549,117,95327,103431,120406]

theorem envBound41368 : H12AffineFastState.Bounded env41368 := by
  intro p hp
  have h : env41368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41352_41368 : H12AffineEnvironment.transform 7 117 env41352 = env41368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41352 == env41368) = true)

theorem identity41368 : scanCanonicalize (H12AffineFastState.compose env41368 (packedSelected [0,1,2,3,5,7,8,9,10,11,18,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 31836) := by decide +kernel

theorem selectedBound41368 : packedSelected [0,1,2,3,5,7,8,9,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env41369 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16400,31836,1024,32769,115735,95327,16,95357,8193,64,130175,78959,102435,64605,61564,40969,117,95327,103431,120406]

theorem envBound41369 : H12AffineFastState.Bounded env41369 := by
  intro p hp
  have h : env41369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41368_41369 : H12AffineEnvironment.transform 17 31836 env41368 = env41369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31836 env41368 == env41369) = true)

theorem identity41369 : scanCanonicalize (H12AffineFastState.compose env41369 (packedSelected [0,1,2,3,5,6,8,10,11,14,18,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound41369 : packedSelected [0,1,2,3,5,6,8,10,11,14,18,19,27] rootPS < 2^1333 := by decide +kernel

def env41370 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,65536,16400,31836,1024,8233,91199,95327,16,95357,8193,64,89175,78959,77835,23669,20564,33,117,95327,78895,95870]

theorem envBound41370 : H12AffineFastState.Bounded env41370 := by
  intro p hp
  have h : env41370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41369_41370 : H12AffineEnvironment.transform 14 8232 env41369 = env41370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env41369 == env41370) = true)

theorem identity41370 : scanCanonicalize (H12AffineFastState.compose env41370 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41370 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env41371 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,8203,16400,31836,1024,8233,17460,21588,16,21622,8193,64,31836,5220,4096,23669,20564,33,117,21588,5156,22133]

theorem envBound41371 : H12AffineFastState.Bounded env41371 := by
  intro p hp
  have h : env41371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41370_41371 : H12AffineEnvironment.transform 15 8203 env41370 = env41371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41370 == env41371) = true)

theorem identity41371 : scanCanonicalize (H12AffineFastState.compose env41371 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound41371 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env41372 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13404,8232,8203,13388,2048,1024,8233,12392,8200,16,8234,8193,64,2048,5220,4096,10281,9224,33,117,8200,5156,8745]

theorem envBound41372 : H12AffineFastState.Bounded env41372 := by
  intro p hp
  have h : env41372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41371_41372 : H12AffineEnvironment.transform 13 13404 env41371 = env41372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env41371 == env41372) = true)

theorem identity41372 : scanCanonicalize (H12AffineFastState.compose env41372 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41372 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env41373 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,0,35,5220,2048,1024,1,4160,32,16,2,41,64,2048,5220,4096,2049,1056,33,117,32,5156,513]

theorem envBound41373 : H12AffineFastState.Bounded env41373 := by
  intro p hp
  have h : env41373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41372_41373 : H12AffineEnvironment.transform 12 40 env41372 = env41373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41372 == env41373) = true)

theorem identity41373 : scanCanonicalize (H12AffineFastState.compose env41373 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound41373 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41374 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,528,40,1636,0,35,1652,2048,1024,1,592,32,16,2,41,64,2048,1652,528,2049,1056,33,117,32,1588,513]

theorem envBound41374 : H12AffineFastState.Bounded env41374 := by
  intro p hp
  have h : env41374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41373_41374 : H12AffineEnvironment.transform 11 528 env41373 = env41374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env41373 == env41374) = true)

def env41375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115735,329731,16,95496,8193,64,130315,79130,102742,294912,61705,318549,256,95530,103431,120406]

theorem envBound41375 : H12AffineFastState.Bounded env41375 := by
  intro p hp
  have h : env41375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41351_41375 : H12AffineEnvironment.transform 16 16401 env41351 = env41375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41351 == env41375) = true)

theorem identity41375 : scanCanonicalize (H12AffineFastState.compose env41375 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound41375 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env41376 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16401,262144,1024,32769,4160,318548,16,41311,8193,64,10588,57677,17665,294912,61705,318549,256,41341,16464,513]

theorem envBound41376 : H12AffineFastState.Bounded env41376 := by
  intro p hp
  have h : env41376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41375_41376 : H12AffineEnvironment.transform 15 54359 env41375 = env41376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env41375 == env41376) = true)

theorem identity41376 : scanCanonicalize (H12AffineFastState.compose env41376 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound41376 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env41377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16401,64809,1024,32769,4160,8573,16,41311,8193,64,10588,57677,17665,32041,61705,8572,256,41341,16464,513]

theorem envBound41377 : H12AffineFastState.Bounded env41377 := by
  intro p hp
  have h : env41377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41376_41377 : H12AffineEnvironment.transform 17 64809 env41376 = env41377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env41376 == env41377) = true)

theorem identity41377 : scanCanonicalize (H12AffineFastState.compose env41377 (packedSelected [1,2,3,4,5,6,8,9,10,14,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41377 : packedSelected [1,2,3,4,5,6,8,9,10,14,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env41378 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,5392,43048,1024,32769,4160,8573,16,41311,8193,64,10588,46156,4096,10280,41992,8572,256,41341,5457,513]

theorem envBound41378 : H12AffineFastState.Bounded env41378 := by
  intro p hp
  have h : env41378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41377_41378 : H12AffineEnvironment.transform 13 5377 env41377 = env41378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41377 == env41378) = true)

theorem identity41378 : scanCanonicalize (H12AffineFastState.compose env41378 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound41378 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33110,5392,35188,1024,32769,4160,33,16,32771,349,64,2048,38160,4096,2420,34132,32,256,32801,5457,513]

theorem envBound41379 : H12AffineFastState.Bounded env41379 := by
  intro p hp
  have h : env41379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41378_41379 : H12AffineEnvironment.transform 12 348 env41378 = env41379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env41378 == env41379) = true)

theorem identity41379 : scanCanonicalize (H12AffineFastState.compose env41379 (packedSelected [2,3,5,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound41379 : packedSelected [2,3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env41380 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,32768,32803,5221,34817,1024,32769,4160,33,16,32771,40,64,2048,37989,4096,2049,33825,32,117,32801,5156,513]

theorem envBound41380 : H12AffineFastState.Bounded env41380 := by
  intro p hp
  have h : env41380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41379_41380 : H12AffineEnvironment.transform 7 117 env41379 = env41380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41379 == env41380) = true)

theorem identity41380 : scanCanonicalize (H12AffineFastState.compose env41380 (packedSelected [2,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41380 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env41381 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,0,35,5221,2049,1024,1,4160,33,16,3,40,64,2048,5221,4096,2049,1057,32,117,33,5156,513]

theorem envBound41381 : H12AffineFastState.Bounded env41381 := by
  intro p hp
  have h : env41381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41380_41381 : H12AffineEnvironment.transform 14 0 env41380 = env41381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41380 == env41381) = true)

def env41382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,329866,16,95497,8328,64,245138,79131,102879,442385,61704,318685,256,95531,103567,120542]

theorem envBound41382 : H12AffineFastState.Bounded env41382 := by
  intro p hp
  have h : env41382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41324_41382 : H12AffineEnvironment.transform 23 95497 env41324 = env41382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env41324 == env41382) = true)

theorem identity41382 : scanCanonicalize (H12AffineFastState.compose env41382 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound41382 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,318549,16,41430,8328,64,158029,57796,17664,442385,61704,318685,256,41460,16464,513]

theorem envBound41383 : H12AffineFastState.Bounded env41383 := by
  intro p hp
  have h : env41383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41382_41383 : H12AffineEnvironment.transform 15 54495 env41382 = env41383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env41382 == env41383) = true)

def env41384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,318549,16,41310,8192,64,158029,57676,17664,442385,61704,318549,256,41340,16464,513]

theorem envBound41384 : H12AffineFastState.Bounded env41384 := by
  intro p hp
  have h : env41384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41383_41384 : H12AffineEnvironment.transform 6 8 env41383 = env41384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41383 == env41384) = true)

theorem identity41384 : scanCanonicalize (H12AffineFastState.compose env41384 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41384 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,131072,262144,1024,8541,4161,294153,16,2,8192,64,158029,16400,17664,418125,20564,294153,256,32,16464,513]

theorem envBound41385 : H12AffineFastState.Bounded env41385 := by
  intro p hp
  have h : env41385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41384_41385 : H12AffineEnvironment.transform 14 8540 env41384 = env41385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41384 == env41385) = true)

theorem identity41385 : scanCanonicalize (H12AffineFastState.compose env41385 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41385 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41386 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,131072,262144,272,8541,4161,292889,16,2,8192,64,158029,16400,16400,418125,20564,292889,256,32,16464,513]

theorem envBound41386 : H12AffineFastState.Bounded env41386 := by
  intro p hp
  have h : env41386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41385_41386 : H12AffineEnvironment.transform 9 272 env41385 = env41386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41385 == env41386) = true)

theorem identity41386 : scanCanonicalize (H12AffineFastState.compose env41386 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound41386 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env41387 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,4096,262144,272,8541,4161,292889,16,2,8192,64,31053,16400,16400,291149,20564,292889,256,32,16464,513]

theorem envBound41387 : H12AffineFastState.Bounded env41387 := by
  intro p hp
  have h : env41387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41386_41387 : H12AffineEnvironment.transform 16 4096 env41386 = env41387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env41386 == env41387) = true)

theorem identity41387 : scanCanonicalize (H12AffineFastState.compose env41387 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 22885) := by decide +kernel

theorem selectedBound41387 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41388 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,4096,22885,272,8541,4161,8572,16,2,8192,64,31053,16400,16400,10280,20564,8572,256,32,16464,513]

theorem envBound41388 : H12AffineFastState.Bounded env41388 := by
  intro p hp
  have h : env41388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41387_41388 : H12AffineEnvironment.transform 17 22885 env41387 = env41388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22885 env41387 == env41388) = true)

theorem identity41388 : scanCanonicalize (H12AffineFastState.compose env41388 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound41388 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env41389 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12573,8540,262,4096,10360,272,8541,4161,8572,16,2,8192,64,2128,12557,12557,10280,8521,8572,256,32,12621,513]

theorem envBound41389 : H12AffineFastState.Bounded env41389 := by
  intro p hp
  have h : env41389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41388_41389 : H12AffineEnvironment.transform 13 12573 env41388 = env41389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env41388 == env41389) = true)

theorem identity41389 : scanCanonicalize (H12AffineFastState.compose env41389 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41389 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env41390 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,4404,373,262,4096,2129,272,372,4161,341,16,2,41,64,2128,4388,4388,2049,352,341,256,32,4452,513]

theorem envBound41390 : H12AffineFastState.Bounded env41390 := by
  intro p hp
  have h : env41390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41389_41390 : H12AffineEnvironment.transform 12 41 env41389 = env41390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41389 == env41390) = true)

theorem identity41390 : scanCanonicalize (H12AffineFastState.compose env41390 (packedSelected [0,1,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound41390 : packedSelected [0,1,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env41391 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,64,41,372,373,262,64,2129,272,372,1,341,16,2,41,64,2128,356,356,2049,352,341,256,32,292,513]

theorem envBound41391 : H12AffineFastState.Bounded env41391 := by
  intro p hp
  have h : env41391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41390_41391 : H12AffineEnvironment.transform 11 64 env41390 = env41391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env41390 == env41391) = true)

theorem identity41391 : scanCanonicalize (H12AffineFastState.compose env41391 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound41391 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env41392 : List Nat := [2,4,8,16,32,64,8,256,324,272,2048,64,41,372,373,262,64,2129,272,372,1,341,16,2,41,64,2128,356,356,2049,352,341,256,32,292,325]

theorem envBound41392 : H12AffineFastState.Bounded env41392 := by
  intro p hp
  have h : env41392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41391_41392 : H12AffineEnvironment.transform 8 324 env41391 = env41392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env41391 == env41392) = true)

theorem identity41392 : scanCanonicalize (H12AffineFastState.compose env41392 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41392 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env41393 : List Nat := [2,4,8,16,32,64,8,36,96,52,2048,64,41,80,81,34,64,2129,52,80,1,113,16,2,41,64,2128,64,64,2049,68,113,36,32,0,97]

theorem envBound41393 : H12AffineFastState.Bounded env41393 := by
  intro p hp
  have h : env41393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41392_41393 : H12AffineEnvironment.transform 7 36 env41392 = env41393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41392 == env41393) = true)

theorem identity41393 : scanCanonicalize (H12AffineFastState.compose env41393 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41394 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,16,41,0,1,34,16,2049,52,0,1,33,16,2,41,16,2048,16,16,2049,20,33,36,32,0,49]

theorem envBound41394 : H12AffineFastState.Bounded env41394 := by
  intro p hp
  have h : env41394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41393_41394 : H12AffineEnvironment.transform 5 16 env41393 = env41394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41393 == env41394) = true)

theorem identity41394 : scanCanonicalize (H12AffineFastState.compose env41394 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound41394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41395 : List Nat := [2,4,8,16,32,16,8,36,48,52,16,16,41,0,1,34,16,17,52,0,1,33,16,2,41,16,16,16,16,17,20,33,36,32,0,49]

theorem envBound41395 : H12AffineFastState.Bounded env41395 := by
  intro p hp
  have h : env41395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41394_41395 : H12AffineEnvironment.transform 10 16 env41394 = env41395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env41394 == env41395) = true)

theorem identity41395 : scanCanonicalize (H12AffineFastState.compose env41395 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41395 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41396 : List Nat := [2,4,8,1,32,1,8,36,33,37,1,1,41,0,1,34,1,0,37,0,1,33,1,2,41,1,1,1,1,0,5,33,36,32,0,32]

theorem envBound41396 : H12AffineFastState.Bounded env41396 := by
  intro p hp
  have h : env41396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41395_41396 : H12AffineEnvironment.transform 3 1 env41395 = env41396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41395 == env41396) = true)

theorem identity41396 : scanCanonicalize (H12AffineFastState.compose env41396 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41396 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41397 : List Nat := [2,4,8,1,1,1,8,5,0,4,1,1,8,0,1,3,1,0,4,0,1,0,1,2,8,1,1,1,1,0,5,0,5,1,0,1]

theorem envBound41397 : H12AffineFastState.Bounded env41397 := by
  intro p hp
  have h : env41397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41396_41397 : H12AffineEnvironment.transform 4 1 env41396 = env41397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41396 == env41397) = true)

def env41398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,318549,16,41311,8193,64,158029,57677,17664,442385,61704,318548,256,41341,16464,513]

theorem envBound41398 : H12AffineFastState.Bounded env41398 := by
  intro p hp
  have h : env41398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41383_41398 : H12AffineEnvironment.transform 6 9 env41383 = env41398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41383 == env41398) = true)

def env41399 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,318469,16,41231,8193,16,157981,57629,17664,442385,61704,318468,256,41261,16384,513]

theorem envBound41399 : H12AffineFastState.Bounded env41399 := by
  intro p hp
  have h : env41399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41398_41399 : H12AffineEnvironment.transform 5 16 env41398 = env41399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41398 == env41399) = true)

theorem identity41399 : scanCanonicalize (H12AffineFastState.compose env41399 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound41399 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41400 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,64808,1024,32769,4113,8493,16,41231,8193,16,157981,57629,17664,146745,61704,8492,256,41261,16384,513]

theorem envBound41400 : H12AffineFastState.Bounded env41400 := by
  intro p hp
  have h : env41400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41399_41400 : H12AffineEnvironment.transform 17 64808 env41399 = env41400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env41399 == env41400) = true)

theorem identity41400 : scanCanonicalize (H12AffineFastState.compose env41400 (packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound41400 : packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env41401 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33030,131072,43048,1024,32769,4113,8493,16,41231,8193,16,146461,46109,4096,146745,41992,8492,256,41261,5376,513]

theorem envBound41401 : H12AffineFastState.Bounded env41401 := by
  intro p hp
  have h : env41401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41400_41401 : H12AffineEnvironment.transform 13 5376 env41400 = env41401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41400 == env41401) = true)

theorem identity41401 : scanCanonicalize (H12AffineFastState.compose env41401 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound41401 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41402 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33030,38161,43048,1024,32769,4113,8493,16,41231,8193,16,43276,46109,4096,43048,41992,8492,256,41261,5376,513]

theorem envBound41402 : H12AffineFastState.Bounded env41402 := by
  intro p hp
  have h : env41402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41401_41402 : H12AffineEnvironment.transform 16 38161 env41401 = env41402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env41401 == env41402) = true)

theorem identity41402 : scanCanonicalize (H12AffineFastState.compose env41402 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41402 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41403 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,0,262,5393,10280,1024,1,4113,8493,16,8463,8193,16,10508,13341,4096,10280,9224,8492,256,8493,5376,513]

theorem envBound41403 : H12AffineFastState.Bounded env41403 := by
  intro p hp
  have h : env41403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41402_41403 : H12AffineEnvironment.transform 14 0 env41402 = env41403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41402 == env41403) = true)

theorem identity41403 : scanCanonicalize (H12AffineFastState.compose env41403 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41403 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41404 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5393,2340,1024,1,4113,33,16,3,269,16,2048,5393,4096,2340,1284,32,256,33,5376,513]

theorem envBound41404 : H12AffineFastState.Bounded env41404 := by
  intro p hp
  have h : env41404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41403_41404 : H12AffineEnvironment.transform 12 268 env41403 = env41404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41403 == env41404) = true)

theorem identity41404 : scanCanonicalize (H12AffineFastState.compose env41404 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41404 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41405 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,0,35,5172,2049,1024,1,4113,33,16,3,40,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound41405 : H12AffineFastState.Bounded env41405 := by
  intro p hp
  have h : env41405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41404_41405 : H12AffineEnvironment.transform 7 37 env41404 = env41405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41404 == env41405) = true)

def env41406 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,0,35,1028,2049,1024,1,33,33,16,3,40,16,2048,1028,48,2049,1057,32,37,33,1045,513]

theorem envBound41406 : H12AffineFastState.Bounded env41406 := by
  intro p hp
  have h : env41406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41405_41406 : H12AffineEnvironment.transform 11 48 env41405 = env41406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env41405 == env41406) = true)

theorem identity41406 : scanCanonicalize (H12AffineFastState.compose env41406 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41406 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41407 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,48,41,32,0,35,49,2049,53,1,33,33,16,3,40,16,2048,49,48,2049,20,32,37,33,32,513]

theorem envBound41407 : H12AffineFastState.Bounded env41407 := by
  intro p hp
  have h : env41407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41406_41407 : H12AffineEnvironment.transform 9 53 env41406 = env41407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41406 == env41407) = true)

theorem identity41407 : scanCanonicalize (H12AffineFastState.compose env41407 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound41407 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41408 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,48,41,32,0,35,49,2049,53,1,33,33,16,3,40,16,2048,49,48,2049,20,32,37,33,32,10]

theorem envBound41408 : H12AffineFastState.Bounded env41408 := by
  intro p hp
  have h : env41408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41407_41408 : H12AffineEnvironment.transform 8 11 env41407 = env41408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env41407 == env41408) = true)

def leafEnv41408 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,48,41,32,0,35,49,2049,53,1,33,33,16,3,20,40,1,16,2048,49,48,2049,20,32,37,33,4,34,32,10,1,33,0]

def active41408 : List Nat := [0,1,2,3,4,10]

def tree41408 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41408 : H12WitnessSearch.Good tree41408 := H12GlobalWitnessIndex.good

theorem leafIdentity41408 : H12AffineFastState.composeSystem env41408 rootObs = leafEnv41408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41408 rootObs == leafEnv41408) = true)

theorem terminalChecked41408 : H12PackedTerminal.terminalCheckFast leafEnv41408 active41408 tree41408 = true := by decide +kernel

def env41409 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,0,35,1029,2049,1024,1,32,33,16,3,40,16,2048,1029,49,2049,1057,32,37,33,1044,513]

theorem envBound41409 : H12AffineFastState.Bounded env41409 := by
  intro p hp
  have h : env41409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41405_41409 : H12AffineEnvironment.transform 11 49 env41405 = env41409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env41405 == env41409) = true)

def env41410 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,49,41,32,0,35,49,2049,52,1,32,33,16,3,40,16,2048,49,49,2049,21,32,37,33,32,513]

theorem envBound41410 : H12AffineFastState.Bounded env41410 := by
  intro p hp
  have h : env41410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41409_41410 : H12AffineEnvironment.transform 9 52 env41409 = env41410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41409 == env41410) = true)

theorem identity41410 : scanCanonicalize (H12AffineFastState.compose env41410 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41411 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,9,0,0,3,17,2049,20,1,0,1,16,3,8,16,2048,17,17,2049,21,0,5,1,0,513]

theorem envBound41411 : H12AffineFastState.Bounded env41411 := by
  intro p hp
  have h : env41411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41410_41411 : H12AffineEnvironment.transform 4 0 env41410 = env41411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41410 == env41411) = true)

def leafEnv41411 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,9,0,0,3,17,2049,20,1,0,1,16,3,21,8,1,16,2048,17,17,2049,21,0,5,1,4,2,0,513,1,0,0]

def active41411 : List Nat := [0,1,2,3,8,10]

def tree41411 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41411 : H12WitnessSearch.Good tree41411 := H12GlobalWitnessIndex.good

theorem leafIdentity41411 : H12AffineFastState.composeSystem env41411 rootObs = leafEnv41411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41411 rootObs == leafEnv41411) = true)

theorem terminalChecked41411 : H12PackedTerminal.terminalCheckFast leafEnv41411 active41411 tree41411 = true := by decide +kernel

def env41412 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,49,41,33,0,35,48,2049,53,1,32,33,16,3,40,16,2048,48,49,2049,20,32,37,33,33,513]

theorem envBound41412 : H12AffineFastState.Bounded env41412 := by
  intro p hp
  have h : env41412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41409_41412 : H12AffineEnvironment.transform 9 53 env41409 = env41412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41409 == env41412) = true)

theorem identity41412 : scanCanonicalize (H12AffineFastState.compose env41412 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound41412 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41413 : List Nat := [2,4,8,16,32,16,9,37,10,53,2048,49,41,33,0,35,48,2049,53,1,32,33,16,3,40,16,2048,48,49,2049,20,32,37,33,33,11]

theorem envBound41413 : H12AffineFastState.Bounded env41413 := by
  intro p hp
  have h : env41413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41412_41413 : H12AffineEnvironment.transform 8 10 env41412 = env41413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env41412 == env41413) = true)

def leafEnv41413 : List Nat := [2,4,8,16,32,16,9,37,10,53,2048,49,41,33,0,35,48,2049,53,1,32,33,16,3,20,40,1,16,2048,48,49,2049,20,32,37,33,4,34,33,11,1,32,0]

def active41413 : List Nat := [0,1,2,3,4,10]

def tree41413 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41413 : H12WitnessSearch.Good tree41413 := H12GlobalWitnessIndex.good

theorem leafIdentity41413 : H12AffineFastState.composeSystem env41413 rootObs = leafEnv41413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41413 rootObs == leafEnv41413) = true)

theorem terminalChecked41413 : H12PackedTerminal.terminalCheckFast leafEnv41413 active41413 tree41413 = true := by decide +kernel

def env41414 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,318468,16,41230,8193,17,157980,57628,17664,442385,61704,318469,256,41260,16385,513]

theorem envBound41414 : H12AffineFastState.Bounded env41414 := by
  intro p hp
  have h : env41414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41398_41414 : H12AffineEnvironment.transform 5 17 env41398 = env41414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41398 == env41414) = true)

theorem identity41414 : scanCanonicalize (H12AffineFastState.compose env41414 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound41414 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41415 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,2340,1024,32769,4112,54560,16,41230,8193,17,157980,57628,17664,182581,61704,54561,256,41260,16385,513]

theorem envBound41415 : H12AffineFastState.Bounded env41415 := by
  intro p hp
  have h : env41415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41414_41415 : H12AffineEnvironment.transform 17 2340 env41414 = env41415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env41414 == env41415) = true)

theorem identity41415 : scanCanonicalize (H12AffineFastState.compose env41415 (packedSelected [0,1,5,7,8,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41415 : packedSelected [0,1,5,7,8,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env41416 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33030,131072,2340,1024,32769,4112,32801,16,41230,8193,17,146461,46109,4097,171060,41993,32800,256,41260,5376,513]

theorem envBound41416 : H12AffineFastState.Bounded env41416 := by
  intro p hp
  have h : env41416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41415_41416 : H12AffineEnvironment.transform 13 5377 env41415 = env41416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41415 == env41416) = true)

theorem identity41416 : scanCanonicalize (H12AffineFastState.compose env41416 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 46392) := by decide +kernel

theorem selectedBound41416 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41417 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33030,46392,2340,1024,32769,4112,32801,16,41230,8193,17,35109,46109,4097,10508,41993,32800,256,41260,5376,513]

theorem envBound41417 : H12AffineFastState.Bounded env41417 := by
  intro p hp
  have h : env41417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41416_41417 : H12AffineEnvironment.transform 16 46392 env41416 = env41417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46392 env41416 == env41417) = true)

theorem identity41417 : scanCanonicalize (H12AffineFastState.compose env41417 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound41417 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env41418 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,293,35,13341,2340,1024,292,4112,260,16,8235,8193,17,2048,13624,4097,10508,9516,261,256,8201,5376,513]

theorem envBound41418 : H12AffineFastState.Bounded env41418 := by
  intro p hp
  have h : env41418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41417_41418 : H12AffineEnvironment.transform 14 293 env41417 = env41418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env41417 == env41418) = true)

theorem identity41418 : scanCanonicalize (H12AffineFastState.compose env41418 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41418 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41419 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,293,35,5392,2340,1024,292,4112,260,16,294,268,17,2048,5173,4097,2049,1057,261,256,260,5376,513]

theorem envBound41419 : H12AffineFastState.Bounded env41419 := by
  intro p hp
  have h : env41419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41418_41419 : H12AffineEnvironment.transform 12 269 env41418 = env41419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41418 == env41419) = true)

theorem identity41419 : scanCanonicalize (H12AffineFastState.compose env41419 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41419 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env41420 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,269,4404,293,35,4389,2340,53,292,4112,260,16,294,268,17,2048,4096,4097,2049,20,261,256,260,4405,513]

theorem envBound41420 : H12AffineFastState.Bounded env41420 := by
  intro p hp
  have h : env41420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41419_41420 : H12AffineEnvironment.transform 9 53 env41419 = env41420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41419 == env41420) = true)

theorem identity41420 : scanCanonicalize (H12AffineFastState.compose env41420 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound41420 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41421 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2357,269,2049,293,35,2064,2340,53,292,2341,260,16,294,268,17,2048,2357,2356,2049,20,261,256,260,2048,513]

theorem envBound41421 : H12AffineFastState.Bounded env41421 := by
  intro p hp
  have h : env41421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41420_41421 : H12AffineEnvironment.transform 11 2357 env41420 = env41421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env41420 == env41421) = true)

theorem identity41421 : scanCanonicalize (H12AffineFastState.compose env41421 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41421 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41422 : List Nat := [2,4,8,16,32,17,9,256,512,53,1,308,269,0,293,35,17,293,53,292,292,260,16,294,268,17,1,308,309,0,20,261,256,260,1,513]

theorem envBound41422 : H12AffineFastState.Bounded env41422 := by
  intro p hp
  have h : env41422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41421_41422 : H12AffineEnvironment.transform 10 1 env41421 = env41422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41421 == env41422) = true)

theorem identity41422 : scanCanonicalize (H12AffineFastState.compose env41422 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41422 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41423 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,16,41,0,1,35,17,1,53,0,0,32,16,2,40,17,1,16,17,0,20,33,36,32,1,513]

theorem envBound41423 : H12AffineFastState.Bounded env41423 := by
  intro p hp
  have h : env41423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41422_41423 : H12AffineEnvironment.transform 7 36 env41422 = env41423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41422 == env41423) = true)

theorem identity41423 : scanCanonicalize (H12AffineFastState.compose env41423 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound41423 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41424 : List Nat := [2,4,8,16,32,17,9,36,17,53,1,16,41,0,1,35,17,1,53,0,0,32,16,2,40,17,1,16,17,0,20,33,36,32,1,16]

theorem envBound41424 : H12AffineFastState.Bounded env41424 := by
  intro p hp
  have h : env41424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41423_41424 : H12AffineEnvironment.transform 8 17 env41423 = env41424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41423 == env41424) = true)

theorem identity41424 : scanCanonicalize (H12AffineFastState.compose env41424 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41424 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41425 : List Nat := [2,4,8,10,32,11,9,36,11,47,1,10,41,0,1,35,11,1,47,0,0,32,10,2,40,11,1,10,11,0,14,33,36,32,1,10]

theorem envBound41425 : H12AffineFastState.Bounded env41425 := by
  intro p hp
  have h : env41425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41424_41425 : H12AffineEnvironment.transform 3 10 env41424 = env41425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41424 == env41425) = true)

def env41426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2411541,2213006,16777216,8328,64,16959642,18973836,102879,2557071,18890911,17148373,256,16777250,16834950,18966345]

theorem envBound41426 : H12AffineFastState.Bounded env41426 := by
  intro p hp
  have h : env41426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41322_41426 : H12AffineEnvironment.transform 21 2411541 env41322 = env41426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2411541 env41322 == env41426) = true)

def env41427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318549,120014,16777216,8328,64,16959642,16880844,102879,464079,16797919,17148373,256,16777250,16834950,16873225]

theorem envBound41427 : H12AffineFastState.Bounded env41427 := by
  intro p hp
  have h : env41427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41426_41427 : H12AffineEnvironment.transform 20 4160 env41426 = env41427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41426 == env41427) = true)

theorem identity41427 : scanCanonicalize (H12AffineFastState.compose env41427 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95496) := by decide +kernel

theorem selectedBound41427 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318549,120014,95496,8328,64,245138,57796,102879,464079,75223,318685,256,95530,103566,513]

theorem envBound41428 : H12AffineFastState.Bounded env41428 := by
  intro p hp
  have h : env41428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41427_41428 : H12AffineEnvironment.transform 23 95496 env41427 = env41428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env41427 == env41428) = true)

def env41429 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318549,119878,95496,8192,64,245018,57676,102743,463943,75103,318549,256,95530,103430,513]

theorem envBound41429 : H12AffineFastState.Bounded env41429 := by
  intro p hp
  have h : env41429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41428_41429 : H12AffineEnvironment.transform 6 8 env41428 = env41429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41428 == env41429) = true)

theorem identity41429 : scanCanonicalize (H12AffineFastState.compose env41429 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound41429 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env41430 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,4160,318549,119878,95496,8192,64,56577,57676,102743,291932,75103,318549,256,95530,103430,513]

theorem envBound41430 : H12AffineFastState.Bounded env41430 := by
  intro p hp
  have h : env41430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41429_41430 : H12AffineEnvironment.transform 16 90139 env41429 = env41430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env41429 == env41430) = true)

def env41431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,4160,62589,119878,95496,8192,64,56577,57676,102743,23668,75103,62589,256,95530,103430,513]

theorem envBound41431 : H12AffineFastState.Bounded env41431 := by
  intro p hp
  have h : env41431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41430_41431 : H12AffineEnvironment.transform 17 10280 env41430 = env41431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41430 == env41431) = true)

theorem identity41431 : scanCanonicalize (H12AffineFastState.compose env41431 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound41431 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46157,10280,1024,32769,4160,62589,16,41310,8192,64,56577,57676,17665,23668,61705,62589,256,41340,16464,513]

theorem envBound41432 : H12AffineFastState.Bounded env41432 := by
  intro p hp
  have h : env41432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41431_41432 : H12AffineEnvironment.transform 15 54358 env41431 = env41432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env41431 == env41432) = true)

theorem identity41432 : scanCanonicalize (H12AffineFastState.compose env41432 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7284) := by decide +kernel

theorem selectedBound41432 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7284,32768,34850,46157,10280,1024,32769,4160,43017,16,41310,8192,64,33141,48440,6517,0,44413,43017,256,41340,7204,513]

theorem envBound41433 : H12AffineFastState.Bounded env41433 := by
  intro p hp
  have h : env41433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41432_41433 : H12AffineEnvironment.transform 13 7284 env41432 = env41433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7284 env41432 == env41433) = true)

theorem identity41433 : scanCanonicalize (H12AffineFastState.compose env41433 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7284,8540,10622,5393,10280,1024,8541,4160,2389,16,2,8192,64,8233,7268,6517,0,3105,2389,256,32,7204,513]

theorem envBound41434 : H12AffineFastState.Bounded env41434 := by
  intro p hp
  have h : env41434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41433_41434 : H12AffineEnvironment.transform 14 8540 env41433 = env41434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41433 == env41434) = true)

theorem identity41434 : scanCanonicalize (H12AffineFastState.compose env41434 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41434 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41435 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,6501,8540,10622,4096,10280,273,8541,4160,2389,16,2,8192,64,8233,6517,6517,0,2352,2389,256,32,6453,513]

theorem envBound41435 : H12AffineFastState.Bounded env41435 := by
  intro p hp
  have h : env41435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41434_41435 : H12AffineEnvironment.transform 9 273 env41434 = env41435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41434 == env41435) = true)

theorem identity41435 : scanCanonicalize (H12AffineFastState.compose env41435 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound41435 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env41436 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,121,6501,293,2311,4096,2129,273,292,4160,2389,16,2,121,64,80,6517,6517,0,2352,2389,256,32,6453,513]

theorem envBound41436 : H12AffineFastState.Bounded env41436 := by
  intro p hp
  have h : env41436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41435_41436 : H12AffineEnvironment.transform 12 121 env41435 = env41436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env41435 == env41436) = true)

theorem identity41436 : scanCanonicalize (H12AffineFastState.compose env41436 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound41436 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env41437 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2112,121,293,293,2311,2112,2129,273,292,2048,2389,16,2,121,64,80,309,309,0,2352,2389,256,32,373,513]

theorem envBound41437 : H12AffineFastState.Bounded env41437 := by
  intro p hp
  have h : env41437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41436_41437 : H12AffineEnvironment.transform 11 2112 env41436 = env41437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env41436 == env41437) = true)

theorem identity41437 : scanCanonicalize (H12AffineFastState.compose env41437 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound41437 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41438 : List Nat := [2,4,8,16,32,64,8,256,17,273,2048,2112,121,293,293,2311,2112,2129,273,292,2048,2389,16,2,121,64,80,309,309,0,2352,2389,256,32,373,16]

theorem envBound41438 : H12AffineFastState.Bounded env41438 := by
  intro p hp
  have h : env41438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41437_41438 : H12AffineEnvironment.transform 8 17 env41437 = env41438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41437 == env41438) = true)

theorem identity41438 : scanCanonicalize (H12AffineFastState.compose env41438 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound41438 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env41439 : List Nat := [2,4,8,16,32,64,8,256,17,273,17,81,121,293,293,278,81,64,273,292,17,324,16,2,121,64,80,309,309,0,289,324,256,32,373,16]

theorem envBound41439 : H12AffineFastState.Bounded env41439 := by
  intro p hp
  have h : env41439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41438_41439 : H12AffineEnvironment.transform 10 17 env41438 = env41439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env41438 == env41439) = true)

theorem identity41439 : scanCanonicalize (H12AffineFastState.compose env41439 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound41439 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41440 : List Nat := [2,4,8,16,32,64,8,101,17,116,17,81,121,64,64,115,81,64,116,65,17,33,16,2,121,64,80,80,80,0,68,33,101,32,16,16]

theorem envBound41440 : H12AffineFastState.Bounded env41440 := by
  intro p hp
  have h : env41440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41439_41440 : H12AffineEnvironment.transform 7 101 env41439 = env41440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env41439 == env41440) = true)

theorem identity41440 : scanCanonicalize (H12AffineFastState.compose env41440 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41441 : List Nat := [2,4,8,16,16,64,8,85,17,68,17,81,73,64,64,67,81,64,68,65,17,17,16,2,73,64,80,80,80,0,68,17,85,16,16,16]

theorem envBound41441 : H12AffineFastState.Bounded env41441 := by
  intro p hp
  have h : env41441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41440_41441 : H12AffineEnvironment.transform 4 16 env41440 = env41441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41440 == env41441) = true)

theorem identity41441 : scanCanonicalize (H12AffineFastState.compose env41441 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound41441 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41442 : List Nat := [2,4,8,16,16,1,8,20,17,5,17,16,8,1,1,2,16,1,5,0,17,17,16,2,8,1,17,17,17,0,5,17,20,16,16,16]

theorem envBound41442 : H12AffineFastState.Bounded env41442 := by
  intro p hp
  have h : env41442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41441_41442 : H12AffineEnvironment.transform 5 1 env41441 = env41442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41441 == env41442) = true)

theorem identity41442 : scanCanonicalize (H12AffineFastState.compose env41442 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41443 : List Nat := [2,4,8,1,1,1,8,5,0,5,0,1,8,1,1,2,1,1,5,0,0,0,1,2,8,1,0,0,0,0,5,0,5,1,1,1]

theorem envBound41443 : H12AffineFastState.Bounded env41443 := by
  intro p hp
  have h : env41443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41442_41443 : H12AffineEnvironment.transform 3 1 env41442 = env41443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41442 == env41443) = true)

def env41444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,4160,62588,119878,95496,8192,64,56577,57676,102743,23669,75103,62588,256,95530,103430,513]

theorem envBound41444 : H12AffineFastState.Bounded env41444 := by
  intro p hp
  have h : env41444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41430_41444 : H12AffineEnvironment.transform 17 10281 env41430 = env41444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41430 == env41444) = true)

theorem identity41444 : scanCanonicalize (H12AffineFastState.compose env41444 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound41444 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28699,4096,10281,1024,32769,4160,62588,42077,1299,8192,64,56577,57676,57676,23669,21828,62588,256,1329,58397,513]

theorem envBound41445 : H12AffineFastState.Bounded env41445 := by
  intro p hp
  have h : env41445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41444_41445 : H12AffineEnvironment.transform 15 28699 env41444 = env41445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env41444 == env41445) = true)

theorem identity41445 : scanCanonicalize (H12AffineFastState.compose env41445 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41445 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28699,4096,10281,1024,8541,4160,21792,1281,1299,8192,64,31837,16400,16400,23669,21828,21792,256,1329,17729,513]

theorem envBound41446 : H12AffineFastState.Bounded env41446 := by
  intro p hp
  have h : env41446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41445_41446 : H12AffineEnvironment.transform 14 8540 env41445 = env41446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41445 == env41446) = true)

theorem identity41446 : scanCanonicalize (H12AffineFastState.compose env41446 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 10509) := by decide +kernel

theorem selectedBound41446 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env41447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10509,8540,6422,4096,10281,1024,8541,4160,15405,1281,1299,8192,64,5456,10525,10525,13688,15433,15405,256,1329,11340,513]

theorem envBound41447 : H12AffineFastState.Bounded env41447 := by
  intro p hp
  have h : env41447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41446_41447 : H12AffineEnvironment.transform 13 10509 env41446 = env41447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10509 env41446 == env41447) = true)

def env41448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318549,119879,95496,8193,64,245019,57677,102742,463942,75102,318548,256,95530,103431,513]

theorem envBound41448 : H12AffineFastState.Bounded env41448 := by
  intro p hp
  have h : env41448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41428_41448 : H12AffineEnvironment.transform 6 9 env41428 = env41448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41428 == env41448) = true)

def env41449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62589,119879,95496,8193,64,245019,57677,102742,212078,75102,62588,256,95530,103431,513]

theorem envBound41449 : H12AffineFastState.Bounded env41449 := by
  intro p hp
  have h : env41449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41448_41449 : H12AffineEnvironment.transform 17 10280 env41448 = env41449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41448 == env41449) = true)

theorem identity41449 : scanCanonicalize (H12AffineFastState.compose env41449 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41449 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env41450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1024,8540,4160,21792,95514,95496,8193,64,203846,16400,77835,212078,75102,21793,256,95530,79194,513]

theorem envBound41450 : H12AffineFastState.Bounded env41450 := by
  intro p hp
  have h : env41450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41449_41450 : H12AffineEnvironment.transform 14 8541 env41449 = env41450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41449 == env41450) = true)

theorem identity41450 : scanCanonicalize (H12AffineFastState.compose env41450 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound41450 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env41451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8541,65536,131072,10280,1024,8540,4160,113,73803,73817,8193,64,203846,5441,77835,212078,75102,112,256,73851,79194,513]

theorem envBound41451 : H12AffineFastState.Bounded env41451 := by
  intro p hp
  have h : env41451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41450_41451 : H12AffineEnvironment.transform 13 5457 env41450 = env41451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env41450 == env41451) = true)

theorem identity41451 : scanCanonicalize (H12AffineFastState.compose env41451 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41451 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env41452 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,65536,131072,10280,1024,8460,4112,33,73755,73737,8193,16,203798,5393,77835,212030,75022,32,256,73771,79114,513]

theorem envBound41452 : H12AffineFastState.Bounded env41452 := by
  intro p hp
  have h : env41452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41451_41452 : H12AffineEnvironment.transform 5 16 env41451 = env41452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41451 == env41452) = true)

theorem identity41452 : scanCanonicalize (H12AffineFastState.compose env41452 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound41452 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41453 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,65536,70679,10280,1024,8460,4112,33,73755,73737,8193,16,2049,5393,77835,10281,75022,32,256,73771,79114,513]

theorem envBound41453 : H12AffineFastState.Bounded env41453 := by
  intro p hp
  have h : env41453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41452_41453 : H12AffineEnvironment.transform 16 70679 env41452 = env41453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env41452 == env41453) = true)

theorem identity41453 : scanCanonicalize (H12AffineFastState.compose env41453 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41453 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41454 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8203,13340,10280,1024,8460,4112,33,16,2,8193,16,2049,5393,4096,10281,1285,32,256,32,5377,513]

theorem envBound41454 : H12AffineFastState.Bounded env41454 := by
  intro p hp
  have h : env41454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41453_41454 : H12AffineEnvironment.transform 15 8203 env41453 = env41454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41453 == env41454) = true)

def env41455 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62588,119879,95496,8193,64,245019,57677,102742,212079,75102,62589,256,95530,103431,513]

theorem envBound41455 : H12AffineFastState.Bounded env41455 := by
  intro p hp
  have h : env41455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41448_41455 : H12AffineEnvironment.transform 17 10281 env41448 = env41455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41448 == env41455) = true)

theorem identity41455 : scanCanonicalize (H12AffineFastState.compose env41455 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound41455 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41456 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,4160,62588,16,41311,8193,64,158028,57677,17665,190520,61705,62589,256,41341,16464,513]

theorem envBound41456 : H12AffineFastState.Bounded env41456 := by
  intro p hp
  have h : env41456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41455_41456 : H12AffineEnvironment.transform 15 54359 env41455 = env41456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env41455 == env41456) = true)

theorem identity41456 : scanCanonicalize (H12AffineFastState.compose env41456 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound41456 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41457 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46156,10281,1024,32769,4160,62588,16,41311,8193,64,56576,57677,17665,23668,61705,62589,256,41341,16464,513]

theorem envBound41457 : H12AffineFastState.Bounded env41457 := by
  intro p hp
  have h : env41457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41456_41457 : H12AffineEnvironment.transform 16 46156 env41456 = env41457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env41456 == env41457) = true)

theorem identity41457 : scanCanonicalize (H12AffineFastState.compose env41457 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound41457 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28699,4096,10281,1024,9293,4160,20528,16,1299,8193,64,31052,17665,17665,23668,21829,20529,256,1329,16464,513]

theorem envBound41458 : H12AffineFastState.Bounded env41458 := by
  intro p hp
  have h : env41458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41457_41458 : H12AffineEnvironment.transform 14 9292 env41457 = env41458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env41457 == env41458) = true)

theorem identity41458 : scanCanonicalize (H12AffineFastState.compose env41458 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5212) := by decide +kernel

theorem selectedBound41458 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5212,16384,4112,17479,4096,7285,1024,4113,4160,20528,16,1299,5213,64,19728,17665,17665,23668,21829,20529,256,1329,16464,513]

theorem envBound41459 : H12AffineFastState.Bounded env41459 := by
  intro p hp
  have h : env41459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41458_41459 : H12AffineEnvironment.transform 12 5212 env41458 = env41459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5212 env41458 == env41459) = true)

theorem identity41459 : scanCanonicalize (H12AffineFastState.compose env41459 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound41459 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env41460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5212,5237,4112,4146,4096,7285,1024,4113,4160,1093,16,1299,5213,64,6501,4468,4468,2049,304,1092,256,1329,5157,513]

theorem envBound41460 : H12AffineFastState.Bounded env41460 := by
  intro p hp
  have h : env41460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41459_41460 : H12AffineEnvironment.transform 13 5237 env41459 = env41460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env41459 == env41460) = true)

theorem identity41460 : scanCanonicalize (H12AffineFastState.compose env41460 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound41460 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1313,381,340,1329,1299,1313,2388,1024,1328,1377,1093,16,1299,380,64,3140,1109,1109,2049,304,1092,256,1329,260,513]

theorem envBound41461 : H12AffineFastState.Bounded env41461 := by
  intro p hp
  have h : env41461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41460_41461 : H12AffineEnvironment.transform 11 1313 env41460 = env41461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env41460 == env41461) = true)

theorem identity41461 : scanCanonicalize (H12AffineFastState.compose env41461 (packedSelected [0,2,3,7,8,11,14,24] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound41461 : packedSelected [0,2,3,7,8,11,14,24] rootPS < 2^1333 := by decide +kernel

def env41462 : List Nat := [2,4,8,16,32,64,9,256,65,1024,2048,1313,381,340,1329,1299,1313,2388,1024,1328,1377,1093,16,1299,380,64,3140,1109,1109,2049,304,1092,256,1329,260,64]

theorem envBound41462 : H12AffineFastState.Bounded env41462 := by
  intro p hp
  have h : env41462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41461_41462 : H12AffineEnvironment.transform 8 65 env41461 = env41462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env41461 == env41462) = true)

theorem identity41462 : scanCanonicalize (H12AffineFastState.compose env41462 (packedSelected [1,2,3,5,7,11,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41462 : packedSelected [1,2,3,5,7,11,14] rootPS < 2^1333 := by decide +kernel

def env41463 : List Nat := [2,4,8,16,1,64,9,256,65,1024,2048,1280,348,340,1296,1299,1280,2388,1024,1297,1344,1093,16,1299,349,64,3140,1109,1109,2049,273,1092,256,1296,260,64]

theorem envBound41463 : H12AffineFastState.Bounded env41463 := by
  intro p hp
  have h : env41463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41462_41463 : H12AffineEnvironment.transform 4 1 env41462 = env41463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41462 == env41463) = true)

theorem identity41463 : scanCanonicalize (H12AffineFastState.compose env41463 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound41463 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env41464 : List Nat := [2,4,8,16,1,64,9,256,65,1024,341,1280,348,340,1296,1299,1280,1,1024,1297,1344,1093,16,1299,349,64,1297,1109,1109,340,273,1092,256,1296,260,64]

theorem envBound41464 : H12AffineFastState.Bounded env41464 := by
  intro p hp
  have h : env41464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41463_41464 : H12AffineEnvironment.transform 10 341 env41463 = env41464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env41463 == env41464) = true)

theorem identity41464 : scanCanonicalize (H12AffineFastState.compose env41464 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 337) := by decide +kernel

theorem selectedBound41464 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env41465 : List Nat := [2,4,8,16,1,64,9,256,65,337,341,81,348,340,65,66,81,1,337,64,17,276,16,66,349,64,64,260,260,340,273,277,256,65,260,64]

theorem envBound41465 : H12AffineFastState.Bounded env41465 := by
  intro p hp
  have h : env41465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41464_41465 : H12AffineEnvironment.transform 9 337 env41464 = env41465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env41464 == env41465) = true)

theorem identity41465 : scanCanonicalize (H12AffineFastState.compose env41465 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound41465 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41466 : List Nat := [2,4,8,16,1,64,9,20,65,69,65,81,72,64,65,66,81,1,69,64,17,0,16,66,73,64,64,16,16,64,5,1,20,65,16,64]

theorem envBound41466 : H12AffineFastState.Bounded env41466 := by
  intro p hp
  have h : env41466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41465_41466 : H12AffineEnvironment.transform 7 20 env41465 = env41466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env41465 == env41466) = true)

theorem identity41466 : scanCanonicalize (H12AffineFastState.compose env41466 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41466 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41467 : List Nat := [2,4,8,16,1,17,9,20,16,20,16,0,25,17,16,19,0,1,20,17,17,0,16,19,24,17,17,16,16,17,5,1,20,16,16,17]

theorem envBound41467 : H12AffineFastState.Bounded env41467 := by
  intro p hp
  have h : env41467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41466_41467 : H12AffineEnvironment.transform 5 17 env41466 = env41467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41466 == env41467) = true)

def env41468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318548,120015,16777216,8328,64,16959642,16880845,102879,464078,16797918,17148373,256,16777250,16834950,16873224]

theorem envBound41468 : H12AffineFastState.Bounded env41468 := by
  intro p hp
  have h : env41468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41426_41468 : H12AffineEnvironment.transform 20 4161 env41426 = env41468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41426 == env41468) = true)

def env41469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4161,62708,120015,16777216,8328,64,16959642,16880845,102879,212078,16797918,16875893,256,16777250,16834950,16873224]

theorem envBound41469 : H12AffineFastState.Bounded env41469 := by
  intro p hp
  have h : env41469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41468_41469 : H12AffineEnvironment.transform 17 10400 env41468 = env41469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env41468 == env41469) = true)

def env41470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62588,119879,16777216,8192,64,16959506,16880709,102743,212078,16797782,16875893,256,16777250,16834830,16873224]

theorem envBound41470 : H12AffineFastState.Bounded env41470 := by
  intro p hp
  have h : env41470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41469_41470 : H12AffineEnvironment.transform 6 8 env41469 = env41470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41469 == env41470) = true)

theorem identity41470 : scanCanonicalize (H12AffineFastState.compose env41470 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound41470 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41471 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,10280,1024,32769,4161,62588,41292,16777216,8192,64,16959506,16834894,58460,149861,16797782,16839806,256,16777250,16834830,16777731]

theorem envBound41471 : H12AffineFastState.Bounded env41471 := by
  intro p hp
  have h : env41471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41470_41471 : H12AffineEnvironment.transform 15 29963 env41470 = env41471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env41470 == env41471) = true)

theorem identity41471 : scanCanonicalize (H12AffineFastState.compose env41471 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 136466) := by decide +kernel

theorem selectedBound41471 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env41472 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,10280,1024,32769,4161,62588,41292,136466,8192,64,56576,193628,58460,149861,148804,188780,256,136496,193564,136977]

theorem envBound41472 : H12AffineFastState.Bounded env41472 := by
  intro p hp
  have h : env41472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41471_41472 : H12AffineEnvironment.transform 23 136466 env41471 = env41472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 136466 env41471 == env41472) = true)

theorem identity41472 : scanCanonicalize (H12AffineFastState.compose env41472 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound41472 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,46156,10280,1024,32769,4161,62588,41292,41310,8192,64,56576,16400,58460,64809,61704,21792,256,41340,16464,41821]

theorem envBound41473 : H12AffineFastState.Bounded env41473 := by
  intro p hp
  have h : env41473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41472_41473 : H12AffineEnvironment.transform 16 46156 env41472 = env41473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env41472 == env41473) = true)

theorem identity41473 : scanCanonicalize (H12AffineFastState.compose env41473 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41473 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env41474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,5392,10280,1024,8541,4161,21792,16,2,8192,64,31836,16400,17664,23669,20564,21792,256,32,16464,513]

theorem envBound41474 : H12AffineFastState.Bounded env41474 := by
  intro p hp
  have h : env41474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41473_41474 : H12AffineEnvironment.transform 14 8540 env41473 = env41474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41473 == env41474) = true)

theorem identity41474 : scanCanonicalize (H12AffineFastState.compose env41474 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7285) := by decide +kernel

theorem selectedBound41474 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41475 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7285,8540,10622,5392,10280,1024,8541,4161,2389,16,2,8192,64,8233,7269,6517,0,3105,2389,256,32,7205,513]

theorem envBound41475 : H12AffineFastState.Bounded env41475 := by
  intro p hp
  have h : env41475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41474_41475 : H12AffineEnvironment.transform 13 7285 env41474 = env41475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7285 env41474 == env41475) = true)

theorem identity41475 : scanCanonicalize (H12AffineFastState.compose env41475 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41475 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41476 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,6501,8540,10622,4096,10280,272,8541,4161,2389,16,2,8192,64,8233,6517,6517,0,2353,2389,256,32,6453,513]

theorem envBound41476 : H12AffineFastState.Bounded env41476 := by
  intro p hp
  have h : env41476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41475_41476 : H12AffineEnvironment.transform 9 272 env41475 = env41476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41475 == env41476) = true)

theorem identity41476 : scanCanonicalize (H12AffineFastState.compose env41476 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound41476 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env41477 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,121,6501,293,2311,4096,2129,272,292,4161,2389,16,2,121,64,80,6517,6517,0,2353,2389,256,32,6453,513]

theorem envBound41477 : H12AffineFastState.Bounded env41477 := by
  intro p hp
  have h : env41477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41476_41477 : H12AffineEnvironment.transform 12 121 env41476 = env41477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env41476 == env41477) = true)

theorem identity41477 : scanCanonicalize (H12AffineFastState.compose env41477 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41477 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env41478 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,16,121,2421,293,2311,16,2129,272,292,81,2389,16,2,121,64,80,2405,2405,0,2353,2389,256,32,2341,513]

theorem envBound41478 : H12AffineFastState.Bounded env41478 := by
  intro p hp
  have h : env41478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41477_41478 : H12AffineEnvironment.transform 11 16 env41477 = env41478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41477 == env41478) = true)

theorem identity41478 : scanCanonicalize (H12AffineFastState.compose env41478 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound41478 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env41479 : List Nat := [2,4,8,16,32,1,8,256,512,272,2048,16,56,2356,293,2311,16,2064,272,292,16,2324,16,2,56,1,17,2340,2340,0,2353,2324,256,32,2341,513]

theorem envBound41479 : H12AffineFastState.Bounded env41479 := by
  intro p hp
  have h : env41479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41478_41479 : H12AffineEnvironment.transform 5 1 env41478 = env41479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41478 == env41479) = true)

theorem identity41479 : scanCanonicalize (H12AffineFastState.compose env41479 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound41479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41480 : List Nat := [2,4,8,16,32,1,8,53,512,37,2048,16,56,2049,16,2098,16,2064,37,17,16,2081,16,2,56,1,17,2065,2065,0,2052,2081,53,32,2064,513]

theorem envBound41480 : H12AffineFastState.Bounded env41480 := by
  intro p hp
  have h : env41480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41479_41480 : H12AffineEnvironment.transform 7 53 env41479 = env41480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env41479 == env41480) = true)

theorem identity41480 : scanCanonicalize (H12AffineFastState.compose env41480 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41481 : List Nat := [2,4,8,16,0,1,8,21,512,5,2048,16,24,2049,16,2066,16,2064,5,17,16,2049,16,2,24,1,17,2065,2065,0,2052,2049,21,0,2064,513]

theorem envBound41481 : H12AffineFastState.Bounded env41481 := by
  intro p hp
  have h : env41481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41480_41481 : H12AffineEnvironment.transform 4 0 env41480 = env41481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41480 == env41481) = true)

theorem identity41481 : scanCanonicalize (H12AffineFastState.compose env41481 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound41481 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41482 : List Nat := [2,4,8,16,0,1,8,21,16,5,2048,16,24,2049,16,2066,16,2064,5,17,16,2049,16,2,24,1,17,2065,2065,0,2052,2049,21,0,2064,17]

theorem envBound41482 : H12AffineFastState.Bounded env41482 := by
  intro p hp
  have h : env41482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41481_41482 : H12AffineEnvironment.transform 8 16 env41481 = env41482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41481 == env41482) = true)

theorem identity41482 : scanCanonicalize (H12AffineFastState.compose env41482 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound41482 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41483 : List Nat := [2,4,8,16,0,1,8,21,16,5,16,16,24,17,16,2,16,0,5,17,16,17,16,2,24,1,17,1,1,0,20,17,21,0,0,17]

theorem envBound41483 : H12AffineFastState.Bounded env41483 := by
  intro p hp
  have h : env41483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41482_41483 : H12AffineEnvironment.transform 10 16 env41482 = env41483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env41482 == env41483) = true)

theorem identity41483 : scanCanonicalize (H12AffineFastState.compose env41483 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41483 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41484 : List Nat := [2,4,8,1,0,1,8,4,1,5,1,1,9,0,1,2,1,0,5,0,1,0,1,2,9,1,0,1,1,0,5,0,4,0,0,0]

theorem envBound41484 : H12AffineFastState.Bounded env41484 := by
  intro p hp
  have h : env41484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41483_41484 : H12AffineEnvironment.transform 3 1 env41483 = env41484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41483 == env41484) = true)

def env41485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62589,119878,16777216,8193,64,16959507,16880708,102742,212078,16797783,16875893,256,16777250,16834831,16873224]

theorem envBound41485 : H12AffineFastState.Bounded env41485 := by
  intro p hp
  have h : env41485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41469_41485 : H12AffineEnvironment.transform 6 9 env41469 = env41485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41469 == env41485) = true)

theorem identity41485 : scanCanonicalize (H12AffineFastState.compose env41485 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound41485 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,4161,62589,16,16777216,8193,64,16959507,16793618,17664,190520,16797783,16799011,256,16777250,16834831,16819038]

theorem envBound41486 : H12AffineFastState.Bounded env41486 := by
  intro p hp
  have h : env41486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41485_41486 : H12AffineEnvironment.transform 15 54358 env41485 = env41486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env41485 == env41486) = true)

theorem identity41486 : scanCanonicalize (H12AffineFastState.compose env41486 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound41486 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env41487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46157,10281,1024,32769,4161,62589,16,16777216,8193,64,16809054,16793618,17664,23669,16797783,16799011,256,16777250,16834831,16819038]

theorem envBound41487 : H12AffineFastState.Bounded env41487 := by
  intro p hp
  have h : env41487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41486_41487 : H12AffineEnvironment.transform 16 46157 env41486 = env41487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env41486 == env41487) = true)

theorem identity41487 : scanCanonicalize (H12AffineFastState.compose env41487 (packedSelected [1,2,3,5,6,7,8,9,10,11,18,19,20,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 33142) := by decide +kernel

theorem selectedBound41487 : packedSelected [1,2,3,5,6,7,8,9,10,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env41488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46157,10281,1024,32769,4161,62589,16,33142,8193,64,64808,49508,17664,23669,53537,54357,256,33108,24697,8744]

theorem envBound41488 : H12AffineFastState.Bounded env41488 := by
  intro p hp
  have h : env41488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41487_41488 : H12AffineEnvironment.transform 23 33142 env41487 = env41488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 33142 env41487 == env41488) = true)

theorem identity41488 : scanCanonicalize (H12AffineFastState.compose env41488 (packedSelected [0,1,7,8,9,14,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound41488 : packedSelected [0,1,7,8,9,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env41489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9293,28699,4096,10281,1024,9292,4161,20528,16,9531,8193,64,22885,25897,17664,23669,30060,28696,256,9497,24697,8744]

theorem envBound41489 : H12AffineFastState.Bounded env41489 := by
  intro p hp
  have h : env41489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41488_41489 : H12AffineEnvironment.transform 14 9293 env41488 = env41489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env41488 == env41489) = true)

theorem identity41489 : scanCanonicalize (H12AffineFastState.compose env41489 (packedSelected [2,3,4,8,9,12,15,16,19,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound41489 : packedSelected [2,3,4,8,9,12,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env41490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13657,9293,1346,4096,10281,1024,9292,4161,9577,16,9531,8193,64,11324,4208,12377,10540,53,1345,256,9497,5408,8744]

theorem envBound41490 : H12AffineFastState.Bounded env41490 := by
  intro p hp
  have h : env41490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41489_41490 : H12AffineEnvironment.transform 13 13657 env41489 = env41490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env41489 == env41490) = true)

theorem identity41490 : scanCanonicalize (H12AffineFastState.compose env41490 (packedSelected [1,2,4,6,8,9,11,14,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound41490 : packedSelected [1,2,4,6,8,9,11,14,19,20,23] rootPS < 2^1333 := by decide +kernel

def env41491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5236,1376,1346,4096,2308,1024,1377,4161,1092,16,1046,300,64,3345,4208,4468,2049,53,1345,256,1076,5408,773]

theorem envBound41491 : H12AffineFastState.Bounded env41491 := by
  intro p hp
  have h : env41491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41490_41491 : H12AffineEnvironment.transform 12 301 env41490 = env41491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env41490 == env41491) = true)

def env41492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4161,62709,120015,16777216,8328,64,16959642,16880845,102879,212079,16797918,16875892,256,16777250,16834950,16873224]

theorem envBound41492 : H12AffineFastState.Bounded env41492 := by
  intro p hp
  have h : env41492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41468_41492 : H12AffineEnvironment.transform 17 10401 env41468 = env41492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env41468 == env41492) = true)

def env41493 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62589,119879,16777216,8192,64,16959506,16880709,102743,212079,16797782,16875892,256,16777250,16834830,16873224]

theorem envBound41493 : H12AffineFastState.Bounded env41493 := by
  intro p hp
  have h : env41493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41492_41493 : H12AffineEnvironment.transform 6 8 env41492 = env41493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41492 == env41493) = true)

theorem identity41493 : scanCanonicalize (H12AffineFastState.compose env41493 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41493 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,4161,21793,95515,16777216,8192,64,16935246,16856345,77835,212079,16797782,16850984,256,16777250,16793682,16873224]

theorem envBound41494 : H12AffineFastState.Bounded env41494 := by
  intro p hp
  have h : env41494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41493_41494 : H12AffineEnvironment.transform 14 8540 env41493 = env41494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41493 == env41494) = true)

theorem identity41494 : scanCanonicalize (H12AffineFastState.compose env41494 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound41494 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env41495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,4161,21793,95515,95497,8192,64,203847,16400,77835,212079,75103,21793,256,95531,79195,513]

theorem envBound41495 : H12AffineFastState.Bounded env41495 := by
  intro p hp
  have h : env41495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41494_41495 : H12AffineEnvironment.transform 23 95497 env41494 = env41495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env41494 == env41495) = true)

theorem identity41495 : scanCanonicalize (H12AffineFastState.compose env41495 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound41495 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10281,1024,8541,4161,21793,95515,95497,8192,64,31836,16400,77835,23668,75103,21793,256,95531,79195,513]

theorem envBound41496 : H12AffineFastState.Bounded env41496 := by
  intro p hp
  have h : env41496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41495_41496 : H12AffineEnvironment.transform 16 90139 env41495 = env41496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env41495 == env41496) = true)

theorem identity41496 : scanCanonicalize (H12AffineFastState.compose env41496 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound41496 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28699,4096,10281,1024,8541,4161,21793,1280,1298,8192,64,31836,16400,16400,23668,21828,21793,256,1328,17728,513]

theorem envBound41497 : H12AffineFastState.Bounded env41497 := by
  intro p hp
  have h : env41497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41496_41497 : H12AffineEnvironment.transform 15 28699 env41496 = env41497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env41496 == env41497) = true)

theorem identity41497 : scanCanonicalize (H12AffineFastState.compose env41497 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 10509) := by decide +kernel

theorem selectedBound41497 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env41498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10509,8540,6422,4096,10281,1024,8541,4161,15404,1280,1298,8192,64,5457,10525,10525,13689,15433,15404,256,1328,11341,513]

theorem envBound41498 : H12AffineFastState.Bounded env41498 := by
  intro p hp
  have h : env41498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41497_41498 : H12AffineEnvironment.transform 13 10509 env41497 = env41498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10509 env41497 == env41498) = true)

def env41499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62588,119878,16777216,8193,64,16959507,16880708,102742,212079,16797783,16875892,256,16777250,16834831,16873224]

theorem envBound41499 : H12AffineFastState.Bounded env41499 := by
  intro p hp
  have h : env41499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41492_41499 : H12AffineEnvironment.transform 6 9 env41492 = env41499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41492 == env41499) = true)

def env41500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62588,119878,95496,8193,64,245019,57676,102742,212079,75103,62588,256,95530,103431,512]

theorem envBound41500 : H12AffineFastState.Bounded env41500 := by
  intro p hp
  have h : env41500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41499_41500 : H12AffineEnvironment.transform 23 95496 env41499 = env41500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env41499 == env41500) = true)

theorem identity41500 : scanCanonicalize (H12AffineFastState.compose env41500 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound41500 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,10280,1024,32769,4161,62588,41293,3,8193,64,182288,57676,58461,149860,20564,62588,256,33,57612,512]

theorem envBound41501 : H12AffineFastState.Bounded env41501 := by
  intro p hp
  have h : env41501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41500_41501 : H12AffineEnvironment.transform 15 29963 env41500 = env41501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env41500 == env41501) = true)

theorem identity41501 : scanCanonicalize (H12AffineFastState.compose env41501 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 58380) := by decide +kernel

theorem selectedBound41501 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env41502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,58380,10280,1024,32769,4161,62588,41293,3,8193,64,11292,57676,58461,44392,20564,62588,256,33,57612,512]

theorem envBound41502 : H12AffineFastState.Bounded env41502 := by
  intro p hp
  have h : env41502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41501_41502 : H12AffineEnvironment.transform 16 58380 env41501 = env41502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58380 env41501 == env41502) = true)

theorem identity41502 : scanCanonicalize (H12AffineFastState.compose env41502 (packedSelected [1,2,6,8,10,12,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 22804) := by decide +kernel

theorem selectedBound41502 : packedSelected [1,2,6,8,10,12,16,20] rootPS < 2^1333 := by decide +kernel

def env41503 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,22804,29963,15640,10280,1024,22805,4161,11624,30809,3,8193,64,11292,14424,15689,29820,20564,11624,256,33,14360,512]

theorem envBound41503 : H12AffineFastState.Bounded env41503 := by
  intro p hp
  have h : env41503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41502_41503 : H12AffineEnvironment.transform 14 22804 env41502 = env41503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22804 env41502 == env41503) = true)

theorem identity41503 : scanCanonicalize (H12AffineFastState.compose env41503 (packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound41503 : packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS < 2^1333 := by decide +kernel

def env41504 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,16384,22804,28746,14425,10280,321,22805,4161,10281,30809,3,8193,64,10589,14424,14344,28989,20564,10281,256,33,14360,512]

theorem envBound41504 : H12AffineFastState.Bounded env41504 := by
  intro p hp
  have h : env41504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41503_41504 : H12AffineEnvironment.transform 9 321 env41503 = env41504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env41503 == env41504) = true)

theorem identity41504 : scanCanonicalize (H12AffineFastState.compose env41504 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41504 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env41505 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,16,8192,16384,18692,24666,10313,10280,321,18693,81,10281,26697,3,8193,64,10589,10312,10264,24877,16452,10281,256,33,10248,512]

theorem envBound41505 : H12AffineFastState.Bounded env41505 := by
  intro p hp
  have h : env41505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41504_41505 : H12AffineEnvironment.transform 11 16 env41504 = env41505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41504 == env41505) = true)

theorem identity41505 : scanCanonicalize (H12AffineFastState.compose env41505 (packedSelected [0,2,3,5,6,7,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 10329) := by decide +kernel

theorem selectedBound41505 : packedSelected [0,2,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env41506 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,16,8192,10329,8541,2051,10313,10280,321,8540,81,10281,16,3,8193,64,10589,10312,10264,2420,10269,10281,256,33,10248,512]

theorem envBound41506 : H12AffineFastState.Bounded env41506 := by
  intro p hp
  have h : env41506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41505_41506 : H12AffineEnvironment.transform 13 10329 env41505 = env41506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10329 env41505 == env41506) = true)

theorem identity41506 : scanCanonicalize (H12AffineFastState.compose env41506 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound41506 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41507 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,16,2056,81,2389,2051,65,32,321,2388,81,33,16,3,2057,64,341,64,16,2420,21,33,256,33,0,512]

theorem envBound41507 : H12AffineFastState.Bounded env41507 := by
  intro p hp
  have h : env41507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41506_41507 : H12AffineEnvironment.transform 12 2056 env41506 = env41507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env41506 == env41507) = true)

theorem identity41507 : scanCanonicalize (H12AffineFastState.compose env41507 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound41507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41508 : List Nat := [2,4,8,16,32,64,9,256,512,321,32,16,40,81,373,35,65,32,321,372,81,33,16,3,41,64,341,64,16,340,21,33,256,33,0,512]

theorem envBound41508 : H12AffineFastState.Bounded env41508 := by
  intro p hp
  have h : env41508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41507_41508 : H12AffineEnvironment.transform 10 32 env41507 = env41508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env41507 == env41508) = true)

theorem identity41508 : scanCanonicalize (H12AffineFastState.compose env41508 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound41508 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41509 : List Nat := [2,4,8,16,32,64,9,256,91,321,32,16,40,81,373,35,65,32,321,372,81,33,16,3,41,64,341,64,16,340,21,33,256,33,0,91]

theorem envBound41509 : H12AffineFastState.Bounded env41509 := by
  intro p hp
  have h : env41509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41508_41509 : H12AffineEnvironment.transform 8 91 env41508 = env41509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env41508 == env41509) = true)

theorem identity41509 : scanCanonicalize (H12AffineFastState.compose env41509 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41509 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41510 : List Nat := [2,4,8,16,0,64,9,256,91,321,0,16,8,81,341,3,65,0,321,340,81,1,16,3,9,64,341,64,16,340,21,1,256,1,0,91]

theorem envBound41510 : H12AffineFastState.Bounded env41510 := by
  intro p hp
  have h : env41510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41509_41510 : H12AffineEnvironment.transform 4 0 env41509 = env41510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41509 == env41510) = true)

theorem identity41510 : scanCanonicalize (H12AffineFastState.compose env41510 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound41510 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41511 : List Nat := [2,4,8,16,0,27,9,256,0,282,0,16,8,10,270,3,26,0,282,271,10,1,16,3,9,27,270,27,16,271,21,1,256,1,0,0]

theorem envBound41511 : H12AffineFastState.Bounded env41511 := by
  intro p hp
  have h : env41511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41510_41511 : H12AffineEnvironment.transform 5 27 env41510 = env41511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env41510 == env41511) = true)

theorem identity41511 : scanCanonicalize (H12AffineFastState.compose env41511 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41511 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41512 : List Nat := [2,4,8,0,0,11,9,256,0,266,0,0,8,10,270,3,10,0,266,271,10,1,0,3,9,11,270,11,0,271,5,1,256,1,0,0]

theorem envBound41512 : H12AffineFastState.Bounded env41512 := by
  intro p hp
  have h : env41512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41511_41512 : H12AffineEnvironment.transform 3 0 env41511 = env41512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41511 == env41512) = true)

theorem identity41512 : scanCanonicalize (H12AffineFastState.compose env41512 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41512 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41513 : List Nat := [0,4,8,0,0,9,9,256,0,264,0,0,8,8,268,1,8,0,264,269,8,1,0,1,9,9,268,9,0,269,5,1,256,1,0,0]

theorem envBound41513 : H12AffineFastState.Bounded env41513 := by
  intro p hp
  have h : env41513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41512_41513 : H12AffineEnvironment.transform 0 0 env41512 = env41513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41512 == env41513) = true)

theorem identity41513 : scanCanonicalize (H12AffineFastState.compose env41513 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41513 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41514 : List Nat := [0,4,8,0,0,9,9,4,0,12,0,0,8,8,8,1,8,0,12,9,8,1,0,1,9,9,8,9,0,9,5,1,4,1,0,0]

theorem envBound41514 : H12AffineFastState.Bounded env41514 := by
  intro p hp
  have h : env41514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41513_41514 : H12AffineEnvironment.transform 7 4 env41513 = env41514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41513 == env41514) = true)

theorem identity41514 : scanCanonicalize (H12AffineFastState.compose env41514 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41514 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41515 : List Nat := [0,4,5,0,0,4,4,4,0,1,0,0,5,5,5,1,5,0,1,4,5,1,0,1,4,4,5,4,0,4,5,1,4,1,0,0]

theorem envBound41515 : H12AffineFastState.Bounded env41515 := by
  intro p hp
  have h : env41515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41514_41515 : H12AffineEnvironment.transform 2 5 env41514 = env41515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41514 == env41515) = true)

def env41516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62588,119878,95497,8193,64,245018,57677,102742,212079,75102,62589,256,95531,103430,513]

theorem envBound41516 : H12AffineFastState.Bounded env41516 := by
  intro p hp
  have h : env41516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41499_41516 : H12AffineEnvironment.transform 23 95497 env41499 = env41516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env41499 == env41516) = true)

theorem identity41516 : scanCanonicalize (H12AffineFastState.compose env41516 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41516 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env41517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1024,8540,4161,21793,95515,95497,8193,64,203847,16400,77835,212079,75102,21792,256,95531,79195,513]

theorem envBound41517 : H12AffineFastState.Bounded env41517 := by
  intro p hp
  have h : env41517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41516_41517 : H12AffineEnvironment.transform 14 8541 env41516 = env41517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41516 == env41517) = true)

theorem identity41517 : scanCanonicalize (H12AffineFastState.compose env41517 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound41517 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env41518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,65536,131072,10280,1024,8540,4161,113,73803,73817,8193,64,203847,5440,77835,212079,75102,112,256,73851,79195,513]

theorem envBound41518 : H12AffineFastState.Bounded env41518 := by
  intro p hp
  have h : env41518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41517_41518 : H12AffineEnvironment.transform 13 5456 env41517 = env41518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env41517 == env41518) = true)

theorem identity41518 : scanCanonicalize (H12AffineFastState.compose env41518 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41518 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env41519 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,65536,131072,10280,1024,8460,4113,33,73755,73737,8193,16,203799,5392,77835,212031,75022,32,256,73771,79115,513]

theorem envBound41519 : H12AffineFastState.Bounded env41519 := by
  intro p hp
  have h : env41519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41518_41519 : H12AffineEnvironment.transform 5 16 env41518 = env41519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41518 == env41519) = true)

theorem identity41519 : scanCanonicalize (H12AffineFastState.compose env41519 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound41519 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41520 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,65536,70678,10280,1024,8460,4113,33,73755,73737,8193,16,2049,5392,77835,10281,75022,32,256,73771,79115,513]

theorem envBound41520 : H12AffineFastState.Bounded env41520 := by
  intro p hp
  have h : env41520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41519_41520 : H12AffineEnvironment.transform 16 70678 env41519 = env41520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env41519 == env41520) = true)

theorem identity41520 : scanCanonicalize (H12AffineFastState.compose env41520 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41520 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41521 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8203,13341,10280,1024,8460,4113,33,16,2,8193,16,2049,5392,4096,10281,1285,32,256,32,5376,513]

theorem envBound41521 : H12AffineFastState.Bounded env41521 := by
  intro p hp
  have h : env41521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41520_41521 : H12AffineEnvironment.transform 15 8203 env41520 = env41521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41520 == env41521) = true)

def env41522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound41522 : H12AffineFastState.Bounded env41522 := by
  intro p hp
  have h : env41522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41320_41522 : H12AffineEnvironment.transform 18 1025 env41320 = env41522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env41320 == env41522) = true)

theorem identity41522 : scanCanonicalize (H12AffineFastState.compose env41522 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2237455) := by decide +kernel

theorem selectedBound41522 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2237455,8328,64,15066127,237698,10507601,8830976,10723358,4407759,257,8642722,8585479,10651593]

theorem envBound41523 : H12AffineFastState.Bounded env41523 := by
  intro p hp
  have h : env41523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41522_41523 : H12AffineEnvironment.transform 23 2237455 env41522 = env41523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2237455 env41522 == env41523) = true)

def env41524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15066127,115150,10507601,8692044,10600786,4268163,257,8487406,8478795,10544773]

theorem envBound41524 : H12AffineFastState.Bounded env41524 := by
  intro p hp
  have h : env41524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41523_41524 : H12AffineEnvironment.transform 16 24908 env41523 = env41524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env41523 == env41524) = true)

def env41525 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,8388608,2114835,8328,16,15066127,115102,10507521,8691996,10600706,4268163,257,8487358,8478747,10544773]

theorem envBound41525 : H12AffineFastState.Bounded env41525 := by
  intro p hp
  have h : env41525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41524_41525 : H12AffineEnvironment.transform 5 16 env41524 = env41525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41524 == env41525) = true)

theorem identity41525 : scanCanonicalize (H12AffineFastState.compose env41525 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(22+1) ^^^ 2155532) := by decide +kernel

theorem selectedBound41525 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env41526 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,2155532,2114835,8328,16,4521987,115102,45325,2376976,75022,4268163,257,2188722,2196503,649]

theorem envBound41526 : H12AffineFastState.Bounded env41526 := by
  intro p hp
  have h : env41526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41525_41526 : H12AffineEnvironment.transform 22 2155532 env41525 = env41526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155532 env41525 == env41526) = true)

def env41527 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,2114864,2155532,2114835,8328,16,2442547,115102,45325,2376976,75022,2188723,257,2188722,2196503,649]

theorem envBound41527 : H12AffineFastState.Bounded env41527 := by
  intro p hp
  have h : env41527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41526_41527 : H12AffineEnvironment.transform 21 2114864 env41526 = env41527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114864 env41526 == env41527) = true)

theorem identity41527 : scanCanonicalize (H12AffineFastState.compose env41527 (packedSelected [10,11,15,17,18,19,21,23,26,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41527 : packedSelected [10,11,15,17,18,19,21,23,26,31,32,38] rootPS < 2^1333 := by decide +kernel

def env41528 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,2114864,2155532,2114835,8328,16,2190619,115102,45325,2125112,75022,2188723,257,2188722,2196503,649]

theorem envBound41528 : H12AffineFastState.Bounded env41528 := by
  intro p hp
  have h : env41528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41527_41528 : H12AffineEnvironment.transform 17 10280 env41527 = env41528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41527 == env41528) = true)

theorem identity41528 : scanCanonicalize (H12AffineFastState.compose env41528 (packedSelected [0,2,6,7,11,17,18,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41528 : packedSelected [0,2,6,7,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env41529 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,2114864,2155532,2114835,8192,16,2190619,114966,45325,2125112,75022,2188603,257,2188602,2196503,513]

theorem envBound41529 : H12AffineFastState.Bounded env41529 := by
  intro p hp
  have h : env41529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41528_41529 : H12AffineEnvironment.transform 6 8 env41528 = env41529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41528 == env41529) = true)

theorem identity41529 : scanCanonicalize (H12AffineFastState.compose env41529 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(20+1) ^^^ 91419) := by decide +kernel

theorem selectedBound41529 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41530 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,91419,73771,98583,73736,8192,16,2048,114966,45325,67619,75022,32,257,33,57612,513]

theorem envBound41530 : H12AffineFastState.Bounded env41530 := by
  intro p hp
  have h : env41530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41529_41530 : H12AffineEnvironment.transform 20 91419 env41529 = env41530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91419 env41529 == env41530) = true)

theorem identity41530 : scanCanonicalize (H12AffineFastState.compose env41530 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound41530 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41531 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33030,24860,10280,1025,32769,58397,41261,17,41230,8192,16,2048,16400,45325,35109,41992,32,257,33,57612,513]

theorem envBound41531 : H12AffineFastState.Bounded env41531 := by
  intro p hp
  have h : env41531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41530_41531 : H12AffineEnvironment.transform 15 33030 env41530 = env41531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env41530 == env41531) = true)

theorem identity41531 : scanCanonicalize (H12AffineFastState.compose env41531 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound41531 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env41532 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,8203,24860,10280,1025,8460,17680,32,17,3,8192,16,2048,16400,4096,10280,1285,32,257,33,16385,513]

theorem envBound41532 : H12AffineFastState.Bounded env41532 := by
  intro p hp
  have h : env41532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41531_41532 : H12AffineEnvironment.transform 14 8461 env41531 = env41532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env41531 == env41532) = true)

theorem identity41532 : scanCanonicalize (H12AffineFastState.compose env41532 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound41532 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41533 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4404,8461,8203,12328,10280,1025,8460,5156,32,17,3,8192,16,2048,4388,4096,10280,1285,32,257,33,4405,513]

theorem envBound41533 : H12AffineFastState.Bounded env41533 := by
  intro p hp
  have h : env41533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41532_41533 : H12AffineEnvironment.transform 13 4404 env41532 = env41533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env41532 == env41533) = true)

theorem identity41533 : scanCanonicalize (H12AffineFastState.compose env41533 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41533 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env41534 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,4404,8461,8203,12328,10280,53,8460,4112,32,17,3,8192,16,2048,4388,4096,10280,305,32,257,33,4405,513]

theorem envBound41534 : H12AffineFastState.Bounded env41534 := by
  intro p hp
  have h : env41534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41533_41534 : H12AffineEnvironment.transform 9 52 env41533 = env41534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41533 == env41534) = true)

theorem identity41534 : scanCanonicalize (H12AffineFastState.compose env41534 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41534 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env41535 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,4096,8192,4372,8461,8203,12296,10248,21,8460,4112,0,17,3,8192,16,2048,4356,4096,10248,273,0,257,1,4373,513]

theorem envBound41535 : H12AffineFastState.Bounded env41535 := by
  intro p hp
  have h : env41535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41534_41535 : H12AffineEnvironment.transform 4 0 env41534 = env41535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41534 == env41535) = true)

theorem identity41535 : scanCanonicalize (H12AffineFastState.compose env41535 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41535 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env41536 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,4096,269,4372,0,262,4357,2309,21,1,4112,0,17,3,269,16,2048,4356,4096,2309,273,0,257,1,4373,513]

theorem envBound41536 : H12AffineFastState.Bounded env41536 := by
  intro p hp
  have h : env41536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41535_41536 : H12AffineEnvironment.transform 12 269 env41535 = env41536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41535 == env41536) = true)

theorem identity41536 : scanCanonicalize (H12AffineFastState.compose env41536 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound41536 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41537 : List Nat := [2,4,8,16,0,16,8,256,512,20,782,4096,269,4372,0,262,4357,523,21,1,4112,0,17,3,269,16,782,4356,4096,523,273,0,257,1,4373,513]

theorem envBound41537 : H12AffineFastState.Bounded env41537 := by
  intro p hp
  have h : env41537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41536_41537 : H12AffineEnvironment.transform 10 782 env41536 = env41537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env41536 == env41537) = true)

theorem identity41537 : scanCanonicalize (H12AffineFastState.compose env41537 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound41537 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41538 : List Nat := [2,4,8,16,0,16,8,256,260,20,10,4096,269,4372,0,262,4357,271,21,1,4112,0,17,3,269,16,10,4356,4096,271,273,0,257,1,4373,261]

theorem envBound41538 : H12AffineFastState.Bounded env41538 := by
  intro p hp
  have h : env41538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41537_41538 : H12AffineEnvironment.transform 8 260 env41537 = env41538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env41537 == env41538) = true)

theorem identity41538 : scanCanonicalize (H12AffineFastState.compose env41538 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound41538 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41539 : List Nat := [2,4,8,16,0,16,8,256,260,20,10,260,269,16,0,262,1,271,21,1,276,0,17,3,269,16,10,0,260,271,273,0,257,1,17,261]

theorem envBound41539 : H12AffineFastState.Bounded env41539 := by
  intro p hp
  have h : env41539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41538_41539 : H12AffineEnvironment.transform 11 260 env41538 = env41539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env41538 == env41539) = true)

theorem identity41539 : scanCanonicalize (H12AffineFastState.compose env41539 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound41539 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41540 : List Nat := [2,4,8,16,0,16,8,9,13,20,10,13,4,16,0,15,1,6,21,1,29,0,17,3,4,16,10,0,13,6,24,0,8,1,17,12]

theorem envBound41540 : H12AffineFastState.Bounded env41540 := by
  intro p hp
  have h : env41540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41539_41540 : H12AffineEnvironment.transform 7 9 env41539 = env41540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env41539 == env41540) = true)

def env41541 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,2114865,2155532,2114835,8328,16,2442546,115102,45325,2376976,75022,2188722,257,2188722,2196503,649]

theorem envBound41541 : H12AffineFastState.Bounded env41541 := by
  intro p hp
  have h : env41541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41526_41541 : H12AffineEnvironment.transform 21 2114865 env41526 = env41541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114865 env41526 == env41541) = true)

theorem identity41541 : scanCanonicalize (H12AffineFastState.compose env41541 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41541 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env41542 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,2114865,2155532,2114835,8192,16,2442546,114966,45325,2376976,75022,2188602,257,2188602,2196503,513]

theorem envBound41542 : H12AffineFastState.Bounded env41542 := by
  intro p hp
  have h : env41542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41541_41542 : H12AffineEnvironment.transform 6 8 env41541 = env41542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41541 == env41542) = true)

theorem identity41542 : scanCanonicalize (H12AffineFastState.compose env41542 (packedSelected [0,7,16,19,21,26] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound41542 : packedSelected [0,7,16,19,21,26] rootPS < 2^1333 := by decide +kernel

def env41543 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,35108,1025,32769,2097152,2114865,2155532,2114835,8192,16,2214934,114966,45325,2149428,75022,2188602,257,2188602,2196503,513]

theorem envBound41543 : H12AffineFastState.Bounded env41543 := by
  intro p hp
  have h : env41543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41542_41543 : H12AffineEnvironment.transform 17 35108 env41542 = env41543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env41542 == env41543) = true)

theorem identity41543 : scanCanonicalize (H12AffineFastState.compose env41543 (packedSelected [3,4,5,9,10,11,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 15406) := by decide +kernel

theorem selectedBound41543 : packedSelected [3,4,5,9,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41544 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,15406,24860,35108,1025,32769,2097152,2114865,2155532,2114835,8192,16,2158648,64824,45325,2149428,6432,2119956,257,2119956,2144313,513]

theorem envBound41544 : H12AffineFastState.Bounded env41544 := by
  intro p hp
  have h : env41544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41543_41544 : H12AffineEnvironment.transform 15 15406 env41543 = env41544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15406 env41543 == env41544) = true)

theorem identity41544 : scanCanonicalize (H12AffineFastState.compose env41544 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 15657) := by decide +kernel

theorem selectedBound41544 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env41545 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,15657,15406,24860,13325,1025,15656,2097152,2114865,2119973,2114835,8192,16,2116881,16401,3108,2126109,6432,2119956,257,2119956,2098448,513]

theorem envBound41545 : H12AffineFastState.Bounded env41545 := by
  intro p hp
  have h : env41545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41544_41545 : H12AffineEnvironment.transform 14 15657 env41544 = env41545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15657 env41544 == env41545) = true)

theorem identity41545 : scanCanonicalize (H12AffineFastState.compose env41545 (packedSelected [1,2,3,4,5,6,8,9,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 7464) := by decide +kernel

theorem selectedBound41545 : packedSelected [1,2,3,4,5,6,8,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env41546 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7464,16384,1,262,23604,2341,1025,0,2097152,2114865,2119973,2114835,7464,16,2116881,16401,3108,2116661,6432,2119956,257,2119956,2098448,513]

theorem envBound41546 : H12AffineFastState.Bounded env41546 := by
  intro p hp
  have h : env41546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41545_41546 : H12AffineEnvironment.transform 12 7464 env41545 = env41546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7464 env41545 == env41546) = true)

theorem identity41546 : scanCanonicalize (H12AffineFastState.compose env41546 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound41546 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41547 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,268,16384,1,262,16400,2341,1025,0,2097152,2114865,2114817,2114835,268,16,2116881,16401,3108,2116661,1284,2114864,257,2114864,2098448,513]

theorem envBound41547 : H12AffineFastState.Bounded env41547 := by
  intro p hp
  have h : env41547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41546_41547 : H12AffineEnvironment.transform 11 3108 env41546 = env41547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env41546 == env41547) = true)

theorem identity41547 : scanCanonicalize (H12AffineFastState.compose env41547 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound41547 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41548 : List Nat := [2,4,8,16,32,16,8,256,512,1024,270,1322,268,16384,1,262,16400,43,1025,0,2097152,2114865,2114817,2114835,268,16,2114591,16401,1322,2114875,1284,2114864,257,2114864,2098448,513]

theorem envBound41548 : H12AffineFastState.Bounded env41548 := by
  intro p hp
  have h : env41548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41547_41548 : H12AffineEnvironment.transform 10 270 env41547 = env41548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env41547 == env41548) = true)

theorem identity41548 : scanCanonicalize (H12AffineFastState.compose env41548 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound41548 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env41549 : List Nat := [2,4,8,16,32,16,8,63,512,1024,49,1045,51,16384,1,57,16400,43,1025,0,2097152,2114574,2114622,2114604,51,16,2114591,16401,1045,2114564,1083,2114575,62,2114575,2098223,513]

theorem envBound41549 : H12AffineFastState.Bounded env41549 := by
  intro p hp
  have h : env41549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41548_41549 : H12AffineEnvironment.transform 7 63 env41548 = env41549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env41548 == env41549) = true)

theorem identity41549 : scanCanonicalize (H12AffineFastState.compose env41549 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 1044) := by decide +kernel

theorem selectedBound41549 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env41550 : List Nat := [2,4,8,16,32,16,8,63,512,1024,49,1045,51,1044,1,57,1028,43,1025,0,2097152,2097178,2097194,2097208,51,16,2097163,1029,1045,2097168,1083,2097179,62,2097179,2098223,513]

theorem envBound41550 : H12AffineFastState.Bounded env41550 := by
  intro p hp
  have h : env41550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41549_41550 : H12AffineEnvironment.transform 13 1044 env41549 = env41550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1044 env41549 == env41550) = true)

theorem identity41550 : scanCanonicalize (H12AffineFastState.compose env41550 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41550 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env41551 : List Nat := [2,4,8,16,32,16,8,63,512,53,49,32,51,33,1,57,49,43,52,0,2097152,2097178,2097194,2097208,51,16,2097163,48,32,2097168,14,2097179,62,2097179,2097178,513]

theorem envBound41551 : H12AffineFastState.Bounded env41551 := by
  intro p hp
  have h : env41551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41550_41551 : H12AffineEnvironment.transform 9 53 env41550 = env41551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41550 == env41551) = true)

theorem identity41551 : scanCanonicalize (H12AffineFastState.compose env41551 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 43) := by decide +kernel

theorem selectedBound41551 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41552 : List Nat := [2,4,8,16,32,16,8,63,512,53,49,32,51,33,1,57,49,43,52,0,43,49,1,19,51,16,32,48,32,59,14,48,62,48,49,513]

theorem envBound41552 : H12AffineFastState.Bounded env41552 := by
  intro p hp
  have h : env41552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41551_41552 : H12AffineEnvironment.transform 20 43 env41551 = env41552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 43 env41551 == env41552) = true)

theorem identity41552 : scanCanonicalize (H12AffineFastState.compose env41552 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41552 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41553 : List Nat := [2,4,8,10,32,10,8,37,512,47,43,32,41,33,1,35,43,43,46,0,43,43,1,9,41,10,32,42,32,33,14,42,36,42,43,513]

theorem envBound41553 : H12AffineFastState.Bounded env41553 := by
  intro p hp
  have h : env41553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41552_41553 : H12AffineEnvironment.transform 3 10 env41552 = env41553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41552 == env41553) = true)

theorem identity41553 : scanCanonicalize (H12AffineFastState.compose env41553 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound41553 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env41554 : List Nat := [2,4,8,10,32,10,8,37,46,47,43,32,41,33,1,35,43,43,46,0,43,43,1,9,41,10,32,42,32,33,14,42,36,42,43,47]

theorem envBound41554 : H12AffineFastState.Bounded env41554 := by
  intro p hp
  have h : env41554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41553_41554 : H12AffineEnvironment.transform 8 46 env41553 = env41554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env41553 == env41554) = true)

theorem identity41554 : scanCanonicalize (H12AffineFastState.compose env41554 (packedSelected [0,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41554 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env41555 : List Nat := [1,4,8,9,32,9,8,37,45,44,40,32,41,33,1,32,40,40,45,0,40,40,1,9,41,9,32,41,32,33,13,41,36,41,40,44]

theorem envBound41555 : H12AffineFastState.Bounded env41555 := by
  intro p hp
  have h : env41555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41554_41555 : H12AffineEnvironment.transform 0 1 env41554 = env41555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41554 == env41555) = true)

theorem identity41555 : scanCanonicalize (H12AffineFastState.compose env41555 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound41555 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env41556 : List Nat := [1,4,8,9,8,9,8,13,5,4,0,8,1,9,1,8,0,0,5,0,0,0,1,9,1,9,8,1,8,9,13,1,12,1,0,4]

theorem envBound41556 : H12AffineFastState.Bounded env41556 := by
  intro p hp
  have h : env41556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41555_41556 : H12AffineEnvironment.transform 4 8 env41555 = env41556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env41555 == env41556) = true)

theorem identity41556 : scanCanonicalize (H12AffineFastState.compose env41556 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41557 : List Nat := [1,4,1,0,1,0,1,4,5,4,0,1,1,0,1,1,0,0,5,0,0,0,1,0,1,0,1,1,1,0,4,1,5,1,0,4]

theorem envBound41557 : H12AffineFastState.Bounded env41557 := by
  intro p hp
  have h : env41557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41556_41557 : H12AffineEnvironment.transform 2 1 env41556 = env41557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41556 == env41557) = true)

def env41558 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,8388608,2114834,8328,17,15066127,115103,10507520,8691997,10600707,4268163,257,8487359,8478746,10544773]

theorem envBound41558 : H12AffineFastState.Bounded env41558 := by
  intro p hp
  have h : env41558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41524_41558 : H12AffineEnvironment.transform 5 17 env41524 = env41558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41524 == env41558) = true)

theorem identity41558 : scanCanonicalize (H12AffineFastState.compose env41558 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(22+1) ^^^ 2411556) := by decide +kernel

theorem selectedBound41558 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env41559 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,2411556,2114834,8328,17,4270123,115103,301348,2125113,331047,4268163,257,2444699,2468926,273057]

theorem envBound41559 : H12AffineFastState.Bounded env41559 := by
  intro p hp
  have h : env41559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41558_41559 : H12AffineEnvironment.transform 22 2411556 env41558 = env41559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2411556 env41558 == env41559) = true)

def env41560 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,32,2411556,2114834,8328,17,75787,115103,301348,2125113,331047,73891,257,2444699,2468926,273057]

theorem envBound41560 : H12AffineFastState.Bounded env41560 := by
  intro p hp
  have h : env41560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41559_41560 : H12AffineEnvironment.transform 21 32 env41559 = env41560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env41559 == env41560) = true)

theorem identity41560 : scanCanonicalize (H12AffineFastState.compose env41560 (packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 322873) := by decide +kernel

theorem selectedBound41560 : packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env41561 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,322873,32,8477,305195,8328,17,75787,115103,301348,294912,331047,73891,257,106658,82183,273057]

theorem envBound41561 : H12AffineFastState.Bounded env41561 := by
  intro p hp
  have h : env41561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41560_41561 : H12AffineEnvironment.transform 20 322873 env41560 = env41561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 322873 env41560 == env41561) = true)

theorem identity41561 : scanCanonicalize (H12AffineFastState.compose env41561 (packedSelected [0,1,4,7,8,9,10,11,15,16,19,21,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound41561 : packedSelected [0,1,4,7,8,9,10,11,15,16,19,21,26] rootPS < 2^1333 := by decide +kernel

def env41562 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8322,24861,262144,1025,32769,322873,32,8477,305195,8328,17,2185,57629,301348,294912,273829,33,257,32800,24965,273057]

theorem envBound41562 : H12AffineFastState.Bounded env41562 := by
  intro p hp
  have h : env41562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41561_41562 : H12AffineEnvironment.transform 15 8322 env41561 = env41562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env41561 == env41562) = true)

theorem identity41562 : scanCanonicalize (H12AffineFastState.compose env41562 (packedSelected [11,12,15,16,17,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41562 : packedSelected [11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env41563 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,8322,24861,262144,1025,1,290105,32,8477,272427,8328,17,2185,24861,268580,262144,273829,33,257,32,24965,273057]

theorem envBound41563 : H12AffineFastState.Bounded env41563 := by
  intro p hp
  have h : env41563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41562_41563 : H12AffineEnvironment.transform 14 0 env41562 = env41563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41562 == env41563) = true)

theorem identity41563 : scanCanonicalize (H12AffineFastState.compose env41563 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound41563 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env41564 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,8322,24861,2340,1025,1,25629,32,8477,8463,8328,17,2185,24861,4096,2340,9345,33,257,32,24965,9093]

theorem envBound41564 : H12AffineFastState.Bounded env41564 := by
  intro p hp
  have h : env41564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41563_41564 : H12AffineEnvironment.transform 17 2340 env41563 = env41564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env41563 == env41564) = true)

theorem identity41564 : scanCanonicalize (H12AffineFastState.compose env41564 (packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41564 : packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41565 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,8203,24861,2340,1025,1,25629,32,8477,8463,8193,17,2048,24861,4096,2340,9224,33,257,32,24844,8972]

theorem envBound41565 : H12AffineFastState.Bounded env41565 := by
  intro p hp
  have h : env41565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41564_41565 : H12AffineEnvironment.transform 6 9 env41564 = env41565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41564 == env41565) = true)

theorem identity41565 : scanCanonicalize (H12AffineFastState.compose env41565 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 4372) := by decide +kernel

theorem selectedBound41565 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env41566 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,4372,0,8203,12297,2340,1025,1,13577,32,8477,8463,8193,17,2048,12297,4096,2340,9224,33,257,32,12312,8972]

theorem envBound41566 : H12AffineFastState.Bounded env41566 := by
  intro p hp
  have h : env41566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41565_41566 : H12AffineEnvironment.transform 13 4372 env41565 = env41566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4372 env41565 == env41566) = true)

theorem identity41566 : scanCanonicalize (H12AffineFastState.compose env41566 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound41566 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env41567 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,4372,0,8203,12297,2340,305,1,12345,32,8477,8463,8193,17,2048,12297,4096,2340,8504,33,257,32,12312,8972]

theorem envBound41567 : H12AffineFastState.Bounded env41567 := by
  intro p hp
  have h : env41567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41566_41567 : H12AffineEnvironment.transform 9 304 env41566 = env41567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env41566 == env41567) = true)

theorem identity41567 : scanCanonicalize (H12AffineFastState.compose env41567 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound41567 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41568 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,301,4372,0,294,4388,2340,305,1,4372,32,48,34,300,17,2048,4388,4096,2340,21,33,257,32,4405,545]

theorem envBound41568 : H12AffineFastState.Bounded env41568 := by
  intro p hp
  have h : env41568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41567_41568 : H12AffineEnvironment.transform 12 301 env41567 = env41568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env41567 == env41568) = true)

theorem identity41568 : scanCanonicalize (H12AffineFastState.compose env41568 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41568 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41569 : List Nat := [2,4,8,16,32,17,9,5,512,53,2048,4096,40,4113,0,35,4129,2081,52,1,4113,32,48,34,41,17,2048,4129,4096,2081,21,33,4,32,4144,545]

theorem envBound41569 : H12AffineFastState.Bounded env41569 := by
  intro p hp
  have h : env41569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41568_41569 : H12AffineEnvironment.transform 7 5 env41568 = env41569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41568 == env41569) = true)

theorem identity41569 : scanCanonicalize (H12AffineFastState.compose env41569 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound41569 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env41570 : List Nat := [2,4,8,16,32,17,9,5,512,53,560,4096,40,4113,0,35,4129,529,52,1,4113,32,48,34,41,17,560,4129,4096,529,21,33,4,32,4144,545]

theorem envBound41570 : H12AffineFastState.Bounded env41570 := by
  intro p hp
  have h : env41570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41569_41570 : H12AffineEnvironment.transform 10 560 env41569 = env41570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env41569 == env41570) = true)

theorem identity41570 : scanCanonicalize (H12AffineFastState.compose env41570 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound41570 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env41571 : List Nat := [2,4,8,16,32,17,9,5,512,53,560,529,40,512,0,35,560,529,52,1,512,32,48,34,41,17,560,560,529,529,21,33,4,32,545,545]

theorem envBound41571 : H12AffineFastState.Bounded env41571 := by
  intro p hp
  have h : env41571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41570_41571 : H12AffineEnvironment.transform 11 529 env41570 = env41571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env41570 == env41571) = true)

theorem identity41571 : scanCanonicalize (H12AffineFastState.compose env41571 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41571 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env41572 : List Nat := [2,4,8,16,32,17,9,5,1,53,49,16,40,1,0,35,49,16,52,1,1,32,48,34,41,17,49,49,16,16,21,33,4,32,32,32]

theorem envBound41572 : H12AffineFastState.Bounded env41572 := by
  intro p hp
  have h : env41572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41571_41572 : H12AffineEnvironment.transform 8 1 env41571 = env41572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41571 == env41572) = true)

theorem identity41572 : scanCanonicalize (H12AffineFastState.compose env41572 (packedSelected [0,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41572 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env41573 : List Nat := [2,4,8,1,32,0,9,5,1,36,32,1,40,1,0,35,32,1,37,1,1,32,33,34,41,0,32,32,1,1,4,33,4,32,32,32]

end H12CloudChart0