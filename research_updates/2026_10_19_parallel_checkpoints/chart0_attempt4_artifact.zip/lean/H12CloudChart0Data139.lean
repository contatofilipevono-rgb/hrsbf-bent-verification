import H12CloudChart0Data138

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env35278 : List Nat := [2,4,8,16,32,16,9,256,512,52,293,17,41,293,1,35,16,293,53,0,292,32,308,295,40,16,0,17,16,292,20,32,257,33,0,804]

theorem envBound35278 : H12AffineFastState.Bounded env35278 := by
  intro p hp
  have h : env35278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35277_35278 : H12AffineEnvironment.transform 9 52 env35277 = env35278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35277 == env35278) = true)

theorem identity35278 : scanCanonicalize (H12AffineFastState.compose env35278 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35278 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env35279 : List Nat := [2,4,8,16,32,16,9,256,1,52,293,17,41,293,1,35,16,293,53,0,292,32,308,295,40,16,0,17,16,292,20,32,257,33,0,293]

theorem envBound35279 : H12AffineFastState.Bounded env35279 := by
  intro p hp
  have h : env35279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35278_35279 : H12AffineEnvironment.transform 8 1 env35278 = env35279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35278 == env35279) = true)

theorem identity35279 : scanCanonicalize (H12AffineFastState.compose env35279 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35279 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35280 : List Nat := [2,4,8,16,32,16,9,37,1,52,0,17,41,0,1,35,16,0,53,0,1,32,17,2,40,16,0,17,16,1,20,32,36,33,0,0]

theorem envBound35280 : H12AffineFastState.Bounded env35280 := by
  intro p hp
  have h : env35280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35279_35280 : H12AffineEnvironment.transform 7 37 env35279 = env35280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35279 == env35280) = true)

def env35281 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,262144,1025,32769,58516,272512,62612,41351,8328,17,100614,115102,17665,262145,119042,329731,257,95531,103566,63108]

theorem envBound35281 : H12AffineFastState.Bounded env35281 := by
  intro p hp
  have h : env35281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35268_35281 : H12AffineEnvironment.transform 5 17 env35268 = env35281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35268 == env35281) = true)

theorem identity35281 : scanCanonicalize (H12AffineFastState.compose env35281 (packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 23724) := by decide +kernel

theorem selectedBound35281 : packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env35282 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,23724,1025,32769,58516,29740,62612,41351,8328,17,100614,115102,17665,23725,119042,87215,257,95531,103566,63108]

theorem envBound35282 : H12AffineFastState.Bounded env35282 := by
  intro p hp
  have h : env35282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35281_35282 : H12AffineEnvironment.transform 17 23724 env35281 = env35282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23724 env35281 == env35282) = true)

theorem identity35282 : scanCanonicalize (H12AffineFastState.compose env35282 (packedSelected [3,5,8,11,16,19,20,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound35282 : packedSelected [3,5,8,11,16,19,20,26,28,32] rootPS < 2^1333 := by decide +kernel

def env35283 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,13460,23724,1025,29828,4113,29740,17,21762,8328,17,97667,79131,17665,23725,75143,87215,257,95531,90123,513]

theorem envBound35283 : H12AffineFastState.Bounded env35283 := by
  intro p hp
  have h : env35283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35282_35283 : H12AffineEnvironment.transform 14 29829 env35282 = env35283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env35282 == env35283) = true)

theorem identity35283 : scanCanonicalize (H12AffineFastState.compose env35283 (packedSelected [1,2,4,5,6,8,9,14,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound35283 : packedSelected [1,2,4,5,6,8,9,14,20,24] rootPS < 2^1333 := by decide +kernel

def env35284 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,262,13460,23724,1025,29828,4113,29740,17,21762,8328,17,31877,13341,17665,23725,9345,21929,257,29741,24845,513]

theorem envBound35284 : H12AffineFastState.Bounded env35284 := by
  intro p hp
  have h : env35284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35283_35284 : H12AffineEnvironment.transform 15 262 env35283 = env35284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env35283 == env35284) = true)

theorem identity35284 : scanCanonicalize (H12AffineFastState.compose env35284 (packedSelected [2,6,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35284 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env35285 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,262,13460,2476,1025,8580,4113,8492,17,2,8328,17,10629,13341,4097,2477,9345,169,257,8493,13325,513]

theorem envBound35285 : H12AffineFastState.Bounded env35285 := by
  intro p hp
  have h : env35285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35284_35285 : H12AffineEnvironment.transform 13 5376 env35284 = env35285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35284 == env35285) = true)

theorem identity35285 : scanCanonicalize (H12AffineFastState.compose env35285 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35285 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35286 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5376,137,262,5528,2476,1025,136,4113,32,17,2,388,17,2185,5393,4097,2477,1421,169,257,33,5377,513]

theorem envBound35286 : H12AffineFastState.Bounded env35286 := by
  intro p hp
  have h : env35286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35285_35286 : H12AffineEnvironment.transform 12 268 env35285 = env35286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35285 == env35286) = true)

theorem identity35286 : scanCanonicalize (H12AffineFastState.compose env35286 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound35286 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env35287 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3328,268,2048,137,262,2200,2476,1025,136,3345,32,17,2,388,17,2185,2065,3329,2477,1421,169,257,33,2049,513]

theorem envBound35287 : H12AffineFastState.Bounded env35287 := by
  intro p hp
  have h : env35287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35286_35287 : H12AffineEnvironment.transform 11 3328 env35286 = env35287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env35286 == env35287) = true)

theorem identity35287 : scanCanonicalize (H12AffineFastState.compose env35287 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound35287 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env35288 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3245,161,2048,137,171,2200,2049,1025,136,3260,32,17,2,41,17,2185,2065,3244,2048,1056,169,172,33,2049,513]

theorem envBound35288 : H12AffineFastState.Bounded env35288 := by
  intro p hp
  have h : env35288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35287_35288 : H12AffineEnvironment.transform 7 173 env35287 = env35288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env35287 == env35288) = true)

theorem identity35288 : scanCanonicalize (H12AffineFastState.compose env35288 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound35288 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env35289 : List Nat := [2,4,8,16,32,17,128,173,512,188,2048,2065,161,2048,137,171,2200,2049,189,136,2048,32,17,2,41,17,2185,2065,2064,2048,156,169,172,33,2049,513]

theorem envBound35289 : H12AffineFastState.Bounded env35289 := by
  intro p hp
  have h : env35289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35288_35289 : H12AffineEnvironment.transform 9 188 env35288 = env35289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env35288 == env35289) = true)

theorem identity35289 : scanCanonicalize (H12AffineFastState.compose env35289 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35289 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35290 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2065,41,2048,1,35,2064,2049,53,0,2048,32,17,2,41,17,2049,2065,2064,2048,20,33,36,33,2049,513]

theorem envBound35290 : H12AffineFastState.Bounded env35290 := by
  intro p hp
  have h : env35290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35289_35290 : H12AffineEnvironment.transform 6 8 env35289 = env35290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35289 == env35290) = true)

theorem identity35290 : scanCanonicalize (H12AffineFastState.compose env35290 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35290 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35291 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,17,41,0,1,35,16,1,53,0,0,32,17,2,41,17,1,17,16,0,20,33,36,33,1,513]

theorem envBound35291 : H12AffineFastState.Bounded env35291 := by
  intro p hp
  have h : env35291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35290_35291 : H12AffineEnvironment.transform 10 0 env35290 = env35291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35290 == env35291) = true)

theorem identity35291 : scanCanonicalize (H12AffineFastState.compose env35291 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound35291 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35292 : List Nat := [2,4,8,16,32,17,8,37,58,52,0,17,41,0,1,35,16,1,53,0,0,32,17,2,41,17,1,17,16,0,20,33,36,33,1,59]

theorem envBound35292 : H12AffineFastState.Bounded env35292 := by
  intro p hp
  have h : env35292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35291_35292 : H12AffineEnvironment.transform 8 58 env35291 = env35292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env35291 == env35292) = true)

def env35293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180224,169235,8328,64,245139,115151,17665,262145,119042,329730,257,213486,237643,63189]

theorem envBound35293 : H12AffineFastState.Bounded env35293 := by
  intro p hp
  have h : env35293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35266_35293 : H12AffineEnvironment.transform 21 272513 env35266 = env35293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35266 == env35293) = true)

theorem identity35293 : scanCanonicalize (H12AffineFastState.compose env35293 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound35293 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140421,272513,144596,156103,8328,64,215367,79131,17665,262145,75222,329730,257,213486,218271,513]

theorem envBound35294 : H12AffineFastState.Bounded env35294 := by
  intro p hp
  have h : env35294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35293_35294 : H12AffineEnvironment.transform 14 29908 env35293 = env35294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env35293 == env35294) = true)

def env35295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140301,272393,144476,155983,8192,64,215367,79131,17665,262145,75102,329730,257,213350,218135,513]

theorem envBound35295 : H12AffineFastState.Bounded env35295 := by
  intro p hp
  have h : env35295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35294_35295 : H12AffineEnvironment.transform 6 8 env35294 = env35295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35294 == env35295) = true)

def env35296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140300,272392,144477,155982,8193,64,215367,79131,17665,262145,75103,329730,257,213351,218134,513]

theorem envBound35296 : H12AffineFastState.Bounded env35296 := by
  intro p hp
  have h : env35296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35294_35296 : H12AffineEnvironment.transform 6 9 env35294 = env35296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35294 == env35296) = true)

theorem identity35296 : scanCanonicalize (H12AffineFastState.compose env35296 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound35296 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1025,29788,82966,272392,87111,65876,8193,64,10589,79131,17665,262145,75103,329730,257,8573,13324,513]

theorem envBound35297 : H12AffineFastState.Bounded env35297 := by
  intro p hp
  have h : env35297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35296_35297 : H12AffineEnvironment.transform 16 90138 env35296 = env35297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env35296 == env35297) = true)

theorem identity35297 : scanCanonicalize (H12AffineFastState.compose env35297 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound35297 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21510,13340,262144,1025,29788,4112,272392,65,21842,8193,64,10589,24861,17665,262145,29017,285700,257,8573,13324,513]

theorem envBound35298 : H12AffineFastState.Bounded env35298 := by
  intro p hp
  have h : env35298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35297_35298 : H12AffineEnvironment.transform 15 21510 env35297 = env35298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env35297 == env35298) = true)

theorem identity35298 : scanCanonicalize (H12AffineFastState.compose env35298 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 11292) := by decide +kernel

theorem selectedBound35298 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env35299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21510,13340,11292,1025,29788,4112,1044,65,21842,8193,64,10589,24861,17665,11293,29017,28696,257,8573,13324,513]

theorem envBound35299 : H12AffineFastState.Bounded env35299 := by
  intro p hp
  have h : env35299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35298_35299 : H12AffineEnvironment.transform 17 11292 env35298 = env35299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11292 env35298 == env35299) = true)

theorem identity35299 : scanCanonicalize (H12AffineFastState.compose env35299 (packedSelected [18,23] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35299 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35300 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,8192,16384,28776,20531,12329,10281,52,28777,4112,33,65,20839,8193,64,10589,24861,16692,10280,29017,28696,257,8573,12345,513]

theorem envBound35300 : H12AffineFastState.Bounded env35300 := by
  intro p hp
  have h : env35300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35299_35300 : H12AffineEnvironment.transform 9 53 env35299 = env35300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35299 == env35300) = true)

theorem identity35300 : scanCanonicalize (H12AffineFastState.compose env35300 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound35300 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env35301 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2404,8192,16384,26892,18775,10573,10281,52,26893,2420,33,65,18435,8193,64,10589,24861,16692,10280,26685,27004,257,8573,10589,513]

theorem envBound35301 : H12AffineFastState.Bounded env35301 := by
  intro p hp
  have h : env35301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35300_35301 : H12AffineEnvironment.transform 11 2404 env35300 = env35301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env35300 == env35301) = true)

theorem identity35301 : scanCanonicalize (H12AffineFastState.compose env35301 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35301 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env35302 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2404,268,16384,18432,18775,2113,2341,52,18433,2420,33,65,18435,269,64,2129,16401,16692,2340,18737,18544,257,113,2129,513]

theorem envBound35302 : H12AffineFastState.Bounded env35302 := by
  intro p hp
  have h : env35302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35301_35302 : H12AffineEnvironment.transform 12 268 env35301 = env35302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35301 == env35302) = true)

theorem identity35302 : scanCanonicalize (H12AffineFastState.compose env35302 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound35302 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35303 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2404,268,2048,0,343,2113,2341,52,1,2420,33,65,3,269,64,2129,2065,2356,2340,305,112,257,113,2129,513]

theorem envBound35303 : H12AffineFastState.Bounded env35303 := by
  intro p hp
  have h : env35303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35302_35303 : H12AffineEnvironment.transform 13 2048 env35302 = env35303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env35302 == env35303) = true)

def env35304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180225,2114883,8328,64,6636867,115150,2266449,262144,2294099,4268162,257,213486,237643,2238084]

theorem envBound35304 : H12AffineFastState.Bounded env35304 := by
  intro p hp
  have h : env35304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35186_35304 : H12AffineEnvironment.transform 22 180225 env35186 = env35304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env35186 == env35304) = true)

def env35305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180225,169235,8328,64,4691219,115150,17665,262144,119043,4268162,257,213486,237643,63188]

theorem envBound35305 : H12AffineFastState.Bounded env35305 := by
  intro p hp
  have h : env35305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35304_35305 : H12AffineEnvironment.transform 20 184400 env35304 = env35305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env35304 == env35305) = true)

def env35306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180225,169235,8328,64,245139,115150,17665,262144,119043,329730,257,213486,237643,63188]

theorem envBound35306 : H12AffineFastState.Bounded env35306 := by
  intro p hp
  have h : env35306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35305_35306 : H12AffineEnvironment.transform 21 272512 env35305 = env35306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35305 == env35306) = true)

theorem identity35306 : scanCanonicalize (H12AffineFastState.compose env35306 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35306 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184400,272512,180225,169235,8328,64,171417,57796,17665,262144,61705,272392,257,156132,163905,63188]

theorem envBound35307 : H12AffineFastState.Bounded env35307 := by
  intro p hp
  have h : env35307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35306_35307 : H12AffineEnvironment.transform 15 8202 env35306 = env35307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35306 == env35307) = true)

def env35308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184400,272392,180225,169235,8192,64,171281,57676,17665,262144,61705,272392,257,156012,163905,63068]

theorem envBound35308 : H12AffineFastState.Bounded env35308 := by
  intro p hp
  have h : env35308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35307_35308 : H12AffineEnvironment.transform 6 8 env35307 = env35308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35307 == env35308) = true)

def env35309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4160,272392,17,21763,8192,64,23809,57676,17665,262144,61705,272392,257,41340,16465,63068]

theorem envBound35309 : H12AffineFastState.Bounded env35309 := by
  intro p hp
  have h : env35309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35308_35309 : H12AffineEnvironment.transform 16 49168 env35308 = env35309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35308 == env35309) = true)

theorem identity35309 : scanCanonicalize (H12AffineFastState.compose env35309 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35309 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10280,1025,32769,4160,32,17,21763,8192,64,23809,57676,17665,10280,61705,32,257,41340,16465,63068]

theorem envBound35310 : H12AffineFastState.Bounded env35310 := by
  intro p hp
  have h : env35310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35309_35310 : H12AffineEnvironment.transform 17 10280 env35309 = env35310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35309 == env35310) = true)

theorem identity35310 : scanCanonicalize (H12AffineFastState.compose env35310 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound35310 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,5393,10280,1025,21760,4160,32,17,21763,8192,64,23809,13389,17665,10280,9224,32,257,29821,16465,9053]

theorem envBound35311 : H12AffineFastState.Bounded env35311 := by
  intro p hp
  have h : env35311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35310_35311 : H12AffineEnvironment.transform 14 21761 env35310 = env35311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env35310 == env35311) = true)

theorem identity35311 : scanCanonicalize (H12AffineFastState.compose env35311 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35311 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8202,5393,10280,1025,1,4160,32,17,2,8192,64,2048,13389,4096,10280,9224,32,257,8572,5456,9053]

theorem envBound35312 : H12AffineFastState.Bounded env35312 := by
  intro p hp
  have h : env35312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35311_35312 : H12AffineEnvironment.transform 13 5377 env35311 = env35312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35311 == env35312) = true)

theorem identity35312 : scanCanonicalize (H12AffineFastState.compose env35312 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound35312 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env35313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,0,34,5393,2048,1025,1,4160,32,17,2,40,64,2048,5221,4096,2048,1056,32,257,340,5456,885]

theorem envBound35313 : H12AffineFastState.Bounded env35313 := by
  intro p hp
  have h : env35313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35312_35313 : H12AffineEnvironment.transform 12 40 env35312 = env35313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env35312 == env35313) = true)

theorem identity35313 : scanCanonicalize (H12AffineFastState.compose env35313 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35313 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35314 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,0,34,5221,2048,1025,1,4160,32,17,2,40,64,2048,5221,4096,2048,1056,32,117,32,5156,513]

theorem envBound35314 : H12AffineFastState.Bounded env35314 := by
  intro p hp
  have h : env35314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35313_35314 : H12AffineEnvironment.transform 7 116 env35313 = env35314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35313 == env35314) = true)

theorem identity35314 : scanCanonicalize (H12AffineFastState.compose env35314 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound35314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35315 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,40,4112,0,34,4096,2048,100,1,4160,32,17,2,40,64,2048,4096,4096,2048,69,32,117,32,4161,513]

theorem envBound35315 : H12AffineFastState.Bounded env35315 := by
  intro p hp
  have h : env35315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35314_35315 : H12AffineEnvironment.transform 9 101 env35314 = env35315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env35314 == env35315) = true)

theorem identity35315 : scanCanonicalize (H12AffineFastState.compose env35315 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound35315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35316 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,16,40,0,0,34,16,2048,100,1,80,32,17,2,40,64,2048,16,16,2048,69,32,117,32,81,513]

theorem envBound35316 : H12AffineFastState.Bounded env35316 := by
  intro p hp
  have h : env35316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35315_35316 : H12AffineEnvironment.transform 11 16 env35315 = env35316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env35315 == env35316) = true)

theorem identity35316 : scanCanonicalize (H12AffineFastState.compose env35316 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound35316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35317 : List Nat := [2,4,8,16,32,64,8,116,512,101,48,16,40,0,0,34,16,48,100,1,80,32,17,2,40,64,48,16,16,48,69,32,117,32,81,513]

theorem envBound35317 : H12AffineFastState.Bounded env35317 := by
  intro p hp
  have h : env35317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35316_35317 : H12AffineEnvironment.transform 10 48 env35316 = env35317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env35316 == env35317) = true)

def env35318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4161,272392,16,21762,8192,64,23808,57676,17665,262144,61705,272392,257,41341,16464,63068]

theorem envBound35318 : H12AffineFastState.Bounded env35318 := by
  intro p hp
  have h : env35318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35308_35318 : H12AffineEnvironment.transform 16 49169 env35308 = env35318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35308 == env35318) = true)

theorem identity35318 : scanCanonicalize (H12AffineFastState.compose env35318 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35318 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49169,262144,1025,32769,4161,264532,16,21762,348,64,23808,49168,17665,262144,53333,264532,257,32801,16464,55040]

theorem envBound35319 : H12AffineFastState.Bounded env35319 := by
  intro p hp
  have h : env35319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35318_35319 : H12AffineEnvironment.transform 12 348 env35318 = env35319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35318 == env35319) = true)

theorem identity35319 : scanCanonicalize (H12AffineFastState.compose env35319 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound35319 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49169,35188,1025,32769,4161,32800,16,21762,348,64,23808,49168,17665,35188,53333,32800,257,32801,16464,55040]

theorem envBound35320 : H12AffineFastState.Bounded env35320 := by
  intro p hp
  have h : env35320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35319_35320 : H12AffineEnvironment.transform 17 35188 env35319 = env35320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env35319 == env35320) = true)

theorem identity35320 : scanCanonicalize (H12AffineFastState.compose env35320 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound35320 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,342,5392,23669,1025,21760,4161,21793,16,21762,348,64,23808,5393,17665,23669,1364,21793,257,21792,16464,513]

theorem envBound35321 : H12AffineFastState.Bounded env35321 := by
  intro p hp
  have h : env35321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35320_35321 : H12AffineEnvironment.transform 14 21761 env35320 = env35321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env35320 == env35321) = true)

theorem identity35321 : scanCanonicalize (H12AffineFastState.compose env35321 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35321 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35322 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,262,5392,23589,1025,21760,4113,21793,16,21762,268,16,23808,5393,17665,23589,1284,21793,257,21792,16384,513]

theorem envBound35322 : H12AffineFastState.Bounded env35322 := by
  intro p hp
  have h : env35322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35321_35322 : H12AffineEnvironment.transform 5 16 env35321 = env35322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35321 == env35322) = true)

theorem identity35322 : scanCanonicalize (H12AffineFastState.compose env35322 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound35322 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env35323 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2065,268,16384,19728,262,3329,17460,1025,19729,2048,19760,16,19731,268,16,17681,3328,17665,17460,1284,19760,257,19761,16384,513]

theorem envBound35323 : H12AffineFastState.Bounded env35323 := by
  intro p hp
  have h : env35323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35322_35323 : H12AffineEnvironment.transform 11 2065 env35322 = env35323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env35322 == env35323) = true)

theorem identity35323 : scanCanonicalize (H12AffineFastState.compose env35323 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 3124) := by decide +kernel

theorem selectedBound35323 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env35324 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2065,268,3124,292,262,3329,2048,1025,293,2048,260,16,295,268,16,2341,3328,2357,2048,1284,260,257,261,3124,513]

theorem envBound35324 : H12AffineFastState.Bounded env35324 := by
  intro p hp
  have h : env35324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35323_35324 : H12AffineEnvironment.transform 13 3124 env35323 = env35324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3124 env35323 == env35324) = true)

theorem identity35324 : scanCanonicalize (H12AffineFastState.compose env35324 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35324 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env35325 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2065,40,3124,0,34,3109,2048,1025,1,2048,32,16,3,40,16,2049,3108,2065,2048,1056,32,37,33,3124,513]

theorem envBound35325 : H12AffineFastState.Bounded env35325 := by
  intro p hp
  have h : env35325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35324_35325 : H12AffineEnvironment.transform 7 36 env35324 = env35325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35324 == env35325) = true)

theorem identity35325 : scanCanonicalize (H12AffineFastState.compose env35325 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35325 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35326 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,16,40,1077,0,34,1060,1,1025,1,1,32,16,3,40,16,0,1061,16,1,1056,32,37,33,1077,513]

theorem envBound35326 : H12AffineFastState.Bounded env35326 := by
  intro p hp
  have h : env35326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35325_35326 : H12AffineEnvironment.transform 10 1 env35325 = env35326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35325 == env35326) = true)

theorem identity35326 : scanCanonicalize (H12AffineFastState.compose env35326 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound35326 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35327 : List Nat := [2,4,8,16,32,16,8,36,512,574,1,16,40,523,0,34,538,1,575,1,1,32,16,3,40,16,0,539,16,1,542,32,37,33,523,513]

theorem envBound35327 : H12AffineFastState.Bounded env35327 := by
  intro p hp
  have h : env35327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35326_35327 : H12AffineEnvironment.transform 9 574 env35326 = env35327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env35326 == env35327) = true)

theorem identity35327 : scanCanonicalize (H12AffineFastState.compose env35327 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound35327 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35328 : List Nat := [2,4,8,13,32,13,8,36,512,547,1,13,40,523,0,34,519,1,546,1,1,32,13,3,40,13,0,518,13,1,515,32,37,33,523,513]

theorem envBound35328 : H12AffineFastState.Bounded env35328 := by
  intro p hp
  have h : env35328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35327_35328 : H12AffineEnvironment.transform 3 13 env35327 = env35328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env35327 == env35328) = true)

theorem identity35328 : scanCanonicalize (H12AffineFastState.compose env35328 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound35328 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35329 : List Nat := [2,4,8,13,32,13,8,36,42,9,1,13,40,33,0,34,45,1,8,1,1,32,13,3,40,13,0,44,13,1,41,32,37,33,33,43]

theorem envBound35329 : H12AffineFastState.Bounded env35329 := by
  intro p hp
  have h : env35329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35328_35329 : H12AffineEnvironment.transform 8 42 env35328 = env35329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env35328 == env35329) = true)

theorem identity35329 : scanCanonicalize (H12AffineFastState.compose env35329 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound35329 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35330 : List Nat := [2,4,8,13,14,13,8,10,4,9,1,13,6,15,0,12,3,1,8,1,1,14,13,3,6,13,0,2,13,1,7,14,11,15,15,5]

theorem envBound35330 : H12AffineFastState.Bounded env35330 := by
  intro p hp
  have h : env35330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35329_35330 : H12AffineEnvironment.transform 4 14 env35329 = env35330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env35329 == env35330) = true)

theorem identity35330 : scanCanonicalize (H12AffineFastState.compose env35330 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound35330 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35331 : List Nat := [2,4,6,3,0,3,6,4,4,7,1,3,6,1,0,2,3,1,6,1,1,0,3,3,6,3,0,2,3,1,7,0,5,1,1,5]

theorem envBound35331 : H12AffineFastState.Bounded env35331 := by
  intro p hp
  have h : env35331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35330_35331 : H12AffineEnvironment.transform 2 6 env35330 = env35331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env35330 == env35331) = true)

def env35332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184400,272393,180225,169235,8193,64,171280,57677,17665,262144,61705,272392,257,156013,163905,63069]

theorem envBound35332 : H12AffineFastState.Bounded env35332 := by
  intro p hp
  have h : env35332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35307_35332 : H12AffineEnvironment.transform 6 9 env35307 = env35332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35307 == env35332) = true)

def env35333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4160,272393,17,21763,8193,64,23808,57677,17665,262144,61705,272392,257,41341,16465,63069]

theorem envBound35333 : H12AffineFastState.Bounded env35333 := by
  intro p hp
  have h : env35333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35332_35333 : H12AffineEnvironment.transform 16 49168 env35332 = env35333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35332 == env35333) = true)

theorem identity35333 : scanCanonicalize (H12AffineFastState.compose env35333 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound35333 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,35188,1025,32769,4160,41341,17,21763,8193,64,23808,57677,17665,35188,61705,41340,257,41341,16465,63069]

theorem envBound35334 : H12AffineFastState.Bounded env35334 := by
  intro p hp
  have h : env35334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35333_35334 : H12AffineEnvironment.transform 17 35188 env35333 = env35334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env35333 == env35334) = true)

theorem identity35334 : scanCanonicalize (H12AffineFastState.compose env35334 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35334 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,38160,35188,1025,32769,4160,41341,17,3,8193,64,2048,46157,4097,35188,41993,41340,257,41341,5457,41821]

theorem envBound35335 : H12AffineFastState.Bounded env35335 := by
  intro p hp
  have h : env35335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35334_35335 : H12AffineEnvironment.transform 13 5376 env35334 = env35335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35334 == env35335) = true)

theorem identity35335 : scanCanonicalize (H12AffineFastState.compose env35335 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound35335 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env35336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1297,8202,4097,3173,1025,1296,4160,9324,17,3,8193,64,2048,12636,4097,3173,8472,9325,257,9324,5457,9804]

theorem envBound35336 : H12AffineFastState.Bounded env35336 := by
  intro p hp
  have h : env35336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35335_35336 : H12AffineEnvironment.transform 14 1297 env35335 = env35336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env35335 == env35336) = true)

theorem identity35336 : scanCanonicalize (H12AffineFastState.compose env35336 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7261) := by decide +kernel

theorem selectedBound35336 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env35337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7261,5376,1297,7255,4097,3173,1025,1296,4160,6193,17,3,7260,64,2048,3329,4097,3173,7493,6192,257,6193,5457,6673]

theorem envBound35337 : H12AffineFastState.Bounded env35337 := by
  intro p hp
  have h : env35337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35336_35337 : H12AffineEnvironment.transform 12 7261 env35336 = env35337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7261 env35336 == env35337) = true)

theorem identity35337 : scanCanonicalize (H12AffineFastState.compose env35337 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound35337 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env35338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,5133,5376,1297,5127,4097,1077,1025,1296,4160,4193,17,3,5132,64,80,1361,4097,1077,5397,4192,257,4193,5457,4673]

theorem envBound35338 : H12AffineFastState.Bounded env35338 := by
  intro p hp
  have h : env35338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35337_35338 : H12AffineEnvironment.transform 10 80 env35337 = env35338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env35337 == env35338) = true)

theorem identity35338 : scanCanonicalize (H12AffineFastState.compose env35338 (packedSelected [0,1,2,6,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound35338 : packedSelected [0,1,2,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env35339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,65,1100,1345,1297,1094,64,1077,1025,1296,1,32,17,3,1101,64,80,1361,64,1077,1364,33,257,32,1296,512]

theorem envBound35339 : H12AffineFastState.Bounded env35339 := by
  intro p hp
  have h : env35339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35338_35339 : H12AffineEnvironment.transform 11 65 env35338 = env35339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env35338 == env35339) = true)

theorem identity35339 : scanCanonicalize (H12AffineFastState.compose env35339 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound35339 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35340 : List Nat := [2,4,8,16,32,64,9,256,512,304,80,65,380,113,33,374,64,261,305,32,1,32,17,3,381,64,80,97,64,261,100,33,257,32,32,512]

theorem envBound35340 : H12AffineFastState.Bounded env35340 := by
  intro p hp
  have h : env35340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35339_35340 : H12AffineEnvironment.transform 9 304 env35339 = env35340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env35339 == env35340) = true)

theorem identity35340 : scanCanonicalize (H12AffineFastState.compose env35340 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound35340 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env35341 : List Nat := [2,4,8,16,32,64,9,5,512,53,80,65,121,113,33,115,64,0,52,32,1,32,17,3,120,64,80,97,64,0,100,33,4,32,32,512]

theorem envBound35341 : H12AffineFastState.Bounded env35341 := by
  intro p hp
  have h : env35341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35340_35341 : H12AffineEnvironment.transform 7 5 env35340 = env35341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env35340 == env35341) = true)

theorem identity35341 : scanCanonicalize (H12AffineFastState.compose env35341 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35341 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35342 : List Nat := [2,4,8,16,0,64,9,5,512,21,80,65,89,81,1,83,64,0,20,0,1,0,17,3,88,64,80,65,64,0,68,1,4,0,0,512]

theorem envBound35342 : H12AffineFastState.Bounded env35342 := by
  intro p hp
  have h : env35342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35341_35342 : H12AffineEnvironment.transform 4 0 env35341 = env35342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35341 == env35342) = true)

def env35343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4161,272393,16,21762,8193,64,23809,57677,17665,262144,61705,272392,257,41340,16464,63069]

theorem envBound35343 : H12AffineFastState.Bounded env35343 := by
  intro p hp
  have h : env35343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35332_35343 : H12AffineEnvironment.transform 16 49169 env35332 = env35343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35332 == env35343) = true)

theorem identity35343 : scanCanonicalize (H12AffineFastState.compose env35343 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35343 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,24908,262144,1025,8540,4161,272393,16,21762,8193,64,23809,16400,17665,262144,20564,272392,257,33,16464,22272]

theorem envBound35344 : H12AffineFastState.Bounded env35344 := by
  intro p hp
  have h : env35344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35343_35344 : H12AffineEnvironment.transform 14 8541 env35343 = env35344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35343 == env35344) = true)

theorem identity35344 : scanCanonicalize (H12AffineFastState.compose env35344 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35344 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,13388,262144,1025,8540,4161,272393,16,2,8193,64,2049,5392,4097,262144,1364,272392,257,33,5456,512]

theorem envBound35345 : H12AffineFastState.Bounded env35345 := by
  intro p hp
  have h : env35345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35344_35345 : H12AffineEnvironment.transform 13 5376 env35344 = env35345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35344 == env35345) = true)

theorem identity35345 : scanCanonicalize (H12AffineFastState.compose env35345 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2308) := by decide +kernel

theorem selectedBound35345 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,13388,2308,1025,8540,4161,8461,16,2,8193,64,2049,5392,4097,2308,1364,8460,257,33,5456,512]

theorem envBound35346 : H12AffineFastState.Bounded env35346 := by
  intro p hp
  have h : env35346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35345_35346 : H12AffineEnvironment.transform 17 2308 env35345 = env35346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2308 env35345 == env35346) = true)

theorem identity35346 : scanCanonicalize (H12AffineFastState.compose env35346 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound35346 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env35347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,9,5376,340,3,5189,2308,1025,341,4161,260,16,2,8,64,2049,5392,4097,2308,1364,261,257,33,5456,512]

theorem envBound35347 : H12AffineFastState.Bounded env35347 := by
  intro p hp
  have h : env35347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35346_35347 : H12AffineEnvironment.transform 12 9 env35346 = env35347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env35346 == env35347) = true)

theorem identity35347 : scanCanonicalize (H12AffineFastState.compose env35347 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35347 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env35348 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5376,261,3,5140,2308,1025,260,4112,260,16,2,8,17,2049,5392,4097,2308,1285,261,257,33,5377,512]

theorem envBound35348 : H12AffineFastState.Bounded env35348 := by
  intro p hp
  have h : env35348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35347_35348 : H12AffineEnvironment.transform 5 17 env35347 = env35348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35347 == env35348) = true)

theorem identity35348 : scanCanonicalize (H12AffineFastState.compose env35348 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound35348 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35349 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2324,9,3092,261,3,3328,2308,1025,260,2308,260,16,2,8,17,2049,3076,2325,2308,1285,261,257,33,3093,512]

theorem envBound35349 : H12AffineFastState.Bounded env35349 := by
  intro p hp
  have h : env35349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35348_35349 : H12AffineEnvironment.transform 11 2324 env35348 = env35349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env35348 == env35349) = true)

theorem identity35349 : scanCanonicalize (H12AffineFastState.compose env35349 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35349 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35350 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,2064,9,3092,1,3,3076,2048,1025,0,2048,0,16,2,8,17,2049,3076,2065,2048,1025,1,5,33,3093,512]

theorem envBound35350 : H12AffineFastState.Bounded env35350 := by
  intro p hp
  have h : env35350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35349_35350 : H12AffineEnvironment.transform 7 4 env35349 = env35350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35349 == env35350) = true)

theorem identity35350 : scanCanonicalize (H12AffineFastState.compose env35350 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound35350 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35351 : List Nat := [2,4,8,16,32,17,9,4,512,1024,33,49,9,1077,1,3,1061,33,1025,0,33,0,16,2,8,17,32,1061,48,33,1025,1,5,33,1076,512]

theorem envBound35351 : H12AffineFastState.Bounded env35351 := by
  intro p hp
  have h : env35351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35350_35351 : H12AffineEnvironment.transform 10 33 env35350 = env35351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env35350 == env35351) = true)

theorem identity35351 : scanCanonicalize (H12AffineFastState.compose env35351 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound35351 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35352 : List Nat := [2,4,8,16,32,17,9,4,10,1024,33,49,9,1077,1,3,1061,33,1025,0,33,0,16,2,8,17,32,1061,48,33,1025,1,5,33,1076,10]

theorem envBound35352 : H12AffineFastState.Bounded env35352 := by
  intro p hp
  have h : env35352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35351_35352 : H12AffineEnvironment.transform 8 10 env35351 = env35352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env35351 == env35352) = true)

theorem identity35352 : scanCanonicalize (H12AffineFastState.compose env35352 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 45) := by decide +kernel

theorem selectedBound35352 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35353 : List Nat := [2,4,8,16,32,17,9,4,10,45,33,49,9,24,1,3,8,33,44,0,33,0,16,2,8,17,32,8,48,33,44,1,5,33,25,10]

theorem envBound35353 : H12AffineFastState.Bounded env35353 := by
  intro p hp
  have h : env35353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35352_35353 : H12AffineEnvironment.transform 9 45 env35352 = env35353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 45 env35352 == env35353) = true)

theorem identity35353 : scanCanonicalize (H12AffineFastState.compose env35353 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound35353 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35354 : List Nat := [2,4,8,9,32,8,9,4,10,45,33,40,9,1,1,3,8,33,44,0,33,0,9,2,8,8,32,8,41,33,44,1,5,33,0,10]

theorem envBound35354 : H12AffineFastState.Bounded env35354 := by
  intro p hp
  have h : env35354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35353_35354 : H12AffineEnvironment.transform 3 9 env35353 = env35354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env35353 == env35354) = true)

theorem identity35354 : scanCanonicalize (H12AffineFastState.compose env35354 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound35354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35355 : List Nat := [2,4,8,9,5,8,9,4,10,8,4,13,9,1,1,3,8,4,9,0,4,0,9,2,8,8,5,8,12,4,9,1,5,4,0,10]

theorem envBound35355 : H12AffineFastState.Bounded env35355 := by
  intro p hp
  have h : env35355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35354_35355 : H12AffineEnvironment.transform 4 5 env35354 = env35355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env35354 == env35355) = true)

theorem identity35355 : scanCanonicalize (H12AffineFastState.compose env35355 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35355 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35356 : List Nat := [2,1,8,9,0,8,9,1,10,8,1,8,9,1,1,3,8,1,9,0,1,0,9,2,8,8,0,8,9,1,9,1,0,1,0,10]

theorem envBound35356 : H12AffineFastState.Bounded env35356 := by
  intro p hp
  have h : env35356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35355_35356 : H12AffineEnvironment.transform 1 1 env35355 = env35356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35355 == env35356) = true)

def env35357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180225,169235,8328,64,245138,115150,17665,262144,119043,329731,257,213486,237643,63188]

theorem envBound35357 : H12AffineFastState.Bounded env35357 := by
  intro p hp
  have h : env35357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35305_35357 : H12AffineEnvironment.transform 21 272513 env35305 = env35357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35305 == env35357) = true)

theorem identity35357 : scanCanonicalize (H12AffineFastState.compose env35357 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound35357 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77898,272513,73755,95497,8328,64,23944,115150,17665,262144,119043,329731,257,41460,16465,63188]

theorem envBound35358 : H12AffineFastState.Bounded env35358 := by
  intro p hp
  have h : env35358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35357_35358 : H12AffineEnvironment.transform 16 122906 env35357 = env35358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env35357 == env35358) = true)

def env35359 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77898,272473,73755,95497,8272,64,23888,114966,17665,262144,119043,329731,257,41260,16465,62988]

theorem envBound35359 : H12AffineFastState.Bounded env35359 := by
  intro p hp
  have h : env35359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35358_35359 : H12AffineEnvironment.transform 6 88 env35358 = env35359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env35358 == env35359) = true)

theorem identity35359 : scanCanonicalize (H12AffineFastState.compose env35359 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound35359 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env35360 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21761,65536,79131,262144,1025,21760,77898,272473,73755,95497,8272,64,23888,70679,17665,262144,66562,329731,257,29741,16465,8973]

theorem envBound35360 : H12AffineFastState.Bounded env35360 := by
  intro p hp
  have h : env35360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35359_35360 : H12AffineEnvironment.transform 14 21761 env35359 = env35360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env35359 == env35360) = true)

theorem identity35360 : scanCanonicalize (H12AffineFastState.compose env35360 (packedSelected [1,3,4,7,9,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound35360 : packedSelected [1,3,4,7,9,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env35361 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21761,65536,79131,97327,1025,21760,77898,87158,73755,95497,8272,64,23888,70679,17665,97327,66562,29740,257,29741,16465,8973]

theorem envBound35361 : H12AffineFastState.Bounded env35361 := by
  intro p hp
  have h : env35361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35360_35361 : H12AffineEnvironment.transform 17 97327 env35360 = env35361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env35360 == env35361) = true)

theorem identity35361 : scanCanonicalize (H12AffineFastState.compose env35361 (packedSelected [4,7,9,16,18,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound35361 : packedSelected [4,7,9,16,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env35362 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21761,262,13341,32041,1025,21760,12620,21872,8477,29711,8272,64,23888,5393,17665,32041,1284,29740,257,29741,16465,8973]

theorem envBound35362 : H12AffineFastState.Bounded env35362 := by
  intro p hp
  have h : env35362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35361_35362 : H12AffineEnvironment.transform 15 262 env35361 = env35362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env35361 == env35362) = true)

theorem identity35362 : scanCanonicalize (H12AffineFastState.compose env35362 (packedSelected [2,11,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound35362 : packedSelected [2,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env35363 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,1084,16384,21761,262,4129,22805,1025,21760,5488,21872,1313,20531,1132,64,23888,5393,17665,22805,1284,20496,257,20497,16465,1841]

theorem envBound35363 : H12AffineFastState.Bounded env35363 := by
  intro p hp
  have h : env35363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35362_35363 : H12AffineEnvironment.transform 12 1084 env35362 = env35363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env35362 == env35363) = true)

theorem identity35363 : scanCanonicalize (H12AffineFastState.compose env35363 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound35363 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35364 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,1084,4145,1328,262,4129,2340,1025,1329,5488,1345,1313,2,1132,64,3425,5393,5424,2340,1284,33,257,32,4192,1841]

theorem envBound35364 : H12AffineFastState.Bounded env35364 := by
  intro p hp
  have h : env35364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35363_35364 : H12AffineEnvironment.transform 13 4145 env35363 = env35364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env35363 == env35364) = true)

theorem identity35364 : scanCanonicalize (H12AffineFastState.compose env35364 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound35364 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env35365 : List Nat := [2,4,8,16,32,64,88,256,512,353,2048,4096,349,4145,81,262,4129,2340,352,80,4113,32,64,2,269,64,2048,4208,4177,2340,101,33,257,32,4192,592]

theorem envBound35365 : H12AffineFastState.Bounded env35365 := by
  intro p hp
  have h : env35365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35364_35365 : H12AffineEnvironment.transform 9 353 env35364 = env35365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env35364 == env35365) = true)

theorem identity35365 : scanCanonicalize (H12AffineFastState.compose env35365 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35365 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35366 : List Nat := [2,4,8,16,32,64,88,4,512,101,2048,4096,89,4145,81,2,4129,2080,100,80,4113,32,64,2,9,64,2048,4208,4177,2080,101,33,5,32,4192,592]

theorem envBound35366 : H12AffineFastState.Bounded env35366 := by
  intro p hp
  have h : env35366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35365_35366 : H12AffineEnvironment.transform 7 4 env35365 = env35366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35365 == env35366) = true)

theorem identity35366 : scanCanonicalize (H12AffineFastState.compose env35366 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35366 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35367 : List Nat := [2,4,8,16,0,64,88,4,512,69,2048,4096,89,4113,81,2,4097,2048,68,80,4113,0,64,2,9,64,2048,4176,4177,2048,69,1,5,0,4160,592]

theorem envBound35367 : H12AffineFastState.Bounded env35367 := by
  intro p hp
  have h : env35367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35366_35367 : H12AffineEnvironment.transform 4 0 env35366 = env35367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35366 == env35367) = true)

theorem identity35367 : scanCanonicalize (H12AffineFastState.compose env35367 (packedSelected [1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound35367 : packedSelected [1,4,8] rootPS < 2^1333 := by decide +kernel

def env35368 : List Nat := [2,4,8,16,0,64,88,4,512,69,2048,2065,89,2048,81,2,2064,2048,68,80,2048,0,64,2,9,64,2048,2113,2112,2048,69,1,5,0,2129,592]

theorem envBound35368 : H12AffineFastState.Bounded env35368 := by
  intro p hp
  have h : env35368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35367_35368 : H12AffineEnvironment.transform 11 2065 env35367 = env35368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env35367 == env35368) = true)

theorem identity35368 : scanCanonicalize (H12AffineFastState.compose env35368 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35368 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env35369 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,2065,9,2048,1,2,2064,2048,20,0,2048,0,16,2,9,16,2048,2065,2064,2048,21,1,5,0,2049,512]

theorem envBound35369 : H12AffineFastState.Bounded env35369 := by
  intro p hp
  have h : env35369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35368_35369 : H12AffineEnvironment.transform 5 16 env35368 = env35369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35368 == env35369) = true)

theorem identity35369 : scanCanonicalize (H12AffineFastState.compose env35369 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound35369 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35370 : List Nat := [2,4,8,16,0,16,8,4,512,21,4,21,9,4,1,2,20,4,20,0,4,0,16,2,9,16,4,21,20,4,21,1,5,0,5,512]

theorem envBound35370 : H12AffineFastState.Bounded env35370 := by
  intro p hp
  have h : env35370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35369_35370 : H12AffineEnvironment.transform 10 4 env35369 = env35370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env35369 == env35370) = true)

def env35371 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77898,272472,73755,95497,8273,64,23889,114967,17665,262144,119043,329731,257,41261,16465,62989]

theorem envBound35371 : H12AffineFastState.Bounded env35371 := by
  intro p hp
  have h : env35371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35358_35371 : H12AffineEnvironment.transform 6 89 env35358 = env35371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env35358 == env35371) = true)

theorem identity35371 : scanCanonicalize (H12AffineFastState.compose env35371 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound35371 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env35372 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,342,57676,262144,1025,32769,12572,272472,8525,29791,8273,64,23889,49217,17665,262144,53333,264533,257,41261,16465,62989]

theorem envBound35372 : H12AffineFastState.Bounded env35372 := by
  intro p hp
  have h : env35372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35371_35372 : H12AffineEnvironment.transform 15 342 env35371 = env35372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env35371 == env35372) = true)

theorem identity35372 : scanCanonicalize (H12AffineFastState.compose env35372 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 64889) := by decide +kernel

theorem selectedBound35372 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env35373 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,342,57676,64889,1025,32769,12572,54561,8525,29791,8273,64,23889,49217,17665,64889,53333,62508,257,41261,16465,62989]

theorem envBound35373 : H12AffineFastState.Bounded env35373 := by
  intro p hp
  have h : env35373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35372_35373 : H12AffineEnvironment.transform 17 64889 env35372 = env35373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64889 env35372 == env35373) = true)

theorem identity35373 : scanCanonicalize (H12AffineFastState.compose env35373 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35373 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env35374 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,32768,342,49169,56356,1025,32769,4161,54561,16,21762,268,64,23889,49217,17665,56356,53333,54641,257,32880,16465,55120]

theorem envBound35374 : H12AffineFastState.Bounded env35374 := by
  intro p hp
  have h : env35374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35373_35374 : H12AffineEnvironment.transform 12 349 env35373 = env35374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35373 == env35374) = true)

theorem identity35374 : scanCanonicalize (H12AffineFastState.compose env35374 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound35374 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env35375 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,21760,342,5393,2340,1025,21761,4161,33,16,21762,268,64,23889,5441,17665,2340,1365,113,257,21872,16465,592]

theorem envBound35375 : H12AffineFastState.Bounded env35375 := by
  intro p hp
  have h : env35375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35374_35375 : H12AffineEnvironment.transform 14 21760 env35374 = env35375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env35374 == env35375) = true)

theorem identity35375 : scanCanonicalize (H12AffineFastState.compose env35375 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound35375 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env35376 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,81,342,5393,2340,1025,80,4161,33,16,83,268,64,2048,5441,4176,2340,1365,113,257,33,5376,592]

theorem envBound35376 : H12AffineFastState.Bounded env35376 := by
  intro p hp
  have h : env35376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35375_35376 : H12AffineEnvironment.transform 13 5457 env35375 = env35376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env35375 == env35376) = true)

theorem identity35376 : scanCanonicalize (H12AffineFastState.compose env35376 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35376 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env35377 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5393,2340,1025,1,4112,33,16,2,268,17,2048,5392,4097,2340,1284,32,257,33,5376,513]

theorem envBound35377 : H12AffineFastState.Bounded env35377 := by
  intro p hp
  have h : env35377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35376_35377 : H12AffineEnvironment.transform 5 17 env35376 = env35377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35376 == env35377) = true)

theorem identity35377 : scanCanonicalize (H12AffineFastState.compose env35377 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35377 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35378 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,34,5172,2049,1025,1,4112,33,16,2,41,17,2048,5173,4097,2049,1057,32,36,33,5157,513]

theorem envBound35378 : H12AffineFastState.Bounded env35378 := by
  intro p hp
  have h : env35378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35377_35378 : H12AffineEnvironment.transform 7 37 env35377 = env35378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35377 == env35378) = true)

def env35379 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1045,0,34,1028,2049,1025,1,32,33,16,2,41,17,2048,1029,49,2049,1057,32,36,33,1045,513]

theorem envBound35379 : H12AffineFastState.Bounded env35379 := by
  intro p hp
  have h : env35379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35378_35379 : H12AffineEnvironment.transform 11 48 env35378 = env35379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35378 == env35379) = true)

theorem identity35379 : scanCanonicalize (H12AffineFastState.compose env35379 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound35379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35380 : List Nat := [2,4,8,16,32,17,8,37,512,549,2048,48,41,560,0,34,545,2049,548,1,32,33,16,2,41,17,2048,544,49,2049,516,32,36,33,560,513]

theorem envBound35380 : H12AffineFastState.Bounded env35380 := by
  intro p hp
  have h : env35380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35379_35380 : H12AffineEnvironment.transform 9 549 env35379 = env35380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env35379 == env35380) = true)

def env35381 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,48,41,32,0,34,49,2049,52,1,32,33,16,2,41,17,2048,48,49,2049,20,32,36,33,32,17]

theorem envBound35381 : H12AffineFastState.Bounded env35381 := by
  intro p hp
  have h : env35381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35380_35381 : H12AffineEnvironment.transform 8 16 env35380 = env35381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35380 == env35381) = true)

theorem identity35381 : scanCanonicalize (H12AffineFastState.compose env35381 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound35381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35382 : List Nat := [2,4,8,16,32,17,8,37,16,53,33,48,41,32,0,34,49,32,52,1,32,33,16,2,41,17,33,48,49,32,20,32,36,33,32,17]

theorem envBound35382 : H12AffineFastState.Bounded env35382 := by
  intro p hp
  have h : env35382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35381_35382 : H12AffineEnvironment.transform 10 33 env35381 = env35382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env35381 == env35382) = true)

def leafEnv35382 : List Nat := [2,4,8,16,32,17,8,37,16,53,33,48,41,32,0,34,49,32,52,1,32,33,16,2,21,41,1,17,33,48,49,32,20,32,36,33,5,34,32,17,1,32,0]

def active35382 : List Nat := [0,1,2,3,4]

def tree35382 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35382 : H12WitnessSearch.Good tree35382 := H12GlobalWitnessIndex.good

theorem leafIdentity35382 : H12AffineFastState.composeSystem env35382 rootObs = leafEnv35382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35382 rootObs == leafEnv35382) = true)

theorem terminalChecked35382 : H12PackedTerminal.terminalCheckFast leafEnv35382 active35382 tree35382 = true := by decide +kernel

def env35383 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,48,41,33,0,34,48,2049,53,1,32,33,16,2,41,17,2048,49,49,2049,21,32,36,33,33,16]

theorem envBound35383 : H12AffineFastState.Bounded env35383 := by
  intro p hp
  have h : env35383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35380_35383 : H12AffineEnvironment.transform 8 17 env35380 = env35383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35380 == env35383) = true)

theorem identity35383 : scanCanonicalize (H12AffineFastState.compose env35383 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound35383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35384 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,48,41,33,0,34,48,27,53,1,32,33,16,2,41,17,26,49,49,27,21,32,36,33,33,16]

theorem envBound35384 : H12AffineFastState.Bounded env35384 := by
  intro p hp
  have h : env35384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35383_35384 : H12AffineEnvironment.transform 10 26 env35383 = env35384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env35383 == env35384) = true)

def leafEnv35384 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,48,41,33,0,34,48,27,53,1,32,33,16,2,20,41,1,17,26,49,49,27,21,32,36,33,5,34,33,16,1,32,0]

def active35384 : List Nat := [0,1,2,3,4]

def tree35384 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35384 : H12WitnessSearch.Good tree35384 := H12GlobalWitnessIndex.good

theorem leafIdentity35384 : H12AffineFastState.composeSystem env35384 rootObs = leafEnv35384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35384 rootObs == leafEnv35384) = true)

theorem terminalChecked35384 : H12PackedTerminal.terminalCheckFast leafEnv35384 active35384 tree35384 = true := by decide +kernel

def env35385 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1044,0,34,1029,2049,1025,1,33,33,16,2,41,17,2048,1028,48,2049,1057,32,36,33,1044,513]

theorem envBound35385 : H12AffineFastState.Bounded env35385 := by
  intro p hp
  have h : env35385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35378_35385 : H12AffineEnvironment.transform 11 49 env35378 = env35385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35378 == env35385) = true)

theorem identity35385 : scanCanonicalize (H12AffineFastState.compose env35385 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35385 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35386 : List Nat := [2,4,8,16,32,17,8,37,17,1024,2048,49,41,1044,0,34,1029,2049,1025,1,33,33,16,2,41,17,2048,1028,48,2049,1057,32,36,33,1044,16]

theorem envBound35386 : H12AffineFastState.Bounded env35386 := by
  intro p hp
  have h : env35386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35385_35386 : H12AffineEnvironment.transform 8 17 env35385 = env35386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35385 == env35386) = true)

def env35387 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,49,41,32,0,34,49,2049,53,1,33,33,16,2,41,17,2048,48,48,2049,21,32,36,33,32,16]

theorem envBound35387 : H12AffineFastState.Bounded env35387 := by
  intro p hp
  have h : env35387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35386_35387 : H12AffineEnvironment.transform 9 52 env35386 = env35387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35386 == env35387) = true)

theorem identity35387 : scanCanonicalize (H12AffineFastState.compose env35387 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound35387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35388 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,49,41,32,0,34,49,27,53,1,33,33,16,2,41,17,26,48,48,27,21,32,36,33,32,16]

theorem envBound35388 : H12AffineFastState.Bounded env35388 := by
  intro p hp
  have h : env35388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35387_35388 : H12AffineEnvironment.transform 10 26 env35387 = env35388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env35387 == env35388) = true)

def leafEnv35388 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,49,41,32,0,34,49,27,53,1,33,33,16,2,20,41,1,17,26,48,48,27,21,32,36,33,5,34,32,16,1,33,0]

def active35388 : List Nat := [0,1,2,3,4]

def tree35388 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35388 : H12WitnessSearch.Good tree35388 := H12GlobalWitnessIndex.good

theorem leafIdentity35388 : H12AffineFastState.composeSystem env35388 rootObs = leafEnv35388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35388 rootObs == leafEnv35388) = true)

theorem terminalChecked35388 : H12PackedTerminal.terminalCheckFast leafEnv35388 active35388 tree35388 = true := by decide +kernel

def env35389 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,49,41,33,0,34,48,2049,52,1,33,33,16,2,41,17,2048,49,48,2049,20,32,36,33,33,16]

theorem envBound35389 : H12AffineFastState.Bounded env35389 := by
  intro p hp
  have h : env35389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35386_35389 : H12AffineEnvironment.transform 9 53 env35386 = env35389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35386 == env35389) = true)

theorem identity35389 : scanCanonicalize (H12AffineFastState.compose env35389 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound35389 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35390 : List Nat := [2,4,8,16,32,17,8,37,17,53,32,49,41,33,0,34,48,33,52,1,33,33,16,2,41,17,32,49,48,33,20,32,36,33,33,16]

theorem envBound35390 : H12AffineFastState.Bounded env35390 := by
  intro p hp
  have h : env35390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35389_35390 : H12AffineEnvironment.transform 10 32 env35389 = env35390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env35389 == env35390) = true)

def leafEnv35390 : List Nat := [2,4,8,16,32,17,8,37,17,53,32,49,41,33,0,34,48,33,52,1,33,33,16,2,21,41,1,17,32,49,48,33,20,32,36,33,5,34,33,16,1,33,0]

def active35390 : List Nat := [0,1,2,3,4]

def tree35390 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35390 : H12WitnessSearch.Good tree35390 := H12GlobalWitnessIndex.good

theorem leafIdentity35390 : H12AffineFastState.composeSystem env35390 rootObs = leafEnv35390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35390 rootObs == leafEnv35390) = true)

theorem terminalChecked35390 : H12PackedTerminal.terminalCheckFast leafEnv35390 active35390 tree35390 = true := by decide +kernel

def env35391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180225,169234,8328,64,4691218,115150,17664,262144,119042,4268162,257,213486,237643,63189]

theorem envBound35391 : H12AffineFastState.Bounded env35391 := by
  intro p hp
  have h : env35391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35304_35391 : H12AffineEnvironment.transform 20 184401 env35304 = env35391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env35304 == env35391) = true)

def env35392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180225,169234,8328,64,245138,115150,17664,262144,119042,329730,257,213486,237643,63189]

theorem envBound35392 : H12AffineFastState.Bounded env35392 := by
  intro p hp
  have h : env35392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35391_35392 : H12AffineEnvironment.transform 21 272512 env35391 = env35392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35391 == env35392) = true)

theorem identity35392 : scanCanonicalize (H12AffineFastState.compose env35392 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound35392 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,184401,272512,180225,169234,8328,64,158028,5392,17664,262144,1500,318684,257,169264,160917,63189]

theorem envBound35393 : H12AffineFastState.Bounded env35393 := by
  intro p hp
  have h : env35393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35392_35393 : H12AffineEnvironment.transform 15 54494 env35392 = env35393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env35392 == env35393) = true)

theorem identity35393 : scanCanonicalize (H12AffineFastState.compose env35393 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound35393 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env35394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,262144,1025,29909,140421,272512,144597,156102,8328,64,158028,5392,17664,262144,1500,272392,257,156132,160917,513]

theorem envBound35394 : H12AffineFastState.Bounded env35394 := by
  intro p hp
  have h : env35394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35393_35394 : H12AffineEnvironment.transform 14 29908 env35393 = env35394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env35393 == env35394) = true)

theorem identity35394 : scanCanonicalize (H12AffineFastState.compose env35394 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound35394 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env35395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,2557,1025,29909,140421,8573,144597,156102,8328,64,158028,5392,17664,2557,1500,8693,257,156132,160917,513]

theorem envBound35395 : H12AffineFastState.Bounded env35395 := by
  intro p hp
  have h : env35395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35394_35395 : H12AffineEnvironment.transform 17 2557 env35394 = env35395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env35394 == env35395) = true)

theorem identity35395 : scanCanonicalize (H12AffineFastState.compose env35395 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound35395 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env35396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,1,8202,131072,2557,1025,0,140421,8573,144597,136467,8328,64,138649,5392,12757,2557,1500,8693,257,136497,131136,513]

theorem envBound35396 : H12AffineFastState.Bounded env35396 := by
  intro p hp
  have h : env35396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35395_35396 : H12AffineEnvironment.transform 13 13525 env35395 = env35396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env35395 == env35396) = true)

theorem identity35396 : scanCanonicalize (H12AffineFastState.compose env35396 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35396 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env35397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,1,342,131072,2557,1025,0,132569,33,136585,136467,468,64,138649,5392,4233,2557,1500,169,257,136497,131136,513]

theorem envBound35397 : H12AffineFastState.Bounded env35397 := by
  intro p hp
  have h : env35397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35396_35397 : H12AffineEnvironment.transform 12 348 env35396 = env35397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35396 == env35397) = true)

theorem identity35397 : scanCanonicalize (H12AffineFastState.compose env35397 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound35397 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env35398 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,348,4113,1,342,131072,2557,409,0,131137,33,135185,135307,468,64,137217,4232,4233,2557,68,169,257,135337,131136,513]

theorem envBound35398 : H12AffineFastState.Bounded env35398 := by
  intro p hp
  have h : env35398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35397_35398 : H12AffineEnvironment.transform 9 408 env35397 = env35398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env35397 == env35398) = true)

theorem identity35398 : scanCanonicalize (H12AffineFastState.compose env35398 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound35398 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35399 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,348,4113,1,342,4096,2557,409,0,4161,33,17,139,468,64,2049,4232,4233,2557,68,169,257,169,4160,513]

theorem envBound35399 : H12AffineFastState.Bounded env35399 := by
  intro p hp
  have h : env35399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35398_35399 : H12AffineEnvironment.transform 16 4096 env35398 = env35399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env35398 == env35399) = true)

theorem identity35399 : scanCanonicalize (H12AffineFastState.compose env35399 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2471) := by decide +kernel

theorem selectedBound35399 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35400 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,2471,348,2486,1,342,2471,2557,409,0,2534,33,17,139,468,64,2049,2351,2350,2557,68,169,257,169,2535,513]

theorem envBound35400 : H12AffineFastState.Bounded env35400 := by
  intro p hp
  have h : env35400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35399_35400 : H12AffineEnvironment.transform 11 2471 env35399 = env35400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2471 env35399 == env35400) = true)

theorem identity35400 : scanCanonicalize (H12AffineFastState.compose env35400 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35400 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35401 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2351,348,2366,1,342,2351,2421,273,0,2414,33,17,3,348,64,2049,2351,2350,2421,68,33,257,33,2415,513]

theorem envBound35401 : H12AffineFastState.Bounded env35401 := by
  intro p hp
  have h : env35401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35400_35401 : H12AffineEnvironment.transform 6 8 env35400 = env35401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35400 == env35401) = true)

theorem identity35401 : scanCanonicalize (H12AffineFastState.compose env35401 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound35401 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35402 : List Nat := [2,4,8,16,32,64,8,100,512,116,2048,2123,56,2138,1,50,2123,2065,117,0,2058,33,17,3,56,64,2049,2123,2122,2065,68,33,101,33,2059,513]

theorem envBound35402 : H12AffineFastState.Bounded env35402 := by
  intro p hp
  have h : env35402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35401_35402 : H12AffineEnvironment.transform 7 100 env35401 = env35402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env35401 == env35402) = true)

theorem identity35402 : scanCanonicalize (H12AffineFastState.compose env35402 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 616) := by decide +kernel

theorem selectedBound35402 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35403 : List Nat := [2,4,8,16,32,64,8,100,512,116,616,547,56,562,1,50,547,633,117,0,610,33,17,3,56,64,617,547,546,633,68,33,101,33,611,513]

theorem envBound35403 : H12AffineFastState.Bounded env35403 := by
  intro p hp
  have h : env35403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35402_35403 : H12AffineEnvironment.transform 10 616 env35402 = env35403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 616 env35402 == env35403) = true)

theorem identity35403 : scanCanonicalize (H12AffineFastState.compose env35403 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound35403 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35404 : List Nat := [2,4,8,16,32,10,8,46,512,62,546,547,56,562,1,50,547,563,63,0,552,33,17,3,56,10,547,547,546,563,14,33,47,33,553,513]

theorem envBound35404 : H12AffineFastState.Bounded env35404 := by
  intro p hp
  have h : env35404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35403_35404 : H12AffineEnvironment.transform 5 10 env35403 = env35404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env35403 == env35404) = true)

theorem identity35404 : scanCanonicalize (H12AffineFastState.compose env35404 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35404 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env35405 : List Nat := [2,4,2,16,32,0,2,36,512,52,546,547,50,562,1,50,547,563,53,0,546,33,17,3,50,0,547,547,546,563,4,33,37,33,547,513]

theorem envBound35405 : H12AffineFastState.Bounded env35405 := by
  intro p hp
  have h : env35405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35404_35405 : H12AffineEnvironment.transform 2 2 env35404 = env35405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35404 == env35405) = true)

theorem identity35405 : scanCanonicalize (H12AffineFastState.compose env35405 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35405 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35406 : List Nat := [2,4,2,1,32,0,2,36,512,37,546,547,35,547,1,35,547,546,36,0,546,33,0,3,35,0,547,547,546,546,4,33,37,33,547,513]

theorem envBound35406 : H12AffineFastState.Bounded env35406 := by
  intro p hp
  have h : env35406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35405_35406 : H12AffineEnvironment.transform 3 1 env35405 = env35406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35405 == env35406) = true)

theorem identity35406 : scanCanonicalize (H12AffineFastState.compose env35406 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound35406 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35407 : List Nat := [2,4,2,1,32,0,2,36,36,37,6,7,35,7,1,35,7,6,36,0,6,33,0,3,35,0,7,7,6,6,4,33,37,33,7,37]

theorem envBound35407 : H12AffineFastState.Bounded env35407 := by
  intro p hp
  have h : env35407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35406_35407 : H12AffineEnvironment.transform 8 36 env35406 = env35407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env35406 == env35407) = true)

theorem identity35407 : scanCanonicalize (H12AffineFastState.compose env35407 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound35407 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35408 : List Nat := [2,4,2,1,6,0,2,2,2,3,6,7,5,7,1,5,7,6,2,0,6,7,0,3,5,0,7,7,6,6,4,7,3,7,7,3]

theorem envBound35408 : H12AffineFastState.Bounded env35408 := by
  intro p hp
  have h : env35408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35407_35408 : H12AffineEnvironment.transform 4 6 env35407 = env35408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env35407 == env35408) = true)

theorem identity35408 : scanCanonicalize (H12AffineFastState.compose env35408 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35408 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env35409 : List Nat := [2,3,2,1,1,0,2,2,2,3,1,0,2,0,1,2,0,1,2,0,1,0,0,3,2,0,0,0,1,1,3,0,3,0,0,3]

theorem envBound35409 : H12AffineFastState.Bounded env35409 := by
  intro p hp
  have h : env35409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35408_35409 : H12AffineEnvironment.transform 1 3 env35408 = env35409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35408 == env35409) = true)

def env35410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180225,169234,8328,64,245139,115150,17664,262144,119042,329731,257,213486,237643,63189]

theorem envBound35410 : H12AffineFastState.Bounded env35410 := by
  intro p hp
  have h : env35410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35391_35410 : H12AffineEnvironment.transform 21 272513 env35391 = env35410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35391 == env35410) = true)

theorem identity35410 : scanCanonicalize (H12AffineFastState.compose env35410 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound35410 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,262144,1025,32769,115871,272513,120015,98780,8328,64,43357,115150,17664,262144,119042,329731,257,21792,46213,63189]

theorem envBound35411 : H12AffineFastState.Bounded env35411 := by
  intro p hp
  have h : env35411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35410_35411 : H12AffineEnvironment.transform 16 70862 env35410 = env35411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env35410 == env35411) = true)

theorem identity35411 : scanCanonicalize (H12AffineFastState.compose env35411 (packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound35411 : packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env35412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,76158,1025,32769,115871,66047,120015,98780,8328,64,43357,115150,17664,76158,119042,8573,257,21792,46213,63189]

theorem envBound35412 : H12AffineFastState.Bounded env35412 := by
  intro p hp
  have h : env35412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35411_35412 : H12AffineEnvironment.transform 17 76158 env35411 = env35412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env35411 == env35412) = true)

def env35413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,76158,1025,32769,115735,65911,119879,98644,8192,64,43357,115014,17664,76158,119042,8573,257,21792,46093,63069]

theorem envBound35413 : H12AffineFastState.Bounded env35413 := by
  intro p hp
  have h : env35413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35412_35413 : H12AffineEnvironment.transform 6 8 env35412 = env35413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35412 == env35413) = true)

theorem identity35413 : scanCanonicalize (H12AffineFastState.compose env35413 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound35413 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,70726,76158,1025,29789,77899,65911,73755,95496,8192,64,23809,79130,17664,76158,75102,8573,257,21792,16465,513]

theorem envBound35414 : H12AffineFastState.Bounded env35414 := by
  intro p hp
  have h : env35414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35413_35414 : H12AffineEnvironment.transform 14 29788 env35413 = env35414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env35413 == env35414) = true)

theorem identity35414 : scanCanonicalize (H12AffineFastState.compose env35414 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound35414 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env35415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21591,16401,32041,1025,29789,25628,21792,29772,8543,8192,64,23809,24909,17664,32041,28937,8573,257,21792,16465,513]

theorem envBound35415 : H12AffineFastState.Bounded env35415 := by
  intro p hp
  have h : env35415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35414_35415 : H12AffineEnvironment.transform 15 21591 env35414 = env35415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env35414 == env35415) = true)

theorem identity35415 : scanCanonicalize (H12AffineFastState.compose env35415 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35415 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,21591,16401,23668,1025,21760,17729,21792,21777,2,349,64,23809,16400,17664,23668,20564,32,257,21792,16465,513]

theorem envBound35416 : H12AffineFastState.Bounded env35416 := by
  intro p hp
  have h : env35416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35415_35416 : H12AffineEnvironment.transform 12 349 env35415 = env35416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35415 == env35416) = true)

theorem identity35416 : scanCanonicalize (H12AffineFastState.compose env35416 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35416 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1025,1,4160,33,16,2,349,64,2048,5393,4097,2421,1365,32,257,33,5456,513]

theorem envBound35417 : H12AffineFastState.Bounded env35417 := by
  intro p hp
  have h : env35417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35416_35417 : H12AffineEnvironment.transform 13 5377 env35416 = env35417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35416 == env35417) = true)

theorem identity35417 : scanCanonicalize (H12AffineFastState.compose env35417 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35417 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35418 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,0,35,5221,2048,1025,1,4160,33,16,2,40,64,2048,5220,4097,2048,1056,32,116,33,5157,513]

theorem envBound35418 : H12AffineFastState.Bounded env35418 := by
  intro p hp
  have h : env35418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35417_35418 : H12AffineEnvironment.transform 7 117 env35417 = env35418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35417 == env35418) = true)

theorem identity35418 : scanCanonicalize (H12AffineFastState.compose env35418 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35418 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35419 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,0,35,5172,2048,1025,1,4113,33,16,2,40,17,2048,5173,4097,2048,1056,32,37,33,5157,513]

theorem envBound35419 : H12AffineFastState.Bounded env35419 := by
  intro p hp
  have h : env35419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35418_35419 : H12AffineEnvironment.transform 5 17 env35418 = env35419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35418 == env35419) = true)

def env35420 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,40,1045,0,35,1028,2048,1025,1,33,33,16,2,40,17,2048,1029,49,2048,1056,32,37,33,1045,513]

theorem envBound35420 : H12AffineFastState.Bounded env35420 := by
  intro p hp
  have h : env35420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35419_35420 : H12AffineEnvironment.transform 11 48 env35419 = env35420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35419 == env35420) = true)

theorem identity35420 : scanCanonicalize (H12AffineFastState.compose env35420 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35420 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35421 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,48,40,1045,0,35,1028,0,1025,1,33,33,16,2,40,17,0,1029,49,0,1056,32,37,33,1045,513]

theorem envBound35421 : H12AffineFastState.Bounded env35421 := by
  intro p hp
  have h : env35421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35420_35421 : H12AffineEnvironment.transform 10 0 env35420 = env35421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35420 == env35421) = true)

def env35422 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,48,40,33,0,35,48,0,53,1,33,33,16,2,40,17,0,49,49,0,20,32,37,33,33,513]

theorem envBound35422 : H12AffineFastState.Bounded env35422 := by
  intro p hp
  have h : env35422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35421_35422 : H12AffineEnvironment.transform 9 52 env35421 = env35422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35421 == env35422) = true)

theorem identity35422 : scanCanonicalize (H12AffineFastState.compose env35422 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound35422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35423 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,48,40,33,0,35,48,0,53,1,33,33,16,2,40,17,0,49,49,0,20,32,37,33,33,11]

theorem envBound35423 : H12AffineFastState.Bounded env35423 := by
  intro p hp
  have h : env35423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35422_35423 : H12AffineEnvironment.transform 8 10 env35422 = env35423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env35422 == env35423) = true)

def leafEnv35423 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,48,40,33,0,35,48,0,53,1,33,33,16,2,21,40,1,17,0,49,49,0,20,32,37,33,5,35,33,11,1,33,0]

def active35423 : List Nat := [0,1,2,3,4]

def tree35423 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35423 : H12WitnessSearch.Good tree35423 := H12GlobalWitnessIndex.good

theorem leafIdentity35423 : H12AffineFastState.composeSystem env35423 rootObs = leafEnv35423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35423 rootObs == leafEnv35423) = true)

theorem terminalChecked35423 : H12PackedTerminal.terminalCheckFast leafEnv35423 active35423 tree35423 = true := by decide +kernel

def env35424 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,40,32,0,35,49,0,52,1,33,33,16,2,40,17,0,48,49,0,21,32,37,33,32,513]

theorem envBound35424 : H12AffineFastState.Bounded env35424 := by
  intro p hp
  have h : env35424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35421_35424 : H12AffineEnvironment.transform 9 53 env35421 = env35424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35421 == env35424) = true)

theorem identity35424 : scanCanonicalize (H12AffineFastState.compose env35424 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35424 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35425 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,9,1,0,2,16,0,21,1,0,0,16,2,9,17,0,17,16,0,21,1,4,0,1,513]

theorem envBound35425 : H12AffineFastState.Bounded env35425 := by
  intro p hp
  have h : env35425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35424_35425 : H12AffineEnvironment.transform 4 1 env35424 = env35425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35424 == env35425) = true)

def leafEnv35425 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,9,1,0,2,16,0,21,1,0,0,16,2,20,9,1,17,0,17,16,0,21,1,4,0,5,2,1,513,1,0,0]

def active35425 : List Nat := [0,1,2,3,8]

def tree35425 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35425 : H12WitnessSearch.Good tree35425 := H12GlobalWitnessIndex.good

theorem leafIdentity35425 : H12AffineFastState.composeSystem env35425 rootObs = leafEnv35425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35425 rootObs == leafEnv35425) = true)

theorem terminalChecked35425 : H12PackedTerminal.terminalCheckFast leafEnv35425 active35425 tree35425 = true := by decide +kernel

def env35426 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1044,0,35,1029,2048,1025,1,32,33,16,2,40,17,2048,1028,48,2048,1056,32,37,33,1044,513]

theorem envBound35426 : H12AffineFastState.Bounded env35426 := by
  intro p hp
  have h : env35426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35419_35426 : H12AffineEnvironment.transform 11 49 env35419 = env35426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35419 == env35426) = true)

theorem identity35426 : scanCanonicalize (H12AffineFastState.compose env35426 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound35426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35427 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,49,40,1044,0,35,1029,1076,1025,1,32,33,16,2,40,17,1076,1028,48,1076,1056,32,37,33,1044,513]

theorem envBound35427 : H12AffineFastState.Bounded env35427 := by
  intro p hp
  have h : env35427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35426_35427 : H12AffineEnvironment.transform 10 1076 env35426 = env35427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env35426 == env35427) = true)

def env35428 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,40,32,0,35,49,0,53,1,32,33,16,2,40,17,0,48,48,0,20,32,37,33,32,513]

theorem envBound35428 : H12AffineFastState.Bounded env35428 := by
  intro p hp
  have h : env35428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35427_35428 : H12AffineEnvironment.transform 9 52 env35427 = env35428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35427 == env35428) = true)

theorem identity35428 : scanCanonicalize (H12AffineFastState.compose env35428 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound35428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35429 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,49,40,32,0,35,49,0,53,1,32,33,16,2,40,17,0,48,48,0,20,32,37,33,32,11]

theorem envBound35429 : H12AffineFastState.Bounded env35429 := by
  intro p hp
  have h : env35429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35428_35429 : H12AffineEnvironment.transform 8 10 env35428 = env35429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env35428 == env35429) = true)

def leafEnv35429 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,49,40,32,0,35,49,0,53,1,32,33,16,2,21,40,1,17,0,48,48,0,20,32,37,33,5,35,32,11,1,32,0]

def active35429 : List Nat := [0,1,2,3,4]

def tree35429 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35429 : H12WitnessSearch.Good tree35429 := H12GlobalWitnessIndex.good

theorem leafIdentity35429 : H12AffineFastState.composeSystem env35429 rootObs = leafEnv35429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35429 rootObs == leafEnv35429) = true)

theorem terminalChecked35429 : H12PackedTerminal.terminalCheckFast leafEnv35429 active35429 tree35429 = true := by decide +kernel

def env35430 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,49,40,33,0,35,48,1,52,1,32,33,16,2,40,17,1,49,48,1,21,32,37,33,33,513]

theorem envBound35430 : H12AffineFastState.Bounded env35430 := by
  intro p hp
  have h : env35430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35427_35430 : H12AffineEnvironment.transform 9 53 env35427 = env35430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35427 == env35430) = true)

theorem identity35430 : scanCanonicalize (H12AffineFastState.compose env35430 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35431 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,16,9,0,0,2,17,1,21,1,1,0,16,2,9,17,1,16,17,1,21,1,4,0,0,513]

theorem envBound35431 : H12AffineFastState.Bounded env35431 := by
  intro p hp
  have h : env35431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35430_35431 : H12AffineEnvironment.transform 4 1 env35430 = env35431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35430 == env35431) = true)

def leafEnv35431 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,16,9,0,0,2,17,1,21,1,1,0,16,2,20,9,1,17,1,16,17,1,21,1,4,0,5,2,0,513,1,1,0]

def active35431 : List Nat := [0,1,2,3,8]

def tree35431 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35431 : H12WitnessSearch.Good tree35431 := H12GlobalWitnessIndex.good

theorem leafIdentity35431 : H12AffineFastState.composeSystem env35431 rootObs = leafEnv35431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35431 rootObs == leafEnv35431) = true)

theorem terminalChecked35431 : H12PackedTerminal.terminalCheckFast leafEnv35431 active35431 tree35431 = true := by decide +kernel

def env35432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,76158,1025,32769,115734,65910,119878,98645,8193,64,43357,115015,17664,76158,119042,8573,257,21792,46092,63068]

theorem envBound35432 : H12AffineFastState.Bounded env35432 := by
  intro p hp
  have h : env35432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35412_35432 : H12AffineEnvironment.transform 6 9 env35412 = env35432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35412 == env35432) = true)

theorem identity35432 : scanCanonicalize (H12AffineFastState.compose env35432 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound35432 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,70727,76158,1025,1,82966,65910,87110,65877,8193,64,10589,82247,17664,76158,86274,8573,257,21792,13324,30300]

theorem envBound35433 : H12AffineFastState.Bounded env35433 := by
  intro p hp
  have h : env35433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35432_35433 : H12AffineEnvironment.transform 14 0 env35432 = env35433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env35432 == env35433) = true)

theorem identity35433 : scanCanonicalize (H12AffineFastState.compose env35433 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound35433 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env35434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,29822,24633,23808,1025,1,12392,29960,8248,29995,8193,64,10589,13625,17664,23808,9596,8573,257,21792,13324,30300]

theorem envBound35434 : H12AffineFastState.Bounded env35434 := by
  intro p hp
  have h : env35434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35433_35434 : H12AffineEnvironment.transform 15 29822 env35433 = env35434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env35433 == env35434) = true)

theorem identity35434 : scanCanonicalize (H12AffineFastState.compose env35434 (packedSelected [0,2,3,5,6,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound35434 : packedSelected [0,2,3,5,6,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env35435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,0,8494,13673,2128,1025,1,12392,8280,8248,8315,8193,64,10589,13625,4176,2128,9596,8573,257,112,13324,8972]

theorem envBound35435 : H12AffineFastState.Bounded env35435 := by
  intro p hp
  have h : env35435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35434_35435 : H12AffineEnvironment.transform 13 5456 env35434 = env35435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env35434 == env35435) = true)

theorem identity35435 : scanCanonicalize (H12AffineFastState.compose env35435 (packedSelected [1,3,5,8,10,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35435 : packedSelected [1,3,5,8,10,26] rootPS < 2^1333 := by decide +kernel

def env35436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,0,35,5220,2128,1025,1,4453,341,309,374,268,64,2128,5172,4176,2128,1137,112,257,112,5377,513]

theorem envBound35436 : H12AffineFastState.Bounded env35436 := by
  intro p hp
  have h : env35436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35435_35436 : H12AffineEnvironment.transform 12 269 env35435 = env35436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35435 == env35436) = true)

theorem identity35436 : scanCanonicalize (H12AffineFastState.compose env35436 (packedSelected [0,2,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound35436 : packedSelected [0,2,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env35437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,4096,269,5456,0,35,5220,292,1025,1,4453,341,309,374,268,64,292,5172,4176,292,1137,112,257,112,5377,513]

theorem envBound35437 : H12AffineFastState.Bounded env35437 := by
  intro p hp
  have h : env35437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35436_35437 : H12AffineEnvironment.transform 10 372 env35436 = env35437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env35436 == env35437) = true)

def env35438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356289,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound35438 : H12AffineFastState.Bounded env35438 := by
  intro p hp
  have h : env35438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34953_35438 : H12AffineEnvironment.transform 26 30393345 env34953 = env35438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env34953 == env35438) = true)

def env35439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound35439 : H12AffineFastState.Bounded env35439 := by
  intro p hp
  have h : env35439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35438_35439 : H12AffineEnvironment.transform 18 1024 env35438 = env35439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env35438 == env35439) = true)

theorem identity35439 : scanCanonicalize (H12AffineFastState.compose env35439 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound35439 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2,8328,64,13090819,2196622,10507600,8830977,8487955,6383042,256,10601646,10560779,8430533]

theorem envBound35440 : H12AffineFastState.Bounded env35440 := by
  intro p hp
  have h : env35440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35439_35440 : H12AffineEnvironment.transform 23 2 env35439 = env35440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env35439 == env35440) = true)

def env35441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,2,8328,64,4554891,2196622,2233816,295049,246939,6383042,256,2327590,2319747,189261]

theorem envBound35441 : H12AffineFastState.Bounded env35441 := by
  intro p hp
  have h : env35441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35440_35441 : H12AffineEnvironment.transform 22 147592 env35440 = env35441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env35440 == env35441) = true)

def env35442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147592,2,8328,64,4450363,2196622,2233816,190521,246939,6383042,256,2327590,2319747,189261]

theorem envBound35442 : H12AffineFastState.Bounded env35442 := by
  intro p hp
  have h : env35442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35441_35442 : H12AffineEnvironment.transform 17 157872 env35441 = env35442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env35441 == env35442) = true)

theorem identity35442 : scanCanonicalize (H12AffineFastState.compose env35442 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound35442 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env35443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1024,32769,2097152,4194304,152,2,8328,64,4302891,2196622,2119112,43049,99467,6383042,256,2212918,2172307,41821]

theorem envBound35443 : H12AffineFastState.Bounded env35443 := by
  intro p hp
  have h : env35443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35442_35443 : H12AffineEnvironment.transform 16 16400 env35442 = env35443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env35442 == env35443) = true)

theorem identity35443 : scanCanonicalize (H12AffineFastState.compose env35443 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35443 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env35444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10400,1024,8541,2097152,4194304,152,2,8328,64,4262263,2172370,2119112,2421,75223,6383042,256,2188650,2172307,513]

theorem envBound35444 : H12AffineFastState.Bounded env35444 := by
  intro p hp
  have h : env35444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35443_35444 : H12AffineEnvironment.transform 14 8540 env35443 = env35444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35443 == env35444) = true)

def env35445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,2097152,4194304,16,2,8192,64,4262263,2172250,2118976,2421,75103,6382922,256,2188650,2172187,513]

theorem envBound35445 : H12AffineFastState.Bounded env35445 := by
  intro p hp
  have h : env35445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35444_35445 : H12AffineEnvironment.transform 6 8 env35444 = env35445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35444 == env35445) = true)

theorem identity35445 : scanCanonicalize (H12AffineFastState.compose env35445 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound35445 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env35446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,91466,4194304,16,2,8192,64,4262263,16400,77834,2421,75103,4194304,256,32,16465,513]

theorem envBound35446 : H12AffineFastState.Bounded env35446 := by
  intro p hp
  have h : env35446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35445_35446 : H12AffineEnvironment.transform 20 91466 env35445 = env35446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env35445 == env35446) = true)

theorem identity35446 : scanCanonicalize (H12AffineFastState.compose env35446 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35446 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env35447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1024,8541,17729,4194304,16,2,8192,64,4204924,16400,4097,2421,1364,4194304,256,32,16465,513]

theorem envBound35447 : H12AffineFastState.Bounded env35447 := by
  intro p hp
  have h : env35447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35446_35447 : H12AffineEnvironment.transform 15 8203 env35446 = env35447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35446 == env35447) = true)

theorem identity35447 : scanCanonicalize (H12AffineFastState.compose env35447 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35447 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35448 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,8203,16400,10280,1024,8461,17681,4194304,16,2,8192,16,4204844,16400,4097,2341,1284,4194304,256,32,16385,513]

theorem envBound35448 : H12AffineFastState.Bounded env35448 := by
  intro p hp
  have h : env35448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35447_35448 : H12AffineEnvironment.transform 5 16 env35447 = env35448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35447 == env35448) = true)

theorem identity35448 : scanCanonicalize (H12AffineFastState.compose env35448 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15366) := by decide +kernel

theorem selectedBound35448 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env35449 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,15366,8460,8203,15382,10280,1024,8461,14615,4194304,16,2,8192,16,4204844,15382,4097,2341,1284,4194304,256,32,15367,513]

theorem envBound35449 : H12AffineFastState.Bounded env35449 := by
  intro p hp
  have h : env35449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35448_35449 : H12AffineEnvironment.transform 13 15366 env35448 = env35449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15366 env35448 == env35449) = true)

theorem identity35449 : scanCanonicalize (H12AffineFastState.compose env35449 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35449 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35450 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,7434,0,263,7450,2340,1024,1,6171,4194304,16,2,268,16,4196384,7450,4097,2341,1284,4194304,256,32,7435,513]

theorem envBound35450 : H12AffineFastState.Bounded env35450 := by
  intro p hp
  have h : env35450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35449_35450 : H12AffineEnvironment.transform 12 268 env35449 = env35450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35449 == env35450) = true)

theorem identity35450 : scanCanonicalize (H12AffineFastState.compose env35450 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 5141) := by decide +kernel

theorem selectedBound35450 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35451 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,7434,0,263,7450,2340,1024,1,6171,5141,16,2,268,16,7221,7450,4097,2341,1284,5141,256,32,7435,513]

theorem envBound35451 : H12AffineFastState.Bounded env35451 := by
  intro p hp
  have h : env35451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35450_35451 : H12AffineEnvironment.transform 21 5141 env35450 = env35451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5141 env35450 == env35451) = true)

theorem identity35451 : scanCanonicalize (H12AffineFastState.compose env35451 (packedSelected [1,3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound35451 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env35452 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1077,268,2367,0,263,2351,2340,1024,1,3118,32,16,2,268,16,2048,2351,1076,2341,1284,32,256,32,2366,513]

theorem envBound35452 : H12AffineFastState.Bounded env35452 := by
  intro p hp
  have h : env35452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35451_35452 : H12AffineEnvironment.transform 11 1077 env35451 = env35452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env35451 == env35452) = true)

theorem identity35452 : scanCanonicalize (H12AffineFastState.compose env35452 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound35452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35453 : List Nat := [2,4,8,16,32,16,8,256,512,1024,271,1077,268,48,0,263,32,43,1024,1,1313,32,16,2,268,16,271,32,1076,42,1284,32,256,32,49,513]

theorem envBound35453 : H12AffineFastState.Bounded env35453 := by
  intro p hp
  have h : env35453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35452_35453 : H12AffineEnvironment.transform 10 271 env35452 = env35453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env35452 == env35453) = true)

theorem identity35453 : scanCanonicalize (H12AffineFastState.compose env35453 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35453 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35454 : List Nat := [2,4,8,16,32,16,8,21,512,1024,26,1077,25,48,0,18,32,43,1024,1,1076,32,16,2,25,16,26,32,1076,42,1041,32,21,32,49,513]

theorem envBound35454 : H12AffineFastState.Bounded env35454 := by
  intro p hp
  have h : env35454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35453_35454 : H12AffineEnvironment.transform 7 21 env35453 = env35454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35453 == env35454) = true)

theorem identity35454 : scanCanonicalize (H12AffineFastState.compose env35454 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound35454 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35455 : List Nat := [2,4,8,16,32,16,8,21,11,1024,26,1077,25,48,0,18,32,43,1024,1,1076,32,16,2,25,16,26,32,1076,42,1041,32,21,32,49,10]

theorem envBound35455 : H12AffineFastState.Bounded env35455 := by
  intro p hp
  have h : env35455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35454_35455 : H12AffineEnvironment.transform 8 11 env35454 = env35455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env35454 == env35455) = true)

theorem identity35455 : scanCanonicalize (H12AffineFastState.compose env35455 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound35455 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35456 : List Nat := [2,4,8,16,32,16,8,21,11,35,26,22,25,48,0,18,32,43,35,1,23,32,16,2,25,16,26,32,23,42,50,32,21,32,49,10]

theorem envBound35456 : H12AffineFastState.Bounded env35456 := by
  intro p hp
  have h : env35456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35455_35456 : H12AffineEnvironment.transform 9 35 env35455 = env35456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env35455 == env35456) = true)

def env35457 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,2097152,4194304,17,2,8193,64,4262263,2172251,2118977,2421,75102,6382923,256,2188650,2172186,513]

theorem envBound35457 : H12AffineFastState.Bounded env35457 := by
  intro p hp
  have h : env35457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35444_35457 : H12AffineEnvironment.transform 6 9 env35444 = env35457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35444 == env35457) = true)

theorem identity35457 : scanCanonicalize (H12AffineFastState.compose env35457 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35457 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env35458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1024,8541,2097152,4194304,17,2,8193,64,4204925,2098513,2118977,2421,1364,6309185,256,2114912,2098448,513]

theorem envBound35458 : H12AffineFastState.Bounded env35458 := by
  intro p hp
  have h : env35458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35457_35458 : H12AffineEnvironment.transform 15 8202 env35457 = env35458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35457 == env35458) = true)

theorem identity35458 : scanCanonicalize (H12AffineFastState.compose env35458 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20528) := by decide +kernel

theorem selectedBound35458 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1024,8541,2097152,20528,17,2,8193,64,31053,2098513,2118977,2421,1364,2102641,256,2114912,2098448,513]

theorem envBound35459 : H12AffineFastState.Bounded env35459 := by
  intro p hp
  have h : env35459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35458_35459 : H12AffineEnvironment.transform 21 20528 env35458 = env35459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20528 env35458 == env35459) = true)

theorem identity35459 : scanCanonicalize (H12AffineFastState.compose env35459 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 23808) := by decide +kernel

theorem selectedBound35459 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env35460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1024,8541,23808,20528,17,2,8193,64,31053,22609,2113,2421,1364,18545,256,6240,22544,513]

theorem envBound35460 : H12AffineFastState.Bounded env35460 := by
  intro p hp
  have h : env35460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35459_35460 : H12AffineEnvironment.transform 20 23808 env35459 = env35460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 23808 env35459 == env35460) = true)

theorem identity35460 : scanCanonicalize (H12AffineFastState.compose env35460 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound35460 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8202,4096,10281,1024,8541,3344,32,17,2,8193,64,10589,2113,2113,2421,1364,6241,256,6240,2048,513]

theorem envBound35461 : H12AffineFastState.Bounded env35461 := by
  intro p hp
  have h : env35461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35460_35461 : H12AffineEnvironment.transform 13 4112 env35460 = env35461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env35460 == env35461) = true)

theorem identity35461 : scanCanonicalize (H12AffineFastState.compose env35461 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound35461 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6476,4112,6160,6470,4096,4453,1024,6161,3344,32,17,2,6477,64,4113,2113,2113,2421,1364,6241,256,6240,2048,513]

theorem envBound35462 : H12AffineFastState.Bounded env35462 := by
  intro p hp
  have h : env35462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35461_35462 : H12AffineEnvironment.transform 12 6476 env35461 = env35462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env35461 == env35462) = true)

theorem identity35462 : scanCanonicalize (H12AffineFastState.compose env35462 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound35462 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1077,4096,5497,4112,5157,5491,4096,4453,1024,5156,293,32,17,2,5496,64,4113,1140,1140,1344,1364,5204,256,5205,1077,513]

theorem envBound35463 : H12AffineFastState.Bounded env35463 := by
  intro p hp
  have h : env35463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35462_35463 : H12AffineEnvironment.transform 10 1077 env35462 = env35463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env35462 == env35463) = true)

theorem identity35463 : scanCanonicalize (H12AffineFastState.compose env35463 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound35463 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1077,1061,348,1077,0,342,1061,1344,1024,1,293,32,17,2,349,64,1076,1140,1140,1344,1364,113,256,112,1077,513]

theorem envBound35464 : H12AffineFastState.Bounded env35464 := by
  intro p hp
  have h : env35464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35463_35464 : H12AffineEnvironment.transform 11 1061 env35463 = env35464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env35463 == env35464) = true)

theorem identity35464 : scanCanonicalize (H12AffineFastState.compose env35464 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35464 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35465 : List Nat := [2,4,8,16,32,64,9,256,512,100,81,65,348,81,0,342,65,292,100,1,293,32,17,2,349,64,80,16,16,292,304,113,256,112,81,513]

theorem envBound35465 : H12AffineFastState.Bounded env35465 := by
  intro p hp
  have h : env35465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35464_35465 : H12AffineEnvironment.transform 9 100 env35464 = env35465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35464 == env35465) = true)

theorem identity35465 : scanCanonicalize (H12AffineFastState.compose env35465 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35465 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35466 : List Nat := [2,4,8,16,32,64,9,116,512,100,81,65,40,81,0,34,65,80,100,1,81,32,17,2,41,64,80,16,16,80,68,113,116,112,81,513]

theorem envBound35466 : H12AffineFastState.Bounded env35466 := by
  intro p hp
  have h : env35466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35465_35466 : H12AffineEnvironment.transform 7 116 env35465 = env35466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35465 == env35466) = true)

theorem identity35466 : scanCanonicalize (H12AffineFastState.compose env35466 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound35466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35467 : List Nat := [2,4,8,16,32,64,9,116,0,100,81,65,40,81,0,34,65,80,100,1,81,32,17,2,41,64,80,16,16,80,68,113,116,112,81,1]

theorem envBound35467 : H12AffineFastState.Bounded env35467 := by
  intro p hp
  have h : env35467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35466_35467 : H12AffineEnvironment.transform 8 0 env35466 = env35467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env35466 == env35467) = true)

def env35468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147592,2,8328,64,4450362,2196622,2233816,190520,246939,6383042,256,2327590,2319747,189261]

theorem envBound35468 : H12AffineFastState.Bounded env35468 := by
  intro p hp
  have h : env35468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35441_35468 : H12AffineEnvironment.transform 17 157873 env35441 = env35468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env35441 == env35468) = true)

theorem identity35468 : scanCanonicalize (H12AffineFastState.compose env35468 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35468 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env35469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,64,4450362,2196486,2233680,190520,246803,6382922,256,2327590,2319627,189261]

theorem envBound35469 : H12AffineFastState.Bounded env35469 := by
  intro p hp
  have h : env35469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35468_35469 : H12AffineEnvironment.transform 6 8 env35468 = env35469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35468 == env35469) = true)

def env35470 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,16,4450362,2196486,2233600,190520,246803,6382874,256,2327590,2319627,189213]

theorem envBound35470 : H12AffineFastState.Bounded env35470 := by
  intro p hp
  have h : env35470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35469_35470 : H12AffineEnvironment.transform 5 16 env35469 = env35470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35469 == env35470) = true)

def env35471 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,2097152,4194304,147456,2,8192,16,4450362,2195766,2232368,190520,246051,6381610,256,2326806,2318395,189213]

theorem envBound35471 : H12AffineFastState.Bounded env35471 := by
  intro p hp
  have h : env35471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35470_35471 : H12AffineEnvironment.transform 9 304 env35470 = env35471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env35470 == env35471) = true)

theorem identity35471 : scanCanonicalize (H12AffineFastState.compose env35471 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound35471 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env35472 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,2097152,73770,147456,2,8192,16,182288,2195766,2232368,190520,246051,2113536,256,2326806,2318395,189213]

theorem envBound35472 : H12AffineFastState.Bounded env35472 := by
  intro p hp
  have h : env35472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35471_35472 : H12AffineEnvironment.transform 21 73770 env35471 = env35472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env35471 == env35472) = true)

theorem identity35472 : scanCanonicalize (H12AffineFastState.compose env35472 (packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(20+1) ^^^ 49185) := by decide +kernel

theorem selectedBound35472 : packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env35473 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,49185,73770,147456,2,8192,16,182288,82199,184337,190520,246051,32801,256,213303,237594,189213]

theorem envBound35473 : H12AffineFastState.Bounded env35473 := by
  intro p hp
  have h : env35473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35472_35473 : H12AffineEnvironment.transform 20 49185 env35472 = env35473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 49185 env35472 == env35473) = true)

theorem identity35473 : scanCanonicalize (H12AffineFastState.compose env35473 (packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35473 : packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS < 2^1333 := by decide +kernel

def env35474 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,1,65536,131072,157753,304,0,16416,73770,147456,2,8192,16,149521,82199,151568,157753,213282,32,256,213303,204827,156444]

theorem envBound35474 : H12AffineFastState.Bounded env35474 := by
  intro p hp
  have h : env35474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35473_35474 : H12AffineEnvironment.transform 14 1 env35473 = env35474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35473 == env35474) = true)

theorem identity35474 : scanCanonicalize (H12AffineFastState.compose env35474 (packedSelected [1,3,4,5,8,10,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound35474 : packedSelected [1,3,4,5,8,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35475 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,1,262,131072,157753,304,0,16416,8492,147456,2,8192,16,149521,16401,151568,157753,147492,32,256,147505,139549,156444]

theorem envBound35475 : H12AffineFastState.Bounded env35475 := by
  intro p hp
  have h : env35475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35474_35475 : H12AffineEnvironment.transform 15 262 env35474 = env35475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env35474 == env35475) = true)

theorem identity35475 : scanCanonicalize (H12AffineFastState.compose env35475 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 12297) := by decide +kernel

theorem selectedBound35475 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env35476 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,1,262,12297,22576,304,0,16416,8492,28681,2,8192,16,30744,16401,24601,22576,28717,32,256,28728,4372,21269]

theorem envBound35476 : H12AffineFastState.Bounded env35476 := by
  intro p hp
  have h : env35476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35475_35476 : H12AffineEnvironment.transform 16 12297 env35475 = env35476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12297 env35475 == env35476) = true)

theorem identity35476 : scanCanonicalize (H12AffineFastState.compose env35476 (packedSelected [0,2,3,5,7,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 12313) := by decide +kernel

theorem selectedBound35476 : packedSelected [0,2,3,5,7,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env35477 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,12313,1,262,12297,10281,304,0,12345,8492,16,2,8192,16,2049,12296,4096,10281,52,32,256,33,4372,8972]

theorem envBound35477 : H12AffineFastState.Bounded env35477 := by
  intro p hp
  have h : env35477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35476_35477 : H12AffineEnvironment.transform 13 12313 env35476 = env35477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12313 env35476 == env35477) = true)

theorem identity35477 : scanCanonicalize (H12AffineFastState.compose env35477 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound35477 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env35478 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,25,4096,1,262,4112,2096,304,0,4128,309,16,2,25,16,2049,4113,4096,2096,52,32,256,33,4372,789]

theorem envBound35478 : H12AffineFastState.Bounded env35478 := by
  intro p hp
  have h : env35478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35477_35478 : H12AffineEnvironment.transform 12 25 env35477 = env35478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env35477 == env35478) = true)

theorem identity35478 : scanCanonicalize (H12AffineFastState.compose env35478 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound35478 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35479 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,32,25,32,1,262,48,2096,304,0,0,309,16,2,25,16,2049,49,32,2096,52,32,256,33,308,789]

theorem envBound35479 : H12AffineFastState.Bounded env35479 := by
  intro p hp
  have h : env35479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35478_35479 : H12AffineEnvironment.transform 11 32 env35478 = env35479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env35478 == env35479) = true)

theorem identity35479 : scanCanonicalize (H12AffineFastState.compose env35479 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 772) := by decide +kernel

theorem selectedBound35479 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env35480 : List Nat := [2,4,8,16,32,16,8,256,512,304,772,32,25,32,1,262,48,820,304,0,0,309,16,2,25,16,773,49,32,820,52,32,256,33,308,789]

theorem envBound35480 : H12AffineFastState.Bounded env35480 := by
  intro p hp
  have h : env35480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35479_35480 : H12AffineEnvironment.transform 10 772 env35479 = env35480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env35479 == env35480) = true)

theorem identity35480 : scanCanonicalize (H12AffineFastState.compose env35480 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound35480 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35481 : List Nat := [2,4,8,16,32,16,8,256,318,304,58,32,25,32,1,262,48,10,304,0,0,309,16,2,25,16,59,49,32,10,52,32,256,33,308,43]

theorem envBound35481 : H12AffineFastState.Bounded env35481 := by
  intro p hp
  have h : env35481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35480_35481 : H12AffineEnvironment.transform 8 318 env35480 = env35481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env35480 == env35481) = true)

theorem identity35481 : scanCanonicalize (H12AffineFastState.compose env35481 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35481 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env35482 : List Nat := [2,4,8,16,1,16,8,256,287,273,27,1,25,1,1,262,17,10,273,0,0,276,16,2,25,16,26,16,1,10,21,1,256,0,277,10]

theorem envBound35482 : H12AffineFastState.Bounded env35482 := by
  intro p hp
  have h : env35482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35481_35482 : H12AffineEnvironment.transform 4 1 env35481 = env35482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35481 == env35482) = true)

theorem identity35482 : scanCanonicalize (H12AffineFastState.compose env35482 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35482 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35483 : List Nat := [2,0,8,16,1,16,8,256,283,273,27,1,25,1,1,258,17,10,273,0,0,272,16,2,25,16,26,16,1,10,17,1,256,0,273,10]

theorem envBound35483 : H12AffineFastState.Bounded env35483 := by
  intro p hp
  have h : env35483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35482_35483 : H12AffineEnvironment.transform 1 0 env35482 = env35483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35482 == env35483) = true)

theorem identity35483 : scanCanonicalize (H12AffineFastState.compose env35483 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound35483 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35484 : List Nat := [2,0,8,16,1,16,8,8,19,25,27,1,25,1,1,10,17,10,25,0,0,24,16,2,25,16,26,16,1,10,17,1,8,0,25,10]

theorem envBound35484 : H12AffineFastState.Bounded env35484 := by
  intro p hp
  have h : env35484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35483_35484 : H12AffineEnvironment.transform 7 8 env35483 = env35484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env35483 == env35484) = true)

theorem identity35484 : scanCanonicalize (H12AffineFastState.compose env35484 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35484 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env35485 : List Nat := [1,0,8,16,1,16,8,8,16,25,24,1,25,1,1,9,17,9,25,0,0,24,16,1,25,16,25,16,1,9,17,1,8,0,25,9]

theorem envBound35485 : H12AffineFastState.Bounded env35485 := by
  intro p hp
  have h : env35485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35484_35485 : H12AffineEnvironment.transform 0 1 env35484 = env35485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35484 == env35485) = true)

theorem identity35485 : scanCanonicalize (H12AffineFastState.compose env35485 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35485 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35486 : List Nat := [1,0,8,0,1,0,8,8,0,9,8,1,9,1,1,9,1,9,9,0,0,8,0,1,9,0,9,0,1,9,1,1,8,0,9,9]

theorem envBound35486 : H12AffineFastState.Bounded env35486 := by
  intro p hp
  have h : env35486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35485_35486 : H12AffineEnvironment.transform 3 0 env35485 = env35486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35485 == env35486) = true)

theorem identity35486 : scanCanonicalize (H12AffineFastState.compose env35486 (packedSelected [14] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound35486 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env35487 : List Nat := [1,0,0,0,1,0,0,0,0,1,0,1,1,1,1,1,1,1,1,0,0,0,0,1,1,0,1,0,1,1,1,1,0,0,1,1]

theorem envBound35487 : H12AffineFastState.Bounded env35487 := by
  intro p hp
  have h : env35487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35486_35487 : H12AffineEnvironment.transform 2 0 env35486 = env35487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env35486 == env35487) = true)

def env35488 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,131072,157753,305,32769,2097152,4194304,147456,2,8192,16,4450362,2195767,2232369,190520,246050,6381611,256,2326807,2318394,189213]

theorem envBound35488 : H12AffineFastState.Bounded env35488 := by
  intro p hp
  have h : env35488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35470_35488 : H12AffineEnvironment.transform 9 305 env35470 = env35488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env35470 == env35488) = true)

theorem identity35488 : scanCanonicalize (H12AffineFastState.compose env35488 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound35488 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env35489 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,131072,157753,305,32769,2097152,246070,147456,2,8192,16,10508,2195767,2232369,190520,246050,2269469,256,2326807,2318394,189213]

theorem envBound35489 : H12AffineFastState.Bounded env35489 := by
  intro p hp
  have h : env35489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35488_35489 : H12AffineEnvironment.transform 21 246070 env35488 = env35489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env35488 == env35489) = true)

theorem identity35489 : scanCanonicalize (H12AffineFastState.compose env35489 (packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound35489 : packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env35490 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,8461,65536,131072,157753,305,8460,2097152,221243,147456,2,8192,16,10508,2170938,2232369,149813,221231,2228240,256,2301978,2318394,147984]

theorem envBound35490 : H12AffineFastState.Bounded env35490 := by
  intro p hp
  have h : env35490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35489_35490 : H12AffineEnvironment.transform 14 8461 env35489 = env35490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env35489 == env35490) = true)

theorem identity35490 : scanCanonicalize (H12AffineFastState.compose env35490 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(20+1) ^^^ 82215) := by decide +kernel

theorem selectedBound35490 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env35491 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,8461,65536,131072,157753,305,8460,82215,221243,147456,2,8192,16,10508,24861,217366,149813,221231,213303,256,155965,139549,147984]

theorem envBound35491 : H12AffineFastState.Bounded env35491 := by
  intro p hp
  have h : env35491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35490_35491 : H12AffineEnvironment.transform 20 82215 env35490 = env35491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82215 env35490 == env35491) = true)

theorem identity35491 : scanCanonicalize (H12AffineFastState.compose env35491 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35491 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env35492 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,16384,1,65536,131072,149813,305,0,82215,213303,147456,2,268,16,2048,16401,217366,149813,213283,213303,256,147505,131089,147984]

theorem envBound35492 : H12AffineFastState.Bounded env35492 := by
  intro p hp
  have h : env35492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35491_35492 : H12AffineEnvironment.transform 12 268 env35491 = env35492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35491 == env35492) = true)

theorem identity35492 : scanCanonicalize (H12AffineFastState.compose env35492 (packedSelected [0,1,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 69894) := by decide +kernel

theorem selectedBound35492 : packedSelected [0,1,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35493 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,16384,1,65536,69894,88115,305,0,82215,20529,86278,2,268,16,2048,16401,16400,88115,20517,20529,256,86327,69911,86806]

theorem envBound35493 : H12AffineFastState.Bounded env35493 := by
  intro p hp
  have h : env35493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35492_35493 : H12AffineEnvironment.transform 16 69894 env35492 = env35493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69894 env35492 == env35493) = true)

theorem identity35493 : scanCanonicalize (H12AffineFastState.compose env35493 (packedSelected [4,7,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound35493 : packedSelected [4,7,10,14] rootPS < 2^1333 := by decide +kernel

def env35494 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,4113,1,65536,69894,67618,305,0,69942,32,65815,2,268,16,2048,4096,4097,67618,52,32,256,65830,69911,66311]

theorem envBound35494 : H12AffineFastState.Bounded env35494 := by
  intro p hp
  have h : env35494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35493_35494 : H12AffineEnvironment.transform 13 4113 env35493 = env35494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env35493 == env35494) = true)

theorem identity35494 : scanCanonicalize (H12AffineFastState.compose env35494 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 6162) := by decide +kernel

theorem selectedBound35494 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env35495 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,4113,1,6162,2324,4144,305,0,2340,32,6405,2,268,16,2048,4096,4097,4144,52,32,256,6452,2309,6933]

theorem envBound35495 : H12AffineFastState.Bounded env35495 := by
  intro p hp
  have h : env35495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35494_35495 : H12AffineEnvironment.transform 15 6162 env35494 = env35495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6162 env35494 == env35495) = true)

theorem identity35495 : scanCanonicalize (H12AffineFastState.compose env35495 (packedSelected [4,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35495 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env35496 : List Nat := [2,4,8,16,32,16,8,4,512,53,2048,4096,8,4113,1,6162,2064,4144,53,0,2080,32,6145,2,8,16,2048,4096,4097,4144,52,32,4,6192,2049,6673]

theorem envBound35496 : H12AffineFastState.Bounded env35496 := by
  intro p hp
  have h : env35496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35495_35496 : H12AffineEnvironment.transform 7 4 env35495 = env35496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35495 == env35496) = true)

theorem identity35496 : scanCanonicalize (H12AffineFastState.compose env35496 (packedSelected [0,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound35496 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env35497 : List Nat := [2,4,8,16,32,16,8,4,512,53,2048,2065,8,2048,1,3,2064,2081,53,0,2080,32,16,2,8,16,2048,2065,2064,2081,52,32,4,33,2049,512]

theorem envBound35497 : H12AffineFastState.Bounded env35497 := by
  intro p hp
  have h : env35497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35496_35497 : H12AffineEnvironment.transform 11 2065 env35496 = env35497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env35496 == env35497) = true)

theorem identity35497 : scanCanonicalize (H12AffineFastState.compose env35497 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 63) := by decide +kernel

theorem selectedBound35497 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35498 : List Nat := [2,4,8,16,32,16,8,4,512,53,63,46,8,63,1,3,47,30,53,0,31,32,16,2,8,16,63,46,47,30,52,32,4,33,62,512]

theorem envBound35498 : H12AffineFastState.Bounded env35498 := by
  intro p hp
  have h : env35498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35497_35498 : H12AffineEnvironment.transform 10 63 env35497 = env35498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 63 env35497 == env35498) = true)

theorem identity35498 : scanCanonicalize (H12AffineFastState.compose env35498 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35498 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35499 : List Nat := [2,4,8,16,0,16,8,4,512,21,31,14,8,31,1,3,15,30,21,0,31,0,16,2,8,16,31,14,15,30,20,0,4,1,30,512]

theorem envBound35499 : H12AffineFastState.Bounded env35499 := by
  intro p hp
  have h : env35499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35498_35499 : H12AffineEnvironment.transform 4 0 env35498 = env35499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35498 == env35499) = true)

theorem identity35499 : scanCanonicalize (H12AffineFastState.compose env35499 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35499 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35500 : List Nat := [2,4,8,16,0,16,8,4,1,21,31,14,8,31,1,3,15,30,21,0,31,0,16,2,8,16,31,14,15,30,20,0,4,1,30,1]

theorem envBound35500 : H12AffineFastState.Bounded env35500 := by
  intro p hp
  have h : env35500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35499_35500 : H12AffineEnvironment.transform 8 1 env35499 = env35500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35499 == env35500) = true)

def leafEnv35500 : List Nat := [2,4,8,16,0,16,8,4,1,21,31,14,8,31,1,3,15,30,21,0,31,0,16,2,20,8,1,16,31,14,15,30,20,0,4,1,4,3,30,1,1,30,0]

def active35500 : List Nat := [0,1,2,3]

def tree35500 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35500 : H12WitnessSearch.Good tree35500 := H12GlobalWitnessIndex.good

theorem leafIdentity35500 : H12AffineFastState.composeSystem env35500 rootObs = leafEnv35500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35500 rootObs == leafEnv35500) = true)

theorem terminalChecked35500 : H12PackedTerminal.terminalCheckFast leafEnv35500 active35500 tree35500 = true := by decide +kernel

def env35501 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,17,4450362,2196486,2233601,190520,246803,6382875,256,2327590,2319627,189212]

theorem envBound35501 : H12AffineFastState.Bounded env35501 := by
  intro p hp
  have h : env35501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35469_35501 : H12AffineEnvironment.transform 5 17 env35469 = env35501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35469 == env35501) = true)

def env35502 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,2097152,4194304,147456,2,8192,17,4450362,2195766,2232369,190520,246051,6381611,256,2326806,2318395,189212]

theorem envBound35502 : H12AffineFastState.Bounded env35502 := by
  intro p hp
  have h : env35502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35501_35502 : H12AffineEnvironment.transform 9 304 env35501 = env35502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env35501 == env35502) = true)

theorem identity35502 : scanCanonicalize (H12AffineFastState.compose env35502 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound35502 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env35503 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,2097152,32,147456,2,8192,17,256026,2195766,2232369,190520,246051,2187275,256,2326806,2318395,189212]

theorem envBound35503 : H12AffineFastState.Bounded env35503 := by
  intro p hp
  have h : env35503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35502_35503 : H12AffineEnvironment.transform 21 32 env35502 = env35503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env35502 == env35503) = true)

theorem identity35503 : scanCanonicalize (H12AffineFastState.compose env35503 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound35503 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env35504 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,8460,65536,131072,157753,304,8461,2097152,32,147456,2,8192,17,215318,2170938,2232369,149812,221231,2187275,256,2301978,2318395,147984]

theorem envBound35504 : H12AffineFastState.Bounded env35504 := by
  intro p hp
  have h : env35504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35503_35504 : H12AffineEnvironment.transform 14 8460 env35503 = env35504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env35503 == env35504) = true)

theorem identity35504 : scanCanonicalize (H12AffineFastState.compose env35504 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35504 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env35505 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,0,65536,131072,149813,304,1,2097152,32,147456,2,268,17,215318,2162998,2232369,149812,213283,2179335,256,2294038,2310455,147984]

theorem envBound35505 : H12AffineFastState.Bounded env35505 := by
  intro p hp
  have h : env35505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35504_35505 : H12AffineEnvironment.transform 12 268 env35504 = env35505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35504 == env35505) = true)

theorem identity35505 : scanCanonicalize (H12AffineFastState.compose env35505 (packedSelected [1,2,6,8,10,11,12,14,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 196919) := by decide +kernel

theorem selectedBound35505 : packedSelected [1,2,6,8,10,11,12,14,16,17] rootPS < 2^1333 := by decide +kernel

def env35506 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,0,65536,131072,149813,304,1,196919,32,147456,2,268,17,215318,131073,69894,149812,213283,147504,256,33,16384,147984]

theorem envBound35506 : H12AffineFastState.Bounded env35506 := by
  intro p hp
  have h : env35506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35505_35506 : H12AffineEnvironment.transform 20 196919 env35505 = env35506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 196919 env35505 == env35506) = true)

theorem identity35506 : scanCanonicalize (H12AffineFastState.compose env35506 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound35506 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env35507 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,0,65536,82199,67618,304,1,16416,32,65815,2,268,17,2049,82198,69894,67619,52,65831,256,33,16384,66311]

theorem envBound35507 : H12AffineFastState.Bounded env35507 := by
  intro p hp
  have h : env35507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35506_35507 : H12AffineEnvironment.transform 16 82199 env35506 = env35507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env35506 == env35507) = true)

theorem identity35507 : scanCanonicalize (H12AffineFastState.compose env35507 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 20530) := by decide +kernel

theorem selectedBound35507 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env35508 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,0,20530,4389,22544,304,1,16416,32,20773,2,268,17,2049,4388,16692,22545,52,20757,256,33,16384,21301]

theorem envBound35508 : H12AffineFastState.Bounded env35508 := by
  intro p hp
  have h : env35508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35507_35508 : H12AffineEnvironment.transform 15 20530 env35507 = env35508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20530 env35507 == env35508) = true)

theorem identity35508 : scanCanonicalize (H12AffineFastState.compose env35508 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound35508 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env35509 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,4373,0,295,4389,2309,304,1,4405,32,48,2,268,17,2049,4388,4129,2308,52,0,256,33,4373,544]

theorem envBound35509 : H12AffineFastState.Bounded env35509 := by
  intro p hp
  have h : env35509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35508_35509 : H12AffineEnvironment.transform 13 4373 env35508 = env35509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env35508 == env35509) = true)

def env35510 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,131072,157753,305,32769,2097152,4194304,147456,2,8192,17,4450362,2195767,2232368,190520,246050,6381610,256,2326807,2318394,189212]

theorem envBound35510 : H12AffineFastState.Bounded env35510 := by
  intro p hp
  have h : env35510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35501_35510 : H12AffineEnvironment.transform 9 305 env35501 = env35510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env35501 == env35510) = true)

theorem identity35510 : scanCanonicalize (H12AffineFastState.compose env35510 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 188733) := by decide +kernel

theorem selectedBound35510 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env35511 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,131072,157753,305,32769,2097152,188733,147456,2,8192,17,67847,2195767,2232368,190520,246050,2326807,256,2326807,2318394,189212]

theorem envBound35511 : H12AffineFastState.Bounded env35511 := by
  intro p hp
  have h : env35511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35510_35511 : H12AffineEnvironment.transform 21 188733 env35510 = env35511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188733 env35510 == env35511) = true)

theorem identity35511 : scanCanonicalize (H12AffineFastState.compose env35511 (packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound35511 : packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env35512 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,114967,108846,305,32769,2097152,73770,98583,2,8192,17,67847,2195767,2216231,76079,53,2113536,256,2113536,2138413,74251]

theorem envBound35512 : H12AffineFastState.Bounded env35512 := by
  intro p hp
  have h : env35512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35511_35512 : H12AffineEnvironment.transform 16 114967 env35511 = env35512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env35511 == env35512) = true)

theorem identity35512 : scanCanonicalize (H12AffineFastState.compose env35512 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 16416) := by decide +kernel

theorem selectedBound35512 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env35513 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,114967,108846,305,32769,16416,73770,98583,2,8192,17,67847,114967,102663,76079,53,32,256,32,57613,74251]

theorem envBound35513 : H12AffineFastState.Bounded env35513 := by
  intro p hp
  have h : env35513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35512_35513 : H12AffineEnvironment.transform 20 16416 env35512 = env35513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16416 env35512 == env35513) = true)

theorem identity35513 : scanCanonicalize (H12AffineFastState.compose env35513 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound35513 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35514 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,40971,24860,2341,305,32769,16416,32801,8476,2,8192,17,43276,24860,12556,35108,53,32,256,32,57613,33280]

theorem envBound35514 : H12AffineFastState.Bounded env35514 := by
  intro p hp
  have h : env35514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35513_35514 : H12AffineEnvironment.transform 15 40971 env35513 = env35514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env35513 == env35514) = true)

theorem identity35514 : scanCanonicalize (H12AffineFastState.compose env35514 (packedSelected [0,6,7,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 14652) := by decide +kernel

theorem selectedBound35514 : packedSelected [0,6,7,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35515 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,14652,32768,40971,6176,2341,305,32769,14620,32801,8476,2,8192,17,43276,6176,12556,35108,53,32,256,32,38961,33280]

theorem envBound35515 : H12AffineFastState.Bounded env35515 := by
  intro p hp
  have h : env35515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35514_35515 : H12AffineEnvironment.transform 13 14652 env35514 = env35515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14652 env35514 == env35515) = true)

theorem identity35515 : scanCanonicalize (H12AffineFastState.compose env35515 (packedSelected [6,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35515 : packedSelected [6,14,15,17] rootPS < 2^1333 := by decide +kernel

def env35516 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,269,6193,32768,33030,6176,2341,305,32769,6161,32801,17,2,269,17,34817,6176,4097,35108,53,32,256,32,38961,33280]

theorem envBound35516 : H12AffineFastState.Bounded env35516 := by
  intro p hp
  have h : env35516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35515_35516 : H12AffineEnvironment.transform 12 269 env35515 = env35516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35515 == env35516) = true)

theorem identity35516 : scanCanonicalize (H12AffineFastState.compose env35516 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35516 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35517 : List Nat := [2,4,8,16,32,17,8,256,512,305,0,4096,269,4145,32768,33030,4128,293,305,32769,4113,32801,17,2,269,17,32769,4128,4097,33060,53,32,256,32,36913,33280]

theorem envBound35517 : H12AffineFastState.Bounded env35517 := by
  intro p hp
  have h : env35517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35516_35517 : H12AffineEnvironment.transform 10 0 env35516 = env35517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35516 == env35517) = true)

theorem identity35517 : scanCanonicalize (H12AffineFastState.compose env35517 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound35517 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env35518 : List Nat := [2,4,8,16,32,17,8,256,512,305,0,277,269,292,32768,33030,309,293,305,32769,260,32801,17,2,269,17,32769,309,276,33060,53,32,256,32,33060,33280]

theorem envBound35518 : H12AffineFastState.Bounded env35518 := by
  intro p hp
  have h : env35518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35517_35518 : H12AffineEnvironment.transform 11 277 env35517 = env35518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env35517 == env35518) = true)

theorem identity35518 : scanCanonicalize (H12AffineFastState.compose env35518 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35518 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env35519 : List Nat := [2,4,8,16,32,17,8,37,512,20,0,48,40,1,32768,32803,16,0,20,32769,33,32801,17,2,40,17,32769,16,49,32769,53,32,37,32,32769,33280]

theorem envBound35519 : H12AffineFastState.Bounded env35519 := by
  intro p hp
  have h : env35519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35518_35519 : H12AffineEnvironment.transform 7 37 env35518 = env35519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35518 == env35519) = true)

def env35520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,2,8328,64,4554890,2196622,2233817,295048,246938,6383042,256,2327591,2319746,189260]

theorem envBound35520 : H12AffineFastState.Bounded env35520 := by
  intro p hp
  have h : env35520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35440_35520 : H12AffineEnvironment.transform 22 147593 env35440 = env35520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env35440 == env35520) = true)

def env35521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147593,2,8328,64,4450362,2196622,2233817,190520,246938,6383042,256,2327591,2319746,189260]

theorem envBound35521 : H12AffineFastState.Bounded env35521 := by
  intro p hp
  have h : env35521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35520_35521 : H12AffineEnvironment.transform 17 157872 env35520 = env35521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env35520 == env35521) = true)

theorem identity35521 : scanCanonicalize (H12AffineFastState.compose env35521 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57797) := by decide +kernel

theorem selectedBound35521 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env35522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,35189,1024,32769,2097152,4194304,41292,2,8328,64,4262399,2196622,2159644,2557,75103,6383042,256,2188770,2196551,649]

theorem envBound35522 : H12AffineFastState.Bounded env35522 := by
  intro p hp
  have h : env35522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35521_35522 : H12AffineEnvironment.transform 16 57797 env35521 = env35522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env35521 == env35522) = true)

def env35523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,35189,1024,32769,2097152,32,41292,2,8328,64,68063,2196622,2159644,2557,75103,2188770,256,2188770,2196551,649]

theorem envBound35523 : H12AffineFastState.Bounded env35523 := by
  intro p hp
  have h : env35523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35522_35523 : H12AffineEnvironment.transform 21 32 env35522 = env35523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env35522 == env35523) = true)

theorem identity35523 : scanCanonicalize (H12AffineFastState.compose env35523 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35523 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35189,1024,32769,2097152,32,41292,2,8192,64,67927,2196486,2159644,2421,75103,2188650,256,2188650,2196551,513]

theorem envBound35524 : H12AffineFastState.Bounded env35524 := by
  intro p hp
  have h : env35524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35523_35524 : H12AffineEnvironment.transform 6 8 env35523 = env35524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35523 == env35524) = true)

theorem identity35524 : scanCanonicalize (H12AffineFastState.compose env35524 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound35524 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env35525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,35189,1024,32769,2097152,32,41292,2,8192,64,34816,2098513,2159644,2421,41992,2155581,256,2155581,2098448,513]

theorem envBound35525 : H12AffineFastState.Bounded env35525 := by
  intro p hp
  have h : env35525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35524_35525 : H12AffineEnvironment.transform 15 33111 env35524 = env35525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env35524 == env35525) = true)

theorem identity35525 : scanCanonicalize (H12AffineFastState.compose env35525 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35525 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,33111,49216,35189,1024,32769,2097152,32,32833,2,269,64,34816,2098513,2151697,2421,34053,2147632,256,2147632,2098448,513]

theorem envBound35526 : H12AffineFastState.Bounded env35526 := by
  intro p hp
  have h : env35526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35525_35526 : H12AffineEnvironment.transform 12 269 env35525 = env35526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35525 == env35526) = true)

theorem identity35526 : scanCanonicalize (H12AffineFastState.compose env35526 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

end H12CloudChart0