import H12CloudChart0Data065

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity16613 : scanCanonicalize (H12AffineFastState.compose env16613 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16613 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16614 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4404,0,262,4389,2340,53,1,4112,32,16,3,269,17,2049,4389,4096,2341,304,33,257,33,4404,513]

theorem envBound16614 : H12AffineFastState.Bounded env16614 := by
  intro p hp
  have h : env16614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16613_16614 : H12AffineEnvironment.transform 9 52 env16613 = env16614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16613 == env16614) = true)

theorem identity16614 : scanCanonicalize (H12AffineFastState.compose env16614 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16614 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16615 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4113,0,35,4096,2049,53,1,4112,32,16,3,40,17,2049,4096,4096,2048,21,33,36,33,4113,513]

theorem envBound16615 : H12AffineFastState.Bounded env16615 := by
  intro p hp
  have h : env16615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16614_16615 : H12AffineEnvironment.transform 7 37 env16614 = env16615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16614 == env16615) = true)

theorem identity16615 : scanCanonicalize (H12AffineFastState.compose env16615 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound16615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16616 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2577,41,2560,0,35,2577,2049,53,1,2561,32,16,3,40,17,2049,2577,2577,2048,21,33,36,33,2560,513]

theorem envBound16616 : H12AffineFastState.Bounded env16616 := by
  intro p hp
  have h : env16616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16615_16616 : H12AffineEnvironment.transform 11 2577 env16615 = env16616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env16615 == env16616) = true)

theorem identity16616 : scanCanonicalize (H12AffineFastState.compose env16616 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound16616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16617 : List Nat := [2,4,8,16,32,17,9,37,512,52,59,554,41,571,0,35,554,58,53,1,570,32,16,3,40,17,58,554,554,59,21,33,36,33,571,513]

theorem envBound16617 : H12AffineFastState.Bounded env16617 := by
  intro p hp
  have h : env16617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16616_16617 : H12AffineEnvironment.transform 10 59 env16616 = env16617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env16616 == env16617) = true)

theorem identity16617 : scanCanonicalize (H12AffineFastState.compose env16617 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound16617 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16618 : List Nat := [2,4,8,16,26,17,9,31,512,14,1,528,19,513,0,25,528,0,15,1,512,26,16,3,18,17,0,528,528,1,21,27,30,27,513,513]

theorem envBound16618 : H12AffineFastState.Bounded env16618 := by
  intro p hp
  have h : env16618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16617_16618 : H12AffineEnvironment.transform 4 26 env16617 = env16618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env16617 == env16618) = true)

theorem identity16618 : scanCanonicalize (H12AffineFastState.compose env16618 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16618 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16619 : List Nat := [2,4,8,16,26,17,9,31,0,14,1,16,19,1,0,25,16,0,15,1,0,26,16,3,18,17,0,16,16,1,21,27,30,27,1,1]

theorem envBound16619 : H12AffineFastState.Bounded env16619 := by
  intro p hp
  have h : env16619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16618_16619 : H12AffineEnvironment.transform 8 0 env16618 = env16619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16618 == env16619) = true)

def env16620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6664478,8393984,10507601,8724626,2102684,12645453,257,21792,46212,2175563]

theorem envBound16620 : H12AffineFastState.Bounded env16620 := by
  intro p hp
  have h : env16620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16539_16620 : H12AffineEnvironment.transform 23 10588557 env16539 = env16620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env16539 == env16620) = true)

def env16621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6664478,2098512,17665,2437314,2102684,6349853,257,21792,46212,2175563]

theorem envBound16621 : H12AffineFastState.Bounded env16621 := by
  intro p hp
  have h : env16621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16620_16621 : H12AffineEnvironment.transform 22 2101328 env16620 = env16621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env16620 == env16621) = true)

def env16622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2202014,2098512,17665,2437314,2102684,2411677,257,21792,46212,2175563]

theorem envBound16622 : H12AffineFastState.Bounded env16622 := by
  intro p hp
  have h : env16622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16621_16622 : H12AffineEnvironment.transform 21 272512 env16621 = env16622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16621 == env16622) = true)

theorem identity16622 : scanCanonicalize (H12AffineFastState.compose env16622 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16622 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,2097152,272512,2101328,41430,8328,64,2144661,2098512,17665,2363593,2102684,2411677,257,21792,46212,2101824]

theorem envBound16623 : H12AffineFastState.Bounded env16623 := by
  intro p hp
  have h : env16623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16622_16623 : H12AffineEnvironment.transform 15 8203 env16622 = env16623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16622 == env16623) = true)

def env16624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2202015,2098512,17665,2437314,2102684,2411676,257,21792,46212,2175563]

theorem envBound16624 : H12AffineFastState.Bounded env16624 := by
  intro p hp
  have h : env16624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16621_16624 : H12AffineEnvironment.transform 21 272513 env16621 = env16624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16621 == env16624) = true)

theorem identity16624 : scanCanonicalize (H12AffineFastState.compose env16624 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound16624 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,77898,272513,73754,98781,8328,64,43477,79130,17665,262280,75222,392406,257,21792,46212,513]

theorem envBound16625 : H12AffineFastState.Bounded env16625 := by
  intro p hp
  have h : env16625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16624_16625 : H12AffineEnvironment.transform 20 77898 env16624 = env16625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env16624 == env16625) = true)

def env16626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90258,262144,1025,1,77898,272513,73754,66013,8328,64,10709,79130,17665,262280,75222,359638,257,21792,13444,513]

theorem envBound16626 : H12AffineFastState.Bounded env16626 := by
  intro p hp
  have h : env16626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16625_16626 : H12AffineEnvironment.transform 14 0 env16625 = env16626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env16625 == env16626) = true)

theorem identity16626 : scanCanonicalize (H12AffineFastState.compose env16626 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16626 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env16627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90139,262144,1025,1,77898,272392,73754,65876,8193,64,10588,79130,17665,262145,75103,359519,257,21792,13325,513]

theorem envBound16627 : H12AffineFastState.Bounded env16627 := by
  intro p hp
  have h : env16627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16626_16627 : H12AffineEnvironment.transform 6 9 env16626 = env16627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16626 == env16627) = true)

theorem identity16627 : scanCanonicalize (H12AffineFastState.compose env16627 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound16627 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env16628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90139,67618,1025,1,77898,73770,73754,65876,8193,64,10588,79130,17665,67619,75103,29821,257,21792,13325,513]

theorem envBound16628 : H12AffineFastState.Bounded env16628 := by
  intro p hp
  have h : env16628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16627_16628 : H12AffineEnvironment.transform 17 67618 env16627 = env16628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env16627 == env16628) = true)

theorem identity16628 : scanCanonicalize (H12AffineFastState.compose env16628 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound16628 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env16629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,65536,70726,67618,1025,1,77898,73770,73754,65876,8193,64,10588,79130,12636,67619,75103,32,257,8573,13325,513]

theorem envBound16629 : H12AffineFastState.Bounded env16629 := by
  intro p hp
  have h : env16629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16628_16629 : H12AffineEnvironment.transform 13 13405 env16628 = env16629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env16628 == env16629) = true)

theorem identity16629 : scanCanonicalize (H12AffineFastState.compose env16629 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16629 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,65536,70726,67618,1025,1,69910,65910,65862,65876,349,64,2048,70726,4096,67619,66563,32,257,33,5457,513]

theorem envBound16630 : H12AffineFastState.Bounded env16630 := by
  intro p hp
  have h : env16630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16629_16630 : H12AffineEnvironment.transform 12 348 env16629 = env16630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16629 == env16630) = true)

theorem identity16630 : scanCanonicalize (H12AffineFastState.compose env16630 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound16630 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env16631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5393,2421,1025,1,4161,33,17,3,349,64,2048,5393,4096,2420,1364,32,257,33,5457,513]

theorem envBound16631 : H12AffineFastState.Bounded env16631 := by
  intro p hp
  have h : env16631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16630_16631 : H12AffineEnvironment.transform 15 343 env16630 = env16631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env16630 == env16631) = true)

theorem identity16631 : scanCanonicalize (H12AffineFastState.compose env16631 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound16631 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,357,348,1124,0,343,1140,2421,1025,1,292,33,17,3,349,64,2048,1140,357,2420,1364,32,257,33,1076,513]

theorem envBound16632 : H12AffineFastState.Bounded env16632 := by
  intro p hp
  have h : env16632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16631_16632 : H12AffineEnvironment.transform 11 357 env16631 = env16632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env16631 == env16632) = true)

theorem identity16632 : scanCanonicalize (H12AffineFastState.compose env16632 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound16632 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,357,348,1124,0,343,1140,1297,1025,1,292,33,17,3,349,64,1124,1140,357,1296,1364,32,257,33,1076,513]

theorem envBound16633 : H12AffineFastState.Bounded env16633 := by
  intro p hp
  have h : env16633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16632_16633 : H12AffineEnvironment.transform 10 1124 env16632 = env16633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env16632 == env16633) = true)

theorem identity16633 : scanCanonicalize (H12AffineFastState.compose env16633 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound16633 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env16634 : List Nat := [2,4,8,16,32,64,9,256,308,1024,1124,357,348,1124,0,343,1140,1297,1025,1,292,33,17,3,349,64,1124,1140,357,1296,1364,32,257,33,1076,309]

theorem envBound16634 : H12AffineFastState.Bounded env16634 := by
  intro p hp
  have h : env16634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16633_16634 : H12AffineEnvironment.transform 8 308 env16633 = env16634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env16633 == env16634) = true)

theorem identity16634 : scanCanonicalize (H12AffineFastState.compose env16634 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16634 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env16635 : List Nat := [2,4,8,16,16,64,9,256,260,1024,1108,341,348,1108,0,343,1092,1297,1025,1,276,17,17,3,349,64,1108,1092,341,1296,1364,16,257,17,1028,261]

theorem envBound16635 : H12AffineFastState.Bounded env16635 := by
  intro p hp
  have h : env16635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16634_16635 : H12AffineEnvironment.transform 4 16 env16634 = env16635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16634 == env16635) = true)

theorem identity16635 : scanCanonicalize (H12AffineFastState.compose env16635 (packedSelected [2,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16635 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env16636 : List Nat := [2,4,8,1,1,64,9,256,260,1024,1093,324,333,1093,0,326,1092,1280,1025,1,261,0,0,3,332,64,1093,1092,324,1281,1349,1,257,0,1028,261]

theorem envBound16636 : H12AffineFastState.Bounded env16636 := by
  intro p hp
  have h : env16636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16635_16636 : H12AffineEnvironment.transform 3 1 env16635 = env16636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16635 == env16636) = true)

theorem identity16636 : scanCanonicalize (H12AffineFastState.compose env16636 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound16636 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env16637 : List Nat := [2,4,8,1,1,1,9,256,260,1024,1028,261,268,1028,0,263,1029,1280,1025,1,261,0,0,3,269,1,1028,1029,261,1281,1284,1,257,0,1028,261]

theorem envBound16637 : H12AffineFastState.Bounded env16637 := by
  intro p hp
  have h : env16637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16636_16637 : H12AffineEnvironment.transform 5 1 env16636 = env16637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16636 == env16637) = true)

theorem identity16637 : scanCanonicalize (H12AffineFastState.compose env16637 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound16637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16638 : List Nat := [2,4,8,1,1,1,9,256,260,256,260,261,268,260,0,263,261,0,257,1,261,0,0,3,269,1,260,261,261,1,4,1,257,0,260,261]

theorem envBound16638 : H12AffineFastState.Bounded env16638 := by
  intro p hp
  have h : env16638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16637_16638 : H12AffineEnvironment.transform 9 256 env16637 = env16638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env16637 == env16638) = true)

theorem identity16638 : scanCanonicalize (H12AffineFastState.compose env16638 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16639 : List Nat := [2,4,8,1,1,1,9,4,0,4,0,1,8,0,0,3,1,0,5,1,1,0,0,3,9,1,0,1,1,1,4,1,5,0,0,1]

theorem envBound16639 : H12AffineFastState.Bounded env16639 := by
  intro p hp
  have h : env16639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16638_16639 : H12AffineEnvironment.transform 7 4 env16638 = env16639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16638 == env16639) = true)

def env16640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90259,262144,1025,0,77898,272513,73754,66012,8328,64,10708,79130,17665,262280,75222,359639,257,21792,13445,513]

theorem envBound16640 : H12AffineFastState.Bounded env16640 := by
  intro p hp
  have h : env16640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16625_16640 : H12AffineEnvironment.transform 14 1 env16625 = env16640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env16625 == env16640) = true)

theorem identity16640 : scanCanonicalize (H12AffineFastState.compose env16640 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound16640 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env16641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8322,16401,262144,1025,0,4296,272513,152,8542,8328,64,10708,5528,17665,262280,1364,285781,257,21792,13445,513]

theorem envBound16641 : H12AffineFastState.Bounded env16641 := by
  intro p hp
  have h : env16641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16640_16641 : H12AffineEnvironment.transform 15 8322 env16640 = env16641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env16640 == env16641) = true)

theorem identity16641 : scanCanonicalize (H12AffineFastState.compose env16641 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound16641 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env16642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8322,16401,10281,1025,0,4296,168,152,8542,8328,64,10708,5528,17665,10401,1364,29820,257,21792,13445,513]

theorem envBound16642 : H12AffineFastState.Bounded env16642 := by
  intro p hp
  have h : env16642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16641_16642 : H12AffineEnvironment.transform 17 10281 env16641 = env16642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env16641 == env16642) = true)

theorem identity16642 : scanCanonicalize (H12AffineFastState.compose env16642 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound16642 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env16643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,1,342,16401,2557,1025,0,4296,168,152,138,348,64,2048,5528,17665,2421,1364,21928,257,21792,5457,513]

theorem envBound16643 : H12AffineFastState.Bounded env16643 := by
  intro p hp
  have h : env16643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16642_16643 : H12AffineEnvironment.transform 12 468 env16642 = env16643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env16642 == env16643) = true)

theorem identity16643 : scanCanonicalize (H12AffineFastState.compose env16643 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound16643 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env16644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,1,342,5392,2557,1025,0,4296,168,152,138,348,64,2048,5528,4096,2421,1364,169,257,33,5457,513]

theorem envBound16644 : H12AffineFastState.Bounded env16644 := by
  intro p hp
  have h : env16644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16643_16644 : H12AffineEnvironment.transform 13 5377 env16643 = env16644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16643 == env16644) = true)

theorem identity16644 : scanCanonicalize (H12AffineFastState.compose env16644 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16644 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env16645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5392,2421,1025,0,4160,32,16,2,348,64,2048,5392,4096,2421,1364,33,257,33,5457,513]

theorem envBound16645 : H12AffineFastState.Bounded env16645 := by
  intro p hp
  have h : env16645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16644_16645 : H12AffineEnvironment.transform 6 8 env16644 = env16645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16644 == env16645) = true)

theorem identity16645 : scanCanonicalize (H12AffineFastState.compose env16645 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16645 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16646 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4112,1,342,4097,2421,272,0,4160,32,16,2,348,64,2048,4097,4096,2421,69,33,257,33,4160,513]

theorem envBound16646 : H12AffineFastState.Bounded env16646 := by
  intro p hp
  have h : env16646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16645_16646 : H12AffineEnvironment.transform 9 273 env16645 = env16646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16645 == env16646) = true)

theorem identity16646 : scanCanonicalize (H12AffineFastState.compose env16646 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16646 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16647 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,4112,1,263,4097,2340,272,0,4113,32,16,2,269,17,2048,4097,4096,2340,20,33,257,33,4113,513]

theorem envBound16647 : H12AffineFastState.Bounded env16647 := by
  intro p hp
  have h : env16647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16646_16647 : H12AffineEnvironment.transform 5 17 env16646 = env16647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16646 == env16647) = true)

theorem identity16647 : scanCanonicalize (H12AffineFastState.compose env16647 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound16647 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16648 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,309,269,293,1,263,308,2340,272,0,292,32,16,2,269,17,2048,308,309,2340,20,33,257,33,292,513]

theorem envBound16648 : H12AffineFastState.Bounded env16648 := by
  intro p hp
  have h : env16648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16647_16648 : H12AffineEnvironment.transform 11 309 env16647 = env16648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env16647 == env16648) = true)

theorem identity16648 : scanCanonicalize (H12AffineFastState.compose env16648 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound16648 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16649 : List Nat := [2,4,8,16,32,17,8,256,512,273,293,309,269,293,1,263,308,1,272,0,292,32,16,2,269,17,293,308,309,1,20,33,257,33,292,513]

theorem envBound16649 : H12AffineFastState.Bounded env16649 := by
  intro p hp
  have h : env16649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16648_16649 : H12AffineEnvironment.transform 10 293 env16648 = env16649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env16648 == env16649) = true)

theorem identity16649 : scanCanonicalize (H12AffineFastState.compose env16649 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16649 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16650 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,17,41,1,1,35,16,1,52,0,0,32,16,2,41,17,1,16,17,1,20,33,37,33,0,513]

theorem envBound16650 : H12AffineFastState.Bounded env16650 := by
  intro p hp
  have h : env16650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16649_16650 : H12AffineEnvironment.transform 7 36 env16649 = env16650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16649 == env16650) = true)

theorem identity16650 : scanCanonicalize (H12AffineFastState.compose env16650 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound16650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16651 : List Nat := [2,4,8,16,17,17,8,21,512,4,1,17,24,1,1,18,16,1,5,0,0,17,16,2,24,17,1,16,17,1,20,16,20,16,0,513]

theorem envBound16651 : H12AffineFastState.Bounded env16651 := by
  intro p hp
  have h : env16651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16650_16651 : H12AffineEnvironment.transform 4 17 env16650 = env16651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env16650 == env16651) = true)

theorem identity16651 : scanCanonicalize (H12AffineFastState.compose env16651 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16651 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16652 : List Nat := [2,4,8,16,17,17,8,21,1,4,1,17,24,1,1,18,16,1,5,0,0,17,16,2,24,17,1,16,17,1,20,16,20,16,0,0]

theorem envBound16652 : H12AffineFastState.Bounded env16652 := by
  intro p hp
  have h : env16652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16651_16652 : H12AffineEnvironment.transform 8 1 env16651 = env16652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16651 == env16652) = true)

def env16653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6664478,2098513,17664,2437315,2102684,6349852,257,21792,46212,2175563]

theorem envBound16653 : H12AffineFastState.Bounded env16653 := by
  intro p hp
  have h : env16653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16620_16653 : H12AffineEnvironment.transform 22 2101329 env16620 = env16653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env16620 == env16653) = true)

def env16654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2202014,2098513,17664,2437315,2102684,2411676,257,21792,46212,2175563]

theorem envBound16654 : H12AffineFastState.Bounded env16654 := by
  intro p hp
  have h : env16654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16653_16654 : H12AffineEnvironment.transform 21 272512 env16653 = env16654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16653 == env16654) = true)

theorem identity16654 : scanCanonicalize (H12AffineFastState.compose env16654 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound16654 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,13388,262144,1025,32769,2097152,272512,2101329,21762,8328,64,2116928,2098513,17664,2417693,2102684,2411676,257,21792,46212,2156181]

theorem envBound16655 : H12AffineFastState.Bounded env16655 := by
  intro p hp
  have h : env16655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16654_16655 : H12AffineEnvironment.transform 15 54494 env16654 = env16655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env16654 == env16655) = true)

def env16656 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,13340,262144,1025,32769,2097152,272512,2101249,21762,8328,16,2116880,2098433,17664,2417693,2102684,2411676,257,21792,46212,2156181]

theorem envBound16656 : H12AffineFastState.Bounded env16656 := by
  intro p hp
  have h : env16656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16655_16656 : H12AffineEnvironment.transform 5 16 env16655 = env16656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16655 == env16656) = true)

theorem identity16656 : scanCanonicalize (H12AffineFastState.compose env16656 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 290105) := by decide +kernel

theorem selectedBound16656 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env16657 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,13340,262144,1025,32769,290105,272512,294200,21762,8328,16,270377,288824,17664,35108,293029,41381,257,21792,46212,297900]

theorem envBound16657 : H12AffineFastState.Bounded env16657 := by
  intro p hp
  have h : env16657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16656_16657 : H12AffineEnvironment.transform 20 290105 env16656 = env16657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290105 env16656 == env16657) = true)

theorem identity16657 : scanCanonicalize (H12AffineFastState.compose env16657 (packedSelected [0,3,5,8,9,18,19,22,23,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound16657 : packedSelected [0,3,5,8,9,18,19,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env16658 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,13340,32160,1025,32769,4249,21792,152,21762,8328,16,23945,5528,17664,35108,1285,41381,257,21792,46212,62988]

theorem envBound16658 : H12AffineFastState.Bounded env16658 := by
  intro p hp
  have h : env16658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16657_16658 : H12AffineEnvironment.transform 17 32160 env16657 = env16658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env16657 == env16658) = true)

theorem identity16658 : scanCanonicalize (H12AffineFastState.compose env16658 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound16658 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env16659 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,33031,13340,10281,1025,32769,4249,169,152,139,8328,16,2048,5528,4233,35108,1285,41381,257,169,46212,41861]

theorem envBound16659 : H12AffineFastState.Bounded env16659 := by
  intro p hp
  have h : env16659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16658_16659 : H12AffineEnvironment.transform 13 5513 env16658 = env16659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env16658 == env16659) = true)

theorem identity16659 : scanCanonicalize (H12AffineFastState.compose env16659 (packedSelected [1,8,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound16659 : packedSelected [1,8,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16660 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8580,8323,13340,10281,1025,8581,4249,169,152,139,8328,16,2048,5528,4233,10400,1285,33,257,169,5376,513]

theorem envBound16660 : H12AffineFastState.Bounded env16660 := by
  intro p hp
  have h : env16660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16659_16660 : H12AffineEnvironment.transform 14 8580 env16659 = env16660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env16659 == env16660) = true)

theorem identity16660 : scanCanonicalize (H12AffineFastState.compose env16660 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound16660 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env16661 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,1,262,5529,2476,1025,0,4249,169,152,139,269,16,2048,5528,4233,2341,1285,33,257,169,5376,513]

theorem envBound16661 : H12AffineFastState.Bounded env16661 := by
  intro p hp
  have h : env16661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16660_16661 : H12AffineEnvironment.transform 12 389 env16660 = env16661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env16660 == env16661) = true)

def env16662 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,13341,262144,1025,32769,2097152,272512,2101248,21762,8328,17,2116881,2098432,17664,2417693,2102684,2411676,257,21792,46212,2156181]

theorem envBound16662 : H12AffineFastState.Bounded env16662 := by
  intro p hp
  have h : env16662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16655_16662 : H12AffineEnvironment.transform 5 17 env16655 = env16662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16655 == env16662) = true)

theorem identity16662 : scanCanonicalize (H12AffineFastState.compose env16662 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 45461) := by decide +kernel

theorem selectedBound16662 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env16663 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,13341,262144,1025,32769,45461,272512,41365,21762,8328,17,64644,46229,17664,284040,41993,294153,257,21792,46212,22272]

theorem envBound16663 : H12AffineFastState.Bounded env16663 := by
  intro p hp
  have h : env16663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16662_16663 : H12AffineEnvironment.transform 20 45461 env16662 = env16663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45461 env16662 == env16663) = true)

theorem identity16663 : scanCanonicalize (H12AffineFastState.compose env16663 (packedSelected [0,3,9,11,16,17,19,20,22,24,27,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound16663 : packedSelected [0,3,9,11,16,17,19,20,22,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env16664 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,13341,35244,1025,32769,45461,41260,41365,21762,8328,17,64644,46229,17664,56356,41993,62629,257,21792,46212,22272]

theorem envBound16664 : H12AffineFastState.Bounded env16664 := by
  intro p hp
  have h : env16664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16663_16664 : H12AffineEnvironment.transform 17 35244 env16663 = env16664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env16663 == env16664) = true)

theorem identity16664 : scanCanonicalize (H12AffineFastState.compose env16664 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound16664 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16665 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,8322,13341,32161,1025,29708,17816,21793,21912,21762,8328,17,2185,16536,17664,10281,20484,168,257,21792,16521,22272]

theorem envBound16665 : H12AffineFastState.Bounded env16665 := by
  intro p hp
  have h : env16665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16664_16665 : H12AffineEnvironment.transform 14 29709 env16664 = env16665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env16664 == env16665) = true)

theorem identity16665 : scanCanonicalize (H12AffineFastState.compose env16665 (packedSelected [0,1,2,6,7,8,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound16665 : packedSelected [0,1,2,6,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env16666 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8461,8322,13341,10401,1025,8460,4248,33,152,2,8328,17,2185,5528,4096,10281,1284,168,257,32,5513,512]

theorem envBound16666 : H12AffineFastState.Bounded env16666 := by
  intro p hp
  have h : env16666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16665_16666 : H12AffineEnvironment.transform 13 5376 env16665 = env16666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16665 == env16666) = true)

theorem identity16666 : scanCanonicalize (H12AffineFastState.compose env16666 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16666 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16667 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,5376,8461,8322,13341,10368,1025,8460,4248,0,152,2,8328,17,2185,5528,4096,10248,1284,137,257,1,5513,512]

theorem envBound16667 : H12AffineFastState.Bounded env16667 := by
  intro p hp
  have h : env16667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16666_16667 : H12AffineEnvironment.transform 4 1 env16666 = env16667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16666 == env16667) = true)

theorem identity16667 : scanCanonicalize (H12AffineFastState.compose env16667 (packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound16667 : packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env16668 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,2064,8192,3344,8461,8322,11277,10368,1025,8460,2184,0,152,2,8328,17,2185,3464,2064,10248,1284,137,257,1,3481,512]

theorem envBound16668 : H12AffineFastState.Bounded env16668 := by
  intro p hp
  have h : env16668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16667_16668 : H12AffineEnvironment.transform 11 2064 env16667 = env16668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env16667 == env16668) = true)

def env16669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2202015,2098513,17664,2437315,2102684,2411677,257,21792,46212,2175563]

theorem envBound16669 : H12AffineFastState.Bounded env16669 := by
  intro p hp
  have h : env16669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16653_16669 : H12AffineEnvironment.transform 21 272513 env16653 = env16669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16653 == env16669) = true)

theorem identity16669 : scanCanonicalize (H12AffineFastState.compose env16669 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound16669 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,115870,272513,120015,98780,8328,64,23809,115151,17664,324701,119042,329731,257,21792,46212,63189]

theorem envBound16670 : H12AffineFastState.Bounded env16670 := by
  intro p hp
  have h : env16670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16669_16670 : H12AffineEnvironment.transform 20 115870 env16669 = env16670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env16669 == env16670) = true)

def env16671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10400,1025,32769,115870,33,120015,98780,8328,64,23809,115151,17664,56573,119042,73891,257,21792,46212,63189]

theorem envBound16671 : H12AffineFastState.Bounded env16671 := by
  intro p hp
  have h : env16671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16670_16671 : H12AffineEnvironment.transform 17 10400 env16670 = env16671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env16670 == env16671) = true)

theorem identity16671 : scanCanonicalize (H12AffineFastState.compose env16671 (packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound16671 : packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env16672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,90139,10400,1025,136,82967,33,87110,65877,8328,64,23809,82246,17664,23668,86411,73891,257,21792,13325,30300]

theorem envBound16672 : H12AffineFastState.Bounded env16672 := by
  intro p hp
  have h : env16672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16671_16672 : H12AffineEnvironment.transform 14 137 env16671 = env16672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env16671 == env16672) = true)

theorem identity16672 : scanCanonicalize (H12AffineFastState.compose env16672 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound16672 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,65536,70726,10400,1025,136,77898,33,73755,65877,8328,64,10588,79131,12637,10281,75222,73891,257,8573,13325,513]

theorem envBound16673 : H12AffineFastState.Bounded env16673 := by
  intro p hp
  have h : env16673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16672_16673 : H12AffineEnvironment.transform 13 13405 env16672 = env16673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env16672 == env16673) = true)

theorem identity16673 : scanCanonicalize (H12AffineFastState.compose env16673 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16673 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16674 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,137,65536,70678,10400,1025,136,77850,33,73755,65797,8328,16,10508,79131,12557,10281,75142,73891,257,8493,13325,513]

theorem envBound16674 : H12AffineFastState.Bounded env16674 := by
  intro p hp
  have h : env16674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16673_16674 : H12AffineEnvironment.transform 5 16 env16673 = env16674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16673 == env16674) = true)

theorem identity16674 : scanCanonicalize (H12AffineFastState.compose env16674 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound16674 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env16675 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,137,398,5528,10400,1025,136,12692,33,8597,139,8328,16,10508,13461,12557,10281,9224,8493,257,8493,13325,513]

theorem envBound16675 : H12AffineFastState.Bounded env16675 := by
  intro p hp
  have h : env16675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16674_16675 : H12AffineEnvironment.transform 15 398 env16674 = env16675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env16674 == env16675) = true)

theorem identity16675 : scanCanonicalize (H12AffineFastState.compose env16675 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16675 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env16676 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,263,5393,10281,1025,1,12573,33,8476,2,8193,16,10508,13340,12557,10281,9224,8493,257,8493,13325,513]

theorem envBound16676 : H12AffineFastState.Bounded env16676 := by
  intro p hp
  have h : env16676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16675_16676 : H12AffineEnvironment.transform 6 9 env16675 = env16676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16675 == env16676) = true)

def env16677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10401,1025,32769,115870,32,120015,98780,8328,64,23809,115151,17664,56572,119042,73890,257,21792,46212,63189]

theorem envBound16677 : H12AffineFastState.Bounded env16677 := by
  intro p hp
  have h : env16677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16670_16677 : H12AffineEnvironment.transform 17 10401 env16670 = env16677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16670 == env16677) = true)

theorem identity16677 : scanCanonicalize (H12AffineFastState.compose env16677 (packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound16677 : packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env16678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,79250,10401,1025,21761,70046,32,65999,87260,8328,64,23809,70863,17664,2556,66562,73890,257,21792,24964,9173]

theorem envBound16678 : H12AffineFastState.Bounded env16678 := by
  intro p hp
  have h : env16678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16677_16678 : H12AffineEnvironment.transform 14 21760 env16677 = env16678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env16677 == env16678) = true)

theorem identity16678 : scanCanonicalize (H12AffineFastState.compose env16678 (packedSelected [0,1,2,6,8,10,11,12,14,15,16,18,19,20,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound16678 : packedSelected [0,1,2,6,8,10,11,12,14,15,16,18,19,20,27,31] rootPS < 2^1333 := by decide +kernel

def env16679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8615,5173,10401,1025,21761,12345,32,8296,30075,8328,64,23809,13672,17664,2556,9637,261,257,21792,24964,9173]

theorem envBound16679 : H12AffineFastState.Bounded env16679 := by
  intro p hp
  have h : env16679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16678_16679 : H12AffineEnvironment.transform 15 8615 env16678 = env16679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env16678 == env16679) = true)

theorem identity16679 : scanCanonicalize (H12AffineFastState.compose env16679 (packedSelected [2,6,9,11,14,16,17,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound16679 : packedSelected [2,6,9,11,14,16,17,20,22,23] rootPS < 2^1333 := by decide +kernel

def env16680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5237,373,8615,5173,10401,1025,372,12345,32,8296,8462,8328,64,2420,13672,4469,2556,9637,261,257,341,13809,9173]

theorem envBound16680 : H12AffineFastState.Bounded env16680 := by
  intro p hp
  have h : env16680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16679_16680 : H12AffineEnvironment.transform 13 5237 env16679 = env16680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env16679 == env16680) = true)

theorem identity16680 : scanCanonicalize (H12AffineFastState.compose env16680 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16680 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env16681 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,5237,80,8322,5173,10401,1025,81,12345,32,8296,8235,8328,64,2129,13389,4176,2265,9344,32,36,112,13524,8944]

theorem envBound16681 : H12AffineFastState.Bounded env16681 := by
  intro p hp
  have h : env16681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16680_16681 : H12AffineEnvironment.transform 7 37 env16680 = env16681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16680 == env16681) = true)

theorem identity16681 : scanCanonicalize (H12AffineFastState.compose env16681 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound16681 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env16682 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,5237,80,8283,5173,10360,1025,81,12345,32,8296,8235,8273,64,2129,13389,4176,2048,9305,32,36,112,13325,8745]

theorem envBound16682 : H12AffineFastState.Bounded env16682 := by
  intro p hp
  have h : env16682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16681_16682 : H12AffineEnvironment.transform 6 89 env16681 = env16682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env16681 == env16682) = true)

theorem identity16682 : scanCanonicalize (H12AffineFastState.compose env16682 (packedSelected [0,1,2,3,5,6,7,8,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound16682 : packedSelected [0,1,2,3,5,6,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env16683 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,5149,5237,80,5190,5173,7269,1025,81,1060,32,5237,5174,5196,64,2129,80,4176,2048,4164,32,36,112,16,5684]

theorem envBound16683 : H12AffineFastState.Bounded env16683 := by
  intro p hp
  have h : env16683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16682_16683 : H12AffineEnvironment.transform 12 5149 env16682 = env16683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env16682 == env16683) = true)

theorem identity16683 : scanCanonicalize (H12AffineFastState.compose env16683 (packedSelected [3,4,5,9,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound16683 : packedSelected [3,4,5,9,12,14] rootPS < 2^1333 := by decide +kernel

def env16684 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,3109,2104,2128,80,2147,2064,64,1025,81,1060,32,2128,2067,2153,64,2129,80,3189,2048,3169,32,36,112,16,2577]

theorem envBound16684 : H12AffineFastState.Bounded env16684 := by
  intro p hp
  have h : env16684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16683_16684 : H12AffineEnvironment.transform 11 3109 env16683 = env16684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env16683 == env16684) = true)

theorem identity16684 : scanCanonicalize (H12AffineFastState.compose env16684 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound16684 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env16685 : List Nat := [2,4,8,16,32,64,89,37,512,1024,1141,80,1101,1061,80,1046,1125,64,1025,81,1060,32,1061,1126,1052,64,1060,80,0,1141,20,32,36,112,16,1636]

theorem envBound16685 : H12AffineFastState.Bounded env16685 := by
  intro p hp
  have h : env16685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16684_16685 : H12AffineEnvironment.transform 10 1141 env16684 = env16685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env16684 == env16685) = true)

theorem identity16685 : scanCanonicalize (H12AffineFastState.compose env16685 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16685 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env16686 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1061,0,1053,1061,0,1046,1077,16,1025,1,1060,32,1061,1078,1052,16,1060,0,0,1061,20,32,36,32,16,1588]

theorem envBound16686 : H12AffineFastState.Bounded env16686 := by
  intro p hp
  have h : env16686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16685_16686 : H12AffineEnvironment.transform 5 16 env16685 = env16686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16685 == env16686) = true)

theorem identity16686 : scanCanonicalize (H12AffineFastState.compose env16686 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16686 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16687 : List Nat := [2,4,8,16,32,16,9,37,0,1024,1061,0,1053,1061,0,1046,1077,16,1025,1,1060,32,1061,1078,1052,16,1060,0,0,1061,20,32,36,32,16,1076]

theorem envBound16687 : H12AffineFastState.Bounded env16687 := by
  intro p hp
  have h : env16687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16686_16687 : H12AffineEnvironment.transform 8 0 env16686 = env16687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16686 == env16687) = true)

theorem identity16687 : scanCanonicalize (H12AffineFastState.compose env16687 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16687 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16688 : List Nat := [2,4,8,16,16,16,9,21,0,1024,1045,0,1053,1045,0,1046,1029,16,1025,1,1044,16,1045,1030,1052,16,1044,0,0,1045,20,16,20,16,16,1028]

theorem envBound16688 : H12AffineFastState.Bounded env16688 := by
  intro p hp
  have h : env16688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16687_16688 : H12AffineEnvironment.transform 4 16 env16687 = env16688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16687 == env16688) = true)

theorem identity16688 : scanCanonicalize (H12AffineFastState.compose env16688 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound16688 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env16689 : List Nat := [2,4,8,16,16,16,9,21,0,5,16,0,24,16,0,19,0,16,4,1,17,16,16,3,25,16,17,0,0,16,20,16,20,16,16,1]

theorem envBound16689 : H12AffineFastState.Bounded env16689 := by
  intro p hp
  have h : env16689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16688_16689 : H12AffineEnvironment.transform 9 5 env16688 = env16689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env16688 == env16689) = true)

theorem identity16689 : scanCanonicalize (H12AffineFastState.compose env16689 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16690 : List Nat := [2,4,8,0,0,0,9,5,0,5,0,0,8,0,0,3,0,0,4,1,1,0,0,3,9,0,1,0,0,0,4,0,4,0,0,1]

theorem envBound16690 : H12AffineFastState.Bounded env16690 := by
  intro p hp
  have h : env16690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16689_16690 : H12AffineEnvironment.transform 3 0 env16689 = env16690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16689 == env16690) = true)

theorem identity16690 : scanCanonicalize (H12AffineFastState.compose env16690 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16690 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16691 : List Nat := [2,4,2,0,0,0,3,5,0,5,0,0,2,0,0,3,0,0,4,1,1,0,0,3,3,0,1,0,0,0,4,0,4,0,0,1]

theorem envBound16691 : H12AffineFastState.Bounded env16691 := by
  intro p hp
  have h : env16691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16690_16691 : H12AffineEnvironment.transform 2 2 env16690 = env16691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16690 == env16691) = true)

def env16692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356288,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound16692 : H12AffineFastState.Bounded env16692 := by
  intro p hp
  have h : env16692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16459_16692 : H12AffineEnvironment.transform 26 30393345 env16459 = env16692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env16459 == env16692) = true)

def env16693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound16693 : H12AffineFastState.Bounded env16693 := by
  intro p hp
  have h : env16693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16692_16693 : H12AffineEnvironment.transform 18 1024 env16692 = env16693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env16692 == env16693) = true)

theorem identity16693 : scanCanonicalize (H12AffineFastState.compose env16693 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2188755) := by decide +kernel

theorem selectedBound16693 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env16694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2188755,16777216,8328,64,23504338,18973836,77954,2598355,18932162,23160257,256,16818558,16793818,18990612]

theorem envBound16694 : H12AffineFastState.Bounded env16694 := by
  intro p hp
  have h : env16694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16693_16694 : H12AffineEnvironment.transform 22 2188755 env16693 = env16694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2188755 env16693 == env16694) = true)

def env16695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,16777216,8328,64,17227834,18973836,77954,2598355,18932162,16850985,256,16818558,16793818,18990612]

theorem envBound16695 : H12AffineFastState.Bounded env16695 := by
  intro p hp
  have h : env16695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16694_16695 : H12AffineEnvironment.transform 21 2115048 env16694 = env16695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115048 env16694 == env16695) = true)

def env16696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,2175048,8328,64,2609266,46276,77954,2598355,119178,2101345,256,2199862,2191506,63068]

theorem envBound16696 : H12AffineFastState.Bounded env16696 := by
  intro p hp
  have h : env16696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16695_16696 : H12AffineEnvironment.transform 23 2175048 env16695 = env16696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175048 env16695 == env16696) = true)

def env16697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101480,2175187,2175048,8328,64,2590066,46276,77954,2598355,99466,2101345,256,2199862,2172306,41820]

theorem envBound16697 : H12AffineFastState.Bounded env16697 := by
  intro p hp
  have h : env16697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16696_16697 : H12AffineEnvironment.transform 13 5376 env16696 = env16697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16696 == env16697) = true)

theorem identity16697 : scanCanonicalize (H12AffineFastState.compose env16697 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound16697 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,262144,1024,32769,2097152,2101480,2101328,2101451,8328,64,2532849,46276,4097,2524496,41993,2101345,256,2142645,2098449,41820]

theorem envBound16698 : H12AffineFastState.Bounded env16698 := by
  intro p hp
  have h : env16698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16697_16698 : H12AffineEnvironment.transform 15 8323 env16697 = env16698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env16697 == env16698) = true)

def env16699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,2097152,2101344,2101328,2101315,8192,64,2532729,46156,4097,2524496,41993,2101345,256,2142525,2098449,41820]

theorem envBound16699 : H12AffineFastState.Bounded env16699 := by
  intro p hp
  have h : env16699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16698_16699 : H12AffineEnvironment.transform 6 8 env16698 = env16699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16698 == env16699) = true)

theorem identity16699 : scanCanonicalize (H12AffineFastState.compose env16699 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound16699 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env16700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,46157,262144,1024,32769,2097152,2101344,2101328,2101315,8192,64,2363700,46156,4097,2371869,41993,2101345,256,2142525,2098449,41820]

theorem envBound16700 : H12AffineFastState.Bounded env16700 := by
  intro p hp
  have h : env16700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16699_16700 : H12AffineEnvironment.transform 16 46157 env16699 = env16700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env16699 == env16700) = true)

theorem identity16700 : scanCanonicalize (H12AffineFastState.compose env16700 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16700 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env16701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5392,262144,1024,8540,2097152,2101344,2101328,2101315,8192,64,2363700,5393,4097,2371869,1364,2101345,256,2101344,2098449,513]

theorem envBound16701 : H12AffineFastState.Bounded env16701 := by
  intro p hp
  have h : env16701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16700_16701 : H12AffineEnvironment.transform 14 8541 env16700 = env16701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16700 == env16701) = true)

theorem identity16701 : scanCanonicalize (H12AffineFastState.compose env16701 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16701 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16702 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8541,8203,4097,262144,273,8540,2097152,2101344,2101328,2101315,8192,64,2363700,4096,4097,2371869,69,2101345,256,2101344,2097152,513]

theorem envBound16702 : H12AffineFastState.Bounded env16702 := by
  intro p hp
  have h : env16702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16701_16702 : H12AffineEnvironment.transform 9 273 env16701 = env16702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16701 == env16702) = true)

theorem identity16702 : scanCanonicalize (H12AffineFastState.compose env16702 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound16702 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16703 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8541,8203,4097,262144,273,8540,276584,272392,272440,272427,8192,64,10588,4096,4097,2421,69,272393,256,272392,276584,513]

theorem envBound16703 : H12AffineFastState.Bounded env16703 := by
  intro p hp
  have h : env16703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16702_16703 : H12AffineEnvironment.transform 20 276584 env16702 = env16703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env16702 == env16703) = true)

theorem identity16703 : scanCanonicalize (H12AffineFastState.compose env16703 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound16703 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env16704 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,41,4113,372,34,4097,262144,273,373,268353,264225,264209,264194,41,64,2421,4096,4097,2421,69,264224,256,264225,268353,513]

theorem envBound16704 : H12AffineFastState.Bounded env16704 := by
  intro p hp
  have h : env16704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16703_16704 : H12AffineEnvironment.transform 12 41 env16703 = env16704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16703 == env16704) = true)

theorem identity16704 : scanCanonicalize (H12AffineFastState.compose env16704 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound16704 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env16705 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,41,4113,372,34,4097,2421,273,373,4404,340,356,375,41,64,2421,4096,4097,2421,69,341,256,340,4404,513]

theorem envBound16705 : H12AffineFastState.Bounded env16705 := by
  intro p hp
  have h : env16705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16704_16705 : H12AffineEnvironment.transform 17 2421 env16704 = env16705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env16704 == env16705) = true)

theorem identity16705 : scanCanonicalize (H12AffineFastState.compose env16705 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16705 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16706 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,41,4113,293,34,4097,2340,273,292,4404,261,309,294,41,17,2340,4096,4097,2340,20,260,256,261,4404,513]

theorem envBound16706 : H12AffineFastState.Bounded env16706 := by
  intro p hp
  have h : env16706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16705_16706 : H12AffineEnvironment.transform 5 17 env16705 = env16706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16705 == env16706) = true)

theorem identity16706 : scanCanonicalize (H12AffineFastState.compose env16706 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16706 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16707 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4113,1,34,4097,2048,53,0,4112,33,17,2,41,17,2048,4096,4097,2048,20,32,36,33,4112,513]

theorem envBound16707 : H12AffineFastState.Bounded env16707 := by
  intro p hp
  have h : env16707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16706_16707 : H12AffineEnvironment.transform 7 36 env16706 = env16707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16706 == env16707) = true)

theorem identity16707 : scanCanonicalize (H12AffineFastState.compose env16707 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound16707 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16708 : List Nat := [2,4,8,16,32,17,8,36,512,53,49,4096,41,4113,1,34,4097,49,53,0,4112,33,17,2,41,17,49,4096,4097,49,20,32,36,33,4112,513]

theorem envBound16708 : H12AffineFastState.Bounded env16708 := by
  intro p hp
  have h : env16708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16707_16708 : H12AffineEnvironment.transform 10 49 env16707 = env16708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env16707 == env16708) = true)

theorem identity16708 : scanCanonicalize (H12AffineFastState.compose env16708 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound16708 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16709 : List Nat := [2,4,8,16,32,17,8,36,33,53,49,4096,41,4113,1,34,4097,49,53,0,4112,33,17,2,41,17,49,4096,4097,49,20,32,36,33,4112,32]

theorem envBound16709 : H12AffineFastState.Bounded env16709 := by
  intro p hp
  have h : env16709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16708_16709 : H12AffineEnvironment.transform 8 33 env16708 = env16709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env16708 == env16709) = true)

theorem identity16709 : scanCanonicalize (H12AffineFastState.compose env16709 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound16709 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16710 : List Nat := [2,4,8,16,32,17,8,36,33,53,49,16,41,1,1,34,17,49,53,0,0,33,17,2,41,17,49,16,17,49,20,32,36,33,0,32]

theorem envBound16710 : H12AffineFastState.Bounded env16710 := by
  intro p hp
  have h : env16710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16709_16710 : H12AffineEnvironment.transform 11 16 env16709 = env16710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env16709 == env16710) = true)

def env16711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,262144,1024,32769,2097152,2101345,2101328,2101314,8193,64,2532728,46157,4097,2524496,41993,2101345,256,2142524,2098449,41820]

theorem envBound16711 : H12AffineFastState.Bounded env16711 := by
  intro p hp
  have h : env16711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16698_16711 : H12AffineEnvironment.transform 6 9 env16698 = env16711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16698 == env16711) = true)

theorem identity16711 : scanCanonicalize (H12AffineFastState.compose env16711 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound16711 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env16712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,5393,262144,1024,32769,2097152,2101345,2101328,2101314,8193,64,2404457,46157,4097,2396225,41993,2101345,256,2142524,2098449,41820]

theorem envBound16712 : H12AffineFastState.Bounded env16712 := by
  intro p hp
  have h : env16712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16711_16712 : H12AffineEnvironment.transform 16 5393 env16711 = env16712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env16711 == env16712) = true)

theorem identity16712 : scanCanonicalize (H12AffineFastState.compose env16712 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16712 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env16713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,5393,262144,1024,8540,2097152,2101345,2101328,2101314,8193,64,2363700,5392,4097,2371868,1364,2101345,256,2101345,2098449,513]

theorem envBound16713 : H12AffineFastState.Bounded env16713 := by
  intro p hp
  have h : env16713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16712_16713 : H12AffineEnvironment.transform 14 8541 env16712 = env16713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16712 == env16713) = true)

def env16714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101481,2175186,2175048,8328,64,2590067,46276,77954,2598355,99467,2101345,256,2199862,2172307,41821]

theorem envBound16714 : H12AffineFastState.Bounded env16714 := by
  intro p hp
  have h : env16714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16696_16714 : H12AffineEnvironment.transform 13 5377 env16696 = env16714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16696 == env16714) = true)

theorem identity16714 : scanCanonicalize (H12AffineFastState.compose env16714 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound16714 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,73771,16,138,8328,64,439729,46276,77954,431377,99467,73891,256,41460,5457,41821]

theorem envBound16715 : H12AffineFastState.Bounded env16715 := by
  intro p hp
  have h : env16715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16714_16715 : H12AffineEnvironment.transform 20 78018 env16714 = env16715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env16714 == env16715) = true)

def env16716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,73771,16,2,8192,64,439609,46156,77834,431377,99331,73771,256,41340,5457,41821]

theorem envBound16716 : H12AffineFastState.Bounded env16716 := by
  intro p hp
  have h : env16716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16715_16716 : H12AffineEnvironment.transform 6 8 env16715 = env16716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16715 == env16716) = true)

theorem identity16716 : scanCanonicalize (H12AffineFastState.compose env16716 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound16716 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env16717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,262144,1024,32769,77898,73771,16,2,8192,64,360483,46156,77834,368651,99331,73771,256,41340,5457,41821]

theorem envBound16717 : H12AffineFastState.Bounded env16717 := by
  intro p hp
  have h : env16717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16716_16717 : H12AffineEnvironment.transform 16 79130 env16716 = env16717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env16716 == env16717) = true)

theorem identity16717 : scanCanonicalize (H12AffineFastState.compose env16717 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound16717 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env16718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,46156,262144,1024,32769,45340,41341,16,2,8192,64,262517,46156,45404,270685,1365,41341,256,41340,5457,41821]

theorem envBound16718 : H12AffineFastState.Bounded env16718 := by
  intro p hp
  have h : env16718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16717_16718 : H12AffineEnvironment.transform 15 33110 env16717 = env16718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env16717 == env16718) = true)

theorem identity16718 : scanCanonicalize (H12AffineFastState.compose env16718 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound16718 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env16719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,32768,33110,37941,262144,1024,32769,37221,33028,16,2,121,64,262517,37941,37157,262436,1365,33028,256,33029,5457,33572]

theorem envBound16719 : H12AffineFastState.Bounded env16719 := by
  intro p hp
  have h : env16719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16718_16719 : H12AffineEnvironment.transform 12 121 env16718 = env16719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env16718 == env16719) = true)

theorem identity16719 : scanCanonicalize (H12AffineFastState.compose env16719 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound16719 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env16720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,32768,33110,37941,35188,1024,32769,37221,33028,16,2,121,64,34817,37941,37157,34896,1365,33028,256,33029,5457,33572]

theorem envBound16720 : H12AffineFastState.Bounded env16720 := by
  intro p hp
  have h : env16720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16719_16720 : H12AffineEnvironment.transform 17 35188 env16719 = env16720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env16719 == env16720) = true)

theorem identity16720 : scanCanonicalize (H12AffineFastState.compose env16720 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound16720 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env16721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,372,34,5441,2048,1024,373,4113,112,16,2,121,64,2421,5441,4177,2340,1365,112,256,113,5457,592]

theorem envBound16721 : H12AffineFastState.Bounded env16721 := by
  intro p hp
  have h : env16721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16720_16721 : H12AffineEnvironment.transform 14 372 env16720 = env16721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env16720 == env16721) = true)

theorem identity16721 : scanCanonicalize (H12AffineFastState.compose env16721 (packedSelected [0,3,4,5,6,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound16721 : packedSelected [0,3,4,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env16722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,121,2128,372,34,2064,2048,1024,373,3392,112,16,2,121,64,2421,2064,3328,2340,1365,112,256,113,2048,592]

theorem envBound16722 : H12AffineFastState.Bounded env16722 := by
  intro p hp
  have h : env16722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16721_16722 : H12AffineEnvironment.transform 11 3409 env16721 = env16722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env16721 == env16722) = true)

theorem identity16722 : scanCanonicalize (H12AffineFastState.compose env16722 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16722 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env16723 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3189,121,2128,80,34,2064,2048,1024,81,3172,112,16,2,121,64,2129,2064,3108,2048,1137,112,36,113,2048,592]

theorem envBound16723 : H12AffineFastState.Bounded env16723 := by
  intro p hp
  have h : env16723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16722_16723 : H12AffineEnvironment.transform 7 36 env16722 = env16723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16722 == env16723) = true)

theorem identity16723 : scanCanonicalize (H12AffineFastState.compose env16723 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16723 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env16724 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3109,41,2048,0,34,2064,2048,1024,1,3124,32,16,2,41,16,2049,2064,3108,2048,1057,32,36,33,2048,512]

theorem envBound16724 : H12AffineFastState.Bounded env16724 := by
  intro p hp
  have h : env16724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16723_16724 : H12AffineEnvironment.transform 5 16 env16723 = env16724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16723 == env16724) = true)

theorem identity16724 : scanCanonicalize (H12AffineFastState.compose env16724 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16724 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16725 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,1061,41,0,0,34,16,0,1024,1,1076,32,16,2,41,16,1,16,1060,0,1057,32,36,33,0,512]

theorem envBound16725 : H12AffineFastState.Bounded env16725 := by
  intro p hp
  have h : env16725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16724_16725 : H12AffineEnvironment.transform 10 0 env16724 = env16725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16724 == env16725) = true)

theorem identity16725 : scanCanonicalize (H12AffineFastState.compose env16725 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound16725 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16726 : List Nat := [2,4,8,16,32,16,8,36,512,543,0,570,41,0,0,34,16,0,543,1,555,32,16,2,41,16,1,16,571,0,574,32,36,33,0,512]

theorem envBound16726 : H12AffineFastState.Bounded env16726 := by
  intro p hp
  have h : env16726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16725_16726 : H12AffineEnvironment.transform 9 543 env16725 = env16726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env16725 == env16726) = true)

theorem identity16726 : scanCanonicalize (H12AffineFastState.compose env16726 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound16726 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16727 : List Nat := [2,4,8,16,12,16,8,8,512,543,0,534,5,0,0,14,16,0,543,1,519,12,16,2,5,16,1,16,535,0,530,12,8,13,0,512]

theorem envBound16727 : H12AffineFastState.Bounded env16727 := by
  intro p hp
  have h : env16727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16726_16727 : H12AffineEnvironment.transform 4 12 env16726 = env16727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env16726 == env16727) = true)

theorem identity16727 : scanCanonicalize (H12AffineFastState.compose env16727 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound16727 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16728 : List Nat := [2,2,8,16,10,16,8,8,512,537,0,528,3,0,0,8,16,0,537,1,513,10,16,2,3,16,1,16,529,0,530,10,8,11,0,512]

theorem envBound16728 : H12AffineFastState.Bounded env16728 := by
  intro p hp
  have h : env16728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16727_16728 : H12AffineEnvironment.transform 1 2 env16727 = env16728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env16727 == env16728) = true)

theorem identity16728 : scanCanonicalize (H12AffineFastState.compose env16728 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound16728 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16729 : List Nat := [2,2,8,16,10,16,8,8,26,3,0,10,3,0,0,8,16,0,3,1,27,10,16,2,3,16,1,16,11,0,8,10,8,11,0,26]

theorem envBound16729 : H12AffineFastState.Bounded env16729 := by
  intro p hp
  have h : env16729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16728_16729 : H12AffineEnvironment.transform 8 26 env16728 = env16729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env16728 == env16729) = true)

theorem identity16729 : scanCanonicalize (H12AffineFastState.compose env16729 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16729 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16730 : List Nat := [2,2,3,16,1,16,3,3,17,3,0,1,3,0,0,3,16,0,3,1,16,1,16,2,3,16,1,16,0,0,3,1,3,0,0,17]

theorem envBound16730 : H12AffineFastState.Bounded env16730 := by
  intro p hp
  have h : env16730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16729_16730 : H12AffineEnvironment.transform 2 3 env16729 = env16730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16729 == env16730) = true)

theorem identity16730 : scanCanonicalize (H12AffineFastState.compose env16730 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound16730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16731 : List Nat := [2,2,3,3,1,3,3,3,2,3,0,1,3,0,0,3,3,0,3,1,3,1,3,2,3,3,1,3,0,0,3,1,3,0,0,2]

theorem envBound16731 : H12AffineFastState.Bounded env16731 := by
  intro p hp
  have h : env16731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16730_16731 : H12AffineEnvironment.transform 3 3 env16730 = env16731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env16730 == env16731) = true)

def env16732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,73771,16,3,8193,64,439608,46157,77835,431377,99330,73770,256,41341,5457,41821]

theorem envBound16732 : H12AffineFastState.Bounded env16732 := by
  intro p hp
  have h : env16732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16715_16732 : H12AffineEnvironment.transform 6 9 env16715 = env16732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16715 == env16732) = true)

theorem identity16732 : scanCanonicalize (H12AffineFastState.compose env16732 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16732 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77899,73771,16,3,8193,64,398436,5393,77835,406605,75102,73770,256,33,5457,513]

theorem envBound16733 : H12AffineFastState.Bounded env16733 := by
  intro p hp
  have h : env16733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16732_16733 : H12AffineEnvironment.transform 14 8540 env16732 = env16733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16732 == env16733) = true)

theorem identity16733 : scanCanonicalize (H12AffineFastState.compose env16733 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound16733 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env16734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77899,73771,16,3,8193,64,146509,5393,77835,138340,75102,73770,256,33,5457,513]

theorem envBound16734 : H12AffineFastState.Bounded env16734 := by
  intro p hp
  have h : env16734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16733_16734 : H12AffineEnvironment.transform 17 10281 env16733 = env16734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env16733 == env16734) = true)

theorem identity16734 : scanCanonicalize (H12AffineFastState.compose env16734 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound16734 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env16735 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,70678,10281,1024,8541,77899,73771,16,3,8193,64,75867,5393,77835,67698,75102,73770,256,33,5457,513]

theorem envBound16735 : H12AffineFastState.Bounded env16735 := by
  intro p hp
  have h : env16735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16734_16735 : H12AffineEnvironment.transform 16 70678 env16734 = env16735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env16734 == env16735) = true)

theorem identity16735 : scanCanonicalize (H12AffineFastState.compose env16735 (packedSelected [4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound16735 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env16736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8282,13388,10281,1024,8541,4113,113,16,3,8193,64,2049,5393,4177,10280,1284,112,256,33,5457,513]

theorem envBound16736 : H12AffineFastState.Bounded env16736 := by
  intro p hp
  have h : env16736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16735_16736 : H12AffineEnvironment.transform 15 8282 env16735 = env16736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env16735 == env16736) = true)

theorem identity16736 : scanCanonicalize (H12AffineFastState.compose env16736 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16736 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env16737 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8203,13341,10281,1024,8460,4113,32,16,3,8193,17,2049,5393,4096,10280,1284,33,256,33,5376,513]

theorem envBound16737 : H12AffineFastState.Bounded env16737 := by
  intro p hp
  have h : env16737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16736_16737 : H12AffineEnvironment.transform 5 17 env16736 = env16737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16736 == env16737) = true)

theorem identity16737 : scanCanonicalize (H12AffineFastState.compose env16737 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound16737 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env16738 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,4380,5377,4113,4375,1281,6453,1024,4112,4113,32,16,3,4381,17,2049,5393,4096,6452,1284,33,256,33,5376,513]

theorem envBound16738 : H12AffineFastState.Bounded env16738 := by
  intro p hp
  have h : env16738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16737_16738 : H12AffineEnvironment.transform 12 4380 env16737 = env16738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env16737 == env16738) = true)

theorem identity16738 : scanCanonicalize (H12AffineFastState.compose env16738 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound16738 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env16739 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3108,3384,2341,3125,3379,1281,1297,1024,3124,3125,32,16,3,3385,17,2049,2357,3108,1296,1284,33,256,33,2340,513]

theorem envBound16739 : H12AffineFastState.Bounded env16739 := by
  intro p hp
  have h : env16739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16738_16739 : H12AffineEnvironment.transform 11 3108 env16738 = env16739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env16738 == env16739) = true)

theorem identity16739 : scanCanonicalize (H12AffineFastState.compose env16739 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16739 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16740 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3108,3100,2049,3125,3095,1061,1077,1024,3124,3125,32,16,3,3101,17,2049,2065,3108,1076,1056,33,36,33,2048,513]

theorem envBound16740 : H12AffineFastState.Bounded env16740 := by
  intro p hp
  have h : env16740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16739_16740 : H12AffineEnvironment.transform 7 36 env16739 = env16740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16739 == env16740) = true)

def env16741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,2175049,8328,64,2609267,46277,77954,2598355,119179,2101344,256,2199863,2191507,63069]

theorem envBound16741 : H12AffineFastState.Bounded env16741 := by
  intro p hp
  have h : env16741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16695_16741 : H12AffineEnvironment.transform 23 2175049 env16695 = env16741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175049 env16695 == env16741) = true)

def env16742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101480,2175187,2175049,8328,64,2590067,46277,77954,2598355,99467,2101344,256,2199863,2172307,41821]

theorem envBound16742 : H12AffineFastState.Bounded env16742 := by
  intro p hp
  have h : env16742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16741_16742 : H12AffineEnvironment.transform 13 5376 env16741 = env16742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16741 == env16742) = true)

theorem identity16742 : scanCanonicalize (H12AffineFastState.compose env16742 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102815) := by decide +kernel

theorem selectedBound16742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102815,98679,41292,41430,8328,64,398572,46277,77954,406604,99467,98815,256,168,46092,41821]

theorem envBound16743 : H12AffineFastState.Bounded env16743 := by
  intro p hp
  have h : env16743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16742_16743 : H12AffineEnvironment.transform 20 102815 env16742 = env16743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102815 env16742 == env16743) = true)

def env16744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102815,98679,41292,41430,8328,64,146628,46277,77954,138340,99467,98815,256,168,46092,41821]

theorem envBound16744 : H12AffineFastState.Bounded env16744 := by
  intro p hp
  have h : env16744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16743_16744 : H12AffineEnvironment.transform 17 10280 env16743 = env16744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env16743 == env16744) = true)

theorem identity16744 : scanCanonicalize (H12AffineFastState.compose env16744 (packedSelected [5,8,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound16744 : packedSelected [5,8,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,103495,10280,1024,32769,102815,98679,41292,41430,8328,64,108675,46277,77954,100387,99467,98815,256,168,46092,41821]

theorem envBound16745 : H12AffineFastState.Bounded env16745 := by
  intro p hp
  have h : env16745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16744_16745 : H12AffineEnvironment.transform 16 103495 env16744 = env16745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env16744 == env16745) = true)

theorem identity16745 : scanCanonicalize (H12AffineFastState.compose env16745 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 33863) := by decide +kernel

theorem selectedBound16745 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env16746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33863,4096,10280,1024,32769,5592,1328,41292,41430,8328,64,11460,46277,46277,3172,204,1464,256,168,46092,41821]

theorem envBound16746 : H12AffineFastState.Bounded env16746 := by
  intro p hp
  have h : env16746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16745_16746 : H12AffineEnvironment.transform 15 33863 env16745 = env16746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33863 env16745 == env16746) = true)

theorem identity16746 : scanCanonicalize (H12AffineFastState.compose env16746 (packedSelected [0,1,2,3,4,5,6,9,11,15,16,18,26,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound16746 : packedSelected [0,1,2,3,4,5,6,9,11,15,16,18,26,27,28,38] rootPS < 2^1333 := by decide +kernel

def env16747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,429,1514,4096,10280,1024,428,5592,1328,8417,8315,8328,64,11460,13672,13672,3172,204,1464,256,168,13729,8944]

theorem envBound16747 : H12AffineFastState.Bounded env16747 := by
  intro p hp
  have h : env16747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16746_16747 : H12AffineEnvironment.transform 14 429 env16746 = env16747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env16746 == env16747) = true)

theorem identity16747 : scanCanonicalize (H12AffineFastState.compose env16747 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound16747 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5376,429,1514,4096,2264,1024,428,5592,1328,17,139,120,64,3124,5528,5528,3172,204,1464,256,168,5457,512]

theorem envBound16748 : H12AffineFastState.Bounded env16748 := by
  intro p hp
  have h : env16748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16747_16748 : H12AffineEnvironment.transform 12 240 env16747 = env16748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env16747 == env16748) = true)

theorem identity16748 : scanCanonicalize (H12AffineFastState.compose env16748 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16748 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16749 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,240,4113,429,251,4096,2264,273,428,4297,33,17,139,120,64,2341,4233,4233,2421,204,169,256,168,4160,512]

theorem envBound16749 : H12AffineFastState.Bounded env16749 := by
  intro p hp
  have h : env16749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16748_16749 : H12AffineEnvironment.transform 9 273 env16748 = env16749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16748 == env16749) = true)

theorem identity16749 : scanCanonicalize (H12AffineFastState.compose env16749 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound16749 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16750 : List Nat := [2,4,8,16,32,64,128,84,512,69,2048,4096,240,4113,249,251,4096,2264,69,248,4297,33,17,139,120,64,2161,4233,4233,2081,204,169,84,168,4160,512]

theorem envBound16750 : H12AffineFastState.Bounded env16750 := by
  intro p hp
  have h : env16750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16749_16750 : H12AffineEnvironment.transform 7 84 env16749 = env16750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env16749 == env16750) = true)

theorem identity16750 : scanCanonicalize (H12AffineFastState.compose env16750 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound16750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16751 : List Nat := [2,4,8,16,32,64,128,84,512,69,2048,185,240,168,249,251,185,2264,69,248,112,33,17,139,120,64,2161,48,48,2081,204,169,84,168,249,512]

theorem envBound16751 : H12AffineFastState.Bounded env16751 := by
  intro p hp
  have h : env16751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16750_16751 : H12AffineEnvironment.transform 11 185 env16750 = env16751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env16750 == env16751) = true)

theorem identity16751 : scanCanonicalize (H12AffineFastState.compose env16751 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 248) := by decide +kernel

theorem selectedBound16751 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env16752 : List Nat := [2,4,8,16,32,64,128,84,512,69,248,185,240,168,249,251,185,32,69,248,112,33,17,139,120,64,137,48,48,217,204,169,84,168,249,512]

theorem envBound16752 : H12AffineFastState.Bounded env16752 := by
  intro p hp
  have h : env16752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16751_16752 : H12AffineEnvironment.transform 10 248 env16751 = env16752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 248 env16751 == env16752) = true)

theorem identity16752 : scanCanonicalize (H12AffineFastState.compose env16752 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16752 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env16753 : List Nat := [2,4,8,16,32,64,9,84,512,69,113,48,121,33,112,114,48,32,69,113,112,33,17,2,120,64,0,48,48,80,69,32,84,33,112,512]

theorem envBound16753 : H12AffineFastState.Bounded env16753 := by
  intro p hp
  have h : env16753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16752_16753 : H12AffineEnvironment.transform 6 9 env16752 = env16753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16752 == env16753) = true)

theorem identity16753 : scanCanonicalize (H12AffineFastState.compose env16753 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16753 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env16754 : List Nat := [2,4,8,16,0,64,9,84,512,69,81,16,89,1,80,82,16,0,69,81,80,1,17,2,88,64,0,16,16,80,69,0,84,1,80,512]

theorem envBound16754 : H12AffineFastState.Bounded env16754 := by
  intro p hp
  have h : env16754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16753_16754 : H12AffineEnvironment.transform 4 0 env16753 = env16754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16753 == env16754) = true)

theorem identity16754 : scanCanonicalize (H12AffineFastState.compose env16754 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound16754 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16755 : List Nat := [2,4,8,16,0,64,9,84,81,69,81,16,89,1,80,82,16,0,69,81,80,1,17,2,88,64,0,16,16,80,69,0,84,1,80,81]

theorem envBound16755 : H12AffineFastState.Bounded env16755 := by
  intro p hp
  have h : env16755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16754_16755 : H12AffineEnvironment.transform 8 81 env16754 = env16755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env16754 == env16755) = true)

theorem identity16755 : scanCanonicalize (H12AffineFastState.compose env16755 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound16755 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16756 : List Nat := [2,4,8,15,0,64,9,75,78,69,78,15,70,1,79,77,15,0,69,78,79,1,14,2,71,64,0,15,15,79,69,0,75,1,79,78]

theorem envBound16756 : H12AffineFastState.Bounded env16756 := by
  intro p hp
  have h : env16756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16755_16756 : H12AffineEnvironment.transform 3 15 env16755 = env16756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env16755 == env16756) = true)

theorem identity16756 : scanCanonicalize (H12AffineFastState.compose env16756 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 14) := by decide +kernel

theorem selectedBound16756 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16757 : List Nat := [2,4,8,15,0,14,9,5,0,11,0,15,8,1,1,3,15,0,11,0,1,1,14,2,9,14,0,15,15,1,11,0,5,1,1,0]

theorem envBound16757 : H12AffineFastState.Bounded env16757 := by
  intro p hp
  have h : env16757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16756_16757 : H12AffineEnvironment.transform 5 14 env16756 = env16757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 14 env16756 == env16757) = true)

def env16758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102815,98679,41292,41430,8328,64,146629,46277,77954,138341,99467,98815,256,168,46092,41821]

theorem envBound16758 : H12AffineFastState.Bounded env16758 := by
  intro p hp
  have h : env16758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16743_16758 : H12AffineEnvironment.transform 17 10281 env16743 = env16758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env16743 == env16758) = true)

theorem identity16758 : scanCanonicalize (H12AffineFastState.compose env16758 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16758 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,78019,73771,16,138,8328,64,146629,5529,77954,138341,75223,73891,256,168,5456,513]

theorem envBound16759 : H12AffineFastState.Bounded env16759 := by
  intro p hp
  have h : env16759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16758_16759 : H12AffineEnvironment.transform 14 8540 env16758 = env16759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16758 == env16759) = true)

theorem identity16759 : scanCanonicalize (H12AffineFastState.compose env16759 (packedSelected [0,2,6,9,11,18,22,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound16759 : packedSelected [0,2,6,9,11,18,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env16760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,79251,10281,1024,8541,78019,73771,16,138,8328,64,67926,5529,77954,76278,75223,73891,256,168,5456,513]

theorem envBound16760 : H12AffineFastState.Bounded env16760 := by
  intro p hp
  have h : env16760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16759_16760 : H12AffineEnvironment.transform 16 79251 env16759 = env16760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env16759 == env16760) = true)

theorem identity16760 : scanCanonicalize (H12AffineFastState.compose env16760 (packedSelected [0,3,5,7,10,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16760 : packedSelected [0,3,5,7,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env16761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,0,65536,70863,2421,1024,1,70047,65911,16,138,468,64,67926,5529,70110,67754,66699,66047,256,168,5456,513]

theorem envBound16761 : H12AffineFastState.Bounded env16761 := by
  intro p hp
  have h : env16761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16760_16761 : H12AffineEnvironment.transform 12 348 env16760 = env16761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16760 == env16761) = true)

theorem identity16761 : scanCanonicalize (H12AffineFastState.compose env16761 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound16761 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env16762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,0,398,5441,2421,1024,1,4113,249,16,138,468,64,2264,5529,4176,2340,1285,113,256,168,5456,513]

theorem envBound16762 : H12AffineFastState.Bounded env16762 := by
  intro p hp
  have h : env16762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16761_16762 : H12AffineEnvironment.transform 15 398 env16761 = env16762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env16761 == env16762) = true)

theorem identity16762 : scanCanonicalize (H12AffineFastState.compose env16762 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16762 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16763 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5376,0,398,5393,2341,1024,1,4113,169,16,138,388,16,2184,5529,4096,2340,1285,33,256,168,5376,513]

theorem envBound16763 : H12AffineFastState.Bounded env16763 := by
  intro p hp
  have h : env16763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16762_16763 : H12AffineEnvironment.transform 5 16 env16762 = env16763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16762 == env16763) = true)

theorem identity16763 : scanCanonicalize (H12AffineFastState.compose env16763 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound16763 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env16764 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,444,268,1212,0,398,1197,2341,1024,1,429,169,16,138,388,16,2184,1061,444,2340,1285,33,256,168,1212,513]

theorem envBound16764 : H12AffineFastState.Bounded env16764 := by
  intro p hp
  have h : env16764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16763_16764 : H12AffineEnvironment.transform 11 444 env16763 = env16764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env16763 == env16764) = true)

theorem identity16764 : scanCanonicalize (H12AffineFastState.compose env16764 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound16764 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16765 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,444,268,1212,0,398,1197,292,1024,1,429,169,16,138,388,16,137,1061,444,293,1285,33,256,168,1212,513]

theorem envBound16765 : H12AffineFastState.Bounded env16765 := by
  intro p hp
  have h : env16765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16764_16765 : H12AffineEnvironment.transform 10 1 env16764 = env16765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16764 == env16765) = true)

theorem identity16765 : scanCanonicalize (H12AffineFastState.compose env16765 (packedSelected [12] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16765 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env16766 : List Nat := [2,4,8,16,32,16,128,256,512,273,1,444,268,429,0,398,444,292,273,1,429,169,16,138,388,16,137,308,444,293,20,33,256,168,429,513]

theorem envBound16766 : H12AffineFastState.Bounded env16766 := by
  intro p hp
  have h : env16766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16765_16766 : H12AffineEnvironment.transform 9 273 env16765 = env16766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16765 == env16766) = true)

def env16767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101481,2175186,2175049,8328,64,2590066,46277,77954,2598355,99466,2101344,256,2199863,2172306,41820]

theorem envBound16767 : H12AffineFastState.Bounded env16767 := by
  intro p hp
  have h : env16767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16741_16767 : H12AffineEnvironment.transform 13 5377 env16741 = env16767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16741 == env16767) = true)

theorem identity16767 : scanCanonicalize (H12AffineFastState.compose env16767 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound16767 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,262144,1024,32769,2097152,2101481,2142476,2142615,8328,64,2491564,46277,45404,2499597,1364,2101344,256,2101481,2139212,41820]

theorem envBound16768 : H12AffineFastState.Bounded env16768 := by
  intro p hp
  have h : env16768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16767_16768 : H12AffineEnvironment.transform 15 33246 env16767 = env16768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env16767 == env16768) = true)

theorem identity16768 : scanCanonicalize (H12AffineFastState.compose env16768 (packedSelected [1,12,15,19,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound16768 : packedSelected [1,12,15,19,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env16769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,46276,262144,1024,32769,2097152,2101481,2142476,2142615,8328,64,2404456,46277,45404,2396361,1364,2101344,256,2101481,2139212,41820]

theorem envBound16769 : H12AffineFastState.Bounded env16769 := by
  intro p hp
  have h : env16769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16768_16769 : H12AffineEnvironment.transform 16 46276 env16768 = env16769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env16768 == env16769) = true)

def env16770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,46276,262144,1024,32769,276704,272393,297452,297335,8328,64,34952,46277,45404,43049,1364,272512,256,272393,302252,41820]

theorem envBound16770 : H12AffineFastState.Bounded env16770 := by
  intro p hp
  have h : env16770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16769_16770 : H12AffineEnvironment.transform 20 276704 env16769 = env16770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276704 env16769 == env16770) = true)

theorem identity16770 : scanCanonicalize (H12AffineFastState.compose env16770 (packedSelected [1,5,8,19,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound16770 : packedSelected [1,5,8,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env16771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,5392,262144,1024,8661,276704,272393,272440,272547,8328,64,10588,5393,4232,2557,1364,272512,256,272393,277880,648]

theorem envBound16771 : H12AffineFastState.Bounded env16771 := by
  intro p hp
  have h : env16771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16770_16771 : H12AffineEnvironment.transform 14 8660 env16770 = env16771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env16770 == env16771) = true)

theorem identity16771 : scanCanonicalize (H12AffineFastState.compose env16771 (packedSelected [0,1,2,3,5,7,8,10,11,14,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound16771 : packedSelected [0,1,2,3,5,7,8,10,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env16772 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,5204,8321,8202,5189,262144,1024,8320,276704,272393,272440,272547,8328,64,10249,5188,4232,2216,1025,272512,85,272393,277549,648]

theorem envBound16772 : H12AffineFastState.Bounded env16772 := by
  intro p hp
  have h : env16772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16771_16772 : H12AffineEnvironment.transform 7 85 env16771 = env16772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env16771 == env16772) = true)

def env16773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,46276,262144,1024,32769,276705,272392,297453,297334,8328,64,34953,46277,45404,43048,1364,272513,256,272392,302253,41820]

theorem envBound16773 : H12AffineFastState.Bounded env16773 := by
  intro p hp
  have h : env16773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16769_16773 : H12AffineEnvironment.transform 20 276705 env16769 = env16773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276705 env16769 == env16773) = true)

theorem identity16773 : scanCanonicalize (H12AffineFastState.compose env16773 (packedSelected [1,5,8,19,21,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound16773 : packedSelected [1,5,8,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env16774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,46276,35188,1024,32769,45461,41340,153,2,8328,64,34953,46277,45404,43048,1364,41461,256,41340,5593,41820]

theorem envBound16774 : H12AffineFastState.Bounded env16774 := by
  intro p hp
  have h : env16774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16773_16774 : H12AffineEnvironment.transform 17 35188 env16773 = env16774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env16773 == env16774) = true)

theorem identity16774 : scanCanonicalize (H12AffineFastState.compose env16774 (packedSelected [0,1,2,4,7,8,9,12,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound16774 : packedSelected [0,1,2,4,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env16775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,429,115,13673,2265,1024,428,12344,8401,153,2,8328,64,2340,13672,12529,10629,1364,8280,256,8401,5593,8945]

theorem envBound16775 : H12AffineFastState.Bounded env16775 := by
  intro p hp
  have h : env16775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16774_16775 : H12AffineEnvironment.transform 14 429 env16774 = env16775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env16774 == env16775) = true)

theorem identity16775 : scanCanonicalize (H12AffineFastState.compose env16775 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound16775 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5377,429,115,5529,2265,1024,428,4296,33,153,2,120,64,2340,5528,4097,2421,1364,168,256,33,5593,513]

theorem envBound16776 : H12AffineFastState.Bounded env16776 := by
  intro p hp
  have h : env16776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16775_16776 : H12AffineEnvironment.transform 12 240 env16775 = env16776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env16775 == env16776) = true)

theorem identity16776 : scanCanonicalize (H12AffineFastState.compose env16776 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16776 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env16777 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,240,5156,136,115,5308,2265,1024,137,4296,33,153,2,120,64,2049,5309,4097,2128,1137,168,37,33,5372,513]

theorem envBound16777 : H12AffineFastState.Bounded env16777 := by
  intro p hp
  have h : env16777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16776_16777 : H12AffineEnvironment.transform 7 37 env16776 = env16777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16776 == env16777) = true)

theorem identity16777 : scanCanonicalize (H12AffineFastState.compose env16777 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16777 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16778 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,161,5156,136,34,5308,2184,1024,137,4249,33,153,2,41,17,2049,5309,4097,2049,1056,168,37,33,5293,513]

theorem envBound16778 : H12AffineFastState.Bounded env16778 := by
  intro p hp
  have h : env16778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16777_16778 : H12AffineEnvironment.transform 5 17 env16777 = env16778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16777 == env16778) = true)

theorem identity16778 : scanCanonicalize (H12AffineFastState.compose env16778 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound16778 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env16779 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,1060,161,0,136,34,152,2184,1024,137,1213,33,153,2,41,17,2049,153,1061,2049,1056,168,37,33,137,513]

theorem envBound16779 : H12AffineFastState.Bounded env16779 := by
  intro p hp
  have h : env16779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16778_16779 : H12AffineEnvironment.transform 11 1060 env16778 = env16779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env16778 == env16779) = true)

theorem identity16779 : scanCanonicalize (H12AffineFastState.compose env16779 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound16779 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16780 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,17,161,0,136,34,152,2184,53,137,136,33,153,2,41,17,2049,153,16,2049,21,168,37,33,137,513]

theorem envBound16780 : H12AffineFastState.Bounded env16780 := by
  intro p hp
  have h : env16780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16779_16780 : H12AffineEnvironment.transform 9 53 env16779 = env16780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env16779 == env16780) = true)

theorem identity16780 : scanCanonicalize (H12AffineFastState.compose env16780 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16780 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16781 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,17,41,0,0,34,16,2048,53,1,0,33,17,2,41,17,2049,17,16,2049,21,32,37,33,1,513]

theorem envBound16781 : H12AffineFastState.Bounded env16781 := by
  intro p hp
  have h : env16781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16780_16781 : H12AffineEnvironment.transform 6 8 env16780 = env16781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16780 == env16781) = true)

theorem identity16781 : scanCanonicalize (H12AffineFastState.compose env16781 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound16781 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16782 : List Nat := [2,4,8,16,32,17,8,37,32,53,2048,17,41,0,0,34,16,2048,53,1,0,33,17,2,41,17,2049,17,16,2049,21,32,37,33,1,33]

theorem envBound16782 : H12AffineFastState.Bounded env16782 := by
  intro p hp
  have h : env16782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16781_16782 : H12AffineEnvironment.transform 8 32 env16781 = env16782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env16781 == env16782) = true)

theorem identity16782 : scanCanonicalize (H12AffineFastState.compose env16782 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound16782 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16783 : List Nat := [2,4,8,16,32,17,8,37,32,53,48,17,41,0,0,34,16,48,53,1,0,33,17,2,41,17,49,17,16,49,21,32,37,33,1,33]

theorem envBound16783 : H12AffineFastState.Bounded env16783 := by
  intro p hp
  have h : env16783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16782_16783 : H12AffineEnvironment.transform 10 48 env16782 = env16783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env16782 == env16783) = true)

theorem identity16783 : scanCanonicalize (H12AffineFastState.compose env16783 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound16783 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16784 : List Nat := [2,4,8,16,17,17,8,20,17,4,1,17,24,0,0,19,16,1,4,1,0,16,17,2,24,17,0,17,16,0,21,17,20,16,1,16]

theorem envBound16784 : H12AffineFastState.Bounded env16784 := by
  intro p hp
  have h : env16784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16783_16784 : H12AffineEnvironment.transform 4 17 env16783 = env16784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env16783 == env16784) = true)

def env16785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,16777216,8328,64,17227835,18973836,77954,2598355,18932162,16850984,256,16818558,16793818,18990612]

theorem envBound16785 : H12AffineFastState.Bounded env16785 := by
  intro p hp
  have h : env16785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16694_16785 : H12AffineEnvironment.transform 21 2115049 env16694 = env16785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115049 env16694 == env16785) = true)

def env16786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,2175048,8328,64,2609267,46276,77954,2598355,119178,2101344,256,2199862,2191506,63068]

theorem envBound16786 : H12AffineFastState.Bounded env16786 := by
  intro p hp
  have h : env16786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16785_16786 : H12AffineEnvironment.transform 23 2175048 env16785 = env16786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175048 env16785 == env16786) = true)

def env16787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101481,2175187,2175048,8328,64,2590067,46276,77954,2598355,99466,2101344,256,2199862,2172306,41820]

theorem envBound16787 : H12AffineFastState.Bounded env16787 := by
  intro p hp
  have h : env16787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16786_16787 : H12AffineEnvironment.transform 13 5376 env16786 = env16787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16786 == env16787) = true)

theorem identity16787 : scanCanonicalize (H12AffineFastState.compose env16787 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound16787 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,169,73875,73736,8328,64,496947,46276,77954,505235,99466,32,256,98678,79314,41820]

theorem envBound16788 : H12AffineFastState.Bounded env16788 := by
  intro p hp
  have h : env16788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16787_16788 : H12AffineEnvironment.transform 20 4160 env16787 = env16788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env16787 == env16788) = true)

def env16789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,73755,73736,8192,64,496947,46156,77834,505115,99330,32,256,98678,79194,41820]

theorem envBound16789 : H12AffineFastState.Bounded env16789 := by
  intro p hp
  have h : env16789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16788_16789 : H12AffineEnvironment.transform 6 8 env16788 = env16789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16788 == env16789) = true)

theorem identity16789 : scanCanonicalize (H12AffineFastState.compose env16789 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound16789 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env16790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,103494,262144,1024,32769,4160,33,73755,73736,8192,64,262517,46156,77834,270685,99330,32,256,98678,79194,41820]

theorem envBound16790 : H12AffineFastState.Bounded env16790 := by
  intro p hp
  have h : env16790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16789_16790 : H12AffineEnvironment.transform 16 103494 env16789 = env16790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env16789 == env16790) = true)

theorem identity16790 : scanCanonicalize (H12AffineFastState.compose env16790 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16790 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env16791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,79131,262144,1024,8540,4160,33,73755,73736,8192,64,262517,5393,77834,270685,75103,32,256,73771,79194,513]

theorem envBound16791 : H12AffineFastState.Bounded env16791 := by
  intro p hp
  have h : env16791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16790_16791 : H12AffineEnvironment.transform 14 8541 env16790 = env16791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16790 == env16791) = true)

theorem identity16791 : scanCanonicalize (H12AffineFastState.compose env16791 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16791 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16792 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5157,8312,65536,78910,262144,1024,8313,4160,33,73755,73736,8192,64,262224,5172,77834,270456,74874,32,37,73771,78975,513]

theorem envBound16792 : H12AffineFastState.Bounded env16792 := by
  intro p hp
  have h : env16792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16791_16792 : H12AffineEnvironment.transform 7 37 env16791 = env16792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16791 == env16792) = true)

theorem identity16792 : scanCanonicalize (H12AffineFastState.compose env16792 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16792 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16793 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,8192,4113,8312,65536,77834,262144,52,8313,4160,33,73755,73736,8192,64,262224,4096,77834,270456,73806,32,37,73771,77899,513]

theorem envBound16793 : H12AffineFastState.Bounded env16793 := by
  intro p hp
  have h : env16793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16792_16793 : H12AffineEnvironment.transform 9 52 env16792 = env16793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16792 == env16793) = true)

theorem identity16793 : scanCanonicalize (H12AffineFastState.compose env16793 (packedSelected [0,2,4,5,6,7,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4729) := by decide +kernel

theorem selectedBound16793 : packedSelected [0,2,4,5,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env16794 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,4729,4113,4609,65536,66163,262144,52,4608,4160,33,70242,70257,4729,64,262224,4096,66163,266753,70199,32,37,70226,66098,513]

theorem envBound16794 : H12AffineFastState.Bounded env16794 := by
  intro p hp
  have h : env16794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16793_16794 : H12AffineEnvironment.transform 12 4729 env16793 = env16794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4729 env16793 == env16794) = true)

theorem identity16794 : scanCanonicalize (H12AffineFastState.compose env16794 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound16794 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env16795 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,4729,4113,4609,65536,66163,67618,52,4608,4160,33,70242,70257,4729,64,67698,4096,66163,72227,70199,32,37,70226,66098,513]

theorem envBound16795 : H12AffineFastState.Bounded env16795 := by
  intro p hp
  have h : env16795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16794_16795 : H12AffineEnvironment.transform 17 67618 env16794 = env16795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env16794 == env16795) = true)

theorem identity16795 : scanCanonicalize (H12AffineFastState.compose env16795 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 4642) := by decide +kernel

theorem selectedBound16795 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env16796 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,4729,4113,4609,4642,4177,6656,52,4608,4160,33,64,83,4729,64,6736,4096,4177,2049,21,32,37,112,4112,513]

theorem envBound16796 : H12AffineFastState.Bounded env16796 := by
  intro p hp
  have h : env16796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16795_16796 : H12AffineEnvironment.transform 15 4642 env16795 = env16796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4642 env16795 == env16796) = true)

theorem identity16796 : scanCanonicalize (H12AffineFastState.compose env16796 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound16796 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env16797 : List Nat := [2,4,8,16,32,64,8,37,17,52,2048,4096,4200,4113,4112,4147,4177,6161,52,4113,4160,33,64,83,4200,64,6209,4096,4177,2049,21,32,37,112,4112,16]

theorem envBound16797 : H12AffineFastState.Bounded env16797 := by
  intro p hp
  have h : env16797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16796_16797 : H12AffineEnvironment.transform 8 17 env16796 = env16797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env16796 == env16797) = true)

theorem identity16797 : scanCanonicalize (H12AffineFastState.compose env16797 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound16797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16798 : List Nat := [2,4,8,16,32,64,8,37,17,52,2048,1,105,16,17,50,80,2064,52,16,65,33,64,83,105,64,2112,1,80,2049,21,32,37,112,17,16]

theorem envBound16798 : H12AffineFastState.Bounded env16798 := by
  intro p hp
  have h : env16798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16797_16798 : H12AffineEnvironment.transform 11 1 env16797 = env16798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env16797 == env16798) = true)

theorem identity16798 : scanCanonicalize (H12AffineFastState.compose env16798 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16798 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16799 : List Nat := [2,4,3,16,32,64,3,37,17,52,2048,1,98,16,17,50,80,2064,52,16,65,33,64,83,98,64,2112,1,80,2049,21,32,37,112,17,16]

theorem envBound16799 : H12AffineFastState.Bounded env16799 := by
  intro p hp
  have h : env16799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16798_16799 : H12AffineEnvironment.transform 2 3 env16798 = env16799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16798 == env16799) = true)

theorem identity16799 : scanCanonicalize (H12AffineFastState.compose env16799 (packedSelected [0,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound16799 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16800 : List Nat := [2,4,3,16,32,0,3,37,17,52,2048,1,34,16,17,50,16,2064,52,16,1,33,0,19,34,0,2048,1,16,2049,21,32,37,48,17,16]

theorem envBound16800 : H12AffineFastState.Bounded env16800 := by
  intro p hp
  have h : env16800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16799_16800 : H12AffineEnvironment.transform 5 0 env16799 = env16800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env16799 == env16800) = true)

theorem identity16800 : scanCanonicalize (H12AffineFastState.compose env16800 (packedSelected [4,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound16800 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env16801 : List Nat := [2,4,3,16,32,0,3,37,17,52,16,1,34,16,17,50,16,0,52,16,1,33,0,19,34,0,16,1,16,17,21,32,37,48,17,16]

theorem envBound16801 : H12AffineFastState.Bounded env16801 := by
  intro p hp
  have h : env16801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16800_16801 : H12AffineEnvironment.transform 10 16 env16800 = env16801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env16800 == env16801) = true)

theorem identity16801 : scanCanonicalize (H12AffineFastState.compose env16801 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16801 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16802 : List Nat := [2,4,3,0,32,0,3,37,1,36,0,1,34,0,1,34,0,0,36,0,1,33,0,3,34,0,0,1,0,1,5,32,37,32,1,0]

theorem envBound16802 : H12AffineFastState.Bounded env16802 := by
  intro p hp
  have h : env16802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16801_16802 : H12AffineEnvironment.transform 3 0 env16801 = env16802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16801 == env16802) = true)

def env16803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73754,73736,8193,64,496947,46157,77835,505114,99331,32,256,98678,79195,41820]

theorem envBound16803 : H12AffineFastState.Bounded env16803 := by
  intro p hp
  have h : env16803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16788_16803 : H12AffineEnvironment.transform 6 9 env16788 = env16803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16788 == env16803) = true)

theorem identity16803 : scanCanonicalize (H12AffineFastState.compose env16803 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound16803 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env16804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,79131,262144,1024,32769,4160,32,73754,73736,8193,64,303144,46157,77835,294913,99331,32,256,98678,79195,41820]

theorem envBound16804 : H12AffineFastState.Bounded env16804 := by
  intro p hp
  have h : env16804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16803_16804 : H12AffineEnvironment.transform 16 79131 env16803 = env16804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env16803 == env16804) = true)

theorem identity16804 : scanCanonicalize (H12AffineFastState.compose env16804 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16804 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env16805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,79131,262144,1024,8540,4160,32,73754,73736,8193,64,262517,5392,77835,270684,75102,32,256,73771,79195,513]

theorem envBound16805 : H12AffineFastState.Bounded env16805 := by
  intro p hp
  have h : env16805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16804_16805 : H12AffineEnvironment.transform 14 8541 env16804 = env16805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16804 == env16805) = true)

theorem identity16805 : scanCanonicalize (H12AffineFastState.compose env16805 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound16805 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env16806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,262,13341,262144,1024,8540,4160,32,8476,8462,8193,64,262517,5392,12557,270684,9304,32,256,8493,13405,513]

theorem envBound16806 : H12AffineFastState.Bounded env16806 := by
  intro p hp
  have h : env16806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16805_16806 : H12AffineEnvironment.transform 15 262 env16805 = env16806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env16805 == env16806) = true)

theorem identity16806 : scanCanonicalize (H12AffineFastState.compose env16806 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16806 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,80,262,5392,262144,1024,81,4160,32,17,3,268,64,262517,5392,4096,262225,1365,32,256,32,5456,513]

theorem envBound16807 : H12AffineFastState.Bounded env16807 := by
  intro p hp
  have h : env16807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16806_16807 : H12AffineEnvironment.transform 12 269 env16806 = env16807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16806 == env16807) = true)

theorem identity16807 : scanCanonicalize (H12AffineFastState.compose env16807 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound16807 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,80,262,5392,2421,1024,81,4160,32,17,3,268,64,2048,5392,4096,2340,1365,32,256,32,5456,513]

theorem envBound16808 : H12AffineFastState.Bounded env16808 := by
  intro p hp
  have h : env16808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16807_16808 : H12AffineEnvironment.transform 17 2421 env16807 = env16808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env16807 == env16808) = true)

theorem identity16808 : scanCanonicalize (H12AffineFastState.compose env16808 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound16808 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env16809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,269,1124,80,262,1140,2421,1024,81,292,32,17,3,268,64,2048,1140,356,2340,1365,32,256,32,1076,513]

theorem envBound16809 : H12AffineFastState.Bounded env16809 := by
  intro p hp
  have h : env16809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16808_16809 : H12AffineEnvironment.transform 11 356 env16808 = env16809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env16808 == env16809) = true)

theorem identity16809 : scanCanonicalize (H12AffineFastState.compose env16809 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound16809 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env16810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,356,269,1124,80,262,1140,81,1024,81,292,32,17,3,268,64,292,1140,356,0,1365,32,256,32,1076,513]

theorem envBound16810 : H12AffineFastState.Bounded env16810 := by
  intro p hp
  have h : env16810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16809_16810 : H12AffineEnvironment.transform 10 292 env16809 = env16810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env16809 == env16810) = true)

theorem identity16810 : scanCanonicalize (H12AffineFastState.compose env16810 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16810 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16811 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,308,269,1076,0,262,1060,1,1024,1,292,32,17,3,268,16,292,1060,308,0,1285,32,256,32,1076,513]

theorem envBound16811 : H12AffineFastState.Bounded env16811 := by
  intro p hp
  have h : env16811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16810_16811 : H12AffineEnvironment.transform 5 16 env16810 = env16811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16810 == env16811) = true)

theorem identity16811 : scanCanonicalize (H12AffineFastState.compose env16811 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound16811 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16812 : List Nat := [2,4,8,16,32,16,9,256,512,304,292,308,269,260,0,262,276,1,304,1,292,32,17,3,268,16,292,276,308,0,53,32,256,32,260,513]

theorem envBound16812 : H12AffineFastState.Bounded env16812 := by
  intro p hp
  have h : env16812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16811_16812 : H12AffineEnvironment.transform 9 304 env16811 = env16812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env16811 == env16812) = true)

theorem identity16812 : scanCanonicalize (H12AffineFastState.compose env16812 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16812 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16813 : List Nat := [2,4,8,16,32,16,9,256,0,304,292,308,269,260,0,262,276,1,304,1,292,32,17,3,268,16,292,276,308,0,53,32,256,32,260,1]

theorem envBound16813 : H12AffineFastState.Bounded env16813 := by
  intro p hp
  have h : env16813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16812_16813 : H12AffineEnvironment.transform 8 0 env16812 = env16813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16812 == env16813) = true)

theorem identity16813 : scanCanonicalize (H12AffineFastState.compose env16813 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16814 : List Nat := [2,4,8,0,32,0,9,256,0,288,292,292,269,260,0,262,260,1,288,1,292,32,1,3,268,0,292,260,292,0,37,32,256,32,260,1]

theorem envBound16814 : H12AffineFastState.Bounded env16814 := by
  intro p hp
  have h : env16814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16813_16814 : H12AffineEnvironment.transform 3 0 env16813 = env16814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16813 == env16814) = true)

theorem identity16814 : scanCanonicalize (H12AffineFastState.compose env16814 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16814 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16815 : List Nat := [2,4,8,0,0,0,9,256,0,256,260,260,269,260,0,262,260,1,256,1,260,0,1,3,268,0,260,260,260,0,5,0,256,0,260,1]

theorem envBound16815 : H12AffineFastState.Bounded env16815 := by
  intro p hp
  have h : env16815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16814_16815 : H12AffineEnvironment.transform 4 0 env16814 = env16815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16814 == env16815) = true)

theorem identity16815 : scanCanonicalize (H12AffineFastState.compose env16815 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16815 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16816 : List Nat := [2,4,2,0,0,0,3,256,0,256,260,260,263,260,0,262,260,1,256,1,260,0,1,3,262,0,260,260,260,0,5,0,256,0,260,1]

theorem envBound16816 : H12AffineFastState.Bounded env16816 := by
  intro p hp
  have h : env16816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16815_16816 : H12AffineEnvironment.transform 2 2 env16815 = env16816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16815 == env16816) = true)

theorem identity16816 : scanCanonicalize (H12AffineFastState.compose env16816 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16816 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16817 : List Nat := [2,4,2,0,0,0,3,4,0,4,0,0,3,0,0,2,0,1,4,1,0,0,1,3,2,0,0,0,0,0,5,0,4,0,0,1]

theorem envBound16817 : H12AffineFastState.Bounded env16817 := by
  intro p hp
  have h : env16817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16816_16817 : H12AffineEnvironment.transform 7 4 env16816 = env16817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16816 == env16817) = true)

def env16818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101480,2175186,2175048,8328,64,2590066,46276,77954,2598355,99467,2101344,256,2199862,2172307,41821]

theorem envBound16818 : H12AffineFastState.Bounded env16818 := by
  intro p hp
  have h : env16818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16786_16818 : H12AffineEnvironment.transform 13 5377 env16786 = env16818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16786 == env16818) = true)

def env16819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101344,2175066,2175048,8192,64,2590066,46156,77834,2598235,99331,2101344,256,2199862,2172187,41821]

theorem envBound16819 : H12AffineFastState.Bounded env16819 := by
  intro p hp
  have h : env16819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16818_16819 : H12AffineEnvironment.transform 6 8 env16818 = env16819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16818 == env16819) = true)

def env16820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,2097152,2101344,2175066,2175048,8192,64,2338138,46156,77834,2329971,99331,2101344,256,2199862,2172187,41821]

theorem envBound16820 : H12AffineFastState.Bounded env16820 := by
  intro p hp
  have h : env16820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16819_16820 : H12AffineEnvironment.transform 17 10280 env16819 = env16820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env16819 == env16820) = true)

theorem identity16820 : scanCanonicalize (H12AffineFastState.compose env16820 (packedSelected [3,4,5,7,8,9,10,14,16,20,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound16820 : packedSelected [3,4,5,7,8,9,10,14,16,20,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env16821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,10280,1024,32769,2097152,2101344,2175066,2175048,8192,64,2136128,46156,77834,2144361,99331,2101344,256,2199862,2172187,41821]

theorem envBound16821 : H12AffineFastState.Bounded env16821 := by
  intro p hp
  have h : env16821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16820_16821 : H12AffineEnvironment.transform 16 79130 env16820 = env16821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env16820 == env16821) = true)

theorem identity16821 : scanCanonicalize (H12AffineFastState.compose env16821 (packedSelected [16,20] rootPS)) = affineNative (2^(20+1) ^^^ 45341) := by decide +kernel

theorem selectedBound16821 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env16822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,10280,1024,32769,45341,41341,98631,98645,8192,64,10589,46156,77834,2420,99331,41341,256,73771,103430,41821]

theorem envBound16822 : H12AffineFastState.Bounded env16822 := by
  intro p hp
  have h : env16822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16821_16822 : H12AffineEnvironment.transform 20 45341 env16821 = env16822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45341 env16821 == env16822) = true)

def env16823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,2097152,2101344,2175066,2175048,8192,64,2338139,46156,77834,2329970,99331,2101344,256,2199862,2172187,41821]

theorem envBound16823 : H12AffineFastState.Bounded env16823 := by
  intro p hp
  have h : env16823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16819_16823 : H12AffineEnvironment.transform 17 10281 env16819 = env16823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env16819 == env16823) = true)

theorem identity16823 : scanCanonicalize (H12AffineFastState.compose env16823 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound16823 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,77898,73770,16,2,8192,64,171281,46156,77834,179512,99331,73770,256,41340,5457,41821]

theorem envBound16824 : H12AffineFastState.Bounded env16824 := by
  intro p hp
  have h : env16824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16823_16824 : H12AffineEnvironment.transform 20 77898 env16823 = env16824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env16823 == env16824) = true)

theorem identity16824 : scanCanonicalize (H12AffineFastState.compose env16824 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound16824 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env16825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103494,10281,1024,32769,77898,73770,16,2,8192,64,67927,46156,77834,76158,99331,73770,256,41340,5457,41821]

theorem envBound16825 : H12AffineFastState.Bounded env16825 := by
  intro p hp
  have h : env16825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16824_16825 : H12AffineEnvironment.transform 16 103494 env16824 = env16825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env16824 == env16825) = true)

theorem identity16825 : scanCanonicalize (H12AffineFastState.compose env16825 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound16825 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env16826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,65536,70727,10281,1024,0,77898,73770,16,2,8192,64,67927,13389,77834,76158,66562,73770,256,8573,5457,9052]

theorem envBound16826 : H12AffineFastState.Bounded env16826 := by
  intro p hp
  have h : env16826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16825_16826 : H12AffineEnvironment.transform 14 1 env16825 = env16826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env16825 == env16826) = true)

theorem identity16826 : scanCanonicalize (H12AffineFastState.compose env16826 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound16826 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,1,65536,70727,2048,1024,0,69731,65539,16,2,41,64,67927,5220,69667,67927,66562,65539,256,340,5457,885]

theorem envBound16827 : H12AffineFastState.Bounded env16827 := by
  intro p hp
  have h : env16827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16826_16827 : H12AffineEnvironment.transform 12 41 env16826 = env16827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16826 == env16827) = true)

def env16828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101345,2175067,2175048,8193,64,2590066,46157,77835,2598234,99330,2101344,256,2199862,2172186,41821]

theorem envBound16828 : H12AffineFastState.Bounded env16828 := by
  intro p hp
  have h : env16828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16818_16828 : H12AffineEnvironment.transform 6 9 env16818 = env16828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16818 == env16828) = true)

theorem identity16828 : scanCanonicalize (H12AffineFastState.compose env16828 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16828 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env16829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,2097152,2101345,2175067,2175048,8193,64,2565166,5393,77835,2556934,75102,2101344,256,2175082,2172186,513]

theorem envBound16829 : H12AffineFastState.Bounded env16829 := by
  intro p hp
  have h : env16829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16828_16829 : H12AffineEnvironment.transform 14 8540 env16828 = env16829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16828 == env16829) = true)

def env16830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10280,1024,8541,2097152,2101345,2175067,2175048,8193,64,2296838,5393,77835,2305070,75102,2101344,256,2175082,2172186,513]

theorem envBound16830 : H12AffineFastState.Bounded env16830 := by
  intro p hp
  have h : env16830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16829_16830 : H12AffineEnvironment.transform 17 10280 env16829 = env16830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env16829 == env16830) = true)

theorem identity16830 : scanCanonicalize (H12AffineFastState.compose env16830 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound16830 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,10280,1024,8541,2097152,2101345,2175067,2175048,8193,64,2111772,5393,77835,2103604,75102,2101344,256,2175082,2172186,513]

theorem envBound16831 : H12AffineFastState.Bounded env16831 := by
  intro p hp
  have h : env16831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16830_16831 : H12AffineEnvironment.transform 16 79130 env16830 = env16831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env16830 == env16831) = true)

theorem identity16831 : scanCanonicalize (H12AffineFastState.compose env16831 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound16831 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,10280,1024,8541,5457,1328,75018,75033,8193,64,11341,5393,77835,3173,75102,1329,256,75067,77899,513]

theorem envBound16832 : H12AffineFastState.Bounded env16832 := by
  intro p hp
  have h : env16832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16831_16832 : H12AffineEnvironment.transform 20 5457 env16831 = env16832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env16831 == env16832) = true)

theorem identity16832 : scanCanonicalize (H12AffineFastState.compose env16832 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound16832 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env16833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,8192,1345,8540,65536,75098,10280,1024,8541,1297,1328,75018,75033,8193,64,11341,1361,73803,3173,75102,1329,256,75067,73739,513]

theorem envBound16833 : H12AffineFastState.Bounded env16833 := by
  intro p hp
  have h : env16833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16832_16833 : H12AffineEnvironment.transform 11 64 env16832 = env16833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env16832 == env16833) = true)

theorem identity16833 : scanCanonicalize (H12AffineFastState.compose env16833 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound16833 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env16834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,8192,1345,8540,342,9228,10280,1024,8541,1297,1328,9308,9295,8193,64,11341,1361,8477,3173,9224,1329,256,9325,8541,513]

theorem envBound16834 : H12AffineFastState.Bounded env16834 := by
  intro p hp
  have h : env16834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16833_16834 : H12AffineEnvironment.transform 15 342 env16833 = env16834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env16833 == env16834) = true)

theorem identity16834 : scanCanonicalize (H12AffineFastState.compose env16834 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16834 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env16835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,268,1345,80,342,1280,2340,1024,81,1297,1328,1360,1347,269,64,3393,1361,17,3173,1284,1329,256,1377,81,513]

theorem envBound16835 : H12AffineFastState.Bounded env16835 := by
  intro p hp
  have h : env16835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16834_16835 : H12AffineEnvironment.transform 12 268 env16834 = env16835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16834 == env16835) = true)

theorem identity16835 : scanCanonicalize (H12AffineFastState.compose env16835 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound16835 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env16836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,64,268,1345,80,342,1280,1125,1024,81,1297,1328,1360,1347,269,64,0,1361,17,292,1284,1329,256,1377,81,513]

theorem envBound16836 : H12AffineFastState.Bounded env16836 := by
  intro p hp
  have h : env16836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16835_16836 : H12AffineEnvironment.transform 10 1345 env16835 = env16836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env16835 == env16836) = true)

theorem identity16836 : scanCanonicalize (H12AffineFastState.compose env16836 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16836 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env16837 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1296,17,268,1296,1,263,1280,1076,1024,0,1297,1328,1281,1298,269,17,0,1280,17,292,1284,1329,256,1328,0,513]

theorem envBound16837 : H12AffineFastState.Bounded env16837 := by
  intro p hp
  have h : env16837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16836_16837 : H12AffineEnvironment.transform 5 17 env16836 = env16837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16836 == env16837) = true)

theorem identity16837 : scanCanonicalize (H12AffineFastState.compose env16837 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16837 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16838 : List Nat := [2,4,8,16,32,17,9,256,512,273,1,17,268,1,1,263,17,293,273,0,0,33,16,3,269,17,0,17,17,292,21,32,256,33,0,513]

theorem envBound16838 : H12AffineFastState.Bounded env16838 := by
  intro p hp
  have h : env16838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16837_16838 : H12AffineEnvironment.transform 9 273 env16837 = env16838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16837 == env16838) = true)

theorem identity16838 : scanCanonicalize (H12AffineFastState.compose env16838 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16838 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16839 : List Nat := [2,4,8,1,32,0,9,256,512,256,1,0,268,1,1,263,0,293,256,0,0,33,1,3,269,0,0,0,0,292,4,32,256,33,0,513]

theorem envBound16839 : H12AffineFastState.Bounded env16839 := by
  intro p hp
  have h : env16839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16838_16839 : H12AffineEnvironment.transform 3 1 env16838 = env16839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16838 == env16839) = true)

theorem identity16839 : scanCanonicalize (H12AffineFastState.compose env16839 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound16839 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16840 : List Nat := [2,4,8,1,32,0,9,256,261,256,1,0,268,1,1,263,0,293,256,0,0,33,1,3,269,0,0,0,0,292,4,32,256,33,0,260]

theorem envBound16840 : H12AffineFastState.Bounded env16840 := by
  intro p hp
  have h : env16840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16839_16840 : H12AffineEnvironment.transform 8 261 env16839 = env16840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env16839 == env16840) = true)

theorem identity16840 : scanCanonicalize (H12AffineFastState.compose env16840 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16840 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16841 : List Nat := [2,4,8,1,32,0,9,4,1,4,1,0,8,1,1,3,0,33,4,0,0,33,1,3,9,0,0,0,0,32,4,32,4,33,0,0]

theorem envBound16841 : H12AffineFastState.Bounded env16841 := by
  intro p hp
  have h : env16841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16840_16841 : H12AffineEnvironment.transform 7 4 env16840 = env16841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16840 == env16841) = true)

theorem identity16841 : scanCanonicalize (H12AffineFastState.compose env16841 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16841 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16842 : List Nat := [2,4,8,1,0,0,9,4,1,4,1,0,8,1,1,3,0,1,4,0,0,1,1,3,9,0,0,0,0,0,4,0,4,1,0,0]

theorem envBound16842 : H12AffineFastState.Bounded env16842 := by
  intro p hp
  have h : env16842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16841_16842 : H12AffineEnvironment.transform 4 0 env16841 = env16842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16841 == env16842) = true)

def env16843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,2097152,2101345,2175067,2175048,8193,64,2296839,5393,77835,2305071,75102,2101344,256,2175082,2172186,513]

theorem envBound16843 : H12AffineFastState.Bounded env16843 := by
  intro p hp
  have h : env16843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16829_16843 : H12AffineEnvironment.transform 17 10281 env16829 = env16843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env16829 == env16843) = true)

theorem identity16843 : scanCanonicalize (H12AffineFastState.compose env16843 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 206091) := by decide +kernel

theorem selectedBound16843 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env16844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,206091,210282,136528,136515,8193,64,10508,5393,77835,2340,75102,210283,256,136545,131089,513]

theorem envBound16844 : H12AffineFastState.Bounded env16844 := by
  intro p hp
  have h : env16844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16843_16844 : H12AffineEnvironment.transform 20 206091 env16843 = env16844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206091 env16843 == env16844) = true)

theorem identity16844 : scanCanonicalize (H12AffineFastState.compose env16844 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound16844 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env16845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,5393,10281,1024,8541,77850,73851,65,82,8193,64,10508,5393,77835,2340,75102,73850,256,112,5376,513]

theorem envBound16845 : H12AffineFastState.Bounded env16845 := by
  intro p hp
  have h : env16845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16844_16845 : H12AffineEnvironment.transform 16 5393 env16844 = env16845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env16844 == env16845) = true)

theorem identity16845 : scanCanonicalize (H12AffineFastState.compose env16845 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound16845 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env16846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,343,5393,10281,1024,8541,12621,8492,65,82,8193,64,10508,5393,12636,2340,9225,8493,256,112,5376,513]

theorem envBound16846 : H12AffineFastState.Bounded env16846 := by
  intro p hp
  have h : env16846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16845_16846 : H12AffineEnvironment.transform 15 343 env16845 = env16846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env16845 == env16846) = true)

def env16847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,2175049,8328,64,2609266,46277,77954,2598355,119179,2101345,256,2199863,2191507,63069]

theorem envBound16847 : H12AffineFastState.Bounded env16847 := by
  intro p hp
  have h : env16847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16785_16847 : H12AffineEnvironment.transform 23 2175049 env16785 = env16847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175049 env16785 == env16847) = true)

def env16848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101481,2175187,2175049,8328,64,2590066,46277,77954,2598355,99467,2101345,256,2199863,2172307,41821]

theorem envBound16848 : H12AffineFastState.Bounded env16848 := by
  intro p hp
  have h : env16848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16847_16848 : H12AffineEnvironment.transform 13 5376 env16847 = env16848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16847 == env16848) = true)

theorem identity16848 : scanCanonicalize (H12AffineFastState.compose env16848 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound16848 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,2097152,2101481,2175187,2175049,8328,64,2565166,5529,77954,2557071,75223,2101345,256,2175083,2172307,513]

theorem envBound16849 : H12AffineFastState.Bounded env16849 := by
  intro p hp
  have h : env16849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16848_16849 : H12AffineEnvironment.transform 14 8540 env16848 = env16849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env16848 == env16849) = true)

def env16850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,2097152,2101481,2175187,2175049,8328,64,2296974,5529,77954,2305071,75223,2101345,256,2175083,2172307,513]

theorem envBound16850 : H12AffineFastState.Bounded env16850 := by
  intro p hp
  have h : env16850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16849_16850 : H12AffineEnvironment.transform 17 10400 env16849 = env16850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env16849 == env16850) = true)

def env16851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1024,8541,2097152,2101345,2175067,2175049,8192,64,2296838,5393,77834,2305071,75103,2101345,256,2175083,2172187,513]

theorem envBound16851 : H12AffineFastState.Bounded env16851 := by
  intro p hp
  have h : env16851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16850_16851 : H12AffineEnvironment.transform 6 8 env16850 = env16851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16850 == env16851) = true)

theorem identity16851 : scanCanonicalize (H12AffineFastState.compose env16851 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound16851 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,79131,10280,1024,8541,2097152,2101345,2175067,2175049,8192,64,2111773,5393,77834,2103604,75103,2101345,256,2175083,2172187,513]

theorem envBound16852 : H12AffineFastState.Bounded env16852 := by
  intro p hp
  have h : env16852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16851_16852 : H12AffineEnvironment.transform 16 79131 env16851 = env16852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env16851 == env16852) = true)

theorem identity16852 : scanCanonicalize (H12AffineFastState.compose env16852 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound16852 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,9499,4096,10280,1024,8541,2097152,2101345,2102592,2102610,8192,64,2111773,5393,5393,2103604,68,2101345,256,2102640,2097152,513]

theorem envBound16853 : H12AffineFastState.Bounded env16853 := by
  intro p hp
  have h : env16853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16852_16853 : H12AffineEnvironment.transform 15 9499 env16852 = env16853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env16852 == env16853) = true)

theorem identity16853 : scanCanonicalize (H12AffineFastState.compose env16853 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(20+1) ^^^ 3393) := by decide +kernel

theorem selectedBound16853 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env16854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,9499,4096,10280,1024,8541,3393,7456,6145,6163,8192,64,13404,5393,5393,5237,68,7456,256,6193,3393,513]

theorem envBound16854 : H12AffineFastState.Bounded env16854 := by
  intro p hp
  have h : env16854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16853_16854 : H12AffineEnvironment.transform 20 3393 env16853 = env16854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3393 env16853 == env16854) = true)

theorem identity16854 : scanCanonicalize (H12AffineFastState.compose env16854 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound16854 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env16855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,8192,2049,8540,9499,3329,10280,1024,8541,3393,33,1280,1298,8192,64,10589,2064,2064,2420,68,33,256,1328,3393,513]

theorem envBound16855 : H12AffineFastState.Bounded env16855 := by
  intro p hp
  have h : env16855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16854_16855 : H12AffineEnvironment.transform 11 3329 env16854 = env16855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env16854 == env16855) = true)

theorem identity16855 : scanCanonicalize (H12AffineFastState.compose env16855 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound16855 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env16856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,41,2049,373,1330,3329,2049,1024,372,3393,33,1280,1298,41,64,2420,2064,2064,2420,68,33,256,1328,3393,513]

theorem envBound16856 : H12AffineFastState.Bounded env16856 := by
  intro p hp
  have h : env16856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16855_16856 : H12AffineEnvironment.transform 12 41 env16855 = env16856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16855 == env16856) = true)

theorem identity16856 : scanCanonicalize (H12AffineFastState.compose env16856 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16856 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env16857 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3109,41,2049,81,1046,3109,2049,1024,80,3173,33,1060,1078,41,64,2128,2064,2064,2128,68,33,36,1044,3173,513]

theorem envBound16857 : H12AffineFastState.Bounded env16857 := by
  intro p hp
  have h : env16857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16856_16857 : H12AffineEnvironment.transform 7 36 env16856 = env16857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16856 == env16857) = true)

theorem identity16857 : scanCanonicalize (H12AffineFastState.compose env16857 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound16857 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16858 : List Nat := [2,4,8,16,32,64,8,36,512,1024,593,1652,41,592,81,1046,1652,592,1024,80,1588,33,1060,1078,41,64,513,577,577,513,68,33,36,1044,1588,513]

theorem envBound16858 : H12AffineFastState.Bounded env16858 := by
  intro p hp
  have h : env16858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16857_16858 : H12AffineEnvironment.transform 10 593 env16857 = env16858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env16857 == env16858) = true)

theorem identity16858 : scanCanonicalize (H12AffineFastState.compose env16858 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound16858 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env16859 : List Nat := [2,4,8,16,32,64,8,36,512,101,593,529,41,592,81,115,529,592,101,80,593,33,65,83,41,64,513,577,577,513,68,33,36,113,593,513]

theorem envBound16859 : H12AffineFastState.Bounded env16859 := by
  intro p hp
  have h : env16859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16858_16859 : H12AffineEnvironment.transform 9 101 env16858 = env16859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env16858 == env16859) = true)

theorem identity16859 : scanCanonicalize (H12AffineFastState.compose env16859 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16859 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16860 : List Nat := [2,4,8,16,32,17,8,36,512,52,512,529,41,513,0,34,529,513,52,1,512,33,16,2,41,17,513,528,528,513,21,33,36,32,512,513]

theorem envBound16860 : H12AffineFastState.Bounded env16860 := by
  intro p hp
  have h : env16860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16859_16860 : H12AffineEnvironment.transform 5 17 env16859 = env16860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16859 == env16860) = true)

theorem identity16860 : scanCanonicalize (H12AffineFastState.compose env16860 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound16860 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16861 : List Nat := [2,4,8,16,32,17,8,36,48,52,48,33,41,49,0,34,33,49,52,1,48,33,16,2,41,17,49,32,32,49,21,33,36,32,48,49]

theorem envBound16861 : H12AffineFastState.Bounded env16861 := by
  intro p hp
  have h : env16861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16860_16861 : H12AffineEnvironment.transform 8 48 env16860 = env16861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env16860 == env16861) = true)

theorem identity16861 : scanCanonicalize (H12AffineFastState.compose env16861 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16861 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16862 : List Nat := [2,4,8,16,16,17,8,20,0,4,0,17,25,1,0,18,17,1,4,1,0,17,16,2,25,17,1,16,16,1,21,17,20,16,0,1]

theorem envBound16862 : H12AffineFastState.Bounded env16862 := by
  intro p hp
  have h : env16862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16861_16862 : H12AffineEnvironment.transform 4 16 env16861 = env16862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16861 == env16862) = true)

def env16863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,2097152,2101344,2175066,2175049,8193,64,2296839,5392,77835,2305071,75102,2101345,256,2175083,2172186,513]

theorem envBound16863 : H12AffineFastState.Bounded env16863 := by
  intro p hp
  have h : env16863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16850_16863 : H12AffineEnvironment.transform 6 9 env16850 = env16863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16850 == env16863) = true)

theorem identity16863 : scanCanonicalize (H12AffineFastState.compose env16863 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 206091) := by decide +kernel

theorem selectedBound16863 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env16864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,206091,210283,136529,136514,8193,64,10508,5392,77835,2340,75102,210282,256,136544,131089,513]

theorem envBound16864 : H12AffineFastState.Bounded env16864 := by
  intro p hp
  have h : env16864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16863_16864 : H12AffineEnvironment.transform 20 206091 env16863 = env16864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206091 env16863 == env16864) = true)

theorem identity16864 : scanCanonicalize (H12AffineFastState.compose env16864 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound16864 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env16865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,5392,10281,1024,8541,77851,73851,65,82,8193,64,10508,5392,77835,2340,75102,73850,256,112,5377,513]

theorem envBound16865 : H12AffineFastState.Bounded env16865 := by
  intro p hp
  have h : env16865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16864_16865 : H12AffineEnvironment.transform 16 5392 env16864 = env16865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env16864 == env16865) = true)

theorem identity16865 : scanCanonicalize (H12AffineFastState.compose env16865 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound16865 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env16866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,343,5392,10281,1024,8541,12620,8492,65,82,8193,64,10508,5392,12636,2340,9225,8493,256,112,5377,513]

theorem envBound16866 : H12AffineFastState.Bounded env16866 := by
  intro p hp
  have h : env16866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16865_16866 : H12AffineEnvironment.transform 15 343 env16865 = env16866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env16865 == env16866) = true)

def env16867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,2097152,2101481,2175187,2175049,8328,64,2296975,5529,77954,2305070,75223,2101345,256,2175083,2172307,513]

theorem envBound16867 : H12AffineFastState.Bounded env16867 := by
  intro p hp
  have h : env16867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16849_16867 : H12AffineEnvironment.transform 17 10401 env16849 = env16867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16849 == env16867) = true)

theorem identity16867 : scanCanonicalize (H12AffineFastState.compose env16867 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 78019) := by decide +kernel

theorem selectedBound16867 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,78019,73770,16,138,8328,64,146508,5529,77954,138477,75223,73890,256,168,5456,513]

theorem envBound16868 : H12AffineFastState.Bounded env16868 := by
  intro p hp
  have h : env16868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16867_16868 : H12AffineEnvironment.transform 20 78019 env16867 = env16868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78019 env16867 == env16868) = true)

theorem identity16868 : scanCanonicalize (H12AffineFastState.compose env16868 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound16868 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env16869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,79131,10401,1024,8541,78019,73770,16,138,8328,64,67927,5529,77954,76278,75223,73890,256,168,5456,513]

theorem envBound16869 : H12AffineFastState.Bounded env16869 := by
  intro p hp
  have h : env16869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16868_16869 : H12AffineEnvironment.transform 16 79131 env16868 = env16869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env16868 == env16869) = true)

theorem identity16869 : scanCanonicalize (H12AffineFastState.compose env16869 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound16869 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env16870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,9499,4096,10401,1024,8541,5592,1329,16,138,8328,64,11340,5529,5529,3309,204,1465,256,168,5456,513]

theorem envBound16870 : H12AffineFastState.Bounded env16870 := by
  intro p hp
  have h : env16870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16869_16870 : H12AffineEnvironment.transform 15 9499 env16869 = env16870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env16869 == env16870) = true)

theorem identity16870 : scanCanonicalize (H12AffineFastState.compose env16870 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound16870 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env16871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,5376,1213,250,4096,3392,1024,1212,5592,1329,16,138,1385,64,2477,5529,5529,3309,204,1465,256,168,5456,513]

theorem envBound16871 : H12AffineFastState.Bounded env16871 := by
  intro p hp
  have h : env16871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16870_16871 : H12AffineEnvironment.transform 12 1505 env16870 = env16871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env16870 == env16871) = true)

theorem identity16871 : scanCanonicalize (H12AffineFastState.compose env16871 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound16871 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env16872 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,161,4160,509,250,4096,2048,320,508,4248,113,16,138,41,64,2477,4313,4313,2477,204,249,256,168,4112,513]

theorem envBound16872 : H12AffineFastState.Bounded env16872 := by
  intro p hp
  have h : env16872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16871_16872 : H12AffineEnvironment.transform 9 320 env16871 = env16872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env16871 == env16872) = true)

theorem identity16872 : scanCanonicalize (H12AffineFastState.compose env16872 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

end H12CloudChart0