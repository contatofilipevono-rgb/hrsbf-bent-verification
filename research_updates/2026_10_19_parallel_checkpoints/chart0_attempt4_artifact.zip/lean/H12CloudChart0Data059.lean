import H12CloudChart0Data058

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound14823 : H12AffineFastState.Bounded env14823 := by
  intro p hp
  have h : env14823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14822_14823 : H12AffineEnvironment.transform 8 81 env14822 = env14823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env14822 == env14823) = true)

theorem identity14823 : scanCanonicalize (H12AffineFastState.compose env14823 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14823 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14824 : List Nat := [2,4,2,16,32,64,2,117,81,101,80,17,115,1,80,114,17,1,100,81,81,32,16,3,115,65,0,16,16,80,68,32,116,33,81,80]

theorem envBound14824 : H12AffineFastState.Bounded env14824 := by
  intro p hp
  have h : env14824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14823_14824 : H12AffineEnvironment.transform 2 2 env14823 = env14824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14823 == env14824) = true)

def env14825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,103494,10280,1025,32769,115734,73770,16,95496,8193,65,10588,79130,102743,97407,61704,62589,257,95530,103430,120407]

theorem envBound14825 : H12AffineFastState.Bounded env14825 := by
  intro p hp
  have h : env14825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14813_14825 : H12AffineEnvironment.transform 6 9 env14813 = env14825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14813 == env14825) = true)

theorem identity14825 : scanCanonicalize (H12AffineFastState.compose env14825 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound14825 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16401,10280,1025,32769,4161,62589,16,41311,8193,65,10588,57677,17664,43048,61704,62589,257,41341,16465,512]

theorem envBound14826 : H12AffineFastState.Bounded env14826 := by
  intro p hp
  have h : env14826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14825_14826 : H12AffineEnvironment.transform 15 54359 env14825 = env14826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env14825 == env14826) = true)

theorem identity14826 : scanCanonicalize (H12AffineFastState.compose env14826 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 15625) := by decide +kernel

theorem selectedBound14826 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env14827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,15625,26974,16401,10280,1025,15624,4161,18804,16,7254,8193,65,10588,23620,17664,5409,19457,18804,257,7284,16465,512]

theorem envBound14827 : H12AffineFastState.Bounded env14827 := by
  intro p hp
  have h : env14827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14826_14827 : H12AffineEnvironment.transform 14 15625 env14826 = env14827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15625 env14826 == env14827) = true)

theorem identity14827 : scanCanonicalize (H12AffineFastState.compose env14827 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 2080) := by decide +kernel

theorem selectedBound14827 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2080,15625,8574,2097,10280,1025,15624,4161,340,16,7254,8193,65,10588,5220,3360,5409,1057,340,257,7284,2161,512]

theorem envBound14828 : H12AffineFastState.Bounded env14828 := by
  intro p hp
  have h : env14828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14827_14828 : H12AffineEnvironment.transform 13 2080 env14827 = env14828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2080 env14827 == env14828) = true)

theorem identity14828 : scanCanonicalize (H12AffineFastState.compose env14828 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound14828 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env14829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,2080,7536,263,2097,2129,1025,7537,4161,340,16,7254,120,65,2341,5220,3360,5409,1057,340,257,7284,2161,512]

theorem envBound14829 : H12AffineFastState.Bounded env14829 := by
  intro p hp
  have h : env14829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14828_14829 : H12AffineEnvironment.transform 12 121 env14828 = env14829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env14828 == env14829) = true)

theorem identity14829 : scanCanonicalize (H12AffineFastState.compose env14829 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound14829 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env14830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,121,2080,112,263,2097,2129,1025,113,3393,340,16,342,120,65,2341,2404,3360,2081,1057,340,257,372,2161,512]

theorem envBound14830 : H12AffineFastState.Bounded env14830 := by
  intro p hp
  have h : env14830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14829_14830 : H12AffineEnvironment.transform 11 3328 env14829 = env14830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env14829 == env14830) = true)

theorem identity14830 : scanCanonicalize (H12AffineFastState.compose env14830 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14830 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env14831 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,3328,88,2049,81,263,2064,2129,1025,80,3393,340,16,342,89,65,2308,2373,3329,2048,1024,340,257,341,2128,512]

theorem envBound14831 : H12AffineFastState.Bounded env14831 := by
  intro p hp
  have h : env14831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14830_14831 : H12AffineEnvironment.transform 4 1 env14830 = env14831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14830 == env14831) = true)

theorem identity14831 : scanCanonicalize (H12AffineFastState.compose env14831 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound14831 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14832 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,3156,88,2049,81,83,2064,2129,1025,80,3093,0,16,2,89,65,2128,2065,3157,2048,1024,0,85,1,2128,512]

theorem envBound14832 : H12AffineFastState.Bounded env14832 := by
  intro p hp
  have h : env14832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14831_14832 : H12AffineEnvironment.transform 7 84 env14831 = env14832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env14831 == env14832) = true)

theorem identity14832 : scanCanonicalize (H12AffineFastState.compose env14832 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound14832 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14833 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1045,65,88,1044,81,83,1029,1092,1025,80,0,0,16,2,89,65,1093,1028,64,1045,1024,0,85,1,1093,512]

theorem envBound14833 : H12AffineFastState.Bounded env14833 := by
  intro p hp
  have h : env14833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14832_14833 : H12AffineEnvironment.transform 10 1045 env14832 = env14833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env14832 == env14833) = true)

theorem identity14833 : scanCanonicalize (H12AffineFastState.compose env14833 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound14833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14834 : List Nat := [2,4,8,16,1,64,9,84,512,20,1,65,88,0,81,83,17,80,21,80,0,0,16,2,89,65,81,16,64,1,20,0,85,1,81,512]

theorem envBound14834 : H12AffineFastState.Bounded env14834 := by
  intro p hp
  have h : env14834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14833_14834 : H12AffineEnvironment.transform 9 20 env14833 = env14834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14833 == env14834) = true)

theorem identity14834 : scanCanonicalize (H12AffineFastState.compose env14834 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14834 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14835 : List Nat := [2,4,8,16,1,16,9,4,512,20,1,17,8,0,1,3,17,0,21,0,0,0,16,2,9,17,1,16,16,1,20,0,5,1,1,512]

theorem envBound14835 : H12AffineFastState.Bounded env14835 := by
  intro p hp
  have h : env14835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14834_14835 : H12AffineEnvironment.transform 5 16 env14834 = env14835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14834 == env14835) = true)

theorem identity14835 : scanCanonicalize (H12AffineFastState.compose env14835 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound14835 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14836 : List Nat := [2,4,8,16,1,16,9,4,14,20,1,17,8,0,1,3,17,0,21,0,0,0,16,2,9,17,1,16,16,1,20,0,5,1,1,14]

theorem envBound14836 : H12AffineFastState.Bounded env14836 := by
  intro p hp
  have h : env14836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14835_14836 : H12AffineEnvironment.transform 8 14 env14835 = env14836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env14835 == env14836) = true)

def env14837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,17,95496,8328,65,4365617,79130,102879,190520,61705,4314199,257,95531,103566,120543]

theorem envBound14837 : H12AffineFastState.Bounded env14837 := by
  intro p hp
  have h : env14837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14810_14837 : H12AffineEnvironment.transform 22 17 env14810 = env14837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14810 == env14837) = true)

theorem identity14837 : scanCanonicalize (H12AffineFastState.compose env14837 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14837 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,58517,4194304,17,21762,8328,65,4365617,5392,45525,190520,61705,4256861,257,21793,46212,63189]

theorem envBound14838 : H12AffineFastState.Bounded env14838 := by
  intro p hp
  have h : env14838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14837_14838 : H12AffineEnvironment.transform 15 8202 env14837 = env14838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14837 == env14838) = true)

theorem identity14838 : scanCanonicalize (H12AffineFastState.compose env14838 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 62628) := by decide +kernel

theorem selectedBound14838 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env14839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,58517,62628,17,21762,8328,65,158101,5392,45525,190520,61705,249,257,21793,46212,63189]

theorem envBound14839 : H12AffineFastState.Bounded env14839 := by
  intro p hp
  have h : env14839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14838_14839 : H12AffineEnvironment.transform 21 62628 env14838 = env14839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62628 env14838 == env14839) = true)

theorem identity14839 : scanCanonicalize (H12AffineFastState.compose env14839 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound14839 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env14840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46277,10280,1025,32769,58517,62628,17,21762,8328,65,56656,5392,45525,23805,61705,249,257,21793,46212,63189]

theorem envBound14840 : H12AffineFastState.Bounded env14840 := by
  intro p hp
  have h : env14840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14839_14840 : H12AffineEnvironment.transform 16 46277 env14839 = env14840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env14839 == env14840) = true)

theorem identity14840 : scanCanonicalize (H12AffineFastState.compose env14840 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound14840 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14841 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,16384,32768,8202,45404,10280,408,32769,57612,61757,17,20635,8328,65,55497,4233,45525,22884,61705,249,257,20664,45341,62284]

theorem envBound14841 : H12AffineFastState.Bounded env14841 := by
  intro p hp
  have h : env14841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14840_14841 : H12AffineEnvironment.transform 9 409 env14840 = env14841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env14840 == env14841) = true)

theorem identity14841 : scanCanonicalize (H12AffineFastState.compose env14841 (packedSelected [0,1,7,8,11,14,17,19,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14841 : packedSelected [0,1,7,8,11,14,17,19,20,23] rootPS < 2^1333 := by decide +kernel

def env14842 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,8192,16384,32768,8202,45325,10280,408,32769,57612,61757,17,20635,8328,16,55448,4233,45444,22837,61705,168,257,20664,45341,62237]

theorem envBound14842 : H12AffineFastState.Bounded env14842 := by
  intro p hp
  have h : env14842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14841_14842 : H12AffineEnvironment.transform 5 17 env14841 = env14842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14841 == env14842) = true)

theorem identity14842 : scanCanonicalize (H12AffineFastState.compose env14842 (packedSelected [0,1,7,8,11,14,16,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14842 : packedSelected [0,1,7,8,11,14,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env14843 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,8192,16384,0,8202,12557,10280,408,1,24844,28989,17,20635,8328,16,22680,4233,12676,22837,28937,168,257,20664,12573,29469]

theorem envBound14843 : H12AffineFastState.Bounded env14843 := by
  intro p hp
  have h : env14843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14842_14843 : H12AffineEnvironment.transform 14 0 env14842 = env14843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14842 == env14843) = true)

theorem identity14843 : scanCanonicalize (H12AffineFastState.compose env14843 (packedSelected [0,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 12464) := by decide +kernel

theorem selectedBound14843 : packedSelected [0,7,14,16] rootPS < 2^1333 := by decide +kernel

def env14844 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,8192,12464,0,8202,12557,10280,408,1,4540,397,17,8235,8328,16,10280,4233,12676,10629,441,168,257,8200,12573,941]

theorem envBound14844 : H12AffineFastState.Bounded env14844 := by
  intro p hp
  have h : env14844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14843_14844 : H12AffineEnvironment.transform 13 12464 env14843 = env14844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12464 env14843 == env14844) = true)

theorem identity14844 : scanCanonicalize (H12AffineFastState.compose env14844 (packedSelected [2,5,6,8,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14844 : packedSelected [2,5,6,8,17] rootPS < 2^1333 := by decide +kernel

def env14845 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,4096,269,4541,0,263,4096,2341,408,1,4540,397,17,294,389,16,2341,4233,4233,2184,441,168,257,261,4112,941]

theorem envBound14845 : H12AffineFastState.Bounded env14845 := by
  intro p hp
  have h : env14845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14844_14845 : H12AffineEnvironment.transform 12 269 env14844 = env14845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14844 == env14845) = true)

theorem identity14845 : scanCanonicalize (H12AffineFastState.compose env14845 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound14845 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env14846 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,4096,161,4113,0,171,4096,2185,52,1,4112,33,17,138,41,16,2185,4233,4233,2184,21,168,173,169,4112,513]

theorem envBound14846 : H12AffineFastState.Bounded env14846 := by
  intro p hp
  have h : env14846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14845_14846 : H12AffineEnvironment.transform 7 172 env14845 = env14846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env14845 == env14846) = true)

theorem identity14846 : scanCanonicalize (H12AffineFastState.compose env14846 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound14846 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14847 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,513,161,528,0,171,513,2185,52,1,529,33,17,138,41,16,2185,648,648,2184,21,168,173,169,529,513]

theorem envBound14847 : H12AffineFastState.Bounded env14847 := by
  intro p hp
  have h : env14847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14846_14847 : H12AffineEnvironment.transform 11 513 env14846 = env14847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env14846 == env14847) = true)

def env14848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,8388608,95497,8328,65,12754208,79130,8491471,8579112,8450329,4314199,257,8484154,8492191,8509135]

theorem envBound14848 : H12AffineFastState.Bounded env14848 := by
  intro p hp
  have h : env14848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14809_14848 : H12AffineEnvironment.transform 17 10281 env14809 = env14848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14809 == env14848) = true)

def env14849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,16,95497,8328,65,4365616,79130,102879,190520,61705,4314199,257,95530,103567,120543]

theorem envBound14849 : H12AffineFastState.Bounded env14849 := by
  intro p hp
  have h : env14849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14848_14849 : H12AffineEnvironment.transform 22 16 env14848 = env14849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14848 == env14849) = true)

theorem identity14849 : scanCanonicalize (H12AffineFastState.compose env14849 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 119927) := by decide +kernel

theorem selectedBound14849 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,119927,16,95497,8328,65,215367,79130,102879,190520,61705,32,257,95530,103567,120543]

theorem envBound14850 : H12AffineFastState.Bounded env14850 := by
  intro p hp
  have h : env14850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14849_14850 : H12AffineEnvironment.transform 21 119927 env14849 = env14850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119927 env14849 == env14850) = true)

theorem identity14850 : scanCanonicalize (H12AffineFastState.compose env14850 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14850 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env14851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1025,32769,115870,119927,16,95497,8328,65,10588,79130,102879,100387,61705,32,257,95530,103567,120543]

theorem envBound14851 : H12AffineFastState.Bounded env14851 := by
  intro p hp
  have h : env14851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14850_14851 : H12AffineEnvironment.transform 16 90139 env14850 = env14851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14850 == env14851) = true)

theorem identity14851 : scanCanonicalize (H12AffineFastState.compose env14851 (packedSelected [0,3,4,7,10,11,12,15,16,17,18,20,22,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound14851 : packedSelected [0,3,4,7,10,11,12,15,16,17,18,20,22,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env14852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,46156,10281,1025,32769,4297,32,16,41310,8328,65,10588,57677,17800,23668,61705,32,257,41341,16600,648]

theorem envBound14852 : H12AffineFastState.Bounded env14852 := by
  intro p hp
  have h : env14852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14851_14852 : H12AffineEnvironment.transform 15 54359 env14851 = env14852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env14851 == env14852) = true)

theorem identity14852 : scanCanonicalize (H12AffineFastState.compose env14852 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound14852 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env14853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,216,21647,13460,10281,1025,217,4297,32,16,8582,8328,65,10588,24981,17800,23668,29137,32,257,8613,16600,648]

theorem envBound14853 : H12AffineFastState.Bounded env14853 := by
  intro p hp
  have h : env14853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14852_14853 : H12AffineEnvironment.transform 14 216 env14852 = env14853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env14852 == env14853) = true)

theorem identity14853 : scanCanonicalize (H12AffineFastState.compose env14853 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound14853 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env14854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,216,8403,13460,10281,1025,217,4297,32,16,8582,8328,65,10588,5577,12756,10280,1421,32,257,8613,13444,648]

theorem envBound14854 : H12AffineFastState.Bounded env14854 := by
  intro p hp
  have h : env14854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14853_14854 : H12AffineEnvironment.transform 13 13404 env14853 = env14854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env14853 == env14854) = true)

theorem identity14854 : scanCanonicalize (H12AffineFastState.compose env14854 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14854 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env14855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,80,8283,13340,10281,1025,81,4161,32,16,8462,8192,65,10588,5441,12636,10280,1285,32,257,8493,13324,512]

theorem envBound14855 : H12AffineFastState.Bounded env14855 := by
  intro p hp
  have h : env14855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14854_14855 : H12AffineEnvironment.transform 6 8 env14854 = env14855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14854 == env14855) = true)

theorem identity14855 : scanCanonicalize (H12AffineFastState.compose env14855 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound14855 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,380,5408,80,295,5472,2389,1025,81,4161,32,16,114,380,65,2080,5441,4128,2388,1285,32,257,81,5488,512]

theorem envBound14856 : H12AffineFastState.Bounded env14856 := by
  intro p hp
  have h : env14856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14855_14856 : H12AffineEnvironment.transform 12 380 env14855 = env14856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env14855 == env14856) = true)

theorem identity14856 : scanCanonicalize (H12AffineFastState.compose env14856 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14856 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14857 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,349,5377,80,262,5441,2389,1025,81,4161,1,16,83,349,65,2049,5441,4097,2388,1285,1,257,81,5457,512]

theorem envBound14857 : H12AffineFastState.Bounded env14857 := by
  intro p hp
  have h : env14857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14856_14857 : H12AffineEnvironment.transform 4 1 env14856 = env14857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14856 == env14857) = true)

theorem identity14857 : scanCanonicalize (H12AffineFastState.compose env14857 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(10+1) ^^^ 862) := by decide +kernel

theorem selectedBound14857 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env14858 : List Nat := [2,4,8,16,1,64,8,256,512,1024,862,4096,349,5377,80,262,5441,523,1025,81,4161,1,16,83,349,65,863,5441,4097,522,1285,1,257,81,5457,512]

theorem envBound14858 : H12AffineFastState.Bounded env14858 := by
  intro p hp
  have h : env14858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14857_14858 : H12AffineEnvironment.transform 10 862 env14857 = env14858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 862 env14857 == env14858) = true)

theorem identity14858 : scanCanonicalize (H12AffineFastState.compose env14858 (packedSelected [1,3,4,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound14858 : packedSelected [1,3,4,7,14] rootPS < 2^1333 := by decide +kernel

def env14859 : List Nat := [2,4,8,16,1,64,8,84,512,1024,522,4096,9,5205,80,82,5141,523,1025,81,4161,1,16,83,9,65,523,5141,4097,522,1105,1,85,81,5125,512]

theorem envBound14859 : H12AffineFastState.Bounded env14859 := by
  intro p hp
  have h : env14859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14858_14859 : H12AffineEnvironment.transform 7 84 env14858 = env14859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env14858 == env14859) = true)

theorem identity14859 : scanCanonicalize (H12AffineFastState.compose env14859 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14859 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env14860 : List Nat := [2,4,8,16,1,17,8,5,512,1024,522,4096,9,5124,1,3,5141,523,1025,0,4112,1,16,2,9,16,523,5141,4097,522,1024,1,4,0,5125,512]

theorem envBound14860 : H12AffineFastState.Bounded env14860 := by
  intro p hp
  have h : env14860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14859_14860 : H12AffineEnvironment.transform 5 17 env14859 = env14860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14859 == env14860) = true)

def env14861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,17,95497,8328,65,4365617,79130,102878,190521,61704,4314199,257,95531,103566,120542]

theorem envBound14861 : H12AffineFastState.Bounded env14861 := by
  intro p hp
  have h : env14861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14848_14861 : H12AffineEnvironment.transform 22 17 env14848 = env14861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14848 == env14861) = true)

theorem identity14861 : scanCanonicalize (H12AffineFastState.compose env14861 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound14861 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10281,1025,32769,4161,4194304,17,41430,8328,65,4365617,57797,17665,190521,61704,4194440,257,41460,16465,513]

theorem envBound14862 : H12AffineFastState.Bounded env14862 := by
  intro p hp
  have h : env14862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14861_14862 : H12AffineEnvironment.transform 15 54495 env14861 = env14862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env14861 == env14862) = true)

def env14863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4161,4194304,17,41310,8192,65,4365617,57677,17665,190521,61704,4194304,257,41340,16465,513]

theorem envBound14863 : H12AffineFastState.Bounded env14863 := by
  intro p hp
  have h : env14863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14862_14863 : H12AffineEnvironment.transform 6 8 env14862 = env14863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14862 == env14863) = true)

theorem identity14863 : scanCanonicalize (H12AffineFastState.compose env14863 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14863 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,131072,10281,1025,8541,4161,4194304,17,2,8192,65,4340845,16401,17665,149861,20564,4194304,257,32,16465,513]

theorem envBound14864 : H12AffineFastState.Bounded env14864 := by
  intro p hp
  have h : env14864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14863_14864 : H12AffineEnvironment.transform 14 8540 env14863 = env14864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14863 == env14864) = true)

theorem identity14864 : scanCanonicalize (H12AffineFastState.compose env14864 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound14864 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14865 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,131072,10281,273,8541,4161,4194304,17,2,8192,65,4340093,16401,16401,149861,20564,4194304,257,32,16465,513]

theorem envBound14865 : H12AffineFastState.Bounded env14865 := by
  intro p hp
  have h : env14865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14864_14865 : H12AffineEnvironment.transform 9 272 env14864 = env14865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14864 == env14865) = true)

theorem identity14865 : scanCanonicalize (H12AffineFastState.compose env14865 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound14865 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env14866 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,28699,4096,10281,273,8541,4161,4194304,17,2,8192,65,4204925,16401,16401,22885,20564,4194304,257,32,16465,513]

theorem envBound14866 : H12AffineFastState.Bounded env14866 := by
  intro p hp
  have h : env14866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14865_14866 : H12AffineEnvironment.transform 16 4096 env14865 = env14866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env14865 == env14866) = true)

theorem identity14866 : scanCanonicalize (H12AffineFastState.compose env14866 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound14866 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env14867 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,4096,8192,16384,8540,28699,4096,8233,273,8541,4161,4194304,17,2,8192,65,4202877,16401,16401,20837,20564,4194304,257,32,16465,513]

theorem envBound14867 : H12AffineFastState.Bounded env14867 := by
  intro p hp
  have h : env14867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14866_14867 : H12AffineEnvironment.transform 10 0 env14866 = env14867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14866 == env14867) = true)

theorem identity14867 : scanCanonicalize (H12AffineFastState.compose env14867 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound14867 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env14868 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,4096,8192,16384,8540,28699,4096,8233,273,8541,4161,8493,17,2,8192,65,80,16401,16401,20837,20564,8493,257,32,16465,513]

theorem envBound14868 : H12AffineFastState.Bounded env14868 := by
  intro p hp
  have h : env14868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14867_14868 : H12AffineEnvironment.transform 21 8493 env14867 = env14868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env14867 == env14868) = true)

theorem identity14868 : scanCanonicalize (H12AffineFastState.compose env14868 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound14868 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14869 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,4096,4380,16384,4160,16647,4096,4405,273,4161,4161,4145,17,2,4380,65,80,16401,16401,20837,20564,4145,257,32,16465,513]

theorem envBound14869 : H12AffineFastState.Bounded env14869 := by
  intro p hp
  have h : env14869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14868_14869 : H12AffineEnvironment.transform 12 4380 env14868 = env14869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env14868 == env14869) = true)

theorem identity14869 : scanCanonicalize (H12AffineFastState.compose env14869 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound14869 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env14870 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,308,40,16384,372,16647,308,1,273,373,373,261,17,2,40,65,80,16401,16401,16465,16736,261,257,32,16465,513]

theorem envBound14870 : H12AffineFastState.Bounded env14870 := by
  intro p hp
  have h : env14870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14869_14870 : H12AffineEnvironment.transform 11 308 env14869 = env14870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env14869 == env14870) = true)

theorem identity14870 : scanCanonicalize (H12AffineFastState.compose env14870 (packedSelected [2,4,6,9,15] rootPS)) = affineNative (2^(13+1) ^^^ 372) := by decide +kernel

theorem selectedBound14870 : packedSelected [2,4,6,9,15] rootPS < 2^1333 := by decide +kernel

def env14871 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,308,40,372,372,115,308,1,273,373,373,261,17,2,40,65,80,357,357,293,20,261,257,32,293,513]

theorem envBound14871 : H12AffineFastState.Bounded env14871 := by
  intro p hp
  have h : env14871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14870_14871 : H12AffineEnvironment.transform 13 372 env14870 = env14871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 372 env14870 == env14871) = true)

theorem identity14871 : scanCanonicalize (H12AffineFastState.compose env14871 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound14871 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14872 : List Nat := [2,4,8,16,32,64,8,68,512,84,0,112,40,48,48,115,112,1,85,49,49,65,17,2,40,65,80,33,33,97,20,65,69,32,97,513]

theorem envBound14872 : H12AffineFastState.Bounded env14872 := by
  intro p hp
  have h : env14872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14871_14872 : H12AffineEnvironment.transform 7 68 env14871 = env14872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env14871 == env14872) = true)

theorem identity14872 : scanCanonicalize (H12AffineFastState.compose env14872 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14872 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env14873 : List Nat := [2,4,8,16,1,64,8,68,512,84,0,81,9,17,17,82,81,1,85,16,16,65,17,2,9,65,80,0,0,64,20,65,69,1,64,513]

theorem envBound14873 : H12AffineFastState.Bounded env14873 := by
  intro p hp
  have h : env14873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14872_14873 : H12AffineEnvironment.transform 4 1 env14872 = env14873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14872 == env14873) = true)

def env14874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4161,4194304,17,41311,8193,65,4365617,57676,17665,190521,61704,4194305,257,41341,16465,513]

theorem envBound14874 : H12AffineFastState.Bounded env14874 := by
  intro p hp
  have h : env14874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14862_14874 : H12AffineEnvironment.transform 6 9 env14862 = env14874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14862 == env14874) = true)

def env14875 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4113,4194304,17,41231,8193,17,4365617,57628,17665,190521,61704,4194305,257,41261,16385,513]

theorem envBound14875 : H12AffineFastState.Bounded env14875 := by
  intro p hp
  have h : env14875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14874_14875 : H12AffineEnvironment.transform 5 16 env14874 = env14875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14874 == env14875) = true)

theorem identity14875 : scanCanonicalize (H12AffineFastState.compose env14875 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound14875 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env14876 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4113,8493,17,41231,8193,17,179228,57628,17665,190521,61704,8492,257,41261,16385,513]

theorem envBound14876 : H12AffineFastState.Bounded env14876 := by
  intro p hp
  have h : env14876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14875_14876 : H12AffineEnvironment.transform 21 8493 env14875 = env14876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env14875 == env14876) = true)

theorem identity14876 : scanCanonicalize (H12AffineFastState.compose env14876 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound14876 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14877 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54278,38160,10281,1025,32769,4113,8493,17,41231,8193,17,10508,57628,17665,32041,61704,8492,257,41261,16385,513]

theorem envBound14877 : H12AffineFastState.Bounded env14877 := by
  intro p hp
  have h : env14877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14876_14877 : H12AffineEnvironment.transform 16 38160 env14876 = env14877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env14876 == env14877) = true)

theorem identity14877 : scanCanonicalize (H12AffineFastState.compose env14877 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound14877 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14878 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33030,38160,10281,1025,32769,4113,8493,17,41231,8193,17,10508,46108,4097,10281,41992,8492,257,41261,5377,513]

theorem envBound14878 : H12AffineFastState.Bounded env14878 := by
  intro p hp
  have h : env14878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14877_14878 : H12AffineEnvironment.transform 13 5376 env14877 = env14878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14877 == env14878) = true)

theorem identity14878 : scanCanonicalize (H12AffineFastState.compose env14878 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14878 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14879 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,32768,33030,38160,2340,1025,32769,4113,32,17,32770,268,17,2049,38161,4097,2340,34053,33,257,32800,5377,513]

theorem envBound14879 : H12AffineFastState.Bounded env14879 := by
  intro p hp
  have h : env14879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14878_14879 : H12AffineEnvironment.transform 12 269 env14878 = env14879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14878 == env14879) = true)

theorem identity14879 : scanCanonicalize (H12AffineFastState.compose env14879 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14879 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14880 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1025,1,4113,32,17,2,268,17,2049,5393,4097,2340,1285,33,257,32,5377,513]

theorem envBound14880 : H12AffineFastState.Bounded env14880 := by
  intro p hp
  have h : env14880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14879_14880 : H12AffineEnvironment.transform 14 0 env14879 = env14880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14879 == env14880) = true)

theorem identity14880 : scanCanonicalize (H12AffineFastState.compose env14880 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound14880 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14881 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,4096,56,5173,0,51,5157,2065,1025,1,4113,32,17,2,57,17,2049,5156,4097,2065,1072,33,52,32,5172,513]

theorem envBound14881 : H12AffineFastState.Bounded env14881 := by
  intro p hp
  have h : env14881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14880_14881 : H12AffineEnvironment.transform 7 53 env14880 = env14881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env14880 == env14881) = true)

theorem identity14881 : scanCanonicalize (H12AffineFastState.compose env14881 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound14881 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14882 : List Nat := [2,4,8,16,32,16,9,53,512,1024,2048,1573,56,528,0,51,512,2065,1025,1,1588,32,17,2,57,17,2049,513,1572,2065,1072,33,52,32,529,513]

theorem envBound14882 : H12AffineFastState.Bounded env14882 := by
  intro p hp
  have h : env14882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14881_14882 : H12AffineEnvironment.transform 11 1573 env14881 = env14882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env14881 == env14882) = true)

theorem identity14882 : scanCanonicalize (H12AffineFastState.compose env14882 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound14882 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14883 : List Nat := [2,4,8,16,32,16,9,53,512,565,2048,16,56,528,0,51,512,2065,564,1,1,32,17,2,57,17,2049,513,17,2065,517,33,52,32,529,513]

theorem envBound14883 : H12AffineFastState.Bounded env14883 := by
  intro p hp
  have h : env14883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14882_14883 : H12AffineEnvironment.transform 9 565 env14882 = env14883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env14882 == env14883) = true)

def env14884 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4112,4194304,17,41230,8193,16,4365617,57629,17665,190521,61704,4194305,257,41260,16384,513]

theorem envBound14884 : H12AffineFastState.Bounded env14884 := by
  intro p hp
  have h : env14884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14874_14884 : H12AffineEnvironment.transform 5 17 env14874 = env14884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14874 == env14884) = true)

theorem identity14884 : scanCanonicalize (H12AffineFastState.compose env14884 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14884 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env14885 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21510,131072,10281,1025,0,4112,4194304,17,8463,8193,16,4332848,24860,17665,157752,28937,4194305,257,8493,16384,513]

theorem envBound14885 : H12AffineFastState.Bounded env14885 := by
  intro p hp
  have h : env14885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14884_14885 : H12AffineEnvironment.transform 14 1 env14884 = env14885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14884 == env14885) = true)

theorem identity14885 : scanCanonicalize (H12AffineFastState.compose env14885 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound14885 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14886 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21510,131072,10281,1025,0,4112,8492,17,8463,8193,16,146460,24860,17665,157752,28937,8493,257,8493,16384,513]

theorem envBound14886 : H12AffineFastState.Bounded env14886 := by
  intro p hp
  have h : env14886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14885_14886 : H12AffineEnvironment.transform 21 8492 env14885 = env14886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env14885 == env14886) = true)

theorem identity14886 : scanCanonicalize (H12AffineFastState.compose env14886 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound14886 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14887 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21510,16401,10281,1025,0,4112,8492,17,8463,8193,16,31757,24860,17665,10281,28937,8493,257,8493,16384,513]

theorem envBound14887 : H12AffineFastState.Bounded env14887 := by
  intro p hp
  have h : env14887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14886_14887 : H12AffineEnvironment.transform 16 16401 env14886 = env14887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14886 == env14887) = true)

theorem identity14887 : scanCanonicalize (H12AffineFastState.compose env14887 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14887 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14888 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,1,263,5392,10281,1025,0,4112,8492,17,8463,8193,16,10508,13341,4096,10281,9224,8493,257,8493,5377,513]

theorem envBound14888 : H12AffineFastState.Bounded env14888 := by
  intro p hp
  have h : env14888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14887_14888 : H12AffineEnvironment.transform 13 5377 env14887 = env14888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14887 == env14888) = true)

theorem identity14888 : scanCanonicalize (H12AffineFastState.compose env14888 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14888 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14889 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5157,1,35,5172,10281,1025,0,4112,8200,17,8235,8193,16,10280,13341,4096,10281,9224,8201,37,8201,5157,513]

theorem envBound14889 : H12AffineFastState.Bounded env14889 := by
  intro p hp
  have h : env14889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14888_14889 : H12AffineEnvironment.transform 7 36 env14888 = env14889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14888 == env14889) = true)

theorem identity14889 : scanCanonicalize (H12AffineFastState.compose env14889 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound14889 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14890 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,7180,5157,1,35,5172,5157,1025,0,4112,7172,17,7207,7181,16,5156,2065,4096,5157,6148,7173,37,7173,5157,513]

theorem envBound14890 : H12AffineFastState.Bounded env14890 := by
  intro p hp
  have h : env14890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14889_14890 : H12AffineEnvironment.transform 12 7180 env14889 = env14890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env14889 == env14890) = true)

theorem identity14890 : scanCanonicalize (H12AffineFastState.compose env14890 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14890 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14891 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1,4096,5133,5157,1,35,5172,5157,1025,0,4112,5125,17,5158,5132,16,5156,16,4096,5157,4101,5124,37,5124,5157,513]

theorem envBound14891 : H12AffineFastState.Bounded env14891 := by
  intro p hp
  have h : env14891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14890_14891 : H12AffineEnvironment.transform 10 1 env14890 = env14891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14890 == env14891) = true)

theorem identity14891 : scanCanonicalize (H12AffineFastState.compose env14891 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound14891 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14892 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1,1061,40,0,1,35,17,0,1025,0,1077,32,17,3,41,16,1,16,1061,0,1056,33,37,33,0,513]

theorem envBound14892 : H12AffineFastState.Bounded env14892 := by
  intro p hp
  have h : env14892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14891_14892 : H12AffineEnvironment.transform 11 1061 env14891 = env14892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env14891 == env14892) = true)

theorem identity14892 : scanCanonicalize (H12AffineFastState.compose env14892 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14892 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14893 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,16,40,0,1,35,17,0,52,0,0,32,17,3,41,16,1,16,16,0,21,33,37,33,0,513]

theorem envBound14893 : H12AffineFastState.Bounded env14893 := by
  intro p hp
  have h : env14893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14892_14893 : H12AffineEnvironment.transform 9 53 env14892 = env14893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14892 == env14893) = true)

theorem identity14893 : scanCanonicalize (H12AffineFastState.compose env14893 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound14893 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14894 : List Nat := [2,0,8,16,32,17,9,32,512,49,1,16,40,0,1,35,17,0,48,0,0,32,17,3,41,16,1,16,16,0,17,33,33,33,0,513]

theorem envBound14894 : H12AffineFastState.Bounded env14894 := by
  intro p hp
  have h : env14894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14893_14894 : H12AffineEnvironment.transform 1 0 env14893 = env14894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env14893 == env14894) = true)

theorem identity14894 : scanCanonicalize (H12AffineFastState.compose env14894 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound14894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14895 : List Nat := [2,0,8,2,32,3,9,32,512,35,1,2,40,0,1,35,3,0,34,0,0,32,3,3,41,2,1,2,2,0,3,33,33,33,0,513]

theorem envBound14895 : H12AffineFastState.Bounded env14895 := by
  intro p hp
  have h : env14895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14894_14895 : H12AffineEnvironment.transform 3 2 env14894 = env14895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env14894 == env14895) = true)

theorem identity14895 : scanCanonicalize (H12AffineFastState.compose env14895 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound14895 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14896 : List Nat := [2,0,8,2,32,3,9,32,10,35,1,2,40,0,1,35,3,0,34,0,0,32,3,3,41,2,1,2,2,0,3,33,33,33,0,11]

theorem envBound14896 : H12AffineFastState.Bounded env14896 := by
  intro p hp
  have h : env14896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14895_14896 : H12AffineEnvironment.transform 8 10 env14895 = env14896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env14895 == env14896) = true)

theorem identity14896 : scanCanonicalize (H12AffineFastState.compose env14896 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14896 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14897 : List Nat := [2,0,8,2,1,3,9,1,10,2,1,2,9,0,1,2,3,0,3,0,0,1,3,3,8,2,1,2,2,0,3,0,0,0,0,11]

theorem envBound14897 : H12AffineFastState.Bounded env14897 := by
  intro p hp
  have h : env14897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14896_14897 : H12AffineEnvironment.transform 4 1 env14896 = env14897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14896 == env14897) = true)

def env14898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388279,4194304,8388608,351521,8328,65,12754209,79131,8763878,8830977,8706353,4314198,257,8484155,8492190,8781543]

theorem envBound14898 : H12AffineFastState.Bounded env14898 := by
  intro p hp
  have h : env14898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14808_14898 : H12AffineEnvironment.transform 23 351521 env14808 = env14898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351521 env14808 == env14898) = true)

def env14899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,8388608,95497,8328,65,12754209,79131,8491470,8579113,8450329,4314198,257,8484155,8492190,8509135]

theorem envBound14899 : H12AffineFastState.Bounded env14899 := by
  intro p hp
  have h : env14899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14898_14899 : H12AffineEnvironment.transform 17 10280 env14898 = env14899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14898 == env14899) = true)

def env14900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,16,95497,8328,65,4365617,79131,102878,190521,61705,4314198,257,95531,103566,120543]

theorem envBound14900 : H12AffineFastState.Bounded env14900 := by
  intro p hp
  have h : env14900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14899_14900 : H12AffineEnvironment.transform 22 16 env14899 = env14900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14899 == env14900) = true)

theorem identity14900 : scanCanonicalize (H12AffineFastState.compose env14900 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound14900 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,62589,16,95497,8328,65,158028,79131,102878,190521,61705,73771,257,95531,103566,120543]

theorem envBound14901 : H12AffineFastState.Bounded env14901 := by
  intro p hp
  have h : env14901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14900_14901 : H12AffineEnvironment.transform 21 62589 env14900 = env14901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env14900 == env14901) = true)

theorem identity14901 : scanCanonicalize (H12AffineFastState.compose env14901 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound14901 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env14902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10280,1025,32769,4161,62589,16,41431,8328,65,158028,57797,17664,190521,61705,62709,257,41461,16464,513]

theorem envBound14902 : H12AffineFastState.Bounded env14902 := by
  intro p hp
  have h : env14902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14901_14902 : H12AffineEnvironment.transform 15 54494 env14901 = env14902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env14901 == env14902) = true)

theorem identity14902 : scanCanonicalize (H12AffineFastState.compose env14902 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound14902 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,46277,10280,1025,32769,4161,62589,16,41431,8328,65,56713,57797,17664,23804,61705,62709,257,41461,16464,513]

theorem envBound14903 : H12AffineFastState.Bounded env14903 := by
  intro p hp
  have h : env14903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14902_14903 : H12AffineEnvironment.transform 16 46277 env14902 = env14903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env14902 == env14903) = true)

theorem identity14903 : scanCanonicalize (H12AffineFastState.compose env14903 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9413) := by decide +kernel

theorem selectedBound14903 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9413,28699,4096,10280,1025,9412,4161,20664,16,1298,8328,65,31052,17664,17664,23804,21964,20528,257,1328,16464,513]

theorem envBound14904 : H12AffineFastState.Bounded env14904 := by
  intro p hp
  have h : env14904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14903_14904 : H12AffineEnvironment.transform 14 9413 env14903 = env14904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9413 env14903 == env14904) = true)

theorem identity14904 : scanCanonicalize (H12AffineFastState.compose env14904 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14904 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,9413,9498,4096,10280,1025,9412,4161,1465,16,1298,8328,65,11341,4097,4097,2557,205,1329,257,1328,5457,513]

theorem envBound14905 : H12AffineFastState.Bounded env14905 := by
  intro p hp
  have h : env14905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14904_14905 : H12AffineEnvironment.transform 13 5377 env14904 = env14905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14904 == env14905) = true)

theorem identity14905 : scanCanonicalize (H12AffineFastState.compose env14905 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound14905 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env14906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,5377,292,251,4096,3529,1025,293,4161,1465,16,1298,1385,65,2476,4097,4097,2557,205,1329,257,1328,5457,513]

theorem envBound14906 : H12AffineFastState.Bounded env14906 := by
  intro p hp
  have h : env14906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14905_14906 : H12AffineEnvironment.transform 12 1505 env14905 = env14906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env14905 == env14906) = true)

theorem identity14906 : scanCanonicalize (H12AffineFastState.compose env14906 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound14906 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14907 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,120,4248,292,251,4096,2128,408,293,4161,32,16,139,240,65,2476,4097,4097,2557,205,168,257,169,4296,513]

theorem envBound14907 : H12AffineFastState.Bounded env14907 := by
  intro p hp
  have h : env14907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14906_14907 : H12AffineEnvironment.transform 9 409 env14906 = env14907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env14906 == env14907) = true)

theorem identity14907 : scanCanonicalize (H12AffineFastState.compose env14907 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14907 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14908 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,120,4112,292,115,4096,2128,272,293,4161,32,16,3,120,65,2340,4097,4097,2421,69,32,257,33,4160,513]

theorem envBound14908 : H12AffineFastState.Bounded env14908 := by
  intro p hp
  have h : env14908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14907_14908 : H12AffineEnvironment.transform 6 8 env14907 = env14908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14907 == env14908) = true)

theorem identity14908 : scanCanonicalize (H12AffineFastState.compose env14908 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound14908 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14909 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,309,120,293,292,115,309,2128,272,293,372,32,16,3,120,65,2340,308,308,2421,69,32,257,33,373,513]

theorem envBound14909 : H12AffineFastState.Bounded env14909 := by
  intro p hp
  have h : env14909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14908_14909 : H12AffineEnvironment.transform 11 309 env14908 = env14909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env14908 == env14909) = true)

theorem identity14909 : scanCanonicalize (H12AffineFastState.compose env14909 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound14909 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14910 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,64,120,80,81,115,64,2128,101,80,1,32,16,3,120,65,2129,65,65,2048,69,32,116,33,0,513]

theorem envBound14910 : H12AffineFastState.Bounded env14910 := by
  intro p hp
  have h : env14910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14909_14910 : H12AffineEnvironment.transform 7 117 env14909 = env14910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env14909 == env14910) = true)

theorem identity14910 : scanCanonicalize (H12AffineFastState.compose env14910 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound14910 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14911 : List Nat := [2,4,8,16,32,64,8,117,512,100,576,64,120,80,81,115,64,528,101,80,1,32,16,3,120,65,529,65,65,576,69,32,116,33,0,513]

theorem envBound14911 : H12AffineFastState.Bounded env14911 := by
  intro p hp
  have h : env14911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14910_14911 : H12AffineEnvironment.transform 10 576 env14910 = env14911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env14910 == env14911) = true)

theorem identity14911 : scanCanonicalize (H12AffineFastState.compose env14911 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14911 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14912 : List Nat := [2,4,8,16,32,16,8,37,512,52,528,16,40,0,1,35,16,528,53,0,1,32,16,3,40,17,529,17,17,528,21,32,36,33,0,513]

theorem envBound14912 : H12AffineFastState.Bounded env14912 := by
  intro p hp
  have h : env14912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14911_14912 : H12AffineEnvironment.transform 5 16 env14911 = env14912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14911 == env14912) = true)

theorem identity14912 : scanCanonicalize (H12AffineFastState.compose env14912 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound14912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14913 : List Nat := [2,4,8,11,32,11,8,37,512,47,523,11,40,0,1,35,11,523,46,0,1,32,11,3,40,10,522,10,10,523,14,32,36,33,0,513]

theorem envBound14913 : H12AffineFastState.Bounded env14913 := by
  intro p hp
  have h : env14913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14912_14913 : H12AffineEnvironment.transform 3 11 env14912 = env14913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env14912 == env14913) = true)

def env14914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115871,4194304,17,95497,8328,65,4365616,79131,102879,190520,61704,4314198,257,95530,103567,120542]

theorem envBound14914 : H12AffineFastState.Bounded env14914 := by
  intro p hp
  have h : env14914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14899_14914 : H12AffineEnvironment.transform 22 17 env14899 = env14914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14899 == env14914) = true)

theorem identity14914 : scanCanonicalize (H12AffineFastState.compose env14914 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound14914 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10280,1025,29908,77898,4194304,17,95497,8328,65,4352485,79131,91402,138477,1501,4268163,257,95530,90202,74251]

theorem envBound14915 : H12AffineFastState.Bounded env14915 := by
  intro p hp
  have h : env14915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14914_14915 : H12AffineEnvironment.transform 14 29909 env14914 = env14915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14914 == env14915) = true)

theorem identity14915 : scanCanonicalize (H12AffineFastState.compose env14915 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14915 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env14916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,10280,1025,29908,77898,4194304,17,95497,8328,65,4262398,79131,91402,97526,1501,4268163,257,95530,90202,74251]

theorem envBound14916 : H12AffineFastState.Bounded env14916 := by
  intro p hp
  have h : env14916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14915_14916 : H12AffineEnvironment.transform 16 90139 env14915 = env14916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14915 == env14916) = true)

theorem identity14916 : scanCanonicalize (H12AffineFastState.compose env14916 (packedSelected [0,1,3,5,8,9,10,11,14,18,19,22,23,27,32,35] rootPS)) = affineNative (2^(21+1) ^^^ 95530) := by decide +kernel

theorem selectedBound14916 : packedSelected [0,1,3,5,8,9,10,11,14,18,19,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env14917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,10280,1025,29908,77898,95530,17,95497,8328,65,31956,79131,91402,97526,1501,21929,257,95530,90202,74251]

theorem envBound14917 : H12AffineFastState.Bounded env14917 := by
  intro p hp
  have h : env14917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14916_14917 : H12AffineEnvironment.transform 21 95530 env14916 = env14917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95530 env14916 == env14917) = true)

theorem identity14917 : scanCanonicalize (H12AffineFastState.compose env14917 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound14917 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env14918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,16384,20497,65536,83167,3308,1025,20496,70798,86510,17,86477,1100,65,22544,70111,82382,88114,1501,21929,257,86510,83102,67279]

theorem envBound14918 : H12AffineFastState.Bounded env14918 := by
  intro p hp
  have h : env14918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14917_14918 : H12AffineEnvironment.transform 12 1220 env14917 = env14918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env14917 == env14918) = true)

theorem identity14918 : scanCanonicalize (H12AffineFastState.compose env14918 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 1230) := by decide +kernel

theorem selectedBound14918 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env14919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1220,16384,20497,1230,16401,3308,1025,20496,4160,21792,17,21763,1100,65,22544,5393,17664,23804,1501,21929,257,21792,16464,513]

theorem envBound14919 : H12AffineFastState.Bounded env14919 := by
  intro p hp
  have h : env14919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14918_14919 : H12AffineEnvironment.transform 15 1230 env14918 = env14919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1230 env14918 == env14919) = true)

theorem identity14919 : scanCanonicalize (H12AffineFastState.compose env14919 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound14919 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14920 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,348,16384,20497,342,16401,2420,409,20496,4160,20664,17,20635,468,65,22544,4233,16536,22884,69,20529,257,20664,16464,513]

theorem envBound14920 : H12AffineFastState.Bounded env14920 := by
  intro p hp
  have h : env14920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14919_14920 : H12AffineEnvironment.transform 9 408 env14919 = env14920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env14919 == env14920) = true)

theorem identity14920 : scanCanonicalize (H12AffineFastState.compose env14920 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound14920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14921 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,348,16384,20497,342,16401,2420,321,20496,4160,20576,17,20547,268,65,22544,4177,16448,22884,69,20529,257,20576,16464,513]

theorem envBound14921 : H12AffineFastState.Bounded env14921 := by
  intro p hp
  have h : env14921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14920_14921 : H12AffineEnvironment.transform 6 88 env14920 = env14921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env14920 == env14921) = true)

theorem identity14921 : scanCanonicalize (H12AffineFastState.compose env14921 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound14921 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14922 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,348,4112,1,342,4097,2420,321,0,4160,112,17,83,268,65,2048,4177,4176,2420,69,33,257,112,4160,513]

theorem envBound14922 : H12AffineFastState.Bounded env14922 := by
  intro p hp
  have h : env14922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14921_14922 : H12AffineEnvironment.transform 13 4112 env14921 = env14922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env14921 == env14922) = true)

theorem identity14922 : scanCanonicalize (H12AffineFastState.compose env14922 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound14922 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14923 : List Nat := [2,4,8,16,32,48,40,256,512,304,2048,4096,300,4112,1,294,4097,2308,305,0,4144,0,17,35,268,49,2048,4129,4128,2308,53,33,257,0,4144,513]

theorem envBound14923 : H12AffineFastState.Bounded env14923 := by
  intro p hp
  have h : env14923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14922_14923 : H12AffineEnvironment.transform 5 48 env14922 = env14923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env14922 == env14923) = true)

theorem identity14923 : scanCanonicalize (H12AffineFastState.compose env14923 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14923 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14924 : List Nat := [2,4,8,16,32,48,40,4,512,52,2048,4096,40,4112,1,34,4097,2048,53,0,4144,0,17,35,8,49,2048,4129,4128,2048,53,33,5,0,4144,513]

theorem envBound14924 : H12AffineFastState.Bounded env14924 := by
  intro p hp
  have h : env14924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14923_14924 : H12AffineEnvironment.transform 7 4 env14923 = env14924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14923 == env14924) = true)

def env14925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,8388608,95496,8328,65,12754209,79131,8491471,8579112,8450328,4314198,257,8484155,8492190,8509134]

theorem envBound14925 : H12AffineFastState.Bounded env14925 := by
  intro p hp
  have h : env14925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14898_14925 : H12AffineEnvironment.transform 17 10281 env14898 = env14925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14898 == env14925) = true)

def env14926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,16,95496,8328,65,4365617,79131,102879,190520,61704,4314198,257,95531,103566,120542]

theorem envBound14926 : H12AffineFastState.Bounded env14926 := by
  intro p hp
  have h : env14926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14925_14926 : H12AffineEnvironment.transform 22 16 env14925 = env14926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env14925 == env14926) = true)

theorem identity14926 : scanCanonicalize (H12AffineFastState.compose env14926 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound14926 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,169,16,95496,8328,65,171416,79131,102879,190520,61704,120063,257,95531,103566,120542]

theorem envBound14927 : H12AffineFastState.Bounded env14927 := by
  intro p hp
  have h : env14927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14926_14927 : H12AffineEnvironment.transform 21 169 env14926 = env14927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env14926 == env14927) = true)

theorem identity14927 : scanCanonicalize (H12AffineFastState.compose env14927 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound14927 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env14928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,46276,10281,1025,32769,115870,169,16,95496,8328,65,10588,79131,102879,23804,61704,120063,257,95531,103566,120542]

theorem envBound14928 : H12AffineFastState.Bounded env14928 := by
  intro p hp
  have h : env14928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14927_14928 : H12AffineEnvironment.transform 16 46276 env14927 = env14928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env14927 == env14928) = true)

theorem identity14928 : scanCanonicalize (H12AffineFastState.compose env14928 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound14928 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,46276,10281,1025,32769,17864,169,16,62558,8328,65,10588,46157,4233,23804,61704,21929,257,62589,5592,22408]

theorem envBound14929 : H12AffineFastState.Bounded env14929 := by
  intro p hp
  have h : env14929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14928_14929 : H12AffineEnvironment.transform 15 33110 env14928 = env14929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env14928 == env14929) = true)

theorem identity14929 : scanCanonicalize (H12AffineFastState.compose env14929 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound14929 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33110,46276,10281,1025,32769,4161,169,16,41431,8328,65,10588,46157,4233,2421,42113,32,257,41460,5592,513]

theorem envBound14930 : H12AffineFastState.Bounded env14930 := by
  intro p hp
  have h : env14930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14929_14930 : H12AffineEnvironment.transform 13 5513 env14929 = env14930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env14929 == env14930) = true)

theorem identity14930 : scanCanonicalize (H12AffineFastState.compose env14930 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound14930 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env14931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,81,263,13461,10281,1025,80,4161,169,16,8582,8328,65,10588,13340,4233,2421,9424,32,257,8613,5592,513]

theorem envBound14931 : H12AffineFastState.Bounded env14931 := by
  intro p hp
  have h : env14931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14930_14931 : H12AffineEnvironment.transform 14 81 env14930 = env14931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env14930 == env14931) = true)

theorem identity14931 : scanCanonicalize (H12AffineFastState.compose env14931 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound14931 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env14932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,81,263,5441,2557,1025,80,4161,169,16,82,348,65,2184,5576,4233,2421,1284,32,257,113,5592,513]

theorem envBound14932 : H12AffineFastState.Bounded env14932 := by
  intro p hp
  have h : env14932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14931_14932 : H12AffineEnvironment.transform 12 468 env14931 = env14932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env14931 == env14932) = true)

theorem identity14932 : scanCanonicalize (H12AffineFastState.compose env14932 (packedSelected [0,4,5,8,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound14932 : packedSelected [0,4,5,8,11,15] rootPS < 2^1333 := by decide +kernel

def env14933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2493,468,3124,81,263,3324,2557,1025,80,2556,169,16,82,348,65,2184,3189,2356,2421,1284,32,257,113,3173,513]

theorem envBound14933 : H12AffineFastState.Bounded env14933 := by
  intro p hp
  have h : env14933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14932_14933 : H12AffineEnvironment.transform 11 2493 env14932 = env14933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env14932 == env14933) = true)

theorem identity14933 : scanCanonicalize (H12AffineFastState.compose env14933 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound14933 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env14934 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2405,268,3124,81,263,3108,2341,1025,80,2340,113,16,82,348,65,2128,3189,2356,2421,1284,32,257,113,3173,513]

theorem envBound14934 : H12AffineFastState.Bounded env14934 := by
  intro p hp
  have h : env14934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14933_14934 : H12AffineEnvironment.transform 6 88 env14933 = env14934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env14933 == env14934) = true)

theorem identity14934 : scanCanonicalize (H12AffineFastState.compose env14934 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14934 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env14935 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1,356,268,1077,81,263,1061,292,1025,80,293,113,16,82,348,65,81,1140,309,372,1284,32,257,113,1124,513]

theorem envBound14935 : H12AffineFastState.Bounded env14935 := by
  intro p hp
  have h : env14935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14934_14935 : H12AffineEnvironment.transform 10 1 env14934 = env14935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14934 == env14935) = true)

def env14936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115870,4194304,17,95496,8328,65,4365616,79131,102878,190521,61705,4314198,257,95530,103567,120543]

theorem envBound14936 : H12AffineFastState.Bounded env14936 := by
  intro p hp
  have h : env14936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14925_14936 : H12AffineEnvironment.transform 22 17 env14925 = env14936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14925 == env14936) = true)

def env14937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,4194304,17,95496,8192,65,4365616,79131,102742,190521,61705,4314198,257,95530,103431,120407]

theorem envBound14937 : H12AffineFastState.Bounded env14937 := by
  intro p hp
  have h : env14937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14936_14937 : H12AffineEnvironment.transform 6 8 env14936 = env14937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14936 == env14937) = true)

theorem identity14937 : scanCanonicalize (H12AffineFastState.compose env14937 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound14937 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10281,1025,32769,45340,4194304,17,2,8192,65,4365616,16401,58460,190521,61705,4235612,257,32,57613,41821]

theorem envBound14938 : H12AffineFastState.Bounded env14938 := by
  intro p hp
  have h : env14938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14937_14938 : H12AffineEnvironment.transform 15 29962 env14937 = env14938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env14937 == env14938) = true)

theorem identity14938 : scanCanonicalize (H12AffineFastState.compose env14938 (packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound14938 : packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env14939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,46157,10281,1025,32769,45340,4194304,17,2,8192,65,4204925,16401,58460,23668,61705,4235612,257,32,57613,41821]

theorem envBound14939 : H12AffineFastState.Bounded env14939 := by
  intro p hp
  have h : env14939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14938_14939 : H12AffineEnvironment.transform 16 46157 env14938 = env14939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env14938 == env14939) = true)

theorem identity14939 : scanCanonicalize (H12AffineFastState.compose env14939 (packedSelected [0,2,4,5,6,9,11,18,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 29820) := by decide +kernel

theorem selectedBound14939 : packedSelected [0,2,4,5,6,9,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env14940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,46157,10281,1025,32769,45340,29820,17,2,8192,65,23809,16401,58460,23668,61705,54560,257,32,57613,41821]

theorem envBound14940 : H12AffineFastState.Bounded env14940 := by
  intro p hp
  have h : env14940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14939_14940 : H12AffineEnvironment.transform 21 29820 env14939 = env14940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29820 env14939 == env14940) = true)

theorem identity14940 : scanCanonicalize (H12AffineFastState.compose env14940 (packedSelected [1,4,8,9,12,14,15,16,18,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound14940 : packedSelected [1,4,8,9,12,14,15,16,18,23,26] rootPS < 2^1333 := by decide +kernel

def env14941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,29962,13672,10281,1025,292,12345,29820,17,2,8192,65,23809,16401,25977,23668,28716,21509,257,32,24616,8824]

theorem envBound14941 : H12AffineFastState.Bounded env14941 := by
  intro p hp
  have h : env14941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14940_14941 : H12AffineEnvironment.transform 14 293 env14940 = env14941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env14940 == env14941) = true)

theorem identity14941 : scanCanonicalize (H12AffineFastState.compose env14941 (packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound14941 : packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env14942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,293,8282,13672,10281,1025,292,12345,8492,17,2,8192,65,2129,5441,12329,2340,9596,341,257,32,13688,8824]

theorem envBound14942 : H12AffineFastState.Bounded env14942 := by
  intro p hp
  have h : env14942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14941_14942 : H12AffineEnvironment.transform 13 5456 env14941 = env14942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env14941 == env14942) = true)

theorem identity14942 : scanCanonicalize (H12AffineFastState.compose env14942 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14942 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env14943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,293,342,5220,2341,1025,292,4405,32,17,2,268,65,2129,5441,4389,2340,1136,341,257,32,5236,884]

theorem envBound14943 : H12AffineFastState.Bounded env14943 := by
  intro p hp
  have h : env14943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14942_14943 : H12AffineEnvironment.transform 12 268 env14942 = env14943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14942 == env14943) = true)

theorem identity14943 : scanCanonicalize (H12AffineFastState.compose env14943 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14943 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14944 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5236,1,114,5220,2049,1025,0,4113,32,17,2,40,65,2129,5221,4097,2048,1136,113,37,32,5236,592]

theorem envBound14944 : H12AffineFastState.Bounded env14944 := by
  intro p hp
  have h : env14944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14943_14944 : H12AffineEnvironment.transform 7 36 env14943 = env14944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14943 == env14944) = true)

theorem identity14944 : scanCanonicalize (H12AffineFastState.compose env14944 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound14944 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env14945 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,40,5124,1,2,5140,2049,1025,0,4113,32,17,2,40,49,2081,5141,4097,2048,1024,1,37,32,5124,544]

theorem envBound14945 : H12AffineFastState.Bounded env14945 := by
  intro p hp
  have h : env14945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14944_14945 : H12AffineEnvironment.transform 5 48 env14944 = env14945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env14944 == env14945) = true)

theorem identity14945 : scanCanonicalize (H12AffineFastState.compose env14945 (packedSelected [2,3,5,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14945 : packedSelected [2,3,5,11,15] rootPS < 2^1333 := by decide +kernel

def env14946 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5124,1,2,5140,2049,1025,0,4113,0,17,2,8,17,2049,5141,4097,2048,1024,1,5,0,5124,512]

theorem envBound14946 : H12AffineFastState.Bounded env14946 := by
  intro p hp
  have h : env14946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14945_14946 : H12AffineEnvironment.transform 4 0 env14945 = env14946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14945 == env14946) = true)

def env14947 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,8,1044,1,2,1028,2049,1025,0,1,0,17,2,8,17,2049,1029,17,2048,1024,1,5,0,1044,512]

theorem envBound14947 : H12AffineFastState.Bounded env14947 := by
  intro p hp
  have h : env14947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14946_14947 : H12AffineEnvironment.transform 11 16 env14946 = env14947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env14946 == env14947) = true)

theorem identity14947 : scanCanonicalize (H12AffineFastState.compose env14947 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound14947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14948 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1044,16,8,1044,1,2,1028,1045,1025,0,1,0,17,2,8,17,1045,1029,17,1044,1024,1,5,0,1044,512]

theorem envBound14948 : H12AffineFastState.Bounded env14948 := by
  intro p hp
  have h : env14948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14947_14948 : H12AffineEnvironment.transform 10 1044 env14947 = env14948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env14947 == env14948) = true)

def env14949 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,8,0,1,2,16,1,21,0,1,0,17,2,8,17,1,17,17,0,20,1,5,0,0,512]

theorem envBound14949 : H12AffineFastState.Bounded env14949 := by
  intro p hp
  have h : env14949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14948_14949 : H12AffineEnvironment.transform 9 20 env14948 = env14949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14948 == env14949) = true)

theorem identity14949 : scanCanonicalize (H12AffineFastState.compose env14949 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound14949 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14950 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,4,8,0,1,2,4,1,1,0,1,0,5,2,8,5,1,5,5,0,0,1,5,0,0,512]

theorem envBound14950 : H12AffineFastState.Bounded env14950 := by
  intro p hp
  have h : env14950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14949_14950 : H12AffineEnvironment.transform 3 4 env14949 = env14950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14949 == env14950) = true)

def leafEnv14950 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,4,8,0,1,2,4,1,1,0,1,0,5,2,1,8,1,5,1,5,5,0,0,1,5,0,5,2,0,512,1,1,0]

def active14950 : List Nat := [0,1,2,8]

def tree14950 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14950 : H12WitnessSearch.Good tree14950 := H12GlobalWitnessIndex.good

theorem leafIdentity14950 : H12AffineFastState.composeSystem env14950 rootObs = leafEnv14950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14950 rootObs == leafEnv14950) = true)

theorem terminalChecked14950 : H12PackedTerminal.terminalCheckFast leafEnv14950 active14950 tree14950 = true := by decide +kernel

def env14951 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,16,8,1,1,2,17,0,20,0,1,0,17,2,8,17,0,16,17,1,21,1,5,0,1,512]

theorem envBound14951 : H12AffineFastState.Bounded env14951 := by
  intro p hp
  have h : env14951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14948_14951 : H12AffineEnvironment.transform 9 21 env14948 = env14951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14948 == env14951) = true)

theorem identity14951 : scanCanonicalize (H12AffineFastState.compose env14951 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound14951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14952 : List Nat := [2,4,8,16,0,16,8,4,30,21,1,16,8,1,1,2,17,0,20,0,1,0,17,2,8,17,0,16,17,1,21,1,5,0,1,30]

theorem envBound14952 : H12AffineFastState.Bounded env14952 := by
  intro p hp
  have h : env14952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14951_14952 : H12AffineEnvironment.transform 8 30 env14951 = env14952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env14951 == env14952) = true)

def leafEnv14952 : List Nat := [2,4,8,16,0,16,8,4,30,21,1,16,8,1,1,2,17,0,20,0,1,0,17,2,20,8,1,17,0,16,17,1,21,1,5,0,5,2,1,30,1,1,0]

def active14952 : List Nat := [0,1,2,3]

def tree14952 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14952 : H12WitnessSearch.Good tree14952 := H12GlobalWitnessIndex.good

theorem leafIdentity14952 : H12AffineFastState.composeSystem env14952 rootObs = leafEnv14952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14952 rootObs == leafEnv14952) = true)

theorem terminalChecked14952 : H12PackedTerminal.terminalCheckFast leafEnv14952 active14952 tree14952 = true := by decide +kernel

def env14953 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,8,1045,1,2,1029,2049,1025,0,0,0,17,2,8,17,2049,1028,16,2048,1024,1,5,0,1045,512]

theorem envBound14953 : H12AffineFastState.Bounded env14953 := by
  intro p hp
  have h : env14953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14946_14953 : H12AffineEnvironment.transform 11 17 env14946 = env14953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14946 == env14953) = true)

theorem identity14953 : scanCanonicalize (H12AffineFastState.compose env14953 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound14953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14954 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,8,1045,1,2,1029,1,1025,0,0,0,17,2,8,17,1,1028,16,0,1024,1,5,0,1045,512]

theorem envBound14954 : H12AffineFastState.Bounded env14954 := by
  intro p hp
  have h : env14954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14953_14954 : H12AffineEnvironment.transform 10 0 env14953 = env14954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14953 == env14954) = true)

def env14955 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,8,1,1,2,17,1,21,0,0,0,17,2,8,17,1,16,16,0,20,1,5,0,1,512]

theorem envBound14955 : H12AffineFastState.Bounded env14955 := by
  intro p hp
  have h : env14955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14954_14955 : H12AffineEnvironment.transform 9 20 env14954 = env14955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14954 == env14955) = true)

theorem identity14955 : scanCanonicalize (H12AffineFastState.compose env14955 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound14955 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14956 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,1,1,2,5,1,1,0,0,0,5,2,8,5,1,4,4,0,0,1,5,0,1,512]

theorem envBound14956 : H12AffineFastState.Bounded env14956 := by
  intro p hp
  have h : env14956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14955_14956 : H12AffineEnvironment.transform 3 4 env14955 = env14956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14955 == env14956) = true)

def leafEnv14956 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,8,1,1,2,5,1,1,0,0,0,5,2,1,8,1,5,1,4,4,0,0,1,5,0,5,2,1,512,1,0,0]

def active14956 : List Nat := [0,1,2,8]

def tree14956 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14956 : H12WitnessSearch.Good tree14956 := H12GlobalWitnessIndex.good

theorem leafIdentity14956 : H12AffineFastState.composeSystem env14956 rootObs = leafEnv14956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14956 rootObs == leafEnv14956) = true)

theorem terminalChecked14956 : H12PackedTerminal.terminalCheckFast leafEnv14956 active14956 tree14956 = true := by decide +kernel

def env14957 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,8,0,1,2,16,1,20,0,0,0,17,2,8,17,1,17,16,0,21,1,5,0,0,512]

theorem envBound14957 : H12AffineFastState.Bounded env14957 := by
  intro p hp
  have h : env14957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14954_14957 : H12AffineEnvironment.transform 9 21 env14954 = env14957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14954 == env14957) = true)

theorem identity14957 : scanCanonicalize (H12AffineFastState.compose env14957 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound14957 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14958 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,17,8,0,1,2,16,1,20,0,0,0,17,2,8,17,1,17,16,0,21,1,5,0,0,31]

theorem envBound14958 : H12AffineFastState.Bounded env14958 := by
  intro p hp
  have h : env14958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14957_14958 : H12AffineEnvironment.transform 8 31 env14957 = env14958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env14957 == env14958) = true)

def leafEnv14958 : List Nat := [2,4,8,16,0,16,8,4,31,21,0,17,8,0,1,2,16,1,20,0,0,0,17,2,20,8,1,17,1,17,16,0,21,1,5,0,5,2,0,31,1,0,0]

def active14958 : List Nat := [0,1,2,3]

def tree14958 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14958 : H12WitnessSearch.Good tree14958 := H12GlobalWitnessIndex.good

theorem leafIdentity14958 : H12AffineFastState.composeSystem env14958 rootObs = leafEnv14958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14958 rootObs == leafEnv14958) = true)

theorem terminalChecked14958 : H12PackedTerminal.terminalCheckFast leafEnv14958 active14958 tree14958 = true := by decide +kernel

def env14959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,4194304,17,95496,8193,65,4365616,79131,102743,190521,61705,4314198,257,95530,103430,120406]

theorem envBound14959 : H12AffineFastState.Bounded env14959 := by
  intro p hp
  have h : env14959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14936_14959 : H12AffineEnvironment.transform 6 9 env14936 = env14959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14936 == env14959) = true)

theorem identity14959 : scanCanonicalize (H12AffineFastState.compose env14959 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound14959 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4160,4194304,17,41311,8193,65,4365616,57676,17664,190521,61705,4194305,257,41341,16465,513]

theorem envBound14960 : H12AffineFastState.Bounded env14960 := by
  intro p hp
  have h : env14960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14959_14960 : H12AffineEnvironment.transform 15 54359 env14959 = env14960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env14959 == env14960) = true)

def env14961 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4112,4194304,17,41231,8193,17,4365616,57628,17664,190521,61705,4194305,257,41261,16385,513]

theorem envBound14961 : H12AffineFastState.Bounded env14961 := by
  intro p hp
  have h : env14961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14960_14961 : H12AffineEnvironment.transform 5 16 env14960 = env14961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14960 == env14961) = true)

theorem identity14961 : scanCanonicalize (H12AffineFastState.compose env14961 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound14961 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env14962 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4112,8493,17,41231,8193,17,179229,57628,17664,190521,61705,8492,257,41261,16385,513]

theorem envBound14962 : H12AffineFastState.Bounded env14962 := by
  intro p hp
  have h : env14962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14961_14962 : H12AffineEnvironment.transform 21 8493 env14961 = env14962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env14961 == env14962) = true)

theorem identity14962 : scanCanonicalize (H12AffineFastState.compose env14962 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound14962 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14963 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,38161,10281,1025,32769,4112,8493,17,41231,8193,17,10508,57628,17664,32040,61705,8492,257,41261,16385,513]

theorem envBound14963 : H12AffineFastState.Bounded env14963 := by
  intro p hp
  have h : env14963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14962_14963 : H12AffineEnvironment.transform 16 38161 env14962 = env14963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env14962 == env14963) = true)

theorem identity14963 : scanCanonicalize (H12AffineFastState.compose env14963 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14963 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14964 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,32768,33030,38161,10281,1025,32769,4112,8493,17,41231,8193,17,10508,46109,4097,10281,41992,8492,257,41261,5376,513]

theorem envBound14964 : H12AffineFastState.Bounded env14964 := by
  intro p hp
  have h : env14964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14963_14964 : H12AffineEnvironment.transform 13 5377 env14963 = env14964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14963 == env14964) = true)

theorem identity14964 : scanCanonicalize (H12AffineFastState.compose env14964 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14964 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14965 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,32768,33030,38161,2340,1025,32769,4112,32,17,32770,268,17,2049,38160,4097,2340,34053,33,257,32800,5376,513]

theorem envBound14965 : H12AffineFastState.Bounded env14965 := by
  intro p hp
  have h : env14965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14964_14965 : H12AffineEnvironment.transform 12 269 env14964 = env14965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14964 == env14965) = true)

theorem identity14965 : scanCanonicalize (H12AffineFastState.compose env14965 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14965 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14966 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1025,1,4112,32,17,2,268,17,2049,5392,4097,2340,1285,33,257,32,5376,513]

theorem envBound14966 : H12AffineFastState.Bounded env14966 := by
  intro p hp
  have h : env14966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14965_14966 : H12AffineEnvironment.transform 14 0 env14965 = env14966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14965 == env14966) = true)

theorem identity14966 : scanCanonicalize (H12AffineFastState.compose env14966 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound14966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14967 : List Nat := [2,4,8,16,32,16,9,52,512,1024,2048,4096,57,5173,0,50,5157,2064,1025,1,4112,32,17,2,56,17,2049,5156,4097,2064,1073,33,53,32,5172,513]

theorem envBound14967 : H12AffineFastState.Bounded env14967 := by
  intro p hp
  have h : env14967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14966_14967 : H12AffineEnvironment.transform 7 52 env14966 = env14967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env14966 == env14967) = true)

theorem identity14967 : scanCanonicalize (H12AffineFastState.compose env14967 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound14967 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14968 : List Nat := [2,4,8,16,32,16,9,52,512,1024,2048,1572,57,529,0,50,513,2064,1025,1,1588,32,17,2,56,17,2049,512,1573,2064,1073,33,53,32,528,513]

theorem envBound14968 : H12AffineFastState.Bounded env14968 := by
  intro p hp
  have h : env14968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14967_14968 : H12AffineEnvironment.transform 11 1572 env14967 = env14968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env14967 == env14968) = true)

theorem identity14968 : scanCanonicalize (H12AffineFastState.compose env14968 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound14968 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14969 : List Nat := [2,4,8,16,32,16,9,52,512,565,2048,17,57,529,0,50,513,2064,564,1,1,32,17,2,56,17,2049,512,16,2064,516,33,53,32,528,513]

theorem envBound14969 : H12AffineFastState.Bounded env14969 := by
  intro p hp
  have h : env14969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14968_14969 : H12AffineEnvironment.transform 9 565 env14968 = env14969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env14968 == env14969) = true)

def env14970 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4113,4194304,17,41230,8193,16,4365616,57629,17664,190521,61705,4194305,257,41260,16384,513]

theorem envBound14970 : H12AffineFastState.Bounded env14970 := by
  intro p hp
  have h : env14970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14960_14970 : H12AffineEnvironment.transform 5 17 env14960 = env14970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14960 == env14970) = true)

theorem identity14970 : scanCanonicalize (H12AffineFastState.compose env14970 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14970 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env14971 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21511,131072,10281,1025,0,4113,4194304,17,8463,8193,16,4332849,24860,17664,157752,28936,4194305,257,8493,16384,513]

theorem envBound14971 : H12AffineFastState.Bounded env14971 := by
  intro p hp
  have h : env14971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14970_14971 : H12AffineEnvironment.transform 14 1 env14970 = env14971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14970 == env14971) = true)

theorem identity14971 : scanCanonicalize (H12AffineFastState.compose env14971 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound14971 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14972 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21511,131072,10281,1025,0,4113,8492,17,8463,8193,16,146461,24860,17664,157752,28936,8493,257,8493,16384,513]

theorem envBound14972 : H12AffineFastState.Bounded env14972 := by
  intro p hp
  have h : env14972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14971_14972 : H12AffineEnvironment.transform 21 8492 env14971 = env14972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env14971 == env14972) = true)

theorem identity14972 : scanCanonicalize (H12AffineFastState.compose env14972 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound14972 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14973 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,21511,16401,10281,1025,0,4113,8492,17,8463,8193,16,31756,24860,17664,10281,28936,8493,257,8493,16384,513]

theorem envBound14973 : H12AffineFastState.Bounded env14973 := by
  intro p hp
  have h : env14973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14972_14973 : H12AffineEnvironment.transform 16 16401 env14972 = env14973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14972 == env14973) = true)

theorem identity14973 : scanCanonicalize (H12AffineFastState.compose env14973 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound14973 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14974 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1,263,5393,10281,1025,0,4113,8492,17,8463,8193,16,10508,13340,4096,10281,9224,8493,257,8493,5376,513]

theorem envBound14974 : H12AffineFastState.Bounded env14974 := by
  intro p hp
  have h : env14974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14973_14974 : H12AffineEnvironment.transform 13 5376 env14973 = env14974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14973 == env14974) = true)

theorem identity14974 : scanCanonicalize (H12AffineFastState.compose env14974 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound14974 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14975 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5376,1,263,5393,2048,1025,0,4113,261,17,294,40,16,2341,5173,4096,2048,1057,260,257,260,5376,513]

theorem envBound14975 : H12AffineFastState.Bounded env14975 := by
  intro p hp
  have h : env14975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14974_14975 : H12AffineEnvironment.transform 12 41 env14974 = env14975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env14974 == env14975) = true)

theorem identity14975 : scanCanonicalize (H12AffineFastState.compose env14975 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound14975 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14976 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3329,41,2049,1,263,2064,2048,1025,0,3344,261,17,294,40,16,2341,2356,3329,2048,1057,260,257,260,2049,513]

theorem envBound14976 : H12AffineFastState.Bounded env14976 := by
  intro p hp
  have h : env14976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14975_14976 : H12AffineEnvironment.transform 11 3329 env14975 = env14976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env14975 == env14976) = true)

theorem identity14976 : scanCanonicalize (H12AffineFastState.compose env14976 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14976 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14977 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,1280,41,0,1,263,17,1,1025,0,1297,261,17,294,40,16,292,309,1280,1,1057,260,257,260,0,513]

theorem envBound14977 : H12AffineFastState.Bounded env14977 := by
  intro p hp
  have h : env14977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14976_14977 : H12AffineEnvironment.transform 10 1 env14976 = env14977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14976 == env14977) = true)

theorem identity14977 : scanCanonicalize (H12AffineFastState.compose env14977 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14977 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14978 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1,1061,41,0,1,34,17,1,1025,0,1076,32,17,3,40,16,1,16,1061,1,1057,33,36,33,0,513]

theorem envBound14978 : H12AffineFastState.Bounded env14978 := by
  intro p hp
  have h : env14978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14977_14978 : H12AffineEnvironment.transform 7 37 env14977 = env14978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14977 == env14978) = true)

theorem identity14978 : scanCanonicalize (H12AffineFastState.compose env14978 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14978 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14979 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,16,41,0,1,34,17,1,52,0,1,32,17,3,40,16,1,16,16,1,20,33,36,33,0,513]

theorem envBound14979 : H12AffineFastState.Bounded env14979 := by
  intro p hp
  have h : env14979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14978_14979 : H12AffineEnvironment.transform 9 53 env14978 = env14979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14978 == env14979) = true)

theorem identity14979 : scanCanonicalize (H12AffineFastState.compose env14979 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound14979 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14980 : List Nat := [2,4,8,16,32,17,9,37,20,53,1,16,41,0,1,34,17,1,52,0,1,32,17,3,40,16,1,16,16,1,20,33,36,33,0,21]

theorem envBound14980 : H12AffineFastState.Bounded env14980 := by
  intro p hp
  have h : env14980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14979_14980 : H12AffineEnvironment.transform 8 20 env14979 = env14980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env14979 == env14980) = true)

theorem identity14980 : scanCanonicalize (H12AffineFastState.compose env14980 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound14980 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14981 : List Nat := [2,4,8,7,32,6,9,37,3,34,1,7,41,0,1,34,6,1,35,0,1,32,6,3,40,7,1,7,7,1,3,33,36,33,0,2]

theorem envBound14981 : H12AffineFastState.Bounded env14981 := by
  intro p hp
  have h : env14981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14980_14981 : H12AffineEnvironment.transform 3 7 env14980 = env14981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env14980 == env14981) = true)

theorem identity14981 : scanCanonicalize (H12AffineFastState.compose env14981 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound14981 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14982 : List Nat := [2,4,0,7,32,6,1,37,3,34,1,7,33,0,1,34,6,1,35,0,1,32,6,3,32,7,1,7,7,1,3,33,36,33,0,2]

theorem envBound14982 : H12AffineFastState.Bounded env14982 := by
  intro p hp
  have h : env14982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14981_14982 : H12AffineEnvironment.transform 2 0 env14981 = env14982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env14981 == env14982) = true)

theorem identity14982 : scanCanonicalize (H12AffineFastState.compose env14982 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14982 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14983 : List Nat := [2,4,0,7,0,6,1,5,3,2,1,7,1,0,1,2,6,1,3,0,1,0,6,3,0,7,1,7,7,1,3,1,4,1,0,2]

theorem envBound14983 : H12AffineFastState.Bounded env14983 := by
  intro p hp
  have h : env14983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14982_14983 : H12AffineEnvironment.transform 4 0 env14982 = env14983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14982 == env14983) = true)

def env14984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374097,4294967296,525568,4308116844,27337993,25733063]

theorem envBound14984 : H12AffineFastState.Bounded env14984 := by
  intro p hp
  have h : env14984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9856_14984 : H12AffineEnvironment.transform 28 77616401 env9856 = env14984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616401 env9856 == env14984) = true)

def env14985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound14985 : H12AffineFastState.Bounded env14985 := by
  intro p hp
  have h : env14985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14984_14985 : H12AffineEnvironment.transform 31 145662400 env14984 = env14985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env14984 == env14985) = true)

def env14986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254784,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound14986 : H12AffineFastState.Bounded env14986 := by
  intro p hp
  have h : env14986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14985_14986 : H12AffineEnvironment.transform 29 155254784 env14985 = env14986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env14985 == env14986) = true)

def env14987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254784,25265169,145662400,525568,140903596,27337993,25733063]

theorem envBound14987 : H12AffineFastState.Bounded env14987 := by
  intro p hp
  have h : env14987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14986_14987 : H12AffineEnvironment.transform 25 64 env14986 = env14987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env14986 == env14987) = true)

def env14988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356288,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound14988 : H12AffineFastState.Bounded env14988 := by
  intro p hp
  have h : env14988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14987_14988 : H12AffineEnvironment.transform 26 30393344 env14987 = env14988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env14987 == env14988) = true)

def env14989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound14989 : H12AffineFastState.Bounded env14989 := by
  intro p hp
  have h : env14989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14988_14989 : H12AffineEnvironment.transform 18 1024 env14988 = env14989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14988 == env14989) = true)

theorem identity14989 : scanCanonicalize (H12AffineFastState.compose env14989 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound14989 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2,8328,64,13090818,2196622,10507601,8830976,8487955,6383042,256,10601646,10560779,8430533]

theorem envBound14990 : H12AffineFastState.Bounded env14990 := by
  intro p hp
  have h : env14990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14989_14990 : H12AffineEnvironment.transform 23 2 env14989 = env14990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env14989 == env14990) = true)

def env14991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,2,8328,64,4554890,2196622,2233817,295048,246939,6383042,256,2327590,2319747,189261]

theorem envBound14991 : H12AffineFastState.Bounded env14991 := by
  intro p hp
  have h : env14991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14990_14991 : H12AffineEnvironment.transform 22 147592 env14990 = env14991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env14990 == env14991) = true)

def env14992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147592,2,8328,64,4450362,2196622,2233817,190520,246939,6383042,256,2327590,2319747,189261]

theorem envBound14992 : H12AffineFastState.Bounded env14992 := by
  intro p hp
  have h : env14992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14991_14992 : H12AffineEnvironment.transform 17 157872 env14991 = env14992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env14991 == env14992) = true)

theorem identity14992 : scanCanonicalize (H12AffineFastState.compose env14992 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound14992 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env14993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1024,32769,2097152,4194304,152,2,8328,64,4302890,2196622,2119113,43048,99467,6383042,256,2212918,2172307,41821]

theorem envBound14993 : H12AffineFastState.Bounded env14993 := by
  intro p hp
  have h : env14993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14992_14993 : H12AffineEnvironment.transform 16 16400 env14992 = env14993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14992 == env14993) = true)

def env14994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,2097152,4194304,16,2,8192,64,4302890,2196486,2118977,43048,99331,6382922,256,2212918,2172187,41821]

theorem envBound14994 : H12AffineFastState.Bounded env14994 := by
  intro p hp
  have h : env14994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14993_14994 : H12AffineEnvironment.transform 6 8 env14993 = env14994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14993 == env14994) = true)

theorem identity14994 : scanCanonicalize (H12AffineFastState.compose env14994 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14994 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,2097152,4194304,16,2,8192,64,4262262,2172250,2118977,2420,75103,6382922,256,2188650,2172187,513]

theorem envBound14995 : H12AffineFastState.Bounded env14995 := by
  intro p hp
  have h : env14995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14994_14995 : H12AffineEnvironment.transform 14 8540 env14994 = env14995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14994 == env14995) = true)

theorem identity14995 : scanCanonicalize (H12AffineFastState.compose env14995 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound14995 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1024,8541,91466,4194304,16,2,8192,64,4262262,16400,77835,2420,75103,4194304,256,32,16465,513]

theorem envBound14996 : H12AffineFastState.Bounded env14996 := by
  intro p hp
  have h : env14996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14995_14996 : H12AffineEnvironment.transform 20 91466 env14995 = env14996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env14995 == env14996) = true)

theorem identity14996 : scanCanonicalize (H12AffineFastState.compose env14996 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14996 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,65536,16400,2421,1024,0,82967,4194304,16,2,349,64,4262262,16400,69974,2420,66562,4194304,256,32,16465,513]

theorem envBound14997 : H12AffineFastState.Bounded env14997 := by
  intro p hp
  have h : env14997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14996_14997 : H12AffineEnvironment.transform 12 349 env14996 = env14997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14996 == env14997) = true)

theorem identity14997 : scanCanonicalize (H12AffineFastState.compose env14997 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound14997 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,342,16400,2421,1024,0,17729,4194304,16,2,349,64,4196384,16400,4096,2420,1364,4194304,256,32,16465,513]

theorem envBound14998 : H12AffineFastState.Bounded env14998 := by
  intro p hp
  have h : env14998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14997_14998 : H12AffineEnvironment.transform 15 342 env14997 = env14998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env14997 == env14998) = true)

theorem identity14998 : scanCanonicalize (H12AffineFastState.compose env14998 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14998 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14999 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,262,16400,2341,1024,0,17681,4194304,16,2,269,16,4196384,16400,4096,2340,1284,4194304,256,32,16385,513]

theorem envBound14999 : H12AffineFastState.Bounded env14999 := by
  intro p hp
  have h : env14999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14998_14999 : H12AffineEnvironment.transform 5 16 env14998 = env14999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14998 == env14999) = true)

theorem identity14999 : scanCanonicalize (H12AffineFastState.compose env14999 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound14999 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15000 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,1,262,5173,2341,1024,0,4404,4194304,16,2,269,16,4196384,5173,4096,2340,1284,4194304,256,32,5156,513]

theorem envBound15000 : H12AffineFastState.Bounded env15000 := by
  intro p hp
  have h : env15000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14999_15000 : H12AffineEnvironment.transform 13 5157 env14999 = env15000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env14999 == env15000) = true)

theorem identity15000 : scanCanonicalize (H12AffineFastState.compose env15000 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound15000 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15001 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,1,262,5173,2341,1024,0,4404,32,16,2,269,16,2048,5173,4096,2340,1284,32,256,32,5156,513]

theorem envBound15001 : H12AffineFastState.Bounded env15001 := by
  intro p hp
  have h : env15001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15000_15001 : H12AffineEnvironment.transform 21 32 env15000 = env15001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15000 == env15001) = true)

theorem identity15001 : scanCanonicalize (H12AffineFastState.compose env15001 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15002 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5125,1,262,5141,2309,1024,0,4372,0,16,2,269,16,2048,5141,4096,2308,1284,0,256,0,5124,513]

theorem envBound15002 : H12AffineFastState.Bounded env15002 := by
  intro p hp
  have h : env15002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15001_15002 : H12AffineEnvironment.transform 4 0 env15001 = env15002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15001 == env15002) = true)

theorem identity15002 : scanCanonicalize (H12AffineFastState.compose env15002 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound15002 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15003 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,1281,269,260,1,262,276,2309,1024,0,1045,0,16,2,269,16,2048,276,1281,2308,1284,0,256,0,261,513]

theorem envBound15003 : H12AffineFastState.Bounded env15003 := by
  intro p hp
  have h : env15003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15002_15003 : H12AffineEnvironment.transform 11 1281 env15002 = env15003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env15002 == env15003) = true)

theorem identity15003 : scanCanonicalize (H12AffineFastState.compose env15003 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound15003 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15004 : List Nat := [2,4,8,16,0,16,8,256,512,1024,1556,1281,269,260,1,262,276,1809,1024,0,1045,0,16,2,269,16,1556,276,1281,1808,1284,0,256,0,261,513]

theorem envBound15004 : H12AffineFastState.Bounded env15004 := by
  intro p hp
  have h : env15004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15003_15004 : H12AffineEnvironment.transform 10 1556 env15003 = env15004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env15003 == env15004) = true)

theorem identity15004 : scanCanonicalize (H12AffineFastState.compose env15004 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound15004 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15005 : List Nat := [2,4,8,16,0,16,8,256,512,769,277,512,269,260,1,262,276,16,769,0,788,0,16,2,269,16,277,276,512,17,517,0,256,0,261,513]

theorem envBound15005 : H12AffineFastState.Bounded env15005 := by
  intro p hp
  have h : env15005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15004_15005 : H12AffineEnvironment.transform 9 769 env15004 = env15005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env15004 == env15005) = true)

theorem identity15005 : scanCanonicalize (H12AffineFastState.compose env15005 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound15005 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15006 : List Nat := [2,4,8,16,0,16,8,256,260,5,277,260,269,260,1,262,276,16,5,0,16,0,16,2,269,16,277,276,260,17,257,0,256,0,261,261]

theorem envBound15006 : H12AffineFastState.Bounded env15006 := by
  intro p hp
  have h : env15006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15005_15006 : H12AffineEnvironment.transform 8 260 env15005 = env15006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env15005 == env15006) = true)

theorem identity15006 : scanCanonicalize (H12AffineFastState.compose env15006 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15006 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15007 : List Nat := [2,4,8,0,0,0,8,256,260,5,261,260,269,260,1,262,260,0,5,0,0,0,0,2,269,0,261,260,260,1,257,0,256,0,261,261]

theorem envBound15007 : H12AffineFastState.Bounded env15007 := by
  intro p hp
  have h : env15007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15006_15007 : H12AffineEnvironment.transform 3 0 env15006 = env15007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15006 == env15007) = true)

def env15008 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,2097152,4194304,17,2,8193,64,4302890,2196487,2118976,43048,99330,6382923,256,2212918,2172186,41821]

theorem envBound15008 : H12AffineFastState.Bounded env15008 := by
  intro p hp
  have h : env15008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14993_15008 : H12AffineEnvironment.transform 6 9 env14993 = env15008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14993 == env15008) = true)

theorem identity15008 : scanCanonicalize (H12AffineFastState.compose env15008 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15008 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env15009 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1024,32769,2097152,4194304,17,2,8193,64,4229153,2139148,2118976,43048,41993,6309184,256,2155581,2098449,41821]

theorem envBound15009 : H12AffineFastState.Bounded env15009 := by
  intro p hp
  have h : env15009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15008_15009 : H12AffineEnvironment.transform 15 8203 env15008 = env15009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15008 == env15009) = true)

theorem identity15009 : scanCanonicalize (H12AffineFastState.compose env15009 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound15009 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env15010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1024,32769,17681,4194304,17,2,8193,64,4229153,57629,4177,43048,41993,4194385,256,41260,16384,41821]

theorem envBound15010 : H12AffineFastState.Bounded env15010 := by
  intro p hp
  have h : env15010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15009_15010 : H12AffineEnvironment.transform 20 17681 env15009 = env15010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env15009 == env15010) = true)

theorem identity15010 : scanCanonicalize (H12AffineFastState.compose env15010 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 62729) := by decide +kernel

theorem selectedBound15010 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env15011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1024,32769,17681,62729,17,2,8193,64,32040,57629,4177,43048,41993,62808,256,41260,16384,41821]

theorem envBound15011 : H12AffineFastState.Bounded env15011 := by
  intro p hp
  have h : env15011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15010_15011 : H12AffineEnvironment.transform 21 62729 env15010 = env15011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62729 env15010 == env15011) = true)

theorem identity15011 : scanCanonicalize (H12AffineFastState.compose env15011 (packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15011 : packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env15012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,16400,10281,1024,0,17681,29960,17,2,8193,64,32040,24860,4177,10281,9224,30041,256,8493,16384,9052]

theorem envBound15012 : H12AffineFastState.Bounded env15012 := by
  intro p hp
  have h : env15012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15011_15012 : H12AffineEnvironment.transform 14 1 env15011 = env15012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15011 == env15012) = true)

theorem identity15012 : scanCanonicalize (H12AffineFastState.compose env15012 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound15012 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env15013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,16384,1,1378,16400,3392,1024,0,17681,20577,17,2,1384,64,22593,17525,4177,3392,353,20528,256,1092,16384,1589]

theorem envBound15013 : H12AffineFastState.Bounded env15013 := by
  intro p hp
  have h : env15013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15012_15013 : H12AffineEnvironment.transform 12 1385 env15012 = env15013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env15012 == env15013) = true)

theorem identity15013 : scanCanonicalize (H12AffineFastState.compose env15013 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound15013 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env15014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,4112,1,1378,4096,3392,1024,0,5377,113,17,2,1384,64,2129,5221,4177,3392,353,32,256,1092,4112,1589]

theorem envBound15014 : H12AffineFastState.Bounded env15014 := by
  intro p hp
  have h : env15014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15013_15014 : H12AffineEnvironment.transform 13 4112 env15013 = env15014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env15013 == env15014) = true)

theorem identity15014 : scanCanonicalize (H12AffineFastState.compose env15014 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15014 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env15015 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4112,1,343,4096,2421,53,0,4404,113,17,2,349,64,2129,4176,4177,2421,353,32,256,113,4112,512]

theorem envBound15015 : H12AffineFastState.Bounded env15015 := by
  intro p hp
  have h : env15015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15014_15015 : H12AffineEnvironment.transform 9 53 env15014 = env15015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15014 == env15015) = true)

theorem identity15015 : scanCanonicalize (H12AffineFastState.compose env15015 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15015 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15016 : List Nat := [2,4,8,16,0,64,9,256,512,21,2048,4096,348,4112,1,343,4096,2389,21,0,4372,81,17,2,349,64,2129,4176,4177,2389,321,0,256,81,4112,512]

theorem envBound15016 : H12AffineFastState.Bounded env15016 := by
  intro p hp
  have h : env15016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15015_15016 : H12AffineEnvironment.transform 4 0 env15015 = env15016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15015 == env15016) = true)

theorem identity15016 : scanCanonicalize (H12AffineFastState.compose env15016 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound15016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15017 : List Nat := [2,4,8,16,0,64,9,84,512,21,2048,4096,8,4112,1,3,4096,2049,21,0,4160,81,17,2,9,64,2129,4176,4177,2049,21,0,84,81,4112,512]

theorem envBound15017 : H12AffineFastState.Bounded env15017 := by
  intro p hp
  have h : env15017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15016_15017 : H12AffineEnvironment.transform 7 84 env15016 = env15017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env15016 == env15017) = true)

theorem identity15017 : scanCanonicalize (H12AffineFastState.compose env15017 (packedSelected [3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 533) := by decide +kernel

theorem selectedBound15017 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env15018 : List Nat := [2,4,8,16,0,64,9,84,512,21,2048,533,8,517,1,3,533,2049,21,0,597,81,17,2,9,64,2129,581,580,2049,21,0,84,81,517,512]

theorem envBound15018 : H12AffineFastState.Bounded env15018 := by
  intro p hp
  have h : env15018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15017_15018 : H12AffineEnvironment.transform 11 533 env15017 = env15018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 533 env15017 == env15018) = true)

theorem identity15018 : scanCanonicalize (H12AffineFastState.compose env15018 (packedSelected [1,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 67) := by decide +kernel

theorem selectedBound15018 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env15019 : List Nat := [2,4,8,16,0,64,9,84,67,21,2048,86,8,70,1,3,86,2049,21,0,22,81,17,2,9,64,2129,6,7,2049,21,0,84,81,70,67]

theorem envBound15019 : H12AffineFastState.Bounded env15019 := by
  intro p hp
  have h : env15019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15018_15019 : H12AffineEnvironment.transform 8 67 env15018 = env15019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 67 env15018 == env15019) = true)

theorem identity15019 : scanCanonicalize (H12AffineFastState.compose env15019 (packedSelected [3,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 72) := by decide +kernel

theorem selectedBound15019 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env15020 : List Nat := [2,4,8,16,0,64,9,84,67,21,72,86,8,70,1,3,86,73,21,0,22,81,17,2,9,64,25,6,7,73,21,0,84,81,70,67]

theorem envBound15020 : H12AffineFastState.Bounded env15020 := by
  intro p hp
  have h : env15020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15019_15020 : H12AffineEnvironment.transform 10 72 env15019 = env15020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 72 env15019 == env15020) = true)

theorem identity15020 : scanCanonicalize (H12AffineFastState.compose env15020 (packedSelected [0,1,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15020 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env15021 : List Nat := [2,4,8,16,0,17,9,5,18,21,25,7,8,23,1,3,7,24,21,0,22,0,17,2,9,17,25,6,7,24,21,0,5,0,23,18]

theorem envBound15021 : H12AffineFastState.Bounded env15021 := by
  intro p hp
  have h : env15021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15020_15021 : H12AffineEnvironment.transform 5 17 env15020 = env15021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15020 == env15021) = true)

theorem identity15021 : scanCanonicalize (H12AffineFastState.compose env15021 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound15021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15022 : List Nat := [2,4,8,5,0,4,9,5,7,0,12,7,8,2,1,3,7,13,0,0,3,0,4,2,9,4,12,6,7,13,0,0,5,0,2,7]

theorem envBound15022 : H12AffineFastState.Bounded env15022 := by
  intro p hp
  have h : env15022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15021_15022 : H12AffineEnvironment.transform 3 5 env15021 = env15022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env15021 == env15022) = true)

theorem identity15022 : scanCanonicalize (H12AffineFastState.compose env15022 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound15022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15023 : List Nat := [2,4,1,5,0,4,0,5,7,0,5,7,1,2,1,3,7,4,0,0,3,0,4,2,0,4,5,6,7,4,0,0,5,0,2,7]

theorem envBound15023 : H12AffineFastState.Bounded env15023 := by
  intro p hp
  have h : env15023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15022_15023 : H12AffineEnvironment.transform 2 1 env15022 = env15023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env15022 == env15023) = true)

def env15024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147592,2,8328,64,4450363,2196622,2233817,190521,246939,6383042,256,2327590,2319747,189261]

theorem envBound15024 : H12AffineFastState.Bounded env15024 := by
  intro p hp
  have h : env15024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14991_15024 : H12AffineEnvironment.transform 17 157873 env14991 = env15024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env14991 == env15024) = true)

theorem identity15024 : scanCanonicalize (H12AffineFastState.compose env15024 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15024 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env15025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,64,4450363,2196486,2233681,190521,246803,6382922,256,2327590,2319627,189261]

theorem envBound15025 : H12AffineFastState.Bounded env15025 := by
  intro p hp
  have h : env15025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15024_15025 : H12AffineEnvironment.transform 6 8 env15024 = env15025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15024 == env15025) = true)

theorem identity15025 : scanCanonicalize (H12AffineFastState.compose env15025 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound15025 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35189,1024,32769,2097152,4194304,41292,2,8192,64,4262263,2196486,2159645,2421,75103,6382922,256,2188650,2196551,513]

theorem envBound15026 : H12AffineFastState.Bounded env15026 := by
  intro p hp
  have h : env15026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15025_15026 : H12AffineEnvironment.transform 16 57676 env15025 = env15026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env15025 == env15026) = true)

theorem identity15026 : scanCanonicalize (H12AffineFastState.compose env15026 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound15026 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env15027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35189,1024,32769,2097152,4194304,41292,2,8192,64,4229152,2098513,2159645,2421,41992,6349853,256,2155581,2098448,513]

theorem envBound15027 : H12AffineFastState.Bounded env15027 := by
  intro p hp
  have h : env15027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15026_15027 : H12AffineEnvironment.transform 15 33111 env15026 = env15027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env15026 == env15027) = true)

theorem identity15027 : scanCanonicalize (H12AffineFastState.compose env15027 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound15027 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env15028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35189,1024,32769,2097152,32,41292,2,8192,64,34816,2098513,2159645,2421,41992,2155581,256,2155581,2098448,513]

theorem envBound15028 : H12AffineFastState.Bounded env15028 := by
  intro p hp
  have h : env15028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15027_15028 : H12AffineEnvironment.transform 21 32 env15027 = env15028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15027 == env15028) = true)

theorem identity15028 : scanCanonicalize (H12AffineFastState.compose env15028 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound15028 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,263,24860,2341,1024,81,2097152,32,8476,2,8192,64,2128,2098513,2126925,2421,9304,2122861,256,2122861,2098448,513]

theorem envBound15029 : H12AffineFastState.Bounded env15029 := by
  intro p hp
  have h : env15029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15028_15029 : H12AffineEnvironment.transform 14 80 env15028 = env15029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env15028 == env15029) = true)

theorem identity15029 : scanCanonicalize (H12AffineFastState.compose env15029 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound15029 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env15030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,80,263,13672,2341,1024,81,2097152,32,8476,2,8192,64,2128,2098513,2105401,2421,9304,2109465,256,2109465,2098448,513]

theorem envBound15030 : H12AffineFastState.Bounded env15030 := by
  intro p hp
  have h : env15030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15029_15030 : H12AffineEnvironment.transform 13 5236 env15029 = env15030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env15029 == env15030) = true)

theorem identity15030 : scanCanonicalize (H12AffineFastState.compose env15030 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15030 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env15031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,80,263,5173,2341,1024,81,2097152,32,65,2,349,64,2128,2098513,2097508,2421,1285,2101572,256,2101572,2098448,513]

theorem envBound15031 : H12AffineFastState.Bounded env15031 := by
  intro p hp
  have h : env15031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15030_15031 : H12AffineEnvironment.transform 12 349 env15030 = env15031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15030 == env15031) = true)

theorem identity15031 : scanCanonicalize (H12AffineFastState.compose env15031 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(20+1) ^^^ 4453) := by decide +kernel

theorem selectedBound15031 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env15032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,80,263,5173,2341,1024,81,4453,32,65,2,349,64,2128,5172,4097,2421,1285,33,256,33,5237,513]

theorem envBound15032 : H12AffineFastState.Bounded env15032 := by
  intro p hp
  have h : env15032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15031_15032 : H12AffineEnvironment.transform 20 4453 env15031 = env15032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4453 env15031 == env15032) = true)

theorem identity15032 : scanCanonicalize (H12AffineFastState.compose env15032 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15032 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15033 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4453,80,263,4388,2341,273,81,4453,32,65,2,349,64,2128,4389,4097,2421,20,33,256,33,4452,513]

theorem envBound15033 : H12AffineFastState.Bounded env15033 := by
  intro p hp
  have h : env15033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15032_15033 : H12AffineEnvironment.transform 9 273 env15032 = env15033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15032 == env15033) = true)

def env15034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,2,8328,64,4554891,2196622,2233816,295049,246938,6383042,256,2327591,2319746,189260]

theorem envBound15034 : H12AffineFastState.Bounded env15034 := by
  intro p hp
  have h : env15034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14990_15034 : H12AffineEnvironment.transform 22 147593 env14990 = env15034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env14990 == env15034) = true)

def env15035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147593,2,8328,64,4450363,2196622,2233816,190521,246938,6383042,256,2327591,2319746,189260]

theorem envBound15035 : H12AffineFastState.Bounded env15035 := by
  intro p hp
  have h : env15035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15034_15035 : H12AffineEnvironment.transform 17 157872 env15034 = env15035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env15034 == env15035) = true)

theorem identity15035 : scanCanonicalize (H12AffineFastState.compose env15035 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57797) := by decide +kernel

theorem selectedBound15035 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env15036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57797,35189,1024,32769,2097152,4194304,41292,2,8328,64,4262398,2196622,2159645,2556,75103,6383042,256,2188770,2196551,649]

theorem envBound15036 : H12AffineFastState.Bounded env15036 := by
  intro p hp
  have h : env15036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15035_15036 : H12AffineEnvironment.transform 16 57797 env15035 = env15036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57797 env15035 == env15036) = true)

theorem identity15036 : scanCanonicalize (H12AffineFastState.compose env15036 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15036 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35189,1024,32769,2097152,4194304,41292,2,8192,64,4262262,2196486,2159645,2420,75103,6382922,256,2188650,2196551,513]

theorem envBound15037 : H12AffineFastState.Bounded env15037 := by
  intro p hp
  have h : env15037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15036_15037 : H12AffineEnvironment.transform 6 8 env15036 = env15037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15036 == env15037) = true)

theorem identity15037 : scanCanonicalize (H12AffineFastState.compose env15037 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound15037 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env15038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1024,32769,2097152,4194304,41292,2,8192,64,4229152,2098512,2159645,2420,41993,6349852,256,2155580,2098449,513]

theorem envBound15038 : H12AffineFastState.Bounded env15038 := by
  intro p hp
  have h : env15038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15037_15038 : H12AffineEnvironment.transform 15 33110 env15037 = env15038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env15037 == env15038) = true)

theorem identity15038 : scanCanonicalize (H12AffineFastState.compose env15038 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 2155581) := by decide +kernel

theorem selectedBound15038 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env15039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1024,32769,2097152,2155581,41292,2,8192,64,2124829,2098512,2159645,2420,41993,33,256,2155580,2098449,513]

theorem envBound15039 : H12AffineFastState.Bounded env15039 := by
  intro p hp
  have h : env15039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15038_15039 : H12AffineEnvironment.transform 21 2155581 env15038 = env15039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env15038 == env15039) = true)

theorem identity15039 : scanCanonicalize (H12AffineFastState.compose env15039 (packedSelected [0,1,3,14,15,17,24,27,28,38] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound15039 : packedSelected [0,1,3,14,15,17,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env15040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1024,32769,17681,41260,41292,2,8192,64,10508,16449,45324,2420,41993,33,256,41261,16384,513]

theorem envBound15040 : H12AffineFastState.Bounded env15040 := by
  intro p hp
  have h : env15040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15039_15040 : H12AffineEnvironment.transform 20 17681 env15039 = env15040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env15039 == env15040) = true)

theorem identity15040 : scanCanonicalize (H12AffineFastState.compose env15040 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15040 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env15041 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33031,57628,35108,1024,32769,17681,41260,41245,2,8192,17,10508,16400,45324,2341,41993,33,256,41261,16384,513]

theorem envBound15041 : H12AffineFastState.Bounded env15041 := by
  intro p hp
  have h : env15041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15040_15041 : H12AffineEnvironment.transform 5 17 env15040 = env15041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15040 == env15041) = true)

theorem identity15041 : scanCanonicalize (H12AffineFastState.compose env15041 (packedSelected [3,4,8,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 22053) := by decide +kernel

theorem selectedBound15041 : packedSelected [3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15042 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,22053,22306,14137,24321,1024,22052,17681,30473,30520,2,8192,17,10508,16400,26409,2341,29228,33,256,30472,16384,513]

theorem envBound15042 : H12AffineFastState.Bounded env15042 := by
  intro p hp
  have h : env15042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15041_15042 : H12AffineEnvironment.transform 14 22053 env15041 = env15042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22053 env15041 == env15042) = true)

theorem identity15042 : scanCanonicalize (H12AffineFastState.compose env15042 (packedSelected [1,8,10,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1061) := by decide +kernel

theorem selectedBound15042 : packedSelected [1,8,10,14,15] rootPS < 2^1333 := by decide +kernel

def env15043 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,1061,4608,4871,14137,6948,1024,4609,308,13100,13085,2,8192,17,10508,1077,8972,2341,13833,33,256,13101,1061,513]

theorem envBound15043 : H12AffineFastState.Bounded env15043 := by
  intro p hp
  have h : env15043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15042_15043 : H12AffineEnvironment.transform 13 1061 env15042 = env15043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1061 env15042 == env15043) = true)

def env15044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147593,2,8328,64,4450362,2196622,2233816,190520,246938,6383042,256,2327591,2319746,189260]

theorem envBound15044 : H12AffineFastState.Bounded env15044 := by
  intro p hp
  have h : env15044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15034_15044 : H12AffineEnvironment.transform 17 157873 env15034 = env15044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env15034 == env15044) = true)

theorem identity15044 : scanCanonicalize (H12AffineFastState.compose env15044 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15044 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env15045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,157873,1024,8541,2097152,4194304,147593,2,8328,64,4409702,2172370,2233816,149860,222662,6383042,256,2303355,2319746,147984]

theorem envBound15045 : H12AffineFastState.Bounded env15045 := by
  intro p hp
  have h : env15045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15044_15045 : H12AffineEnvironment.transform 14 8540 env15044 = env15045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15044 == env15045) = true)

def env15046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10401,1024,8541,2097152,4194304,153,2,8328,64,4262262,2172370,2119112,2420,75222,6383042,256,2188651,2172306,512]

theorem envBound15046 : H12AffineFastState.Bounded env15046 := by
  intro p hp
  have h : env15046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15045_15046 : H12AffineEnvironment.transform 16 16400 env15045 = env15046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env15045 == env15046) = true)

theorem identity15046 : scanCanonicalize (H12AffineFastState.compose env15046 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15046 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,2097152,4194304,17,2,8192,64,4262262,2172250,2118976,2420,75102,6382922,256,2188651,2172186,512]

theorem envBound15047 : H12AffineFastState.Bounded env15047 := by
  intro p hp
  have h : env15047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15046_15047 : H12AffineEnvironment.transform 6 8 env15046 = env15047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15046 == env15047) = true)

theorem identity15047 : scanCanonicalize (H12AffineFastState.compose env15047 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound15047 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,17461,4194304,17,2,8192,64,4262262,90479,4469,2420,75102,4268415,256,74078,90415,512]

theorem envBound15048 : H12AffineFastState.Bounded env15048 := by
  intro p hp
  have h : env15048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15047_15048 : H12AffineEnvironment.transform 20 17461 env15047 = env15048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env15047 == env15048) = true)

theorem identity15048 : scanCanonicalize (H12AffineFastState.compose env15048 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound15048 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env15049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,17461,32,17,2,8192,64,67926,90479,4469,2420,75102,74079,256,74078,90415,512]

theorem envBound15049 : H12AffineFastState.Bounded env15049 := by
  intro p hp
  have h : env15049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15048_15049 : H12AffineEnvironment.transform 21 32 env15048 = env15049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15048 == env15049) = true)

theorem identity15049 : scanCanonicalize (H12AffineFastState.compose env15049 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 19762) := by decide +kernel

theorem selectedBound15049 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,19762,16400,10281,1024,8541,17461,32,17,2,8192,64,17508,11357,4469,2420,26732,27757,256,27756,11293,512]

theorem envBound15050 : H12AffineFastState.Bounded env15050 := by
  intro p hp
  have h : env15050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15049_15050 : H12AffineEnvironment.transform 15 19762 env15049 = env15050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19762 env15049 == env15050) = true)

theorem identity15050 : scanCanonicalize (H12AffineFastState.compose env15050 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound15050 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5205,8540,6503,5189,10281,1024,8541,4192,32,17,2,8192,64,4145,11357,4469,2420,15417,14392,256,14393,11293,512]

theorem envBound15051 : H12AffineFastState.Bounded env15051 := by
  intro p hp
  have h : env15051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15050_15051 : H12AffineEnvironment.transform 13 5205 env15050 = env15051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env15050 == env15051) = true)

theorem identity15051 : scanCanonicalize (H12AffineFastState.compose env15051 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7212) := by decide +kernel

theorem selectedBound15051 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env15052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7212,5205,7536,6503,5189,5125,1024,7537,4192,32,17,2,7212,64,4145,4209,4469,2420,21,1044,256,1045,4145,512]

theorem envBound15052 : H12AffineFastState.Bounded env15052 := by
  intro p hp
  have h : env15052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15051_15052 : H12AffineEnvironment.transform 12 7212 env15051 = env15052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7212 env15051 == env15052) = true)

theorem identity15052 : scanCanonicalize (H12AffineFastState.compose env15052 (packedSelected [1,2,3,4,5,6,8,9,17] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15052 : packedSelected [1,2,3,4,5,6,8,9,17] rootPS < 2^1333 := by decide +kernel

def env15053 : List Nat := [2,4,8,16,32,64,8,256,512,21,2048,4096,6201,4160,6501,6503,4176,4112,21,6500,4192,32,17,2,6201,64,4145,4209,4469,2420,21,1,256,0,4145,512]

theorem envBound15053 : H12AffineFastState.Bounded env15053 := by
  intro p hp
  have h : env15053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15052_15053 : H12AffineEnvironment.transform 9 21 env15052 = env15053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15052 == env15053) = true)

theorem identity15053 : scanCanonicalize (H12AffineFastState.compose env15053 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound15053 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env15054 : List Nat := [2,4,8,16,32,64,8,256,512,21,2048,2112,121,2048,293,295,2064,2128,21,292,2080,32,17,2,121,64,2161,2097,2357,2420,21,1,256,0,2161,512]

theorem envBound15054 : H12AffineFastState.Bounded env15054 := by
  intro p hp
  have h : env15054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15053_15054 : H12AffineEnvironment.transform 11 2112 env15053 = env15054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env15053 == env15054) = true)

theorem identity15054 : scanCanonicalize (H12AffineFastState.compose env15054 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15054 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env15055 : List Nat := [2,4,8,16,0,64,8,256,512,21,2048,2112,89,2048,261,263,2064,2128,21,260,2048,0,17,2,89,64,2129,2065,2325,2388,21,1,256,0,2129,512]

theorem envBound15055 : H12AffineFastState.Bounded env15055 := by
  intro p hp
  have h : env15055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15054_15055 : H12AffineEnvironment.transform 4 0 env15054 = env15055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15054 == env15055) = true)

theorem identity15055 : scanCanonicalize (H12AffineFastState.compose env15055 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound15055 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env15056 : List Nat := [2,4,8,16,0,64,8,84,512,21,2048,2112,89,2048,81,83,2064,2128,21,80,2048,0,17,2,89,64,2129,2065,2113,2048,21,1,84,0,2129,512]

theorem envBound15056 : H12AffineFastState.Bounded env15056 := by
  intro p hp
  have h : env15056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15055_15056 : H12AffineEnvironment.transform 7 84 env15055 = env15056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env15055 == env15056) = true)

theorem identity15056 : scanCanonicalize (H12AffineFastState.compose env15056 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound15056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15057 : List Nat := [2,4,8,16,0,64,8,84,512,21,592,528,89,592,81,83,576,512,21,80,592,0,17,2,89,64,513,577,529,592,21,1,84,0,513,512]

theorem envBound15057 : H12AffineFastState.Bounded env15057 := by
  intro p hp
  have h : env15057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15056_15057 : H12AffineEnvironment.transform 10 592 env15056 = env15057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env15056 == env15057) = true)

theorem identity15057 : scanCanonicalize (H12AffineFastState.compose env15057 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound15057 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15058 : List Nat := [2,4,8,16,0,64,8,84,80,21,0,64,89,0,81,83,16,80,21,80,0,0,17,2,89,64,81,17,65,0,21,1,84,0,81,80]

theorem envBound15058 : H12AffineFastState.Bounded env15058 := by
  intro p hp
  have h : env15058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15057_15058 : H12AffineEnvironment.transform 8 80 env15057 = env15058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env15057 == env15058) = true)

theorem identity15058 : scanCanonicalize (H12AffineFastState.compose env15058 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15058 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15059 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,16,9,0,1,3,16,0,21,0,0,0,17,2,9,16,1,17,17,0,21,1,4,0,1,0]

theorem envBound15059 : H12AffineFastState.Bounded env15059 := by
  intro p hp
  have h : env15059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15058_15059 : H12AffineEnvironment.transform 5 16 env15058 = env15059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15058 == env15059) = true)

theorem identity15059 : scanCanonicalize (H12AffineFastState.compose env15059 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound15059 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15060 : List Nat := [2,4,8,15,0,15,8,4,0,10,0,15,9,0,1,3,15,0,10,0,0,0,14,2,9,15,1,14,14,0,10,1,4,0,1,0]

theorem envBound15060 : H12AffineFastState.Bounded env15060 := by
  intro p hp
  have h : env15060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15059_15060 : H12AffineEnvironment.transform 3 15 env15059 = env15060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env15059 == env15060) = true)

def env15061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10400,1024,8541,2097152,4194304,152,2,8328,64,4262263,2172370,2119113,2421,75223,6383042,256,2188650,2172307,513]

theorem envBound15061 : H12AffineFastState.Bounded env15061 := by
  intro p hp
  have h : env15061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15045_15061 : H12AffineEnvironment.transform 16 16401 env15045 = env15061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15045 == env15061) = true)

def env15062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,2097152,4194304,16,2,8192,64,4262263,2172250,2118977,2421,75103,6382922,256,2188650,2172187,513]

theorem envBound15062 : H12AffineFastState.Bounded env15062 := by
  intro p hp
  have h : env15062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15061_15062 : H12AffineEnvironment.transform 6 8 env15061 = env15062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15061 == env15062) = true)

theorem identity15062 : scanCanonicalize (H12AffineFastState.compose env15062 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound15062 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env15063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,91466,4194304,16,2,8192,64,4262263,16400,77835,2421,75103,4194304,256,32,16465,513]

theorem envBound15063 : H12AffineFastState.Bounded env15063 := by
  intro p hp
  have h : env15063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15062_15063 : H12AffineEnvironment.transform 20 91466 env15062 = env15063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env15062 == env15063) = true)

theorem identity15063 : scanCanonicalize (H12AffineFastState.compose env15063 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound15063 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env15064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,91466,32,16,2,8192,64,67927,16400,77835,2421,75103,32,256,32,16465,513]

theorem envBound15064 : H12AffineFastState.Bounded env15064 := by
  intro p hp
  have h : env15064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15063_15064 : H12AffineEnvironment.transform 21 32 env15063 = env15064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15063 == env15064) = true)

def env15065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1024,8541,2097152,4194304,17,2,8193,64,4262263,2172251,2118976,2421,75102,6382923,256,2188650,2172186,513]

theorem envBound15065 : H12AffineFastState.Bounded env15065 := by
  intro p hp
  have h : env15065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15061_15065 : H12AffineEnvironment.transform 6 9 env15061 = env15065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15061 == env15065) = true)

theorem identity15065 : scanCanonicalize (H12AffineFastState.compose env15065 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15065 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10281,1024,8541,2097152,4194304,17,2,8193,64,4204925,2098513,2118976,2421,1364,6309185,256,2114912,2098448,513]

theorem envBound15066 : H12AffineFastState.Bounded env15066 := by
  intro p hp
  have h : env15066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15065_15066 : H12AffineEnvironment.transform 15 8202 env15065 = env15066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15065 == env15066) = true)

theorem identity15066 : scanCanonicalize (H12AffineFastState.compose env15066 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2102641) := by decide +kernel

theorem selectedBound15066 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10281,1024,8541,2097152,2102641,17,2,8193,64,2112524,2098513,2118976,2421,1364,20528,256,2114912,2098448,513]

theorem envBound15067 : H12AffineFastState.Bounded env15067 := by
  intro p hp
  have h : env15067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15066_15067 : H12AffineEnvironment.transform 21 2102641 env15066 = env15067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102641 env15066 == env15067) = true)

theorem identity15067 : scanCanonicalize (H12AffineFastState.compose env15067 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound15067 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env15068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,8192,16384,8540,8202,16401,10281,1024,8541,2097152,2100529,17,2,8193,64,2106444,2098513,2116864,2421,1364,18544,256,2114912,2098448,513]

theorem envBound15068 : H12AffineFastState.Bounded env15068 := by
  intro p hp
  have h : env15068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15067_15068 : H12AffineEnvironment.transform 11 2112 env15067 = env15068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env15067 == env15068) = true)

theorem identity15068 : scanCanonicalize (H12AffineFastState.compose env15068 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 3345) := by decide +kernel

theorem selectedBound15068 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,8192,16384,8540,8202,16401,10281,1024,8541,3345,32,17,2,8193,64,10589,2112,16401,2421,1364,18544,256,18545,2049,513]

theorem envBound15069 : H12AffineFastState.Bounded env15069 := by
  intro p hp
  have h : env15069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15068_15069 : H12AffineEnvironment.transform 20 3345 env15068 = env15069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3345 env15068 == env15069) = true)

theorem identity15069 : scanCanonicalize (H12AffineFastState.compose env15069 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 10588) := by decide +kernel

theorem selectedBound15069 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2112,8192,10588,8540,8202,10573,10281,1024,8541,3345,32,17,2,8193,64,10589,2112,10573,2421,1364,8492,256,8493,2049,513]

theorem envBound15070 : H12AffineFastState.Bounded env15070 := by
  intro p hp
  have h : env15070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15069_15070 : H12AffineEnvironment.transform 13 10588 env15069 = env15070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10588 env15069 == env15070) = true)

theorem identity15070 : scanCanonicalize (H12AffineFastState.compose env15070 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15070 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env15071 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2112,8192,10280,8232,8202,10297,10281,1024,8233,3173,32,17,2,8193,64,10281,2112,10297,2049,1056,8280,116,8281,2049,513]

theorem envBound15071 : H12AffineFastState.Bounded env15071 := by
  intro p hp
  have h : env15071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15070_15071 : H12AffineEnvironment.transform 7 116 env15070 = env15071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15070 == env15071) = true)

theorem identity15071 : scanCanonicalize (H12AffineFastState.compose env15071 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound15071 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env15072 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,1060,8192,9292,8232,8202,9309,9293,1024,8233,1,32,17,2,8193,64,9293,1060,9309,1125,1056,8280,116,8281,1125,513]

theorem envBound15072 : H12AffineFastState.Bounded env15072 := by
  intro p hp
  have h : env15072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15071_15072 : H12AffineEnvironment.transform 10 1124 env15071 = env15072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env15071 == env15072) = true)

theorem identity15072 : scanCanonicalize (H12AffineFastState.compose env15072 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound15072 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env15073 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,1060,121,1077,81,115,1060,1076,1024,80,1,32,17,2,120,64,1076,1060,1060,1125,1056,33,116,32,1125,513]

theorem envBound15073 : H12AffineFastState.Bounded env15073 := by
  intro p hp
  have h : env15073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15072_15073 : H12AffineEnvironment.transform 12 121 env15072 = env15073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env15072 == env15073) = true)

def env15074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound15074 : H12AffineFastState.Bounded env15074 := by
  intro p hp
  have h : env15074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14988_15074 : H12AffineEnvironment.transform 18 1025 env14988 = env15074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14988 == env15074) = true)

theorem identity15074 : scanCanonicalize (H12AffineFastState.compose env15074 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 254083) := by decide +kernel

theorem selectedBound15074 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,254083,16777216,8328,64,21241986,18973837,2340306,336002,16934034,23160256,257,19014702,19056010,16991045]

theorem envBound15075 : H12AffineFastState.Bounded env15075 := by
  intro p hp
  have h : env15075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15074_15075 : H12AffineEnvironment.transform 22 254083 env15074 = env15075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 254083 env15074 == env15075) = true)

def env15076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254083,16777216,8328,64,16959642,18973837,2340306,336002,16934034,19369432,257,19014702,19056010,16991045]

theorem envBound15076 : H12AffineFastState.Bounded env15076 := by
  intro p hp
  have h : env15076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15075_15076 : H12AffineEnvironment.transform 21 452632 env15075 = env15076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env15075 == env15076) = true)

def env15077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254083,243088,8328,64,97546,2240797,2340306,336002,119042,2373704,257,2199998,2191386,63189]

end H12CloudChart0