import H12CloudChart0Data221

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity56215 : scanCanonicalize (H12AffineFastState.compose env56215 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound56215 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56216 : List Nat := [2,4,8,4,1,5,9,5,0,0,5,5,9,0,1,2,5,5,1,0,0,1,5,2,8,4,4,4,4,4,0,0,4,0,1,0]

theorem envBound56216 : H12AffineFastState.Bounded env56216 := by
  intro p hp
  have h : env56216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56215_56216 : H12AffineEnvironment.transform 3 4 env56215 = env56216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env56215 == env56216) = true)

def env56217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356288,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound56217 : H12AffineFastState.Bounded env56217 := by
  intro p hp
  have h : env56217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55859_56217 : H12AffineEnvironment.transform 26 30393345 env55859 = env56217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env55859 == env56217) = true)

def env56218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound56218 : H12AffineFastState.Bounded env56218 := by
  intro p hp
  have h : env56218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56217_56218 : H12AffineEnvironment.transform 18 1024 env56217 = env56218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env56217 == env56218) = true)

theorem identity56218 : scanCanonicalize (H12AffineFastState.compose env56218 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 437744) := by decide +kernel

theorem selectedBound56218 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,8388608,16777216,8328,65,29868033,17246589,8845472,8830976,25265168,21481520,256,25651548,25659640,25207751]

theorem envBound56219 : H12AffineFastState.Bounded env56219 := by
  intro p hp
  have h : env56219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56218_56219 : H12AffineEnvironment.transform 20 437744 env56218 = env56219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437744 env56218 == env56219) = true)

def env56220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,8388608,8862844,8328,65,4258941,8393985,8845472,8830976,440428,12645452,256,21792,46212,499643]

theorem envBound56220 : H12AffineFastState.Bounded env56220 := by
  intro p hp
  have h : env56220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56219_56220 : H12AffineEnvironment.transform 23 8862844 env56219 = env56220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862844 env56219 == env56220) = true)

def env56221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,441760,98780,8328,65,4258941,436385,17664,32160,440428,4606444,256,21792,46212,499643]

theorem envBound56221 : H12AffineFastState.Bounded env56221 := by
  intro p hp
  have h : env56221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56220_56221 : H12AffineEnvironment.transform 22 441760 env56220 = env56221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env56220 == env56221) = true)

def env56222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272512,441760,98780,8328,65,316669,436385,17664,32160,440428,156012,256,21792,46212,499643]

theorem envBound56222 : H12AffineFastState.Bounded env56222 := by
  intro p hp
  have h : env56222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56221_56222 : H12AffineEnvironment.transform 21 272512 env56221 = env56222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env56221 == env56222) = true)

def env56223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,272392,441640,98644,8192,65,316533,436265,17664,32040,440428,156012,256,21792,46092,499507]

theorem envBound56223 : H12AffineFastState.Bounded env56223 := by
  intro p hp
  have h : env56223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56222_56223 : H12AffineEnvironment.transform 6 8 env56222 = env56223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56222 == env56223) = true)

def env56224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,276584,272392,272440,98644,8192,65,316533,277817,17664,32040,273788,62588,256,21792,46092,330275]

theorem envBound56224 : H12AffineFastState.Bounded env56224 := by
  intro p hp
  have h : env56224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56223_56224 : H12AffineEnvironment.transform 16 38160 env56223 = env56224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env56223 == env56224) = true)

theorem identity56224 : scanCanonicalize (H12AffineFastState.compose env56224 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound56224 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4161,33,17,98644,8192,65,64604,5392,17664,32040,1365,62588,256,21792,46092,74250]

theorem envBound56225 : H12AffineFastState.Bounded env56225 := by
  intro p hp
  have h : env56225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56224_56225 : H12AffineEnvironment.transform 17 10281 env56224 = env56225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56224 == env56225) = true)

theorem identity56225 : scanCanonicalize (H12AffineFastState.compose env56225 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound56225 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env56226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54279,38160,10281,1024,32769,4161,33,17,21843,8192,65,64604,5392,17664,32040,1365,62588,256,21792,46092,62989]

theorem envBound56226 : H12AffineFastState.Bounded env56226 := by
  intro p hp
  have h : env56226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56225_56226 : H12AffineEnvironment.transform 15 54279 env56225 = env56226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env56225 == env56226) = true)

theorem identity56226 : scanCanonicalize (H12AffineFastState.compose env56226 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound56226 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env56227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21510,5393,10281,1024,0,4161,33,17,21843,8192,65,31837,5392,17664,32040,1365,29821,256,21792,13325,30220]

theorem envBound56227 : H12AffineFastState.Bounded env56227 := by
  intro p hp
  have h : env56227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56226_56227 : H12AffineEnvironment.transform 14 1 env56226 = env56227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env56226 == env56227) = true)

theorem identity56227 : scanCanonicalize (H12AffineFastState.compose env56227 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound56227 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env56228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,1,343,5393,10281,1024,0,4161,33,17,2,8192,65,10508,5392,4177,10361,1365,8492,256,113,13325,9053]

theorem envBound56228 : H12AffineFastState.Bounded env56228 := by
  intro p hp
  have h : env56228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56227_56228 : H12AffineEnvironment.transform 13 5457 env56227 = env56228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env56227 == env56228) = true)

theorem identity56228 : scanCanonicalize (H12AffineFastState.compose env56228 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56228 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56229 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,1,263,5393,10281,1024,0,4113,33,17,2,8192,17,10508,5392,4097,10281,1285,8492,256,33,13325,8973]

theorem envBound56229 : H12AffineFastState.Bounded env56229 := by
  intro p hp
  have h : env56229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56228_56229 : H12AffineEnvironment.transform 5 16 env56228 = env56229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56228 == env56229) = true)

theorem identity56229 : scanCanonicalize (H12AffineFastState.compose env56229 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56229 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56230 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5393,2341,1024,0,4113,33,17,2,268,17,2048,5392,4097,2341,1285,32,256,33,5377,513]

theorem envBound56230 : H12AffineFastState.Bounded env56230 := by
  intro p hp
  have h : env56230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56229_56230 : H12AffineEnvironment.transform 12 268 env56229 = env56230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56229 == env56230) = true)

theorem identity56230 : scanCanonicalize (H12AffineFastState.compose env56230 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56230 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56231 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,1,34,5172,2048,1024,0,4113,33,17,2,41,17,2048,5173,4097,2048,1056,32,37,33,5156,513]

theorem envBound56231 : H12AffineFastState.Bounded env56231 := by
  intro p hp
  have h : env56231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56230_56231 : H12AffineEnvironment.transform 7 37 env56230 = env56231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56230 == env56231) = true)

def env56232 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1044,1,34,1028,2048,1024,0,33,33,17,2,41,17,2048,1029,49,2048,1056,32,37,33,1044,513]

theorem envBound56232 : H12AffineFastState.Bounded env56232 := by
  intro p hp
  have h : env56232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56231_56232 : H12AffineEnvironment.transform 11 48 env56231 = env56232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env56231 == env56232) = true)

theorem identity56232 : scanCanonicalize (H12AffineFastState.compose env56232 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound56232 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56233 : List Nat := [2,4,8,16,32,16,8,37,512,1024,32,48,41,1044,1,34,1028,32,1024,0,33,33,17,2,41,17,32,1029,49,32,1056,32,37,33,1044,513]

theorem envBound56233 : H12AffineFastState.Bounded env56233 := by
  intro p hp
  have h : env56233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56232_56233 : H12AffineEnvironment.transform 10 32 env56232 = env56233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env56232 == env56233) = true)

def env56234 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,48,41,32,1,34,48,32,52,0,33,33,17,2,41,17,32,49,49,32,20,32,37,33,32,513]

theorem envBound56234 : H12AffineFastState.Bounded env56234 := by
  intro p hp
  have h : env56234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56233_56234 : H12AffineEnvironment.transform 9 52 env56233 = env56234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56233 == env56234) = true)

theorem identity56234 : scanCanonicalize (H12AffineFastState.compose env56234 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound56234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56235 : List Nat := [2,4,8,16,32,16,8,37,42,52,32,48,41,32,1,34,48,32,52,0,33,33,17,2,41,17,32,49,49,32,20,32,37,33,32,43]

theorem envBound56235 : H12AffineFastState.Bounded env56235 := by
  intro p hp
  have h : env56235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56234_56235 : H12AffineEnvironment.transform 8 42 env56234 = env56235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env56234 == env56235) = true)

def leafEnv56235 : List Nat := [2,4,8,16,32,16,8,37,42,52,32,48,41,32,1,34,48,32,52,0,33,33,17,2,20,41,1,17,32,49,49,32,20,32,37,33,4,34,32,43,1,33,0]

def active56235 : List Nat := [0,1,2,3,4]

def tree56235 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56235 : H12WitnessSearch.Good tree56235 := H12GlobalWitnessIndex.good

theorem leafIdentity56235 : H12AffineFastState.composeSystem env56235 rootObs = leafEnv56235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56235 rootObs == leafEnv56235) = true)

theorem terminalChecked56235 : H12PackedTerminal.terminalCheckFast leafEnv56235 active56235 tree56235 = true := by decide +kernel

def env56236 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,48,41,33,1,34,49,32,53,0,33,33,17,2,41,17,32,48,49,32,21,32,37,33,33,513]

theorem envBound56236 : H12AffineFastState.Bounded env56236 := by
  intro p hp
  have h : env56236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56233_56236 : H12AffineEnvironment.transform 9 53 env56233 = env56236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56233 == env56236) = true)

def env56237 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1045,1,34,1029,2048,1024,0,32,33,17,2,41,17,2048,1028,48,2048,1056,32,37,33,1045,513]

theorem envBound56237 : H12AffineFastState.Bounded env56237 := by
  intro p hp
  have h : env56237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56231_56237 : H12AffineEnvironment.transform 11 49 env56231 = env56237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env56231 == env56237) = true)

theorem identity56237 : scanCanonicalize (H12AffineFastState.compose env56237 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound56237 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56238 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1045,49,41,1045,1,34,1029,1045,1024,0,32,33,17,2,41,17,1045,1028,48,1045,1056,32,37,33,1045,513]

theorem envBound56238 : H12AffineFastState.Bounded env56238 := by
  intro p hp
  have h : env56238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56237_56238 : H12AffineEnvironment.transform 10 1045 env56237 = env56238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env56237 == env56238) = true)

def env56239 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,49,41,33,1,34,49,33,52,0,32,33,17,2,41,17,33,48,48,33,20,32,37,33,33,513]

theorem envBound56239 : H12AffineFastState.Bounded env56239 := by
  intro p hp
  have h : env56239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56238_56239 : H12AffineEnvironment.transform 9 52 env56238 = env56239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56238 == env56239) = true)

theorem identity56239 : scanCanonicalize (H12AffineFastState.compose env56239 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound56239 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56240 : List Nat := [2,4,8,16,32,16,8,37,43,52,33,49,41,33,1,34,49,33,52,0,32,33,17,2,41,17,33,48,48,33,20,32,37,33,33,42]

theorem envBound56240 : H12AffineFastState.Bounded env56240 := by
  intro p hp
  have h : env56240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56239_56240 : H12AffineEnvironment.transform 8 43 env56239 = env56240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env56239 == env56240) = true)

def leafEnv56240 : List Nat := [2,4,8,16,32,16,8,37,43,52,33,49,41,33,1,34,49,33,52,0,32,33,17,2,20,41,1,17,33,48,48,33,20,32,37,33,4,34,33,42,1,32,0]

def active56240 : List Nat := [0,1,2,3,4]

def tree56240 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56240 : H12WitnessSearch.Good tree56240 := H12GlobalWitnessIndex.good

theorem leafIdentity56240 : H12AffineFastState.composeSystem env56240 rootObs = leafEnv56240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56240 rootObs == leafEnv56240) = true)

theorem terminalChecked56240 : H12PackedTerminal.terminalCheckFast leafEnv56240 active56240 tree56240 = true := by decide +kernel

def env56241 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,49,41,32,1,34,48,32,53,0,32,33,17,2,41,17,32,49,48,32,21,32,37,33,32,513]

theorem envBound56241 : H12AffineFastState.Bounded env56241 := by
  intro p hp
  have h : env56241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56238_56241 : H12AffineEnvironment.transform 9 53 env56238 = env56241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56238 == env56241) = true)

def env56242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,276585,272392,272441,98644,8192,65,316533,277816,17664,32040,273789,62589,256,21792,46092,330274]

theorem envBound56242 : H12AffineFastState.Bounded env56242 := by
  intro p hp
  have h : env56242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56223_56242 : H12AffineEnvironment.transform 16 38161 env56223 = env56242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env56223 == env56242) = true)

def env56243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,64808,1024,32769,50497,54560,54545,98644,8192,65,10589,49168,17664,32040,53333,62589,256,21792,46092,128778]

theorem envBound56243 : H12AffineFastState.Bounded env56243 := by
  intro p hp
  have h : env56243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56242_56243 : H12AffineEnvironment.transform 17 64808 env56242 = env56243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env56242 == env56243) = true)

theorem identity56243 : scanCanonicalize (H12AffineFastState.compose env56243 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound56243 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env56244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16400,10281,1024,21760,4160,33,16,87125,8192,65,10589,5393,17664,32040,1364,8572,256,21792,24845,74251]

theorem envBound56244 : H12AffineFastState.Bounded env56244 := by
  intro p hp
  have h : env56244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56243_56244 : H12AffineEnvironment.transform 14 21761 env56243 = env56244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env56243 == env56244) = true)

theorem identity56244 : scanCanonicalize (H12AffineFastState.compose env56244 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound56244 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env56245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,65536,13388,10281,1024,8540,4160,33,16,73737,8192,65,10589,5393,12636,2420,1364,8572,256,8572,5457,74251]

theorem envBound56245 : H12AffineFastState.Bounded env56245 := by
  intro p hp
  have h : env56245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56244_56245 : H12AffineEnvironment.transform 13 13404 env56244 = env56245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env56244 == env56245) = true)

theorem identity56245 : scanCanonicalize (H12AffineFastState.compose env56245 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 8542) := by decide +kernel

theorem selectedBound56245 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,8542,13388,10281,1024,8540,4160,33,16,343,8192,65,10589,5393,12636,2420,1364,8572,256,8572,5457,853]

theorem envBound56246 : H12AffineFastState.Bounded env56246 := by
  intro p hp
  have h : env56246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56245_56246 : H12AffineEnvironment.transform 15 8542 env56245 = env56246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8542 env56245 == env56246) = true)

theorem identity56246 : scanCanonicalize (H12AffineFastState.compose env56246 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound56246 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env56247 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,13404,8200,8203,13388,10281,1024,8201,4160,33,16,2,8192,65,10248,5188,12297,2081,1025,8233,85,8233,5124,512]

theorem envBound56247 : H12AffineFastState.Bounded env56247 := by
  intro p hp
  have h : env56247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56246_56247 : H12AffineEnvironment.transform 7 85 env56246 = env56247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env56246 == env56247) = true)

theorem identity56247 : scanCanonicalize (H12AffineFastState.compose env56247 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound56247 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56248 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,120,5156,112,115,5172,2129,1024,113,4160,33,16,2,120,65,2160,5188,4209,2081,1025,81,85,81,5124,512]

theorem envBound56248 : H12AffineFastState.Bounded env56248 := by
  intro p hp
  have h : env56248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56247_56248 : H12AffineEnvironment.transform 12 120 env56247 = env56248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env56247 == env56248) = true)

theorem identity56248 : scanCanonicalize (H12AffineFastState.compose env56248 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound56248 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56249 : List Nat := [2,4,8,16,32,64,8,85,512,1024,602,4096,120,5156,112,115,5172,523,1024,113,4160,33,16,2,120,65,554,5188,4209,635,1025,81,85,81,5124,512]

theorem envBound56249 : H12AffineFastState.Bounded env56249 := by
  intro p hp
  have h : env56249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56248_56249 : H12AffineEnvironment.transform 10 602 env56248 = env56249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env56248 == env56249) = true)

theorem identity56249 : scanCanonicalize (H12AffineFastState.compose env56249 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound56249 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56250 : List Nat := [2,4,8,16,32,49,8,36,512,1024,555,4096,9,5156,1,2,5172,523,1024,0,4145,33,16,2,9,48,554,5173,4096,522,1025,32,36,32,5124,512]

theorem envBound56250 : H12AffineFastState.Bounded env56250 := by
  intro p hp
  have h : env56250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56249_56250 : H12AffineEnvironment.transform 5 49 env56249 = env56250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56249 == env56250) = true)

theorem identity56250 : scanCanonicalize (H12AffineFastState.compose env56250 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56250 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56251 : List Nat := [2,4,8,16,32,49,8,36,512,53,555,4096,9,4113,1,2,4097,523,53,0,4145,33,16,2,9,48,554,4096,4096,522,52,32,36,32,4145,512]

theorem envBound56251 : H12AffineFastState.Bounded env56251 := by
  intro p hp
  have h : env56251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56250_56251 : H12AffineEnvironment.transform 9 53 env56250 = env56251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56250 == env56251) = true)

theorem identity56251 : scanCanonicalize (H12AffineFastState.compose env56251 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56252 : List Nat := [2,4,8,16,1,16,8,5,512,20,522,4096,9,4113,1,2,4097,523,20,0,4112,0,16,2,9,17,523,4096,4096,522,21,1,5,1,4112,512]

theorem envBound56252 : H12AffineFastState.Bounded env56252 := by
  intro p hp
  have h : env56252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56251_56252 : H12AffineEnvironment.transform 4 1 env56251 = env56252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56251 == env56252) = true)

theorem identity56252 : scanCanonicalize (H12AffineFastState.compose env56252 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound56252 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56253 : List Nat := [2,4,8,16,1,16,8,5,30,20,20,4096,9,4113,1,2,4097,21,20,0,4112,0,16,2,9,17,21,4096,4096,20,21,1,5,1,4112,30]

theorem envBound56253 : H12AffineFastState.Bounded env56253 := by
  intro p hp
  have h : env56253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56252_56253 : H12AffineEnvironment.transform 8 30 env56252 = env56253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env56252 == env56253) = true)

theorem identity56253 : scanCanonicalize (H12AffineFastState.compose env56253 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 23) := by decide +kernel

theorem selectedBound56253 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56254 : List Nat := [2,4,8,16,1,16,8,5,30,20,20,23,9,6,1,2,22,21,20,0,7,0,16,2,9,17,21,23,23,20,21,1,5,1,7,30]

theorem envBound56254 : H12AffineFastState.Bounded env56254 := by
  intro p hp
  have h : env56254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56253_56254 : H12AffineEnvironment.transform 11 23 env56253 = env56254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 23 env56253 == env56254) = true)

def env56255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,64809,1024,32769,50496,54561,54544,98644,8192,65,10588,49169,17664,32040,53332,62589,256,21792,46092,128779]

theorem envBound56255 : H12AffineFastState.Bounded env56255 := by
  intro p hp
  have h : env56255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56242_56255 : H12AffineEnvironment.transform 17 64809 env56242 = env56255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env56242 == env56255) = true)

theorem identity56255 : scanCanonicalize (H12AffineFastState.compose env56255 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound56255 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env56256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38161,64809,1024,32769,50496,54561,54544,29790,8192,65,10588,49169,17664,32040,53332,62589,256,21792,46092,513]

theorem envBound56256 : H12AffineFastState.Bounded env56256 := by
  intro p hp
  have h : env56256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56255_56256 : H12AffineEnvironment.transform 15 62730 env56255 = env56256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env56255 == env56256) = true)

theorem identity56256 : scanCanonicalize (H12AffineFastState.compose env56256 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound56256 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,24909,2421,1024,29789,12572,8573,8524,29790,8192,65,10588,13389,17664,32040,9224,33,256,21792,16464,513]

theorem envBound56257 : H12AffineFastState.Bounded env56257 := by
  intro p hp
  have h : env56257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56256_56257 : H12AffineEnvironment.transform 14 29788 env56256 = env56257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env56256 == env56257) = true)

theorem identity56257 : scanCanonicalize (H12AffineFastState.compose env56257 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound56257 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56258 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,342,5393,2421,1024,1,12572,8573,8524,2,8192,65,10588,13389,12636,2420,9224,33,256,8572,13324,513]

theorem envBound56258 : H12AffineFastState.Bounded env56258 := by
  intro p hp
  have h : env56258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56257_56258 : H12AffineEnvironment.transform 13 13404 env56257 = env56258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env56257 == env56258) = true)

theorem identity56258 : scanCanonicalize (H12AffineFastState.compose env56258 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56258 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56259 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,0,263,5393,2340,1024,1,12572,8492,8477,2,8192,16,10509,13340,12557,2341,9224,33,256,8493,13324,513]

theorem envBound56259 : H12AffineFastState.Bounded env56259 := by
  intro p hp
  have h : env56259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56258_56259 : H12AffineEnvironment.transform 5 17 env56258 = env56259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56258 == env56259) = true)

theorem identity56259 : scanCanonicalize (H12AffineFastState.compose env56259 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound56259 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56260 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,4113,0,263,5393,2340,1024,1,5376,1328,1281,2,1052,16,3345,4096,5393,2341,20,33,256,1329,4112,513]

theorem envBound56260 : H12AffineFastState.Bounded env56260 := by
  intro p hp
  have h : env56260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56259_56260 : H12AffineEnvironment.transform 12 1052 env56259 = env56260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env56259 == env56260) = true)

theorem identity56260 : scanCanonicalize (H12AffineFastState.compose env56260 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound56260 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env56261 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,4096,1052,4113,0,263,5393,292,1024,1,5376,1328,1281,2,1052,16,1297,4096,5393,293,20,33,256,1329,4112,513]

theorem envBound56261 : H12AffineFastState.Bounded env56261 := by
  intro p hp
  have h : env56261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56260_56261 : H12AffineEnvironment.transform 10 0 env56260 = env56261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env56260 == env56261) = true)

theorem identity56261 : scanCanonicalize (H12AffineFastState.compose env56261 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56261 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56262 : List Nat := [2,4,8,16,32,17,8,256,512,272,0,4096,268,4113,0,263,4097,292,272,1,4112,32,17,2,268,16,1,4096,4097,293,20,33,256,33,4112,513]

theorem envBound56262 : H12AffineFastState.Bounded env56262 := by
  intro p hp
  have h : env56262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56261_56262 : H12AffineEnvironment.transform 9 272 env56261 = env56262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56261 == env56262) = true)

theorem identity56262 : scanCanonicalize (H12AffineFastState.compose env56262 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56262 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56263 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,4096,41,4113,0,34,4097,1,53,1,4112,32,17,2,41,16,1,4096,4097,0,20,33,37,33,4112,513]

theorem envBound56263 : H12AffineFastState.Bounded env56263 := by
  intro p hp
  have h : env56263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56262_56263 : H12AffineEnvironment.transform 7 37 env56262 = env56263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56262 == env56263) = true)

theorem identity56263 : scanCanonicalize (H12AffineFastState.compose env56263 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound56263 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56264 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,48,41,33,0,34,49,1,53,1,32,32,17,2,41,16,1,48,49,0,20,33,37,33,32,513]

theorem envBound56264 : H12AffineFastState.Bounded env56264 := by
  intro p hp
  have h : env56264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56263_56264 : H12AffineEnvironment.transform 11 48 env56263 = env56264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env56263 == env56264) = true)

theorem identity56264 : scanCanonicalize (H12AffineFastState.compose env56264 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56264 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56265 : List Nat := [2,4,8,16,1,17,8,4,512,20,0,17,8,0,0,3,16,1,20,1,1,1,17,2,8,16,1,17,16,0,20,0,4,0,1,513]

theorem envBound56265 : H12AffineFastState.Bounded env56265 := by
  intro p hp
  have h : env56265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56264_56265 : H12AffineEnvironment.transform 4 1 env56264 = env56265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56264 == env56265) = true)

def env56266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,272393,441641,98645,8193,65,316532,436264,17664,32041,440428,156012,256,21792,46093,499506]

theorem envBound56266 : H12AffineFastState.Bounded env56266 := by
  intro p hp
  have h : env56266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56222_56266 : H12AffineEnvironment.transform 6 9 env56222 = env56266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56222 == env56266) = true)

theorem identity56266 : scanCanonicalize (H12AffineFastState.compose env56266 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound56266 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env56267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,122147,1024,32769,225370,128298,221194,98645,8193,65,67927,226571,17664,32041,222543,156012,256,21792,46093,147985]

theorem envBound56267 : H12AffineFastState.Bounded env56267 := by
  intro p hp
  have h : env56267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56266_56267 : H12AffineEnvironment.transform 17 122147 env56266 = env56267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env56266 == env56267) = true)

theorem identity56267 : scanCanonicalize (H12AffineFastState.compose env56267 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound56267 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,122147,1024,32769,102679,128298,98631,98645,8193,65,67927,103494,17664,32041,99330,32801,256,21792,46093,41820]

theorem envBound56268 : H12AffineFastState.Bounded env56268 := by
  intro p hp
  have h : env56268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56267_56268 : H12AffineEnvironment.transform 16 57677 env56267 = env56268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env56267 == env56268) = true)

theorem identity56268 : scanCanonicalize (H12AffineFastState.compose env56268 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56268 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env56269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,97406,1024,8540,77898,87159,73754,73736,8193,65,67927,79131,17664,32041,75103,8572,256,21792,5456,513]

theorem envBound56269 : H12AffineFastState.Bounded env56269 := by
  intro p hp
  have h : env56269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56268_56269 : H12AffineEnvironment.transform 14 8541 env56268 = env56269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56268 == env56269) = true)

theorem identity56269 : scanCanonicalize (H12AffineFastState.compose env56269 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound56269 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56270 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,16384,8541,65536,16400,96623,273,8540,77898,86374,73754,73736,8193,65,67927,77834,16401,30776,73806,8572,256,20529,4161,513]

theorem envBound56270 : H12AffineFastState.Bounded env56270 := by
  intro p hp
  have h : env56270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56269_56270 : H12AffineEnvironment.transform 9 273 env56269 = env56270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env56269 == env56270) = true)

theorem identity56270 : scanCanonicalize (H12AffineFastState.compose env56270 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound56270 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env56271 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12620,8541,65536,12636,67619,273,8540,77898,73770,73754,73736,8193,65,67927,77834,12637,2420,73806,8572,256,8573,4161,513]

theorem envBound56271 : H12AffineFastState.Bounded env56271 := by
  intro p hp
  have h : env56271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56270_56271 : H12AffineEnvironment.transform 13 12620 env56270 = env56271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env56270 == env56271) = true)

theorem identity56271 : scanCanonicalize (H12AffineFastState.compose env56271 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56271 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56272 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12620,8541,8203,12636,10280,273,8540,4161,33,17,3,8193,65,10588,4097,12637,2420,69,8572,256,8573,4161,513]

theorem envBound56272 : H12AffineFastState.Bounded env56272 := by
  intro p hp
  have h : env56272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56271_56272 : H12AffineEnvironment.transform 15 8203 env56271 = env56272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56271 == env56272) = true)

theorem identity56272 : scanCanonicalize (H12AffineFastState.compose env56272 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56273 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,268,4160,81,263,4176,2340,273,80,4161,33,17,3,269,65,2128,4097,4177,2420,69,112,256,113,4161,513]

theorem envBound56273 : H12AffineFastState.Bounded env56273 := by
  intro p hp
  have h : env56273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56272_56273 : H12AffineEnvironment.transform 12 268 env56272 = env56273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56272 == env56273) = true)

theorem identity56273 : scanCanonicalize (H12AffineFastState.compose env56273 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56273 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env56274 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4113,0,263,4097,2340,273,1,4112,33,17,3,269,16,2049,4097,4096,2341,20,33,256,32,4112,513]

theorem envBound56274 : H12AffineFastState.Bounded env56274 := by
  intro p hp
  have h : env56274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56273_56274 : H12AffineEnvironment.transform 5 17 env56273 = env56274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56273 == env56274) = true)

theorem identity56274 : scanCanonicalize (H12AffineFastState.compose env56274 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound56274 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56275 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2064,268,2049,0,263,2065,2340,273,1,2048,33,17,3,269,16,2049,2065,2064,2341,20,33,256,32,2048,513]

theorem envBound56275 : H12AffineFastState.Bounded env56275 := by
  intro p hp
  have h : env56275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56274_56275 : H12AffineEnvironment.transform 11 2064 env56274 = env56275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env56274 == env56275) = true)

theorem identity56275 : scanCanonicalize (H12AffineFastState.compose env56275 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56275 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56276 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2064,40,2049,0,35,2065,2048,53,1,2048,33,17,3,41,16,2049,2065,2064,2049,20,33,36,32,2048,513]

theorem envBound56276 : H12AffineFastState.Bounded env56276 := by
  intro p hp
  have h : env56276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56275_56276 : H12AffineEnvironment.transform 7 36 env56275 = env56276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56275 == env56276) = true)

theorem identity56276 : scanCanonicalize (H12AffineFastState.compose env56276 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound56276 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56277 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,33,40,48,0,35,32,49,53,1,49,33,17,3,41,16,48,32,33,48,20,33,36,32,49,513]

theorem envBound56277 : H12AffineFastState.Bounded env56277 := by
  intro p hp
  have h : env56277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56276_56277 : H12AffineEnvironment.transform 10 49 env56276 = env56277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env56276 == env56277) = true)

def leafEnv56277 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,33,40,48,0,35,32,49,53,1,49,33,17,3,20,41,1,16,48,32,33,48,20,33,36,32,4,34,49,513,1,48,0]

def active56277 : List Nat := [0,1,2,3,4,8]

def tree56277 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56277 : H12WitnessSearch.Good tree56277 := H12GlobalWitnessIndex.good

theorem leafIdentity56277 : H12AffineFastState.composeSystem env56277 rootObs = leafEnv56277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56277 rootObs == leafEnv56277) = true)

theorem terminalChecked56277 : H12PackedTerminal.terminalCheckFast leafEnv56277 active56277 tree56277 = true := by decide +kernel

def env56278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272513,441760,98780,8328,65,316668,436385,17664,32160,440428,156013,256,21792,46212,499643]

theorem envBound56278 : H12AffineFastState.Bounded env56278 := by
  intro p hp
  have h : env56278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56221_56278 : H12AffineEnvironment.transform 21 272513 env56221 = env56278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env56221 == env56278) = true)

theorem identity56278 : scanCanonicalize (H12AffineFastState.compose env56278 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound56278 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,169265,16,98780,8328,65,158028,5393,17664,32160,1500,156013,256,21792,46212,74251]

theorem envBound56279 : H12AffineFastState.Bounded env56279 := by
  intro p hp
  have h : env56279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56278_56279 : H12AffineEnvironment.transform 17 179632 env56278 = env56279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env56278 == env56279) = true)

theorem identity56279 : scanCanonicalize (H12AffineFastState.compose env56279 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56279 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env56280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179632,1024,32769,4160,169265,16,41430,8328,65,158028,5393,17664,32160,1500,156013,256,21792,46212,513]

theorem envBound56280 : H12AffineFastState.Bounded env56280 := by
  intro p hp
  have h : env56280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56279_56280 : H12AffineEnvironment.transform 15 8202 env56279 = env56280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56279 == env56280) = true)

def env56281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,441761,98781,8328,65,4258941,436384,17665,32161,440428,4606445,256,21792,46212,499643]

theorem envBound56281 : H12AffineFastState.Bounded env56281 := by
  intro p hp
  have h : env56281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56220_56281 : H12AffineEnvironment.transform 22 441761 env56220 = env56281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env56220 == env56281) = true)

def env56282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272512,441761,98781,8328,65,316669,436384,17665,32161,440428,156013,256,21792,46212,499643]

theorem envBound56282 : H12AffineFastState.Bounded env56282 := by
  intro p hp
  have h : env56282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56281_56282 : H12AffineEnvironment.transform 21 272512 env56281 = env56282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env56281 == env56282) = true)

theorem identity56282 : scanCanonicalize (H12AffineFastState.compose env56282 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound56282 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,416036,272512,412021,95497,8328,65,270377,416884,17665,32161,412856,156013,256,21792,16464,486255]

theorem envBound56283 : H12AffineFastState.Bounded env56283 := by
  intro p hp
  have h : env56283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56282_56283 : H12AffineEnvironment.transform 14 29908 env56282 = env56283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env56282 == env56283) = true)

def env56284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,160132,32,156117,95497,8328,65,2185,160980,17665,32161,156696,156013,256,21792,16464,213967]

theorem envBound56284 : H12AffineFastState.Bounded env56284 := by
  intro p hp
  have h : env56284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56283_56284 : H12AffineEnvironment.transform 17 10400 env56283 = env56284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env56283 == env56284) = true)

theorem identity56284 : scanCanonicalize (H12AffineFastState.compose env56284 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 79079) := by decide +kernel

theorem selectedBound56284 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env56285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79079,10400,1024,29909,83299,32,87346,95497,8328,65,2185,81971,17665,32161,86271,87434,256,21792,16464,30504]

theorem envBound56285 : H12AffineFastState.Bounded env56285 := by
  intro p hp
  have h : env56285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56284_56285 : H12AffineEnvironment.transform 16 79079 env56284 = env56285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79079 env56284 == env56285) = true)

theorem identity56285 : scanCanonicalize (H12AffineFastState.compose env56285 (packedSelected [0,1,2,4,5,6,9,11,15,17,18,19,20,24,26,27,28,31,41] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound56285 : packedSelected [0,1,2,4,5,6,9,11,15,17,18,19,20,24,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env56286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,170,13389,10400,1024,29909,17865,32,21912,30115,8328,65,2185,16537,17665,32161,20565,21792,256,21792,16464,30504]

theorem envBound56286 : H12AffineFastState.Bounded env56286 := by
  intro p hp
  have h : env56286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56285_56286 : H12AffineEnvironment.transform 15 170 env56285 = env56286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env56285 == env56286) = true)

theorem identity56286 : scanCanonicalize (H12AffineFastState.compose env56286 (packedSelected [0,1,3,4,7,8,10,12,15,17,18,19,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound56286 : packedSelected [0,1,3,4,7,8,10,12,15,17,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env56287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8352,170,13389,10400,1024,8353,4541,32,492,8663,8328,65,2185,5357,4469,10709,1057,340,256,340,5156,9052]

theorem envBound56287 : H12AffineFastState.Bounded env56287 := by
  intro p hp
  have h : env56287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56286_56287 : H12AffineEnvironment.transform 13 5236 env56286 = env56287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env56286 == env56287) = true)

theorem identity56287 : scanCanonicalize (H12AffineFastState.compose env56287 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound56287 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env56288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5236,136,170,5221,2184,1024,137,4541,32,492,511,160,65,2185,5357,4469,2557,1057,340,256,340,5156,884]

theorem envBound56288 : H12AffineFastState.Bounded env56288 := by
  intro p hp
  have h : env56288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56287_56288 : H12AffineEnvironment.transform 12 40 env56287 = env56288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env56287 == env56288) = true)

theorem identity56288 : scanCanonicalize (H12AffineFastState.compose env56288 (packedSelected [0,1,3,5,7,8,12,14,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound56288 : packedSelected [0,1,3,5,7,8,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env56289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1140,40,0,136,170,17,2184,1024,137,1481,32,492,511,160,65,2185,153,1281,2557,1057,340,256,340,80,884]

theorem envBound56289 : H12AffineFastState.Bounded env56289 := by
  intro p hp
  have h : env56289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56288_56289 : H12AffineEnvironment.transform 11 1140 env56288 = env56289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env56288 == env56289) = true)

theorem identity56289 : scanCanonicalize (H12AffineFastState.compose env56289 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56289 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env56290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,40,0,1,35,17,2049,1024,0,1344,32,357,374,41,65,2048,16,1281,2420,1057,340,256,340,80,884]

theorem envBound56290 : H12AffineFastState.Bounded env56290 := by
  intro p hp
  have h : env56290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56289_56290 : H12AffineEnvironment.transform 6 9 env56289 = env56290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56289 == env56290) = true)

theorem identity56290 : scanCanonicalize (H12AffineFastState.compose env56290 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56290 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56291 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,40,0,1,35,17,2049,1024,0,1296,32,309,294,41,17,2048,16,1281,2340,1057,260,256,260,0,804]

theorem envBound56291 : H12AffineFastState.Bounded env56291 := by
  intro p hp
  have h : env56291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56290_56291 : H12AffineEnvironment.transform 5 16 env56290 = env56291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56290 == env56291) = true)

theorem identity56291 : scanCanonicalize (H12AffineFastState.compose env56291 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56291 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env56292 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,1060,40,0,1,35,17,2049,1024,0,1044,32,49,34,41,17,2048,16,1029,2080,1057,0,4,0,0,544]

theorem envBound56292 : H12AffineFastState.Bounded env56292 := by
  intro p hp
  have h : env56292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56291_56292 : H12AffineEnvironment.transform 7 4 env56291 = env56292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56291 == env56292) = true)

def env56293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,160133,33,156116,95497,8328,65,2184,160981,17665,32161,156697,156013,256,21792,16464,213966]

theorem envBound56293 : H12AffineFastState.Bounded env56293 := by
  intro p hp
  have h : env56293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56283_56293 : H12AffineEnvironment.transform 17 10401 env56283 = env56293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env56283 == env56293) = true)

theorem identity56293 : scanCanonicalize (H12AffineFastState.compose env56293 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound56293 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env56294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,10401,1024,29909,70047,33,65998,95497,8328,65,2184,70863,17665,32161,66563,65911,256,21792,16464,9172]

theorem envBound56294 : H12AffineFastState.Bounded env56294 := by
  intro p hp
  have h : env56294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56293_56294 : H12AffineEnvironment.transform 16 90138 env56293 = env56294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env56293 == env56294) = true)

theorem identity56294 : scanCanonicalize (H12AffineFastState.compose env56294 (packedSelected [0,1,3,9,17,18,19,22,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound56294 : packedSelected [0,1,3,9,17,18,19,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env56295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21590,13388,10401,1024,29909,17865,33,21912,8543,8328,65,2184,16537,17665,32161,20565,21793,256,21792,16464,9172]

theorem envBound56295 : H12AffineFastState.Bounded env56295 := by
  intro p hp
  have h : env56295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56294_56295 : H12AffineEnvironment.transform 15 21590 env56294 = env56295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env56294 == env56295) = true)

theorem identity56295 : scanCanonicalize (H12AffineFastState.compose env56295 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound56295 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env56296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,8203,13388,10401,1024,136,12692,33,8645,8543,8328,65,2184,13508,12636,2556,9224,8572,256,8573,13325,9172]

theorem envBound56296 : H12AffineFastState.Bounded env56296 := by
  intro p hp
  have h : env56296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56295_56296 : H12AffineEnvironment.transform 13 13405 env56295 = env56296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env56295 == env56296) = true)

theorem identity56296 : scanCanonicalize (H12AffineFastState.compose env56296 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56296 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env56297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,342,5393,2556,1024,136,4297,33,152,2,469,65,2184,5529,4097,2556,1365,33,256,32,5456,649]

theorem envBound56297 : H12AffineFastState.Bounded env56297 := by
  intro p hp
  have h : env56297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56296_56297 : H12AffineEnvironment.transform 12 349 env56296 = env56297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56296 == env56297) = true)

theorem identity56297 : scanCanonicalize (H12AffineFastState.compose env56297 (packedSelected [11,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56297 : packedSelected [11,14] rootPS < 2^1333 := by decide +kernel

def env56298 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5236,137,34,5221,2184,1024,136,4297,33,152,2,161,65,2184,5357,4097,2184,1057,33,116,32,5156,649]

theorem envBound56298 : H12AffineFastState.Bounded env56298 := by
  intro p hp
  have h : env56298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56297_56298 : H12AffineEnvironment.transform 7 116 env56297 = env56298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56297 == env56298) = true)

theorem identity56298 : scanCanonicalize (H12AffineFastState.compose env56298 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound56298 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56299 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,41,5236,80,34,5221,2129,1024,81,4112,33,65,2,120,65,2129,5172,4097,2129,1057,33,116,32,5156,592]

theorem envBound56299 : H12AffineFastState.Bounded env56299 := by
  intro p hp
  have h : env56299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56298_56299 : H12AffineEnvironment.transform 6 89 env56298 = env56299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env56298 == env56299) = true)

theorem identity56299 : scanCanonicalize (H12AffineFastState.compose env56299 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56299 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56300 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,0,34,5173,2049,1024,1,4112,33,17,2,40,17,2049,5172,4097,2049,1057,33,36,32,5156,512]

theorem envBound56300 : H12AffineFastState.Bounded env56300 := by
  intro p hp
  have h : env56300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56299_56300 : H12AffineEnvironment.transform 5 16 env56299 = env56300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56299 == env56300) = true)

theorem identity56300 : scanCanonicalize (H12AffineFastState.compose env56300 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56300 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56301 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,4096,9,5124,0,2,5141,2049,1024,1,4112,1,17,2,8,17,2049,5140,4097,2049,1025,1,4,0,5124,512]

theorem envBound56301 : H12AffineFastState.Bounded env56301 := by
  intro p hp
  have h : env56301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56300_56301 : H12AffineEnvironment.transform 4 0 env56300 = env56301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56300 == env56301) = true)

theorem identity56301 : scanCanonicalize (H12AffineFastState.compose env56301 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound56301 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56302 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,1028,9,0,0,2,17,2049,1024,1,1044,1,17,2,8,17,2049,16,1029,2049,1025,1,4,0,0,512]

theorem envBound56302 : H12AffineFastState.Bounded env56302 := by
  intro p hp
  have h : env56302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56301_56302 : H12AffineEnvironment.transform 11 1028 env56301 = env56302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env56301 == env56302) = true)

theorem identity56302 : scanCanonicalize (H12AffineFastState.compose env56302 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56303 : List Nat := [2,4,8,16,0,16,9,4,1,1024,2048,1028,9,0,0,2,17,2049,1024,1,1044,1,17,2,8,17,2049,16,1029,2049,1025,1,4,0,0,1]

theorem envBound56303 : H12AffineFastState.Bounded env56303 := by
  intro p hp
  have h : env56303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56302_56303 : H12AffineEnvironment.transform 8 1 env56302 = env56303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56302 == env56303) = true)

theorem identity56303 : scanCanonicalize (H12AffineFastState.compose env56303 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56303 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56304 : List Nat := [2,4,8,16,0,16,9,4,1,1024,1,1028,9,0,0,2,17,0,1024,1,1044,1,17,2,8,17,0,16,1029,0,1025,1,4,0,0,1]

theorem envBound56304 : H12AffineFastState.Bounded env56304 := by
  intro p hp
  have h : env56304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56303_56304 : H12AffineEnvironment.transform 10 1 env56303 = env56304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56303 == env56304) = true)

theorem identity56304 : scanCanonicalize (H12AffineFastState.compose env56304 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound56304 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56305 : List Nat := [2,4,8,16,0,16,9,4,1,20,1,16,9,0,0,2,17,0,20,1,0,1,17,2,8,17,0,16,17,0,21,1,4,0,0,1]

theorem envBound56305 : H12AffineFastState.Bounded env56305 := by
  intro p hp
  have h : env56305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56304_56305 : H12AffineEnvironment.transform 9 20 env56304 = env56305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56304 == env56305) = true)

theorem identity56305 : scanCanonicalize (H12AffineFastState.compose env56305 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound56305 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56306 : List Nat := [2,4,8,4,0,4,9,4,1,0,1,4,9,0,0,2,5,0,0,1,0,1,5,2,8,5,0,4,5,0,1,1,4,0,0,1]

theorem envBound56306 : H12AffineFastState.Bounded env56306 := by
  intro p hp
  have h : env56306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56305_56306 : H12AffineEnvironment.transform 3 4 env56305 = env56306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env56305 == env56306) = true)

def env56307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272513,441761,98781,8328,65,316668,436384,17665,32161,440428,156012,256,21792,46212,499643]

theorem envBound56307 : H12AffineFastState.Bounded env56307 := by
  intro p hp
  have h : env56307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56281_56307 : H12AffineEnvironment.transform 21 272513 env56281 = env56307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env56281 == env56307) = true)

theorem identity56307 : scanCanonicalize (H12AffineFastState.compose env56307 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound56307 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,58517,156132,62660,98781,8328,65,171417,57797,17665,32161,61705,156012,256,21792,46212,120542]

theorem envBound56308 : H12AffineFastState.Bounded env56308 := by
  intro p hp
  have h : env56308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56307_56308 : H12AffineEnvironment.transform 17 149861 env56307 = env56308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env56307 == env56308) = true)

def env56309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,56573,1024,32769,58517,62588,62660,98781,8328,65,2049,57797,17665,32161,61705,62708,256,21792,46212,120542]

theorem envBound56309 : H12AffineFastState.Bounded env56309 := by
  intro p hp
  have h : env56309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56308_56309 : H12AffineEnvironment.transform 16 38296 env56308 = env56309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env56308 == env56309) = true)

def env56310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38296,35325,1024,32769,45461,41340,41412,98781,8328,65,2049,46277,4097,10401,41993,41460,256,32,46212,99294]

theorem envBound56310 : H12AffineFastState.Bounded env56310 := by
  intro p hp
  have h : env56310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56309_56310 : H12AffineEnvironment.transform 13 5376 env56309 = env56310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56309 == env56310) = true)

theorem identity56310 : scanCanonicalize (H12AffineFastState.compose env56310 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56310 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38160,35189,1024,32769,45341,41340,41292,98645,8192,65,2049,46157,4097,10281,41993,41340,256,32,46092,99158]

theorem envBound56311 : H12AffineFastState.Bounded env56311 := by
  intro p hp
  have h : env56311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56310_56311 : H12AffineEnvironment.transform 6 8 env56310 = env56311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56310 == env56311) = true)

theorem identity56311 : scanCanonicalize (H12AffineFastState.compose env56311 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound56311 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env56312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13388,10281,1024,8541,4161,32,16,73737,8192,65,2049,5393,4097,10281,1365,32,256,32,5456,74250]

theorem envBound56312 : H12AffineFastState.Bounded env56312 := by
  intro p hp
  have h : env56312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56311_56312 : H12AffineEnvironment.transform 14 8540 env56311 = env56312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env56311 == env56312) = true)

theorem identity56312 : scanCanonicalize (H12AffineFastState.compose env56312 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound56312 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56313 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,5205,8201,65536,13388,10281,1024,8200,4161,32,16,73737,8192,65,2049,5188,4097,10281,1024,32,85,32,5125,74250]

theorem envBound56313 : H12AffineFastState.Bounded env56313 := by
  intro p hp
  have h : env56313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56312_56313 : H12AffineEnvironment.transform 7 85 env56312 = env56313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env56312 == env56313) = true)

theorem identity56313 : scanCanonicalize (H12AffineFastState.compose env56313 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56313 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56314 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,5205,8201,8203,13388,10281,1024,8200,4161,32,16,2,8192,65,2049,5188,4097,10281,1024,32,85,32,5125,513]

theorem envBound56314 : H12AffineFastState.Bounded env56314 := by
  intro p hp
  have h : env56314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56313_56314 : H12AffineEnvironment.transform 15 8203 env56313 = env56314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56313 == env56314) = true)

theorem identity56314 : scanCanonicalize (H12AffineFastState.compose env56314 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound56314 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56315 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,88,5205,81,83,5140,2161,1024,80,4161,32,16,2,88,65,2049,5188,4097,2161,1024,32,85,32,5125,513]

theorem envBound56315 : H12AffineFastState.Bounded env56315 := by
  intro p hp
  have h : env56315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56314_56315 : H12AffineEnvironment.transform 12 88 env56314 = env56315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env56314 == env56315) = true)

theorem identity56315 : scanCanonicalize (H12AffineFastState.compose env56315 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound56315 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56316 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,1541,88,592,81,83,529,2161,1024,80,1604,32,16,2,88,65,2049,577,1540,2161,1024,32,85,32,512,513]

theorem envBound56316 : H12AffineFastState.Bounded env56316 := by
  intro p hp
  have h : env56316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56315_56316 : H12AffineEnvironment.transform 11 1541 env56315 = env56316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env56315 == env56316) = true)

theorem identity56316 : scanCanonicalize (H12AffineFastState.compose env56316 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound56316 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env56317 : List Nat := [2,4,8,16,32,64,8,85,512,1024,64,1541,88,592,81,83,529,49,1024,80,1604,32,16,2,88,65,65,577,1540,49,1024,32,85,32,512,513]

theorem envBound56317 : H12AffineFastState.Bounded env56317 := by
  intro p hp
  have h : env56317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56316_56317 : H12AffineEnvironment.transform 10 64 env56316 = env56317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env56316 == env56317) = true)

theorem identity56317 : scanCanonicalize (H12AffineFastState.compose env56317 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56317 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env56318 : List Nat := [2,4,8,16,32,16,8,5,512,1024,16,1541,8,512,1,3,529,49,1024,0,1556,32,16,2,8,17,17,529,1540,49,1024,32,5,32,512,513]

theorem envBound56318 : H12AffineFastState.Bounded env56318 := by
  intro p hp
  have h : env56318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56317_56318 : H12AffineEnvironment.transform 5 16 env56317 = env56318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56317 == env56318) = true)

theorem identity56318 : scanCanonicalize (H12AffineFastState.compose env56318 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56318 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56319 : List Nat := [2,4,8,16,32,16,8,5,512,53,16,560,8,512,1,3,529,49,53,0,545,32,16,2,8,17,17,529,561,49,53,32,5,32,512,513]

theorem envBound56319 : H12AffineFastState.Bounded env56319 := by
  intro p hp
  have h : env56319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56318_56319 : H12AffineEnvironment.transform 9 53 env56318 = env56319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56318 == env56319) = true)

theorem identity56319 : scanCanonicalize (H12AffineFastState.compose env56319 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound56319 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56320 : List Nat := [2,4,8,16,26,16,8,5,512,15,16,522,8,512,1,3,529,11,15,0,539,26,16,2,8,17,17,529,523,11,15,26,5,26,512,513]

theorem envBound56320 : H12AffineFastState.Bounded env56320 := by
  intro p hp
  have h : env56320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56319_56320 : H12AffineEnvironment.transform 4 26 env56319 = env56320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env56319 == env56320) = true)

theorem identity56320 : scanCanonicalize (H12AffineFastState.compose env56320 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56320 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56321 : List Nat := [2,4,8,1,11,1,8,5,512,15,1,522,8,512,1,3,512,11,15,0,522,11,1,2,8,0,0,512,523,11,15,11,5,11,512,513]

theorem envBound56321 : H12AffineFastState.Bounded env56321 := by
  intro p hp
  have h : env56321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56320_56321 : H12AffineEnvironment.transform 3 1 env56320 = env56321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56320 == env56321) = true)

theorem identity56321 : scanCanonicalize (H12AffineFastState.compose env56321 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56322 : List Nat := [2,0,8,1,11,1,8,1,512,11,1,522,8,512,1,3,512,11,11,0,522,11,1,2,8,0,0,512,523,11,11,11,1,11,512,513]

theorem envBound56322 : H12AffineFastState.Bounded env56322 := by
  intro p hp
  have h : env56322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56321_56322 : H12AffineEnvironment.transform 1 0 env56321 = env56322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56321 == env56322) = true)

theorem identity56322 : scanCanonicalize (H12AffineFastState.compose env56322 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound56322 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env56323 : List Nat := [2,0,8,1,11,1,8,1,11,11,1,1,8,11,1,3,11,11,11,0,1,11,1,2,8,0,0,11,0,11,11,11,1,11,11,10]

theorem envBound56323 : H12AffineFastState.Bounded env56323 := by
  intro p hp
  have h : env56323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56322_56323 : H12AffineEnvironment.transform 8 11 env56322 = env56323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env56322 == env56323) = true)

theorem identity56323 : scanCanonicalize (H12AffineFastState.compose env56323 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound56323 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56324 : List Nat := [2,0,1,1,2,1,1,1,2,2,1,1,1,2,1,3,2,2,2,0,1,2,1,2,1,0,0,2,0,2,2,2,1,2,2,3]

theorem envBound56324 : H12AffineFastState.Bounded env56324 := by
  intro p hp
  have h : env56324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56323_56324 : H12AffineEnvironment.transform 2 1 env56323 = env56324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env56323 == env56324) = true)

def env56325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38296,35324,1024,32769,45460,41341,41413,98781,8328,65,2049,46276,4096,10400,41992,41461,256,33,46212,99295]

theorem envBound56325 : H12AffineFastState.Bounded env56325 := by
  intro p hp
  have h : env56325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56309_56325 : H12AffineEnvironment.transform 13 5377 env56309 = env56325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56309 == env56325) = true)

theorem identity56325 : scanCanonicalize (H12AffineFastState.compose env56325 (packedSelected [0,1,4,5,7,8,10,16,18,20,22,23,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound56325 : packedSelected [0,1,4,5,7,8,10,16,18,20,22,23,24,31] rootPS < 2^1333 := by decide +kernel

def env56326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8282,38296,35324,1024,32769,45460,41341,41413,41351,8328,65,2049,46276,4096,10400,41992,41461,256,33,46212,41861]

theorem envBound56326 : H12AffineFastState.Bounded env56326 := by
  intro p hp
  have h : env56326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56325_56326 : H12AffineEnvironment.transform 15 8282 env56325 = env56326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env56325 == env56326) = true)

theorem identity56326 : scanCanonicalize (H12AffineFastState.compose env56326 (packedSelected [3,4,7,9,10,18,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound56326 : packedSelected [3,4,7,9,10,18,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8282,13389,10281,1024,8660,4161,168,16,82,8328,65,2049,5393,4096,10400,1501,32,256,33,5457,592]

theorem envBound56327 : H12AffineFastState.Bounded env56327 := by
  intro p hp
  have h : env56327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56326_56327 : H12AffineEnvironment.transform 14 8661 env56326 = env56327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env56326 == env56327) = true)

theorem identity56327 : scanCanonicalize (H12AffineFastState.compose env56327 (packedSelected [2,3,4,5,9,10,11,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound56327 : packedSelected [2,3,4,5,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env56328 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,8192,5377,8492,8282,13389,10281,1024,8493,4161,81,16,82,8305,65,2049,5393,4096,10329,1316,32,256,33,5457,592]

theorem envBound56328 : H12AffineFastState.Bounded env56328 := by
  intro p hp
  have h : env56328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56327_56328 : H12AffineEnvironment.transform 6 121 env56327 = env56328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env56327 == env56328) = true)

theorem identity56328 : scanCanonicalize (H12AffineFastState.compose env56328 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56328 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56329 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,5377,8492,8203,13340,10281,1024,8493,4112,0,16,3,8224,16,2049,5393,4096,10248,1316,32,256,33,5376,513]

theorem envBound56329 : H12AffineFastState.Bounded env56329 := by
  intro p hp
  have h : env56329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56328_56329 : H12AffineEnvironment.transform 5 17 env56328 = env56329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56328 == env56329) = true)

theorem identity56329 : scanCanonicalize (H12AffineFastState.compose env56329 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56329 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56330 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,13340,10249,1024,8461,4112,0,16,3,8192,16,2049,5393,4096,10248,1284,0,256,1,5376,513]

theorem envBound56330 : H12AffineFastState.Bounded env56330 := by
  intro p hp
  have h : env56330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56329_56330 : H12AffineEnvironment.transform 4 0 env56329 = env56330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56329 == env56330) = true)

theorem identity56330 : scanCanonicalize (H12AffineFastState.compose env56330 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound56330 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env56331 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8192,5124,8201,8203,13340,10249,1024,8200,4112,0,16,3,8192,16,2049,5140,4096,10248,1025,0,5,1,5125,513]

theorem envBound56331 : H12AffineFastState.Bounded env56331 := by
  intro p hp
  have h : env56331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56330_56331 : H12AffineEnvironment.transform 7 5 env56330 = env56331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env56330 == env56331) = true)

theorem identity56331 : scanCanonicalize (H12AffineFastState.compose env56331 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound56331 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56332 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5124,1,3,5140,2049,1024,0,4112,0,16,3,8,16,2049,5140,4096,2048,1025,0,5,1,5125,513]

theorem envBound56332 : H12AffineFastState.Bounded env56332 := by
  intro p hp
  have h : env56332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56331_56332 : H12AffineEnvironment.transform 12 8 env56331 = env56332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env56331 == env56332) = true)

theorem identity56332 : scanCanonicalize (H12AffineFastState.compose env56332 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound56332 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56333 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,1044,8,16,1,3,0,2049,1024,0,1028,0,16,3,8,16,2049,0,1044,2048,1025,0,5,1,17,513]

theorem envBound56333 : H12AffineFastState.Bounded env56333 := by
  intro p hp
  have h : env56333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56332_56333 : H12AffineEnvironment.transform 11 1044 env56332 = env56333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env56332 == env56333) = true)

theorem identity56333 : scanCanonicalize (H12AffineFastState.compose env56333 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound56333 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56334 : List Nat := [2,4,8,16,0,17,8,5,512,532,2048,512,8,16,1,3,0,2049,532,0,528,0,16,3,8,16,2049,0,512,2048,533,0,5,1,17,513]

theorem envBound56334 : H12AffineFastState.Bounded env56334 := by
  intro p hp
  have h : env56334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56333_56334 : H12AffineEnvironment.transform 9 532 env56333 = env56334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env56333 == env56334) = true)

theorem identity56334 : scanCanonicalize (H12AffineFastState.compose env56334 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound56334 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56335 : List Nat := [2,4,8,16,0,17,8,5,512,532,17,512,8,16,1,3,0,16,532,0,528,0,16,3,8,16,16,0,512,17,533,0,5,1,17,513]

theorem envBound56335 : H12AffineFastState.Bounded env56335 := by
  intro p hp
  have h : env56335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56334_56335 : H12AffineEnvironment.transform 10 17 env56334 = env56335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env56334 == env56335) = true)

def env56336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,56572,1024,32769,58517,62589,62660,98781,8328,65,2048,57797,17665,32161,61705,62709,256,21792,46212,120542]

theorem envBound56336 : H12AffineFastState.Bounded env56336 := by
  intro p hp
  have h : env56336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56308_56336 : H12AffineEnvironment.transform 16 38297 env56308 = env56336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env56308 == env56336) = true)

def env56337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38297,35324,1024,32769,45461,41341,41412,98781,8328,65,2048,46277,4097,10401,41993,41461,256,32,46212,99294]

theorem envBound56337 : H12AffineFastState.Bounded env56337 := by
  intro p hp
  have h : env56337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56336_56337 : H12AffineEnvironment.transform 13 5376 env56336 = env56337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56336 == env56337) = true)

theorem identity56337 : scanCanonicalize (H12AffineFastState.compose env56337 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56337 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,13508,10401,1024,8540,4296,32,153,73856,8328,65,2048,5528,4097,10401,1364,168,256,32,5593,74371]

theorem envBound56338 : H12AffineFastState.Bounded env56338 := by
  intro p hp
  have h : env56338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56337_56338 : H12AffineEnvironment.transform 14 8541 env56337 = env56338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56337 == env56338) = true)

theorem identity56338 : scanCanonicalize (H12AffineFastState.compose env56338 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound56338 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env56339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,13508,10401,1024,8540,4296,32,153,2,8328,65,2048,5528,4097,10401,1364,168,256,32,5593,513]

theorem envBound56339 : H12AffineFastState.Bounded env56339 := by
  intro p hp
  have h : env56339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56338_56339 : H12AffineEnvironment.transform 15 8322 env56338 = env56339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env56338 == env56339) = true)

theorem identity56339 : scanCanonicalize (H12AffineFastState.compose env56339 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56339 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,80,399,5577,2476,1024,81,4296,32,153,2,389,65,2048,5528,4097,2476,1364,168,256,32,5593,513]

theorem envBound56340 : H12AffineFastState.Bounded env56340 := by
  intro p hp
  have h : env56340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56339_56340 : H12AffineEnvironment.transform 12 269 env56339 = env56340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56339 == env56340) = true)

def env56341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38297,35325,1024,32769,45460,41340,41413,98781,8328,65,2048,46276,4096,10400,41992,41460,256,33,46212,99295]

theorem envBound56341 : H12AffineFastState.Bounded env56341 := by
  intro p hp
  have h : env56341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56336_56341 : H12AffineEnvironment.transform 13 5377 env56336 = env56341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56336 == env56341) = true)

theorem identity56341 : scanCanonicalize (H12AffineFastState.compose env56341 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound56341 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,10281,1024,8661,4160,168,17,73737,8328,65,2048,5392,4096,10400,1500,32,256,33,5456,74251]

theorem envBound56342 : H12AffineFastState.Bounded env56342 := by
  intro p hp
  have h : env56342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56341_56342 : H12AffineEnvironment.transform 14 8660 env56341 = env56342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env56341 == env56342) = true)

theorem identity56342 : scanCanonicalize (H12AffineFastState.compose env56342 (packedSelected [0,1,2,3,4,5,7,8,9,10,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56342 : packedSelected [0,1,2,3,4,5,7,8,9,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env56343 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,65536,13340,10281,1024,8580,4113,168,17,73737,8328,16,2048,5392,4096,10400,1421,32,256,33,5377,74251]

theorem envBound56343 : H12AffineFastState.Bounded env56343 := by
  intro p hp
  have h : env56343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56342_56343 : H12AffineEnvironment.transform 5 17 env56342 = env56343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56342 == env56343) = true)

theorem identity56343 : scanCanonicalize (H12AffineFastState.compose env56343 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound56343 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env56344 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,8322,13340,10281,1024,8580,4113,168,17,139,8328,16,2048,5392,4096,10400,1421,32,256,33,5377,649]

theorem envBound56344 : H12AffineFastState.Bounded env56344 := by
  intro p hp
  have h : env56344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56343_56344 : H12AffineEnvironment.transform 15 8322 env56343 = env56344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env56343 == env56344) = true)

theorem identity56344 : scanCanonicalize (H12AffineFastState.compose env56344 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound56344 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56345 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5377,0,263,5529,2476,1024,1,4113,168,17,139,269,16,2048,5392,4096,2341,1421,32,256,33,5377,649]

theorem envBound56345 : H12AffineFastState.Bounded env56345 := by
  intro p hp
  have h : env56345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56344_56345 : H12AffineEnvironment.transform 12 389 env56344 = env56345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env56344 == env56345) = true)

theorem identity56345 : scanCanonicalize (H12AffineFastState.compose env56345 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56345 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56346 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1024,1,4113,32,17,3,269,16,2048,5392,4096,2341,1285,32,256,33,5377,513]

theorem envBound56346 : H12AffineFastState.Bounded env56346 := by
  intro p hp
  have h : env56346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56345_56346 : H12AffineEnvironment.transform 6 8 env56345 = env56346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56345 == env56346) = true)

theorem identity56346 : scanCanonicalize (H12AffineFastState.compose env56346 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound56346 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56347 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,308,269,1077,0,263,1061,2340,1024,1,293,32,17,3,269,16,2048,1060,308,2341,1285,32,256,33,1077,513]

theorem envBound56347 : H12AffineFastState.Bounded env56347 := by
  intro p hp
  have h : env56347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56346_56347 : H12AffineEnvironment.transform 11 308 env56346 = env56347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env56346 == env56347) = true)

theorem identity56347 : scanCanonicalize (H12AffineFastState.compose env56347 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound56347 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56348 : List Nat := [2,4,8,16,32,17,8,256,512,1024,814,308,269,1077,0,263,1061,522,1024,1,293,32,17,3,269,16,814,1060,308,523,1285,32,256,33,1077,513]

theorem envBound56348 : H12AffineFastState.Bounded env56348 := by
  intro p hp
  have h : env56348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56347_56348 : H12AffineEnvironment.transform 10 814 env56347 = env56348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env56347 == env56348) = true)

theorem identity56348 : scanCanonicalize (H12AffineFastState.compose env56348 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound56348 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56349 : List Nat := [2,4,8,16,32,17,8,256,512,543,814,308,269,554,0,263,570,522,543,1,293,32,17,3,269,16,814,571,308,523,794,32,256,33,554,513]

theorem envBound56349 : H12AffineFastState.Bounded env56349 := by
  intro p hp
  have h : env56349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56348_56349 : H12AffineEnvironment.transform 9 543 env56348 = env56349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env56348 == env56349) = true)

theorem identity56349 : scanCanonicalize (H12AffineFastState.compose env56349 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound56349 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56350 : List Nat := [2,4,8,16,32,17,8,256,303,304,1,308,269,261,0,263,277,293,304,1,293,32,17,3,269,16,1,276,308,292,53,32,256,33,261,302]

theorem envBound56350 : H12AffineFastState.Bounded env56350 := by
  intro p hp
  have h : env56350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56349_56350 : H12AffineEnvironment.transform 8 303 env56349 = env56350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env56349 == env56350) = true)

theorem identity56350 : scanCanonicalize (H12AffineFastState.compose env56350 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound56350 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56351 : List Nat := [2,4,8,16,32,17,8,5,42,53,1,49,8,0,0,2,16,32,53,1,32,32,17,3,8,16,1,17,49,33,53,32,5,33,0,43]

theorem envBound56351 : H12AffineFastState.Bounded env56351 := by
  intro p hp
  have h : env56351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56350_56351 : H12AffineEnvironment.transform 7 5 env56350 = env56351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env56350 == env56351) = true)

theorem identity56351 : scanCanonicalize (H12AffineFastState.compose env56351 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56351 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env56352 : List Nat := [2,4,8,16,1,17,8,5,11,20,1,16,8,0,0,2,16,1,20,1,1,1,17,3,8,16,1,17,16,0,20,1,5,0,0,10]

theorem envBound56352 : H12AffineFastState.Bounded env56352 := by
  intro p hp
  have h : env56352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56351_56352 : H12AffineEnvironment.transform 4 1 env56351 = env56352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56351 == env56352) = true)

theorem identity56352 : scanCanonicalize (H12AffineFastState.compose env56352 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56353 : List Nat := [2,0,8,16,1,17,8,1,11,16,1,16,8,0,0,2,16,1,16,1,1,1,17,3,8,16,1,17,16,0,16,1,1,0,0,10]

theorem envBound56353 : H12AffineFastState.Bounded env56353 := by
  intro p hp
  have h : env56353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56352_56353 : H12AffineEnvironment.transform 1 0 env56352 = env56353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56352 == env56353) = true)

theorem identity56353 : scanCanonicalize (H12AffineFastState.compose env56353 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56354 : List Nat := [1,0,8,16,1,17,8,1,8,16,1,16,8,0,0,1,16,1,16,1,1,1,17,0,8,16,1,17,16,0,16,1,1,0,0,9]

theorem envBound56354 : H12AffineFastState.Bounded env56354 := by
  intro p hp
  have h : env56354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56353_56354 : H12AffineEnvironment.transform 0 1 env56353 = env56354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56353 == env56354) = true)

def env56355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,8388608,8862845,8328,65,4258940,8393984,8845472,8830976,440429,12645453,256,21793,46213,499642]

theorem envBound56355 : H12AffineFastState.Bounded env56355 := by
  intro p hp
  have h : env56355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56219_56355 : H12AffineEnvironment.transform 23 8862845 env56219 = env56355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862845 env56219 == env56355) = true)

def env56356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,441760,98781,8328,65,4258940,436384,17664,32160,440429,4606445,256,21793,46213,499642]

theorem envBound56356 : H12AffineFastState.Bounded env56356 := by
  intro p hp
  have h : env56356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56355_56356 : H12AffineEnvironment.transform 22 441760 env56355 = env56356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env56355 == env56356) = true)

def env56357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272512,441760,98781,8328,65,316668,436384,17664,32160,440429,156013,256,21793,46213,499642]

theorem envBound56357 : H12AffineFastState.Bounded env56357 := by
  intro p hp
  have h : env56357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56356_56357 : H12AffineEnvironment.transform 21 272512 env56356 = env56357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env56356 == env56357) = true)

theorem identity56357 : scanCanonicalize (H12AffineFastState.compose env56357 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound56357 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115870,213486,120014,98781,8328,65,245138,115150,17664,32160,119043,156013,256,21793,46213,63188]

theorem envBound56358 : H12AffineFastState.Bounded env56358 := by
  intro p hp
  have h : env56358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56357_56358 : H12AffineEnvironment.transform 17 223598 env56357 = env56358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env56357 == env56358) = true)

def env56359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130174,1024,32769,115870,120062,120014,98781,8328,65,75906,115150,17664,32160,119043,62589,256,21793,46213,63188]

theorem envBound56359 : H12AffineFastState.Bounded env56359 := by
  intro p hp
  have h : env56359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56358_56359 : H12AffineEnvironment.transform 16 38160 env56358 = env56359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env56358 == env56359) = true)

theorem identity56359 : scanCanonicalize (H12AffineFastState.compose env56359 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound56359 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env56360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25029,67755,1024,29908,77899,73771,73755,95496,8328,65,75906,79131,17664,32160,75222,168,256,21793,16464,513]

theorem envBound56360 : H12AffineFastState.Bounded env56360 := by
  intro p hp
  have h : env56360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56359_56360 : H12AffineEnvironment.transform 14 29909 env56359 = env56360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env56359 == env56360) = true)

theorem identity56360 : scanCanonicalize (H12AffineFastState.compose env56360 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound56360 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env56361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,25029,2421,1024,29908,12693,8693,8645,29910,8328,65,10588,13509,17664,32160,9224,168,256,21793,16464,513]

theorem envBound56361 : H12AffineFastState.Bounded env56361 := by
  intro p hp
  have h : env56361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56360_56361 : H12AffineEnvironment.transform 15 478 env56360 = env56361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env56360 == env56361) = true)

theorem identity56361 : scanCanonicalize (H12AffineFastState.compose env56361 (packedSelected [3,5,8,17,18,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound56361 : packedSelected [3,5,8,17,18,23,28] rootPS < 2^1333 := by decide +kernel

def env56362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,478,13389,2421,1024,8540,12693,8693,8645,8542,8328,65,10588,13509,4232,10280,9224,168,256,169,5592,513]

theorem envBound56362 : H12AffineFastState.Bounded env56362 := by
  intro p hp
  have h : env56362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56361_56362 : H12AffineEnvironment.transform 13 5512 env56361 = env56362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env56361 == env56362) = true)

theorem identity56362 : scanCanonicalize (H12AffineFastState.compose env56362 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound56362 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,478,5529,2421,1024,136,4161,33,17,138,348,65,2184,5393,4232,2556,1500,168,256,169,5592,513]

theorem envBound56363 : H12AffineFastState.Bounded env56363 := by
  intro p hp
  have h : env56363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56362_56363 : H12AffineEnvironment.transform 12 468 env56362 = env56363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env56362 == env56363) = true)

theorem identity56363 : scanCanonicalize (H12AffineFastState.compose env56363 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56363 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56364 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5512,137,399,5529,2340,1024,136,4112,33,17,138,269,16,2184,5393,4232,2477,1421,168,256,169,5513,513]

theorem envBound56364 : H12AffineFastState.Bounded env56364 := by
  intro p hp
  have h : env56364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56363_56364 : H12AffineEnvironment.transform 5 17 env56363 = env56364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56363 == env56364) = true)

theorem identity56364 : scanCanonicalize (H12AffineFastState.compose env56364 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound56364 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56365 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,773,389,1677,137,399,1692,2340,1024,136,789,33,17,138,269,16,2184,1556,909,2477,1421,168,256,169,1676,513]

theorem envBound56365 : H12AffineFastState.Bounded env56365 := by
  intro p hp
  have h : env56365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56364_56365 : H12AffineEnvironment.transform 11 773 env56364 = env56365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env56364 == env56365) = true)

theorem identity56365 : scanCanonicalize (H12AffineFastState.compose env56365 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound56365 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env56366 : List Nat := [2,4,8,16,32,17,128,256,512,1024,821,773,389,1677,137,399,1692,529,1024,136,789,33,17,138,269,16,957,1556,909,664,1421,168,256,169,1676,513]

theorem envBound56366 : H12AffineFastState.Bounded env56366 := by
  intro p hp
  have h : env56366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56365_56366 : H12AffineEnvironment.transform 10 821 env56365 = env56366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env56365 == env56366) = true)

theorem identity56366 : scanCanonicalize (H12AffineFastState.compose env56366 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound56366 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env56367 : List Nat := [2,4,8,16,32,17,128,52,512,1024,513,561,177,1677,137,187,1692,529,1024,136,545,33,17,138,57,16,649,1556,697,664,1209,168,52,169,1676,513]

theorem envBound56367 : H12AffineFastState.Bounded env56367 := by
  intro p hp
  have h : env56367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56366_56367 : H12AffineEnvironment.transform 7 52 env56366 = env56367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env56366 == env56367) = true)

theorem identity56367 : scanCanonicalize (H12AffineFastState.compose env56367 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound56367 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env56368 : List Nat := [2,4,8,16,32,17,128,52,512,156,513,561,177,529,137,187,512,529,156,136,545,33,17,138,57,16,649,648,697,664,37,168,52,169,528,513]

theorem envBound56368 : H12AffineFastState.Bounded env56368 := by
  intro p hp
  have h : env56368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56367_56368 : H12AffineEnvironment.transform 9 156 env56367 = env56368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env56367 == env56368) = true)

def env56369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,130175,1024,32769,115870,120063,120014,98781,8328,65,75907,115150,17664,32160,119043,62588,256,21793,46213,63188]

theorem envBound56369 : H12AffineFastState.Bounded env56369 := by
  intro p hp
  have h : env56369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56358_56369 : H12AffineEnvironment.transform 16 38161 env56358 = env56369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env56358 == env56369) = true)

theorem identity56369 : scanCanonicalize (H12AffineFastState.compose env56369 (packedSelected [0,1,4,5,7,8,10,15,16,18,20,22,23,24,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound56369 : packedSelected [0,1,4,5,7,8,10,15,16,18,20,22,23,24,31,38] rootPS < 2^1333 := by decide +kernel

def env56370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,80,65536,5441,97327,1024,81,83150,87215,87198,65933,8328,65,75907,82334,17664,32160,86355,29740,256,21793,13525,30340]

theorem envBound56370 : H12AffineFastState.Bounded env56370 := by
  intro p hp
  have h : env56370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56369_56370 : H12AffineEnvironment.transform 14 80 env56369 = env56370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env56369 == env56370) = true)

theorem identity56370 : scanCanonicalize (H12AffineFastState.compose env56370 (packedSelected [1,10,16,20,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound56370 : packedSelected [1,10,16,20,26,28] rootPS < 2^1333 := by decide +kernel

def env56371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,80,263,5441,32040,1024,81,17865,21928,21913,138,8328,65,10628,16537,17664,32160,20564,29740,256,21793,13525,30340]

theorem envBound56371 : H12AffineFastState.Bounded env56371 := by
  intro p hp
  have h : env56371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56370_56371 : H12AffineEnvironment.transform 15 263 env56370 = env56371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env56370 == env56371) = true)

theorem identity56371 : scanCanonicalize (H12AffineFastState.compose env56371 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56371 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env56372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,80,263,5441,23588,1024,81,17865,21928,21913,138,388,65,2184,16537,17664,23724,20564,21792,256,21793,5593,22408]

theorem envBound56372 : H12AffineFastState.Bounded env56372 := by
  intro p hp
  have h : env56372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56371_56372 : H12AffineEnvironment.transform 12 268 env56371 = env56372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56371 == env56372) = true)

theorem identity56372 : scanCanonicalize (H12AffineFastState.compose env56372 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56372 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env56373 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,1,263,5392,23588,1024,0,17816,21928,21913,138,388,16,2184,16537,17664,23724,20485,21792,256,21793,5512,22408]

theorem envBound56373 : H12AffineFastState.Bounded env56373 := by
  intro p hp
  have h : env56373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56372_56373 : H12AffineEnvironment.transform 5 17 env56372 = env56373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56372 == env56373) = true)

theorem identity56373 : scanCanonicalize (H12AffineFastState.compose env56373 (packedSelected [0,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56373 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env56374 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,5392,23588,1024,0,17680,21792,21777,2,268,16,2048,16401,17664,23588,20485,21792,256,21793,5376,22272]

theorem envBound56374 : H12AffineFastState.Bounded env56374 := by
  intro p hp
  have h : env56374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56373_56374 : H12AffineEnvironment.transform 6 8 env56373 = env56374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56373 == env56374) = true)

theorem identity56374 : scanCanonicalize (H12AffineFastState.compose env56374 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound56374 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env56375 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5156,1,263,5392,2048,1024,0,4404,260,309,2,268,16,2048,5173,4388,2048,1057,260,256,261,5376,804]

theorem envBound56375 : H12AffineFastState.Bounded env56375 := by
  intro p hp
  have h : env56375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56374_56375 : H12AffineEnvironment.transform 13 5156 env56374 = env56375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env56374 == env56375) = true)

theorem identity56375 : scanCanonicalize (H12AffineFastState.compose env56375 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56375 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env56376 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5173,2048,1024,0,4113,33,16,2,41,16,2048,5173,4097,2048,1057,33,37,32,5157,513]

theorem envBound56376 : H12AffineFastState.Bounded env56376 := by
  intro p hp
  have h : env56376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56375_56376 : H12AffineEnvironment.transform 7 37 env56375 = env56376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56375 == env56376) = true)

theorem identity56376 : scanCanonicalize (H12AffineFastState.compose env56376 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound56376 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56377 : List Nat := [2,4,8,16,32,17,8,37,512,1024,522,4096,41,5156,1,34,5173,522,1024,0,4113,33,16,2,41,16,522,5173,4097,522,1057,33,37,32,5157,513]

theorem envBound56377 : H12AffineFastState.Bounded env56377 := by
  intro p hp
  have h : env56377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56376_56377 : H12AffineEnvironment.transform 10 522 env56376 = env56377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env56376 == env56377) = true)

theorem identity56377 : scanCanonicalize (H12AffineFastState.compose env56377 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56377 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56378 : List Nat := [2,4,8,16,1,17,8,4,512,1024,522,4096,8,5125,1,3,5140,522,1024,0,4113,0,16,2,8,16,522,5140,4097,522,1024,0,4,1,5124,513]

theorem envBound56378 : H12AffineFastState.Bounded env56378 := by
  intro p hp
  have h : env56378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56377_56378 : H12AffineEnvironment.transform 4 1 env56377 = env56378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56377 == env56378) = true)

def env56379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272513,441760,98781,8328,65,316669,436384,17664,32160,440429,156012,256,21793,46213,499642]

theorem envBound56379 : H12AffineFastState.Bounded env56379 := by
  intro p hp
  have h : env56379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56356_56379 : H12AffineEnvironment.transform 21 272513 env56356 = env56379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env56356 == env56379) = true)

theorem identity56379 : scanCanonicalize (H12AffineFastState.compose env56379 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound56379 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,437744,272513,441760,21763,8328,65,316669,436384,17664,32160,440429,156012,256,21793,46213,412516]

theorem envBound56380 : H12AffineFastState.Bounded env56380 := by
  intro p hp
  have h : env56380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56379_56380 : H12AffineEnvironment.transform 15 54494 env56379 = env56380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env56379 == env56380) = true)

def env56381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,437624,272393,441640,21763,8192,65,316533,436264,17664,32040,440429,156012,256,21793,46093,412516]

theorem envBound56381 : H12AffineFastState.Bounded env56381 := by
  intro p hp
  have h : env56381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56380_56381 : H12AffineEnvironment.transform 6 8 env56380 = env56381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56380 == env56381) = true)

theorem identity56381 : scanCanonicalize (H12AffineFastState.compose env56381 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound56381 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env56382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,165201,32,169217,21763,8192,65,64604,163841,17664,32040,168004,156012,256,21793,46093,156493]

theorem envBound56382 : H12AffineFastState.Bounded env56382 := by
  intro p hp
  have h : env56382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56381_56382 : H12AffineEnvironment.transform 17 10281 env56381 = env56382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56381 == env56382) = true)

theorem identity56382 : scanCanonicalize (H12AffineFastState.compose env56382 (packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound56382 : packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env56383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,10281,1024,32769,17728,32,21776,21763,8192,65,64604,16400,17664,32040,20565,41341,256,21793,46093,41820]

theorem envBound56383 : H12AffineFastState.Bounded env56383 := by
  intro p hp
  have h : env56383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56382_56383 : H12AffineEnvironment.transform 16 49169 env56382 = env56383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env56382 == env56383) = true)

theorem identity56383 : scanCanonicalize (H12AffineFastState.compose env56383 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56383 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,24908,10281,1024,8540,17728,32,21776,21763,8192,65,23809,16400,17664,32040,20565,32,256,21793,5456,513]

theorem envBound56384 : H12AffineFastState.Bounded env56384 := by
  intro p hp
  have h : env56384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56383_56384 : H12AffineEnvironment.transform 14 8541 env56383 = env56384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56383 == env56384) = true)

theorem identity56384 : scanCanonicalize (H12AffineFastState.compose env56384 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56384 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env56385 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,29963,24861,10281,1024,8461,17681,32,21776,21763,8192,16,23809,16400,17664,32040,20484,32,256,21793,5377,513]

theorem envBound56385 : H12AffineFastState.Bounded env56385 := by
  intro p hp
  have h : env56385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56384_56385 : H12AffineEnvironment.transform 5 17 env56384 = env56385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56384 == env56385) = true)

theorem identity56385 : scanCanonicalize (H12AffineFastState.compose env56385 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56385 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env56386 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,21510,16400,2340,1024,0,17681,32,21776,21763,269,16,23809,16400,17664,23589,20484,32,256,21793,5377,513]

theorem envBound56386 : H12AffineFastState.Bounded env56386 := by
  intro p hp
  have h : env56386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56385_56386 : H12AffineEnvironment.transform 12 269 env56385 = env56386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56385 == env56386) = true)

def env56387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,437625,272392,441641,21763,8193,65,316532,436265,17664,32041,440429,156012,256,21793,46092,412516]

theorem envBound56387 : H12AffineFastState.Bounded env56387 := by
  intro p hp
  have h : env56387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56380_56387 : H12AffineEnvironment.transform 6 9 env56380 = env56387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56380 == env56387) = true)

theorem identity56387 : scanCanonicalize (H12AffineFastState.compose env56387 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56387 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env56388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54359,131072,262144,1024,32769,429092,264533,433268,21763,348,65,316532,428404,17664,23668,432432,147505,256,21793,38225,412516]

theorem envBound56388 : H12AffineFastState.Bounded env56388 := by
  intro p hp
  have h : env56388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56387_56388 : H12AffineEnvironment.transform 12 349 env56387 = env56388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56387 == env56388) = true)

theorem identity56388 : scanCanonicalize (H12AffineFastState.compose env56388 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 182629) := by decide +kernel

theorem selectedBound56388 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54359,131072,182629,1024,32769,17729,180272,21777,21763,348,65,138513,16401,17664,23668,20565,147505,256,21793,38225,33281]

theorem envBound56389 : H12AffineFastState.Bounded env56389 := by
  intro p hp
  have h : env56389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56388_56389 : H12AffineEnvironment.transform 17 182629 env56388 = env56389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env56388 == env56389) = true)

theorem identity56389 : scanCanonicalize (H12AffineFastState.compose env56389 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound56389 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env56390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54359,5393,56436,1024,32769,17729,54561,21777,21763,348,65,2048,16401,17664,23668,20565,21792,256,21793,38225,33281]

theorem envBound56390 : H12AffineFastState.Bounded env56390 := by
  intro p hp
  have h : env56390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56389_56390 : H12AffineEnvironment.transform 16 5393 env56389 = env56390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env56389 == env56390) = true)

theorem identity56390 : scanCanonicalize (H12AffineFastState.compose env56390 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56390 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env56391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,33111,5393,35188,1024,32769,4161,32801,17,3,348,65,2048,5393,4096,2420,1365,32,256,33,38225,33281]

theorem envBound56391 : H12AffineFastState.Bounded env56391 := by
  intro p hp
  have h : env56391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56390_56391 : H12AffineEnvironment.transform 13 5376 env56390 = env56391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56390 == env56391) = true)

theorem identity56391 : scanCanonicalize (H12AffineFastState.compose env56391 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound56391 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env56392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,349,2340,32768,33111,2357,35188,1024,32769,3173,32801,17,3,348,65,2048,2357,3108,2420,1365,32,256,33,35189,33281]

theorem envBound56392 : H12AffineFastState.Bounded env56392 := by
  intro p hp
  have h : env56392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56391_56392 : H12AffineEnvironment.transform 11 3108 env56391 = env56392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env56391 == env56392) = true)

theorem identity56392 : scanCanonicalize (H12AffineFastState.compose env56392 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 3700) := by decide +kernel

theorem selectedBound56392 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env56393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3108,349,2340,3700,3875,2357,1792,1024,3701,3173,3669,17,3,348,65,2048,2357,3108,2420,1365,32,256,33,1793,3189]

theorem envBound56393 : H12AffineFastState.Bounded env56393 := by
  intro p hp
  have h : env56393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56392_56393 : H12AffineEnvironment.transform 14 3700 env56392 = env56393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3700 env56392 == env56393) = true)

theorem identity56393 : scanCanonicalize (H12AffineFastState.compose env56393 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56393 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env56394 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3108,120,2049,3700,3590,2064,1573,1024,3701,3173,3669,17,3,121,65,2048,2064,3108,2129,1136,32,37,33,1572,3189]

theorem envBound56394 : H12AffineFastState.Bounded env56394 := by
  intro p hp
  have h : env56394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56393_56394 : H12AffineEnvironment.transform 7 37 env56393 = env56394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56393 == env56394) = true)

theorem identity56394 : scanCanonicalize (H12AffineFastState.compose env56394 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound56394 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env56395 : List Nat := [2,4,8,16,32,64,9,37,512,1024,80,1140,120,81,1572,1622,64,1573,1024,1573,1077,1541,17,3,121,65,80,64,1140,1,1136,32,37,33,1572,1061]

theorem envBound56395 : H12AffineFastState.Bounded env56395 := by
  intro p hp
  have h : env56395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56394_56395 : H12AffineEnvironment.transform 10 80 env56394 = env56395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env56394 == env56395) = true)

theorem identity56395 : scanCanonicalize (H12AffineFastState.compose env56395 (packedSelected [0,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound56395 : packedSelected [0,6,9] rootPS < 2^1333 := by decide +kernel

def env56396 : List Nat := [2,4,8,16,32,64,9,37,512,36,80,80,120,81,512,626,64,513,36,513,17,545,17,3,121,65,80,64,80,1,84,32,37,33,512,1]

theorem envBound56396 : H12AffineFastState.Bounded env56396 := by
  intro p hp
  have h : env56396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56395_56396 : H12AffineEnvironment.transform 9 36 env56395 = env56396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env56395 == env56396) = true)

theorem identity56396 : scanCanonicalize (H12AffineFastState.compose env56396 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56396 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env56397 : List Nat := [2,4,8,16,32,16,9,37,512,36,0,0,40,1,512,546,16,513,36,513,17,545,17,3,41,17,0,16,0,1,4,32,37,33,512,1]

theorem envBound56397 : H12AffineFastState.Bounded env56397 := by
  intro p hp
  have h : env56397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56396_56397 : H12AffineEnvironment.transform 5 16 env56396 = env56397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56396 == env56397) = true)

theorem identity56397 : scanCanonicalize (H12AffineFastState.compose env56397 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56397 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56398 : List Nat := [2,4,8,0,32,0,9,37,512,36,0,0,40,1,512,546,0,513,36,513,1,545,1,3,41,1,0,0,0,1,4,32,37,33,512,1]

theorem envBound56398 : H12AffineFastState.Bounded env56398 := by
  intro p hp
  have h : env56398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56397_56398 : H12AffineEnvironment.transform 3 0 env56397 = env56398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56397 == env56398) = true)

theorem identity56398 : scanCanonicalize (H12AffineFastState.compose env56398 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56398 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env56399 : List Nat := [2,4,8,0,32,0,9,37,0,36,0,0,40,1,0,34,0,1,36,1,1,33,1,3,41,1,0,0,0,1,4,32,37,33,0,1]

theorem envBound56399 : H12AffineFastState.Bounded env56399 := by
  intro p hp
  have h : env56399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56398_56399 : H12AffineEnvironment.transform 8 0 env56398 = env56399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56398 == env56399) = true)

theorem identity56399 : scanCanonicalize (H12AffineFastState.compose env56399 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56400 : List Nat := [2,4,8,0,10,0,9,15,0,14,0,0,2,1,0,8,0,1,14,1,1,11,1,3,3,1,0,0,0,1,4,10,15,11,0,1]

theorem envBound56400 : H12AffineFastState.Bounded env56400 := by
  intro p hp
  have h : env56400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56399_56400 : H12AffineEnvironment.transform 4 10 env56399 = env56400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56399 == env56400) = true)

def env56401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,441761,98780,8328,65,4258940,436385,17665,32161,440429,4606444,256,21793,46213,499642]

theorem envBound56401 : H12AffineFastState.Bounded env56401 := by
  intro p hp
  have h : env56401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56355_56401 : H12AffineEnvironment.transform 22 441761 env56355 = env56401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env56355 == env56401) = true)

def env56402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272512,441761,98780,8328,65,316668,436385,17665,32161,440429,156012,256,21793,46213,499642]

theorem envBound56402 : H12AffineFastState.Bounded env56402 := by
  intro p hp
  have h : env56402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56401_56402 : H12AffineEnvironment.transform 21 272512 env56401 = env56402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env56401 == env56402) = true)

theorem identity56402 : scanCanonicalize (H12AffineFastState.compose env56402 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236987) := by decide +kernel

theorem selectedBound56402 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236987,1024,32769,77899,243003,73754,98780,8328,65,215367,79130,17665,32161,75222,156012,256,21793,46213,513]

theorem envBound56403 : H12AffineFastState.Bounded env56403 := by
  intro p hp
  have h : env56403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56402_56403 : H12AffineEnvironment.transform 17 236987 env56402 = env56403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236987 env56402 == env56403) = true)

def env56404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,77899,243003,73754,98644,8192,65,215367,79130,17665,32041,75102,156012,256,21793,46093,513]

theorem envBound56404 : H12AffineFastState.Bounded env56404 := by
  intro p hp
  have h : env56404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56403_56404 : H12AffineEnvironment.transform 6 8 env56403 = env56404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56403 == env56404) = true)

theorem identity56404 : scanCanonicalize (H12AffineFastState.compose env56404 (packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound56404 : packedSelected [0,2,3,4,6,9,10,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,64808,1024,32769,77899,54560,73754,98644,8192,65,10588,79130,17665,32041,75102,65911,256,21793,46093,513]

theorem envBound56405 : H12AffineFastState.Bounded env56405 := by
  intro p hp
  have h : env56405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56404_56405 : H12AffineEnvironment.transform 16 90139 env56404 = env56405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env56404 == env56405) = true)

theorem identity56405 : scanCanonicalize (H12AffineFastState.compose env56405 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound56405 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env56406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46157,64808,1024,32769,58397,54560,62540,21762,8192,65,10588,57676,17665,32041,61704,54561,256,21793,46093,513]

theorem envBound56406 : H12AffineFastState.Bounded env56406 := by
  intro p hp
  have h : env56406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56405_56406 : H12AffineEnvironment.transform 15 54358 env56405 = env56406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env56405 == env56406) = true)

theorem identity56406 : scanCanonicalize (H12AffineFastState.compose env56406 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound56406 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env56407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16400,2421,1024,29788,4160,8573,17,21762,8192,65,10588,5393,17665,32041,1365,8572,256,21793,16464,513]

theorem envBound56407 : H12AffineFastState.Bounded env56407 := by
  intro p hp
  have h : env56407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56406_56407 : H12AffineEnvironment.transform 14 29789 env56406 = env56407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env56406 == env56407) = true)

theorem identity56407 : scanCanonicalize (H12AffineFastState.compose env56407 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56407 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5392,2421,1024,8540,4160,8573,17,2,8192,65,10588,5393,4097,10281,1365,8572,256,33,5456,513]

theorem envBound56408 : H12AffineFastState.Bounded env56408 := by
  intro p hp
  have h : env56408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56407_56408 : H12AffineEnvironment.transform 13 5376 env56407 = env56408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56407 == env56408) = true)

theorem identity56408 : scanCanonicalize (H12AffineFastState.compose env56408 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56408 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,263,5392,2421,1024,80,4160,113,17,2,268,65,2128,5393,4097,2341,1365,112,256,33,5456,513]

theorem envBound56409 : H12AffineFastState.Bounded env56409 := by
  intro p hp
  have h : env56409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56408_56409 : H12AffineEnvironment.transform 12 268 env56408 = env56409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56408 == env56409) = true)

theorem identity56409 : scanCanonicalize (H12AffineFastState.compose env56409 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56409 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env56410 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1024,0,4112,33,17,2,268,17,2048,5393,4097,2341,1285,32,256,33,5376,513]

theorem envBound56410 : H12AffineFastState.Bounded env56410 := by
  intro p hp
  have h : env56410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56409_56410 : H12AffineEnvironment.transform 5 16 env56409 = env56410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56409 == env56410) = true)

theorem identity56410 : scanCanonicalize (H12AffineFastState.compose env56410 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56410 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56411 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,1,35,5172,2049,1024,0,4112,33,17,2,40,17,2048,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound56411 : H12AffineFastState.Bounded env56411 := by
  intro p hp
  have h : env56411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56410_56411 : H12AffineEnvironment.transform 7 36 env56410 = env56411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56410 == env56411) = true)

def env56412 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1044,1,35,1028,2049,1024,0,32,33,17,2,40,17,2048,1029,49,2049,1057,32,36,33,1044,513]

theorem envBound56412 : H12AffineFastState.Bounded env56412 := by
  intro p hp
  have h : env56412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56411_56412 : H12AffineEnvironment.transform 11 48 env56411 = env56412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env56411 == env56412) = true)

theorem identity56412 : scanCanonicalize (H12AffineFastState.compose env56412 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound56412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56413 : List Nat := [2,4,8,16,32,16,8,36,512,516,2048,48,40,528,1,35,512,2049,516,0,32,33,17,2,40,17,2048,513,49,2049,549,32,36,33,528,513]

theorem envBound56413 : H12AffineFastState.Bounded env56413 := by
  intro p hp
  have h : env56413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56412_56413 : H12AffineEnvironment.transform 9 516 env56412 = env56413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env56412 == env56413) = true)

def env56414 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,48,40,32,1,35,48,2049,52,0,32,33,17,2,40,17,2048,49,49,2049,21,32,36,33,32,49]

theorem envBound56414 : H12AffineFastState.Bounded env56414 := by
  intro p hp
  have h : env56414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56413_56414 : H12AffineEnvironment.transform 8 48 env56413 = env56414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56413 == env56414) = true)

theorem identity56414 : scanCanonicalize (H12AffineFastState.compose env56414 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56415 : List Nat := [2,4,8,11,32,11,8,36,43,47,2048,43,40,32,1,35,43,2049,47,0,32,33,10,2,40,10,2048,42,42,2049,14,32,36,33,32,42]

theorem envBound56415 : H12AffineFastState.Bounded env56415 := by
  intro p hp
  have h : env56415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56414_56415 : H12AffineEnvironment.transform 3 11 env56414 = env56415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56414 == env56415) = true)

def leafEnv56415 : List Nat := [2,4,8,11,32,11,8,36,43,47,2048,43,40,32,1,35,43,2049,47,0,32,33,10,2,14,40,1,10,2048,42,42,2049,14,32,36,33,4,35,32,42,1,32,0]

def active56415 : List Nat := [0,1,2,4,10]

def tree56415 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56415 : H12WitnessSearch.Good tree56415 := H12GlobalWitnessIndex.good

theorem leafIdentity56415 : H12AffineFastState.composeSystem env56415 rootObs = leafEnv56415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56415 rootObs == leafEnv56415) = true)

theorem terminalChecked56415 : H12PackedTerminal.terminalCheckFast leafEnv56415 active56415 tree56415 = true := by decide +kernel

def env56416 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,48,40,33,1,35,49,2049,53,0,32,33,17,2,40,17,2048,48,49,2049,20,32,36,33,33,48]

theorem envBound56416 : H12AffineFastState.Bounded env56416 := by
  intro p hp
  have h : env56416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56413_56416 : H12AffineEnvironment.transform 8 49 env56413 = env56416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56413 == env56416) = true)

def env56417 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1045,1,35,1029,2049,1024,0,33,33,17,2,40,17,2048,1028,48,2049,1057,32,36,33,1045,513]

theorem envBound56417 : H12AffineFastState.Bounded env56417 := by
  intro p hp
  have h : env56417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56411_56417 : H12AffineEnvironment.transform 11 49 env56411 = env56417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env56411 == env56417) = true)

theorem identity56417 : scanCanonicalize (H12AffineFastState.compose env56417 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound56417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56418 : List Nat := [2,4,8,16,32,16,8,36,49,1024,2048,49,40,1045,1,35,1029,2049,1024,0,33,33,17,2,40,17,2048,1028,48,2049,1057,32,36,33,1045,48]

theorem envBound56418 : H12AffineFastState.Bounded env56418 := by
  intro p hp
  have h : env56418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56417_56418 : H12AffineEnvironment.transform 8 49 env56417 = env56418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56417 == env56418) = true)

def env56419 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,49,40,33,1,35,49,2049,52,0,33,33,17,2,40,17,2048,48,48,2049,21,32,36,33,33,48]

theorem envBound56419 : H12AffineFastState.Bounded env56419 := by
  intro p hp
  have h : env56419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56418_56419 : H12AffineEnvironment.transform 9 52 env56418 = env56419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56418 == env56419) = true)

theorem identity56419 : scanCanonicalize (H12AffineFastState.compose env56419 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56419 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56420 : List Nat := [2,4,8,11,32,11,8,36,42,47,2048,42,40,33,1,35,42,2049,47,0,33,33,10,2,40,10,2048,43,43,2049,14,32,36,33,33,43]

theorem envBound56420 : H12AffineFastState.Bounded env56420 := by
  intro p hp
  have h : env56420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56419_56420 : H12AffineEnvironment.transform 3 11 env56419 = env56420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56419 == env56420) = true)

def leafEnv56420 : List Nat := [2,4,8,11,32,11,8,36,42,47,2048,42,40,33,1,35,42,2049,47,0,33,33,10,2,14,40,1,10,2048,43,43,2049,14,32,36,33,4,35,33,43,1,33,0]

def active56420 : List Nat := [0,1,2,4,10]

def tree56420 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56420 : H12WitnessSearch.Good tree56420 := H12GlobalWitnessIndex.good

theorem leafIdentity56420 : H12AffineFastState.composeSystem env56420 rootObs = leafEnv56420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56420 rootObs == leafEnv56420) = true)

theorem terminalChecked56420 : H12PackedTerminal.terminalCheckFast leafEnv56420 active56420 tree56420 = true := by decide +kernel

def env56421 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,49,40,32,1,35,48,2049,53,0,33,33,17,2,40,17,2048,49,48,2049,20,32,36,33,32,48]

theorem envBound56421 : H12AffineFastState.Bounded env56421 := by
  intro p hp
  have h : env56421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56418_56421 : H12AffineEnvironment.transform 9 53 env56418 = env56421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56418 == env56421) = true)

def env56422 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,77899,243003,73754,98645,8193,65,215367,79130,17665,32040,75103,156012,256,21793,46092,513]

theorem envBound56422 : H12AffineFastState.Bounded env56422 := by
  intro p hp
  have h : env56422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56403_56422 : H12AffineEnvironment.transform 6 9 env56403 = env56422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56403 == env56422) = true)

theorem identity56422 : scanCanonicalize (H12AffineFastState.compose env56422 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound56422 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env56423 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,64809,1024,32769,77899,54560,73754,98645,8193,65,10588,79130,17665,32040,75103,65911,256,21793,46092,513]

theorem envBound56423 : H12AffineFastState.Bounded env56423 := by
  intro p hp
  have h : env56423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56422_56423 : H12AffineEnvironment.transform 16 90139 env56422 = env56423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env56422 == env56423) = true)

theorem identity56423 : scanCanonicalize (H12AffineFastState.compose env56423 (packedSelected [0,2,4,6,9,18,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound56423 : packedSelected [0,2,4,6,9,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env56424 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,1047,25612,64809,1024,32769,13404,54560,9229,34114,8193,65,10588,12557,17665,32040,8520,1376,256,21793,46092,513]

theorem envBound56424 : H12AffineFastState.Bounded env56424 := by
  intro p hp
  have h : env56424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56423_56424 : H12AffineEnvironment.transform 15 1047 env56423 = env56424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env56423 == env56424) = true)

theorem identity56424 : scanCanonicalize (H12AffineFastState.compose env56424 (packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56424 : packedSelected [2,3,4,5,6,9,10,12,14,17,20,38] rootPS < 2^1333 := by decide +kernel

def env56425 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,1047,25612,64605,1024,32769,13404,54356,9229,33846,8193,65,10280,12409,17525,31836,8252,1044,116,21589,46092,513]

theorem envBound56425 : H12AffineFastState.Bounded env56425 := by
  intro p hp
  have h : env56425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56424_56425 : H12AffineEnvironment.transform 7 116 env56424 = env56425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56424 == env56425) = true)

theorem identity56425 : scanCanonicalize (H12AffineFastState.compose env56425 (packedSelected [1,2,3,6,11,12,15,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 28777) := by decide +kernel

theorem selectedBound56425 : packedSelected [1,2,3,6,11,12,15,23,24,28] rootPS < 2^1333 := by decide +kernel

def env56426 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,28777,1047,25612,3124,1024,28776,13404,9277,9229,29791,8193,65,10280,12409,17525,31836,8252,1044,116,21589,17509,513]

theorem envBound56426 : H12AffineFastState.Bounded env56426 := by
  intro p hp
  have h : env56426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56425_56426 : H12AffineEnvironment.transform 14 28777 env56425 = env56426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28777 env56425 == env56426) = true)

theorem identity56426 : scanCanonicalize (H12AffineFastState.compose env56426 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound56426 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56427 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13404,1077,1047,4176,3124,1024,1076,13404,9277,9229,3,8193,65,10280,12409,12329,2048,8252,1044,116,8201,12345,513]

theorem envBound56427 : H12AffineFastState.Bounded env56427 := by
  intro p hp
  have h : env56427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56426_56427 : H12AffineEnvironment.transform 13 13404 env56426 = env56427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env56426 == env56427) = true)

theorem identity56427 : scanCanonicalize (H12AffineFastState.compose env56427 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56427 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56428 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,13325,1077,1047,4097,3124,1024,1076,13325,9277,9229,3,8193,16,10280,12328,12329,2048,8252,1044,37,8201,12345,513]

theorem envBound56428 : H12AffineFastState.Bounded env56428 := by
  intro p hp
  have h : env56428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56427_56428 : H12AffineEnvironment.transform 5 17 env56427 = env56428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56427 == env56428) = true)

theorem identity56428 : scanCanonicalize (H12AffineFastState.compose env56428 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound56428 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env56429 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,1052,4113,1077,1047,4097,3124,1024,1076,4113,33,17,3,1053,16,3124,5172,5173,2048,1056,1044,37,1045,5157,513]

theorem envBound56429 : H12AffineFastState.Bounded env56429 := by
  intro p hp
  have h : env56429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56428_56429 : H12AffineEnvironment.transform 12 1052 env56428 = env56429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env56428 == env56429) = true)

theorem identity56429 : scanCanonicalize (H12AffineFastState.compose env56429 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound56429 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56430 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,1,35,4097,2048,52,0,4113,33,17,3,41,16,2048,4096,4097,2048,20,32,37,33,4113,513]

theorem envBound56430 : H12AffineFastState.Bounded env56430 := by
  intro p hp
  have h : env56430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56429_56430 : H12AffineEnvironment.transform 9 52 env56429 = env56430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56429 == env56430) = true)

theorem identity56430 : scanCanonicalize (H12AffineFastState.compose env56430 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound56430 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56431 : List Nat := [2,4,8,16,32,17,9,37,512,52,561,4096,40,4113,1,35,4097,561,52,0,4113,33,17,3,41,16,561,4096,4097,561,20,32,37,33,4113,513]

theorem envBound56431 : H12AffineFastState.Bounded env56431 := by
  intro p hp
  have h : env56431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56430_56431 : H12AffineEnvironment.transform 10 561 env56430 = env56431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env56430 == env56431) = true)

theorem identity56431 : scanCanonicalize (H12AffineFastState.compose env56431 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound56431 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56432 : List Nat := [2,4,8,16,32,17,9,37,48,52,1,4096,40,4113,1,35,4097,1,52,0,4113,33,17,3,41,16,1,4096,4097,1,20,32,37,33,4113,49]

theorem envBound56432 : H12AffineFastState.Bounded env56432 := by
  intro p hp
  have h : env56432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56431_56432 : H12AffineEnvironment.transform 8 48 env56431 = env56432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56431 == env56432) = true)

def env56433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272513,441761,98780,8328,65,316669,436385,17665,32161,440429,156013,256,21793,46213,499642]

theorem envBound56433 : H12AffineFastState.Bounded env56433 := by
  intro p hp
  have h : env56433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56401_56433 : H12AffineEnvironment.transform 21 272513 env56401 = env56433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env56401 == env56433) = true)

theorem identity56433 : scanCanonicalize (H12AffineFastState.compose env56433 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56433 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437744,272513,441761,41430,8328,65,316669,436385,17665,32161,440429,156013,256,21793,46213,442288]

theorem envBound56434 : H12AffineFastState.Bounded env56434 := by
  intro p hp
  have h : env56434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56433_56434 : H12AffineEnvironment.transform 15 8202 env56433 = env56434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56433 == env56434) = true)

def env56435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437624,272393,441641,41310,8192,65,316533,436265,17665,32041,440429,156013,256,21793,46093,442168]

theorem envBound56435 : H12AffineFastState.Bounded env56435 := by
  intro p hp
  have h : env56435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56434_56435 : H12AffineEnvironment.transform 6 8 env56434 = env56435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56434 == env56435) = true)

theorem identity56435 : scanCanonicalize (H12AffineFastState.compose env56435 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound56435 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env56436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1024,32769,276585,272393,272440,41310,8192,65,316533,277816,17665,32041,273788,62588,256,21793,46093,272937]

theorem envBound56436 : H12AffineFastState.Bounded env56436 := by
  intro p hp
  have h : env56436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56435_56436 : H12AffineEnvironment.transform 16 38161 env56435 = env56436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env56435 == env56436) = true)

theorem identity56436 : scanCanonicalize (H12AffineFastState.compose env56436 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound56436 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10281,1024,32769,4160,32,17,41310,8192,65,64604,5393,17665,32041,1365,62588,256,21793,46093,512]

theorem envBound56437 : H12AffineFastState.Bounded env56437 := by
  intro p hp
  have h : env56437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56436_56437 : H12AffineEnvironment.transform 17 10281 env56436 = env56437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56436 == env56437) = true)

theorem identity56437 : scanCanonicalize (H12AffineFastState.compose env56437 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound56437 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env56438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1296,32768,8202,38161,10281,1024,32769,4160,32,17,41310,8192,65,47436,5393,17,14393,1365,45420,256,4145,46093,512]

theorem envBound56438 : H12AffineFastState.Bounded env56438 := by
  intro p hp
  have h : env56438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56437_56438 : H12AffineEnvironment.transform 13 1296 env56437 = env56438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56437 == env56438) = true)

theorem identity56438 : scanCanonicalize (H12AffineFastState.compose env56438 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 12345) := by decide +kernel

theorem selectedBound56438 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1296,12345,8202,9512,10281,1024,12344,4160,32,17,4455,8192,65,2421,5393,17,14393,1365,341,256,4145,1076,512]

theorem envBound56439 : H12AffineFastState.Bounded env56439 := by
  intro p hp
  have h : env56439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56438_56439 : H12AffineEnvironment.transform 14 12345 env56438 = env56439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12345 env56438 == env56439) = true)

theorem identity56439 : scanCanonicalize (H12AffineFastState.compose env56439 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound56439 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,1296,4193,82,1392,2161,1024,4192,4160,32,17,4455,88,65,2421,5393,17,6241,1365,341,256,4145,1076,512]

theorem envBound56440 : H12AffineFastState.Bounded env56440 := by
  intro p hp
  have h : env56440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56439_56440 : H12AffineEnvironment.transform 12 88 env56439 = env56440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env56439 == env56440) = true)

def env56441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,437625,272392,441640,41311,8193,65,316532,436264,17665,32040,440429,156013,256,21793,46092,442169]

theorem envBound56441 : H12AffineFastState.Bounded env56441 := by
  intro p hp
  have h : env56441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56434_56441 : H12AffineEnvironment.transform 6 9 env56434 = env56441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56434 == env56441) = true)

theorem identity56441 : scanCanonicalize (H12AffineFastState.compose env56441 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound56441 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env56442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13388,262144,1024,32769,301365,272392,297316,41311,8193,65,316532,302180,17665,32040,298017,21793,256,21793,46092,297845]

theorem envBound56442 : H12AffineFastState.Bounded env56442 := by
  intro p hp
  have h : env56442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56441_56442 : H12AffineEnvironment.transform 16 13388 env56441 = env56442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env56441 == env56442) = true)

theorem identity56442 : scanCanonicalize (H12AffineFastState.compose env56442 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound56442 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13388,23808,1024,32769,50229,29960,54372,41311,8193,65,35188,49508,17665,32040,53537,21793,256,21793,46092,54901]

theorem envBound56443 : H12AffineFastState.Bounded env56443 := by
  intro p hp
  have h : env56443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56442_56443 : H12AffineEnvironment.transform 17 23808 env56442 = env56443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env56442 == env56443) = true)

theorem identity56443 : scanCanonicalize (H12AffineFastState.compose env56443 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound56443 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env56444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21621,8202,13388,23808,1024,21620,4160,29960,17,29994,8193,65,23809,5393,17665,32040,1364,21793,256,21793,24697,512]

theorem envBound56444 : H12AffineFastState.Bounded env56444 := by
  intro p hp
  have h : env56444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56443_56444 : H12AffineEnvironment.transform 14 21621 env56443 = env56444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env56443 == env56444) = true)

theorem identity56444 : scanCanonicalize (H12AffineFastState.compose env56444 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56444 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21621,343,5393,23808,1024,21620,4160,21589,17,21623,348,65,23809,5393,17665,23669,1364,21793,256,21793,16676,512]

theorem envBound56445 : H12AffineFastState.Bounded env56445 := by
  intro p hp
  have h : env56445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56444_56445 : H12AffineEnvironment.transform 12 349 env56444 = env56445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56444 == env56445) = true)

theorem identity56445 : scanCanonicalize (H12AffineFastState.compose env56445 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56445 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env56446 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21541,263,5393,23808,1024,21540,4112,21509,17,21543,268,17,23809,5393,17665,23589,1284,21793,256,21793,16676,512]

theorem envBound56446 : H12AffineFastState.Bounded env56446 := by
  intro p hp
  have h : env56446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56445_56446 : H12AffineEnvironment.transform 5 16 env56445 = env56446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56445 == env56446) = true)

theorem identity56446 : scanCanonicalize (H12AffineFastState.compose env56446 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound56446 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env56447 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,2081,7172,263,5393,5409,1024,7173,4112,7204,17,7174,268,17,5408,5393,3360,5124,1284,7424,256,7424,2309,512]

theorem envBound56447 : H12AffineFastState.Bounded env56447 := by
  intro p hp
  have h : env56447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56446_56447 : H12AffineEnvironment.transform 13 2081 env56446 = env56447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env56446 == env56447) = true)

theorem identity56447 : scanCanonicalize (H12AffineFastState.compose env56447 (packedSelected [11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound56447 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env56448 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3076,269,2081,0,263,2325,2341,1024,1,3092,32,17,2,268,17,2340,2325,3360,2048,1284,260,256,260,2309,512]

theorem envBound56448 : H12AffineFastState.Bounded env56448 := by
  intro p hp
  have h : env56448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56447_56448 : H12AffineEnvironment.transform 11 3076 env56447 = env56448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env56447 == env56448) = true)

theorem identity56448 : scanCanonicalize (H12AffineFastState.compose env56448 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56448 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56449 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,3076,9,2081,0,3,2065,2081,1024,1,3092,32,17,2,8,17,2080,2065,3108,2048,1024,0,4,0,2049,512]

theorem envBound56449 : H12AffineFastState.Bounded env56449 := by
  intro p hp
  have h : env56449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56448_56449 : H12AffineEnvironment.transform 7 4 env56448 = env56449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56448 == env56449) = true)

theorem identity56449 : scanCanonicalize (H12AffineFastState.compose env56449 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound56449 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env56450 : List Nat := [2,4,8,16,32,16,9,4,512,21,2048,2065,9,2081,0,3,2065,2081,21,1,2049,32,17,2,8,17,2080,2065,2097,2048,21,0,4,0,2049,512]

theorem envBound56450 : H12AffineFastState.Bounded env56450 := by
  intro p hp
  have h : env56450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56449_56450 : H12AffineEnvironment.transform 9 21 env56449 = env56450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env56449 == env56450) = true)

theorem identity56450 : scanCanonicalize (H12AffineFastState.compose env56450 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56450 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env56451 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,2065,9,2048,0,3,2065,2048,21,1,2049,1,17,2,8,17,2049,2065,2064,2048,21,0,4,0,2049,512]

theorem envBound56451 : H12AffineFastState.Bounded env56451 := by
  intro p hp
  have h : env56451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56450_56451 : H12AffineEnvironment.transform 4 1 env56450 = env56451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56450 == env56451) = true)

theorem identity56451 : scanCanonicalize (H12AffineFastState.compose env56451 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound56451 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56452 : List Nat := [2,4,8,16,1,16,9,4,512,21,5,20,9,5,0,3,20,5,21,1,4,1,17,2,8,17,4,20,21,5,21,0,4,0,4,512]

theorem envBound56452 : H12AffineFastState.Bounded env56452 := by
  intro p hp
  have h : env56452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56451_56452 : H12AffineEnvironment.transform 10 5 env56451 = env56452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env56451 == env56452) = true)

theorem identity56452 : scanCanonicalize (H12AffineFastState.compose env56452 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound56452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56453 : List Nat := [2,4,8,16,1,16,9,4,22,21,5,20,9,5,0,3,20,5,21,1,4,1,17,2,8,17,4,20,21,5,21,0,4,0,4,22]

theorem envBound56453 : H12AffineFastState.Bounded env56453 := by
  intro p hp
  have h : env56453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56452_56453 : H12AffineEnvironment.transform 8 22 env56452 = env56453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env56452 == env56453) = true)

theorem identity56453 : scanCanonicalize (H12AffineFastState.compose env56453 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound56453 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56454 : List Nat := [2,1,8,16,1,16,9,1,19,16,0,17,9,0,0,3,17,0,16,1,1,1,17,2,8,17,1,17,16,0,16,0,1,0,1,19]

theorem envBound56454 : H12AffineFastState.Bounded env56454 := by
  intro p hp
  have h : env56454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56453_56454 : H12AffineEnvironment.transform 1 1 env56453 = env56454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env56453 == env56454) = true)

theorem identity56454 : scanCanonicalize (H12AffineFastState.compose env56454 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound56454 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56455 : List Nat := [2,1,8,9,1,9,9,1,10,9,0,8,9,0,0,3,8,0,9,1,1,1,8,2,8,8,1,8,9,0,9,0,1,0,1,10]

theorem envBound56455 : H12AffineFastState.Bounded env56455 := by
  intro p hp
  have h : env56455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56454_56455 : H12AffineEnvironment.transform 3 9 env56454 = env56455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env56454 == env56455) = true)

def env56456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound56456 : H12AffineFastState.Bounded env56456 := by
  intro p hp
  have h : env56456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56217_56456 : H12AffineEnvironment.transform 18 1025 env56217 = env56456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env56217 == env56456) = true)

theorem identity56456 : scanCanonicalize (H12AffineFastState.compose env56456 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10833264) := by decide +kernel

theorem selectedBound56456 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10833264,8328,65,6458736,8702460,10507600,8830977,2410848,12855472,257,297437,288888,2485942]

theorem envBound56457 : H12AffineFastState.Bounded env56457 := by
  intro p hp
  have h : env56457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56456_56457 : H12AffineEnvironment.transform 23 10833264 env56456 = env56457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10833264 env56456 == env56457) = true)

def env56458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,2097152,4194304,8388608,10588556,8328,65,6458736,8393984,10507600,8527101,2102684,12645452,257,21793,46212,2175562]

theorem envBound56458 : H12AffineFastState.Bounded env56458 := by
  intro p hp
  have h : env56458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56457_56458 : H12AffineEnvironment.transform 17 56572 env56457 = env56458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env56457 == env56458) = true)

def env56459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,8388608,8487372,8328,65,4365616,8393984,8406288,8527101,1500,12645452,257,21793,46212,74250]

theorem envBound56459 : H12AffineFastState.Bounded env56459 := by
  intro p hp
  have h : env56459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56458_56459 : H12AffineEnvironment.transform 20 4160 env56458 = env56459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env56458 == env56459) = true)

def env56460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,16,98780,8328,65,4365616,5392,17664,138477,1500,4256860,257,21793,46212,74250]

theorem envBound56460 : H12AffineFastState.Bounded env56460 := by
  intro p hp
  have h : env56460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56459_56460 : H12AffineEnvironment.transform 22 16 env56459 = env56460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56459 == env56460) = true)

theorem identity56460 : scanCanonicalize (H12AffineFastState.compose env56460 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound56460 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,62588,16,98780,8328,65,158028,5392,17664,138477,1500,32,257,21793,46212,74250]

theorem envBound56461 : H12AffineFastState.Bounded env56461 := by
  intro p hp
  have h : env56461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56460_56461 : H12AffineEnvironment.transform 21 62588 env56460 = env56461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env56460 == env56461) = true)

theorem identity56461 : scanCanonicalize (H12AffineFastState.compose env56461 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56461 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env56462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56572,1025,32769,4160,62588,16,41431,8328,65,158028,5392,17664,138477,1500,32,257,21793,46212,513]

theorem envBound56462 : H12AffineFastState.Bounded env56462 := by
  intro p hp
  have h : env56462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56461_56462 : H12AffineEnvironment.transform 15 8203 env56461 = env56462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56461 == env56462) = true)

theorem identity56462 : scanCanonicalize (H12AffineFastState.compose env56462 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound56462 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56572,1025,32769,4160,62588,16,41431,8328,65,10588,5392,17664,23805,1500,32,257,21793,46212,513]

theorem envBound56463 : H12AffineFastState.Bounded env56463 := by
  intro p hp
  have h : env56463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56462_56463 : H12AffineEnvironment.transform 16 16400 env56462 = env56463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env56462 == env56463) = true)

def env56464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56572,1025,32769,4160,4194304,17,98781,8328,65,4365616,5393,17665,138476,1500,4256861,257,21793,46212,74250]

theorem envBound56464 : H12AffineFastState.Bounded env56464 := by
  intro p hp
  have h : env56464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56459_56464 : H12AffineEnvironment.transform 22 17 env56459 = env56464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56459 == env56464) = true)

theorem identity56464 : scanCanonicalize (H12AffineFastState.compose env56464 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound56464 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10281,1025,29908,4160,4194304,17,95496,8328,65,4352485,5393,17665,138476,1500,4194440,257,21793,16465,74250]

theorem envBound56465 : H12AffineFastState.Bounded env56465 := by
  intro p hp
  have h : env56465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56464_56465 : H12AffineEnvironment.transform 14 29909 env56464 = env56465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env56464 == env56465) = true)

def env56466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10281,1025,8660,4160,4194304,17,73736,8328,65,4340965,5393,4097,138476,1500,4194440,257,33,5457,74250]

theorem envBound56466 : H12AffineFastState.Bounded env56466 := by
  intro p hp
  have h : env56466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56465_56466 : H12AffineEnvironment.transform 13 5376 env56465 = env56466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56465 == env56466) = true)

theorem identity56466 : scanCanonicalize (H12AffineFastState.compose env56466 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56466 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56467 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1025,8541,4160,4194304,17,73736,8193,65,4340844,5393,4097,138341,1365,4194305,257,33,5457,74250]

theorem envBound56467 : H12AffineFastState.Bounded env56467 := by
  intro p hp
  have h : env56467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56466_56467 : H12AffineEnvironment.transform 6 9 env56466 = env56467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56466 == env56467) = true)

theorem identity56467 : scanCanonicalize (H12AffineFastState.compose env56467 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 210235) := by decide +kernel

theorem selectedBound56467 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env56468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1025,8541,4160,210235,17,73736,8193,65,67927,5393,4097,138341,1365,210234,257,33,5457,74250]

theorem envBound56468 : H12AffineFastState.Bounded env56468 := by
  intro p hp
  have h : env56468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56467_56468 : H12AffineEnvironment.transform 21 210235 env56467 = env56468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210235 env56467 == env56468) = true)

theorem identity56468 : scanCanonicalize (H12AffineFastState.compose env56468 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound56468 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env56469 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,79131,10281,1025,8541,4160,32,17,73736,8193,65,67927,5393,4097,76158,1365,33,257,33,5457,74250]

theorem envBound56469 : H12AffineFastState.Bounded env56469 := by
  intro p hp
  have h : env56469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56468_56469 : H12AffineEnvironment.transform 16 79131 env56468 = env56469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env56468 == env56469) = true)

theorem identity56469 : scanCanonicalize (H12AffineFastState.compose env56469 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound56469 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56470 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5376,373,65536,70962,2048,1025,372,4160,32,17,65569,40,65,67927,5393,4097,67927,1365,33,257,33,5457,66083]

theorem envBound56470 : H12AffineFastState.Bounded env56470 := by
  intro p hp
  have h : env56470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56469_56470 : H12AffineEnvironment.transform 12 41 env56469 = env56470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env56469 == env56470) = true)

theorem identity56470 : scanCanonicalize (H12AffineFastState.compose env56470 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 4439) := by decide +kernel

theorem selectedBound56470 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5376,373,4439,1125,2048,1025,372,4160,32,17,4470,40,65,6144,5393,4097,6144,1365,33,257,33,5457,4980]

theorem envBound56471 : H12AffineFastState.Bounded env56471 := by
  intro p hp
  have h : env56471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56470_56471 : H12AffineEnvironment.transform 15 4439 env56470 = env56471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4439 env56470 == env56471) = true)

def env56472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10281,1025,8661,4160,4194304,17,73737,8328,65,4340964,5393,4096,138476,1500,4194440,257,32,5456,74250]

theorem envBound56472 : H12AffineFastState.Bounded env56472 := by
  intro p hp
  have h : env56472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0