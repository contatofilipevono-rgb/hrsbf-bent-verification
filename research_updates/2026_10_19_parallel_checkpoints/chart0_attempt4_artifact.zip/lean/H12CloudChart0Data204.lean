import H12CloudChart0Data203

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound51652 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env51653 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,3157,349,2389,0,2648,586,2388,1024,1,1819,0,2846,2829,348,64,2048,586,3156,2388,3674,2831,256,0,2309,512]

theorem envBound51653 : H12AffineFastState.Bounded env51653 := by
  intro p hp
  have h : env51653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51652_51653 : H12AffineEnvironment.transform 11 3157 env51652 = env51653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env51652 == env51653) = true)

theorem identity51653 : scanCanonicalize (H12AffineFastState.compose env51653 (packedSelected [0,1,2,3,7,14] rootPS)) = affineNative (2^(10+1) ^^^ 1866) := by decide +kernel

theorem selectedBound51653 : packedSelected [0,1,2,3,7,14] rootPS < 2^1333 := by decide +kernel

def env51654 : List Nat := [2,4,8,16,0,64,9,256,512,1024,1866,799,349,1567,0,1298,586,1566,1024,1,1819,0,1108,1095,348,64,1866,586,798,1566,272,1093,256,0,1615,512]

theorem envBound51654 : H12AffineFastState.Bounded env51654 := by
  intro p hp
  have h : env51654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51653_51654 : H12AffineEnvironment.transform 10 1866 env51653 = env51654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1866 env51653 == env51654) = true)

theorem identity51654 : scanCanonicalize (H12AffineFastState.compose env51654 (packedSelected [0,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 350) := by decide +kernel

theorem selectedBound51654 : packedSelected [0,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env51655 : List Nat := [2,4,8,16,0,64,9,256,350,1024,1044,65,349,1345,0,1298,276,1344,1024,1,1093,0,1108,1095,348,64,1044,276,64,1344,272,1093,256,0,1297,350]

theorem envBound51655 : H12AffineFastState.Bounded env51655 := by
  intro p hp
  have h : env51655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51654_51655 : H12AffineEnvironment.transform 8 350 env51654 = env51655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 350 env51654 == env51655) = true)

theorem identity51655 : scanCanonicalize (H12AffineFastState.compose env51655 (packedSelected [0,2,7,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51655 : packedSelected [0,2,7,15] rootPS < 2^1333 := by decide +kernel

def env51656 : List Nat := [2,4,8,16,0,64,9,256,350,272,260,65,349,81,0,2,276,80,272,1,341,0,324,343,348,64,260,276,64,80,272,341,256,0,1,350]

theorem envBound51656 : H12AffineFastState.Bounded env51656 := by
  intro p hp
  have h : env51656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51655_51656 : H12AffineEnvironment.transform 9 272 env51655 = env51656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51655 == env51656) = true)

theorem identity51656 : scanCanonicalize (H12AffineFastState.compose env51656 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound51656 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51657 : List Nat := [2,4,8,16,0,64,9,85,11,69,81,65,8,81,0,2,65,80,69,1,0,0,17,2,9,64,81,65,64,80,69,0,85,0,1,11]

theorem envBound51657 : H12AffineFastState.Bounded env51657 := by
  intro p hp
  have h : env51657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51656_51657 : H12AffineEnvironment.transform 7 85 env51656 = env51657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env51656 == env51657) = true)

theorem identity51657 : scanCanonicalize (H12AffineFastState.compose env51657 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound51657 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51658 : List Nat := [2,4,8,5,0,64,9,64,11,69,68,65,8,68,0,2,65,69,69,1,0,0,4,2,9,64,68,65,64,69,69,0,64,0,1,11]

theorem envBound51658 : H12AffineFastState.Bounded env51658 := by
  intro p hp
  have h : env51658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51657_51658 : H12AffineEnvironment.transform 3 5 env51657 = env51658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env51657 == env51658) = true)

theorem identity51658 : scanCanonicalize (H12AffineFastState.compose env51658 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51658 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51659 : List Nat := [2,4,5,5,0,64,4,64,6,69,68,65,5,68,0,2,65,69,69,1,0,0,4,2,4,64,68,65,64,69,69,0,64,0,1,6]

theorem envBound51659 : H12AffineFastState.Bounded env51659 := by
  intro p hp
  have h : env51659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51658_51659 : H12AffineEnvironment.transform 2 5 env51658 = env51659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51658 == env51659) = true)

theorem identity51659 : scanCanonicalize (H12AffineFastState.compose env51659 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound51659 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51660 : List Nat := [2,4,5,5,0,2,4,2,6,7,6,3,5,6,0,2,3,7,7,1,0,0,4,2,4,2,6,3,2,7,7,0,2,0,1,6]

theorem envBound51660 : H12AffineFastState.Bounded env51660 := by
  intro p hp
  have h : env51660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51659_51660 : H12AffineEnvironment.transform 5 2 env51659 = env51660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env51659 == env51660) = true)

theorem identity51660 : scanCanonicalize (H12AffineFastState.compose env51660 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51660 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env51661 : List Nat := [0,4,5,5,0,0,4,0,4,5,4,1,5,4,0,0,1,5,5,1,0,0,4,0,4,0,4,1,0,5,5,0,0,0,1,4]

theorem envBound51661 : H12AffineFastState.Bounded env51661 := by
  intro p hp
  have h : env51661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51660_51661 : H12AffineEnvironment.transform 0 0 env51660 = env51661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51660 == env51661) = true)

theorem identity51661 : scanCanonicalize (H12AffineFastState.compose env51661 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51661 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51662 : List Nat := [0,0,1,1,0,0,0,0,0,1,0,1,1,0,0,0,1,1,1,1,0,0,0,0,0,0,0,1,0,1,1,0,0,0,1,0]

theorem envBound51662 : H12AffineFastState.Bounded env51662 := by
  intro p hp
  have h : env51662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51661_51662 : H12AffineEnvironment.transform 1 0 env51661 = env51662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51661 == env51662) = true)

def env51663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1024,8661,2097152,33,8388608,10563672,8328,64,2239500,8393985,10485841,8526964,2102685,8388793,256,32,5456,2175563]

theorem envBound51663 : H12AffineFastState.Bounded env51663 := by
  intro p hp
  have h : env51663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51626_51663 : H12AffineEnvironment.transform 17 10401 env51626 = env51663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env51626 == env51663) = true)

theorem identity51663 : scanCanonicalize (H12AffineFastState.compose env51663 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound51663 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1024,8661,2097152,33,16,2175048,8328,64,2239500,5393,2097217,138340,2102685,169,256,32,5456,2175563]

theorem envBound51664 : H12AffineFastState.Bounded env51664 := by
  intro p hp
  have h : env51664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51663_51664 : H12AffineEnvironment.transform 22 16 env51663 = env51664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51663 == env51664) = true)

theorem identity51664 : scanCanonicalize (H12AffineFastState.compose env51664 (packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 206170) := by decide +kernel

theorem selectedBound51664 : packedSelected [0,1,3,4,5,7,8,10,11,16,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env51665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1024,8661,206170,33,16,136466,8328,64,67926,5393,206107,138340,209095,169,256,32,5456,136977]

theorem envBound51665 : H12AffineFastState.Bounded env51665 := by
  intro p hp
  have h : env51665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51664_51665 : H12AffineEnvironment.transform 20 206170 env51664 = env51665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206170 env51664 == env51665) = true)

theorem identity51665 : scanCanonicalize (H12AffineFastState.compose env51665 (packedSelected [4,7,9,12,14,15,16,20,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound51665 : packedSelected [4,7,9,12,14,15,16,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env51666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8323,131072,10401,1024,8661,132569,33,16,136466,8328,64,10709,5393,132504,138340,135236,169,256,32,5456,136977]

theorem envBound51666 : H12AffineFastState.Bounded env51666 := by
  intro p hp
  have h : env51666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51665_51666 : H12AffineEnvironment.transform 15 8323 env51665 = env51666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env51665 == env51666) = true)

theorem identity51666 : scanCanonicalize (H12AffineFastState.compose env51666 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound51666 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env51667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8323,5529,10401,1024,8661,4160,33,16,139,8328,64,10709,5393,4097,2557,1501,169,256,32,5456,648]

theorem envBound51667 : H12AffineFastState.Bounded env51667 := by
  intro p hp
  have h : env51667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51666_51667 : H12AffineEnvironment.transform 16 5529 env51666 = env51667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env51666 == env51667) = true)

theorem identity51667 : scanCanonicalize (H12AffineFastState.compose env51667 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound51667 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,381,5376,169,510,5529,2524,1024,168,4160,33,16,139,501,64,2216,5393,4097,2557,1501,169,256,32,5456,648]

theorem envBound51668 : H12AffineFastState.Bounded env51668 := by
  intro p hp
  have h : env51668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51667_51668 : H12AffineEnvironment.transform 12 381 env51667 = env51668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env51667 == env51668) = true)

theorem identity51668 : scanCanonicalize (H12AffineFastState.compose env51668 (packedSelected [0,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound51668 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env51669 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,381,5376,1,342,5425,2420,1024,0,4160,33,16,35,349,64,2048,5393,4097,2389,1397,1,256,32,5456,544]

theorem envBound51669 : H12AffineFastState.Bounded env51669 := by
  intro p hp
  have h : env51669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51668_51669 : H12AffineEnvironment.transform 6 40 env51668 = env51669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env51668 == env51669) = true)

theorem identity51669 : scanCanonicalize (H12AffineFastState.compose env51669 (packedSelected [2,3,5,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound51669 : packedSelected [2,3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env51670 : List Nat := [2,4,8,16,32,64,40,256,512,1024,293,4096,381,5376,1,342,5425,81,1024,0,4160,33,16,35,349,64,293,5393,4097,112,1397,1,256,32,5456,544]

theorem envBound51670 : H12AffineFastState.Bounded env51670 := by
  intro p hp
  have h : env51670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51669_51670 : H12AffineEnvironment.transform 10 293 env51669 = env51670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env51669 == env51670) = true)

theorem identity51670 : scanCanonicalize (H12AffineFastState.compose env51670 (packedSelected [0,3,5,6,7,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51670 : packedSelected [0,3,5,6,7,10,14] rootPS < 2^1333 := by decide +kernel

def env51671 : List Nat := [2,4,8,16,32,64,40,36,512,1024,1,4096,89,5156,1,114,5141,81,1024,0,4160,33,16,35,121,64,1,5173,4097,112,1105,1,36,32,5236,544]

theorem envBound51671 : H12AffineFastState.Bounded env51671 := by
  intro p hp
  have h : env51671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51670_51671 : H12AffineEnvironment.transform 7 36 env51670 = env51671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51670 == env51671) = true)

theorem identity51671 : scanCanonicalize (H12AffineFastState.compose env51671 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51671 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env51672 : List Nat := [2,4,8,16,32,16,40,36,512,1024,1,4096,9,5156,1,34,5141,1,1024,0,4112,33,16,35,41,16,1,5173,4097,32,1025,1,36,32,5156,544]

theorem envBound51672 : H12AffineFastState.Bounded env51672 := by
  intro p hp
  have h : env51672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51671_51672 : H12AffineEnvironment.transform 5 16 env51671 = env51672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51671 == env51672) = true)

theorem identity51672 : scanCanonicalize (H12AffineFastState.compose env51672 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51672 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51673 : List Nat := [2,4,8,16,1,16,9,5,512,1024,1,4096,9,5125,1,3,5141,1,1024,0,4112,0,16,2,8,16,1,5140,4097,1,1025,1,5,1,5125,513]

theorem envBound51673 : H12AffineFastState.Bounded env51673 := by
  intro p hp
  have h : env51673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51672_51673 : H12AffineEnvironment.transform 4 1 env51672 = env51673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51672 == env51673) = true)

theorem identity51673 : scanCanonicalize (H12AffineFastState.compose env51673 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound51673 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51674 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,4096,9,4112,1,3,4096,1,21,0,4112,0,16,2,8,16,1,4097,4097,1,20,1,5,1,4112,513]

theorem envBound51674 : H12AffineFastState.Bounded env51674 := by
  intro p hp
  have h : env51674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51673_51674 : H12AffineEnvironment.transform 9 21 env51673 = env51674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51673 == env51674) = true)

theorem identity51674 : scanCanonicalize (H12AffineFastState.compose env51674 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound51674 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51675 : List Nat := [2,4,8,16,1,16,9,5,16,21,1,4096,9,4112,1,3,4096,1,21,0,4112,0,16,2,8,16,1,4097,4097,1,20,1,5,1,4112,17]

theorem envBound51675 : H12AffineFastState.Bounded env51675 := by
  intro p hp
  have h : env51675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51674_51675 : H12AffineEnvironment.transform 8 16 env51674 = env51675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51674 == env51675) = true)

theorem identity51675 : scanCanonicalize (H12AffineFastState.compose env51675 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound51675 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51676 : List Nat := [2,4,8,16,1,16,9,5,16,21,1,1,9,17,1,3,1,1,21,0,17,0,16,2,8,16,1,0,0,1,20,1,5,1,17,17]

theorem envBound51676 : H12AffineFastState.Bounded env51676 := by
  intro p hp
  have h : env51676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51675_51676 : H12AffineEnvironment.transform 11 1 env51675 = env51676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env51675 == env51676) = true)

theorem identity51676 : scanCanonicalize (H12AffineFastState.compose env51676 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51676 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51677 : List Nat := [2,4,8,1,1,1,9,5,1,4,1,1,9,0,1,3,1,1,4,0,0,0,1,2,8,1,1,0,0,1,5,1,5,1,0,0]

theorem envBound51677 : H12AffineFastState.Bounded env51677 := by
  intro p hp
  have h : env51677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51676_51677 : H12AffineEnvironment.transform 3 1 env51676 = env51677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51676 == env51677) = true)

def env51678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,2097152,272512,8388608,10563673,8328,64,2239501,8393985,10485840,8795349,2102685,8661016,256,33,5457,2175563]

theorem envBound51678 : H12AffineFastState.Bounded env51678 := by
  intro p hp
  have h : env51678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51625_51678 : H12AffineEnvironment.transform 13 5377 env51625 = env51678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51625 == env51678) = true)

def env51679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1024,8660,2097152,32,8388608,10563673,8328,64,2239501,8393985,10485840,8526965,2102685,8388792,256,33,5457,2175563]

theorem envBound51679 : H12AffineFastState.Bounded env51679 := by
  intro p hp
  have h : env51679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51678_51679 : H12AffineEnvironment.transform 17 10400 env51678 = env51679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env51678 == env51679) = true)

theorem identity51679 : scanCanonicalize (H12AffineFastState.compose env51679 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51679 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51680 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,2097152,32,8388608,10563673,8193,64,2239501,8393985,10485840,8526965,2102548,8388657,256,33,5457,2175563]

theorem envBound51680 : H12AffineFastState.Bounded env51680 := by
  intro p hp
  have h : env51680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51679_51680 : H12AffineEnvironment.transform 6 9 env51679 = env51680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51679 == env51680) = true)

theorem identity51680 : scanCanonicalize (H12AffineFastState.compose env51680 (packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound51680 : packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51681 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77898,32,8388608,8388627,8193,64,203847,8393985,8466458,8526965,75102,8388657,256,33,5457,513]

theorem envBound51681 : H12AffineFastState.Bounded env51681 := by
  intro p hp
  have h : env51681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51680_51681 : H12AffineEnvironment.transform 20 77898 env51680 = env51681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env51680 == env51681) = true)

theorem identity51681 : scanCanonicalize (H12AffineFastState.compose env51681 (packedSelected [0,1,7,8,10,11,12,16,18] rootPS)) = affineNative (2^(22+1) ^^^ 210267) := by decide +kernel

theorem selectedBound51681 : packedSelected [0,1,7,8,10,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env51682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77898,32,210267,210248,8193,64,203847,204890,132417,76078,75102,210282,256,33,5457,513]

theorem envBound51682 : H12AffineFastState.Bounded env51682 := by
  intro p hp
  have h : env51682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51681_51682 : H12AffineEnvironment.transform 22 210267 env51681 = env51682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 210267 env51681 == env51682) = true)

theorem identity51682 : scanCanonicalize (H12AffineFastState.compose env51682 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound51682 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,263,131072,10281,1024,8541,12621,32,144476,144463,8193,64,138560,139613,132417,10281,9305,144493,256,33,5457,513]

theorem envBound51683 : H12AffineFastState.Bounded env51683 := by
  intro p hp
  have h : env51683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51682_51683 : H12AffineEnvironment.transform 15 263 env51682 = env51683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env51682 == env51683) = true)

theorem identity51683 : scanCanonicalize (H12AffineFastState.compose env51683 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51683 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51684 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,263,131072,10281,1024,8460,12572,32,144397,144414,8193,17,138513,139532,132368,10281,9224,144444,256,33,5376,513]

theorem envBound51684 : H12AffineFastState.Bounded env51684 := by
  intro p hp
  have h : env51684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51683_51684 : H12AffineEnvironment.transform 5 17 env51683 = env51684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51683 == env51684) = true)

theorem identity51684 : scanCanonicalize (H12AffineFastState.compose env51684 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound51684 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51685 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,263,5392,10281,1024,8460,12572,32,8477,8462,8193,17,2049,13340,4096,10281,9224,8492,256,33,5376,513]

theorem envBound51685 : H12AffineFastState.Bounded env51685 := by
  intro p hp
  have h : env51685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51684_51685 : H12AffineEnvironment.transform 16 5392 env51684 = env51685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env51684 == env51685) = true)

theorem identity51685 : scanCanonicalize (H12AffineFastState.compose env51685 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51685 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51686 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,263,5392,2341,1024,0,4112,32,17,2,269,17,2049,5392,4096,2341,1284,32,256,33,5376,513]

theorem envBound51686 : H12AffineFastState.Bounded env51686 := by
  intro p hp
  have h : env51686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51685_51686 : H12AffineEnvironment.transform 12 268 env51685 = env51686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51685 == env51686) = true)

theorem identity51686 : scanCanonicalize (H12AffineFastState.compose env51686 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound51686 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51687 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,308,268,1077,1,263,1060,2341,1024,0,292,32,17,2,269,17,2049,1060,308,2341,1284,32,256,33,1076,513]

theorem envBound51687 : H12AffineFastState.Bounded env51687 := by
  intro p hp
  have h : env51687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51686_51687 : H12AffineEnvironment.transform 11 308 env51686 = env51687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env51686 == env51687) = true)

theorem identity51687 : scanCanonicalize (H12AffineFastState.compose env51687 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51687 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51688 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,308,268,292,1,263,309,2341,273,0,292,32,17,2,269,17,2049,309,308,2341,21,32,256,33,293,513]

theorem envBound51688 : H12AffineFastState.Bounded env51688 := by
  intro p hp
  have h : env51688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51687_51688 : H12AffineEnvironment.transform 9 273 env51687 = env51688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51687 == env51688) = true)

theorem identity51688 : scanCanonicalize (H12AffineFastState.compose env51688 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51688 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51689 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,16,40,0,1,35,17,2049,53,0,0,32,17,2,41,17,2049,17,16,2049,21,32,36,33,1,513]

theorem envBound51689 : H12AffineFastState.Bounded env51689 := by
  intro p hp
  have h : env51689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51688_51689 : H12AffineEnvironment.transform 7 36 env51688 = env51689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51688 == env51689) = true)

theorem identity51689 : scanCanonicalize (H12AffineFastState.compose env51689 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound51689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51690 : List Nat := [2,4,8,16,32,17,9,36,49,53,2048,16,40,0,1,35,17,2049,53,0,0,32,17,2,41,17,2049,17,16,2049,21,32,36,33,1,48]

theorem envBound51690 : H12AffineFastState.Bounded env51690 := by
  intro p hp
  have h : env51690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51689_51690 : H12AffineEnvironment.transform 8 49 env51689 = env51690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env51689 == env51690) = true)

theorem identity51690 : scanCanonicalize (H12AffineFastState.compose env51690 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound51690 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51691 : List Nat := [2,4,8,16,32,17,9,36,49,53,48,16,40,0,1,35,17,49,53,0,0,32,17,2,41,17,49,17,16,49,21,32,36,33,1,48]

theorem envBound51691 : H12AffineFastState.Bounded env51691 := by
  intro p hp
  have h : env51691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51690_51691 : H12AffineEnvironment.transform 10 48 env51690 = env51691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env51690 == env51691) = true)

theorem identity51691 : scanCanonicalize (H12AffineFastState.compose env51691 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound51691 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51692 : List Nat := [2,4,8,16,17,17,9,21,0,4,1,16,25,0,1,18,17,0,4,0,0,17,17,2,24,17,0,17,16,0,21,17,21,16,1,1]

theorem envBound51692 : H12AffineFastState.Bounded env51692 := by
  intro p hp
  have h : env51692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51691_51692 : H12AffineEnvironment.transform 4 17 env51691 = env51692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env51691 == env51692) = true)

def env51693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1024,8660,2097152,33,8388608,10563673,8328,64,2239501,8393985,10485840,8526964,2102685,8388793,256,33,5457,2175563]

theorem envBound51693 : H12AffineFastState.Bounded env51693 := by
  intro p hp
  have h : env51693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51678_51693 : H12AffineEnvironment.transform 17 10401 env51678 = env51693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env51678 == env51693) = true)

theorem identity51693 : scanCanonicalize (H12AffineFastState.compose env51693 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 153) := by decide +kernel

theorem selectedBound51693 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1024,8660,2097152,33,153,2175168,8328,64,2239501,5528,2097353,138477,2102685,32,256,33,5457,2175563]

theorem envBound51694 : H12AffineFastState.Bounded env51694 := by
  intro p hp
  have h : env51694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51693_51694 : H12AffineEnvironment.transform 22 153 env51693 = env51694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 153 env51693 == env51694) = true)

theorem identity51694 : scanCanonicalize (H12AffineFastState.compose env51694 (packedSelected [0,1,4,7,11,16,18,19,20,22,23,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 4296) := by decide +kernel

theorem selectedBound51694 : packedSelected [0,1,4,7,11,16,18,19,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10401,1024,8660,4296,33,153,73736,8328,64,146629,5528,4097,138477,1365,32,256,33,5457,74371]

theorem envBound51695 : H12AffineFastState.Bounded env51695 := by
  intro p hp
  have h : env51695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51694_51695 : H12AffineEnvironment.transform 20 4296 env51694 = env51695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4296 env51694 == env51695) = true)

theorem identity51695 : scanCanonicalize (H12AffineFastState.compose env51695 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound51695 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env51696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8323,131072,10401,1024,8660,4296,33,153,139,8328,64,146629,5528,4097,138477,1365,32,256,33,5457,512]

theorem envBound51696 : H12AffineFastState.Bounded env51696 := by
  intro p hp
  have h : env51696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51695_51696 : H12AffineEnvironment.transform 15 8323 env51695 = env51696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env51695 == env51696) = true)

theorem identity51696 : scanCanonicalize (H12AffineFastState.compose env51696 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound51696 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5377,112,294,131072,2308,1024,113,4296,33,153,139,301,64,138592,5528,4097,138477,1365,32,256,33,5457,512]

theorem envBound51697 : H12AffineFastState.Bounded env51697 := by
  intro p hp
  have h : env51697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51696_51697 : H12AffineEnvironment.transform 12 421 env51696 = env51697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env51696 == env51697) = true)

theorem identity51697 : scanCanonicalize (H12AffineFastState.compose env51697 (packedSelected [2,4,9,12,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound51697 : packedSelected [2,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env51698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5377,112,294,5393,2308,1024,113,4296,33,153,139,301,64,2161,5528,4097,2556,1365,32,256,33,5457,512]

theorem envBound51698 : H12AffineFastState.Bounded env51698 := by
  intro p hp
  have h : env51698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51697_51698 : H12AffineEnvironment.transform 16 5393 env51697 = env51698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env51697 == env51698) = true)

theorem identity51698 : scanCanonicalize (H12AffineFastState.compose env51698 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound51698 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env51699 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,121,5341,112,250,5325,2264,1024,113,4296,33,153,139,241,64,2161,5188,4097,2080,1161,32,220,33,5261,512]

theorem envBound51699 : H12AffineFastState.Bounded env51699 := by
  intro p hp
  have h : env51699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51698_51699 : H12AffineEnvironment.transform 7 220 env51698 = env51699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env51698 == env51699) = true)

theorem identity51699 : scanCanonicalize (H12AffineFastState.compose env51699 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51699 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51700 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,88,5341,81,219,5325,2264,1024,80,4296,0,153,139,208,64,2128,5188,4097,2049,1161,1,220,0,5261,512]

theorem envBound51700 : H12AffineFastState.Bounded env51700 := by
  intro p hp
  have h : env51700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51699_51700 : H12AffineEnvironment.transform 4 1 env51699 = env51700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51699 == env51700) = true)

theorem identity51700 : scanCanonicalize (H12AffineFastState.compose env51700 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound51700 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env51701 : List Nat := [2,4,8,16,1,64,128,220,512,156,2048,4096,88,4161,81,219,4177,2264,156,80,4296,0,153,139,208,64,2128,4312,4097,2049,21,1,220,0,4113,512]

theorem envBound51701 : H12AffineFastState.Bounded env51701 := by
  intro p hp
  have h : env51701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51700_51701 : H12AffineEnvironment.transform 9 156 env51700 = env51701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env51700 == env51701) = true)

theorem identity51701 : scanCanonicalize (H12AffineFastState.compose env51701 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51701 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env51702 : List Nat := [2,4,8,16,1,64,9,85,512,21,2048,4096,88,4161,81,82,4177,2129,21,80,4161,0,16,2,89,64,2128,4177,4097,2049,21,1,85,0,4113,512]

theorem envBound51702 : H12AffineFastState.Bounded env51702 := by
  intro p hp
  have h : env51702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51701_51702 : H12AffineEnvironment.transform 6 9 env51701 = env51702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51701 == env51702) = true)

theorem identity51702 : scanCanonicalize (H12AffineFastState.compose env51702 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 20) := by decide +kernel

theorem selectedBound51702 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51703 : List Nat := [2,4,8,16,1,20,9,1,512,21,2048,4096,12,4117,5,6,4101,2053,21,4,4117,0,16,2,13,20,2052,4101,4097,2049,21,1,1,0,4113,512]

theorem envBound51703 : H12AffineFastState.Bounded env51703 := by
  intro p hp
  have h : env51703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51702_51703 : H12AffineEnvironment.transform 5 20 env51702 = env51703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env51702 == env51703) = true)

theorem identity51703 : scanCanonicalize (H12AffineFastState.compose env51703 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound51703 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51704 : List Nat := [2,4,8,16,1,20,9,1,512,21,2048,0,12,21,5,6,5,2053,21,4,21,0,16,2,13,20,2052,5,1,2049,21,1,1,0,17,512]

theorem envBound51704 : H12AffineFastState.Bounded env51704 := by
  intro p hp
  have h : env51704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51703_51704 : H12AffineEnvironment.transform 11 0 env51703 = env51704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env51703 == env51704) = true)

theorem identity51704 : scanCanonicalize (H12AffineFastState.compose env51704 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 15) := by decide +kernel

theorem selectedBound51704 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51705 : List Nat := [2,4,8,16,1,20,9,1,512,21,15,0,12,21,5,6,5,10,21,4,21,0,16,2,13,20,11,5,1,14,21,1,1,0,17,512]

theorem envBound51705 : H12AffineFastState.Bounded env51705 := by
  intro p hp
  have h : env51705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51704_51705 : H12AffineEnvironment.transform 10 15 env51704 = env51705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 15 env51704 == env51705) = true)

theorem identity51705 : scanCanonicalize (H12AffineFastState.compose env51705 (packedSelected [1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound51705 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env51706 : List Nat := [2,4,8,16,1,20,9,1,5,21,15,0,12,21,5,6,5,10,21,4,21,0,16,2,13,20,11,5,1,14,21,1,1,0,17,5]

theorem envBound51706 : H12AffineFastState.Bounded env51706 := by
  intro p hp
  have h : env51706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51705_51706 : H12AffineEnvironment.transform 8 5 env51705 = env51706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env51705 == env51706) = true)

theorem identity51706 : scanCanonicalize (H12AffineFastState.compose env51706 (packedSelected [1,4,8] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51706 : packedSelected [1,4,8] rootPS < 2^1333 := by decide +kernel

def env51707 : List Nat := [2,0,8,16,1,16,9,1,1,17,11,0,8,17,1,2,1,10,17,0,17,0,16,2,9,16,11,1,1,10,17,1,1,0,17,1]

theorem envBound51707 : H12AffineFastState.Bounded env51707 := by
  intro p hp
  have h : env51707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51706_51707 : H12AffineEnvironment.transform 1 0 env51706 = env51707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51706 == env51707) = true)

theorem identity51707 : scanCanonicalize (H12AffineFastState.compose env51707 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound51707 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51708 : List Nat := [2,0,8,8,1,8,9,1,1,9,11,0,8,9,1,2,1,10,9,0,9,0,8,2,9,8,11,1,1,10,9,1,1,0,9,1]

theorem envBound51708 : H12AffineFastState.Bounded env51708 := by
  intro p hp
  have h : env51708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51707_51708 : H12AffineEnvironment.transform 3 8 env51707 = env51708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env51707 == env51708) = true)

theorem identity51708 : scanCanonicalize (H12AffineFastState.compose env51708 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51708 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51709 : List Nat := [0,0,8,8,1,8,9,1,1,9,9,0,8,9,1,0,1,8,9,0,9,0,8,0,9,8,9,1,1,8,9,1,1,0,9,1]

theorem envBound51709 : H12AffineFastState.Bounded env51709 := by
  intro p hp
  have h : env51709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51708_51709 : H12AffineEnvironment.transform 0 0 env51708 = env51709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51708 == env51709) = true)

def env51710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,8388608,10577240,8328,64,2259213,8393985,10507601,8795349,2102685,8661017,256,21792,16464,2175563]

theorem envBound51710 : H12AffineFastState.Bounded env51710 := by
  intro p hp
  have h : env51710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51624_51710 : H12AffineEnvironment.transform 21 272513 env51624 = env51710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51624 == env51710) = true)

theorem identity51710 : scanCanonicalize (H12AffineFastState.compose env51710 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound51710 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,2097152,272513,16,2188616,8328,64,2259213,5393,2118977,406725,2102685,272393,256,21792,16464,2175563]

theorem envBound51711 : H12AffineFastState.Bounded env51711 := by
  intro p hp
  have h : env51711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51710_51711 : H12AffineEnvironment.transform 22 16 env51710 = env51711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51710 == env51711) = true)

def env51712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,262144,1024,8661,2097152,272513,16,2175048,8328,64,2239501,5393,2097217,406725,2102685,272393,256,32,5456,2175563]

theorem envBound51712 : H12AffineFastState.Bounded env51712 := by
  intro p hp
  have h : env51712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51711_51712 : H12AffineEnvironment.transform 13 5376 env51711 = env51712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51711 == env51712) = true)

def env51713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,262144,1024,8661,2097152,272513,16,2175048,8328,64,2111773,5393,2097217,270805,2102685,272393,256,32,5456,2175563]

theorem envBound51713 : H12AffineFastState.Bounded env51713 := by
  intro p hp
  have h : env51713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51712_51713 : H12AffineEnvironment.transform 16 5392 env51712 = env51713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env51712 == env51713) = true)

theorem identity51713 : scanCanonicalize (H12AffineFastState.compose env51713 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound51713 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env51714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,262144,1024,8661,77898,272513,16,2,8328,64,67927,5393,77835,270805,75223,272393,256,32,5456,513]

theorem envBound51714 : H12AffineFastState.Bounded env51714 := by
  intro p hp
  have h : env51714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51713_51714 : H12AffineEnvironment.transform 20 77898 env51713 = env51714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env51713 == env51714) = true)

def env51715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,10280,1024,8661,77898,169,16,2,8328,64,67927,5393,77835,2557,75223,33,256,32,5456,513]

theorem envBound51715 : H12AffineFastState.Bounded env51715 := by
  intro p hp
  have h : env51715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51714_51715 : H12AffineEnvironment.transform 17 10280 env51714 = env51715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51714 == env51715) = true)

theorem identity51715 : scanCanonicalize (H12AffineFastState.compose env51715 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound51715 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env51716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5376,509,65536,5392,2049,1024,508,69731,169,16,2,161,64,67927,5393,69666,2557,67070,33,256,32,5456,513]

theorem envBound51716 : H12AffineFastState.Bounded env51716 := by
  intro p hp
  have h : env51716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51715_51716 : H12AffineEnvironment.transform 12 41 env51715 = env51716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env51715 == env51716) = true)

theorem identity51716 : scanCanonicalize (H12AffineFastState.compose env51716 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound51716 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5376,509,35,5392,2049,1024,508,4160,169,16,2,161,64,2420,5393,4097,2557,1501,33,256,32,5456,513]

theorem envBound51717 : H12AffineFastState.Bounded env51717 := by
  intro p hp
  have h : env51717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51716_51717 : H12AffineEnvironment.transform 15 35 env51716 = env51717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env51716 == env51717) = true)

theorem identity51717 : scanCanonicalize (H12AffineFastState.compose env51717 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51717 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51718 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,41,4112,509,35,4096,2049,272,508,4160,169,16,2,161,64,2420,4097,4097,2557,205,33,256,32,4160,513]

theorem envBound51718 : H12AffineFastState.Bounded env51718 := by
  intro p hp
  have h : env51718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51717_51718 : H12AffineEnvironment.transform 9 272 env51717 = env51718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51717 == env51718) = true)

theorem identity51718 : scanCanonicalize (H12AffineFastState.compose env51718 (packedSelected [11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51718 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env51719 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,41,4112,428,35,4096,2049,272,429,4113,169,16,2,161,17,2341,4097,4097,2476,156,33,256,32,4113,513]

theorem envBound51719 : H12AffineFastState.Bounded env51719 := by
  intro p hp
  have h : env51719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51718_51719 : H12AffineEnvironment.transform 5 17 env51718 = env51719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51718 == env51719) = true)

theorem identity51719 : scanCanonicalize (H12AffineFastState.compose env51719 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51719 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51720 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,41,4112,293,35,4096,2049,272,292,4113,32,16,2,40,17,2341,4097,4097,2341,21,33,256,32,4113,513]

theorem envBound51720 : H12AffineFastState.Bounded env51720 := by
  intro p hp
  have h : env51720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51719_51720 : H12AffineEnvironment.transform 6 9 env51719 = env51720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51719 == env51720) = true)

theorem identity51720 : scanCanonicalize (H12AffineFastState.compose env51720 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51721 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4112,1,35,4096,2049,52,0,4113,32,16,2,40,17,2049,4097,4097,2049,21,33,36,32,4113,513]

theorem envBound51721 : H12AffineFastState.Bounded env51721 := by
  intro p hp
  have h : env51721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51720_51721 : H12AffineEnvironment.transform 7 36 env51720 = env51721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51720 == env51721) = true)

theorem identity51721 : scanCanonicalize (H12AffineFastState.compose env51721 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound51721 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51722 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,544,41,560,1,35,544,2049,52,0,561,32,16,2,40,17,2049,545,545,2049,21,33,36,32,561,513]

theorem envBound51722 : H12AffineFastState.Bounded env51722 := by
  intro p hp
  have h : env51722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51721_51722 : H12AffineEnvironment.transform 11 544 env51721 = env51722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env51721 == env51722) = true)

theorem identity51722 : scanCanonicalize (H12AffineFastState.compose env51722 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound51722 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51723 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,544,41,560,1,35,544,529,52,0,561,32,16,2,40,17,529,545,545,529,21,33,36,32,561,513]

theorem envBound51723 : H12AffineFastState.Bounded env51723 := by
  intro p hp
  have h : env51723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51722_51723 : H12AffineEnvironment.transform 10 528 env51722 = env51723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env51722 == env51723) = true)

theorem identity51723 : scanCanonicalize (H12AffineFastState.compose env51723 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound51723 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51724 : List Nat := [2,4,8,16,32,17,9,36,48,52,32,16,41,0,1,35,16,33,52,0,1,32,16,2,40,17,33,17,17,33,21,33,36,32,1,49]

theorem envBound51724 : H12AffineFastState.Bounded env51724 := by
  intro p hp
  have h : env51724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51723_51724 : H12AffineEnvironment.transform 8 48 env51723 = env51724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env51723 == env51724) = true)

def env51725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5392,10281,1024,8661,77898,168,16,2,8328,64,67927,5393,77835,2556,75223,32,256,32,5456,513]

theorem envBound51725 : H12AffineFastState.Bounded env51725 := by
  intro p hp
  have h : env51725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51714_51725 : H12AffineEnvironment.transform 17 10281 env51714 = env51725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51714 == env51725) = true)

theorem identity51725 : scanCanonicalize (H12AffineFastState.compose env51725 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound51725 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env51726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,1,65536,5392,2556,1024,0,70047,168,16,2,349,64,67927,5393,70110,2556,66562,32,256,32,5456,513]

theorem envBound51726 : H12AffineFastState.Bounded env51726 := by
  intro p hp
  have h : env51726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51725_51726 : H12AffineEnvironment.transform 12 469 env51725 = env51726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env51725 == env51726) = true)

theorem identity51726 : scanCanonicalize (H12AffineFastState.compose env51726 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound51726 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env51727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,1,343,5392,2556,1024,0,4296,168,16,2,349,64,2048,5393,4233,2556,1365,32,256,32,5456,513]

theorem envBound51727 : H12AffineFastState.Bounded env51727 := by
  intro p hp
  have h : env51727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51726_51727 : H12AffineEnvironment.transform 15 343 env51726 = env51727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env51726 == env51727) = true)

theorem identity51727 : scanCanonicalize (H12AffineFastState.compose env51727 (packedSelected [4,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound51727 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env51728 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,469,4588,1,343,4604,2556,236,0,4296,168,16,2,349,64,2048,4605,4233,2556,441,32,256,32,4540,513]

theorem envBound51728 : H12AffineFastState.Bounded env51728 := by
  intro p hp
  have h : env51728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51727_51728 : H12AffineEnvironment.transform 9 236 env51727 = env51728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env51727 == env51728) = true)

theorem identity51728 : scanCanonicalize (H12AffineFastState.compose env51728 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound51728 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env51729 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,2065,469,2557,1,343,2541,2556,236,0,2265,168,16,2,349,64,2048,2540,2200,2556,441,32,256,32,2477,513]

theorem envBound51729 : H12AffineFastState.Bounded env51729 := by
  intro p hp
  have h : env51729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51728_51729 : H12AffineEnvironment.transform 11 2065 env51728 = env51729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env51728 == env51729) = true)

def env51730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5393,262144,1024,8661,2097152,272513,16,2175048,8328,64,2111772,5393,2097217,270804,2102685,272393,256,32,5456,2175563]

theorem envBound51730 : H12AffineFastState.Bounded env51730 := by
  intro p hp
  have h : env51730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51712_51730 : H12AffineEnvironment.transform 16 5393 env51712 = env51730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env51712 == env51730) = true)

def env51731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5393,262144,1024,8661,4160,272513,16,73736,8328,64,10588,5393,4097,270804,1501,272393,256,32,5456,74251]

theorem envBound51731 : H12AffineFastState.Bounded env51731 := by
  intro p hp
  have h : env51731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51730_51731 : H12AffineEnvironment.transform 20 4160 env51730 = env51731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env51730 == env51731) = true)

theorem identity51731 : scanCanonicalize (H12AffineFastState.compose env51731 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound51731 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5393,10281,1024,8661,4160,168,16,73736,8328,64,10588,5393,4097,2557,1501,32,256,32,5456,74251]

theorem envBound51732 : H12AffineFastState.Bounded env51732 := by
  intro p hp
  have h : env51732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51731_51732 : H12AffineEnvironment.transform 17 10281 env51731 = env51732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51731 == env51732) = true)

theorem identity51732 : scanCanonicalize (H12AffineFastState.compose env51732 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound51732 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8574,5393,10281,1024,8661,4160,168,16,374,8328,64,10588,5393,4097,2557,1501,32,256,32,5456,885]

theorem envBound51733 : H12AffineFastState.Bounded env51733 := by
  intro p hp
  have h : env51733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51732_51733 : H12AffineEnvironment.transform 15 8574 env51732 = env51733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env51732 == env51733) = true)

theorem identity51733 : scanCanonicalize (H12AffineFastState.compose env51733 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound51733 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env51734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,1,171,5393,2556,1024,0,4160,168,16,374,349,64,2185,5393,4097,2557,1501,32,256,32,5456,885]

theorem envBound51734 : H12AffineFastState.Bounded env51734 := by
  intro p hp
  have h : env51734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51733_51734 : H12AffineEnvironment.transform 12 469 env51733 = env51734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env51733 == env51734) = true)

def env51735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5393,262144,1024,8661,4161,272513,16,73737,8328,64,10589,5393,4096,270804,1500,272393,256,32,5456,74250]

theorem envBound51735 : H12AffineFastState.Bounded env51735 := by
  intro p hp
  have h : env51735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51730_51735 : H12AffineEnvironment.transform 20 4161 env51730 = env51735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51730 == env51735) = true)

theorem identity51735 : scanCanonicalize (H12AffineFastState.compose env51735 (packedSelected [0,2,4,7,9,11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound51735 : packedSelected [0,2,4,7,9,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env51736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,139,5393,262144,1024,8661,4161,272513,16,8322,8328,64,10589,5393,4096,270804,1500,272393,256,32,5456,8833]

theorem envBound51736 : H12AffineFastState.Bounded env51736 := by
  intro p hp
  have h : env51736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51735_51736 : H12AffineEnvironment.transform 15 139 env51735 = env51736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env51735 == env51736) = true)

theorem identity51736 : scanCanonicalize (H12AffineFastState.compose env51736 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2217) := by decide +kernel

theorem selectedBound51736 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env51737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,139,5393,2217,1024,8661,4161,8232,16,8322,8328,64,10589,5393,4096,10621,1500,8352,256,32,5456,8833]

theorem envBound51737 : H12AffineFastState.Bounded env51737 := by
  intro p hp
  have h : env51737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51736_51737 : H12AffineEnvironment.transform 17 2217 env51736 = env51737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2217 env51736 == env51737) = true)

theorem identity51737 : scanCanonicalize (H12AffineFastState.compose env51737 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51737 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,2,5393,2080,1024,8540,4161,8232,16,8203,8193,64,10589,5393,4096,10621,1365,8233,256,32,5456,8712]

theorem envBound51738 : H12AffineFastState.Bounded env51738 := by
  intro p hp
  have h : env51738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51737_51738 : H12AffineEnvironment.transform 6 9 env51737 = env51738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51737 == env51738) = true)

theorem identity51738 : scanCanonicalize (H12AffineFastState.compose env51738 (packedSelected [1,3,5,6,8,11,12,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound51738 : packedSelected [1,3,5,6,8,11,12,20] rootPS < 2^1333 := by decide +kernel

def env51739 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,5205,8200,2,5188,2080,1024,8201,4161,8232,16,8203,8193,64,10248,5188,4096,10280,1024,8233,85,32,5125,8712]

theorem envBound51739 : H12AffineFastState.Bounded env51739 := by
  intro p hp
  have h : env51739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51738_51739 : H12AffineEnvironment.transform 7 85 env51738 = env51739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env51738 == env51739) = true)

theorem identity51739 : scanCanonicalize (H12AffineFastState.compose env51739 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51739 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env51740 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,5124,8200,2,5141,2080,1024,8201,4112,8232,16,8203,8193,17,10248,5141,4096,10280,1024,8233,4,32,5125,8712]

theorem envBound51740 : H12AffineFastState.Bounded env51740 := by
  intro p hp
  have h : env51740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51739_51740 : H12AffineEnvironment.transform 5 17 env51739 = env51740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51739 == env51740) = true)

theorem identity51740 : scanCanonicalize (H12AffineFastState.compose env51740 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 7213) := by decide +kernel

theorem selectedBound51740 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51741 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,7213,5124,7205,2,5141,2080,1024,7204,4112,7173,16,7206,7212,17,5157,5141,4096,5125,1024,7172,4,32,5125,7717]

theorem envBound51741 : H12AffineFastState.Bounded env51741 := by
  intro p hp
  have h : env51741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51740_51741 : H12AffineEnvironment.transform 12 7213 env51740 = env51741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7213 env51740 == env51741) = true)

theorem identity51741 : scanCanonicalize (H12AffineFastState.compose env51741 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound51741 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env51742 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,3109,8,2081,0,2,2096,2080,1024,1,3125,32,16,3,9,17,2048,2096,3109,2080,1024,33,4,32,2080,512]

theorem envBound51742 : H12AffineFastState.Bounded env51742 := by
  intro p hp
  have h : env51742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51741_51742 : H12AffineEnvironment.transform 11 3109 env51741 = env51742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env51741 == env51742) = true)

theorem identity51742 : scanCanonicalize (H12AffineFastState.compose env51742 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51742 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51743 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,3077,8,2049,0,2,2064,2048,1024,1,3093,0,16,3,9,17,2048,2064,3077,2048,1024,1,4,0,2048,512]

theorem envBound51743 : H12AffineFastState.Bounded env51743 := by
  intro p hp
  have h : env51743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51742_51743 : H12AffineEnvironment.transform 4 0 env51742 = env51743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51742 == env51743) = true)

theorem identity51743 : scanCanonicalize (H12AffineFastState.compose env51743 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound51743 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51744 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,2064,8,2049,0,2,2064,2048,21,1,2048,0,16,3,9,17,2048,2064,2064,2048,21,1,4,0,2048,512]

theorem envBound51744 : H12AffineFastState.Bounded env51744 := by
  intro p hp
  have h : env51744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51743_51744 : H12AffineEnvironment.transform 9 21 env51743 = env51744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51743 == env51744) = true)

theorem identity51744 : scanCanonicalize (H12AffineFastState.compose env51744 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51744 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51745 : List Nat := [2,4,8,16,0,17,9,4,1,21,2048,2064,8,2049,0,2,2064,2048,21,1,2048,0,16,3,9,17,2048,2064,2064,2048,21,1,4,0,2048,1]

theorem envBound51745 : H12AffineFastState.Bounded env51745 := by
  intro p hp
  have h : env51745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51744_51745 : H12AffineEnvironment.transform 8 1 env51744 = env51745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51744 == env51745) = true)

theorem identity51745 : scanCanonicalize (H12AffineFastState.compose env51745 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound51745 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51746 : List Nat := [2,4,8,4,0,5,9,4,1,1,2048,2052,8,2049,0,2,2052,2048,1,1,2048,0,4,3,9,5,2048,2052,2052,2048,1,1,4,0,2048,1]

theorem envBound51746 : H12AffineFastState.Bounded env51746 := by
  intro p hp
  have h : env51746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51745_51746 : H12AffineEnvironment.transform 3 4 env51745 = env51746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env51745 == env51746) = true)

def leafEnv51746 : List Nat := [2,4,8,4,0,5,9,4,1,1,2048,2052,8,2049,0,2,2052,2048,1,1,2048,0,4,3,1,9,1,5,2048,2052,2052,2048,1,1,4,0,4,3,2048,1,1,2049,0]

def active51746 : List Nat := [0,1,2,10]

def tree51746 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51746 : H12WitnessSearch.Good tree51746 := H12GlobalWitnessIndex.good

theorem leafIdentity51746 : H12AffineFastState.composeSystem env51746 rootObs = leafEnv51746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51746 rootObs == leafEnv51746) = true)

theorem terminalChecked51746 : H12PackedTerminal.terminalCheckFast leafEnv51746 active51746 tree51746 = true := by decide +kernel

def env51747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,262144,1024,8660,2097152,272513,16,2175049,8328,64,2239500,5393,2097216,406725,2102685,272393,256,33,5457,2175563]

theorem envBound51747 : H12AffineFastState.Bounded env51747 := by
  intro p hp
  have h : env51747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51711_51747 : H12AffineEnvironment.transform 13 5377 env51711 = env51747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51711 == env51747) = true)

theorem identity51747 : scanCanonicalize (H12AffineFastState.compose env51747 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51747 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,2097152,272392,16,2175049,8193,64,2239500,5393,2097216,406604,2102548,272393,256,33,5457,2175563]

theorem envBound51748 : H12AffineFastState.Bounded env51748 := by
  intro p hp
  have h : env51748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51747_51748 : H12AffineEnvironment.transform 6 9 env51747 = env51748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51747 == env51748) = true)

theorem identity51748 : scanCanonicalize (H12AffineFastState.compose env51748 (packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound51748 : packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env51749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77898,272392,16,3,8193,64,203846,5393,77834,406604,75102,272393,256,33,5457,513]

theorem envBound51749 : H12AffineFastState.Bounded env51749 := by
  intro p hp
  have h : env51749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51748_51749 : H12AffineEnvironment.transform 20 77898 env51748 = env51749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env51748 == env51749) = true)

theorem identity51749 : scanCanonicalize (H12AffineFastState.compose env51749 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound51749 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79131,262144,1024,8541,77898,272392,16,3,8193,64,10589,5393,77834,328023,75102,272393,256,33,5457,513]

theorem envBound51750 : H12AffineFastState.Bounded env51750 := by
  intro p hp
  have h : env51750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51749_51750 : H12AffineEnvironment.transform 16 79131 env51749 = env51750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env51749 == env51750) = true)

theorem identity51750 : scanCanonicalize (H12AffineFastState.compose env51750 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51750 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env51751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5393,262144,1024,8541,4160,272392,16,3,8193,64,10589,5393,4096,270685,1364,272393,256,33,5457,513]

theorem envBound51751 : H12AffineFastState.Bounded env51751 := by
  intro p hp
  have h : env51751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51750_51751 : H12AffineEnvironment.transform 15 8202 env51750 = env51751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51750 == env51751) = true)

theorem identity51751 : scanCanonicalize (H12AffineFastState.compose env51751 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51751 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51752 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,5393,262144,1024,8461,4112,272392,16,3,8193,16,10509,5393,4096,270605,1284,272393,256,33,5377,513]

theorem envBound51752 : H12AffineFastState.Bounded env51752 := by
  intro p hp
  have h : env51752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51751_51752 : H12AffineEnvironment.transform 5 16 env51751 = env51752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51751 == env51752) = true)

theorem identity51752 : scanCanonicalize (H12AffineFastState.compose env51752 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51752 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51753 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5156,8233,8202,5172,262144,1024,8232,4112,272392,16,3,8193,16,10280,5172,4096,270376,1057,272393,37,33,5156,513]

theorem envBound51753 : H12AffineFastState.Bounded env51753 := by
  intro p hp
  have h : env51753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51752_51753 : H12AffineEnvironment.transform 7 37 env51752 = env51753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51752 == env51753) = true)

theorem identity51753 : scanCanonicalize (H12AffineFastState.compose env51753 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51753 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51754 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5172,262144,1024,0,4112,264224,16,3,41,16,2048,5172,4096,262144,1057,264225,37,33,5156,513]

theorem envBound51754 : H12AffineFastState.Bounded env51754 := by
  intro p hp
  have h : env51754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51753_51754 : H12AffineEnvironment.transform 12 40 env51753 = env51754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51753 == env51754) = true)

theorem identity51754 : scanCanonicalize (H12AffineFastState.compose env51754 (packedSelected [10] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound51754 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env51755 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5172,2049,1024,0,4112,33,16,3,41,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound51755 : H12AffineFastState.Bounded env51755 := by
  intro p hp
  have h : env51755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51754_51755 : H12AffineEnvironment.transform 17 2049 env51754 = env51755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env51754 == env51755) = true)

def env51756 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1044,1,34,1028,2049,1024,0,32,33,16,3,41,16,2048,1028,48,2049,1057,32,37,33,1044,513]

theorem envBound51756 : H12AffineFastState.Bounded env51756 := by
  intro p hp
  have h : env51756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51755_51756 : H12AffineEnvironment.transform 11 48 env51755 = env51756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51755 == env51756) = true)

theorem identity51756 : scanCanonicalize (H12AffineFastState.compose env51756 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51757 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,48,40,33,1,34,49,2049,53,0,32,33,16,3,41,16,2048,49,48,2049,20,32,37,33,33,513]

theorem envBound51757 : H12AffineFastState.Bounded env51757 := by
  intro p hp
  have h : env51757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51756_51757 : H12AffineEnvironment.transform 9 53 env51756 = env51757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51756 == env51757) = true)

theorem identity51757 : scanCanonicalize (H12AffineFastState.compose env51757 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound51757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51758 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,48,40,33,1,34,49,2049,53,0,32,33,16,3,41,16,2048,49,48,2049,20,32,37,33,33,10]

theorem envBound51758 : H12AffineFastState.Bounded env51758 := by
  intro p hp
  have h : env51758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51757_51758 : H12AffineEnvironment.transform 8 11 env51757 = env51758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env51757 == env51758) = true)

def leafEnv51758 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,48,40,33,1,34,49,2049,53,0,32,33,16,3,20,41,1,16,2048,49,48,2049,20,32,37,33,4,35,33,10,1,32,0]

def active51758 : List Nat := [0,1,2,3,4,10]

def tree51758 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51758 : H12WitnessSearch.Good tree51758 := H12GlobalWitnessIndex.good

theorem leafIdentity51758 : H12AffineFastState.composeSystem env51758 rootObs = leafEnv51758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51758 rootObs == leafEnv51758) = true)

theorem terminalChecked51758 : H12PackedTerminal.terminalCheckFast leafEnv51758 active51758 tree51758 = true := by decide +kernel

def env51759 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1045,1,34,1029,2049,1024,0,33,33,16,3,41,16,2048,1029,49,2049,1057,32,37,33,1045,513]

theorem envBound51759 : H12AffineFastState.Bounded env51759 := by
  intro p hp
  have h : env51759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51755_51759 : H12AffineEnvironment.transform 11 49 env51755 = env51759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51755 == env51759) = true)

def env51760 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,49,40,33,1,34,49,2049,52,0,33,33,16,3,41,16,2048,49,49,2049,21,32,37,33,33,513]

theorem envBound51760 : H12AffineFastState.Bounded env51760 := by
  intro p hp
  have h : env51760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51759_51760 : H12AffineEnvironment.transform 9 52 env51759 = env51760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51759 == env51760) = true)

theorem identity51760 : scanCanonicalize (H12AffineFastState.compose env51760 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51761 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,8,1,1,2,17,2049,20,0,1,1,16,3,9,16,2048,17,17,2049,21,0,5,1,1,513]

theorem envBound51761 : H12AffineFastState.Bounded env51761 := by
  intro p hp
  have h : env51761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51760_51761 : H12AffineEnvironment.transform 4 0 env51760 = env51761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51760 == env51761) = true)

def leafEnv51761 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,8,1,1,2,17,2049,20,0,1,1,16,3,21,9,1,16,2048,17,17,2049,21,0,5,1,4,3,1,513,1,1,0]

def active51761 : List Nat := [0,1,2,3,8,10]

def tree51761 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51761 : H12WitnessSearch.Good tree51761 := H12GlobalWitnessIndex.good

theorem leafIdentity51761 : H12AffineFastState.composeSystem env51761 rootObs = leafEnv51761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51761 rootObs == leafEnv51761) = true)

theorem terminalChecked51761 : H12PackedTerminal.terminalCheckFast leafEnv51761 active51761 tree51761 = true := by decide +kernel

def env51762 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,49,40,32,1,34,48,2049,53,0,33,33,16,3,41,16,2048,48,49,2049,20,32,37,33,32,513]

theorem envBound51762 : H12AffineFastState.Bounded env51762 := by
  intro p hp
  have h : env51762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51759_51762 : H12AffineEnvironment.transform 9 53 env51759 = env51762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51759 == env51762) = true)

theorem identity51762 : scanCanonicalize (H12AffineFastState.compose env51762 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound51762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51763 : List Nat := [2,4,8,16,32,16,9,37,10,53,2048,49,40,32,1,34,48,2049,53,0,33,33,16,3,41,16,2048,48,49,2049,20,32,37,33,32,11]

theorem envBound51763 : H12AffineFastState.Bounded env51763 := by
  intro p hp
  have h : env51763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51762_51763 : H12AffineEnvironment.transform 8 10 env51762 = env51763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env51762 == env51763) = true)

def leafEnv51763 : List Nat := [2,4,8,16,32,16,9,37,10,53,2048,49,40,32,1,34,48,2049,53,0,33,33,16,3,20,41,1,16,2048,48,49,2049,20,32,37,33,4,35,32,11,1,33,0]

def active51763 : List Nat := [0,1,2,3,4,10]

def tree51763 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51763 : H12WitnessSearch.Good tree51763 := H12GlobalWitnessIndex.good

theorem leafIdentity51763 : H12AffineFastState.composeSystem env51763 rootObs = leafEnv51763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51763 rootObs == leafEnv51763) = true)

theorem terminalChecked51763 : H12PackedTerminal.terminalCheckFast leafEnv51763 active51763 tree51763 = true := by decide +kernel

def env51764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,4194304,8388608,10577240,8328,64,6705549,8393984,10507601,8795348,2102684,12583064,256,21793,16464,2175562]

theorem envBound51764 : H12AffineFastState.Bounded env51764 := by
  intro p hp
  have h : env51764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51623_51764 : H12AffineEnvironment.transform 14 29909 env51623 = env51764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env51623 == env51764) = true)

def env51765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272512,8388608,10577240,8328,64,2259213,8393984,10507601,8795348,2102684,8661016,256,21793,16464,2175562]

theorem envBound51765 : H12AffineFastState.Bounded env51765 := by
  intro p hp
  have h : env51765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51764_51765 : H12AffineEnvironment.transform 21 272512 env51764 = env51765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51764 == env51765) = true)

theorem identity51765 : scanCanonicalize (H12AffineFastState.compose env51765 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound51765 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,77899,272512,8388608,8410387,8328,64,215366,8393984,8480026,8795348,75223,8661016,256,21793,16464,513]

theorem envBound51766 : H12AffineFastState.Bounded env51766 := by
  intro p hp
  have h : env51766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51765_51766 : H12AffineEnvironment.transform 20 77899 env51765 = env51766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env51765 == env51766) = true)

def env51767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,77899,272392,8388608,8410387,8192,64,215366,8393984,8480026,8795228,75103,8661016,256,21793,16464,513]

theorem envBound51767 : H12AffineFastState.Bounded env51767 := by
  intro p hp
  have h : env51767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51766_51767 : H12AffineEnvironment.transform 6 8 env51766 = env51767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51766 == env51767) = true)

theorem identity51767 : scanCanonicalize (H12AffineFastState.compose env51767 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51767 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env51768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1024,29788,77899,272392,8388608,8410387,8192,64,10588,8393984,8480026,8737862,75103,8661016,256,21793,16464,513]

theorem envBound51768 : H12AffineFastState.Bounded env51768 := by
  intro p hp
  have h : env51768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51767_51768 : H12AffineEnvironment.transform 16 90138 env51767 = env51768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51767 == env51768) = true)

def env51769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1024,29788,77899,272392,16,21763,8192,64,10588,5392,91402,349270,75103,272392,256,21793,16464,513]

theorem envBound51769 : H12AffineFastState.Bounded env51769 := by
  intro p hp
  have h : env51769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51768_51769 : H12AffineEnvironment.transform 22 16 env51768 = env51769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51768 == env51769) = true)

theorem identity51769 : scanCanonicalize (H12AffineFastState.compose env51769 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51769 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79131,262144,1024,8541,77899,272392,16,2,8192,64,10588,5392,77835,328023,75103,272392,256,32,5457,513]

theorem envBound51770 : H12AffineFastState.Bounded env51770 := by
  intro p hp
  have h : env51770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51769_51770 : H12AffineEnvironment.transform 13 5377 env51769 = env51770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51769 == env51770) = true)

theorem identity51770 : scanCanonicalize (H12AffineFastState.compose env51770 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound51770 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9499,4096,262144,1024,8541,5456,272392,16,2,8192,64,10588,5392,5392,271436,68,272392,256,32,5457,513]

theorem envBound51771 : H12AffineFastState.Bounded env51771 := by
  intro p hp
  have h : env51771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51770_51771 : H12AffineEnvironment.transform 15 9499 env51770 = env51771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env51770 == env51771) = true)

theorem identity51771 : scanCanonicalize (H12AffineFastState.compose env51771 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 11577) := by decide +kernel

theorem selectedBound51771 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env51772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9499,4096,11577,1024,8541,5456,1329,16,2,8192,64,10588,5392,5392,2421,68,1329,256,32,5457,513]

theorem envBound51772 : H12AffineFastState.Bounded env51772 := by
  intro p hp
  have h : env51772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51771_51772 : H12AffineEnvironment.transform 17 11577 env51771 = env51772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11577 env51771 == env51772) = true)

theorem identity51772 : scanCanonicalize (H12AffineFastState.compose env51772 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound51772 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env51773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5377,1125,34,4096,2048,1024,1124,5456,1329,16,2,1337,64,3173,5392,5392,2421,68,1329,256,32,5457,513]

theorem envBound51773 : H12AffineFastState.Bounded env51773 := by
  intro p hp
  have h : env51773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51772_51773 : H12AffineEnvironment.transform 12 1337 env51772 = env51773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env51772 == env51773) = true)

theorem identity51773 : scanCanonicalize (H12AffineFastState.compose env51773 (packedSelected [1,3,5,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound51773 : packedSelected [1,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env51774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,1337,5377,1125,34,4096,1296,1024,1124,5456,1329,16,2,1337,64,373,5392,5392,1125,68,1329,256,32,5457,513]

theorem envBound51774 : H12AffineFastState.Bounded env51774 := by
  intro p hp
  have h : env51774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51773_51774 : H12AffineEnvironment.transform 10 1296 env51773 = env51774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env51773 == env51774) = true)

theorem identity51774 : scanCanonicalize (H12AffineFastState.compose env51774 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound51774 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env51775 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,1140,1337,373,1125,34,1140,1296,1024,1124,292,1329,16,2,1337,64,373,356,356,1125,68,1329,256,32,293,513]

theorem envBound51775 : H12AffineFastState.Bounded env51775 := by
  intro p hp
  have h : env51775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51774_51775 : H12AffineEnvironment.transform 11 1140 env51774 = env51775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env51774 == env51775) = true)

theorem identity51775 : scanCanonicalize (H12AffineFastState.compose env51775 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound51775 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env51776 : List Nat := [2,4,8,16,32,64,8,256,292,1024,1296,1140,1337,373,1125,34,1140,1296,1024,1124,292,1329,16,2,1337,64,373,356,356,1125,68,1329,256,32,293,293]

theorem envBound51776 : H12AffineFastState.Bounded env51776 := by
  intro p hp
  have h : env51776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51775_51776 : H12AffineEnvironment.transform 8 292 env51775 = env51776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env51775 == env51776) = true)

theorem identity51776 : scanCanonicalize (H12AffineFastState.compose env51776 (packedSelected [0,1,5] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound51776 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env51777 : List Nat := [2,4,8,16,32,64,8,256,292,84,324,32,365,373,49,34,32,324,84,48,292,357,16,2,365,64,373,356,356,49,68,357,256,32,293,293]

theorem envBound51777 : H12AffineFastState.Bounded env51777 := by
  intro p hp
  have h : env51777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51776_51777 : H12AffineEnvironment.transform 9 84 env51776 = env51777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env51776 == env51777) = true)

theorem identity51777 : scanCanonicalize (H12AffineFastState.compose env51777 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound51777 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51778 : List Nat := [2,4,8,16,32,64,8,101,65,84,33,32,8,16,49,34,32,33,84,48,65,0,16,2,8,64,16,1,1,49,68,0,101,32,64,64]

theorem envBound51778 : H12AffineFastState.Bounded env51778 := by
  intro p hp
  have h : env51778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51777_51778 : H12AffineEnvironment.transform 7 101 env51777 = env51778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env51777 == env51778) = true)

theorem identity51778 : scanCanonicalize (H12AffineFastState.compose env51778 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51778 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51779 : List Nat := [2,4,8,1,32,64,8,101,65,69,33,32,8,1,32,34,32,33,69,33,65,0,1,2,8,64,1,1,1,32,68,0,101,32,64,64]

theorem envBound51779 : H12AffineFastState.Bounded env51779 := by
  intro p hp
  have h : env51779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51778_51779 : H12AffineEnvironment.transform 3 1 env51778 = env51779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51778 == env51779) = true)

theorem identity51779 : scanCanonicalize (H12AffineFastState.compose env51779 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound51779 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51780 : List Nat := [2,4,8,1,32,32,8,5,33,37,33,32,8,1,32,34,32,33,37,33,33,0,1,2,8,32,1,1,1,32,36,0,5,32,32,32]

theorem envBound51780 : H12AffineFastState.Bounded env51780 := by
  intro p hp
  have h : env51780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51779_51780 : H12AffineEnvironment.transform 5 32 env51779 = env51780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env51779 == env51780) = true)

theorem identity51780 : scanCanonicalize (H12AffineFastState.compose env51780 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51780 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51781 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,0,8,1,0,2,0,1,5,1,1,0,1,2,8,0,1,1,1,0,4,0,5,0,0,0]

theorem envBound51781 : H12AffineFastState.Bounded env51781 := by
  intro p hp
  have h : env51781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51780_51781 : H12AffineEnvironment.transform 4 0 env51780 = env51781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51780 == env51781) = true)

def env51782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1024,29788,77899,272392,17,21762,8192,64,10588,5393,91403,349271,75103,272393,256,21793,16464,513]

theorem envBound51782 : H12AffineFastState.Bounded env51782 := by
  intro p hp
  have h : env51782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51768_51782 : H12AffineEnvironment.transform 22 17 env51768 = env51782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env51768 == env51782) = true)

theorem identity51782 : scanCanonicalize (H12AffineFastState.compose env51782 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound51782 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,32041,1024,29788,77899,21793,17,21762,8192,64,10588,5393,91403,76158,75103,21792,256,21793,16464,513]

theorem envBound51783 : H12AffineFastState.Bounded env51783 := by
  intro p hp
  have h : env51783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51782_51783 : H12AffineEnvironment.transform 17 32041 env51782 = env51783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env51782 == env51783) = true)

theorem identity51783 : scanCanonicalize (H12AffineFastState.compose env51783 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51783 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51784 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,29004,65536,90138,30776,273,29005,77899,20528,17,20499,8192,64,10588,4096,90138,76158,73806,20529,256,20528,16464,513]

theorem envBound51784 : H12AffineFastState.Bounded env51784 := by
  intro p hp
  have h : env51784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51783_51784 : H12AffineEnvironment.transform 9 273 env51783 = env51784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51783 == env51784) = true)

theorem identity51784 : scanCanonicalize (H12AffineFastState.compose env51784 (packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound51784 : packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS < 2^1333 := by decide +kernel

def env51785 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,29004,28699,4097,30776,273,29005,16464,20528,17,20499,8192,64,10588,4096,4097,22885,20565,20529,256,20528,16464,513]

theorem envBound51785 : H12AffineFastState.Bounded env51785 := by
  intro p hp
  have h : env51785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51784_51785 : H12AffineEnvironment.transform 15 28699 env51784 = env51785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env51784 == env51785) = true)

def env51786 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,77899,272393,8388608,8410387,8193,64,215366,8393984,8480026,8795229,75102,8661016,256,21793,16464,513]

theorem envBound51786 : H12AffineFastState.Bounded env51786 := by
  intro p hp
  have h : env51786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51766_51786 : H12AffineEnvironment.transform 6 9 env51766 = env51786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51766 == env51786) = true)

def env51787 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,77899,272393,16,21763,8193,64,215366,5392,91402,406605,75102,272392,256,21793,16464,513]

theorem envBound51787 : H12AffineFastState.Bounded env51787 := by
  intro p hp
  have h : env51787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51786_51787 : H12AffineEnvironment.transform 22 16 env51786 = env51787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51786 == env51787) = true)

def env51788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,77899,272393,16,3,8193,64,203846,5392,77834,406605,75102,272392,256,33,5456,513]

theorem envBound51788 : H12AffineFastState.Bounded env51788 := by
  intro p hp
  have h : env51788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51787_51788 : H12AffineEnvironment.transform 13 5376 env51787 = env51788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51787 == env51788) = true)

theorem identity51788 : scanCanonicalize (H12AffineFastState.compose env51788 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound51788 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,79130,262144,1024,8541,77899,272393,16,3,8193,64,10588,5392,77834,328023,75102,272392,256,33,5456,513]

theorem envBound51789 : H12AffineFastState.Bounded env51789 := by
  intro p hp
  have h : env51789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51788_51789 : H12AffineEnvironment.transform 16 79130 env51788 = env51789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env51788 == env51789) = true)

def env51790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77899,272393,16,2,8193,64,203847,5392,77835,406605,75102,272392,256,32,5457,513]

theorem envBound51790 : H12AffineFastState.Bounded env51790 := by
  intro p hp
  have h : env51790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51787_51790 : H12AffineEnvironment.transform 13 5377 env51787 = env51790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51787 == env51790) = true)

theorem identity51790 : scanCanonicalize (H12AffineFastState.compose env51790 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51790 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env51791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,65536,131072,262144,1024,1,69910,264532,16,2,348,64,203847,5392,69974,398608,66563,264533,256,32,5457,513]

theorem envBound51791 : H12AffineFastState.Bounded env51791 := by
  intro p hp
  have h : env51791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51790_51791 : H12AffineEnvironment.transform 12 349 env51790 = env51791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51790 == env51791) = true)

theorem identity51791 : scanCanonicalize (H12AffineFastState.compose env51791 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound51791 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,65536,131072,138341,1024,1,69910,136497,16,2,348,64,203847,5392,69974,2421,66563,136496,256,32,5457,513]

theorem envBound51792 : H12AffineFastState.Bounded env51792 := by
  intro p hp
  have h : env51792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51791_51792 : H12AffineEnvironment.transform 17 138341 env51791 = env51792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env51791 == env51792) = true)

theorem identity51792 : scanCanonicalize (H12AffineFastState.compose env51792 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound51792 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env51793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,65536,5393,2420,1024,1,69910,32,16,2,348,64,67926,5392,69974,2421,66563,33,256,32,5457,513]

theorem envBound51793 : H12AffineFastState.Bounded env51793 := by
  intro p hp
  have h : env51793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51792_51793 : H12AffineEnvironment.transform 16 5393 env51792 = env51793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env51792 == env51793) = true)

theorem identity51793 : scanCanonicalize (H12AffineFastState.compose env51793 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound51793 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5393,2420,1024,1,4161,32,16,2,348,64,2049,5392,4097,2421,1364,33,256,32,5457,513]

theorem envBound51794 : H12AffineFastState.Bounded env51794 := by
  intro p hp
  have h : env51794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51793_51794 : H12AffineEnvironment.transform 15 343 env51793 = env51794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env51793 == env51794) = true)

theorem identity51794 : scanCanonicalize (H12AffineFastState.compose env51794 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51794 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51795 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,349,4405,0,343,4389,2420,52,1,4161,32,16,2,348,64,2049,4388,4097,2421,352,33,256,32,4453,513]

theorem envBound51795 : H12AffineFastState.Bounded env51795 := by
  intro p hp
  have h : env51795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51794_51795 : H12AffineEnvironment.transform 9 52 env51794 = env51795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51794 == env51795) = true)

theorem identity51795 : scanCanonicalize (H12AffineFastState.compose env51795 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51795 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51796 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4405,0,262,4389,2341,52,1,4112,32,16,2,269,17,2049,4388,4097,2340,305,33,256,32,4404,513]

theorem envBound51796 : H12AffineFastState.Bounded env51796 := by
  intro p hp
  have h : env51796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51795_51796 : H12AffineEnvironment.transform 5 17 env51795 = env51796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51795 == env51796) = true)

theorem identity51796 : scanCanonicalize (H12AffineFastState.compose env51796 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51797 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,4096,9,4144,0,3,4128,2080,52,1,4112,32,16,2,8,17,2049,4129,4097,2081,52,33,5,32,4145,513]

theorem envBound51797 : H12AffineFastState.Bounded env51797 := by
  intro p hp
  have h : env51797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51796_51797 : H12AffineEnvironment.transform 7 5 env51796 = env51797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51796 == env51797) = true)

theorem identity51797 : scanCanonicalize (H12AffineFastState.compose env51797 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound51797 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51798 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,2608,9,2560,0,3,2576,2080,52,1,2592,32,16,2,8,17,2049,2577,2609,2081,52,33,5,32,2561,513]

theorem envBound51798 : H12AffineFastState.Bounded env51798 := by
  intro p hp
  have h : env51798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51797_51798 : H12AffineEnvironment.transform 11 2608 env51797 = env51798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env51797 == env51798) = true)

theorem identity51798 : scanCanonicalize (H12AffineFastState.compose env51798 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound51798 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51799 : List Nat := [2,4,8,16,32,17,9,5,512,52,545,17,9,33,0,3,49,513,52,1,1,32,16,2,8,17,544,48,16,512,52,33,5,32,32,513]

theorem envBound51799 : H12AffineFastState.Bounded env51799 := by
  intro p hp
  have h : env51799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51798_51799 : H12AffineEnvironment.transform 10 545 env51798 = env51799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env51798 == env51799) = true)

theorem identity51799 : scanCanonicalize (H12AffineFastState.compose env51799 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound51799 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51800 : List Nat := [2,4,8,16,32,17,9,5,16,52,49,17,9,33,0,3,49,17,52,1,1,32,16,2,8,17,48,48,16,16,52,33,5,32,32,17]

theorem envBound51800 : H12AffineFastState.Bounded env51800 := by
  intro p hp
  have h : env51800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51799_51800 : H12AffineEnvironment.transform 8 16 env51799 = env51800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51799 == env51800) = true)

theorem identity51800 : scanCanonicalize (H12AffineFastState.compose env51800 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51800 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51801 : List Nat := [2,4,8,16,1,17,9,5,16,21,16,17,9,0,0,3,16,17,21,1,1,1,16,2,8,17,17,17,16,16,21,0,5,1,1,17]

theorem envBound51801 : H12AffineFastState.Bounded env51801 := by
  intro p hp
  have h : env51801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51800_51801 : H12AffineEnvironment.transform 4 1 env51800 = env51801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51800 == env51801) = true)

theorem identity51801 : scanCanonicalize (H12AffineFastState.compose env51801 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51802 : List Nat := [2,4,8,10,1,11,9,5,10,15,10,11,9,0,0,3,10,11,15,1,1,1,10,2,8,11,11,11,10,10,15,0,5,1,1,11]

theorem envBound51802 : H12AffineFastState.Bounded env51802 := by
  intro p hp
  have h : env51802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51801_51802 : H12AffineEnvironment.transform 3 10 env51801 = env51802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51801 == env51802) = true)

def env51803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,77899,272393,17,21762,8193,64,215366,5393,91403,406604,75102,272393,256,21793,16464,513]

theorem envBound51803 : H12AffineFastState.Bounded env51803 := by
  intro p hp
  have h : env51803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51786_51803 : H12AffineEnvironment.transform 22 17 env51786 = env51803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env51786 == env51803) = true)

theorem identity51803 : scanCanonicalize (H12AffineFastState.compose env51803 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound51803 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1024,29789,77899,272393,17,21762,8193,64,10588,5393,91403,349270,75102,272393,256,21793,16464,513]

theorem envBound51804 : H12AffineFastState.Bounded env51804 := by
  intro p hp
  have h : env51804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51803_51804 : H12AffineEnvironment.transform 16 90138 env51803 = env51804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env51803 == env51804) = true)

theorem identity51804 : scanCanonicalize (H12AffineFastState.compose env51804 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound51804 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,10281,1024,29789,77899,32,17,21762,8193,64,10588,5393,91403,97407,75102,32,256,21793,16464,513]

theorem envBound51805 : H12AffineFastState.Bounded env51805 := by
  intro p hp
  have h : env51805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51804_51805 : H12AffineEnvironment.transform 17 10281 env51804 = env51805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51804 == env51805) = true)

theorem identity51805 : scanCanonicalize (H12AffineFastState.compose env51805 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound51805 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,5393,10281,1024,29789,17728,32,17,21762,8193,64,10588,5393,4096,2420,20565,32,256,21793,16464,513]

theorem envBound51806 : H12AffineFastState.Bounded env51806 := by
  intro p hp
  have h : env51806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51805_51806 : H12AffineEnvironment.transform 15 29963 env51805 = env51806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env51805 == env51806) = true)

theorem identity51806 : scanCanonicalize (H12AffineFastState.compose env51806 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51806 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51807 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,29963,5393,10281,1024,29708,17681,32,17,21762,8193,17,10509,5393,4096,2341,20484,32,256,21793,16385,513]

theorem envBound51807 : H12AffineFastState.Bounded env51807 := by
  intro p hp
  have h : env51807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51806_51807 : H12AffineEnvironment.transform 5 17 env51806 = env51807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51806 == env51807) = true)

theorem identity51807 : scanCanonicalize (H12AffineFastState.compose env51807 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51807 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51808 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8203,5393,10281,1024,8460,4113,32,17,2,8193,17,10509,5393,4096,2341,1284,32,256,33,5377,513]

theorem envBound51808 : H12AffineFastState.Bounded env51808 := by
  intro p hp
  have h : env51808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51807_51808 : H12AffineEnvironment.transform 13 5376 env51807 = env51808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51807 == env51808) = true)

theorem identity51808 : scanCanonicalize (H12AffineFastState.compose env51808 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound51808 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51809 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,4153,5376,4404,4146,5393,6160,1024,4405,4113,32,17,2,4152,17,6452,5393,4096,2341,1284,32,256,33,5377,513]

theorem envBound51809 : H12AffineFastState.Bounded env51809 := by
  intro p hp
  have h : env51809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51808_51809 : H12AffineEnvironment.transform 12 4153 env51808 = env51809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env51808 == env51809) = true)

theorem identity51809 : scanCanonicalize (H12AffineFastState.compose env51809 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound51809 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51810 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,309,268,1077,1,263,1060,2341,1024,0,292,32,17,2,269,17,2049,1060,309,2341,1284,32,256,33,1076,513]

theorem envBound51810 : H12AffineFastState.Bounded env51810 := by
  intro p hp
  have h : env51810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51809_51810 : H12AffineEnvironment.transform 11 309 env51809 = env51810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env51809 == env51810) = true)

theorem identity51810 : scanCanonicalize (H12AffineFastState.compose env51810 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51810 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51811 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,309,268,292,1,263,309,2341,273,0,292,32,17,2,269,17,2049,309,309,2341,21,32,256,33,293,513]

theorem envBound51811 : H12AffineFastState.Bounded env51811 := by
  intro p hp
  have h : env51811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51810_51811 : H12AffineEnvironment.transform 9 273 env51810 = env51811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51810 == env51811) = true)

theorem identity51811 : scanCanonicalize (H12AffineFastState.compose env51811 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51811 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51812 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,16,41,1,1,34,16,2048,52,0,1,32,17,2,40,17,2049,16,16,2048,21,32,37,33,0,513]

theorem envBound51812 : H12AffineFastState.Bounded env51812 := by
  intro p hp
  have h : env51812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51811_51812 : H12AffineEnvironment.transform 7 37 env51811 = env51812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51811 == env51812) = true)

theorem identity51812 : scanCanonicalize (H12AffineFastState.compose env51812 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51813 : List Nat := [2,4,8,16,32,17,9,37,512,52,0,16,41,1,1,34,16,0,52,0,1,32,17,2,40,17,1,16,16,0,21,32,37,33,0,513]

theorem envBound51813 : H12AffineFastState.Bounded env51813 := by
  intro p hp
  have h : env51813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51812_51813 : H12AffineEnvironment.transform 10 0 env51812 = env51813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51812 == env51813) = true)

theorem identity51813 : scanCanonicalize (H12AffineFastState.compose env51813 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51813 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51814 : List Nat := [2,4,2,16,32,17,3,37,512,52,0,16,35,1,1,34,16,0,52,0,1,32,17,2,34,17,1,16,16,0,21,32,37,33,0,513]

theorem envBound51814 : H12AffineFastState.Bounded env51814 := by
  intro p hp
  have h : env51814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51813_51814 : H12AffineEnvironment.transform 2 2 env51813 = env51814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51813 == env51814) = true)

def env51815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,8388608,10577240,8328,64,2259212,8393984,10507601,8795348,2102684,8661017,256,21793,16464,2175562]

theorem envBound51815 : H12AffineFastState.Bounded env51815 := by
  intro p hp
  have h : env51815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51764_51815 : H12AffineEnvironment.transform 21 272513 env51764 = env51815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51764 == env51815) = true)

theorem identity51815 : scanCanonicalize (H12AffineFastState.compose env51815 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 2175067) := by decide +kernel

theorem selectedBound51815 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,2175067,21763,8328,64,2259212,2172251,91402,2557071,2102684,2431042,256,21793,16464,2175562]

theorem envBound51816 : H12AffineFastState.Bounded env51816 := by
  intro p hp
  have h : env51816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51815_51816 : H12AffineEnvironment.transform 22 2175067 env51815 = env51816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2175067 env51815 == env51816) = true)

def env51817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,2097152,33,2175067,21763,8328,64,2259212,2172251,91402,2305071,2102684,2175202,256,21793,16464,2175562]

theorem envBound51817 : H12AffineFastState.Bounded env51817 := by
  intro p hp
  have h : env51817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51816_51817 : H12AffineEnvironment.transform 17 10400 env51816 = env51817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env51816 == env51817) = true)

def env51818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1024,8660,2097152,33,2175067,3,8328,64,2239500,2172251,77834,2305071,2102684,2175202,256,33,5456,2175562]

theorem envBound51818 : H12AffineFastState.Bounded env51818 := by
  intro p hp
  have h : env51818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51817_51818 : H12AffineEnvironment.transform 13 5376 env51817 = env51818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51817 == env51818) = true)

theorem identity51818 : scanCanonicalize (H12AffineFastState.compose env51818 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51818 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,2097152,33,2175067,3,8193,64,2239500,2172251,77834,2305071,2102549,2175083,256,33,5456,2175562]

theorem envBound51819 : H12AffineFastState.Bounded env51819 := by
  intro p hp
  have h : env51819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51818_51819 : H12AffineEnvironment.transform 6 9 env51818 = env51819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51818 == env51819) = true)

theorem identity51819 : scanCanonicalize (H12AffineFastState.compose env51819 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 12620) := by decide +kernel

theorem selectedBound51819 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env51820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,12620,33,65815,3,8193,64,138560,70679,77834,204131,9305,65831,256,33,5456,66310]

theorem envBound51820 : H12AffineFastState.Bounded env51820 := by
  intro p hp
  have h : env51820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51819_51820 : H12AffineEnvironment.transform 20 12620 env51819 = env51820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12620 env51819 == env51820) = true)

theorem identity51820 : scanCanonicalize (H12AffineFastState.compose env51820 (packedSelected [2,4,6,11,16,18,22] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound51820 : packedSelected [2,4,6,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env51821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,13389,10281,1024,8541,12620,33,65815,3,8193,64,10509,70679,77834,76078,9305,65831,256,33,5456,66310]

theorem envBound51821 : H12AffineFastState.Bounded env51821 := by
  intro p hp
  have h : env51821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51820_51821 : H12AffineEnvironment.transform 16 13389 env51820 = env51821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env51820 == env51821) = true)

theorem identity51821 : scanCanonicalize (H12AffineFastState.compose env51821 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51821 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env51822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,13389,10281,1024,8541,12620,33,8477,3,8193,64,10509,13341,4096,2340,9305,8493,256,33,5456,8972]

theorem envBound51822 : H12AffineFastState.Bounded env51822 := by
  intro p hp
  have h : env51822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51821_51822 : H12AffineEnvironment.transform 15 8202 env51821 = env51822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51821 == env51822) = true)

theorem identity51822 : scanCanonicalize (H12AffineFastState.compose env51822 (packedSelected [0,3,4,5,6,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51822 : packedSelected [0,3,4,5,6,14] rootPS < 2^1333 := by decide +kernel

def env51823 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5156,8312,8202,13389,10281,1024,8313,12392,33,8249,3,8193,64,10281,13341,4096,2048,9305,8201,36,33,5236,8744]

theorem envBound51823 : H12AffineFastState.Bounded env51823 := by
  intro p hp
  have h : env51823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51822_51823 : H12AffineEnvironment.transform 7 36 env51822 = env51823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51822 == env51823) = true)

theorem identity51823 : scanCanonicalize (H12AffineFastState.compose env51823 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51823 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env51824 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,5156,8232,8202,13341,10281,1024,8233,12344,33,8249,3,8193,16,10281,13341,4096,2048,9225,8201,36,33,5156,8744]

theorem envBound51824 : H12AffineFastState.Bounded env51824 := by
  intro p hp
  have h : env51824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51823_51824 : H12AffineEnvironment.transform 5 16 env51823 = env51824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51823 == env51824) = true)

def env51825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1024,8661,2097152,33,2175067,2,8328,64,2239501,2172251,77835,2305071,2102684,2175202,256,32,5457,2175562]

theorem envBound51825 : H12AffineFastState.Bounded env51825 := by
  intro p hp
  have h : env51825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51817_51825 : H12AffineEnvironment.transform 13 5377 env51817 = env51825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51817 == env51825) = true)

theorem identity51825 : scanCanonicalize (H12AffineFastState.compose env51825 (packedSelected [0,3,4,5,7,8,10,12,15,16,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound51825 : packedSelected [0,3,4,5,7,8,10,12,15,16,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env51826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1024,8661,77899,33,16,2,8328,64,203846,5392,77835,138340,75223,169,256,32,5457,513]

theorem envBound51826 : H12AffineFastState.Bounded env51826 := by
  intro p hp
  have h : env51826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51825_51826 : H12AffineEnvironment.transform 20 77899 env51825 = env51826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env51825 == env51826) = true)

theorem identity51826 : scanCanonicalize (H12AffineFastState.compose env51826 (packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound51826 : packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env51827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,131072,10400,1024,8661,4297,33,16,2,8328,64,146628,5392,4233,138340,1365,169,256,32,5457,513]

theorem envBound51827 : H12AffineFastState.Bounded env51827 := by
  intro p hp
  have h : env51827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51826_51827 : H12AffineEnvironment.transform 15 8322 env51826 = env51827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env51826 == env51827) = true)

theorem identity51827 : scanCanonicalize (H12AffineFastState.compose env51827 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51827 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env51828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,478,131072,2556,1024,137,4297,33,16,2,468,64,138648,5392,4233,138340,1365,169,256,32,5457,513]

theorem envBound51828 : H12AffineFastState.Bounded env51828 := by
  intro p hp
  have h : env51828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51827_51828 : H12AffineEnvironment.transform 12 348 env51827 = env51828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51827 == env51828) = true)

theorem identity51828 : scanCanonicalize (H12AffineFastState.compose env51828 (packedSelected [2,4,6,9,10,12,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound51828 : packedSelected [2,4,6,9,10,12,19,23] rootPS < 2^1333 := by decide +kernel

def env51829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,478,5529,2556,1024,137,4297,33,16,2,468,64,2049,5392,4233,2557,1365,169,256,32,5457,513]

theorem envBound51829 : H12AffineFastState.Bounded env51829 := by
  intro p hp
  have h : env51829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51828_51829 : H12AffineEnvironment.transform 16 5529 env51828 = env51829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env51828 == env51829) = true)

theorem identity51829 : scanCanonicalize (H12AffineFastState.compose env51829 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51829 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env51830 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,136,399,5529,2477,1024,137,4248,33,16,2,389,17,2049,5392,4233,2476,1284,169,256,32,5376,513]

theorem envBound51830 : H12AffineFastState.Bounded env51830 := by
  intro p hp
  have h : env51830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51829_51830 : H12AffineEnvironment.transform 5 17 env51829 = env51830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51829 == env51830) = true)

theorem identity51830 : scanCanonicalize (H12AffineFastState.compose env51830 (packedSelected [0,1,4,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound51830 : packedSelected [0,1,4,5,10] rootPS < 2^1333 := by decide +kernel

def env51831 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3244,269,2477,136,399,2357,2477,1024,137,3124,33,16,2,389,17,2049,2492,3109,2476,1284,169,256,32,2476,513]

theorem envBound51831 : H12AffineFastState.Bounded env51831 := by
  intro p hp
  have h : env51831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51830_51831 : H12AffineEnvironment.transform 11 3244 env51830 = env51831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env51830 == env51831) = true)

theorem identity51831 : scanCanonicalize (H12AffineFastState.compose env51831 (packedSelected [0,4,5,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51831 : packedSelected [0,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env51832 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,2200,269,2477,136,399,2357,2477,52,137,2048,33,16,2,389,17,2049,2492,2065,2476,304,169,256,32,2476,513]

theorem envBound51832 : H12AffineFastState.Bounded env51832 := by
  intro p hp
  have h : env51832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51831_51832 : H12AffineEnvironment.transform 9 52 env51831 = env51832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51831 == env51832) = true)

theorem identity51832 : scanCanonicalize (H12AffineFastState.compose env51832 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51832 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env51833 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2064,269,2341,0,263,2357,2341,52,1,2048,33,16,2,269,17,2049,2356,2065,2340,304,33,256,32,2340,513]

theorem envBound51833 : H12AffineFastState.Bounded env51833 := by
  intro p hp
  have h : env51833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51832_51833 : H12AffineEnvironment.transform 6 8 env51832 = env51833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51832 == env51833) = true)

theorem identity51833 : scanCanonicalize (H12AffineFastState.compose env51833 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51834 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2064,40,2048,0,34,2064,2048,52,1,2048,33,16,2,40,17,2049,2065,2065,2049,21,33,37,32,2049,513]

theorem envBound51834 : H12AffineFastState.Bounded env51834 := by
  intro p hp
  have h : env51834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51833_51834 : H12AffineEnvironment.transform 7 37 env51833 = env51834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51833 == env51834) = true)

theorem identity51834 : scanCanonicalize (H12AffineFastState.compose env51834 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound51834 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51835 : List Nat := [2,4,8,16,32,17,8,37,33,52,2048,2064,40,2048,0,34,2064,2048,52,1,2048,33,16,2,40,17,2049,2065,2065,2049,21,33,37,32,2049,32]

theorem envBound51835 : H12AffineFastState.Bounded env51835 := by
  intro p hp
  have h : env51835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51834_51835 : H12AffineEnvironment.transform 8 33 env51834 = env51835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env51834 == env51835) = true)

theorem identity51835 : scanCanonicalize (H12AffineFastState.compose env51835 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51835 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51836 : List Nat := [2,4,8,16,1,17,8,4,0,21,2048,2064,9,2048,0,3,2064,2048,21,1,2048,0,16,2,9,17,2049,2065,2065,2049,21,0,4,1,2049,1]

theorem envBound51836 : H12AffineFastState.Bounded env51836 := by
  intro p hp
  have h : env51836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51835_51836 : H12AffineEnvironment.transform 4 1 env51835 = env51836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51835 == env51836) = true)

def env51837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,2097152,32,2175067,21763,8328,64,2259212,2172251,91402,2305070,2102684,2175203,256,21793,16464,2175562]

theorem envBound51837 : H12AffineFastState.Bounded env51837 := by
  intro p hp
  have h : env51837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51816_51837 : H12AffineEnvironment.transform 17 10401 env51816 = env51837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env51816 == env51837) = true)

theorem identity51837 : scanCanonicalize (H12AffineFastState.compose env51837 (packedSelected [1,11,17,18,19,23,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 17864) := by decide +kernel

theorem selectedBound51837 : packedSelected [1,11,17,18,19,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env51838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,17864,32,95635,21763,8328,64,146628,90259,91402,223718,20564,95531,256,21793,16464,96130]

theorem envBound51838 : H12AffineFastState.Bounded env51838 := by
  intro p hp
  have h : env51838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51837_51838 : H12AffineEnvironment.transform 20 17864 env51837 = env51838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env51837 == env51838) = true)

theorem identity51838 : scanCanonicalize (H12AffineFastState.compose env51838 (packedSelected [1,3,10,12,15,17,19,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51838 : packedSelected [1,3,10,12,15,17,19,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env51839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,10401,1024,29908,17864,32,21913,21763,8328,64,146628,16537,17664,149996,20564,21793,256,21793,16464,22408]

theorem envBound51839 : H12AffineFastState.Bounded env51839 := by
  intro p hp
  have h : env51839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51838_51839 : H12AffineEnvironment.transform 15 8202 env51838 = env51839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51838 == env51839) = true)

theorem identity51839 : scanCanonicalize (H12AffineFastState.compose env51839 (packedSelected [0,1,2,3,5,7,8,9,10,11,17,18,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16877) := by decide +kernel

theorem selectedBound51839 : packedSelected [0,1,2,3,5,7,8,9,10,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env51840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,16877,10401,1024,29908,17864,32,21913,21763,8328,64,32041,16537,17664,2049,20564,21793,256,21793,16464,22408]

theorem envBound51840 : H12AffineFastState.Bounded env51840 := by
  intro p hp
  have h : env51840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51839_51840 : H12AffineEnvironment.transform 16 16877 env51839 = env51840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16877 env51839 == env51840) = true)

theorem identity51840 : scanCanonicalize (H12AffineFastState.compose env51840 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound51840 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env51841 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,29909,8202,16400,10401,1024,29908,17461,32,21604,21758,8328,64,31956,16537,17661,2049,20564,21724,253,21724,16464,22133]

theorem envBound51841 : H12AffineFastState.Bounded env51841 := by
  intro p hp
  have h : env51841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51840_51841 : H12AffineEnvironment.transform 7 253 env51840 = env51841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env51840 == env51841) = true)

theorem identity51841 : scanCanonicalize (H12AffineFastState.compose env51841 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound51841 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env51842 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5236,8353,8202,5220,10401,1024,8352,4161,32,16,138,8328,64,10400,5357,4233,2049,1056,168,253,168,5156,513]

theorem envBound51842 : H12AffineFastState.Bounded env51842 := by
  intro p hp
  have h : env51842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51841_51842 : H12AffineEnvironment.transform 13 5236 env51841 = env51842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env51841 == env51842) = true)

theorem identity51842 : scanCanonicalize (H12AffineFastState.compose env51842 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51842 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51843 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5156,8353,8202,5172,10401,1024,8352,4113,32,16,138,8328,16,10400,5309,4233,2049,1056,168,173,168,5156,513]

theorem envBound51843 : H12AffineFastState.Bounded env51843 := by
  intro p hp
  have h : env51843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51842_51843 : H12AffineEnvironment.transform 5 16 env51842 = env51843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51842 == env51843) = true)

theorem identity51843 : scanCanonicalize (H12AffineFastState.compose env51843 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51843 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51844 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,5156,8233,8202,5172,10281,1024,8232,4113,32,16,2,8192,16,10280,5173,4097,2049,1056,32,37,32,5156,513]

theorem envBound51844 : H12AffineFastState.Bounded env51844 := by
  intro p hp
  have h : env51844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51843_51844 : H12AffineEnvironment.transform 6 8 env51843 = env51844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51843 == env51844) = true)

theorem identity51844 : scanCanonicalize (H12AffineFastState.compose env51844 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51844 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51845 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,8192,4113,8233,8202,4097,10281,53,8232,4113,32,16,2,8192,16,10280,4096,4097,2049,21,32,37,32,4113,513]

theorem envBound51845 : H12AffineFastState.Bounded env51845 := by
  intro p hp
  have h : env51845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51844_51845 : H12AffineEnvironment.transform 9 53 env51844 = env51845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51844 == env51845) = true)

theorem identity51845 : scanCanonicalize (H12AffineFastState.compose env51845 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound51845 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51846 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,552,4113,513,546,4097,2561,53,512,4113,32,16,2,552,16,2560,4096,4097,2049,21,32,37,32,4113,513]

theorem envBound51846 : H12AffineFastState.Bounded env51846 := by
  intro p hp
  have h : env51846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51845_51846 : H12AffineEnvironment.transform 12 552 env51845 = env51846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env51845 == env51846) = true)

theorem identity51846 : scanCanonicalize (H12AffineFastState.compose env51846 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound51846 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env51847 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2107,552,2090,513,546,2106,2561,53,512,2090,32,16,2,552,16,2560,2107,2106,2049,21,32,37,32,2090,513]

theorem envBound51847 : H12AffineFastState.Bounded env51847 := by
  intro p hp
  have h : env51847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51846_51847 : H12AffineEnvironment.transform 11 2107 env51846 = env51847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env51846 == env51847) = true)

theorem identity51847 : scanCanonicalize (H12AffineFastState.compose env51847 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51847 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env51848 : List Nat := [2,4,8,16,32,16,8,37,1,53,2048,2107,41,2090,0,35,2106,2048,53,1,2090,32,16,2,41,16,2049,2107,2106,2049,21,32,37,32,2090,0]

theorem envBound51848 : H12AffineFastState.Bounded env51848 := by
  intro p hp
  have h : env51848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51847_51848 : H12AffineEnvironment.transform 8 1 env51847 = env51848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51847 == env51848) = true)

theorem identity51848 : scanCanonicalize (H12AffineFastState.compose env51848 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound51848 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51849 : List Nat := [2,4,8,16,32,16,8,37,1,53,43,16,41,1,0,35,17,43,53,1,1,32,16,2,41,16,42,16,17,42,21,32,37,32,1,0]

theorem envBound51849 : H12AffineFastState.Bounded env51849 := by
  intro p hp
  have h : env51849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51848_51849 : H12AffineEnvironment.transform 10 43 env51848 = env51849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env51848 == env51849) = true)

theorem identity51849 : scanCanonicalize (H12AffineFastState.compose env51849 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51849 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51850 : List Nat := [2,4,8,16,11,16,8,14,1,30,0,16,2,1,0,8,17,0,30,1,1,11,16,2,2,16,1,16,17,1,21,11,14,11,1,0]

theorem envBound51850 : H12AffineFastState.Bounded env51850 := by
  intro p hp
  have h : env51850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51849_51850 : H12AffineEnvironment.transform 4 11 env51849 = env51850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51849 == env51850) = true)

def env51851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound51851 : H12AffineFastState.Bounded env51851 := by
  intro p hp
  have h : env51851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51621_51851 : H12AffineEnvironment.transform 18 1025 env51621 = env51851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env51621 == env51851) = true)

theorem identity51851 : scanCanonicalize (H12AffineFastState.compose env51851 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 165336) := by decide +kernel

theorem selectedBound51851 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,8388608,16777216,8328,64,29868033,16974164,8573065,8830976,25265169,21225496,257,25379189,25403600,25207750]

theorem envBound51852 : H12AffineFastState.Bounded env51852 := by
  intro p hp
  have h : env51852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51851_51852 : H12AffineEnvironment.transform 20 165336 env51851 = env51852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env51851 == env51852) = true)

def env51853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,8388608,8590420,8328,64,4510805,8393984,8573065,8830976,168005,12645452,257,21793,46212,243602]

theorem envBound51853 : H12AffineFastState.Bounded env51853 := by
  intro p hp
  have h : env51853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51852_51853 : H12AffineEnvironment.transform 23 8590420 env51852 = env51853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590420 env51852 == env51853) = true)

def env51854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,169352,98780,8328,64,4510805,163976,17665,284040,168005,4350404,257,21793,46212,243602]

theorem envBound51854 : H12AffineFastState.Bounded env51854 := by
  intro p hp
  have h : env51854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51853_51854 : H12AffineEnvironment.transform 22 169352 env51853 = env51854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env51853 == env51854) = true)

def env51855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272512,169352,98780,8328,64,64725,163976,17665,284040,168005,411972,257,21793,46212,243602]

theorem envBound51855 : H12AffineFastState.Bounded env51855 := by
  intro p hp
  have h : env51855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51854_51855 : H12AffineEnvironment.transform 21 272512 env51854 = env51855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51854 == env51855) = true)

def env51856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272392,169216,98644,8192,64,64605,163840,17665,283904,168005,411972,257,21793,46092,243482]

theorem envBound51856 : H12AffineFastState.Bounded env51856 := by
  intro p hp
  have h : env51856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51855_51856 : H12AffineEnvironment.transform 6 8 env51855 = env51856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51855 == env51856) = true)

def env51857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272392,16,98644,8192,64,64605,5392,17665,283904,1365,318548,257,21793,46092,74250]

theorem envBound51857 : H12AffineFastState.Bounded env51857 := by
  intro p hp
  have h : env51857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51856_51857 : H12AffineEnvironment.transform 16 38160 env51856 = env51857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env51856 == env51857) = true)

theorem identity51857 : scanCanonicalize (H12AffineFastState.compose env51857 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51857 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env51858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,4160,272392,16,41311,8192,64,64605,5392,17665,283904,1365,318548,257,21793,46092,513]

theorem envBound51858 : H12AffineFastState.Bounded env51858 := by
  intro p hp
  have h : env51858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51857_51858 : H12AffineEnvironment.transform 15 8203 env51857 = env51858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51857 == env51858) = true)

theorem identity51858 : scanCanonicalize (H12AffineFastState.compose env51858 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound51858 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8203,16401,262144,1025,21760,4160,272392,16,29790,8192,64,10588,5392,17665,283904,1365,264533,257,21793,24845,513]

theorem envBound51859 : H12AffineFastState.Bounded env51859 := by
  intro p hp
  have h : env51859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51858_51859 : H12AffineEnvironment.transform 14 21761 env51858 = env51859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env51858 == env51859) = true)

theorem identity51859 : scanCanonicalize (H12AffineFastState.compose env51859 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound51859 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,8203,13389,262144,1025,8540,4160,272392,16,2,8192,64,10588,5392,12637,270684,1365,264533,257,8573,5457,513]

theorem envBound51860 : H12AffineFastState.Bounded env51860 := by
  intro p hp
  have h : env51860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51859_51860 : H12AffineEnvironment.transform 13 13404 env51859 = env51860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env51859 == env51860) = true)

theorem identity51860 : scanCanonicalize (H12AffineFastState.compose env51860 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51860 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,80,262,5440,262144,1025,81,4160,264453,16,2,269,64,2129,5392,4176,262225,1365,264533,257,112,5457,513]

theorem envBound51861 : H12AffineFastState.Bounded env51861 := by
  intro p hp
  have h : env51861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51860_51861 : H12AffineEnvironment.transform 12 269 env51860 = env51861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51860 == env51861) = true)

theorem identity51861 : scanCanonicalize (H12AffineFastState.compose env51861 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51861 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51862 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,5237,80,34,5220,262144,1025,81,4160,264225,16,2,41,64,2129,5172,4176,262225,1137,264305,37,112,5237,513]

theorem envBound51862 : H12AffineFastState.Bounded env51862 := by
  intro p hp
  have h : env51862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51861_51862 : H12AffineEnvironment.transform 7 36 env51861 = env51862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51861 == env51862) = true)

theorem identity51862 : scanCanonicalize (H12AffineFastState.compose env51862 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51862 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51863 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5156,1,34,5173,262144,1025,0,4113,264225,16,2,41,17,2048,5172,4097,262144,1056,264224,37,33,5156,513]

theorem envBound51863 : H12AffineFastState.Bounded env51863 := by
  intro p hp
  have h : env51863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51862_51863 : H12AffineEnvironment.transform 5 17 env51862 = env51863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51862 == env51863) = true)

theorem identity51863 : scanCanonicalize (H12AffineFastState.compose env51863 (packedSelected [0,4] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound51863 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51864 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5156,1,34,5173,2048,1025,0,4113,33,16,2,41,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound51864 : H12AffineFastState.Bounded env51864 := by
  intro p hp
  have h : env51864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51863_51864 : H12AffineEnvironment.transform 17 2048 env51863 = env51864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env51863 == env51864) = true)

def env51865 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,41,1044,1,34,1029,2048,1025,0,33,33,16,2,41,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound51865 : H12AffineFastState.Bounded env51865 := by
  intro p hp
  have h : env51865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51864_51865 : H12AffineEnvironment.transform 11 48 env51864 = env51865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51864 == env51865) = true)

theorem identity51865 : scanCanonicalize (H12AffineFastState.compose env51865 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound51865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51866 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,48,41,1044,1,34,1029,1077,1025,0,33,33,16,2,41,17,1077,1028,49,1077,1056,32,37,33,1044,513]

theorem envBound51866 : H12AffineFastState.Bounded env51866 := by
  intro p hp
  have h : env51866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51865_51866 : H12AffineEnvironment.transform 10 1077 env51865 = env51866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env51865 == env51866) = true)

def env51867 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,48,41,32,1,34,49,1,53,0,33,33,16,2,41,17,1,48,49,1,20,32,37,33,32,513]

theorem envBound51867 : H12AffineFastState.Bounded env51867 := by
  intro p hp
  have h : env51867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51866_51867 : H12AffineEnvironment.transform 9 52 env51866 = env51867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51866 == env51867) = true)

theorem identity51867 : scanCanonicalize (H12AffineFastState.compose env51867 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51868 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,16,9,0,1,2,17,1,21,0,1,1,16,2,9,17,1,16,17,1,20,0,5,1,0,513]

theorem envBound51868 : H12AffineFastState.Bounded env51868 := by
  intro p hp
  have h : env51868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51867_51868 : H12AffineEnvironment.transform 4 0 env51867 = env51868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51867 == env51868) = true)

def leafEnv51868 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,16,9,0,1,2,17,1,21,0,1,1,16,2,21,9,1,17,1,16,17,1,20,0,5,1,5,2,0,513,1,1,0]

def active51868 : List Nat := [0,1,2,3,8]

def tree51868 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51868 : H12WitnessSearch.Good tree51868 := H12GlobalWitnessIndex.good

theorem leafIdentity51868 : H12AffineFastState.composeSystem env51868 rootObs = leafEnv51868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51868 rootObs == leafEnv51868) = true)

theorem terminalChecked51868 : H12PackedTerminal.terminalCheckFast leafEnv51868 active51868 tree51868 = true := by decide +kernel

def env51869 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,41,33,1,34,48,0,52,0,33,33,16,2,41,17,0,49,49,0,21,32,37,33,33,513]

theorem envBound51869 : H12AffineFastState.Bounded env51869 := by
  intro p hp
  have h : env51869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51866_51869 : H12AffineEnvironment.transform 9 53 env51866 = env51869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51866 == env51869) = true)

theorem identity51869 : scanCanonicalize (H12AffineFastState.compose env51869 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound51869 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51870 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,48,41,33,1,34,48,0,52,0,33,33,16,2,41,17,0,49,49,0,21,32,37,33,33,10]

theorem envBound51870 : H12AffineFastState.Bounded env51870 := by
  intro p hp
  have h : env51870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51869_51870 : H12AffineEnvironment.transform 8 11 env51869 = env51870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env51869 == env51870) = true)

def leafEnv51870 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,48,41,33,1,34,48,0,52,0,33,33,16,2,20,41,1,17,0,49,49,0,21,32,37,33,5,34,33,10,1,33,0]

def active51870 : List Nat := [0,1,2,3,4]

def tree51870 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51870 : H12WitnessSearch.Good tree51870 := H12GlobalWitnessIndex.good

theorem leafIdentity51870 : H12AffineFastState.composeSystem env51870 rootObs = leafEnv51870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51870 rootObs == leafEnv51870) = true)

theorem terminalChecked51870 : H12PackedTerminal.terminalCheckFast leafEnv51870 active51870 tree51870 = true := by decide +kernel

def env51871 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,41,1045,1,34,1028,2048,1025,0,32,33,16,2,41,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound51871 : H12AffineFastState.Bounded env51871 := by
  intro p hp
  have h : env51871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51864_51871 : H12AffineEnvironment.transform 11 49 env51864 = env51871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51864 == env51871) = true)

theorem identity51871 : scanCanonicalize (H12AffineFastState.compose env51871 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51871 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51872 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,49,41,1045,1,34,1028,0,1025,0,32,33,16,2,41,17,0,1029,48,0,1056,32,37,33,1045,513]

theorem envBound51872 : H12AffineFastState.Bounded env51872 := by
  intro p hp
  have h : env51872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51871_51872 : H12AffineEnvironment.transform 10 0 env51871 = env51872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51871 == env51872) = true)

def env51873 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,41,33,1,34,48,0,53,0,32,33,16,2,41,17,0,49,48,0,20,32,37,33,33,513]

theorem envBound51873 : H12AffineFastState.Bounded env51873 := by
  intro p hp
  have h : env51873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51872_51873 : H12AffineEnvironment.transform 9 52 env51872 = env51873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51872 == env51873) = true)

theorem identity51873 : scanCanonicalize (H12AffineFastState.compose env51873 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51873 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51874 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,9,1,1,2,16,0,21,0,0,1,16,2,9,17,0,17,16,0,20,0,5,1,1,513]

theorem envBound51874 : H12AffineFastState.Bounded env51874 := by
  intro p hp
  have h : env51874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51873_51874 : H12AffineEnvironment.transform 4 0 env51873 = env51874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51873 == env51874) = true)

def leafEnv51874 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,9,1,1,2,16,0,21,0,0,1,16,2,21,9,1,17,0,17,16,0,20,0,5,1,5,2,1,513,1,0,0]

def active51874 : List Nat := [0,1,2,3,8]

def tree51874 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51874 : H12WitnessSearch.Good tree51874 := H12GlobalWitnessIndex.good

theorem leafIdentity51874 : H12AffineFastState.composeSystem env51874 rootObs = leafEnv51874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51874 rootObs == leafEnv51874) = true)

theorem terminalChecked51874 : H12PackedTerminal.terminalCheckFast leafEnv51874 active51874 tree51874 = true := by decide +kernel

def env51875 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,49,41,32,1,34,49,0,52,0,32,33,16,2,41,17,0,48,48,0,21,32,37,33,32,513]

theorem envBound51875 : H12AffineFastState.Bounded env51875 := by
  intro p hp
  have h : env51875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51872_51875 : H12AffineEnvironment.transform 9 53 env51872 = env51875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51872 == env51875) = true)

theorem identity51875 : scanCanonicalize (H12AffineFastState.compose env51875 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound51875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51876 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,49,41,32,1,34,49,0,52,0,32,33,16,2,41,17,0,48,48,0,21,32,37,33,32,10]

theorem envBound51876 : H12AffineFastState.Bounded env51876 := by
  intro p hp
  have h : env51876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51875_51876 : H12AffineEnvironment.transform 8 11 env51875 = env51876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env51875 == env51876) = true)

def leafEnv51876 : List Nat := [2,4,8,16,32,17,8,36,11,53,0,49,41,32,1,34,49,0,52,0,32,33,16,2,20,41,1,17,0,48,48,0,21,32,37,33,5,34,32,10,1,32,0]

def active51876 : List Nat := [0,1,2,3,4]

def tree51876 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51876 : H12WitnessSearch.Good tree51876 := H12GlobalWitnessIndex.good

theorem leafIdentity51876 : H12AffineFastState.composeSystem env51876 rootObs = leafEnv51876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51876 rootObs == leafEnv51876) = true)

theorem terminalChecked51876 : H12PackedTerminal.terminalCheckFast leafEnv51876 active51876 tree51876 = true := by decide +kernel

def env51877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272392,17,98644,8192,64,64605,5393,17665,283904,1364,318549,257,21793,46092,74251]

theorem envBound51877 : H12AffineFastState.Bounded env51877 := by
  intro p hp
  have h : env51877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51856_51877 : H12AffineEnvironment.transform 16 38161 env51856 = env51877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env51856 == env51877) = true)

theorem identity51877 : scanCanonicalize (H12AffineFastState.compose env51877 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound51877 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4161,33,17,98644,8192,64,64605,5393,17665,32041,1364,62588,257,21793,46092,74251]

theorem envBound51878 : H12AffineFastState.Bounded env51878 := by
  intro p hp
  have h : env51878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51877_51878 : H12AffineEnvironment.transform 17 10281 env51877 = env51878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51877 == env51878) = true)

theorem identity51878 : scanCanonicalize (H12AffineFastState.compose env51878 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound51878 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env51879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,24909,10281,1025,29789,4161,33,17,95496,8192,64,2049,5393,17665,32041,1364,32,257,21793,16464,74251]

theorem envBound51879 : H12AffineFastState.Bounded env51879 := by
  intro p hp
  have h : env51879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51878_51879 : H12AffineEnvironment.transform 14 29788 env51878 = env51879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env51878 == env51879) = true)

theorem identity51879 : scanCanonicalize (H12AffineFastState.compose env51879 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound51879 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env51880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,343,24909,10281,1025,29789,4161,33,17,29791,8192,64,2049,5393,17665,32041,1364,32,257,21793,16464,9052]

theorem envBound51880 : H12AffineFastState.Bounded env51880 := by
  intro p hp
  have h : env51880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51879_51880 : H12AffineEnvironment.transform 15 343 env51879 = env51880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env51879 == env51880) = true)

theorem identity51880 : scanCanonicalize (H12AffineFastState.compose env51880 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound51880 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env51881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,343,5392,10281,1025,0,4161,33,17,2,8192,64,2049,5393,12636,2420,1364,32,257,8572,13325,9052]

theorem envBound51881 : H12AffineFastState.Bounded env51881 := by
  intro p hp
  have h : env51881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51880_51881 : H12AffineEnvironment.transform 13 13405 env51880 = env51881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env51880 == env51881) = true)

theorem identity51881 : scanCanonicalize (H12AffineFastState.compose env51881 (packedSelected [0,1,3,5,6,7,8,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound51881 : packedSelected [0,1,3,5,6,7,8,14,15] rootPS < 2^1333 := by decide +kernel

def env51882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,32,4096,8192,13405,1,343,5392,8201,1025,0,4161,33,17,2,8192,64,33,5393,12636,340,1364,32,257,8572,13325,9052]

theorem envBound51882 : H12AffineFastState.Bounded env51882 := by
  intro p hp
  have h : env51882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51881_51882 : H12AffineEnvironment.transform 10 32 env51881 = env51882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env51881 == env51882) = true)

theorem identity51882 : scanCanonicalize (H12AffineFastState.compose env51882 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51882 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env51883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,32,4096,348,5377,1,343,5392,341,1025,0,4161,33,17,2,348,64,33,5393,4096,340,1364,32,257,32,5457,512]

theorem envBound51883 : H12AffineFastState.Bounded env51883 := by
  intro p hp
  have h : env51883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51882_51883 : H12AffineEnvironment.transform 12 348 env51882 = env51883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51882 == env51883) = true)

theorem identity51883 : scanCanonicalize (H12AffineFastState.compose env51883 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 794) := by decide +kernel

theorem selectedBound51883 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51884 : List Nat := [2,4,8,16,32,64,8,256,512,794,32,4096,348,4635,1,343,4618,341,795,0,4161,33,17,2,348,64,33,4619,4096,340,590,32,257,32,4683,512]

theorem envBound51884 : H12AffineFastState.Bounded env51884 := by
  intro p hp
  have h : env51884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51883_51884 : H12AffineEnvironment.transform 9 794 env51883 = env51884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 794 env51883 == env51884) = true)

theorem identity51884 : scanCanonicalize (H12AffineFastState.compose env51884 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound51884 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51885 : List Nat := [2,4,8,16,32,49,8,256,512,794,32,4096,301,4635,1,294,4618,292,795,0,4144,33,17,2,301,49,33,4619,4096,293,575,32,257,32,4666,512]

theorem envBound51885 : H12AffineFastState.Bounded env51885 := by
  intro p hp
  have h : env51885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51884_51885 : H12AffineEnvironment.transform 5 49 env51884 = env51885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env51884 == env51885) = true)

theorem identity51885 : scanCanonicalize (H12AffineFastState.compose env51885 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound51885 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51886 : List Nat := [2,4,8,16,32,49,8,256,302,52,32,4096,301,4405,1,294,4388,292,53,0,4144,33,17,2,301,49,33,4389,4096,293,273,32,257,32,4372,302]

theorem envBound51886 : H12AffineFastState.Bounded env51886 := by
  intro p hp
  have h : env51886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51885_51886 : H12AffineEnvironment.transform 8 302 env51885 = env51886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env51885 == env51886) = true)

theorem identity51886 : scanCanonicalize (H12AffineFastState.compose env51886 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51886 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51887 : List Nat := [2,4,8,16,32,49,8,37,11,52,32,4096,8,4112,1,3,4097,1,53,0,4144,33,17,2,8,49,33,4096,4096,0,52,32,36,32,4145,11]

theorem envBound51887 : H12AffineFastState.Bounded env51887 := by
  intro p hp
  have h : env51887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51886_51887 : H12AffineEnvironment.transform 7 37 env51886 = env51887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51886 == env51887) = true)

def env51888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272393,169217,98645,8193,64,64604,163841,17665,283905,168005,411972,257,21793,46093,243483]

theorem envBound51888 : H12AffineFastState.Bounded env51888 := by
  intro p hp
  have h : env51888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51855_51888 : H12AffineEnvironment.transform 6 9 env51855 = env51888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51855 == env51888) = true)

theorem identity51888 : scanCanonicalize (H12AffineFastState.compose env51888 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound51888 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env51889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,131072,262144,1025,32769,165201,272393,169217,29790,8193,64,64604,163841,17665,283905,168005,411972,257,21793,46093,147984]

theorem envBound51889 : H12AffineFastState.Bounded env51889 := by
  intro p hp
  have h : env51889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51888_51889 : H12AffineEnvironment.transform 15 62731 env51888 = env51889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env51888 == env51889) = true)

theorem identity51889 : scanCanonicalize (H12AffineFastState.compose env51889 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound51889 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env51890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,57676,262144,1025,32769,25629,272393,29773,29790,8193,64,64604,24909,17665,283905,28937,305160,257,21793,46093,41820]

theorem envBound51890 : H12AffineFastState.Bounded env51890 := by
  intro p hp
  have h : env51890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51889_51890 : H12AffineEnvironment.transform 16 57676 env51889 = env51890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env51889 == env51890) = true)

theorem identity51890 : scanCanonicalize (H12AffineFastState.compose env51890 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51890 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env51891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21590,16401,262144,1025,8540,25629,272393,29773,29790,8193,64,23809,24909,17665,283905,28937,264533,257,21793,5456,513]

theorem envBound51891 : H12AffineFastState.Bounded env51891 := by
  intro p hp
  have h : env51891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51890_51891 : H12AffineEnvironment.transform 14 8541 env51890 = env51891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51890 == env51891) = true)

theorem identity51891 : scanCanonicalize (H12AffineFastState.compose env51891 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound51891 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21590,16401,11576,1025,8540,25629,1329,29773,29790,8193,64,23809,24909,17665,30777,28937,9325,257,21793,5456,513]

theorem envBound51892 : H12AffineFastState.Bounded env51892 := by
  intro p hp
  have h : env51892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51891_51892 : H12AffineEnvironment.transform 17 11576 env51891 = env51892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env51891 == env51892) = true)

theorem identity51892 : scanCanonicalize (H12AffineFastState.compose env51892 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound51892 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env51893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8203,13388,11576,1025,8540,4160,1329,16,3,8193,64,10588,5392,12636,3172,1364,9325,257,8572,5456,513]

theorem envBound51893 : H12AffineFastState.Bounded env51893 := by
  intro p hp
  have h : env51893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51892_51893 : H12AffineEnvironment.transform 13 13405 env51892 = env51893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env51892 == env51893) = true)

theorem identity51893 : scanCanonicalize (H12AffineFastState.compose env51893 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound51893 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,1077,1379,4388,2128,1025,1076,4160,1329,16,3,1385,64,3124,5392,5172,3172,1364,261,257,1044,5456,513]

theorem envBound51894 : H12AffineFastState.Bounded env51894 := by
  intro p hp
  have h : env51894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51893_51894 : H12AffineEnvironment.transform 12 1384 env51893 = env51894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env51893 == env51894) = true)

theorem identity51894 : scanCanonicalize (H12AffineFastState.compose env51894 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51894 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env51895 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,349,4405,0,342,4388,2128,52,1,4160,260,16,3,348,64,2049,4389,4097,2129,353,261,257,33,4453,513]

theorem envBound51895 : H12AffineFastState.Bounded env51895 := by
  intro p hp
  have h : env51895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51894_51895 : H12AffineEnvironment.transform 9 53 env51894 = env51895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51894 == env51895) = true)

def env51896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272513,169352,98780,8328,64,64724,163976,17665,284040,168005,411973,257,21793,46212,243602]

theorem envBound51896 : H12AffineFastState.Bounded env51896 := by
  intro p hp
  have h : env51896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51854_51896 : H12AffineEnvironment.transform 21 272513 env51854 = env51896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51854 == env51896) = true)

theorem identity51896 : scanCanonicalize (H12AffineFastState.compose env51896 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound51896 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4161,272513,17,98780,8328,64,64724,5393,17665,284040,1500,318684,257,21793,46212,74251]

theorem envBound51897 : H12AffineFastState.Bounded env51897 := by
  intro p hp
  have h : env51897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51896_51897 : H12AffineEnvironment.transform 16 38297 env51896 = env51897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env51896 == env51897) = true)

theorem identity51897 : scanCanonicalize (H12AffineFastState.compose env51897 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51897 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env51898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38297,262144,1025,32769,4161,272513,17,41430,8328,64,64724,5393,17665,284040,1500,318684,257,21793,46212,513]

theorem envBound51898 : H12AffineFastState.Bounded env51898 := by
  intro p hp
  have h : env51898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51897_51898 : H12AffineEnvironment.transform 15 8202 env51897 = env51898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51897 == env51898) = true)

def env51899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,4194304,169353,98781,8328,64,4510805,163977,17664,284041,168005,4350405,257,21793,46212,243602]

theorem envBound51899 : H12AffineFastState.Bounded env51899 := by
  intro p hp
  have h : env51899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51853_51899 : H12AffineEnvironment.transform 22 169353 env51853 = env51899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env51853 == env51899) = true)

def env51900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,272512,169353,98781,8328,64,64725,163977,17664,284041,168005,411973,257,21793,46212,243602]

theorem envBound51900 : H12AffineFastState.Bounded env51900 := by
  intro p hp
  have h : env51900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51899_51900 : H12AffineEnvironment.transform 21 272512 env51899 = env51900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51899 == env51900) = true)

theorem identity51900 : scanCanonicalize (H12AffineFastState.compose env51900 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound51900 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,160013,272512,155996,95496,8328,64,2048,160860,17664,284041,156816,411973,257,21793,16465,213831]

theorem envBound51901 : H12AffineFastState.Bounded env51901 := by
  intro p hp
  have h : env51901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51900_51901 : H12AffineEnvironment.transform 14 29909 env51900 = env51901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env51900 == env51901) = true)

def env51902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160013,272392,155996,95496,8192,64,2048,160860,17664,283905,156696,411973,257,21793,16465,213831]

theorem envBound51902 : H12AffineFastState.Bounded env51902 := by
  intro p hp
  have h : env51902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51901_51902 : H12AffineEnvironment.transform 6 8 env51901 = env51902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51901 == env51902) = true)

theorem identity51902 : scanCanonicalize (H12AffineFastState.compose env51902 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound51902 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env51903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,223599,1025,29788,160013,213351,155996,95496,8192,64,2048,160860,17664,212078,156696,73770,257,21793,16465,213831]

end H12CloudChart0