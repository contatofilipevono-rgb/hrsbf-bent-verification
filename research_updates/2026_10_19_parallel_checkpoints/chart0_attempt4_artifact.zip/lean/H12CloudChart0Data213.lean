import H12CloudChart0Data212

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound53927 : H12AffineFastState.Bounded env53927 := by
  intro p hp
  have h : env53927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53926_53927 : H12AffineEnvironment.transform 11 16 env53926 = env53927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env53926 == env53927) = true)

theorem identity53927 : scanCanonicalize (H12AffineFastState.compose env53927 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound53927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53928 : List Nat := [2,4,8,16,1,16,8,5,512,1024,1044,16,9,1045,0,2,1028,1044,1024,1,1,0,16,2,9,16,1044,1028,16,1044,1025,0,5,1,1045,513]

theorem envBound53928 : H12AffineFastState.Bounded env53928 := by
  intro p hp
  have h : env53928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53927_53928 : H12AffineEnvironment.transform 10 1044 env53927 = env53928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env53927 == env53928) = true)

def env53929 : List Nat := [2,4,8,16,1,16,8,5,512,20,0,16,9,1,0,2,16,0,20,1,1,0,16,2,9,16,0,16,16,0,21,0,5,1,1,513]

theorem envBound53929 : H12AffineFastState.Bounded env53929 := by
  intro p hp
  have h : env53929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53928_53929 : H12AffineEnvironment.transform 9 20 env53928 = env53929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53928 == env53929) = true)

def env53930 : List Nat := [2,4,8,16,1,16,8,5,512,21,1,16,9,0,0,2,17,1,21,1,1,0,16,2,9,16,1,17,16,1,20,0,5,1,0,513]

theorem envBound53930 : H12AffineFastState.Bounded env53930 := by
  intro p hp
  have h : env53930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53928_53930 : H12AffineEnvironment.transform 9 21 env53928 = env53930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53928 == env53930) = true)

theorem identity53930 : scanCanonicalize (H12AffineFastState.compose env53930 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound53930 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53931 : List Nat := [2,4,8,16,1,16,8,5,11,21,1,16,9,0,0,2,17,1,21,1,1,0,16,2,9,16,1,17,16,1,20,0,5,1,0,10]

theorem envBound53931 : H12AffineFastState.Bounded env53931 := by
  intro p hp
  have h : env53931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53930_53931 : H12AffineEnvironment.transform 8 11 env53930 = env53931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env53930 == env53931) = true)

def leafEnv53931 : List Nat := [2,4,8,16,1,16,8,5,11,21,1,16,9,0,0,2,17,1,21,1,1,0,16,2,20,9,1,16,1,17,16,1,20,0,5,1,4,2,0,10,1,1,0]

def active53931 : List Nat := [0,1,2,3]

def tree53931 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53931 : H12WitnessSearch.Good tree53931 := H12GlobalWitnessIndex.good

theorem leafIdentity53931 : H12AffineFastState.composeSystem env53931 rootObs = leafEnv53931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53931 rootObs == leafEnv53931) = true)

theorem terminalChecked53931 : H12PackedTerminal.terminalCheckFast leafEnv53931 active53931 tree53931 = true := by decide +kernel

def env53932 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,17,9,1044,0,2,1029,2048,1024,1,0,0,16,2,9,16,2048,1029,17,2048,1025,0,5,1,1044,513]

theorem envBound53932 : H12AffineFastState.Bounded env53932 := by
  intro p hp
  have h : env53932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53926_53932 : H12AffineEnvironment.transform 11 17 env53926 = env53932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env53926 == env53932) = true)

theorem identity53932 : scanCanonicalize (H12AffineFastState.compose env53932 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53933 : List Nat := [2,4,8,16,1,16,8,5,512,1024,1,17,9,1044,0,2,1029,1,1024,1,0,0,16,2,9,16,1,1029,17,1,1025,0,5,1,1044,513]

theorem envBound53933 : H12AffineFastState.Bounded env53933 := by
  intro p hp
  have h : env53933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53932_53933 : H12AffineEnvironment.transform 10 1 env53932 = env53933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53932 == env53933) = true)

def env53934 : List Nat := [2,4,8,16,1,16,8,5,512,20,1,17,9,0,0,2,17,1,20,1,0,0,16,2,9,16,1,17,17,1,21,0,5,1,0,513]

theorem envBound53934 : H12AffineFastState.Bounded env53934 := by
  intro p hp
  have h : env53934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53933_53934 : H12AffineEnvironment.transform 9 20 env53933 = env53934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53933 == env53934) = true)

def env53935 : List Nat := [2,4,8,16,1,16,8,5,512,21,1,17,9,1,0,2,16,1,21,1,0,0,16,2,9,16,1,16,17,1,20,0,5,1,1,513]

theorem envBound53935 : H12AffineFastState.Bounded env53935 := by
  intro p hp
  have h : env53935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53933_53935 : H12AffineEnvironment.transform 9 21 env53933 = env53935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53933 == env53935) = true)

theorem identity53935 : scanCanonicalize (H12AffineFastState.compose env53935 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound53935 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53936 : List Nat := [2,4,8,16,1,16,8,5,11,21,1,17,9,1,0,2,16,1,21,1,0,0,16,2,9,16,1,16,17,1,20,0,5,1,1,10]

theorem envBound53936 : H12AffineFastState.Bounded env53936 := by
  intro p hp
  have h : env53936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53935_53936 : H12AffineEnvironment.transform 8 11 env53935 = env53936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env53935 == env53936) = true)

def leafEnv53936 : List Nat := [2,4,8,16,1,16,8,5,11,21,1,17,9,1,0,2,16,1,21,1,0,0,16,2,20,9,1,16,1,16,17,1,20,0,5,1,4,2,1,10,1,0,0]

def active53936 : List Nat := [0,1,2,3]

def tree53936 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53936 : H12WitnessSearch.Good tree53936 := H12GlobalWitnessIndex.good

theorem leafIdentity53936 : H12AffineFastState.composeSystem env53936 rootObs = leafEnv53936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53936 rootObs == leafEnv53936) = true)

theorem terminalChecked53936 : H12PackedTerminal.terminalCheckFast leafEnv53936 active53936 tree53936 = true := by decide +kernel

def env53937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,65536,131072,76079,1024,80,12620,8492,16,73736,8193,64,203846,5393,4096,204130,9304,8492,256,8493,13404,66311]

theorem envBound53937 : H12AffineFastState.Bounded env53937 := by
  intro p hp
  have h : env53937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53900_53937 : H12AffineEnvironment.transform 6 9 env53900 = env53937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53900 == env53937) = true)

theorem identity53937 : scanCanonicalize (H12AffineFastState.compose env53937 (packedSelected [1,4,6,8,9,10,12,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53937 : packedSelected [1,4,6,8,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env53938 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13325,81,65536,131072,75866,1024,80,12345,8281,16,73736,8193,64,203846,5220,4096,203799,9304,8281,117,8280,13404,66162]

theorem envBound53938 : H12AffineFastState.Bounded env53938 := by
  intro p hp
  have h : env53938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53937_53938 : H12AffineEnvironment.transform 7 117 env53937 = env53938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53937 == env53938) = true)

theorem identity53938 : scanCanonicalize (H12AffineFastState.compose env53938 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound53938 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53939 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,81,65536,131072,67618,1024,80,4161,33,16,65648,121,64,203846,5220,4096,203799,1056,33,117,32,5156,66162]

theorem envBound53939 : H12AffineFastState.Bounded env53939 := by
  intro p hp
  have h : env53939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53938_53939 : H12AffineEnvironment.transform 12 120 env53938 = env53939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env53938 == env53939) = true)

theorem identity53939 : scanCanonicalize (H12AffineFastState.compose env53939 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound53939 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53940 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,81,65536,70679,67618,1024,80,4161,33,16,65648,121,64,2129,5220,4096,2048,1056,33,117,32,5156,66162]

theorem envBound53940 : H12AffineFastState.Bounded env53940 := by
  intro p hp
  have h : env53940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53939_53940 : H12AffineEnvironment.transform 16 70679 env53939 = env53940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env53939 == env53940) = true)

theorem identity53940 : scanCanonicalize (H12AffineFastState.compose env53940 (packedSelected [3,4,5,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53940 : packedSelected [3,4,5,7,20] rootPS < 2^1333 := by decide +kernel

def env53941 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,65536,70679,67618,1024,0,4113,33,16,65568,41,16,2049,5172,4096,2048,1056,33,37,32,5156,66082]

theorem envBound53941 : H12AffineFastState.Bounded env53941 := by
  intro p hp
  have h : env53941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53940_53941 : H12AffineEnvironment.transform 5 16 env53940 = env53941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53940 == env53941) = true)

theorem identity53941 : scanCanonicalize (H12AffineFastState.compose env53941 (packedSelected [0,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound53941 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env53942 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3109,40,2048,1,65536,67634,67618,1024,0,3124,33,16,65568,41,16,2049,2065,3109,2048,1056,33,37,32,2049,66082]

theorem envBound53942 : H12AffineFastState.Bounded env53942 := by
  intro p hp
  have h : env53942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53941_53942 : H12AffineEnvironment.transform 11 3109 env53941 = env53942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env53941 == env53942) = true)

theorem identity53942 : scanCanonicalize (H12AffineFastState.compose env53942 (packedSelected [4,7] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound53942 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env53943 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3109,40,2048,1,1046,3108,3124,1024,0,3124,33,16,1078,41,16,2049,2065,3109,2048,1056,33,37,32,2049,1588]

theorem envBound53943 : H12AffineFastState.Bounded env53943 := by
  intro p hp
  have h : env53943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53942_53943 : H12AffineEnvironment.transform 15 1046 env53942 = env53943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env53942 == env53943) = true)

theorem identity53943 : scanCanonicalize (H12AffineFastState.compose env53943 (packedSelected [2,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound53943 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env53944 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2064,40,2048,1,35,2065,2049,53,0,2049,33,16,3,41,16,2049,2065,2064,2048,21,33,37,32,2049,513]

theorem envBound53944 : H12AffineFastState.Bounded env53944 := by
  intro p hp
  have h : env53944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53943_53944 : H12AffineEnvironment.transform 9 53 env53943 = env53944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53943 == env53944) = true)

theorem identity53944 : scanCanonicalize (H12AffineFastState.compose env53944 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53945 : List Nat := [2,4,8,16,32,16,9,37,1,53,2048,2064,40,2048,1,35,2065,2049,53,0,2049,33,16,3,41,16,2049,2065,2064,2048,21,33,37,32,2049,0]

theorem envBound53945 : H12AffineFastState.Bounded env53945 := by
  intro p hp
  have h : env53945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53944_53945 : H12AffineEnvironment.transform 8 1 env53944 = env53945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53944 == env53945) = true)

theorem identity53945 : scanCanonicalize (H12AffineFastState.compose env53945 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound53945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53946 : List Nat := [2,4,8,16,32,16,9,37,1,53,10,26,40,10,1,35,27,11,53,0,11,33,16,3,41,16,11,27,26,10,21,33,37,32,11,0]

theorem envBound53946 : H12AffineFastState.Bounded env53946 := by
  intro p hp
  have h : env53946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53945_53946 : H12AffineEnvironment.transform 10 10 env53945 = env53946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env53945 == env53946) = true)

def env53947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,89515,1024,29788,17729,21793,17,73857,8328,64,203846,5392,4097,223718,20700,21793,256,21792,16601,96010]

theorem envBound53947 : H12AffineFastState.Bounded env53947 := by
  intro p hp
  have h : env53947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53898_53947 : H12AffineEnvironment.transform 14 29789 env53898 = env53947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env53898 == env53947) = true)

theorem identity53947 : scanCanonicalize (H12AffineFastState.compose env53947 (packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound53947 : packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env53948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,5393,89515,1024,29788,17729,21793,17,73857,8328,64,67927,5392,4097,97527,20700,21793,256,21792,16601,96010]

theorem envBound53948 : H12AffineFastState.Bounded env53948 := by
  intro p hp
  have h : env53948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53947_53948 : H12AffineEnvironment.transform 16 5393 env53947 = env53948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env53947 == env53948) = true)

theorem identity53948 : scanCanonicalize (H12AffineFastState.compose env53948 (packedSelected [0,2,4,5,6,9,20,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53948 : packedSelected [0,2,4,5,6,9,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,21841,65536,5393,89515,1024,21840,17729,21793,17,65933,388,64,67927,5392,4097,89595,20700,21793,256,21792,16601,87558]

theorem envBound53949 : H12AffineFastState.Bounded env53949 := by
  intro p hp
  have h : env53949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53948_53949 : H12AffineEnvironment.transform 12 268 env53948 = env53949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53948 == env53949) = true)

theorem identity53949 : scanCanonicalize (H12AffineFastState.compose env53949 (packedSelected [2,4,9,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound53949 : packedSelected [2,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env53950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,216,65536,5393,67618,1024,217,4296,168,17,65933,388,64,67927,5392,4097,67698,1365,168,256,169,5456,66447]

theorem envBound53950 : H12AffineFastState.Bounded env53950 := by
  intro p hp
  have h : env53950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53949_53950 : H12AffineEnvironment.transform 13 5513 env53949 = env53950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env53949 == env53950) = true)

theorem identity53950 : scanCanonicalize (H12AffineFastState.compose env53950 (packedSelected [0,2,4,7,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53950 : packedSelected [0,2,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env53951 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,137,65536,5393,67618,1024,136,4249,168,17,65933,388,17,67846,5392,4097,67619,1284,168,256,169,5377,66447]

theorem envBound53951 : H12AffineFastState.Bounded env53951 := by
  intro p hp
  have h : env53951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53950_53951 : H12AffineEnvironment.transform 5 17 env53950 = env53951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53950 == env53951) = true)

theorem identity53951 : scanCanonicalize (H12AffineFastState.compose env53951 (packedSelected [0,1,2,3,5,8,9,10,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound53951 : packedSelected [0,1,2,3,5,8,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env53952 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3108,268,2477,137,65536,2357,67618,1024,136,3261,168,17,65933,388,17,67846,2356,3109,67619,1284,168,256,169,2341,66447]

theorem envBound53952 : H12AffineFastState.Bounded env53952 := by
  intro p hp
  have h : env53952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53951_53952 : H12AffineEnvironment.transform 11 3108 env53951 = env53952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env53951 == env53952) = true)

theorem identity53952 : scanCanonicalize (H12AffineFastState.compose env53952 (packedSelected [0,1,2,4,7,8,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound53952 : packedSelected [0,1,2,4,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env53953 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3108,268,2477,137,399,2357,2477,1024,136,3261,168,17,2,388,17,2185,2356,3109,2476,1284,168,256,169,2341,512]

theorem envBound53953 : H12AffineFastState.Bounded env53953 := by
  intro p hp
  have h : env53953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53952_53953 : H12AffineEnvironment.transform 15 399 env53952 = env53953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env53952 == env53953) = true)

theorem identity53953 : scanCanonicalize (H12AffineFastState.compose env53953 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound53953 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53954 : List Nat := [2,4,8,16,32,17,128,141,512,1024,2048,3108,129,2080,137,2,2232,2080,1024,136,3261,168,17,2,9,17,2185,2233,3109,2081,1161,168,141,169,2216,512]

theorem envBound53954 : H12AffineFastState.Bounded env53954 := by
  intro p hp
  have h : env53954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53953_53954 : H12AffineEnvironment.transform 7 141 env53953 = env53954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env53953 == env53954) = true)

theorem identity53954 : scanCanonicalize (H12AffineFastState.compose env53954 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53954 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53955 : List Nat := [2,4,8,16,0,17,128,141,512,1024,2048,3076,129,2048,137,2,2200,2048,1024,136,3229,136,17,2,9,17,2185,2201,3077,2049,1161,136,141,137,2184,512]

theorem envBound53955 : H12AffineFastState.Bounded env53955 := by
  intro p hp
  have h : env53955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53954_53955 : H12AffineEnvironment.transform 4 0 env53954 = env53955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53954 == env53955) = true)

def env53956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101345,62540,2188736,8328,64,410092,57677,2138397,406605,2102685,2101345,256,21792,46212,2175563]

theorem envBound53956 : H12AffineFastState.Bounded env53956 := by
  intro p hp
  have h : env53956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53864_53956 : H12AffineEnvironment.transform 21 2101345 env53864 = env53956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101345 env53864 == env53956) = true)

def env53957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,62540,73856,8328,64,410092,57677,58461,406605,20701,21793,256,21792,46212,96011]

theorem envBound53957 : H12AffineFastState.Bounded env53957 := by
  intro p hp
  have h : env53957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53956_53957 : H12AffineEnvironment.transform 20 17728 env53956 = env53957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env53956 == env53957) = true)

theorem identity53957 : scanCanonicalize (H12AffineFastState.compose env53957 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound53957 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,17728,21793,152,73856,8328,64,410092,5529,4233,406605,20701,21793,256,21792,16464,96011]

theorem envBound53958 : H12AffineFastState.Bounded env53958 := by
  intro p hp
  have h : env53958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53957_53958 : H12AffineEnvironment.transform 14 29908 env53957 = env53958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env53957 == env53958) = true)

theorem identity53958 : scanCanonicalize (H12AffineFastState.compose env53958 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89514) := by decide +kernel

theorem selectedBound53958 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env53959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,89514,1024,29909,17728,21793,152,73856,8328,64,203846,5529,4233,223719,20701,21793,256,21792,16464,96011]

theorem envBound53959 : H12AffineFastState.Bounded env53959 := by
  intro p hp
  have h : env53959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53958_53959 : H12AffineEnvironment.transform 17 89514 env53958 = env53959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89514 env53958 == env53959) = true)

theorem identity53959 : scanCanonicalize (H12AffineFastState.compose env53959 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound53959 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29962,131072,10400,1024,29909,17728,21793,152,21898,8328,64,158028,5529,4233,138477,20701,21793,256,21792,16464,513]

theorem envBound53960 : H12AffineFastState.Bounded env53960 := by
  intro p hp
  have h : env53960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53959_53960 : H12AffineEnvironment.transform 15 29962 env53959 = env53960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env53959 == env53960) = true)

theorem identity53960 : scanCanonicalize (H12AffineFastState.compose env53960 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound53960 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env53961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29962,13460,10400,1024,29909,17728,21793,152,21898,8328,64,24024,5529,4233,10361,20701,21793,256,21792,16464,513]

theorem envBound53961 : H12AffineFastState.Bounded env53961 := by
  intro p hp
  have h : env53961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53960_53961 : H12AffineEnvironment.transform 16 13460 env53960 = env53961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env53960 == env53961) = true)

theorem identity53961 : scanCanonicalize (H12AffineFastState.compose env53961 (packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound53961 : packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env53962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8322,13460,10400,1024,8541,4296,169,152,2,8328,64,2128,5529,4233,10361,1365,169,256,168,5592,513]

theorem envBound53962 : H12AffineFastState.Bounded env53962 := by
  intro p hp
  have h : env53962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53961_53962 : H12AffineEnvironment.transform 13 5512 env53961 = env53962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env53961 == env53962) = true)

theorem identity53962 : scanCanonicalize (H12AffineFastState.compose env53962 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53962 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53963 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,5512,8540,8322,13460,10368,1024,8541,4296,137,152,2,8328,64,2128,5529,4233,10329,1365,137,256,136,5592,513]

theorem envBound53963 : H12AffineFastState.Bounded env53963 := by
  intro p hp
  have h : env53963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53962_53963 : H12AffineEnvironment.transform 4 0 env53962 = env53963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53962 == env53963) = true)

theorem identity53963 : scanCanonicalize (H12AffineFastState.compose env53963 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53963 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env53964 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,13341,10249,1024,8541,4161,0,17,2,8193,64,2128,5392,4096,10329,1365,0,256,1,5457,513]

theorem envBound53964 : H12AffineFastState.Bounded env53964 := by
  intro p hp
  have h : env53964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53963_53964 : H12AffineEnvironment.transform 6 9 env53963 = env53964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53963 == env53964) = true)

theorem identity53964 : scanCanonicalize (H12AffineFastState.compose env53964 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53964 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53965 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,8192,5377,8461,8203,13341,10249,1024,8460,4112,0,17,2,8193,17,2049,5392,4096,10248,1284,0,256,1,5376,513]

theorem envBound53965 : H12AffineFastState.Bounded env53965 := by
  intro p hp
  have h : env53965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53964_53965 : H12AffineEnvironment.transform 5 17 env53964 = env53965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53964 == env53965) = true)

theorem identity53965 : scanCanonicalize (H12AffineFastState.compose env53965 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53965 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env53966 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5377,0,262,5392,2308,1024,1,4112,0,17,2,268,17,2049,5392,4096,2309,1284,0,256,1,5376,513]

theorem envBound53966 : H12AffineFastState.Bounded env53966 := by
  intro p hp
  have h : env53966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53965_53966 : H12AffineEnvironment.transform 12 269 env53965 = env53966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53965 == env53966) = true)

theorem identity53966 : scanCanonicalize (H12AffineFastState.compose env53966 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound53966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53967 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,1297,269,16,0,262,1,2308,1024,1,1281,0,17,2,268,17,2049,1,1297,2309,1284,0,256,1,17,513]

theorem envBound53967 : H12AffineFastState.Bounded env53967 := by
  intro p hp
  have h : env53967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53966_53967 : H12AffineEnvironment.transform 11 1297 env53966 = env53967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env53966 == env53967) = true)

theorem identity53967 : scanCanonicalize (H12AffineFastState.compose env53967 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound53967 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53968 : List Nat := [2,4,8,16,0,17,9,256,261,1024,2048,1297,269,16,0,262,1,2308,1024,1,1281,0,17,2,268,17,2049,1,1297,2309,1284,0,256,1,17,260]

theorem envBound53968 : H12AffineFastState.Bounded env53968 := by
  intro p hp
  have h : env53968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53967_53968 : H12AffineEnvironment.transform 8 261 env53967 = env53968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env53967 == env53968) = true)

theorem identity53968 : scanCanonicalize (H12AffineFastState.compose env53968 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound53968 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53969 : List Nat := [2,4,8,16,0,17,9,256,261,1024,277,1297,269,16,0,262,1,17,1024,1,1281,0,17,2,268,17,276,1,1297,16,1284,0,256,1,17,260]

theorem envBound53969 : H12AffineFastState.Bounded env53969 := by
  intro p hp
  have h : env53969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53968_53969 : H12AffineEnvironment.transform 10 277 env53968 = env53969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env53968 == env53969) = true)

theorem identity53969 : scanCanonicalize (H12AffineFastState.compose env53969 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53969 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53970 : List Nat := [2,4,8,16,0,17,9,5,0,1024,16,1044,8,16,0,3,1,17,1024,1,1028,0,17,2,9,17,17,1,1044,16,1025,0,5,1,17,1]

theorem envBound53970 : H12AffineFastState.Bounded env53970 := by
  intro p hp
  have h : env53970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53969_53970 : H12AffineEnvironment.transform 7 5 env53969 = env53970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53969 == env53970) = true)

def env53971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,62540,73857,8328,64,410092,57677,58460,406605,20700,21792,256,21792,46212,96010]

theorem envBound53971 : H12AffineFastState.Bounded env53971 := by
  intro p hp
  have h : env53971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53956_53971 : H12AffineEnvironment.transform 20 17729 env53956 = env53971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env53956 == env53971) = true)

theorem identity53971 : scanCanonicalize (H12AffineFastState.compose env53971 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound53971 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,21792,16,73857,8328,64,410092,5393,4096,406605,20700,21792,256,21792,16600,96010]

theorem envBound53972 : H12AffineFastState.Bounded env53972 := by
  intro p hp
  have h : env53972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53971_53972 : H12AffineEnvironment.transform 14 29788 env53971 = env53972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env53971 == env53972) = true)

def env53973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4161,32,16,73857,8328,64,398572,5393,4096,406605,1500,32,256,32,5592,74250]

theorem envBound53973 : H12AffineFastState.Bounded env53973 := by
  intro p hp
  have h : env53973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53972_53973 : H12AffineEnvironment.transform 13 5376 env53972 = env53973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53972 == env53973) = true)

theorem identity53973 : scanCanonicalize (H12AffineFastState.compose env53973 (packedSelected [0,1,4,7,11,15,16,19,20,22,28,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound53973 : packedSelected [0,1,4,7,11,15,16,19,20,22,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env53974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,4161,32,16,73857,8328,64,146509,5393,4096,138476,1500,32,256,32,5592,74250]

theorem envBound53974 : H12AffineFastState.Bounded env53974 := by
  intro p hp
  have h : env53974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53973_53974 : H12AffineEnvironment.transform 17 10401 env53973 = env53974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env53973 == env53974) = true)

theorem identity53974 : scanCanonicalize (H12AffineFastState.compose env53974 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound53974 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env53975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,70863,10401,1024,8541,4161,32,16,73857,8328,64,75906,5393,4096,67619,1500,32,256,32,5592,74250]

theorem envBound53975 : H12AffineFastState.Bounded env53975 := by
  intro p hp
  have h : env53975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53974_53975 : H12AffineEnvironment.transform 16 70863 env53974 = env53975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env53974 == env53975) = true)

theorem identity53975 : scanCanonicalize (H12AffineFastState.compose env53975 (packedSelected [0,2,5,7,12,14,15,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound53975 : packedSelected [0,2,5,7,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env53976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,342,5529,10401,1024,8541,4161,32,16,8663,8328,64,10708,5393,4096,2421,1500,32,256,32,5592,9052]

theorem envBound53976 : H12AffineFastState.Bounded env53976 := by
  intro p hp
  have h : env53976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53975_53976 : H12AffineEnvironment.transform 15 342 env53975 = env53976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env53975 == env53976) = true)

theorem identity53976 : scanCanonicalize (H12AffineFastState.compose env53976 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53976 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env53977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,1,342,5529,2556,1024,0,4161,32,16,138,469,64,2185,5393,4096,2421,1500,32,256,32,5592,513]

theorem envBound53977 : H12AffineFastState.Bounded env53977 := by
  intro p hp
  have h : env53977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53976_53977 : H12AffineEnvironment.transform 12 349 env53976 = env53977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53976 == env53977) = true)

theorem identity53977 : scanCanonicalize (H12AffineFastState.compose env53977 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53977 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53978 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5376,1,263,5529,2477,1024,0,4112,32,16,138,388,17,2185,5393,4096,2340,1421,32,256,32,5513,513]

theorem envBound53978 : H12AffineFastState.Bounded env53978 := by
  intro p hp
  have h : env53978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53977_53978 : H12AffineEnvironment.transform 5 17 env53977 = env53978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53977 == env53978) = true)

theorem identity53978 : scanCanonicalize (H12AffineFastState.compose env53978 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound53978 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env53979 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,161,5293,1,170,5172,2048,1024,0,4112,32,16,138,41,17,2185,5308,4096,2185,1056,32,173,32,5156,513]

theorem envBound53979 : H12AffineFastState.Bounded env53979 := by
  intro p hp
  have h : env53979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53978_53979 : H12AffineEnvironment.transform 7 173 env53978 = env53979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env53978 == env53979) = true)

theorem identity53979 : scanCanonicalize (H12AffineFastState.compose env53979 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound53979 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env53980 : List Nat := [2,4,8,16,32,17,128,173,512,1024,0,4096,161,5293,1,170,5172,0,1024,0,4112,32,16,138,41,17,137,5308,4096,137,1056,32,173,32,5156,513]

theorem envBound53980 : H12AffineFastState.Bounded env53980 := by
  intro p hp
  have h : env53980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53979_53980 : H12AffineEnvironment.transform 10 0 env53979 = env53980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53979 == env53980) = true)

theorem identity53980 : scanCanonicalize (H12AffineFastState.compose env53980 (packedSelected [2,3,4,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound53980 : packedSelected [2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env53981 : List Nat := [2,4,8,16,32,17,128,173,512,1024,0,1060,161,137,1,170,16,0,1024,0,1076,32,16,138,41,17,137,152,1060,137,1056,32,173,32,0,513]

theorem envBound53981 : H12AffineFastState.Bounded env53981 := by
  intro p hp
  have h : env53981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53980_53981 : H12AffineEnvironment.transform 11 1060 env53980 = env53981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env53980 == env53981) = true)

theorem identity53981 : scanCanonicalize (H12AffineFastState.compose env53981 (packedSelected [0,2,3,4,5,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound53981 : packedSelected [0,2,3,4,5,14] rootPS < 2^1333 := by decide +kernel

def env53982 : List Nat := [2,4,8,16,32,17,128,173,512,52,0,16,161,137,1,170,16,0,52,0,0,32,16,138,41,17,137,152,16,137,20,32,173,32,0,513]

theorem envBound53982 : H12AffineFastState.Bounded env53982 := by
  intro p hp
  have h : env53982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53981_53982 : H12AffineEnvironment.transform 9 52 env53981 = env53982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53981 == env53982) = true)

theorem identity53982 : scanCanonicalize (H12AffineFastState.compose env53982 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53982 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env53983 : List Nat := [2,4,8,16,32,17,8,37,512,52,0,16,41,1,1,34,16,0,52,0,0,32,16,2,41,17,1,16,16,1,20,32,37,32,0,513]

theorem envBound53983 : H12AffineFastState.Bounded env53983 := by
  intro p hp
  have h : env53983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53982_53983 : H12AffineEnvironment.transform 6 8 env53982 = env53983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53982 == env53983) = true)

theorem identity53983 : scanCanonicalize (H12AffineFastState.compose env53983 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound53983 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53984 : List Nat := [2,4,8,16,32,17,8,37,33,52,0,16,41,1,1,34,16,0,52,0,0,32,16,2,41,17,1,16,16,1,20,32,37,32,0,32]

theorem envBound53984 : H12AffineFastState.Bounded env53984 := by
  intro p hp
  have h : env53984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53983_53984 : H12AffineEnvironment.transform 8 33 env53983 = env53984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env53983 == env53984) = true)

theorem identity53984 : scanCanonicalize (H12AffineFastState.compose env53984 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound53984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53985 : List Nat := [2,4,8,1,32,0,8,37,33,37,0,1,41,1,1,34,1,0,37,0,0,32,1,2,41,0,1,1,1,1,5,32,37,32,0,32]

theorem envBound53985 : H12AffineFastState.Bounded env53985 := by
  intro p hp
  have h : env53985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53984_53985 : H12AffineEnvironment.transform 3 1 env53984 = env53985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53984 == env53985) = true)

def env53986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4160,33,16,73857,8328,64,398573,5393,4096,406605,1501,33,256,33,5593,74251]

theorem envBound53986 : H12AffineFastState.Bounded env53986 := by
  intro p hp
  have h : env53986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53972_53986 : H12AffineEnvironment.transform 13 5377 env53972 = env53986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53972 == env53986) = true)

theorem identity53986 : scanCanonicalize (H12AffineFastState.compose env53986 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53986 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4160,33,16,73737,8192,64,398437,5393,4096,406605,1365,33,256,33,5457,74251]

theorem envBound53987 : H12AffineFastState.Bounded env53987 := by
  intro p hp
  have h : env53987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53986_53987 : H12AffineEnvironment.transform 6 8 env53986 = env53987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53986 == env53987) = true)

theorem identity53987 : scanCanonicalize (H12AffineFastState.compose env53987 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 212078) := by decide +kernel

theorem selectedBound53987 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env53988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,212078,1024,8540,4160,33,16,73737,8192,64,75787,5393,4096,67619,1365,33,256,33,5457,74251]

theorem envBound53988 : H12AffineFastState.Bounded env53988 := by
  intro p hp
  have h : env53988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53987_53988 : H12AffineEnvironment.transform 17 212078 env53987 = env53988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212078 env53987 == env53988) = true)

theorem identity53988 : scanCanonicalize (H12AffineFastState.compose env53988 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53988 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,65536,131072,204082,1024,0,4160,33,16,65877,348,64,67927,5393,4096,67619,1365,33,256,33,5457,66391]

theorem envBound53989 : H12AffineFastState.Bounded env53989 := by
  intro p hp
  have h : env53989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53988_53989 : H12AffineEnvironment.transform 12 348 env53988 = env53989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53988 == env53989) = true)

theorem identity53989 : scanCanonicalize (H12AffineFastState.compose env53989 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound53989 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,65536,5393,67619,1024,0,4160,33,16,65877,348,64,67927,5393,4096,67619,1365,33,256,33,5457,66391]

theorem envBound53990 : H12AffineFastState.Bounded env53990 := by
  intro p hp
  have h : env53990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53989_53990 : H12AffineEnvironment.transform 16 5393 env53989 = env53990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env53989 == env53990) = true)

theorem identity53990 : scanCanonicalize (H12AffineFastState.compose env53990 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 7175) := by decide +kernel

theorem selectedBound53990 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53991 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,7175,5393,5156,1024,0,4160,33,16,7506,348,64,5456,5393,4096,5156,1365,33,256,33,5457,8016]

theorem envBound53991 : H12AffineFastState.Bounded env53991 := by
  intro p hp
  have h : env53991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53990_53991 : H12AffineEnvironment.transform 15 7175 env53990 = env53991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7175 env53990 == env53991) = true)

theorem identity53991 : scanCanonicalize (H12AffineFastState.compose env53991 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53991 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env53992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,4096,348,5377,1,5126,5393,5156,1024,0,4160,33,16,5459,348,64,5456,5393,4096,5156,1365,33,256,33,5457,5969]

theorem envBound53992 : H12AffineFastState.Bounded env53992 := by
  intro p hp
  have h : env53992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53991_53992 : H12AffineEnvironment.transform 10 1 env53991 = env53992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53991 == env53992) = true)

theorem identity53992 : scanCanonicalize (H12AffineFastState.compose env53992 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound53992 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env53993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1141,348,372,1,115,356,81,1024,0,1077,33,16,294,348,64,293,356,1141,81,1365,33,256,33,292,804]

theorem envBound53993 : H12AffineFastState.Bounded env53993 := by
  intro p hp
  have h : env53993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53992_53993 : H12AffineEnvironment.transform 11 1141 env53992 = env53993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env53992 == env53993) = true)

theorem identity53993 : scanCanonicalize (H12AffineFastState.compose env53993 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53993 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env53994 : List Nat := [2,4,8,16,32,64,8,256,512,272,1,357,348,372,1,115,356,81,272,0,293,33,16,294,348,64,293,356,357,81,69,33,256,33,292,804]

theorem envBound53994 : H12AffineFastState.Bounded env53994 := by
  intro p hp
  have h : env53994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53993_53994 : H12AffineEnvironment.transform 9 272 env53993 = env53994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53993 == env53994) = true)

theorem identity53994 : scanCanonicalize (H12AffineFastState.compose env53994 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53994 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53995 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,309,268,292,1,35,308,1,272,0,293,33,16,294,268,16,293,308,309,1,21,33,256,33,292,804]

theorem envBound53995 : H12AffineFastState.Bounded env53995 := by
  intro p hp
  have h : env53995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53994_53995 : H12AffineEnvironment.transform 5 16 env53994 = env53995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53994 == env53995) = true)

theorem identity53995 : scanCanonicalize (H12AffineFastState.compose env53995 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53995 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env53996 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,16,41,1,1,35,17,1,53,0,0,33,16,3,41,16,0,17,16,1,21,33,37,33,1,513]

theorem envBound53996 : H12AffineFastState.Bounded env53996 := by
  intro p hp
  have h : env53996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53995_53996 : H12AffineEnvironment.transform 7 37 env53995 = env53996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53995 == env53996) = true)

theorem identity53996 : scanCanonicalize (H12AffineFastState.compose env53996 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53996 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53997 : List Nat := [2,4,8,16,32,16,8,37,1,53,1,16,41,1,1,35,17,1,53,0,0,33,16,3,41,16,0,17,16,1,21,33,37,33,1,0]

theorem envBound53997 : H12AffineFastState.Bounded env53997 := by
  intro p hp
  have h : env53997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53996_53997 : H12AffineEnvironment.transform 8 1 env53996 = env53997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53996 == env53997) = true)

theorem identity53997 : scanCanonicalize (H12AffineFastState.compose env53997 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53997 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53998 : List Nat := [2,4,8,10,32,10,8,37,1,47,1,10,41,1,1,35,11,1,47,0,0,33,10,3,41,10,0,11,10,1,15,33,37,33,1,0]

theorem envBound53998 : H12AffineFastState.Bounded env53998 := by
  intro p hp
  have h : env53998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53997_53998 : H12AffineEnvironment.transform 3 10 env53997 = env53998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53997 == env53998) = true)

theorem identity53998 : scanCanonicalize (H12AffineFastState.compose env53998 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53999 : List Nat := [2,4,3,1,32,1,3,37,1,36,1,1,34,1,1,35,0,1,36,0,0,33,1,3,34,1,0,0,1,1,4,33,37,33,1,0]

theorem envBound53999 : H12AffineFastState.Bounded env53999 := by
  intro p hp
  have h : env53999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53998_53999 : H12AffineEnvironment.transform 2 3 env53998 = env53999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53998 == env53999) = true)

def env54000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62541,2188736,8328,64,6705548,57677,2138396,406604,2102684,4194304,256,21793,46213,2175562]

theorem envBound54000 : H12AffineFastState.Bounded env54000 := by
  intro p hp
  have h : env54000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53863_54000 : H12AffineEnvironment.transform 22 62541 env53863 = env54000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62541 env53863 == env54000) = true)

def env54001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101344,62541,2188736,8328,64,410092,57677,2138396,406604,2102684,2101344,256,21793,46213,2175562]

theorem envBound54001 : H12AffineFastState.Bounded env54001 := by
  intro p hp
  have h : env54001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54000_54001 : H12AffineEnvironment.transform 21 2101344 env54000 = env54001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101344 env54000 == env54001) = true)

def env54002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62541,73856,8328,64,410092,57677,58460,406604,20700,21792,256,21793,46213,96010]

theorem envBound54002 : H12AffineFastState.Bounded env54002 := by
  intro p hp
  have h : env54002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54001_54002 : H12AffineEnvironment.transform 20 17728 env54001 = env54002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env54001 == env54002) = true)

theorem identity54002 : scanCanonicalize (H12AffineFastState.compose env54002 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound54002 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,1024,32769,17728,21792,62541,41310,8328,64,410092,57677,58460,406604,20700,21792,256,21793,46213,63188]

theorem envBound54003 : H12AffineFastState.Bounded env54003 := by
  intro p hp
  have h : env54003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54002_54003 : H12AffineEnvironment.transform 15 33246 env54002 = env54003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env54002 == env54003) = true)

theorem identity54003 : scanCanonicalize (H12AffineFastState.compose env54003 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound54003 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env54004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,56437,1024,32769,17728,21792,62541,41310,8328,64,171417,57677,58460,190521,20700,21792,256,21793,46213,63188]

theorem envBound54004 : H12AffineFastState.Bounded env54004 := by
  intro p hp
  have h : env54004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54003_54004 : H12AffineEnvironment.transform 17 56437 env54003 = env54004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env54003 == env54004) = true)

theorem identity54004 : scanCanonicalize (H12AffineFastState.compose env54004 (packedSelected [0,2,4,12,15,20,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 13356) := by decide +kernel

theorem selectedBound54004 : packedSelected [0,2,4,12,15,20,22,27] rootPS < 2^1333 := by decide +kernel

def env54005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,32768,33246,131072,43097,1024,32769,12652,8460,32865,41310,8328,64,171417,38241,36976,171029,9456,8460,256,8461,46213,33528]

theorem envBound54005 : H12AffineFastState.Bounded env54005 := by
  intro p hp
  have h : env54005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54004_54005 : H12AffineEnvironment.transform 13 13356 env54004 = env54005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13356 env54004 == env54005) = true)

theorem identity54005 : scanCanonicalize (H12AffineFastState.compose env54005 (packedSelected [0,2,7,9,12,14,15,16,22,35] rootPS)) = affineNative (2^(14+1) ^^^ 249) := by decide +kernel

theorem selectedBound54005 : packedSelected [0,2,7,9,12,14,15,16,22,35] rootPS < 2^1333 := by decide +kernel

def env54006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,249,295,131072,10400,1024,248,12652,8460,152,8615,8328,64,138592,5528,4233,138476,9456,8460,256,8461,13436,513]

theorem envBound54006 : H12AffineFastState.Bounded env54006 := by
  intro p hp
  have h : env54006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54005_54006 : H12AffineEnvironment.transform 14 249 env54005 = env54006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 249 env54005 == env54006) = true)

theorem identity54006 : scanCanonicalize (H12AffineFastState.compose env54006 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound54006 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env54007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,249,295,13461,10400,1024,248,12652,8460,152,8615,8328,64,10741,5528,4233,10361,9456,8460,256,8461,13436,513]

theorem envBound54007 : H12AffineFastState.Bounded env54007 := by
  intro p hp
  have h : env54007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54006_54007 : H12AffineEnvironment.transform 16 13461 env54006 = env54007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env54006 == env54007) = true)

theorem identity54007 : scanCanonicalize (H12AffineFastState.compose env54007 (packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound54007 : packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env54008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,5513,249,295,5424,2309,1024,248,4297,169,152,2,301,64,2128,5528,4233,2524,1365,169,256,168,5593,513]

theorem envBound54008 : H12AffineFastState.Bounded env54008 := by
  intro p hp
  have h : env54008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54007_54008 : H12AffineEnvironment.transform 12 421 env54007 = env54008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env54007 == env54008) = true)

theorem identity54008 : scanCanonicalize (H12AffineFastState.compose env54008 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54008 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env54009 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,300,5376,112,295,5424,2309,1024,113,4160,32,17,2,301,64,2128,5393,4096,2389,1365,32,256,33,5456,513]

theorem envBound54009 : H12AffineFastState.Bounded env54009 := by
  intro p hp
  have h : env54009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54008_54009 : H12AffineEnvironment.transform 6 9 env54008 = env54009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54008 == env54009) = true)

theorem identity54009 : scanCanonicalize (H12AffineFastState.compose env54009 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54009 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54010 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,300,5376,33,295,5424,2309,1024,32,4113,32,17,2,301,17,2049,5393,4096,2308,1284,32,256,33,5377,513]

theorem envBound54010 : H12AffineFastState.Bounded env54010 := by
  intro p hp
  have h : env54010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54009_54010 : H12AffineEnvironment.transform 5 17 env54009 = env54010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54009 == env54010) = true)

theorem identity54010 : scanCanonicalize (H12AffineFastState.compose env54010 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54010 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env54011 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,5376,0,262,5393,2309,1024,1,4113,1,17,2,268,17,2049,5393,4096,2308,1284,1,256,0,5377,513]

theorem envBound54011 : H12AffineFastState.Bounded env54011 := by
  intro p hp
  have h : env54011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54010_54011 : H12AffineEnvironment.transform 4 1 env54010 = env54011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54010 == env54011) = true)

theorem identity54011 : scanCanonicalize (H12AffineFastState.compose env54011 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound54011 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54012 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,1297,269,17,0,262,0,2309,1024,1,1280,1,17,2,268,17,2049,0,1297,2308,1284,1,256,0,16,513]

theorem envBound54012 : H12AffineFastState.Bounded env54012 := by
  intro p hp
  have h : env54012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54011_54012 : H12AffineEnvironment.transform 11 1297 env54011 = env54012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env54011 == env54012) = true)

theorem identity54012 : scanCanonicalize (H12AffineFastState.compose env54012 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound54012 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54013 : List Nat := [2,4,8,16,1,17,9,256,260,1024,2048,1297,269,17,0,262,0,2309,1024,1,1280,1,17,2,268,17,2049,0,1297,2308,1284,1,256,0,16,261]

theorem envBound54013 : H12AffineFastState.Bounded env54013 := by
  intro p hp
  have h : env54013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54012_54013 : H12AffineEnvironment.transform 8 260 env54012 = env54013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env54012 == env54013) = true)

theorem identity54013 : scanCanonicalize (H12AffineFastState.compose env54013 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound54013 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54014 : List Nat := [2,4,8,16,1,17,9,256,260,1024,276,1297,269,17,0,262,0,17,1024,1,1280,1,17,2,268,17,277,0,1297,16,1284,1,256,0,16,261]

theorem envBound54014 : H12AffineFastState.Bounded env54014 := by
  intro p hp
  have h : env54014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54013_54014 : H12AffineEnvironment.transform 10 276 env54013 = env54014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env54013 == env54014) = true)

theorem identity54014 : scanCanonicalize (H12AffineFastState.compose env54014 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54014 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54015 : List Nat := [2,4,8,16,1,17,9,5,1,1024,17,1044,8,17,0,3,0,17,1024,1,1029,1,17,2,9,17,16,0,1044,16,1025,1,5,0,16,0]

theorem envBound54015 : H12AffineFastState.Bounded env54015 := by
  intro p hp
  have h : env54015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54014_54015 : H12AffineEnvironment.transform 7 5 env54014 = env54015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54014 == env54015) = true)

def env54016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,62541,73857,8328,64,410092,57677,58461,406604,20701,21793,256,21793,46213,96011]

theorem envBound54016 : H12AffineFastState.Bounded env54016 := by
  intro p hp
  have h : env54016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54001_54016 : H12AffineEnvironment.transform 20 17729 env54001 = env54016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env54001 == env54016) = true)

theorem identity54016 : scanCanonicalize (H12AffineFastState.compose env54016 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound54016 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,131072,262144,1024,32769,17729,21793,62541,41430,8328,64,410092,57677,58461,406604,20701,21793,256,21793,46213,63068]

theorem envBound54017 : H12AffineFastState.Bounded env54017 := by
  intro p hp
  have h : env54017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54016_54017 : H12AffineEnvironment.transform 15 33111 env54016 = env54017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env54016 == env54017) = true)

def env54018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,131072,10400,1024,32769,17729,21793,62541,41430,8328,64,158028,57677,58461,138476,20701,21793,256,21793,46213,63068]

theorem envBound54018 : H12AffineFastState.Bounded env54018 := by
  intro p hp
  have h : env54018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54017_54018 : H12AffineEnvironment.transform 17 10400 env54017 = env54018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env54017 == env54018) = true)

theorem identity54018 : scanCanonicalize (H12AffineFastState.compose env54018 (packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57489) := by decide +kernel

theorem selectedBound54018 : packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS < 2^1333 := by decide +kernel

def env54019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,57489,10400,1024,32769,17729,21793,62541,41430,8328,64,35293,57677,58461,64637,20701,21793,256,21793,46213,63068]

theorem envBound54019 : H12AffineFastState.Bounded env54019 := by
  intro p hp
  have h : env54019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54018_54019 : H12AffineEnvironment.transform 16 57489 env54018 = env54019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57489 env54018 == env54019) = true)

theorem identity54019 : scanCanonicalize (H12AffineFastState.compose env54019 (packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54019 : packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env54020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57369,10280,1024,32769,17729,21793,62541,41310,8192,64,35157,57677,58461,64637,20565,21793,256,21793,46093,63068]

theorem envBound54020 : H12AffineFastState.Bounded env54020 := by
  intro p hp
  have h : env54020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54019_54020 : H12AffineEnvironment.transform 6 8 env54019 = env54020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54019 == env54020) = true)

theorem identity54020 : scanCanonicalize (H12AffineFastState.compose env54020 (packedSelected [4,9,12,14,15,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54020 : packedSelected [4,9,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env54021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16709,10280,1024,8541,17729,21793,21777,2,8192,64,10249,16401,17665,23841,20565,21793,256,21793,5457,22272]

theorem envBound54021 : H12AffineFastState.Bounded env54021 := by
  intro p hp
  have h : env54021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54020_54021 : H12AffineEnvironment.transform 14 8540 env54020 = env54021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54020 == env54021) = true)

theorem identity54021 : scanCanonicalize (H12AffineFastState.compose env54021 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound54021 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env54022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8540,8203,13641,10280,1024,8541,12621,8493,8477,2,8192,64,10249,13341,12557,10541,9305,8493,256,8493,5457,8972]

theorem envBound54022 : H12AffineFastState.Bounded env54022 := by
  intro p hp
  have h : env54022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54021_54022 : H12AffineEnvironment.transform 13 13324 env54021 = env54022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env54021 == env54022) = true)

theorem identity54022 : scanCanonicalize (H12AffineFastState.compose env54022 (packedSelected [1,2,3,5,6,8,10,12,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54022 : packedSelected [1,2,3,5,6,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env54023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,263,5189,2340,1024,81,4161,33,17,2,268,64,2309,5393,4097,2081,1365,33,256,33,5457,512]

theorem envBound54023 : H12AffineFastState.Bounded env54023 := by
  intro p hp
  have h : env54023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54022_54023 : H12AffineEnvironment.transform 12 268 env54022 = env54023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54022 == env54023) = true)

theorem identity54023 : scanCanonicalize (H12AffineFastState.compose env54023 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54023 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54024 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,121,5237,80,114,5189,2129,1024,81,4161,33,17,2,121,64,2160,5220,4097,2081,1056,33,117,33,5156,512]

theorem envBound54024 : H12AffineFastState.Bounded env54024 := by
  intro p hp
  have h : env54024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54023_54024 : H12AffineEnvironment.transform 7 117 env54023 = env54024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54023 == env54024) = true)

theorem identity54024 : scanCanonicalize (H12AffineFastState.compose env54024 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54024 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env54025 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,121,4161,80,114,4209,2129,52,81,4161,33,17,2,121,64,2160,4176,4097,2081,20,33,117,33,4112,512]

theorem envBound54025 : H12AffineFastState.Bounded env54025 := by
  intro p hp
  have h : env54025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54024_54025 : H12AffineEnvironment.transform 9 52 env54024 = env54025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54024 == env54025) = true)

def env54026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,131072,10401,1024,32769,17729,21793,62541,41430,8328,64,158029,57677,58461,138477,20701,21793,256,21793,46213,63068]

theorem envBound54026 : H12AffineFastState.Bounded env54026 := by
  intro p hp
  have h : env54026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54017_54026 : H12AffineEnvironment.transform 17 10401 env54017 = env54026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env54017 == env54026) = true)

theorem identity54026 : scanCanonicalize (H12AffineFastState.compose env54026 (packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 46440) := by decide +kernel

theorem selectedBound54026 : packedSelected [1,3,4,6,9,11,16,18,21,24,28] rootPS < 2^1333 := by decide +kernel

def env54027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,46440,10401,1024,32769,17729,21793,62541,41430,8328,64,56357,57677,58461,43397,20701,21793,256,21793,46213,63068]

theorem envBound54027 : H12AffineFastState.Bounded env54027 := by
  intro p hp
  have h : env54027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54026_54027 : H12AffineEnvironment.transform 16 46440 env54026 = env54027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46440 env54026 == env54027) = true)

theorem identity54027 : scanCanonicalize (H12AffineFastState.compose env54027 (packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54027 : packedSelected [0,3,6,7,9,19,20,21,22,23,24,31,32] rootPS < 2^1333 := by decide +kernel

def env54028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,46440,10401,1024,32769,4160,32,41292,41430,8328,64,35108,46156,45404,43397,1500,32,256,32,46213,41821]

theorem envBound54028 : H12AffineFastState.Bounded env54028 := by
  intro p hp
  have h : env54028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54027_54028 : H12AffineEnvironment.transform 13 5377 env54027 = env54028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54027 == env54028) = true)

theorem identity54028 : scanCanonicalize (H12AffineFastState.compose env54028 (packedSelected [0,4,7,21,22] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound54028 : packedSelected [0,4,7,21,22] rootPS < 2^1333 := by decide +kernel

def env54029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5377,32768,33111,38297,2128,1024,32769,4160,32,33213,33063,121,64,35108,38077,37293,35188,1500,32,256,32,38004,33708]

theorem envBound54029 : H12AffineFastState.Bounded env54029 := by
  intro p hp
  have h : env54029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54028_54029 : H12AffineEnvironment.transform 12 241 env54028 = env54029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env54028 == env54029) = true)

theorem identity54029 : scanCanonicalize (H12AffineFastState.compose env54029 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54029 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env54030 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,5157,32768,32883,38077,2128,1024,32769,4160,32,32921,32771,121,64,34816,38077,37001,34896,1272,32,36,32,38004,33416]

theorem envBound54030 : H12AffineFastState.Bounded env54030 := by
  intro p hp
  have h : env54030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54029_54030 : H12AffineEnvironment.transform 7 36 env54029 = env54030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54029 == env54030) = true)

theorem identity54030 : scanCanonicalize (H12AffineFastState.compose env54030 (packedSelected [4,6,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound54030 : packedSelected [4,6,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env54031 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,5157,137,250,5172,2128,1024,136,4160,32,16,138,121,64,2185,5172,4096,2265,1272,32,36,32,5373,513]

theorem envBound54031 : H12AffineFastState.Bounded env54031 := by
  intro p hp
  have h : env54031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54030_54031 : H12AffineEnvironment.transform 14 137 env54030 = env54031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env54030 == env54031) = true)

theorem identity54031 : scanCanonicalize (H12AffineFastState.compose env54031 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54031 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54032 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,160,5157,137,171,5172,2049,1024,136,4113,32,16,138,40,17,2185,5172,4096,2184,1193,32,36,32,5292,513]

theorem envBound54032 : H12AffineFastState.Bounded env54032 := by
  intro p hp
  have h : env54032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54031_54032 : H12AffineEnvironment.transform 5 17 env54031 = env54032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54031 == env54032) = true)

theorem identity54032 : scanCanonicalize (H12AffineFastState.compose env54032 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54032 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54033 : List Nat := [2,4,8,16,32,17,128,36,512,53,2048,4096,160,4112,137,171,4097,2049,53,136,4113,32,16,138,40,17,2185,4097,4096,2184,156,32,36,32,4249,513]

theorem envBound54033 : H12AffineFastState.Bounded env54033 := by
  intro p hp
  have h : env54033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54032_54033 : H12AffineEnvironment.transform 9 53 env54032 = env54033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54032 == env54033) = true)

theorem identity54033 : scanCanonicalize (H12AffineFastState.compose env54033 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54033 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54034 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4112,0,34,4097,2049,53,1,4113,32,16,3,40,17,2048,4097,4096,2049,21,32,36,32,4112,513]

theorem envBound54034 : H12AffineFastState.Bounded env54034 := by
  intro p hp
  have h : env54034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54033_54034 : H12AffineEnvironment.transform 6 9 env54033 = env54034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54033 == env54034) = true)

theorem identity54034 : scanCanonicalize (H12AffineFastState.compose env54034 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54035 : List Nat := [2,4,8,0,32,1,9,36,512,37,2048,4096,41,4096,0,34,4097,2049,37,1,4097,32,0,3,40,1,2048,4097,4096,2049,5,32,36,32,4096,513]

theorem envBound54035 : H12AffineFastState.Bounded env54035 := by
  intro p hp
  have h : env54035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54034_54035 : H12AffineEnvironment.transform 3 0 env54034 = env54035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54034 == env54035) = true)

theorem identity54035 : scanCanonicalize (H12AffineFastState.compose env54035 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound54035 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54036 : List Nat := [2,4,8,0,32,1,9,36,10,37,2048,4096,41,4096,0,34,4097,2049,37,1,4097,32,0,3,40,1,2048,4097,4096,2049,5,32,36,32,4096,11]

theorem envBound54036 : H12AffineFastState.Bounded env54036 := by
  intro p hp
  have h : env54036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54035_54036 : H12AffineEnvironment.transform 8 10 env54035 = env54036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env54035 == env54036) = true)

def env54037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101345,62541,2188736,8328,64,410093,57677,2138396,406604,2102684,2101345,256,21793,46213,2175562]

theorem envBound54037 : H12AffineFastState.Bounded env54037 := by
  intro p hp
  have h : env54037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54000_54037 : H12AffineEnvironment.transform 21 2101345 env54000 = env54037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101345 env54000 == env54037) = true)

def env54038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,62541,73856,8328,64,410093,57677,58460,406604,20700,21793,256,21793,46213,96010]

theorem envBound54038 : H12AffineFastState.Bounded env54038 := by
  intro p hp
  have h : env54038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54037_54038 : H12AffineEnvironment.transform 20 17728 env54037 = env54038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env54037 == env54038) = true)

theorem identity54038 : scanCanonicalize (H12AffineFastState.compose env54038 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound54038 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30083,131072,262144,1024,32769,17728,21793,62541,21763,8328,64,410093,57677,58460,406604,20700,21793,256,21793,46213,649]

theorem envBound54039 : H12AffineFastState.Bounded env54039 := by
  intro p hp
  have h : env54039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54038_54039 : H12AffineEnvironment.transform 15 30083 env54038 = env54039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env54038 == env54039) = true)

theorem identity54039 : scanCanonicalize (H12AffineFastState.compose env54039 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54039 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54040 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,17728,21793,62541,21763,8192,64,409957,57677,58460,406604,20564,21793,256,21793,46093,513]

theorem envBound54040 : H12AffineFastState.Bounded env54040 := by
  intro p hp
  have h : env54040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54039_54040 : H12AffineEnvironment.transform 6 8 env54039 = env54040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54039 == env54040) = true)

theorem identity54040 : scanCanonicalize (H12AffineFastState.compose env54040 (packedSelected [0,4,7,9,11,14,15,16,20,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 182629) := by decide +kernel

theorem selectedBound54040 : packedSelected [0,4,7,9,11,14,15,16,20,32,38] rootPS < 2^1333 := by decide +kernel

def env54041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,182629,1024,32769,17728,21793,62541,21763,8192,64,34816,57677,58460,64809,20564,21793,256,21793,46093,513]

theorem envBound54041 : H12AffineFastState.Bounded env54041 := by
  intro p hp
  have h : env54041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54040_54041 : H12AffineEnvironment.transform 17 182629 env54040 = env54041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env54040 == env54041) = true)

theorem identity54041 : scanCanonicalize (H12AffineFastState.compose env54041 (packedSelected [3,5,10,12,15,16,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound54041 : packedSelected [3,5,10,12,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env54042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,49168,2421,1024,32769,17728,21793,62541,21763,8192,64,34816,57677,58460,64809,20564,21793,256,21793,46093,513]

theorem envBound54042 : H12AffineFastState.Bounded env54042 := by
  intro p hp
  have h : env54042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54041_54042 : H12AffineEnvironment.transform 16 49168 env54041 = env54042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env54041 == env54042) = true)

theorem identity54042 : scanCanonicalize (H12AffineFastState.compose env54042 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54042 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env54043 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,29963,49168,2341,1024,32769,17680,21793,62493,21763,8192,16,34816,57629,58380,64809,20484,21793,256,21793,46093,513]

theorem envBound54043 : H12AffineFastState.Bounded env54043 := by
  intro p hp
  have h : env54043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54042_54043 : H12AffineEnvironment.transform 5 16 env54042 = env54043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54042 == env54043) = true)

theorem identity54043 : scanCanonicalize (H12AffineFastState.compose env54043 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound54043 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54044 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,29963,5392,2341,1024,21761,17680,21793,8477,21763,8192,16,23808,13341,12556,10281,20484,21793,256,21793,24845,513]

theorem envBound54044 : H12AffineFastState.Bounded env54044 := by
  intro p hp
  have h : env54044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54043_54044 : H12AffineEnvironment.transform 14 21760 env54043 = env54044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env54043 == env54044) = true)

theorem identity54044 : scanCanonicalize (H12AffineFastState.compose env54044 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54044 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54045 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,21760,21510,5392,2341,1024,21761,17680,21793,16,21763,269,16,23808,5392,4097,2340,20484,21793,256,21793,16384,513]

theorem envBound54045 : H12AffineFastState.Bounded env54045 := by
  intro p hp
  have h : env54045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54044_54045 : H12AffineEnvironment.transform 12 269 env54044 = env54045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54044 == env54045) = true)

theorem identity54045 : scanCanonicalize (H12AffineFastState.compose env54045 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54045 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54046 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,269,16384,21760,21510,5392,2308,1024,21761,17680,21760,16,21763,269,16,23808,5392,4097,2309,20484,21760,256,21760,16384,513]

theorem envBound54046 : H12AffineFastState.Bounded env54046 := by
  intro p hp
  have h : env54046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54045_54046 : H12AffineEnvironment.transform 4 1 env54045 = env54046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54045 == env54046) = true)

theorem identity54046 : scanCanonicalize (H12AffineFastState.compose env54046 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54046 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54047 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,9,16384,21508,21510,5140,2048,1024,21509,17428,21508,16,21511,9,16,23556,5140,4097,2049,20484,21508,4,21508,16384,513]

theorem envBound54047 : H12AffineFastState.Bounded env54047 := by
  intro p hp
  have h : env54047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54046_54047 : H12AffineEnvironment.transform 7 4 env54046 = env54047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54046 == env54047) = true)

theorem identity54047 : scanCanonicalize (H12AffineFastState.compose env54047 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 3093) := by decide +kernel

theorem selectedBound54047 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54048 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,9,3093,6161,6163,5140,2048,1024,6160,2049,6161,16,6162,9,16,4113,5140,4097,2049,7185,6161,4,6161,3093,513]

theorem envBound54048 : H12AffineFastState.Bounded env54048 := by
  intro p hp
  have h : env54048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54047_54048 : H12AffineEnvironment.transform 13 3093 env54047 = env54048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3093 env54047 == env54048) = true)

theorem identity54048 : scanCanonicalize (H12AffineFastState.compose env54048 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54048 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54049 : List Nat := [2,4,8,16,1,16,8,4,512,1024,1,4096,9,1044,4112,4114,5140,1,1024,4113,0,4112,16,4115,9,16,4113,5140,4097,0,5136,4112,4,4112,1044,513]

theorem envBound54049 : H12AffineFastState.Bounded env54049 := by
  intro p hp
  have h : env54049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54048_54049 : H12AffineEnvironment.transform 10 1 env54048 = env54049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54048 == env54049) = true)

theorem identity54049 : scanCanonicalize (H12AffineFastState.compose env54049 (packedSelected [1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1051) := by decide +kernel

theorem selectedBound54049 : packedSelected [1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env54050 : List Nat := [2,4,8,16,1,16,8,4,512,1024,1,1051,9,1044,1035,1033,15,1,1024,1034,0,1035,16,1032,9,16,1034,15,1050,0,11,1035,4,1035,1044,513]

theorem envBound54050 : H12AffineFastState.Bounded env54050 := by
  intro p hp
  have h : env54050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54049_54050 : H12AffineEnvironment.transform 11 1051 env54049 = env54050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1051 env54049 == env54050) = true)

def env54051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,62541,73857,8328,64,410093,57677,58461,406604,20701,21792,256,21793,46213,96011]

theorem envBound54051 : H12AffineFastState.Bounded env54051 := by
  intro p hp
  have h : env54051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54037_54051 : H12AffineEnvironment.transform 20 17729 env54037 = env54051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env54037 == env54051) = true)

theorem identity54051 : scanCanonicalize (H12AffineFastState.compose env54051 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound54051 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17729,21792,62541,21899,8328,64,410093,57677,58461,406604,20701,21792,256,21793,46213,513]

theorem envBound54052 : H12AffineFastState.Bounded env54052 := by
  intro p hp
  have h : env54052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54051_54052 : H12AffineEnvironment.transform 15 29962 env54051 = env54052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env54051 == env54052) = true)

theorem identity54052 : scanCanonicalize (H12AffineFastState.compose env54052 (packedSelected [11,12,15,18,23,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound54052 : packedSelected [11,12,15,18,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env54053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10400,1024,32769,17729,21792,62541,21899,8328,64,158029,57677,58461,138476,20701,21792,256,21793,46213,513]

theorem envBound54053 : H12AffineFastState.Bounded env54053 := by
  intro p hp
  have h : env54053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54052_54053 : H12AffineEnvironment.transform 17 10400 env54052 = env54053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env54052 == env54053) = true)

theorem identity54053 : scanCanonicalize (H12AffineFastState.compose env54053 (packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound54053 : packedSelected [1,2,6,8,9,10,11,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env54054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,5440,10400,1024,32769,17729,21792,62541,21899,8328,64,31757,57677,58461,2476,20701,21792,256,21793,46213,513]

theorem envBound54054 : H12AffineFastState.Bounded env54054 := by
  intro p hp
  have h : env54054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54053_54054 : H12AffineEnvironment.transform 16 5440 env54053 = env54054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env54053 == env54054) = true)

theorem identity54054 : scanCanonicalize (H12AffineFastState.compose env54054 (packedSelected [1,2,4,5,8,9,12,15,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound54054 : packedSelected [1,2,4,5,8,9,12,15,20,24] rootPS < 2^1333 := by decide +kernel

def env54055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,29962,5440,10400,1024,21760,17729,21792,8524,21899,8328,64,31757,13388,12636,2476,20701,21792,256,21793,24964,513]

theorem envBound54055 : H12AffineFastState.Bounded env54055 := by
  intro p hp
  have h : env54055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54054_54055 : H12AffineEnvironment.transform 14 21761 env54054 = env54055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env54054 == env54055) = true)

theorem identity54055 : scanCanonicalize (H12AffineFastState.compose env54055 (packedSelected [2,12,14,15,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound54055 : packedSelected [2,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env54056 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21761,29962,5440,10360,1024,21760,17729,21792,8524,21843,8272,64,31757,13388,12636,2420,20485,21792,256,21793,24924,513]

theorem envBound54056 : H12AffineFastState.Bounded env54056 := by
  intro p hp
  have h : env54056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54055_54056 : H12AffineEnvironment.transform 6 88 env54055 = env54056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env54055 == env54056) = true)

theorem identity54056 : scanCanonicalize (H12AffineFastState.compose env54056 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54056 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env54057 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,16384,21761,21590,5440,2340,1024,21760,17729,21792,16,21843,268,64,23889,5392,4096,2420,20485,21792,256,21793,16384,513]

theorem envBound54057 : H12AffineFastState.Bounded env54057 := by
  intro p hp
  have h : env54057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54056_54057 : H12AffineEnvironment.transform 12 348 env54056 = env54057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54056 == env54057) = true)

theorem identity54057 : scanCanonicalize (H12AffineFastState.compose env54057 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54057 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54058 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,21510,5392,2340,1024,21760,17681,21792,16,21763,268,16,23809,5392,4096,2340,20485,21792,256,21793,16384,513]

theorem envBound54058 : H12AffineFastState.Bounded env54058 := by
  intro p hp
  have h : env54058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54057_54058 : H12AffineEnvironment.transform 5 16 env54057 = env54058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54057 == env54058) = true)

theorem identity54058 : scanCanonicalize (H12AffineFastState.compose env54058 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54058 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54059 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,16384,21541,21510,5172,2048,1024,21540,17461,21508,16,21543,40,16,23589,5172,4096,2048,20485,21508,36,21509,16384,513]

theorem envBound54059 : H12AffineFastState.Bounded env54059 := by
  intro p hp
  have h : env54059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54058_54059 : H12AffineEnvironment.transform 7 36 env54058 = env54059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54058 == env54059) = true)

theorem identity54059 : scanCanonicalize (H12AffineFastState.compose env54059 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound54059 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env54060 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5172,2048,1024,1,4112,33,16,2,40,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound54060 : H12AffineFastState.Bounded env54060 := by
  intro p hp
  have h : env54060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54059_54060 : H12AffineEnvironment.transform 13 5157 env54059 = env54060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env54059 == env54060) = true)

def env54061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound54061 : H12AffineFastState.Bounded env54061 := by
  intro p hp
  have h : env54061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53861_54061 : H12AffineEnvironment.transform 18 1025 env53861 = env54061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env53861 == env54061) = true)

theorem identity54061 : scanCanonicalize (H12AffineFastState.compose env54061 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2262336) := by decide +kernel

theorem selectedBound54061 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262336,16777216,8328,64,23414080,18973836,184337,2377024,19071313,23160256,257,16990701,17014856,19015302]

theorem envBound54062 : H12AffineFastState.Bounded env54062 := by
  intro p hp
  have h : env54062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54061_54062 : H12AffineEnvironment.transform 22 2262336 env54061 = env54062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2262336 env54061 == env54062) = true)

def env54063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262336,201932,8328,64,6705548,2265152,184337,2377024,2102685,6451468,257,21793,46212,2175562]

theorem envBound54063 : H12AffineFastState.Bounded env54063 := by
  intro p hp
  have h : env54063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54062_54063 : H12AffineEnvironment.transform 23 201932 env54062 = env54063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201932 env54062 == env54063) = true)

def env54064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6603932,2098512,17665,2377024,2102685,6349852,257,21793,46212,2175562]

theorem envBound54064 : H12AffineFastState.Bounded env54064 := by
  intro p hp
  have h : env54064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54063_54064 : H12AffineEnvironment.transform 16 38160 env54063 = env54064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env54063 == env54064) = true)

def env54065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2157596,2098512,17665,2377024,2102685,2411676,257,21793,46212,2175562]

theorem envBound54065 : H12AffineFastState.Bounded env54065 := by
  intro p hp
  have h : env54065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54064_54065 : H12AffineEnvironment.transform 21 272512 env54064 = env54065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54064 == env54065) = true)

theorem identity54065 : scanCanonicalize (H12AffineFastState.compose env54065 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound54065 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25029,262144,1025,29908,2097152,272512,2101328,95497,8328,64,2103497,2098512,17665,2377024,2102685,2373705,257,21793,16465,2175562]

theorem envBound54066 : H12AffineFastState.Bounded env54066 := by
  intro p hp
  have h : env54066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54065_54066 : H12AffineEnvironment.transform 14 29909 env54065 = env54066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env54065 == env54066) = true)

def env54067 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24981,262144,1025,29828,2097152,272512,2101248,95497,8328,16,2103449,2098432,17665,2376976,2102685,2373657,257,21793,16385,2175514]

theorem envBound54067 : H12AffineFastState.Bounded env54067 := by
  intro p hp
  have h : env54067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54066_54067 : H12AffineEnvironment.transform 5 16 env54066 = env54067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54066 == env54067) = true)

theorem identity54067 : scanCanonicalize (H12AffineFastState.compose env54067 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54067 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env54068 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,65536,13461,262144,1025,8580,2097152,272512,2101248,73737,8328,16,2103449,2098432,4097,2363408,2102685,2373657,257,33,5377,2175514]

theorem envBound54068 : H12AffineFastState.Bounded env54068 := by
  intro p hp
  have h : env54068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54067_54068 : H12AffineEnvironment.transform 13 5376 env54067 = env54068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54067 == env54068) = true)

theorem identity54068 : scanCanonicalize (H12AffineFastState.compose env54068 (packedSelected [0,9,10,14,16,17,18,19,20,22,23,26,27,31,35] rootPS)) = affineNative (2^(20+1) ^^^ 268733) := by decide +kernel

theorem selectedBound54068 : packedSelected [0,9,10,14,16,17,18,19,20,22,23,26,27,31,35] rootPS < 2^1333 := by decide +kernel

def env54069 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,65536,13461,262144,1025,8580,268733,272512,264637,73737,8328,16,262436,269501,4097,2477,265248,8612,257,33,5377,338855]

theorem envBound54069 : H12AffineFastState.Bounded env54069 := by
  intro p hp
  have h : env54069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54068_54069 : H12AffineEnvironment.transform 20 268733 env54068 = env54069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268733 env54068 == env54069) = true)

theorem identity54069 : scanCanonicalize (H12AffineFastState.compose env54069 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound54069 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env54070 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,65536,13461,76078,1025,8580,77971,65966,73875,73737,8328,16,75786,79251,4097,2477,75022,8612,257,33,5377,649]

theorem envBound54070 : H12AffineFastState.Bounded env54070 := by
  intro p hp
  have h : env54070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54069_54070 : H12AffineEnvironment.transform 17 76078 env54069 = env54070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env54069 == env54070) = true)

theorem identity54070 : scanCanonicalize (H12AffineFastState.compose env54070 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54070 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env54071 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,4096,8192,4404,8581,65536,12449,76078,53,8580,77971,65966,73875,73737,8328,16,75786,78247,4097,2477,74042,8612,257,33,4405,649]

theorem envBound54071 : H12AffineFastState.Bounded env54071 := by
  intro p hp
  have h : env54071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54070_54071 : H12AffineEnvironment.transform 9 52 env54070 = env54071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54070 == env54071) = true)

theorem identity54071 : scanCanonicalize (H12AffineFastState.compose env54071 (packedSelected [1,3,5,8,10,11,12,15,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54071 : packedSelected [1,3,5,8,10,11,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env54072 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,8192,4404,8460,65536,12328,76078,53,8461,77850,65831,73754,73737,8193,16,75786,78126,4097,2340,74042,8493,257,33,4405,512]

theorem envBound54072 : H12AffineFastState.Bounded env54072 := by
  intro p hp
  have h : env54072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54071_54072 : H12AffineEnvironment.transform 6 9 env54071 = env54072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54071 == env54072) = true)

theorem identity54072 : scanCanonicalize (H12AffineFastState.compose env54072 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54072 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54073 : List Nat := [2,4,8,16,0,16,9,256,512,20,2048,4096,8192,4372,8460,65536,12296,76046,21,8461,77850,65799,73754,73737,8193,16,75786,78094,4097,2308,74010,8461,257,1,4373,512]

theorem envBound54073 : H12AffineFastState.Bounded env54073 := by
  intro p hp
  have h : env54073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54072_54073 : H12AffineEnvironment.transform 4 0 env54072 = env54073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54072 == env54073) = true)

theorem identity54073 : scanCanonicalize (H12AffineFastState.compose env54073 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54073 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54074 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8192,4113,8201,65536,12296,75787,21,8200,77850,65538,73754,73737,8193,16,75786,77835,4097,2049,73759,8200,4,1,4112,512]

theorem envBound54074 : H12AffineFastState.Bounded env54074 := by
  intro p hp
  have h : env54074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54073_54074 : H12AffineEnvironment.transform 7 5 env54073 = env54074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54073 == env54074) = true)

theorem identity54074 : scanCanonicalize (H12AffineFastState.compose env54074 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54074 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54075 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8192,4113,8201,8202,12296,2049,21,8200,4112,8200,16,3,8193,16,2048,4097,4097,2049,21,8200,4,1,4112,512]

theorem envBound54075 : H12AffineFastState.Bounded env54075 := by
  intro p hp
  have h : env54075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54074_54075 : H12AffineEnvironment.transform 15 8202 env54074 = env54075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54074 == env54075) = true)

theorem identity54075 : scanCanonicalize (H12AffineFastState.compose env54075 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound54075 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54076 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8,4113,1,2,4096,2049,21,0,4112,0,16,3,9,16,2048,4097,4097,2049,21,0,4,1,4112,512]

theorem envBound54076 : H12AffineFastState.Bounded env54076 := by
  intro p hp
  have h : env54076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54075_54076 : H12AffineEnvironment.transform 12 8 env54075 = env54076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env54075 == env54076) = true)

theorem identity54076 : scanCanonicalize (H12AffineFastState.compose env54076 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2591) := by decide +kernel

theorem selectedBound54076 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54077 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2591,8,2574,1,2,2591,2049,21,0,2575,0,16,3,9,16,2048,2590,2590,2049,21,0,4,1,2575,512]

theorem envBound54077 : H12AffineFastState.Bounded env54077 := by
  intro p hp
  have h : env54077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54076_54077 : H12AffineEnvironment.transform 11 2591 env54076 = env54077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2591 env54076 == env54077) = true)

theorem identity54077 : scanCanonicalize (H12AffineFastState.compose env54077 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound54077 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54078 : List Nat := [2,4,8,16,0,16,9,5,15,20,2048,2064,8,2049,1,2,2064,2049,21,0,2048,0,16,3,9,16,2048,2065,2065,2049,21,0,4,1,2048,15]

theorem envBound54078 : H12AffineFastState.Bounded env54078 := by
  intro p hp
  have h : env54078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54077_54078 : H12AffineEnvironment.transform 8 15 env54077 = env54078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env54077 == env54078) = true)

def env54079 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,262144,1025,29829,2097152,272512,2101249,95497,8328,17,2103448,2098433,17665,2376977,2102685,2373656,257,21793,16384,2175515]

theorem envBound54079 : H12AffineFastState.Bounded env54079 := by
  intro p hp
  have h : env54079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54066_54079 : H12AffineEnvironment.transform 5 17 env54066 = env54079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54066 == env54079) = true)

theorem identity54079 : scanCanonicalize (H12AffineFastState.compose env54079 (packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 4248) := by decide +kernel

theorem selectedBound54079 : packedSelected [3,4,5,7,8,9,10,11,17,19,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env54080 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,262144,1025,29829,4248,272512,153,95497,8328,17,2048,5529,17665,284041,1285,272512,257,21793,16384,74371]

theorem envBound54080 : H12AffineFastState.Bounded env54080 := by
  intro p hp
  have h : env54080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54079_54080 : H12AffineEnvironment.transform 20 4248 env54079 = env54080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4248 env54079 == env54080) = true)

theorem identity54080 : scanCanonicalize (H12AffineFastState.compose env54080 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound54080 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env54081 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,76198,1025,29829,4248,65830,153,95497,8328,17,2048,5529,17665,97327,1285,65830,257,21793,16384,74371]

theorem envBound54081 : H12AffineFastState.Bounded env54081 := by
  intro p hp
  have h : env54081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54080_54081 : H12AffineEnvironment.transform 17 76198 env54080 = env54081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env54080 == env54081) = true)

theorem identity54081 : scanCanonicalize (H12AffineFastState.compose env54081 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound54081 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env54082 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,0,65536,5392,76198,1025,1,4248,65830,153,65933,8328,17,2048,5529,12677,67755,1285,65830,257,8613,13444,74371]

theorem envBound54082 : H12AffineFastState.Bounded env54082 := by
  intro p hp
  have h : env54082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54081_54082 : H12AffineEnvironment.transform 13 13444 env54081 = env54082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env54081 == env54082) = true)

theorem identity54082 : scanCanonicalize (H12AffineFastState.compose env54082 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound54082 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54083 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,0,263,5392,10401,1025,1,4248,33,153,138,8328,17,2048,5529,12677,2476,1285,33,257,8613,13444,9092]

theorem envBound54083 : H12AffineFastState.Bounded env54083 := by
  intro p hp
  have h : env54083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54082_54083 : H12AffineEnvironment.transform 15 263 env54082 = env54083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env54082 == env54083) = true)

def env54084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2157597,2098512,17665,2377024,2102685,2411677,257,21793,46212,2175562]

theorem envBound54084 : H12AffineFastState.Bounded env54084 := by
  intro p hp
  have h : env54084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54064_54084 : H12AffineEnvironment.transform 21 272513 env54064 = env54084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54064 == env54084) = true)

theorem identity54084 : scanCanonicalize (H12AffineFastState.compose env54084 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound54084 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58516,272513,62660,98780,8328,64,2185,57796,17665,303572,61705,272393,257,21793,46212,120542]

theorem envBound54085 : H12AffineFastState.Bounded env54085 := by
  intro p hp
  have h : env54085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54084_54085 : H12AffineEnvironment.transform 20 58516 env54084 = env54085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env54084 == env54085) = true)

def env54086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,58516,169,62660,98780,8328,64,2185,57796,17665,35324,61705,33,257,21793,46212,120542]

theorem envBound54086 : H12AffineFastState.Bounded env54086 := by
  intro p hp
  have h : env54086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54085_54086 : H12AffineEnvironment.transform 17 10280 env54085 = env54086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54085 == env54086) = true)

theorem identity54086 : scanCanonicalize (H12AffineFastState.compose env54086 (packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound54086 : packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env54087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,38160,10280,1025,32769,36929,169,32785,98780,8328,64,2185,38161,12756,35324,34268,33,257,8692,46212,107019]

theorem envBound54087 : H12AffineFastState.Bounded env54087 := by
  intro p hp
  have h : env54087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54086_54087 : H12AffineEnvironment.transform 13 13525 env54086 = env54087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env54086 == env54087) = true)

theorem identity54087 : scanCanonicalize (H12AffineFastState.compose env54087 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound54087 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env54088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,41091,38160,10280,1025,32769,36929,169,32785,8543,8328,64,2185,38161,12756,35324,34268,33,257,8692,46212,648]

theorem envBound54088 : H12AffineFastState.Bounded env54088 := by
  intro p hp
  have h : env54088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54087_54088 : H12AffineEnvironment.transform 15 41091 env54087 = env54088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env54087 == env54088) = true)

theorem identity54088 : scanCanonicalize (H12AffineFastState.compose env54088 (packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound54088 : packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env54089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,80,8403,5440,10280,1025,81,4113,169,65,8543,8328,64,2185,5441,12756,2476,1420,33,257,8692,13524,648]

theorem envBound54089 : H12AffineFastState.Bounded env54089 := by
  intro p hp
  have h : env54089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54088_54089 : H12AffineEnvironment.transform 14 80 env54088 = env54089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env54088 == env54089) = true)

theorem identity54089 : scanCanonicalize (H12AffineFastState.compose env54089 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound54089 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54090 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13324,80,8202,5440,10280,1025,81,4113,112,65,8543,8273,64,2128,5441,12557,2421,1365,33,257,8493,13325,593]

theorem envBound54090 : H12AffineFastState.Bounded env54090 := by
  intro p hp
  have h : env54090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54089_54090 : H12AffineEnvironment.transform 6 89 env54089 = env54090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env54089 == env54090) = true)

theorem identity54090 : scanCanonicalize (H12AffineFastState.compose env54090 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54090 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env54091 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,80,343,5440,2421,1025,81,4113,112,65,2,268,64,2128,5441,4176,2421,1365,33,257,112,5456,593]

theorem envBound54091 : H12AffineFastState.Bounded env54091 := by
  intro p hp
  have h : env54091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54090_54091 : H12AffineEnvironment.transform 12 349 env54090 = env54091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54090 == env54091) = true)

theorem identity54091 : scanCanonicalize (H12AffineFastState.compose env54091 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound54091 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env54092 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,261,349,1108,80,343,1093,2421,1025,81,276,112,65,2,268,64,2128,1092,341,2421,1365,33,257,112,1109,593]

theorem envBound54092 : H12AffineFastState.Bounded env54092 := by
  intro p hp
  have h : env54092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54091_54092 : H12AffineEnvironment.transform 11 261 env54091 = env54092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env54091 == env54092) = true)

theorem identity54092 : scanCanonicalize (H12AffineFastState.compose env54092 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound54092 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env54093 : List Nat := [2,4,8,16,32,64,89,256,340,1024,2048,261,349,1108,80,343,1093,2421,1025,81,276,112,65,2,268,64,2128,1092,341,2421,1365,33,257,112,1109,261]

theorem envBound54093 : H12AffineFastState.Bounded env54093 := by
  intro p hp
  have h : env54093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54092_54093 : H12AffineEnvironment.transform 8 340 env54092 = env54093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env54092 == env54093) = true)

theorem identity54093 : scanCanonicalize (H12AffineFastState.compose env54093 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54093 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54094 : List Nat := [2,4,8,16,32,16,9,256,260,1024,2048,261,269,1028,0,263,1045,2341,1025,1,276,32,17,2,268,16,2048,1044,261,2341,1285,33,257,32,1029,261]

theorem envBound54094 : H12AffineFastState.Bounded env54094 := by
  intro p hp
  have h : env54094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54093_54094 : H12AffineEnvironment.transform 5 16 env54093 = env54094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54093 == env54094) = true)

theorem identity54094 : scanCanonicalize (H12AffineFastState.compose env54094 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound54094 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54095 : List Nat := [2,4,8,16,32,16,9,256,260,21,2048,261,269,17,0,263,0,2341,20,1,276,32,17,2,268,16,2048,1,261,2341,272,33,257,32,16,261]

theorem envBound54095 : H12AffineFastState.Bounded env54095 := by
  intro p hp
  have h : env54095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54094_54095 : H12AffineEnvironment.transform 9 21 env54094 = env54095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env54094 == env54095) = true)

theorem identity54095 : scanCanonicalize (H12AffineFastState.compose env54095 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound54095 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54096 : List Nat := [2,4,8,16,32,16,9,256,260,21,42,261,269,17,0,263,0,271,20,1,276,32,17,2,268,16,42,1,261,271,272,33,257,32,16,261]

theorem envBound54096 : H12AffineFastState.Bounded env54096 := by
  intro p hp
  have h : env54096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54095_54096 : H12AffineEnvironment.transform 10 42 env54095 = env54096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env54095 == env54096) = true)

theorem identity54096 : scanCanonicalize (H12AffineFastState.compose env54096 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54096 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54097 : List Nat := [2,4,8,16,0,16,9,256,260,21,10,261,269,17,0,263,0,271,20,1,276,0,17,2,268,16,10,1,261,271,272,1,257,0,16,261]

theorem envBound54097 : H12AffineFastState.Bounded env54097 := by
  intro p hp
  have h : env54097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54096_54097 : H12AffineEnvironment.transform 4 0 env54096 = env54097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54096 == env54097) = true)

theorem identity54097 : scanCanonicalize (H12AffineFastState.compose env54097 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound54097 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54098 : List Nat := [2,4,8,16,0,16,9,18,22,21,10,23,31,17,0,21,0,29,20,1,6,0,17,2,30,16,10,1,23,29,2,1,19,0,16,23]

theorem envBound54098 : H12AffineFastState.Bounded env54098 := by
  intro p hp
  have h : env54098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54097_54098 : H12AffineEnvironment.transform 7 18 env54097 = env54098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env54097 == env54098) = true)

def env54099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,58516,168,62660,98780,8328,64,2185,57796,17665,35325,61705,32,257,21793,46212,120542]

theorem envBound54099 : H12AffineFastState.Bounded env54099 := by
  intro p hp
  have h : env54099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54085_54099 : H12AffineEnvironment.transform 17 10281 env54085 = env54099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env54085 == env54099) = true)

theorem identity54099 : scanCanonicalize (H12AffineFastState.compose env54099 (packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 508) := by decide +kernel

theorem selectedBound54099 : packedSelected [0,1,2,4,5,6,8,9,17,19,20,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env54100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,508,65536,5356,10281,1025,509,25960,168,30008,65568,8328,64,2185,24632,17665,2049,28917,32,257,21793,13688,87842]

theorem envBound54100 : H12AffineFastState.Bounded env54100 := by
  intro p hp
  have h : env54100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54099_54100 : H12AffineEnvironment.transform 14 508 env54099 = env54100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 508 env54099 == env54100) = true)

theorem identity54100 : scanCanonicalize (H12AffineFastState.compose env54100 (packedSelected [1,4,8,9,14,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 20943) := by decide +kernel

theorem selectedBound54100 : packedSelected [1,4,8,9,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env54101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,508,20943,5356,10281,1025,509,25960,168,30008,20975,8328,64,2185,24632,17665,2049,28917,32,257,21793,13688,1773]

theorem envBound54101 : H12AffineFastState.Bounded env54101 := by
  intro p hp
  have h : env54101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54100_54101 : H12AffineEnvironment.transform 15 20943 env54100 = env54101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20943 env54100 == env54101) = true)

theorem identity54101 : scanCanonicalize (H12AffineFastState.compose env54101 (packedSelected [1,8,10,12,15,17,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound54101 : packedSelected [1,8,10,12,15,17,26,31] rootPS < 2^1333 := by decide +kernel

def env54102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,508,9547,5356,10281,1025,509,4588,168,444,9579,8328,64,2185,5308,12677,2049,1137,32,257,8613,13688,1773]

theorem envBound54102 : H12AffineFastState.Bounded env54102 := by
  intro p hp
  have h : env54102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54101_54102 : H12AffineEnvironment.transform 13 13444 env54101 = env54102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env54101 == env54102) = true)

theorem identity54102 : scanCanonicalize (H12AffineFastState.compose env54102 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54102 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env54103 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,13444,217,9326,5356,10281,1025,216,4297,168,153,9294,8328,64,2185,5308,12448,2049,1137,32,36,8320,13405,1773]

theorem envBound54103 : H12AffineFastState.Bounded env54103 := by
  intro p hp
  have h : env54103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54102_54103 : H12AffineEnvironment.transform 7 37 env54102 = env54103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54102 == env54103) = true)

theorem identity54103 : scanCanonicalize (H12AffineFastState.compose env54103 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound54103 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env54104 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,1053,4249,217,115,5356,3124,1025,216,4297,168,153,83,1173,64,2185,5308,5309,2049,1137,32,36,1181,4160,1773]

theorem envBound54104 : H12AffineFastState.Bounded env54104 := by
  intro p hp
  have h : env54104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54103_54104 : H12AffineEnvironment.transform 12 1053 env54103 = env54104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env54103 == env54104) = true)

theorem identity54104 : scanCanonicalize (H12AffineFastState.compose env54104 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound54104 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54105 : List Nat := [2,4,8,16,32,64,128,37,512,236,2048,4096,241,4249,217,115,4096,2264,237,216,4297,168,153,83,121,64,2185,4176,4177,2049,157,32,36,113,4160,513]

theorem envBound54105 : H12AffineFastState.Bounded env54105 := by
  intro p hp
  have h : env54105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54104_54105 : H12AffineEnvironment.transform 9 236 env54104 = env54105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env54104 == env54105) = true)

def env54106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6603933,2098513,17664,2377024,2102685,6349853,257,21793,46212,2175562]

theorem envBound54106 : H12AffineFastState.Bounded env54106 := by
  intro p hp
  have h : env54106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54063_54106 : H12AffineEnvironment.transform 16 38161 env54063 = env54106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env54063 == env54106) = true)

def env54107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2157597,2098513,17664,2377024,2102685,2411677,257,21793,46212,2175562]

theorem envBound54107 : H12AffineFastState.Bounded env54107 := by
  intro p hp
  have h : env54107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54106_54107 : H12AffineEnvironment.transform 21 272512 env54106 = env54107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54106 == env54107) = true)

def env54108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272392,2101329,98645,8192,64,2157597,2098513,17664,2377024,2102549,2411541,257,21793,46092,2175562]

theorem envBound54108 : H12AffineFastState.Bounded env54108 := by
  intro p hp
  have h : env54108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54107_54108 : H12AffineEnvironment.transform 6 8 env54107 = env54108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54107 == env54108) = true)

theorem identity54108 : scanCanonicalize (H12AffineFastState.compose env54108 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 124234) := by decide +kernel

theorem selectedBound54108 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env54109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,124234,272392,128283,98645,8192,64,67927,122907,17664,368650,127071,338271,257,21793,46092,55040]

theorem envBound54109 : H12AffineFastState.Bounded env54109 := by
  intro p hp
  have h : env54109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54108_54109 : H12AffineEnvironment.transform 20 124234 env54108 = env54109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124234 env54108 == env54109) = true)

theorem identity54109 : scanCanonicalize (H12AffineFastState.compose env54109 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54109 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env54110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,38161,262144,1025,32769,102678,272392,98631,98645,8192,64,67927,103495,12636,368650,99331,338271,257,8573,46092,41820]

theorem envBound54110 : H12AffineFastState.Bounded env54110 := by
  intro p hp
  have h : env54110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54109_54110 : H12AffineEnvironment.transform 13 13404 env54109 = env54110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54109 == env54110) = true)

theorem identity54110 : scanCanonicalize (H12AffineFastState.compose env54110 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound54110 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env54111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,65536,13388,262144,1025,8540,77899,272392,73754,73736,8192,64,67927,79130,12636,328023,75102,338271,257,8573,5457,513]

theorem envBound54111 : H12AffineFastState.Bounded env54111 := by
  intro p hp
  have h : env54111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54110_54111 : H12AffineEnvironment.transform 14 8541 env54110 = env54111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env54110 == env54111) = true)

theorem identity54111 : scanCanonicalize (H12AffineFastState.compose env54111 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 68914) := by decide +kernel

theorem selectedBound54111 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,65536,13388,68914,1025,8540,77899,75066,73754,73736,8192,64,67927,79130,12636,3173,75102,9325,257,8573,5457,513]

theorem envBound54112 : H12AffineFastState.Bounded env54112 := by
  intro p hp
  have h : env54112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54111_54112 : H12AffineEnvironment.transform 17 68914 env54111 = env54112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68914 env54111 == env54112) = true)

theorem identity54112 : scanCanonicalize (H12AffineFastState.compose env54112 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound54112 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4113,1296,65536,4097,68914,1025,1297,70662,65911,66647,66629,1101,64,67927,69975,5393,3173,65811,32,257,1328,5457,513]

theorem envBound54113 : H12AffineFastState.Bounded env54113 := by
  intro p hp
  have h : env54113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54112_54113 : H12AffineEnvironment.transform 12 1101 env54112 = env54113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env54112 == env54113) = true)

theorem identity54113 : scanCanonicalize (H12AffineFastState.compose env54113 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound54113 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4113,1296,342,4097,3172,1025,1297,5456,33,1281,1299,1101,64,2049,4097,5393,3173,69,32,257,1328,5457,513]

theorem envBound54114 : H12AffineFastState.Bounded env54114 := by
  intro p hp
  have h : env54114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54113_54114 : H12AffineEnvironment.transform 15 342 env54113 = env54114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env54113 == env54114) = true)

theorem identity54114 : scanCanonicalize (H12AffineFastState.compose env54114 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound54114 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,1101,3173,1296,342,3189,3172,1025,1297,2340,33,1281,1299,1101,64,2049,3189,2405,3173,69,32,257,1328,2341,513]

theorem envBound54115 : H12AffineFastState.Bounded env54115 := by
  intro p hp
  have h : env54115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54114_54115 : H12AffineEnvironment.transform 11 3188 env54114 = env54115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env54114 == env54115) = true)

theorem identity54115 : scanCanonicalize (H12AffineFastState.compose env54115 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54115 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env54116 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3188,1101,3173,1076,114,3189,3172,1025,1077,2048,33,1061,1079,1101,64,2049,3189,2113,3173,69,32,37,1044,2049,513]

theorem envBound54116 : H12AffineFastState.Bounded env54116 := by
  intro p hp
  have h : env54116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54115_54116 : H12AffineEnvironment.transform 7 36 env54115 = env54116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54115 == env54116) = true)

theorem identity54116 : scanCanonicalize (H12AffineFastState.compose env54116 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54116 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env54117 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3108,1053,3125,1076,34,3109,3124,1025,1077,2048,33,1061,1079,1053,16,2049,3109,2065,3125,21,32,37,1044,2049,513]

theorem envBound54117 : H12AffineFastState.Bounded env54117 := by
  intro p hp
  have h : env54117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54116_54117 : H12AffineEnvironment.transform 5 16 env54116 = env54117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54116 == env54117) = true)

theorem identity54117 : scanCanonicalize (H12AffineFastState.compose env54117 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54117 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env54118 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,40,2048,1,34,2064,2049,52,0,2048,33,16,2,40,16,2049,2064,2065,2048,21,32,37,33,2049,513]

theorem envBound54118 : H12AffineFastState.Bounded env54118 := by
  intro p hp
  have h : env54118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54117_54118 : H12AffineEnvironment.transform 9 53 env54117 = env54118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54117 == env54118) = true)

theorem identity54118 : scanCanonicalize (H12AffineFastState.compose env54118 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound54118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54119 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,33,40,48,1,34,32,49,52,0,48,33,16,2,40,16,49,32,33,48,21,32,37,33,49,513]

theorem envBound54119 : H12AffineFastState.Bounded env54119 := by
  intro p hp
  have h : env54119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54118_54119 : H12AffineEnvironment.transform 10 48 env54118 = env54119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env54118 == env54119) = true)

def leafEnv54119 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,33,40,48,1,34,32,49,52,0,48,33,16,2,20,40,1,16,49,32,33,48,21,32,37,33,5,34,49,513,1,49,0]

def active54119 : List Nat := [0,1,2,3,4,8]

def tree54119 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54119 : H12WitnessSearch.Good tree54119 := H12GlobalWitnessIndex.good

theorem leafIdentity54119 : H12AffineFastState.composeSystem env54119 rootObs = leafEnv54119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54119 rootObs == leafEnv54119) = true)

theorem terminalChecked54119 : H12PackedTerminal.terminalCheckFast leafEnv54119 active54119 tree54119 = true := by decide +kernel

def env54120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272393,2101329,98644,8193,64,2157597,2098513,17664,2377024,2102548,2411540,257,21793,46093,2175562]

theorem envBound54120 : H12AffineFastState.Bounded env54120 := by
  intro p hp
  have h : env54120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54107_54120 : H12AffineEnvironment.transform 6 9 env54107 = env54120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54107 == env54120) = true)

def env54121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272393,17,98644,8193,64,64605,5393,17664,283904,1364,318548,257,21793,46093,74250]

theorem envBound54121 : H12AffineFastState.Bounded env54121 := by
  intro p hp
  have h : env54121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54120_54121 : H12AffineEnvironment.transform 20 4160 env54120 = env54121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54120 == env54121) = true)

theorem identity54121 : scanCanonicalize (H12AffineFastState.compose env54121 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54121 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4160,33,17,98644,8193,64,64605,5393,17664,32040,1364,62588,257,21793,46093,74250]

theorem envBound54122 : H12AffineFastState.Bounded env54122 := by
  intro p hp
  have h : env54122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54121_54122 : H12AffineEnvironment.transform 17 10280 env54121 = env54122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54121 == env54122) = true)

theorem identity54122 : scanCanonicalize (H12AffineFastState.compose env54122 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54122 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env54123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10280,1025,32769,4160,33,17,98644,8193,64,43356,5393,4097,10281,1364,41341,257,32,46093,74250]

theorem envBound54123 : H12AffineFastState.Bounded env54123 := by
  intro p hp
  have h : env54123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54122_54123 : H12AffineEnvironment.transform 13 5377 env54122 = env54123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54122 == env54123) = true)

theorem identity54123 : scanCanonicalize (H12AffineFastState.compose env54123 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound54123 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env54124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,40970,38161,10280,1025,32769,4160,33,17,8542,8193,64,43356,5393,4097,10281,1364,41341,257,32,46093,33280]

theorem envBound54124 : H12AffineFastState.Bounded env54124 := by
  intro p hp
  have h : env54124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54123_54124 : H12AffineEnvironment.transform 15 40970 env54123 = env54124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env54123 == env54124) = true)

theorem identity54124 : scanCanonicalize (H12AffineFastState.compose env54124 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound54124 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env54125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,8282,5441,10280,1025,81,4160,33,17,8542,8193,64,10508,5393,4097,10281,1364,8493,257,32,13405,592]

theorem envBound54125 : H12AffineFastState.Bounded env54125 := by
  intro p hp
  have h : env54125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54124_54125 : H12AffineEnvironment.transform 14 80 env54124 = env54125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env54124 == env54125) = true)

theorem identity54125 : scanCanonicalize (H12AffineFastState.compose env54125 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound54125 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env54126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1141,8192,372,80,8282,308,10280,1025,81,1077,33,17,8542,8193,64,10508,356,1140,10281,1364,8493,257,32,8232,592]

theorem envBound54126 : H12AffineFastState.Bounded env54126 := by
  intro p hp
  have h : env54126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54125_54126 : H12AffineEnvironment.transform 11 1141 env54125 = env54126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env54125 == env54126) = true)

theorem identity54126 : scanCanonicalize (H12AffineFastState.compose env54126 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound54126 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env54127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1141,2317,372,80,2391,308,293,1025,81,1077,33,17,2131,2316,64,1,356,1140,292,1364,2080,257,32,2341,592]

theorem envBound54127 : H12AffineFastState.Bounded env54127 := by
  intro p hp
  have h : env54127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54126_54127 : H12AffineEnvironment.transform 12 2317 env54126 = env54127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env54126 == env54127) = true)

def env54128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272393,16,98644,8193,64,64604,5392,17664,283905,1365,318549,257,21793,46093,74251]

theorem envBound54128 : H12AffineFastState.Bounded env54128 := by
  intro p hp
  have h : env54128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54120_54128 : H12AffineEnvironment.transform 20 4161 env54120 = env54128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54120 == env54128) = true)

theorem identity54128 : scanCanonicalize (H12AffineFastState.compose env54128 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54128 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,4161,272393,16,41310,8193,64,64604,5392,17664,283905,1365,318549,257,21793,46093,513]

theorem envBound54129 : H12AffineFastState.Bounded env54129 := by
  intro p hp
  have h : env54129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54128_54129 : H12AffineEnvironment.transform 15 8202 env54128 = env54129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54128 == env54129) = true)

theorem identity54129 : scanCanonicalize (H12AffineFastState.compose env54129 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound54129 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8202,16400,262144,1025,21760,4161,272393,16,29791,8193,64,10589,5392,17664,283905,1365,264532,257,21793,24844,513]

theorem envBound54130 : H12AffineFastState.Bounded env54130 := by
  intro p hp
  have h : env54130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54129_54130 : H12AffineEnvironment.transform 14 21761 env54129 = env54130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env54129 == env54130) = true)

theorem identity54130 : scanCanonicalize (H12AffineFastState.compose env54130 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54130 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env54131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8202,13388,262144,1025,8540,4161,272393,16,3,8193,64,10589,5392,12636,270685,1365,264532,257,8573,5456,513]

theorem envBound54131 : H12AffineFastState.Bounded env54131 := by
  intro p hp
  have h : env54131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54130_54131 : H12AffineEnvironment.transform 13 13404 env54130 = env54131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54130 == env54131) = true)

theorem identity54131 : scanCanonicalize (H12AffineFastState.compose env54131 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54131 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,81,262,5440,262144,1025,80,4161,264453,16,3,269,64,2129,5392,4176,262225,1365,264532,257,113,5456,513]

theorem envBound54132 : H12AffineFastState.Bounded env54132 := by
  intro p hp
  have h : env54132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54131_54132 : H12AffineEnvironment.transform 12 268 env54131 = env54132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54131 == env54132) = true)

theorem identity54132 : scanCanonicalize (H12AffineFastState.compose env54132 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54132 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54133 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,5237,81,35,5221,262144,1025,80,4161,264224,16,3,40,64,2129,5173,4176,262225,1136,264305,36,113,5237,513]

theorem envBound54133 : H12AffineFastState.Bounded env54133 := by
  intro p hp
  have h : env54133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54132_54133 : H12AffineEnvironment.transform 7 37 env54132 = env54133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54132 == env54133) = true)

theorem identity54133 : scanCanonicalize (H12AffineFastState.compose env54133 (packedSelected [0,2,7] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound54133 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env54134 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,41,5237,81,35,5221,2049,1025,80,4161,33,16,3,40,64,2129,5173,4176,2128,1136,112,36,113,5237,513]

theorem envBound54134 : H12AffineFastState.Bounded env54134 := by
  intro p hp
  have h : env54134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54133_54134 : H12AffineEnvironment.transform 17 2049 env54133 = env54134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env54133 == env54134) = true)

theorem identity54134 : scanCanonicalize (H12AffineFastState.compose env54134 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54134 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54135 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,0,35,5172,2049,1025,1,4112,33,16,3,40,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound54135 : H12AffineFastState.Bounded env54135 := by
  intro p hp
  have h : env54135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54134_54135 : H12AffineEnvironment.transform 5 17 env54134 = env54135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54134 == env54135) = true)

def env54136 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,41,1044,0,35,1028,2049,1025,1,32,33,16,3,40,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound54136 : H12AffineFastState.Bounded env54136 := by
  intro p hp
  have h : env54136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54135_54136 : H12AffineEnvironment.transform 11 48 env54135 = env54136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54135 == env54136) = true)

def env54137 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,41,1045,0,35,1029,2049,1025,1,33,33,16,3,40,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound54137 : H12AffineFastState.Bounded env54137 := by
  intro p hp
  have h : env54137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54135_54137 : H12AffineEnvironment.transform 11 49 env54135 = env54137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54135 == env54137) = true)

theorem identity54137 : scanCanonicalize (H12AffineFastState.compose env54137 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54138 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,49,41,32,0,35,48,2049,52,1,33,33,16,3,40,17,2048,49,48,2049,20,33,36,32,32,513]

theorem envBound54138 : H12AffineFastState.Bounded env54138 := by
  intro p hp
  have h : env54138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54137_54138 : H12AffineEnvironment.transform 9 53 env54137 = env54138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54137 == env54138) = true)

def env54139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2157596,2098513,17664,2377024,2102685,2411676,257,21793,46212,2175562]

theorem envBound54139 : H12AffineFastState.Bounded env54139 := by
  intro p hp
  have h : env54139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54106_54139 : H12AffineEnvironment.transform 21 272513 env54106 = env54139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54106 == env54139) = true)

theorem identity54139 : scanCanonicalize (H12AffineFastState.compose env54139 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound54139 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272513,17,98781,8328,64,64604,5393,17664,283904,1501,318684,257,21793,46212,74250]

theorem envBound54140 : H12AffineFastState.Bounded env54140 := by
  intro p hp
  have h : env54140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54139_54140 : H12AffineEnvironment.transform 20 4160 env54139 = env54140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54139 == env54140) = true)

theorem identity54140 : scanCanonicalize (H12AffineFastState.compose env54140 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54140 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,4160,272513,17,41430,8328,64,64604,5393,17664,283904,1501,318684,257,21793,46212,513]

theorem envBound54141 : H12AffineFastState.Bounded env54141 := by
  intro p hp
  have h : env54141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54140_54141 : H12AffineEnvironment.transform 15 8203 env54140 = env54141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54140 == env54141) = true)

def env54142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262336,201933,8328,64,6705549,2265153,184337,2377024,2102684,6451469,257,21792,46213,2175563]

theorem envBound54142 : H12AffineFastState.Bounded env54142 := by
  intro p hp
  have h : env54142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54062_54142 : H12AffineEnvironment.transform 23 201933 env54062 = env54142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201933 env54062 == env54142) = true)

def env54143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6603933,2098513,17665,2377024,2102684,6349853,257,21792,46213,2175563]

theorem envBound54143 : H12AffineFastState.Bounded env54143 := by
  intro p hp
  have h : env54143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54142_54143 : H12AffineEnvironment.transform 16 38160 env54142 = env54143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env54142 == env54143) = true)

def env54144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2157597,2098513,17665,2377024,2102684,2411677,257,21792,46213,2175563]

theorem envBound54144 : H12AffineFastState.Bounded env54144 := by
  intro p hp
  have h : env54144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54143_54144 : H12AffineEnvironment.transform 21 272512 env54143 = env54144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54143 == env54144) = true)

theorem identity54144 : scanCanonicalize (H12AffineFastState.compose env54144 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound54144 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77898,272512,73754,98781,8328,64,121943,79131,17665,357642,75222,392407,257,21792,46213,513]

theorem envBound54145 : H12AffineFastState.Bounded env54145 := by
  intro p hp
  have h : env54145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54144_54145 : H12AffineEnvironment.transform 20 77898 env54144 = env54145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env54144 == env54145) = true)

def env54146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77898,272392,73754,98645,8192,64,121943,79131,17665,357642,75102,392287,257,21792,46093,513]

theorem envBound54146 : H12AffineFastState.Bounded env54146 := by
  intro p hp
  have h : env54146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54145_54146 : H12AffineEnvironment.transform 6 8 env54145 = env54146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54145 == env54146) = true)

theorem identity54146 : scanCanonicalize (H12AffineFastState.compose env54146 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound54146 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,50496,272392,54544,29791,8192,64,10589,49169,17665,294912,53332,264533,257,21792,46093,513]

theorem envBound54147 : H12AffineFastState.Bounded env54147 := by
  intro p hp
  have h : env54147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54146_54147 : H12AffineEnvironment.transform 15 62730 env54146 = env54147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env54146 == env54147) = true)

theorem identity54147 : scanCanonicalize (H12AffineFastState.compose env54147 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound54147 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env54148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21621,8575,16741,262144,1025,21620,4405,272392,357,29791,8192,64,10589,5220,17665,283765,1057,264533,257,21792,24696,513]

theorem envBound54148 : H12AffineFastState.Bounded env54148 := by
  intro p hp
  have h : env54148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54147_54148 : H12AffineEnvironment.transform 14 21621 env54147 = env54148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env54147 == env54148) = true)

theorem identity54148 : scanCanonicalize (H12AffineFastState.compose env54148 (packedSelected [0,2,6,7,11,17,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound54148 : packedSelected [0,2,6,7,11,17,20,23] rootPS < 2^1333 := by decide +kernel

def env54149 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8461,8575,13341,262144,1025,8460,4405,272392,357,295,8192,64,10589,5220,12409,270605,1057,264533,257,8280,5376,513]

theorem envBound54149 : H12AffineFastState.Bounded env54149 := by
  intro p hp
  have h : env54149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54148_54149 : H12AffineEnvironment.transform 13 13688 env54148 = env54149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env54148 == env54149) = true)

theorem identity54149 : scanCanonicalize (H12AffineFastState.compose env54149 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54149 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env54150 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13608,8461,8495,13341,262144,1025,8460,4405,272392,309,295,8192,16,10509,5172,12329,270605,1057,264453,257,8200,5376,513]

theorem envBound54150 : H12AffineFastState.Bounded env54150 := by
  intro p hp
  have h : env54150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54149_54150 : H12AffineEnvironment.transform 5 16 env54149 = env54150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54149 == env54150) = true)

theorem identity54150 : scanCanonicalize (H12AffineFastState.compose env54150 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54150 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env54151 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5377,292,262,5172,262144,1025,293,4405,264225,309,295,41,16,2340,5172,4096,262436,1057,264453,257,33,5376,513]

theorem envBound54151 : H12AffineFastState.Bounded env54151 := by
  intro p hp
  have h : env54151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54150_54151 : H12AffineEnvironment.transform 12 41 env54150 = env54151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54150 == env54151) = true)

theorem identity54151 : scanCanonicalize (H12AffineFastState.compose env54151 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54151 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54152 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,1,35,5172,262144,1025,0,4112,264225,16,2,41,16,2049,5172,4096,262145,1057,264224,36,33,5157,513]

theorem envBound54152 : H12AffineFastState.Bounded env54152 := by
  intro p hp
  have h : env54152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54151_54152 : H12AffineEnvironment.transform 7 37 env54151 = env54152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54151 == env54152) = true)

theorem identity54152 : scanCanonicalize (H12AffineFastState.compose env54152 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 3124) := by decide +kernel

theorem selectedBound54152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54153 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,1,35,5172,3124,1025,0,4112,1045,16,2,41,16,2049,5172,4096,3125,1057,1044,36,33,5157,513]

theorem envBound54153 : H12AffineFastState.Bounded env54153 := by
  intro p hp
  have h : env54153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54152_54153 : H12AffineEnvironment.transform 17 3124 env54152 = env54153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3124 env54152 == env54153) = true)

theorem identity54153 : scanCanonicalize (H12AffineFastState.compose env54153 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound54153 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54154 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,2065,41,3125,1,35,3109,3124,1025,0,2049,1045,16,2,41,16,2049,3109,2065,3125,1057,1044,36,33,3124,513]

theorem envBound54154 : H12AffineFastState.Bounded env54154 := by
  intro p hp
  have h : env54154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54153_54154 : H12AffineEnvironment.transform 11 2065 env54153 = env54154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env54153 == env54154) = true)

theorem identity54154 : scanCanonicalize (H12AffineFastState.compose env54154 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54154 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54155 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2065,41,2048,1,35,2064,2049,52,0,2049,32,16,2,41,16,2049,2064,2065,2048,20,33,36,33,2049,513]

theorem envBound54155 : H12AffineFastState.Bounded env54155 := by
  intro p hp
  have h : env54155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54154_54155 : H12AffineEnvironment.transform 9 53 env54154 = env54155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54154 == env54155) = true)

theorem identity54155 : scanCanonicalize (H12AffineFastState.compose env54155 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound54155 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54156 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,49,41,32,1,35,48,33,52,0,33,32,16,2,41,16,33,48,49,32,20,33,36,33,33,513]

theorem envBound54156 : H12AffineFastState.Bounded env54156 := by
  intro p hp
  have h : env54156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54155_54156 : H12AffineEnvironment.transform 10 32 env54155 = env54156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env54155 == env54156) = true)

theorem identity54156 : scanCanonicalize (H12AffineFastState.compose env54156 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound54156 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54157 : List Nat := [2,4,8,16,32,16,8,37,49,53,32,49,41,32,1,35,48,33,52,0,33,32,16,2,41,16,33,48,49,32,20,33,36,33,33,48]

theorem envBound54157 : H12AffineFastState.Bounded env54157 := by
  intro p hp
  have h : env54157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54156_54157 : H12AffineEnvironment.transform 8 49 env54156 = env54157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env54156 == env54157) = true)

def env54158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77898,272393,73754,98644,8193,64,121943,79131,17665,357642,75103,392286,257,21792,46092,513]

theorem envBound54158 : H12AffineFastState.Bounded env54158 := by
  intro p hp
  have h : env54158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54145_54158 : H12AffineEnvironment.transform 6 9 env54145 = env54158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54145 == env54158) = true)

def env54159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,77898,33,73754,98644,8193,64,121943,79131,17665,89378,75103,119926,257,21792,46092,513]

theorem envBound54159 : H12AffineFastState.Bounded env54159 := by
  intro p hp
  have h : env54159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54158_54159 : H12AffineEnvironment.transform 17 10280 env54158 = env54159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54158 == env54159) = true)

theorem identity54159 : scanCanonicalize (H12AffineFastState.compose env54159 (packedSelected [2,6,12,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound54159 : packedSelected [2,6,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env54160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,10280,1025,21761,77898,33,73754,87124,8193,64,67927,79131,17665,89378,75103,65910,257,21792,24844,513]

theorem envBound54160 : H12AffineFastState.Bounded env54160 := by
  intro p hp
  have h : env54160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54159_54160 : H12AffineEnvironment.transform 14 21760 env54159 = env54160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env54159 == env54160) = true)

theorem identity54160 : scanCanonicalize (H12AffineFastState.compose env54160 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound54160 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env54161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21591,16400,10280,1025,21761,25629,33,29773,3,8193,64,23808,24908,17665,2421,28936,21793,257,21792,24844,513]

theorem envBound54161 : H12AffineFastState.Bounded env54161 := by
  intro p hp
  have h : env54161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54160_54161 : H12AffineEnvironment.transform 15 21591 env54160 = env54161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env54160 == env54161) = true)

theorem identity54161 : scanCanonicalize (H12AffineFastState.compose env54161 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54161 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21591,16400,2421,1025,21761,17728,33,21776,3,348,64,23808,16401,17665,2421,20565,21793,257,21792,16465,513]

theorem envBound54162 : H12AffineFastState.Bounded env54162 := by
  intro p hp
  have h : env54162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54161_54162 : H12AffineEnvironment.transform 12 349 env54161 = env54162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54161 == env54162) = true)

theorem identity54162 : scanCanonicalize (H12AffineFastState.compose env54162 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound54162 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env54163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,81,262,5441,2421,1025,80,4113,33,65,3,348,64,2129,5440,4176,2421,1284,112,257,113,5376,513]

theorem envBound54163 : H12AffineFastState.Bounded env54163 := by
  intro p hp
  have h : env54163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54162_54163 : H12AffineEnvironment.transform 13 5457 env54162 = env54163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env54162 == env54163) = true)

theorem identity54163 : scanCanonicalize (H12AffineFastState.compose env54163 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54163 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54164 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1025,1,4113,33,16,3,269,17,2048,5393,4097,2340,1284,33,257,32,5376,513]

theorem envBound54164 : H12AffineFastState.Bounded env54164 := by
  intro p hp
  have h : env54164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54163_54164 : H12AffineEnvironment.transform 5 17 env54163 = env54164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54163 == env54164) = true)

theorem identity54164 : scanCanonicalize (H12AffineFastState.compose env54164 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54164 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54165 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5172,2048,1025,1,4113,33,16,3,41,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound54165 : H12AffineFastState.Bounded env54165 := by
  intro p hp
  have h : env54165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54164_54165 : H12AffineEnvironment.transform 7 36 env54164 = env54165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54164 == env54165) = true)

def env54166 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1044,0,34,1028,2048,1025,1,33,33,16,3,41,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound54166 : H12AffineFastState.Bounded env54166 := by
  intro p hp
  have h : env54166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54165_54166 : H12AffineEnvironment.transform 11 48 env54165 = env54166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54165 == env54166) = true)

theorem identity54166 : scanCanonicalize (H12AffineFastState.compose env54166 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound54166 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54167 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,48,40,1044,0,34,1028,1572,1025,1,33,33,16,3,41,17,1572,1029,49,1572,1056,33,37,32,1044,513]

theorem envBound54167 : H12AffineFastState.Bounded env54167 := by
  intro p hp
  have h : env54167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54166_54167 : H12AffineEnvironment.transform 10 1572 env54166 = env54167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env54166 == env54167) = true)

def env54168 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,40,32,0,34,48,528,53,1,33,33,16,3,41,17,528,49,49,528,20,33,37,32,32,513]

theorem envBound54168 : H12AffineFastState.Bounded env54168 := by
  intro p hp
  have h : env54168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54167_54168 : H12AffineEnvironment.transform 9 52 env54167 = env54168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54167 == env54168) = true)

theorem identity54168 : scanCanonicalize (H12AffineFastState.compose env54168 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound54168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54169 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,48,40,32,0,34,48,58,53,1,33,33,16,3,41,17,58,49,49,58,20,33,37,32,32,43]

theorem envBound54169 : H12AffineFastState.Bounded env54169 := by
  intro p hp
  have h : env54169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54168_54169 : H12AffineEnvironment.transform 8 42 env54168 = env54169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env54168 == env54169) = true)

def leafEnv54169 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,48,40,32,0,34,48,58,53,1,33,33,16,3,21,41,1,17,58,49,49,58,20,33,37,32,5,35,32,43,1,33,0]

def active54169 : List Nat := [0,1,2,3,4]

def tree54169 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54169 : H12WitnessSearch.Good tree54169 := H12GlobalWitnessIndex.good

theorem leafIdentity54169 : H12AffineFastState.composeSystem env54169 rootObs = leafEnv54169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54169 rootObs == leafEnv54169) = true)

theorem terminalChecked54169 : H12PackedTerminal.terminalCheckFast leafEnv54169 active54169 tree54169 = true := by decide +kernel

def env54170 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,40,33,0,34,49,529,52,1,33,33,16,3,41,17,529,48,49,529,21,33,37,32,33,513]

theorem envBound54170 : H12AffineFastState.Bounded env54170 := by
  intro p hp
  have h : env54170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54167_54170 : H12AffineEnvironment.transform 9 53 env54167 = env54170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54167 == env54170) = true)

def env54171 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1045,0,34,1029,2048,1025,1,32,33,16,3,41,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound54171 : H12AffineFastState.Bounded env54171 := by
  intro p hp
  have h : env54171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54165_54171 : H12AffineEnvironment.transform 11 49 env54165 = env54171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54165 == env54171) = true)

theorem identity54171 : scanCanonicalize (H12AffineFastState.compose env54171 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound54171 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54172 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,49,40,1045,0,34,1029,528,1025,1,32,33,16,3,41,17,528,1028,48,528,1056,33,37,32,1045,513]

theorem envBound54172 : H12AffineFastState.Bounded env54172 := by
  intro p hp
  have h : env54172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54171_54172 : H12AffineEnvironment.transform 10 528 env54171 = env54172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env54171 == env54172) = true)

def env54173 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,40,33,0,34,49,528,53,1,32,33,16,3,41,17,528,48,48,528,20,33,37,32,33,513]

theorem envBound54173 : H12AffineFastState.Bounded env54173 := by
  intro p hp
  have h : env54173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54172_54173 : H12AffineEnvironment.transform 9 52 env54172 = env54173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54172 == env54173) = true)

theorem identity54173 : scanCanonicalize (H12AffineFastState.compose env54173 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound54173 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54174 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,49,40,33,0,34,49,59,53,1,32,33,16,3,41,17,59,48,48,59,20,33,37,32,33,42]

theorem envBound54174 : H12AffineFastState.Bounded env54174 := by
  intro p hp
  have h : env54174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54173_54174 : H12AffineEnvironment.transform 8 43 env54173 = env54174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env54173 == env54174) = true)

def leafEnv54174 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,49,40,33,0,34,49,59,53,1,32,33,16,3,21,41,1,17,59,48,48,59,20,33,37,32,5,35,33,42,1,32,0]

def active54174 : List Nat := [0,1,2,3,4]

def tree54174 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54174 : H12WitnessSearch.Good tree54174 := H12GlobalWitnessIndex.good

theorem leafIdentity54174 : H12AffineFastState.composeSystem env54174 rootObs = leafEnv54174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54174 rootObs == leafEnv54174) = true)

theorem terminalChecked54174 : H12PackedTerminal.terminalCheckFast leafEnv54174 active54174 tree54174 = true := by decide +kernel

def env54175 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,40,32,0,34,48,528,52,1,32,33,16,3,41,17,528,49,48,528,21,33,37,32,32,513]

theorem envBound54175 : H12AffineFastState.Bounded env54175 := by
  intro p hp
  have h : env54175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54172_54175 : H12AffineEnvironment.transform 9 53 env54172 = env54175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54172 == env54175) = true)

def env54176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,77898,32,73754,98644,8193,64,121943,79131,17665,89379,75103,119927,257,21792,46092,513]

theorem envBound54176 : H12AffineFastState.Bounded env54176 := by
  intro p hp
  have h : env54176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54158_54176 : H12AffineEnvironment.transform 17 10281 env54158 = env54176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env54158 == env54176) = true)

theorem identity54176 : scanCanonicalize (H12AffineFastState.compose env54176 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54176 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1025,32769,4160,32,16,41310,8193,64,64605,5393,17665,32041,1365,62589,257,21792,46092,513]

theorem envBound54177 : H12AffineFastState.Bounded env54177 := by
  intro p hp
  have h : env54177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54176_54177 : H12AffineEnvironment.transform 15 8202 env54176 = env54177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54176 == env54177) = true)

theorem identity54177 : scanCanonicalize (H12AffineFastState.compose env54177 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound54177 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env54178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,32768,3142,38160,1125,1025,32769,4160,32,16,36114,3149,64,53265,5393,17665,20837,1365,55345,257,21792,38976,513]

theorem envBound54178 : H12AffineFastState.Bounded env54178 := by
  intro p hp
  have h : env54178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54177_54178 : H12AffineEnvironment.transform 12 3148 env54177 = env54178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env54177 == env54178) = true)

theorem identity54178 : scanCanonicalize (H12AffineFastState.compose env54178 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound54178 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3148,16384,21760,3142,16400,1125,1025,21761,4160,32,16,22546,3149,64,1297,5393,17665,20837,1365,3377,257,21792,19776,513]

theorem envBound54179 : H12AffineFastState.Bounded env54179 := by
  intro p hp
  have h : env54179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54178_54179 : H12AffineEnvironment.transform 14 21760 env54178 = env54179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env54178 == env54179) = true)

theorem identity54179 : scanCanonicalize (H12AffineFastState.compose env54179 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound54179 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,4096,348,16384,21760,342,16400,1125,1025,21761,4160,32,16,21762,349,64,1297,5393,17665,20837,1365,33,257,21792,16464,513]

theorem envBound54180 : H12AffineFastState.Bounded env54180 := by
  intro p hp
  have h : env54180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54179_54180 : H12AffineEnvironment.transform 10 1296 env54179 = env54180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env54179 == env54180) = true)

theorem identity54180 : scanCanonicalize (H12AffineFastState.compose env54180 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound54180 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,4096,348,5456,80,342,5440,1125,1025,81,4160,32,16,82,349,64,1297,5393,4177,1077,1365,33,257,112,5376,513]

theorem envBound54181 : H12AffineFastState.Bounded env54181 := by
  intro p hp
  have h : env54181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54180_54181 : H12AffineEnvironment.transform 13 5456 env54180 = env54181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env54180 == env54181) = true)

theorem identity54181 : scanCanonicalize (H12AffineFastState.compose env54181 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound54181 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0