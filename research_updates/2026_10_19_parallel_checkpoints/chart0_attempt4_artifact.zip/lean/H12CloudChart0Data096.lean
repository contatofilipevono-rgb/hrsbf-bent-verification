import H12CloudChart0Data095

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env24290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,10400,1025,32769,115870,33,120015,98781,8328,64,75786,115151,17665,109046,119043,73890,257,21793,46212,63188]

theorem envBound24290 : H12AffineFastState.Bounded env24290 := by
  intro p hp
  have h : env24290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24289_24290 : H12AffineEnvironment.transform 17 10400 env24289 = env24290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env24289 == env24290) = true)

theorem identity24290 : scanCanonicalize (H12AffineFastState.compose env24290 (packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound24290 : packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env24291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24909,10400,1025,29909,77898,33,73755,95497,8328,64,75786,79131,17665,89378,75223,73890,257,21793,16464,512]

theorem envBound24291 : H12AffineFastState.Bounded env24291 := by
  intro p hp
  have h : env24291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24290_24291 : H12AffineEnvironment.transform 14 29908 env24290 = env24291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env24290 == env24291) = true)

theorem identity24291 : scanCanonicalize (H12AffineFastState.compose env24291 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 19866) := by decide +kernel

theorem selectedBound24291 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env24292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,19866,24909,10400,1025,29909,32208,33,28033,14483,8328,64,26000,30849,17665,4280,26701,27960,257,21793,16464,512]

theorem envBound24292 : H12AffineFastState.Bounded env24292 := by
  intro p hp
  have h : env24292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24291_24292 : H12AffineEnvironment.transform 15 19866 env24291 = env24292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19866 env24291 == env24292) = true)

theorem identity24292 : scanCanonicalize (H12AffineFastState.compose env24292 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound24292 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24293 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,29908,19558,24753,10400,1025,29909,31788,33,27773,14483,8328,64,25708,30849,17661,4280,26701,27844,253,21725,16464,512]

theorem envBound24293 : H12AffineFastState.Bounded env24293 := by
  intro p hp
  have h : env24293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24292_24293 : H12AffineEnvironment.transform 7 252 env24292 = env24293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24292 == env24293) = true)

theorem identity24293 : scanCanonicalize (H12AffineFastState.compose env24293 (packedSelected [1,2,3,4,6,8,9,11,12,16,18,19,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 3325) := by decide +kernel

theorem selectedBound24293 : packedSelected [1,2,3,4,6,8,9,11,12,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env24294 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,3325,8192,16384,26665,19558,24753,10400,1025,26664,24785,33,27773,9326,8328,64,25708,25724,17661,3141,26701,27844,253,18464,16464,512]

theorem envBound24294 : H12AffineFastState.Bounded env24294 := by
  intro p hp
  have h : env24294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24293_24294 : H12AffineEnvironment.transform 11 3325 env24293 = env24294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3325 env24293 == env24294) = true)

theorem identity24294 : scanCanonicalize (H12AffineFastState.compose env24294 (packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 3269) := by decide +kernel

theorem selectedBound24294 : packedSelected [0,3,4,5,7,9,11,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env24295 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,3325,3269,16384,17644,19558,19572,1125,1025,17645,19476,33,16568,2219,3149,64,18601,18617,17661,3141,17544,16385,253,18464,16464,512]

theorem envBound24295 : H12AffineFastState.Bounded env24295 := by
  intro p hp
  have h : env24295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24294_24295 : H12AffineEnvironment.transform 12 3269 env24294 = env24295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3269 env24294 == env24295) = true)

theorem identity24295 : scanCanonicalize (H12AffineFastState.compose env24295 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,20,23,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24295 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,20,23,26] rootPS < 2^1333 := by decide +kernel

def env24296 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3189,3149,16384,17508,19558,19572,1125,1025,17509,19476,33,16432,2083,3149,64,18465,18481,17525,3141,17408,16385,117,18464,16464,512]

theorem envBound24296 : H12AffineFastState.Bounded env24296 := by
  intro p hp
  have h : env24296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24295_24296 : H12AffineEnvironment.transform 6 8 env24295 = env24296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24295 == env24296) = true)

theorem identity24296 : scanCanonicalize (H12AffineFastState.compose env24296 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound24296 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24297 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2065,2089,16384,16384,18434,18448,1,101,16385,18544,33,16432,2083,2089,64,18465,18481,16401,2081,16484,16385,117,18464,16464,512]

theorem envBound24297 : H12AffineFastState.Bounded env24297 := by
  intro p hp
  have h : env24297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24296_24297 : H12AffineEnvironment.transform 9 100 env24296 = env24297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env24296 == env24297) = true)

theorem identity24297 : scanCanonicalize (H12AffineFastState.compose env24297 (packedSelected [0,1,2,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound24297 : packedSelected [0,1,2,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24298 : List Nat := [2,4,8,16,32,64,8,116,512,100,81,64,120,16384,16384,16467,16449,1,101,16385,16417,33,16432,114,120,64,16496,16480,16401,112,16484,16385,117,16497,16464,512]

theorem envBound24298 : H12AffineFastState.Bounded env24298 := by
  intro p hp
  have h : env24298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24297_24298 : H12AffineEnvironment.transform 10 81 env24297 = env24298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24297 == env24298) = true)

theorem identity24298 : scanCanonicalize (H12AffineFastState.compose env24298 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound24298 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24299 : List Nat := [2,4,8,16,32,48,8,4,512,20,33,48,8,16384,16384,16419,16433,1,21,16385,16417,33,16432,2,8,48,16384,16400,16401,0,16404,16385,5,16385,16416,512]

theorem envBound24299 : H12AffineFastState.Bounded env24299 := by
  intro p hp
  have h : env24299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24298_24299 : H12AffineEnvironment.transform 5 48 env24298 = env24299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24298 == env24299) = true)

theorem identity24299 : scanCanonicalize (H12AffineFastState.compose env24299 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound24299 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env24300 : List Nat := [2,4,8,16,32,48,8,4,512,20,33,48,8,0,0,35,49,1,21,1,33,33,48,2,8,48,0,16,17,0,20,1,5,1,32,512]

theorem envBound24300 : H12AffineFastState.Bounded env24300 := by
  intro p hp
  have h : env24300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24299_24300 : H12AffineEnvironment.transform 13 0 env24299 = env24300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env24299 == env24300) = true)

theorem identity24300 : scanCanonicalize (H12AffineFastState.compose env24300 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound24300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24301 : List Nat := [2,4,8,16,32,48,8,4,48,20,33,48,8,0,0,35,49,1,21,1,33,33,48,2,8,48,0,16,17,0,20,1,5,1,32,48]

theorem envBound24301 : H12AffineFastState.Bounded env24301 := by
  intro p hp
  have h : env24301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24300_24301 : H12AffineEnvironment.transform 8 48 env24300 = env24301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env24300 == env24301) = true)

theorem identity24301 : scanCanonicalize (H12AffineFastState.compose env24301 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24301 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24302 : List Nat := [2,4,8,16,1,17,8,4,17,20,0,17,8,0,0,2,16,1,21,1,0,0,17,2,8,17,0,16,17,0,20,1,5,1,1,17]

theorem envBound24302 : H12AffineFastState.Bounded env24302 := by
  intro p hp
  have h : env24302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24301_24302 : H12AffineEnvironment.transform 4 1 env24301 = env24302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24301 == env24302) = true)

theorem identity24302 : scanCanonicalize (H12AffineFastState.compose env24302 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound24302 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24303 : List Nat := [2,4,7,16,1,17,7,4,17,20,0,17,7,0,0,2,16,1,21,1,0,0,17,2,7,17,0,16,17,0,20,1,5,1,1,17]

theorem envBound24303 : H12AffineFastState.Bounded env24303 := by
  intro p hp
  have h : env24303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24302_24303 : H12AffineEnvironment.transform 2 7 env24302 = env24303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env24302 == env24303) = true)

theorem identity24303 : scanCanonicalize (H12AffineFastState.compose env24303 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24303 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24304 : List Nat := [2,4,7,1,1,0,7,4,0,5,0,0,7,0,0,2,1,1,4,1,0,0,0,2,7,0,0,1,0,0,5,1,5,1,1,0]

theorem envBound24304 : H12AffineFastState.Bounded env24304 := by
  intro p hp
  have h : env24304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24303_24304 : H12AffineEnvironment.transform 3 1 env24303 = env24304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24303 == env24304) = true)

def env24305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,10401,1025,32769,115870,32,120015,98781,8328,64,75786,115151,17665,109047,119043,73891,257,21793,46212,63188]

theorem envBound24305 : H12AffineFastState.Bounded env24305 := by
  intro p hp
  have h : env24305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24289_24305 : H12AffineEnvironment.transform 17 10401 env24289 = env24305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env24289 == env24305) = true)

theorem identity24305 : scanCanonicalize (H12AffineFastState.compose env24305 (packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24305 : packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env24306 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,38124,10401,1025,32769,115870,32,120015,98472,8328,64,75786,114874,17524,108674,118902,73891,116,21588,46212,63188]

theorem envBound24306 : H12AffineFastState.Bounded env24306 := by
  intro p hp
  have h : env24306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24305_24306 : H12AffineEnvironment.transform 7 117 env24305 = env24306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24305 == env24306) = true)

theorem identity24306 : scanCanonicalize (H12AffineFastState.compose env24306 (packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound24306 : packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS < 2^1333 := by decide +kernel

def env24307 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,171,38124,10401,1025,32769,50229,32,54372,32771,8328,64,10401,49169,17524,43049,53469,8200,116,21588,46212,63188]

theorem envBound24307 : H12AffineFastState.Bounded env24307 := by
  intro p hp
  have h : env24307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24306_24307 : H12AffineEnvironment.transform 15 171 env24306 = env24307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env24306 == env24307) = true)

theorem identity24307 : scanCanonicalize (H12AffineFastState.compose env24307 (packedSelected [4,5,9,12,14,15,16,17,18,19,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound24307 : packedSelected [4,5,9,12,14,15,16,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env24308 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,8192,16384,32768,114,37941,10360,1025,32769,50229,32,54372,32771,8273,64,10360,49169,17524,43049,53252,8200,116,21588,46173,62989]

theorem envBound24308 : H12AffineFastState.Bounded env24308 := by
  intro p hp
  have h : env24308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24307_24308 : H12AffineEnvironment.transform 6 89 env24307 = env24308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24307 == env24308) = true)

theorem identity24308 : scanCanonicalize (H12AffineFastState.compose env24308 (packedSelected [2,3,5,6,9,10,11,12,14,15,17,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound24308 : packedSelected [2,3,5,6,9,10,11,12,14,15,17,18,22] rootPS < 2^1333 := by decide +kernel

def env24309 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,8192,16384,8233,114,13340,10360,1025,8232,25628,32,29773,8234,8273,64,10360,24632,17524,2048,28717,8200,116,21588,5236,22052]

theorem envBound24309 : H12AffineFastState.Bounded env24309 := by
  intro p hp
  have h : env24309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24308_24309 : H12AffineEnvironment.transform 14 8233 env24308 = env24309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env24308 == env24309) = true)

theorem identity24309 : scanCanonicalize (H12AffineFastState.compose env24309 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24309 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24310 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,41,16384,0,114,5173,2129,1025,1,17461,32,21604,3,120,64,2129,16401,17524,2048,20484,33,116,21588,5236,22052]

theorem envBound24310 : H12AffineFastState.Bounded env24310 := by
  intro p hp
  have h : env24310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24309_24310 : H12AffineEnvironment.transform 12 41 env24309 = env24310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24309 == env24310) = true)

theorem identity24310 : scanCanonicalize (H12AffineFastState.compose env24310 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound24310 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24311 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,41,5236,0,114,5173,2129,1025,1,4161,32,16,3,120,64,2129,5221,4096,2048,1136,33,116,32,5236,592]

theorem envBound24311 : H12AffineFastState.Bounded env24311 := by
  intro p hp
  have h : env24311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24310_24311 : H12AffineEnvironment.transform 13 5236 env24310 = env24311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env24310 == env24311) = true)

theorem identity24311 : scanCanonicalize (H12AffineFastState.compose env24311 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24311 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24312 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,34,5173,2049,1025,1,4113,32,16,3,40,16,2049,5173,4096,2048,1056,33,36,32,5156,512]

theorem envBound24312 : H12AffineFastState.Bounded env24312 := by
  intro p hp
  have h : env24312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24311_24312 : H12AffineEnvironment.transform 5 16 env24311 = env24312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24311 == env24312) = true)

theorem identity24312 : scanCanonicalize (H12AffineFastState.compose env24312 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24313 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5124,0,2,5141,2049,1025,1,4113,0,16,3,8,16,2049,5141,4096,2048,1024,1,4,0,5124,512]

theorem envBound24313 : H12AffineFastState.Bounded env24313 := by
  intro p hp
  have h : env24313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24312_24313 : H12AffineEnvironment.transform 4 0 env24312 = env24313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24312 == env24313) = true)

def env24314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262472,201797,8328,64,6705549,2265289,184472,2377160,2102684,6451589,257,21792,46213,2175563]

theorem envBound24314 : H12AffineFastState.Bounded env24314 := by
  intro p hp
  have h : env24314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24217_24314 : H12AffineEnvironment.transform 23 201797 env24217 = env24314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201797 env24217 == env24314) = true)

def env24315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6603797,2098513,17664,2377160,2102684,6349853,257,21792,46213,2175563]

theorem envBound24315 : H12AffineFastState.Bounded env24315 := by
  intro p hp
  have h : env24315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24314_24315 : H12AffineEnvironment.transform 16 38296 env24314 = env24315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env24314 == env24315) = true)

def env24316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2157717,2098513,17664,2377160,2102684,2411677,257,21792,46213,2175563]

theorem envBound24316 : H12AffineFastState.Bounded env24316 := by
  intro p hp
  have h : env24316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24315_24316 : H12AffineEnvironment.transform 21 272512 env24315 = env24316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24315 == env24316) = true)

theorem identity24316 : scanCanonicalize (H12AffineFastState.compose env24316 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound24316 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,58517,272512,62661,98781,8328,64,2048,57796,17664,303453,61705,272392,257,21792,46213,120542]

theorem envBound24317 : H12AffineFastState.Bounded env24317 := by
  intro p hp
  have h : env24317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24316_24317 : H12AffineEnvironment.transform 20 58517 env24316 = env24317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env24316 == env24317) = true)

def env24318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,10280,1025,32769,58517,168,62661,98781,8328,64,2048,57796,17664,35189,61705,32,257,21792,46213,120542]

theorem envBound24318 : H12AffineFastState.Bounded env24318 := by
  intro p hp
  have h : env24318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24317_24318 : H12AffineEnvironment.transform 17 10280 env24317 = env24318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24317 == env24318) = true)

theorem identity24318 : scanCanonicalize (H12AffineFastState.compose env24318 (packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound24318 : packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env24319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,38296,10280,1025,32769,58517,168,62661,139,8328,64,2048,57796,17664,35189,61705,32,257,21792,46213,22408]

theorem envBound24319 : H12AffineFastState.Bounded env24319 := by
  intro p hp
  have h : env24319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24318_24319 : H12AffineEnvironment.transform 15 33110 env24318 = env24319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env24318 == env24319) = true)

theorem identity24319 : scanCanonicalize (H12AffineFastState.compose env24319 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound24319 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30082,24908,10280,1025,29909,4161,168,17,139,8328,64,2048,5392,17664,32161,1501,32,257,21792,16465,22408]

theorem envBound24320 : H12AffineFastState.Bounded env24320 := by
  intro p hp
  have h : env24320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24319_24320 : H12AffineEnvironment.transform 14 29908 env24319 = env24320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env24319 == env24320) = true)

theorem identity24320 : scanCanonicalize (H12AffineFastState.compose env24320 (packedSelected [1,4,6,8,9,11,12,15,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13356) := by decide +kernel

theorem selectedBound24320 : packedSelected [1,4,6,8,9,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env24321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,248,430,5472,10280,1025,249,4161,168,17,139,8328,64,2048,5392,12588,2445,1501,32,257,8460,13437,9124]

theorem envBound24321 : H12AffineFastState.Bounded env24321 := by
  intro p hp
  have h : env24321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24320_24321 : H12AffineEnvironment.transform 13 13356 env24320 = env24321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13356 env24320 == env24321) = true)

theorem identity24321 : scanCanonicalize (H12AffineFastState.compose env24321 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24321 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env24322 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,13356,80,262,5472,10280,1025,81,4161,0,17,35,8224,64,2048,5392,12588,2341,1397,32,257,8460,13437,8972]

theorem envBound24322 : H12AffineFastState.Bounded env24322 := by
  intro p hp
  have h : env24322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24321_24322 : H12AffineEnvironment.transform 6 40 env24321 = env24322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24321 == env24322) = true)

theorem identity24322 : scanCanonicalize (H12AffineFastState.compose env24322 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24322 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24323 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,13325,80,262,5441,10249,1025,81,4161,0,17,2,8193,64,2048,5392,12557,2308,1364,1,257,8460,13404,8972]

theorem envBound24323 : H12AffineFastState.Bounded env24323 := by
  intro p hp
  have h : env24323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24322_24323 : H12AffineEnvironment.transform 4 1 env24322 = env24323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24322 == env24323) = true)

theorem identity24323 : scanCanonicalize (H12AffineFastState.compose env24323 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24323 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24324 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,8192,13325,0,262,5393,10249,1025,1,4113,0,17,2,8193,16,2048,5392,12557,2308,1284,1,257,8460,13324,8972]

theorem envBound24324 : H12AffineFastState.Bounded env24324 := by
  intro p hp
  have h : env24324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24323_24324 : H12AffineEnvironment.transform 5 16 env24323 = env24324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24323 == env24324) = true)

def env24325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,10281,1025,32769,58517,169,62661,98781,8328,64,2048,57796,17664,35188,61705,33,257,21792,46213,120542]

theorem envBound24325 : H12AffineFastState.Bounded env24325 := by
  intro p hp
  have h : env24325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24317_24325 : H12AffineEnvironment.transform 17 10281 env24317 = env24325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24317 == env24325) = true)

theorem identity24325 : scanCanonicalize (H12AffineFastState.compose env24325 (packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound24325 : packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env24326 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,16384,32768,65536,37372,10281,101,32769,57585,169,61601,98781,8328,64,2048,57796,16740,35188,61705,33,257,20804,45281,119482]

theorem envBound24326 : H12AffineFastState.Bounded env24326 := by
  intro p hp
  have h : env24326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24325_24326 : H12AffineEnvironment.transform 9 100 env24325 = env24326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env24325 == env24326) = true)

theorem identity24326 : scanCanonicalize (H12AffineFastState.compose env24326 (packedSelected [0,1,4,7,8,10,15,16,20,22,26,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound24326 : packedSelected [0,1,4,7,8,10,15,16,20,22,26,31,38] rootPS < 2^1333 := by decide +kernel

def env24327 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,12573,32768,65536,37372,10281,101,32769,37356,169,33212,98781,8328,64,2048,37081,12409,35188,32788,33,257,8281,45281,107431]

theorem envBound24327 : H12AffineFastState.Bounded env24327 := by
  intro p hp
  have h : env24327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24326_24327 : H12AffineEnvironment.transform 13 12573 env24326 = env24327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env24326 == env24327) = true)

theorem identity24327 : scanCanonicalize (H12AffineFastState.compose env24327 (packedSelected [1,2,3,4,5,6,11,12,15,16,17,22,23,26,28] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound24327 : packedSelected [1,2,3,4,5,6,11,12,15,16,17,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env24328 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,12573,8661,65536,12329,10281,101,8660,12345,169,8297,73736,8328,64,2048,12556,12409,10401,8641,33,257,8281,4404,66162]

theorem envBound24328 : H12AffineFastState.Bounded env24328 := by
  intro p hp
  have h : env24328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24327_24328 : H12AffineEnvironment.transform 14 8661 env24327 = env24328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env24327 == env24328) = true)

theorem identity24328 : scanCanonicalize (H12AffineFastState.compose env24328 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound24328 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env24329 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,12573,8661,8403,12329,10281,101,8660,12345,169,8297,219,8328,64,2048,12556,12409,10401,8641,33,257,8281,4404,8865]

theorem envBound24329 : H12AffineFastState.Bounded env24329 := by
  intro p hp
  have h : env24329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24328_24329 : H12AffineEnvironment.transform 15 8403 env24328 = env24329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env24328 == env24329) = true)

theorem identity24329 : scanCanonicalize (H12AffineFastState.compose env24329 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound24329 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24330 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,4096,8192,12573,8460,8202,12329,10281,101,8461,12345,112,8297,2,8273,64,2048,12556,12409,10360,8472,33,257,8281,4404,8824]

theorem envBound24330 : H12AffineFastState.Bounded env24330 := by
  intro p hp
  have h : env24330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24329_24330 : H12AffineEnvironment.transform 6 89 env24329 = env24330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24329 == env24330) = true)

theorem identity24330 : scanCanonicalize (H12AffineFastState.compose env24330 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24330 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24331 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,4096,269,4112,1,263,4388,2340,101,0,4404,112,356,2,348,64,2048,4097,4468,2421,21,33,257,340,4404,885]

theorem envBound24331 : H12AffineFastState.Bounded env24331 := by
  intro p hp
  have h : env24331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24330_24331 : H12AffineEnvironment.transform 12 269 env24330 = env24331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24330 == env24331) = true)

def env24332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2157716,2098513,17664,2377160,2102684,2411676,257,21792,46213,2175563]

theorem envBound24332 : H12AffineFastState.Bounded env24332 := by
  intro p hp
  have h : env24332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24315_24332 : H12AffineEnvironment.transform 21 272513 env24315 = env24332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24315 == env24332) = true)

theorem identity24332 : scanCanonicalize (H12AffineFastState.compose env24332 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound24332 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24908,262144,1025,29909,2097152,272513,2101328,95497,8328,64,2103360,2098513,17664,2377160,2102684,2373704,257,21792,16465,2175563]

theorem envBound24333 : H12AffineFastState.Bounded env24333 := by
  intro p hp
  have h : env24333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24332_24333 : H12AffineEnvironment.transform 14 29908 env24332 = env24333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env24332 == env24333) = true)

def env24334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13388,262144,1025,8661,2097152,272513,2101328,73737,8328,64,2103360,2098513,4096,2363592,2102684,2373704,257,32,5457,2175563]

theorem envBound24334 : H12AffineFastState.Bounded env24334 := by
  intro p hp
  have h : env24334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24333_24334 : H12AffineEnvironment.transform 13 5376 env24333 = env24334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24333 == env24334) = true)

theorem identity24334 : scanCanonicalize (H12AffineFastState.compose env24334 (packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound24334 : packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env24335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,65536,5528,262144,1025,1,2097152,264533,2101328,66013,348,64,2103360,2098513,4096,2363592,2102684,2365852,257,32,5457,2167711]

theorem envBound24335 : H12AffineFastState.Bounded env24335 := by
  intro p hp
  have h : env24335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24334_24335 : H12AffineEnvironment.transform 12 468 env24334 = env24335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env24334 == env24335) = true)

theorem identity24335 : scanCanonicalize (H12AffineFastState.compose env24335 (packedSelected [0,1,4,7,19,22,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 333922) := by decide +kernel

theorem selectedBound24335 : packedSelected [0,1,4,7,19,22,28,31] rootPS < 2^1333 := by decide +kernel

def env24336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,65536,5528,262144,1025,1,333922,264533,329778,66013,348,64,327714,335155,4096,67754,331262,66046,257,32,5457,265213]

theorem envBound24336 : H12AffineFastState.Bounded env24336 := by
  intro p hp
  have h : env24336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24335_24336 : H12AffineEnvironment.transform 20 333922 env24335 = env24336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 333922 env24335 == env24336) = true)

theorem identity24336 : scanCanonicalize (H12AffineFastState.compose env24336 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound24336 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env24337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,65536,5528,67755,1025,1,4297,66046,153,66013,348,64,2185,5528,4096,67754,1365,66046,257,32,5457,66390]

theorem envBound24337 : H12AffineFastState.Bounded env24337 := by
  intro p hp
  have h : env24337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24336_24337 : H12AffineEnvironment.transform 17 67755 env24336 = env24337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env24336 == env24337) = true)

theorem identity24337 : scanCanonicalize (H12AffineFastState.compose env24337 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound24337 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env24338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,343,5528,2556,1025,1,4297,169,153,138,348,64,2185,5528,4096,2557,1365,169,257,32,5457,513]

theorem envBound24338 : H12AffineFastState.Bounded env24338 := by
  intro p hp
  have h : env24338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24337_24338 : H12AffineEnvironment.transform 15 343 env24337 = env24338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env24337 == env24338) = true)

theorem identity24338 : scanCanonicalize (H12AffineFastState.compose env24338 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24338 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24339 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,262,5528,2477,1025,1,4248,169,153,138,269,17,2185,5528,4096,2476,1284,169,257,32,5376,513]

theorem envBound24339 : H12AffineFastState.Bounded env24339 := by
  intro p hp
  have h : env24339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24338_24339 : H12AffineEnvironment.transform 5 17 env24338 = env24339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24338 == env24339) = true)

theorem identity24339 : scanCanonicalize (H12AffineFastState.compose env24339 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound24339 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env24340 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1725,389,957,0,262,805,2477,1025,1,1573,169,153,138,269,17,2185,805,1725,2476,1284,169,257,32,957,513]

theorem envBound24340 : H12AffineFastState.Bounded env24340 := by
  intro p hp
  have h : env24340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24339_24340 : H12AffineEnvironment.transform 11 1725 env24339 = env24340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env24339 == env24340) = true)

theorem identity24340 : scanCanonicalize (H12AffineFastState.compose env24340 (packedSelected [3,5,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound24340 : packedSelected [3,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env24341 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1280,1725,389,957,0,262,805,1197,1025,1,1573,169,153,138,269,17,1417,805,1725,1196,1284,169,257,32,957,513]

theorem envBound24341 : H12AffineFastState.Bounded env24341 := by
  intro p hp
  have h : env24341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24340_24341 : H12AffineEnvironment.transform 10 1280 env24340 = env24341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env24340 == env24341) = true)

theorem identity24341 : scanCanonicalize (H12AffineFastState.compose env24341 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound24341 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env24342 : List Nat := [2,4,8,16,32,17,128,256,512,37,293,664,389,957,0,262,805,136,36,1,512,169,153,138,269,17,428,805,664,137,289,169,257,32,957,513]

theorem envBound24342 : H12AffineFastState.Bounded env24342 := by
  intro p hp
  have h : env24342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24341_24342 : H12AffineEnvironment.transform 9 37 env24341 = env24342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env24341 == env24342) = true)

theorem identity24342 : scanCanonicalize (H12AffineFastState.compose env24342 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound24342 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env24343 : List Nat := [2,4,8,16,32,17,128,256,429,37,293,309,389,16,0,262,136,136,36,1,429,169,153,138,269,17,428,136,309,137,289,169,257,32,16,428]

theorem envBound24343 : H12AffineFastState.Bounded env24343 := by
  intro p hp
  have h : env24343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24342_24343 : H12AffineEnvironment.transform 8 429 env24342 = env24343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env24342 == env24343) = true)

theorem identity24343 : scanCanonicalize (H12AffineFastState.compose env24343 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound24343 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24344 : List Nat := [2,4,8,16,32,17,128,52,153,37,17,1,177,16,0,50,136,136,36,1,153,169,153,138,57,17,152,136,1,137,21,169,53,32,16,152]

theorem envBound24344 : H12AffineFastState.Bounded env24344 := by
  intro p hp
  have h : env24344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24343_24344 : H12AffineEnvironment.transform 7 52 env24343 = env24344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env24343 == env24344) = true)

theorem identity24344 : scanCanonicalize (H12AffineFastState.compose env24344 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound24344 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24345 : List Nat := [2,4,8,16,32,17,34,52,59,37,17,1,19,16,0,50,42,42,36,1,59,11,59,40,57,17,58,42,1,43,21,11,53,32,16,58]

theorem envBound24345 : H12AffineFastState.Bounded env24345 := by
  intro p hp
  have h : env24345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24344_24345 : H12AffineEnvironment.transform 6 34 env24344 = env24345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env24344 == env24345) = true)

theorem identity24345 : scanCanonicalize (H12AffineFastState.compose env24345 (packedSelected [1,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24345 : packedSelected [1,9] rootPS < 2^1333 := by decide +kernel

def env24346 : List Nat := [2,4,8,0,32,1,34,36,43,37,1,1,3,0,0,34,42,42,36,1,43,11,43,40,41,1,42,42,1,43,5,11,37,32,0,42]

theorem envBound24346 : H12AffineFastState.Bounded env24346 := by
  intro p hp
  have h : env24346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24345_24346 : H12AffineEnvironment.transform 3 0 env24345 = env24346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24345 == env24346) = true)

theorem identity24346 : scanCanonicalize (H12AffineFastState.compose env24346 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound24346 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24347 : List Nat := [2,4,8,0,11,1,9,15,0,14,1,1,3,0,0,9,1,1,15,1,0,11,0,3,2,1,1,1,1,0,5,11,14,11,0,1]

theorem envBound24347 : H12AffineFastState.Bounded env24347 := by
  intro p hp
  have h : env24347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24346_24347 : H12AffineEnvironment.transform 4 11 env24346 = env24347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env24346 == env24347) = true)

theorem identity24347 : scanCanonicalize (H12AffineFastState.compose env24347 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound24347 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24348 : List Nat := [2,4,3,0,0,1,2,4,0,5,1,1,3,0,0,2,1,1,4,1,0,0,0,3,2,1,1,1,1,0,5,0,5,0,0,1]

theorem envBound24348 : H12AffineFastState.Bounded env24348 := by
  intro p hp
  have h : env24348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24347_24348 : H12AffineEnvironment.transform 2 3 env24347 = env24348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env24347 == env24348) = true)

def env24349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,262144,1025,8660,2097152,272513,2101328,73736,8328,64,2103360,2098513,4097,2363593,2102684,2373704,257,33,5456,2175563]

theorem envBound24349 : H12AffineFastState.Bounded env24349 := by
  intro p hp
  have h : env24349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24333_24349 : H12AffineEnvironment.transform 13 5377 env24333 = env24349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24333 == env24349) = true)

theorem identity24349 : scanCanonicalize (H12AffineFastState.compose env24349 (packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound24349 : packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env24350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,262144,1025,8660,276584,272513,272440,73736,8328,64,270376,277817,4097,10401,273908,32,257,33,5456,330275]

theorem envBound24350 : H12AffineFastState.Bounded env24350 := by
  intro p hp
  have h : env24350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24349_24350 : H12AffineEnvironment.transform 20 276584 env24349 = env24350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env24349 == env24350) = true)

theorem identity24350 : scanCanonicalize (H12AffineFastState.compose env24350 (packedSelected [1,4,5,7,8,9,10,16,17,19,20,24,26,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound24350 : packedSelected [1,4,5,7,8,9,10,16,17,19,20,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env24351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,13389,262144,1025,8660,276584,272513,272440,138,8328,64,270376,277817,4097,10401,273908,32,257,33,5456,273057]

theorem envBound24351 : H12AffineFastState.Bounded env24351 := by
  intro p hp
  have h : env24351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24350_24351 : H12AffineEnvironment.transform 15 8322 env24350 = env24351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env24350 == env24351) = true)

theorem identity24351 : scanCanonicalize (H12AffineFastState.compose env24351 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24351 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env24352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,478,5393,262144,1025,136,268596,264669,264548,138,468,64,262516,269413,4097,2557,265384,32,257,33,5456,265213]

theorem envBound24352 : H12AffineFastState.Bounded env24352 := by
  intro p hp
  have h : env24352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24351_24352 : H12AffineEnvironment.transform 12 348 env24351 = env24352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24351 == env24352) = true)

theorem identity24352 : scanCanonicalize (H12AffineFastState.compose env24352 (packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound24352 : packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env24353 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5377,80,263,5393,262144,1025,81,268596,264452,264548,83,269,64,262516,269413,4097,2340,265329,32,257,33,5456,264996]

theorem envBound24353 : H12AffineFastState.Bounded env24353 := by
  intro p hp
  have h : env24353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24352_24353 : H12AffineEnvironment.transform 6 89 env24352 = env24353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24352 == env24353) = true)

theorem identity24353 : scanCanonicalize (H12AffineFastState.compose env24353 (packedSelected [2,3,5,6,10,11,15] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound24353 : packedSelected [2,3,5,6,10,11,15] rootPS < 2^1333 := by decide +kernel

def env24354 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5377,80,263,5393,2341,1025,81,4113,33,65,83,269,64,2129,5440,4097,2340,1364,32,257,33,5456,513]

theorem envBound24354 : H12AffineFastState.Bounded env24354 := by
  intro p hp
  have h : env24354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24353_24354 : H12AffineEnvironment.transform 17 2341 env24353 = env24354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env24353 == env24354) = true)

theorem identity24354 : scanCanonicalize (H12AffineFastState.compose env24354 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24354 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24355 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,263,5393,2341,1025,1,4113,33,17,3,269,16,2049,5392,4097,2340,1284,32,257,33,5376,513]

theorem envBound24355 : H12AffineFastState.Bounded env24355 := by
  intro p hp
  have h : env24355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24354_24355 : H12AffineEnvironment.transform 5 16 env24354 = env24355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24354 == env24355) = true)

theorem identity24355 : scanCanonicalize (H12AffineFastState.compose env24355 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound24355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24356 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1296,268,17,0,263,1,2341,1025,1,1281,33,17,3,269,16,2049,0,1297,2340,1284,32,257,33,16,513]

theorem envBound24356 : H12AffineFastState.Bounded env24356 := by
  intro p hp
  have h : env24356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24355_24356 : H12AffineEnvironment.transform 11 1296 env24355 = env24356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env24355 == env24356) = true)

theorem identity24356 : scanCanonicalize (H12AffineFastState.compose env24356 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound24356 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24357 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,1296,268,17,0,263,1,2341,1025,1,1281,33,17,3,269,16,2049,0,1297,2340,1284,32,257,33,16,0]

theorem envBound24357 : H12AffineFastState.Bounded env24357 := by
  intro p hp
  have h : env24357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24356_24357 : H12AffineEnvironment.transform 8 1 env24356 = env24357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env24356 == env24357) = true)

theorem identity24357 : scanCanonicalize (H12AffineFastState.compose env24357 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound24357 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24358 : List Nat := [2,4,8,16,32,16,9,256,1,1024,16,1296,268,17,0,263,1,309,1025,1,1281,33,17,3,269,16,17,0,1297,308,1284,32,257,33,16,0]

theorem envBound24358 : H12AffineFastState.Bounded env24358 := by
  intro p hp
  have h : env24358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24357_24358 : H12AffineEnvironment.transform 10 16 env24357 = env24358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env24357 == env24358) = true)

theorem identity24358 : scanCanonicalize (H12AffineFastState.compose env24358 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24358 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24359 : List Nat := [2,4,8,16,32,16,9,37,1,1024,16,1077,41,17,0,34,1,16,1025,1,1060,33,17,3,40,16,17,0,1076,17,1057,32,36,33,16,0]

theorem envBound24359 : H12AffineFastState.Bounded env24359 := by
  intro p hp
  have h : env24359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24358_24359 : H12AffineEnvironment.transform 7 37 env24358 = env24359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24358 == env24359) = true)

def env24360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6603796,2098512,17665,2377160,2102684,6349852,257,21792,46213,2175563]

theorem envBound24360 : H12AffineFastState.Bounded env24360 := by
  intro p hp
  have h : env24360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24314_24360 : H12AffineEnvironment.transform 16 38297 env24314 = env24360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env24314 == env24360) = true)

def env24361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2157716,2098512,17665,2377160,2102684,2411676,257,21792,46213,2175563]

theorem envBound24361 : H12AffineFastState.Bounded env24361 := by
  intro p hp
  have h : env24361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24360_24361 : H12AffineEnvironment.transform 21 272512 env24360 = env24361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24360 == env24361) = true)

theorem identity24361 : scanCanonicalize (H12AffineFastState.compose env24361 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound24361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4160,272512,17,98780,8328,64,64724,5392,17665,284040,1500,318684,257,21792,46213,74251]

theorem envBound24362 : H12AffineFastState.Bounded env24362 := by
  intro p hp
  have h : env24362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24361_24362 : H12AffineEnvironment.transform 20 4160 env24361 = env24362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24361 == env24362) = true)

theorem identity24362 : scanCanonicalize (H12AffineFastState.compose env24362 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24362 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env24363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38297,262144,1025,32769,4160,272512,17,41430,8328,64,64724,5392,17665,284040,1500,318684,257,21792,46213,513]

theorem envBound24363 : H12AffineFastState.Bounded env24363 := by
  intro p hp
  have h : env24363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24362_24363 : H12AffineEnvironment.transform 15 8202 env24362 = env24363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24362 == env24363) = true)

def env24364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2157717,2098512,17665,2377160,2102684,2411677,257,21792,46213,2175563]

theorem envBound24364 : H12AffineFastState.Bounded env24364 := by
  intro p hp
  have h : env24364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24360_24364 : H12AffineEnvironment.transform 21 272513 env24360 = env24364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24360 == env24364) = true)

def env24365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272393,2101329,98644,8192,64,2157597,2098512,17665,2377024,2102548,2411541,257,21792,46093,2175563]

theorem envBound24365 : H12AffineFastState.Bounded env24365 := by
  intro p hp
  have h : env24365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24364_24365 : H12AffineEnvironment.transform 6 8 env24364 = env24365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24364 == env24365) = true)

theorem identity24365 : scanCanonicalize (H12AffineFastState.compose env24365 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound24365 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env24366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77898,272393,73755,98644,8192,64,121943,79130,17665,357642,75102,392287,257,21792,46093,513]

theorem envBound24366 : H12AffineFastState.Bounded env24366 := by
  intro p hp
  have h : env24366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24365_24366 : H12AffineEnvironment.transform 20 77898 env24365 = env24366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env24365 == env24366) = true)

def env24367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,77898,33,73755,98644,8192,64,121943,79130,17665,89378,75102,119927,257,21792,46093,513]

theorem envBound24367 : H12AffineFastState.Bounded env24367 := by
  intro p hp
  have h : env24367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24366_24367 : H12AffineEnvironment.transform 17 10280 env24366 = env24367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24366 == env24367) = true)

theorem identity24367 : scanCanonicalize (H12AffineFastState.compose env24367 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24367 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env24368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,38161,2420,1025,32769,69910,33,65863,98644,348,64,121943,70726,17665,89378,66562,119927,257,21792,38225,513]

theorem envBound24368 : H12AffineFastState.Bounded env24368 := by
  intro p hp
  have h : env24368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24367_24368 : H12AffineEnvironment.transform 12 348 env24367 = env24368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24367 == env24368) = true)

theorem identity24368 : scanCanonicalize (H12AffineFastState.compose env24368 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound24368 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,16400,2420,1025,21760,69910,33,65863,87125,348,64,67926,70726,17665,89378,66562,65910,257,21792,16464,513]

theorem envBound24369 : H12AffineFastState.Bounded env24369 := by
  intro p hp
  have h : env24369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24368_24369 : H12AffineEnvironment.transform 14 21761 env24368 = env24369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env24368 == env24369) = true)

theorem identity24369 : scanCanonicalize (H12AffineFastState.compose env24369 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound24369 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24370 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,65536,5393,2420,1025,1,69910,33,65863,65876,348,64,67926,70726,4096,67619,66562,65910,257,33,5457,513]

theorem envBound24370 : H12AffineFastState.Bounded env24370 := by
  intro p hp
  have h : env24370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24369_24370 : H12AffineEnvironment.transform 13 5377 env24369 = env24370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24369 == env24370) = true)

theorem identity24370 : scanCanonicalize (H12AffineFastState.compose env24370 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound24370 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24371 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5393,2420,1025,1,4160,33,17,2,348,64,2048,5392,4096,2421,1364,32,257,33,5457,513]

theorem envBound24371 : H12AffineFastState.Bounded env24371 := by
  intro p hp
  have h : env24371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24370_24371 : H12AffineEnvironment.transform 15 342 env24370 = env24371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env24370 == env24371) = true)

theorem identity24371 : scanCanonicalize (H12AffineFastState.compose env24371 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2414) := by decide +kernel

theorem selectedBound24371 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24372 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2414,348,3183,0,342,3199,2420,1025,1,2350,33,17,2,348,64,2048,3198,2414,2421,1364,32,257,33,3135,513]

theorem envBound24372 : H12AffineFastState.Bounded env24372 := by
  intro p hp
  have h : env24372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24371_24372 : H12AffineEnvironment.transform 11 2414 env24371 = env24372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2414 env24371 == env24372) = true)

theorem identity24372 : scanCanonicalize (H12AffineFastState.compose env24372 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound24372 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24373 : List Nat := [2,4,8,16,32,64,8,256,512,267,2048,2414,348,2404,0,342,2420,2420,266,1,2350,33,17,2,348,64,2048,2421,2414,2421,95,32,257,33,2356,513]

theorem envBound24373 : H12AffineFastState.Bounded env24373 := by
  intro p hp
  have h : env24373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24372_24373 : H12AffineEnvironment.transform 9 267 env24372 = env24373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env24372 == env24373) = true)

theorem identity24373 : scanCanonicalize (H12AffineFastState.compose env24373 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24373 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env24374 : List Nat := [2,4,8,16,1,64,8,256,512,267,2048,2383,348,2373,0,342,2389,2389,266,1,2319,0,17,2,348,64,2048,2388,2383,2388,95,1,257,0,2325,513]

theorem envBound24374 : H12AffineFastState.Bounded env24374 := by
  intro p hp
  have h : env24374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24373_24374 : H12AffineEnvironment.transform 4 1 env24373 = env24374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24373 == env24374) = true)

theorem identity24374 : scanCanonicalize (H12AffineFastState.compose env24374 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24374 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env24375 : List Nat := [2,4,8,16,1,16,8,256,512,267,2048,2335,268,2325,0,262,2309,2309,266,1,2319,0,17,2,268,16,2048,2308,2335,2308,15,1,257,0,2325,513]

theorem envBound24375 : H12AffineFastState.Bounded env24375 := by
  intro p hp
  have h : env24375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24374_24375 : H12AffineEnvironment.transform 5 16 env24374 = env24375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24374 == env24375) = true)

theorem identity24375 : scanCanonicalize (H12AffineFastState.compose env24375 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound24375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24376 : List Nat := [2,4,8,16,1,16,8,14,512,5,2048,2065,2,2075,0,8,2059,2059,4,1,2049,0,17,2,2,16,2048,2058,2065,2058,15,1,15,0,2075,513]

theorem envBound24376 : H12AffineFastState.Bounded env24376 := by
  intro p hp
  have h : env24376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24375_24376 : H12AffineEnvironment.transform 7 14 env24375 = env24376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env24375 == env24376) = true)

theorem identity24376 : scanCanonicalize (H12AffineFastState.compose env24376 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound24376 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24377 : List Nat := [2,4,8,16,1,16,8,14,16,5,2048,2065,2,2075,0,8,2059,2059,4,1,2049,0,17,2,2,16,2048,2058,2065,2058,15,1,15,0,2075,17]

theorem envBound24377 : H12AffineFastState.Bounded env24377 := by
  intro p hp
  have h : env24377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24376_24377 : H12AffineEnvironment.transform 8 16 env24376 = env24377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env24376 == env24377) = true)

theorem identity24377 : scanCanonicalize (H12AffineFastState.compose env24377 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound24377 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24378 : List Nat := [2,4,8,16,1,16,8,14,16,5,26,11,2,1,0,8,17,17,4,1,27,0,17,2,2,16,26,16,11,16,15,1,15,0,1,17]

theorem envBound24378 : H12AffineFastState.Bounded env24378 := by
  intro p hp
  have h : env24378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24377_24378 : H12AffineEnvironment.transform 10 26 env24377 = env24378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env24377 == env24378) = true)

theorem identity24378 : scanCanonicalize (H12AffineFastState.compose env24378 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound24378 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24379 : List Nat := [2,3,8,16,1,16,8,9,16,2,26,11,2,1,0,8,17,17,3,1,27,0,17,2,2,16,26,16,11,16,8,1,8,0,1,17]

theorem envBound24379 : H12AffineFastState.Bounded env24379 := by
  intro p hp
  have h : env24379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24378_24379 : H12AffineEnvironment.transform 1 3 env24378 = env24379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env24378 == env24379) = true)

theorem identity24379 : scanCanonicalize (H12AffineFastState.compose env24379 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24379 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env24380 : List Nat := [2,3,8,11,1,11,8,9,11,2,1,11,2,1,0,8,10,10,3,1,0,0,10,2,2,11,1,11,11,11,8,1,8,0,1,10]

theorem envBound24380 : H12AffineFastState.Bounded env24380 := by
  intro p hp
  have h : env24380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24379_24380 : H12AffineEnvironment.transform 3 11 env24379 = env24380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24379 == env24380) = true)

theorem identity24380 : scanCanonicalize (H12AffineFastState.compose env24380 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound24380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24381 : List Nat := [0,1,8,9,1,9,8,9,9,0,1,9,0,1,0,8,8,8,1,1,0,0,8,0,0,9,1,9,9,9,8,1,8,0,1,8]

theorem envBound24381 : H12AffineFastState.Bounded env24381 := by
  intro p hp
  have h : env24381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24380_24381 : H12AffineEnvironment.transform 0 0 env24380 = env24381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env24380 == env24381) = true)

def env24382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,77898,32,73755,98644,8192,64,121943,79130,17665,89379,75102,119926,257,21792,46093,513]

theorem envBound24382 : H12AffineFastState.Bounded env24382 := by
  intro p hp
  have h : env24382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24366_24382 : H12AffineEnvironment.transform 17 10281 env24366 = env24382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24366 == env24382) = true)

theorem identity24382 : scanCanonicalize (H12AffineFastState.compose env24382 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24382 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10281,1025,32769,4161,32,16,41311,8192,64,64604,5393,17665,32040,1365,62589,257,21792,46093,513]

theorem envBound24383 : H12AffineFastState.Bounded env24383 := by
  intro p hp
  have h : env24383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24382_24383 : H12AffineEnvironment.transform 15 8203 env24382 = env24383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24382 == env24383) = true)

theorem identity24383 : scanCanonicalize (H12AffineFastState.compose env24383 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound24383 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,32768,3143,38161,1125,1025,32769,4161,32,16,36115,3148,64,53264,5393,17665,20836,1365,55345,257,21792,38977,513]

theorem envBound24384 : H12AffineFastState.Bounded env24384 := by
  intro p hp
  have h : env24384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24383_24384 : H12AffineEnvironment.transform 12 3148 env24383 = env24384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env24383 == env24384) = true)

theorem identity24384 : scanCanonicalize (H12AffineFastState.compose env24384 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound24384 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,21761,3143,16400,1125,1025,21760,4161,32,16,22546,3148,64,1297,5393,17665,20836,1365,3376,257,21792,19776,513]

theorem envBound24385 : H12AffineFastState.Bounded env24385 := by
  intro p hp
  have h : env24385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24384_24385 : H12AffineEnvironment.transform 14 21761 env24384 = env24385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env24384 == env24385) = true)

theorem identity24385 : scanCanonicalize (H12AffineFastState.compose env24385 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound24385 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,348,16384,21761,343,16400,1125,1025,21760,4161,32,16,21762,348,64,1297,5393,17665,20836,1365,32,257,21792,16464,513]

theorem envBound24386 : H12AffineFastState.Bounded env24386 := by
  intro p hp
  have h : env24386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24385_24386 : H12AffineEnvironment.transform 10 1296 env24385 = env24386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env24385 == env24386) = true)

theorem identity24386 : scanCanonicalize (H12AffineFastState.compose env24386 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound24386 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24387 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,4096,348,16384,20545,343,16400,293,321,20544,4161,32,16,20546,348,64,81,4177,16449,20836,21,32,257,20576,16464,513]

theorem envBound24387 : H12AffineFastState.Bounded env24387 := by
  intro p hp
  have h : env24387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24386_24387 : H12AffineEnvironment.transform 9 320 env24386 = env24387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env24386 == env24387) = true)

theorem identity24387 : scanCanonicalize (H12AffineFastState.compose env24387 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound24387 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env24388 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,64,348,16384,16385,343,16400,293,321,16384,1,32,16,16386,348,64,81,17,16449,16676,21,32,257,16416,16464,513]

theorem envBound24388 : H12AffineFastState.Bounded env24388 := by
  intro p hp
  have h : env24388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24387_24388 : H12AffineEnvironment.transform 11 64 env24387 = env24388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env24387 == env24388) = true)

theorem identity24388 : scanCanonicalize (H12AffineFastState.compose env24388 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24388 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env24389 : List Nat := [2,4,8,16,32,64,8,36,512,100,80,64,120,16384,16385,115,16400,1,101,16384,1,32,16,16386,120,64,81,17,16449,16384,21,32,37,16416,16464,513]

theorem envBound24389 : H12AffineFastState.Bounded env24389 := by
  intro p hp
  have h : env24389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24388_24389 : H12AffineEnvironment.transform 7 36 env24388 = env24389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24388 == env24389) = true)

theorem identity24389 : scanCanonicalize (H12AffineFastState.compose env24389 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24389 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24390 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,17,41,16384,16385,34,16400,1,52,16384,1,32,16,16386,41,17,0,17,16400,16384,21,32,37,16416,16385,513]

theorem envBound24390 : H12AffineFastState.Bounded env24390 := by
  intro p hp
  have h : env24390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24389_24390 : H12AffineEnvironment.transform 5 17 env24389 = env24390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24389 == env24390) = true)

def env24391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272392,2101329,98645,8193,64,2157596,2098512,17665,2377025,2102549,2411540,257,21792,46092,2175563]

theorem envBound24391 : H12AffineFastState.Bounded env24391 := by
  intro p hp
  have h : env24391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24364_24391 : H12AffineEnvironment.transform 6 9 env24364 = env24391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24364 == env24391) = true)

theorem identity24391 : scanCanonicalize (H12AffineFastState.compose env24391 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound24391 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env24392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1025,21761,2097152,272392,2101329,87125,8193,64,2111772,2098512,17665,2377025,2102549,2365716,257,21792,24844,2175563]

theorem envBound24392 : H12AffineFastState.Bounded env24392 := by
  intro p hp
  have h : env24392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24391_24392 : H12AffineEnvironment.transform 14 21760 env24391 = env24392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env24391 == env24392) = true)

def env24393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1025,21761,4160,272392,17,87125,8193,64,10588,5392,17665,283905,1365,264532,257,21792,24844,74251]

theorem envBound24393 : H12AffineFastState.Bounded env24393 := by
  intro p hp
  have h : env24393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24392_24393 : H12AffineEnvironment.transform 20 4160 env24392 = env24393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env24392 == env24393) = true)

theorem identity24393 : scanCanonicalize (H12AffineFastState.compose env24393 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97406) := by decide +kernel

theorem selectedBound24393 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,97406,1025,21761,4160,87158,17,87125,8193,64,10588,5392,17665,76159,1365,95530,257,21792,24844,74251]

theorem envBound24394 : H12AffineFastState.Bounded env24394 := by
  intro p hp
  have h : env24394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24393_24394 : H12AffineEnvironment.transform 17 97406 env24393 = env24394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97406 env24393 == env24394) = true)

theorem identity24394 : scanCanonicalize (H12AffineFastState.compose env24394 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24394 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,16400,23669,1025,21761,4160,29821,17,29790,8193,64,10588,5392,17665,2420,1365,21793,257,21792,24844,512]

theorem envBound24395 : H12AffineFastState.Bounded env24395 := by
  intro p hp
  have h : env24395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24394_24395 : H12AffineEnvironment.transform 15 8203 env24394 = env24395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24394 == env24395) = true)

theorem identity24395 : scanCanonicalize (H12AffineFastState.compose env24395 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound24395 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,21760,114,16400,23669,1025,21761,4160,21508,17,21543,120,64,2341,5392,17665,2420,1365,21793,257,21792,16757,512]

theorem envBound24396 : H12AffineFastState.Bounded env24396 := by
  intro p hp
  have h : env24396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24395_24396 : H12AffineEnvironment.transform 12 121 env24395 = env24396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env24395 == env24396) = true)

theorem identity24396 : scanCanonicalize (H12AffineFastState.compose env24396 (packedSelected [0,2,4,5,6,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 862) := by decide +kernel

theorem selectedBound24396 : packedSelected [0,2,4,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env24397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,862,4096,121,16384,21760,114,16400,22315,1025,21761,4160,21508,17,21543,120,64,635,5392,17665,554,1365,21793,257,21792,16757,512]

theorem envBound24397 : H12AffineFastState.Bounded env24397 := by
  intro p hp
  have h : env24397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24396_24397 : H12AffineEnvironment.transform 10 862 env24396 = env24397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 862 env24396 == env24397) = true)

theorem identity24397 : scanCanonicalize (H12AffineFastState.compose env24397 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound24397 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env24398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,862,4096,121,5236,372,114,5220,863,1025,373,4160,112,17,83,120,64,635,5392,4469,554,1365,341,257,340,5377,512]

theorem envBound24398 : H12AffineFastState.Bounded env24398 := by
  intro p hp
  have h : env24398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24397_24398 : H12AffineEnvironment.transform 13 5236 env24397 = env24398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env24397 == env24398) = true)

theorem identity24398 : scanCanonicalize (H12AffineFastState.compose env24398 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24398 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env24399 : List Nat := [2,4,8,16,32,17,9,256,512,1024,783,4096,40,5157,293,35,5173,782,1025,292,4113,33,17,2,41,17,554,5392,4388,554,1284,260,257,261,5377,512]

theorem envBound24399 : H12AffineFastState.Bounded env24399 := by
  intro p hp
  have h : env24399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24398_24399 : H12AffineEnvironment.transform 5 17 env24398 = env24399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24398 == env24399) = true)

theorem identity24399 : scanCanonicalize (H12AffineFastState.compose env24399 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound24399 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24400 : List Nat := [2,4,8,16,32,17,9,256,512,1024,783,1313,40,260,293,35,276,782,1025,292,1328,33,17,2,41,17,554,49,1029,554,1284,260,257,261,32,512]

theorem envBound24400 : H12AffineFastState.Bounded env24400 := by
  intro p hp
  have h : env24400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24399_24400 : H12AffineEnvironment.transform 11 1313 env24399 = env24400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env24399 == env24400) = true)

theorem identity24400 : scanCanonicalize (H12AffineFastState.compose env24400 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24400 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24401 : List Nat := [2,4,8,16,32,17,9,5,512,1024,522,1060,40,1,32,35,17,523,1025,33,1077,33,17,2,41,17,554,49,1029,554,1025,1,4,0,32,512]

theorem envBound24401 : H12AffineFastState.Bounded env24401 := by
  intro p hp
  have h : env24401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24400_24401 : H12AffineEnvironment.transform 7 5 env24400 = env24401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24400 == env24401) = true)

theorem identity24401 : scanCanonicalize (H12AffineFastState.compose env24401 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound24401 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24402 : List Nat := [2,4,8,16,32,17,9,5,512,542,522,570,40,1,32,35,17,523,543,33,555,33,17,2,41,17,554,49,539,554,543,1,4,0,32,512]

theorem envBound24402 : H12AffineFastState.Bounded env24402 := by
  intro p hp
  have h : env24402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24401_24402 : H12AffineEnvironment.transform 9 542 env24401 = env24402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env24401 == env24402) = true)

theorem identity24402 : scanCanonicalize (H12AffineFastState.compose env24402 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound24402 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24403 : List Nat := [2,4,8,16,32,17,9,5,40,54,34,18,40,1,32,35,17,35,55,33,3,33,17,2,41,17,2,49,51,2,55,1,4,0,32,40]

theorem envBound24403 : H12AffineFastState.Bounded env24403 := by
  intro p hp
  have h : env24403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24402_24403 : H12AffineEnvironment.transform 8 40 env24402 = env24403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env24402 == env24403) = true)

theorem identity24403 : scanCanonicalize (H12AffineFastState.compose env24403 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound24403 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env24404 : List Nat := [2,4,8,16,3,17,9,5,11,21,1,18,11,1,3,0,17,0,20,2,3,2,17,2,10,17,2,18,16,2,20,1,4,0,3,11]

theorem envBound24404 : H12AffineFastState.Bounded env24404 := by
  intro p hp
  have h : env24404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24403_24404 : H12AffineEnvironment.transform 4 3 env24403 = env24404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env24403 == env24404) = true)

def env24405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1025,21761,4161,272392,16,87125,8193,64,10589,5393,17665,283904,1364,264533,257,21792,24844,74250]

theorem envBound24405 : H12AffineFastState.Bounded env24405 := by
  intro p hp
  have h : env24405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24392_24405 : H12AffineEnvironment.transform 20 4161 env24392 = env24405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24392 == env24405) = true)

theorem identity24405 : scanCanonicalize (H12AffineFastState.compose env24405 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound24405 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21590,16400,262144,1025,21761,4161,272392,16,3,8193,64,10589,5393,17665,283904,1364,264533,257,21792,24844,30300]

theorem envBound24406 : H12AffineFastState.Bounded env24406 := by
  intro p hp
  have h : env24406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24405_24406 : H12AffineEnvironment.transform 15 21590 env24405 = env24406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env24405 == env24406) = true)

theorem identity24406 : scanCanonicalize (H12AffineFastState.compose env24406 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound24406 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env24407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21590,16400,32040,1025,21761,4161,21792,16,3,8193,64,10589,5393,17665,10280,1364,29821,257,21792,24844,30300]

theorem envBound24407 : H12AffineFastState.Bounded env24407 := by
  intro p hp
  have h : env24407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24406_24407 : H12AffineEnvironment.transform 17 32040 env24406 = env24407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env24406 == env24407) = true)

theorem identity24407 : scanCanonicalize (H12AffineFastState.compose env24407 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound24407 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env24408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8312,8494,13672,2128,1025,8313,4161,8280,16,3,8193,64,10589,5393,12409,10280,1364,261,257,8280,5236,804]

theorem envBound24408 : H12AffineFastState.Bounded env24408 := by
  intro p hp
  have h : env24408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24407_24408 : H12AffineEnvironment.transform 13 13688 env24407 = env24408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env24407 == env24408) = true)

theorem identity24408 : scanCanonicalize (H12AffineFastState.compose env24408 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24408 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env24409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5156,292,114,5172,2128,1025,293,4161,260,16,3,349,64,2049,5393,4389,2420,1364,261,257,260,5236,804]

theorem envBound24409 : H12AffineFastState.Bounded env24409 := by
  intro p hp
  have h : env24409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24408_24409 : H12AffineEnvironment.transform 12 348 env24408 = env24409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24408 == env24409) = true)

theorem identity24409 : scanCanonicalize (H12AffineFastState.compose env24409 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound24409 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3409,348,2421,292,114,2405,2128,1025,293,3344,260,16,3,349,64,2049,2112,3188,2420,1364,261,257,260,2341,804]

theorem envBound24410 : H12AffineFastState.Bounded env24410 := by
  intro p hp
  have h : env24410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24409_24410 : H12AffineEnvironment.transform 11 3409 env24409 = env24410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env24409 == env24410) = true)

theorem identity24410 : scanCanonicalize (H12AffineFastState.compose env24410 (packedSelected [0,1,2,3,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24410 : packedSelected [0,1,2,3,9,10] rootPS < 2^1333 := by decide +kernel

def env24411 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3328,269,2340,292,35,2356,2049,1025,293,3344,260,16,3,268,17,2049,2065,3109,2341,1285,261,257,260,2341,804]

theorem envBound24411 : H12AffineFastState.Bounded env24411 := by
  intro p hp
  have h : env24411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24410_24411 : H12AffineEnvironment.transform 5 17 env24410 = env24411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24410 == env24411) = true)

theorem identity24411 : scanCanonicalize (H12AffineFastState.compose env24411 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24411 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env24412 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2356,269,2340,292,35,2356,2049,53,293,2340,260,16,3,268,17,2049,2065,2065,2341,305,261,257,260,2341,804]

theorem envBound24412 : H12AffineFastState.Bounded env24412 := by
  intro p hp
  have h : env24412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24411_24412 : H12AffineEnvironment.transform 9 52 env24411 = env24412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24411 == env24412) = true)

theorem identity24412 : scanCanonicalize (H12AffineFastState.compose env24412 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound24412 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env24413 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,512,269,528,292,35,512,821,53,293,528,260,16,3,268,17,821,805,805,529,305,261,257,260,529,804]

theorem envBound24413 : H12AffineFastState.Bounded env24413 := by
  intro p hp
  have h : env24413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24412_24413 : H12AffineEnvironment.transform 10 820 env24412 = env24413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env24412 == env24413) = true)

theorem identity24413 : scanCanonicalize (H12AffineFastState.compose env24413 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24413 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env24414 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,512,40,528,1,35,512,528,53,0,528,33,16,3,41,17,528,512,512,529,20,32,36,33,529,513]

theorem envBound24414 : H12AffineFastState.Bounded env24414 := by
  intro p hp
  have h : env24414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24413_24414 : H12AffineEnvironment.transform 7 37 env24413 = env24414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24413 == env24414) = true)

theorem identity24414 : scanCanonicalize (H12AffineFastState.compose env24414 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound24414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24415 : List Nat := [2,4,8,16,32,17,9,37,26,52,11,26,40,10,1,35,26,10,53,0,10,33,16,3,41,17,10,26,26,11,20,32,36,33,11,27]

theorem envBound24415 : H12AffineFastState.Bounded env24415 := by
  intro p hp
  have h : env24415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24414_24415 : H12AffineEnvironment.transform 8 26 env24414 = env24415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env24414 == env24415) = true)

def env24416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254784,25265168,145662401,525568,140903597,27337992,25733063]

theorem envBound24416 : H12AffineFastState.Bounded env24416 := by
  intro p hp
  have h : env24416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23707_24416 : H12AffineEnvironment.transform 25 65 env23707 = env24416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env23707 == env24416) = true)

def env24417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356288,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound24417 : H12AffineFastState.Bounded env24417 := by
  intro p hp
  have h : env24417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24416_24417 : H12AffineEnvironment.transform 26 30393344 env24416 = env24417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env24416 == env24417) = true)

def env24418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound24418 : H12AffineFastState.Bounded env24418 := by
  intro p hp
  have h : env24418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24417_24418 : H12AffineEnvironment.transform 18 1024 env24417 = env24418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env24417 == env24418) = true)

theorem identity24418 : scanCanonicalize (H12AffineFastState.compose env24418 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8898728) := by decide +kernel

theorem selectedBound24418 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8898728,8328,65,4196520,10898469,10507601,8830976,412856,15117673,256,2493445,2551200,486255]

theorem envBound24419 : H12AffineFastState.Bounded env24419 := by
  intro p hp
  have h : env24419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24418_24419 : H12AffineEnvironment.transform 23 8898728 env24418 = env24419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8898728 env24418 == env24419) = true)

def env24420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,8388608,8898728,8328,65,4196520,8393985,8785013,8830976,412856,12645453,256,21793,46212,486255]

theorem envBound24420 : H12AffineFastState.Bounded env24420 := by
  intro p hp
  have h : env24420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24419_24420 : H12AffineEnvironment.transform 20 416036 env24419 = env24420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416036 env24419 == env24420) = true)

def env24421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,441760,95496,8328,65,4196520,436385,45525,32160,412856,4606445,256,21793,46212,486255]

theorem envBound24421 : H12AffineFastState.Bounded env24421 := by
  intro p hp
  have h : env24421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24420_24421 : H12AffineEnvironment.transform 22 441760 env24420 = env24421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env24420 == env24421) = true)

def env24422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272512,441760,95496,8328,65,270376,436385,45525,32160,412856,156013,256,21793,46212,486255]

theorem envBound24422 : H12AffineFastState.Bounded env24422 := by
  intro p hp
  have h : env24422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24421_24422 : H12AffineEnvironment.transform 21 272512 env24421 = env24422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24421 == env24422) = true)

theorem identity24422 : scanCanonicalize (H12AffineFastState.compose env24422 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound24422 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,58516,169264,16,95496,8328,65,171416,5393,45525,32160,61704,156013,256,21793,46212,120543]

theorem envBound24423 : H12AffineFastState.Bounded env24423 := by
  intro p hp
  have h : env24423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24422_24423 : H12AffineEnvironment.transform 17 179632 env24422 = env24423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env24422 == env24423) = true)

def env24424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,58396,169264,16,95496,8192,65,171280,5393,45405,32040,61704,156013,256,21793,46092,120407]

theorem envBound24424 : H12AffineFastState.Bounded env24424 := by
  intro p hp
  have h : env24424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24423_24424 : H12AffineEnvironment.transform 6 8 env24423 = env24424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24423 == env24424) = true)

theorem identity24424 : scanCanonicalize (H12AffineFastState.compose env24424 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound24424 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,130174,1024,32769,58396,119926,16,95496,8192,65,121942,5393,45405,32040,61704,73771,256,21793,46092,120407]

theorem envBound24425 : H12AffineFastState.Bounded env24425 := by
  intro p hp
  have h : env24425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24424_24425 : H12AffineEnvironment.transform 16 82246 env24424 = env24425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env24424 == env24425) = true)

theorem identity24425 : scanCanonicalize (H12AffineFastState.compose env24425 (packedSelected [0,2,4,5,6,7,10,11,12,14,16,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24425 : packedSelected [0,2,4,5,6,7,10,11,12,14,16,22,24] rootPS < 2^1333 := by decide +kernel

def env24426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,122147,1024,32769,50497,119926,16,87125,349,65,121942,5393,36864,23669,53333,65910,256,21793,38225,120407]

theorem envBound24426 : H12AffineFastState.Bounded env24426 := by
  intro p hp
  have h : env24426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24425_24426 : H12AffineEnvironment.transform 12 349 env24425 = env24426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24425 == env24426) = true)

def env24427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,58397,169264,16,95496,8193,65,171281,5393,45404,32041,61704,156013,256,21793,46093,120406]

theorem envBound24427 : H12AffineFastState.Bounded env24427 := by
  intro p hp
  have h : env24427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24423_24427 : H12AffineEnvironment.transform 6 9 env24423 = env24427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24423 == env24427) = true)

theorem identity24427 : scanCanonicalize (H12AffineFastState.compose env24427 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound24427 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,89379,1024,32769,58397,95530,16,95496,8193,65,97547,5393,45404,32041,61704,98679,256,21793,46093,120406]

theorem envBound24428 : H12AffineFastState.Bounded env24428 := by
  intro p hp
  have h : env24428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24427_24428 : H12AffineEnvironment.transform 16 122906 env24427 = env24428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env24427 == env24428) = true)

theorem identity24428 : scanCanonicalize (H12AffineFastState.compose env24428 (packedSelected [1,3,5,7,10,12,14,15,19,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound24428 : packedSelected [1,3,5,7,10,12,14,15,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env24429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29822,37988,10589,1024,32769,58397,340,16,374,8193,65,2421,5393,45404,32041,61704,62729,256,21793,46093,41512]

theorem envBound24429 : H12AffineFastState.Bounded env24429 := by
  intro p hp
  have h : env24429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24428_24429 : H12AffineEnvironment.transform 15 29822 env24428 = env24429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env24428 == env24429) = true)

theorem identity24429 : scanCanonicalize (H12AffineFastState.compose env24429 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24429 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env24430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,21591,37988,2420,1024,32769,50228,340,16,374,40,65,2421,5393,37237,23808,53537,54560,256,21793,37924,33281]

theorem envBound24430 : H12AffineFastState.Bounded env24430 := by
  intro p hp
  have h : env24430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24429_24430 : H12AffineEnvironment.transform 12 41 env24429 = env24430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24429 == env24430) = true)

theorem identity24430 : scanCanonicalize (H12AffineFastState.compose env24430 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24430 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,0,21591,5220,2420,1024,1,17460,340,16,374,40,65,2421,5393,4469,23808,20769,21792,256,21793,5156,513]

theorem envBound24431 : H12AffineFastState.Bounded env24431 := by
  intro p hp
  have h : env24431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24430_24431 : H12AffineEnvironment.transform 14 0 env24430 = env24431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24430 == env24431) = true)

theorem identity24431 : scanCanonicalize (H12AffineFastState.compose env24431 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound24431 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24432 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,41,16384,0,20531,4096,2420,100,1,16464,340,16,374,40,65,2421,4469,4469,22884,20769,20804,256,20805,4160,513]

theorem envBound24432 : H12AffineFastState.Bounded env24432 := by
  intro p hp
  have h : env24432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24431_24432 : H12AffineEnvironment.transform 9 100 env24431 = env24432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env24431 == env24432) = true)

theorem identity24432 : scanCanonicalize (H12AffineFastState.compose env24432 (packedSelected [11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound24432 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env24433 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,41,4453,0,342,4096,2420,100,1,4405,340,16,374,40,65,2421,4469,4469,2049,68,33,256,32,4160,513]

theorem envBound24433 : H12AffineFastState.Bounded env24433 := by
  intro p hp
  have h : env24433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24432_24433 : H12AffineEnvironment.transform 13 4453 env24432 = env24433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env24432 == env24433) = true)

theorem identity24433 : scanCanonicalize (H12AffineFastState.compose env24433 (packedSelected [1,2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2916) := by decide +kernel

theorem selectedBound24433 : packedSelected [1,2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env24434 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2916,41,2561,0,342,2916,2420,100,1,2641,340,16,374,40,65,2421,2577,2577,2049,68,33,256,32,2852,513]

theorem envBound24434 : H12AffineFastState.Bounded env24434 := by
  intro p hp
  have h : env24434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24433_24434 : H12AffineEnvironment.transform 11 2916 env24433 = env24434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2916 env24433 == env24434) = true)

theorem identity24434 : scanCanonicalize (H12AffineFastState.compose env24434 (packedSelected [0,1,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound24434 : packedSelected [0,1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env24435 : List Nat := [2,4,8,16,32,64,9,256,512,100,324,544,41,837,0,342,544,48,100,1,789,340,16,374,40,65,49,853,853,325,68,33,256,32,608,513]

theorem envBound24435 : H12AffineFastState.Bounded env24435 := by
  intro p hp
  have h : env24435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24434_24435 : H12AffineEnvironment.transform 10 324 env24434 = env24435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env24434 == env24435) = true)

theorem identity24435 : scanCanonicalize (H12AffineFastState.compose env24435 (packedSelected [0,2,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound24435 : packedSelected [0,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24436 : List Nat := [2,4,8,16,32,64,9,256,0,100,324,32,41,325,0,342,32,48,100,1,277,340,16,374,40,65,49,341,341,325,68,33,256,32,96,1]

theorem envBound24436 : H12AffineFastState.Bounded env24436 := by
  intro p hp
  have h : env24436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24435_24436 : H12AffineEnvironment.transform 8 0 env24435 = env24436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env24435 == env24436) = true)

theorem identity24436 : scanCanonicalize (H12AffineFastState.compose env24436 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24436 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24437 : List Nat := [2,4,8,16,32,64,9,117,0,100,49,32,41,48,0,35,32,48,100,1,96,33,16,3,40,65,49,32,32,48,68,33,117,32,96,1]

theorem envBound24437 : H12AffineFastState.Bounded env24437 := by
  intro p hp
  have h : env24437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24436_24437 : H12AffineEnvironment.transform 7 117 env24436 = env24437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24436 == env24437) = true)

theorem identity24437 : scanCanonicalize (H12AffineFastState.compose env24437 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound24437 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24438 : List Nat := [2,4,8,16,32,33,9,20,0,5,49,32,41,48,0,35,32,48,5,1,1,33,16,3,40,32,49,32,32,48,37,33,20,32,1,1]

theorem envBound24438 : H12AffineFastState.Bounded env24438 := by
  intro p hp
  have h : env24438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24437_24438 : H12AffineEnvironment.transform 5 33 env24437 = env24438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env24437 == env24438) = true)

def env24439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272513,441760,95496,8328,65,270377,436385,45525,32160,412856,156012,256,21793,46212,486255]

theorem envBound24439 : H12AffineFastState.Bounded env24439 := by
  intro p hp
  have h : env24439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24421_24439 : H12AffineEnvironment.transform 21 272513 env24421 = env24439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24421 == env24439) = true)

def env24440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272393,441640,95496,8192,65,270377,436265,45405,32040,412720,156012,256,21793,46092,486255]

theorem envBound24440 : H12AffineFastState.Bounded env24440 := by
  intro p hp
  have h : env24440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24439_24440 : H12AffineEnvironment.transform 6 8 env24439 = env24440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24439 == env24440) = true)

def env24441 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272393,272440,95496,8192,65,270377,277817,45405,32040,317728,62588,256,21793,46092,392831]

theorem envBound24441 : H12AffineFastState.Bounded env24441 := by
  intro p hp
  have h : env24441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24440_24441 : H12AffineEnvironment.transform 16 38160 env24440 = env24441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env24440 == env24441) = true)

theorem identity24441 : scanCanonicalize (H12AffineFastState.compose env24441 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound24441 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24442 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130174,1024,32769,77898,119927,119878,95496,8192,65,121943,115015,45405,32040,75102,62588,256,21793,46092,513]

theorem envBound24442 : H12AffineFastState.Bounded env24442 := by
  intro p hp
  have h : env24442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24441_24442 : H12AffineEnvironment.transform 17 130174 env24441 = env24442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env24441 == env24442) = true)

theorem identity24442 : scanCanonicalize (H12AffineFastState.compose env24442 (packedSelected [1,2,6,10,18,19,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound24442 : packedSelected [1,2,6,10,18,19,23,28] rootPS < 2^1333 := by decide +kernel

def env24443 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,65536,13340,89458,1024,8461,77898,95611,95562,95496,8192,65,97627,90187,4177,32040,75102,21872,256,21793,5376,513]

theorem envBound24443 : H12AffineFastState.Bounded env24443 := by
  intro p hp
  have h : env24443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24442_24443 : H12AffineEnvironment.transform 14 8460 env24442 = env24443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env24442 == env24443) = true)

theorem identity24443 : scanCanonicalize (H12AffineFastState.compose env24443 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound24443 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24444 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,21591,13340,2341,1024,8461,25629,8492,8477,8543,8192,65,10508,13340,4177,32040,28937,21872,256,21793,5376,513]

theorem envBound24444 : H12AffineFastState.Bounded env24444 := by
  intro p hp
  have h : env24444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24443_24444 : H12AffineEnvironment.transform 15 21591 env24443 = env24444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env24443 == env24444) = true)

theorem identity24444 : scanCanonicalize (H12AffineFastState.compose env24444 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24444 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,343,13340,2341,1024,8461,12573,8492,8477,8543,8192,65,10508,13340,4177,10280,9225,112,256,33,5376,513]

theorem envBound24445 : H12AffineFastState.Bounded env24445 := by
  intro p hp
  have h : env24445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24444_24445 : H12AffineEnvironment.transform 13 5376 env24444 = env24445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24444 == env24445) = true)

theorem identity24445 : scanCanonicalize (H12AffineFastState.compose env24445 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24445 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24446 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,262,13340,2341,1024,8461,12573,8492,8477,8462,8192,16,10508,13340,4096,10280,9225,33,256,33,5376,513]

theorem envBound24446 : H12AffineFastState.Bounded env24446 := by
  intro p hp
  have h : env24446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24445_24446 : H12AffineEnvironment.transform 5 17 env24445 = env24446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24445 == env24446) = true)

theorem identity24446 : scanCanonicalize (H12AffineFastState.compose env24446 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 2617) := by decide +kernel

theorem selectedBound24446 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env24447 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,2617,5376,2869,262,7717,2341,1024,2868,6948,2837,2852,2871,2617,16,821,7717,4096,529,3632,33,256,33,5376,513]

theorem envBound24447 : H12AffineFastState.Bounded env24447 := by
  intro p hp
  have h : env24447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24446_24447 : H12AffineEnvironment.transform 12 2617 env24446 = env24447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2617 env24446 == env24447) = true)

theorem identity24447 : scanCanonicalize (H12AffineFastState.compose env24447 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound24447 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env24448 : List Nat := [2,4,8,16,32,17,8,256,512,1024,529,4096,40,5376,292,262,5172,820,1024,293,4405,260,309,294,40,16,821,5172,4096,529,1057,33,256,33,5376,513]

theorem envBound24448 : H12AffineFastState.Bounded env24448 := by
  intro p hp
  have h : env24448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24447_24448 : H12AffineEnvironment.transform 10 529 env24447 = env24448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env24447 == env24448) = true)

theorem identity24448 : scanCanonicalize (H12AffineFastState.compose env24448 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound24448 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24449 : List Nat := [2,4,8,16,32,17,8,256,512,1024,529,820,40,1588,292,262,1792,820,1024,293,513,260,309,294,40,16,821,1792,820,529,1057,33,256,33,1588,513]

theorem envBound24449 : H12AffineFastState.Bounded env24449 := by
  intro p hp
  have h : env24449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24448_24449 : H12AffineEnvironment.transform 11 820 env24448 = env24449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env24448 == env24449) = true)

theorem identity24449 : scanCanonicalize (H12AffineFastState.compose env24449 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound24449 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env24450 : List Nat := [2,4,8,16,32,17,8,53,512,1024,529,513,40,1588,17,51,1589,513,1024,16,513,49,0,19,40,16,512,1589,513,529,1057,33,53,33,1588,513]

theorem envBound24450 : H12AffineFastState.Bounded env24450 := by
  intro p hp
  have h : env24450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24449_24450 : H12AffineEnvironment.transform 7 53 env24449 = env24450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env24449 == env24450) = true)

theorem identity24450 : scanCanonicalize (H12AffineFastState.compose env24450 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24450 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24451 : List Nat := [2,4,8,0,32,1,8,37,512,1024,513,513,40,1572,1,35,1573,513,1024,0,513,33,0,3,40,0,512,1573,513,513,1057,33,37,33,1572,513]

theorem envBound24451 : H12AffineFastState.Bounded env24451 := by
  intro p hp
  have h : env24451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24450_24451 : H12AffineEnvironment.transform 3 0 env24450 = env24451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24450 == env24451) = true)

theorem identity24451 : scanCanonicalize (H12AffineFastState.compose env24451 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound24451 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24452 : List Nat := [2,4,8,0,32,1,8,37,512,549,513,513,40,1,1,35,0,513,549,0,513,33,0,3,40,0,512,0,513,513,516,33,37,33,1,513]

theorem envBound24452 : H12AffineFastState.Bounded env24452 := by
  intro p hp
  have h : env24452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24451_24452 : H12AffineEnvironment.transform 9 549 env24451 = env24452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env24451 == env24452) = true)

def env24453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272393,272441,95496,8192,65,270377,277816,45405,32040,317729,62589,256,21793,46092,392830]

theorem envBound24453 : H12AffineFastState.Bounded env24453 := by
  intro p hp
  have h : env24453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24440_24453 : H12AffineEnvironment.transform 16 38161 env24440 = env24453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env24440 == env24453) = true)

theorem identity24453 : scanCanonicalize (H12AffineFastState.compose env24453 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound24453 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1024,32769,314421,272393,272441,41311,8192,65,270377,277816,45405,32040,317729,62589,256,21793,46092,272937]

theorem envBound24454 : H12AffineFastState.Bounded env24454 := by
  intro p hp
  have h : env24454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24453_24454 : H12AffineEnvironment.transform 15 54359 env24453 = env24454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env24453 == env24454) = true)

theorem identity24454 : scanCanonicalize (H12AffineFastState.compose env24454 (packedSelected [0,3,7,11,12,14,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24454 : packedSelected [0,3,7,11,12,14,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env24455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21591,5393,262144,1024,1,281653,272393,272441,8543,8192,65,270377,277816,12637,32040,284961,29821,256,21793,13324,272937]

theorem envBound24455 : H12AffineFastState.Bounded env24455 := by
  intro p hp
  have h : env24455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24454_24455 : H12AffineEnvironment.transform 14 0 env24454 = env24455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24454 == env24455) = true)

theorem identity24455 : scanCanonicalize (H12AffineFastState.compose env24455 (packedSelected [0,1,3,5,7,8,14,15,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound24455 : packedSelected [0,1,3,5,7,8,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env24456 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8203,5393,262144,1024,1,276585,272393,272441,8543,8192,65,270377,277816,12637,2420,273789,33,256,8573,13324,272937]

theorem envBound24456 : H12AffineFastState.Bounded env24456 := by
  intro p hp
  have h : env24456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24455_24456 : H12AffineEnvironment.transform 13 13404 env24455 = env24456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env24455 == env24456) = true)

theorem identity24456 : scanCanonicalize (H12AffineFastState.compose env24456 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound24456 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env24457 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8203,5393,10361,1024,1,4112,112,64,8543,8192,65,2128,5441,12637,2420,1284,33,256,8573,13324,592]

theorem envBound24457 : H12AffineFastState.Bounded env24457 := by
  intro p hp
  have h : env24457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24456_24457 : H12AffineEnvironment.transform 17 10361 env24456 = env24457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env24456 == env24457) = true)

theorem identity24457 : scanCanonicalize (H12AffineFastState.compose env24457 (packedSelected [2,3,4,5,6,7,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound24457 : packedSelected [2,3,4,5,6,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env24458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,8192,10509,0,8203,2112,10361,1024,1,3393,112,64,8543,8192,65,2128,2064,11276,2420,1284,33,256,8573,10589,592]

theorem envBound24458 : H12AffineFastState.Bounded env24458 := by
  intro p hp
  have h : env24458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24457_24458 : H12AffineEnvironment.transform 11 3409 env24457 = env24458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env24457 == env24458) = true)

theorem identity24458 : scanCanonicalize (H12AffineFastState.compose env24458 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24458 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env24459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,349,2128,0,342,2112,2340,1024,1,3393,112,64,2,349,65,2128,2064,3409,2420,1284,33,256,32,2048,592]

theorem envBound24459 : H12AffineFastState.Bounded env24459 := by
  intro p hp
  have h : env24459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24458_24459 : H12AffineEnvironment.transform 12 349 env24458 = env24459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24458 == env24459) = true)

theorem identity24459 : scanCanonicalize (H12AffineFastState.compose env24459 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound24459 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24460 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1329,96,349,1377,0,342,1393,1045,1024,1,112,112,64,2,349,65,1377,1313,96,1093,1284,33,256,32,1329,592]

theorem envBound24460 : H12AffineFastState.Bounded env24460 := by
  intro p hp
  have h : env24460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24459_24460 : H12AffineEnvironment.transform 10 1329 env24459 = env24460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env24459 == env24460) = true)

def env24461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272392,441641,95496,8193,65,270377,436264,45404,32041,412721,156012,256,21793,46093,486255]

theorem envBound24461 : H12AffineFastState.Bounded env24461 := by
  intro p hp
  have h : env24461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24439_24461 : H12AffineEnvironment.transform 6 9 env24439 = env24461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24439 == env24461) = true)

def env24462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1024,32769,314420,272392,272441,95496,8193,65,270377,277816,45404,32041,317729,62588,256,21793,46093,392831]

theorem envBound24462 : H12AffineFastState.Bounded env24462 := by
  intro p hp
  have h : env24462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24461_24462 : H12AffineEnvironment.transform 16 38160 env24461 = env24462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env24461 == env24462) = true)

theorem identity24462 : scanCanonicalize (H12AffineFastState.compose env24462 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound24462 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,89379,1024,32769,102679,95531,95514,95496,8193,65,97546,90139,45404,32041,99330,62588,256,21793,46093,41820]

theorem envBound24463 : H12AffineFastState.Bounded env24463 := by
  intro p hp
  have h : env24463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24462_24463 : H12AffineEnvironment.transform 17 89379 env24462 = env24463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env24462 == env24463) = true)

theorem identity24463 : scanCanonicalize (H12AffineFastState.compose env24463 (packedSelected [1,3,7,8,10,12,14,15,18,20,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound24463 : packedSelected [1,3,7,8,10,12,14,15,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env24464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,32768,65536,38160,89379,1024,32769,102679,87299,87346,87328,41,65,89378,81971,37236,23809,99330,54356,256,21793,37925,33652]

theorem envBound24464 : H12AffineFastState.Bounded env24464 := by
  intro p hp
  have h : env24464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24463_24464 : H12AffineEnvironment.transform 12 40 env24463 = env24464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env24463 == env24464) = true)

theorem identity24464 : scanCanonicalize (H12AffineFastState.compose env24464 (packedSelected [1,2,3,4,6,8,10,11,12,15,20,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound24464 : packedSelected [1,2,3,4,6,8,10,11,12,15,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env24465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,32768,54359,38160,35188,1024,32769,17728,33108,33125,33143,41,65,35189,37988,37236,23809,20565,54356,256,21793,37925,33652]

theorem envBound24465 : H12AffineFastState.Bounded env24465 := by
  intro p hp
  have h : env24465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24464_24465 : H12AffineEnvironment.transform 15 54359 env24464 = env24465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env24464 == env24465) = true)

theorem identity24465 : scanCanonicalize (H12AffineFastState.compose env24465 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24465 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env24466 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,16384,32768,54359,37941,34897,1024,32769,17509,32881,32832,32850,41,65,34896,37988,36945,23588,20565,54356,37,21508,37925,33361]

theorem envBound24466 : H12AffineFastState.Bounded env24466 := by
  intro p hp
  have h : env24466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24465_24466 : H12AffineEnvironment.transform 7 37 env24465 = env24466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24465 == env24466) = true)

theorem identity24466 : scanCanonicalize (H12AffineFastState.compose env24466 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24466 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env24467 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,16384,0,21591,5173,2129,1024,1,17509,113,64,82,41,65,2128,5220,4177,23588,20565,21588,37,21508,5157,593]

theorem envBound24467 : H12AffineFastState.Bounded env24467 := by
  intro p hp
  have h : env24467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24466_24467 : H12AffineEnvironment.transform 14 0 env24466 = env24467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24466 == env24467) = true)

theorem identity24467 : scanCanonicalize (H12AffineFastState.compose env24467 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound24467 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env24468 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5157,0,114,5173,2129,1024,1,4160,113,64,82,41,65,2128,5220,4177,2049,1136,113,37,33,5157,593]

theorem envBound24468 : H12AffineFastState.Bounded env24468 := by
  intro p hp
  have h : env24468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24467_24468 : H12AffineEnvironment.transform 13 5157 env24467 = env24468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env24467 == env24468) = true)

theorem identity24468 : scanCanonicalize (H12AffineFastState.compose env24468 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24468 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env24469 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,0,35,5173,2048,1024,1,4113,32,17,3,41,16,2049,5173,4096,2049,1057,32,37,33,5157,512]

theorem envBound24469 : H12AffineFastState.Bounded env24469 := by
  intro p hp
  have h : env24469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24468_24469 : H12AffineEnvironment.transform 5 17 env24468 = env24469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24468 == env24469) = true)

theorem identity24469 : scanCanonicalize (H12AffineFastState.compose env24469 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24470 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,8,5125,0,3,5141,2048,1024,1,4113,0,17,3,9,16,2049,5141,4096,2049,1025,0,5,1,5125,512]

theorem envBound24470 : H12AffineFastState.Bounded env24470 := by
  intro p hp
  have h : env24470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24469_24470 : H12AffineEnvironment.transform 4 0 env24469 = env24470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24469 == env24470) = true)

def env24471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1024,32769,314421,272392,272440,95496,8193,65,270377,277817,45404,32041,317728,62589,256,21793,46093,392830]

theorem envBound24471 : H12AffineFastState.Bounded env24471 := by
  intro p hp
  have h : env24471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24461_24471 : H12AffineEnvironment.transform 16 38161 env24461 = env24471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env24461 == env24471) = true)

theorem identity24471 : scanCanonicalize (H12AffineFastState.compose env24471 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound24471 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24472 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,38161,262144,1024,32769,314421,272392,272440,3,8193,65,270377,277817,45404,32041,317728,62589,256,21793,46093,297845]

theorem envBound24472 : H12AffineFastState.Bounded env24472 := by
  intro p hp
  have h : env24472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24471_24472 : H12AffineEnvironment.transform 15 29963 env24471 = env24472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env24471 == env24472) = true)

theorem identity24472 : scanCanonicalize (H12AffineFastState.compose env24472 (packedSelected [3,5,7,10,12,14,15,16,18,19,23,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound24472 : packedSelected [3,5,7,10,12,14,15,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env24473 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,35,38161,262144,1024,32769,309533,272392,272440,3,8193,65,270377,277817,45404,2049,306184,33109,256,8201,46093,297845]

theorem envBound24473 : H12AffineFastState.Bounded env24473 := by
  intro p hp
  have h : env24473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24472_24473 : H12AffineEnvironment.transform 13 13608 env24472 = env24473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env24472 == env24473) = true)

theorem identity24473 : scanCanonicalize (H12AffineFastState.compose env24473 (packedSelected [0,1,5,7,8,9,14,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24473 : packedSelected [0,1,5,7,8,9,14,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24474 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,0,35,5393,262144,1024,1,276765,272392,272440,3,8193,65,270377,277817,12636,2049,273416,341,256,8201,13325,265077]

theorem envBound24474 : H12AffineFastState.Bounded env24474 := by
  intro p hp
  have h : env24474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24473_24474 : H12AffineEnvironment.transform 14 0 env24473 = env24474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24473 == env24474) = true)

theorem identity24474 : scanCanonicalize (H12AffineFastState.compose env24474 (packedSelected [0,1,2,3,6,7,8,10,11,12,15,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound24474 : packedSelected [0,1,2,3,6,7,8,10,11,12,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env24475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,0,35,5393,262144,1024,1,268597,264224,264208,3,41,65,262145,269585,4468,2049,265248,341,256,33,5157,265077]

theorem envBound24475 : H12AffineFastState.Bounded env24475 := by
  intro p hp
  have h : env24475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24474_24475 : H12AffineEnvironment.transform 12 40 env24474 = env24475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env24474 == env24475) = true)

theorem identity24475 : scanCanonicalize (H12AffineFastState.compose env24475 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24475 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24476 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,0,35,5393,262144,1024,1,268597,264224,264208,3,41,16,262145,269585,4389,2049,265248,260,256,33,5157,264996]

theorem envBound24476 : H12AffineFastState.Bounded env24476 := by
  intro p hp
  have h : env24476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24475_24476 : H12AffineEnvironment.transform 5 17 env24475 = env24476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24475 == env24476) = true)

theorem identity24476 : scanCanonicalize (H12AffineFastState.compose env24476 (packedSelected [1,2,8,10,14] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound24476 : packedSelected [1,2,8,10,14] rootPS < 2^1333 := by decide +kernel

def env24477 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,0,35,5393,2048,1024,1,4405,32,16,3,41,16,2049,5393,4389,2049,1056,260,256,33,5157,804]

theorem envBound24477 : H12AffineFastState.Bounded env24477 := by
  intro p hp
  have h : env24477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24476_24477 : H12AffineEnvironment.transform 17 2048 env24476 = env24477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env24476 == env24477) = true)

theorem identity24477 : scanCanonicalize (H12AffineFastState.compose env24477 (packedSelected [0,3,5,6,7,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24477 : packedSelected [0,3,5,6,7,18] rootPS < 2^1333 := by decide +kernel

def env24478 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,35,5173,2048,1024,1,4113,32,16,3,41,16,2049,5173,4097,2049,1056,32,36,33,5157,512]

theorem envBound24478 : H12AffineFastState.Bounded env24478 := by
  intro p hp
  have h : env24478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24477_24478 : H12AffineEnvironment.transform 7 36 env24477 = env24478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24477 == env24478) = true)

theorem identity24478 : scanCanonicalize (H12AffineFastState.compose env24478 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24478 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24479 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5124,0,3,5141,2048,1024,1,4113,0,16,3,9,16,2049,5141,4097,2049,1024,0,4,1,5125,512]

theorem envBound24479 : H12AffineFastState.Bounded env24479 := by
  intro p hp
  have h : env24479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24478_24479 : H12AffineEnvironment.transform 4 0 env24478 = env24479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24478 == env24479) = true)

theorem identity24479 : scanCanonicalize (H12AffineFastState.compose env24479 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound24479 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24480 : List Nat := [2,4,8,16,0,17,9,4,512,1024,522,4096,8,5124,0,3,5141,522,1024,1,4113,0,16,3,9,16,523,5141,4097,523,1024,0,4,1,5125,512]

theorem envBound24480 : H12AffineFastState.Bounded env24480 := by
  intro p hp
  have h : env24480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24479_24480 : H12AffineEnvironment.transform 10 522 env24479 = env24480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env24479 == env24480) = true)

def env24481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,4194304,441761,95497,8328,65,4196520,436384,45524,32161,412856,4606444,256,21793,46212,486255]

theorem envBound24481 : H12AffineFastState.Bounded env24481 := by
  intro p hp
  have h : env24481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24420_24481 : H12AffineEnvironment.transform 22 441761 env24420 = env24481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441761 env24420 == env24481) = true)

def env24482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272512,441761,95497,8328,65,270376,436384,45524,32161,412856,156012,256,21793,46212,486255]

theorem envBound24482 : H12AffineFastState.Bounded env24482 := by
  intro p hp
  have h : env24482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24481_24482 : H12AffineEnvironment.transform 21 272512 env24481 = env24482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24481 == env24482) = true)

theorem identity24482 : scanCanonicalize (H12AffineFastState.compose env24482 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound24482 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,156132,62661,95497,8328,65,158028,57796,45524,32161,1500,156012,256,21793,46212,74251]

theorem envBound24483 : H12AffineFastState.Bounded env24483 := by
  intro p hp
  have h : env24483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24482_24483 : H12AffineEnvironment.transform 17 149860 env24482 = env24483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env24482 == env24483) = true)

theorem identity24483 : scanCanonicalize (H12AffineFastState.compose env24483 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24483 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env24484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4160,156132,62661,21763,8328,65,158028,57796,45524,32161,1500,156012,256,21793,46212,513]

theorem envBound24484 : H12AffineFastState.Bounded env24484 := by
  intro p hp
  have h : env24484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24483_24484 : H12AffineEnvironment.transform 15 8202 env24483 = env24484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24483 == env24484) = true)

theorem identity24484 : scanCanonicalize (H12AffineFastState.compose env24484 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound24484 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env24485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5528,23804,1024,32769,4160,29820,62661,21763,8328,65,31956,57796,45524,32161,1500,29940,256,21793,46212,513]

theorem envBound24485 : H12AffineFastState.Bounded env24485 := by
  intro p hp
  have h : env24485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24484_24485 : H12AffineEnvironment.transform 16 5528 env24484 = env24485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env24484 == env24485) = true)

theorem identity24485 : scanCanonicalize (H12AffineFastState.compose env24485 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound24485 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env24486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,479,5528,23804,1024,32769,4160,21929,54544,21763,349,65,23809,49169,36865,23668,1500,21793,256,21793,38225,513]

theorem envBound24486 : H12AffineFastState.Bounded env24486 := by
  intro p hp
  have h : env24486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24485_24486 : H12AffineEnvironment.transform 12 469 env24485 = env24486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env24485 == env24486) = true)

theorem identity24486 : scanCanonicalize (H12AffineFastState.compose env24486 (packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound24486 : packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env24487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5372,32768,479,5528,2048,1024,32769,4160,341,33260,511,349,65,2557,38125,36865,2184,1500,477,256,477,38225,513]

theorem envBound24487 : H12AffineFastState.Bounded env24487 := by
  intro p hp
  have h : env24487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24486_24487 : H12AffineEnvironment.transform 13 5372 env24486 = env24487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env24486 == env24487) = true)

theorem identity24487 : scanCanonicalize (H12AffineFastState.compose env24487 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound24487 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env24488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5372,372,479,5528,2048,1024,373,4160,341,152,511,349,65,2557,5529,4469,2184,1500,477,256,477,5157,513]

theorem envBound24488 : H12AffineFastState.Bounded env24488 := by
  intro p hp
  have h : env24488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24487_24488 : H12AffineEnvironment.transform 14 372 env24487 = env24488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env24487 == env24488) = true)

theorem identity24488 : scanCanonicalize (H12AffineFastState.compose env24488 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24488 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,372,343,5392,2048,1024,373,4160,341,16,375,349,65,2421,5393,4469,2048,1364,341,256,341,5157,513]

theorem envBound24489 : H12AffineFastState.Bounded env24489 := by
  intro p hp
  have h : env24489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24488_24489 : H12AffineEnvironment.transform 6 8 env24488 = env24489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24488 == env24489) = true)

theorem identity24489 : scanCanonicalize (H12AffineFastState.compose env24489 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24489 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24490 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1,34,5221,2048,1024,0,4160,32,16,2,40,65,2048,5220,4096,2048,1057,32,117,32,5157,513]

theorem envBound24490 : H12AffineFastState.Bounded env24490 := by
  intro p hp
  have h : env24490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24489_24490 : H12AffineEnvironment.transform 7 117 env24489 = env24490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24489 == env24490) = true)

theorem identity24490 : scanCanonicalize (H12AffineFastState.compose env24490 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound24490 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24491 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1134,4096,40,5236,1,34,5221,1134,1024,0,4160,32,16,2,40,65,1134,5220,4096,1134,1057,32,117,32,5157,513]

theorem envBound24491 : H12AffineFastState.Bounded env24491 := by
  intro p hp
  have h : env24491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24490_24491 : H12AffineEnvironment.transform 10 1134 env24490 = env24491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env24490 == env24491) = true)

theorem identity24491 : scanCanonicalize (H12AffineFastState.compose env24491 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound24491 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24492 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1134,1124,40,16,1,34,1,1134,1024,0,1060,32,16,2,40,65,1134,0,1124,1134,1057,32,117,32,65,513]

theorem envBound24492 : H12AffineFastState.Bounded env24492 := by
  intro p hp
  have h : env24492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24491_24492 : H12AffineEnvironment.transform 11 1124 env24491 = env24492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env24491 == env24492) = true)

theorem identity24492 : scanCanonicalize (H12AffineFastState.compose env24492 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound24492 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24493 : List Nat := [2,4,8,16,32,64,8,117,512,111,1,11,40,16,1,34,1,1,111,0,75,32,16,2,40,65,1,0,11,1,78,32,117,32,65,513]

theorem envBound24493 : H12AffineFastState.Bounded env24493 := by
  intro p hp
  have h : env24493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24492_24493 : H12AffineEnvironment.transform 9 111 env24492 = env24493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env24492 == env24493) = true)

theorem identity24493 : scanCanonicalize (H12AffineFastState.compose env24493 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound24493 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24494 : List Nat := [2,4,8,16,10,64,8,95,512,69,1,11,2,16,1,8,1,1,69,0,75,10,16,2,2,65,1,0,11,1,78,10,95,10,65,513]

theorem envBound24494 : H12AffineFastState.Bounded env24494 := by
  intro p hp
  have h : env24494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24493_24494 : H12AffineEnvironment.transform 4 10 env24493 = env24494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env24493 == env24494) = true)

theorem identity24494 : scanCanonicalize (H12AffineFastState.compose env24494 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24494 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env24495 : List Nat := [2,4,8,16,10,17,8,14,512,20,1,11,2,16,1,8,1,1,20,0,26,10,16,2,2,16,1,0,11,1,31,10,14,10,16,513]

theorem envBound24495 : H12AffineFastState.Bounded env24495 := by
  intro p hp
  have h : env24495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24494_24495 : H12AffineEnvironment.transform 5 17 env24494 = env24495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24494 == env24495) = true)

theorem identity24495 : scanCanonicalize (H12AffineFastState.compose env24495 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24496 : List Nat := [2,4,8,11,10,10,8,14,512,15,1,11,2,11,1,8,1,1,15,0,1,10,11,2,2,11,1,0,11,1,4,10,14,10,11,513]

theorem envBound24496 : H12AffineFastState.Bounded env24496 := by
  intro p hp
  have h : env24496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24495_24496 : H12AffineEnvironment.transform 3 11 env24495 = env24496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24495 == env24496) = true)

theorem identity24496 : scanCanonicalize (H12AffineFastState.compose env24496 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound24496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24497 : List Nat := [2,4,6,5,4,4,6,0,512,1,1,5,2,5,1,6,1,1,1,0,1,4,5,2,2,5,1,0,5,1,4,4,0,4,5,513]

theorem envBound24497 : H12AffineFastState.Bounded env24497 := by
  intro p hp
  have h : env24497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24496_24497 : H12AffineEnvironment.transform 2 6 env24496 = env24497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env24496 == env24497) = true)

def env24498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416036,272513,441761,95497,8328,65,270377,436384,45524,32161,412856,156013,256,21793,46212,486255]

theorem envBound24498 : H12AffineFastState.Bounded env24498 := by
  intro p hp
  have h : env24498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24481_24498 : H12AffineEnvironment.transform 21 272513 env24481 = env24498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env24481 == env24498) = true)

theorem identity24498 : scanCanonicalize (H12AffineFastState.compose env24498 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound24498 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,416036,272513,412020,95497,8328,65,270377,416885,17665,32161,412856,156013,256,21793,16465,486255]

theorem envBound24499 : H12AffineFastState.Bounded env24499 := by
  intro p hp
  have h : env24499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24498_24499 : H12AffineEnvironment.transform 14 29909 env24498 = env24499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env24498 == env24499) = true)

def env24500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,160132,33,156116,95497,8328,65,2185,160981,17665,32161,156696,156013,256,21793,16465,213967]

theorem envBound24500 : H12AffineFastState.Bounded env24500 := by
  intro p hp
  have h : env24500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24499_24500 : H12AffineEnvironment.transform 17 10400 env24499 = env24500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env24499 == env24500) = true)

theorem identity24500 : scanCanonicalize (H12AffineFastState.compose env24500 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound24500 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env24501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25029,10400,1024,29908,4161,33,17,95497,8328,65,2185,5392,17665,32161,1501,168,256,21793,16465,74250]

theorem envBound24501 : H12AffineFastState.Bounded env24501 := by
  intro p hp
  have h : env24501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24500_24501 : H12AffineEnvironment.transform 16 25029 env24500 = env24501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env24500 == env24501) = true)

theorem identity24501 : scanCanonicalize (H12AffineFastState.compose env24501 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound24501 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env24502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,65536,16401,2420,1024,21760,4161,33,17,87261,348,65,2185,5392,17665,23669,1501,168,256,21793,16465,66526]

theorem envBound24502 : H12AffineFastState.Bounded env24502 := by
  intro p hp
  have h : env24502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24501_24502 : H12AffineEnvironment.transform 12 468 env24501 = env24502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env24501 == env24502) = true)

def env24503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,160133,32,156117,95497,8328,65,2184,160980,17665,32161,156697,156013,256,21793,16465,213966]

theorem envBound24503 : H12AffineFastState.Bounded env24503 := by
  intro p hp
  have h : env24503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24499_24503 : H12AffineEnvironment.transform 17 10401 env24499 = env24503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env24499 == env24503) = true)

theorem identity24503 : scanCanonicalize (H12AffineFastState.compose env24503 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound24503 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env24504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13625,10401,1024,29908,17596,32,21740,95497,8328,65,2184,16877,17665,32161,20768,21588,256,21793,16465,95991]

theorem envBound24504 : H12AffineFastState.Bounded env24504 := by
  intro p hp
  have h : env24504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24503_24504 : H12AffineEnvironment.transform 16 13625 env24503 = env24504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env24503 == env24504) = true)

theorem identity24504 : scanCanonicalize (H12AffineFastState.compose env24504 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound24504 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env24505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8233,65536,13625,10401,1024,8232,4160,32,16,74229,8328,65,2184,5393,4605,10589,1500,168,256,477,5293,74251]

theorem envBound24505 : H12AffineFastState.Bounded env24505 := by
  intro p hp
  have h : env24505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24504_24505 : H12AffineEnvironment.transform 13 5372 env24504 = env24505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env24504 == env24505) = true)

theorem identity24505 : scanCanonicalize (H12AffineFastState.compose env24505 (packedSelected [0,2,7,14,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound24505 : packedSelected [0,2,7,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24506 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,5372,8233,65536,13541,10401,1024,8232,4160,32,16,73769,8328,65,2184,5325,4129,10369,1024,168,220,1,5293,74251]

theorem envBound24506 : H12AffineFastState.Bounded env24506 := by
  intro p hp
  have h : env24506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24505_24506 : H12AffineEnvironment.transform 7 220 env24505 = env24506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env24505 == env24506) = true)

theorem identity24506 : scanCanonicalize (H12AffineFastState.compose env24506 (packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound24506 : packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env24507 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,5372,8233,34,13541,10401,1024,8232,4160,32,16,8203,8328,65,2184,5325,4129,10369,1024,168,220,1,5293,8745]

theorem envBound24507 : H12AffineFastState.Bounded env24507 := by
  intro p hp
  have h : env24507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24506_24507 : H12AffineEnvironment.transform 15 34 env24506 = env24507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env24506 == env24507) = true)

theorem identity24507 : scanCanonicalize (H12AffineFastState.compose env24507 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24507 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env24508 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,8192,5341,8200,3,13508,10368,1024,8201,4160,1,16,8203,8328,65,2184,5325,4096,10369,1024,137,220,1,5260,8712]

theorem envBound24508 : H12AffineFastState.Bounded env24508 := by
  intro p hp
  have h : env24508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24507_24508 : H12AffineEnvironment.transform 4 1 env24507 = env24508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24507 == env24508) = true)

theorem identity24508 : scanCanonicalize (H12AffineFastState.compose env24508 (packedSelected [2,4,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24508 : packedSelected [2,4,9,12] rootPS < 2^1333 := by decide +kernel

def env24509 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,4096,8192,5204,8200,3,13389,10249,1024,8201,4160,1,16,8203,8193,65,2049,5188,4096,10248,1024,0,85,1,5125,8712]

theorem envBound24509 : H12AffineFastState.Bounded env24509 := by
  intro p hp
  have h : env24509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24508_24509 : H12AffineEnvironment.transform 6 9 env24508 = env24509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24508 == env24509) = true)

theorem identity24509 : scanCanonicalize (H12AffineFastState.compose env24509 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound24509 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24510 : List Nat := [2,4,8,16,1,64,9,85,512,1024,2048,4096,8,5204,0,3,5189,2049,1024,1,4160,1,16,3,9,65,2049,5188,4096,2048,1024,0,85,1,5125,512]

theorem envBound24510 : H12AffineFastState.Bounded env24510 := by
  intro p hp
  have h : env24510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24509_24510 : H12AffineEnvironment.transform 12 8 env24509 = env24510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env24509 == env24510) = true)

theorem identity24510 : scanCanonicalize (H12AffineFastState.compose env24510 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound24510 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24511 : List Nat := [2,4,8,16,1,64,9,85,512,1024,522,4096,8,5204,0,3,5189,523,1024,1,4160,1,16,3,9,65,523,5188,4096,522,1024,0,85,1,5125,512]

theorem envBound24511 : H12AffineFastState.Bounded env24511 := by
  intro p hp
  have h : env24511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24510_24511 : H12AffineEnvironment.transform 10 522 env24510 = env24511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env24510 == env24511) = true)

theorem identity24511 : scanCanonicalize (H12AffineFastState.compose env24511 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24511 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24512 : List Nat := [2,4,8,16,1,17,9,4,512,1024,522,4096,8,5125,0,3,5140,523,1024,1,4113,1,16,3,9,16,523,5141,4096,522,1024,0,4,1,5125,512]

theorem envBound24512 : H12AffineFastState.Bounded env24512 := by
  intro p hp
  have h : env24512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24511_24512 : H12AffineEnvironment.transform 5 17 env24511 = env24512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24511 == env24512) = true)

theorem identity24512 : scanCanonicalize (H12AffineFastState.compose env24512 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24513 : List Nat := [2,4,8,16,1,17,9,4,512,20,522,4096,8,4113,0,3,4096,523,20,1,4113,1,16,3,9,16,523,4097,4096,522,20,0,4,1,4113,512]

theorem envBound24513 : H12AffineFastState.Bounded env24513 := by
  intro p hp
  have h : env24513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24512_24513 : H12AffineEnvironment.transform 9 20 env24512 = env24513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24512 == env24513) = true)

theorem identity24513 : scanCanonicalize (H12AffineFastState.compose env24513 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 31) := by decide +kernel

theorem selectedBound24513 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24514 : List Nat := [2,4,8,16,1,17,9,4,512,20,522,31,8,14,0,3,31,523,20,1,14,1,16,3,9,16,523,30,31,522,20,0,4,1,14,512]

theorem envBound24514 : H12AffineFastState.Bounded env24514 := by
  intro p hp
  have h : env24514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24513_24514 : H12AffineEnvironment.transform 11 31 env24513 = env24514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 31 env24513 == env24514) = true)

theorem identity24514 : scanCanonicalize (H12AffineFastState.compose env24514 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound24514 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24515 : List Nat := [0,4,8,16,1,17,9,4,512,20,520,29,8,12,0,1,29,521,20,1,12,1,16,1,9,16,521,28,29,520,20,0,4,1,12,512]

theorem envBound24515 : H12AffineFastState.Bounded env24515 := by
  intro p hp
  have h : env24515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24514_24515 : H12AffineEnvironment.transform 0 0 env24514 = env24515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env24514 == env24515) = true)

theorem identity24515 : scanCanonicalize (H12AffineFastState.compose env24515 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound24515 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24516 : List Nat := [0,4,4,16,1,17,5,4,512,20,516,17,4,0,0,1,17,517,20,1,0,1,16,1,5,16,517,16,17,516,20,0,4,1,0,512]

theorem envBound24516 : H12AffineFastState.Bounded env24516 := by
  intro p hp
  have h : env24516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24515_24516 : H12AffineEnvironment.transform 2 4 env24515 = env24516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env24515 == env24516) = true)

theorem identity24516 : scanCanonicalize (H12AffineFastState.compose env24516 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound24516 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24517 : List Nat := [0,4,4,16,1,17,5,4,4,20,0,17,4,0,0,1,17,1,20,1,0,1,16,1,5,16,1,16,17,0,20,0,4,1,0,4]

theorem envBound24517 : H12AffineFastState.Bounded env24517 := by
  intro p hp
  have h : env24517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24516_24517 : H12AffineEnvironment.transform 8 4 env24516 = env24517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env24516 == env24517) = true)

def env24518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,8388608,8898728,8328,65,4196520,8393984,8785012,8830976,412856,12645452,256,21792,46213,486255]

theorem envBound24518 : H12AffineFastState.Bounded env24518 := by
  intro p hp
  have h : env24518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24419_24518 : H12AffineEnvironment.transform 20 416037 env24419 = env24518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 416037 env24419 == env24518) = true)

def env24519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,4194304,441760,95496,8328,65,4196520,436384,45524,32160,412856,4606444,256,21792,46213,486255]

theorem envBound24519 : H12AffineFastState.Bounded env24519 := by
  intro p hp
  have h : env24519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24518_24519 : H12AffineEnvironment.transform 22 441760 env24518 = env24519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env24518 == env24519) = true)

def env24520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,416037,272512,441760,95496,8328,65,270376,436384,45524,32160,412856,156012,256,21792,46213,486255]

theorem envBound24520 : H12AffineFastState.Bounded env24520 := by
  intro p hp
  have h : env24520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24519_24520 : H12AffineEnvironment.transform 21 272512 env24519 = env24520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env24519 == env24520) = true)

theorem identity24520 : scanCanonicalize (H12AffineFastState.compose env24520 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24520 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272512,441760,21762,8328,65,270376,436384,45524,32160,412856,156012,256,21792,46213,412517]

theorem envBound24521 : H12AffineFastState.Bounded env24521 := by
  intro p hp
  have h : env24521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24520_24521 : H12AffineEnvironment.transform 15 8202 env24520 = env24521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24520 == env24521) = true)

def env24522 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272392,441640,21762,8192,65,270376,436264,45404,32040,412720,156012,256,21792,46093,412517]

theorem envBound24522 : H12AffineFastState.Bounded env24522 := by
  intro p hp
  have h : env24522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24521_24522 : H12AffineEnvironment.transform 6 8 env24521 = env24522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24521 == env24522) = true)

theorem identity24522 : scanCanonicalize (H12AffineFastState.compose env24522 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound24522 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env24523 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,157753,1024,32769,12572,147505,54545,21762,8192,65,149521,49169,45404,32040,9225,156012,256,21792,46093,9052]

theorem envBound24523 : H12AffineFastState.Bounded env24523 := by
  intro p hp
  have h : env24523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24522_24523 : H12AffineEnvironment.transform 17 157753 env24522 = env24523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env24522 == env24523) = true)

theorem identity24523 : scanCanonicalize (H12AffineFastState.compose env24523 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound24523 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env24524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46157,56436,1024,32769,12572,62588,54545,21762,8192,65,64604,49169,45404,32040,9225,54561,256,21792,46093,9052]

theorem envBound24524 : H12AffineFastState.Bounded env24524 := by
  intro p hp
  have h : env24524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24523_24524 : H12AffineEnvironment.transform 16 46157 env24523 = env24524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env24523 == env24524) = true)

theorem identity24524 : scanCanonicalize (H12AffineFastState.compose env24524 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24524 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env24525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,13388,23669,1024,0,12572,29821,21776,21762,8192,65,31837,16400,12637,32040,9225,21792,256,21792,13324,9052]

theorem envBound24525 : H12AffineFastState.Bounded env24525 := by
  intro p hp
  have h : env24525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24524_24525 : H12AffineEnvironment.transform 14 1 env24524 = env24525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24524 == env24525) = true)

theorem identity24525 : scanCanonicalize (H12AffineFastState.compose env24525 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound24525 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env24526 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,1,34,5220,23669,1024,0,4404,21589,21776,21762,40,65,23669,16400,4469,23808,1057,21792,256,21792,5156,884]

theorem envBound24526 : H12AffineFastState.Bounded env24526 := by
  intro p hp
  have h : env24526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24525_24526 : H12AffineEnvironment.transform 12 40 env24525 = env24526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env24525 == env24526) = true)

theorem identity24526 : scanCanonicalize (H12AffineFastState.compose env24526 (packedSelected [2,3,5,10,11,12,14,15,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24526 : packedSelected [2,3,5,10,11,12,14,15,17,23] rootPS < 2^1333 := by decide +kernel

def env24527 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,1,34,5220,2421,1024,0,4404,341,16,2,40,65,2421,5392,4469,2048,1057,32,256,32,5156,884]

theorem envBound24527 : H12AffineFastState.Bounded env24527 := by
  intro p hp
  have h : env24527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24526_24527 : H12AffineEnvironment.transform 13 5376 env24526 = env24527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24526 == env24527) = true)

theorem identity24527 : scanCanonicalize (H12AffineFastState.compose env24527 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound24527 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env24528 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2059,40,3339,1,34,3183,2421,1024,0,2367,341,16,2,40,65,2421,3355,2430,2048,1057,32,256,32,3119,884]

theorem envBound24528 : H12AffineFastState.Bounded env24528 := by
  intro p hp
  have h : env24528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24527_24528 : H12AffineEnvironment.transform 11 2059 env24527 = env24528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env24527 == env24528) = true)

theorem identity24528 : scanCanonicalize (H12AffineFastState.compose env24528 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24528 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,10,40,1290,1,34,1134,372,1024,0,318,341,16,2,40,65,372,1306,383,1,1057,32,256,32,1070,884]

theorem envBound24529 : H12AffineFastState.Bounded env24529 := by
  intro p hp
  have h : env24529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24528_24529 : H12AffineEnvironment.transform 10 1 env24528 = env24529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24528 == env24529) = true)

theorem identity24529 : scanCanonicalize (H12AffineFastState.compose env24529 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound24529 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env24530 : List Nat := [2,4,8,16,32,64,8,256,512,69,1,10,40,335,1,34,43,372,69,0,318,341,16,2,40,65,372,351,383,1,100,32,256,32,107,884]

theorem envBound24530 : H12AffineFastState.Bounded env24530 := by
  intro p hp
  have h : env24530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24529_24530 : H12AffineEnvironment.transform 9 69 env24529 = env24530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env24529 == env24530) = true)

theorem identity24530 : scanCanonicalize (H12AffineFastState.compose env24530 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound24530 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24531 : List Nat := [2,4,8,16,32,64,8,95,512,69,1,10,40,16,1,34,43,43,69,0,97,10,16,2,40,65,43,0,32,1,100,32,95,32,107,555]

theorem envBound24531 : H12AffineFastState.Bounded env24531 := by
  intro p hp
  have h : env24531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24530_24531 : H12AffineEnvironment.transform 7 95 env24530 = env24531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env24530 == env24531) = true)

theorem identity24531 : scanCanonicalize (H12AffineFastState.compose env24531 (packedSelected [2,6,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound24531 : packedSelected [2,6,10] rootPS < 2^1333 := by decide +kernel

def env24532 : List Nat := [2,4,8,16,10,64,8,95,512,69,1,10,2,16,1,8,1,1,69,0,75,10,16,2,2,65,1,0,10,1,78,10,95,10,65,513]

theorem envBound24532 : H12AffineFastState.Bounded env24532 := by
  intro p hp
  have h : env24532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24531_24532 : H12AffineEnvironment.transform 4 10 env24531 = env24532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env24531 == env24532) = true)

theorem identity24532 : scanCanonicalize (H12AffineFastState.compose env24532 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24532 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env24533 : List Nat := [2,4,8,16,10,17,8,14,512,20,1,10,2,16,1,8,1,1,20,0,26,10,16,2,2,16,1,0,10,1,31,10,14,10,16,513]

theorem envBound24533 : H12AffineFastState.Bounded env24533 := by
  intro p hp
  have h : env24533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24532_24533 : H12AffineEnvironment.transform 5 17 env24532 = env24533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24532 == env24533) = true)

theorem identity24533 : scanCanonicalize (H12AffineFastState.compose env24533 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24533 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24534 : List Nat := [2,4,8,10,10,11,8,14,512,14,1,10,2,10,1,8,1,1,14,0,0,10,10,2,2,10,1,0,10,1,5,10,14,10,10,513]

theorem envBound24534 : H12AffineFastState.Bounded env24534 := by
  intro p hp
  have h : env24534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24533_24534 : H12AffineEnvironment.transform 3 10 env24533 = env24534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24533 == env24534) = true)

theorem identity24534 : scanCanonicalize (H12AffineFastState.compose env24534 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound24534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24535 : List Nat := [2,4,7,5,5,4,7,1,512,1,1,5,2,5,1,7,1,1,1,0,0,5,5,2,2,5,1,0,5,1,5,5,1,5,5,513]

theorem envBound24535 : H12AffineFastState.Bounded env24535 := by
  intro p hp
  have h : env24535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24534_24535 : H12AffineEnvironment.transform 2 7 env24534 = env24535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env24534 == env24535) = true)

def env24536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,416037,272393,441641,21762,8193,65,270376,436265,45405,32041,412721,156012,256,21792,46092,412517]

theorem envBound24536 : H12AffineFastState.Bounded env24536 := by
  intro p hp
  have h : env24536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24521_24536 : H12AffineEnvironment.transform 6 9 env24521 = env24536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24521 == env24536) = true)

theorem identity24536 : scanCanonicalize (H12AffineFastState.compose env24536 (packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 16740) := by decide +kernel

theorem selectedBound24536 : packedSelected [1,7,8,14,15,17,19,20,27,41] rootPS < 2^1333 := by decide +kernel

def env24537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16740,262144,1024,32769,268353,272393,326733,21762,8193,65,270376,321869,45405,32041,265557,8200,256,21792,46092,264705]

theorem envBound24537 : H12AffineFastState.Bounded env24537 := by
  intro p hp
  have h : env24537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24536_24537 : H12AffineEnvironment.transform 16 16740 env24536 = env24537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16740 env24536 == env24537) = true)

theorem identity24537 : scanCanonicalize (H12AffineFastState.compose env24537 (packedSelected [2,3,4,9,10,11,16,18,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 43356) := by decide +kernel

theorem selectedBound24537 : packedSelected [2,3,4,9,10,11,16,18,24,26] rootPS < 2^1333 := by decide +kernel

def env24538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16740,43356,1024,32769,45341,33109,21777,21762,8193,65,35188,16401,45405,32041,41993,8200,256,21792,46092,41821]

theorem envBound24538 : H12AffineFastState.Bounded env24538 := by
  intro p hp
  have h : env24538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24537_24538 : H12AffineEnvironment.transform 17 43356 env24537 = env24538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43356 env24537 == env24538) = true)

theorem identity24538 : scanCanonicalize (H12AffineFastState.compose env24538 (packedSelected [6,9,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24538 : packedSelected [6,9,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,32768,35,16740,35189,1024,32769,37172,33109,21777,21762,40,65,35188,16401,37236,23808,33824,33,256,21792,37925,33652]

theorem envBound24539 : H12AffineFastState.Bounded env24539 := by
  intro p hp
  have h : env24539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24538_24539 : H12AffineEnvironment.transform 12 41 env24538 = env24539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24538 == env24539) = true)

theorem identity24539 : scanCanonicalize (H12AffineFastState.compose env24539 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound24539 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env24540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,32768,35,5392,35189,1024,32769,37172,33109,357,374,40,65,35188,5221,37236,2420,33824,33,256,340,37925,33652]

theorem envBound24540 : H12AffineFastState.Bounded env24540 := by
  intro p hp
  have h : env24540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24539_24540 : H12AffineEnvironment.transform 13 5236 env24539 = env24540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env24539 == env24540) = true)

theorem identity24540 : scanCanonicalize (H12AffineFastState.compose env24540 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24540 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env24541 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5236,32768,35,5220,34817,1024,32769,36928,32801,17,2,40,65,34816,5221,36864,2048,33824,33,116,32,37925,33280]

theorem envBound24541 : H12AffineFastState.Bounded env24541 := by
  intro p hp
  have h : env24541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24540_24541 : H12AffineEnvironment.transform 7 116 env24540 = env24541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24540 == env24541) = true)

theorem identity24541 : scanCanonicalize (H12AffineFastState.compose env24541 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound24541 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24542 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3109,41,2129,32768,35,2113,34817,1024,32769,35941,32801,17,2,40,65,34816,2112,35877,2048,33824,33,116,32,34816,33280]

theorem envBound24542 : H12AffineFastState.Bounded env24542 := by
  intro p hp
  have h : env24542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24541_24542 : H12AffineEnvironment.transform 11 3109 env24541 = env24542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env24541 == env24542) = true)

theorem identity24542 : scanCanonicalize (H12AffineFastState.compose env24542 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24542 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env24543 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,2065,41,2129,32768,35,2113,34817,52,32769,34897,32801,17,2,40,65,34816,2112,34833,2048,32788,33,116,32,34816,33280]

theorem envBound24543 : H12AffineFastState.Bounded env24543 := by
  intro p hp
  have h : env24543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24542_24543 : H12AffineEnvironment.transform 9 52 env24542 = env24543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24542 == env24543) = true)

theorem identity24543 : scanCanonicalize (H12AffineFastState.compose env24543 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound24543 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env24544 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,2065,41,2129,81,35,2113,2128,52,80,2048,112,17,2,40,65,2129,2112,2112,2048,69,33,116,32,2129,593]

theorem envBound24544 : H12AffineFastState.Bounded env24544 := by
  intro p hp
  have h : env24544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24543_24544 : H12AffineEnvironment.transform 14 81 env24543 = env24544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env24543 == env24544) = true)

theorem identity24544 : scanCanonicalize (H12AffineFastState.compose env24544 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24544 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24545 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2065,41,2049,1,35,2065,2048,52,0,2048,32,17,2,40,17,2049,2064,2064,2048,21,33,36,32,2049,513]

theorem envBound24545 : H12AffineFastState.Bounded env24545 := by
  intro p hp
  have h : env24545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24544_24545 : H12AffineEnvironment.transform 5 16 env24544 = env24545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24544 == env24545) = true)

theorem identity24545 : scanCanonicalize (H12AffineFastState.compose env24545 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24546 : List Nat := [2,4,8,11,32,11,9,36,512,47,2048,2058,41,2049,1,35,2058,2048,47,0,2048,32,10,2,40,10,2049,2059,2059,2048,14,33,36,32,2049,513]

theorem envBound24546 : H12AffineFastState.Bounded env24546 := by
  intro p hp
  have h : env24546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24545_24546 : H12AffineEnvironment.transform 3 11 env24545 = env24546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24545 == env24546) = true)

theorem identity24546 : scanCanonicalize (H12AffineFastState.compose env24546 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound24546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24547 : List Nat := [2,4,2,1,32,1,3,36,512,37,2048,2048,35,2049,1,35,2048,2048,37,0,2048,32,0,2,34,0,2049,2049,2049,2048,4,33,36,32,2049,513]

end H12CloudChart0