import H12CloudChart0Data027

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound6939 : H12AffineFastState.Bounded env6939 := by
  intro p hp
  have h : env6939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6938_6939 : H12AffineEnvironment.transform 17 2048 env6938 = env6939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env6938 == env6939) = true)

theorem identity6939 : scanCanonicalize (H12AffineFastState.compose env6939 (packedSelected [1,2,3,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound6939 : packedSelected [1,2,3,11,14,18] rootPS < 2^1333 := by decide +kernel

def env6940 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,8202,131072,2048,20596,8233,159865,33,21604,3,8192,21556,2048,139304,12328,2048,1056,32,21505,33,13325,513]

theorem envBound6940 : H12AffineFastState.Bounded env6940 := by
  intro p hp
  have h : env6940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6939_6940 : H12AffineEnvironment.transform 15 8202 env6939 = env6940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env6939 == env6940) = true)

def env6941 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,65536,131072,262144,524288,8233,927757,33,525329,73736,8192,599114,335882,1005655,870487,75787,74794,73770,525429,73770,13324,74251]

theorem envBound6941 : H12AffineFastState.Bounded env6941 := by
  intro p hp
  have h : env6941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6936_6941 : H12AffineEnvironment.transform 22 525329 env6936 = env6941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env6936 == env6941) = true)

theorem identity6941 : scanCanonicalize (H12AffineFastState.compose env6941 (packedSelected [13] rootPS)) = affineNative (2^(18+1) ^^^ 478259) := by decide +kernel

theorem selectedBound6941 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env6942 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,65536,131072,262144,478259,8233,91198,33,477218,73736,8192,419961,335882,5220,132196,75787,74794,73770,477254,73770,13324,74251]

theorem envBound6942 : H12AffineFastState.Bounded env6942 := by
  intro p hp
  have h : env6942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6941_6942 : H12AffineEnvironment.transform 18 478259 env6941 = env6942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 478259 env6941 == env6942) = true)

theorem identity6942 : scanCanonicalize (H12AffineFastState.compose env6942 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound6942 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env6943 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,65536,78959,262144,292956,8233,91198,33,293965,73736,8192,351254,335882,5220,77835,75787,74794,73770,293929,73770,13324,74251]

theorem envBound6943 : H12AffineFastState.Bounded env6943 := by
  intro p hp
  have h : env6943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6942_6943 : H12AffineEnvironment.transform 16 78959 env6942 = env6943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env6942 == env6943) = true)

theorem identity6943 : scanCanonicalize (H12AffineFastState.compose env6943 (packedSelected [3,5,10,12,15,21] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound6943 : packedSelected [3,5,10,12,15,21] rootPS < 2^1333 := by decide +kernel

def env6944 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,65536,78959,97326,66674,8233,91198,33,65635,73736,8192,8248,23588,5220,77835,75787,74794,73770,65543,73770,13324,74251]

theorem envBound6944 : H12AffineFastState.Bounded env6944 := by
  intro p hp
  have h : env6944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6943_6944 : H12AffineEnvironment.transform 17 97326 env6943 = env6944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env6943 == env6944) = true)

theorem identity6944 : scanCanonicalize (H12AffineFastState.compose env6944 (packedSelected [0,1,3,4,7,9,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 10795) := by decide +kernel

theorem selectedBound6944 : packedSelected [0,1,3,4,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env6945 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,10795,7748,22021,11865,8233,19989,33,10824,2595,8192,8248,23588,5220,6688,544,3585,2561,10796,2561,13324,2080]

theorem envBound6945 : H12AffineFastState.Bounded env6945 := by
  intro p hp
  have h : env6945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6944_6945 : H12AffineEnvironment.transform 15 10795 env6944 = env6945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10795 env6944 == env6945) = true)

theorem identity6945 : scanCanonicalize (H12AffineFastState.compose env6945 (packedSelected [1,2,3,6,11,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound6945 : packedSelected [1,2,3,6,11,12,18] rootPS < 2^1333 := by decide +kernel

def env6946 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,1,2563,7748,22021,3697,1,19989,33,2656,2595,40,16,23588,5220,6688,544,3585,2561,2564,2561,5156,2080]

theorem envBound6946 : H12AffineFastState.Bounded env6946 := by
  intro p hp
  have h : env6946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6945_6946 : H12AffineEnvironment.transform 12 40 env6945 = env6946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env6945 == env6946) = true)

theorem identity6946 : scanCanonicalize (H12AffineFastState.compose env6946 (packedSelected [0,1,2,3,4,7,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 6672) := by decide +kernel

theorem selectedBound6946 : packedSelected [0,1,2,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env6947 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,6672,1,2563,7748,3093,3697,1,5125,33,2656,2595,40,16,1588,5220,6688,544,3585,2561,2564,2561,5156,2080]

theorem envBound6947 : H12AffineFastState.Bounded env6947 := by
  intro p hp
  have h : env6947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6946_6947 : H12AffineEnvironment.transform 13 6672 env6946 = env6947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6672 env6946 == env6947) = true)

theorem identity6947 : scanCanonicalize (H12AffineFastState.compose env6947 (packedSelected [0,1,2,4,5,7,9,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6947 : packedSelected [0,1,2,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env6948 : List Nat := [2,4,8,16,0,64,8,85,512,1024,2048,4096,8,6672,1,2563,7748,3093,3665,1,5125,1,2624,2563,8,16,1556,5188,6656,512,3585,2561,2564,2561,5124,2048]

theorem envBound6948 : H12AffineFastState.Bounded env6948 := by
  intro p hp
  have h : env6948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6947_6948 : H12AffineEnvironment.transform 4 0 env6947 = env6948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6947 == env6948) = true)

def env6949 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,2097152,33,8388608,8987673,8193,599115,335882,11105354,11232330,8989722,74794,73770,525428,8987707,34359738368,74250]

theorem envBound6949 : H12AffineFastState.Bounded env6949 := by
  intro p hp
  have h : env6949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6913_6949 : H12AffineEnvironment.transform 6 9 env6913 = env6949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env6913 == env6949) = true)

theorem identity6949 : scanCanonicalize (H12AffineFastState.compose env6949 (packedSelected [0,2,6,11,12,14,23,27,38] rootPS)) = affineNative (2^(34+1) ^^^ 10958875) := by decide +kernel

theorem selectedBound6949 : packedSelected [0,2,6,11,12,14,23,27,38] rootPS < 2^1333 := by decide +kernel

def env6950 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,2097152,33,8388608,8987673,8193,599115,335882,11105354,11232330,8989722,74794,73770,525428,8987707,10958875,74250]

theorem envBound6950 : H12AffineFastState.Bounded env6950 := by
  intro p hp
  have h : env6950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6949_6950 : H12AffineEnvironment.transform 34 10958875 env6949 = env6950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 10958875 env6949 == env6950) = true)

theorem identity6950 : scanCanonicalize (H12AffineFastState.compose env6950 (packedSelected [1,2,3,6,7,9,11,12,15,20,22,23,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound6950 : packedSelected [1,2,3,6,7,9,11,12,15,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env6951 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,8202,131072,262144,524288,8232,2097152,33,8388608,8913939,8193,525377,262144,11031616,11158592,8915984,1056,32,525428,8913969,10885137,512]

theorem envBound6951 : H12AffineFastState.Bounded env6951 := by
  intro p hp
  have h : env6951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6950_6951 : H12AffineEnvironment.transform 15 8202 env6950 = env6951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env6950 == env6951) = true)

theorem identity6951 : scanCanonicalize (H12AffineFastState.compose env6951 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound6951 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6952 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,8202,131072,262144,524288,8232,17460,33,8388608,8913939,8193,525377,262144,8917108,9044084,8915984,1056,32,525428,8913969,8805413,512]

theorem envBound6952 : H12AffineFastState.Bounded env6952 := by
  intro p hp
  have h : env6952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6951_6952 : H12AffineEnvironment.transform 20 17460 env6951 = env6952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env6951 == env6952) = true)

theorem identity6952 : scanCanonicalize (H12AffineFastState.compose env6952 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(22+1) ^^^ 525328) := by decide +kernel

theorem selectedBound6952 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env6953 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,8202,131072,262144,524288,8232,17460,33,525328,3,8193,525377,262144,5220,132196,2048,1056,32,525428,33,940085,512]

theorem envBound6953 : H12AffineFastState.Bounded env6953 := by
  intro p hp
  have h : env6953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6952_6953 : H12AffineEnvironment.transform 22 525328 env6952 = env6953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env6952 == env6953) = true)

theorem identity6953 : scanCanonicalize (H12AffineFastState.compose env6953 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound6953 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6954 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,8202,5221,262144,524288,8232,17460,33,525328,3,8193,525377,262144,5220,4097,2048,1056,32,525428,33,805968,512]

theorem envBound6954 : H12AffineFastState.Bounded env6954 := by
  intro p hp
  have h : env6954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6953_6954 : H12AffineEnvironment.transform 16 5221 env6953 = env6954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env6953 == env6954) = true)

theorem identity6954 : scanCanonicalize (H12AffineFastState.compose env6954 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3180) := by decide +kernel

theorem selectedBound6954 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env6955 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,3180,16384,3140,3174,5221,262144,524288,3140,17460,33,525328,3,3181,525377,262144,5220,4097,2048,1056,32,525428,33,805968,512]

theorem envBound6955 : H12AffineFastState.Bounded env6955 := by
  intro p hp
  have h : env6955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6954_6955 : H12AffineEnvironment.transform 12 3180 env6954 = env6955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3180 env6954 == env6955) = true)

theorem identity6955 : scanCanonicalize (H12AffineFastState.compose env6955 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 1124) := by decide +kernel

theorem selectedBound6955 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6956 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,3180,16384,3140,3174,5221,1124,524288,3140,17460,33,525328,3,3181,525377,1124,5220,4097,2048,1056,32,525428,33,542772,512]

theorem envBound6956 : H12AffineFastState.Bounded env6956 := by
  intro p hp
  have h : env6956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6955_6956 : H12AffineEnvironment.transform 17 1124 env6955 = env6956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1124 env6955 == env6956) = true)

theorem identity6956 : scanCanonicalize (H12AffineFastState.compose env6956 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound6956 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env6957 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1092,4096,40,16384,0,34,5221,1124,524288,0,17460,33,525328,3,41,525377,1124,5220,4097,1092,1056,32,525428,33,541808,512]

theorem envBound6957 : H12AffineFastState.Bounded env6957 := by
  intro p hp
  have h : env6957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6956_6957 : H12AffineEnvironment.transform 10 1092 env6956 = env6957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env6956 == env6957) = true)

theorem identity6957 : scanCanonicalize (H12AffineFastState.compose env6957 (packedSelected [0,1,2,3,7,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6957 : packedSelected [0,1,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env6958 : List Nat := [2,4,8,16,1,64,9,85,512,1024,1092,4096,9,16384,0,3,5188,1093,524288,0,17429,0,525328,3,8,525377,1093,5189,4097,1092,1025,1,525397,0,541777,512]

theorem envBound6958 : H12AffineFastState.Bounded env6958 := by
  intro p hp
  have h : env6958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6957_6958 : H12AffineEnvironment.transform 4 1 env6957 = env6958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6957 == env6958) = true)

def env6959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,32,8388608,8988132,8328,599234,336374,11105475,11232451,8989722,74795,73770,525568,8987707,34359738368,74623]

theorem envBound6959 : H12AffineFastState.Bounded env6959 := by
  intro p hp
  have h : env6959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6906_6959 : H12AffineEnvironment.transform 14 8541 env6906 = env6959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env6906 == env6959) = true)

theorem identity6959 : scanCanonicalize (H12AffineFastState.compose env6959 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound6959 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8575,131072,262144,524288,8541,2097152,32,8388608,8914075,8328,525757,262281,11031996,11158972,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6960 : H12AffineFastState.Bounded env6960 := by
  intro p hp
  have h : env6960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6959_6960 : H12AffineEnvironment.transform 15 8575 env6959 = env6960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env6959 == env6960) = true)

def env6961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8575,131072,262144,524288,8541,151632,32,8388608,8914075,8328,525757,262281,9045484,8918508,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6961 : H12AffineFastState.Bounded env6961 := by
  intro p hp
  have h : env6961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6960_6961 : H12AffineEnvironment.transform 20 151632 env6960 = env6961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env6960 == env6961) = true)

theorem identity6961 : scanCanonicalize (H12AffineFastState.compose env6961 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound6961 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8575,5357,262144,524288,8541,17597,32,8388608,8914075,8328,525757,262281,8917249,8918508,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6962 : H12AffineFastState.Bounded env6962 := by
  intro p hp
  have h : env6962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6961_6962 : H12AffineEnvironment.transform 16 5357 env6961 = env6962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env6961 == env6962) = true)

theorem identity6962 : scanCanonicalize (H12AffineFastState.compose env6962 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound6962 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,34,5357,262144,524288,0,17597,32,8388608,8914075,469,525757,262281,8917249,8918508,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6963 : H12AffineFastState.Bounded env6963 := by
  intro p hp
  have h : env6963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6962_6963 : H12AffineEnvironment.transform 12 349 env6962 = env6963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env6962 == env6963) = true)

theorem identity6963 : scanCanonicalize (H12AffineFastState.compose env6963 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(22+1) ^^^ 525805) := by decide +kernel

theorem selectedBound6963 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env6964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,34,5357,262144,524288,0,17597,32,525805,374,469,525757,262281,5356,4097,2184,1364,341,525568,169,34359738368,512]

theorem envBound6964 : H12AffineFastState.Bounded env6964 := by
  intro p hp
  have h : env6964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6963_6964 : H12AffineEnvironment.transform 22 525805 env6963 = env6964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525805 env6963 == env6964) = true)

theorem identity6964 : scanCanonicalize (H12AffineFastState.compose env6964 (packedSelected [2,6] rootPS)) = affineNative (2^(18+1) ^^^ 1452) := by decide +kernel

theorem selectedBound6964 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,34,5357,262144,1452,0,17597,32,65,374,469,17,262281,5356,4097,2184,1364,341,172,169,34359738368,512]

theorem envBound6965 : H12AffineFastState.Bounded env6965 := by
  intro p hp
  have h : env6965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6964_6965 : H12AffineEnvironment.transform 18 1452 env6964 = env6965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1452 env6964 == env6965) = true)

theorem identity6965 : scanCanonicalize (H12AffineFastState.compose env6965 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6965 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env6966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,34,5357,2184,1452,0,17597,32,65,374,469,17,2049,5356,4097,2184,1364,341,172,169,34359738368,512]

theorem envBound6966 : H12AffineFastState.Bounded env6966 := by
  intro p hp
  have h : env6966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6965_6966 : H12AffineEnvironment.transform 17 2184 env6965 = env6966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6965 == env6966) = true)

theorem identity6966 : scanCanonicalize (H12AffineFastState.compose env6966 (packedSelected [4,9,11] rootPS)) = affineNative (2^(34+1) ^^^ 16893) := by decide +kernel

theorem selectedBound6966 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env6967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,34,5357,2184,1452,0,17597,32,65,374,469,17,2049,5356,4097,2184,1364,341,172,169,16893,512]

theorem envBound6967 : H12AffineFastState.Bounded env6967 := by
  intro p hp
  have h : env6967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6966_6967 : H12AffineEnvironment.transform 34 16893 env6966 = env6967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 16893 env6966 == env6967) = true)

def env6968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8575,131072,262144,524288,8541,151633,32,8388608,8914075,8328,525757,262281,9045485,8918509,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6968 : H12AffineFastState.Bounded env6968 := by
  intro p hp
  have h : env6968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6960_6968 : H12AffineEnvironment.transform 20 151633 env6960 = env6968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env6960 == env6968) = true)

theorem identity6968 : scanCanonicalize (H12AffineFastState.compose env6968 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound6968 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8575,5393,262144,524288,8541,17728,32,8388608,8914075,8328,525757,262281,8917244,8918509,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6969 : H12AffineFastState.Bounded env6969 := by
  intro p hp
  have h : env6969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6968_6969 : H12AffineEnvironment.transform 16 5393 env6968 = env6969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env6968 == env6969) = true)

theorem identity6969 : scanCanonicalize (H12AffineFastState.compose env6969 (packedSelected [0,7,20] rootPS)) = affineNative (2^(22+1) ^^^ 533837) := by decide +kernel

theorem selectedBound6969 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8575,5393,262144,524288,8541,17728,32,533837,8662,8328,525757,262281,13745,12448,10280,1364,341,525568,8201,34359738368,512]

theorem envBound6970 : H12AffineFastState.Bounded env6970 := by
  intro p hp
  have h : env6970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6969_6970 : H12AffineEnvironment.transform 22 533837 env6969 = env6970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 533837 env6969 == env6970) = true)

def env6971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,16384,509,479,5393,262144,524288,509,17728,32,525805,374,40,525757,262281,5393,4096,2184,1364,341,525568,169,34359738368,512]

theorem envBound6971 : H12AffineFastState.Bounded env6971 := by
  intro p hp
  have h : env6971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6970_6971 : H12AffineEnvironment.transform 12 160 env6970 = env6971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env6970 == env6971) = true)

theorem identity6971 : scanCanonicalize (H12AffineFastState.compose env6971 (packedSelected [2,6] rootPS)) = affineNative (2^(18+1) ^^^ 1453) := by decide +kernel

theorem selectedBound6971 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,16384,509,479,5393,262144,1453,509,17728,32,64,374,40,16,262281,5393,4096,2184,1364,341,173,169,34359738368,512]

theorem envBound6972 : H12AffineFastState.Bounded env6972 := by
  intro p hp
  have h : env6972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6971_6972 : H12AffineEnvironment.transform 18 1453 env6971 = env6972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1453 env6971 == env6972) = true)

theorem identity6972 : scanCanonicalize (H12AffineFastState.compose env6972 (packedSelected [1,3,4,5,8,9,11,12,13] rootPS)) = affineNative (2^(34+1) ^^^ 280949) := by decide +kernel

theorem selectedBound6972 : packedSelected [1,3,4,5,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env6973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,16384,509,479,5393,262144,1453,509,17728,32,64,374,40,16,262281,5393,4096,2184,1364,341,173,169,280949,512]

theorem envBound6973 : H12AffineFastState.Bounded env6973 := by
  intro p hp
  have h : env6973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6972_6973 : H12AffineEnvironment.transform 34 280949 env6972 = env6973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280949 env6972 == env6973) = true)

theorem identity6973 : scanCanonicalize (H12AffineFastState.compose env6973 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound6973 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env6974 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,5357,262144,1105,1,17596,32,64,138,40,16,262281,5357,4096,2184,1192,169,173,169,280713,512]

theorem envBound6974 : H12AffineFastState.Bounded env6974 := by
  intro p hp
  have h : env6974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6973_6974 : H12AffineEnvironment.transform 7 252 env6973 = env6974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env6973 == env6974) = true)

theorem identity6974 : scanCanonicalize (H12AffineFastState.compose env6974 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(17+1) ^^^ 22618) := by decide +kernel

theorem selectedBound6974 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6975 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,5357,22618,1105,1,17596,32,64,138,40,16,22739,5357,4096,2184,1192,169,173,169,4307,512]

theorem envBound6975 : H12AffineFastState.Bounded env6975 := by
  intro p hp
  have h : env6975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6974_6975 : H12AffineEnvironment.transform 17 22618 env6974 = env6975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22618 env6974 == env6975) = true)

theorem identity6975 : scanCanonicalize (H12AffineFastState.compose env6975 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound6975 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env6976 : List Nat := [2,4,8,16,32,64,128,252,512,166,2048,4096,160,16384,1,35,4171,22618,247,1,16410,32,64,138,40,16,22739,4171,4096,2184,14,169,173,169,4307,512]

theorem envBound6976 : H12AffineFastState.Bounded env6976 := by
  intro p hp
  have h : env6976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6975_6976 : H12AffineEnvironment.transform 9 166 env6975 = env6976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env6975 == env6976) = true)

theorem identity6976 : scanCanonicalize (H12AffineFastState.compose env6976 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound6976 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6977 : List Nat := [2,4,8,16,32,64,88,36,512,126,2048,4096,120,16384,1,35,4171,22618,47,1,16410,32,64,82,40,16,22539,4171,4096,2128,14,113,117,113,4107,512]

theorem envBound6977 : H12AffineFastState.Bounded env6977 := by
  intro p hp
  have h : env6977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6976_6977 : H12AffineEnvironment.transform 6 88 env6976 = env6977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env6976 == env6977) = true)

theorem identity6977 : scanCanonicalize (H12AffineFastState.compose env6977 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound6977 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env6978 : List Nat := [2,4,8,16,32,64,88,36,512,126,522,4096,120,16384,1,35,4171,21072,47,1,16410,32,64,82,40,16,20993,4171,4096,602,14,113,117,113,4107,512]

theorem envBound6978 : H12AffineFastState.Bounded env6978 := by
  intro p hp
  have h : env6978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6977_6978 : H12AffineEnvironment.transform 10 522 env6977 = env6978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env6977 == env6978) = true)

def env6979 : List Nat := [2,4,8,16,32,16,8,36,512,46,522,4096,40,16384,1,35,4123,20992,47,1,16410,32,16,2,40,16,20993,4123,4096,522,14,33,37,33,4107,512]

theorem envBound6979 : H12AffineFastState.Bounded env6979 := by
  intro p hp
  have h : env6979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6978_6979 : H12AffineEnvironment.transform 5 16 env6978 = env6979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6978 == env6979) = true)

theorem identity6979 : scanCanonicalize (H12AffineFastState.compose env6979 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound6979 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6980 : List Nat := [2,4,8,16,16,16,8,20,512,30,522,4096,24,16384,1,19,4123,20992,31,1,16410,16,16,2,24,16,20993,4123,4096,522,14,17,21,17,4107,512]

theorem envBound6980 : H12AffineFastState.Bounded env6980 := by
  intro p hp
  have h : env6980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6979_6980 : H12AffineEnvironment.transform 4 16 env6979 = env6980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env6979 == env6980) = true)

def env6981 : List Nat := [2,4,8,16,16,16,8,20,512,30,522,0,24,16384,1,19,27,16896,31,1,16410,16,16,2,24,16,16897,27,0,522,14,17,21,17,11,512]

theorem envBound6981 : H12AffineFastState.Bounded env6981 := by
  intro p hp
  have h : env6981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6980_6981 : H12AffineEnvironment.transform 11 0 env6980 = env6981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env6980 == env6981) = true)

theorem identity6981 : scanCanonicalize (H12AffineFastState.compose env6981 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound6981 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6982 : List Nat := [0,4,8,16,16,16,8,20,512,28,520,0,24,16384,1,17,25,16896,29,1,16408,16,16,0,24,16,16897,25,0,520,12,17,21,17,9,512]

theorem envBound6982 : H12AffineFastState.Bounded env6982 := by
  intro p hp
  have h : env6982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6981_6982 : H12AffineEnvironment.transform 0 0 env6981 = env6982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env6981 == env6982) = true)

def env6983 : List Nat := [0,4,8,16,16,16,8,20,512,28,520,0,24,528,1,17,25,16,29,1,520,16,16,0,24,16,17,25,0,520,12,17,21,17,9,512]

theorem envBound6983 : H12AffineFastState.Bounded env6983 := by
  intro p hp
  have h : env6983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6982_6983 : H12AffineEnvironment.transform 13 528 env6982 = env6983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 528 env6982 == env6983) = true)

def env6984 : List Nat := [0,4,8,16,16,16,8,20,16,28,24,0,24,0,1,17,25,16,29,1,24,16,16,0,24,16,17,25,0,24,12,17,21,17,9,16]

theorem envBound6984 : H12AffineFastState.Bounded env6984 := by
  intro p hp
  have h : env6984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6983_6984 : H12AffineEnvironment.transform 8 16 env6983 = env6984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env6983 == env6984) = true)

theorem identity6984 : scanCanonicalize (H12AffineFastState.compose env6984 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound6984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6985 : List Nat := [0,4,5,16,16,16,5,20,16,17,21,0,21,0,1,17,20,16,16,1,21,16,16,0,21,16,17,20,0,21,1,17,21,17,4,16]

theorem envBound6985 : H12AffineFastState.Bounded env6985 := by
  intro p hp
  have h : env6985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6984_6985 : H12AffineEnvironment.transform 2 5 env6984 = env6985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env6984 == env6985) = true)

def env6986 : List Nat := [0,4,5,0,0,0,5,4,0,1,5,0,5,0,1,1,4,0,0,1,5,0,0,0,5,0,1,4,0,5,1,1,5,1,4,0]

theorem envBound6986 : H12AffineFastState.Bounded env6986 := by
  intro p hp
  have h : env6986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6985_6986 : H12AffineEnvironment.transform 3 0 env6985 = env6986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6985 == env6986) = true)

theorem identity6986 : scanCanonicalize (H12AffineFastState.compose env6986 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6986 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6987 : List Nat := [0,1,0,0,0,0,0,1,0,1,0,0,0,0,1,1,1,0,0,1,0,0,0,0,0,0,1,1,0,0,1,1,0,1,1,0]

theorem envBound6987 : H12AffineFastState.Bounded env6987 := by
  intro p hp
  have h : env6987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6986_6987 : H12AffineEnvironment.transform 1 1 env6986 = env6987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6986 == env6987) = true)

def leafEnv6987 : List Nat := [0,1,0,0,0,0,0,1,0,1,0,0,0,0,1,1,1,0,0,1,0,0,0,0,0,0,1,0,1,1,0,0,1,1,0,1,0,1,1,0,1,0,0]

def active6987 : List Nat := []

def tree6987 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6987 : H12WitnessSearch.Good tree6987 := H12GlobalWitnessIndex.good

theorem leafIdentity6987 : H12AffineFastState.composeSystem env6987 rootObs = leafEnv6987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6987 rootObs == leafEnv6987) = true)

theorem terminalChecked6987 : H12PackedTerminal.terminalCheckFast leafEnv6987 active6987 tree6987 = true := by decide +kernel

def env6988 : List Nat := [0,4,5,1,1,1,5,5,1,0,4,0,4,0,1,0,5,1,1,1,4,1,1,0,4,1,0,5,0,4,1,0,4,0,4,1]

theorem envBound6988 : H12AffineFastState.Bounded env6988 := by
  intro p hp
  have h : env6988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6985_6988 : H12AffineEnvironment.transform 3 1 env6985 = env6988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6985 == env6988) = true)

def leafEnv6988 : List Nat := [0,4,5,1,1,1,5,5,1,0,4,0,4,0,1,0,5,1,1,1,4,1,1,0,0,4,1,1,0,5,0,4,1,0,4,0,5,0,4,1,1,1,0]

def active6988 : List Nat := [1]

def tree6988 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6988 : H12WitnessSearch.Good tree6988 := H12GlobalWitnessIndex.good

theorem leafIdentity6988 : H12AffineFastState.composeSystem env6988 rootObs = leafEnv6988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6988 rootObs == leafEnv6988) = true)

theorem terminalChecked6988 : H12PackedTerminal.terminalCheckFast leafEnv6988 active6988 tree6988 = true := by decide +kernel

def env6989 : List Nat := [0,4,8,16,16,16,8,20,17,28,25,0,24,1,1,17,25,16,29,1,25,16,16,0,24,16,17,25,0,25,12,17,21,17,9,17]

theorem envBound6989 : H12AffineFastState.Bounded env6989 := by
  intro p hp
  have h : env6989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6983_6989 : H12AffineEnvironment.transform 8 17 env6983 = env6989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env6983 == env6989) = true)

theorem identity6989 : scanCanonicalize (H12AffineFastState.compose env6989 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6989 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6990 : List Nat := [0,0,8,16,16,16,8,16,17,24,25,0,24,1,1,17,25,16,25,1,25,16,16,0,24,16,17,25,0,25,8,17,17,17,9,17]

theorem envBound6990 : H12AffineFastState.Bounded env6990 := by
  intro p hp
  have h : env6990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6989_6990 : H12AffineEnvironment.transform 1 0 env6989 = env6990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6989 == env6990) = true)

def env6991 : List Nat := [0,0,8,0,0,0,8,0,1,8,9,0,8,1,1,1,9,0,9,1,9,0,0,0,8,0,1,9,0,9,8,1,1,1,9,1]

theorem envBound6991 : H12AffineFastState.Bounded env6991 := by
  intro p hp
  have h : env6991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6990_6991 : H12AffineEnvironment.transform 3 0 env6990 = env6991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6990 == env6991) = true)

def leafEnv6991 : List Nat := [0,0,8,0,0,0,8,0,1,8,9,0,8,1,1,1,9,0,9,1,9,0,0,0,9,8,1,0,1,9,0,9,8,1,1,1,1,1,9,1,1,0,0]

def active6991 : List Nat := [2]

def tree6991 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6991 : H12WitnessSearch.Good tree6991 := H12GlobalWitnessIndex.good

theorem leafIdentity6991 : H12AffineFastState.composeSystem env6991 rootObs = leafEnv6991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6991 rootObs == leafEnv6991) = true)

theorem terminalChecked6991 : H12PackedTerminal.terminalCheckFast leafEnv6991 active6991 tree6991 = true := by decide +kernel

def env6992 : List Nat := [0,0,8,1,1,1,8,1,0,9,8,0,9,1,1,0,8,1,8,1,8,1,1,0,9,1,0,8,0,8,8,0,0,0,9,0]

theorem envBound6992 : H12AffineFastState.Bounded env6992 := by
  intro p hp
  have h : env6992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6990_6992 : H12AffineEnvironment.transform 3 1 env6990 = env6992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6990 == env6992) = true)

theorem identity6992 : scanCanonicalize (H12AffineFastState.compose env6992 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound6992 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6993 : List Nat := [0,0,1,1,1,1,1,1,0,0,1,0,0,1,1,0,1,1,1,1,1,1,1,0,0,1,0,1,0,1,1,0,0,0,0,0]

theorem envBound6993 : H12AffineFastState.Bounded env6993 := by
  intro p hp
  have h : env6993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6992_6993 : H12AffineEnvironment.transform 2 1 env6992 = env6993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env6992 == env6993) = true)

def leafEnv6993 : List Nat := [0,0,1,1,1,1,1,1,0,0,1,0,0,1,1,0,1,1,1,1,1,1,1,0,0,0,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,1,0]

def active6993 : List Nat := []

def tree6993 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6993 : H12WitnessSearch.Good tree6993 := H12GlobalWitnessIndex.good

theorem leafIdentity6993 : H12AffineFastState.composeSystem env6993 rootObs = leafEnv6993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6993 rootObs == leafEnv6993) = true)

theorem terminalChecked6993 : H12PackedTerminal.terminalCheckFast leafEnv6993 active6993 tree6993 = true := by decide +kernel

def env6994 : List Nat := [0,4,8,16,16,16,8,20,512,28,520,0,24,529,1,17,25,17,29,1,521,16,16,0,24,16,16,25,0,520,12,17,21,17,9,512]

theorem envBound6994 : H12AffineFastState.Bounded env6994 := by
  intro p hp
  have h : env6994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6982_6994 : H12AffineEnvironment.transform 13 529 env6982 = env6994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 529 env6982 == env6994) = true)

theorem identity6994 : scanCanonicalize (H12AffineFastState.compose env6994 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound6994 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6995 : List Nat := [0,4,8,16,16,16,8,20,24,28,16,0,24,9,1,17,25,17,29,1,17,16,16,0,24,16,16,25,0,16,12,17,21,17,9,24]

theorem envBound6995 : H12AffineFastState.Bounded env6995 := by
  intro p hp
  have h : env6995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6994_6995 : H12AffineEnvironment.transform 8 24 env6994 = env6995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env6994 == env6995) = true)

theorem identity6995 : scanCanonicalize (H12AffineFastState.compose env6995 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound6995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6996 : List Nat := [0,4,8,13,13,13,8,9,5,1,13,0,5,9,1,12,4,12,0,1,12,13,13,0,5,13,13,4,0,13,12,12,8,12,9,5]

theorem envBound6996 : H12AffineFastState.Bounded env6996 := by
  intro p hp
  have h : env6996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6995_6996 : H12AffineEnvironment.transform 3 13 env6995 = env6996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env6995 == env6996) = true)

theorem identity6996 : scanCanonicalize (H12AffineFastState.compose env6996 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6996 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6997 : List Nat := [0,0,8,9,9,9,8,9,1,1,9,0,1,9,1,8,0,8,0,1,8,9,9,0,1,9,9,0,0,9,8,8,8,8,9,1]

theorem envBound6997 : H12AffineFastState.Bounded env6997 := by
  intro p hp
  have h : env6997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6996_6997 : H12AffineEnvironment.transform 1 0 env6996 = env6997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6996 == env6997) = true)

def leafEnv6997 : List Nat := [0,0,8,9,9,9,8,9,1,1,9,0,1,9,1,8,0,8,0,1,8,9,9,0,9,1,1,9,9,0,0,9,8,8,8,8,1,8,9,1,1,9,0]

def active6997 : List Nat := [2]

def tree6997 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6997 : H12WitnessSearch.Good tree6997 := H12GlobalWitnessIndex.good

theorem leafIdentity6997 : H12AffineFastState.composeSystem env6997 rootObs = leafEnv6997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6997 rootObs == leafEnv6997) = true)

theorem terminalChecked6997 : H12PackedTerminal.terminalCheckFast leafEnv6997 active6997 tree6997 = true := by decide +kernel

def env6998 : List Nat := [2,4,8,16,16,16,8,20,512,30,522,1,24,16384,1,19,26,16897,31,1,16410,16,16,2,24,16,16896,26,1,522,14,17,21,17,10,512]

theorem envBound6998 : H12AffineFastState.Bounded env6998 := by
  intro p hp
  have h : env6998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6980_6998 : H12AffineEnvironment.transform 11 1 env6980 = env6998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env6980 == env6998) = true)

theorem identity6998 : scanCanonicalize (H12AffineFastState.compose env6998 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound6998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6999 : List Nat := [2,4,8,8,8,8,8,12,512,6,522,1,0,16384,1,11,2,16897,7,1,16386,8,8,2,0,8,16896,2,1,522,14,9,13,9,10,512]

theorem envBound6999 : H12AffineFastState.Bounded env6999 := by
  intro p hp
  have h : env6999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6998_6999 : H12AffineEnvironment.transform 3 8 env6998 = env6999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env6998 == env6999) = true)

def env7000 : List Nat := [2,4,8,8,8,8,8,12,512,6,522,1,0,520,1,11,2,9,7,1,522,8,8,2,0,8,8,2,1,522,14,9,13,9,10,512]

theorem envBound7000 : H12AffineFastState.Bounded env7000 := by
  intro p hp
  have h : env7000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6999_7000 : H12AffineEnvironment.transform 13 520 env6999 = env7000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 520 env6999 == env7000) = true)

def env7001 : List Nat := [2,4,8,8,8,8,8,12,8,6,2,1,0,0,1,11,2,9,7,1,2,8,8,2,0,8,8,2,1,2,14,9,13,9,10,8]

theorem envBound7001 : H12AffineFastState.Bounded env7001 := by
  intro p hp
  have h : env7001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7000_7001 : H12AffineEnvironment.transform 8 8 env7000 = env7001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env7000 == env7001) = true)

theorem identity7001 : scanCanonicalize (H12AffineFastState.compose env7001 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound7001 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7002 : List Nat := [2,3,8,8,8,8,8,11,8,1,2,1,0,0,1,11,2,9,0,1,2,8,8,2,0,8,8,2,1,2,9,9,10,9,10,8]

theorem envBound7002 : H12AffineFastState.Bounded env7002 := by
  intro p hp
  have h : env7002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7001_7002 : H12AffineEnvironment.transform 1 3 env7001 = env7002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env7001 == env7002) = true)

def env7003 : List Nat := [2,3,0,0,0,0,0,3,0,1,2,1,0,0,1,3,2,1,0,1,2,0,0,2,0,0,0,2,1,2,1,1,2,1,2,0]

theorem envBound7003 : H12AffineFastState.Bounded env7003 := by
  intro p hp
  have h : env7003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7002_7003 : H12AffineEnvironment.transform 2 0 env7002 = env7003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env7002 == env7003) = true)

def leafEnv7003 : List Nat := [2,3,0,0,0,0,0,3,0,1,2,1,0,0,1,3,2,1,0,1,2,0,0,2,0,0,1,0,0,2,1,2,1,1,2,1,2,3,2,0,1,1,0]

def active7003 : List Nat := [0]

def tree7003 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7003 : H12WitnessSearch.Good tree7003 := H12GlobalWitnessIndex.good

theorem leafIdentity7003 : H12AffineFastState.composeSystem env7003 rootObs = leafEnv7003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7003 rootObs == leafEnv7003) = true)

theorem terminalChecked7003 : H12PackedTerminal.terminalCheckFast leafEnv7003 active7003 tree7003 = true := by decide +kernel

def env7004 : List Nat := [2,3,1,1,1,1,1,2,1,1,2,1,0,0,1,2,2,0,0,1,2,1,1,2,0,1,1,2,1,2,0,0,3,0,3,1]

theorem envBound7004 : H12AffineFastState.Bounded env7004 := by
  intro p hp
  have h : env7004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7002_7004 : H12AffineEnvironment.transform 2 1 env7002 = env7004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env7002 == env7004) = true)

theorem identity7004 : scanCanonicalize (H12AffineFastState.compose env7004 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound7004 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env7005 : List Nat := [0,1,1,1,1,1,1,0,1,1,0,1,0,0,1,0,0,0,0,1,0,1,1,0,0,1,1,0,1,0,0,0,1,0,1,1]

theorem envBound7005 : H12AffineFastState.Bounded env7005 := by
  intro p hp
  have h : env7005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7004_7005 : H12AffineEnvironment.transform 0 0 env7004 = env7005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env7004 == env7005) = true)

def leafEnv7005 : List Nat := [0,1,1,1,1,1,1,0,1,1,0,1,0,0,1,0,0,0,0,1,0,1,1,0,1,0,1,1,1,0,1,0,0,0,1,0,0,0,1,1,1,0,0]

def active7005 : List Nat := []

def tree7005 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7005 : H12WitnessSearch.Good tree7005 := H12GlobalWitnessIndex.good

theorem leafIdentity7005 : H12AffineFastState.composeSystem env7005 rootObs = leafEnv7005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7005 rootObs == leafEnv7005) = true)

theorem terminalChecked7005 : H12PackedTerminal.terminalCheckFast leafEnv7005 active7005 tree7005 = true := by decide +kernel

def env7006 : List Nat := [2,4,8,8,8,8,8,12,9,6,3,1,0,1,1,11,2,9,7,1,3,8,8,2,0,8,8,2,1,3,14,9,13,9,10,9]

theorem envBound7006 : H12AffineFastState.Bounded env7006 := by
  intro p hp
  have h : env7006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7000_7006 : H12AffineEnvironment.transform 8 9 env7000 = env7006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env7000 == env7006) = true)

theorem identity7006 : scanCanonicalize (H12AffineFastState.compose env7006 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound7006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7007 : List Nat := [2,4,4,4,4,4,4,0,5,6,3,1,0,1,1,7,2,5,7,1,3,4,4,2,0,4,4,2,1,3,2,5,1,5,6,5]

theorem envBound7007 : H12AffineFastState.Bounded env7007 := by
  intro p hp
  have h : env7007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7006_7007 : H12AffineEnvironment.transform 2 4 env7006 = env7007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env7006 == env7007) = true)

def env7008 : List Nat := [2,0,0,0,0,0,0,0,1,2,3,1,0,1,1,3,2,1,3,1,3,0,0,2,0,0,0,2,1,3,2,1,1,1,2,1]

theorem envBound7008 : H12AffineFastState.Bounded env7008 := by
  intro p hp
  have h : env7008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7007_7008 : H12AffineEnvironment.transform 1 0 env7007 = env7008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env7007 == env7008) = true)

theorem identity7008 : scanCanonicalize (H12AffineFastState.compose env7008 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound7008 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env7009 : List Nat := [0,0,0,0,0,0,0,0,1,0,1,1,0,1,1,1,0,1,1,1,1,0,0,0,0,0,0,0,1,1,0,1,1,1,0,1]

theorem envBound7009 : H12AffineFastState.Bounded env7009 := by
  intro p hp
  have h : env7009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7008_7009 : H12AffineEnvironment.transform 0 0 env7008 = env7009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env7008 == env7009) = true)

def leafEnv7009 : List Nat := [0,0,0,0,0,0,0,0,1,0,1,1,0,1,1,1,0,1,1,1,1,0,0,0,1,0,1,0,0,0,1,1,0,1,1,1,1,1,0,1,1,1,0]

def active7009 : List Nat := []

def tree7009 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7009 : H12WitnessSearch.Good tree7009 := H12GlobalWitnessIndex.good

theorem leafIdentity7009 : H12AffineFastState.composeSystem env7009 rootObs = leafEnv7009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7009 rootObs == leafEnv7009) = true)

theorem terminalChecked7009 : H12PackedTerminal.terminalCheckFast leafEnv7009 active7009 tree7009 = true := by decide +kernel

def env7010 : List Nat := [2,1,1,1,1,1,1,0,0,3,3,1,0,1,1,2,2,0,2,1,3,1,1,2,0,1,1,2,1,3,2,0,1,0,3,0]

theorem envBound7010 : H12AffineFastState.Bounded env7010 := by
  intro p hp
  have h : env7010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7007_7010 : H12AffineEnvironment.transform 1 1 env7007 = env7010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env7007 == env7010) = true)

def leafEnv7010 : List Nat := [2,1,1,1,1,1,1,0,0,3,3,1,0,1,1,2,2,0,2,1,3,1,1,2,3,0,1,1,1,2,1,3,2,0,1,0,0,2,3,0,1,0,0]

def active7010 : List Nat := [0]

def tree7010 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7010 : H12WitnessSearch.Good tree7010 := H12GlobalWitnessIndex.good

theorem leafIdentity7010 : H12AffineFastState.composeSystem env7010 rootObs = leafEnv7010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7010 rootObs == leafEnv7010) = true)

theorem terminalChecked7010 : H12PackedTerminal.terminalCheckFast leafEnv7010 active7010 tree7010 = true := by decide +kernel

def env7011 : List Nat := [2,4,8,8,8,8,8,12,512,6,522,1,0,521,1,11,2,8,7,1,523,8,8,2,0,8,9,2,1,522,14,9,13,9,10,512]

theorem envBound7011 : H12AffineFastState.Bounded env7011 := by
  intro p hp
  have h : env7011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6999_7011 : H12AffineEnvironment.transform 13 521 env6999 = env7011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 521 env6999 == env7011) = true)

theorem identity7011 : scanCanonicalize (H12AffineFastState.compose env7011 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound7011 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7012 : List Nat := [2,4,8,8,8,8,8,12,3,6,9,1,0,10,1,11,2,8,7,1,8,8,8,2,0,8,9,2,1,9,14,9,13,9,10,3]

theorem envBound7012 : H12AffineFastState.Bounded env7012 := by
  intro p hp
  have h : env7012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7011_7012 : H12AffineEnvironment.transform 8 3 env7011 = env7012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env7011 == env7012) = true)

theorem identity7012 : scanCanonicalize (H12AffineFastState.compose env7012 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound7012 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7013 : List Nat := [2,0,8,8,8,8,8,8,3,2,9,1,0,10,1,11,2,8,3,1,8,8,8,2,0,8,9,2,1,9,10,9,9,9,10,3]

theorem envBound7013 : H12AffineFastState.Bounded env7013 := by
  intro p hp
  have h : env7013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7012_7013 : H12AffineEnvironment.transform 1 0 env7012 = env7013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env7012 == env7013) = true)

theorem identity7013 : scanCanonicalize (H12AffineFastState.compose env7013 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound7013 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env7014 : List Nat := [1,0,8,8,8,8,8,8,0,1,9,1,0,9,1,8,1,8,0,1,8,8,8,1,0,8,9,1,1,9,9,9,9,9,9,0]

theorem envBound7014 : H12AffineFastState.Bounded env7014 := by
  intro p hp
  have h : env7014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7013_7014 : H12AffineEnvironment.transform 0 1 env7013 = env7014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env7013 == env7014) = true)

def leafEnv7014 : List Nat := [1,0,8,8,8,8,8,8,0,1,9,1,0,9,1,8,1,8,0,1,8,8,8,1,8,0,1,8,9,1,1,9,9,9,9,9,1,8,9,0,1,9,0]

def active7014 : List Nat := [2]

def tree7014 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7014 : H12WitnessSearch.Good tree7014 := H12GlobalWitnessIndex.good

theorem leafIdentity7014 : H12AffineFastState.composeSystem env7014 rootObs = leafEnv7014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7014 rootObs == leafEnv7014) = true)

theorem terminalChecked7014 : H12PackedTerminal.terminalCheckFast leafEnv7014 active7014 tree7014 = true := by decide +kernel

def env7015 : List Nat := [2,4,8,16,32,17,9,36,512,47,522,4096,41,16384,1,35,4122,20993,47,1,16410,32,17,3,40,16,20993,4122,4096,523,14,32,36,32,4107,512]

theorem envBound7015 : H12AffineFastState.Bounded env7015 := by
  intro p hp
  have h : env7015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6978_7015 : H12AffineEnvironment.transform 5 17 env6978 = env7015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6978 == env7015) = true)

theorem identity7015 : scanCanonicalize (H12AffineFastState.compose env7015 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4154) := by decide +kernel

theorem selectedBound7015 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7016 : List Nat := [2,4,8,16,32,17,9,36,512,47,522,4096,41,4154,1,35,4122,571,47,1,4128,32,17,3,40,16,571,4122,4096,523,14,32,36,32,4107,512]

theorem envBound7016 : H12AffineFastState.Bounded env7016 := by
  intro p hp
  have h : env7016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7015_7016 : H12AffineEnvironment.transform 13 4154 env7015 = env7016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4154 env7015 == env7016) = true)

def env7017 : List Nat := [2,4,8,16,32,17,9,36,512,47,522,48,41,10,1,35,42,571,47,1,16,32,17,3,40,16,571,42,48,523,14,32,36,32,59,512]

theorem envBound7017 : H12AffineFastState.Bounded env7017 := by
  intro p hp
  have h : env7017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7016_7017 : H12AffineEnvironment.transform 11 48 env7016 = env7017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env7016 == env7017) = true)

theorem identity7017 : scanCanonicalize (H12AffineFastState.compose env7017 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound7017 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7018 : List Nat := [2,4,8,16,32,17,9,36,25,47,19,48,41,10,1,35,42,34,47,1,16,32,17,3,40,16,34,42,48,18,14,32,36,32,59,25]

theorem envBound7018 : H12AffineFastState.Bounded env7018 := by
  intro p hp
  have h : env7018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7017_7018 : H12AffineEnvironment.transform 8 25 env7017 = env7018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env7017 == env7018) = true)

def env7019 : List Nat := [2,4,8,16,16,17,9,20,25,31,19,0,25,10,1,19,26,18,31,1,16,16,17,3,24,16,18,26,0,18,14,16,20,16,11,25]

theorem envBound7019 : H12AffineFastState.Bounded env7019 := by
  intro p hp
  have h : env7019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7018_7019 : H12AffineEnvironment.transform 4 16 env7018 = env7019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env7018 == env7019) = true)

theorem identity7019 : scanCanonicalize (H12AffineFastState.compose env7019 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound7019 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7020 : List Nat := [1,4,8,16,16,17,9,20,25,28,16,0,25,9,1,16,25,17,28,1,16,16,17,0,24,16,17,25,0,17,13,16,20,16,8,25]

theorem envBound7020 : H12AffineFastState.Bounded env7020 := by
  intro p hp
  have h : env7020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7019_7020 : H12AffineEnvironment.transform 0 1 env7019 = env7020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env7019 == env7020) = true)

theorem identity7020 : scanCanonicalize (H12AffineFastState.compose env7020 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound7020 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7021 : List Nat := [1,4,8,4,4,5,9,0,13,8,4,0,13,9,1,4,13,5,8,1,4,4,5,0,12,4,5,13,0,5,13,4,0,4,8,13]

theorem envBound7021 : H12AffineFastState.Bounded env7021 := by
  intro p hp
  have h : env7021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7020_7021 : H12AffineEnvironment.transform 3 4 env7020 = env7021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env7020 == env7021) = true)

def leafEnv7021 : List Nat := [1,4,8,4,4,5,9,0,13,8,4,0,13,9,1,4,13,5,8,1,4,4,5,0,13,12,1,4,5,13,0,5,13,4,0,4,4,5,8,13,1,4,0]

def active7021 : List Nat := [1,2]

def tree7021 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7021 : H12WitnessSearch.Good tree7021 := H12GlobalWitnessIndex.good

theorem leafIdentity7021 : H12AffineFastState.composeSystem env7021 rootObs = leafEnv7021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7021 rootObs == leafEnv7021) = true)

theorem terminalChecked7021 : H12PackedTerminal.terminalCheckFast leafEnv7021 active7021 tree7021 = true := by decide +kernel

def env7022 : List Nat := [2,4,8,16,17,17,9,21,25,30,19,1,24,10,1,18,27,19,30,1,16,17,17,3,25,16,19,27,1,18,14,17,21,17,10,25]

theorem envBound7022 : H12AffineFastState.Bounded env7022 := by
  intro p hp
  have h : env7022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7018_7022 : H12AffineEnvironment.transform 4 17 env7018 = env7022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env7018 == env7022) = true)

theorem identity7022 : scanCanonicalize (H12AffineFastState.compose env7022 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound7022 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7023 : List Nat := [2,4,8,8,9,9,9,13,1,6,11,1,0,10,1,10,3,11,6,1,8,9,9,3,1,8,11,3,1,10,14,9,13,9,10,1]

theorem envBound7023 : H12AffineFastState.Bounded env7023 := by
  intro p hp
  have h : env7023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7022_7023 : H12AffineEnvironment.transform 3 8 env7022 = env7023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env7022 == env7023) = true)

theorem identity7023 : scanCanonicalize (H12AffineFastState.compose env7023 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound7023 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7024 : List Nat := [2,0,8,8,9,9,9,9,1,2,11,1,0,10,1,10,3,11,2,1,8,9,9,3,1,8,11,3,1,10,10,9,9,9,10,1]

theorem envBound7024 : H12AffineFastState.Bounded env7024 := by
  intro p hp
  have h : env7024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7023_7024 : H12AffineEnvironment.transform 1 0 env7023 = env7024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env7023 == env7024) = true)

def leafEnv7024 : List Nat := [2,0,8,8,9,9,9,9,1,2,11,1,0,10,1,10,3,11,2,1,8,9,9,3,10,1,1,8,11,3,1,10,10,9,9,9,0,11,10,1,1,9,0]

def active7024 : List Nat := [0,2]

def tree7024 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7024 : H12WitnessSearch.Good tree7024 := H12GlobalWitnessIndex.good

theorem leafIdentity7024 : H12AffineFastState.composeSystem env7024 rootObs = leafEnv7024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7024 rootObs == leafEnv7024) = true)

theorem terminalChecked7024 : H12PackedTerminal.terminalCheckFast leafEnv7024 active7024 tree7024 = true := by decide +kernel

def env7025 : List Nat := [2,4,8,16,32,17,9,36,512,47,522,49,41,11,1,35,43,571,47,1,17,32,17,3,40,16,571,43,49,523,14,32,36,32,58,512]

theorem envBound7025 : H12AffineFastState.Bounded env7025 := by
  intro p hp
  have h : env7025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7016_7025 : H12AffineEnvironment.transform 11 49 env7016 = env7025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env7016 == env7025) = true)

theorem identity7025 : scanCanonicalize (H12AffineFastState.compose env7025 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound7025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7026 : List Nat := [2,4,8,16,32,17,9,36,3,47,9,49,41,11,1,35,43,56,47,1,17,32,17,3,40,16,56,43,49,8,14,32,36,32,58,3]

theorem envBound7026 : H12AffineFastState.Bounded env7026 := by
  intro p hp
  have h : env7026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7025_7026 : H12AffineEnvironment.transform 8 3 env7025 = env7026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env7025 == env7026) = true)

def env7027 : List Nat := [2,4,8,16,16,17,9,20,3,31,9,1,25,11,1,19,27,8,31,1,17,16,17,3,24,16,8,27,1,8,14,16,20,16,10,3]

theorem envBound7027 : H12AffineFastState.Bounded env7027 := by
  intro p hp
  have h : env7027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7026_7027 : H12AffineEnvironment.transform 4 16 env7026 = env7027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env7026 == env7027) = true)

theorem identity7027 : scanCanonicalize (H12AffineFastState.compose env7027 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound7027 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7028 : List Nat := [2,4,8,8,8,9,9,12,3,7,9,1,1,11,1,11,3,8,7,1,9,8,9,3,0,8,8,3,1,8,14,8,12,8,10,3]

theorem envBound7028 : H12AffineFastState.Bounded env7028 := by
  intro p hp
  have h : env7028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7027_7028 : H12AffineEnvironment.transform 3 8 env7027 = env7028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env7027 == env7028) = true)

theorem identity7028 : scanCanonicalize (H12AffineFastState.compose env7028 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound7028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7029 : List Nat := [2,4,6,6,6,7,7,2,3,7,7,1,1,5,1,5,3,6,7,1,7,6,7,3,0,6,6,3,1,6,0,6,2,6,4,3]

theorem envBound7029 : H12AffineFastState.Bounded env7029 := by
  intro p hp
  have h : env7029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7028_7029 : H12AffineEnvironment.transform 2 6 env7028 = env7029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env7028 == env7029) = true)

def leafEnv7029 : List Nat := [2,4,6,6,6,7,7,2,3,7,7,1,1,5,1,5,3,6,7,1,7,6,7,3,0,0,1,6,6,3,1,6,0,6,2,6,4,4,4,3,1,7,0]

def active7029 : List Nat := [0,1]

def tree7029 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7029 : H12WitnessSearch.Good tree7029 := H12GlobalWitnessIndex.good

theorem leafIdentity7029 : H12AffineFastState.composeSystem env7029 rootObs = leafEnv7029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7029 rootObs == leafEnv7029) = true)

theorem terminalChecked7029 : H12PackedTerminal.terminalCheckFast leafEnv7029 active7029 tree7029 = true := by decide +kernel

def env7030 : List Nat := [2,4,8,16,17,17,9,21,3,30,9,0,24,11,1,18,26,9,30,1,17,17,17,3,25,16,9,26,0,8,14,17,21,17,11,3]

theorem envBound7030 : H12AffineFastState.Bounded env7030 := by
  intro p hp
  have h : env7030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7026_7030 : H12AffineEnvironment.transform 4 17 env7026 = env7030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env7026 == env7030) = true)

theorem identity7030 : scanCanonicalize (H12AffineFastState.compose env7030 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound7030 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7031 : List Nat := [1,4,8,16,17,17,9,21,0,29,9,0,24,8,1,17,25,9,29,1,17,17,17,0,25,16,9,25,0,8,13,17,21,17,8,0]

theorem envBound7031 : H12AffineFastState.Bounded env7031 := by
  intro p hp
  have h : env7031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7030_7031 : H12AffineEnvironment.transform 0 1 env7030 = env7031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env7030 == env7031) = true)

theorem identity7031 : scanCanonicalize (H12AffineFastState.compose env7031 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound7031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7032 : List Nat := [1,4,8,13,12,12,9,8,0,0,9,0,5,8,1,12,4,9,0,1,12,12,12,0,4,13,9,4,0,8,13,12,8,12,8,0]

theorem envBound7032 : H12AffineFastState.Bounded env7032 := by
  intro p hp
  have h : env7032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7031_7032 : H12AffineEnvironment.transform 3 13 env7031 = env7032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env7031 == env7032) = true)

def leafEnv7032 : List Nat := [1,4,8,13,12,12,9,8,0,0,9,0,5,8,1,12,4,9,0,1,12,12,12,0,13,4,1,13,9,4,0,8,13,12,8,12,4,13,8,0,1,13,0]

def active7032 : List Nat := [1,2]

def tree7032 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7032 : H12WitnessSearch.Good tree7032 := H12GlobalWitnessIndex.good

theorem leafIdentity7032 : H12AffineFastState.composeSystem env7032 rootObs = leafEnv7032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7032 rootObs == leafEnv7032) = true)

theorem terminalChecked7032 : H12PackedTerminal.terminalCheckFast leafEnv7032 active7032 tree7032 = true := by decide +kernel

def env7033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,16384,508,478,5393,262144,524288,508,17728,32,525804,375,41,525757,262281,5392,4097,2185,1364,341,525568,168,34359738368,512]

theorem envBound7033 : H12AffineFastState.Bounded env7033 := by
  intro p hp
  have h : env7033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6970_7033 : H12AffineEnvironment.transform 12 161 env6970 = env7033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env6970 == env7033) = true)

def env7034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,360618,268435456,268570624,1073741824,67674549,1086893389,525568,1073743905,34359738368,98851]

theorem envBound7034 : H12AffineFastState.Bounded env7034 := by
  intro p hp
  have h : env7034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6671_7034 : H12AffineEnvironment.transform 23 8988133 env6671 = env7034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8988133 env6671 == env7034) = true)

theorem identity7034 : scanCanonicalize (H12AffineFastState.compose env7034 (packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(29+1) ^^^ 13110596) := by decide +kernel

theorem selectedBound7034 : packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env7035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,360618,268435456,268570624,13110596,67674549,40969,525568,13108581,34359738368,98851]

theorem envBound7035 : H12AffineFastState.Bounded env7035 := by
  intro p hp
  have h : env7035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7034_7035 : H12AffineEnvironment.transform 29 13110596 env7034 = env7035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13110596 env7034 == env7035) = true)

def env7036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,360618,77615104,77742080,13110596,67674549,40969,525568,13108581,34359738368,98851]

theorem envBound7036 : H12AffineFastState.Bounded env7036 := by
  intro p hp
  have h : env7036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7035_7036 : H12AffineEnvironment.transform 27 77615104 env7035 = env7036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615104 env7035 == env7036) = true)

theorem identity7036 : scanCanonicalize (H12AffineFastState.compose env7036 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 566497) := by decide +kernel

theorem selectedBound7036 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env7037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,566497,360618,11072737,11199713,13110596,1364,40969,525568,13108581,34359738368,98851]

theorem envBound7037 : H12AffineFastState.Bounded env7037 := by
  intro p hp
  have h : env7037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7036_7037 : H12AffineEnvironment.transform 25 566497 env7036 = env7037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 566497 env7036 == env7037) = true)

def env7038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41088,8388608,8988133,8328,566497,360618,11072737,11199713,8957380,1364,40969,525568,8955365,34359738368,98851]

theorem envBound7038 : H12AffineFastState.Bounded env7038 := by
  intro p hp
  have h : env7038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7037_7038 : H12AffineEnvironment.transform 21 41088 env7037 = env7038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env7037 == env7038) = true)

def env7039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,62640,32768,2097152,41088,8388608,8507733,8328,20561,360618,10485841,10621009,8411508,1364,40969,61872,8409429,34359738368,98851]

theorem envBound7039 : H12AffineFastState.Bounded env7039 := by
  intro p hp
  have h : env7039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7038_7039 : H12AffineEnvironment.transform 18 62640 env7038 = env7039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62640 env7038 == env7039) = true)

theorem identity7039 : scanCanonicalize (H12AffineFastState.compose env7039 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 103731) := by decide +kernel

theorem selectedBound7039 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103731,262144,62640,32768,2097152,41088,8388608,8507733,8328,20561,360618,10485841,10585442,8411508,1364,40969,61872,8409429,34359738368,98851]

theorem envBound7040 : H12AffineFastState.Bounded env7040 := by
  intro p hp
  have h : env7040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7039_7040 : H12AffineEnvironment.transform 16 103731 env7039 = env7040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103731 env7039 == env7040) = true)

def env7041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103731,262144,62640,32768,2097152,41088,61600,74229,8328,20561,360618,2158833,2192834,43476,1364,40969,61872,41461,34359738368,98851]

theorem envBound7041 : H12AffineFastState.Bounded env7041 := by
  intro p hp
  have h : env7041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7040_7041 : H12AffineEnvironment.transform 22 61600 env7040 = env7041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61600 env7040 == env7041) = true)

theorem identity7041 : scanCanonicalize (H12AffineFastState.compose env7041 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound7041 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32803,5392,262144,62640,32768,2097152,41088,61600,41430,8328,20561,262281,2158833,2160097,43476,1364,40969,61872,41461,34359738368,512]

theorem envBound7042 : H12AffineFastState.Bounded env7042 := by
  intro p hp
  have h : env7042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7041_7042 : H12AffineEnvironment.transform 15 32803 env7041 = env7042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env7041 == env7042) = true)

theorem identity7042 : scanCanonicalize (H12AffineFastState.compose env7042 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7042 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env7043 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32803,5356,262144,62640,32768,2097152,41088,61600,41002,8328,20561,262281,2158833,2159645,43048,1192,40969,61516,40969,34359738368,512]

theorem envBound7043 : H12AffineFastState.Bounded env7043 := by
  intro p hp
  have h : env7043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7042_7043 : H12AffineEnvironment.transform 7 252 env7042 = env7043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7042 == env7043) = true)

def env7044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103731,262144,62640,32768,2097152,41088,61601,74228,8328,20561,360618,2158832,2192835,43477,1364,40969,61872,41460,34359738368,98851]

theorem envBound7044 : H12AffineFastState.Bounded env7044 := by
  intro p hp
  have h : env7044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7040_7044 : H12AffineEnvironment.transform 22 61601 env7040 = env7044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61601 env7040 == env7044) = true)

theorem identity7044 : scanCanonicalize (H12AffineFastState.compose env7044 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound7044 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,5356,262144,62640,32768,2097152,41088,61601,41003,8328,20561,262517,2158832,2159644,43477,1364,40969,61872,41460,34359738368,1020]

theorem envBound7045 : H12AffineFastState.Bounded env7045 := by
  intro p hp
  have h : env7045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7044_7045 : H12AffineEnvironment.transform 15 33247 env7044 = env7045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env7044 == env7045) = true)

theorem identity7045 : scanCanonicalize (H12AffineFastState.compose env7045 (packedSelected [11,18,21] rootPS)) = affineNative (2^(20+1) ^^^ 310484) := by decide +kernel

theorem selectedBound7045 : packedSelected [11,18,21] rootPS < 2^1333 := by decide +kernel

def env7046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,5356,262144,62640,32768,310484,41088,61601,41003,8328,20561,262517,281636,280776,43477,1364,40969,61872,41460,34359738368,1020]

theorem envBound7046 : H12AffineFastState.Bounded env7046 := by
  intro p hp
  have h : env7046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7045_7046 : H12AffineEnvironment.transform 20 310484 env7045 = env7046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 310484 env7045 == env7046) = true)

def env7047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,62641,32768,2097152,41088,8388608,8507732,8328,20560,360618,10485840,10621008,8411509,1364,40969,61873,8409428,34359738368,98851]

theorem envBound7047 : H12AffineFastState.Bounded env7047 := by
  intro p hp
  have h : env7047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7038_7047 : H12AffineEnvironment.transform 18 62641 env7038 = env7047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62641 env7038 == env7047) = true)

theorem identity7047 : scanCanonicalize (H12AffineFastState.compose env7047 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound7047 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5392,262144,62641,32768,2097152,41088,8388608,8507732,8328,20560,360618,10485840,10487104,8411509,1364,40969,61873,8409428,34359738368,98851]

theorem envBound7048 : H12AffineFastState.Bounded env7048 := by
  intro p hp
  have h : env7048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7047_7048 : H12AffineEnvironment.transform 16 5392 env7047 = env7048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env7047 == env7048) = true)

def env7049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5392,262144,62641,32768,2097152,41088,61600,74228,8328,20560,360618,2158832,2160096,43477,1364,40969,61873,41460,34359738368,98851]

theorem envBound7049 : H12AffineFastState.Bounded env7049 := by
  intro p hp
  have h : env7049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7048_7049 : H12AffineEnvironment.transform 22 61600 env7048 = env7049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61600 env7048 == env7049) = true)

theorem identity7049 : scanCanonicalize (H12AffineFastState.compose env7049 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound7049 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,5392,262144,62641,32768,2097152,41088,61600,41003,8328,20560,262517,2158832,2160096,43477,1364,40969,61873,41460,34359738368,1020]

theorem envBound7050 : H12AffineFastState.Bounded env7050 := by
  intro p hp
  have h : env7050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7049_7050 : H12AffineEnvironment.transform 15 33247 env7049 = env7050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env7049 == env7050) = true)

theorem identity7050 : scanCanonicalize (H12AffineFastState.compose env7050 (packedSelected [11,18,21] rootPS)) = affineNative (2^(20+1) ^^^ 310569) := by decide +kernel

theorem selectedBound7050 : packedSelected [11,18,21] rootPS < 2^1333 := by decide +kernel

def env7051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,5392,262144,62641,32768,310569,41088,61600,41003,8328,20560,262517,282073,280777,43477,1364,40969,61873,41460,34359738368,1020]

theorem envBound7051 : H12AffineFastState.Bounded env7051 := by
  intro p hp
  have h : env7051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7050_7051 : H12AffineEnvironment.transform 20 310569 env7050 = env7051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 310569 env7050 == env7051) = true)

def env7052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5392,262144,62641,32768,2097152,41088,61601,74229,8328,20560,360618,2158833,2160097,43476,1364,40969,61873,41461,34359738368,98851]

theorem envBound7052 : H12AffineFastState.Bounded env7052 := by
  intro p hp
  have h : env7052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7048_7052 : H12AffineEnvironment.transform 22 61601 env7048 = env7052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61601 env7048 == env7052) = true)

theorem identity7052 : scanCanonicalize (H12AffineFastState.compose env7052 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound7052 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32803,5392,262144,62641,32768,2097152,41088,61601,41430,8328,20560,262281,2158833,2160097,43476,1364,40969,61873,41461,34359738368,512]

theorem envBound7053 : H12AffineFastState.Bounded env7053 := by
  intro p hp
  have h : env7053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7052_7053 : H12AffineEnvironment.transform 15 32803 env7052 = env7053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env7052 == env7053) = true)

theorem identity7053 : scanCanonicalize (H12AffineFastState.compose env7053 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7053 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env7054 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32803,5356,262144,62641,32768,2097152,41088,61601,41002,8328,20560,262281,2158833,2159645,43048,1192,40969,61517,40969,34359738368,512]

theorem envBound7054 : H12AffineFastState.Bounded env7054 := by
  intro p hp
  have h : env7054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7053_7054 : H12AffineEnvironment.transform 7 252 env7053 = env7054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7053 == env7054) = true)

def env7055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41089,8388608,8988133,8328,566497,360618,11072737,11199713,8957381,1364,40969,525568,8955364,34359738368,98851]

theorem envBound7055 : H12AffineFastState.Bounded env7055 := by
  intro p hp
  have h : env7055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7037_7055 : H12AffineEnvironment.transform 21 41089 env7037 = env7055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env7037 == env7055) = true)

theorem identity7055 : scanCanonicalize (H12AffineFastState.compose env7055 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound7055 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env7056 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41089,8388608,8987672,8328,566497,360618,11072737,11199713,8956984,1193,40969,525565,8954905,34359738368,98851]

theorem envBound7056 : H12AffineFastState.Bounded env7056 := by
  intro p hp
  have h : env7056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7055_7056 : H12AffineEnvironment.transform 7 253 env7055 = env7056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7055 == env7056) = true)

theorem identity7056 : scanCanonicalize (H12AffineFastState.compose env7056 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound7056 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7057 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,32803,131072,262144,524288,32768,2097152,41089,8388608,8954939,8328,566497,262281,11072737,11199713,8956984,1193,40969,525565,8954905,34359738368,512]

theorem envBound7057 : H12AffineFastState.Bounded env7057 := by
  intro p hp
  have h : env7057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7056_7057 : H12AffineEnvironment.transform 15 32803 env7056 = env7057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env7056 == env7057) = true)

theorem identity7057 : scanCanonicalize (H12AffineFastState.compose env7057 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17597) := by decide +kernel

theorem selectedBound7057 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7058 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,32803,131072,262144,524288,32768,17597,41089,8388608,8954939,8328,566497,262281,8958044,9085020,8956984,1193,40969,525565,8954905,34359738368,512]

theorem envBound7058 : H12AffineFastState.Bounded env7058 := by
  intro p hp
  have h : env7058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7057_7058 : H12AffineEnvironment.transform 20 17597 env7057 = env7058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17597 env7057 == env7058) = true)

def env7059 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,131072,262144,524288,32768,17597,32801,8388608,8946843,40,558145,262281,8950012,9076988,8948888,1193,32937,525565,8946873,34359738368,512]

theorem envBound7059 : H12AffineFastState.Bounded env7059 := by
  intro p hp
  have h : env7059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7058_7059 : H12AffineEnvironment.transform 12 160 env7058 = env7059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7058 == env7059) = true)

theorem identity7059 : scanCanonicalize (H12AffineFastState.compose env7059 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(22+1) ^^^ 433188) := by decide +kernel

theorem selectedBound7059 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7060 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,131072,262144,524288,32768,17597,32801,433188,923839,40,558145,262281,920792,793816,921788,1193,32937,525565,923805,34359738368,512]

theorem envBound7060 : H12AffineFastState.Bounded env7060 := by
  intro p hp
  have h : env7060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7059_7060 : H12AffineEnvironment.transform 22 433188 env7059 = env7060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 433188 env7059 == env7060) = true)

theorem identity7060 : scanCanonicalize (H12AffineFastState.compose env7060 (packedSelected [1,2,3,4,6,9,11,14,18,20,24,28] rootPS)) = affineNative (2^(18+1) ^^^ 432181) := by decide +kernel

theorem selectedBound7060 : packedSelected [1,2,3,4,6,9,11,14,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env7061 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,131072,262144,432181,32768,17597,32801,433188,32906,40,400500,262281,38125,165101,34953,1193,32937,433352,32936,34359738368,512]

theorem envBound7061 : H12AffineFastState.Bounded env7061 := by
  intro p hp
  have h : env7061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7060_7061 : H12AffineEnvironment.transform 18 432181 env7060 = env7061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 432181 env7060 == env7061) = true)

theorem identity7061 : scanCanonicalize (H12AffineFastState.compose env7061 (packedSelected [2,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 182368) := by decide +kernel

theorem selectedBound7061 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7062 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,131072,182368,20565,32768,17597,32801,21572,32906,40,54292,182505,38125,165101,34953,1193,32937,21672,32936,34359738368,512]

theorem envBound7062 : H12AffineFastState.Bounded env7062 := by
  intro p hp
  have h : env7062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7061_7062 : H12AffineEnvironment.transform 17 182368 env7061 = env7062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182368 env7061 == env7062) = true)

theorem identity7062 : scanCanonicalize (H12AffineFastState.compose env7062 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 38124) := by decide +kernel

theorem selectedBound7062 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7063 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32803,38124,23692,20565,32768,17597,32801,21572,32906,40,54292,23557,38125,4097,34953,1193,32937,21672,32936,34359738368,512]

theorem envBound7063 : H12AffineFastState.Bounded env7063 := by
  intro p hp
  have h : env7063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7062_7063 : H12AffineEnvironment.transform 16 38124 env7062 = env7063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38124 env7062 == env7063) = true)

def env7064 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,262144,524288,32768,17597,32800,8388608,8946842,41,558144,262281,8950013,9076989,8948889,1193,32936,525565,8946872,34359738368,512]

theorem envBound7064 : H12AffineFastState.Bounded env7064 := by
  intro p hp
  have h : env7064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7058_7064 : H12AffineEnvironment.transform 12 161 env7058 = env7064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7058 == env7064) = true)

theorem identity7064 : scanCanonicalize (H12AffineFastState.compose env7064 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 432180) := by decide +kernel

theorem selectedBound7064 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7065 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,262144,432180,32768,17597,32800,8388608,8789166,41,400500,262281,8784073,8657097,8787117,1193,32936,433353,8789132,34359738368,512]

theorem envBound7065 : H12AffineFastState.Bounded env7065 := by
  intro p hp
  have h : env7065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7064_7065 : H12AffineEnvironment.transform 18 432180 env7064 = env7065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 432180 env7064 == env7065) = true)

def env7066 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,262144,432180,32768,17597,32800,8388608,8789166,41,400500,262281,8784073,8657097,8787117,1193,32936,433353,8789132,8702152,512]

theorem envBound7066 : H12AffineFastState.Bounded env7066 := by
  intro p hp
  have h : env7066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7065_7066 : H12AffineEnvironment.transform 34 8702152 env7065 = env7066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 8702152 env7065 == env7066) = true)

theorem identity7066 : scanCanonicalize (H12AffineFastState.compose env7066 (packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound7066 : packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7067 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,5357,262144,298201,32768,17597,32800,8388608,8652867,41,264345,262281,8657956,8657097,8650816,1193,32936,296996,8652897,8702152,512]

theorem envBound7067 : H12AffineFastState.Bounded env7067 := by
  intro p hp
  have h : env7067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7066_7067 : H12AffineEnvironment.transform 16 5357 env7066 = env7067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env7066 == env7067) = true)

theorem identity7067 : scanCanonicalize (H12AffineFastState.compose env7067 (packedSelected [4,9,11] rootPS)) = affineNative (2^(22+1) ^^^ 297161) := by decide +kernel

theorem selectedBound7067 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env7068 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,5357,262144,298201,32768,17597,32800,297161,32906,41,264345,262281,38125,36864,34953,1193,32936,296996,32936,16385,512]

theorem envBound7068 : H12AffineFastState.Bounded env7068 := by
  intro p hp
  have h : env7068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7067_7068 : H12AffineEnvironment.transform 22 297161 env7067 = env7068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297161 env7067 == env7068) = true)

theorem identity7068 : scanCanonicalize (H12AffineFastState.compose env7068 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound7068 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7069 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,5357,2080,34041,32768,17597,32800,33001,32906,41,185,2217,38125,36864,34953,1193,32936,32772,32936,16385,512]

theorem envBound7069 : H12AffineFastState.Bounded env7069 := by
  intro p hp
  have h : env7069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7068_7069 : H12AffineEnvironment.transform 17 2080 env7068 = env7069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env7068 == env7069) = true)

theorem identity7069 : scanCanonicalize (H12AffineFastState.compose env7069 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7069 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env7070 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,32768,32803,5188,2080,33872,32768,17428,32800,32832,32803,41,16,2048,37956,36864,34848,1024,32769,32772,32769,16385,512]

theorem envBound7070 : H12AffineFastState.Bounded env7070 := by
  intro p hp
  have h : env7070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7069_7070 : H12AffineEnvironment.transform 6 41 env7069 = env7070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7069 == env7070) = true)

theorem identity7070 : scanCanonicalize (H12AffineFastState.compose env7070 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2107) := by decide +kernel

theorem selectedBound7070 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7071 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,2107,32768,32803,5188,2080,33872,32768,3119,32800,32832,32803,41,16,2048,37956,36864,34848,1024,32769,32772,32769,2106,512]

theorem envBound7071 : H12AffineFastState.Bounded env7071 := by
  intro p hp
  have h : env7071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7070_7071 : H12AffineEnvironment.transform 13 2107 env7070 = env7071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2107 env7070 == env7071) = true)

theorem identity7071 : scanCanonicalize (H12AffineFastState.compose env7071 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 1093) := by decide +kernel

theorem selectedBound7071 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env7072 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,2107,1093,1126,5188,2080,21,1093,3119,1125,1029,1126,41,16,2048,4097,5189,3173,1024,1092,1089,1092,2106,512]

theorem envBound7072 : H12AffineFastState.Bounded env7072 := by
  intro p hp
  have h : env7072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7071_7072 : H12AffineEnvironment.transform 14 1093 env7071 = env7072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1093 env7071 == env7072) = true)

theorem identity7072 : scanCanonicalize (H12AffineFastState.compose env7072 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound7072 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7073 : List Nat := [2,4,8,16,32,64,41,84,512,69,2048,4096,8,2107,0,35,4097,2080,21,0,2154,32,64,35,41,16,2048,4097,4096,2080,69,1,4,1,2106,512]

theorem envBound7073 : H12AffineFastState.Bounded env7073 := by
  intro p hp
  have h : env7073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7072_7073 : H12AffineEnvironment.transform 9 69 env7072 = env7073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env7072 == env7073) = true)

theorem identity7073 : scanCanonicalize (H12AffineFastState.compose env7073 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound7073 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7074 : List Nat := [2,4,8,16,32,16,41,4,512,21,2048,4096,8,2107,0,35,4097,2080,21,0,2106,32,16,35,41,16,2048,4097,4096,2080,21,1,4,1,2106,512]

theorem envBound7074 : H12AffineFastState.Bounded env7074 := by
  intro p hp
  have h : env7074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7073_7074 : H12AffineEnvironment.transform 5 16 env7073 = env7074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env7073 == env7074) = true)

theorem identity7074 : scanCanonicalize (H12AffineFastState.compose env7074 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound7074 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7075 : List Nat := [2,4,8,16,32,16,41,4,512,21,17,4096,8,42,0,35,4097,49,21,0,43,32,16,35,41,16,17,4097,4096,49,21,1,4,1,43,512]

theorem envBound7075 : H12AffineFastState.Bounded env7075 := by
  intro p hp
  have h : env7075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7074_7075 : H12AffineEnvironment.transform 10 17 env7074 = env7075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env7074 == env7075) = true)

theorem identity7075 : scanCanonicalize (H12AffineFastState.compose env7075 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound7075 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7076 : List Nat := [2,4,8,16,0,16,9,4,512,21,17,4096,8,10,0,3,4097,17,21,0,11,0,16,3,9,16,17,4097,4096,17,21,1,4,1,11,512]

theorem envBound7076 : H12AffineFastState.Bounded env7076 := by
  intro p hp
  have h : env7076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7075_7076 : H12AffineEnvironment.transform 4 0 env7075 = env7076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env7075 == env7076) = true)

theorem identity7076 : scanCanonicalize (H12AffineFastState.compose env7076 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 520) := by decide +kernel

theorem selectedBound7076 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7077 : List Nat := [2,4,8,16,0,16,9,4,512,21,17,520,8,10,0,3,521,17,21,0,11,0,16,3,9,16,17,521,520,17,21,1,4,1,11,512]

theorem envBound7077 : H12AffineFastState.Bounded env7077 := by
  intro p hp
  have h : env7077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7076_7077 : H12AffineEnvironment.transform 11 520 env7076 = env7077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 520 env7076 == env7077) = true)

theorem identity7077 : scanCanonicalize (H12AffineFastState.compose env7077 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound7077 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7078 : List Nat := [2,4,8,16,0,16,9,4,7,21,17,15,8,10,0,3,14,17,21,0,11,0,16,3,9,16,17,14,15,17,21,1,4,1,11,7]

theorem envBound7078 : H12AffineFastState.Bounded env7078 := by
  intro p hp
  have h : env7078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7077_7078 : H12AffineEnvironment.transform 8 7 env7077 = env7078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env7077 == env7078) = true)

def env7079 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,262144,432180,32768,17597,32800,8388608,8789166,41,400500,262281,8784073,8657097,8787117,1193,32936,433353,8789132,8702153,512]

theorem envBound7079 : H12AffineFastState.Bounded env7079 := by
  intro p hp
  have h : env7079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7065_7079 : H12AffineEnvironment.transform 34 8702153 env7065 = env7079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 8702153 env7065 == env7079) = true)

theorem identity7079 : scanCanonicalize (H12AffineFastState.compose env7079 (packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound7079 : packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7080 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,2185,168125,32768,17597,32800,8388608,8524839,41,136445,2048,8519744,8392768,8526884,1193,32936,169024,8524805,8437824,512]

theorem envBound7080 : H12AffineFastState.Bounded env7080 := by
  intro p hp
  have h : env7080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7079_7080 : H12AffineEnvironment.transform 17 2185 env7079 = env7080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env7079 == env7080) = true)

theorem identity7080 : scanCanonicalize (H12AffineFastState.compose env7080 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 64) := by decide +kernel

theorem selectedBound7080 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env7081 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,131072,2185,168125,32768,17597,32800,64,136295,41,136445,2048,131072,4096,138340,1193,32936,169024,136261,49152,512]

theorem envBound7081 : H12AffineFastState.Bounded env7081 := by
  intro p hp
  have h : env7081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7080_7081 : H12AffineEnvironment.transform 22 64 env7080 = env7081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 64 env7080 == env7081) = true)

theorem identity7081 : scanCanonicalize (H12AffineFastState.compose env7081 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound7081 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7082 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32803,5357,2185,33872,32768,17597,32800,64,138,41,16,2048,5357,4096,2185,1193,32936,32941,168,49152,512]

theorem envBound7082 : H12AffineFastState.Bounded env7082 := by
  intro p hp
  have h : env7082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7081_7082 : H12AffineEnvironment.transform 16 5357 env7081 = env7082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env7081 == env7082) = true)

theorem identity7082 : scanCanonicalize (H12AffineFastState.compose env7082 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound7082 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7083 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,0,35,5357,2185,1104,0,17597,32,64,138,41,16,2048,5357,4096,2185,1193,168,173,168,16384,512]

theorem envBound7083 : H12AffineFastState.Bounded env7083 := by
  intro p hp
  have h : env7083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7082_7083 : H12AffineEnvironment.transform 14 0 env7082 = env7083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env7082 == env7083) = true)

theorem identity7083 : scanCanonicalize (H12AffineFastState.compose env7083 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound7083 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7084 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,88,16384,0,35,5140,2160,1104,0,17476,32,64,115,41,16,2048,5140,4096,2160,1104,81,84,81,16384,512]

theorem envBound7084 : H12AffineFastState.Bounded env7084 := by
  intro p hp
  have h : env7084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7083_7084 : H12AffineEnvironment.transform 6 121 env7083 = env7084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env7083 == env7084) = true)

theorem identity7084 : scanCanonicalize (H12AffineFastState.compose env7084 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound7084 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7085 : List Nat := [2,4,8,16,32,59,2,4,512,1024,2048,4096,35,16384,0,35,5140,2059,1067,0,17471,32,59,8,41,16,2048,5140,4096,2059,1067,42,47,42,16384,512]

theorem envBound7085 : H12AffineFastState.Bounded env7085 := by
  intro p hp
  have h : env7085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7084_7085 : H12AffineEnvironment.transform 5 59 env7084 = env7085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env7084 == env7085) = true)

theorem identity7085 : scanCanonicalize (H12AffineFastState.compose env7085 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound7085 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7086 : List Nat := [2,4,8,16,32,59,2,4,512,47,2048,4096,35,16384,0,35,4155,2059,4,0,16400,32,59,8,41,16,2048,4155,4096,2059,4,42,47,42,16384,512]

theorem envBound7086 : H12AffineFastState.Bounded env7086 := by
  intro p hp
  have h : env7086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7085_7086 : H12AffineEnvironment.transform 9 47 env7085 = env7086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env7085 == env7086) = true)

theorem identity7086 : scanCanonicalize (H12AffineFastState.compose env7086 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound7086 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7087 : List Nat := [2,4,8,16,1,26,2,4,512,14,2048,4096,2,16384,0,2,4122,2059,4,0,16400,1,26,8,8,16,2048,4122,4096,2059,4,11,14,11,16384,512]

theorem envBound7087 : H12AffineFastState.Bounded env7087 := by
  intro p hp
  have h : env7087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7086_7087 : H12AffineEnvironment.transform 4 1 env7086 = env7087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env7086 == env7087) = true)

theorem identity7087 : scanCanonicalize (H12AffineFastState.compose env7087 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound7087 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env7088 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,4096,2,16384,0,2,4112,2049,4,0,16400,1,16,2,2,16,2048,4112,4096,2049,4,1,4,1,16384,512]

theorem envBound7088 : H12AffineFastState.Bounded env7088 := by
  intro p hp
  have h : env7088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7087_7088 : H12AffineEnvironment.transform 2 2 env7087 = env7088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env7087 == env7088) = true)

def env7089 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,0,2,16384,0,2,16,2049,4,0,16400,1,16,2,2,16,2048,16,0,2049,4,1,4,1,16384,512]

theorem envBound7089 : H12AffineFastState.Bounded env7089 := by
  intro p hp
  have h : env7089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7088_7089 : H12AffineEnvironment.transform 11 0 env7088 = env7089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env7088 == env7089) = true)

theorem identity7089 : scanCanonicalize (H12AffineFastState.compose env7089 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 531) := by decide +kernel

theorem selectedBound7089 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7090 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,0,2,531,0,2,16,2049,4,0,515,1,16,2,2,16,2048,16,0,2049,4,1,4,1,531,512]

theorem envBound7090 : H12AffineFastState.Bounded env7090 := by
  intro p hp
  have h : env7090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7089_7090 : H12AffineEnvironment.transform 13 531 env7089 = env7090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 531 env7089 == env7090) = true)

def env7091 : List Nat := [2,4,2,16,1,16,2,4,0,4,2048,0,2,19,0,2,16,2049,4,0,3,1,16,2,2,16,2048,16,0,2049,4,1,4,1,19,0]

theorem envBound7091 : H12AffineFastState.Bounded env7091 := by
  intro p hp
  have h : env7091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7090_7091 : H12AffineEnvironment.transform 8 0 env7090 = env7091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env7090 == env7091) = true)

theorem identity7091 : scanCanonicalize (H12AffineFastState.compose env7091 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound7091 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7092 : List Nat := [2,4,2,7,1,7,2,4,0,4,2048,0,2,4,0,2,7,2049,4,0,3,1,7,2,2,7,2048,7,0,2049,4,1,4,1,4,0]

theorem envBound7092 : H12AffineFastState.Bounded env7092 := by
  intro p hp
  have h : env7092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7091_7092 : H12AffineEnvironment.transform 3 7 env7091 = env7092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env7091 == env7092) = true)

def leafEnv7092 : List Nat := [2,4,2,7,1,7,2,4,0,4,2048,0,2,4,0,2,7,2049,4,0,3,1,7,2,4,2,1,7,2048,7,0,2049,4,1,4,1,4,2,4,0,1,3,0]

def active7092 : List Nat := [0,1,10]

def tree7092 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7092 : H12WitnessSearch.Good tree7092 := H12GlobalWitnessIndex.good

theorem leafIdentity7092 : H12AffineFastState.composeSystem env7092 rootObs = leafEnv7092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7092 rootObs == leafEnv7092) = true)

theorem terminalChecked7092 : H12PackedTerminal.terminalCheckFast leafEnv7092 active7092 tree7092 = true := by decide +kernel

def env7093 : List Nat := [2,4,2,16,1,16,2,4,1,4,2048,0,2,18,0,2,16,2049,4,0,2,1,16,2,2,16,2048,16,0,2049,4,1,4,1,18,1]

theorem envBound7093 : H12AffineFastState.Bounded env7093 := by
  intro p hp
  have h : env7093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7090_7093 : H12AffineEnvironment.transform 8 1 env7090 = env7093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env7090 == env7093) = true)

theorem identity7093 : scanCanonicalize (H12AffineFastState.compose env7093 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound7093 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7094 : List Nat := [2,2,2,16,1,16,2,2,1,2,2048,0,2,18,0,2,16,2049,2,0,2,1,16,2,2,16,2048,16,0,2049,2,1,2,1,18,1]

theorem envBound7094 : H12AffineFastState.Bounded env7094 := by
  intro p hp
  have h : env7094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7093_7094 : H12AffineEnvironment.transform 1 2 env7093 = env7094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env7093 == env7094) = true)

def leafEnv7094 : List Nat := [2,2,2,16,1,16,2,2,1,2,2048,0,2,18,0,2,16,2049,2,0,2,1,16,2,2,2,1,16,2048,16,0,2049,2,1,2,1,2,2,18,1,1,2,0]

def active7094 : List Nat := [0,3,10]

def tree7094 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7094 : H12WitnessSearch.Good tree7094 := H12GlobalWitnessIndex.good

theorem leafIdentity7094 : H12AffineFastState.composeSystem env7094 rootObs = leafEnv7094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7094 rootObs == leafEnv7094) = true)

theorem terminalChecked7094 : H12PackedTerminal.terminalCheckFast leafEnv7094 active7094 tree7094 = true := by decide +kernel

def env7095 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,1,2,16384,0,2,17,2049,4,0,16400,1,16,2,2,16,2048,17,1,2049,4,1,4,1,16384,512]

theorem envBound7095 : H12AffineFastState.Bounded env7095 := by
  intro p hp
  have h : env7095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7088_7095 : H12AffineEnvironment.transform 11 1 env7088 = env7095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env7088 == env7095) = true)

theorem identity7095 : scanCanonicalize (H12AffineFastState.compose env7095 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 515) := by decide +kernel

theorem selectedBound7095 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7096 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,1,2,515,0,2,17,2049,4,0,531,1,16,2,2,16,2048,17,1,2049,4,1,4,1,515,512]

theorem envBound7096 : H12AffineFastState.Bounded env7096 := by
  intro p hp
  have h : env7096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7095_7096 : H12AffineEnvironment.transform 13 515 env7095 = env7096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 515 env7095 == env7096) = true)

def env7097 : List Nat := [2,4,2,16,1,16,2,4,0,4,2048,1,2,3,0,2,17,2049,4,0,19,1,16,2,2,16,2048,17,1,2049,4,1,4,1,3,0]

theorem envBound7097 : H12AffineFastState.Bounded env7097 := by
  intro p hp
  have h : env7097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7096_7097 : H12AffineEnvironment.transform 8 0 env7096 = env7097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env7096 == env7097) = true)

theorem identity7097 : scanCanonicalize (H12AffineFastState.compose env7097 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound7097 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7098 : List Nat := [2,2,2,16,1,16,2,2,0,2,2048,1,2,3,0,2,17,2049,2,0,19,1,16,2,2,16,2048,17,1,2049,2,1,2,1,3,0]

theorem envBound7098 : H12AffineFastState.Bounded env7098 := by
  intro p hp
  have h : env7098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7097_7098 : H12AffineEnvironment.transform 1 2 env7097 = env7098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env7097 == env7098) = true)

def leafEnv7098 : List Nat := [2,2,2,16,1,16,2,2,0,2,2048,1,2,3,0,2,17,2049,2,0,19,1,16,2,2,2,1,16,2048,17,1,2049,2,1,2,1,2,2,3,0,1,19,0]

def active7098 : List Nat := [0,3,10]

def tree7098 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7098 : H12WitnessSearch.Good tree7098 := H12GlobalWitnessIndex.good

theorem leafIdentity7098 : H12AffineFastState.composeSystem env7098 rootObs = leafEnv7098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7098 rootObs == leafEnv7098) = true)

theorem terminalChecked7098 : H12PackedTerminal.terminalCheckFast leafEnv7098 active7098 tree7098 = true := by decide +kernel

def env7099 : List Nat := [2,4,2,16,1,16,2,4,1,4,2048,1,2,2,0,2,17,2049,4,0,18,1,16,2,2,16,2048,17,1,2049,4,1,4,1,2,1]

theorem envBound7099 : H12AffineFastState.Bounded env7099 := by
  intro p hp
  have h : env7099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7096_7099 : H12AffineEnvironment.transform 8 1 env7096 = env7099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env7096 == env7099) = true)

theorem identity7099 : scanCanonicalize (H12AffineFastState.compose env7099 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound7099 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7100 : List Nat := [2,4,2,7,1,7,2,4,1,4,2048,1,2,2,0,2,6,2049,4,0,5,1,7,2,2,7,2048,6,1,2049,4,1,4,1,2,1]

theorem envBound7100 : H12AffineFastState.Bounded env7100 := by
  intro p hp
  have h : env7100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7099_7100 : H12AffineEnvironment.transform 3 7 env7099 = env7100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env7099 == env7100) = true)

def leafEnv7100 : List Nat := [2,4,2,7,1,7,2,4,1,4,2048,1,2,2,0,2,6,2049,4,0,5,1,7,2,4,2,1,7,2048,6,1,2049,4,1,4,1,4,2,2,1,1,5,0]

def active7100 : List Nat := [0,1,10]

def tree7100 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7100 : H12WitnessSearch.Good tree7100 := H12GlobalWitnessIndex.good

theorem leafIdentity7100 : H12AffineFastState.composeSystem env7100 rootObs = leafEnv7100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7100 rootObs == leafEnv7100) = true)

theorem terminalChecked7100 : H12PackedTerminal.terminalCheckFast leafEnv7100 active7100 tree7100 = true := by decide +kernel

def env7101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,360618,77615105,77742081,13110596,67674549,40969,525568,13108581,34359738368,98851]

theorem envBound7101 : H12AffineFastState.Bounded env7101 := by
  intro p hp
  have h : env7101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7035_7101 : H12AffineEnvironment.transform 27 77615105 env7035 = env7101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615105 env7035 == env7101) = true)

theorem identity7101 : scanCanonicalize (H12AffineFastState.compose env7101 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 599234) := by decide +kernel

theorem selectedBound7101 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env7102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,599234,360618,11105475,11232451,13110596,99703,40969,525568,13108581,34359738368,98851]

theorem envBound7102 : H12AffineFastState.Bounded env7102 := by
  intro p hp
  have h : env7102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7101_7102 : H12AffineEnvironment.transform 25 599234 env7101 = env7102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 599234 env7101 == env7102) = true)

def env7103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41088,8388608,8988133,8328,599234,360618,11105475,11232451,8957380,99703,40969,525568,8955365,34359738368,98851]

theorem envBound7103 : H12AffineFastState.Bounded env7103 := by
  intro p hp
  have h : env7103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7102_7103 : H12AffineEnvironment.transform 21 41088 env7102 = env7103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env7102 == env7103) = true)

def env7104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,62640,32768,2097152,41088,8388608,8507733,8328,118898,360618,10584179,10719347,8411508,99703,40969,61872,8409429,34359738368,98851]

theorem envBound7104 : H12AffineFastState.Bounded env7104 := by
  intro p hp
  have h : env7104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7103_7104 : H12AffineEnvironment.transform 18 62640 env7103 = env7104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62640 env7103 == env7104) = true)

theorem identity7104 : scanCanonicalize (H12AffineFastState.compose env7104 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound7104 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5393,262144,62640,32768,2097152,41088,8388608,8507733,8328,118898,360618,10584179,10585442,8411508,99703,40969,61872,8409429,34359738368,98851]

theorem envBound7105 : H12AffineFastState.Bounded env7105 := by
  intro p hp
  have h : env7105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7104_7105 : H12AffineEnvironment.transform 16 5393 env7104 = env7105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env7104 == env7105) = true)

def env7106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5393,262144,62640,32768,2097152,41088,20480,98645,8328,118898,360618,2216051,2217314,2420,99703,40969,61872,341,34359738368,98851]

theorem envBound7106 : H12AffineFastState.Bounded env7106 := by
  intro p hp
  have h : env7106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7105_7106 : H12AffineEnvironment.transform 22 20480 env7105 = env7106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env7105 == env7106) = true)

def env7107 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,5357,262144,62640,32768,2097152,41088,20480,98473,8328,118898,360618,2216051,2217118,2184,99467,40969,61516,169,34359738368,98851]

theorem envBound7107 : H12AffineFastState.Bounded env7107 := by
  intro p hp
  have h : env7107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7106_7107 : H12AffineEnvironment.transform 7 252 env7106 = env7107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7106 == env7107) = true)

theorem identity7107 : scanCanonicalize (H12AffineFastState.compose env7107 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 367703) := by decide +kernel

theorem selectedBound7107 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7108 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,5357,262144,62640,32768,367703,41088,20480,98473,8328,118898,360618,281636,280777,2184,99467,40969,61516,169,34359738368,98851]

theorem envBound7108 : H12AffineFastState.Bounded env7108 := by
  intro p hp
  have h : env7108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7107_7108 : H12AffineEnvironment.transform 20 367703 env7107 = env7108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 367703 env7107 == env7108) = true)

theorem identity7108 : scanCanonicalize (H12AffineFastState.compose env7108 (packedSelected [11,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound7108 : packedSelected [11,17,18] rootPS < 2^1333 := by decide +kernel

def env7109 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,5357,262144,21520,8352,343287,32,20480,73737,8328,94418,335882,281636,280777,2184,74795,169,20716,169,34359738368,74371]

theorem envBound7109 : H12AffineFastState.Bounded env7109 := by
  intro p hp
  have h : env7109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7108_7109 : H12AffineEnvironment.transform 14 8352 env7108 = env7109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env7108 == env7109) = true)

theorem identity7109 : scanCanonicalize (H12AffineFastState.compose env7109 (packedSelected [2,13,14] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound7109 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7110 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,5357,262144,21520,8352,343287,32,20480,73737,8328,94418,335882,281636,280777,2184,74795,169,20716,169,280712,74371]

theorem envBound7110 : H12AffineFastState.Bounded env7110 := by
  intro p hp
  have h : env7110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7109_7110 : H12AffineEnvironment.transform 34 280712 env7109 = env7110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env7109 == env7110) = true)

theorem identity7110 : scanCanonicalize (H12AffineFastState.compose env7110 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 7846) := by decide +kernel

theorem selectedBound7110 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7111 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,65536,5357,262144,2742,8352,343287,32,3750,73737,8328,77428,335882,266882,267887,2184,74795,169,3658,169,267822,74371]

theorem envBound7111 : H12AffineFastState.Bounded env7111 := by
  intro p hp
  have h : env7111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7110_7111 : H12AffineEnvironment.transform 13 7846 env7110 = env7111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7846 env7110 == env7111) = true)

def env7112 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2800,5357,262144,2742,8352,275975,32,3750,11001,8328,9348,273146,266882,267887,2184,11995,169,3658,169,267822,10355]

theorem envBound7112 : H12AffineFastState.Bounded env7112 := by
  intro p hp
  have h : env7112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7111_7112 : H12AffineEnvironment.transform 15 2800 env7111 = env7112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2800 env7111 == env7112) = true)

theorem identity7112 : scanCanonicalize (H12AffineFastState.compose env7112 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 4842) := by decide +kernel

theorem selectedBound7112 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7113 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,4842,7846,4682,2800,5357,262144,2742,4682,263405,32,3750,6163,4706,5742,268304,266882,267887,2184,7217,169,3658,169,267822,6809]

theorem envBound7113 : H12AffineFastState.Bounded env7113 := by
  intro p hp
  have h : env7113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7112_7113 : H12AffineEnvironment.transform 12 4842 env7112 = env7113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4842 env7112 == env7113) = true)

theorem identity7113 : scanCanonicalize (H12AffineFastState.compose env7113 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 723) := by decide +kernel

theorem selectedBound7113 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7114 : List Nat := [2,4,8,16,32,64,128,252,512,1024,723,4096,4842,5237,4682,35,5357,262144,101,4682,263405,32,1141,4800,4706,5742,266947,266882,267887,603,5858,169,1177,169,267822,4170]

theorem envBound7114 : H12AffineFastState.Bounded env7114 := by
  intro p hp
  have h : env7114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7113_7114 : H12AffineEnvironment.transform 10 723 env7113 = env7114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 723 env7113 == env7114) = true)

theorem identity7114 : scanCanonicalize (H12AffineFastState.compose env7114 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound7114 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env7115 : List Nat := [2,4,8,16,32,64,128,252,512,69,723,4096,4842,4144,4682,35,4264,262144,101,4682,262312,32,48,4800,4706,4651,266947,266882,266794,603,4775,169,220,169,266859,4170]

theorem envBound7115 : H12AffineFastState.Bounded env7115 := by
  intro p hp
  have h : env7115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7114_7115 : H12AffineEnvironment.transform 9 69 env7114 = env7115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env7114 == env7115) = true)

theorem identity7115 : scanCanonicalize (H12AffineFastState.compose env7115 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 586) := by decide +kernel

theorem selectedBound7115 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7116 : List Nat := [2,4,8,16,32,64,128,252,512,69,723,586,160,634,0,35,738,262144,101,0,262312,32,48,138,40,97,262281,262344,262240,603,237,169,220,169,262177,512]

theorem envBound7116 : H12AffineFastState.Bounded env7116 := by
  intro p hp
  have h : env7116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7115_7116 : H12AffineEnvironment.transform 11 586 env7115 = env7116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 586 env7115 == env7116) = true)

theorem identity7116 : scanCanonicalize (H12AffineFastState.compose env7116 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 743) := by decide +kernel

theorem selectedBound7116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7117 : List Nat := [2,4,8,16,32,64,128,252,512,69,723,586,160,634,0,35,738,743,101,0,591,32,48,138,40,97,622,559,647,603,237,169,220,169,710,512]

theorem envBound7117 : H12AffineFastState.Bounded env7117 := by
  intro p hp
  have h : env7117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7116_7117 : H12AffineEnvironment.transform 17 743 env7116 = env7117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 743 env7116 == env7117) = true)

def env7118 : List Nat := [2,4,8,16,32,64,60,64,512,69,623,586,28,634,0,35,606,603,101,0,591,32,48,54,40,97,622,559,571,603,81,21,96,21,634,512]

theorem envBound7118 : H12AffineFastState.Bounded env7118 := by
  intro p hp
  have h : env7118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7117_7118 : H12AffineEnvironment.transform 6 60 env7117 = env7118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 60 env7117 == env7118) = true)

theorem identity7118 : scanCanonicalize (H12AffineFastState.compose env7118 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound7118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7119 : List Nat := [2,4,8,16,13,64,17,64,512,69,578,586,28,599,0,14,606,603,72,0,591,13,29,27,5,76,579,514,534,603,81,21,77,21,599,512]

theorem envBound7119 : H12AffineFastState.Bounded env7119 := by
  intro p hp
  have h : env7119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7118_7119 : H12AffineEnvironment.transform 4 13 env7118 = env7119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env7118 == env7119) = true)

theorem identity7119 : scanCanonicalize (H12AffineFastState.compose env7119 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 67) := by decide +kernel

theorem selectedBound7119 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7120 : List Nat := [2,4,8,16,13,64,17,64,67,69,1,9,28,20,0,14,29,24,72,0,12,13,29,27,5,76,0,65,85,24,81,21,77,21,20,67]

theorem envBound7120 : H12AffineFastState.Bounded env7120 := by
  intro p hp
  have h : env7120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7119_7120 : H12AffineEnvironment.transform 8 67 env7119 = env7120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 67 env7119 == env7120) = true)

def leafEnv7120 : List Nat := [2,4,8,16,13,64,17,64,67,69,1,9,28,20,0,14,29,24,72,0,12,13,29,27,93,5,1,76,0,65,85,24,81,21,77,21,8,23,20,67,1,13,0]

def active7120 : List Nat := [0,1,2,3,5]

def tree7120 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7120 : H12WitnessSearch.Good tree7120 := H12GlobalWitnessIndex.good

theorem leafIdentity7120 : H12AffineFastState.composeSystem env7120 rootObs = leafEnv7120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7120 rootObs == leafEnv7120) = true)

theorem terminalChecked7120 : H12PackedTerminal.terminalCheckFast leafEnv7120 active7120 tree7120 = true := by decide +kernel

def env7121 : List Nat := [2,4,8,16,32,64,61,65,512,69,622,586,29,634,0,35,607,602,101,0,591,32,48,55,40,97,622,559,570,603,80,20,97,20,635,512]

theorem envBound7121 : H12AffineFastState.Bounded env7121 := by
  intro p hp
  have h : env7121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7117_7121 : H12AffineEnvironment.transform 6 61 env7117 = env7121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 61 env7117 == env7121) = true)

theorem identity7121 : scanCanonicalize (H12AffineFastState.compose env7121 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 118) := by decide +kernel

theorem selectedBound7121 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7122 : List Nat := [2,4,8,16,32,64,61,65,118,69,24,60,29,12,0,35,41,44,101,0,57,32,48,55,40,97,24,89,76,45,80,20,97,20,13,118]

theorem envBound7122 : H12AffineFastState.Bounded env7122 := by
  intro p hp
  have h : env7122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7121_7122 : H12AffineEnvironment.transform 8 118 env7121 = env7122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 118 env7121 == env7122) = true)

theorem identity7122 : scanCanonicalize (H12AffineFastState.compose env7122 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound7122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7123 : List Nat := [2,4,8,16,12,64,17,65,90,69,24,16,29,12,0,15,5,0,73,0,21,12,28,27,4,77,24,89,76,1,80,20,77,20,13,90]

theorem envBound7123 : H12AffineFastState.Bounded env7123 := by
  intro p hp
  have h : env7123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7122_7123 : H12AffineEnvironment.transform 4 12 env7122 = env7123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env7122 == env7123) = true)

def leafEnv7123 : List Nat := [2,4,8,16,12,64,17,65,90,69,24,16,29,12,0,15,5,0,73,0,21,12,28,27,93,4,1,77,24,89,76,1,80,20,77,20,9,22,13,90,1,21,0]

def active7123 : List Nat := [0,1,2,3,5]

def tree7123 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7123 : H12WitnessSearch.Good tree7123 := H12GlobalWitnessIndex.good

theorem leafIdentity7123 : H12AffineFastState.composeSystem env7123 rootObs = leafEnv7123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7123 rootObs == leafEnv7123) = true)

theorem terminalChecked7123 : H12PackedTerminal.terminalCheckFast leafEnv7123 active7123 tree7123 = true := by decide +kernel

def env7124 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2801,5357,262144,2742,8352,275974,32,3750,11000,8328,9349,273147,266882,267887,2184,11994,169,3658,169,267822,10354]

theorem envBound7124 : H12AffineFastState.Bounded env7124 := by
  intro p hp
  have h : env7124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7111_7124 : H12AffineEnvironment.transform 15 2801 env7111 = env7124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2801 env7111 == env7124) = true)

theorem identity7124 : scanCanonicalize (H12AffineFastState.compose env7124 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(17+1) ^^^ 4112) := by decide +kernel

theorem selectedBound7124 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7125 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7846,8352,2801,5357,4112,2742,8352,9750,32,3750,11000,8328,9349,15083,658,1663,2184,11994,169,3658,169,1598,10354]

theorem envBound7125 : H12AffineFastState.Bounded env7125 := by
  intro p hp
  have h : env7125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7124_7125 : H12AffineEnvironment.transform 17 4112 env7124 = env7125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4112 env7124 == env7125) = true)

theorem identity7125 : scanCanonicalize (H12AffineFastState.compose env7125 (packedSelected [13] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound7125 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7126 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,7846,0,2801,5357,4112,2742,0,1718,32,3750,2648,40,1061,6731,658,1663,2184,3706,169,3658,169,1598,2258]

theorem envBound7126 : H12AffineFastState.Bounded env7126 := by
  intro p hp
  have h : env7126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7125_7126 : H12AffineEnvironment.transform 12 160 env7125 = env7126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7125 == env7126) = true)

theorem identity7126 : scanCanonicalize (H12AffineFastState.compose env7126 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7126 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env7127 : List Nat := [2,4,8,16,32,64,128,252,512,68,2048,4096,160,6882,0,2801,4265,4112,2742,0,754,32,2786,2648,40,97,6731,658,571,2184,2622,169,2574,169,634,2258]

theorem envBound7127 : H12AffineFastState.Bounded env7127 := by
  intro p hp
  have h : env7127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7126_7127 : H12AffineEnvironment.transform 9 68 env7126 = env7127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7126 == env7127) = true)

theorem identity7127 : scanCanonicalize (H12AffineFastState.compose env7127 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 722) := by decide +kernel

theorem selectedBound7127 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env7128 : List Nat := [2,4,8,16,32,64,128,252,512,68,722,4096,160,4144,0,35,4265,4112,100,0,754,32,48,138,40,97,4249,658,571,602,236,169,220,169,634,512]

theorem envBound7128 : H12AffineFastState.Bounded env7128 := by
  intro p hp
  have h : env7128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7127_7128 : H12AffineEnvironment.transform 10 722 env7127 = env7128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 722 env7127 == env7128) = true)

theorem identity7128 : scanCanonicalize (H12AffineFastState.compose env7128 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound7128 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env7129 : List Nat := [2,4,8,16,32,36,128,152,512,32,694,4096,160,4144,0,35,4265,4112,0,0,662,32,48,138,40,5,4249,658,571,574,136,169,184,169,542,512]

theorem envBound7129 : H12AffineFastState.Bounded env7129 := by
  intro p hp
  have h : env7129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7128_7129 : H12AffineEnvironment.transform 5 36 env7128 = env7129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env7128 == env7129) = true)

def env7130 : List Nat := [2,4,8,16,32,36,128,152,512,32,694,152,160,168,0,35,49,136,0,0,662,32,48,138,40,5,1,658,571,574,136,169,184,169,542,512]

theorem envBound7130 : H12AffineFastState.Bounded env7130 := by
  intro p hp
  have h : env7130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7129_7130 : H12AffineEnvironment.transform 11 152 env7129 = env7130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env7129 == env7130) = true)

theorem identity7130 : scanCanonicalize (H12AffineFastState.compose env7130 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound7130 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7131 : List Nat := [2,4,8,16,24,28,128,152,512,24,654,152,152,144,0,27,9,136,0,0,662,24,8,138,16,5,1,658,515,518,136,145,128,145,542,512]

theorem envBound7131 : H12AffineFastState.Bounded env7131 := by
  intro p hp
  have h : env7131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7130_7131 : H12AffineEnvironment.transform 4 24 env7130 = env7131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env7130 == env7131) = true)

def env7132 : List Nat := [2,4,8,16,24,28,8,16,512,24,518,16,16,24,0,27,9,0,0,0,542,24,8,2,16,5,1,538,515,518,0,25,8,25,542,512]

theorem envBound7132 : H12AffineFastState.Bounded env7132 := by
  intro p hp
  have h : env7132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7131_7132 : H12AffineEnvironment.transform 6 8 env7131 = env7132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7131 == env7132) = true)

theorem identity7132 : scanCanonicalize (H12AffineFastState.compose env7132 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound7132 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7133 : List Nat := [2,4,8,16,24,28,8,16,6,24,0,16,16,24,0,27,9,0,0,0,24,24,8,2,16,5,1,28,5,0,0,25,8,25,24,6]

theorem envBound7133 : H12AffineFastState.Bounded env7133 := by
  intro p hp
  have h : env7133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7132_7133 : H12AffineEnvironment.transform 8 6 env7132 = env7133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env7132 == env7133) = true)

def leafEnv7133 : List Nat := [2,4,8,16,24,28,8,16,6,24,0,16,16,24,0,27,9,0,0,0,24,24,8,2,25,16,1,5,1,28,5,0,0,25,8,25,29,27,24,6,1,25,0]

def active7133 : List Nat := [0,1,2,3]

def tree7133 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7133 : H12WitnessSearch.Good tree7133 := H12GlobalWitnessIndex.good

theorem leafIdentity7133 : H12AffineFastState.composeSystem env7133 rootObs = leafEnv7133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7133 rootObs == leafEnv7133) = true)

theorem terminalChecked7133 : H12PackedTerminal.terminalCheckFast leafEnv7133 active7133 tree7133 = true := by decide +kernel

def env7134 : List Nat := [2,4,8,16,24,28,9,17,512,24,519,17,17,25,0,27,9,1,0,0,543,24,8,3,16,5,1,539,515,518,1,24,9,24,542,512]

theorem envBound7134 : H12AffineFastState.Bounded env7134 := by
  intro p hp
  have h : env7134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7131_7134 : H12AffineEnvironment.transform 6 9 env7131 = env7134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7131 == env7134) = true)

def leafEnv7134 : List Nat := [2,4,8,16,24,28,9,17,512,24,519,17,17,25,0,27,9,1,0,0,543,24,8,3,24,16,1,5,1,539,515,518,1,24,9,24,29,26,542,512,1,25,0]

def active7134 : List Nat := [0,1,2,3,8]

def tree7134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7134 : H12WitnessSearch.Good tree7134 := H12GlobalWitnessIndex.good

theorem leafIdentity7134 : H12AffineFastState.composeSystem env7134 rootObs = leafEnv7134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7134 rootObs == leafEnv7134) = true)

theorem terminalChecked7134 : H12PackedTerminal.terminalCheckFast leafEnv7134 active7134 tree7134 = true := by decide +kernel

def env7135 : List Nat := [2,4,8,16,32,36,128,152,512,32,694,153,160,169,0,35,48,137,0,0,662,32,48,138,40,5,0,658,571,574,136,169,184,169,542,512]

theorem envBound7135 : H12AffineFastState.Bounded env7135 := by
  intro p hp
  have h : env7135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7129_7135 : H12AffineEnvironment.transform 11 153 env7129 = env7135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env7129 == env7135) = true)

theorem identity7135 : scanCanonicalize (H12AffineFastState.compose env7135 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound7135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7136 : List Nat := [2,4,8,16,32,36,128,152,142,32,56,153,160,169,0,35,48,137,0,0,24,32,48,138,40,5,0,28,181,176,136,169,184,169,144,142]

theorem envBound7136 : H12AffineFastState.Bounded env7136 := by
  intro p hp
  have h : env7136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7135_7136 : H12AffineEnvironment.transform 8 142 env7135 = env7136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env7135 == env7136) = true)

def env7137 : List Nat := [2,4,8,16,32,36,48,40,62,32,56,41,16,25,0,35,48,57,0,0,24,32,48,58,40,5,0,28,5,0,56,25,8,25,32,62]

theorem envBound7137 : H12AffineFastState.Bounded env7137 := by
  intro p hp
  have h : env7137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7136_7137 : H12AffineEnvironment.transform 6 48 env7136 = env7137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 48 env7136 == env7137) = true)

theorem identity7137 : scanCanonicalize (H12AffineFastState.compose env7137 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound7137 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7138 : List Nat := [2,4,8,16,24,28,8,16,6,24,0,17,16,25,0,27,8,1,0,0,24,24,8,2,16,5,0,28,5,0,0,25,8,25,24,6]

theorem envBound7138 : H12AffineFastState.Bounded env7138 := by
  intro p hp
  have h : env7138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7137_7138 : H12AffineEnvironment.transform 4 24 env7137 = env7138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env7137 == env7138) = true)

def leafEnv7138 : List Nat := [2,4,8,16,24,28,8,16,6,24,0,17,16,25,0,27,8,1,0,0,24,24,8,2,25,16,1,5,0,28,5,0,0,25,8,25,29,27,24,6,1,24,0]

def active7138 : List Nat := [0,1,2,3]

def tree7138 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7138 : H12WitnessSearch.Good tree7138 := H12GlobalWitnessIndex.good

theorem leafIdentity7138 : H12AffineFastState.composeSystem env7138 rootObs = leafEnv7138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7138 rootObs == leafEnv7138) = true)

theorem terminalChecked7138 : H12PackedTerminal.terminalCheckFast leafEnv7138 active7138 tree7138 = true := by decide +kernel

def env7139 : List Nat := [2,4,8,16,32,36,49,41,63,32,56,40,17,24,0,35,48,56,0,0,24,32,48,59,40,5,0,28,4,1,57,24,9,24,33,63]

theorem envBound7139 : H12AffineFastState.Bounded env7139 := by
  intro p hp
  have h : env7139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7136_7139 : H12AffineEnvironment.transform 6 49 env7136 = env7139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 49 env7136 == env7139) = true)

def env7140 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,5356,262144,62640,32768,2097152,41088,20480,98472,8328,118898,360618,2216051,2217119,2185,99466,40969,61517,168,34359738368,98851]

theorem envBound7140 : H12AffineFastState.Bounded env7140 := by
  intro p hp
  have h : env7140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7106_7140 : H12AffineEnvironment.transform 7 253 env7106 = env7140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7106 == env7140) = true)

theorem identity7140 : scanCanonicalize (H12AffineFastState.compose env7140 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 288928) := by decide +kernel

theorem selectedBound7140 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7141 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,5356,262144,62640,32768,288928,41088,20480,98472,8328,118898,360618,374995,375871,2185,99466,40969,61517,168,34359738368,98851]

theorem envBound7141 : H12AffineFastState.Bounded env7141 := by
  intro p hp
  have h : env7141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7140_7141 : H12AffineEnvironment.transform 20 288928 env7140 = env7141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 288928 env7140 == env7141) = true)

theorem identity7141 : scanCanonicalize (H12AffineFastState.compose env7141 (packedSelected [0,2,4,6,7,9,13,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound7141 : packedSelected [0,2,4,6,7,9,13,14,17] rootPS < 2^1333 := by decide +kernel

def env7142 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,170,5356,262144,62640,32768,288928,41088,20480,32770,8328,53464,294912,309369,310421,2185,33824,40969,61517,168,34359738368,33417]

theorem envBound7142 : H12AffineFastState.Bounded env7142 := by
  intro p hp
  have h : env7142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7141_7142 : H12AffineEnvironment.transform 15 170 env7141 = env7142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env7141 == env7142) = true)

theorem identity7142 : scanCanonicalize (H12AffineFastState.compose env7142 (packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound7142 : packedSelected [0,2,4,6,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env7143 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,170,5356,262144,21520,8352,288928,32,20480,8354,8328,28792,270496,268505,269365,2185,9344,169,20717,168,34359738368,8745]

theorem envBound7143 : H12AffineFastState.Bounded env7143 := by
  intro p hp
  have h : env7143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7142_7143 : H12AffineEnvironment.transform 14 8352 env7142 = env7143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env7142 == env7143) = true)

theorem identity7143 : scanCanonicalize (H12AffineFastState.compose env7143 (packedSelected [0,4,6,7,9,13] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound7143 : packedSelected [0,4,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env7144 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,170,5356,23588,21520,8352,13444,32,20480,8354,8328,28792,31876,17661,16401,2185,9344,169,20717,168,34359738368,8745]

theorem envBound7144 : H12AffineFastState.Bounded env7144 := by
  intro p hp
  have h : env7144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7143_7144 : H12AffineEnvironment.transform 17 23588 env7143 = env7144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env7143 == env7144) = true)

theorem identity7144 : scanCanonicalize (H12AffineFastState.compose env7144 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound7144 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7145 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,16384,137,170,5356,23588,21520,137,5293,32,20480,139,161,20561,23725,17661,16401,2185,1193,169,20717,168,34359738368,512]

theorem envBound7145 : H12AffineFastState.Bounded env7145 := by
  intro p hp
  have h : env7145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7144_7145 : H12AffineEnvironment.transform 12 41 env7144 = env7145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env7144 == env7145) = true)

theorem identity7145 : scanCanonicalize (H12AffineFastState.compose env7145 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 4792) := by decide +kernel

theorem selectedBound7145 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7146 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,4792,137,170,5356,3740,1704,137,5293,32,696,139,161,745,3605,5701,4777,2185,1193,169,597,168,34359738368,512]

theorem envBound7146 : H12AffineFastState.Bounded env7146 := by
  intro p hp
  have h : env7146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7145_7146 : H12AffineEnvironment.transform 13 4792 env7145 = env7146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4792 env7145 == env7146) = true)

theorem identity7146 : scanCanonicalize (H12AffineFastState.compose env7146 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound7146 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7147 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,41,4705,80,115,5173,3653,1649,80,5236,32,609,82,120,560,3605,5701,4720,2128,1136,112,597,113,34359738368,512]

theorem envBound7147 : H12AffineFastState.Bounded env7147 := by
  intro p hp
  have h : env7147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7146_7147 : H12AffineEnvironment.transform 6 89 env7146 = env7147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env7146 == env7147) = true)

theorem identity7147 : scanCanonicalize (H12AffineFastState.compose env7147 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7147 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env7148 : List Nat := [2,4,8,16,32,64,89,36,512,4,2048,4096,41,4705,80,115,4145,2625,629,80,4208,32,609,82,120,560,2577,4673,4720,2128,116,112,597,113,34359738368,512]

theorem envBound7148 : H12AffineFastState.Bounded env7148 := by
  intro p hp
  have h : env7148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7147_7148 : H12AffineEnvironment.transform 9 4 env7147 = env7148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7147 == env7148) = true)

theorem identity7148 : scanCanonicalize (H12AffineFastState.compose env7148 (packedSelected [2,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound7148 : packedSelected [2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env7149 : List Nat := [2,4,8,16,32,64,89,36,512,4,2048,2609,41,2128,80,115,2560,2625,629,80,2625,32,609,82,120,560,2577,2160,2113,2128,116,112,597,113,34359738368,512]

theorem envBound7149 : H12AffineFastState.Bounded env7149 := by
  intro p hp
  have h : env7149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7148_7149 : H12AffineEnvironment.transform 11 2609 env7148 = env7149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env7148 == env7149) = true)

theorem identity7149 : scanCanonicalize (H12AffineFastState.compose env7149 (packedSelected [2,5,8,15] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound7149 : packedSelected [2,5,8,15] rootPS < 2^1333 := by decide +kernel

def env7150 : List Nat := [2,4,8,16,32,64,89,36,65,4,2048,2160,41,2128,80,115,2113,2048,52,80,2048,32,32,82,120,113,2128,2160,2113,2128,116,112,20,113,34359738368,65]

theorem envBound7150 : H12AffineFastState.Bounded env7150 := by
  intro p hp
  have h : env7150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7149_7150 : H12AffineEnvironment.transform 8 65 env7149 = env7150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env7149 == env7150) = true)

theorem identity7150 : scanCanonicalize (H12AffineFastState.compose env7150 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound7150 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env7151 : List Nat := [2,4,8,16,32,64,89,36,65,4,27,107,41,75,80,115,90,27,52,80,27,32,32,82,120,113,75,107,90,75,116,112,20,113,34359738368,65]

theorem envBound7151 : H12AffineFastState.Bounded env7151 := by
  intro p hp
  have h : env7151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7150_7151 : H12AffineEnvironment.transform 10 27 env7150 = env7151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env7150 == env7151) = true)

theorem identity7151 : scanCanonicalize (H12AffineFastState.compose env7151 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound7151 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7152 : List Nat := [2,4,8,16,10,64,89,14,65,4,27,65,3,75,80,89,90,27,30,80,27,10,10,82,82,91,75,65,90,75,94,90,20,91,34359738368,65]

theorem envBound7152 : H12AffineFastState.Bounded env7152 := by
  intro p hp
  have h : env7152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7151_7152 : H12AffineEnvironment.transform 4 10 env7151 = env7152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env7151 == env7152) = true)

theorem identity7152 : scanCanonicalize (H12AffineFastState.compose env7152 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound7152 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env7153 : List Nat := [2,4,8,11,10,64,66,14,65,4,0,65,3,75,75,66,65,0,5,75,0,10,10,73,73,64,75,65,65,75,69,65,15,64,34359738368,65]

theorem envBound7153 : H12AffineFastState.Bounded env7153 := by
  intro p hp
  have h : env7153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7152_7153 : H12AffineEnvironment.transform 3 11 env7152 = env7153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env7152 == env7153) = true)

theorem identity7153 : scanCanonicalize (H12AffineFastState.compose env7153 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound7153 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7154 : List Nat := [2,4,8,11,10,9,11,14,8,4,0,8,3,2,2,11,8,0,5,2,0,10,10,0,0,9,2,8,8,2,12,8,15,9,34359738368,8]

theorem envBound7154 : H12AffineFastState.Bounded env7154 := by
  intro p hp
  have h : env7154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7153_7154 : H12AffineEnvironment.transform 5 9 env7153 = env7154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env7153 == env7154) = true)

def env7155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5393,262144,62640,32768,2097152,41088,20481,98644,8328,118898,360618,2216050,2217315,2421,99703,40969,61872,340,34359738368,98851]

theorem envBound7155 : H12AffineFastState.Bounded env7155 := by
  intro p hp
  have h : env7155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7105_7155 : H12AffineEnvironment.transform 22 20481 env7105 = env7155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20481 env7105 == env7155) = true)

theorem identity7155 : scanCanonicalize (H12AffineFastState.compose env7155 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7155 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env7156 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,5357,262144,62640,32768,2097152,41088,20481,98472,8328,118898,360618,2216050,2217119,2185,99467,40969,61516,168,34359738368,98851]

theorem envBound7156 : H12AffineFastState.Bounded env7156 := by
  intro p hp
  have h : env7156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7155_7156 : H12AffineEnvironment.transform 7 252 env7155 = env7156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7155 == env7156) = true)

theorem identity7156 : scanCanonicalize (H12AffineFastState.compose env7156 (packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 343286) := by decide +kernel

theorem selectedBound7156 : packedSelected [0,1,2,3,4,6,7,9,13,14,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env7157 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,5357,262144,62640,32768,343286,41088,20481,98472,8328,118898,360618,322692,321641,2185,99467,40969,61516,168,34359738368,98851]

theorem envBound7157 : H12AffineFastState.Bounded env7157 := by
  intro p hp
  have h : env7157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7156_7157 : H12AffineEnvironment.transform 20 343286 env7156 = env7157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 343286 env7156 == env7157) = true)

theorem identity7157 : scanCanonicalize (H12AffineFastState.compose env7157 (packedSelected [11,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound7157 : packedSelected [11,17,18] rootPS < 2^1333 := by decide +kernel

def env7158 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,5357,262144,21521,8353,343286,33,20481,73737,8328,94419,335883,281637,280776,2185,74794,168,20717,168,34359738368,74370]

theorem envBound7158 : H12AffineFastState.Bounded env7158 := by
  intro p hp
  have h : env7158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7157_7158 : H12AffineEnvironment.transform 14 8353 env7157 = env7158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env7157 == env7158) = true)

theorem identity7158 : scanCanonicalize (H12AffineFastState.compose env7158 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound7158 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env7159 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,5357,262144,21521,8353,343286,33,20481,73737,8328,94419,335883,281637,280776,2185,74794,168,20717,168,280712,74370]

theorem envBound7159 : H12AffineFastState.Bounded env7159 := by
  intro p hp
  have h : env7159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7158_7159 : H12AffineEnvironment.transform 34 280712 env7158 = env7159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env7158 == env7159) = true)

theorem identity7159 : scanCanonicalize (H12AffineFastState.compose env7159 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 7847) := by decide +kernel

theorem selectedBound7159 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env7160 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,65536,5357,262144,2742,8353,343286,33,3750,73737,8328,77428,335883,266882,267887,2185,74794,168,3658,168,267823,74370]

theorem envBound7160 : H12AffineFastState.Bounded env7160 := by
  intro p hp
  have h : env7160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7159_7160 : H12AffineEnvironment.transform 13 7847 env7159 = env7160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7847 env7159 == env7160) = true)

def env7161 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2800,5357,262144,2742,8353,275974,33,3750,11001,8328,9348,273147,266882,267887,2185,11994,168,3658,168,267823,10354]

theorem envBound7161 : H12AffineFastState.Bounded env7161 := by
  intro p hp
  have h : env7161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7160_7161 : H12AffineEnvironment.transform 15 2800 env7160 = env7161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2800 env7160 == env7161) = true)

theorem identity7161 : scanCanonicalize (H12AffineFastState.compose env7161 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(17+1) ^^^ 8954) := by decide +kernel

theorem selectedBound7161 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env7162 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2800,5357,8954,2742,8353,5372,33,3750,11001,8328,9348,2049,12408,13461,2185,11994,168,3658,168,13525,10354]

theorem envBound7162 : H12AffineFastState.Bounded env7162 := by
  intro p hp
  have h : env7162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7161_7162 : H12AffineEnvironment.transform 17 8954 env7161 = env7162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8954 env7161 == env7162) = true)

theorem identity7162 : scanCanonicalize (H12AffineFastState.compose env7162 (packedSelected [13] rootPS)) = affineNative (2^(12+1) ^^^ 2674) := by decide +kernel

theorem selectedBound7162 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7163 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,2674,7847,2771,2800,5357,2184,2742,2771,5372,33,3750,139,2810,3830,2049,6666,7911,2185,1192,168,3658,168,7847,512]

theorem envBound7163 : H12AffineFastState.Bounded env7163 := by
  intro p hp
  have h : env7163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7162_7163 : H12AffineEnvironment.transform 12 2674 env7162 = env7163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2674 env7162 == env7163) = true)

theorem identity7163 : scanCanonicalize (H12AffineFastState.compose env7163 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7164 : List Nat := [2,4,8,16,32,64,128,252,512,68,2048,4096,2674,6883,2771,2800,4265,2184,2742,2771,4280,33,2786,139,2810,2738,2049,6666,6819,2185,236,168,2574,168,6883,512]

theorem envBound7164 : H12AffineFastState.Bounded env7164 := by
  intro p hp
  have h : env7164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7163_7164 : H12AffineEnvironment.transform 9 68 env7163 = env7164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7163 == env7164) = true)

theorem identity7164 : scanCanonicalize (H12AffineFastState.compose env7164 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 722) := by decide +kernel

theorem selectedBound7164 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7165 : List Nat := [2,4,8,16,32,64,128,252,512,68,722,4096,160,4145,1,34,4265,602,100,1,4280,33,48,139,40,96,723,4312,4209,603,236,168,220,168,4145,512]

theorem envBound7165 : H12AffineFastState.Bounded env7165 := by
  intro p hp
  have h : env7165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7164_7165 : H12AffineEnvironment.transform 10 722 env7164 = env7165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 722 env7164 == env7165) = true)

theorem identity7165 : scanCanonicalize (H12AffineFastState.compose env7165 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound7165 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7166 : List Nat := [2,4,8,16,32,60,128,128,512,56,686,4096,160,4145,1,34,4265,550,24,1,4280,33,48,139,40,28,687,4260,4109,551,144,168,160,168,4145,512]

theorem envBound7166 : H12AffineFastState.Bounded env7166 := by
  intro p hp
  have h : env7166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7165_7166 : H12AffineEnvironment.transform 5 60 env7165 = env7166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env7165 == env7166) = true)

def env7167 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2801,5357,262144,2742,8353,275975,33,3750,11000,8328,9349,273146,266882,267887,2185,11995,168,3658,168,267823,10355]

theorem envBound7167 : H12AffineFastState.Bounded env7167 := by
  intro p hp
  have h : env7167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7160_7167 : H12AffineEnvironment.transform 15 2801 env7160 = env7167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2801 env7160 == env7167) = true)

def env7168 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,7847,8353,2801,5357,3276,2742,8353,15051,33,3750,11000,8328,9349,9782,7758,6819,2185,11995,168,3658,168,6883,10355]

theorem envBound7168 : H12AffineFastState.Bounded env7168 := by
  intro p hp
  have h : env7168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7167_7168 : H12AffineEnvironment.transform 17 3276 env7167 = env7168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3276 env7167 == env7168) = true)

theorem identity7168 : scanCanonicalize (H12AffineFastState.compose env7168 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1252) := by decide +kernel

theorem selectedBound7168 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7169 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,1252,7847,1093,2801,5357,3276,2742,1093,7727,33,3750,3612,1132,97,722,7758,6819,2185,2623,168,3658,168,6883,3223]

theorem envBound7169 : H12AffineFastState.Bounded env7169 := by
  intro p hp
  have h : env7169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7168_7169 : H12AffineEnvironment.transform 12 1252 env7168 = env7169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1252 env7168 == env7169) = true)

def env7170 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1108,1252,2803,1093,2801,185,3276,2742,1093,2683,33,3750,3612,1132,97,722,2586,3831,2185,2623,168,3658,168,3767,3223]

theorem envBound7170 : H12AffineFastState.Bounded env7170 := by
  intro p hp
  have h : env7170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7169_7170 : H12AffineEnvironment.transform 11 1108 env7169 = env7170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env7169 == env7170) = true)

def env7171 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1108,1132,2683,1093,2681,49,3140,2622,1093,2683,33,3630,3612,1132,97,602,2586,3711,2049,2623,32,3658,32,3647,3103]

theorem envBound7171 : H12AffineFastState.Bounded env7171 := by
  intro p hp
  have h : env7171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7170_7171 : H12AffineEnvironment.transform 6 8 env7170 = env7171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7170 == env7171) = true)

theorem identity7171 : scanCanonicalize (H12AffineFastState.compose env7171 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound7171 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7172 : List Nat := [2,4,8,16,32,64,8,116,512,68,2048,16,40,2683,1,2681,49,2048,2622,1,2683,33,2666,2648,40,97,602,2586,2619,2049,2623,32,2574,32,2683,2139]

theorem envBound7172 : H12AffineFastState.Bounded env7172 := by
  intro p hp
  have h : env7172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7171_7172 : H12AffineEnvironment.transform 9 68 env7171 = env7172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env7171 == env7172) = true)

theorem identity7172 : scanCanonicalize (H12AffineFastState.compose env7172 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound7172 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env7173 : List Nat := [2,4,8,16,32,64,8,116,512,68,602,16,40,33,1,35,49,602,100,1,33,33,48,2,40,97,602,64,97,603,101,32,84,32,33,513]

theorem envBound7173 : H12AffineFastState.Bounded env7173 := by
  intro p hp
  have h : env7173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7172_7173 : H12AffineEnvironment.transform 10 602 env7172 = env7173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env7172 == env7173) = true)

theorem identity7173 : scanCanonicalize (H12AffineFastState.compose env7173 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound7173 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7174 : List Nat := [2,4,8,16,32,2,8,54,512,6,536,16,40,33,1,35,49,536,38,1,33,33,48,2,40,35,536,2,35,537,39,32,22,32,33,513]

theorem envBound7174 : H12AffineFastState.Bounded env7174 := by
  intro p hp
  have h : env7174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7173_7174 : H12AffineEnvironment.transform 5 2 env7173 = env7174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env7173 == env7174) = true)

theorem identity7174 : scanCanonicalize (H12AffineFastState.compose env7174 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound7174 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7175 : List Nat := [2,4,8,3,32,2,8,37,512,6,523,3,40,33,1,35,34,523,38,1,33,33,35,2,40,35,523,2,35,522,39,32,5,32,33,513]

theorem envBound7175 : H12AffineFastState.Bounded env7175 := by
  intro p hp
  have h : env7175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7174_7175 : H12AffineEnvironment.transform 3 3 env7174 = env7175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env7174 == env7175) = true)

theorem identity7175 : scanCanonicalize (H12AffineFastState.compose env7175 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound7175 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7176 : List Nat := [2,4,8,3,32,2,8,37,10,6,1,3,40,33,1,35,34,1,38,1,33,33,35,2,40,35,1,2,35,0,39,32,5,32,33,11]

theorem envBound7176 : H12AffineFastState.Bounded env7176 := by
  intro p hp
  have h : env7176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7175_7176 : H12AffineEnvironment.transform 8 10 env7175 = env7176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env7175 == env7176) = true)

def env7177 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1108,1133,2682,1093,2680,48,3141,2623,1093,2683,33,3631,3612,1132,97,603,2586,3710,2048,2623,33,3658,33,3646,3102]

theorem envBound7177 : H12AffineFastState.Bounded env7177 := by
  intro p hp
  have h : env7177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7170_7177 : H12AffineEnvironment.transform 6 9 env7170 = env7177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7170 == env7177) = true)

def env7178 : List Nat := [2,4,8,16,32,64,9,117,512,112,2048,36,29,2682,53,2680,48,2101,2623,53,2683,33,2655,2668,28,97,603,2586,2574,2048,2623,33,2618,33,2638,2158]

theorem envBound7178 : H12AffineFastState.Bounded env7178 := by
  intro p hp
  have h : env7178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7177_7178 : H12AffineEnvironment.transform 9 112 env7177 = env7178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 112 env7177 == env7178) = true)

theorem identity7178 : scanCanonicalize (H12AffineFastState.compose env7178 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound7178 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7179 : List Nat := [2,4,8,16,32,64,9,117,512,112,81,36,29,555,53,553,48,100,622,53,554,33,526,573,28,97,603,587,607,81,622,33,619,33,543,63]

theorem envBound7179 : H12AffineFastState.Bounded env7179 := by
  intro p hp
  have h : env7179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7178_7179 : H12AffineEnvironment.transform 10 81 env7178 = env7179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env7178 == env7179) = true)

def env7180 : List Nat := [2,4,8,16,32,16,9,37,512,32,1,36,29,555,53,553,48,52,574,53,554,33,526,573,28,49,523,539,527,1,574,33,571,33,543,63]

theorem envBound7180 : H12AffineFastState.Bounded env7180 := by
  intro p hp
  have h : env7180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7179_7180 : H12AffineEnvironment.transform 5 16 env7179 = env7180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env7179 == env7180) = true)

theorem identity7180 : scanCanonicalize (H12AffineFastState.compose env7180 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound7180 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7181 : List Nat := [2,4,8,16,32,16,9,37,11,32,1,36,29,32,53,34,48,52,53,53,33,33,5,54,28,49,0,16,4,1,53,33,48,33,20,63]

theorem envBound7181 : H12AffineFastState.Bounded env7181 := by
  intro p hp
  have h : env7181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7180_7181 : H12AffineEnvironment.transform 8 11 env7180 = env7181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env7180 == env7181) = true)

theorem identity7181 : scanCanonicalize (H12AffineFastState.compose env7181 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound7181 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7182 : List Nat := [2,4,8,16,21,16,9,16,11,21,1,17,29,21,0,23,5,1,0,0,20,20,5,3,28,4,0,16,4,1,0,20,5,20,20,10]

theorem envBound7182 : H12AffineFastState.Bounded env7182 := by
  intro p hp
  have h : env7182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7181_7182 : H12AffineEnvironment.transform 4 21 env7181 = env7182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env7181 == env7182) = true)

theorem identity7182 : scanCanonicalize (H12AffineFastState.compose env7182 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

end H12CloudChart0