import H12CloudChart0Data191

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound48623 : H12AffineFastState.Bounded env48623 := by
  intro p hp
  have h : env48623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48622_48623 : H12AffineEnvironment.transform 14 217 env48622 = env48623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env48622 == env48623) = true)

theorem identity48623 : scanCanonicalize (H12AffineFastState.compose env48623 (packedSelected [0,1,2,6,7,8,11,12,15,17,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound48623 : packedSelected [0,1,2,6,7,8,11,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env48624 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5292,217,171,13460,2185,1025,216,4161,112,201,138,8328,64,10481,5173,4232,10401,1056,8321,253,112,13404,8864]

theorem envBound48624 : H12AffineFastState.Bounded env48624 := by
  intro p hp
  have h : env48624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48623_48624 : H12AffineEnvironment.transform 7 252 env48623 = env48624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env48623 == env48624) = true)

theorem identity48624 : scanCanonicalize (H12AffineFastState.compose env48624 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound48624 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env48625 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,240,5292,217,171,5220,2185,1025,216,4161,112,201,138,120,64,2049,5173,4232,2129,1056,113,253,112,5292,592]

theorem envBound48625 : H12AffineFastState.Bounded env48625 := by
  intro p hp
  have h : env48625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48624_48625 : H12AffineEnvironment.transform 12 240 env48624 = env48625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env48624 == env48625) = true)

theorem identity48625 : scanCanonicalize (H12AffineFastState.compose env48625 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound48625 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48626 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,3109,240,2185,217,171,2113,2185,1025,216,3172,112,201,138,120,64,2049,2064,3245,2129,1056,113,253,112,2185,592]

theorem envBound48626 : H12AffineFastState.Bounded env48626 := by
  intro p hp
  have h : env48626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48625_48626 : H12AffineEnvironment.transform 11 3109 env48625 = env48626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env48625 == env48626) = true)

def env48627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,2237468,243088,8328,64,2144660,2240796,160076,2417692,2102685,2373704,257,21792,46213,2175562]

theorem envBound48627 : H12AffineFastState.Bounded env48627 := by
  intro p hp
  have h : env48627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48566_48627 : H12AffineEnvironment.transform 21 452633 env48566 = env48627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env48566 == env48627) = true)

def env48628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,144476,243088,8328,64,43476,139612,160076,324700,1501,272392,257,21792,46213,74250]

theorem envBound48628 : H12AffineFastState.Bounded env48628 := by
  intro p hp
  have h : env48628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48627_48628 : H12AffineEnvironment.transform 20 4160 env48627 = env48628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48627 == env48628) = true)

theorem identity48628 : scanCanonicalize (H12AffineFastState.compose env48628 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48628 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,452633,144476,169371,8328,64,43476,139612,160076,324700,1501,272392,257,21792,46213,513]

theorem envBound48629 : H12AffineFastState.Bounded env48629 := by
  intro p hp
  have h : env48629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48628_48629 : H12AffineEnvironment.transform 15 8203 env48628 = env48629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48628 == env48629) = true)

def env48630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4160,305161,29772,54667,8328,64,43476,24908,12636,324700,1501,272392,257,21792,46213,513]

theorem envBound48630 : H12AffineFastState.Bounded env48630 := by
  intro p hp
  have h : env48630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48629_48630 : H12AffineEnvironment.transform 16 16400 env48629 = env48630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env48629 == env48630) = true)

def env48631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4160,305161,29772,54531,8192,64,43356,24908,12636,324700,1365,272392,257,21792,46093,513]

theorem envBound48631 : H12AffineFastState.Bounded env48631 := by
  intro p hp
  have h : env48631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48630_48631 : H12AffineEnvironment.transform 6 8 env48630 = env48631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48630 == env48631) = true)

theorem identity48631 : scanCanonicalize (H12AffineFastState.compose env48631 (packedSelected [0,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound48631 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env48632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,32768,1095,16400,262144,1025,32769,4160,298053,20480,54531,1100,64,36112,17664,5392,315408,1365,265284,257,21792,36929,513]

theorem envBound48632 : H12AffineFastState.Bounded env48632 := by
  intro p hp
  have h : env48632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48631_48632 : H12AffineEnvironment.transform 12 1100 env48631 = env48632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env48631 == env48632) = true)

theorem identity48632 : scanCanonicalize (H12AffineFastState.compose env48632 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound48632 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env48633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1297,1095,16400,262144,1025,1296,4160,264532,20480,20498,1100,64,2049,17664,5392,283905,1365,265284,257,21792,5456,513]

theorem envBound48633 : H12AffineFastState.Bounded env48633 := by
  intro p hp
  have h : env48633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48632_48633 : H12AffineEnvironment.transform 14 1297 env48632 = env48633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env48632 == env48633) = true)

theorem identity48633 : scanCanonicalize (H12AffineFastState.compose env48633 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound48633 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1297,1095,16400,3172,1025,1296,4160,1328,20480,20498,1100,64,2049,17664,5392,22885,1365,32,257,21792,5456,513]

theorem envBound48634 : H12AffineFastState.Bounded env48634 := by
  intro p hp
  have h : env48634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48633_48634 : H12AffineEnvironment.transform 17 3172 env48633 = env48634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env48633 == env48634) = true)

theorem identity48634 : scanCanonicalize (H12AffineFastState.compose env48634 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound48634 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,1100,16384,1297,1095,16400,3172,1025,1296,3393,1328,19713,19731,1100,64,2049,17664,2065,17508,1365,32,257,18465,2129,513]

theorem envBound48635 : H12AffineFastState.Bounded env48635 := by
  intro p hp
  have h : env48635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48634_48635 : H12AffineEnvironment.transform 11 3329 env48634 = env48635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env48634 == env48635) = true)

theorem identity48635 : scanCanonicalize (H12AffineFastState.compose env48635 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48635 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env48636 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3109,1100,16384,1077,1095,16400,3172,1025,1076,3173,1044,19493,19511,1100,64,2049,17444,2065,17508,1137,32,37,18465,2129,513]

theorem envBound48636 : H12AffineFastState.Bounded env48636 := by
  intro p hp
  have h : env48636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48635_48636 : H12AffineEnvironment.transform 7 36 env48635 = env48636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48635 == env48636) = true)

theorem identity48636 : scanCanonicalize (H12AffineFastState.compose env48636 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound48636 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env48637 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3109,1100,2128,1077,1095,2112,3172,1025,1076,3173,1044,1141,1127,1100,64,2049,3188,2065,3124,1137,32,37,113,2129,513]

theorem envBound48637 : H12AffineFastState.Bounded env48637 := by
  intro p hp
  have h : env48637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48636_48637 : H12AffineEnvironment.transform 13 2128 env48636 = env48637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env48636 == env48637) = true)

theorem identity48637 : scanCanonicalize (H12AffineFastState.compose env48637 (packedSelected [1,2,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 619) := by decide +kernel

theorem selectedBound48637 : packedSelected [1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env48638 : List Nat := [2,4,8,16,32,64,8,36,512,1024,619,1614,1100,571,1077,1095,555,1551,1025,1076,1550,1044,1141,1127,1100,64,618,1567,634,1631,1137,32,37,113,570,513]

theorem envBound48638 : H12AffineFastState.Bounded env48638 := by
  intro p hp
  have h : env48638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48637_48638 : H12AffineEnvironment.transform 10 619 env48637 = env48638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 619 env48637 == env48638) = true)

theorem identity48638 : scanCanonicalize (H12AffineFastState.compose env48638 (packedSelected [3,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48638 : packedSelected [3,6,9] rootPS < 2^1333 := by decide +kernel

def env48639 : List Nat := [2,4,8,16,32,16,8,36,512,1024,571,1566,1052,571,1077,1047,555,1551,1025,1076,1550,1044,1061,1079,1052,16,570,1567,554,1551,1057,32,37,33,570,513]

theorem envBound48639 : H12AffineFastState.Bounded env48639 := by
  intro p hp
  have h : env48639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48638_48639 : H12AffineEnvironment.transform 5 16 env48638 = env48639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48638 == env48639) = true)

def env48640 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4160,305161,29772,54530,8193,64,43357,24908,12636,324700,1364,272392,257,21792,46092,513]

theorem envBound48640 : H12AffineFastState.Bounded env48640 := by
  intro p hp
  have h : env48640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48630_48640 : H12AffineEnvironment.transform 6 9 env48630 = env48640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48630 == env48640) = true)

def env48641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,305160,29773,54666,8328,64,43476,24909,12637,324700,1501,272392,257,21792,46213,513]

theorem envBound48641 : H12AffineFastState.Bounded env48641 := by
  intro p hp
  have h : env48641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48629_48641 : H12AffineEnvironment.transform 16 16401 env48629 = env48641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env48629 == env48641) = true)

theorem identity48641 : scanCanonicalize (H12AffineFastState.compose env48641 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound48641 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,13389,262144,1025,32769,4160,305160,17,41430,8328,64,43476,5393,12637,294912,1501,272392,257,8572,46213,513]

theorem envBound48642 : H12AffineFastState.Bounded env48642 := by
  intro p hp
  have h : env48642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48641_48642 : H12AffineEnvironment.transform 13 13404 env48641 = env48642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env48641 == env48642) = true)

theorem identity48642 : scanCanonicalize (H12AffineFastState.compose env48642 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 43169) := by decide +kernel

theorem selectedBound48642 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,13389,43169,1025,32769,4160,169,17,41430,8328,64,43476,5393,12637,10401,1501,32937,257,8572,46213,513]

theorem envBound48643 : H12AffineFastState.Bounded env48643 := by
  intro p hp
  have h : env48643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48642_48643 : H12AffineEnvironment.transform 17 43169 env48642 = env48643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43169 env48642 == env48643) = true)

theorem identity48643 : scanCanonicalize (H12AffineFastState.compose env48643 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound48643 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env48644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8661,8203,13389,2420,1025,8660,4160,169,17,3,8328,64,2049,5393,12637,10401,1501,8572,257,8572,5456,513]

theorem envBound48644 : H12AffineFastState.Bounded env48644 := by
  intro p hp
  have h : env48644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48643_48644 : H12AffineEnvironment.transform 14 8661 env48643 = env48644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env48643 == env48644) = true)

theorem identity48644 : scanCanonicalize (H12AffineFastState.compose env48644 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound48644 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,1,479,5529,2420,1025,0,4160,169,17,3,348,64,2049,5393,4233,2421,1501,168,257,168,5456,513]

theorem envBound48645 : H12AffineFastState.Bounded env48645 := by
  intro p hp
  have h : env48645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48644_48645 : H12AffineEnvironment.transform 12 468 env48644 = env48645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env48644 == env48645) = true)

theorem identity48645 : scanCanonicalize (H12AffineFastState.compose env48645 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound48645 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env48646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,468,1416,1,479,1433,2420,1025,0,64,169,17,3,348,64,2049,1297,137,2421,1501,168,257,168,1360,513]

theorem envBound48646 : H12AffineFastState.Bounded env48646 := by
  intro p hp
  have h : env48646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48645_48646 : H12AffineEnvironment.transform 11 0 env48645 = env48646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env48645 == env48646) = true)

theorem identity48646 : scanCanonicalize (H12AffineFastState.compose env48646 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 502) := by decide +kernel

theorem selectedBound48646 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env48647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,502,0,468,1416,1,479,1433,130,1025,0,64,169,17,3,348,64,503,1297,137,131,1501,168,257,168,1360,513]

theorem envBound48647 : H12AffineFastState.Bounded env48647 := by
  intro p hp
  have h : env48647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48646_48647 : H12AffineEnvironment.transform 10 502 env48646 = env48647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 502 env48646 == env48647) = true)

theorem identity48647 : scanCanonicalize (H12AffineFastState.compose env48647 (packedSelected [1,3,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48647 : packedSelected [1,3,11,18] rootPS < 2^1333 := by decide +kernel

def env48648 : List Nat := [2,4,8,16,32,16,128,256,512,1024,422,0,388,1416,1,399,1433,130,1025,0,16,169,17,3,268,16,423,1297,137,131,1421,168,257,168,1280,513]

theorem envBound48648 : H12AffineFastState.Bounded env48648 := by
  intro p hp
  have h : env48648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48647_48648 : H12AffineEnvironment.transform 5 16 env48647 = env48648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48647 == env48648) = true)

theorem identity48648 : scanCanonicalize (H12AffineFastState.compose env48648 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 403) := by decide +kernel

theorem selectedBound48648 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48649 : List Nat := [2,4,8,16,32,16,128,256,512,403,422,0,388,27,1,399,10,130,402,0,16,169,17,3,268,16,423,130,137,131,30,168,257,168,147,513]

theorem envBound48649 : H12AffineFastState.Bounded env48649 := by
  intro p hp
  have h : env48649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48648_48649 : H12AffineEnvironment.transform 9 403 env48648 = env48649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 403 env48648 == env48649) = true)

theorem identity48649 : scanCanonicalize (H12AffineFastState.compose env48649 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound48649 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env48650 : List Nat := [2,4,8,16,32,16,50,256,512,289,276,0,310,27,1,317,10,48,288,0,16,27,17,3,268,16,277,48,59,49,30,26,257,26,33,513]

theorem envBound48650 : H12AffineFastState.Bounded env48650 := by
  intro p hp
  have h : env48650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48649_48650 : H12AffineEnvironment.transform 6 50 env48649 = env48650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env48649 == env48650) = true)

theorem identity48650 : scanCanonicalize (H12AffineFastState.compose env48650 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound48650 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env48651 : List Nat := [2,4,8,16,32,16,50,63,512,30,43,0,9,27,1,2,10,48,31,0,16,27,17,3,51,16,42,48,59,49,30,26,62,26,33,513]

theorem envBound48651 : H12AffineFastState.Bounded env48651 := by
  intro p hp
  have h : env48651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48650_48651 : H12AffineEnvironment.transform 7 63 env48650 = env48651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env48650 == env48651) = true)

theorem identity48651 : scanCanonicalize (H12AffineFastState.compose env48651 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48651 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48652 : List Nat := [2,4,8,16,0,16,18,31,512,30,11,0,9,27,1,2,10,16,31,0,16,27,17,3,19,16,10,16,27,17,30,26,30,26,1,513]

theorem envBound48652 : H12AffineFastState.Bounded env48652 := by
  intro p hp
  have h : env48652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48651_48652 : H12AffineEnvironment.transform 4 0 env48651 = env48652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48651 == env48652) = true)

theorem identity48652 : scanCanonicalize (H12AffineFastState.compose env48652 (packedSelected [0,1,3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48652 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env48653 : List Nat := [2,0,8,16,0,16,18,27,512,26,11,0,9,27,1,2,10,16,27,0,16,27,17,3,19,16,10,16,27,17,26,26,26,26,1,513]

theorem envBound48653 : H12AffineFastState.Bounded env48653 := by
  intro p hp
  have h : env48653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48652_48653 : H12AffineEnvironment.transform 1 0 env48652 = env48653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48652 == env48653) = true)

theorem identity48653 : scanCanonicalize (H12AffineFastState.compose env48653 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48653 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env48654 : List Nat := [2,0,8,10,0,10,8,1,512,0,11,0,9,1,1,2,10,10,1,0,10,1,11,3,9,10,10,10,1,11,0,0,0,0,1,513]

theorem envBound48654 : H12AffineFastState.Bounded env48654 := by
  intro p hp
  have h : env48654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48653_48654 : H12AffineEnvironment.transform 3 10 env48653 = env48654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48653 == env48654) = true)

theorem identity48654 : scanCanonicalize (H12AffineFastState.compose env48654 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48654 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48655 : List Nat := [2,0,2,0,0,0,2,1,512,0,1,0,3,1,1,2,0,0,1,0,0,1,1,3,3,0,0,0,1,1,0,0,0,0,1,513]

theorem envBound48655 : H12AffineFastState.Bounded env48655 := by
  intro p hp
  have h : env48655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48654_48655 : H12AffineEnvironment.transform 2 2 env48654 = env48655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48654 == env48655) = true)

theorem identity48655 : scanCanonicalize (H12AffineFastState.compose env48655 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound48655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48656 : List Nat := [2,0,2,0,0,0,2,1,3,0,1,0,3,1,1,2,0,0,1,0,0,1,1,3,3,0,0,0,1,1,0,0,0,0,1,2]

theorem envBound48656 : H12AffineFastState.Bounded env48656 := by
  intro p hp
  have h : env48656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48655_48656 : H12AffineEnvironment.transform 8 3 env48655 = env48656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env48655 == env48656) = true)

theorem identity48656 : scanCanonicalize (H12AffineFastState.compose env48656 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48656 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48657 : List Nat := [1,0,1,0,0,0,1,1,0,0,1,0,0,1,1,1,0,0,1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,1,1]

theorem envBound48657 : H12AffineFastState.Bounded env48657 := by
  intro p hp
  have h : env48657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48656_48657 : H12AffineEnvironment.transform 0 1 env48656 = env48657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48656 == env48657) = true)

def env48658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,144477,243088,8328,64,43477,139613,160076,324701,1500,272393,257,21792,46213,74251]

theorem envBound48658 : H12AffineFastState.Bounded env48658 := by
  intro p hp
  have h : env48658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48627_48658 : H12AffineEnvironment.transform 20 4161 env48627 = env48658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48627 == env48658) = true)

theorem identity48658 : scanCanonicalize (H12AffineFastState.compose env48658 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound48658 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,4161,329867,120015,21762,8328,64,43477,115151,102878,324701,1500,272393,257,21792,46213,74251]

theorem envBound48659 : H12AffineFastState.Bounded env48659 := by
  intro p hp
  have h : env48659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48658_48659 : H12AffineEnvironment.transform 16 123026 env48658 = env48659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env48658 == env48659) = true)

def env48660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10400,1025,32769,4161,73771,120015,21762,8328,64,43477,115151,102878,56573,1500,169,257,21792,46213,74251]

theorem envBound48660 : H12AffineFastState.Bounded env48660 := by
  intro p hp
  have h : env48660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48659_48660 : H12AffineEnvironment.transform 17 10400 env48659 = env48660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env48659 == env48660) = true)

def env48661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1025,32769,4161,73771,119879,21762,8192,64,43357,115015,102742,56437,1364,33,257,21792,46093,74251]

theorem envBound48661 : H12AffineFastState.Bounded env48661 := by
  intro p hp
  have h : env48661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48660_48661 : H12AffineEnvironment.transform 6 8 env48660 = env48661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48660 == env48661) = true)

theorem identity48661 : scanCanonicalize (H12AffineFastState.compose env48661 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48661 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,82247,10280,1025,8540,4161,73771,95514,21762,8192,64,2048,90138,77835,32040,1364,33,257,21792,5456,74251]

theorem envBound48662 : H12AffineFastState.Bounded env48662 := by
  intro p hp
  have h : env48662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48661_48662 : H12AffineEnvironment.transform 14 8541 env48661 = env48662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48661 == env48662) = true)

theorem identity48662 : scanCanonicalize (H12AffineFastState.compose env48662 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound48662 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env48663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,16400,10280,1025,8540,4161,8572,29773,21762,8192,64,2048,24909,12636,32040,1364,33,257,21792,5456,9052]

theorem envBound48663 : H12AffineFastState.Bounded env48663 := by
  intro p hp
  have h : env48663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48662_48663 : H12AffineEnvironment.transform 15 343 env48662 = env48663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env48662 == env48663) = true)

theorem identity48663 : scanCanonicalize (H12AffineFastState.compose env48663 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound48663 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,343,4096,10280,1025,8540,4161,8572,9309,1298,8192,64,2048,12637,12636,11576,1364,33,257,1328,5456,9052]

theorem envBound48664 : H12AffineFastState.Bounded env48664 := by
  intro p hp
  have h : env48664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48663_48664 : H12AffineEnvironment.transform 13 4112 env48663 = env48664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env48663 == env48664) = true)

theorem identity48664 : scanCanonicalize (H12AffineFastState.compose env48664 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48664 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48665 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,4112,8541,343,4096,10280,53,8540,4161,8572,8297,294,8192,64,2048,12637,12636,10508,352,33,257,260,4452,9052]

theorem envBound48665 : H12AffineFastState.Bounded env48665 := by
  intro p hp
  have h : env48665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48664_48665 : H12AffineEnvironment.transform 9 52 env48664 = env48665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48664 == env48665) = true)

theorem identity48665 : scanCanonicalize (H12AffineFastState.compose env48665 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48665 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env48666 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,349,4112,0,343,4096,2421,53,1,4161,33,308,294,349,64,2048,4096,4097,2129,352,33,257,260,4452,513]

theorem envBound48666 : H12AffineFastState.Bounded env48666 := by
  intro p hp
  have h : env48666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48665_48666 : H12AffineEnvironment.transform 12 349 env48665 = env48666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48665 == env48666) = true)

theorem identity48666 : scanCanonicalize (H12AffineFastState.compose env48666 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48666 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48667 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,120,4112,0,114,4096,2128,53,1,4161,33,17,3,120,64,2048,4096,4097,2129,69,33,36,33,4161,513]

theorem envBound48667 : H12AffineFastState.Bounded env48667 := by
  intro p hp
  have h : env48667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48666_48667 : H12AffineEnvironment.transform 7 37 env48666 = env48667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48666 == env48667) = true)

theorem identity48667 : scanCanonicalize (H12AffineFastState.compose env48667 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound48667 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48668 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,2587,120,2571,0,114,2587,2128,53,1,2650,33,17,3,120,64,2048,2587,2586,2129,69,33,36,33,2650,513]

theorem envBound48668 : H12AffineFastState.Bounded env48668 := by
  intro p hp
  have h : env48668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48667_48668 : H12AffineEnvironment.transform 11 2587 env48667 = env48668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env48667 == env48668) = true)

theorem identity48668 : scanCanonicalize (H12AffineFastState.compose env48668 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48668 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48669 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2587,40,2571,0,34,2587,2048,53,1,2570,33,17,3,40,16,2048,2587,2586,2049,21,33,36,33,2570,513]

theorem envBound48669 : H12AffineFastState.Bounded env48669 := by
  intro p hp
  have h : env48669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48668_48669 : H12AffineEnvironment.transform 5 16 env48668 = env48669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48668 == env48669) = true)

theorem identity48669 : scanCanonicalize (H12AffineFastState.compose env48669 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound48669 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48670 : List Nat := [2,4,8,16,21,16,8,16,512,1,2048,2587,29,2571,0,23,2587,2048,0,1,2570,20,17,3,29,16,2048,2587,2586,2049,21,20,17,20,2570,513]

theorem envBound48670 : H12AffineFastState.Bounded env48670 := by
  intro p hp
  have h : env48670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48669_48670 : H12AffineEnvironment.transform 4 21 env48669 = env48670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env48669 == env48670) = true)

theorem identity48670 : scanCanonicalize (H12AffineFastState.compose env48670 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 520) := by decide +kernel

theorem selectedBound48670 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48671 : List Nat := [2,4,8,16,21,16,8,16,512,1,520,19,29,3,0,23,19,520,0,1,2,20,17,3,29,16,520,19,18,521,21,20,17,20,2,513]

theorem envBound48671 : H12AffineFastState.Bounded env48671 := by
  intro p hp
  have h : env48671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48670_48671 : H12AffineEnvironment.transform 10 520 env48670 = env48671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 520 env48670 == env48671) = true)

theorem identity48671 : scanCanonicalize (H12AffineFastState.compose env48671 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound48671 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48672 : List Nat := [2,4,8,16,21,16,8,16,29,1,21,19,29,3,0,23,19,21,0,1,2,20,17,3,29,16,21,19,18,20,21,20,17,20,2,28]

theorem envBound48672 : H12AffineFastState.Bounded env48672 := by
  intro p hp
  have h : env48672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48671_48672 : H12AffineEnvironment.transform 8 29 env48671 = env48672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env48671 == env48672) = true)

theorem identity48672 : scanCanonicalize (H12AffineFastState.compose env48672 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound48672 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48673 : List Nat := [2,4,8,5,0,5,8,5,8,1,0,6,8,3,0,2,6,0,0,1,2,1,4,3,8,5,0,6,7,1,0,1,4,1,2,9]

theorem envBound48673 : H12AffineFastState.Bounded env48673 := by
  intro p hp
  have h : env48673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48672_48673 : H12AffineEnvironment.transform 3 5 env48672 = env48673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env48672 == env48673) = true)

theorem identity48673 : scanCanonicalize (H12AffineFastState.compose env48673 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48673 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env48674 : List Nat := [1,4,8,5,0,5,8,5,8,1,0,5,8,0,0,1,5,0,0,1,1,1,4,0,8,5,0,5,4,1,0,1,4,1,1,9]

theorem envBound48674 : H12AffineFastState.Bounded env48674 := by
  intro p hp
  have h : env48674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48673_48674 : H12AffineEnvironment.transform 0 1 env48673 = env48674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48673 == env48674) = true)

def env48675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,4161,73771,119878,21762,8193,64,43356,115014,102743,56436,1365,32,257,21792,46092,74251]

theorem envBound48675 : H12AffineFastState.Bounded env48675 := by
  intro p hp
  have h : env48675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48660_48675 : H12AffineEnvironment.transform 6 9 env48660 = env48675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48660 == env48675) = true)

theorem identity48675 : scanCanonicalize (H12AffineFastState.compose env48675 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound48675 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,70726,10281,1025,29788,4161,73771,73755,21762,8193,64,23809,79131,91402,10281,1365,32,257,21792,16465,74251]

theorem envBound48676 : H12AffineFastState.Bounded env48676 := by
  intro p hp
  have h : env48676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48675_48676 : H12AffineEnvironment.transform 14 29789 env48675 = env48676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env48675 == env48676) = true)

theorem identity48676 : scanCanonicalize (H12AffineFastState.compose env48676 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48676 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13388,10281,1025,29788,4161,33,17,21762,8193,64,23809,5393,17664,10281,1365,32,257,21792,16465,513]

theorem envBound48677 : H12AffineFastState.Bounded env48677 := by
  intro p hp
  have h : env48677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48676_48677 : H12AffineEnvironment.transform 15 8202 env48676 = env48677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48676 == env48677) = true)

theorem identity48677 : scanCanonicalize (H12AffineFastState.compose env48677 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound48677 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,81,8202,13388,10281,1025,80,4161,33,17,8462,8193,64,10509,5393,12556,10281,1365,32,257,8492,13405,513]

theorem envBound48678 : H12AffineFastState.Bounded env48678 := by
  intro p hp
  have h : env48678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48677_48678 : H12AffineEnvironment.transform 13 13324 env48677 = env48678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env48677 == env48678) = true)

theorem identity48678 : scanCanonicalize (H12AffineFastState.compose env48678 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48678 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env48679 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,1,8202,13340,10281,1025,0,4113,33,17,8462,8193,16,10509,5393,12556,10281,1285,32,257,8492,13325,513]

theorem envBound48679 : H12AffineFastState.Bounded env48679 := by
  intro p hp
  have h : env48679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48678_48679 : H12AffineEnvironment.transform 5 16 env48678 = env48679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48678 == env48679) = true)

theorem identity48679 : scanCanonicalize (H12AffineFastState.compose env48679 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48679 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env48680 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8192,13324,1,8202,13340,10281,1025,0,4113,33,17,8203,8193,16,10248,5140,12297,10281,1024,32,4,8233,13325,513]

theorem envBound48680 : H12AffineFastState.Bounded env48680 := by
  intro p hp
  have h : env48680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48679_48680 : H12AffineEnvironment.transform 7 5 env48679 = env48680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48679 == env48680) = true)

theorem identity48680 : scanCanonicalize (H12AffineFastState.compose env48680 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound48680 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48681 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,5124,1,2,5140,2081,1025,0,4113,33,17,3,9,16,2048,5140,4097,2081,1024,32,4,33,5125,513]

theorem envBound48681 : H12AffineFastState.Bounded env48681 := by
  intro p hp
  have h : env48681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48680_48681 : H12AffineEnvironment.transform 12 8 env48680 = env48681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env48680 == env48681) = true)

theorem identity48681 : scanCanonicalize (H12AffineFastState.compose env48681 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48682 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,8,5124,1,2,5140,2048,1025,0,4113,0,17,3,9,16,2048,5140,4097,2048,1024,1,4,0,5125,513]

theorem envBound48682 : H12AffineFastState.Bounded env48682 := by
  intro p hp
  have h : env48682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48681_48682 : H12AffineEnvironment.transform 4 1 env48681 = env48682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48681 == env48682) = true)

theorem identity48682 : scanCanonicalize (H12AffineFastState.compose env48682 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound48682 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48683 : List Nat := [2,4,8,16,1,16,9,5,512,1024,522,4096,8,5124,1,2,5140,522,1025,0,4113,0,17,3,9,16,522,5140,4097,522,1024,1,4,0,5125,513]

theorem envBound48683 : H12AffineFastState.Bounded env48683 := by
  intro p hp
  have h : env48683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48682_48683 : H12AffineEnvironment.transform 10 522 env48682 = env48683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env48682 == env48683) = true)

def env48684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10401,1025,32769,4161,73770,120015,21762,8328,64,43477,115151,102878,56572,1500,168,257,21792,46213,74251]

theorem envBound48684 : H12AffineFastState.Bounded env48684 := by
  intro p hp
  have h : env48684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48659_48684 : H12AffineEnvironment.transform 17 10401 env48659 = env48684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env48659 == env48684) = true)

def env48685 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,4161,73770,119879,21762,8192,64,43357,115015,102742,56436,1364,32,257,21792,46093,74251]

theorem envBound48685 : H12AffineFastState.Bounded env48685 := by
  intro p hp
  have h : env48685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48684_48685 : H12AffineEnvironment.transform 6 8 env48684 = env48685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48684 == env48685) = true)

theorem identity48685 : scanCanonicalize (H12AffineFastState.compose env48685 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound48685 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48686 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,38160,10281,1025,32769,4161,21792,41293,21762,8192,64,43357,46157,58460,56436,1364,32,257,21792,46093,22273]

theorem envBound48686 : H12AffineFastState.Bounded env48686 := by
  intro p hp
  have h : env48686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48685_48686 : H12AffineEnvironment.transform 15 29962 env48685 = env48686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env48685 == env48686) = true)

theorem identity48686 : scanCanonicalize (H12AffineFastState.compose env48686 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound48686 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env48687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,29962,24860,10281,1025,29709,4161,21792,21825,21762,8192,64,23889,16449,4176,10360,1364,32,257,21792,16385,22273]

theorem envBound48687 : H12AffineFastState.Bounded env48687 := by
  intro p hp
  have h : env48687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48686_48687 : H12AffineEnvironment.transform 14 29708 env48686 = env48687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env48686 == env48687) = true)

theorem identity48687 : scanCanonicalize (H12AffineFastState.compose env48687 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound48687 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,81,343,5441,10281,1025,80,4161,8573,8476,8543,8192,64,10508,13340,4176,10360,1364,32,257,8573,13404,9052]

theorem envBound48688 : H12AffineFastState.Bounded env48688 := by
  intro p hp
  have h : env48688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48687_48688 : H12AffineEnvironment.transform 13 13405 env48687 = env48688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env48687 == env48688) = true)

theorem identity48688 : scanCanonicalize (H12AffineFastState.compose env48688 (packedSelected [1,4,6,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7544) := by decide +kernel

theorem selectedBound48688 : packedSelected [1,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env48689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7544,2341,81,343,5441,5457,1025,80,4161,7173,7268,7207,7544,64,5236,2404,4176,5376,1364,32,257,7173,2340,7716]

theorem envBound48689 : H12AffineFastState.Bounded env48689 := by
  intro p hp
  have h : env48689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48688_48689 : H12AffineEnvironment.transform 12 7544 env48688 = env48689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7544 env48688 == env48689) = true)

theorem identity48689 : scanCanonicalize (H12AffineFastState.compose env48689 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound48689 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3109,349,2341,81,343,2404,2420,1025,80,3172,32,65,2,349,64,2129,2404,3189,2341,1364,32,257,32,2340,513]

theorem envBound48690 : H12AffineFastState.Bounded env48690 := by
  intro p hp
  have h : env48690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48689_48690 : H12AffineEnvironment.transform 11 3109 env48689 = env48690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env48689 == env48690) = true)

theorem identity48690 : scanCanonicalize (H12AffineFastState.compose env48690 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound48690 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48691 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3109,41,2129,81,35,2064,2048,1025,80,3172,32,65,2,41,64,2129,2064,3189,2129,1056,32,117,32,2128,513]

theorem envBound48691 : H12AffineFastState.Bounded env48691 := by
  intro p hp
  have h : env48691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48690_48691 : H12AffineEnvironment.transform 7 116 env48690 = env48691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48690 == env48691) = true)

theorem identity48691 : scanCanonicalize (H12AffineFastState.compose env48691 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound48691 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48692 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1061,0,41,1140,81,35,1077,1061,1025,80,65,32,65,2,41,64,1140,1077,80,1140,1056,32,117,32,1141,513]

theorem envBound48692 : H12AffineFastState.Bounded env48692 := by
  intro p hp
  have h : env48692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48691_48692 : H12AffineEnvironment.transform 10 1061 env48691 = env48692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env48691 == env48692) = true)

theorem identity48692 : scanCanonicalize (H12AffineFastState.compose env48692 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound48692 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env48693 : List Nat := [2,4,8,16,32,64,8,116,512,101,64,0,41,17,81,35,80,64,100,80,65,32,65,2,41,64,17,80,80,17,69,32,117,32,16,513]

theorem envBound48693 : H12AffineFastState.Bounded env48693 := by
  intro p hp
  have h : env48693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48692_48693 : H12AffineEnvironment.transform 9 101 env48692 = env48693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env48692 == env48693) = true)

theorem identity48693 : scanCanonicalize (H12AffineFastState.compose env48693 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound48693 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env48694 : List Nat := [2,4,8,16,32,1,8,53,512,36,1,0,41,17,16,35,17,1,37,17,0,32,0,2,41,1,17,17,17,17,4,32,52,32,16,513]

theorem envBound48694 : H12AffineFastState.Bounded env48694 := by
  intro p hp
  have h : env48694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48693_48694 : H12AffineEnvironment.transform 5 1 env48693 = env48694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48693 == env48694) = true)

def env48695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1025,32769,4161,73770,119878,21762,8193,64,43356,115014,102743,56437,1365,33,257,21792,46092,74251]

theorem envBound48695 : H12AffineFastState.Bounded env48695 := by
  intro p hp
  have h : env48695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48684_48695 : H12AffineEnvironment.transform 6 9 env48684 = env48695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48684 == env48695) = true)

theorem identity48695 : scanCanonicalize (H12AffineFastState.compose env48695 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound48695 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48696 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,10280,1025,32769,4161,62588,16,21762,8193,64,43356,5392,17665,56437,1365,33,257,21792,46092,63069]

theorem envBound48696 : H12AffineFastState.Bounded env48696 := by
  intro p hp
  have h : env48696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48695_48696 : H12AffineEnvironment.transform 15 54358 env48695 = env48696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env48695 == env48696) = true)

theorem identity48696 : scanCanonicalize (H12AffineFastState.compose env48696 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound48696 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48697 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13389,10280,1025,29789,4161,32,16,21762,8193,64,23808,5392,17665,10281,1365,33,257,21792,16464,513]

theorem envBound48697 : H12AffineFastState.Bounded env48697 := by
  intro p hp
  have h : env48697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48696_48697 : H12AffineEnvironment.transform 14 29788 env48696 = env48697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env48696 == env48697) = true)

theorem identity48697 : scanCanonicalize (H12AffineFastState.compose env48697 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound48697 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48698 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,20497,1095,4096,3173,1025,20496,4161,32,16,21762,1100,64,23808,5392,17665,3172,1365,33,257,21792,16464,513]

theorem envBound48698 : H12AffineFastState.Bounded env48698 := by
  intro p hp
  have h : env48698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48697_48698 : H12AffineEnvironment.transform 12 1101 env48697 = env48698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env48697 == env48698) = true)

theorem identity48698 : scanCanonicalize (H12AffineFastState.compose env48698 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound48698 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env48699 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,1101,16384,16465,1095,64,3173,1025,16464,1,32,16,17730,1100,64,19776,1360,17665,3172,1365,33,257,17760,16464,513]

theorem envBound48699 : H12AffineFastState.Bounded env48699 := by
  intro p hp
  have h : env48699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48698_48699 : H12AffineEnvironment.transform 11 64 env48698 = env48699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env48698 == env48699) = true)

theorem identity48699 : scanCanonicalize (H12AffineFastState.compose env48699 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48699 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48700 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,64,349,16384,16465,343,64,2421,273,16464,1,32,16,16466,348,64,18512,64,16401,2420,69,33,257,16496,16464,513]

theorem envBound48700 : H12AffineFastState.Bounded env48700 := by
  intro p hp
  have h : env48700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48699_48700 : H12AffineEnvironment.transform 9 272 env48699 = env48700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48699 == env48700) = true)

theorem identity48700 : scanCanonicalize (H12AffineFastState.compose env48700 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound48700 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48701 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,64,349,81,0,343,64,2421,273,1,1,32,16,3,348,64,2049,64,64,2420,69,33,257,33,1,513]

theorem envBound48701 : H12AffineFastState.Bounded env48701 := by
  intro p hp
  have h : env48701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48700_48701 : H12AffineEnvironment.transform 13 81 env48700 = env48701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env48700 == env48701) = true)

theorem identity48701 : scanCanonicalize (H12AffineFastState.compose env48701 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48701 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48702 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,64,120,81,0,114,64,2128,52,1,1,32,16,3,121,64,2049,64,64,2129,69,33,36,33,1,513]

theorem envBound48702 : H12AffineFastState.Bounded env48702 := by
  intro p hp
  have h : env48702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48701_48702 : H12AffineEnvironment.transform 7 37 env48701 = env48702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48701 == env48702) = true)

theorem identity48702 : scanCanonicalize (H12AffineFastState.compose env48702 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48702 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48703 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,17,41,0,0,35,17,2049,52,1,1,32,16,3,40,17,2049,17,17,2048,20,33,36,33,1,513]

theorem envBound48703 : H12AffineFastState.Bounded env48703 := by
  intro p hp
  have h : env48703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48702_48703 : H12AffineEnvironment.transform 5 17 env48702 = env48703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48702 == env48703) = true)

theorem identity48703 : scanCanonicalize (H12AffineFastState.compose env48703 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound48703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48704 : List Nat := [2,4,8,16,32,17,9,37,512,53,513,17,41,0,0,35,17,512,52,1,1,32,16,3,40,17,512,17,17,513,20,33,36,33,1,513]

theorem envBound48704 : H12AffineFastState.Bounded env48704 := by
  intro p hp
  have h : env48704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48703_48704 : H12AffineEnvironment.transform 10 513 env48703 = env48704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env48703 == env48704) = true)

theorem identity48704 : scanCanonicalize (H12AffineFastState.compose env48704 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound48704 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48705 : List Nat := [2,4,8,16,26,17,9,31,512,15,513,17,19,0,0,25,17,512,14,1,1,26,16,3,18,17,512,17,17,513,20,27,30,27,1,513]

theorem envBound48705 : H12AffineFastState.Bounded env48705 := by
  intro p hp
  have h : env48705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48704_48705 : H12AffineEnvironment.transform 4 26 env48704 = env48705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env48704 == env48705) = true)

theorem identity48705 : scanCanonicalize (H12AffineFastState.compose env48705 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48705 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48706 : List Nat := [2,4,8,16,26,17,9,31,1,15,0,17,19,0,0,25,17,1,14,1,1,26,16,3,18,17,1,17,17,0,20,27,30,27,1,0]

theorem envBound48706 : H12AffineFastState.Bounded env48706 := by
  intro p hp
  have h : env48706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48705_48706 : H12AffineEnvironment.transform 8 1 env48705 = env48706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48705 == env48706) = true)

def env48707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237468,243089,8328,64,6705548,2240797,160076,2417692,2102684,6475856,257,21793,46212,2175563]

theorem envBound48707 : H12AffineFastState.Bounded env48707 := by
  intro p hp
  have h : env48707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48565_48707 : H12AffineEnvironment.transform 23 243089 env48565 = env48707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env48565 == env48707) = true)

def env48708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,2237468,243089,8328,64,2144660,2240797,160076,2417692,2102684,2373704,257,21793,46212,2175563]

theorem envBound48708 : H12AffineFastState.Bounded env48708 := by
  intro p hp
  have h : env48708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48707_48708 : H12AffineEnvironment.transform 21 452632 env48707 = env48708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env48707 == env48708) = true)

def env48709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,144476,243089,8328,64,43476,139613,160076,324700,1500,272392,257,21793,46212,74251]

theorem envBound48709 : H12AffineFastState.Bounded env48709 := by
  intro p hp
  have h : env48709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48708_48709 : H12AffineEnvironment.transform 20 4160 env48708 = env48709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48708 == env48709) = true)

theorem identity48709 : scanCanonicalize (H12AffineFastState.compose env48709 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound48709 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,400589,144476,213316,8328,64,23809,139613,160076,262281,1500,272392,257,21793,16465,74251]

theorem envBound48710 : H12AffineFastState.Bounded env48710 := by
  intro p hp
  have h : env48710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48709_48710 : H12AffineEnvironment.transform 14 29909 env48709 = env48710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env48709 == env48710) = true)

def env48711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32240,1025,29908,4160,155965,144476,213316,8328,64,23809,139613,160076,32121,1500,22008,257,21793,16465,74251]

theorem envBound48711 : H12AffineFastState.Bounded env48711 := by
  intro p hp
  have h : env48711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48710_48711 : H12AffineEnvironment.transform 17 32240 env48710 = env48711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env48710 == env48711) = true)

theorem identity48711 : scanCanonicalize (H12AffineFastState.compose env48711 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79179) := by decide +kernel

theorem selectedBound48711 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79179,32240,1025,29908,4160,87158,65815,29711,8328,64,23809,70678,82951,32121,1500,22008,257,21793,16465,74251]

theorem envBound48712 : H12AffineFastState.Bounded env48712 := by
  intro p hp
  have h : env48712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48711_48712 : H12AffineEnvironment.transform 16 79179 env48711 = env48712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79179 env48711 == env48712) = true)

theorem identity48712 : scanCanonicalize (H12AffineFastState.compose env48712 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound48712 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env48713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30082,16585,32240,1025,29908,4160,8692,29845,29711,8328,64,23809,24980,12677,32121,1500,22008,257,21793,16465,22409]

theorem envBound48713 : H12AffineFastState.Bounded env48713 := by
  intro p hp
  have h : env48713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48712_48713 : H12AffineEnvironment.transform 15 30082 env48712 = env48713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env48712 == env48713) = true)

theorem identity48713 : scanCanonicalize (H12AffineFastState.compose env48713 (packedSelected [4,9,10,11,12,15,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound48713 : packedSelected [4,9,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env48714 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29709,30042,16401,32040,1025,29708,4160,8492,29773,29711,8272,64,23809,24908,12637,32121,1284,21792,257,21793,16465,22353]

theorem envBound48714 : H12AffineFastState.Bounded env48714 := by
  intro p hp
  have h : env48714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48713_48714 : H12AffineEnvironment.transform 6 88 env48713 = env48714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env48713 == env48714) = true)

theorem identity48714 : scanCanonicalize (H12AffineFastState.compose env48714 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound48714 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env48715 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13405,80,263,13388,2421,1025,81,4160,8492,16,82,8272,64,10588,5393,12637,2340,1284,8573,257,8572,13324,8972]

theorem envBound48715 : H12AffineFastState.Bounded env48715 := by
  intro p hp
  have h : env48715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48714_48715 : H12AffineEnvironment.transform 13 13405 env48714 = env48715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env48714 == env48715) = true)

theorem identity48715 : scanCanonicalize (H12AffineFastState.compose env48715 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48715 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48716 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5456,80,263,5441,2421,1025,81,4160,33,16,82,349,64,2129,5393,4176,2340,1284,112,257,113,5377,513]

theorem envBound48716 : H12AffineFastState.Bounded env48716 := by
  intro p hp
  have h : env48716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48715_48716 : H12AffineEnvironment.transform 12 269 env48715 = env48716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48715 == env48716) = true)

theorem identity48716 : scanCanonicalize (H12AffineFastState.compose env48716 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound48716 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48717 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,121,5156,80,115,5173,2049,1025,81,4160,33,16,82,41,64,2129,5221,4176,2128,1136,112,117,113,5237,513]

theorem envBound48717 : H12AffineFastState.Bounded env48717 := by
  intro p hp
  have h : env48717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48716_48717 : H12AffineEnvironment.transform 7 116 env48716 = env48717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48716 == env48717) = true)

def env48718 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,35,5173,2049,1025,1,4112,33,16,2,41,16,2049,5173,4096,2048,1056,32,37,33,5157,513]

theorem envBound48718 : H12AffineFastState.Bounded env48718 := by
  intro p hp
  have h : env48718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48717_48718 : H12AffineEnvironment.transform 5 16 env48717 = env48718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48717 == env48718) = true)

theorem identity48718 : scanCanonicalize (H12AffineFastState.compose env48718 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48719 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,0,35,4097,2049,53,1,4112,33,16,2,41,16,2049,4097,4096,2048,20,32,37,33,4113,513]

theorem envBound48719 : H12AffineFastState.Bounded env48719 := by
  intro p hp
  have h : env48719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48718_48719 : H12AffineEnvironment.transform 9 52 env48718 = env48719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48718 == env48719) = true)

theorem identity48719 : scanCanonicalize (H12AffineFastState.compose env48719 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound48719 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48720 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,4096,41,4112,0,35,4097,49,53,1,4112,33,16,2,41,16,49,4097,4096,48,20,32,37,33,4113,513]

theorem envBound48720 : H12AffineFastState.Bounded env48720 := by
  intro p hp
  have h : env48720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48719_48720 : H12AffineEnvironment.transform 10 48 env48719 = env48720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env48719 == env48720) = true)

theorem identity48720 : scanCanonicalize (H12AffineFastState.compose env48720 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound48720 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48721 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,41,48,0,35,33,49,53,1,48,33,16,2,41,16,49,33,32,48,20,32,37,33,49,513]

theorem envBound48721 : H12AffineFastState.Bounded env48721 := by
  intro p hp
  have h : env48721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48720_48721 : H12AffineEnvironment.transform 11 32 env48720 = env48721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env48720 == env48721) = true)

def leafEnv48721 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,32,41,48,0,35,33,49,53,1,48,33,16,2,21,41,1,16,49,33,32,48,20,32,37,33,5,35,49,513,1,49,0]

def active48721 : List Nat := [0,1,2,3,4,8]

def tree48721 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48721 : H12WitnessSearch.Good tree48721 := H12GlobalWitnessIndex.good

theorem leafIdentity48721 : H12AffineFastState.composeSystem env48721 rootObs = leafEnv48721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48721 rootObs == leafEnv48721) = true)

theorem terminalChecked48721 : H12PackedTerminal.terminalCheckFast leafEnv48721 active48721 tree48721 = true := by decide +kernel

def env48722 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5156,1,34,5173,2049,1025,0,4113,33,16,3,41,17,2048,5172,4097,2049,1057,33,36,32,5156,513]

theorem envBound48722 : H12AffineFastState.Bounded env48722 := by
  intro p hp
  have h : env48722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48717_48722 : H12AffineEnvironment.transform 5 17 env48717 = env48722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48717 == env48722) = true)

def env48723 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1044,1,34,1029,2049,1025,0,33,33,16,3,41,17,2048,1028,49,2049,1057,33,36,32,1044,513]

theorem envBound48723 : H12AffineFastState.Bounded env48723 := by
  intro p hp
  have h : env48723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48722_48723 : H12AffineEnvironment.transform 11 48 env48722 = env48723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48722 == env48723) = true)

theorem identity48723 : scanCanonicalize (H12AffineFastState.compose env48723 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48724 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,48,40,33,1,34,48,2049,52,0,33,33,16,3,41,17,2048,49,49,2049,20,33,36,32,33,513]

theorem envBound48724 : H12AffineFastState.Bounded env48724 := by
  intro p hp
  have h : env48724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48723_48724 : H12AffineEnvironment.transform 9 53 env48723 = env48724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48723 == env48724) = true)

theorem identity48724 : scanCanonicalize (H12AffineFastState.compose env48724 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound48724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48725 : List Nat := [2,4,8,16,32,17,9,37,42,53,2048,48,40,33,1,34,48,2049,52,0,33,33,16,3,41,17,2048,49,49,2049,20,33,36,32,33,43]

theorem envBound48725 : H12AffineFastState.Bounded env48725 := by
  intro p hp
  have h : env48725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48724_48725 : H12AffineEnvironment.transform 8 42 env48724 = env48725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env48724 == env48725) = true)

def leafEnv48725 : List Nat := [2,4,8,16,32,17,9,37,42,53,2048,48,40,33,1,34,48,2049,52,0,33,33,16,3,21,41,1,17,2048,49,49,2049,20,33,36,32,5,35,33,43,1,33,0]

def active48725 : List Nat := [0,1,2,3,4,10]

def tree48725 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48725 : H12WitnessSearch.Good tree48725 := H12GlobalWitnessIndex.good

theorem leafIdentity48725 : H12AffineFastState.composeSystem env48725 rootObs = leafEnv48725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48725 rootObs == leafEnv48725) = true)

theorem terminalChecked48725 : H12PackedTerminal.terminalCheckFast leafEnv48725 active48725 tree48725 = true := by decide +kernel

def env48726 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1045,1,34,1028,2049,1025,0,32,33,16,3,41,17,2048,1029,48,2049,1057,33,36,32,1045,513]

theorem envBound48726 : H12AffineFastState.Bounded env48726 := by
  intro p hp
  have h : env48726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48722_48726 : H12AffineEnvironment.transform 11 49 env48722 = env48726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48722 == env48726) = true)

def env48727 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,40,33,1,34,48,2049,53,0,32,33,16,3,41,17,2048,49,48,2049,21,33,36,32,33,513]

theorem envBound48727 : H12AffineFastState.Bounded env48727 := by
  intro p hp
  have h : env48727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48726_48727 : H12AffineEnvironment.transform 9 52 env48726 = env48727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48726 == env48727) = true)

def env48728 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,49,40,32,1,34,49,2049,52,0,32,33,16,3,41,17,2048,48,48,2049,20,33,36,32,32,513]

theorem envBound48728 : H12AffineFastState.Bounded env48728 := by
  intro p hp
  have h : env48728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48726_48728 : H12AffineEnvironment.transform 9 53 env48726 = env48728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48726 == env48728) = true)

theorem identity48728 : scanCanonicalize (H12AffineFastState.compose env48728 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48728 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48729 : List Nat := [2,4,8,16,32,17,9,37,43,53,2048,49,40,32,1,34,49,2049,52,0,32,33,16,3,41,17,2048,48,48,2049,20,33,36,32,32,42]

theorem envBound48729 : H12AffineFastState.Bounded env48729 := by
  intro p hp
  have h : env48729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48728_48729 : H12AffineEnvironment.transform 8 43 env48728 = env48729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48728 == env48729) = true)

def leafEnv48729 : List Nat := [2,4,8,16,32,17,9,37,43,53,2048,49,40,32,1,34,49,2049,52,0,32,33,16,3,21,41,1,17,2048,48,48,2049,20,33,36,32,5,35,32,42,1,32,0]

def active48729 : List Nat := [0,1,2,3,4,10]

def tree48729 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48729 : H12WitnessSearch.Good tree48729 := H12GlobalWitnessIndex.good

theorem leafIdentity48729 : H12AffineFastState.composeSystem env48729 rootObs = leafEnv48729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48729 rootObs == leafEnv48729) = true)

theorem terminalChecked48729 : H12PackedTerminal.terminalCheckFast leafEnv48729 active48729 tree48729 = true := by decide +kernel

def env48730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32241,1025,29908,4160,155964,144476,213316,8328,64,23809,139613,160076,32120,1500,22009,257,21793,16465,74251]

theorem envBound48730 : H12AffineFastState.Bounded env48730 := by
  intro p hp
  have h : env48730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48710_48730 : H12AffineEnvironment.transform 17 32241 env48710 = env48730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env48710 == env48730) = true)

theorem identity48730 : scanCanonicalize (H12AffineFastState.compose env48730 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79298) := by decide +kernel

theorem selectedBound48730 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79298,32241,1025,29908,4160,87294,65950,29830,8328,64,23809,70815,83086,32120,1500,22009,257,21793,16465,74251]

theorem envBound48731 : H12AffineFastState.Bounded env48731 := by
  intro p hp
  have h : env48731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48730_48731 : H12AffineEnvironment.transform 16 79298 env48730 = env48731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79298 env48730 == env48731) = true)

theorem identity48731 : scanCanonicalize (H12AffineFastState.compose env48731 (packedSelected [1,5,8,11,16,17,20,24,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48731 : packedSelected [1,5,8,11,16,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env48732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,5577,32241,1025,29908,4160,29941,8597,29830,8328,64,23809,13460,25733,32120,1500,22009,257,21793,16465,512]

theorem envBound48732 : H12AffineFastState.Bounded env48732 := by
  intro p hp
  have h : env48732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48731_48732 : H12AffineEnvironment.transform 15 8203 env48731 = env48732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48731 == env48732) = true)

theorem identity48732 : scanCanonicalize (H12AffineFastState.compose env48732 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound48732 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env48733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13688,429,8203,5577,2185,1025,428,4160,397,8597,510,8328,64,10361,13460,4605,2048,1500,8321,257,8281,13609,512]

theorem envBound48733 : H12AffineFastState.Bounded env48733 := by
  intro p hp
  have h : env48733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48732_48733 : H12AffineEnvironment.transform 13 13688 env48732 = env48733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env48732 == env48733) = true)

theorem identity48733 : scanCanonicalize (H12AffineFastState.compose env48733 (packedSelected [2,4,6,11,17,18,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48733 : packedSelected [2,4,6,11,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env48734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,293,8203,5441,2049,1025,292,4160,261,8477,374,8192,64,10361,13340,4469,2048,1364,8201,257,8281,13609,512]

theorem envBound48734 : H12AffineFastState.Bounded env48734 := by
  intro p hp
  have h : env48734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48733_48734 : H12AffineEnvironment.transform 6 8 env48733 = env48734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48733 == env48734) = true)

theorem identity48734 : scanCanonicalize (H12AffineFastState.compose env48734 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48734 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5236,293,263,5441,2049,1025,292,4160,261,17,374,268,64,2421,5392,4469,2048,1364,261,257,341,5157,512]

theorem envBound48735 : H12AffineFastState.Bounded env48735 := by
  intro p hp
  have h : env48735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48734_48735 : H12AffineEnvironment.transform 12 268 env48734 = env48735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48734 == env48735) = true)

theorem identity48735 : scanCanonicalize (H12AffineFastState.compose env48735 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound48735 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env48736 : List Nat := [2,4,8,16,32,64,8,256,512,68,2048,4096,268,4144,293,263,4357,2049,69,292,4160,261,17,374,268,64,2421,4436,4469,2048,272,261,257,341,4193,512]

theorem envBound48736 : H12AffineFastState.Bounded env48736 := by
  intro p hp
  have h : env48736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48735_48736 : H12AffineEnvironment.transform 9 68 env48735 = env48736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env48735 == env48736) = true)

theorem identity48736 : scanCanonicalize (H12AffineFastState.compose env48736 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48736 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env48737 : List Nat := [2,4,8,16,32,64,8,37,512,68,2048,4096,41,4144,0,34,4128,2049,69,1,4160,32,17,83,41,64,2128,4209,4176,2048,53,32,36,112,4193,512]

theorem envBound48737 : H12AffineFastState.Bounded env48737 := by
  intro p hp
  have h : env48737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48736_48737 : H12AffineEnvironment.transform 7 37 env48736 = env48737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48736 == env48737) = true)

theorem identity48737 : scanCanonicalize (H12AffineFastState.compose env48737 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48737 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48738 : List Nat := [2,4,8,0,32,64,8,37,512,68,2048,4096,41,4128,0,34,4128,2049,69,1,4160,32,1,67,41,64,2112,4193,4160,2048,37,32,36,96,4193,512]

theorem envBound48738 : H12AffineFastState.Bounded env48738 := by
  intro p hp
  have h : env48738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48737_48738 : H12AffineEnvironment.transform 3 0 env48737 = env48738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48737 == env48738) = true)

theorem identity48738 : scanCanonicalize (H12AffineFastState.compose env48738 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound48738 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env48739 : List Nat := [2,4,8,0,32,64,8,37,512,68,2048,2154,41,2122,0,34,2122,2049,69,1,2090,32,1,67,41,64,2112,2059,2090,2048,37,32,36,96,2059,512]

theorem envBound48739 : H12AffineFastState.Bounded env48739 := by
  intro p hp
  have h : env48739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48738_48739 : H12AffineEnvironment.transform 11 2154 env48738 = env48739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env48738 == env48739) = true)

theorem identity48739 : scanCanonicalize (H12AffineFastState.compose env48739 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48739 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48740 : List Nat := [2,4,8,0,1,64,8,4,512,68,2048,2123,8,2122,0,3,2122,2049,69,1,2059,1,1,67,8,64,2112,2059,2059,2048,4,1,5,65,2059,512]

theorem envBound48740 : H12AffineFastState.Bounded env48740 := by
  intro p hp
  have h : env48740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48739_48740 : H12AffineEnvironment.transform 4 1 env48739 = env48740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48739 == env48740) = true)

theorem identity48740 : scanCanonicalize (H12AffineFastState.compose env48740 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound48740 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48741 : List Nat := [2,4,8,0,1,64,8,4,512,68,71,12,8,13,0,3,13,70,69,1,76,1,1,67,8,64,7,76,76,71,4,1,5,65,76,512]

theorem envBound48741 : H12AffineFastState.Bounded env48741 := by
  intro p hp
  have h : env48741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48740_48741 : H12AffineEnvironment.transform 10 71 env48740 = env48741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env48740 == env48741) = true)

theorem identity48741 : scanCanonicalize (H12AffineFastState.compose env48741 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48741 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env48742 : List Nat := [2,4,3,0,1,64,3,4,512,68,71,7,3,6,0,3,6,70,69,1,71,1,1,67,3,64,7,71,71,71,4,1,5,65,71,512]

theorem envBound48742 : H12AffineFastState.Bounded env48742 := by
  intro p hp
  have h : env48742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48741_48742 : H12AffineEnvironment.transform 2 3 env48741 = env48742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48741 == env48742) = true)

theorem identity48742 : scanCanonicalize (H12AffineFastState.compose env48742 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound48742 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48743 : List Nat := [2,4,3,0,1,0,3,4,512,4,7,7,3,6,0,3,6,6,5,1,7,1,1,3,3,0,7,7,7,7,4,1,5,1,7,512]

theorem envBound48743 : H12AffineFastState.Bounded env48743 := by
  intro p hp
  have h : env48743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48742_48743 : H12AffineEnvironment.transform 5 0 env48742 = env48743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48742 == env48743) = true)

theorem identity48743 : scanCanonicalize (H12AffineFastState.compose env48743 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound48743 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48744 : List Nat := [2,4,3,0,1,0,3,4,3,4,7,7,3,6,0,3,6,6,5,1,7,1,1,3,3,0,7,7,7,7,4,1,5,1,7,3]

theorem envBound48744 : H12AffineFastState.Bounded env48744 := by
  intro p hp
  have h : env48744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48743_48744 : H12AffineEnvironment.transform 8 3 env48743 = env48744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env48743 == env48744) = true)

def env48745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,144477,243089,8328,64,43477,139612,160076,324701,1501,272393,257,21793,46212,74250]

theorem envBound48745 : H12AffineFastState.Bounded env48745 := by
  intro p hp
  have h : env48745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48708_48745 : H12AffineEnvironment.transform 20 4161 env48708 = env48745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48708 == env48745) = true)

theorem identity48745 : scanCanonicalize (H12AffineFastState.compose env48745 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound48745 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318548,17,98781,8328,64,43477,5392,17664,324701,1501,272393,257,21793,46212,74250]

theorem envBound48746 : H12AffineFastState.Bounded env48746 := by
  intro p hp
  have h : env48746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48745_48746 : H12AffineEnvironment.transform 16 13388 env48745 = env48746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env48745 == env48746) = true)

def env48747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318548,17,98645,8192,64,43357,5392,17664,324701,1365,272393,257,21793,46092,74250]

theorem envBound48747 : H12AffineFastState.Bounded env48747 := by
  intro p hp
  have h : env48747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48746_48747 : H12AffineEnvironment.transform 6 8 env48746 = env48747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48746 == env48747) = true)

theorem identity48747 : scanCanonicalize (H12AffineFastState.compose env48747 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound48747 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,35189,1025,32769,4161,21793,17,98645,8192,64,43357,5392,17664,32040,1365,41340,257,21793,46092,74250]

theorem envBound48748 : H12AffineFastState.Bounded env48748 := by
  intro p hp
  have h : env48748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48747_48748 : H12AffineEnvironment.transform 17 35189 env48747 = env48748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env48747 == env48748) = true)

theorem identity48748 : scanCanonicalize (H12AffineFastState.compose env48748 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound48748 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,262,13388,35189,1025,32769,4161,21793,17,32851,8192,64,43357,5392,17664,32040,1365,41340,257,21793,46092,8972]

theorem envBound48749 : H12AffineFastState.Bounded env48749 := by
  intro p hp
  have h : env48749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48748_48749 : H12AffineEnvironment.transform 15 262 env48748 = env48749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env48748 == env48749) = true)

theorem identity48749 : scanCanonicalize (H12AffineFastState.compose env48749 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound48749 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,262,13388,23589,1025,21841,4161,21793,17,21763,8192,64,31757,5392,17664,32040,1365,29740,257,21793,24924,8972]

theorem envBound48750 : H12AffineFastState.Bounded env48750 := by
  intro p hp
  have h : env48750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48749_48750 : H12AffineEnvironment.transform 14 21840 env48749 = env48750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env48749 == env48750) = true)

theorem identity48750 : scanCanonicalize (H12AffineFastState.compose env48750 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound48750 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env48751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,300,16384,21840,262,5472,23589,1025,21841,4161,21793,17,21763,300,64,23841,5392,17664,23556,1365,21760,257,21793,16496,544]

theorem envBound48751 : H12AffineFastState.Bounded env48751 := by
  intro p hp
  have h : env48751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48750_48751 : H12AffineEnvironment.transform 12 300 env48750 = env48751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env48750 == env48751) = true)

theorem identity48751 : scanCanonicalize (H12AffineFastState.compose env48751 (packedSelected [1,2,4,6,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48751 : packedSelected [1,2,4,6,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env48752 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,41,16384,21589,3,5221,23589,1025,21588,4161,21540,17,21510,41,64,23588,5141,17413,23556,1104,21509,4,21540,16496,544]

theorem envBound48752 : H12AffineFastState.Bounded env48752 := by
  intro p hp
  have h : env48752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48751_48752 : H12AffineEnvironment.transform 7 5 env48751 = env48752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48751 == env48752) = true)

theorem identity48752 : scanCanonicalize (H12AffineFastState.compose env48752 (packedSelected [2,3,4,5,7,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 1621) := by decide +kernel

theorem selectedBound48752 : packedSelected [2,3,4,5,7,11,15] rootPS < 2^1333 := by decide +kernel

def env48753 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,41,1621,4608,3,5221,6768,1025,4609,4161,4721,17,4691,41,64,6769,5141,592,6737,1104,4688,4,4721,1573,544]

theorem envBound48753 : H12AffineFastState.Bounded env48753 := by
  intro p hp
  have h : env48753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48752_48753 : H12AffineEnvironment.transform 13 1621 env48752 = env48753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1621 env48752 == env48753) = true)

def env48754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318548,17,98644,8193,64,43356,5392,17664,324701,1364,272393,257,21793,46093,74250]

theorem envBound48754 : H12AffineFastState.Bounded env48754 := by
  intro p hp
  have h : env48754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48746_48754 : H12AffineEnvironment.transform 6 9 env48746 = env48754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48746 == env48754) = true)

theorem identity48754 : scanCanonicalize (H12AffineFastState.compose env48754 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound48754 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10281,1025,32769,4161,62589,17,98644,8193,64,43356,5392,17664,56436,1364,32,257,21793,46093,74250]

theorem envBound48755 : H12AffineFastState.Bounded env48755 := by
  intro p hp
  have h : env48755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48754_48755 : H12AffineEnvironment.transform 17 10281 env48754 = env48755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env48754 == env48755) = true)

theorem identity48755 : scanCanonicalize (H12AffineFastState.compose env48755 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound48755 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1025,29789,4161,33,17,95496,8193,64,23808,5392,17664,10280,1364,32,257,21793,16465,74250]

theorem envBound48756 : H12AffineFastState.Bounded env48756 := by
  intro p hp
  have h : env48756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48755_48756 : H12AffineEnvironment.transform 14 29788 env48755 = env48756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env48755 == env48756) = true)

theorem identity48756 : scanCanonicalize (H12AffineFastState.compose env48756 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound48756 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env48757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21591,13388,10281,1025,29789,4161,33,17,8543,8193,64,23808,5392,17664,10280,1364,32,257,21793,16465,30301]

theorem envBound48757 : H12AffineFastState.Bounded env48757 := by
  intro p hp
  have h : env48757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48756_48757 : H12AffineEnvironment.transform 15 21591 env48756 = env48757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env48756 == env48757) = true)

theorem identity48757 : scanCanonicalize (H12AffineFastState.compose env48757 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48757 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env48758 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,21511,13340,10281,1025,29709,4113,33,17,8463,8193,16,23808,5392,17664,10280,1284,32,257,21793,16385,30221]

theorem envBound48758 : H12AffineFastState.Bounded env48758 := by
  intro p hp
  have h : env48758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48757_48758 : H12AffineEnvironment.transform 5 16 env48757 = env48758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48757 == env48758) = true)

def env48759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,2237468,243089,8328,64,2144661,2240797,160076,2417692,2102684,2373705,257,21793,46212,2175563]

theorem envBound48759 : H12AffineFastState.Bounded env48759 := by
  intro p hp
  have h : env48759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48707_48759 : H12AffineEnvironment.transform 21 452633 env48707 = env48759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env48707 == env48759) = true)

def env48760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,144476,243089,8328,64,43477,139613,160076,324700,1500,272393,257,21793,46212,74251]

theorem envBound48760 : H12AffineFastState.Bounded env48760 := by
  intro p hp
  have h : env48760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48759_48760 : H12AffineEnvironment.transform 20 4160 env48759 = env48760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48759 == env48760) = true)

theorem identity48760 : scanCanonicalize (H12AffineFastState.compose env48760 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound48760 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4160,272513,62660,95497,8328,64,43477,57797,45524,324700,1500,272393,257,21793,46212,74251]

theorem envBound48761 : H12AffineFastState.Bounded env48761 := by
  intro p hp
  have h : env48761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48760_48761 : H12AffineEnvironment.transform 16 49304 env48760 = env48761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env48760 == env48761) = true)

theorem identity48761 : scanCanonicalize (H12AffineFastState.compose env48761 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48761 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env48762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49304,262144,1025,32769,4160,272513,62660,21763,8328,64,43477,57797,45524,324700,1500,272393,257,21793,46212,513]

theorem envBound48762 : H12AffineFastState.Bounded env48762 := by
  intro p hp
  have h : env48762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48761_48762 : H12AffineEnvironment.transform 15 8202 env48761 = env48762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48761 == env48762) = true)

theorem identity48762 : scanCanonicalize (H12AffineFastState.compose env48762 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound48762 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env48763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49304,56437,1025,32769,4160,62708,62660,21763,8328,64,43477,57797,45524,10281,1500,62588,257,21793,46212,513]

theorem envBound48763 : H12AffineFastState.Bounded env48763 := by
  intro p hp
  have h : env48763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48762_48763 : H12AffineEnvironment.transform 17 56437 env48762 = env48763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env48762 == env48763) = true)

theorem identity48763 : scanCanonicalize (H12AffineFastState.compose env48763 (packedSelected [2,3,6,7,10,14,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48763 : packedSelected [2,3,6,7,10,14,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env48764 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,49304,56357,1025,32769,4112,62628,62612,21763,8328,16,43397,57749,45444,10281,1420,62508,257,21793,46212,513]

theorem envBound48764 : H12AffineFastState.Bounded env48764 := by
  intro p hp
  have h : env48764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48763_48764 : H12AffineEnvironment.transform 5 16 env48763 = env48764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48763 == env48764) = true)

theorem identity48764 : scanCanonicalize (H12AffineFastState.compose env48764 (packedSelected [2,3,4,6,9,10,14,19,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48764 : packedSelected [2,3,4,6,9,10,14,19,20,24] rootPS < 2^1333 := by decide +kernel

def env48765 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,56357,1025,32769,4112,62509,62493,21763,8193,16,43276,57628,45325,10281,1285,62508,257,21793,46093,513]

theorem envBound48765 : H12AffineFastState.Bounded env48765 := by
  intro p hp
  have h : env48765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48764_48765 : H12AffineEnvironment.transform 6 9 env48764 = env48765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48764 == env48765) = true)

theorem identity48765 : scanCanonicalize (H12AffineFastState.compose env48765 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound48765 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env48766 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,8202,46108,43048,1025,32769,4112,32800,32784,8462,8193,16,43276,38161,45325,10281,1285,32801,257,8492,46093,513]

theorem envBound48766 : H12AffineFastState.Bounded env48766 := by
  intro p hp
  have h : env48766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48765_48766 : H12AffineEnvironment.transform 13 13325 env48765 = env48766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env48765 == env48766) = true)

theorem identity48766 : scanCanonicalize (H12AffineFastState.compose env48766 (packedSelected [2,4,6,7,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound48766 : packedSelected [2,4,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48767 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,293,8202,13625,10509,1025,292,4112,261,309,8462,8193,16,10281,5172,12328,10281,1285,260,257,8492,13608,513]

theorem envBound48767 : H12AffineFastState.Bounded env48767 := by
  intro p hp
  have h : env48767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48766_48767 : H12AffineEnvironment.transform 14 293 env48766 = env48767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env48766 == env48767) = true)

theorem identity48767 : scanCanonicalize (H12AffineFastState.compose env48767 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48767 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48768 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,293,263,5172,2048,1025,292,4112,261,309,3,268,16,2340,5172,4389,2340,1285,260,257,33,5157,513]

theorem envBound48768 : H12AffineFastState.Bounded env48768 := by
  intro p hp
  have h : env48768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48767_48768 : H12AffineEnvironment.transform 12 269 env48767 = env48768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48767 == env48768) = true)

def env48769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,144477,243089,8328,64,43476,139612,160076,324701,1501,272392,257,21793,46212,74250]

theorem envBound48769 : H12AffineFastState.Bounded env48769 := by
  intro p hp
  have h : env48769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48759_48769 : H12AffineEnvironment.transform 20 4161 env48759 = env48769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48759 == env48769) = true)

def env48770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,180273,144477,243089,8328,64,43476,139612,160076,56437,1501,32,257,21793,46212,74250]

theorem envBound48770 : H12AffineFastState.Bounded env48770 := by
  intro p hp
  have h : env48770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48769_48770 : H12AffineEnvironment.transform 17 10280 env48769 = env48770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48769 == env48770) = true)

def env48771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4161,21793,41293,73857,8328,64,43476,46156,58460,56437,1501,32,257,21793,46212,74250]

theorem envBound48771 : H12AffineFastState.Bounded env48771 := by
  intro p hp
  have h : env48771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48770_48771 : H12AffineEnvironment.transform 16 38160 env48770 = env48771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env48770 == env48771) = true)

theorem identity48771 : scanCanonicalize (H12AffineFastState.compose env48771 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48771 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,13389,10280,1025,8540,4161,21793,16,73857,8328,64,2185,5393,17665,32040,1501,32,257,21793,5593,74250]

theorem envBound48772 : H12AffineFastState.Bounded env48772 := by
  intro p hp
  have h : env48772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48771_48772 : H12AffineEnvironment.transform 14 8541 env48771 = env48772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48771 == env48772) = true)

theorem identity48772 : scanCanonicalize (H12AffineFastState.compose env48772 (packedSelected [5,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound48772 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env48773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,1094,13389,10280,1025,8540,4161,21793,16,9415,8328,64,2185,5393,17665,32040,1501,32,257,21793,5593,9804]

theorem envBound48773 : H12AffineFastState.Bounded env48773 := by
  intro p hp
  have h : env48773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48772_48773 : H12AffineEnvironment.transform 15 1094 env48772 = env48773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env48772 == env48773) = true)

theorem identity48773 : scanCanonicalize (H12AffineFastState.compose env48773 (packedSelected [2,6,7,9,20,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound48773 : packedSelected [2,6,7,9,20,22,27] rootPS < 2^1333 := by decide +kernel

def env48774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,16384,1344,1094,4176,3125,1025,1345,4161,21793,16,218,1173,64,2185,5393,17665,22837,1501,32,257,21793,5593,593]

theorem envBound48774 : H12AffineFastState.Bounded env48774 := by
  intro p hp
  have h : env48774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48773_48774 : H12AffineEnvironment.transform 12 1053 env48773 = env48774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env48773 == env48774) = true)

theorem identity48774 : scanCanonicalize (H12AffineFastState.compose env48774 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound48774 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48775 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1053,16384,1260,1094,4176,3125,1025,1261,4161,21645,16,218,1173,64,2185,5309,17581,22681,1137,32,173,21645,5237,593]

theorem envBound48775 : H12AffineFastState.Bounded env48775 := by
  intro p hp
  have h : env48775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48774_48775 : H12AffineEnvironment.transform 7 172 env48774 = env48775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env48774 == env48775) = true)

theorem identity48775 : scanCanonicalize (H12AffineFastState.compose env48775 (packedSelected [2,3,5,6,9,10,14,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48775 : packedSelected [2,3,5,6,9,10,14,22] rootPS < 2^1333 := by decide +kernel

def env48776 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1053,16384,1212,1046,4096,3125,1025,1213,4113,21645,16,138,1173,16,2185,5309,17581,22681,1057,32,173,21645,5157,513]

theorem envBound48776 : H12AffineFastState.Bounded env48776 := by
  intro p hp
  have h : env48776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48775_48776 : H12AffineEnvironment.transform 5 16 env48775 = env48776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48775 == env48776) = true)

theorem identity48776 : scanCanonicalize (H12AffineFastState.compose env48776 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound48776 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48777 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1053,5157,1212,1046,4096,3125,1025,1213,4113,168,16,138,1173,16,2185,5309,4232,3260,1057,32,173,168,5157,513]

theorem envBound48777 : H12AffineFastState.Bounded env48777 := by
  intro p hp
  have h : env48777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48776_48777 : H12AffineEnvironment.transform 13 5157 env48776 = env48777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env48776 == env48777) = true)

theorem identity48777 : scanCanonicalize (H12AffineFastState.compose env48777 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound48777 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env48778 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1196,1053,137,1212,1046,1196,3125,1025,1213,1213,168,16,138,1173,16,2185,17,1060,3260,1057,32,173,168,137,513]

theorem envBound48778 : H12AffineFastState.Bounded env48778 := by
  intro p hp
  have h : env48778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48777_48778 : H12AffineEnvironment.transform 11 1196 env48777 = env48778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env48777 == env48778) = true)

theorem identity48778 : scanCanonicalize (H12AffineFastState.compose env48778 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound48778 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48779 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1077,1196,1053,137,1212,1046,1196,0,1025,1213,1213,168,16,138,1173,16,1212,17,1060,137,1057,32,173,168,137,513]

theorem envBound48779 : H12AffineFastState.Bounded env48779 := by
  intro p hp
  have h : env48779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48778_48779 : H12AffineEnvironment.transform 10 1077 env48778 = env48779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env48778 == env48779) = true)

theorem identity48779 : scanCanonicalize (H12AffineFastState.compose env48779 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound48779 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env48780 : List Nat := [2,4,8,16,32,16,128,172,512,189,136,17,160,137,1,171,17,0,188,0,0,168,16,138,40,16,1,17,153,137,156,32,173,168,137,513]

theorem envBound48780 : H12AffineFastState.Bounded env48780 := by
  intro p hp
  have h : env48780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48779_48780 : H12AffineEnvironment.transform 9 189 env48779 = env48780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env48779 == env48780) = true)

theorem identity48780 : scanCanonicalize (H12AffineFastState.compose env48780 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48780 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env48781 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,40,1,1,35,17,0,52,0,0,32,16,2,40,16,1,17,17,1,20,32,37,32,1,513]

theorem envBound48781 : H12AffineFastState.Bounded env48781 := by
  intro p hp
  have h : env48781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48780_48781 : H12AffineEnvironment.transform 6 8 env48780 = env48781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48780 == env48781) = true)

theorem identity48781 : scanCanonicalize (H12AffineFastState.compose env48781 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound48781 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48782 : List Nat := [2,4,8,16,32,16,8,36,16,53,0,17,40,1,1,35,17,0,52,0,0,32,16,2,40,16,1,17,17,1,20,32,37,32,1,17]

theorem envBound48782 : H12AffineFastState.Bounded env48782 := by
  intro p hp
  have h : env48782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48781_48782 : H12AffineEnvironment.transform 8 16 env48781 = env48782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env48781 == env48782) = true)

theorem identity48782 : scanCanonicalize (H12AffineFastState.compose env48782 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48782 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48783 : List Nat := [2,4,8,16,10,16,8,14,16,31,0,17,2,1,1,9,17,0,30,0,0,10,16,2,2,16,1,17,17,1,20,10,15,10,1,17]

theorem envBound48783 : H12AffineFastState.Bounded env48783 := by
  intro p hp
  have h : env48783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48782_48783 : H12AffineEnvironment.transform 4 10 env48782 = env48783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48782 == env48783) = true)

theorem identity48783 : scanCanonicalize (H12AffineFastState.compose env48783 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48783 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48784 : List Nat := [2,4,8,1,10,1,8,14,1,14,0,0,2,1,1,9,0,0,15,0,0,10,1,2,2,1,1,0,0,1,5,10,15,10,1,0]

theorem envBound48784 : H12AffineFastState.Bounded env48784 := by
  intro p hp
  have h : env48784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48783_48784 : H12AffineEnvironment.transform 3 1 env48783 = env48784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48783 == env48784) = true)

def env48785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4161,21792,41292,73856,8328,64,43476,46157,58461,56437,1501,32,257,21793,46212,74250]

theorem envBound48785 : H12AffineFastState.Bounded env48785 := by
  intro p hp
  have h : env48785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48770_48785 : H12AffineEnvironment.transform 16 38161 env48770 = env48785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env48770 == env48785) = true)

theorem identity48785 : scanCanonicalize (H12AffineFastState.compose env48785 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound48785 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,13508,10280,1025,8660,4161,21792,153,73856,8328,64,2049,5528,17800,32160,1501,32,257,21793,5457,74250]

theorem envBound48786 : H12AffineFastState.Bounded env48786 := by
  intro p hp
  have h : env48786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48785_48786 : H12AffineEnvironment.transform 14 8661 env48785 = env48786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env48785 == env48786) = true)

theorem identity48786 : scanCanonicalize (H12AffineFastState.compose env48786 (packedSelected [0,2,3,6,7,8,11,16,18,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound48786 : packedSelected [0,2,3,6,7,8,11,16,18,24,26,28] rootPS < 2^1333 := by decide +kernel

def env48787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4541,8661,65536,13508,10280,1025,8660,4161,1181,153,73856,8328,64,2049,5528,5173,11293,1501,32,257,1180,5457,74250]

theorem envBound48787 : H12AffineFastState.Bounded env48787 := by
  intro p hp
  have h : env48787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48786_48787 : H12AffineEnvironment.transform 13 4541 env48786 = env48787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env48786 == env48787) = true)

theorem identity48787 : scanCanonicalize (H12AffineFastState.compose env48787 (packedSelected [2,5,6,7,9,12,15,16,19,22,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound48787 : packedSelected [2,5,6,7,9,12,15,16,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env48788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4541,8661,9326,13508,10280,1025,8660,4161,1181,153,1262,8328,64,2049,5528,5173,11293,1501,32,257,1180,5457,1636]

theorem envBound48788 : H12AffineFastState.Bounded env48788 := by
  intro p hp
  have h : env48788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48787_48788 : H12AffineEnvironment.transform 15 9326 env48787 = env48788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env48787 == env48788) = true)

theorem identity48788 : scanCanonicalize (H12AffineFastState.compose env48788 (packedSelected [3,5,10,11,12,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound48788 : packedSelected [3,5,10,11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env48789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,4541,509,1094,5356,2048,1025,508,4161,1181,153,1262,160,64,2049,5528,5173,3125,1501,32,257,1180,5457,1636]

theorem envBound48789 : H12AffineFastState.Bounded env48789 := by
  intro p hp
  have h : env48789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48788_48789 : H12AffineEnvironment.transform 12 40 env48788 = env48789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env48788 == env48789) = true)

theorem identity48789 : scanCanonicalize (H12AffineFastState.compose env48789 (packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound48789 : packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env48790 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,40,4541,509,343,4605,2048,272,508,4161,396,153,511,160,64,2049,4233,4388,2340,204,32,257,397,4160,885]

theorem envBound48790 : H12AffineFastState.Bounded env48790 := by
  intro p hp
  have h : env48790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48789_48790 : H12AffineEnvironment.transform 9 273 env48789 = env48790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48789 == env48790) = true)

def env48791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,180272,144477,243089,8328,64,43476,139612,160076,56436,1501,33,257,21793,46212,74250]

theorem envBound48791 : H12AffineFastState.Bounded env48791 := by
  intro p hp
  have h : env48791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48769_48791 : H12AffineEnvironment.transform 17 10281 env48769 = env48791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env48769 == env48791) = true)

def env48792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4161,21792,41293,73857,8328,64,43476,46156,58460,56436,1501,33,257,21793,46212,74250]

theorem envBound48792 : H12AffineFastState.Bounded env48792 := by
  intro p hp
  have h : env48792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48791_48792 : H12AffineEnvironment.transform 16 38160 env48791 = env48792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env48791 == env48792) = true)

theorem identity48792 : scanCanonicalize (H12AffineFastState.compose env48792 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound48792 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env48793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38160,10281,1025,32769,4161,21792,41293,3,8328,64,43476,46156,58460,56436,1501,33,257,21793,46212,648]

theorem envBound48793 : H12AffineFastState.Bounded env48793 := by
  intro p hp
  have h : env48793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48792_48793 : H12AffineEnvironment.transform 15 8322 env48792 = env48793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env48792 == env48793) = true)

theorem identity48793 : scanCanonicalize (H12AffineFastState.compose env48793 (packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48793 : packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env48794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,479,38160,2420,1025,32769,4161,21792,32784,3,469,64,34953,38161,50433,56436,1501,33,257,21793,38361,648]

theorem envBound48794 : H12AffineFastState.Bounded env48794 := by
  intro p hp
  have h : env48794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48793_48794 : H12AffineEnvironment.transform 12 349 env48793 = env48794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48793 == env48794) = true)

theorem identity48794 : scanCanonicalize (H12AffineFastState.compose env48794 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound48794 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env48795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,216,479,5576,2420,1025,217,4161,21792,200,3,469,64,2129,5577,17881,23724,1501,33,257,21793,5377,648]

theorem envBound48795 : H12AffineFastState.Bounded env48795 := by
  intro p hp
  have h : env48795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48794_48795 : H12AffineEnvironment.transform 14 216 env48794 = env48795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env48794 == env48795) = true)

theorem identity48795 : scanCanonicalize (H12AffineFastState.compose env48795 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound48795 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48796 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,1,262,5393,2420,1025,0,4161,21792,17,3,268,64,2129,5392,17664,23669,1284,33,257,21793,5377,593]

theorem envBound48796 : H12AffineFastState.Bounded env48796 := by
  intro p hp
  have h : env48796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48795_48796 : H12AffineEnvironment.transform 6 89 env48795 = env48796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env48795 == env48796) = true)

theorem identity48796 : scanCanonicalize (H12AffineFastState.compose env48796 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48796 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env48797 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5377,1,262,5393,2420,1025,0,4161,33,17,3,268,64,2129,5392,4097,2420,1284,33,257,32,5377,593]

theorem envBound48797 : H12AffineFastState.Bounded env48797 := by
  intro p hp
  have h : env48797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48796_48797 : H12AffineEnvironment.transform 13 5377 env48796 = env48797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48796 == env48797) = true)

theorem identity48797 : scanCanonicalize (H12AffineFastState.compose env48797 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 869) := by decide +kernel

theorem selectedBound48797 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env48798 : List Nat := [2,4,8,16,32,64,89,256,512,1024,869,4096,349,5377,1,262,5393,529,1025,0,4161,33,17,3,268,64,820,5392,4097,529,1284,33,257,32,5377,593]

theorem envBound48798 : H12AffineFastState.Bounded env48798 := by
  intro p hp
  have h : env48798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48797_48798 : H12AffineEnvironment.transform 10 869 env48797 = env48798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 869 env48797 == env48798) = true)

theorem identity48798 : scanCanonicalize (H12AffineFastState.compose env48798 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound48798 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env48799 : List Nat := [2,4,8,16,32,48,41,256,512,1024,789,4096,301,5377,1,262,5393,529,1025,0,4145,33,17,3,268,48,820,5392,4097,529,1284,33,257,32,5377,545]

theorem envBound48799 : H12AffineFastState.Bounded env48799 := by
  intro p hp
  have h : env48799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48798_48799 : H12AffineEnvironment.transform 5 48 env48798 = env48799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env48798 == env48799) = true)

theorem identity48799 : scanCanonicalize (H12AffineFastState.compose env48799 (packedSelected [0,1,2,3,7,14] rootPS)) = affineNative (2^(11+1) ^^^ 1556) := by decide +kernel

theorem selectedBound48799 : packedSelected [0,1,2,3,7,14] rootPS < 2^1333 := by decide +kernel

def env48800 : List Nat := [2,4,8,16,32,48,41,256,512,1024,789,1556,301,789,1,262,773,529,1025,0,1573,33,17,3,268,48,820,772,1557,529,1284,33,257,32,789,545]

theorem envBound48800 : H12AffineFastState.Bounded env48800 := by
  intro p hp
  have h : env48800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48799_48800 : H12AffineEnvironment.transform 11 1556 env48799 = env48800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env48799 == env48800) = true)

theorem identity48800 : scanCanonicalize (H12AffineFastState.compose env48800 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound48800 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48801 : List Nat := [2,4,8,16,32,48,41,256,512,21,789,513,301,789,1,262,773,529,20,0,560,33,17,3,268,48,820,772,512,529,273,33,257,32,789,545]

theorem envBound48801 : H12AffineFastState.Bounded env48801 := by
  intro p hp
  have h : env48801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48800_48801 : H12AffineEnvironment.transform 9 21 env48800 = env48801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env48800 == env48801) = true)

theorem identity48801 : scanCanonicalize (H12AffineFastState.compose env48801 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48801 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env48802 : List Nat := [2,4,8,16,32,48,41,37,512,21,560,513,8,560,1,35,544,529,20,0,560,33,17,3,41,48,529,545,512,529,52,33,36,32,560,545]

theorem envBound48802 : H12AffineFastState.Bounded env48802 := by
  intro p hp
  have h : env48802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48801_48802 : H12AffineEnvironment.transform 7 37 env48801 = env48802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48801 == env48802) = true)

theorem identity48802 : scanCanonicalize (H12AffineFastState.compose env48802 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48802 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48803 : List Nat := [2,4,8,16,1,17,8,4,512,21,529,513,8,529,1,2,513,529,20,0,529,0,17,3,8,17,529,512,512,529,21,0,5,1,529,512]

theorem envBound48803 : H12AffineFastState.Bounded env48803 := by
  intro p hp
  have h : env48803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48802_48803 : H12AffineEnvironment.transform 4 1 env48802 = env48803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48802 == env48803) = true)

theorem identity48803 : scanCanonicalize (H12AffineFastState.compose env48803 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48804 : List Nat := [2,4,8,16,1,17,8,4,1,21,16,0,8,16,1,2,0,16,20,0,16,0,17,3,8,17,16,1,1,16,21,0,5,1,16,1]

theorem envBound48804 : H12AffineFastState.Bounded env48804 := by
  intro p hp
  have h : env48804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48803_48804 : H12AffineEnvironment.transform 8 1 env48803 = env48804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48803 == env48804) = true)

theorem identity48804 : scanCanonicalize (H12AffineFastState.compose env48804 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48804 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48805 : List Nat := [2,0,8,16,1,17,8,0,1,17,16,0,8,16,1,2,0,16,16,0,16,0,17,3,8,17,16,1,1,16,17,0,1,1,16,1]

theorem envBound48805 : H12AffineFastState.Bounded env48805 := by
  intro p hp
  have h : env48805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48804_48805 : H12AffineEnvironment.transform 1 0 env48804 = env48805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48804 == env48805) = true)

def env48806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4161,21793,41292,73856,8328,64,43476,46157,58461,56436,1501,33,257,21793,46212,74250]

theorem envBound48806 : H12AffineFastState.Bounded env48806 := by
  intro p hp
  have h : env48806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48791_48806 : H12AffineEnvironment.transform 16 38161 env48791 = env48806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env48791 == env48806) = true)

theorem identity48806 : scanCanonicalize (H12AffineFastState.compose env48806 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48806 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4161,21793,41292,73737,8193,64,43357,46157,58461,56436,1364,33,257,21793,46093,74250]

theorem envBound48807 : H12AffineFastState.Bounded env48807 := by
  intro p hp
  have h : env48807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48806_48807 : H12AffineEnvironment.transform 6 9 env48806 = env48807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48806 == env48807) = true)

theorem identity48807 : scanCanonicalize (H12AffineFastState.compose env48807 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound48807 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,10281,1025,32769,4161,21793,41292,54530,8193,64,43357,46157,58461,56436,1364,33,257,21793,46093,55041]

theorem envBound48808 : H12AffineFastState.Bounded env48808 := by
  intro p hp
  have h : env48808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48807_48808 : H12AffineEnvironment.transform 15 62731 env48807 = env48808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env48807 == env48808) = true)

theorem identity48808 : scanCanonicalize (H12AffineFastState.compose env48808 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound48808 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,29962,5392,10281,1025,0,4161,21793,8525,21763,8193,64,10588,13388,25692,23669,1364,33,257,21793,13324,22272]

theorem envBound48809 : H12AffineFastState.Bounded env48809 := by
  intro p hp
  have h : env48809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48808_48809 : H12AffineEnvironment.transform 14 1 env48808 = env48809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env48808 == env48809) = true)

theorem identity48809 : scanCanonicalize (H12AffineFastState.compose env48809 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound48809 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env48810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,1,263,5392,10281,1025,0,4161,8492,8525,8462,8193,64,10588,13388,4177,10360,1364,33,257,8492,13324,8973]

theorem envBound48810 : H12AffineFastState.Bounded env48810 := by
  intro p hp
  have h : env48810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48809_48810 : H12AffineEnvironment.transform 13 13325 env48809 = env48810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env48809 == env48810) = true)

theorem identity48810 : scanCanonicalize (H12AffineFastState.compose env48810 (packedSelected [0,3,5,6,7,10,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48810 : packedSelected [0,3,5,6,7,10,14,16] rootPS < 2^1333 := by decide +kernel

def env48811 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,1,263,5392,10281,1025,0,4112,8492,8476,8462,8193,17,10509,13341,4096,10281,1285,33,257,8492,13324,8973]

theorem envBound48811 : H12AffineFastState.Bounded env48811 := by
  intro p hp
  have h : env48811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48810_48811 : H12AffineEnvironment.transform 5 17 env48810 = env48811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48810 == env48811) = true)

theorem identity48811 : scanCanonicalize (H12AffineFastState.compose env48811 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound48811 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env48812 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2096,8192,11325,1,263,3360,10281,1025,0,2080,8492,8476,8462,8193,17,10509,11309,2096,10281,1285,33,257,8492,11324,8973]

theorem envBound48812 : H12AffineFastState.Bounded env48812 := by
  intro p hp
  have h : env48812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48811_48812 : H12AffineEnvironment.transform 11 2096 env48811 = env48812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env48811 == env48812) = true)

theorem identity48812 : scanCanonicalize (H12AffineFastState.compose env48812 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound48812 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env48813 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2096,1304,2341,1,263,3360,3377,1025,0,2080,1076,1028,1046,1305,17,3093,2357,2096,3377,1285,33,257,1076,2340,1557]

theorem envBound48813 : H12AffineFastState.Bounded env48813 := by
  intro p hp
  have h : env48813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48812_48813 : H12AffineEnvironment.transform 12 1304 env48812 = env48813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env48812 == env48813) = true)

theorem identity48813 : scanCanonicalize (H12AffineFastState.compose env48813 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound48813 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env48814 : List Nat := [2,4,8,16,32,17,9,256,512,21,2048,2096,269,2341,1,263,2357,2340,20,0,2080,33,17,3,268,17,2048,2357,2096,2340,272,33,257,33,2340,512]

theorem envBound48814 : H12AffineFastState.Bounded env48814 := by
  intro p hp
  have h : env48814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48813_48814 : H12AffineEnvironment.transform 9 21 env48813 = env48814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env48813 == env48814) = true)

theorem identity48814 : scanCanonicalize (H12AffineFastState.compose env48814 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound48814 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48815 : List Nat := [2,4,8,16,32,17,9,256,512,21,49,1,269,276,1,263,260,277,20,0,17,33,17,3,268,17,49,260,1,277,272,33,257,33,277,512]

theorem envBound48815 : H12AffineFastState.Bounded env48815 := by
  intro p hp
  have h : env48815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48814_48815 : H12AffineEnvironment.transform 10 49 env48814 = env48815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env48814 == env48815) = true)

theorem identity48815 : scanCanonicalize (H12AffineFastState.compose env48815 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound48815 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48816 : List Nat := [2,4,8,16,32,17,9,256,33,21,49,1,269,276,1,263,260,277,20,0,17,33,17,3,268,17,49,260,1,277,272,33,257,33,277,33]

theorem envBound48816 : H12AffineFastState.Bounded env48816 := by
  intro p hp
  have h : env48816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48815_48816 : H12AffineEnvironment.transform 8 33 env48815 = env48816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env48815 == env48816) = true)

theorem identity48816 : scanCanonicalize (H12AffineFastState.compose env48816 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48816 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48817 : List Nat := [2,4,8,16,1,17,9,256,0,21,16,1,269,276,1,263,260,277,20,0,17,0,17,3,268,17,16,260,1,277,272,0,257,0,277,0]

theorem envBound48817 : H12AffineFastState.Bounded env48817 := by
  intro p hp
  have h : env48817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48816_48817 : H12AffineEnvironment.transform 4 1 env48816 = env48817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48816 == env48817) = true)

theorem identity48817 : scanCanonicalize (H12AffineFastState.compose env48817 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48817 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48818 : List Nat := [2,4,8,1,1,0,9,256,0,4,1,1,269,261,1,263,260,260,5,0,0,0,0,3,268,0,1,260,1,260,257,0,257,0,260,0]

theorem envBound48818 : H12AffineFastState.Bounded env48818 := by
  intro p hp
  have h : env48818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48817_48818 : H12AffineEnvironment.transform 3 1 env48817 = env48818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48817 == env48818) = true)

def env48819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356288,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound48819 : H12AffineFastState.Bounded env48819 := by
  intro p hp
  have h : env48819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48374_48819 : H12AffineEnvironment.transform 26 30393345 env48374 = env48819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env48374 == env48819) = true)

def env48820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound48820 : H12AffineFastState.Bounded env48820 := by
  intro p hp
  have h : env48820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48819_48820 : H12AffineEnvironment.transform 18 1024 env48819 = env48820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env48819 == env48820) = true)

theorem identity48820 : scanCanonicalize (H12AffineFastState.compose env48820 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48820 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,8388608,16777216,8328,64,29843805,18949585,10507600,8806748,25240909,23160256,256,27354608,27337993,25166491]

theorem envBound48821 : H12AffineFastState.Bounded env48821 := by
  intro p hp
  have h : env48821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48820_48821 : H12AffineEnvironment.transform 14 8540 env48820 = env48821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48820 == env48821) = true)

def env48822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,2097152,4194304,147456,16777216,8328,64,21307741,18949585,2233680,270684,16999757,23160256,256,19080688,19096841,16925339]

theorem envBound48822 : H12AffineFastState.Bounded env48822 := by
  intro p hp
  have h : env48822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48821_48822 : H12AffineEnvironment.transform 22 147456 env48821 = env48822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env48821 == env48822) = true)

def env48823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147456,16777216,8328,64,21039613,18949585,2233680,2556,16999757,23160256,256,19080688,19096841,16925339]

theorem envBound48823 : H12AffineFastState.Bounded env48823 := by
  intro p hp
  have h : env48823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48822_48823 : H12AffineEnvironment.transform 17 10400 env48822 = env48823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env48822 == env48823) = true)

def env48824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147456,73856,8328,64,4204925,2098513,2233680,2556,148941,6309184,256,2229616,2246025,221723]

theorem envBound48824 : H12AffineFastState.Bounded env48824 := by
  intro p hp
  have h : env48824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48823_48824 : H12AffineEnvironment.transform 23 73856 env48823 = env48824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73856 env48823 == env48824) = true)

theorem identity48824 : scanCanonicalize (H12AffineFastState.compose env48824 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48824 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env48825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10281,1024,8541,2097152,4194304,147456,73737,8193,64,4204925,2098513,2233680,2421,148804,6309184,256,2229616,2245888,221723]

theorem envBound48825 : H12AffineFastState.Bounded env48825 := by
  intro p hp
  have h : env48825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48824_48825 : H12AffineEnvironment.transform 6 9 env48824 = env48825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48824 == env48825) = true)

def env48826 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,4194304,147456,73737,8193,16,4204845,2098433,2233600,2341,148756,6309136,256,2229536,2245888,221723]

theorem envBound48826 : H12AffineFastState.Bounded env48826 := by
  intro p hp
  have h : env48826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48825_48826 : H12AffineEnvironment.transform 5 16 env48825 = env48826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48825 == env48826) = true)

theorem identity48826 : scanCanonicalize (H12AffineFastState.compose env48826 (packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound48826 : packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env48827 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,17680,4194304,147456,73737,8193,16,4204845,16401,151568,2341,148756,4194304,256,147504,131088,221723]

theorem envBound48827 : H12AffineFastState.Bounded env48827 := by
  intro p hp
  have h : env48827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48826_48827 : H12AffineEnvironment.transform 20 17680 env48826 = env48827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env48826 == env48827) = true)

theorem identity48827 : scanCanonicalize (H12AffineFastState.compose env48827 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound48827 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env48828 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,65536,24860,10281,1024,8461,17680,4194304,8476,73737,8193,16,4204845,16401,12556,2341,9224,4194304,256,8492,24844,66311]

theorem envBound48828 : H12AffineFastState.Bounded env48828 := by
  intro p hp
  have h : env48828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48827_48828 : H12AffineEnvironment.transform 16 24860 env48827 = env48828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env48827 == env48828) = true)

theorem identity48828 : scanCanonicalize (H12AffineFastState.compose env48828 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound48828 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env48829 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,65536,24860,10281,1024,8461,17680,33,8476,73737,8193,16,10508,16401,12556,2341,9224,33,256,8492,24844,66311]

theorem envBound48829 : H12AffineFastState.Bounded env48829 := by
  intro p hp
  have h : env48829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48828_48829 : H12AffineEnvironment.transform 21 33 env48828 = env48829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env48828 == env48829) = true)

theorem identity48829 : scanCanonicalize (H12AffineFastState.compose env48829 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48829 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env48830 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,65536,16401,2340,1024,0,17680,33,17,65796,268,16,2049,16401,4097,2341,1285,33,256,33,16385,66311]

theorem envBound48830 : H12AffineFastState.Bounded env48830 := by
  intro p hp
  have h : env48830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48829_48830 : H12AffineEnvironment.transform 12 269 env48829 = env48830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48829 == env48830) = true)

theorem identity48830 : scanCanonicalize (H12AffineFastState.compose env48830 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 23357) := by decide +kernel

theorem selectedBound48830 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48831 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,23357,16401,2340,1024,0,17680,33,17,23097,268,16,2049,16401,4097,2341,1285,33,256,33,16385,22586]

theorem envBound48831 : H12AffineFastState.Bounded env48831 := by
  intro p hp
  have h : env48831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48830_48831 : H12AffineEnvironment.transform 15 23357 env48830 = env48831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 23357 env48830 == env48831) = true)

theorem identity48831 : scanCanonicalize (H12AffineFastState.compose env48831 (packedSelected [1,3,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48831 : packedSelected [1,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48832 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,16384,1,23096,16401,2081,1024,0,17429,33,17,23097,9,16,2049,16401,4097,2080,1024,33,5,33,16385,22586]

theorem envBound48832 : H12AffineFastState.Bounded env48832 := by
  intro p hp
  have h : env48832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48831_48832 : H12AffineEnvironment.transform 7 5 env48831 = env48832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48831 == env48832) = true)

theorem identity48832 : scanCanonicalize (H12AffineFastState.compose env48832 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 3615) := by decide +kernel

theorem selectedBound48832 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env48833 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,3615,1,5159,3598,2081,1024,0,2570,33,17,5158,9,16,2049,3598,4097,2080,1024,33,5,33,3614,5669]

theorem envBound48833 : H12AffineFastState.Bounded env48833 := by
  intro p hp
  have h : env48833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48832_48833 : H12AffineEnvironment.transform 13 3615 env48832 = env48833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3615 env48832 == env48833) = true)

theorem identity48833 : scanCanonicalize (H12AffineFastState.compose env48833 (packedSelected [2,6,12] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound48833 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env48834 : List Nat := [2,4,8,16,32,16,9,5,512,542,2048,4096,8,2049,1,4665,2064,2081,542,0,2570,33,17,4664,9,16,2049,2064,4097,2080,542,33,5,33,2048,4155]

theorem envBound48834 : H12AffineFastState.Bounded env48834 := by
  intro p hp
  have h : env48834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48833_48834 : H12AffineEnvironment.transform 9 542 env48833 = env48834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env48833 == env48834) = true)

def env48835 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,4194304,147456,73737,8193,17,4204844,2098432,2233601,2340,148757,6309137,256,2229537,2245888,221723]

theorem envBound48835 : H12AffineFastState.Bounded env48835 := by
  intro p hp
  have h : env48835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48825_48835 : H12AffineEnvironment.transform 5 17 env48825 = env48835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48825 == env48835) = true)

theorem identity48835 : scanCanonicalize (H12AffineFastState.compose env48835 (packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 2303274) := by decide +kernel

theorem selectedBound48835 : packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env48836 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,2303274,147456,73737,8193,17,2296838,2098432,2233601,2340,148757,221243,256,2229537,2245888,221723]

theorem envBound48836 : H12AffineFastState.Bounded env48836 := by
  intro p hp
  have h : env48836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48835_48836 : H12AffineEnvironment.transform 21 2303274 env48835 = env48836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2303274 env48835 == env48836) = true)

theorem identity48836 : scanCanonicalize (H12AffineFastState.compose env48836 (packedSelected [2,6,9,11,12,14,15,16,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound48836 : packedSelected [2,6,9,11,12,14,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env48837 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,263,131072,10281,1024,8460,2097152,2237485,147456,8462,8193,17,2231553,2098432,2233601,2340,148757,155964,256,2229537,2245888,156444]

theorem envBound48837 : H12AffineFastState.Bounded env48837 := by
  intro p hp
  have h : env48837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48836_48837 : H12AffineEnvironment.transform 15 263 env48836 = env48837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env48836 == env48837) = true)

theorem identity48837 : scanCanonicalize (H12AffineFastState.compose env48837 (packedSelected [0,1,2,6,7,8,11,16,17,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound48837 : packedSelected [0,1,2,6,7,8,11,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env48838 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,263,24861,10281,1024,8460,2097152,2114864,8477,8462,8193,17,2124828,2098432,2126876,2340,9224,33,256,2122812,2106397,513]

theorem envBound48838 : H12AffineFastState.Bounded env48838 := by
  intro p hp
  have h : env48838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48837_48838 : H12AffineEnvironment.transform 16 24861 env48837 = env48838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env48837 == env48838) = true)

theorem identity48838 : scanCanonicalize (H12AffineFastState.compose env48838 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound48838 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48839 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,263,24861,10281,1024,8460,17681,33,8477,8462,8193,17,10509,16401,12557,2340,9224,33,256,8493,24844,513]

theorem envBound48839 : H12AffineFastState.Bounded env48839 := by
  intro p hp
  have h : env48839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48838_48839 : H12AffineEnvironment.transform 20 17681 env48838 = env48839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env48838 == env48839) = true)

theorem identity48839 : scanCanonicalize (H12AffineFastState.compose env48839 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48839 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48840 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,16400,2340,1024,1,17681,33,16,3,268,17,2048,16401,4096,2340,1285,33,256,32,16385,513]

theorem envBound48840 : H12AffineFastState.Bounded env48840 := by
  intro p hp
  have h : env48840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48839_48840 : H12AffineEnvironment.transform 12 269 env48839 = env48840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48839 == env48840) = true)

theorem identity48840 : scanCanonicalize (H12AffineFastState.compose env48840 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound48840 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48841 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1076,269,16384,0,263,16400,2340,1024,1,17681,33,16,3,268,17,2048,16401,1076,2340,1285,33,256,32,16385,513]

theorem envBound48841 : H12AffineFastState.Bounded env48841 := by
  intro p hp
  have h : env48841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48840_48841 : H12AffineEnvironment.transform 11 1076 env48840 = env48841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env48840 == env48841) = true)

theorem identity48841 : scanCanonicalize (H12AffineFastState.compose env48841 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 2367) := by decide +kernel

theorem selectedBound48841 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48842 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1076,269,2367,0,263,2351,2340,1024,1,3118,33,16,3,268,17,2048,2350,1076,2340,1285,33,256,32,2366,513]

theorem envBound48842 : H12AffineFastState.Bounded env48842 := by
  intro p hp
  have h : env48842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48841_48842 : H12AffineEnvironment.transform 13 2367 env48841 = env48842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2367 env48841 == env48842) = true)

theorem identity48842 : scanCanonicalize (H12AffineFastState.compose env48842 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound48842 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48843 : List Nat := [2,4,8,16,32,17,9,256,512,1024,43,1076,269,276,0,263,260,271,1024,1,1029,33,16,3,268,17,43,261,1076,271,1285,33,256,32,277,513]

theorem envBound48843 : H12AffineFastState.Bounded env48843 := by
  intro p hp
  have h : env48843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48842_48843 : H12AffineEnvironment.transform 10 43 env48842 = env48843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env48842 == env48843) = true)

theorem identity48843 : scanCanonicalize (H12AffineFastState.compose env48843 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48843 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48844 : List Nat := [2,4,8,16,32,17,9,36,512,1024,43,1076,41,48,0,35,32,43,1024,1,1029,33,16,3,40,17,43,33,1076,43,1057,33,36,32,49,513]

theorem envBound48844 : H12AffineFastState.Bounded env48844 := by
  intro p hp
  have h : env48844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48843_48844 : H12AffineEnvironment.transform 7 36 env48843 = env48844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48843 == env48844) = true)

theorem identity48844 : scanCanonicalize (H12AffineFastState.compose env48844 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound48844 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48845 : List Nat := [2,4,8,16,32,17,9,36,512,21,43,33,41,48,0,35,32,43,21,1,16,33,16,3,40,17,43,33,33,43,52,33,36,32,49,513]

theorem envBound48845 : H12AffineFastState.Bounded env48845 := by
  intro p hp
  have h : env48845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48844_48845 : H12AffineEnvironment.transform 9 21 env48844 = env48845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env48844 == env48845) = true)

theorem identity48845 : scanCanonicalize (H12AffineFastState.compose env48845 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48845 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env48846 : List Nat := [2,4,8,16,0,17,9,4,512,21,11,1,9,16,0,3,0,11,21,1,16,1,16,3,8,17,11,1,1,11,20,1,4,0,17,513]

theorem envBound48846 : H12AffineFastState.Bounded env48846 := by
  intro p hp
  have h : env48846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48845_48846 : H12AffineEnvironment.transform 4 0 env48845 = env48846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48845 == env48846) = true)

theorem identity48846 : scanCanonicalize (H12AffineFastState.compose env48846 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound48846 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48847 : List Nat := [2,4,8,16,0,17,9,4,31,21,11,1,9,16,0,3,0,11,21,1,16,1,16,3,8,17,11,1,1,11,20,1,4,0,17,30]

theorem envBound48847 : H12AffineFastState.Bounded env48847 := by
  intro p hp
  have h : env48847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48846_48847 : H12AffineEnvironment.transform 8 31 env48846 = env48847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env48846 == env48847) = true)

theorem identity48847 : scanCanonicalize (H12AffineFastState.compose env48847 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48847 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48848 : List Nat := [2,4,8,7,0,6,9,4,8,2,11,1,9,7,0,3,0,11,2,1,7,1,7,3,8,6,11,1,1,11,3,1,4,0,6,9]

theorem envBound48848 : H12AffineFastState.Bounded env48848 := by
  intro p hp
  have h : env48848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48847_48848 : H12AffineEnvironment.transform 3 7 env48847 = env48848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48847 == env48848) = true)

def env48849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,2097152,4194304,147456,73857,8328,64,4204924,2098512,2233680,2556,148940,6309185,256,2229617,2246024,221722]

theorem envBound48849 : H12AffineFastState.Bounded env48849 := by
  intro p hp
  have h : env48849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48823_48849 : H12AffineEnvironment.transform 23 73857 env48823 = env48849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73857 env48823 == env48849) = true)

theorem identity48849 : scanCanonicalize (H12AffineFastState.compose env48849 (packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound48849 : packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env48850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10400,1024,8541,2097152,4194304,73755,73857,8328,64,4204924,2098512,2192715,2556,75223,6309185,256,2188650,2172307,513]

theorem envBound48850 : H12AffineFastState.Bounded env48850 := by
  intro p hp
  have h : env48850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48849_48850 : H12AffineEnvironment.transform 16 90139 env48849 = env48850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env48849 == env48850) = true)

def env48851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10400,1024,8541,2097152,32,73755,73857,8328,64,10588,2098512,2192715,2556,75223,2114913,256,2188650,2172307,513]

theorem envBound48851 : H12AffineFastState.Bounded env48851 := by
  intro p hp
  have h : env48851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48850_48851 : H12AffineEnvironment.transform 21 32 env48850 = env48851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env48850 == env48851) = true)

theorem identity48851 : scanCanonicalize (H12AffineFastState.compose env48851 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 91586) := by decide +kernel

theorem selectedBound48851 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10400,1024,8541,91586,32,73755,73857,8328,64,10588,90258,4233,2556,75223,73891,256,168,16465,513]

theorem envBound48852 : H12AffineFastState.Bounded env48852 := by
  intro p hp
  have h : env48852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48851_48852 : H12AffineEnvironment.transform 20 91586 env48851 = env48852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91586 env48851 == env48852) = true)

theorem identity48852 : scanCanonicalize (H12AffineFastState.compose env48852 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48852 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env48853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10400,1024,8541,17865,32,16,138,8328,64,10588,16537,4233,2556,1500,168,256,168,16465,513]

theorem envBound48853 : H12AffineFastState.Bounded env48853 := by
  intro p hp
  have h : env48853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48852_48853 : H12AffineEnvironment.transform 15 8203 env48852 = env48853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48852 == env48853) = true)

theorem identity48853 : scanCanonicalize (H12AffineFastState.compose env48853 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48853 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env48854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,0,343,16400,2556,1024,1,17865,32,16,138,468,64,2048,16537,4233,2556,1500,168,256,168,16465,513]

theorem envBound48854 : H12AffineFastState.Bounded env48854 := by
  intro p hp
  have h : env48854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48853_48854 : H12AffineEnvironment.transform 12 348 env48853 = env48854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48853 == env48854) = true)

theorem identity48854 : scanCanonicalize (H12AffineFastState.compose env48854 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5101) := by decide +kernel

theorem selectedBound48854 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5101,0,343,5117,2556,1024,1,5668,32,16,138,468,64,2048,4980,4233,2556,1500,168,256,168,5052,513]

theorem envBound48855 : H12AffineFastState.Bounded env48855 := by
  intro p hp
  have h : env48855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48854_48855 : H12AffineEnvironment.transform 13 5101 env48854 = env48855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5101 env48854 == env48855) = true)

theorem identity48855 : scanCanonicalize (H12AffineFastState.compose env48855 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound48855 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env48856 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,4917,0,343,4901,2340,1024,1,5668,32,16,82,268,64,2048,4980,4177,2340,1284,112,256,112,4964,513]

theorem envBound48856 : H12AffineFastState.Bounded env48856 := by
  intro p hp
  have h : env48856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48855_48856 : H12AffineEnvironment.transform 6 88 env48855 = env48856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env48855 == env48856) = true)

theorem identity48856 : scanCanonicalize (H12AffineFastState.compose env48856 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound48856 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48857 : List Nat := [2,4,8,16,32,64,88,256,17,1024,2048,4096,348,4388,0,343,4404,2340,1024,1,5173,32,16,82,268,64,2048,4453,4177,2340,1284,112,256,112,4469,16]

theorem envBound48857 : H12AffineFastState.Bounded env48857 := by
  intro p hp
  have h : env48857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48856_48857 : H12AffineEnvironment.transform 8 17 env48856 = env48857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env48856 == env48857) = true)

theorem identity48857 : scanCanonicalize (H12AffineFastState.compose env48857 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound48857 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48858 : List Nat := [2,4,8,16,32,64,88,256,17,1024,1281,4096,348,4388,0,343,4404,1061,1024,1,5173,32,16,82,268,64,1281,4453,4177,1061,1284,112,256,112,4469,16]

theorem envBound48858 : H12AffineFastState.Bounded env48858 := by
  intro p hp
  have h : env48858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48857_48858 : H12AffineEnvironment.transform 10 1281 env48857 = env48858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env48857 == env48858) = true)

theorem identity48858 : scanCanonicalize (H12AffineFastState.compose env48858 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48858 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env48859 : List Nat := [2,4,8,16,32,64,88,256,17,52,309,4096,348,4388,0,343,4404,17,52,1,4097,32,16,82,268,64,309,4453,4177,17,304,112,256,112,4469,16]

theorem envBound48859 : H12AffineFastState.Bounded env48859 := by
  intro p hp
  have h : env48859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48858_48859 : H12AffineEnvironment.transform 9 52 env48858 = env48859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48858 == env48859) = true)

theorem identity48859 : scanCanonicalize (H12AffineFastState.compose env48859 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound48859 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48860 : List Nat := [2,4,8,16,32,64,88,256,17,52,309,16,348,308,0,343,292,17,52,1,17,32,16,82,268,64,309,373,65,17,304,112,256,112,357,16]

theorem envBound48860 : H12AffineFastState.Bounded env48860 := by
  intro p hp
  have h : env48860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48859_48860 : H12AffineEnvironment.transform 11 16 env48859 = env48860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env48859 == env48860) = true)

theorem identity48860 : scanCanonicalize (H12AffineFastState.compose env48860 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48860 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env48861 : List Nat := [2,4,8,16,32,16,8,256,17,52,309,16,268,308,0,263,292,17,52,1,17,32,16,2,268,16,309,293,17,17,304,32,256,32,309,16]

theorem envBound48861 : H12AffineFastState.Bounded env48861 := by
  intro p hp
  have h : env48861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48860_48861 : H12AffineEnvironment.transform 5 16 env48860 = env48861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48860 == env48861) = true)

theorem identity48861 : scanCanonicalize (H12AffineFastState.compose env48861 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48861 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48862 : List Nat := [2,4,8,16,32,16,8,37,17,52,16,16,41,17,0,34,1,17,52,1,17,32,16,2,41,16,16,0,17,17,21,32,37,32,16,16]

theorem envBound48862 : H12AffineFastState.Bounded env48862 := by
  intro p hp
  have h : env48862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48861_48862 : H12AffineEnvironment.transform 7 37 env48861 = env48862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48861 == env48862) = true)

theorem identity48862 : scanCanonicalize (H12AffineFastState.compose env48862 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48862 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48863 : List Nat := [2,4,8,1,32,1,8,37,0,37,1,1,41,0,0,34,1,0,37,1,0,32,1,2,41,1,1,0,0,0,4,32,37,32,1,1]

theorem envBound48863 : H12AffineFastState.Bounded env48863 := by
  intro p hp
  have h : env48863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48862_48863 : H12AffineEnvironment.transform 3 1 env48862 = env48863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48862 == env48863) = true)

theorem identity48863 : scanCanonicalize (H12AffineFastState.compose env48863 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48863 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48864 : List Nat := [2,4,8,1,1,1,8,4,0,4,1,1,8,0,0,3,1,0,4,1,0,1,1,2,8,1,1,0,0,0,4,1,4,1,1,1]

theorem envBound48864 : H12AffineFastState.Bounded env48864 := by
  intro p hp
  have h : env48864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48863_48864 : H12AffineEnvironment.transform 4 1 env48863 = env48864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48863 == env48864) = true)

def env48865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10400,1024,8541,2097152,33,73755,73857,8328,64,10589,2098512,2192715,2556,75223,2114912,256,2188650,2172307,513]

theorem envBound48865 : H12AffineFastState.Bounded env48865 := by
  intro p hp
  have h : env48865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48850_48865 : H12AffineEnvironment.transform 21 33 env48850 = env48865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env48850 == env48865) = true)

theorem identity48865 : scanCanonicalize (H12AffineFastState.compose env48865 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 17865) := by decide +kernel

theorem selectedBound48865 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,90139,10400,1024,8541,17865,33,73755,73857,8328,64,10589,16537,77954,2556,75223,169,256,73891,90202,513]

theorem envBound48866 : H12AffineFastState.Bounded env48866 := by
  intro p hp
  have h : env48866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48865_48866 : H12AffineEnvironment.transform 20 17865 env48865 = env48866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env48865 == env48866) = true)

theorem identity48866 : scanCanonicalize (H12AffineFastState.compose env48866 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48866 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10400,1024,8541,17865,33,16,138,8328,64,10589,16537,4233,2556,1500,169,256,168,16465,513]

theorem envBound48867 : H12AffineFastState.Bounded env48867 := by
  intro p hp
  have h : env48867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48866_48867 : H12AffineEnvironment.transform 15 8203 env48866 = env48867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48866 == env48867) = true)

theorem identity48867 : scanCanonicalize (H12AffineFastState.compose env48867 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48867 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1024,8541,17729,33,16,2,8192,64,10589,16401,4097,2420,1364,33,256,32,16465,513]

theorem envBound48868 : H12AffineFastState.Bounded env48868 := by
  intro p hp
  have h : env48868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48867_48868 : H12AffineEnvironment.transform 6 8 env48867 = env48868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48867 == env48868) = true)

theorem identity48868 : scanCanonicalize (H12AffineFastState.compose env48868 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound48868 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13576,8540,8203,13592,10280,1024,8541,12361,33,16,2,8192,64,10589,13593,4097,2420,1364,33,256,32,13657,513]

theorem envBound48869 : H12AffineFastState.Bounded env48869 := by
  intro p hp
  have h : env48869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48868_48869 : H12AffineEnvironment.transform 13 13576 env48868 = env48869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env48868 == env48869) = true)

theorem identity48869 : scanCanonicalize (H12AffineFastState.compose env48869 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound48869 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1304,4112,1092,1299,4096,3376,1024,1093,5457,33,16,2,1304,64,3141,4097,4097,2420,1364,33,256,32,4161,513]

theorem envBound48870 : H12AffineFastState.Bounded env48870 := by
  intro p hp
  have h : env48870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48869_48870 : H12AffineEnvironment.transform 12 1304 env48869 = env48870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env48869 == env48870) = true)

theorem identity48870 : scanCanonicalize (H12AffineFastState.compose env48870 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound48870 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env48871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,1304,2129,1092,1299,2113,3376,1024,1093,3344,33,16,2,1304,64,3141,2112,2112,2420,1364,33,256,32,2048,513]

theorem envBound48871 : H12AffineFastState.Bounded env48871 := by
  intro p hp
  have h : env48871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48870_48871 : H12AffineEnvironment.transform 11 2113 env48870 = env48871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env48870 == env48871) = true)

theorem identity48871 : scanCanonicalize (H12AffineFastState.compose env48871 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound48871 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env48872 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,2096,1304,2080,1077,1299,2096,3376,1024,1076,3344,33,16,2,1304,49,3124,2097,2097,2309,1317,33,256,32,2048,513]

theorem envBound48872 : H12AffineFastState.Bounded env48872 := by
  intro p hp
  have h : env48872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48871_48872 : H12AffineEnvironment.transform 5 49 env48871 = env48872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env48871 == env48872) = true)

theorem identity48872 : scanCanonicalize (H12AffineFastState.compose env48872 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound48872 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env48873 : List Nat := [2,4,8,16,32,49,8,256,512,1024,1573,1557,1304,1541,1077,1299,1557,789,1024,1076,821,33,16,2,1304,49,529,1556,1556,1824,1317,33,256,32,1573,513]

theorem envBound48873 : H12AffineFastState.Bounded env48873 := by
  intro p hp
  have h : env48873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48872_48873 : H12AffineEnvironment.transform 10 1573 env48872 = env48873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env48872 == env48873) = true)

theorem identity48873 : scanCanonicalize (H12AffineFastState.compose env48873 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48873 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env48874 : List Nat := [2,4,8,16,32,49,8,256,512,52,529,545,300,561,1,295,545,789,52,0,821,33,16,2,300,49,529,544,544,788,273,33,256,32,529,513]

theorem envBound48874 : H12AffineFastState.Bounded env48874 := by
  intro p hp
  have h : env48874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48873_48874 : H12AffineEnvironment.transform 9 52 env48873 = env48874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48873 == env48874) = true)

theorem identity48874 : scanCanonicalize (H12AffineFastState.compose env48874 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound48874 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env48875 : List Nat := [2,4,8,16,32,49,8,256,33,52,48,0,300,16,1,295,0,308,52,0,276,33,16,2,300,49,48,1,1,309,273,33,256,32,48,32]

theorem envBound48875 : H12AffineFastState.Bounded env48875 := by
  intro p hp
  have h : env48875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48874_48875 : H12AffineEnvironment.transform 8 33 env48874 = env48875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env48874 == env48875) = true)

theorem identity48875 : scanCanonicalize (H12AffineFastState.compose env48875 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48876 : List Nat := [2,4,8,16,1,16,8,256,0,21,17,0,269,16,1,262,0,277,21,0,276,0,16,2,269,16,17,1,1,276,273,0,256,1,17,1]

theorem envBound48876 : H12AffineFastState.Bounded env48876 := by
  intro p hp
  have h : env48876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48875_48876 : H12AffineEnvironment.transform 4 1 env48875 = env48876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48875 == env48876) = true)

theorem identity48876 : scanCanonicalize (H12AffineFastState.compose env48876 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound48876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48877 : List Nat := [2,4,8,16,1,16,8,21,0,21,17,0,24,16,1,19,0,0,21,0,1,0,16,2,24,16,17,1,1,1,4,0,21,1,17,1]

theorem envBound48877 : H12AffineFastState.Bounded env48877 := by
  intro p hp
  have h : env48877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48876_48877 : H12AffineEnvironment.transform 7 21 env48876 = env48877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env48876 == env48877) = true)

theorem identity48877 : scanCanonicalize (H12AffineFastState.compose env48877 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48877 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0