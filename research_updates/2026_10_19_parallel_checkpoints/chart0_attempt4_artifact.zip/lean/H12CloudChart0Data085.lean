import H12CloudChart0Data084

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity21469 : scanCanonicalize (H12AffineFastState.compose env21469 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21469 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env21470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,32768,343,38160,35109,1025,32769,36881,32880,17,83,348,64,2049,5393,36865,35189,34052,33,257,113,38224,33360]

theorem envBound21470 : H12AffineFastState.Bounded env21470 := by
  intro p hp
  have h : env21470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21469_21470 : H12AffineEnvironment.transform 12 348 env21469 = env21470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21469 == env21470) = true)

theorem identity21470 : scanCanonicalize (H12AffineFastState.compose env21470 (packedSelected [0,1,2,4,5,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 7937) := by decide +kernel

theorem selectedBound21470 : packedSelected [0,1,2,4,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env21471 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,7937,343,2577,5668,1025,7936,3856,8049,17,83,348,64,2049,5393,3840,5748,6661,33,257,113,2641,7505]

theorem envBound21471 : H12AffineFastState.Bounded env21471 := by
  intro p hp
  have h : env21471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21470_21471 : H12AffineEnvironment.transform 14 7937 env21470 = env21471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7937 env21470 == env21471) = true)

theorem identity21471 : scanCanonicalize (H12AffineFastState.compose env21471 (packedSelected [4,5,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound21471 : packedSelected [4,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env21472 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1077,348,356,2868,343,2577,529,1025,2869,3856,2884,17,83,348,64,2049,292,3840,577,3632,33,257,113,2641,2404]

theorem envBound21472 : H12AffineFastState.Bounded env21472 := by
  intro p hp
  have h : env21472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21471_21472 : H12AffineEnvironment.transform 11 1077 env21471 = env21472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env21471 == env21472) = true)

theorem identity21472 : scanCanonicalize (H12AffineFastState.compose env21472 (packedSelected [2,3,5,6,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound21472 : packedSelected [2,3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env21473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,821,1077,348,356,1,343,292,529,1025,0,1061,113,17,83,348,64,820,292,1077,577,1285,33,257,113,356,593]

theorem envBound21473 : H12AffineFastState.Bounded env21473 := by
  intro p hp
  have h : env21473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21472_21473 : H12AffineEnvironment.transform 10 821 env21472 = env21473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env21472 == env21473) = true)

theorem identity21473 : scanCanonicalize (H12AffineFastState.compose env21473 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 832) := by decide +kernel

theorem selectedBound21473 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env21474 : List Nat := [2,4,8,16,32,64,8,256,512,832,821,885,348,356,1,343,292,529,833,0,869,113,17,83,348,64,820,292,885,577,581,33,257,113,356,593]

theorem envBound21474 : H12AffineFastState.Bounded env21474 := by
  intro p hp
  have h : env21474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21473_21474 : H12AffineEnvironment.transform 9 832 env21473 = env21474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 832 env21473 == env21474) = true)

theorem identity21474 : scanCanonicalize (H12AffineFastState.compose env21474 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21474 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21475 : List Nat := [2,4,8,16,32,64,8,116,512,564,577,513,40,16,1,35,80,529,565,0,529,113,17,83,40,64,576,80,513,577,581,33,117,113,16,593]

theorem envBound21475 : H12AffineFastState.Bounded env21475 := by
  intro p hp
  have h : env21475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21474_21475 : H12AffineEnvironment.transform 7 116 env21474 = env21475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21474 == env21475) = true)

def env21476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,16,95497,8192,64,2049,5392,45405,283905,61704,318548,257,21792,46092,120407]

theorem envBound21476 : H12AffineFastState.Bounded env21476 := by
  intro p hp
  have h : env21476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21465_21476 : H12AffineEnvironment.transform 16 38161 env21465 = env21476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env21465 == env21476) = true)

theorem identity21476 : scanCanonicalize (H12AffineFastState.compose env21476 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound21476 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,58397,272393,16,41311,8192,64,2049,5392,45405,283905,61704,318548,257,21792,46092,513]

theorem envBound21477 : H12AffineFastState.Bounded env21477 := by
  intro p hp
  have h : env21477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21476_21477 : H12AffineEnvironment.transform 15 54358 env21476 = env21477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env21476 == env21477) = true)

theorem identity21477 : scanCanonicalize (H12AffineFastState.compose env21477 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21477 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54358,38161,262144,1025,32769,50497,264533,16,32771,348,64,2049,5392,36865,283905,53332,318548,257,21792,38224,513]

theorem envBound21478 : H12AffineFastState.Bounded env21478 := by
  intro p hp
  have h : env21478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21477_21478 : H12AffineEnvironment.transform 12 348 env21477 = env21478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21477 == env21478) = true)

theorem identity21478 : scanCanonicalize (H12AffineFastState.compose env21478 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21478 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33110,38161,262144,1025,32769,36929,264533,16,32771,348,64,2049,5392,36865,262145,34132,297300,257,32,38224,513]

theorem envBound21479 : H12AffineFastState.Bounded env21479 := by
  intro p hp
  have h : env21479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21478_21479 : H12AffineEnvironment.transform 13 5376 env21478 = env21479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21478 == env21479) = true)

theorem identity21479 : scanCanonicalize (H12AffineFastState.compose env21479 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound21479 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33110,38161,2421,1025,32769,36929,32,16,32771,348,64,2049,5392,36865,2420,34132,32801,257,32,38224,513]

theorem envBound21480 : H12AffineFastState.Bounded env21480 := by
  intro p hp
  have h : env21480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21479_21480 : H12AffineEnvironment.transform 17 2421 env21479 = env21480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env21479 == env21480) = true)

theorem identity21480 : scanCanonicalize (H12AffineFastState.compose env21480 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound21480 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21481 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,4112,32768,33110,36865,2421,273,32769,36929,32,16,32771,348,64,2049,4096,36865,2420,32836,32801,257,32,36928,513]

theorem envBound21481 : H12AffineFastState.Bounded env21481 := by
  intro p hp
  have h : env21481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21480_21481 : H12AffineEnvironment.transform 9 272 env21480 = env21481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21480 == env21481) = true)

theorem identity21481 : scanCanonicalize (H12AffineFastState.compose env21481 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2128) := by decide +kernel

theorem selectedBound21481 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env21482 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,4112,2128,2310,6225,2421,273,2129,6161,32,16,2131,348,64,2049,4096,6225,2420,2068,2161,257,32,6160,513]

theorem envBound21482 : H12AffineFastState.Bounded env21482 := by
  intro p hp
  have h : env21482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21481_21482 : H12AffineEnvironment.transform 14 2128 env21481 = env21482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2128 env21481 == env21482) = true)

theorem identity21482 : scanCanonicalize (H12AffineFastState.compose env21482 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound21482 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env21483 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,17,348,1,2128,2310,2112,2421,273,2129,2048,32,16,2131,348,64,2049,17,2112,2420,2068,2161,257,32,2049,513]

theorem envBound21483 : H12AffineFastState.Bounded env21483 := by
  intro p hp
  have h : env21483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21482_21483 : H12AffineEnvironment.transform 11 17 env21482 = env21483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21482 == env21483) = true)

theorem identity21483 : scanCanonicalize (H12AffineFastState.compose env21483 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound21483 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21484 : List Nat := [2,4,8,16,32,64,8,256,512,272,293,17,348,1,373,35,357,80,273,372,293,32,16,374,348,64,292,17,357,81,305,340,257,32,292,513]

theorem envBound21484 : H12AffineFastState.Bounded env21484 := by
  intro p hp
  have h : env21484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21483_21484 : H12AffineEnvironment.transform 10 293 env21483 = env21484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env21483 == env21484) = true)

theorem identity21484 : scanCanonicalize (H12AffineFastState.compose env21484 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21484 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env21485 : List Nat := [2,4,8,16,32,17,8,256,512,272,293,17,269,1,292,35,308,1,273,293,293,32,16,295,269,17,292,17,308,0,305,261,257,32,292,513]

theorem envBound21485 : H12AffineFastState.Bounded env21485 := by
  intro p hp
  have h : env21485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21484_21485 : H12AffineEnvironment.transform 5 17 env21484 = env21485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21484 == env21485) = true)

def env21486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272392,169216,95497,8193,64,2049,163840,45404,283904,156696,411973,257,21792,46093,213830]

theorem envBound21486 : H12AffineFastState.Bounded env21486 := by
  intro p hp
  have h : env21486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21464_21486 : H12AffineEnvironment.transform 6 9 env21464 = env21486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21464 == env21486) = true)

def env21487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272392,16,95497,8193,64,2049,5392,45404,283904,61704,318549,257,21792,46093,120406]

theorem envBound21487 : H12AffineFastState.Bounded env21487 := by
  intro p hp
  have h : env21487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21486_21487 : H12AffineEnvironment.transform 16 38160 env21486 = env21487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env21486 == env21487) = true)

theorem identity21487 : scanCanonicalize (H12AffineFastState.compose env21487 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound21487 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,38160,262144,1025,32769,58396,272392,16,3,8193,64,2049,5392,45404,283904,61704,318549,257,21792,46093,41820]

theorem envBound21488 : H12AffineFastState.Bounded env21488 := by
  intro p hp
  have h : env21488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21487_21488 : H12AffineEnvironment.transform 15 29962 env21487 = env21488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env21487 == env21488) = true)

theorem identity21488 : scanCanonicalize (H12AffineFastState.compose env21488 (packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound21488 : packedSelected [1,3,5,8,10,16,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env21489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,38160,56357,1025,32769,58396,62509,16,3,8193,64,2049,5392,45404,35109,61704,112,257,21792,46093,41820]

theorem envBound21489 : H12AffineFastState.Bounded env21489 := by
  intro p hp
  have h : env21489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21488_21489 : H12AffineEnvironment.transform 17 56357 env21488 = env21489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env21488 == env21489) = true)

theorem identity21489 : scanCanonicalize (H12AffineFastState.compose env21489 (packedSelected [1,3,4,5,8,9,11,12,15,16,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound21489 : packedSelected [1,3,4,5,8,9,11,12,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env21490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,343,38160,43128,1025,32769,36929,32880,16,3,8193,64,2049,5392,45404,35109,34133,112,257,8573,46093,41820]

theorem envBound21490 : H12AffineFastState.Bounded env21490 := by
  intro p hp
  have h : env21490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21489_21490 : H12AffineEnvironment.transform 13 13405 env21489 = env21490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env21489 == env21490) = true)

theorem identity21490 : scanCanonicalize (H12AffineFastState.compose env21490 (packedSelected [1,3,4,5,8,9,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21490 : packedSelected [1,3,4,5,8,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env21491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,343,38160,35108,1025,32769,36929,32880,16,3,349,64,2049,5392,36864,35109,34133,112,257,33,38225,33280]

theorem envBound21491 : H12AffineFastState.Bounded env21491 := by
  intro p hp
  have h : env21491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21490_21491 : H12AffineEnvironment.transform 12 348 env21490 = env21491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21490 == env21491) = true)

theorem identity21491 : scanCanonicalize (H12AffineFastState.compose env21491 (packedSelected [0,1,2,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21491 : packedSelected [0,1,2,5,7,10] rootPS < 2^1333 := by decide +kernel

def env21492 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,32768,34,37989,34897,1025,32769,36929,32880,16,3,40,64,2049,5221,36864,34896,33824,112,116,33,37924,33280]

theorem envBound21492 : H12AffineFastState.Bounded env21492 := by
  intro p hp
  have h : env21492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21491_21492 : H12AffineEnvironment.transform 7 117 env21491 = env21492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21491 == env21492) = true)

theorem identity21492 : scanCanonicalize (H12AffineFastState.compose env21492 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21492 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21493 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,0,34,5221,2129,1025,1,4161,112,16,3,40,64,2049,5221,4096,2128,1056,112,116,33,5156,512]

theorem envBound21493 : H12AffineFastState.Bounded env21493 := by
  intro p hp
  have h : env21493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21492_21493 : H12AffineEnvironment.transform 14 0 env21492 = env21493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21492 == env21493) = true)

theorem identity21493 : scanCanonicalize (H12AffineFastState.compose env21493 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound21493 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21494 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,41,5124,0,34,5141,2081,1025,1,4145,0,16,3,40,48,2049,5141,4096,2080,1056,0,4,33,5156,512]

theorem envBound21494 : H12AffineFastState.Bounded env21494 := by
  intro p hp
  have h : env21494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21493_21494 : H12AffineEnvironment.transform 5 48 env21493 = env21494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env21493 == env21494) = true)

theorem identity21494 : scanCanonicalize (H12AffineFastState.compose env21494 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21494 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21495 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5124,0,3,5141,2048,1025,1,4112,0,16,3,9,17,2049,5141,4096,2049,1025,0,4,0,5125,512]

theorem envBound21495 : H12AffineFastState.Bounded env21495 := by
  intro p hp
  have h : env21495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21494_21495 : H12AffineEnvironment.transform 4 1 env21494 = env21495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21494 == env21495) = true)

theorem identity21495 : scanCanonicalize (H12AffineFastState.compose env21495 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21496 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,4096,8,4112,0,3,4097,2048,21,1,4112,0,16,3,9,17,2049,4097,4096,2049,21,0,4,0,4113,512]

theorem envBound21496 : H12AffineFastState.Bounded env21496 := by
  intro p hp
  have h : env21496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21495_21496 : H12AffineEnvironment.transform 9 20 env21495 = env21496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21495 == env21496) = true)

def env21497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272392,17,95497,8193,64,2049,5393,45404,283904,61705,318548,257,21792,46093,120407]

theorem envBound21497 : H12AffineFastState.Bounded env21497 := by
  intro p hp
  have h : env21497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21486_21497 : H12AffineEnvironment.transform 16 38161 env21486 = env21497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env21486 == env21497) = true)

theorem identity21497 : scanCanonicalize (H12AffineFastState.compose env21497 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound21497 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,89378,1025,32769,58397,95530,17,95497,8193,64,2049,5393,45404,67618,61705,98678,257,21792,46093,120407]

theorem envBound21498 : H12AffineFastState.Bounded env21498 := by
  intro p hp
  have h : env21498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21497_21498 : H12AffineEnvironment.transform 17 89378 env21497 = env21498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env21497 == env21498) = true)

theorem identity21498 : scanCanonicalize (H12AffineFastState.compose env21498 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21498 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env21499 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,32768,65536,37940,89095,1025,32769,58397,95247,17,95276,8193,64,2049,5172,45177,67618,61484,98387,36,21509,46093,120407]

theorem envBound21499 : H12AffineFastState.Bounded env21499 := by
  intro p hp
  have h : env21499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21498_21499 : H12AffineEnvironment.transform 7 37 env21498 = env21499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21498 == env21499) = true)

theorem identity21499 : scanCanonicalize (H12AffineFastState.compose env21499 (packedSelected [4,8,9,10,12,14,15,18,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 62511) := by decide +kernel

theorem selectedBound21499 : packedSelected [4,8,9,10,12,14,15,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env21500 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,32768,62511,37940,43048,1025,32769,58397,32800,17,32771,8193,64,2049,5172,45177,64525,61484,29820,36,21509,46093,8824]

theorem envBound21500 : H12AffineFastState.Bounded env21500 := by
  intro p hp
  have h : env21500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21499_21500 : H12AffineEnvironment.transform 15 62511 env21499 = env21500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62511 env21499 == env21500) = true)

theorem identity21500 : scanCanonicalize (H12AffineFastState.compose env21500 (packedSelected [3,5,10,11,12,15,16,20,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound21500 : packedSelected [3,5,10,11,12,15,16,20,32] rootPS < 2^1333 := by decide +kernel

def env21501 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29708,35,24632,23588,1025,29709,4113,29740,17,29711,8193,64,2049,5172,17525,2049,1056,29820,36,21509,16385,8824]

theorem envBound21501 : H12AffineFastState.Bounded env21501 := by
  intro p hp
  have h : env21501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21500_21501 : H12AffineEnvironment.transform 14 29708 env21500 = env21501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env21500 == env21501) = true)

theorem identity21501 : scanCanonicalize (H12AffineFastState.compose env21501 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound21501 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env21502 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,8232,35,13340,2048,1025,8233,4113,8200,17,8235,8193,64,2049,5172,4177,2049,1056,8280,36,33,5157,8824]

theorem envBound21502 : H12AffineFastState.Bounded env21502 := by
  intro p hp
  have h : env21502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21501_21502 : H12AffineEnvironment.transform 13 5156 env21501 = env21502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env21501 == env21502) = true)

theorem identity21502 : scanCanonicalize (H12AffineFastState.compose env21502 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21502 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env21503 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5156,8232,35,13340,2048,1025,8233,4113,8200,17,8235,8193,16,2049,5172,4097,2049,1056,8200,36,33,5157,8744]

theorem envBound21503 : H12AffineFastState.Bounded env21503 := by
  intro p hp
  have h : env21503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21502_21503 : H12AffineEnvironment.transform 5 16 env21502 = env21503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21502 == env21503) = true)

def env21504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,8388608,8642688,8328,64,4464768,8393985,8528989,8830976,156817,12645452,257,21793,46213,213830]

theorem envBound21504 : H12AffineFastState.Bounded env21504 := by
  intro p hp
  have h : env21504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21398_21504 : H12AffineEnvironment.transform 20 160013 env21398 = env21504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160013 env21398 == env21504) = true)

def env21505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,169352,95496,8328,64,4464768,163977,45525,284040,156817,4350404,257,21793,46213,213830]

theorem envBound21505 : H12AffineFastState.Bounded env21505 := by
  intro p hp
  have h : env21505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21504_21505 : H12AffineEnvironment.transform 22 169352 env21504 = env21505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env21504 == env21505) = true)

def env21506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272512,169352,95496,8328,64,2048,163977,45525,284040,156817,411972,257,21793,46213,213830]

theorem envBound21506 : H12AffineFastState.Bounded env21506 := by
  intro p hp
  have h : env21506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21505_21506 : H12AffineEnvironment.transform 21 272512 env21505 = env21506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21505 == env21506) = true)

theorem identity21506 : scanCanonicalize (H12AffineFastState.compose env21506 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound21506 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,160013,272512,169352,41430,8328,64,2048,163977,45525,284040,156817,411972,257,21793,46213,169880]

theorem envBound21507 : H12AffineFastState.Bounded env21507 := by
  intro p hp
  have h : env21507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21506_21507 : H12AffineEnvironment.transform 15 54494 env21506 = env21507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env21506 == env21507) = true)

def env21508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,160013,272392,169216,41310,8192,64,2048,163841,45405,283904,156697,411972,257,21793,46093,169744]

theorem envBound21508 : H12AffineFastState.Bounded env21508 := by
  intro p hp
  have h : env21508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21507_21508 : H12AffineEnvironment.transform 6 8 env21507 = env21508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21507 == env21508) = true)

theorem identity21508 : scanCanonicalize (H12AffineFastState.compose env21508 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound21508 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env21509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,138340,1025,32769,160013,144492,169216,41310,8192,64,2048,163841,45405,149860,156697,21792,257,21793,46093,169744]

theorem envBound21509 : H12AffineFastState.Bounded env21509 := by
  intro p hp
  have h : env21509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21508_21509 : H12AffineEnvironment.transform 17 138340 env21508 = env21509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env21508 == env21509) = true)

theorem identity21509 : scanCanonicalize (H12AffineFastState.compose env21509 (packedSelected [0,1,9,10,16,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound21509 : packedSelected [0,1,9,10,16,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env21510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24908,32040,1025,32769,4161,21792,62540,41310,8192,64,2048,57677,45405,10280,1365,21792,257,21793,46093,63068]

theorem envBound21510 : H12AffineFastState.Bounded env21510 := by
  intro p hp
  have h : env21510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21509_21510 : H12AffineEnvironment.transform 16 24908 env21509 = env21510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env21509 == env21510) = true)

theorem identity21510 : scanCanonicalize (H12AffineFastState.compose env21510 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21872) := by decide +kernel

theorem selectedBound21510 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env21511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21872,294,24908,32040,1025,21873,4161,21792,8508,29742,8192,64,2048,13373,25645,10280,1365,21792,257,21793,24957,9004]

theorem envBound21511 : H12AffineFastState.Bounded env21511 := by
  intro p hp
  have h : env21511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21510_21511 : H12AffineEnvironment.transform 14 21872 env21510 = env21511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21872 env21510 == env21511) = true)

theorem identity21511 : scanCanonicalize (H12AffineFastState.compose env21511 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound21511 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env21512 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,16384,21761,294,24893,32040,1025,21760,4144,21792,8508,29742,8192,49,2048,13373,25645,10280,1316,21792,257,21793,24844,9004]

theorem envBound21512 : H12AffineFastState.Bounded env21512 := by
  intro p hp
  have h : env21512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21511_21512 : H12AffineEnvironment.transform 5 49 env21511 = env21512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env21511 == env21512) = true)

theorem identity21512 : scanCanonicalize (H12AffineFastState.compose env21512 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound21512 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env21513 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,301,16384,21761,294,16400,23557,1025,21760,4144,21792,17,21763,301,49,2048,5392,17664,2309,1316,21792,257,21793,16417,513]

theorem envBound21513 : H12AffineFastState.Bounded env21513 := by
  intro p hp
  have h : env21513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21512_21513 : H12AffineEnvironment.transform 12 301 env21512 = env21513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env21512 == env21513) = true)

theorem identity21513 : scanCanonicalize (H12AffineFastState.compose env21513 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound21513 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21514 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,301,5408,33,294,5424,2341,1025,32,4144,0,17,35,301,49,2048,5392,4128,2309,1316,0,257,1,5377,513]

theorem envBound21514 : H12AffineFastState.Bounded env21514 := by
  intro p hp
  have h : env21514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21513_21514 : H12AffineEnvironment.transform 13 5408 env21513 = env21514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env21513 == env21514) = true)

theorem identity21514 : scanCanonicalize (H12AffineFastState.compose env21514 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound21514 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env21515 : List Nat := [2,4,8,16,32,49,8,256,512,1024,309,4096,301,5408,33,294,5424,16,1025,32,4144,0,17,35,301,49,309,5392,4128,48,1316,0,257,1,5377,513]

theorem envBound21515 : H12AffineFastState.Bounded env21515 := by
  intro p hp
  have h : env21515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21514_21515 : H12AffineEnvironment.transform 10 309 env21514 = env21515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env21514 == env21515) = true)

theorem identity21515 : scanCanonicalize (H12AffineFastState.compose env21515 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound21515 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env21516 : List Nat := [2,4,8,16,32,49,8,256,512,1024,309,1312,301,0,33,294,16,16,1025,32,1296,0,17,35,301,49,309,48,1280,48,1316,0,257,1,33,513]

theorem envBound21516 : H12AffineFastState.Bounded env21516 := by
  intro p hp
  have h : env21516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21515_21516 : H12AffineEnvironment.transform 11 1312 env21515 = env21516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env21515 == env21516) = true)

theorem identity21516 : scanCanonicalize (H12AffineFastState.compose env21516 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound21516 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21517 : List Nat := [2,4,8,16,32,49,8,256,512,801,309,513,301,0,33,294,16,16,800,32,561,0,17,35,301,49,309,48,545,48,517,0,257,1,33,513]

theorem envBound21517 : H12AffineFastState.Bounded env21517 := by
  intro p hp
  have h : env21517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21516_21517 : H12AffineEnvironment.transform 9 801 env21516 = env21517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env21516 == env21517) = true)

theorem identity21517 : scanCanonicalize (H12AffineFastState.compose env21517 (packedSelected [1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound21517 : packedSelected [1,4,8] rootPS < 2^1333 := by decide +kernel

def env21518 : List Nat := [2,4,8,16,32,49,8,256,17,304,309,16,301,0,33,294,16,16,305,32,32,0,17,35,301,49,309,48,48,48,20,0,257,1,33,16]

theorem envBound21518 : H12AffineFastState.Bounded env21518 := by
  intro p hp
  have h : env21518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21517_21518 : H12AffineEnvironment.transform 8 17 env21517 = env21518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env21517 == env21518) = true)

theorem identity21518 : scanCanonicalize (H12AffineFastState.compose env21518 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21518 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21519 : List Nat := [2,4,8,1,32,32,8,256,0,289,292,1,301,0,33,294,1,1,288,32,32,0,0,35,301,32,292,33,33,33,5,0,257,1,33,1]

theorem envBound21519 : H12AffineFastState.Bounded env21519 := by
  intro p hp
  have h : env21519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21518_21519 : H12AffineEnvironment.transform 3 1 env21518 = env21519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21518 == env21519) = true)

theorem identity21519 : scanCanonicalize (H12AffineFastState.compose env21519 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21519 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21520 : List Nat := [2,4,8,1,32,32,8,4,0,37,32,1,41,0,33,34,1,1,36,32,32,0,0,35,41,32,32,33,33,33,5,0,5,1,33,1]

theorem envBound21520 : H12AffineFastState.Bounded env21520 := by
  intro p hp
  have h : env21520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21519_21520 : H12AffineEnvironment.transform 7 4 env21519 = env21520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21519 == env21520) = true)

theorem identity21520 : scanCanonicalize (H12AffineFastState.compose env21520 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21520 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21521 : List Nat := [2,4,8,1,1,1,8,4,0,4,1,1,8,0,0,3,1,1,5,1,1,0,0,2,8,1,1,0,0,0,5,0,5,1,0,1]

theorem envBound21521 : H12AffineFastState.Bounded env21521 := by
  intro p hp
  have h : env21521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21520_21521 : H12AffineEnvironment.transform 4 1 env21520 = env21521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21520 == env21521) = true)

def env21522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,160013,272393,169217,41311,8193,64,2048,163840,45404,283905,156696,411972,257,21793,46092,169745]

theorem envBound21522 : H12AffineFastState.Bounded env21522 := by
  intro p hp
  have h : env21522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21507_21522 : H12AffineEnvironment.transform 6 9 env21507 = env21522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21507 == env21522) = true)

theorem identity21522 : scanCanonicalize (H12AffineFastState.compose env21522 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(16+1) ^^^ 46392) := by decide +kernel

theorem selectedBound21522 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env21523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46392,262144,1025,32769,50229,272393,8249,41311,8193,64,2048,13624,45404,283905,53536,326780,257,21793,46092,8745]

theorem envBound21523 : H12AffineFastState.Bounded env21523 := by
  intro p hp
  have h : env21523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21522_21523 : H12AffineEnvironment.transform 16 46392 env21522 = env21523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46392 env21522 == env21523) = true)

theorem identity21523 : scanCanonicalize (H12AffineFastState.compose env21523 (packedSelected [1,3,7,10,17,19,20,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound21523 : packedSelected [1,3,7,10,17,19,20,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env21524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46392,35188,1025,32769,50229,41341,8249,41311,8193,64,2048,13624,45404,56437,53536,29960,257,21793,46092,8745]

theorem envBound21524 : H12AffineFastState.Bounded env21524 := by
  intro p hp
  have h : env21524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21523_21524 : H12AffineEnvironment.transform 17 35188 env21523 = env21524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env21523 == env21524) = true)

theorem identity21524 : scanCanonicalize (H12AffineFastState.compose env21524 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21524 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env21525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54359,37988,35188,1025,32769,50229,32801,357,32771,349,64,2048,5220,36864,56437,53536,21588,257,21793,38224,885]

theorem envBound21525 : H12AffineFastState.Bounded env21525 := by
  intro p hp
  have h : env21525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21524_21525 : H12AffineEnvironment.transform 12 348 env21524 = env21525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21524 == env21525) = true)

theorem identity21525 : scanCanonicalize (H12AffineFastState.compose env21525 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21525 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env21526 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,16384,32768,54359,37988,34816,1025,32769,50229,32801,17,32771,41,64,2048,5220,36864,56437,53332,21588,117,21589,37924,513]

theorem envBound21526 : H12AffineFastState.Bounded env21526 := by
  intro p hp
  have h : env21526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21525_21526 : H12AffineEnvironment.transform 7 116 env21525 = env21526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21525 == env21526) = true)

theorem identity21526 : scanCanonicalize (H12AffineFastState.compose env21526 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound21526 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21527 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,16384,21620,35,16400,23668,1025,21621,4161,21589,17,21623,41,64,2048,5220,17524,2049,1056,21588,117,21589,16464,513]

theorem envBound21527 : H12AffineFastState.Bounded env21527 := by
  intro p hp
  have h : env21527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21526_21527 : H12AffineEnvironment.transform 14 21620 env21526 = env21527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env21526 == env21527) = true)

theorem identity21527 : scanCanonicalize (H12AffineFastState.compose env21527 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound21527 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21528 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5157,81,35,5173,2129,1025,80,4161,112,17,82,41,64,2048,5220,4177,2049,1056,113,117,112,5237,513]

theorem envBound21528 : H12AffineFastState.Bounded env21528 := by
  intro p hp
  have h : env21528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21527_21528 : H12AffineEnvironment.transform 13 5157 env21527 = env21528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env21527 == env21528) = true)

theorem identity21528 : scanCanonicalize (H12AffineFastState.compose env21528 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound21528 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21529 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1045,40,48,81,35,32,2129,1025,80,1108,112,17,82,41,64,2048,113,1092,2049,1056,113,117,112,96,513]

theorem envBound21529 : H12AffineFastState.Bounded env21529 := by
  intro p hp
  have h : env21529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21528_21529 : H12AffineEnvironment.transform 11 1045 env21528 = env21529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env21528 == env21529) = true)

theorem identity21529 : scanCanonicalize (H12AffineFastState.compose env21529 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound21529 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env21530 : List Nat := [2,4,8,16,32,48,9,4,512,1024,2048,1045,40,48,33,35,32,2081,1025,32,1060,0,17,34,41,48,2048,1,1076,2049,1056,1,5,0,16,513]

theorem envBound21530 : H12AffineFastState.Bounded env21530 := by
  intro p hp
  have h : env21530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21529_21530 : H12AffineEnvironment.transform 5 48 env21529 = env21530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env21529 == env21530) = true)

theorem identity21530 : scanCanonicalize (H12AffineFastState.compose env21530 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21530 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env21531 : List Nat := [2,4,8,16,32,48,9,4,512,52,2048,33,40,48,33,35,32,2081,53,32,16,0,17,34,41,48,2048,1,0,2049,20,1,5,0,16,513]

theorem envBound21531 : H12AffineFastState.Bounded env21531 := by
  intro p hp
  have h : env21531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21530_21531 : H12AffineEnvironment.transform 9 52 env21530 = env21531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21530 == env21531) = true)

theorem identity21531 : scanCanonicalize (H12AffineFastState.compose env21531 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound21531 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env21532 : List Nat := [2,4,8,16,32,48,9,4,512,52,58,33,40,48,33,35,32,27,53,32,16,0,17,34,41,48,58,1,0,59,20,1,5,0,16,513]

theorem envBound21532 : H12AffineFastState.Bounded env21532 := by
  intro p hp
  have h : env21532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21531_21532 : H12AffineEnvironment.transform 10 58 env21531 = env21532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env21531 == env21532) = true)

theorem identity21532 : scanCanonicalize (H12AffineFastState.compose env21532 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound21532 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env21533 : List Nat := [2,4,8,16,32,48,9,4,0,52,58,33,40,48,33,35,32,27,53,32,16,0,17,34,41,48,58,1,0,59,20,1,5,0,16,1]

theorem envBound21533 : H12AffineFastState.Bounded env21533 := by
  intro p hp
  have h : env21533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21532_21533 : H12AffineEnvironment.transform 8 0 env21532 = env21533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21532 == env21533) = true)

theorem identity21533 : scanCanonicalize (H12AffineFastState.compose env21533 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21533 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env21534 : List Nat := [2,4,8,16,1,17,9,4,0,21,27,0,9,17,0,2,1,27,20,1,16,0,17,3,8,17,27,1,0,26,20,1,5,0,16,1]

theorem envBound21534 : H12AffineFastState.Bounded env21534 := by
  intro p hp
  have h : env21534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21533_21534 : H12AffineEnvironment.transform 4 1 env21533 = env21534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21533 == env21534) = true)

theorem identity21534 : scanCanonicalize (H12AffineFastState.compose env21534 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21535 : List Nat := [2,4,8,1,1,0,9,4,0,4,10,0,9,0,0,2,1,10,5,1,1,0,0,3,8,0,10,1,0,11,5,1,5,0,1,1]

theorem envBound21535 : H12AffineFastState.Bounded env21535 := by
  intro p hp
  have h : env21535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21534_21535 : H12AffineEnvironment.transform 3 1 env21534 = env21535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21534 == env21535) = true)

theorem identity21535 : scanCanonicalize (H12AffineFastState.compose env21535 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21535 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21536 : List Nat := [2,4,2,1,1,0,3,4,0,4,0,0,3,0,0,2,1,0,5,1,1,0,0,3,2,0,0,1,0,1,5,1,5,0,1,1]

theorem envBound21536 : H12AffineFastState.Bounded env21536 := by
  intro p hp
  have h : env21536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21535_21536 : H12AffineEnvironment.transform 2 2 env21535 = env21536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21535 == env21536) = true)

def env21537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272513,169352,95496,8328,64,2049,163977,45525,284040,156817,411973,257,21793,46213,213830]

theorem envBound21537 : H12AffineFastState.Bounded env21537 := by
  intro p hp
  have h : env21537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21505_21537 : H12AffineEnvironment.transform 21 272513 env21505 = env21537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21505 == env21537) = true)

theorem identity21537 : scanCanonicalize (H12AffineFastState.compose env21537 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound21537 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272513,120015,95496,8328,64,2049,115150,45525,284040,75222,329730,257,21793,46213,513]

theorem envBound21538 : H12AffineFastState.Bounded env21538 := by
  intro p hp
  have h : env21538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21537_21538 : H12AffineEnvironment.transform 16 82247 env21537 = env21538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env21537 == env21538) = true)

def env21539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272393,119879,95496,8192,64,2049,115014,45405,283904,75102,329730,257,21793,46093,513]

theorem envBound21539 : H12AffineFastState.Bounded env21539 := by
  intro p hp
  have h : env21539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21538_21539 : H12AffineEnvironment.transform 6 8 env21538 = env21539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21538 == env21539) = true)

def env21540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,77898,33,119879,95496,8192,64,2049,115014,45405,32040,75102,73770,257,21793,46093,513]

theorem envBound21540 : H12AffineFastState.Bounded env21540 := by
  intro p hp
  have h : env21540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21539_21540 : H12AffineEnvironment.transform 17 10280 env21539 = env21540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21539 == env21540) = true)

theorem identity21540 : scanCanonicalize (H12AffineFastState.compose env21540 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound21540 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env21541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,5393,10280,1025,32769,25628,33,32785,8542,8192,64,2049,38160,45405,32040,28936,29820,257,21793,46093,513]

theorem envBound21541 : H12AffineFastState.Bounded env21541 := by
  intro p hp
  have h : env21541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21540_21541 : H12AffineEnvironment.transform 15 21590 env21540 = env21541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env21540 == env21541) = true)

theorem identity21541 : scanCanonicalize (H12AffineFastState.compose env21541 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21541 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env21542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21590,5393,10280,1025,0,25628,33,16,8542,8192,64,2049,5393,12636,32040,28936,29820,257,21793,13324,513]

theorem envBound21542 : H12AffineFastState.Bounded env21542 := by
  intro p hp
  have h : env21542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21541_21542 : H12AffineEnvironment.transform 14 1 env21541 = env21542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21541 == env21542) = true)

theorem identity21542 : scanCanonicalize (H12AffineFastState.compose env21542 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21542 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,21590,5393,2341,1025,0,17681,33,16,83,269,64,2049,5393,4177,23589,20485,21873,257,21793,5377,513]

theorem envBound21543 : H12AffineFastState.Bounded env21543 := by
  intro p hp
  have h : env21543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21542_21543 : H12AffineEnvironment.transform 12 269 env21542 = env21543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21542 == env21543) = true)

theorem identity21543 : scanCanonicalize (H12AffineFastState.compose env21543 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21543 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,1,342,5393,2341,1025,0,4113,33,16,83,269,64,2049,5393,4177,2341,1285,113,257,33,5377,513]

theorem envBound21544 : H12AffineFastState.Bounded env21544 := by
  intro p hp
  have h : env21544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21543_21544 : H12AffineEnvironment.transform 13 5376 env21543 = env21544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21543 == env21544) = true)

def env21545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,77898,32,119879,95496,8192,64,2049,115014,45405,32041,75102,73771,257,21793,46093,513]

theorem envBound21545 : H12AffineFastState.Bounded env21545 := by
  intro p hp
  have h : env21545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21539_21545 : H12AffineEnvironment.transform 17 10281 env21539 = env21545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21539 == env21545) = true)

theorem identity21545 : scanCanonicalize (H12AffineFastState.compose env21545 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound21545 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10281,1025,32769,58397,32,16,41311,8192,64,2049,5393,45405,32041,61705,62588,257,21793,46093,513]

theorem envBound21546 : H12AffineFastState.Bounded env21546 := by
  intro p hp
  have h : env21546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21545_21546 : H12AffineEnvironment.transform 15 54359 env21545 = env21546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env21545 == env21546) = true)

theorem identity21546 : scanCanonicalize (H12AffineFastState.compose env21546 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound21546 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env21547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,2048,32768,40023,38160,10281,1025,32769,44061,32,16,41311,8192,64,2049,5393,45405,13609,47369,48252,257,7457,46093,513]

theorem envBound21547 : H12AffineFastState.Bounded env21547 := by
  intro p hp
  have h : env21547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21546_21547 : H12AffineEnvironment.transform 13 2048 env21546 = env21547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env21546 == env21547) = true)

theorem identity21547 : scanCanonicalize (H12AffineFastState.compose env21547 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21547 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,2048,32768,40023,38160,2421,1025,32769,36161,32,16,32771,348,64,2049,5393,36865,5237,38997,40224,257,7457,38225,513]

theorem envBound21548 : H12AffineFastState.Bounded env21548 := by
  intro p hp
  have h : env21548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21547_21548 : H12AffineEnvironment.transform 12 348 env21547 = env21548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21547 == env21548) = true)

theorem identity21548 : scanCanonicalize (H12AffineFastState.compose env21548 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound21548 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env21549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,348,1296,32768,37191,38160,1125,1025,32769,32849,32,16,32771,348,64,1297,5393,36865,5237,38213,36912,257,4145,38225,513]

theorem envBound21549 : H12AffineFastState.Bounded env21549 := by
  intro p hp
  have h : env21549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21548_21549 : H12AffineEnvironment.transform 10 1296 env21548 = env21549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env21548 == env21549) = true)

theorem identity21549 : scanCanonicalize (H12AffineFastState.compose env21549 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21549 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env21550 : List Nat := [2,4,8,16,32,64,8,256,512,273,1,4096,348,1,32768,37191,36865,372,272,32769,32849,32,16,32771,348,64,0,4096,36865,4452,36948,36912,257,4145,36928,513]

theorem envBound21550 : H12AffineFastState.Bounded env21550 := by
  intro p hp
  have h : env21550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21549_21550 : H12AffineEnvironment.transform 9 273 env21549 = env21550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21549 == env21550) = true)

theorem identity21550 : scanCanonicalize (H12AffineFastState.compose env21550 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 4453) := by decide +kernel

theorem selectedBound21550 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21551 : List Nat := [2,4,8,16,32,64,8,256,512,273,1,4096,348,1,4453,34,356,372,272,4452,4404,32,16,4454,348,64,0,4096,356,4452,305,341,257,4145,293,513]

theorem envBound21551 : H12AffineFastState.Bounded env21551 := by
  intro p hp
  have h : env21551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21550_21551 : H12AffineEnvironment.transform 14 4453 env21550 = env21551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4453 env21550 == env21551) = true)

theorem identity21551 : scanCanonicalize (H12AffineFastState.compose env21551 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21551 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env21552 : List Nat := [2,4,8,16,32,64,8,117,512,100,1,4096,41,1,4112,34,17,1,101,4113,4161,32,16,4115,41,64,0,4096,17,4113,68,32,116,4145,80,513]

theorem envBound21552 : H12AffineFastState.Bounded env21552 := by
  intro p hp
  have h : env21552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21551_21552 : H12AffineEnvironment.transform 7 117 env21551 = env21552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21551 == env21552) = true)

theorem identity21552 : scanCanonicalize (H12AffineFastState.compose env21552 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound21552 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21553 : List Nat := [2,4,8,16,32,64,8,117,512,100,1,64,41,1,80,34,17,1,101,81,1,32,16,83,41,64,0,64,17,81,68,32,116,113,80,513]

theorem envBound21553 : H12AffineFastState.Bounded env21553 := by
  intro p hp
  have h : env21553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21552_21553 : H12AffineEnvironment.transform 11 64 env21552 = env21553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env21552 == env21553) = true)

theorem identity21553 : scanCanonicalize (H12AffineFastState.compose env21553 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21553 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21554 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,16,41,1,0,34,17,1,53,1,1,32,16,3,41,16,0,16,17,1,20,32,36,33,0,513]

theorem envBound21554 : H12AffineFastState.Bounded env21554 := by
  intro p hp
  have h : env21554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21553_21554 : H12AffineEnvironment.transform 5 16 env21553 = env21554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21553 == env21554) = true)

theorem identity21554 : scanCanonicalize (H12AffineFastState.compose env21554 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound21554 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21555 : List Nat := [2,4,8,16,32,16,8,37,32,52,1,16,41,1,0,34,17,1,53,1,1,32,16,3,41,16,0,16,17,1,20,32,36,33,0,33]

theorem envBound21555 : H12AffineFastState.Bounded env21555 := by
  intro p hp
  have h : env21555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21554_21555 : H12AffineEnvironment.transform 8 32 env21554 = env21555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env21554 == env21555) = true)

theorem identity21555 : scanCanonicalize (H12AffineFastState.compose env21555 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21555 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21556 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,16,9,1,0,2,17,1,21,1,1,0,16,3,9,16,0,16,17,1,20,0,4,1,0,1]

theorem envBound21556 : H12AffineFastState.Bounded env21556 := by
  intro p hp
  have h : env21556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21555_21556 : H12AffineEnvironment.transform 4 0 env21555 = env21556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21555 == env21556) = true)

def env21557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272392,119878,95496,8193,64,2049,115015,45404,283905,75103,329730,257,21793,46092,513]

theorem envBound21557 : H12AffineFastState.Bounded env21557 := by
  intro p hp
  have h : env21557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21538_21557 : H12AffineEnvironment.transform 6 9 env21538 = env21557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21538 == env21557) = true)

theorem identity21557 : scanCanonicalize (H12AffineFastState.compose env21557 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21557 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82247,262144,1025,32769,69910,264532,119878,87124,349,64,2049,115015,36864,283905,66563,329730,257,21793,38224,513]

theorem envBound21558 : H12AffineFastState.Bounded env21558 := by
  intro p hp
  have h : env21558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21557_21558 : H12AffineEnvironment.transform 12 348 env21557 = env21558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21557 == env21558) = true)

theorem identity21558 : scanCanonicalize (H12AffineFastState.compose env21558 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound21558 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env21559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21841,65536,82247,262144,1025,21840,69910,264532,65815,87124,349,64,2049,70678,17745,283905,66563,329730,257,21793,16385,513]

theorem envBound21559 : H12AffineFastState.Bounded env21559 := by
  intro p hp
  have h : env21559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21558_21559 : H12AffineEnvironment.transform 14 21841 env21558 = env21559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env21558 == env21559) = true)

theorem identity21559 : scanCanonicalize (H12AffineFastState.compose env21559 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 89174) := by decide +kernel

theorem selectedBound21559 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21841,65536,82247,89174,1025,21840,69910,87298,65815,87124,349,64,2049,70678,17745,67927,66563,21588,257,21793,16385,513]

theorem envBound21560 : H12AffineFastState.Bounded env21560 := by
  intro p hp
  have h : env21560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21559_21560 : H12AffineEnvironment.transform 17 89174 env21559 = env21560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89174 env21559 == env21560) = true)

theorem identity21560 : scanCanonicalize (H12AffineFastState.compose env21560 (packedSelected [0,1,4,5,7,8,9,11,14,17,18,24] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21560 : packedSelected [0,1,4,5,7,8,9,11,14,17,18,24] rootPS < 2^1333 := by decide +kernel

def env21561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,81,65536,70727,67926,1025,80,69910,65538,65815,65876,349,64,2049,70678,4177,67927,66563,340,257,33,5377,513]

theorem envBound21561 : H12AffineFastState.Bounded env21561 := by
  intro p hp
  have h : env21561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21560_21561 : H12AffineEnvironment.transform 13 5376 env21560 = env21561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21560 == env21561) = true)

theorem identity21561 : scanCanonicalize (H12AffineFastState.compose env21561 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21561 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21562 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4405,81,65536,69746,67926,52,80,69910,65538,65815,65876,349,64,2049,69667,4177,67927,65590,340,257,33,4404,513]

theorem envBound21562 : H12AffineFastState.Bounded env21562 := by
  intro p hp
  have h : env21562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21561_21562 : H12AffineEnvironment.transform 9 53 env21561 = env21562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21561 == env21562) = true)

theorem identity21562 : scanCanonicalize (H12AffineFastState.compose env21562 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound21562 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21563 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4405,81,263,4469,2129,52,80,4113,261,16,83,349,64,2049,4388,4177,2128,305,340,257,33,4404,513]

theorem envBound21563 : H12AffineFastState.Bounded env21563 := by
  intro p hp
  have h : env21563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21562_21563 : H12AffineEnvironment.transform 15 263 env21562 = env21563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env21562 == env21563) = true)

theorem identity21563 : scanCanonicalize (H12AffineFastState.compose env21563 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound21563 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env21564 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,348,2049,81,263,2113,2129,52,80,2341,261,16,83,349,64,2049,2064,2405,2128,305,340,257,33,2048,513]

theorem envBound21564 : H12AffineFastState.Bounded env21564 := by
  intro p hp
  have h : env21564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21563_21564 : H12AffineEnvironment.transform 11 2356 env21563 = env21564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env21563 == env21564) = true)

theorem identity21564 : scanCanonicalize (H12AffineFastState.compose env21564 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21564 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env21565 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2356,269,2049,0,263,2064,2048,52,1,2341,261,16,2,268,17,2049,2064,2356,2049,305,261,257,33,2048,513]

theorem envBound21565 : H12AffineFastState.Bounded env21565 := by
  intro p hp
  have h : env21565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21564_21565 : H12AffineEnvironment.transform 5 17 env21564 = env21565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21564 == env21565) = true)

theorem identity21565 : scanCanonicalize (H12AffineFastState.compose env21565 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21565 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21566 : List Nat := [2,4,8,16,32,17,9,20,512,53,2048,2080,25,2049,0,19,2064,2048,52,1,2097,17,16,2,24,17,2049,2064,2080,2049,37,17,21,33,2048,513]

theorem envBound21566 : H12AffineFastState.Bounded env21566 := by
  intro p hp
  have h : env21566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21565_21566 : H12AffineEnvironment.transform 7 20 env21565 = env21566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21565 == env21566) = true)

theorem identity21566 : scanCanonicalize (H12AffineFastState.compose env21566 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21566 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21567 : List Nat := [2,4,8,16,32,17,9,20,1,53,2048,2080,25,2049,0,19,2064,2048,52,1,2097,17,16,2,24,17,2049,2064,2080,2049,37,17,21,33,2048,0]

theorem envBound21567 : H12AffineFastState.Bounded env21567 := by
  intro p hp
  have h : env21567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21566_21567 : H12AffineEnvironment.transform 8 1 env21566 = env21567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21566 == env21567) = true)

theorem identity21567 : scanCanonicalize (H12AffineFastState.compose env21567 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21567 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21568 : List Nat := [2,4,8,1,32,0,9,5,1,36,2048,2080,8,2049,0,2,2049,2048,37,1,2080,0,1,2,9,0,2049,2049,2080,2049,37,0,4,33,2048,0]

theorem envBound21568 : H12AffineFastState.Bounded env21568 := by
  intro p hp
  have h : env21568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21567_21568 : H12AffineEnvironment.transform 3 1 env21567 = env21568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21567 == env21568) = true)

theorem identity21568 : scanCanonicalize (H12AffineFastState.compose env21568 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21568 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21569 : List Nat := [2,4,8,1,0,0,9,5,1,4,2048,2048,8,2049,0,2,2049,2048,5,1,2048,0,1,2,9,0,2049,2049,2048,2049,5,0,4,1,2048,0]

theorem envBound21569 : H12AffineFastState.Bounded env21569 := by
  intro p hp
  have h : env21569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21568_21569 : H12AffineEnvironment.transform 4 0 env21568 = env21569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21568 == env21569) = true)

theorem identity21569 : scanCanonicalize (H12AffineFastState.compose env21569 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21569 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env21570 : List Nat := [2,4,8,1,0,0,9,5,1,4,1,1,8,0,0,2,0,1,5,1,1,0,1,2,9,0,0,0,1,0,5,0,4,1,1,0]

theorem envBound21570 : H12AffineFastState.Bounded env21570 := by
  intro p hp
  have h : env21570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21569_21570 : H12AffineEnvironment.transform 10 1 env21569 = env21570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21569 == env21570) = true)

def env21571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,169353,95497,8328,64,4464768,163976,45524,284041,156817,4350405,257,21793,46213,213830]

theorem envBound21571 : H12AffineFastState.Bounded env21571 := by
  intro p hp
  have h : env21571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21504_21571 : H12AffineEnvironment.transform 22 169353 env21504 = env21571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env21504 == env21571) = true)

def env21572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272512,169353,95497,8328,64,2048,163976,45524,284041,156817,411973,257,21793,46213,213830]

theorem envBound21572 : H12AffineFastState.Bounded env21572 := by
  intro p hp
  have h : env21572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21571_21572 : H12AffineEnvironment.transform 21 272512 env21571 = env21572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21571 == env21572) = true)

theorem identity21572 : scanCanonicalize (H12AffineFastState.compose env21572 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21572 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272512,169353,21763,8328,64,2048,163976,45524,284041,156817,411973,257,21793,46213,156492]

theorem envBound21573 : H12AffineFastState.Bounded env21573 := by
  intro p hp
  have h : env21573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21572_21573 : H12AffineEnvironment.transform 15 8202 env21572 = env21573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21572 == env21573) = true)

def env21574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272392,169217,21763,8192,64,2048,163840,45404,283905,156697,411973,257,21793,46093,156492]

theorem envBound21574 : H12AffineFastState.Bounded env21574 := by
  intro p hp
  have h : env21574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21573_21574 : H12AffineEnvironment.transform 6 8 env21573 = env21574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21573 == env21574) = true)

theorem identity21574 : scanCanonicalize (H12AffineFastState.compose env21574 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound21574 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env21575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,157752,1025,32769,160013,147504,169217,21763,8192,64,2048,163840,45404,146745,156697,8573,257,21793,46093,156492]

theorem envBound21575 : H12AffineFastState.Bounded env21575 := by
  intro p hp
  have h : env21575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21574_21575 : H12AffineEnvironment.transform 17 157752 env21574 = env21575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env21574 == env21575) = true)

theorem identity21575 : scanCanonicalize (H12AffineFastState.compose env21575 (packedSelected [1,4,5,7,8,9,17,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound21575 : packedSelected [1,4,5,7,8,9,17,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env21576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,57676,35188,1025,32769,36929,41340,29773,21763,8192,64,2048,24908,45404,56437,34133,8573,257,21793,46093,33280]

theorem envBound21576 : H12AffineFastState.Bounded env21576 := by
  intro p hp
  have h : env21576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21575_21576 : H12AffineEnvironment.transform 16 57676 env21575 = env21576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env21575 == env21576) = true)

theorem identity21576 : scanCanonicalize (H12AffineFastState.compose env21576 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound21576 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env21577 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,13388,23668,1025,21761,17729,29820,29773,21763,8192,64,2048,24908,25692,2421,20565,8573,257,21793,24845,22272]

theorem envBound21577 : H12AffineFastState.Bounded env21577 := by
  intro p hp
  have h : env21577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21576_21577 : H12AffineEnvironment.transform 14 21760 env21576 = env21577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env21576 == env21577) = true)

theorem identity21577 : scanCanonicalize (H12AffineFastState.compose env21577 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound21577 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21578 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,372,8202,13388,2048,1025,373,4405,8200,8249,375,8192,64,2048,13624,12328,2421,1057,8573,257,341,13689,884]

theorem envBound21578 : H12AffineFastState.Bounded env21578 := by
  intro p hp
  have h : env21578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21577_21578 : H12AffineEnvironment.transform 13 5236 env21577 = env21578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env21577 == env21578) = true)

theorem identity21578 : scanCanonicalize (H12AffineFastState.compose env21578 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21578 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21579 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,1,8202,13388,2048,1025,0,4160,8200,8249,2,8192,64,2048,13389,12328,2048,1057,8200,116,32,13324,513]

theorem envBound21579 : H12AffineFastState.Bounded env21579 := by
  intro p hp
  have h : env21579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21578_21579 : H12AffineEnvironment.transform 7 117 env21578 = env21579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21578 == env21579) = true)

theorem identity21579 : scanCanonicalize (H12AffineFastState.compose env21579 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 5196) := by decide +kernel

theorem selectedBound21579 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env21580 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,5196,5236,1,5190,0,2048,1025,0,4160,5188,5237,2,5196,64,2048,1,1124,2048,1057,5188,116,32,64,513]

theorem envBound21580 : H12AffineFastState.Bounded env21580 := by
  intro p hp
  have h : env21580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21579_21580 : H12AffineEnvironment.transform 12 5196 env21579 = env21580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5196 env21579 == env21580) = true)

theorem identity21580 : scanCanonicalize (H12AffineFastState.compose env21580 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3173) := by decide +kernel

theorem selectedBound21580 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env21581 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3173,2089,2065,1,2083,0,2048,1025,0,3109,2081,2064,2,2089,64,2048,1,1124,2048,1057,2081,116,32,64,513]

theorem envBound21581 : H12AffineFastState.Bounded env21581 := by
  intro p hp
  have h : env21581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21580_21581 : H12AffineEnvironment.transform 11 3173 env21580 = env21581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3173 env21580 == env21581) = true)

theorem identity21581 : scanCanonicalize (H12AffineFastState.compose env21581 (packedSelected [6,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21581 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env21582 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3125,2089,2065,1,2083,0,2048,1025,0,3109,2081,2064,2,2089,16,2048,1,1076,2048,1057,2081,36,32,16,513]

theorem envBound21582 : H12AffineFastState.Bounded env21582 := by
  intro p hp
  have h : env21582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21581_21582 : H12AffineEnvironment.transform 5 16 env21581 = env21582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21581 == env21582) = true)

theorem identity21582 : scanCanonicalize (H12AffineFastState.compose env21582 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound21582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21583 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1061,16,1036,1076,1,1030,0,1061,1025,0,0,1028,1077,2,1036,16,1061,1,1076,1061,1057,1028,36,32,16,513]

theorem envBound21583 : H12AffineFastState.Bounded env21583 := by
  intro p hp
  have h : env21583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21582_21583 : H12AffineEnvironment.transform 10 1061 env21582 = env21583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env21582 == env21583) = true)

def env21584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272393,169216,21763,8193,64,2048,163841,45405,283904,156696,411973,257,21793,46092,156492]

theorem envBound21584 : H12AffineFastState.Bounded env21584 := by
  intro p hp
  have h : env21584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21573_21584 : H12AffineEnvironment.transform 6 9 env21573 = env21584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21573 == env21584) = true)

theorem identity21584 : scanCanonicalize (H12AffineFastState.compose env21584 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 16741) := by decide +kernel

theorem selectedBound21584 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env21585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16741,262144,1025,32769,12392,272393,54373,21763,8193,64,2048,49508,45405,283904,9597,264224,257,21793,46092,8745]

theorem envBound21585 : H12AffineFastState.Bounded env21585 := by
  intro p hp
  have h : env21585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21584_21585 : H12AffineEnvironment.transform 16 16741 env21584 = env21585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16741 env21584 == env21585) = true)

theorem identity21585 : scanCanonicalize (H12AffineFastState.compose env21585 (packedSelected [2,3,4,9,10,11,16,18,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound21585 : packedSelected [2,3,4,9,10,11,16,18,24,26] rootPS < 2^1333 := by decide +kernel

def env21586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,8202,16741,262144,1025,373,12392,272393,21777,21763,8193,64,2048,16400,12329,283904,9597,264224,257,21793,13688,8745]

theorem envBound21586 : H12AffineFastState.Bounded env21586 := by
  intro p hp
  have h : env21586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21585_21586 : H12AffineEnvironment.transform 14 372 env21585 = env21586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env21585 == env21586) = true)

theorem identity21586 : scanCanonicalize (H12AffineFastState.compose env21586 (packedSelected [6,9,16,17,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 23809) := by decide +kernel

theorem selectedBound21586 : packedSelected [6,9,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env21587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,8202,16741,23809,1025,373,12392,29960,21777,21763,8193,64,2048,16400,12329,2049,9597,21793,257,21793,13688,8745]

theorem envBound21587 : H12AffineFastState.Bounded env21587 := by
  intro p hp
  have h : env21587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21586_21587 : H12AffineEnvironment.transform 17 23809 env21586 = env21587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env21586 == env21587) = true)

theorem identity21587 : scanCanonicalize (H12AffineFastState.compose env21587 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21587 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env21588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,372,343,16741,23809,1025,373,4405,21589,21777,21763,348,64,2048,16400,4468,2049,1056,21793,257,21793,5157,884]

theorem envBound21588 : H12AffineFastState.Bounded env21588 := by
  intro p hp
  have h : env21588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21587_21588 : H12AffineEnvironment.transform 12 349 env21587 = env21588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21587 == env21588) = true)

theorem identity21588 : scanCanonicalize (H12AffineFastState.compose env21588 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound21588 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env21589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5237,372,343,5392,2420,1025,373,4405,32,356,374,348,64,2048,5221,4468,2049,1056,340,257,340,5157,884]

theorem envBound21589 : H12AffineFastState.Bounded env21589 := by
  intro p hp
  have h : env21589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21588_21589 : H12AffineEnvironment.transform 13 5237 env21588 = env21589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env21588 == env21589) = true)

theorem identity21589 : scanCanonicalize (H12AffineFastState.compose env21589 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21589 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21590 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,4112,372,343,4469,2420,100,373,4405,32,356,374,348,64,2048,4096,4468,2049,69,340,257,340,4160,884]

theorem envBound21590 : H12AffineFastState.Bounded env21590 := by
  intro p hp
  have h : env21590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21589_21590 : H12AffineEnvironment.transform 9 101 env21589 = env21590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21589 == env21590) = true)

theorem identity21590 : scanCanonicalize (H12AffineFastState.compose env21590 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound21590 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env21591 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,308,349,292,372,343,65,2420,100,373,1,32,356,374,348,64,2048,308,64,2049,69,340,257,340,372,884]

theorem envBound21591 : H12AffineFastState.Bounded env21591 := by
  intro p hp
  have h : env21591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21590_21591 : H12AffineEnvironment.transform 11 308 env21590 = env21591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env21590 == env21591) = true)

theorem identity21591 : scanCanonicalize (H12AffineFastState.compose env21591 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 46) := by decide +kernel

theorem selectedBound21591 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env21592 : List Nat := [2,4,8,16,32,64,9,256,512,101,46,308,349,292,372,343,65,346,100,373,1,32,356,374,348,64,46,308,64,47,69,340,257,340,372,884]

theorem envBound21592 : H12AffineFastState.Bounded env21592 := by
  intro p hp
  have h : env21592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21591_21592 : H12AffineEnvironment.transform 10 46 env21591 = env21592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 46 env21591 == env21592) = true)

theorem identity21592 : scanCanonicalize (H12AffineFastState.compose env21592 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 11) := by decide +kernel

theorem selectedBound21592 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env21593 : List Nat := [2,4,8,16,32,64,9,11,512,101,46,63,86,47,127,92,65,81,100,126,1,32,111,125,87,64,46,63,64,47,69,95,10,95,127,639]

theorem envBound21593 : H12AffineFastState.Bounded env21593 := by
  intro p hp
  have h : env21593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21592_21593 : H12AffineEnvironment.transform 7 11 env21592 = env21593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 11 env21592 == env21593) = true)

theorem identity21593 : scanCanonicalize (H12AffineFastState.compose env21593 (packedSelected [1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 62) := by decide +kernel

theorem selectedBound21593 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env21594 : List Nat := [2,4,8,16,32,62,9,11,512,27,46,63,40,47,1,34,63,47,26,0,1,32,17,3,41,62,46,63,62,47,59,33,10,33,1,513]

theorem envBound21594 : H12AffineFastState.Bounded env21594 := by
  intro p hp
  have h : env21594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21593_21594 : H12AffineEnvironment.transform 5 62 env21593 = env21594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 62 env21593 == env21594) = true)

theorem identity21594 : scanCanonicalize (H12AffineFastState.compose env21594 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound21594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21595 : List Nat := [2,4,8,16,5,27,9,11,512,27,11,26,13,10,1,7,26,10,26,0,1,5,17,3,12,27,11,26,27,10,30,4,10,4,1,513]

theorem envBound21595 : H12AffineFastState.Bounded env21595 := by
  intro p hp
  have h : env21595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21594_21595 : H12AffineEnvironment.transform 4 5 env21594 = env21595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env21594 == env21595) = true)

theorem identity21595 : scanCanonicalize (H12AffineFastState.compose env21595 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound21595 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21596 : List Nat := [2,2,8,16,3,27,9,11,512,27,11,26,11,10,1,1,26,10,26,0,1,3,17,3,10,27,11,26,27,10,24,2,10,2,1,513]

theorem envBound21596 : H12AffineFastState.Bounded env21596 := by
  intro p hp
  have h : env21596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21595_21596 : H12AffineEnvironment.transform 1 2 env21595 = env21596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env21595 == env21596) = true)

theorem identity21596 : scanCanonicalize (H12AffineFastState.compose env21596 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound21596 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21597 : List Nat := [2,2,8,10,3,1,9,11,512,1,11,0,11,10,1,1,0,10,0,0,1,3,11,3,10,1,11,0,1,10,2,2,10,2,1,513]

theorem envBound21597 : H12AffineFastState.Bounded env21597 := by
  intro p hp
  have h : env21597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21596_21597 : H12AffineEnvironment.transform 3 10 env21596 = env21597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env21596 == env21597) = true)

def env21598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272513,169353,95497,8328,64,2049,163976,45524,284041,156817,411972,257,21793,46213,213830]

theorem envBound21598 : H12AffineFastState.Bounded env21598 := by
  intro p hp
  have h : env21598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21571_21598 : H12AffineEnvironment.transform 21 272513 env21571 = env21598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21571 == env21598) = true)

theorem identity21598 : scanCanonicalize (H12AffineFastState.compose env21598 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112018) := by decide +kernel

theorem selectedBound21598 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,115871,272513,73755,95497,8328,64,2049,79130,45524,284041,119043,392406,257,21793,46213,63188]

theorem envBound21599 : H12AffineFastState.Bounded env21599 := by
  intro p hp
  have h : env21599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21598_21599 : H12AffineEnvironment.transform 16 112018 env21598 = env21599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112018 env21598 == env21599) = true)

def env21600 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,115871,272513,73755,95497,8328,16,2049,79130,45444,284041,119043,392326,257,21793,46213,63108]

theorem envBound21600 : H12AffineFastState.Bounded env21600 := by
  intro p hp
  have h : env21600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21599_21600 : H12AffineEnvironment.transform 5 16 env21599 = env21600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21599 == env21600) = true)

theorem identity21600 : scanCanonicalize (H12AffineFastState.compose env21600 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound21600 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env21601 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,76078,1025,32769,115871,65967,73755,95497,8328,16,2049,79130,45444,97447,119043,54696,257,21793,46213,63108]

theorem envBound21601 : H12AffineFastState.Bounded env21601 := by
  intro p hp
  have h : env21601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21600_21601 : H12AffineEnvironment.transform 17 76078 env21600 = env21601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env21600 == env21601) = true)

theorem identity21601 : scanCanonicalize (H12AffineFastState.compose env21601 (packedSelected [3,5,8,10,16,17,19,20,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound21601 : packedSelected [3,5,8,10,16,17,19,20,26,28,31] rootPS < 2^1333 := by decide +kernel

def env21602 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,65536,90259,76078,1025,21760,70046,65967,73755,95497,8328,16,2049,79130,25733,97447,66562,169,257,21793,24964,9093]

theorem envBound21602 : H12AffineFastState.Bounded env21602 := by
  intro p hp
  have h : env21602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21601_21602 : H12AffineEnvironment.transform 14 21761 env21601 = env21602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env21601 == env21602) = true)

theorem identity21602 : scanCanonicalize (H12AffineFastState.compose env21602 (packedSelected [0,4,7,16,17,19,20,22,26] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound21602 : packedSelected [0,4,7,16,17,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env21603 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21761,65536,82199,67754,1025,21760,70046,65967,65951,87181,268,16,2049,70814,17665,89379,66562,169,257,21793,16384,513]

theorem envBound21603 : H12AffineFastState.Bounded env21603 := by
  intro p hp
  have h : env21603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21602_21603 : H12AffineEnvironment.transform 12 388 env21602 = env21603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env21602 == env21603) = true)

theorem identity21603 : scanCanonicalize (H12AffineFastState.compose env21603 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21603 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21604 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,65536,82199,67618,1025,21760,69910,65831,65815,87045,268,16,2049,70678,17665,89379,66562,33,257,21793,16384,513]

theorem envBound21604 : H12AffineFastState.Bounded env21604 := by
  intro p hp
  have h : env21604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21603_21604 : H12AffineEnvironment.transform 6 8 env21603 = env21604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21603 == env21604) = true)

theorem identity21604 : scanCanonicalize (H12AffineFastState.compose env21604 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound21604 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21605 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,263,16400,2341,1025,21760,4113,32,16,21762,268,16,2049,5393,17665,23588,1285,33,257,21793,16384,513]

theorem envBound21605 : H12AffineFastState.Bounded env21605 := by
  intro p hp
  have h : env21605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21604_21605 : H12AffineEnvironment.transform 15 263 env21604 = env21605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env21604 == env21605) = true)

theorem identity21605 : scanCanonicalize (H12AffineFastState.compose env21605 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21605 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21606 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1025,0,4113,32,16,2,268,16,2049,5393,4097,2340,1285,33,257,33,5376,513]

theorem envBound21606 : H12AffineFastState.Bounded env21606 := by
  intro p hp
  have h : env21606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21605_21606 : H12AffineEnvironment.transform 13 5376 env21605 = env21606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21605 == env21606) = true)

theorem identity21606 : scanCanonicalize (H12AffineFastState.compose env21606 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21606 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21607 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,4405,1,263,4389,2341,52,0,4113,32,16,2,268,16,2049,4388,4097,2340,304,33,257,33,4405,513]

theorem envBound21607 : H12AffineFastState.Bounded env21607 := by
  intro p hp
  have h : env21607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21606_21607 : H12AffineEnvironment.transform 9 53 env21606 = env21607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21606 == env21607) = true)

def env21608 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,115871,272513,73755,95497,8328,17,2049,79130,45445,284041,119043,392327,257,21793,46213,63109]

theorem envBound21608 : H12AffineFastState.Bounded env21608 := by
  intro p hp
  have h : env21608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21599_21608 : H12AffineEnvironment.transform 5 17 env21599 = env21608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21599 == env21608) = true)

theorem identity21608 : scanCanonicalize (H12AffineFastState.compose env21608 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound21608 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env21609 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,64809,1025,32769,115871,54696,73755,95497,8328,17,2049,79130,45445,43168,119043,65966,257,21793,46213,63109]

theorem envBound21609 : H12AffineFastState.Bounded env21609 := by
  intro p hp
  have h : env21609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21608_21609 : H12AffineEnvironment.transform 17 64809 env21608 = env21609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env21608 == env21609) = true)

theorem identity21609 : scanCanonicalize (H12AffineFastState.compose env21609 (packedSelected [0,1,3,4,5,7,8,17,18,22,23,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21609 : packedSelected [0,1,3,4,5,7,8,17,18,22,23,26,31] rootPS < 2^1333 := by decide +kernel

def env21610 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,65536,112018,43048,1025,32769,102814,32937,73755,73736,8328,17,2049,79130,45445,43168,99330,65966,257,32,46213,41860]

theorem envBound21610 : H12AffineFastState.Bounded env21610 := by
  intro p hp
  have h : env21610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21609_21610 : H12AffineEnvironment.transform 13 5377 env21609 = env21610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21609 == env21610) = true)

theorem identity21610 : scanCanonicalize (H12AffineFastState.compose env21610 (packedSelected [1,3,5,8,10,16,20,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound21610 : packedSelected [1,3,5,8,10,16,20,26] rootPS < 2^1333 := by decide +kernel

def env21611 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8322,38160,43048,1025,32769,45340,32937,153,138,8328,17,2049,5528,45445,43168,42112,8492,257,32,46213,41860]

theorem envBound21611 : H12AffineFastState.Bounded env21611 := by
  intro p hp
  have h : env21611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21610_21611 : H12AffineEnvironment.transform 15 8322 env21610 = env21611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env21610 == env21611) = true)

theorem identity21611 : scanCanonicalize (H12AffineFastState.compose env21611 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21611 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env21612 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,32768,399,38160,35109,1025,32769,36881,32937,153,138,389,17,2049,5528,37000,35245,34189,33,257,32,38280,33417]

theorem envBound21612 : H12AffineFastState.Bounded env21612 := by
  intro p hp
  have h : env21612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21611_21612 : H12AffineEnvironment.transform 12 269 env21611 = env21612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21611 == env21612) = true)

theorem identity21612 : scanCanonicalize (H12AffineFastState.compose env21612 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound21612 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env21613 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,137,399,5529,2476,1025,136,4248,32,153,138,389,17,2049,5528,4097,2340,1284,33,257,32,5377,512]

theorem envBound21613 : H12AffineFastState.Bounded env21613 := by
  intro p hp
  have h : env21613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21612_21613 : H12AffineEnvironment.transform 14 137 env21612 = env21613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env21612 == env21613) = true)

theorem identity21613 : scanCanonicalize (H12AffineFastState.compose env21613 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound21613 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21614 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,269,5377,33,295,5425,2308,1025,32,4144,32,49,34,301,17,2049,5424,4097,2340,1284,33,257,32,5377,512]

theorem envBound21614 : H12AffineFastState.Bounded env21614 := by
  intro p hp
  have h : env21614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21613_21614 : H12AffineEnvironment.transform 6 40 env21613 = env21614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env21613 == env21614) = true)

theorem identity21614 : scanCanonicalize (H12AffineFastState.compose env21614 (packedSelected [0,1,2,3,5,7,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21614 : packedSelected [0,1,2,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env21615 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,5377,0,262,5392,2308,1025,1,4113,1,16,3,268,17,2049,5393,4097,2309,1284,0,257,1,5377,512]

theorem envBound21615 : H12AffineFastState.Bounded env21615 := by
  intro p hp
  have h : env21615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21614_21615 : H12AffineEnvironment.transform 4 1 env21614 = env21615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21614 == env21615) = true)

theorem identity21615 : scanCanonicalize (H12AffineFastState.compose env21615 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21615 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21616 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,9,5125,0,2,5140,2048,1025,1,4113,1,16,3,8,17,2049,5141,4097,2049,1024,0,5,1,5125,512]

theorem envBound21616 : H12AffineFastState.Bounded env21616 := by
  intro p hp
  have h : env21616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21615_21616 : H12AffineEnvironment.transform 7 4 env21615 = env21616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21615 == env21616) = true)

def env21617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254784,25265168,145662400,525568,140903596,27337992,25733063]

theorem envBound21617 : H12AffineFastState.Bounded env21617 := by
  intro p hp
  have h : env21617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20774_21617 : H12AffineEnvironment.transform 25 65 env20774 = env21617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env20774 == env21617) = true)

def env21618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356288,25265168,23160256,525568,27902124,27337992,25733063]

theorem envBound21618 : H12AffineFastState.Bounded env21618 := by
  intro p hp
  have h : env21618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21617_21618 : H12AffineEnvironment.transform 26 30393344 env21617 = env21618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env21617 == env21618) = true)

def env21619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265168,23160256,256,27378860,27337992,25207751]

theorem envBound21619 : H12AffineFastState.Bounded env21619 := by
  intro p hp
  have h : env21619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21618_21619 : H12AffineEnvironment.transform 18 1024 env21618 = env21619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env21618 == env21619) = true)

theorem identity21619 : scanCanonicalize (H12AffineFastState.compose env21619 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2534880) := by decide +kernel

theorem selectedBound21619 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534880,16777216,8328,65,23162336,18973837,456881,2125280,19343856,23160256,256,17262924,17271016,19271207]

theorem envBound21620 : H12AffineFastState.Bounded env21620 := by
  intro p hp
  have h : env21620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21619_21620 : H12AffineEnvironment.transform 22 2534880 env21619 = env21620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2534880 env21619 == env21620) = true)

def env21621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534880,474220,8328,65,6705548,2537697,456881,2125280,2102684,6707628,256,21792,46212,2175563]

theorem envBound21621 : H12AffineFastState.Bounded env21621 := by
  intro p hp
  have h : env21621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21620_21621 : H12AffineEnvironment.transform 23 474220 env21620 = env21621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474220 env21620 == env21621) = true)

def env21622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,2097152,4194304,2101328,98780,8328,65,6351932,2098513,17665,2125280,2102684,6349852,256,21792,46212,2175563]

theorem envBound21622 : H12AffineFastState.Bounded env21622 := by
  intro p hp
  have h : env21622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21621_21622 : H12AffineEnvironment.transform 17 179632 env21621 = env21622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env21621 == env21622) = true)

def env21623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,4194304,16,98780,8328,65,4258940,5393,17665,32160,1500,4256860,256,21792,46212,74251]

theorem envBound21623 : H12AffineFastState.Bounded env21623 := by
  intro p hp
  have h : env21623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21622_21623 : H12AffineEnvironment.transform 20 4160 env21622 = env21623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21622 == env21623) = true)

theorem identity21623 : scanCanonicalize (H12AffineFastState.compose env21623 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21623 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179632,1024,32769,4160,4194304,16,41430,8328,65,4258940,5393,17665,32160,1500,4256860,256,21792,46212,513]

theorem envBound21624 : H12AffineFastState.Bounded env21624 := by
  intro p hp
  have h : env21624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21623_21624 : H12AffineEnvironment.transform 15 8202 env21623 = env21624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21623 == env21624) = true)

theorem identity21624 : scanCanonicalize (H12AffineFastState.compose env21624 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 169265) := by decide +kernel

theorem selectedBound21624 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env21625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179632,1024,32769,4160,169265,16,41430,8328,65,158029,5393,17665,32160,1500,156013,256,21792,46212,513]

theorem envBound21625 : H12AffineFastState.Bounded env21625 := by
  intro p hp
  have h : env21625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21624_21625 : H12AffineEnvironment.transform 21 169265 env21624 = env21625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env21624 == env21625) = true)

theorem identity21625 : scanCanonicalize (H12AffineFastState.compose env21625 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21625 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env21626 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4160,169265,16,41310,8192,65,158029,5393,17665,32040,1364,156013,256,21792,46092,513]

theorem envBound21626 : H12AffineFastState.Bounded env21626 := by
  intro p hp
  have h : env21626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21625_21626 : H12AffineEnvironment.transform 6 8 env21625 = env21626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21625 == env21626) = true)

theorem identity21626 : scanCanonicalize (H12AffineFastState.compose env21626 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound21626 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10280,1024,32769,4160,33,16,41310,8192,65,64605,5393,17665,32040,1364,62589,256,21792,46092,513]

theorem envBound21627 : H12AffineFastState.Bounded env21627 := by
  intro p hp
  have h : env21627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21626_21627 : H12AffineEnvironment.transform 16 38160 env21626 = env21627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env21626 == env21627) = true)

theorem identity21627 : scanCanonicalize (H12AffineFastState.compose env21627 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21627 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,5392,10280,1024,1,4160,33,16,8542,8192,65,31837,5393,17665,32040,1364,29821,256,21792,13324,513]

theorem envBound21628 : H12AffineFastState.Bounded env21628 := by
  intro p hp
  have h : env21628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21627_21628 : H12AffineEnvironment.transform 14 0 env21627 = env21628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21627 == env21628) = true)

theorem identity21628 : scanCanonicalize (H12AffineFastState.compose env21628 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound21628 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,5392,10280,1024,1,4160,33,16,8542,8192,65,2048,5393,12636,2421,1364,32,256,8573,13324,513]

theorem envBound21629 : H12AffineFastState.Bounded env21629 := by
  intro p hp
  have h : env21629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21628_21629 : H12AffineEnvironment.transform 13 13405 env21628 = env21629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env21628 == env21629) = true)

theorem identity21629 : scanCanonicalize (H12AffineFastState.compose env21629 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21629 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env21630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5392,2421,1024,1,4160,33,16,3,349,65,2048,5393,4097,2421,1364,32,256,32,5457,513]

theorem envBound21630 : H12AffineFastState.Bounded env21630 := by
  intro p hp
  have h : env21630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21629_21630 : H12AffineEnvironment.transform 12 349 env21629 = env21630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21629 == env21630) = true)

theorem identity21630 : scanCanonicalize (H12AffineFastState.compose env21630 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound21630 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21631 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4112,0,343,4096,2421,272,1,4160,33,16,3,349,65,2048,4097,4097,2421,68,32,256,32,4161,513]

theorem envBound21631 : H12AffineFastState.Bounded env21631 := by
  intro p hp
  have h : env21631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21630_21631 : H12AffineEnvironment.transform 9 272 env21630 = env21631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21630 == env21631) = true)

theorem identity21631 : scanCanonicalize (H12AffineFastState.compose env21631 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound21631 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21632 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,49,349,33,0,343,49,2421,272,1,113,33,16,3,349,65,2048,48,48,2421,68,32,256,32,112,513]

theorem envBound21632 : H12AffineFastState.Bounded env21632 := by
  intro p hp
  have h : env21632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21631_21632 : H12AffineEnvironment.transform 11 49 env21631 = env21632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env21631 == env21632) = true)

theorem identity21632 : scanCanonicalize (H12AffineFastState.compose env21632 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21632 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21633 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,49,40,33,0,34,49,2048,101,1,113,33,16,3,40,65,2048,48,48,2048,68,32,117,32,112,513]

theorem envBound21633 : H12AffineFastState.Bounded env21633 := by
  intro p hp
  have h : env21633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21632_21633 : H12AffineEnvironment.transform 7 117 env21632 = env21633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21632 == env21633) = true)

theorem identity21633 : scanCanonicalize (H12AffineFastState.compose env21633 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound21633 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21634 : List Nat := [2,4,8,16,32,64,8,117,512,101,513,49,40,33,0,34,49,513,101,1,113,33,16,3,40,65,513,48,48,513,68,32,117,32,112,513]

theorem envBound21634 : H12AffineFastState.Bounded env21634 := by
  intro p hp
  have h : env21634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21633_21634 : H12AffineEnvironment.transform 10 513 env21633 = env21634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env21633 == env21634) = true)

def env21635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,4194304,17,98780,8328,65,4258941,5392,17665,32161,1501,4256861,256,21792,46212,74250]

theorem envBound21635 : H12AffineFastState.Bounded env21635 := by
  intro p hp
  have h : env21635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21622_21635 : H12AffineEnvironment.transform 20 4161 env21622 = env21635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21622 == env21635) = true)

theorem identity21635 : scanCanonicalize (H12AffineFastState.compose env21635 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243002) := by decide +kernel

theorem selectedBound21635 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,243002,17,98780,8328,65,215367,5392,17665,32161,1501,213351,256,21792,46212,74250]

theorem envBound21636 : H12AffineFastState.Bounded env21636 := by
  intro p hp
  have h : env21636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21635_21636 : H12AffineEnvironment.transform 21 243002 env21635 = env21636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243002 env21635 == env21636) = true)

def env21637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,243002,17,98644,8192,65,215367,5392,17665,32041,1365,213351,256,21792,46092,74250]

theorem envBound21637 : H12AffineFastState.Bounded env21637 := by
  intro p hp
  have h : env21637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21636_21637 : H12AffineEnvironment.transform 6 8 env21636 = env21637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21636 == env21637) = true)

theorem identity21637 : scanCanonicalize (H12AffineFastState.compose env21637 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21637 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4161,169265,17,41311,8192,65,158028,5392,17665,32041,1365,156012,256,21792,46092,513]

theorem envBound21638 : H12AffineFastState.Bounded env21638 := by
  intro p hp
  have h : env21638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21637_21638 : H12AffineEnvironment.transform 15 8203 env21637 = env21638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21637 == env21638) = true)

theorem identity21638 : scanCanonicalize (H12AffineFastState.compose env21638 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound21638 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64809,1024,32769,4161,54560,17,41311,8192,65,10589,5392,17665,32041,1365,8573,256,21792,46092,513]

theorem envBound21639 : H12AffineFastState.Bounded env21639 := by
  intro p hp
  have h : env21639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21638_21639 : H12AffineEnvironment.transform 16 16401 env21638 = env21639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env21638 == env21639) = true)

theorem identity21639 : scanCanonicalize (H12AffineFastState.compose env21639 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21639 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,23669,1024,8541,4161,29820,17,3,8192,65,10589,5392,17665,32041,1365,8573,256,21792,5456,513]

theorem envBound21640 : H12AffineFastState.Bounded env21640 := by
  intro p hp
  have h : env21640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21639_21640 : H12AffineEnvironment.transform 14 8540 env21639 = env21640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21639 == env21640) = true)

theorem identity21640 : scanCanonicalize (H12AffineFastState.compose env21640 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound21640 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8540,8203,13673,10509,1024,8541,4161,260,17,3,8192,65,10589,5392,12409,2129,1365,8573,256,8280,5456,513]

theorem envBound21641 : H12AffineFastState.Bounded env21641 := by
  intro p hp
  have h : env21641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21640_21641 : H12AffineEnvironment.transform 13 13688 env21640 = env21641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env21640 == env21641) = true)

theorem identity21641 : scanCanonicalize (H12AffineFastState.compose env21641 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound21641 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21642 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,12344,8540,8203,12329,10509,320,8541,4161,260,17,3,8192,65,10589,4176,12409,2129,21,8573,256,8280,4112,513]

theorem envBound21642 : H12AffineFastState.Bounded env21642 := by
  intro p hp
  have h : env21642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21641_21642 : H12AffineEnvironment.transform 9 320 env21641 = env21642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env21641 == env21642) = true)

theorem identity21642 : scanCanonicalize (H12AffineFastState.compose env21642 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound21642 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21643 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,4153,1,4453,4146,16,6452,320,4452,4161,260,17,3,4153,65,6500,4176,64,2129,21,4420,256,4193,4112,513]

theorem envBound21643 : H12AffineFastState.Bounded env21643 := by
  intro p hp
  have h : env21643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21642_21643 : H12AffineEnvironment.transform 12 4153 env21642 = env21643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env21642 == env21643) = true)

theorem identity21643 : scanCanonicalize (H12AffineFastState.compose env21643 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound21643 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env21644 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,4096,4153,1,4453,4146,16,4452,320,4452,4161,260,17,3,4153,65,4404,4176,64,1,21,4420,256,4193,4112,513]

theorem envBound21644 : H12AffineFastState.Bounded env21644 := by
  intro p hp
  have h : env21644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21643_21644 : H12AffineEnvironment.transform 10 80 env21643 = env21644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env21643 == env21644) = true)

theorem identity21644 : scanCanonicalize (H12AffineFastState.compose env21644 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21644 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21645 : List Nat := [2,4,8,16,32,64,8,36,512,100,80,4096,4153,1,4161,4146,16,4160,100,4160,4161,32,17,3,4153,65,4112,4176,64,1,21,4192,36,4193,4112,513]

theorem envBound21645 : H12AffineFastState.Bounded env21645 := by
  intro p hp
  have h : env21645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21644_21645 : H12AffineEnvironment.transform 7 36 env21644 = env21645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21644 == env21645) = true)

theorem identity21645 : scanCanonicalize (H12AffineFastState.compose env21645 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound21645 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env21646 : List Nat := [2,4,8,16,32,64,8,36,512,100,80,65,120,1,0,115,16,1,100,1,0,32,17,3,120,65,81,17,64,1,21,33,36,32,81,513]

theorem envBound21646 : H12AffineFastState.Bounded env21646 := by
  intro p hp
  have h : env21646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21645_21646 : H12AffineEnvironment.transform 11 65 env21645 = env21646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env21645 == env21646) = true)

theorem identity21646 : scanCanonicalize (H12AffineFastState.compose env21646 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21646 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21647 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,16,41,1,0,34,16,1,53,1,0,32,17,3,41,16,0,17,17,1,21,33,36,32,0,513]

theorem envBound21647 : H12AffineFastState.Bounded env21647 := by
  intro p hp
  have h : env21647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21646_21647 : H12AffineEnvironment.transform 5 17 env21646 = env21647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21646 == env21647) = true)

theorem identity21647 : scanCanonicalize (H12AffineFastState.compose env21647 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound21647 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21648 : List Nat := [2,4,8,16,32,17,8,36,16,53,1,16,41,1,0,34,16,1,53,1,0,32,17,3,41,16,0,17,17,1,21,33,36,32,0,17]

theorem envBound21648 : H12AffineFastState.Bounded env21648 := by
  intro p hp
  have h : env21648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21647_21648 : H12AffineEnvironment.transform 8 16 env21647 = env21648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env21647 == env21648) = true)

theorem identity21648 : scanCanonicalize (H12AffineFastState.compose env21648 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21648 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21649 : List Nat := [2,4,3,16,32,17,3,36,16,53,1,16,34,1,0,34,16,1,53,1,0,32,17,3,34,16,0,17,17,1,21,33,36,32,0,17]

theorem envBound21649 : H12AffineFastState.Bounded env21649 := by
  intro p hp
  have h : env21649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21648_21649 : H12AffineEnvironment.transform 2 3 env21648 = env21649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21648 == env21649) = true)

def env21650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,243002,17,98645,8193,65,215367,5392,17665,32040,1364,213351,256,21792,46093,74250]

theorem envBound21650 : H12AffineFastState.Bounded env21650 := by
  intro p hp
  have h : env21650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21636_21650 : H12AffineEnvironment.transform 6 9 env21636 = env21650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21636 == env21650) = true)

theorem identity21650 : scanCanonicalize (H12AffineFastState.compose env21650 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound21650 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,179513,1024,32769,4161,144492,17,3,8193,65,182289,5392,17665,32040,1364,180273,256,21792,46093,41820]

theorem envBound21651 : H12AffineFastState.Bounded env21651 := by
  intro p hp
  have h : env21651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21650_21651 : H12AffineEnvironment.transform 15 33110 env21650 = env21651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env21650 == env21651) = true)

theorem identity21651 : scanCanonicalize (H12AffineFastState.compose env21651 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound21651 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,5393,43048,1024,32769,4161,8573,17,3,8193,65,56576,5392,17665,32040,1364,54560,256,21792,46093,41820]

theorem envBound21652 : H12AffineFastState.Bounded env21652 := by
  intro p hp
  have h : env21652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21651_21652 : H12AffineEnvironment.transform 16 5393 env21651 = env21652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env21651 == env21652) = true)

theorem identity21652 : scanCanonicalize (H12AffineFastState.compose env21652 (packedSelected [0,1,3,5,6,8,10,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound21652 : packedSelected [0,1,3,5,6,8,10,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env21653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,33110,5393,43048,1024,32769,4161,8573,17,3,8193,65,35189,5392,4468,10589,1364,33109,256,341,46093,41820]

theorem envBound21653 : H12AffineFastState.Bounded env21653 := by
  intro p hp
  have h : env21653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21652_21653 : H12AffineEnvironment.transform 13 5237 env21652 = env21653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env21652 == env21653) = true)

theorem identity21653 : scanCanonicalize (H12AffineFastState.compose env21653 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21653 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env21654 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,32802,5221,43048,1024,32769,4161,8201,17,3,8193,65,34817,5220,4096,10281,1056,32801,116,33,46093,41512]

theorem envBound21654 : H12AffineFastState.Bounded env21654 := by
  intro p hp
  have h : env21654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21653_21654 : H12AffineEnvironment.transform 7 116 env21653 = env21654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21653 == env21654) = true)

theorem identity21654 : scanCanonicalize (H12AffineFastState.compose env21654 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21654 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env21655 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,0,34,5221,10280,1024,1,4161,8201,17,3,8193,65,2049,5220,4096,10281,1056,33,116,33,13325,8744]

theorem envBound21655 : H12AffineFastState.Bounded env21655 := by
  intro p hp
  have h : env21655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21654_21655 : H12AffineEnvironment.transform 14 0 env21654 = env21655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21654 == env21655) = true)

theorem identity21655 : scanCanonicalize (H12AffineFastState.compose env21655 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound21655 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21656 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,0,34,5221,2049,1024,1,4161,32,17,3,40,65,2049,5220,4096,2048,1056,33,116,33,5156,513]

theorem envBound21656 : H12AffineFastState.Bounded env21656 := by
  intro p hp
  have h : env21656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21655_21656 : H12AffineEnvironment.transform 12 41 env21655 = env21656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21655 == env21656) = true)

theorem identity21656 : scanCanonicalize (H12AffineFastState.compose env21656 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound21656 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21657 : List Nat := [2,4,8,16,32,64,9,116,512,1024,90,4096,41,5237,0,34,5221,91,1024,1,4161,32,17,3,40,65,91,5220,4096,90,1056,33,116,33,5156,513]

theorem envBound21657 : H12AffineFastState.Bounded env21657 := by
  intro p hp
  have h : env21657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21656_21657 : H12AffineEnvironment.transform 10 90 env21656 = env21657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env21656 == env21657) = true)

def env21658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,2097152,4194304,2101329,98781,8328,65,6351933,2098512,17664,2125280,2102684,6349853,256,21792,46212,2175563]

theorem envBound21658 : H12AffineFastState.Bounded env21658 := by
  intro p hp
  have h : env21658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21621_21658 : H12AffineEnvironment.transform 17 179633 env21621 = env21658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env21621 == env21658) = true)

def env21659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,4194304,17,98781,8328,65,4258941,5392,17664,32160,1500,4256861,256,21792,46212,74251]

theorem envBound21659 : H12AffineFastState.Bounded env21659 := by
  intro p hp
  have h : env21659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21658_21659 : H12AffineEnvironment.transform 20 4160 env21658 = env21659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21658 == env21659) = true)

theorem identity21659 : scanCanonicalize (H12AffineFastState.compose env21659 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213486) := by decide +kernel

theorem selectedBound21659 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,213486,17,98781,8328,65,245139,5392,17664,32160,1500,243123,256,21792,46212,74251]

theorem envBound21660 : H12AffineFastState.Bounded env21660 := by
  intro p hp
  have h : env21660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21659_21660 : H12AffineEnvironment.transform 21 213486 env21659 = env21660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213486 env21659 == env21660) = true)

def env21661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,213350,17,98645,8192,65,245019,5392,17664,32040,1364,243003,256,21792,46092,74251]

theorem envBound21661 : H12AffineFastState.Bounded env21661 := by
  intro p hp
  have h : env21661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21660_21661 : H12AffineEnvironment.transform 6 8 env21660 = env21661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21660 == env21661) = true)

theorem identity21661 : scanCanonicalize (H12AffineFastState.compose env21661 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21661 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4160,156012,17,41311,8192,65,171281,5392,17664,32040,1364,169265,256,21792,46092,513]

theorem envBound21662 : H12AffineFastState.Bounded env21662 := by
  intro p hp
  have h : env21662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21661_21662 : H12AffineEnvironment.transform 15 8202 env21661 = env21662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21661 == env21662) = true)

theorem identity21662 : scanCanonicalize (H12AffineFastState.compose env21662 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound21662 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,64809,1024,32769,4160,8572,17,41311,8192,65,56577,5392,17664,32040,1364,54561,256,21792,46092,513]

theorem envBound21663 : H12AffineFastState.Bounded env21663 := by
  intro p hp
  have h : env21663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21662_21663 : H12AffineEnvironment.transform 16 16400 env21662 = env21663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env21662 == env21663) = true)

theorem identity21663 : scanCanonicalize (H12AffineFastState.compose env21663 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21663 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,23668,1024,8540,4160,8572,17,2,8192,65,31836,5392,17664,32040,1364,29820,256,21792,5457,513]

theorem envBound21664 : H12AffineFastState.Bounded env21664 := by
  intro p hp
  have h : env21664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21663_21664 : H12AffineEnvironment.transform 14 8541 env21663 = env21664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21663 == env21664) = true)

theorem identity21664 : scanCanonicalize (H12AffineFastState.compose env21664 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound21664 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,8202,13341,10361,1024,8540,4160,8572,17,2,8192,65,2129,5392,12557,2341,1364,113,256,8493,5457,513]

theorem envBound21665 : H12AffineFastState.Bounded env21665 := by
  intro p hp
  have h : env21665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21664_21665 : H12AffineEnvironment.transform 13 13325 env21664 = env21665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env21664 == env21665) = true)

theorem identity21665 : scanCanonicalize (H12AffineFastState.compose env21665 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21665 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,262,5393,2421,1024,80,4160,112,17,2,268,65,2129,5392,4097,2341,1364,113,256,33,5457,513]

theorem envBound21666 : H12AffineFastState.Bounded env21666 := by
  intro p hp
  have h : env21666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21665_21666 : H12AffineEnvironment.transform 12 268 env21665 = env21666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21665 == env21666) = true)

theorem identity21666 : scanCanonicalize (H12AffineFastState.compose env21666 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1888) := by decide +kernel

theorem selectedBound21666 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21667 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1888,268,609,81,262,625,2421,1024,80,1824,112,17,2,268,65,2129,624,1889,2341,1364,113,256,33,561,513]

theorem envBound21667 : H12AffineFastState.Bounded env21667 := by
  intro p hp
  have h : env21667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21666_21667 : H12AffineEnvironment.transform 11 1888 env21666 = env21667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1888 env21666 == env21667) = true)

theorem identity21667 : scanCanonicalize (H12AffineFastState.compose env21667 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21667 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21668 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1840,268,561,1,262,545,2341,1024,0,1824,32,17,2,268,17,2049,544,1841,2341,1284,33,256,33,561,513]

theorem envBound21668 : H12AffineFastState.Bounded env21668 := by
  intro p hp
  have h : env21668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21667_21668 : H12AffineEnvironment.transform 5 16 env21667 = env21668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21667 == env21668) = true)

theorem identity21668 : scanCanonicalize (H12AffineFastState.compose env21668 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound21668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21669 : List Nat := [2,4,8,16,32,16,8,21,512,1024,2048,1573,25,561,1,19,545,2096,1024,0,1589,32,17,2,25,17,2049,544,1572,2096,1041,33,21,33,561,513]

theorem envBound21669 : H12AffineFastState.Bounded env21669 := by
  intro p hp
  have h : env21669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21668_21669 : H12AffineEnvironment.transform 7 21 env21668 = env21669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env21668 == env21669) = true)

theorem identity21669 : scanCanonicalize (H12AffineFastState.compose env21669 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound21669 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21670 : List Nat := [2,4,8,16,32,16,8,21,48,1024,2048,1045,25,1,1,19,17,2096,1024,0,1029,32,17,2,25,17,2049,16,1044,2096,1041,33,21,33,1,49]

theorem envBound21670 : H12AffineFastState.Bounded env21670 := by
  intro p hp
  have h : env21670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21669_21670 : H12AffineEnvironment.transform 8 48 env21669 = env21670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env21669 == env21670) = true)

theorem identity21670 : scanCanonicalize (H12AffineFastState.compose env21670 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound21670 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21671 : List Nat := [2,4,8,16,32,16,8,21,48,1024,17,1045,25,1,1,19,17,33,1024,0,1029,32,17,2,25,17,16,16,1044,33,1041,33,21,33,1,49]

theorem envBound21671 : H12AffineFastState.Bounded env21671 := by
  intro p hp
  have h : env21671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21670_21671 : H12AffineEnvironment.transform 10 17 env21670 = env21671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env21670 == env21671) = true)

theorem identity21671 : scanCanonicalize (H12AffineFastState.compose env21671 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21671 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env21672 : List Nat := [2,4,8,16,32,16,8,21,48,21,17,0,25,1,1,19,17,33,21,0,16,32,17,2,25,17,16,16,1,33,4,33,21,33,1,49]

theorem envBound21672 : H12AffineFastState.Bounded env21672 := by
  intro p hp
  have h : env21672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21671_21672 : H12AffineEnvironment.transform 9 21 env21671 = env21672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21671 == env21672) = true)

theorem identity21672 : scanCanonicalize (H12AffineFastState.compose env21672 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21672 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env21673 : List Nat := [2,4,8,16,1,16,8,21,17,21,17,0,25,1,1,19,17,0,21,0,16,1,17,2,25,17,16,16,1,0,4,0,21,0,1,16]

theorem envBound21673 : H12AffineFastState.Bounded env21673 := by
  intro p hp
  have h : env21673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21672_21673 : H12AffineEnvironment.transform 4 1 env21672 = env21673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21672 == env21673) = true)

theorem identity21673 : scanCanonicalize (H12AffineFastState.compose env21673 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21673 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21674 : List Nat := [2,4,8,0,1,0,8,5,1,5,1,0,9,1,1,3,1,0,5,0,0,1,1,2,9,1,0,0,1,0,4,0,5,0,1,0]

theorem envBound21674 : H12AffineFastState.Bounded env21674 := by
  intro p hp
  have h : env21674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21673_21674 : H12AffineEnvironment.transform 3 0 env21673 = env21674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21673 == env21674) = true)

def env21675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,213351,17,98644,8193,65,245018,5392,17664,32041,1365,243002,256,21792,46093,74251]

theorem envBound21675 : H12AffineFastState.Bounded env21675 := by
  intro p hp
  have h : env21675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21660_21675 : H12AffineEnvironment.transform 6 9 env21660 = env21675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21660 == env21675) = true)

theorem identity21675 : scanCanonicalize (H12AffineFastState.compose env21675 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound21675 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,179512,1024,32769,4160,180272,17,3,8193,65,146509,5392,17664,32041,1365,144493,256,21792,46093,41820]

theorem envBound21676 : H12AffineFastState.Bounded env21676 := by
  intro p hp
  have h : env21676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21675_21676 : H12AffineEnvironment.transform 15 33111 env21675 = env21676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env21675 == env21676) = true)

theorem identity21676 : scanCanonicalize (H12AffineFastState.compose env21676 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound21676 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env21677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16449,64889,1024,32769,4160,32881,17,3,8193,65,31756,5392,17664,32041,1365,29740,256,21792,46093,41820]

theorem envBound21677 : H12AffineFastState.Bounded env21677 := by
  intro p hp
  have h : env21677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21676_21677 : H12AffineEnvironment.transform 16 16449 env21676 = env21677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env21676 == env21677) = true)

theorem identity21677 : scanCanonicalize (H12AffineFastState.compose env21677 (packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound21677 : packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env21678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,292,115,16449,31837,1024,293,4160,341,17,3,8193,65,31756,5392,17664,32041,1365,29740,256,21792,13609,8824]

theorem envBound21678 : H12AffineFastState.Bounded env21678 := by
  intro p hp
  have h : env21678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21677_21678 : H12AffineEnvironment.transform 14 292 env21677 = env21678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env21677 == env21678) = true)

theorem identity21678 : scanCanonicalize (H12AffineFastState.compose env21678 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound21678 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env21679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,292,115,16449,23589,1024,293,4160,341,17,3,121,65,23668,5392,17664,23889,1365,21588,256,21792,5457,512]

theorem envBound21679 : H12AffineFastState.Bounded env21679 := by
  intro p hp
  have h : env21679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21678_21679 : H12AffineEnvironment.transform 12 120 env21678 = env21679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env21678 == env21679) = true)

theorem identity21679 : scanCanonicalize (H12AffineFastState.compose env21679 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound21679 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21680 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,292,115,5172,2128,1024,293,4160,341,17,3,121,65,2049,5392,4469,2340,1365,33,256,341,5457,512]

theorem envBound21680 : H12AffineFastState.Bounded env21680 := by
  intro p hp
  have h : env21680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21679_21680 : H12AffineEnvironment.transform 13 5237 env21679 = env21680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env21679 == env21680) = true)

theorem identity21680 : scanCanonicalize (H12AffineFastState.compose env21680 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound21680 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21681 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,9,5124,292,2,5172,2081,1024,293,4145,292,17,3,8,48,2049,5392,4356,2340,1316,33,256,292,5408,512]

theorem envBound21681 : H12AffineFastState.Bounded env21681 := by
  intro p hp
  have h : env21681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21680_21681 : H12AffineEnvironment.transform 5 49 env21680 = env21681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env21680 == env21681) = true)

theorem identity21681 : scanCanonicalize (H12AffineFastState.compose env21681 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21681 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21682 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,9,5124,0,2,5172,2081,1024,1,4145,0,17,3,8,48,2049,5172,4128,2048,1024,33,36,0,5124,512]

theorem envBound21682 : H12AffineFastState.Bounded env21682 := by
  intro p hp
  have h : env21682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21681_21682 : H12AffineEnvironment.transform 7 36 env21681 = env21682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21681 == env21682) = true)

theorem identity21682 : scanCanonicalize (H12AffineFastState.compose env21682 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21682 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21683 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,0,2,5140,2049,1024,1,4113,0,17,3,8,16,2049,5140,4096,2048,1024,1,4,0,5124,512]

theorem envBound21683 : H12AffineFastState.Bounded env21683 := by
  intro p hp
  have h : env21683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21682_21683 : H12AffineEnvironment.transform 4 0 env21682 = env21683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21682 == env21683) = true)

def env21684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,4194304,16,98781,8328,65,4258940,5393,17664,32161,1501,4256860,256,21792,46212,74250]

theorem envBound21684 : H12AffineFastState.Bounded env21684 := by
  intro p hp
  have h : env21684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21658_21684 : H12AffineEnvironment.transform 20 4161 env21658 = env21684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21658 == env21684) = true)

theorem identity21684 : scanCanonicalize (H12AffineFastState.compose env21684 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound21684 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179633,1024,32769,4161,4194304,16,21762,8328,65,4258940,5393,17664,32161,1501,4256860,256,21792,46212,63189]

theorem envBound21685 : H12AffineFastState.Bounded env21685 := by
  intro p hp
  have h : env21685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21684_21685 : H12AffineEnvironment.transform 15 54495 env21684 = env21685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env21684 == env21685) = true)

def env21686 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4161,4194304,16,21762,8192,65,4258940,5393,17664,32041,1365,4256860,256,21792,46092,63069]

theorem envBound21686 : H12AffineFastState.Bounded env21686 := by
  intro p hp
  have h : env21686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21685_21686 : H12AffineEnvironment.transform 6 8 env21685 = env21686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21685 == env21686) = true)

theorem identity21686 : scanCanonicalize (H12AffineFastState.compose env21686 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound21686 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24909,56436,1024,32769,4161,4194304,16,21762,8192,65,4258940,5393,17664,32041,1365,4256860,256,21792,46092,63069]

theorem envBound21687 : H12AffineFastState.Bounded env21687 := by
  intro p hp
  have h : env21687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21686_21687 : H12AffineEnvironment.transform 16 24909 env21686 = env21687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env21686 == env21687) = true)

theorem identity21687 : scanCanonicalize (H12AffineFastState.compose env21687 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound21687 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env21688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,24909,10280,1024,29789,4161,4194304,16,21762,8192,65,4196384,5393,17664,32041,1365,4194304,256,21792,16464,513]

theorem envBound21688 : H12AffineFastState.Bounded env21688 := by
  intro p hp
  have h : env21688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21687_21688 : H12AffineEnvironment.transform 14 29788 env21687 = env21688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env21687 == env21688) = true)

theorem identity21688 : scanCanonicalize (H12AffineFastState.compose env21688 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound21688 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,24909,10280,1024,29789,4161,8493,16,21762,8192,65,10509,5393,17664,32041,1365,8493,256,21792,16464,513]

theorem envBound21689 : H12AffineFastState.Bounded env21689 := by
  intro p hp
  have h : env21689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21688_21689 : H12AffineEnvironment.transform 21 8493 env21688 = env21689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env21688 == env21689) = true)

def env21690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4161,4194304,16,21762,8193,65,4258940,5393,17664,32040,1364,4256860,256,21792,46093,63068]

theorem envBound21690 : H12AffineFastState.Bounded env21690 := by
  intro p hp
  have h : env21690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21685_21690 : H12AffineEnvironment.transform 6 9 env21685 = env21690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21685 == env21690) = true)

theorem identity21690 : scanCanonicalize (H12AffineFastState.compose env21690 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound21690 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49169,32041,1024,32769,4161,4194304,16,21762,8193,65,4258940,5393,17664,32040,1364,4256860,256,21792,46093,63068]

theorem envBound21691 : H12AffineFastState.Bounded env21691 := by
  intro p hp
  have h : env21691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21690_21691 : H12AffineEnvironment.transform 16 49169 env21690 = env21691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env21690 == env21691) = true)

theorem identity21691 : scanCanonicalize (H12AffineFastState.compose env21691 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21691 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env21692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54358,49169,23668,1024,32769,4161,4194304,16,21762,348,65,4250913,5393,17664,23669,1364,4248833,256,21792,38224,55041]

theorem envBound21692 : H12AffineFastState.Bounded env21692 := by
  intro p hp
  have h : env21692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21691_21692 : H12AffineEnvironment.transform 12 349 env21691 = env21692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21691 == env21692) = true)

theorem identity21692 : scanCanonicalize (H12AffineFastState.compose env21692 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound21692 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54358,49169,23668,1024,32769,4161,33,16,21762,348,65,56576,5393,17664,23669,1364,54560,256,21792,38224,55041]

theorem envBound21693 : H12AffineFastState.Bounded env21693 := by
  intro p hp
  have h : env21693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21692_21693 : H12AffineEnvironment.transform 21 33 env21692 = env21693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env21692 == env21693) = true)

theorem identity21693 : scanCanonicalize (H12AffineFastState.compose env21693 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21693 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,32768,33110,38161,2420,1024,32769,4161,33,16,2,348,65,34816,5393,4096,2421,1364,32800,256,32,38224,33281]

theorem envBound21694 : H12AffineFastState.Bounded env21694 := by
  intro p hp
  have h : env21694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21693_21694 : H12AffineEnvironment.transform 13 5376 env21693 = env21694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21693 == env21694) = true)

theorem identity21694 : scanCanonicalize (H12AffineFastState.compose env21694 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21694 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1297,1095,4096,2420,1024,1296,4161,33,16,2,348,65,3345,5393,4096,2421,1364,1329,256,32,4161,1808]

theorem envBound21695 : H12AffineFastState.Bounded env21695 := by
  intro p hp
  have h : env21695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21694_21695 : H12AffineEnvironment.transform 14 1297 env21694 = env21695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env21694 == env21695) = true)

theorem identity21695 : scanCanonicalize (H12AffineFastState.compose env21695 (packedSelected [4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 357) := by decide +kernel

theorem selectedBound21695 : packedSelected [4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env21696 : List Nat := [2,4,8,16,32,64,9,256,512,1024,357,4096,349,5376,1297,1095,4096,17,1024,1296,4161,33,16,2,348,65,1140,5393,4096,16,1364,1329,256,32,4161,1808]

theorem envBound21696 : H12AffineFastState.Bounded env21696 := by
  intro p hp
  have h : env21696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21695_21696 : H12AffineEnvironment.transform 10 357 env21695 = env21696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 357 env21695 == env21696) = true)

theorem identity21696 : scanCanonicalize (H12AffineFastState.compose env21696 (packedSelected [0,1,3,5,6,7,8,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound21696 : packedSelected [0,1,3,5,6,7,8,12,14] rootPS < 2^1333 := by decide +kernel

def env21697 : List Nat := [2,4,8,16,32,64,9,256,512,256,357,4096,349,4096,17,327,4096,17,256,16,4161,33,16,2,348,65,372,4113,4096,16,84,49,256,32,4161,528]

theorem envBound21697 : H12AffineFastState.Bounded env21697 := by
  intro p hp
  have h : env21697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21696_21697 : H12AffineEnvironment.transform 9 256 env21696 = env21697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env21696 == env21697) = true)

theorem identity21697 : scanCanonicalize (H12AffineFastState.compose env21697 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound21697 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21698 : List Nat := [2,4,8,16,32,64,9,256,512,256,357,1,349,1,17,327,1,17,256,16,64,33,16,2,348,65,372,16,1,16,84,49,256,32,64,528]

theorem envBound21698 : H12AffineFastState.Bounded env21698 := by
  intro p hp
  have h : env21698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21697_21698 : H12AffineEnvironment.transform 11 1 env21697 = env21698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env21697 == env21698) = true)

theorem identity21698 : scanCanonicalize (H12AffineFastState.compose env21698 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound21698 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21699 : List Nat := [2,4,8,16,32,64,9,52,512,52,81,1,105,1,17,115,1,17,52,16,64,33,16,2,104,65,64,16,1,16,84,49,52,32,64,528]

theorem envBound21699 : H12AffineFastState.Bounded env21699 := by
  intro p hp
  have h : env21699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21698_21699 : H12AffineEnvironment.transform 7 52 env21698 = env21699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env21698 == env21699) = true)

theorem identity21699 : scanCanonicalize (H12AffineFastState.compose env21699 (packedSelected [1,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound21699 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env21700 : List Nat := [2,4,8,16,32,0,9,52,512,52,17,1,41,1,17,51,1,17,52,16,0,33,16,2,40,1,0,16,1,16,20,49,52,32,0,528]

theorem envBound21700 : H12AffineFastState.Bounded env21700 := by
  intro p hp
  have h : env21700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21699_21700 : H12AffineEnvironment.transform 5 0 env21699 = env21700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env21699 == env21700) = true)

def env21701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534880,474221,8328,65,6705549,2537696,456881,2125280,2102685,6707629,256,21793,46213,2175562]

theorem envBound21701 : H12AffineFastState.Bounded env21701 := by
  intro p hp
  have h : env21701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21620_21701 : H12AffineEnvironment.transform 23 474221 env21620 = env21701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474221 env21620 == env21701) = true)

def env21702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,2097152,4194304,2101328,98781,8328,65,6351933,2098512,17665,2125280,2102685,6349853,256,21793,46213,2175562]

theorem envBound21702 : H12AffineFastState.Bounded env21702 := by
  intro p hp
  have h : env21702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21701_21702 : H12AffineEnvironment.transform 17 179632 env21701 = env21702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env21701 == env21702) = true)

def env21703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,4194304,16,98781,8328,65,4258941,5392,17665,32160,1501,4256861,256,21793,46213,74250]

theorem envBound21703 : H12AffineFastState.Bounded env21703 := by
  intro p hp
  have h : env21703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21702_21703 : H12AffineEnvironment.transform 20 4160 env21702 = env21703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21702 == env21703) = true)

theorem identity21703 : scanCanonicalize (H12AffineFastState.compose env21703 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound21703 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149861,1024,29908,4160,4194304,16,95496,8328,65,4196520,5392,17665,32160,1501,4194440,256,21793,16464,74250]

theorem envBound21704 : H12AffineFastState.Bounded env21704 := by
  intro p hp
  have h : env21704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21703_21704 : H12AffineEnvironment.transform 14 29909 env21703 = env21704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env21703 == env21704) = true)

def env21705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138341,1024,8660,4160,4194304,16,73736,8328,65,4196520,5392,4097,10400,1501,4194440,256,33,5456,74250]

theorem envBound21705 : H12AffineFastState.Bounded env21705 := by
  intro p hp
  have h : env21705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21704_21705 : H12AffineEnvironment.transform 13 5376 env21704 = env21705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21704 == env21705) = true)

theorem identity21705 : scanCanonicalize (H12AffineFastState.compose env21705 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound21705 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70726,67619,1024,8660,4160,4194304,16,73736,8328,65,4196520,5392,4097,10400,1501,4194440,256,33,5456,74250]

theorem envBound21706 : H12AffineFastState.Bounded env21706 := by
  intro p hp
  have h : env21706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21705_21706 : H12AffineEnvironment.transform 16 70726 env21705 = env21706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env21705 == env21706) = true)

theorem identity21706 : scanCanonicalize (H12AffineFastState.compose env21706 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21706 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13389,10280,1024,8660,4160,4194304,16,3,8328,65,4196520,5392,4097,10400,1501,4194440,256,33,5456,513]

theorem envBound21707 : H12AffineFastState.Bounded env21707 := by
  intro p hp
  have h : env21707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21706_21707 : H12AffineEnvironment.transform 15 8203 env21706 = env21707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21706 == env21707) = true)

theorem identity21707 : scanCanonicalize (H12AffineFastState.compose env21707 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound21707 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13389,10280,1024,8660,4160,8492,16,3,8328,65,10628,5392,4097,10400,1501,8612,256,33,5456,513]

theorem envBound21708 : H12AffineFastState.Bounded env21708 := by
  intro p hp
  have h : env21708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21707_21708 : H12AffineEnvironment.transform 21 8492 env21707 = env21708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env21707 == env21708) = true)

def env21709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138340,1024,8661,4160,4194304,16,73737,8328,65,4196520,5392,4096,10401,1501,4194440,256,32,5457,74250]

theorem envBound21709 : H12AffineFastState.Bounded env21709 := by
  intro p hp
  have h : env21709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21704_21709 : H12AffineEnvironment.transform 13 5377 env21704 = env21709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21704 == env21709) = true)

theorem identity21709 : scanCanonicalize (H12AffineFastState.compose env21709 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound21709 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70863,67755,1024,8661,4160,4194304,16,73737,8328,65,4196520,5392,4096,10401,1501,4194440,256,32,5457,74250]

theorem envBound21710 : H12AffineFastState.Bounded env21710 := by
  intro p hp
  have h : env21710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21709_21710 : H12AffineEnvironment.transform 16 70863 env21709 = env21710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env21709 == env21710) = true)

theorem identity21710 : scanCanonicalize (H12AffineFastState.compose env21710 (packedSelected [0,2,3,4,5,6,9,10,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21710 : packedSelected [0,2,3,4,5,6,9,10,20,27] rootPS < 2^1333 := by decide +kernel

def env21711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,70726,67618,1024,8540,4160,4194304,16,73737,8193,65,4196385,5392,4096,10280,1364,4194305,256,32,5457,74250]

theorem envBound21711 : H12AffineFastState.Bounded env21711 := by
  intro p hp
  have h : env21711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21710_21711 : H12AffineEnvironment.transform 6 9 env21710 = env21711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21710 == env21711) = true)

theorem identity21711 : scanCanonicalize (H12AffineFastState.compose env21711 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound21711 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,342,5392,2420,1024,8540,4160,4194304,16,8543,8193,65,4196385,5392,4096,10280,1364,4194305,256,32,5457,9052]

theorem envBound21712 : H12AffineFastState.Bounded env21712 := by
  intro p hp
  have h : env21712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21711_21712 : H12AffineEnvironment.transform 15 342 env21711 = env21712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env21711 == env21712) = true)

theorem identity21712 : scanCanonicalize (H12AffineFastState.compose env21712 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 8280) := by decide +kernel

theorem selectedBound21712 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env21713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,342,5392,2420,1024,8540,4160,8280,16,8543,8193,65,10361,5392,4096,10280,1364,8281,256,32,5457,9052]

theorem envBound21713 : H12AffineFastState.Bounded env21713 := by
  intro p hp
  have h : env21713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21712_21713 : H12AffineEnvironment.transform 21 8280 env21712 = env21713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8280 env21712 == env21713) = true)

theorem identity21713 : scanCanonicalize (H12AffineFastState.compose env21713 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21713 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env21714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5392,2420,1024,0,4160,260,16,3,349,65,2341,5392,4096,2420,1364,261,256,32,5457,512]

theorem envBound21714 : H12AffineFastState.Bounded env21714 := by
  intro p hp
  have h : env21714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21713_21714 : H12AffineEnvironment.transform 12 348 env21713 = env21714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21713 == env21714) = true)

theorem identity21714 : scanCanonicalize (H12AffineFastState.compose env21714 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21714 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21715 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,88,5125,1,82,5140,2160,1024,0,4160,0,16,3,89,65,2081,5140,4096,2160,1104,1,4,32,5205,512]

theorem envBound21715 : H12AffineFastState.Bounded env21715 := by
  intro p hp
  have h : env21715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21714_21715 : H12AffineEnvironment.transform 7 4 env21714 = env21715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21714 == env21715) = true)

theorem identity21715 : scanCanonicalize (H12AffineFastState.compose env21715 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound21715 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env21716 : List Nat := [2,4,8,16,32,64,9,4,512,1024,1092,4096,88,5125,1,82,5140,1076,1024,0,4160,0,16,3,89,65,1125,5140,4096,1076,1104,1,4,32,5205,512]

theorem envBound21716 : H12AffineFastState.Bounded env21716 := by
  intro p hp
  have h : env21716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21715_21716 : H12AffineEnvironment.transform 10 1092 env21715 = env21716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env21715 == env21716) = true)

theorem identity21716 : scanCanonicalize (H12AffineFastState.compose env21716 (packedSelected [0,2,5,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21716 : packedSelected [0,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env21717 : List Nat := [2,4,8,16,0,64,9,4,512,1024,1092,4096,88,5125,1,82,5140,1044,1024,0,4160,0,16,3,89,65,1093,5140,4096,1044,1104,1,4,0,5205,512]

theorem envBound21717 : H12AffineFastState.Bounded env21717 := by
  intro p hp
  have h : env21717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21716_21717 : H12AffineEnvironment.transform 4 0 env21716 = env21717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21716 == env21717) = true)

theorem identity21717 : scanCanonicalize (H12AffineFastState.compose env21717 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound21717 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21718 : List Nat := [2,4,8,16,0,64,9,4,512,1024,1092,17,88,1044,1,82,1029,1044,1024,0,81,0,16,3,89,65,1093,1029,17,1044,1104,1,4,0,1092,512]

theorem envBound21718 : H12AffineFastState.Bounded env21718 := by
  intro p hp
  have h : env21718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21717_21718 : H12AffineEnvironment.transform 11 17 env21717 = env21718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21717 == env21718) = true)

theorem identity21718 : scanCanonicalize (H12AffineFastState.compose env21718 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound21718 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21719 : List Nat := [2,4,8,16,0,64,9,4,80,1024,1092,17,88,1044,1,82,1029,1044,1024,0,81,0,16,3,89,65,1093,1029,17,1044,1104,1,4,0,1092,80]

theorem envBound21719 : H12AffineFastState.Bounded env21719 := by
  intro p hp
  have h : env21719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21718_21719 : H12AffineEnvironment.transform 8 80 env21718 = env21719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env21718 == env21719) = true)

theorem identity21719 : scanCanonicalize (H12AffineFastState.compose env21719 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound21719 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21720 : List Nat := [2,4,8,16,0,64,9,4,80,68,0,17,88,80,1,82,65,80,68,0,81,0,16,3,89,65,1,65,17,80,20,1,4,0,0,80]

theorem envBound21720 : H12AffineFastState.Bounded env21720 := by
  intro p hp
  have h : env21720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21719_21720 : H12AffineEnvironment.transform 9 68 env21719 = env21720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env21719 == env21720) = true)

theorem identity21720 : scanCanonicalize (H12AffineFastState.compose env21720 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21720 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21721 : List Nat := [2,4,8,16,0,16,9,4,0,20,0,17,8,0,1,2,17,0,20,0,1,0,16,3,9,17,1,17,17,0,20,1,4,0,0,0]

theorem envBound21721 : H12AffineFastState.Bounded env21721 := by
  intro p hp
  have h : env21721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21720_21721 : H12AffineEnvironment.transform 5 16 env21720 = env21721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21720 == env21721) = true)

theorem identity21721 : scanCanonicalize (H12AffineFastState.compose env21721 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound21721 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21722 : List Nat := [2,4,8,5,0,5,9,4,0,1,0,4,8,0,1,2,4,0,1,0,1,0,5,3,9,4,1,4,4,0,1,1,4,0,0,0]

theorem envBound21722 : H12AffineFastState.Bounded env21722 := by
  intro p hp
  have h : env21722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21721_21722 : H12AffineEnvironment.transform 3 5 env21721 = env21722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env21721 == env21722) = true)

theorem identity21722 : scanCanonicalize (H12AffineFastState.compose env21722 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound21722 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21723 : List Nat := [2,0,8,1,0,1,9,0,0,1,0,0,8,0,1,2,0,0,1,0,1,0,1,3,9,0,1,0,0,0,1,1,0,0,0,0]

theorem envBound21723 : H12AffineFastState.Bounded env21723 := by
  intro p hp
  have h : env21723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21722_21723 : H12AffineEnvironment.transform 1 0 env21722 = env21723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env21722 == env21723) = true)

def env21724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,4194304,17,98781,8328,65,4258940,5393,17665,32161,1500,4256860,256,21793,46213,74251]

theorem envBound21724 : H12AffineFastState.Bounded env21724 := by
  intro p hp
  have h : env21724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21702_21724 : H12AffineEnvironment.transform 20 4161 env21702 = env21724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21702 == env21724) = true)

theorem identity21724 : scanCanonicalize (H12AffineFastState.compose env21724 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156132) := by decide +kernel

theorem selectedBound21724 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,156132,17,98781,8328,65,171416,5393,17665,32161,1500,169400,256,21793,46213,74251]

theorem envBound21725 : H12AffineFastState.Bounded env21725 := by
  intro p hp
  have h : env21725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21724_21725 : H12AffineEnvironment.transform 21 156132 env21724 = env21725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env21724 == env21725) = true)

def env21726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156012,17,98645,8192,65,171280,5393,17665,32041,1364,169264,256,21793,46093,74251]

theorem envBound21726 : H12AffineFastState.Bounded env21726 := by
  intro p hp
  have h : env21726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21725_21726 : H12AffineEnvironment.transform 6 8 env21725 = env21726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21725 == env21726) = true)

theorem identity21726 : scanCanonicalize (H12AffineFastState.compose env21726 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21726 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4161,156012,17,41311,8192,65,171280,5393,17665,32041,1364,169264,256,21793,46093,513]

end H12CloudChart0