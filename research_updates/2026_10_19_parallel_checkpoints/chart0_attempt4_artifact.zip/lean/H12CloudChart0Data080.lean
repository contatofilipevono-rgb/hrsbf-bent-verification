import H12CloudChart0Data079

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound20187 : H12AffineFastState.Bounded env20187 := by
  intro p hp
  have h : env20187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20186_20187 : H12AffineEnvironment.transform 6 88 env20186 = env20187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20186 == env20187) = true)

def env20188 : List Nat := [2,4,8,16,32,64,88,256,512,256,2048,4096,8192,16384,28940,28762,4160,2421,256,28941,4160,29052,17,20483,8272,65,30989,16449,16385,10281,20564,8572,256,113,4097,513]

theorem envBound20188 : H12AffineFastState.Bounded env20188 := by
  intro p hp
  have h : env20188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20187_20188 : H12AffineEnvironment.transform 9 256 env20187 = env20188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env20187 == env20188) = true)

theorem identity20188 : scanCanonicalize (H12AffineFastState.compose env20188 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound20188 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env20189 : List Nat := [2,4,8,16,32,64,88,256,512,256,2048,4096,57,16384,20789,20579,4160,2421,256,20788,4160,20805,17,20483,105,65,22836,16449,16385,2064,20564,325,256,113,4097,513]

theorem envBound20189 : H12AffineFastState.Bounded env20189 := by
  intro p hp
  have h : env20189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20188_20189 : H12AffineEnvironment.transform 12 57 env20188 = env20189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env20188 == env20189) = true)

theorem identity20189 : scanCanonicalize (H12AffineFastState.compose env20189 (packedSelected [6,17] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound20189 : packedSelected [6,17] rootPS < 2^1333 := by decide +kernel

def env20190 : List Nat := [2,4,8,16,32,64,88,256,512,256,2048,4096,57,4404,1,343,4160,2421,256,0,4160,113,17,311,105,65,2048,4469,4405,2064,352,325,256,113,4097,513]

theorem envBound20190 : H12AffineFastState.Bounded env20190 := by
  intro p hp
  have h : env20190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20189_20190 : H12AffineEnvironment.transform 13 4404 env20189 = env20190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env20189 == env20190) = true)

theorem identity20190 : scanCanonicalize (H12AffineFastState.compose env20190 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20191 : List Nat := [2,4,8,16,32,17,9,256,512,256,2048,4096,57,4404,1,262,4113,2340,256,0,4113,32,17,311,56,16,2048,4388,4405,2064,305,276,256,32,4097,513]

theorem envBound20191 : H12AffineFastState.Bounded env20191 := by
  intro p hp
  have h : env20191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20190_20191 : H12AffineEnvironment.transform 5 17 env20190 = env20191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20190 == env20191) = true)

theorem identity20191 : scanCanonicalize (H12AffineFastState.compose env20191 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound20191 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20192 : List Nat := [2,4,8,16,32,17,9,256,512,256,292,4096,57,4404,1,262,4113,0,256,0,4113,32,17,311,56,16,292,4388,4405,308,305,276,256,32,4097,513]

theorem envBound20192 : H12AffineFastState.Bounded env20192 := by
  intro p hp
  have h : env20192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20191_20192 : H12AffineEnvironment.transform 10 292 env20191 = env20192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env20191 == env20192) = true)

theorem identity20192 : scanCanonicalize (H12AffineFastState.compose env20192 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound20192 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20193 : List Nat := [2,4,8,16,32,17,9,52,512,52,16,4096,57,4096,1,50,4113,0,52,0,4113,32,17,3,56,16,16,4112,4097,0,5,32,52,32,4097,513]

theorem envBound20193 : H12AffineFastState.Bounded env20193 := by
  intro p hp
  have h : env20193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20192_20193 : H12AffineEnvironment.transform 7 52 env20192 = env20193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env20192 == env20193) = true)

theorem identity20193 : scanCanonicalize (H12AffineFastState.compose env20193 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound20193 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20194 : List Nat := [2,4,8,16,32,17,9,52,512,52,16,17,57,17,1,50,0,0,52,0,0,32,17,3,56,16,16,1,16,0,5,32,52,32,16,513]

theorem envBound20194 : H12AffineFastState.Bounded env20194 := by
  intro p hp
  have h : env20194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20193_20194 : H12AffineEnvironment.transform 11 17 env20193 = env20194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20193 == env20194) = true)

theorem identity20194 : scanCanonicalize (H12AffineFastState.compose env20194 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20194 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20195 : List Nat := [2,4,8,0,32,1,9,36,512,36,0,1,41,1,1,34,0,0,36,0,0,32,1,3,40,0,0,1,0,0,5,32,36,32,0,513]

theorem envBound20195 : H12AffineFastState.Bounded env20195 := by
  intro p hp
  have h : env20195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20194_20195 : H12AffineEnvironment.transform 3 0 env20194 = env20195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20194 == env20195) = true)

theorem identity20195 : scanCanonicalize (H12AffineFastState.compose env20195 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20195 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20196 : List Nat := [2,4,8,0,32,1,9,36,33,36,0,1,41,1,1,34,0,0,36,0,0,32,1,3,40,0,0,1,0,0,5,32,36,32,0,32]

theorem envBound20196 : H12AffineFastState.Bounded env20196 := by
  intro p hp
  have h : env20196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20195_20196 : H12AffineEnvironment.transform 8 33 env20195 = env20196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20195 == env20196) = true)

def env20197 : List Nat := [2,4,8,16,32,64,88,256,512,257,2048,4096,8192,16384,28941,28763,4161,2421,257,28940,4160,29053,17,20482,8272,65,30988,16449,16384,10281,20564,8572,256,113,4096,513]

theorem envBound20197 : H12AffineFastState.Bounded env20197 := by
  intro p hp
  have h : env20197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20187_20197 : H12AffineEnvironment.transform 9 257 env20187 = env20197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env20187 == env20197) = true)

theorem identity20197 : scanCanonicalize (H12AffineFastState.compose env20197 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound20197 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env20198 : List Nat := [2,4,8,16,32,64,88,256,512,257,2048,4096,8192,12392,357,51,4161,2421,257,356,4160,277,17,8298,8272,65,2404,12329,12392,10281,8252,8572,256,113,4096,513]

theorem envBound20198 : H12AffineFastState.Bounded env20198 := by
  intro p hp
  have h : env20198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20197_20198 : H12AffineEnvironment.transform 13 12392 env20197 = env20198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env20197 == env20198) = true)

theorem identity20198 : scanCanonicalize (H12AffineFastState.compose env20198 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound20198 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20199 : List Nat := [2,4,8,16,32,64,88,100,512,101,2048,4096,8192,12392,1,51,4161,2065,101,0,4160,113,17,8298,8272,65,2048,12329,12392,10281,8252,8216,100,113,4096,513]

theorem envBound20199 : H12AffineFastState.Bounded env20199 := by
  intro p hp
  have h : env20199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20198_20199 : H12AffineEnvironment.transform 7 100 env20198 = env20199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env20198 == env20199) = true)

theorem identity20199 : scanCanonicalize (H12AffineFastState.compose env20199 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound20199 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env20200 : List Nat := [2,4,8,16,32,64,88,100,512,101,2048,4096,105,4097,1,51,4161,2065,101,0,4160,113,17,3,57,65,2048,4160,4097,2112,85,113,100,113,4096,513]

theorem envBound20200 : H12AffineFastState.Bounded env20200 := by
  intro p hp
  have h : env20200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20199_20200 : H12AffineEnvironment.transform 12 105 env20199 = env20200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env20199 == env20200) = true)

theorem identity20200 : scanCanonicalize (H12AffineFastState.compose env20200 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20200 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20201 : List Nat := [2,4,8,16,32,17,9,53,512,52,2048,4096,56,4097,1,51,4112,2065,52,0,4113,32,17,3,57,16,2048,4113,4097,2065,4,32,53,32,4096,513]

theorem envBound20201 : H12AffineFastState.Bounded env20201 := by
  intro p hp
  have h : env20201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20200_20201 : H12AffineEnvironment.transform 5 17 env20200 = env20201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20200 == env20201) = true)

theorem identity20201 : scanCanonicalize (H12AffineFastState.compose env20201 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound20201 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20202 : List Nat := [2,4,8,16,32,17,9,53,512,52,2048,17,56,16,1,51,1,2065,52,0,0,32,17,3,57,16,2048,0,16,2065,4,32,53,32,17,513]

theorem envBound20202 : H12AffineFastState.Bounded env20202 := by
  intro p hp
  have h : env20202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20201_20202 : H12AffineEnvironment.transform 11 17 env20201 = env20202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20201 == env20202) = true)

theorem identity20202 : scanCanonicalize (H12AffineFastState.compose env20202 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound20202 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20203 : List Nat := [2,4,8,16,32,17,9,53,512,52,17,17,56,16,1,51,1,0,52,0,0,32,17,3,57,16,17,0,16,0,4,32,53,32,17,513]

theorem envBound20203 : H12AffineFastState.Bounded env20203 := by
  intro p hp
  have h : env20203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20202_20203 : H12AffineEnvironment.transform 10 17 env20202 = env20203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env20202 == env20203) = true)

theorem identity20203 : scanCanonicalize (H12AffineFastState.compose env20203 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20203 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20204 : List Nat := [2,4,8,1,32,0,9,36,512,37,0,0,41,1,1,34,1,0,37,0,0,32,0,3,40,1,0,0,1,0,4,32,36,32,0,513]

theorem envBound20204 : H12AffineFastState.Bounded env20204 := by
  intro p hp
  have h : env20204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20203_20204 : H12AffineEnvironment.transform 3 1 env20203 = env20204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20203 == env20204) = true)

theorem identity20204 : scanCanonicalize (H12AffineFastState.compose env20204 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20205 : List Nat := [2,4,8,1,32,0,9,36,33,37,0,0,41,1,1,34,1,0,37,0,0,32,0,3,40,1,0,0,1,0,4,32,36,32,0,32]

theorem envBound20205 : H12AffineFastState.Bounded env20205 := by
  intro p hp
  have h : env20205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20204_20205 : H12AffineEnvironment.transform 8 33 env20204 = env20205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20204 == env20205) = true)

def env20206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,21762,8328,65,4291883,115151,17665,10280,119042,4268162,256,98814,90202,63189]

theorem envBound20206 : H12AffineFastState.Bounded env20206 := by
  intro p hp
  have h : env20206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20181_20206 : H12AffineEnvironment.transform 20 4161 env20181 = env20206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20181 == env20206) = true)

theorem identity20206 : scanCanonicalize (H12AffineFastState.compose env20206 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound20206 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,190521,1024,32769,4161,4194304,16,21762,8328,65,4237813,5393,17665,10280,1500,4256860,256,21792,46212,63189]

theorem envBound20207 : H12AffineFastState.Bounded env20207 := by
  intro p hp
  have h : env20207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20206_20207 : H12AffineEnvironment.transform 15 54494 env20206 = env20207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env20206 == env20207) = true)

def env20208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190521,1024,32769,4161,4194304,16,21762,8192,65,4237693,5393,17665,10280,1364,4256860,256,21792,46092,63069]

theorem envBound20208 : H12AffineFastState.Bounded env20208 := by
  intro p hp
  have h : env20208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20207_20208 : H12AffineEnvironment.transform 6 8 env20207 = env20208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20207 == env20208) = true)

theorem identity20208 : scanCanonicalize (H12AffineFastState.compose env20208 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound20208 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20209 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,56437,1024,32769,4161,4194304,16,21762,8192,65,4237693,5393,17665,10280,1364,4256860,256,21792,46092,63069]

theorem envBound20209 : H12AffineFastState.Bounded env20209 := by
  intro p hp
  have h : env20209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20208_20209 : H12AffineEnvironment.transform 16 13388 env20208 = env20209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env20208 == env20209) = true)

theorem identity20209 : scanCanonicalize (H12AffineFastState.compose env20209 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 29821) := by decide +kernel

theorem selectedBound20209 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env20210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,56437,1024,32769,4161,29821,16,21762,8192,65,56576,5393,17665,10280,1364,32801,256,21792,46092,63069]

theorem envBound20210 : H12AffineFastState.Bounded env20210 := by
  intro p hp
  have h : env20210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20209_20210 : H12AffineEnvironment.transform 21 29821 env20209 = env20210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29821 env20209 == env20210) = true)

theorem identity20210 : scanCanonicalize (H12AffineFastState.compose env20210 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound20210 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env20211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,263,13388,2340,1024,21840,4161,29821,16,21762,8192,65,2129,5393,17665,10280,1364,21872,256,21792,24925,8972]

theorem envBound20211 : H12AffineFastState.Bounded env20211 := by
  intro p hp
  have h : env20211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20210_20211 : H12AffineEnvironment.transform 14 21841 env20210 = env20211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env20210 == env20211) = true)

theorem identity20211 : scanCanonicalize (H12AffineFastState.compose env20211 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20211 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env20212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,81,263,13388,2340,1024,80,4161,8573,16,2,8192,65,2129,5393,4097,10280,1364,112,256,32,13405,8972]

theorem envBound20212 : H12AffineFastState.Bounded env20212 := by
  intro p hp
  have h : env20212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20211_20212 : H12AffineEnvironment.transform 13 5376 env20211 = env20212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20211 == env20212) = true)

theorem identity20212 : scanCanonicalize (H12AffineFastState.compose env20212 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20212 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env20213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,263,5440,2340,1024,80,4161,113,16,2,268,65,2129,5393,4097,2340,1364,112,256,32,5457,512]

theorem envBound20213 : H12AffineFastState.Bounded env20213 := by
  intro p hp
  have h : env20213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20212_20213 : H12AffineEnvironment.transform 12 268 env20212 = env20213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20212 == env20213) = true)

theorem identity20213 : scanCanonicalize (H12AffineFastState.compose env20213 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20213 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20214 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,268,5376,81,263,5440,2308,1024,80,4161,81,16,2,268,65,2129,5393,4097,2308,1364,80,256,0,5457,512]

theorem envBound20214 : H12AffineFastState.Bounded env20214 := by
  intro p hp
  have h : env20214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20213_20214 : H12AffineEnvironment.transform 4 0 env20213 = env20214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20213 == env20214) = true)

theorem identity20214 : scanCanonicalize (H12AffineFastState.compose env20214 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound20214 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20215 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,4096,268,4112,81,263,4176,2308,272,80,4161,81,16,2,268,65,2129,4097,4097,2308,68,80,256,0,4161,512]

theorem envBound20215 : H12AffineFastState.Bounded env20215 := by
  intro p hp
  have h : env20215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20214_20215 : H12AffineEnvironment.transform 9 272 env20214 = env20215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20214 == env20215) = true)

theorem identity20215 : scanCanonicalize (H12AffineFastState.compose env20215 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound20215 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20216 : List Nat := [2,4,8,16,0,64,8,256,512,272,2048,2112,268,2128,81,263,2064,2308,272,80,2049,81,16,2,268,65,2129,2113,2113,2308,68,80,256,0,2049,512]

theorem envBound20216 : H12AffineFastState.Bounded env20216 := by
  intro p hp
  have h : env20216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20215_20216 : H12AffineEnvironment.transform 11 2112 env20215 = env20216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env20215 == env20216) = true)

theorem identity20216 : scanCanonicalize (H12AffineFastState.compose env20216 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound20216 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env20217 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,2112,89,2128,81,82,2064,2129,69,80,2049,81,16,2,89,65,2129,2113,2113,2129,68,80,85,0,2049,512]

theorem envBound20217 : H12AffineFastState.Bounded env20217 := by
  intro p hp
  have h : env20217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20216_20217 : H12AffineEnvironment.transform 7 85 env20216 = env20217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env20216 == env20217) = true)

def env20218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4161,4194304,16,21762,8193,65,4237692,5393,17665,10280,1365,4256860,256,21792,46093,63068]

theorem envBound20218 : H12AffineFastState.Bounded env20218 := by
  intro p hp
  have h : env20218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20207_20218 : H12AffineEnvironment.transform 6 9 env20207 = env20218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20207 == env20218) = true)

theorem identity20218 : scanCanonicalize (H12AffineFastState.compose env20218 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound20218 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,32040,1024,32769,4161,4194304,16,21762,8193,65,4237692,5393,17665,10280,1365,4256860,256,21792,46093,63068]

theorem envBound20219 : H12AffineFastState.Bounded env20219 := by
  intro p hp
  have h : env20219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20218_20219 : H12AffineEnvironment.transform 16 38161 env20218 = env20219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env20218 == env20219) = true)

theorem identity20219 : scanCanonicalize (H12AffineFastState.compose env20219 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound20219 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env20220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,32040,1024,32769,4161,8492,16,21762,8193,65,34896,5393,17665,10280,1365,54640,256,21792,46093,63068]

theorem envBound20220 : H12AffineFastState.Bounded env20220 := by
  intro p hp
  have h : env20220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20219_20220 : H12AffineEnvironment.transform 21 8492 env20219 = env20220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env20219 == env20220) = true)

theorem identity20220 : scanCanonicalize (H12AffineFastState.compose env20220 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound20220 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env20221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,33030,38161,10361,1024,32769,4161,8492,16,83,8193,65,34896,5393,4176,10280,1365,32801,256,113,46093,41741]

theorem envBound20221 : H12AffineFastState.Bounded env20221 := by
  intro p hp
  have h : env20221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20220_20221 : H12AffineEnvironment.transform 13 5457 env20220 = env20221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env20220 == env20221) = true)

theorem identity20221 : scanCanonicalize (H12AffineFastState.compose env20221 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20221 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,32768,33030,38161,2341,1024,32769,4161,112,16,83,349,65,34896,5393,4176,2420,1365,32801,256,113,38225,33361]

theorem envBound20222 : H12AffineFastState.Bounded env20222 := by
  intro p hp
  have h : env20222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20221_20222 : H12AffineEnvironment.transform 12 348 env20221 = env20222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20221 == env20222) = true)

theorem identity20222 : scanCanonicalize (H12AffineFastState.compose env20222 (packedSelected [2,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20222 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env20223 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,89,5204,32768,32771,37908,2080,1024,32769,4161,112,16,83,88,65,34896,5140,4176,2161,1104,32801,5,113,37972,33361]

theorem envBound20223 : H12AffineFastState.Bounded env20223 := by
  intro p hp
  have h : env20223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20222_20223 : H12AffineEnvironment.transform 7 5 env20222 = env20223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20222 == env20223) = true)

theorem identity20223 : scanCanonicalize (H12AffineFastState.compose env20223 (packedSelected [2,3,4,5,9,10,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound20223 : packedSelected [2,3,4,5,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env20224 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,89,5204,113,114,5221,2080,1024,112,4161,112,16,83,88,65,2081,5140,4176,2161,1104,80,5,113,5157,544]

theorem envBound20224 : H12AffineFastState.Bounded env20224 := by
  intro p hp
  have h : env20224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20223_20224 : H12AffineEnvironment.transform 14 113 env20223 = env20224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env20223 == env20224) = true)

theorem identity20224 : scanCanonicalize (H12AffineFastState.compose env20224 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20224 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20225 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,9,5124,33,34,5173,2080,1024,32,4113,32,16,3,8,17,2081,5140,4096,2081,1024,0,5,33,5157,544]

theorem envBound20225 : H12AffineFastState.Bounded env20225 := by
  intro p hp
  have h : env20225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20224_20225 : H12AffineEnvironment.transform 5 16 env20224 = env20225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20224 == env20225) = true)

theorem identity20225 : scanCanonicalize (H12AffineFastState.compose env20225 (packedSelected [0,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20225 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env20226 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5124,1,2,5141,2048,1024,0,4113,0,16,3,8,17,2049,5140,4096,2049,1024,0,5,1,5125,512]

theorem envBound20226 : H12AffineFastState.Bounded env20226 := by
  intro p hp
  have h : env20226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20225_20226 : H12AffineEnvironment.transform 4 0 env20225 = env20226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20225 == env20226) = true)

theorem identity20226 : scanCanonicalize (H12AffineFastState.compose env20226 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound20226 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20227 : List Nat := [2,4,8,16,0,16,9,5,512,1024,522,4096,9,5124,1,2,5141,522,1024,0,4113,0,16,3,8,17,523,5140,4096,523,1024,0,5,1,5125,512]

theorem envBound20227 : H12AffineFastState.Bounded env20227 := by
  intro p hp
  have h : env20227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20226_20227 : H12AffineEnvironment.transform 10 522 env20226 = env20227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env20226 == env20227) = true)

def env20228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound20228 : H12AffineFastState.Bounded env20228 := by
  intro p hp
  have h : env20228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20031_20228 : H12AffineEnvironment.transform 18 1025 env20031 = env20228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20031 == env20228) = true)

theorem identity20228 : scanCanonicalize (H12AffineFastState.compose env20228 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2444795) := by decide +kernel

theorem selectedBound20228 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2444795,16777216,8328,65,23236090,18973837,333995,2330107,19188203,23160257,257,17074519,17066226,19263037]

theorem envBound20229 : H12AffineFastState.Bounded env20229 := by
  intro p hp
  have h : env20229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20228_20229 : H12AffineEnvironment.transform 22 2444795 env20228 = env20229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2444795 env20228 == env20229) = true)

def env20230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,16777216,8328,65,16959642,18973837,333995,2330107,19188203,16851105,257,17074519,17066226,19263037]

theorem envBound20230 : H12AffineFastState.Bounded env20230 := by
  intro p hp
  have h : env20230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20229_20230 : H12AffineEnvironment.transform 21 2114912 env20229 = env20230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env20229 == env20230) = true)

def env20231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,2431208,8328,65,2609266,302181,333995,2330107,119043,2373705,257,2199999,2191386,63189]

theorem envBound20231 : H12AffineFastState.Bounded env20231 := by
  intro p hp
  have h : env20231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20230_20231 : H12AffineEnvironment.transform 23 2431208 env20230 = env20231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431208 env20230 == env20231) = true)

def env20232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21792,351675,329896,8328,65,507954,302181,333995,236987,119043,272393,257,98815,90202,63189]

theorem envBound20232 : H12AffineFastState.Bounded env20232 := by
  intro p hp
  have h : env20232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20231_20232 : H12AffineEnvironment.transform 20 4160 env20231 = env20232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20231 == env20232) = true)

def env20233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4160,21792,95515,73736,8328,65,256146,46277,77835,236987,119043,169,257,98815,90202,63189]

theorem envBound20233 : H12AffineFastState.Bounded env20233 := by
  intro p hp
  have h : env20233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20232_20233 : H12AffineEnvironment.transform 17 10400 env20232 = env20233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env20232 == env20233) = true)

def env20234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,21792,95515,73736,8192,65,256026,46157,77835,236851,119043,33,257,98679,90202,63069]

theorem envBound20234 : H12AffineFastState.Bounded env20234 := by
  intro p hp
  have h : env20234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20233_20234 : H12AffineEnvironment.transform 6 8 env20233 = env20234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20233 == env20234) = true)

theorem identity20234 : scanCanonicalize (H12AffineFastState.compose env20234 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20234 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4160,32,73755,73736,8192,65,245018,46157,77835,236851,99331,33,257,98679,79194,41821]

theorem envBound20235 : H12AffineFastState.Bounded env20235 := by
  intro p hp
  have h : env20235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20234_20235 : H12AffineEnvironment.transform 13 5376 env20234 = env20235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20234 == env20235) = true)

theorem identity20235 : scanCanonicalize (H12AffineFastState.compose env20235 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound20235 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,103494,10280,1025,32769,4160,32,73755,73736,8192,65,10588,46157,77835,2421,99331,33,257,98679,79194,41821]

theorem envBound20236 : H12AffineFastState.Bounded env20236 := by
  intro p hp
  have h : env20236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20235_20236 : H12AffineEnvironment.transform 16 103494 env20235 = env20236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env20235 == env20236) = true)

theorem identity20236 : scanCanonicalize (H12AffineFastState.compose env20236 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound20236 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,9498,45404,10280,1025,32769,4160,32,1281,1298,8192,65,10588,46157,5393,2421,41241,33,257,42093,4160,41821]

theorem envBound20237 : H12AffineFastState.Bounded env20237 := by
  intro p hp
  have h : env20237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20236_20237 : H12AffineEnvironment.transform 15 9498 env20236 = env20237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env20236 == env20237) = true)

theorem identity20237 : scanCanonicalize (H12AffineFastState.compose env20237 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20237 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env20238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,9498,4097,10280,1025,8540,4160,32,1281,1298,8192,65,10588,5392,5393,2421,68,33,257,1328,4160,512]

theorem envBound20238 : H12AffineFastState.Bounded env20238 := by
  intro p hp
  have h : env20238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20237_20238 : H12AffineEnvironment.transform 14 8541 env20237 = env20238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20237 == env20238) = true)

theorem identity20238 : scanCanonicalize (H12AffineFastState.compose env20238 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4428) := by decide +kernel

theorem selectedBound20238 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env20239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4428,5376,4113,5206,4097,6500,1025,4112,4160,32,1281,1298,4428,65,6160,5392,5393,2421,68,33,257,1328,4160,512]

theorem envBound20239 : H12AffineFastState.Bounded env20239 := by
  intro p hp
  have h : env20239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20238_20239 : H12AffineEnvironment.transform 12 4428 env20238 = env20239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4428 env20238 == env20239) = true)

theorem identity20239 : scanCanonicalize (H12AffineFastState.compose env20239 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound20239 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env20240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,4428,5376,4113,5206,4097,4452,1025,4112,4160,32,1281,1298,4428,65,4112,5392,5393,373,68,33,257,1328,4160,512]

theorem envBound20240 : H12AffineFastState.Bounded env20240 := by
  intro p hp
  have h : env20240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20239_20240 : H12AffineEnvironment.transform 10 0 env20239 = env20240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20239 == env20240) = true)

theorem identity20240 : scanCanonicalize (H12AffineFastState.compose env20240 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound20240 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20241 : List Nat := [2,4,8,16,32,64,8,256,512,69,0,4096,4428,4421,4113,4115,4097,4452,68,4112,4160,32,324,343,4428,65,4112,4437,4436,373,68,33,257,373,4160,512]

theorem envBound20241 : H12AffineFastState.Bounded env20241 := by
  intro p hp
  have h : env20241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20240_20241 : H12AffineEnvironment.transform 9 69 env20240 = env20241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env20240 == env20241) = true)

theorem identity20241 : scanCanonicalize (H12AffineFastState.compose env20241 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound20241 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20242 : List Nat := [2,4,8,16,32,64,8,256,512,69,0,17,349,340,0,2,16,373,68,1,81,32,324,343,349,65,1,324,325,373,68,33,257,373,81,512]

theorem envBound20242 : H12AffineFastState.Bounded env20242 := by
  intro p hp
  have h : env20242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20241_20242 : H12AffineEnvironment.transform 11 17 env20241 = env20242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20241 == env20242) = true)

theorem identity20242 : scanCanonicalize (H12AffineFastState.compose env20242 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20242 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20243 : List Nat := [2,4,8,16,32,48,8,256,512,53,0,17,301,292,0,2,16,261,52,1,33,32,308,295,301,49,1,308,309,261,52,33,257,261,33,512]

theorem envBound20243 : H12AffineFastState.Bounded env20243 := by
  intro p hp
  have h : env20243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20242_20243 : H12AffineEnvironment.transform 5 48 env20242 = env20243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20242 == env20243) = true)

theorem identity20243 : scanCanonicalize (H12AffineFastState.compose env20243 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20243 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20244 : List Nat := [2,4,8,16,32,48,8,5,512,53,0,17,40,33,0,2,16,0,52,1,33,32,49,34,40,49,1,49,48,0,52,33,4,0,33,512]

theorem envBound20244 : H12AffineFastState.Bounded env20244 := by
  intro p hp
  have h : env20244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20243_20244 : H12AffineEnvironment.transform 7 5 env20243 = env20244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20243 == env20244) = true)

theorem identity20244 : scanCanonicalize (H12AffineFastState.compose env20244 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound20244 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env20245 : List Nat := [2,4,8,16,32,48,8,5,48,53,0,17,40,33,0,2,16,0,52,1,33,32,49,34,40,49,1,49,48,0,52,33,4,0,33,48]

theorem envBound20245 : H12AffineFastState.Bounded env20245 := by
  intro p hp
  have h : env20245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20244_20245 : H12AffineEnvironment.transform 8 48 env20244 = env20245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env20244 == env20245) = true)

def env20246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,21792,95515,73736,8193,65,256027,46156,77835,236850,119043,32,257,98678,90202,63068]

theorem envBound20246 : H12AffineFastState.Bounded env20246 := by
  intro p hp
  have h : env20246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20233_20246 : H12AffineEnvironment.transform 6 9 env20233 = env20246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20233 == env20246) = true)

theorem identity20246 : scanCanonicalize (H12AffineFastState.compose env20246 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20246 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,4160,21792,95515,73736,8193,65,203846,16401,77835,223599,75102,32,257,95531,90202,513]

theorem envBound20247 : H12AffineFastState.Bounded env20247 := by
  intro p hp
  have h : env20247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20246_20247 : H12AffineEnvironment.transform 14 29789 env20246 = env20247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20246 == env20247) = true)

theorem identity20247 : scanCanonicalize (H12AffineFastState.compose env20247 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound20247 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env20248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8283,131072,10281,1025,29788,4160,21792,21824,83,8193,65,146461,16401,4176,149812,1285,32,257,21872,16385,513]

theorem envBound20248 : H12AffineFastState.Bounded env20248 := by
  intro p hp
  have h : env20248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20247_20248 : H12AffineEnvironment.transform 15 8283 env20247 = env20248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env20247 == env20248) = true)

theorem identity20248 : scanCanonicalize (H12AffineFastState.compose env20248 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound20248 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env20249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8283,24860,10281,1025,29788,4160,21792,21824,83,8193,65,23809,16401,4176,10280,1285,32,257,21872,16385,513]

theorem envBound20249 : H12AffineFastState.Bounded env20249 := by
  intro p hp
  have h : env20249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20248_20249 : H12AffineEnvironment.transform 16 24860 env20248 = env20249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env20248 == env20249) = true)

theorem identity20249 : scanCanonicalize (H12AffineFastState.compose env20249 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20249 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20250 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8203,24860,10281,1025,29708,4112,21792,21776,3,8193,17,23809,16401,4096,10280,1285,32,257,21792,16385,513]

theorem envBound20250 : H12AffineFastState.Bounded env20250 := by
  intro p hp
  have h : env20250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20249_20250 : H12AffineEnvironment.transform 5 16 env20249 = env20250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20249 == env20250) = true)

theorem identity20250 : scanCanonicalize (H12AffineFastState.compose env20250 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20250 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20251 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8203,13340,10281,1025,8460,4112,32,16,3,8193,17,2049,5393,4096,10280,1285,32,257,32,5377,513]

theorem envBound20251 : H12AffineFastState.Bounded env20251 := by
  intro p hp
  have h : env20251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20250_20251 : H12AffineEnvironment.transform 13 5376 env20250 = env20251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20250 == env20251) = true)

theorem identity20251 : scanCanonicalize (H12AffineFastState.compose env20251 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound20251 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env20252 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1280,8192,0,8461,8203,8476,10281,1025,8460,1296,32,16,3,8193,17,2049,17,1280,10280,1285,32,257,32,1,513]

theorem envBound20252 : H12AffineFastState.Bounded env20252 := by
  intro p hp
  have h : env20252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20251_20252 : H12AffineEnvironment.transform 11 1280 env20251 = env20252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env20251 == env20252) = true)

theorem identity20252 : scanCanonicalize (H12AffineFastState.compose env20252 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound20252 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20253 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1280,3384,0,3125,3379,3108,1297,1025,3124,1296,32,16,3,3385,17,2049,17,1280,1296,1285,32,257,32,1,513]

theorem envBound20253 : H12AffineFastState.Bounded env20253 := by
  intro p hp
  have h : env20253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20252_20253 : H12AffineEnvironment.transform 12 3384 env20252 = env20253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env20252 == env20253) = true)

theorem identity20253 : scanCanonicalize (H12AffineFastState.compose env20253 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound20253 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20254 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1296,1280,40,0,293,35,308,1297,1025,292,1296,32,16,3,41,17,1297,17,1280,1296,1285,32,257,32,1,513]

theorem envBound20254 : H12AffineFastState.Bounded env20254 := by
  intro p hp
  have h : env20254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20253_20254 : H12AffineEnvironment.transform 10 1296 env20253 = env20254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env20253 == env20254) = true)

theorem identity20254 : scanCanonicalize (H12AffineFastState.compose env20254 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20254 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env20255 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1076,1060,40,0,1,35,16,1077,1025,0,1076,32,16,3,41,17,1077,17,1060,1076,1057,32,37,32,1,513]

theorem envBound20255 : H12AffineFastState.Bounded env20255 := by
  intro p hp
  have h : env20255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20254_20255 : H12AffineEnvironment.transform 7 36 env20254 = env20255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20254 == env20255) = true)

theorem identity20255 : scanCanonicalize (H12AffineFastState.compose env20255 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20255 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20256 : List Nat := [2,4,8,0,32,0,9,36,512,1024,1060,1060,40,0,1,35,0,1061,1025,0,1060,32,0,3,41,1,1061,1,1060,1060,1057,32,37,32,1,513]

theorem envBound20256 : H12AffineFastState.Bounded env20256 := by
  intro p hp
  have h : env20256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20255_20256 : H12AffineEnvironment.transform 3 0 env20255 = env20256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20255 == env20256) = true)

theorem identity20256 : scanCanonicalize (H12AffineFastState.compose env20256 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound20256 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20257 : List Nat := [2,4,8,0,32,0,9,36,512,46,10,10,40,0,1,35,0,11,47,0,10,32,0,3,41,1,11,1,10,10,15,32,37,32,1,513]

theorem envBound20257 : H12AffineFastState.Bounded env20257 := by
  intro p hp
  have h : env20257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20256_20257 : H12AffineEnvironment.transform 9 46 env20256 = env20257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env20256 == env20257) = true)

theorem identity20257 : scanCanonicalize (H12AffineFastState.compose env20257 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound20257 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20258 : List Nat := [2,4,8,0,11,0,9,15,512,5,10,10,3,0,1,8,0,11,4,0,10,11,0,3,2,1,11,1,10,10,15,11,14,11,1,513]

theorem envBound20258 : H12AffineFastState.Bounded env20258 := by
  intro p hp
  have h : env20258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20257_20258 : H12AffineEnvironment.transform 4 11 env20257 = env20258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env20257 == env20258) = true)

theorem identity20258 : scanCanonicalize (H12AffineFastState.compose env20258 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound20258 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20259 : List Nat := [2,4,8,0,11,0,9,15,15,5,10,10,3,0,1,8,0,11,4,0,10,11,0,3,2,1,11,1,10,10,15,11,14,11,1,14]

theorem envBound20259 : H12AffineFastState.Bounded env20259 := by
  intro p hp
  have h : env20259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20258_20259 : H12AffineEnvironment.transform 8 15 env20258 = env20259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env20258 == env20259) = true)

theorem identity20259 : scanCanonicalize (H12AffineFastState.compose env20259 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound20259 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20260 : List Nat := [2,4,3,0,0,0,2,4,4,5,1,1,3,0,1,3,0,0,4,0,1,0,0,3,2,1,0,1,1,1,4,0,5,0,1,5]

theorem envBound20260 : H12AffineFastState.Bounded env20260 := by
  intro p hp
  have h : env20260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20259_20260 : H12AffineEnvironment.transform 2 3 env20259 = env20260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env20259 == env20260) = true)

theorem identity20260 : scanCanonicalize (H12AffineFastState.compose env20260 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound20260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20261 : List Nat := [1,4,0,0,0,0,1,4,4,5,1,1,0,0,1,0,0,0,4,0,1,0,0,0,1,1,0,1,1,1,4,0,5,0,1,5]

theorem envBound20261 : H12AffineFastState.Bounded env20261 := by
  intro p hp
  have h : env20261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20260_20261 : H12AffineEnvironment.transform 0 1 env20260 = env20261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env20260 == env20261) = true)

def env20262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4160,21792,95514,73737,8328,65,256147,46276,77834,236987,119043,168,257,98815,90202,63189]

theorem envBound20262 : H12AffineFastState.Bounded env20262 := by
  intro p hp
  have h : env20262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20232_20262 : H12AffineEnvironment.transform 17 10401 env20232 = env20262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env20232 == env20262) = true)

theorem identity20262 : scanCanonicalize (H12AffineFastState.compose env20262 (packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound20262 : packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env20263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10401,1025,32769,4160,21792,95514,73737,8328,65,68062,46276,77834,97526,119043,168,257,98815,90202,63189]

theorem envBound20263 : H12AffineFastState.Bounded env20263 := by
  intro p hp
  have h : env20263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20262_20263 : H12AffineEnvironment.transform 16 57677 env20262 = env20263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env20262 == env20263) = true)

theorem identity20263 : scanCanonicalize (H12AffineFastState.compose env20263 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound20263 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env20264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,57677,10401,1025,32769,4160,21792,41412,62679,8328,65,56576,46276,58580,43048,1501,168,257,21793,46212,63189]

theorem envBound20264 : H12AffineFastState.Bounded env20264 := by
  intro p hp
  have h : env20264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20263_20264 : H12AffineEnvironment.transform 15 54494 env20263 = env20264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env20263 == env20264) = true)

theorem identity20264 : scanCanonicalize (H12AffineFastState.compose env20264 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound20264 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env20265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33110,46277,10401,1025,32769,4160,168,41412,41311,8328,65,34952,46276,45404,43048,1501,168,257,169,46212,41821]

theorem envBound20265 : H12AffineFastState.Bounded env20265 := by
  intro p hp
  have h : env20265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20264_20265 : H12AffineEnvironment.transform 13 5512 env20264 = env20265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env20264 == env20265) = true)

theorem identity20265 : scanCanonicalize (H12AffineFastState.compose env20265 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20265 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env20266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,46156,10280,1025,32769,4160,33,41293,41311,8193,65,34817,46157,45404,43048,1364,33,257,32,46093,41821]

theorem envBound20266 : H12AffineFastState.Bounded env20266 := by
  intro p hp
  have h : env20266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20265_20266 : H12AffineEnvironment.transform 6 9 env20265 = env20266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20265 == env20266) = true)

theorem identity20266 : scanCanonicalize (H12AffineFastState.compose env20266 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound20266 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env20267 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,32768,33110,45404,10280,273,32769,4160,33,41293,41311,8193,65,34817,45405,45404,43048,68,33,257,32,45341,41821]

theorem envBound20267 : H12AffineFastState.Bounded env20267 := by
  intro p hp
  have h : env20267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20266_20267 : H12AffineEnvironment.transform 9 272 env20266 = env20267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20266 == env20267) = true)

theorem identity20267 : scanCanonicalize (H12AffineFastState.compose env20267 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20267 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20268 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,268,4113,32768,33110,36944,2340,273,32769,4160,33,32833,32851,269,65,34817,36945,36944,35108,68,33,257,32,36881,33361]

theorem envBound20268 : H12AffineFastState.Bounded env20268 := by
  intro p hp
  have h : env20268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20267_20268 : H12AffineEnvironment.transform 12 268 env20267 = env20268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20267 == env20268) = true)

theorem identity20268 : scanCanonicalize (H12AffineFastState.compose env20268 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound20268 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env20269 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,268,4113,260,82,4436,2340,273,261,4160,33,325,343,269,65,2309,4437,4436,2080,68,33,257,32,4373,853]

theorem envBound20269 : H12AffineFastState.Bounded env20269 := by
  intro p hp
  have h : env20269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20268_20269 : H12AffineEnvironment.transform 14 260 env20268 = env20269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env20268 == env20269) = true)

theorem identity20269 : scanCanonicalize (H12AffineFastState.compose env20269 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20269 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env20270 : List Nat := [2,4,8,16,0,64,9,256,512,272,2048,4096,268,4113,260,82,4436,2308,273,261,4160,1,325,343,269,65,2309,4437,4436,2048,68,1,257,0,4373,853]

theorem envBound20270 : H12AffineFastState.Bounded env20270 := by
  intro p hp
  have h : env20270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20269_20270 : H12AffineEnvironment.transform 4 0 env20269 = env20270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20269 == env20270) = true)

theorem identity20270 : scanCanonicalize (H12AffineFastState.compose env20270 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound20270 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20271 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,4096,89,4113,81,82,4097,2129,68,80,4160,1,16,2,88,65,2128,4096,4097,2048,68,1,84,0,4160,512]

theorem envBound20271 : H12AffineFastState.Bounded env20271 := by
  intro p hp
  have h : env20271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20270_20271 : H12AffineEnvironment.transform 7 85 env20270 = env20271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env20270 == env20271) = true)

theorem identity20271 : scanCanonicalize (H12AffineFastState.compose env20271 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound20271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20272 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,17,89,0,81,82,16,2129,68,80,81,1,16,2,88,65,2128,17,16,2048,68,1,84,0,81,512]

theorem envBound20272 : H12AffineFastState.Bounded env20272 := by
  intro p hp
  have h : env20272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20271_20272 : H12AffineEnvironment.transform 11 17 env20271 = env20272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env20271 == env20272) = true)

theorem identity20272 : scanCanonicalize (H12AffineFastState.compose env20272 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound20272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20273 : List Nat := [2,4,8,16,0,64,9,85,512,69,0,17,89,0,81,82,16,81,68,80,81,1,16,2,88,65,80,17,16,0,68,1,84,0,81,512]

theorem envBound20273 : H12AffineFastState.Bounded env20273 := by
  intro p hp
  have h : env20273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20272_20273 : H12AffineEnvironment.transform 10 0 env20272 = env20273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20272 == env20273) = true)

theorem identity20273 : scanCanonicalize (H12AffineFastState.compose env20273 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound20273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20274 : List Nat := [2,0,8,16,0,64,9,81,512,65,0,17,89,0,81,82,16,81,64,80,81,1,16,2,88,65,80,17,16,0,64,1,80,0,81,512]

theorem envBound20274 : H12AffineFastState.Bounded env20274 := by
  intro p hp
  have h : env20274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20273_20274 : H12AffineEnvironment.transform 1 0 env20273 = env20274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env20273 == env20274) = true)

def env20275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21793,351674,329897,8328,65,507955,302181,333995,236986,119043,272392,257,98814,90203,63189]

theorem envBound20275 : H12AffineFastState.Bounded env20275 := by
  intro p hp
  have h : env20275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20231_20275 : H12AffineEnvironment.transform 20 4161 env20231 = env20275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20231 == env20275) = true)

theorem identity20275 : scanCanonicalize (H12AffineFastState.compose env20275 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32161) := by decide +kernel

theorem selectedBound20275 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,21793,73755,95496,8328,65,245138,57796,91402,236986,119043,21929,257,98814,90203,63189]

theorem envBound20276 : H12AffineFastState.Bounded env20276 := by
  intro p hp
  have h : env20276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20275_20276 : H12AffineEnvironment.transform 17 32161 env20275 = env20276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env20275 == env20276) = true)

def env20277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10401,1025,32769,4161,33,73755,73736,8328,65,245138,46276,77834,236986,99331,169,257,98814,79195,41941]

theorem envBound20277 : H12AffineFastState.Bounded env20277 := by
  intro p hp
  have h : env20277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20276_20277 : H12AffineEnvironment.transform 13 5376 env20276 = env20277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20276 == env20277) = true)

theorem identity20277 : scanCanonicalize (H12AffineFastState.compose env20277 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound20277 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,5392,10401,1025,32769,4161,33,73755,73736,8328,65,108674,46276,77834,100522,99331,169,257,98814,79195,41941]

theorem envBound20278 : H12AffineFastState.Bounded env20278 := by
  intro p hp
  have h : env20278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20277_20278 : H12AffineEnvironment.transform 16 5392 env20277 = env20278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env20277 == env20278) = true)

theorem identity20278 : scanCanonicalize (H12AffineFastState.compose env20278 (packedSelected [3,5,8,10,12,15,28,31,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20278 : packedSelected [3,5,8,10,12,15,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env20279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5392,10280,1025,32769,4161,33,73755,73736,8193,65,108555,46157,77834,100387,99331,32,257,98679,79195,41820]

theorem envBound20279 : H12AffineFastState.Bounded env20279 := by
  intro p hp
  have h : env20279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20278_20279 : H12AffineEnvironment.transform 6 9 env20278 = env20279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20278 == env20279) = true)

theorem identity20279 : scanCanonicalize (H12AffineFastState.compose env20279 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound20279 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,5392,10280,1025,32769,4161,33,41292,41311,8193,65,10588,46157,45405,2420,1364,32,257,32,46092,41820]

theorem envBound20280 : H12AffineFastState.Bounded env20280 := by
  intro p hp
  have h : env20280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20279_20280 : H12AffineEnvironment.transform 15 33111 env20279 = env20280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env20279 == env20280) = true)

theorem identity20280 : scanCanonicalize (H12AffineFastState.compose env20280 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound20280 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9293,9498,5392,10280,1025,9292,4161,33,1281,1298,8193,65,10588,4096,5392,2420,1364,32,257,32,4161,1809]

theorem envBound20281 : H12AffineFastState.Bounded env20281 := by
  intro p hp
  have h : env20281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20280_20281 : H12AffineEnvironment.transform 14 9293 env20280 = env20281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env20280 == env20281) = true)

theorem identity20281 : scanCanonicalize (H12AffineFastState.compose env20281 (packedSelected [0,2,6,7,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 3433) := by decide +kernel

theorem selectedBound20281 : packedSelected [0,2,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env20282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3433,5376,2340,2163,5392,1345,1025,2341,4161,33,1281,1298,3432,65,1077,4096,5392,2420,1364,32,257,32,4161,1809]

theorem envBound20282 : H12AffineFastState.Bounded env20282 := by
  intro p hp
  have h : env20282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20281_20282 : H12AffineEnvironment.transform 12 3433 env20281 = env20282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3433 env20281 == env20282) = true)

theorem identity20282 : scanCanonicalize (H12AffineFastState.compose env20282 (packedSelected [0,1,2,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound20282 : packedSelected [0,1,2,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env20283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,49,3433,1329,2340,2163,1313,1345,1025,2341,112,33,1281,1298,3432,65,1077,49,1313,2420,1364,32,257,32,112,1809]

theorem envBound20283 : H12AffineFastState.Bounded env20283 := by
  intro p hp
  have h : env20283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20282_20283 : H12AffineEnvironment.transform 11 49 env20282 = env20283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env20282 == env20283) = true)

theorem identity20283 : scanCanonicalize (H12AffineFastState.compose env20283 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1328) := by decide +kernel

theorem selectedBound20283 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env20284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1328,49,89,1329,1044,1347,1313,1345,1025,1045,112,33,1281,1298,88,65,1077,49,1313,1092,1364,32,257,32,112,1809]

theorem envBound20284 : H12AffineFastState.Bounded env20284 := by
  intro p hp
  have h : env20284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20283_20284 : H12AffineEnvironment.transform 10 1328 env20283 = env20284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1328 env20283 == env20284) = true)

theorem identity20284 : scanCanonicalize (H12AffineFastState.compose env20284 (packedSelected [2,4,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound20284 : packedSelected [2,4,9,11] rootPS < 2^1333 := by decide +kernel

def env20285 : List Nat := [2,4,8,16,32,64,9,256,512,305,1,49,89,0,293,114,16,112,304,292,112,33,48,35,88,65,260,49,16,373,101,32,257,32,112,544]

theorem envBound20285 : H12AffineFastState.Bounded env20285 := by
  intro p hp
  have h : env20285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20284_20285 : H12AffineEnvironment.transform 9 305 env20284 = env20285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env20284 == env20285) = true)

def env20286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10400,1025,32769,4161,32,73755,73737,8328,65,245138,46277,77835,236986,99330,168,257,98814,79194,41940]

theorem envBound20286 : H12AffineFastState.Bounded env20286 := by
  intro p hp
  have h : env20286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20276_20286 : H12AffineEnvironment.transform 13 5377 env20276 = env20286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20276 == env20286) = true)

theorem identity20286 : scanCanonicalize (H12AffineFastState.compose env20286 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20286 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1025,32769,4161,32,73755,73737,8193,65,245019,46156,77835,236851,99330,33,257,98679,79194,41821]

theorem envBound20287 : H12AffineFastState.Bounded env20287 := by
  intro p hp
  have h : env20287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20286_20287 : H12AffineEnvironment.transform 6 9 env20286 = env20287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20286 == env20287) = true)

theorem identity20287 : scanCanonicalize (H12AffineFastState.compose env20287 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20287 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1025,8541,4161,32,73755,73737,8193,65,203847,5392,77835,212079,75102,33,257,73771,79194,513]

theorem envBound20288 : H12AffineFastState.Bounded env20288 := by
  intro p hp
  have h : env20288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20287_20288 : H12AffineEnvironment.transform 14 8540 env20287 = env20288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20287 == env20288) = true)

theorem identity20288 : scanCanonicalize (H12AffineFastState.compose env20288 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound20288 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env20289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8282,131072,10281,1025,8541,4161,32,65,83,8193,65,146461,5392,4177,138293,1284,33,257,113,5376,513]

theorem envBound20289 : H12AffineFastState.Bounded env20289 := by
  intro p hp
  have h : env20289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20288_20289 : H12AffineEnvironment.transform 15 8282 env20288 = env20289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env20288 == env20289) = true)

theorem identity20289 : scanCanonicalize (H12AffineFastState.compose env20289 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound20289 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env20290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8282,5440,10281,1025,8541,4161,32,65,83,8193,65,10589,5392,4177,2421,1284,33,257,113,5376,513]

theorem envBound20290 : H12AffineFastState.Bounded env20290 := by
  intro p hp
  have h : env20290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20289_20290 : H12AffineEnvironment.transform 16 5440 env20289 = env20290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env20289 == env20290) = true)

theorem identity20290 : scanCanonicalize (H12AffineFastState.compose env20290 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20290 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,342,5440,2341,1025,81,4161,32,65,83,269,65,2129,5392,4177,2421,1284,33,257,113,5376,513]

theorem envBound20291 : H12AffineFastState.Bounded env20291 := by
  intro p hp
  have h : env20291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20290_20291 : H12AffineEnvironment.transform 12 268 env20290 = env20291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20290 == env20291) = true)

theorem identity20291 : scanCanonicalize (H12AffineFastState.compose env20291 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2415) := by decide +kernel

theorem selectedBound20291 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2415,268,3182,80,342,3119,2341,1025,81,2350,32,65,83,269,65,2129,3199,2366,2421,1284,33,257,113,3183,513]

theorem envBound20292 : H12AffineFastState.Bounded env20292 := by
  intro p hp
  have h : env20292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20291_20292 : H12AffineEnvironment.transform 11 2415 env20291 = env20292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2415 env20291 == env20292) = true)

def env20293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,2431209,8328,65,2609267,302180,333995,2330107,119042,2373704,257,2199998,2191387,63188]

theorem envBound20293 : H12AffineFastState.Bounded env20293 := by
  intro p hp
  have h : env20293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20230_20293 : H12AffineEnvironment.transform 23 2431209 env20230 = env20293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431209 env20230 == env20293) = true)

def env20294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21792,351675,329897,8328,65,507955,302180,333995,236987,119042,272392,257,98814,90203,63188]

theorem envBound20294 : H12AffineFastState.Bounded env20294 := by
  intro p hp
  have h : env20294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20293_20294 : H12AffineEnvironment.transform 20 4160 env20293 = env20294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20293 == env20294) = true)

theorem identity20294 : scanCanonicalize (H12AffineFastState.compose env20294 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound20294 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,4160,21792,120014,98780,8328,65,215366,5393,102878,236987,119042,41341,257,98814,90203,63188]

theorem envBound20295 : H12AffineFastState.Bounded env20295 := by
  intro p hp
  have h : env20295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20294_20295 : H12AffineEnvironment.transform 17 35189 env20294 = env20295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env20294 == env20295) = true)

def env20296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10401,1025,8661,4160,21792,95514,73736,8328,65,215366,5393,77834,212079,94422,169,257,73770,90203,22272]

theorem envBound20296 : H12AffineFastState.Bounded env20296 := by
  intro p hp
  have h : env20296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20295_20296 : H12AffineEnvironment.transform 14 8660 env20295 = env20296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env20295 == env20296) = true)

theorem identity20296 : scanCanonicalize (H12AffineFastState.compose env20296 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20296 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,131072,10401,1025,8661,4160,21792,21776,2,8328,65,158028,5393,4096,138341,20700,169,257,32,16465,22272]

theorem envBound20297 : H12AffineFastState.Bounded env20297 := by
  intro p hp
  have h : env20297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20296_20297 : H12AffineEnvironment.transform 15 8202 env20296 = env20297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20296 == env20297) = true)

theorem identity20297 : scanCanonicalize (H12AffineFastState.compose env20297 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound20297 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env20298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,8660,8202,131072,10401,1025,8661,4160,248,200,2,8328,65,146580,5393,4096,138341,1284,169,257,32,5513,728]

theorem envBound20298 : H12AffineFastState.Bounded env20298 := by
  intro p hp
  have h : env20298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20297_20298 : H12AffineEnvironment.transform 13 5592 env20297 = env20298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env20297 == env20298) = true)

theorem identity20298 : scanCanonicalize (H12AffineFastState.compose env20298 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20298 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env20299 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5292,8352,8202,131072,10401,1025,8353,4160,248,200,2,8328,65,146580,5221,4096,138341,1136,169,117,32,5373,728]

theorem envBound20299 : H12AffineFastState.Bounded env20299 := by
  intro p hp
  have h : env20299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20298_20299 : H12AffineEnvironment.transform 7 116 env20298 = env20299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20298 == env20299) = true)

theorem identity20299 : scanCanonicalize (H12AffineFastState.compose env20299 (packedSelected [0,1,2,3,5,6,7,8,10,11,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20299 : packedSelected [0,1,2,3,5,6,7,8,10,11,19,20,23] rootPS < 2^1333 := by decide +kernel

def env20300 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5292,137,35,131072,2184,1025,136,4160,248,200,2,161,65,138429,5221,4096,138341,1136,169,117,32,5373,728]

theorem envBound20300 : H12AffineFastState.Bounded env20300 := by
  intro p hp
  have h : env20300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20299_20300 : H12AffineEnvironment.transform 12 41 env20299 = env20300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20299 == env20300) = true)

theorem identity20300 : scanCanonicalize (H12AffineFastState.compose env20300 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20300 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env20301 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,41,5292,137,35,131072,2184,1025,136,4112,168,152,2,161,17,138429,5173,4096,138293,1056,169,37,32,5293,648]

theorem envBound20301 : H12AffineFastState.Bounded env20301 := by
  intro p hp
  have h : env20301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20300_20301 : H12AffineEnvironment.transform 5 16 env20300 = env20301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20300 == env20301) = true)

theorem identity20301 : scanCanonicalize (H12AffineFastState.compose env20301 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5277) := by decide +kernel

theorem selectedBound20301 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20302 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,41,5292,137,35,5277,2184,1025,136,4112,168,152,2,161,17,2080,5173,4096,2216,1056,169,37,32,5293,648]

theorem envBound20302 : H12AffineFastState.Bounded env20302 := by
  intro p hp
  have h : env20302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20301_20302 : H12AffineEnvironment.transform 16 5277 env20301 = env20302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5277 env20301 == env20302) = true)

theorem identity20302 : scanCanonicalize (H12AffineFastState.compose env20302 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20302 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20303 : List Nat := [2,4,8,16,0,16,128,4,512,1024,2048,4096,9,5260,137,3,5277,2184,1025,136,4112,136,152,2,129,17,2048,5141,4096,2184,1024,137,5,0,5261,648]

theorem envBound20303 : H12AffineFastState.Bounded env20303 := by
  intro p hp
  have h : env20303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20302_20303 : H12AffineEnvironment.transform 4 0 env20302 = env20303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20302 == env20303) = true)

theorem identity20303 : scanCanonicalize (H12AffineFastState.compose env20303 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound20303 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20304 : List Nat := [2,4,8,16,0,16,128,4,512,1024,2048,0,9,1164,137,3,1181,2184,1025,136,16,136,152,2,129,17,2048,1045,0,2184,1024,137,5,0,1165,648]

theorem envBound20304 : H12AffineFastState.Bounded env20304 := by
  intro p hp
  have h : env20304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20303_20304 : H12AffineEnvironment.transform 11 0 env20303 = env20304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env20303 == env20304) = true)

theorem identity20304 : scanCanonicalize (H12AffineFastState.compose env20304 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 157) := by decide +kernel

theorem selectedBound20304 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20305 : List Nat := [2,4,8,16,0,16,128,4,512,157,2048,0,9,17,137,3,0,2184,156,136,16,136,152,2,129,17,2048,136,0,2184,157,137,5,0,16,648]

theorem envBound20305 : H12AffineFastState.Bounded env20305 := by
  intro p hp
  have h : env20305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20304_20305 : H12AffineEnvironment.transform 9 157 env20304 = env20305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env20304 == env20305) = true)

theorem identity20305 : scanCanonicalize (H12AffineFastState.compose env20305 (packedSelected [3,5,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound20305 : packedSelected [3,5,11,12] rootPS < 2^1333 := by decide +kernel

def env20306 : List Nat := [2,4,8,16,0,16,128,4,512,157,16,0,9,17,137,3,0,152,156,136,16,136,152,2,129,17,16,136,0,152,157,137,5,0,16,648]

theorem envBound20306 : H12AffineFastState.Bounded env20306 := by
  intro p hp
  have h : env20306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20305_20306 : H12AffineEnvironment.transform 10 16 env20305 = env20306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env20305 == env20306) = true)

theorem identity20306 : scanCanonicalize (H12AffineFastState.compose env20306 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20306 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20307 : List Nat := [2,4,8,16,0,16,9,4,512,20,16,0,9,17,0,3,0,17,21,1,16,1,17,2,8,17,16,1,0,17,20,0,5,0,16,513]

theorem envBound20307 : H12AffineFastState.Bounded env20307 := by
  intro p hp
  have h : env20307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20306_20307 : H12AffineEnvironment.transform 6 9 env20306 = env20307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20306 == env20307) = true)

theorem identity20307 : scanCanonicalize (H12AffineFastState.compose env20307 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20308 : List Nat := [2,1,8,16,0,16,9,1,512,17,16,0,9,17,0,3,0,17,16,1,16,1,17,2,8,17,16,1,0,17,17,0,0,0,16,513]

theorem envBound20308 : H12AffineFastState.Bounded env20308 := by
  intro p hp
  have h : env20308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20307_20308 : H12AffineEnvironment.transform 1 1 env20307 = env20308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20307 == env20308) = true)

theorem identity20308 : scanCanonicalize (H12AffineFastState.compose env20308 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound20308 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20309 : List Nat := [2,1,8,16,0,16,9,1,8,17,16,0,9,17,0,3,0,17,16,1,16,1,17,2,8,17,16,1,0,17,17,0,0,0,16,9]

theorem envBound20309 : H12AffineFastState.Bounded env20309 := by
  intro p hp
  have h : env20309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20308_20309 : H12AffineEnvironment.transform 8 8 env20308 = env20309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env20308 == env20309) = true)

theorem identity20309 : scanCanonicalize (H12AffineFastState.compose env20309 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound20309 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20310 : List Nat := [2,1,8,10,0,10,9,1,8,11,10,0,9,11,0,3,0,11,10,1,10,1,11,2,8,11,10,1,0,11,11,0,0,0,10,9]

theorem envBound20310 : H12AffineFastState.Bounded env20310 := by
  intro p hp
  have h : env20310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20309_20310 : H12AffineEnvironment.transform 3 10 env20309 = env20310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env20309 == env20310) = true)

theorem identity20310 : scanCanonicalize (H12AffineFastState.compose env20310 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound20310 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20311 : List Nat := [2,1,0,2,0,2,1,1,0,3,2,0,1,3,0,3,0,3,2,1,2,1,3,2,0,3,2,1,0,3,3,0,0,0,2,1]

theorem envBound20311 : H12AffineFastState.Bounded env20311 := by
  intro p hp
  have h : env20311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20310_20311 : H12AffineEnvironment.transform 2 0 env20310 = env20311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env20310 == env20311) = true)

theorem identity20311 : scanCanonicalize (H12AffineFastState.compose env20311 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound20311 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20312 : List Nat := [1,1,0,1,0,1,1,1,0,0,1,0,1,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,0,0,0,0,0,1,1]

theorem envBound20312 : H12AffineFastState.Bounded env20312 := by
  intro p hp
  have h : env20312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20311_20312 : H12AffineEnvironment.transform 0 1 env20311 = env20312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env20311 == env20312) = true)

def env20313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10400,1025,8660,4160,21792,95515,73737,8328,65,215366,5393,77835,212078,94423,168,257,73771,90203,22273]

theorem envBound20313 : H12AffineFastState.Bounded env20313 := by
  intro p hp
  have h : env20313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20295_20313 : H12AffineEnvironment.transform 14 8661 env20295 = env20313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env20295 == env20313) = true)

theorem identity20313 : scanCanonicalize (H12AffineFastState.compose env20313 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound20313 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,65536,131072,10400,1025,8660,4160,169,73874,73737,8328,65,203983,5393,77835,212078,75102,168,257,73771,79314,648]

theorem envBound20314 : H12AffineFastState.Bounded env20314 := by
  intro p hp
  have h : env20314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20313_20314 : H12AffineEnvironment.transform 13 5513 env20313 = env20314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env20313 == env20314) = true)

theorem identity20314 : scanCanonicalize (H12AffineFastState.compose env20314 (packedSelected [0,1,2,3,4,6,7,9,11,14,16,20,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound20314 : packedSelected [0,1,2,3,4,6,7,9,11,14,16,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env20315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,262,131072,10400,1025,8660,4160,169,8596,8463,8328,65,138697,5393,12557,146792,9304,168,257,8493,13524,648]

theorem envBound20315 : H12AffineFastState.Bounded env20315 := by
  intro p hp
  have h : env20315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20314_20315 : H12AffineEnvironment.transform 15 262 env20314 = env20315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env20314 == env20315) = true)

theorem identity20315 : scanCanonicalize (H12AffineFastState.compose env20315 (packedSelected [0,1,3,5,7,8,9,10,11,14,16,19,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound20315 : packedSelected [0,1,3,5,7,8,9,10,11,14,16,19,22,23] rootPS < 2^1333 := by decide +kernel

def env20316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,262,5528,10400,1025,8660,4160,169,8596,8463,8328,65,2129,5393,12557,10480,9304,168,257,8493,13524,648]

theorem envBound20316 : H12AffineFastState.Bounded env20316 := by
  intro p hp
  have h : env20316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20315_20316 : H12AffineEnvironment.transform 16 5528 env20315 = env20316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env20315 == env20316) = true)

theorem identity20316 : scanCanonicalize (H12AffineFastState.compose env20316 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20316 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env20317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,217,262,5528,2476,1025,216,4160,169,152,3,388,65,2129,5393,4097,2556,1364,168,257,33,5592,648]

theorem envBound20317 : H12AffineFastState.Bounded env20317 := by
  intro p hp
  have h : env20317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20316_20317 : H12AffineEnvironment.transform 12 268 env20316 = env20317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20316 == env20317) = true)

theorem identity20317 : scanCanonicalize (H12AffineFastState.compose env20317 (packedSelected [1,4,6,8,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound20317 : packedSelected [1,4,6,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env20318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3156,268,2525,217,262,2508,2476,1025,216,3092,169,152,3,388,65,2129,2373,3157,2556,1364,168,257,33,2444,648]

theorem envBound20318 : H12AffineFastState.Bounded env20318 := by
  intro p hp
  have h : env20318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20317_20318 : H12AffineEnvironment.transform 11 3156 env20317 = env20318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env20317 == env20318) = true)

theorem identity20318 : scanCanonicalize (H12AffineFastState.compose env20318 (packedSelected [11,12] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound20318 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env20319 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,3156,209,2048,217,219,2065,2161,1025,216,3092,169,152,3,89,65,2129,2200,3157,2081,1161,168,220,33,2129,648]

theorem envBound20319 : H12AffineFastState.Bounded env20319 := by
  intro p hp
  have h : env20319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20318_20319 : H12AffineEnvironment.transform 7 221 env20318 = env20319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env20318 == env20319) = true)

theorem identity20319 : scanCanonicalize (H12AffineFastState.compose env20319 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20319 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env20320 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,3156,88,2048,80,82,2065,2161,1025,81,3092,32,17,3,89,65,2129,2065,3157,2081,1024,33,85,33,2129,513]

theorem envBound20320 : H12AffineFastState.Bounded env20320 := by
  intro p hp
  have h : env20320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20319_20320 : H12AffineEnvironment.transform 6 9 env20319 = env20320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20319 == env20320) = true)

theorem identity20320 : scanCanonicalize (H12AffineFastState.compose env20320 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound20320 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env20321 : List Nat := [2,4,8,16,32,64,9,84,512,1024,75,1055,88,75,80,82,90,58,1025,81,1119,32,17,3,89,65,26,90,1054,106,1024,33,85,33,26,513]

theorem envBound20321 : H12AffineFastState.Bounded env20321 := by
  intro p hp
  have h : env20321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20320_20321 : H12AffineEnvironment.transform 10 75 env20320 = env20321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env20320 == env20321) = true)

theorem identity20321 : scanCanonicalize (H12AffineFastState.compose env20321 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound20321 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20322 : List Nat := [2,4,8,16,32,64,9,84,512,581,75,602,88,75,80,82,90,58,580,81,538,32,17,3,89,65,26,90,603,106,581,33,85,33,26,513]

theorem envBound20322 : H12AffineFastState.Bounded env20322 := by
  intro p hp
  have h : env20322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20321_20322 : H12AffineEnvironment.transform 9 581 env20321 = env20322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env20321 == env20322) = true)

theorem identity20322 : scanCanonicalize (H12AffineFastState.compose env20322 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound20322 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env20323 : List Nat := [2,4,8,16,32,32,9,52,512,549,43,570,56,43,48,50,58,58,548,49,538,32,17,3,57,33,26,58,571,10,549,33,53,33,26,513]

theorem envBound20323 : H12AffineFastState.Bounded env20323 := by
  intro p hp
  have h : env20323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20322_20323 : H12AffineEnvironment.transform 5 32 env20322 = env20323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env20322 == env20323) = true)

theorem identity20323 : scanCanonicalize (H12AffineFastState.compose env20323 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound20323 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20324 : List Nat := [2,4,8,16,17,17,9,5,512,532,26,523,9,26,1,3,11,11,533,0,538,17,17,3,8,16,26,11,522,10,532,16,4,16,26,513]

theorem envBound20324 : H12AffineFastState.Bounded env20324 := by
  intro p hp
  have h : env20324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20323_20324 : H12AffineEnvironment.transform 4 17 env20323 = env20324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env20323 == env20324) = true)

theorem identity20324 : scanCanonicalize (H12AffineFastState.compose env20324 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound20324 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20325 : List Nat := [2,4,8,10,11,11,9,5,512,526,0,523,9,0,1,3,11,11,527,0,512,11,11,3,8,10,0,11,522,10,526,10,4,10,0,513]

theorem envBound20325 : H12AffineFastState.Bounded env20325 := by
  intro p hp
  have h : env20325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20324_20325 : H12AffineEnvironment.transform 3 10 env20324 = env20325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env20324 == env20325) = true)

theorem identity20325 : scanCanonicalize (H12AffineFastState.compose env20325 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound20325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20326 : List Nat := [2,4,1,3,2,2,0,5,512,519,0,514,0,0,1,3,2,2,518,0,512,2,2,3,1,3,0,2,515,3,519,3,4,3,0,513]

theorem envBound20326 : H12AffineFastState.Bounded env20326 := by
  intro p hp
  have h : env20326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20325_20326 : H12AffineEnvironment.transform 2 1 env20325 = env20326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env20325 == env20326) = true)

def env20327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21793,351674,329896,8328,65,507954,302180,333995,236986,119042,272393,257,98815,90202,63188]

theorem envBound20327 : H12AffineFastState.Bounded env20327 := by
  intro p hp
  have h : env20327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20293_20327 : H12AffineEnvironment.transform 20 4161 env20293 = env20327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20293 == env20327) = true)

theorem identity20327 : scanCanonicalize (H12AffineFastState.compose env20327 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound20327 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,21793,351674,329896,8328,65,472295,288945,333995,223599,75223,272393,257,95530,90202,513]

theorem envBound20328 : H12AffineFastState.Bounded env20328 := by
  intro p hp
  have h : env20328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20327_20328 : H12AffineEnvironment.transform 14 29909 env20327 = env20328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env20327 == env20328) = true)

def env20329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,21793,351538,329760,8192,65,472175,288825,333859,223599,75103,272393,257,95530,90202,513]

theorem envBound20329 : H12AffineFastState.Bounded env20329 := by
  intro p hp
  have h : env20329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20328_20329 : H12AffineEnvironment.transform 6 8 env20328 = env20329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20328 == env20329) = true)

theorem identity20329 : scanCanonicalize (H12AffineFastState.compose env20329 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20329 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1025,29788,4161,21793,351538,329760,8192,65,283765,288825,333859,2421,75103,272393,257,95530,90202,513]

theorem envBound20330 : H12AffineFastState.Bounded env20330 := by
  intro p hp
  have h : env20330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20329_20330 : H12AffineEnvironment.transform 16 90138 env20329 = env20330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20329 == env20330) = true)

theorem identity20330 : scanCanonicalize (H12AffineFastState.compose env20330 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 77131) := by decide +kernel

theorem selectedBound20330 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env20331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90138,77131,1025,29788,4161,21793,28793,9579,8192,65,96574,83314,13672,2421,75103,66882,257,95530,90202,513]

theorem envBound20331 : H12AffineFastState.Bounded env20331 := by
  intro p hp
  have h : env20331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20330_20331 : H12AffineEnvironment.transform 17 77131 env20330 = env20331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 77131 env20330 == env20331) = true)

theorem identity20331 : scanCanonicalize (H12AffineFastState.compose env20331 (packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound20331 : packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env20332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,9499,17665,2128,1025,29788,4161,21793,28793,9579,8192,65,23589,24681,13672,2421,68,8281,257,20529,17729,513]

theorem envBound20332 : H12AffineFastState.Bounded env20332 := by
  intro p hp
  have h : env20332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20331_20332 : H12AffineEnvironment.transform 15 9499 env20331 = env20332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env20331 == env20332) = true)

theorem identity20332 : scanCanonicalize (H12AffineFastState.compose env20332 (packedSelected [3,5,7,10,14,15,18,20,23,27,41] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20332 : packedSelected [3,5,7,10,14,15,18,20,23,27,41] rootPS < 2^1333 := by decide +kernel

def env20333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9499,4096,2128,1025,8541,4161,32,9592,9579,8192,65,2340,13672,13672,2421,68,8281,257,1328,4160,513]

theorem envBound20333 : H12AffineFastState.Bounded env20333 := by
  intro p hp
  have h : env20333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20332_20333 : H12AffineEnvironment.transform 13 5377 env20332 = env20333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20332 == env20333) = true)

theorem identity20333 : scanCanonicalize (H12AffineFastState.compose env20333 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound20333 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20334 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4112,8540,8202,4096,2128,272,8541,4161,32,8297,8314,8192,65,2340,12409,12409,2421,68,8281,257,33,4160,513]

theorem envBound20334 : H12AffineFastState.Bounded env20334 := by
  intro p hp
  have h : env20334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20333_20334 : H12AffineEnvironment.transform 9 273 env20333 = env20334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20333 == env20334) = true)

theorem identity20334 : scanCanonicalize (H12AffineFastState.compose env20334 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound20334 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20335 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,309,8192,293,8540,8202,309,2128,272,8541,372,32,8297,8314,8192,65,2340,8524,8524,2421,68,8281,257,33,373,513]

theorem envBound20335 : H12AffineFastState.Bounded env20335 := by
  intro p hp
  have h : env20335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20334_20335 : H12AffineEnvironment.transform 11 309 env20334 = env20335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env20334 == env20335) = true)

theorem identity20335 : scanCanonicalize (H12AffineFastState.compose env20335 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20335 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20336 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,309,120,293,292,114,309,2128,272,293,372,32,17,2,120,65,2340,308,308,2421,68,33,257,33,373,513]

theorem envBound20336 : H12AffineFastState.Bounded env20336 := by
  intro p hp
  have h : env20336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20335_20336 : H12AffineEnvironment.transform 12 120 env20335 = env20336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20335 == env20336) = true)

theorem identity20336 : scanCanonicalize (H12AffineFastState.compose env20336 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound20336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20337 : List Nat := [2,4,8,16,32,49,8,256,512,273,2048,309,9,293,292,3,309,2081,272,293,261,32,17,2,9,48,2340,308,308,2308,53,33,257,33,260,513]

theorem envBound20337 : H12AffineFastState.Bounded env20337 := by
  intro p hp
  have h : env20337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20336_20337 : H12AffineEnvironment.transform 5 49 env20336 = env20337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env20336 == env20337) = true)

theorem identity20337 : scanCanonicalize (H12AffineFastState.compose env20337 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20337 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20338 : List Nat := [2,4,8,16,1,16,8,256,512,273,2048,276,9,260,261,3,276,2048,272,260,261,1,17,2,9,17,2309,277,277,2308,20,0,257,0,260,513]

theorem envBound20338 : H12AffineFastState.Bounded env20338 := by
  intro p hp
  have h : env20338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20337_20338 : H12AffineEnvironment.transform 4 1 env20337 = env20338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20337 == env20338) = true)

theorem identity20338 : scanCanonicalize (H12AffineFastState.compose env20338 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20338 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20339 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,17,9,1,0,3,17,2048,21,1,0,1,17,2,9,17,2048,16,16,2049,20,0,4,0,1,513]

theorem envBound20339 : H12AffineFastState.Bounded env20339 := by
  intro p hp
  have h : env20339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20338_20339 : H12AffineEnvironment.transform 7 5 env20338 = env20339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20338 == env20339) = true)

def env20340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,21793,351539,329761,8193,65,472174,288824,333858,223599,75102,272393,257,95530,90202,513]

theorem envBound20340 : H12AffineFastState.Bounded env20340 := by
  intro p hp
  have h : env20340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20328_20340 : H12AffineEnvironment.transform 6 9 env20328 = env20340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20328 == env20340) = true)

theorem identity20340 : scanCanonicalize (H12AffineFastState.compose env20340 (packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound20340 : packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env20341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,138293,1025,29789,4161,21793,213254,201748,8193,65,75867,160781,197655,223599,75102,144444,257,95530,90202,513]

theorem envBound20341 : H12AffineFastState.Bounded env20341 := by
  intro p hp
  have h : env20341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20340_20341 : H12AffineEnvironment.transform 17 138293 env20340 = env20341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env20340 == env20341) = true)

theorem identity20341 : scanCanonicalize (H12AffineFastState.compose env20341 (packedSelected [0,2,3,5,6,7,10,12,15,19,20,26] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound20341 : packedSelected [0,2,3,5,6,7,10,12,15,19,20,26] rootPS < 2^1333 := by decide +kernel

def env20342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,24861,32040,1025,29789,4161,21793,73755,95497,8193,65,75867,5392,91402,67698,75102,21793,257,95530,90202,513]

theorem envBound20342 : H12AffineFastState.Bounded env20342 := by
  intro p hp
  have h : env20342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20341_20342 : H12AffineEnvironment.transform 16 24861 env20341 = env20342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env20341 == env20342) = true)

theorem identity20342 : scanCanonicalize (H12AffineFastState.compose env20342 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20342 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,24861,32040,1025,29789,4161,21793,16,21762,8193,65,2128,5392,17665,10361,1365,21793,257,21793,16465,513]

theorem envBound20343 : H12AffineFastState.Bounded env20343 := by
  intro p hp
  have h : env20343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20342_20343 : H12AffineEnvironment.transform 15 8203 env20342 = env20343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20342 == env20343) = true)

theorem identity20343 : scanCanonicalize (H12AffineFastState.compose env20343 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound20343 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,81,8203,5392,2341,1025,80,4161,8492,16,8463,8193,65,2128,5392,12556,10361,1365,8492,257,8492,13404,513]

theorem envBound20344 : H12AffineFastState.Bounded env20344 := by
  intro p hp
  have h : env20344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20343_20344 : H12AffineEnvironment.transform 13 13325 env20343 = env20344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env20343 == env20344) = true)

theorem identity20344 : scanCanonicalize (H12AffineFastState.compose env20344 (packedSelected [1,2,3,5,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 3385) := by decide +kernel

theorem selectedBound20344 : packedSelected [1,2,3,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3385,6452,81,3378,5392,2341,1025,80,4161,3093,16,3126,3384,65,2128,5392,7221,1344,1365,3093,257,3093,6501,513]

theorem envBound20345 : H12AffineFastState.Bounded env20345 := by
  intro p hp
  have h : env20345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20344_20345 : H12AffineEnvironment.transform 12 3385 env20344 = env20345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3385 env20344 == env20345) = true)

theorem identity20345 : scanCanonicalize (H12AffineFastState.compose env20345 (packedSelected [0,1,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20345 : packedSelected [0,1,8,9] rootPS < 2^1333 := by decide +kernel

def env20346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,4096,120,5237,81,115,5392,1124,1025,80,4161,340,16,375,121,65,1297,5392,4468,1344,1365,340,257,340,5156,513]

theorem envBound20346 : H12AffineFastState.Bounded env20346 := by
  intro p hp
  have h : env20346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20345_20346 : H12AffineEnvironment.transform 10 1345 env20345 = env20346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env20345 == env20346) = true)

theorem identity20346 : scanCanonicalize (H12AffineFastState.compose env20346 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound20346 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env20347 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1076,4096,120,5237,81,115,5221,1124,1025,80,4161,33,16,2,121,65,1124,5221,4097,1077,1056,33,116,33,5156,513]

theorem envBound20347 : H12AffineFastState.Bounded env20347 := by
  intro p hp
  have h : env20347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20346_20347 : H12AffineEnvironment.transform 7 117 env20346 = env20347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env20346 == env20347) = true)

theorem identity20347 : scanCanonicalize (H12AffineFastState.compose env20347 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound20347 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env20348 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1076,10,120,1151,81,115,1135,1124,1025,80,75,33,16,2,121,65,1124,1135,11,1077,1056,33,116,33,1070,513]

theorem envBound20348 : H12AffineFastState.Bounded env20348 := by
  intro p hp
  have h : env20348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20347_20348 : H12AffineEnvironment.transform 11 10 env20347 = env20348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env20347 == env20348) = true)

theorem identity20348 : scanCanonicalize (H12AffineFastState.compose env20348 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound20348 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20349 : List Nat := [2,4,8,16,32,64,9,117,512,101,81,10,120,26,81,115,10,1,100,80,75,33,16,2,121,65,1,10,11,80,69,33,116,33,75,513]

theorem envBound20349 : H12AffineFastState.Bounded env20349 := by
  intro p hp
  have h : env20349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20348_20349 : H12AffineEnvironment.transform 9 101 env20348 = env20349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env20348 == env20349) = true)

theorem identity20349 : scanCanonicalize (H12AffineFastState.compose env20349 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound20349 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env20350 : List Nat := [2,4,8,16,32,64,9,117,39,101,81,10,120,26,81,115,10,1,100,80,75,33,16,2,121,65,1,10,11,80,69,33,116,33,75,38]

theorem envBound20350 : H12AffineFastState.Bounded env20350 := by
  intro p hp
  have h : env20350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20349_20350 : H12AffineEnvironment.transform 8 39 env20349 = env20350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env20349 == env20350) = true)

theorem identity20350 : scanCanonicalize (H12AffineFastState.compose env20350 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20350 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20351 : List Nat := [2,4,8,0,32,64,9,101,39,101,65,10,104,10,65,99,10,1,100,64,75,33,0,2,105,65,1,10,11,64,69,33,100,33,75,38]

theorem envBound20351 : H12AffineFastState.Bounded env20351 := by
  intro p hp
  have h : env20351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20350_20351 : H12AffineEnvironment.transform 3 0 env20350 = env20351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20350 == env20351) = true)

theorem identity20351 : scanCanonicalize (H12AffineFastState.compose env20351 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound20351 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20352 : List Nat := [2,4,1,0,32,64,0,101,39,101,65,3,97,3,65,99,3,1,100,64,66,33,0,2,96,65,1,3,2,64,69,33,100,33,66,38]

theorem envBound20352 : H12AffineFastState.Bounded env20352 := by
  intro p hp
  have h : env20352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20351_20352 : H12AffineEnvironment.transform 2 1 env20351 = env20352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env20351 == env20352) = true)

def env20353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,16777216,8328,65,16959643,18973837,333995,2330107,19188203,16851104,257,17074519,17066226,19263037]

theorem envBound20353 : H12AffineFastState.Bounded env20353 := by
  intro p hp
  have h : env20353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20229_20353 : H12AffineEnvironment.transform 21 2114913 env20229 = env20353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env20229 == env20353) = true)

def env20354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,2431208,8328,65,2609267,302181,333995,2330107,119043,2373704,257,2199999,2191386,63189]

theorem envBound20354 : H12AffineFastState.Bounded env20354 := by
  intro p hp
  have h : env20354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20353_20354 : H12AffineEnvironment.transform 23 2431208 env20353 = env20354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431208 env20353 == env20354) = true)

def env20355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21793,351675,329896,8328,65,507955,302181,333995,236987,119043,272392,257,98815,90202,63189]

theorem envBound20355 : H12AffineFastState.Bounded env20355 := by
  intro p hp
  have h : env20355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20354_20355 : H12AffineEnvironment.transform 20 4160 env20354 = env20355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20354 == env20355) = true)

theorem identity20355 : scanCanonicalize (H12AffineFastState.compose env20355 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89514) := by decide +kernel

theorem selectedBound20355 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89514,1025,32769,4160,21793,17,21762,8328,65,171417,115151,17665,236987,119043,95650,257,98815,90202,63189]

theorem envBound20356 : H12AffineFastState.Bounded env20356 := by
  intro p hp
  have h : env20356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20355_20356 : H12AffineEnvironment.transform 17 89514 env20355 = env20356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89514 env20355 == env20356) = true)

def env20357 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,4160,21793,17,21762,8192,65,171281,115015,17665,236851,119043,95530,257,98679,90202,63069]

theorem envBound20357 : H12AffineFastState.Bounded env20357 := by
  intro p hp
  have h : env20357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20356_20357 : H12AffineEnvironment.transform 6 8 env20356 = env20357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20356 == env20357) = true)

theorem identity20357 : scanCanonicalize (H12AffineFastState.compose env20357 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20357 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20358 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1025,32769,4160,33,17,2,8192,65,171281,103495,4097,236851,99331,73770,257,98679,79194,41821]

theorem envBound20358 : H12AffineFastState.Bounded env20358 := by
  intro p hp
  have h : env20358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20357_20358 : H12AffineEnvironment.transform 13 5376 env20357 = env20358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20357 == env20358) = true)

theorem identity20358 : scanCanonicalize (H12AffineFastState.compose env20358 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound20358 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env20359 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,342,131072,2420,1025,32769,4160,33,17,2,8192,65,171281,38161,4097,171109,34133,8572,257,32801,13324,41821]

theorem envBound20359 : H12AffineFastState.Bounded env20359 := by
  intro p hp
  have h : env20359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20358_20359 : H12AffineEnvironment.transform 15 342 env20358 = env20359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env20358 == env20359) = true)

theorem identity20359 : scanCanonicalize (H12AffineFastState.compose env20359 (packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20359 : packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env20360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,342,131072,2420,1025,1,4160,33,17,2,8192,65,138513,5393,4097,138341,1365,8572,257,33,13324,9053]

theorem envBound20360 : H12AffineFastState.Bounded env20360 := by
  intro p hp
  have h : env20360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20359_20360 : H12AffineEnvironment.transform 14 0 env20359 = env20360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20359 == env20360) = true)

theorem identity20360 : scanCanonicalize (H12AffineFastState.compose env20360 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound20360 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,342,5221,2420,1025,1,4160,33,17,2,8192,65,2420,5393,4097,2048,1365,8572,257,33,13324,9053]

theorem envBound20361 : H12AffineFastState.Bounded env20361 := by
  intro p hp
  have h : env20361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20360_20361 : H12AffineEnvironment.transform 16 5221 env20360 = env20361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env20360 == env20361) = true)

theorem identity20361 : scanCanonicalize (H12AffineFastState.compose env20361 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20361 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,0,342,5221,2420,1025,1,4160,33,17,2,120,65,2420,5393,4097,2048,1365,260,257,33,5236,805]

theorem envBound20362 : H12AffineFastState.Bounded env20362 := by
  intro p hp
  have h : env20362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20361_20362 : H12AffineEnvironment.transform 12 120 env20361 = env20362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20361 == env20362) = true)

theorem identity20362 : scanCanonicalize (H12AffineFastState.compose env20362 (packedSelected [0,1,2,4,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound20362 : packedSelected [0,1,2,4,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,120,3392,0,342,3109,2420,1025,1,2048,33,17,2,120,65,2420,3409,2113,2048,1365,260,257,33,3124,805]

theorem envBound20363 : H12AffineFastState.Bounded env20363 := by
  intro p hp
  have h : env20363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20362_20363 : H12AffineEnvironment.transform 11 2112 env20362 = env20363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env20362 == env20363) = true)

theorem identity20363 : scanCanonicalize (H12AffineFastState.compose env20363 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound20363 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env20364 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2112,120,3125,0,35,3109,2049,1025,1,2048,33,17,2,120,65,2049,3108,2113,2048,1056,113,116,33,3124,592]

theorem envBound20364 : H12AffineFastState.Bounded env20364 := by
  intro p hp
  have h : env20364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20363_20364 : H12AffineEnvironment.transform 7 117 env20363 = env20364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env20363 == env20364) = true)

theorem identity20364 : scanCanonicalize (H12AffineFastState.compose env20364 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20364 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20365 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2112,120,2048,0,35,2064,2049,52,1,2048,33,17,2,120,65,2049,2065,2113,2048,21,113,116,33,2049,592]

theorem envBound20365 : H12AffineFastState.Bounded env20365 := by
  intro p hp
  have h : env20365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20364_20365 : H12AffineEnvironment.transform 9 53 env20364 = env20365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20364 == env20365) = true)

theorem identity20365 : scanCanonicalize (H12AffineFastState.compose env20365 (packedSelected [0,2,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20365 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env20366 : List Nat := [2,4,8,0,32,64,8,101,512,37,2048,2112,104,2048,0,35,2048,2049,36,1,2048,33,1,2,104,65,2049,2049,2113,2048,5,97,100,33,2049,576]

theorem envBound20366 : H12AffineFastState.Bounded env20366 := by
  intro p hp
  have h : env20366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20365_20366 : H12AffineEnvironment.transform 3 0 env20365 = env20366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20365 == env20366) = true)

theorem identity20366 : scanCanonicalize (H12AffineFastState.compose env20366 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound20366 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env20367 : List Nat := [2,4,8,0,32,1,8,36,512,37,2048,2049,41,2048,0,35,2048,2049,36,1,2048,33,1,2,41,0,2049,2049,2048,2048,5,32,37,33,2049,513]

theorem envBound20367 : H12AffineFastState.Bounded env20367 := by
  intro p hp
  have h : env20367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20366_20367 : H12AffineEnvironment.transform 5 1 env20366 = env20367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env20366 == env20367) = true)

def env20368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,4160,21793,17,21762,8193,65,171280,115014,17665,236850,119043,95531,257,98678,90202,63068]

theorem envBound20368 : H12AffineFastState.Bounded env20368 := by
  intro p hp
  have h : env20368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20356_20368 : H12AffineEnvironment.transform 6 9 env20356 = env20368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20356 == env20368) = true)

theorem identity20368 : scanCanonicalize (H12AffineFastState.compose env20368 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20368 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,89379,1025,29788,4160,21793,17,21762,8193,65,158029,79131,17665,223599,75102,95531,257,95531,90202,513]

theorem envBound20369 : H12AffineFastState.Bounded env20369 := by
  intro p hp
  have h : env20369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20368_20369 : H12AffineEnvironment.transform 14 29789 env20368 = env20369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20368 == env20369) = true)

theorem identity20369 : scanCanonicalize (H12AffineFastState.compose env20369 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound20369 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env20370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8232,65536,131072,67926,1025,8233,4160,340,17,375,8193,65,146744,79131,4468,212250,75102,74078,257,74078,78895,513]

theorem envBound20370 : H12AffineFastState.Bounded env20370 := by
  intro p hp
  have h : env20370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20369_20370 : H12AffineEnvironment.transform 13 5237 env20369 = env20370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env20369 == env20370) = true)

theorem identity20370 : scanCanonicalize (H12AffineFastState.compose env20370 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20370 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env20371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8232,8203,131072,10589,1025,8233,4160,340,17,375,8193,65,146744,5392,4468,138513,1365,341,257,341,5156,513]

theorem envBound20371 : H12AffineFastState.Bounded env20371 := by
  intro p hp
  have h : env20371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20370_20371 : H12AffineEnvironment.transform 15 8203 env20370 = env20371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20370 == env20371) = true)

theorem identity20371 : scanCanonicalize (H12AffineFastState.compose env20371 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound20371 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5237,0,35,131072,2421,1025,1,4160,340,17,375,41,65,138512,5392,4468,138513,1365,341,257,341,5156,513]

theorem envBound20372 : H12AffineFastState.Bounded env20372 := by
  intro p hp
  have h : env20372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20371_20372 : H12AffineEnvironment.transform 12 40 env20371 = env20372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env20371 == env20372) = true)

theorem identity20372 : scanCanonicalize (H12AffineFastState.compose env20372 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20372 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env20373 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,0,35,131072,2049,1025,1,4160,32,17,3,41,65,138340,5220,4096,138341,1057,33,117,33,5156,513]

theorem envBound20373 : H12AffineFastState.Bounded env20373 := by
  intro p hp
  have h : env20373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20372_20373 : H12AffineEnvironment.transform 7 116 env20372 = env20373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20372 == env20373) = true)

theorem identity20373 : scanCanonicalize (H12AffineFastState.compose env20373 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound20373 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env20374 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,0,35,5221,2049,1025,1,4160,32,17,3,41,65,2049,5220,4096,2048,1057,33,117,33,5156,513]

theorem envBound20374 : H12AffineFastState.Bounded env20374 := by
  intro p hp
  have h : env20374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20373_20374 : H12AffineEnvironment.transform 16 5221 env20373 = env20374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env20373 == env20374) = true)

theorem identity20374 : scanCanonicalize (H12AffineFastState.compose env20374 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound20374 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20375 : List Nat := [2,4,8,16,32,64,9,116,512,1024,603,4096,40,5237,0,35,5221,602,1025,1,4160,32,17,3,41,65,602,5220,4096,603,1057,33,117,33,5156,513]

theorem envBound20375 : H12AffineFastState.Bounded env20375 := by
  intro p hp
  have h : env20375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20374_20375 : H12AffineEnvironment.transform 10 603 env20374 = env20375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env20374 == env20375) = true)

theorem identity20375 : scanCanonicalize (H12AffineFastState.compose env20375 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound20375 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20376 : List Nat := [2,4,8,16,32,64,9,116,512,100,603,4096,40,4113,0,35,4097,602,101,1,4160,32,17,3,41,65,602,4096,4096,603,69,33,117,33,4160,513]

theorem envBound20376 : H12AffineFastState.Bounded env20376 := by
  intro p hp
  have h : env20376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20375_20376 : H12AffineEnvironment.transform 9 100 env20375 = env20376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env20375 == env20376) = true)

theorem identity20376 : scanCanonicalize (H12AffineFastState.compose env20376 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound20376 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20377 : List Nat := [2,4,8,16,32,64,9,116,512,100,603,64,40,81,0,35,65,602,101,1,0,32,17,3,41,65,602,64,64,603,69,33,117,33,0,513]

theorem envBound20377 : H12AffineFastState.Bounded env20377 := by
  intro p hp
  have h : env20377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20376_20377 : H12AffineEnvironment.transform 11 64 env20376 = env20377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env20376 == env20377) = true)

theorem identity20377 : scanCanonicalize (H12AffineFastState.compose env20377 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound20377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20378 : List Nat := [2,4,7,16,32,64,6,116,512,100,596,64,39,81,0,35,65,597,101,1,0,32,17,3,38,65,597,64,64,596,69,33,117,33,0,513]

theorem envBound20378 : H12AffineFastState.Bounded env20378 := by
  intro p hp
  have h : env20378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20377_20378 : H12AffineEnvironment.transform 2 7 env20377 = env20378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env20377 == env20378) = true)

theorem identity20378 : scanCanonicalize (H12AffineFastState.compose env20378 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound20378 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20379 : List Nat := [2,4,7,16,32,64,6,116,36,100,112,64,39,81,0,35,65,113,101,1,0,32,17,3,38,65,113,64,64,112,69,33,117,33,0,37]

theorem envBound20379 : H12AffineFastState.Bounded env20379 := by
  intro p hp
  have h : env20379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20378_20379 : H12AffineEnvironment.transform 8 36 env20378 = env20379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env20378 == env20379) = true)

theorem identity20379 : scanCanonicalize (H12AffineFastState.compose env20379 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound20379 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20380 : List Nat := [0,4,5,16,32,64,4,116,36,100,112,64,37,81,0,33,65,113,101,1,0,32,17,1,36,65,113,64,64,112,69,33,117,33,0,37]

theorem envBound20380 : H12AffineFastState.Bounded env20380 := by
  intro p hp
  have h : env20380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20379_20380 : H12AffineEnvironment.transform 0 0 env20379 = env20380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env20379 == env20380) = true)

theorem identity20380 : scanCanonicalize (H12AffineFastState.compose env20380 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20380 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env20381 : List Nat := [0,4,5,16,1,64,4,85,5,69,81,64,4,81,0,0,65,80,68,1,0,1,17,1,5,65,80,64,64,81,69,0,84,0,0,4]

theorem envBound20381 : H12AffineFastState.Bounded env20381 := by
  intro p hp
  have h : env20381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20380_20381 : H12AffineEnvironment.transform 4 1 env20380 = env20381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20380 == env20381) = true)

def env20382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21792,351674,329897,8328,65,507954,302181,333995,236986,119043,272393,257,98814,90203,63189]

theorem envBound20382 : H12AffineFastState.Bounded env20382 := by
  intro p hp
  have h : env20382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20354_20382 : H12AffineEnvironment.transform 20 4161 env20354 = env20382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20354 == env20382) = true)

theorem identity20382 : scanCanonicalize (H12AffineFastState.compose env20382 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20382 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,21792,294320,272547,8328,65,450616,302181,276641,179632,61705,272393,257,41460,16465,63189]

theorem envBound20383 : H12AffineFastState.Bounded env20383 := by
  intro p hp
  have h : env20383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20382_20383 : H12AffineEnvironment.transform 15 8202 env20382 = env20383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20382 == env20383) = true)

def env20384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,21792,294200,272427,8192,65,450616,302181,276521,179512,61705,272393,257,41340,16465,63069]

theorem envBound20384 : H12AffineFastState.Bounded env20384 := by
  intro p hp
  have h : env20384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20383_20384 : H12AffineEnvironment.transform 6 8 env20383 = env20384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20383 == env20384) = true)

theorem identity20384 : scanCanonicalize (H12AffineFastState.compose env20384 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound20384 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46156,262144,1025,32769,4161,21792,294200,272427,8192,65,283764,302181,276521,2420,61705,272393,257,41340,16465,63069]

theorem envBound20385 : H12AffineFastState.Bounded env20385 := by
  intro p hp
  have h : env20385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20384_20385 : H12AffineEnvironment.transform 16 46156 env20384 = env20385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env20384 == env20385) = true)

theorem identity20385 : scanCanonicalize (H12AffineFastState.compose env20385 (packedSelected [0,9,17,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound20385 : packedSelected [0,9,17,22,27] rootPS < 2^1333 := by decide +kernel

def env20386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,8202,5440,262144,1025,8461,4161,21792,294200,272427,8192,65,283764,277865,276521,2420,20485,272393,257,112,16465,22353]

theorem envBound20386 : H12AffineFastState.Bounded env20386 := by
  intro p hp
  have h : env20386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20385_20386 : H12AffineEnvironment.transform 14 8460 env20385 = env20386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env20385 == env20386) = true)

theorem identity20386 : scanCanonicalize (H12AffineFastState.compose env20386 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20386 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env20387 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,8232,8202,5220,262144,1025,8233,4161,21508,293916,272427,8192,65,283764,277581,276521,2128,20485,272393,37,112,16465,22133]

theorem envBound20387 : H12AffineFastState.Bounded env20387 := by
  intro p hp
  have h : env20387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20386_20387 : H12AffineEnvironment.transform 7 36 env20386 = env20387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20386 == env20387) = true)

theorem identity20387 : scanCanonicalize (H12AffineFastState.compose env20387 (packedSelected [2,6,9,11,14,17,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20387 : packedSelected [2,6,9,11,14,17,22,23] rootPS < 2^1333 := by decide +kernel

def env20388 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,80,114,5220,262144,1025,81,4161,21508,285796,264275,120,65,283764,269365,268369,2128,20485,264305,37,112,16465,22133]

theorem envBound20388 : H12AffineFastState.Bounded env20388 := by
  intro p hp
  have h : env20388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20387_20388 : H12AffineEnvironment.transform 12 120 env20387 = env20388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20387 == env20388) = true)

theorem identity20388 : scanCanonicalize (H12AffineFastState.compose env20388 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound20388 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env20389 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,80,114,5220,23669,1025,81,4161,21508,17,21542,120,65,2049,16448,17444,2128,20485,21508,37,112,16465,22133]

theorem envBound20389 : H12AffineFastState.Bounded env20389 := by
  intro p hp
  have h : env20389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20388_20389 : H12AffineEnvironment.transform 17 23669 env20388 = env20389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env20388 == env20389) = true)

def env20390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,21792,294201,272426,8193,65,450616,302181,276520,179513,61705,272393,257,41341,16465,63068]

theorem envBound20390 : H12AffineFastState.Bounded env20390 := by
  intro p hp
  have h : env20390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20383_20390 : H12AffineEnvironment.transform 6 9 env20383 = env20390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20383 == env20390) = true)

theorem identity20390 : scanCanonicalize (H12AffineFastState.compose env20390 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound20390 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,262144,1025,29788,4161,21792,294201,272426,8193,65,398437,288824,276520,149860,1364,272393,257,21792,16465,513]

theorem envBound20391 : H12AffineFastState.Bounded env20391 := by
  intro p hp
  have h : env20391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20390_20391 : H12AffineEnvironment.transform 14 29789 env20390 = env20391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env20390 == env20391) = true)

theorem identity20391 : scanCanonicalize (H12AffineFastState.compose env20391 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound20391 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32040,1025,29788,4161,21792,17,21762,8193,65,158029,5392,17664,149860,1364,21793,257,21792,16465,513]

theorem envBound20392 : H12AffineFastState.Bounded env20392 := by
  intro p hp
  have h : env20392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20391_20392 : H12AffineEnvironment.transform 17 32040 env20391 = env20392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env20391 == env20392) = true)

theorem identity20392 : scanCanonicalize (H12AffineFastState.compose env20392 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20392 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,263,131072,23589,1025,21841,4161,21792,17,21762,268,65,149568,5392,17664,149860,1364,21793,257,21792,16465,513]

theorem envBound20393 : H12AffineFastState.Bounded env20393 := by
  intro p hp
  have h : env20393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20392_20393 : H12AffineEnvironment.transform 12 269 env20392 = env20393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20392 == env20393) = true)

theorem identity20393 : scanCanonicalize (H12AffineFastState.compose env20393 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20393 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env20394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,81,263,131072,2340,1025,80,4161,33,17,3,268,65,138561,5392,4097,138341,1364,32,257,33,5456,513]

theorem envBound20394 : H12AffineFastState.Bounded env20394 := by
  intro p hp
  have h : env20394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20393_20394 : H12AffineEnvironment.transform 13 5377 env20393 = env20394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20393 == env20394) = true)

theorem identity20394 : scanCanonicalize (H12AffineFastState.compose env20394 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound20394 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,81,263,5441,2340,1025,80,4161,33,17,3,268,65,2048,5392,4097,2340,1364,32,257,33,5456,513]

theorem envBound20395 : H12AffineFastState.Bounded env20395 := by
  intro p hp
  have h : env20395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20394_20395 : H12AffineEnvironment.transform 16 5441 env20394 = env20395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env20394 == env20395) = true)

theorem identity20395 : scanCanonicalize (H12AffineFastState.compose env20395 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound20395 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,269,3344,81,263,3408,2340,1025,80,2128,33,17,3,268,65,2048,3329,2064,2340,1364,32,257,33,3393,513]

theorem envBound20396 : H12AffineFastState.Bounded env20396 := by
  intro p hp
  have h : env20396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20395_20396 : H12AffineEnvironment.transform 11 2065 env20395 = env20396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env20395 == env20396) = true)

theorem identity20396 : scanCanonicalize (H12AffineFastState.compose env20396 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20396 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env20397 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,269,3344,0,263,3329,2340,1025,1,2049,33,17,3,268,16,2048,3329,2064,2340,1285,32,257,33,3344,513]

theorem envBound20397 : H12AffineFastState.Bounded env20397 := by
  intro p hp
  have h : env20397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20396_20397 : H12AffineEnvironment.transform 5 17 env20396 = env20397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20396 == env20397) = true)

theorem identity20397 : scanCanonicalize (H12AffineFastState.compose env20397 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound20397 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20398 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1060,1077,269,308,0,263,293,1280,1025,1,1061,33,17,3,268,16,1060,293,1076,1280,1285,32,257,33,308,513]

theorem envBound20398 : H12AffineFastState.Bounded env20398 := by
  intro p hp
  have h : env20398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20397_20398 : H12AffineEnvironment.transform 10 1060 env20397 = env20398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env20397 == env20398) = true)

theorem identity20398 : scanCanonicalize (H12AffineFastState.compose env20398 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound20398 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20399 : List Nat := [2,4,8,16,32,17,9,256,512,267,303,318,269,308,0,263,293,11,266,1,302,33,17,3,268,16,303,293,319,11,14,32,257,33,308,513]

theorem envBound20399 : H12AffineFastState.Bounded env20399 := by
  intro p hp
  have h : env20399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20398_20399 : H12AffineEnvironment.transform 9 267 env20398 = env20399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env20398 == env20399) = true)

theorem identity20399 : scanCanonicalize (H12AffineFastState.compose env20399 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound20399 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20400 : List Nat := [2,4,8,16,32,17,9,14,512,5,33,48,3,58,0,9,43,11,4,1,32,33,17,3,2,16,33,43,49,11,14,32,15,33,58,513]

theorem envBound20400 : H12AffineFastState.Bounded env20400 := by
  intro p hp
  have h : env20400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20399_20400 : H12AffineEnvironment.transform 7 14 env20399 = env20400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env20399 == env20400) = true)

def env20401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114913,2444795,2431209,8328,65,2609266,302180,333995,2330107,119042,2373705,257,2199998,2191387,63188]

theorem envBound20401 : H12AffineFastState.Bounded env20401 := by
  intro p hp
  have h : env20401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20353_20401 : H12AffineEnvironment.transform 23 2431209 env20353 = env20401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431209 env20353 == env20401) = true)

def env20402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21793,351675,329897,8328,65,507954,302180,333995,236987,119042,272393,257,98814,90203,63188]

theorem envBound20402 : H12AffineFastState.Bounded env20402 := by
  intro p hp
  have h : env20402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20401_20402 : H12AffineEnvironment.transform 20 4160 env20401 = env20402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20401 == env20402) = true)

theorem identity20402 : scanCanonicalize (H12AffineFastState.compose env20402 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound20402 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,21793,297316,318582,8328,65,398573,302180,314484,149860,1501,272393,257,21793,46212,63188]

theorem envBound20403 : H12AffineFastState.Bounded env20403 := by
  intro p hp
  have h : env20403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20402_20403 : H12AffineEnvironment.transform 15 54495 env20402 = env20403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env20402 == env20403) = true)

def env20404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10280,1025,32769,4160,21793,41292,62558,8328,65,146629,46156,58460,149860,1501,33,257,21793,46212,63188]

theorem envBound20404 : H12AffineFastState.Bounded env20404 := by
  intro p hp
  have h : env20404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20403_20404 : H12AffineEnvironment.transform 17 10280 env20403 = env20404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env20403 == env20404) = true)

theorem identity20404 : scanCanonicalize (H12AffineFastState.compose env20404 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20404 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,10280,1025,32769,4160,32,41292,41311,8328,65,146629,46156,45405,138341,1501,33,257,32,46212,41941]

theorem envBound20405 : H12AffineFastState.Bounded env20405 := by
  intro p hp
  have h : env20405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20404_20405 : H12AffineEnvironment.transform 13 5377 env20404 = env20405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20404 == env20405) = true)

theorem identity20405 : scanCanonicalize (H12AffineFastState.compose env20405 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound20405 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,5393,10280,1025,32769,4160,32,41292,41311,8328,65,10708,46156,45405,2420,1501,33,257,32,46212,41941]

theorem envBound20406 : H12AffineFastState.Bounded env20406 := by
  intro p hp
  have h : env20406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20405_20406 : H12AffineEnvironment.transform 16 5393 env20405 = env20406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env20405 == env20406) = true)

theorem identity20406 : scanCanonicalize (H12AffineFastState.compose env20406 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound20406 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env20407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,5393,10280,1025,8661,4160,32,152,139,8328,65,10708,5528,4233,2420,1501,33,257,32,5456,513]

theorem envBound20407 : H12AffineFastState.Bounded env20407 := by
  intro p hp
  have h : env20407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20406_20407 : H12AffineEnvironment.transform 14 8660 env20406 = env20407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env20406 == env20407) = true)

theorem identity20407 : scanCanonicalize (H12AffineFastState.compose env20407 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound20407 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20408 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,4249,8660,8202,4233,10280,409,8661,4160,32,152,139,8328,65,10708,4096,4233,2420,69,33,257,32,4296,513]

theorem envBound20408 : H12AffineFastState.Bounded env20408 := by
  intro p hp
  have h : env20408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20407_20408 : H12AffineEnvironment.transform 9 408 env20407 = env20408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env20407 == env20408) = true)

theorem identity20408 : scanCanonicalize (H12AffineFastState.compose env20408 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20408 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env20409 : List Nat := [2,4,8,16,32,64,128,36,512,188,2048,4096,8192,4249,8432,8202,4233,10280,189,8433,4160,32,152,139,8328,65,10480,4096,4233,2128,69,33,37,32,4296,513]

theorem envBound20409 : H12AffineFastState.Bounded env20409 := by
  intro p hp
  have h : env20409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20408_20409 : H12AffineEnvironment.transform 7 36 env20408 = env20409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20408 == env20409) = true)

theorem identity20409 : scanCanonicalize (H12AffineFastState.compose env20409 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound20409 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env20410 : List Nat := [2,4,8,16,32,64,128,36,512,188,2048,4096,121,4249,137,115,4233,2129,189,136,4160,32,152,139,241,65,2185,4096,4233,2128,69,33,37,32,4296,513]

theorem envBound20410 : H12AffineFastState.Bounded env20410 := by
  intro p hp
  have h : env20410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20409_20410 : H12AffineEnvironment.transform 12 121 env20409 = env20410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env20409 == env20410) = true)

theorem identity20410 : scanCanonicalize (H12AffineFastState.compose env20410 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2249) := by decide +kernel

theorem selectedBound20410 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env20411 : List Nat := [2,4,8,16,32,64,128,36,512,188,2048,2249,121,2128,137,115,2112,2129,189,136,2185,32,152,139,241,65,2185,2249,2112,2128,69,33,37,32,2049,513]

theorem envBound20411 : H12AffineFastState.Bounded env20411 := by
  intro p hp
  have h : env20411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20410_20411 : H12AffineEnvironment.transform 11 2249 env20410 = env20411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2249 env20410 == env20411) = true)

def env20412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10281,1025,32769,4160,21793,41293,62559,8328,65,146628,46157,58461,149860,1501,32,257,21793,46212,63188]

theorem envBound20412 : H12AffineFastState.Bounded env20412 := by
  intro p hp
  have h : env20412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20403_20412 : H12AffineEnvironment.transform 17 10281 env20403 = env20412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env20403 == env20412) = true)

theorem identity20412 : scanCanonicalize (H12AffineFastState.compose env20412 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound20412 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,10281,1025,29908,4160,21793,21912,138,8328,65,146628,16536,4232,149860,1501,32,257,21793,16465,513]

theorem envBound20413 : H12AffineFastState.Bounded env20413 := by
  intro p hp
  have h : env20413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20412_20413 : H12AffineEnvironment.transform 14 29909 env20412 = env20413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env20412 == env20413) = true)

theorem identity20413 : scanCanonicalize (H12AffineFastState.compose env20413 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20413 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env20414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21976,263,131072,2340,1025,21977,4160,21793,21912,138,389,65,138697,16536,4232,149860,1501,32,257,21793,16465,513]

theorem envBound20414 : H12AffineFastState.Bounded env20414 := by
  intro p hp
  have h : env20414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20413_20414 : H12AffineEnvironment.transform 12 269 env20413 = env20414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20413 == env20414) = true)

theorem identity20414 : scanCanonicalize (H12AffineFastState.compose env20414 (packedSelected [0,2,4,6,7,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20414 : packedSelected [0,2,4,6,7,22] rootPS < 2^1333 := by decide +kernel

def env20415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,263,131072,2340,1025,21840,4160,21793,21777,3,268,65,138560,16401,4097,149860,1364,32,257,21793,16465,513]

theorem envBound20415 : H12AffineFastState.Bounded env20415 := by
  intro p hp
  have h : env20415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20414_20415 : H12AffineEnvironment.transform 6 9 env20414 = env20415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20414 == env20415) = true)

theorem identity20415 : scanCanonicalize (H12AffineFastState.compose env20415 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound20415 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env20416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,263,5393,2340,1025,21840,4160,21793,21777,3,268,65,2129,16401,4097,23669,1364,32,257,21793,16465,513]

theorem envBound20416 : H12AffineFastState.Bounded env20416 := by
  intro p hp
  have h : env20416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20415_20416 : H12AffineEnvironment.transform 16 5393 env20415 = env20416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env20415 == env20416) = true)

theorem identity20416 : scanCanonicalize (H12AffineFastState.compose env20416 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20416 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env20417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,81,263,5393,2340,1025,80,4160,33,17,3,268,65,2129,5393,4097,2421,1364,32,257,33,5457,513]

theorem envBound20417 : H12AffineFastState.Bounded env20417 := by
  intro p hp
  have h : env20417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20416_20417 : H12AffineEnvironment.transform 13 5376 env20416 = env20417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20416 == env20417) = true)

theorem identity20417 : scanCanonicalize (H12AffineFastState.compose env20417 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 3354) := by decide +kernel

theorem selectedBound20417 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env20418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3354,269,2074,81,263,2059,2340,1025,80,3418,33,17,3,268,65,2129,2059,3355,2421,1364,32,257,33,2123,513]

theorem envBound20418 : H12AffineFastState.Bounded env20418 := by
  intro p hp
  have h : env20418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20417_20418 : H12AffineEnvironment.transform 11 3354 env20417 = env20418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3354 env20417 == env20418) = true)

theorem identity20418 : scanCanonicalize (H12AffineFastState.compose env20418 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 346) := by decide +kernel

theorem selectedBound20418 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20419 : List Nat := [2,4,8,16,32,64,9,256,512,346,2048,2112,269,2074,81,263,2059,2340,347,80,2048,33,17,3,268,65,2129,2059,2113,2421,14,32,257,33,2123,513]

theorem envBound20419 : H12AffineFastState.Bounded env20419 := by
  intro p hp
  have h : env20419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20418_20419 : H12AffineEnvironment.transform 9 346 env20418 = env20419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 346 env20418 == env20419) = true)

theorem identity20419 : scanCanonicalize (H12AffineFastState.compose env20419 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound20419 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20420 : List Nat := [2,4,8,16,32,64,9,14,512,84,2048,2112,3,2074,81,9,2059,2090,85,80,2048,33,17,3,2,65,2129,2059,2113,2171,14,32,15,33,2123,513]

theorem envBound20420 : H12AffineFastState.Bounded env20420 := by
  intro p hp
  have h : env20420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20419_20420 : H12AffineEnvironment.transform 7 14 env20419 = env20420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env20419 == env20420) = true)

theorem identity20420 : scanCanonicalize (H12AffineFastState.compose env20420 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20420 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20421 : List Nat := [2,4,8,16,32,17,9,14,512,5,2048,2065,3,2074,0,9,2059,2090,4,1,2048,33,17,3,2,16,2048,2059,2064,2090,14,32,15,33,2074,513]

theorem envBound20421 : H12AffineFastState.Bounded env20421 := by
  intro p hp
  have h : env20421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20420_20421 : H12AffineEnvironment.transform 5 17 env20420 = env20421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20420 == env20421) = true)

theorem identity20421 : scanCanonicalize (H12AffineFastState.compose env20421 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound20421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20422 : List Nat := [2,4,8,16,32,17,9,14,512,5,32,49,3,58,0,9,43,10,4,1,32,33,17,3,2,16,32,43,48,10,14,32,15,33,58,513]

theorem envBound20422 : H12AffineFastState.Bounded env20422 := by
  intro p hp
  have h : env20422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20421_20422 : H12AffineEnvironment.transform 10 32 env20421 = env20422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env20421 == env20422) = true)

def env20423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21792,351674,329896,8328,65,507955,302180,333995,236986,119042,272392,257,98815,90202,63188]

theorem envBound20423 : H12AffineFastState.Bounded env20423 := by
  intro p hp
  have h : env20423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20401_20423 : H12AffineEnvironment.transform 20 4161 env20401 = env20423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20401 == env20423) = true)

theorem identity20423 : scanCanonicalize (H12AffineFastState.compose env20423 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound20423 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108926,1025,32769,4161,21792,62660,41430,8328,65,158029,79130,45525,236986,119042,98678,257,98815,90202,63188]

theorem envBound20424 : H12AffineFastState.Bounded env20424 := by
  intro p hp
  have h : env20424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20423_20424 : H12AffineEnvironment.transform 17 108926 env20423 = env20424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env20423 == env20424) = true)

theorem identity20424 : scanCanonicalize (H12AffineFastState.compose env20424 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound20424 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env20425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,89515,1025,29908,4161,21792,17,21763,8328,65,158029,79130,17664,223599,75223,95651,257,95530,90202,513]

theorem envBound20425 : H12AffineFastState.Bounded env20425 := by
  intro p hp
  have h : env20425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20424_20425 : H12AffineEnvironment.transform 14 29909 env20424 = env20425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env20424 == env20425) = true)

theorem identity20425 : scanCanonicalize (H12AffineFastState.compose env20425 (packedSelected [0,1,2,3,4,5,6,8,10,11,14,18,19,20,22,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound20425 : packedSelected [0,1,2,3,4,5,6,8,10,11,14,18,19,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env20426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82247,89515,1025,29908,4161,21792,17,21763,8328,65,75786,79130,17664,10280,75223,95651,257,95530,90202,513]

theorem envBound20426 : H12AffineFastState.Bounded env20426 := by
  intro p hp
  have h : env20426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20425_20426 : H12AffineEnvironment.transform 16 82247 env20425 = env20426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env20425 == env20426) = true)

theorem identity20426 : scanCanonicalize (H12AffineFastState.compose env20426 (packedSelected [0,1,2,3,8,9,10,11,12,14,15,18,19,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound20426 : packedSelected [0,1,2,3,8,9,10,11,12,14,15,18,19,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8353,65536,70963,68063,1025,8352,4161,340,17,375,8328,65,75786,79130,4468,10280,75223,74199,257,74078,78894,513]

theorem envBound20427 : H12AffineFastState.Bounded env20427 := by
  intro p hp
  have h : env20427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20426_20427 : H12AffineEnvironment.transform 13 5236 env20426 = env20427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env20426 == env20427) = true)

theorem identity20427 : scanCanonicalize (H12AffineFastState.compose env20427 (packedSelected [0,2,4,7,11,14,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound20427 : packedSelected [0,2,4,7,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env20428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8353,8574,13389,10401,1025,8352,4161,340,17,375,8328,65,2420,5220,4468,10280,1193,169,257,32,5456,513]

theorem envBound20428 : H12AffineFastState.Bounded env20428 := by
  intro p hp
  have h : env20428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20427_20428 : H12AffineEnvironment.transform 15 8574 env20427 = env20428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env20427 == env20428) = true)

theorem identity20428 : scanCanonicalize (H12AffineFastState.compose env20428 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3544) := by decide +kernel

theorem selectedBound20428 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3544,8192,2476,8353,8574,10645,10401,1025,8352,3481,340,17,375,8328,65,2420,2492,3244,10280,1193,169,257,32,2184,513]

theorem envBound20429 : H12AffineFastState.Bounded env20429 := by
  intro p hp
  have h : env20429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20428_20429 : H12AffineEnvironment.transform 11 3544 env20428 = env20429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3544 env20428 == env20429) = true)

theorem identity20429 : scanCanonicalize (H12AffineFastState.compose env20429 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound20429 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env20430 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,2113,8192,2476,8353,8574,10645,10401,408,8352,2048,340,17,375,8328,65,2420,2492,2357,10280,304,169,257,32,2184,513]

theorem envBound20430 : H12AffineFastState.Bounded env20430 := by
  intro p hp
  have h : env20430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20429_20430 : H12AffineEnvironment.transform 9 409 env20429 = env20430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env20429 == env20430) = true)

theorem identity20430 : scanCanonicalize (H12AffineFastState.compose env20430 (packedSelected [0,1,2,3,5,6,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound20430 : packedSelected [0,1,2,3,5,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20431 : List Nat := [2,4,8,16,32,64,128,256,512,409,1,64,8192,429,8353,8574,8596,8352,408,8352,1,340,17,375,8328,65,373,445,308,8233,304,169,257,32,137,513]

theorem envBound20431 : H12AffineFastState.Bounded env20431 := by
  intro p hp
  have h : env20431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20430_20431 : H12AffineEnvironment.transform 10 1 env20430 = env20431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20430 == env20431) = true)

theorem identity20431 : scanCanonicalize (H12AffineFastState.compose env20431 (packedSelected [0,1,3,5,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound20431 : packedSelected [0,1,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env20432 : List Nat := [2,4,8,16,32,64,128,256,512,409,1,64,160,429,1,478,308,0,408,0,1,340,17,375,40,65,373,445,308,137,304,169,257,32,137,513]

theorem envBound20432 : H12AffineFastState.Bounded env20432 := by
  intro p hp
  have h : env20432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20431_20432 : H12AffineEnvironment.transform 12 160 env20431 = env20432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env20431 == env20432) = true)

theorem identity20432 : scanCanonicalize (H12AffineFastState.compose env20432 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound20432 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env20433 : List Nat := [2,4,8,16,32,64,89,256,512,320,1,64,121,372,1,263,308,0,321,0,1,340,17,375,40,65,373,356,308,80,304,112,257,32,80,513]

theorem envBound20433 : H12AffineFastState.Bounded env20433 := by
  intro p hp
  have h : env20433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20432_20433 : H12AffineEnvironment.transform 6 89 env20432 = env20433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20432 == env20433) = true)

theorem identity20433 : scanCanonicalize (H12AffineFastState.compose env20433 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20433 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20434 : List Nat := [2,4,8,16,32,64,89,36,512,100,1,64,121,80,1,35,16,0,101,0,1,112,17,83,40,65,81,64,16,80,20,112,37,32,80,513]

theorem envBound20434 : H12AffineFastState.Bounded env20434 := by
  intro p hp
  have h : env20434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20433_20434 : H12AffineEnvironment.transform 7 36 env20433 = env20434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20433 == env20434) = true)

def env20435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356288,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound20435 : H12AffineFastState.Bounded env20435 := by
  intro p hp
  have h : env20435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20030_20435 : H12AffineEnvironment.transform 26 30393345 env20030 = env20435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env20030 == env20435) = true)

def env20436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound20436 : H12AffineFastState.Bounded env20436 := by
  intro p hp
  have h : env20436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20435_20436 : H12AffineEnvironment.transform 18 1024 env20435 = env20436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env20435 == env20436) = true)

theorem identity20436 : scanCanonicalize (H12AffineFastState.compose env20436 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound20436 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,2097152,4194304,8388608,16777216,8328,65,29362363,18973836,10507600,8456378,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound20437 : H12AffineFastState.Bounded env20437 := by
  intro p hp
  have h : env20437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20436_20437 : H12AffineEnvironment.transform 17 247994 env20436 = env20437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env20436 == env20437) = true)

def env20438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,2097152,4194304,8388608,2199964,8328,65,14784807,5392,10507600,8456378,10491276,4256860,256,8410416,8434837,10564187]

theorem envBound20438 : H12AffineFastState.Bounded env20438 := by
  intro p hp
  have h : env20438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20437_20438 : H12AffineEnvironment.transform 23 2199964 env20437 = env20438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env20437 == env20438) = true)

def env20439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,8388608,98780,8328,65,12683623,5392,8406288,8456378,8390092,4256860,256,8410416,8434837,8462875]

theorem envBound20439 : H12AffineFastState.Bounded env20439 := by
  intro p hp
  have h : env20439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20438_20439 : H12AffineEnvironment.transform 20 4160 env20438 = env20439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20438 == env20439) = true)

def env20440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4160,4194304,4374560,98780,8328,65,215367,5392,4359472,4442266,4376044,4256860,256,4363536,4355253,4448827]

theorem envBound20440 : H12AffineFastState.Bounded env20440 := by
  intro p hp
  have h : env20440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20439_20440 : H12AffineEnvironment.transform 22 4374560 env20439 = env20440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env20439 == env20440) = true)

theorem identity20440 : scanCanonicalize (H12AffineFastState.compose env20440 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound20440 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212078,1024,29909,4160,4194304,4338932,95496,8328,65,215367,5392,4354532,4406350,4337976,4194440,256,4350404,4355253,4396783]

theorem envBound20441 : H12AffineFastState.Bounded env20441 := by
  intro p hp
  have h : env20441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20440_20441 : H12AffineEnvironment.transform 14 29908 env20440 = env20441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env20440 == env20441) = true)

def env20442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212078,1024,29909,4160,144612,16,95496,8328,65,215367,5392,17664,67754,1500,144492,256,21792,16465,74251]

theorem envBound20442 : H12AffineFastState.Bounded env20442 := by
  intro p hp
  have h : env20442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20441_20442 : H12AffineEnvironment.transform 21 144612 env20441 = env20442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144612 env20441 == env20442) = true)

theorem identity20442 : scanCanonicalize (H12AffineFastState.compose env20442 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20442 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env20443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,138340,1024,29909,4160,144612,16,21762,8328,65,158029,5392,17664,10400,1500,144492,256,21792,16465,513]

theorem envBound20443 : H12AffineFastState.Bounded env20443 := by
  intro p hp
  have h : env20443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20442_20443 : H12AffineEnvironment.transform 15 8202 env20442 = env20443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20442 == env20443) = true)

theorem identity20443 : scanCanonicalize (H12AffineFastState.compose env20443 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound20443 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0