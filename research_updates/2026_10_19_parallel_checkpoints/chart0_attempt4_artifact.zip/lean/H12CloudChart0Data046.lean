import H12CloudChart0Data045

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound11505 : H12AffineFastState.Bounded env11505 := by
  intro p hp
  have h : env11505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11504_11505 : H12AffineEnvironment.transform 4 0 env11504 = env11505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11504 == env11505) = true)

theorem identity11505 : scanCanonicalize (H12AffineFastState.compose env11505 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound11505 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11506 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,17,269,16384,1,262,16401,2308,1024,0,17680,0,16,2,269,16,2049,16401,17,2308,1284,0,256,0,16385,513]

theorem envBound11506 : H12AffineFastState.Bounded env11506 := by
  intro p hp
  have h : env11506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11505_11506 : H12AffineEnvironment.transform 11 17 env11505 = env11506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11505 == env11506) = true)

theorem identity11506 : scanCanonicalize (H12AffineFastState.compose env11506 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1808) := by decide +kernel

theorem selectedBound11506 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11507 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,17,269,1808,1,262,1793,2308,1024,0,512,0,16,2,269,16,2049,1793,17,2308,1284,0,256,0,1809,513]

theorem envBound11507 : H12AffineFastState.Bounded env11507 := by
  intro p hp
  have h : env11507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11506_11507 : H12AffineEnvironment.transform 13 1808 env11506 = env11507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1808 env11506 == env11507) = true)

theorem identity11507 : scanCanonicalize (H12AffineFastState.compose env11507 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound11507 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11508 : List Nat := [2,4,8,16,0,16,8,256,512,1024,529,17,269,1808,1,262,1793,789,1024,0,512,0,16,2,269,16,528,1793,17,789,1284,0,256,0,1809,513]

theorem envBound11508 : H12AffineFastState.Bounded env11508 := by
  intro p hp
  have h : env11508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11507_11508 : H12AffineEnvironment.transform 10 529 env11507 = env11508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env11507 == env11508) = true)

theorem identity11508 : scanCanonicalize (H12AffineFastState.compose env11508 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound11508 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11509 : List Nat := [2,4,8,16,0,16,8,256,512,256,529,17,269,528,1,262,513,789,256,0,512,0,16,2,269,16,528,513,17,789,4,0,256,0,529,513]

theorem envBound11509 : H12AffineFastState.Bounded env11509 := by
  intro p hp
  have h : env11509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11508_11509 : H12AffineEnvironment.transform 9 256 env11508 = env11509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env11508 == env11509) = true)

theorem identity11509 : scanCanonicalize (H12AffineFastState.compose env11509 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound11509 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11510 : List Nat := [2,4,8,16,0,16,8,256,260,256,277,17,269,276,1,262,261,17,256,0,260,0,16,2,269,16,276,261,17,17,4,0,256,0,277,261]

theorem envBound11510 : H12AffineFastState.Bounded env11510 := by
  intro p hp
  have h : env11510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11509_11510 : H12AffineEnvironment.transform 8 260 env11509 = env11510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env11509 == env11510) = true)

def env11511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41310,8192,64,4677967,115015,45405,442384,75103,4268042,256,98678,90203,513]

theorem envBound11511 : H12AffineFastState.Bounded env11511 := by
  intro p hp
  have h : env11511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11485_11511 : H12AffineEnvironment.transform 20 58397 env11485 = env11511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env11485 == env11511) = true)

def env11512 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8192,16,4677919,114967,45325,442384,75023,4268042,256,98598,90123,513]

theorem envBound11512 : H12AffineFastState.Bounded env11512 := by
  intro p hp
  have h : env11512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11511_11512 : H12AffineEnvironment.transform 5 16 env11511 = env11512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11511 == env11512) = true)

def env11513 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41230,8192,16,4409655,114967,45325,190520,75023,4268042,256,98598,90123,513]

theorem envBound11513 : H12AffineFastState.Bounded env11513 := by
  intro p hp
  have h : env11513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11512_11513 : H12AffineEnvironment.transform 17 10280 env11512 = env11513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11512 == env11513) = true)

theorem identity11513 : scanCanonicalize (H12AffineFastState.compose env11513 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118034) := by decide +kernel

theorem selectedBound11513 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env11514 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,118034,16,41230,8192,16,164901,114967,45325,190520,75023,60696,256,98598,90123,513]

theorem envBound11514 : H12AffineFastState.Bounded env11514 := by
  intro p hp
  have h : env11514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11513_11514 : H12AffineEnvironment.transform 21 118034 env11513 = env11514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118034 env11513 == env11514) = true)

theorem identity11514 : scanCanonicalize (H12AffineFastState.compose env11514 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound11514 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env11515 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,58397,118034,16,41230,8192,16,123967,114967,45325,100386,75023,60696,256,98598,90123,513]

theorem envBound11515 : H12AffineFastState.Bounded env11515 := by
  intro p hp
  have h : env11515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11514_11515 : H12AffineEnvironment.transform 16 90138 env11514 = env11515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env11514 == env11515) = true)

theorem identity11515 : scanCanonicalize (H12AffineFastState.compose env11515 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11293) := by decide +kernel

theorem selectedBound11515 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env11516 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,11293,65536,90138,10280,1024,11292,18432,90383,16,3347,8192,16,84002,93450,7440,74815,75023,16645,256,77115,90123,513]

theorem envBound11516 : H12AffineFastState.Bounded env11516 := by
  intro p hp
  have h : env11516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11515_11516 : H12AffineEnvironment.transform 14 11293 env11515 = env11516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11293 env11515 == env11516) = true)

theorem identity11516 : scanCanonicalize (H12AffineFastState.compose env11516 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound11516 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11517 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,11293,8202,16400,10280,1024,11292,18432,16645,16,3347,8192,16,26664,19712,7440,1077,1285,16645,256,3377,16385,513]

theorem envBound11517 : H12AffineFastState.Bounded env11517 := by
  intro p hp
  have h : env11517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11516_11517 : H12AffineEnvironment.transform 15 8202 env11516 = env11517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env11516 == env11517) = true)

theorem identity11517 : scanCanonicalize (H12AffineFastState.compose env11517 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound11517 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11518 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4112,11293,8202,4096,10280,1024,11292,6160,4373,16,3347,8192,16,14392,7440,7440,1077,1285,4373,256,3377,4113,513]

theorem envBound11518 : H12AffineFastState.Bounded env11518 := by
  intro p hp
  have h : env11518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11517_11518 : H12AffineEnvironment.transform 13 4112 env11517 = env11518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env11517 == env11518) = true)

theorem identity11518 : scanCanonicalize (H12AffineFastState.compose env11518 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound11518 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env11519 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5416,4112,6453,5410,4096,7424,1024,6452,6160,4373,16,3347,5416,16,3344,7440,7440,1077,1285,4373,256,3377,4113,513]

theorem envBound11519 : H12AffineFastState.Bounded env11519 := by
  intro p hp
  have h : env11519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11518_11519 : H12AffineEnvironment.transform 12 5416 env11518 = env11519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env11518 == env11519) = true)

theorem identity11519 : scanCanonicalize (H12AffineFastState.compose env11519 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound11519 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env11520 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3328,2088,3344,1077,2082,3328,0,1024,1076,1296,3093,16,3347,2088,16,3344,16,16,1077,1285,3093,256,3377,3345,513]

theorem envBound11520 : H12AffineFastState.Bounded env11520 := by
  intro p hp
  have h : env11520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11519_11520 : H12AffineEnvironment.transform 11 3328 env11519 = env11520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env11519 == env11520) = true)

theorem identity11520 : scanCanonicalize (H12AffineFastState.compose env11520 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound11520 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env11521 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1588,820,1564,804,1077,1558,820,0,1024,1076,1296,545,16,807,1564,16,804,16,16,1077,1285,545,256,773,805,513]

theorem envBound11521 : H12AffineFastState.Bounded env11521 := by
  intro p hp
  have h : env11521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11520_11521 : H12AffineEnvironment.transform 10 1588 env11520 = env11521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env11520 == env11521) = true)

theorem identity11521 : scanCanonicalize (H12AffineFastState.compose env11521 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11521 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11522 : List Nat := [2,4,8,16,32,16,8,256,512,52,512,820,552,804,1,546,820,0,52,0,292,545,16,807,552,16,804,16,16,1,305,545,256,773,805,513]

theorem envBound11522 : H12AffineFastState.Bounded env11522 := by
  intro p hp
  have h : env11522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11521_11522 : H12AffineEnvironment.transform 9 52 env11521 = env11522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11521 == env11522) = true)

theorem identity11522 : scanCanonicalize (H12AffineFastState.compose env11522 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11522 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11523 : List Nat := [2,4,8,16,32,16,8,37,512,52,512,529,552,513,1,546,529,0,52,0,1,545,16,514,552,16,513,16,16,1,20,545,37,544,512,513]

theorem envBound11523 : H12AffineFastState.Bounded env11523 := by
  intro p hp
  have h : env11523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11522_11523 : H12AffineEnvironment.transform 7 37 env11522 = env11523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11522 == env11523) = true)

theorem identity11523 : scanCanonicalize (H12AffineFastState.compose env11523 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound11523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11524 : List Nat := [2,4,8,16,32,16,8,37,49,52,49,32,25,48,1,19,32,0,52,0,1,16,16,51,25,16,48,16,16,1,20,16,37,17,49,48]

theorem envBound11524 : H12AffineFastState.Bounded env11524 := by
  intro p hp
  have h : env11524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11523_11524 : H12AffineEnvironment.transform 8 49 env11523 = env11524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env11523 == env11524) = true)

theorem identity11524 : scanCanonicalize (H12AffineFastState.compose env11524 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound11524 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11525 : List Nat := [2,4,8,16,16,16,8,21,1,4,1,16,25,0,1,19,16,0,4,0,1,16,16,3,25,16,0,16,16,1,20,16,21,17,1,0]

theorem envBound11525 : H12AffineFastState.Bounded env11525 := by
  intro p hp
  have h : env11525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11524_11525 : H12AffineEnvironment.transform 4 16 env11524 = env11525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env11524 == env11525) = true)

def env11526 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41230,8192,16,4409654,114967,45325,190521,75023,4268042,256,98598,90123,513]

theorem envBound11526 : H12AffineFastState.Bounded env11526 := by
  intro p hp
  have h : env11526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11512_11526 : H12AffineEnvironment.transform 17 10281 env11512 = env11526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11512 == env11526) = true)

theorem identity11526 : scanCanonicalize (H12AffineFastState.compose env11526 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound11526 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env11527 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,246070,16,41230,8192,16,34816,114967,45325,190521,75023,188732,256,98598,90123,513]

theorem envBound11527 : H12AffineFastState.Bounded env11527 := by
  intro p hp
  have h : env11527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11526_11527 : H12AffineEnvironment.transform 21 246070 env11526 = env11527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env11526 == env11527) = true)

theorem identity11527 : scanCanonicalize (H12AffineFastState.compose env11527 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound11527 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env11528 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,114967,10281,1024,32769,58397,33,16,41230,8192,16,34816,114967,45325,76078,75023,73771,256,98598,90123,513]

theorem envBound11528 : H12AffineFastState.Bounded env11528 := by
  intro p hp
  have h : env11528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11527_11528 : H12AffineEnvironment.transform 16 114967 env11527 = env11528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env11527 == env11528) = true)

theorem identity11528 : scanCanonicalize (H12AffineFastState.compose env11528 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound11528 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env11529 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,263,49168,10281,1024,32769,58397,33,16,41230,8192,16,34816,49168,45325,10281,9224,8492,256,32801,24844,513]

theorem envBound11529 : H12AffineFastState.Bounded env11529 := by
  intro p hp
  have h : env11529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11528_11529 : H12AffineEnvironment.transform 15 263 env11528 = env11529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env11528 == env11529) = true)

theorem identity11529 : scanCanonicalize (H12AffineFastState.compose env11529 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound11529 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11530 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,263,24861,10281,1024,8460,17680,33,16,3,8192,16,10509,24861,4096,10281,9224,8492,256,8492,24844,513]

theorem envBound11530 : H12AffineFastState.Bounded env11530 := by
  intro p hp
  have h : env11530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11529_11530 : H12AffineEnvironment.transform 14 8461 env11529 = env11530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env11529 == env11530) = true)

theorem identity11530 : scanCanonicalize (H12AffineFastState.compose env11530 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11530 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11531 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,263,16401,2341,1024,0,17680,33,16,3,268,16,2049,16401,4096,2341,1284,32,256,32,16384,513]

theorem envBound11531 : H12AffineFastState.Bounded env11531 := by
  intro p hp
  have h : env11531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11530_11531 : H12AffineEnvironment.transform 12 268 env11530 = env11531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11530 == env11531) = true)

theorem identity11531 : scanCanonicalize (H12AffineFastState.compose env11531 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound11531 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11532 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,17,268,16384,1,263,16401,2341,1024,0,17680,33,16,3,268,16,2049,16401,17,2341,1284,32,256,32,16384,513]

theorem envBound11532 : H12AffineFastState.Bounded env11532 := by
  intro p hp
  have h : env11532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11531_11532 : H12AffineEnvironment.transform 11 17 env11531 = env11532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11531 == env11532) = true)

theorem identity11532 : scanCanonicalize (H12AffineFastState.compose env11532 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound11532 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11533 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,17,268,16384,1,263,16401,2341,272,0,16384,33,16,3,268,16,2049,16401,17,2341,20,32,256,32,16384,513]

theorem envBound11533 : H12AffineFastState.Bounded env11533 := by
  intro p hp
  have h : env11533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11532_11533 : H12AffineEnvironment.transform 9 272 env11532 = env11533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env11532 == env11533) = true)

theorem identity11533 : scanCanonicalize (H12AffineFastState.compose env11533 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound11533 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11534 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,17,268,16384,1,263,16401,292,272,0,16384,33,16,3,268,16,0,16401,17,292,20,32,256,32,16384,513]

theorem envBound11534 : H12AffineFastState.Bounded env11534 := by
  intro p hp
  have h : env11534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11533_11534 : H12AffineEnvironment.transform 10 1 env11533 = env11534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11533 == env11534) = true)

theorem identity11534 : scanCanonicalize (H12AffineFastState.compose env11534 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11534 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env11535 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,17,41,16384,1,34,16401,1,53,0,16384,33,16,3,41,16,0,16401,17,1,20,32,37,32,16384,513]

theorem envBound11535 : H12AffineFastState.Bounded env11535 := by
  intro p hp
  have h : env11535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11534_11535 : H12AffineEnvironment.transform 7 37 env11534 = env11535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11534 == env11535) = true)

def env11536 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8192,17,4677918,114966,45324,442384,75022,4268042,256,98599,90122,513]

theorem envBound11536 : H12AffineFastState.Bounded env11536 := by
  intro p hp
  have h : env11536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11511_11536 : H12AffineEnvironment.transform 5 17 env11511 = env11536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11511 == env11536) = true)

theorem identity11536 : scanCanonicalize (H12AffineFastState.compose env11536 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound11536 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env11537 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41231,8192,17,4409655,114966,45324,190521,75022,4268042,256,98599,90122,513]

theorem envBound11537 : H12AffineFastState.Bounded env11537 := by
  intro p hp
  have h : env11537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11536_11537 : H12AffineEnvironment.transform 17 10281 env11536 = env11537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11536 == env11537) = true)

theorem identity11537 : scanCanonicalize (H12AffineFastState.compose env11537 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound11537 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env11538 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58397,4194304,16,41231,8192,17,4385085,24860,45324,190521,34052,4227072,256,8493,49152,513]

theorem envBound11538 : H12AffineFastState.Bounded env11538 := by
  intro p hp
  have h : env11538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11537_11538 : H12AffineEnvironment.transform 15 40970 env11537 = env11538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env11537 == env11538) = true)

theorem identity11538 : scanCanonicalize (H12AffineFastState.compose env11538 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 147504) := by decide +kernel

theorem selectedBound11538 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11539 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58397,147504,16,41231,8192,17,43277,24860,45324,190521,34052,180272,256,8493,49152,513]

theorem envBound11539 : H12AffineFastState.Bounded env11539 := by
  intro p hp
  have h : env11539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11538_11539 : H12AffineEnvironment.transform 21 147504 env11538 = env11539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147504 env11538 == env11539) = true)

theorem identity11539 : scanCanonicalize (H12AffineFastState.compose env11539 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound11539 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11540 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,24860,10281,1024,32769,58397,8492,16,41231,8192,17,43277,24860,45324,35109,34052,41260,256,8493,49152,513]

theorem envBound11540 : H12AffineFastState.Bounded env11540 := by
  intro p hp
  have h : env11540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11539_11540 : H12AffineEnvironment.transform 16 24860 env11539 = env11540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env11539 == env11540) = true)

def env11541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41310,8192,64,4677966,2172250,2118977,442385,75102,6407191,256,2188650,2196551,512]

theorem envBound11541 : H12AffineFastState.Bounded env11541 := by
  intro p hp
  have h : env11541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11484_11541 : H12AffineEnvironment.transform 22 17 env11484 = env11541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env11484 == env11541) = true)

theorem identity11541 : scanCanonicalize (H12AffineFastState.compose env11541 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 314688) := by decide +kernel

theorem selectedBound11541 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,314688,4194304,17,41310,8192,64,4677966,387098,301057,442385,75102,4524375,256,370730,346375,512]

theorem envBound11542 : H12AffineFastState.Bounded env11542 := by
  intro p hp
  have h : env11542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11541_11542 : H12AffineEnvironment.transform 20 314688 env11541 = env11542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314688 env11541 == env11542) = true)

theorem identity11542 : scanCanonicalize (H12AffineFastState.compose env11542 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound11542 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env11543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58728,4194304,17,41310,8192,64,4409702,114738,45097,190521,75102,4268415,256,98306,90415,512]

theorem envBound11543 : H12AffineFastState.Bounded env11543 := by
  intro p hp
  have h : env11543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11542_11543 : H12AffineEnvironment.transform 17 10280 env11542 = env11543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11542 == env11543) = true)

theorem identity11543 : scanCanonicalize (H12AffineFastState.compose env11543 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 246119) := by decide +kernel

theorem selectedBound11543 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env11544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58728,246119,17,41310,8192,64,34817,114738,45097,190521,75102,188440,256,98306,90415,512]

theorem envBound11544 : H12AffineFastState.Bounded env11544 := by
  intro p hp
  have h : env11544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11543_11544 : H12AffineEnvironment.transform 21 246119 env11543 = env11544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246119 env11543 == env11544) = true)

theorem identity11544 : scanCanonicalize (H12AffineFastState.compose env11544 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound11544 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env11545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,10280,1024,32769,58728,147504,17,41310,8192,64,34817,16741,45097,190521,41993,188440,256,341,57464,512]

theorem envBound11545 : H12AffineFastState.Bounded env11545 := by
  intro p hp
  have h : env11545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11544_11545 : H12AffineEnvironment.transform 15 33111 env11544 = env11545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env11544 == env11545) = true)

theorem identity11545 : scanCanonicalize (H12AffineFastState.compose env11545 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 10328) := by decide +kernel

theorem selectedBound11545 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10328,32768,33111,131072,10280,1024,32769,36144,141416,17,41310,8192,64,34817,10557,45097,163937,41993,165952,256,341,34848,512]

theorem envBound11546 : H12AffineFastState.Bounded env11546 := by
  intro p hp
  have h : env11546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11545_11546 : H12AffineEnvironment.transform 13 10328 env11545 = env11546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10328 env11545 == env11546) = true)

theorem identity11546 : scanCanonicalize (H12AffineFastState.compose env11546 (packedSelected [0,1,3,5,7,8,10,14,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound11546 : packedSelected [0,1,3,5,7,8,10,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env11547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,8192,10328,32768,33111,131072,10280,1024,32769,36144,141416,17,41310,8192,64,34817,10557,44125,163937,41993,165952,256,341,34848,512]

theorem envBound11547 : H12AffineFastState.Bounded env11547 := by
  intro p hp
  have h : env11547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11546_11547 : H12AffineEnvironment.transform 11 3188 env11546 = env11547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env11546 == env11547) = true)

theorem identity11547 : scanCanonicalize (H12AffineFastState.compose env11547 (packedSelected [0,6,7,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound11547 : packedSelected [0,6,7,12,15,18] rootPS < 2^1333 := by decide +kernel

def env11548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,8192,10328,81,262,131072,10280,1024,80,3425,141416,17,8463,8192,64,2128,10557,11276,131120,9304,133137,256,341,2161,512]

theorem envBound11548 : H12AffineFastState.Bounded env11548 := by
  intro p hp
  have h : env11548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11547_11548 : H12AffineEnvironment.transform 14 81 env11547 = env11548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env11547 == env11548) = true)

theorem identity11548 : scanCanonicalize (H12AffineFastState.compose env11548 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound11548 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,120,2080,81,262,131072,2128,1024,80,3425,133136,17,375,120,64,2128,2373,3188,131120,1056,133137,256,341,2161,512]

theorem envBound11549 : H12AffineFastState.Bounded env11549 := by
  intro p hp
  have h : env11549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11548_11549 : H12AffineEnvironment.transform 12 120 env11548 = env11549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env11548 == env11549) = true)

theorem identity11549 : scanCanonicalize (H12AffineFastState.compose env11549 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound11549 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env11550 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,2373,120,2080,81,262,131072,2128,305,80,2128,133136,17,375,120,64,2128,2373,2373,131120,273,133137,256,341,2161,512]

theorem envBound11550 : H12AffineFastState.Bounded env11550 := by
  intro p hp
  have h : env11550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11549_11550 : H12AffineEnvironment.transform 9 305 env11549 = env11550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env11549 == env11550) = true)

theorem identity11550 : scanCanonicalize (H12AffineFastState.compose env11550 (packedSelected [1,2,3,5,8,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11550 : packedSelected [1,2,3,5,8,14,15] rootPS < 2^1333 := by decide +kernel

def env11551 : List Nat := [2,4,8,16,32,64,8,116,512,69,2048,2097,120,2080,81,114,131072,2128,69,80,2128,133136,17,3,120,64,2128,2097,2097,131120,101,133137,116,33,2161,512]

theorem envBound11551 : H12AffineFastState.Bounded env11551 := by
  intro p hp
  have h : env11551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11550_11551 : H12AffineEnvironment.transform 7 116 env11550 = env11551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11550 == env11551) = true)

theorem identity11551 : scanCanonicalize (H12AffineFastState.compose env11551 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11551 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11552 : List Nat := [2,4,8,16,32,64,8,116,512,69,2048,2097,120,2080,81,114,2064,2128,69,80,2128,0,17,3,120,64,2128,2097,2097,2080,101,1,116,33,2161,512]

theorem envBound11552 : H12AffineFastState.Bounded env11552 := by
  intro p hp
  have h : env11552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11551_11552 : H12AffineEnvironment.transform 16 2064 env11551 = env11552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2064 env11551 == env11552) = true)

theorem identity11552 : scanCanonicalize (H12AffineFastState.compose env11552 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11552 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env11553 : List Nat := [2,4,8,16,0,64,8,84,512,69,2048,2065,88,2048,81,82,2064,2128,69,80,2128,0,17,3,88,64,2128,2065,2065,2048,69,1,84,1,2129,512]

theorem envBound11553 : H12AffineFastState.Bounded env11553 := by
  intro p hp
  have h : env11553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11552_11553 : H12AffineEnvironment.transform 4 0 env11552 = env11553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11552 == env11553) = true)

theorem identity11553 : scanCanonicalize (H12AffineFastState.compose env11553 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound11553 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11554 : List Nat := [2,4,8,13,0,64,8,73,512,69,2048,2060,69,2048,76,79,2061,2125,69,77,2125,0,12,3,69,64,2125,2060,2060,2048,69,1,73,1,2124,512]

theorem envBound11554 : H12AffineFastState.Bounded env11554 := by
  intro p hp
  have h : env11554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11553_11554 : H12AffineEnvironment.transform 3 13 env11553 = env11554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env11553 == env11554) = true)

theorem identity11554 : scanCanonicalize (H12AffineFastState.compose env11554 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound11554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11555 : List Nat := [2,4,5,0,0,64,5,68,512,69,2048,2049,69,2048,65,66,2048,2112,69,64,2112,0,1,3,69,64,2112,2049,2049,2048,69,1,68,1,2113,512]

theorem envBound11555 : H12AffineFastState.Bounded env11555 := by
  intro p hp
  have h : env11555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11554_11555 : H12AffineEnvironment.transform 2 5 env11554 = env11555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env11554 == env11555) = true)

theorem identity11555 : scanCanonicalize (H12AffineFastState.compose env11555 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound11555 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11556 : List Nat := [2,4,5,0,0,64,5,68,512,69,70,71,69,70,65,66,70,6,69,64,6,0,1,3,69,64,6,71,71,70,69,1,68,1,7,512]

theorem envBound11556 : H12AffineFastState.Bounded env11556 := by
  intro p hp
  have h : env11556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11555_11556 : H12AffineEnvironment.transform 10 70 env11555 = env11556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env11555 == env11556) = true)

theorem identity11556 : scanCanonicalize (H12AffineFastState.compose env11556 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound11556 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11557 : List Nat := [2,4,5,0,0,64,5,68,71,69,70,71,69,70,65,66,70,6,69,64,6,0,1,3,69,64,6,71,71,70,69,1,68,1,7,71]

theorem envBound11557 : H12AffineFastState.Bounded env11557 := by
  intro p hp
  have h : env11557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11556_11557 : H12AffineEnvironment.transform 8 71 env11556 = env11557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env11556 == env11557) = true)

theorem identity11557 : scanCanonicalize (H12AffineFastState.compose env11557 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound11557 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11558 : List Nat := [2,4,5,0,0,6,5,2,1,3,0,1,3,0,7,4,0,6,3,6,6,0,1,3,3,6,6,1,1,0,3,1,2,1,7,1]

theorem envBound11558 : H12AffineFastState.Bounded env11558 := by
  intro p hp
  have h : env11558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11557_11558 : H12AffineEnvironment.transform 5 6 env11557 = env11558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env11557 == env11558) = true)

theorem identity11558 : scanCanonicalize (H12AffineFastState.compose env11558 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound11558 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11559 : List Nat := [2,1,0,0,0,3,0,2,1,3,0,1,3,0,2,1,0,3,3,3,3,0,1,3,3,3,3,1,1,0,3,1,2,1,2,1]

theorem envBound11559 : H12AffineFastState.Bounded env11559 := by
  intro p hp
  have h : env11559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11558_11559 : H12AffineEnvironment.transform 1 1 env11558 = env11559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env11558 == env11559) = true)

theorem identity11559 : scanCanonicalize (H12AffineFastState.compose env11559 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11559 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env11560 : List Nat := [1,1,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,1,1,1,1,1]

theorem envBound11560 : H12AffineFastState.Bounded env11560 := by
  intro p hp
  have h : env11560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11559_11560 : H12AffineEnvironment.transform 0 1 env11559 = env11560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11559 == env11560) = true)

def env11561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41310,8193,64,13066591,2172251,10507600,8830976,8463695,6407190,256,10577274,10585174,8389136]

theorem envBound11561 : H12AffineFastState.Bounded env11561 := by
  intro p hp
  have h : env11561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11483_11561 : H12AffineEnvironment.transform 6 9 env11483 = env11561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11483 == env11561) = true)

def env11562 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8193,64,4677967,2172251,2118976,442384,75103,6407190,256,2188650,2196550,512]

theorem envBound11562 : H12AffineFastState.Bounded env11562 := by
  intro p hp
  have h : env11562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11561_11562 : H12AffineEnvironment.transform 22 16 env11561 = env11562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env11561 == env11562) = true)

theorem identity11562 : scanCanonicalize (H12AffineFastState.compose env11562 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 503130) := by decide +kernel

theorem selectedBound11562 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,503130,4194304,16,41310,8193,64,4677967,428033,522266,442384,75103,4614476,256,444464,403740,512]

theorem envBound11563 : H12AffineFastState.Bounded env11563 := by
  intro p hp
  have h : env11563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11562_11563 : H12AffineEnvironment.transform 20 503130 env11562 = env11563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 503130 env11562 == env11563) = true)

theorem identity11563 : scanCanonicalize (H12AffineFastState.compose env11563 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound11563 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env11564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,461831,4194304,16,3,8193,64,4677967,403804,481607,418125,75103,4614476,256,420205,403740,512]

theorem envBound11564 : H12AffineFastState.Bounded env11564 := by
  intro p hp
  have h : env11564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11563_11564 : H12AffineEnvironment.transform 14 8541 env11563 = env11564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env11563 == env11564) = true)

theorem identity11564 : scanCanonicalize (H12AffineFastState.compose env11564 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 420173) := by decide +kernel

theorem selectedBound11564 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,461831,420173,16,3,8193,64,67586,403804,481607,418125,75103,1,256,420205,403740,512]

theorem envBound11565 : H12AffineFastState.Bounded env11565 := by
  intro p hp
  have h : env11565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11564_11565 : H12AffineEnvironment.transform 21 420173 env11564 = env11565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 420173 env11564 == env11565) = true)

theorem identity11565 : scanCanonicalize (H12AffineFastState.compose env11565 (packedSelected [9,14,22] rootPS)) = affineNative (2^(17+1) ^^^ 158061) := by decide +kernel

theorem selectedBound11565 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env11566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,158061,1024,8540,91498,32,16,3,8193,64,67586,16433,77866,2080,75103,1,256,0,16497,512]

theorem envBound11566 : H12AffineFastState.Bounded env11566 := by
  intro p hp
  have h : env11566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11565_11566 : H12AffineEnvironment.transform 17 158061 env11565 = env11566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 158061 env11565 == env11566) = true)

theorem identity11566 : scanCanonicalize (H12AffineFastState.compose env11566 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound11566 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env11567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10621,1024,8540,91498,32,16,3,8193,64,67586,16433,77866,2080,75103,1,256,0,16497,512]

theorem envBound11567 : H12AffineFastState.Bounded env11567 := by
  intro p hp
  have h : env11567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11566_11567 : H12AffineEnvironment.transform 16 16400 env11566 = env11567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env11566 == env11567) = true)

theorem identity11567 : scanCanonicalize (H12AffineFastState.compose env11567 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(15+1) ^^^ 21622) := by decide +kernel

theorem selectedBound11567 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env11568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21622,16400,10621,1024,8540,12572,32,16,3,8193,64,23668,16433,25692,2080,28969,1,256,0,16497,512]

theorem envBound11568 : H12AffineFastState.Bounded env11568 := by
  intro p hp
  have h : env11568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11567_11568 : H12AffineEnvironment.transform 15 21622 env11567 = env11568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21622 env11567 == env11568) = true)

theorem identity11568 : scanCanonicalize (H12AffineFastState.compose env11568 (packedSelected [2,3,5,6,10,11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound11568 : packedSelected [2,3,5,6,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env11569 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,16384,8492,21511,16400,10508,1024,8493,12572,32,16,3,8193,49,23557,16433,25645,2080,28969,1,256,0,16384,512]

theorem envBound11569 : H12AffineFastState.Bounded env11569 := by
  intro p hp
  have h : env11569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11568_11569 : H12AffineEnvironment.transform 5 49 env11568 = env11569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env11568 == env11569) = true)

theorem identity11569 : scanCanonicalize (H12AffineFastState.compose env11569 (packedSelected [0,1,3,4,5,6,7,8,9,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11569 : packedSelected [0,1,3,4,5,6,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env11570 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,8192,16384,8201,21511,16400,10281,1024,8200,12345,32,16,3,8193,49,23557,16433,25645,2080,28684,1,37,0,16384,512]

theorem envBound11570 : H12AffineFastState.Bounded env11570 := by
  intro p hp
  have h : env11570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11569_11570 : H12AffineEnvironment.transform 7 37 env11569 = env11570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11569 == env11570) = true)

theorem identity11570 : scanCanonicalize (H12AffineFastState.compose env11570 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11570 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11571 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,41,16384,32,21511,16400,2048,1024,33,4112,32,16,3,40,49,23557,16433,17412,2080,20517,1,37,0,16384,512]

theorem envBound11571 : H12AffineFastState.Bounded env11571 := by
  intro p hp
  have h : env11571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11570_11571 : H12AffineEnvironment.transform 12 41 env11570 = env11571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11570 == env11571) = true)

theorem identity11571 : scanCanonicalize (H12AffineFastState.compose env11571 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound11571 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env11572 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,41,5157,32,34,5173,2048,1024,33,4112,32,16,3,40,49,2080,5140,4129,2080,1024,1,37,0,5157,512]

theorem envBound11572 : H12AffineFastState.Bounded env11572 := by
  intro p hp
  have h : env11572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11571_11572 : H12AffineEnvironment.transform 13 5157 env11571 = env11572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env11571 == env11572) = true)

theorem identity11572 : scanCanonicalize (H12AffineFastState.compose env11572 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11572 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11573 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5124,1,3,5140,2048,1024,0,4112,1,16,3,9,16,2049,5140,4096,2049,1024,1,4,0,5124,512]

theorem envBound11573 : H12AffineFastState.Bounded env11573 := by
  intro p hp
  have h : env11573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11572_11573 : H12AffineEnvironment.transform 4 1 env11572 = env11573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11572 == env11573) = true)

def env11574 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,8,1044,1,3,1028,2048,1024,0,0,1,16,3,9,16,2049,1028,16,2049,1024,1,4,0,1044,512]

theorem envBound11574 : H12AffineFastState.Bounded env11574 := by
  intro p hp
  have h : env11574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11573_11574 : H12AffineEnvironment.transform 11 16 env11573 = env11574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env11573 == env11574) = true)

theorem identity11574 : scanCanonicalize (H12AffineFastState.compose env11574 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound11574 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11575 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,1,1,3,17,2048,21,0,0,1,16,3,9,16,2049,17,16,2049,21,1,4,0,1,512]

theorem envBound11575 : H12AffineFastState.Bounded env11575 := by
  intro p hp
  have h : env11575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11574_11575 : H12AffineEnvironment.transform 9 21 env11574 = env11575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11574 == env11575) = true)

theorem identity11575 : scanCanonicalize (H12AffineFastState.compose env11575 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound11575 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11576 : List Nat := [2,4,8,16,1,16,9,4,31,21,2048,16,8,1,1,3,17,2048,21,0,0,1,16,3,9,16,2049,17,16,2049,21,1,4,0,1,31]

theorem envBound11576 : H12AffineFastState.Bounded env11576 := by
  intro p hp
  have h : env11576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11575_11576 : H12AffineEnvironment.transform 8 31 env11575 = env11576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env11575 == env11576) = true)

def leafEnv11576 : List Nat := [2,4,8,16,1,16,9,4,31,21,2048,16,8,1,1,3,17,2048,21,0,0,1,16,3,21,9,1,16,2049,17,16,2049,21,1,4,0,4,2,1,31,1,0,0]

def active11576 : List Nat := [0,1,2,3,10]

def tree11576 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11576 : H12WitnessSearch.Good tree11576 := H12GlobalWitnessIndex.good

theorem leafIdentity11576 : H12AffineFastState.composeSystem env11576 rootObs = leafEnv11576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11576 rootObs == leafEnv11576) = true)

theorem terminalChecked11576 : H12PackedTerminal.terminalCheckFast leafEnv11576 active11576 tree11576 = true := by decide +kernel

def env11577 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1045,1,3,1029,2048,1024,0,1,1,16,3,9,16,2049,1029,17,2049,1024,1,4,0,1045,512]

theorem envBound11577 : H12AffineFastState.Bounded env11577 := by
  intro p hp
  have h : env11577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11573_11577 : H12AffineEnvironment.transform 11 17 env11573 = env11577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env11573 == env11577) = true)

def env11578 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,8,1,1,3,17,2048,20,0,1,1,16,3,9,16,2049,17,17,2049,20,1,4,0,1,512]

theorem envBound11578 : H12AffineFastState.Bounded env11578 := by
  intro p hp
  have h : env11578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11577_11578 : H12AffineEnvironment.transform 9 20 env11577 = env11578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11577 == env11578) = true)

theorem identity11578 : scanCanonicalize (H12AffineFastState.compose env11578 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound11578 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11579 : List Nat := [2,4,8,5,1,5,9,4,512,1,2048,4,8,1,1,3,4,2048,1,0,1,1,5,3,9,5,2049,4,4,2049,1,1,4,0,1,512]

theorem envBound11579 : H12AffineFastState.Bounded env11579 := by
  intro p hp
  have h : env11579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11578_11579 : H12AffineEnvironment.transform 3 5 env11578 = env11579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env11578 == env11579) = true)

def leafEnv11579 : List Nat := [2,4,8,5,1,5,9,4,512,1,2048,4,8,1,1,3,4,2048,1,0,1,1,5,3,1,9,1,5,2049,4,4,2049,1,1,4,0,4,2,1,512,1,1,0]

def active11579 : List Nat := [0,1,2,8,10]

def tree11579 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11579 : H12WitnessSearch.Good tree11579 := H12GlobalWitnessIndex.good

theorem leafIdentity11579 : H12AffineFastState.composeSystem env11579 rootObs = leafEnv11579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11579 rootObs == leafEnv11579) = true)

theorem terminalChecked11579 : H12PackedTerminal.terminalCheckFast leafEnv11579 active11579 tree11579 = true := by decide +kernel

def env11580 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,0,1,3,16,2048,21,0,1,1,16,3,9,16,2049,16,17,2049,21,1,4,0,0,512]

theorem envBound11580 : H12AffineFastState.Bounded env11580 := by
  intro p hp
  have h : env11580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11577_11580 : H12AffineEnvironment.transform 9 21 env11577 = env11580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11577 == env11580) = true)

theorem identity11580 : scanCanonicalize (H12AffineFastState.compose env11580 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound11580 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11581 : List Nat := [2,4,8,16,1,16,9,4,30,21,2048,17,8,0,1,3,16,2048,21,0,1,1,16,3,9,16,2049,16,17,2049,21,1,4,0,0,30]

theorem envBound11581 : H12AffineFastState.Bounded env11581 := by
  intro p hp
  have h : env11581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11580_11581 : H12AffineEnvironment.transform 8 30 env11580 = env11581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env11580 == env11581) = true)

def leafEnv11581 : List Nat := [2,4,8,16,1,16,9,4,30,21,2048,17,8,0,1,3,16,2048,21,0,1,1,16,3,21,9,1,16,2049,16,17,2049,21,1,4,0,4,2,0,30,1,1,0]

def active11581 : List Nat := [0,1,2,3,10]

def tree11581 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11581 : H12WitnessSearch.Good tree11581 := H12GlobalWitnessIndex.good

theorem leafIdentity11581 : H12AffineFastState.composeSystem env11581 rootObs = leafEnv11581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11581 rootObs == leafEnv11581) = true)

theorem terminalChecked11581 : H12PackedTerminal.terminalCheckFast leafEnv11581 active11581 tree11581 = true := by decide +kernel

def env11582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41310,8193,64,4677966,2172251,2118977,442385,75102,6407190,256,2188651,2196551,513]

theorem envBound11582 : H12AffineFastState.Bounded env11582 := by
  intro p hp
  have h : env11582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11561_11582 : H12AffineEnvironment.transform 22 17 env11561 = env11582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env11561 == env11582) = true)

theorem identity11582 : scanCanonicalize (H12AffineFastState.compose env11582 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound11582 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env11583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,17,41310,8193,64,4456788,2172251,2118977,368651,75102,6407190,256,2188651,2196551,513]

theorem envBound11583 : H12AffineFastState.Bounded env11583 := by
  intro p hp
  have h : env11583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11582_11583 : H12AffineEnvironment.transform 16 90138 env11582 = env11583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env11582 == env11583) = true)

theorem identity11583 : scanCanonicalize (H12AffineFastState.compose env11583 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound11583 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,262144,1024,29004,2097152,4194304,17,20499,8193,64,4456788,2172251,2118977,348486,75102,6370651,256,2188651,2192650,513]

theorem envBound11584 : H12AffineFastState.Bounded env11584 := by
  intro p hp
  have h : env11584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11583_11584 : H12AffineEnvironment.transform 14 29005 env11583 = env11584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env11583 == env11584) = true)

theorem identity11584 : scanCanonicalize (H12AffineFastState.compose env11584 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound11584 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env11585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,2097152,4194304,17,20499,8193,64,4225389,2172251,2118977,76159,75102,6370651,256,2188651,2192650,513]

theorem envBound11585 : H12AffineFastState.Bounded env11585 := by
  intro p hp
  have h : env11585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11584_11585 : H12AffineEnvironment.transform 17 30777 env11584 = env11585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env11584 == env11585) = true)

def env11586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,5456,4194304,17,20499,8193,64,4225389,77835,16401,76159,75102,4268043,256,94267,90202,513]

theorem envBound11586 : H12AffineFastState.Bounded env11586 := by
  intro p hp
  have h : env11586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11585_11586 : H12AffineEnvironment.transform 20 5456 env11585 = env11586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env11585 == env11586) = true)

theorem identity11586 : scanCanonicalize (H12AffineFastState.compose env11586 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 94266) := by decide +kernel

theorem selectedBound11586 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11587 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,5456,94266,17,20499,8193,64,67927,77835,16401,76159,75102,20529,256,94267,90202,513]

theorem envBound11587 : H12AffineFastState.Bounded env11587 := by
  intro p hp
  have h : env11587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11586_11587 : H12AffineEnvironment.transform 21 94266 env11586 = env11587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94266 env11586 == env11587) = true)

theorem identity11587 : scanCanonicalize (H12AffineFastState.compose env11587 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11587 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8203,16401,30777,1024,29004,5456,20529,17,20499,8193,64,10588,4096,16401,2420,1365,20529,256,20528,16465,513]

theorem envBound11588 : H12AffineFastState.Bounded env11588 := by
  intro p hp
  have h : env11588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11587_11588 : H12AffineEnvironment.transform 15 8203 env11587 = env11588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11587 == env11588) = true)

theorem identity11588 : scanCanonicalize (H12AffineFastState.compose env11588 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound11588 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8203,4097,10281,1024,8540,5456,33,17,3,8193,64,10588,4096,4097,2420,1365,33,256,32,4161,513]

theorem envBound11589 : H12AffineFastState.Bounded env11589 := by
  intro p hp
  have h : env11589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11588_11589 : H12AffineEnvironment.transform 13 4112 env11588 = env11589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env11588 == env11589) = true)

def env11590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,5457,4194304,17,20499,8193,64,4225389,77834,16400,76159,75102,4268042,256,94266,90203,513]

theorem envBound11590 : H12AffineFastState.Bounded env11590 := by
  intro p hp
  have h : env11590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11585_11590 : H12AffineEnvironment.transform 20 5457 env11585 = env11590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env11585 == env11590) = true)

theorem identity11590 : scanCanonicalize (H12AffineFastState.compose env11590 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound11590 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90138,30777,1024,29004,5457,73770,17,20499,8193,64,88391,77834,16400,76159,75102,32,256,94266,90203,513]

theorem envBound11591 : H12AffineFastState.Bounded env11591 := by
  intro p hp
  have h : env11591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11590_11591 : H12AffineEnvironment.transform 21 73770 env11590 = env11591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env11590 == env11591) = true)

theorem identity11591 : scanCanonicalize (H12AffineFastState.compose env11591 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound11591 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,65536,77835,10280,1024,8541,5457,73770,17,2,8193,64,67926,77834,4097,76159,75102,32,256,73771,77898,513]

theorem envBound11592 : H12AffineFastState.Bounded env11592 := by
  intro p hp
  have h : env11592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11591_11592 : H12AffineEnvironment.transform 13 4113 env11591 = env11592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env11591 == env11592) = true)

theorem identity11592 : scanCanonicalize (H12AffineFastState.compose env11592 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound11592 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env11593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,8192,3172,8540,65536,76926,10280,1024,8541,2340,73770,17,2,8193,64,67926,76927,3188,76159,75102,32,256,73771,76863,513]

theorem envBound11593 : H12AffineFastState.Bounded env11593 := by
  intro p hp
  have h : env11593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11592_11593 : H12AffineEnvironment.transform 11 3189 env11592 = env11593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env11592 == env11593) = true)

def env11594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound11594 : H12AffineFastState.Bounded env11594 := by
  intro p hp
  have h : env11594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11481_11594 : H12AffineEnvironment.transform 18 1025 env11481 = env11594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env11481 == env11594) = true)

theorem identity11594 : scanCanonicalize (H12AffineFastState.compose env11594 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 213470) := by decide +kernel

theorem selectedBound11594 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,213470,16777216,8328,64,21266910,18973837,2299022,360927,16958927,23160257,257,19039602,19031254,17031704]

theorem envBound11595 : H12AffineFastState.Bounded env11595 := by
  intro p hp
  have h : env11595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11594_11595 : H12AffineEnvironment.transform 22 213470 env11594 = env11595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 213470 env11594 == env11595) = true)

def env11596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,411972,213470,16777216,8328,64,16959642,18973837,2299022,360927,16958927,19344517,257,19039602,19031254,17031704]

theorem envBound11596 : H12AffineFastState.Bounded env11596 := by
  intro p hp
  have h : env11596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11595_11596 : H12AffineEnvironment.transform 21 411972 env11595 = env11596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 411972 env11595 == env11596) = true)

def env11597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411972,213470,16777216,8328,64,16959642,16974301,102878,360927,16958927,17148373,257,16777250,16834950,17031704]

theorem envBound11597 : H12AffineFastState.Bounded env11597 := by
  intro p hp
  have h : env11597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11596_11597 : H12AffineEnvironment.transform 20 165200 env11596 = env11597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env11596 == env11597) = true)

theorem identity11597 : scanCanonicalize (H12AffineFastState.compose env11597 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound11597 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env11598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115871,329867,17,16777216,8328,64,16877909,16793618,102878,360927,16876544,17148373,257,16777250,16834950,16819159]

theorem envBound11598 : H12AffineFastState.Bounded env11598 := by
  intro p hp
  have h : env11598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11597_11598 : H12AffineEnvironment.transform 16 82383 env11597 = env11598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env11597 == env11598) = true)

def env11599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115871,329867,17,95496,8328,64,64605,79130,102878,360927,61704,318685,257,95530,103566,120543]

theorem envBound11599 : H12AffineFastState.Bounded env11599 := by
  intro p hp
  have h : env11599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11598_11599 : H12AffineEnvironment.transform 23 95496 env11598 = env11599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env11598 == env11599) = true)

theorem identity11599 : scanCanonicalize (H12AffineFastState.compose env11599 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound11599 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38161,262144,1025,32769,4161,318549,17,41430,8328,64,64605,57796,17664,283905,61704,318685,257,41460,16464,513]

theorem envBound11600 : H12AffineFastState.Bounded env11600 := by
  intro p hp
  have h : env11600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11599_11600 : H12AffineEnvironment.transform 15 54494 env11599 = env11600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env11599 == env11600) = true)

def env11601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,4161,318549,17,41310,8192,64,64605,57676,17664,283905,61704,318549,257,41340,16464,513]

theorem envBound11601 : H12AffineFastState.Bounded env11601 := by
  intro p hp
  have h : env11601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11600_11601 : H12AffineEnvironment.transform 6 8 env11600 = env11601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11600 == env11601) = true)

theorem identity11601 : scanCanonicalize (H12AffineFastState.compose env11601 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound11601 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,35189,1025,32769,4161,21792,17,41310,8192,64,64605,57676,17664,56436,61704,21792,257,41340,16464,513]

theorem envBound11602 : H12AffineFastState.Bounded env11602 := by
  intro p hp
  have h : env11602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11601_11602 : H12AffineEnvironment.transform 17 35189 env11601 = env11602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env11601 == env11602) = true)

theorem identity11602 : scanCanonicalize (H12AffineFastState.compose env11602 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound11602 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env11603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9292,28698,12637,11577,1025,9293,4161,21792,17,1298,8192,64,22545,17664,17664,30776,21828,21792,257,1328,16464,513]

theorem envBound11603 : H12AffineFastState.Bounded env11603 := by
  intro p hp
  have h : env11603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11602_11603 : H12AffineEnvironment.transform 14 9292 env11602 = env11603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env11602 == env11603) = true)

theorem identity11603 : scanCanonicalize (H12AffineFastState.compose env11603 (packedSelected [1,8,9,14,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11603 : packedSelected [1,8,9,14,19,22] rootPS < 2^1333 := by decide +kernel

def env11604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1297,20807,4096,3172,1025,1296,4161,21792,17,1298,349,64,22545,17664,17664,22885,21828,21792,257,1328,16464,513]

theorem envBound11604 : H12AffineFastState.Bounded env11604 := by
  intro p hp
  have h : env11604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11603_11604 : H12AffineEnvironment.transform 12 349 env11603 = env11604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11603 == env11604) = true)

def env11605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,4161,318549,17,41311,8193,64,64605,57677,17664,283905,61704,318548,257,41341,16464,513]

theorem envBound11605 : H12AffineFastState.Bounded env11605 := by
  intro p hp
  have h : env11605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11600_11605 : H12AffineEnvironment.transform 6 9 env11600 = env11605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11600 == env11605) = true)

theorem identity11605 : scanCanonicalize (H12AffineFastState.compose env11605 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound11605 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10281,1025,32769,4161,62588,17,41311,8193,64,64605,57677,17664,32040,61704,62589,257,41341,16464,513]

theorem envBound11606 : H12AffineFastState.Bounded env11606 := by
  intro p hp
  have h : env11606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11605_11606 : H12AffineEnvironment.transform 17 10281 env11605 = env11606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11605 == env11606) = true)

theorem identity11606 : scanCanonicalize (H12AffineFastState.compose env11606 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11606 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env11607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,38161,10281,1025,32769,4161,41340,17,41311,8193,64,43357,46157,4096,10280,41992,41341,257,41341,5456,513]

theorem envBound11607 : H12AffineFastState.Bounded env11607 := by
  intro p hp
  have h : env11607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11606_11607 : H12AffineEnvironment.transform 13 5376 env11606 = env11607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11606 == env11607) = true)

theorem identity11607 : scanCanonicalize (H12AffineFastState.compose env11607 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound11607 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,372,35,5221,10281,1025,373,4161,8200,17,8235,8193,64,10281,13625,4096,10280,9596,8201,257,8201,5456,513]

theorem envBound11608 : H12AffineFastState.Bounded env11608 := by
  intro p hp
  have h : env11608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11607_11608 : H12AffineEnvironment.transform 14 372 env11607 = env11608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env11607 == env11608) = true)

theorem identity11608 : scanCanonicalize (H12AffineFastState.compose env11608 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11608 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env11609 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5156,80,35,5221,10281,1025,81,4161,8200,17,8235,8193,64,10281,13341,4096,10280,9304,8201,37,8201,5236,513]

theorem envBound11609 : H12AffineFastState.Bounded env11609 := by
  intro p hp
  have h : env11609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11608_11609 : H12AffineEnvironment.transform 7 36 env11608 = env11609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11608 == env11609) = true)

theorem identity11609 : scanCanonicalize (H12AffineFastState.compose env11609 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11609 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env11610 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,40,5156,80,35,5221,2049,1025,81,4161,32,17,3,41,64,2049,5173,4096,2048,1136,33,37,33,5236,513]

theorem envBound11610 : H12AffineFastState.Bounded env11610 := by
  intro p hp
  have h : env11610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11609_11610 : H12AffineEnvironment.transform 12 40 env11609 = env11610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11609 == env11610) = true)

theorem identity11610 : scanCanonicalize (H12AffineFastState.compose env11610 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound11610 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env11611 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,64,40,1124,80,35,1061,2049,1025,81,1,32,17,3,41,64,2049,1141,64,2048,1136,33,37,33,1076,513]

theorem envBound11611 : H12AffineFastState.Bounded env11611 := by
  intro p hp
  have h : env11611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11610_11611 : H12AffineEnvironment.transform 11 64 env11610 = env11611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env11610 == env11611) = true)

theorem identity11611 : scanCanonicalize (H12AffineFastState.compose env11611 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound11611 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env11612 : List Nat := [2,4,8,16,32,64,9,36,512,1024,1124,64,40,1124,80,35,1061,1125,1025,81,1,32,17,3,41,64,1125,1141,64,1124,1136,33,37,33,1076,513]

theorem envBound11612 : H12AffineFastState.Bounded env11612 := by
  intro p hp
  have h : env11612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11611_11612 : H12AffineEnvironment.transform 10 1124 env11611 = env11612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env11611 == env11612) = true)

theorem identity11612 : scanCanonicalize (H12AffineFastState.compose env11612 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11612 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env11613 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1077,17,40,1077,1,35,1061,1076,1025,0,1,32,17,3,41,17,1076,1060,17,1077,1057,33,37,33,1076,513]

theorem envBound11613 : H12AffineFastState.Bounded env11613 := by
  intro p hp
  have h : env11613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11612_11613 : H12AffineEnvironment.transform 5 17 env11612 = env11613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11612 == env11613) = true)

theorem identity11613 : scanCanonicalize (H12AffineFastState.compose env11613 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11613 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11614 : List Nat := [2,4,8,0,32,1,9,36,512,1024,1061,1,40,1061,1,35,1061,1060,1025,0,1,32,1,3,41,1,1060,1060,1,1061,1057,33,37,33,1060,513]

theorem envBound11614 : H12AffineFastState.Bounded env11614 := by
  intro p hp
  have h : env11614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11613_11614 : H12AffineEnvironment.transform 3 0 env11613 = env11614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11613 == env11614) = true)

theorem identity11614 : scanCanonicalize (H12AffineFastState.compose env11614 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound11614 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11615 : List Nat := [2,4,8,0,32,1,9,36,512,46,11,1,40,11,1,35,11,10,47,0,1,32,1,3,41,1,10,10,1,11,15,33,37,33,10,513]

theorem envBound11615 : H12AffineFastState.Bounded env11615 := by
  intro p hp
  have h : env11615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11614_11615 : H12AffineEnvironment.transform 9 46 env11614 = env11615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env11614 == env11615) = true)

theorem identity11615 : scanCanonicalize (H12AffineFastState.compose env11615 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11615 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11616 : List Nat := [2,4,8,0,10,1,9,14,512,4,11,1,2,11,1,9,11,10,5,0,1,10,1,3,3,1,10,10,1,11,15,11,15,11,10,513]

theorem envBound11616 : H12AffineFastState.Bounded env11616 := by
  intro p hp
  have h : env11616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11615_11616 : H12AffineEnvironment.transform 4 10 env11615 = env11616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11615 == env11616) = true)

theorem identity11616 : scanCanonicalize (H12AffineFastState.compose env11616 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound11616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11617 : List Nat := [2,4,8,0,10,1,9,14,15,4,11,1,2,11,1,9,11,10,5,0,1,10,1,3,3,1,10,10,1,11,15,11,15,11,10,14]

theorem envBound11617 : H12AffineFastState.Bounded env11617 := by
  intro p hp
  have h : env11617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11616_11617 : H12AffineEnvironment.transform 8 15 env11616 = env11617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env11616 == env11617) = true)

theorem identity11617 : scanCanonicalize (H12AffineFastState.compose env11617 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11617 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env11618 : List Nat := [2,4,3,0,1,1,2,5,4,4,0,1,2,0,1,2,0,1,5,0,1,1,1,3,3,1,1,1,1,0,4,0,4,0,1,5]

theorem envBound11618 : H12AffineFastState.Bounded env11618 := by
  intro p hp
  have h : env11618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11617_11618 : H12AffineEnvironment.transform 2 3 env11617 = env11618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11617 == env11618) = true)

theorem identity11618 : scanCanonicalize (H12AffineFastState.compose env11618 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11619 : List Nat := [1,4,0,0,1,1,1,5,4,4,0,1,1,0,1,1,0,1,5,0,1,1,1,0,0,1,1,1,1,0,4,0,4,0,1,5]

theorem envBound11619 : H12AffineFastState.Bounded env11619 := by
  intro p hp
  have h : env11619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11618_11619 : H12AffineEnvironment.transform 0 1 env11618 = env11619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11618 == env11619) = true)

def env11620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115871,329867,17,95497,8328,64,64604,79131,102878,360927,61705,318684,257,95531,103567,120542]

theorem envBound11620 : H12AffineFastState.Bounded env11620 := by
  intro p hp
  have h : env11620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11598_11620 : H12AffineEnvironment.transform 23 95497 env11598 = env11620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env11598 == env11620) = true)

def env11621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115735,329731,17,95497,8192,64,64604,79131,102742,360791,61705,318548,257,95531,103431,120406]

theorem envBound11621 : H12AffineFastState.Bounded env11621 := by
  intro p hp
  have h : env11621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11620_11621 : H12AffineEnvironment.transform 6 8 env11620 = env11621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11620 == env11621) = true)

theorem identity11621 : scanCanonicalize (H12AffineFastState.compose env11621 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound11621 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,89378,1025,32769,115735,21793,17,95497,8192,64,64604,79131,102742,56437,61705,98678,257,95531,103431,120406]

theorem envBound11622 : H12AffineFastState.Bounded env11622 := by
  intro p hp
  have h : env11622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11621_11622 : H12AffineEnvironment.transform 17 89378 env11621 = env11622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env11621 == env11622) = true)

theorem identity11622 : scanCanonicalize (H12AffineFastState.compose env11622 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11622 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,89378,1025,32769,115735,21793,17,87124,349,64,56577,70726,102742,56437,53332,98678,257,87158,103431,120406]

theorem envBound11623 : H12AffineFastState.Bounded env11623 := by
  intro p hp
  have h : env11623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11622_11623 : H12AffineEnvironment.transform 12 349 env11622 = env11623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11622 == env11623) = true)

def env11624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115734,329730,17,95497,8193,64,64604,79131,102743,360790,61705,318549,257,95531,103430,120407]

theorem envBound11624 : H12AffineFastState.Bounded env11624 := by
  intro p hp
  have h : env11624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11620_11624 : H12AffineEnvironment.transform 6 9 env11620 = env11624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11620 == env11624) = true)

theorem identity11624 : scanCanonicalize (H12AffineFastState.compose env11624 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound11624 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,130175,1025,32769,115734,62589,17,95497,8193,64,64604,79131,102743,32041,61705,73770,257,95531,103430,120407]

theorem envBound11625 : H12AffineFastState.Bounded env11625 := by
  intro p hp
  have h : env11625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11624_11625 : H12AffineEnvironment.transform 17 130175 env11624 = env11625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env11624 == env11625) = true)

theorem identity11625 : scanCanonicalize (H12AffineFastState.compose env11625 (packedSelected [1,2,3,6,8,11,12,14,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11625 : packedSelected [1,2,3,6,8,11,12,14,19,20,24] rootPS < 2^1333 := by decide +kernel

def env11626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,65536,82246,122226,1025,32769,115734,54640,17,87044,268,64,56657,70678,102743,23588,53252,65831,257,87078,103430,120407]

theorem envBound11626 : H12AffineFastState.Bounded env11626 := by
  intro p hp
  have h : env11626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11625_11626 : H12AffineEnvironment.transform 12 269 env11625 = env11626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11625 == env11626) = true)

theorem identity11626 : scanCanonicalize (H12AffineFastState.compose env11626 (packedSelected [1,2,4,6,8,16,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11626 : packedSelected [1,2,4,6,8,16,19,22] rootPS < 2^1333 := by decide +kernel

def env11627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,0,65536,82246,89458,1025,1,82966,21872,17,87044,268,64,23889,70678,69975,23588,20484,65831,257,87078,70662,87639]

theorem envBound11627 : H12AffineFastState.Bounded env11627 := by
  intro p hp
  have h : env11627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11626_11627 : H12AffineEnvironment.transform 14 0 env11626 = env11627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11626 == env11627) = true)

theorem identity11627 : scanCanonicalize (H12AffineFastState.compose env11627 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound11627 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env11628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,0,21510,5440,2420,1025,1,4112,21872,17,2,268,64,23889,16400,17745,23588,20484,21793,257,32,16384,593]

theorem envBound11628 : H12AffineFastState.Bounded env11628 := by
  intro p hp
  have h : env11628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11627_11628 : H12AffineEnvironment.transform 15 21510 env11627 = env11628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env11627 == env11628) = true)

theorem identity11628 : scanCanonicalize (H12AffineFastState.compose env11628 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound11628 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env11629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,3344,0,6422,5440,2420,1025,1,4112,6240,17,2,268,64,4161,3328,2113,4404,7444,6193,257,32,3344,593]

theorem envBound11629 : H12AffineFastState.Bounded env11629 := by
  intro p hp
  have h : env11629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11628_11629 : H12AffineEnvironment.transform 13 3344 env11628 = env11629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env11628 == env11629) = true)

theorem identity11629 : scanCanonicalize (H12AffineFastState.compose env11629 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound11629 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env11630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,269,3344,0,343,3329,2420,1025,1,2129,33,17,2,268,64,2048,3328,2113,2421,1365,112,257,32,3344,593]

theorem envBound11630 : H12AffineFastState.Bounded env11630 := by
  intro p hp
  have h : env11630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11629_11630 : H12AffineEnvironment.transform 11 2113 env11629 = env11630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env11629 == env11630) = true)

theorem identity11630 : scanCanonicalize (H12AffineFastState.compose env11630 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound11630 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env11631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,113,48,269,1377,0,343,1392,261,1025,1,32,33,17,2,268,64,113,1393,48,260,1365,112,257,32,1377,593]

theorem envBound11631 : H12AffineFastState.Bounded env11631 := by
  intro p hp
  have h : env11631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11630_11631 : H12AffineEnvironment.transform 10 113 env11630 = env11631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env11630 == env11631) = true)

theorem identity11631 : scanCanonicalize (H12AffineFastState.compose env11631 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11631 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env11632 : List Nat := [2,4,8,16,32,64,9,36,512,1024,113,48,41,1093,0,115,1108,33,1025,1,32,33,17,2,40,64,113,1109,48,32,1137,112,37,32,1093,593]

theorem envBound11632 : H12AffineFastState.Bounded env11632 := by
  intro p hp
  have h : env11632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11631_11632 : H12AffineEnvironment.transform 7 36 env11631 = env11632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11631 == env11632) = true)

theorem identity11632 : scanCanonicalize (H12AffineFastState.compose env11632 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 106) := by decide +kernel

theorem selectedBound11632 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env11633 : List Nat := [2,4,8,16,32,64,9,36,512,106,113,48,41,47,0,115,62,33,107,1,32,33,17,2,40,64,113,63,48,32,27,112,37,32,47,593]

theorem envBound11633 : H12AffineFastState.Bounded env11633 := by
  intro p hp
  have h : env11633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11632_11633 : H12AffineEnvironment.transform 9 106 env11632 = env11633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 106 env11632 == env11633) = true)

theorem identity11633 : scanCanonicalize (H12AffineFastState.compose env11633 (packedSelected [0,3,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 30) := by decide +kernel

theorem selectedBound11633 : packedSelected [0,3,6,8] rootPS < 2^1333 := by decide +kernel

def env11634 : List Nat := [2,4,8,16,32,30,9,36,512,52,47,48,41,47,0,45,62,33,53,1,32,33,17,2,40,30,47,63,48,32,27,46,37,32,47,527]

theorem envBound11634 : H12AffineFastState.Bounded env11634 := by
  intro p hp
  have h : env11634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11633_11634 : H12AffineEnvironment.transform 5 30 env11633 = env11634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 30 env11633 == env11634) = true)

theorem identity11634 : scanCanonicalize (H12AffineFastState.compose env11634 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11634 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env11635 : List Nat := [2,4,8,16,1,30,9,5,512,21,14,17,8,14,0,12,31,0,20,1,1,0,17,2,9,30,14,30,17,1,27,15,4,1,14,527]

theorem envBound11635 : H12AffineFastState.Bounded env11635 := by
  intro p hp
  have h : env11635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11634_11635 : H12AffineEnvironment.transform 4 1 env11634 = env11635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11634 == env11635) = true)

theorem identity11635 : scanCanonicalize (H12AffineFastState.compose env11635 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound11635 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11636 : List Nat := [2,2,8,16,1,24,9,3,512,19,8,17,8,8,0,10,25,0,18,1,1,0,17,2,9,24,8,24,17,1,27,9,2,1,8,521]

theorem envBound11636 : H12AffineFastState.Bounded env11636 := by
  intro p hp
  have h : env11636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11635_11636 : H12AffineEnvironment.transform 1 2 env11635 = env11636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env11635 == env11636) = true)

theorem identity11636 : scanCanonicalize (H12AffineFastState.compose env11636 (packedSelected [2,6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound11636 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11637 : List Nat := [2,2,0,16,1,16,1,3,512,19,0,17,0,0,0,2,17,0,18,1,1,0,17,2,1,16,0,16,17,1,19,1,2,1,0,513]

theorem envBound11637 : H12AffineFastState.Bounded env11637 := by
  intro p hp
  have h : env11637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11636_11637 : H12AffineEnvironment.transform 2 0 env11636 = env11637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env11636 == env11637) = true)

theorem identity11637 : scanCanonicalize (H12AffineFastState.compose env11637 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound11637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11638 : List Nat := [2,2,0,16,1,16,1,3,3,19,0,17,0,0,0,2,17,0,18,1,1,0,17,2,1,16,0,16,17,1,19,1,2,1,0,2]

theorem envBound11638 : H12AffineFastState.Bounded env11638 := by
  intro p hp
  have h : env11638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11637_11638 : H12AffineEnvironment.transform 8 3 env11637 = env11638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env11637 == env11638) = true)

def env11639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411972,213470,16777216,8328,64,16959642,16974300,102879,360927,16958927,17148372,257,16777251,16834951,17031704]

theorem envBound11639 : H12AffineFastState.Bounded env11639 := by
  intro p hp
  have h : env11639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11596_11639 : H12AffineEnvironment.transform 20 165201 env11596 = env11639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env11596 == env11639) = true)

theorem identity11639 : scanCanonicalize (H12AffineFastState.compose env11639 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 106504) := by decide +kernel

theorem selectedBound11639 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env11640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411972,213470,106504,8328,64,223378,172500,102879,360927,222663,264668,257,106539,82319,147984]

theorem envBound11640 : H12AffineFastState.Bounded env11640 := by
  intro p hp
  have h : env11640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11639_11640 : H12AffineEnvironment.transform 23 106504 env11639 = env11640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 106504 env11639 == env11640) = true)

def env11641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,131072,262144,1025,21761,151633,411972,213470,95496,8328,64,223378,160980,83167,349407,222663,264668,257,95531,82319,147984]

theorem envBound11641 : H12AffineFastState.Bounded env11641 := by
  intro p hp
  have h : env11641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11640_11641 : H12AffineEnvironment.transform 14 21760 env11640 = env11641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env11640 == env11641) = true)

theorem identity11641 : scanCanonicalize (H12AffineFastState.compose env11641 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound11641 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90138,262144,1025,21761,77899,338270,8644,95496,8328,64,2184,70862,83167,349407,1501,264668,257,95531,82319,74250]

theorem envBound11642 : H12AffineFastState.Bounded env11642 := by
  intro p hp
  have h : env11642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11641_11642 : H12AffineEnvironment.transform 16 90138 env11641 = env11642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env11641 == env11642) = true)

theorem identity11642 : scanCanonicalize (H12AffineFastState.compose env11642 (packedSelected [0,1,9,10,11,12,15,17,19,22,27,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 32241) := by decide +kernel

theorem selectedBound11642 : packedSelected [0,1,9,10,11,12,15,17,19,22,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env11643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90138,32241,1025,21761,77899,87215,8644,95496,8328,64,2184,70862,83167,76078,1501,29741,257,95531,82319,74250]

theorem envBound11643 : H12AffineFastState.Bounded env11643 := by
  intro p hp
  have h : env11643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11642_11643 : H12AffineEnvironment.transform 17 32241 env11642 = env11643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env11642 == env11643) = true)

theorem identity11643 : scanCanonicalize (H12AffineFastState.compose env11643 (packedSelected [0,4,7,17,18,19,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound11643 : packedSelected [0,4,7,17,18,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env11644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,65536,70727,2476,1025,8540,77899,73970,8644,65877,8328,64,2184,70862,77954,76078,1501,112,257,65910,79314,74250]

theorem envBound11644 : H12AffineFastState.Bounded env11644 := by
  intro p hp
  have h : env11644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11643_11644 : H12AffineEnvironment.transform 13 13405 env11643 = env11644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env11643 == env11644) = true)

theorem identity11644 : scanCanonicalize (H12AffineFastState.compose env11644 (packedSelected [10,11,12,14,15,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound11644 : packedSelected [10,11,12,14,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env11645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,478,5529,2476,1025,8540,12693,8492,8644,139,8328,64,2184,5392,12636,10480,1501,112,257,168,13324,9172]

theorem envBound11645 : H12AffineFastState.Bounded env11645 := by
  intro p hp
  have h : env11645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11644_11645 : H12AffineEnvironment.transform 15 478 env11644 = env11645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env11644 == env11645) = true)

theorem identity11645 : scanCanonicalize (H12AffineFastState.compose env11645 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound11645 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env11646 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13405,8541,263,5440,2421,1025,8540,12620,8492,8477,82,8273,64,2129,5392,12636,10281,1284,112,257,113,13324,8973]

theorem envBound11646 : H12AffineFastState.Bounded env11646 := by
  intro p hp
  have h : env11646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11645_11646 : H12AffineEnvironment.transform 6 89 env11645 = env11646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env11645 == env11646) = true)

theorem identity11646 : scanCanonicalize (H12AffineFastState.compose env11646 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11646 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11647 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,8460,263,5393,2340,1025,8461,12573,8492,8477,3,8192,17,2048,5392,12557,10281,1284,33,257,32,13324,8973]

theorem envBound11647 : H12AffineFastState.Bounded env11647 := by
  intro p hp
  have h : env11647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11646_11647 : H12AffineEnvironment.transform 5 17 env11646 = env11647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11646 == env11647) = true)

theorem identity11647 : scanCanonicalize (H12AffineFastState.compose env11647 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11647 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11648 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,13324,8232,35,5173,2048,1025,8233,12345,8200,8249,3,8192,17,2048,5172,12329,10281,1056,33,37,32,13324,8745]

theorem envBound11648 : H12AffineFastState.Bounded env11648 := by
  intro p hp
  have h : env11648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11647_11648 : H12AffineEnvironment.transform 7 36 env11647 = env11648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11647 == env11648) = true)

theorem identity11648 : scanCanonicalize (H12AffineFastState.compose env11648 (packedSelected [3,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound11648 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env11649 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,7180,2048,7204,35,5173,2048,1025,7205,3125,7172,7221,3,7180,17,2048,5172,3109,5157,1056,33,37,32,2048,7717]

theorem envBound11649 : H12AffineFastState.Bounded env11649 := by
  intro p hp
  have h : env11649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11648_11649 : H12AffineEnvironment.transform 12 7180 env11648 = env11649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env11648 == env11649) = true)

theorem identity11649 : scanCanonicalize (H12AffineFastState.compose env11649 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound11649 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env11650 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,3108,40,2048,0,35,2065,2048,1025,1,3125,32,17,3,40,17,2048,2064,3109,2049,1056,33,37,32,2048,513]

theorem envBound11650 : H12AffineFastState.Bounded env11650 := by
  intro p hp
  have h : env11650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11649_11650 : H12AffineEnvironment.transform 11 3108 env11649 = env11650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env11649 == env11650) = true)

theorem identity11650 : scanCanonicalize (H12AffineFastState.compose env11650 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound11650 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11651 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,17,40,1077,0,35,1060,1077,1025,1,0,32,17,3,40,17,1077,1061,16,1076,1056,33,37,32,1077,513]

theorem envBound11651 : H12AffineFastState.Bounded env11651 := by
  intro p hp
  have h : env11651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11650_11651 : H12AffineEnvironment.transform 10 1077 env11650 = env11651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env11650 == env11651) = true)

theorem identity11651 : scanCanonicalize (H12AffineFastState.compose env11651 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11651 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11652 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,17,40,0,0,35,17,0,52,1,0,32,17,3,40,17,0,16,16,1,21,33,37,32,0,513]

theorem envBound11652 : H12AffineFastState.Bounded env11652 := by
  intro p hp
  have h : env11652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11651_11652 : H12AffineEnvironment.transform 9 53 env11651 = env11652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11651 == env11652) = true)

theorem identity11652 : scanCanonicalize (H12AffineFastState.compose env11652 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound11652 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11653 : List Nat := [2,4,8,16,16,17,8,20,512,5,0,17,24,0,0,19,17,0,4,1,0,16,17,3,24,17,0,16,16,1,21,17,21,16,0,513]

theorem envBound11653 : H12AffineFastState.Bounded env11653 := by
  intro p hp
  have h : env11653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11652_11653 : H12AffineEnvironment.transform 4 16 env11652 = env11653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env11652 == env11653) = true)

def env11654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,131072,262144,1025,21760,151632,411972,213470,95497,8328,64,223378,160981,83166,349406,222663,264668,257,95530,82319,147984]

theorem envBound11654 : H12AffineFastState.Bounded env11654 := by
  intro p hp
  have h : env11654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11640_11654 : H12AffineEnvironment.transform 14 21761 env11640 = env11654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env11640 == env11654) = true)

theorem identity11654 : scanCanonicalize (H12AffineFastState.compose env11654 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound11654 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,131072,262144,1025,21760,151632,411972,156117,21762,8328,64,149657,160981,25813,292053,148940,264668,257,21793,24964,147984]

theorem envBound11655 : H12AffineFastState.Bounded env11655 := by
  intro p hp
  have h : env11655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11654_11655 : H12AffineEnvironment.transform 15 8203 env11654 = env11655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env11654 == env11655) = true)

def env11656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,131072,10280,1025,21760,151632,156012,156117,21762,8328,64,149657,160981,25813,23805,148940,8692,257,21793,24964,147984]

theorem envBound11656 : H12AffineFastState.Bounded env11656 := by
  intro p hp
  have h : env11656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11655_11656 : H12AffineEnvironment.transform 17 10280 env11655 = env11656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env11655 == env11656) = true)

theorem identity11656 : scanCanonicalize (H12AffineFastState.compose env11656 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 17800) := by decide +kernel

theorem selectedBound11656 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,17800,10280,1025,21760,5592,9444,9309,21762,8328,64,3345,12637,25813,23805,68,8692,257,21793,24964,1944]

theorem envBound11657 : H12AffineFastState.Bounded env11657 := by
  intro p hp
  have h : env11657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11656_11657 : H12AffineEnvironment.transform 16 17800 env11656 = env11657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17800 env11656 == env11657) = true)

theorem identity11657 : scanCanonicalize (H12AffineFastState.compose env11657 (packedSelected [1,2,4,6,8,11,17,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 1456) := by decide +kernel

theorem selectedBound11657 : packedSelected [1,2,4,6,8,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,16384,21761,1467,17800,3480,1025,21760,5592,340,493,21762,1336,64,3345,5357,16741,23805,68,1092,257,21793,17460,1944]

theorem envBound11658 : H12AffineFastState.Bounded env11658 := by
  intro p hp
  have h : env11658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11657_11658 : H12AffineEnvironment.transform 12 1456 env11657 = env11658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env11657 == env11658) = true)

theorem identity11658 : scanCanonicalize (H12AffineFastState.compose env11658 (packedSelected [1,3,4,7,9,12,15,17,24,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound11658 : packedSelected [1,3,4,7,9,12,15,17,24,27,28] rootPS < 2^1333 := by decide +kernel

def env11659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,4405,1076,1467,5309,3480,1025,1077,5592,340,493,1079,1336,64,3345,5357,4176,3528,68,1092,257,1044,5377,1944]

theorem envBound11659 : H12AffineFastState.Bounded env11659 := by
  intro p hp
  have h : env11659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11658_11659 : H12AffineEnvironment.transform 13 4405 env11658 = env11659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env11658 == env11659) = true)

theorem identity11659 : scanCanonicalize (H12AffineFastState.compose env11659 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound11659 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11660 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,1100,4297,1076,1095,5309,3172,1025,1077,5156,168,17,1079,1220,64,3309,5357,4176,3124,68,1092,253,1044,5373,1636]

theorem envBound11660 : H12AffineFastState.Bounded env11660 := by
  intro p hp
  have h : env11660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11659_11660 : H12AffineEnvironment.transform 7 252 env11659 = env11660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env11659 == env11660) = true)

theorem identity11660 : scanCanonicalize (H12AffineFastState.compose env11660 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound11660 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env11661 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,4096,161,4297,217,170,4176,2185,236,216,4297,168,17,218,41,64,2048,4096,4176,2265,68,169,253,249,4112,649]

theorem envBound11661 : H12AffineFastState.Bounded env11661 := by
  intro p hp
  have h : env11661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11660_11661 : H12AffineEnvironment.transform 9 237 env11660 = env11661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env11660 == env11661) = true)

theorem identity11661 : scanCanonicalize (H12AffineFastState.compose env11661 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound11661 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env11662 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,2064,161,2265,217,170,2112,2185,236,216,2265,168,17,218,41,64,2048,2064,2112,2265,68,169,253,249,2048,649]

theorem envBound11662 : H12AffineFastState.Bounded env11662 := by
  intro p hp
  have h : env11662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11661_11662 : H12AffineEnvironment.transform 11 2064 env11661 = env11662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env11661 == env11662) = true)

theorem identity11662 : scanCanonicalize (H12AffineFastState.compose env11662 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound11662 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11663 : List Nat := [2,4,8,16,32,64,88,36,512,53,2048,2064,121,2049,1,114,2112,2129,52,0,2049,112,17,2,41,64,2048,2064,2112,2049,68,113,37,33,2048,593]

theorem envBound11663 : H12AffineFastState.Bounded env11663 := by
  intro p hp
  have h : env11663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11662_11663 : H12AffineEnvironment.transform 6 88 env11662 = env11663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11662 == env11663) = true)

theorem identity11663 : scanCanonicalize (H12AffineFastState.compose env11663 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound11663 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env11664 : List Nat := [2,4,8,16,32,64,88,36,512,53,81,65,121,80,1,114,17,0,52,0,80,112,17,2,41,64,81,65,17,80,68,113,37,33,81,593]

theorem envBound11664 : H12AffineFastState.Bounded env11664 := by
  intro p hp
  have h : env11664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11663_11664 : H12AffineEnvironment.transform 10 81 env11663 = env11664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env11663 == env11664) = true)

theorem identity11664 : scanCanonicalize (H12AffineFastState.compose env11664 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11664 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env11665 : List Nat := [2,4,8,16,32,17,9,36,512,53,0,16,40,1,1,35,17,0,52,0,1,33,17,2,41,17,0,16,17,1,21,32,37,33,0,512]

theorem envBound11665 : H12AffineFastState.Bounded env11665 := by
  intro p hp
  have h : env11665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11664_11665 : H12AffineEnvironment.transform 5 17 env11664 = env11665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11664 == env11665) = true)

theorem identity11665 : scanCanonicalize (H12AffineFastState.compose env11665 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound11665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11666 : List Nat := [2,4,8,16,32,17,9,36,0,53,0,16,40,1,1,35,17,0,52,0,1,33,17,2,41,17,0,16,17,1,21,32,37,33,0,0]

theorem envBound11666 : H12AffineFastState.Bounded env11666 := by
  intro p hp
  have h : env11666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11665_11666 : H12AffineEnvironment.transform 8 0 env11665 = env11666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11665 == env11666) = true)

theorem identity11666 : scanCanonicalize (H12AffineFastState.compose env11666 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound11666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11667 : List Nat := [2,4,8,16,30,17,9,26,0,11,0,16,22,1,1,29,17,0,10,0,1,31,17,2,23,17,0,16,17,1,21,30,27,31,0,0]

theorem envBound11667 : H12AffineFastState.Bounded env11667 := by
  intro p hp
  have h : env11667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11666_11667 : H12AffineEnvironment.transform 4 30 env11666 = env11667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env11666 == env11667) = true)

theorem identity11667 : scanCanonicalize (H12AffineFastState.compose env11667 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound11667 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11668 : List Nat := [2,4,8,15,1,14,9,5,0,11,0,15,9,1,1,2,14,0,10,0,1,0,14,2,8,14,0,15,14,1,10,1,4,0,0,0]

theorem envBound11668 : H12AffineFastState.Bounded env11668 := by
  intro p hp
  have h : env11668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11667_11668 : H12AffineEnvironment.transform 3 15 env11667 = env11668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env11667 == env11668) = true)

def env11669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,131072,10281,1025,21760,151632,156013,156117,21762,8328,64,149657,160981,25813,23804,148940,8693,257,21793,24964,147984]

theorem envBound11669 : H12AffineFastState.Bounded env11669 := by
  intro p hp
  have h : env11669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11655_11669 : H12AffineEnvironment.transform 17 10281 env11655 = env11669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env11655 == env11669) = true)

theorem identity11669 : scanCanonicalize (H12AffineFastState.compose env11669 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound11669 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,13388,10281,1025,21760,25628,21793,21913,21762,8328,64,31957,16537,25813,23804,29056,8693,257,21793,24964,30300]

theorem envBound11670 : H12AffineFastState.Bounded env11670 := by
  intro p hp
  have h : env11670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11669_11670 : H12AffineEnvironment.transform 16 13388 env11669 = env11670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env11669 == env11670) = true)

def env11671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,411973,213470,16777216,8328,64,16959643,18973837,2299022,360927,16958927,19344516,257,19039602,19031254,17031704]

theorem envBound11671 : H12AffineFastState.Bounded env11671 := by
  intro p hp
  have h : env11671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11595_11671 : H12AffineEnvironment.transform 21 411973 env11595 = env11671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 411973 env11595 == env11671) = true)

def env11672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411973,213470,16777216,8328,64,16959643,16974301,102878,360927,16958927,17148372,257,16777250,16834950,17031704]

theorem envBound11672 : H12AffineFastState.Bounded env11672 := by
  intro p hp
  have h : env11672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11671_11672 : H12AffineEnvironment.transform 20 165200 env11671 = env11672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env11671 == env11672) = true)

def env11673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318549,120014,16777216,8328,64,16801163,16880845,102878,360927,16797919,17148372,257,16777250,16834950,16873224]

theorem envBound11673 : H12AffineFastState.Bounded env11673 := by
  intro p hp
  have h : env11673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11672_11673 : H12AffineEnvironment.transform 16 38160 env11672 = env11673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env11672 == env11673) = true)

theorem identity11673 : scanCanonicalize (H12AffineFastState.compose env11673 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound11673 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318549,120014,95497,8328,64,75906,57796,102878,360927,75222,318685,257,95531,103567,513]

theorem envBound11674 : H12AffineFastState.Bounded env11674 := by
  intro p hp
  have h : env11674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11673_11674 : H12AffineEnvironment.transform 23 95497 env11673 = env11674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env11673 == env11674) = true)

def env11675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318549,119878,95497,8192,64,75786,57676,102742,360791,75102,318549,257,95531,103431,513]

theorem envBound11675 : H12AffineFastState.Bounded env11675 := by
  intro p hp
  have h : env11675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11674_11675 : H12AffineEnvironment.transform 6 8 env11674 = env11675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11674 == env11675) = true)

theorem identity11675 : scanCanonicalize (H12AffineFastState.compose env11675 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound11675 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env11676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,4160,318549,8524,32771,8192,64,56576,57676,25692,291933,53332,318549,257,32801,24845,513]

theorem envBound11676 : H12AffineFastState.Bounded env11676 := by
  intro p hp
  have h : env11676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11675_11676 : H12AffineEnvironment.transform 15 62730 env11675 = env11676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env11675 == env11676) = true)

theorem identity11676 : scanCanonicalize (H12AffineFastState.compose env11676 (packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound11676 : packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env11677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38160,22884,1025,32769,4160,34097,8524,32771,8192,64,56576,57676,25692,11577,53332,34097,257,32801,24845,513]

theorem envBound11677 : H12AffineFastState.Bounded env11677 := by
  intro p hp
  have h : env11677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11676_11677 : H12AffineEnvironment.transform 17 22884 env11676 = env11677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env11676 == env11677) = true)

theorem identity11677 : scanCanonicalize (H12AffineFastState.compose env11677 (packedSelected [0,4,8,9,10,17,20,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11677 : packedSelected [0,4,8,9,10,17,20,27,28] rootPS < 2^1333 := by decide +kernel

def env11678 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,62730,38160,22837,1025,32769,4113,34097,8477,32771,8192,17,56576,57629,25613,11577,53253,34097,257,32801,24845,513]

theorem envBound11678 : H12AffineFastState.Bounded env11678 := by
  intro p hp
  have h : env11678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11677_11678 : H12AffineEnvironment.transform 5 17 env11677 = env11678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11677 == env11678) = true)

theorem identity11678 : scanCanonicalize (H12AffineFastState.compose env11678 (packedSelected [0,2,4,6,7,9,12,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound11678 : packedSelected [0,2,4,6,7,9,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env11679 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1336,16384,32768,53298,38160,22837,1025,32769,4113,34097,1061,32771,1336,17,56576,50213,16693,2049,53253,34097,257,32801,17461,513]

theorem envBound11679 : H12AffineFastState.Bounded env11679 := by
  intro p hp
  have h : env11679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11678_11679 : H12AffineEnvironment.transform 12 1336 env11678 = env11679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env11678 == env11679) = true)

theorem identity11679 : scanCanonicalize (H12AffineFastState.compose env11679 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 20788) := by decide +kernel

theorem selectedBound11679 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env11680 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1336,16384,20788,262,17444,22837,1025,20789,4113,21509,1061,20791,1336,17,3124,5393,16693,2049,305,21509,257,20757,17461,513]

theorem envBound11680 : H12AffineFastState.Bounded env11680 := by
  intro p hp
  have h : env11680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11679_11680 : H12AffineEnvironment.transform 14 20788 env11679 = env11680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20788 env11679 == env11680) = true)

theorem identity11680 : scanCanonicalize (H12AffineFastState.compose env11680 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound11680 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11681 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,268,16384,20788,262,16400,22837,53,20789,4113,20529,17,20791,268,17,2048,4389,16693,2049,305,20529,257,20757,16385,513]

theorem envBound11681 : H12AffineFastState.Bounded env11681 := by
  intro p hp
  have h : env11681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11680_11681 : H12AffineEnvironment.transform 9 52 env11680 = env11681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env11680 == env11681) = true)

theorem identity11681 : scanCanonicalize (H12AffineFastState.compose env11681 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound11681 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env11682 : List Nat := [2,4,8,16,32,17,8,256,512,52,32,4096,268,16384,20788,262,16400,20757,53,20789,4113,20529,17,20791,268,17,32,4389,16693,33,305,20529,257,20757,16385,513]

theorem envBound11682 : H12AffineFastState.Bounded env11682 := by
  intro p hp
  have h : env11682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11681_11682 : H12AffineEnvironment.transform 10 32 env11681 = env11682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env11681 == env11682) = true)

theorem identity11682 : scanCanonicalize (H12AffineFastState.compose env11682 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound11682 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11683 : List Nat := [2,4,8,16,32,17,8,256,512,52,32,4096,268,4112,292,262,4096,261,53,293,4113,33,17,295,268,17,32,4389,4389,33,305,33,257,261,4113,513]

theorem envBound11683 : H12AffineFastState.Bounded env11683 := by
  intro p hp
  have h : env11683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11682_11683 : H12AffineEnvironment.transform 13 4112 env11682 = env11683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env11682 == env11683) = true)

theorem identity11683 : scanCanonicalize (H12AffineFastState.compose env11683 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound11683 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11684 : List Nat := [2,4,8,16,32,17,8,256,512,52,32,33,268,49,292,262,33,261,53,293,48,33,17,295,268,17,32,260,260,33,305,33,257,261,48,513]

theorem envBound11684 : H12AffineFastState.Bounded env11684 := by
  intro p hp
  have h : env11684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11683_11684 : H12AffineEnvironment.transform 11 33 env11683 = env11684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env11683 == env11684) = true)

theorem identity11684 : scanCanonicalize (H12AffineFastState.compose env11684 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound11684 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env11685 : List Nat := [2,4,8,16,32,17,8,256,261,52,32,33,268,49,292,262,33,261,53,293,48,33,17,295,268,17,32,260,260,33,305,33,257,261,48,260]

theorem envBound11685 : H12AffineFastState.Bounded env11685 := by
  intro p hp
  have h : env11685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11684_11685 : H12AffineEnvironment.transform 8 261 env11684 = env11685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env11684 == env11685) = true)

theorem identity11685 : scanCanonicalize (H12AffineFastState.compose env11685 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound11685 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11686 : List Nat := [2,4,8,16,16,17,8,256,261,4,16,17,268,1,276,262,17,261,5,277,0,17,17,279,268,17,16,260,260,17,257,17,257,261,0,260]

theorem envBound11686 : H12AffineFastState.Bounded env11686 := by
  intro p hp
  have h : env11686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11685_11686 : H12AffineEnvironment.transform 4 16 env11685 = env11686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env11685 == env11686) = true)

theorem identity11686 : scanCanonicalize (H12AffineFastState.compose env11686 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11686 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11687 : List Nat := [2,4,8,16,16,17,8,5,0,4,16,17,9,1,17,3,17,0,5,16,0,17,17,18,9,17,16,1,1,17,4,17,4,0,0,1]

theorem envBound11687 : H12AffineFastState.Bounded env11687 := by
  intro p hp
  have h : env11687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11686_11687 : H12AffineEnvironment.transform 7 5 env11686 = env11687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11686 == env11687) = true)

theorem identity11687 : scanCanonicalize (H12AffineFastState.compose env11687 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11687 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env11688 : List Nat := [2,4,8,0,0,1,8,5,0,4,0,1,9,1,1,3,1,0,5,0,0,1,1,2,9,1,0,1,1,1,4,1,4,0,0,1]

theorem envBound11688 : H12AffineFastState.Bounded env11688 := by
  intro p hp
  have h : env11688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11687_11688 : H12AffineEnvironment.transform 3 0 env11687 = env11688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11687 == env11688) = true)

def env11689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318549,119879,95497,8193,64,75787,57677,102743,360790,75103,318548,257,95531,103430,513]

theorem envBound11689 : H12AffineFastState.Bounded env11689 := by
  intro p hp
  have h : env11689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11674_11689 : H12AffineEnvironment.transform 6 9 env11674 = env11689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11674 == env11689) = true)

theorem identity11689 : scanCanonicalize (H12AffineFastState.compose env11689 (packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound11689 : packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env11690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35189,1025,32769,4160,21792,119879,95497,8193,64,75787,57677,102743,67619,75103,21793,257,95531,103430,513]

theorem envBound11690 : H12AffineFastState.Bounded env11690 := by
  intro p hp
  have h : env11690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11689_11690 : H12AffineEnvironment.transform 17 35189 env11689 = env11690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env11689 == env11690) = true)

theorem identity11690 : scanCanonicalize (H12AffineFastState.compose env11690 (packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound11690 : packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env11691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,38160,35189,1025,32769,4160,21792,41244,82,8193,64,23888,57677,58380,32120,20484,21793,257,112,57693,513]

theorem envBound11691 : H12AffineFastState.Bounded env11691 := by
  intro p hp
  have h : env11691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11690_11691 : H12AffineEnvironment.transform 15 30043 env11690 = env11691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env11690 == env11691) = true)

theorem identity11691 : scanCanonicalize (H12AffineFastState.compose env11691 (packedSelected [2,3,5,6,10,12,15,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound11691 : packedSelected [2,3,5,6,10,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env11692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,8202,38160,35189,1025,32769,4160,113,41244,82,8193,64,2049,46108,45405,10281,1365,112,257,112,46092,513]

theorem envBound11692 : H12AffineFastState.Bounded env11692 := by
  intro p hp
  have h : env11692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11691_11692 : H12AffineEnvironment.transform 13 5457 env11691 = env11692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env11691 == env11692) = true)

theorem identity11692 : scanCanonicalize (H12AffineFastState.compose env11692 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound11692 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,0,8202,5392,2421,1025,1,4160,113,8476,82,8193,64,2049,13340,12637,10281,1365,112,257,112,13324,513]

theorem envBound11693 : H12AffineFastState.Bounded env11693 := by
  intro p hp
  have h : env11693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11692_11693 : H12AffineEnvironment.transform 14 0 env11692 = env11693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env11692 == env11693) = true)

theorem identity11693 : scanCanonicalize (H12AffineFastState.compose env11693 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11693 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env11694 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,0,8202,5392,2340,1025,1,4113,32,8476,3,8193,17,2049,13340,12556,10281,1284,33,257,33,13324,513]

theorem envBound11694 : H12AffineFastState.Bounded env11694 := by
  intro p hp
  have h : env11694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11693_11694 : H12AffineEnvironment.transform 5 17 env11693 = env11694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11693 == env11694) = true)

theorem identity11694 : scanCanonicalize (H12AffineFastState.compose env11694 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound11694 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env11695 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,5132,5376,0,5126,5392,2340,1025,1,4113,32,5392,3,5133,17,2049,16,1280,7205,1284,33,257,33,0,513]

theorem envBound11695 : H12AffineFastState.Bounded env11695 := by
  intro p hp
  have h : env11695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11694_11695 : H12AffineEnvironment.transform 12 5132 env11694 = env11695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env11694 == env11695) = true)

theorem identity11695 : scanCanonicalize (H12AffineFastState.compose env11695 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound11695 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env11696 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,4096,5132,5376,0,5126,5392,0,1025,1,4113,32,5392,3,5133,17,293,16,1280,5377,1284,33,257,33,0,513]

theorem envBound11696 : H12AffineFastState.Bounded env11696 := by
  intro p hp
  have h : env11696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11695_11696 : H12AffineEnvironment.transform 10 292 env11695 = env11696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env11695 == env11696) = true)

theorem identity11696 : scanCanonicalize (H12AffineFastState.compose env11696 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11696 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env11697 : List Nat := [2,4,8,16,32,17,9,256,512,53,292,4096,4153,4405,0,4147,4389,0,52,1,4113,32,4389,3,4152,17,293,16,309,4404,305,33,257,33,0,513]

theorem envBound11697 : H12AffineFastState.Bounded env11697 := by
  intro p hp
  have h : env11697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11696_11697 : H12AffineEnvironment.transform 9 53 env11696 = env11697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11696 == env11697) = true)

theorem identity11697 : scanCanonicalize (H12AffineFastState.compose env11697 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound11697 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11698 : List Nat := [2,4,8,16,32,17,9,256,512,53,292,309,268,0,0,262,16,0,52,1,292,32,16,3,269,17,293,16,309,1,305,33,257,33,0,513]

theorem envBound11698 : H12AffineFastState.Bounded env11698 := by
  intro p hp
  have h : env11698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11697_11698 : H12AffineEnvironment.transform 11 309 env11697 = env11698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env11697 == env11698) = true)

theorem identity11698 : scanCanonicalize (H12AffineFastState.compose env11698 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11698 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11699 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,16,41,0,0,35,16,0,52,1,1,32,16,3,40,17,0,16,16,1,20,33,36,33,0,513]

theorem envBound11699 : H12AffineFastState.Bounded env11699 := by
  intro p hp
  have h : env11699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11698_11699 : H12AffineEnvironment.transform 7 37 env11698 = env11699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11698 == env11699) = true)

theorem identity11699 : scanCanonicalize (H12AffineFastState.compose env11699 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound11699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11700 : List Nat := [2,4,8,16,32,17,9,37,1,53,1,16,41,0,0,35,16,0,52,1,1,32,16,3,40,17,0,16,16,1,20,33,36,33,0,0]

theorem envBound11700 : H12AffineFastState.Bounded env11700 := by
  intro p hp
  have h : env11700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11699_11700 : H12AffineEnvironment.transform 8 1 env11699 = env11700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env11699 == env11700) = true)

theorem identity11700 : scanCanonicalize (H12AffineFastState.compose env11700 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound11700 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11701 : List Nat := [2,4,8,16,26,17,9,31,1,15,1,16,19,0,0,25,16,0,14,1,1,26,16,3,18,17,0,16,16,1,20,27,30,27,0,0]

theorem envBound11701 : H12AffineFastState.Bounded env11701 := by
  intro p hp
  have h : env11701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11700_11701 : H12AffineEnvironment.transform 4 26 env11700 = env11701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env11700 == env11701) = true)

def env11702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318548,120015,16777216,8328,64,16801162,16880844,102878,360927,16797918,17148372,257,16777250,16834950,16873225]

theorem envBound11702 : H12AffineFastState.Bounded env11702 := by
  intro p hp
  have h : env11702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11672_11702 : H12AffineEnvironment.transform 16 38161 env11672 = env11702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env11672 == env11702) = true)

def env11703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318548,120015,338048,8328,64,357642,310348,102878,360927,358494,33108,257,338082,379142,286601]

theorem envBound11703 : H12AffineFastState.Bounded env11703 := by
  intro p hp
  have h : env11703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11702_11703 : H12AffineEnvironment.transform 23 338048 env11702 = env11703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338048 env11702 == env11703) = true)

theorem identity11703 : scanCanonicalize (H12AffineFastState.compose env11703 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound11703 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env11704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21621,65536,16740,262144,1025,21620,4161,264225,65722,338048,8328,64,357642,288825,83371,349610,358494,21793,257,338082,335219,286601]

theorem envBound11704 : H12AffineFastState.Bounded env11704 := by
  intro p hp
  have h : env11704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11703_11704 : H12AffineEnvironment.transform 14 21621 env11703 = env11704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env11703 == env11704) = true)

theorem identity11704 : scanCanonicalize (H12AffineFastState.compose env11704 (packedSelected [0,2,4,6,7,9,16,17,20,23,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound11704 : packedSelected [0,2,4,6,7,9,16,17,20,23,32,35] rootPS < 2^1333 := by decide +kernel

def env11705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21621,30082,16740,262144,1025,21620,4161,264225,30008,285954,8328,64,262280,288825,12329,270376,265692,21793,257,285984,289009,286601]

theorem envBound11705 : H12AffineFastState.Bounded env11705 := by
  intro p hp
  have h : env11705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11704_11705 : H12AffineEnvironment.transform 15 30082 env11704 = env11705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env11704 == env11705) = true)

def env11706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21621,30082,16740,23808,1025,21620,4161,21793,30008,2,8328,64,23944,13625,12329,32040,20700,21793,257,32,13809,649]

theorem envBound11706 : H12AffineFastState.Bounded env11706 := by
  intro p hp
  have h : env11706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11705_11706 : H12AffineEnvironment.transform 17 23808 env11705 = env11706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env11705 == env11706) = true)

theorem identity11706 : scanCanonicalize (H12AffineFastState.compose env11706 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11706 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21621,29962,16740,23808,1025,21620,4161,21793,30008,2,8192,64,23808,13625,12329,32040,20564,21793,257,32,13689,513]

theorem envBound11707 : H12AffineFastState.Bounded env11707 := by
  intro p hp
  have h : env11707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11706_11707 : H12AffineEnvironment.transform 6 8 env11706 = env11707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11706 == env11707) = true)

theorem identity11707 : scanCanonicalize (H12AffineFastState.compose env11707 (packedSelected [0,3,4,5,7,9,10,12,14,15,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound11707 : packedSelected [0,3,4,5,7,9,10,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env11708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,9245,1378,12556,11624,1025,9244,4161,9545,1360,2,8192,64,11624,13625,12329,3392,8252,9545,257,32,13689,513]

theorem envBound11708 : H12AffineFastState.Bounded env11708 := by
  intro p hp
  have h : env11708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11707_11708 : H12AffineEnvironment.transform 13 12392 env11707 = env11708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env11707 == env11708) = true)

theorem identity11708 : scanCanonicalize (H12AffineFastState.compose env11708 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound11708 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env11709 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12392,8460,115,12556,10361,272,8461,4161,8280,65,2,8192,64,10361,12328,12329,2129,8252,8280,257,32,12392,513]

theorem envBound11709 : H12AffineFastState.Bounded env11709 := by
  intro p hp
  have h : env11709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11708_11709 : H12AffineEnvironment.transform 9 273 env11708 = env11709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env11708 == env11709) = true)

theorem identity11709 : scanCanonicalize (H12AffineFastState.compose env11709 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11709 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env11710 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4404,80,115,4176,2341,272,81,4161,260,65,2,348,64,2341,4468,4469,2129,352,260,257,32,4404,513]

theorem envBound11710 : H12AffineFastState.Bounded env11710 := by
  intro p hp
  have h : env11710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11709_11710 : H12AffineEnvironment.transform 12 348 env11709 = env11710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11709 == env11710) = true)

theorem identity11710 : scanCanonicalize (H12AffineFastState.compose env11710 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11710 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11711 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,268,4404,0,35,4096,2341,272,1,4113,260,17,2,268,16,2341,4388,4389,2049,304,260,257,32,4404,513]

theorem envBound11711 : H12AffineFastState.Bounded env11711 := by
  intro p hp
  have h : env11711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11710_11711 : H12AffineEnvironment.transform 5 16 env11710 = env11711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11710 == env11711) = true)

theorem identity11711 : scanCanonicalize (H12AffineFastState.compose env11711 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 257) := by decide +kernel

theorem selectedBound11711 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11712 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,257,268,53,0,35,257,2341,272,1,272,260,17,2,268,16,2341,37,36,2049,304,260,257,32,53,513]

theorem envBound11712 : H12AffineFastState.Bounded env11712 := by
  intro p hp
  have h : env11712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11711_11712 : H12AffineEnvironment.transform 11 257 env11711 = env11712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 257 env11711 == env11712) = true)

theorem identity11712 : scanCanonicalize (H12AffineFastState.compose env11712 (packedSelected [1,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound11712 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env11713 : List Nat := [2,4,8,16,32,16,8,256,512,273,28,257,268,53,0,35,257,313,272,1,272,260,17,2,268,16,313,37,36,29,304,260,257,32,53,513]

theorem envBound11713 : H12AffineFastState.Bounded env11713 := by
  intro p hp
  have h : env11713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11712_11713 : H12AffineEnvironment.transform 10 28 env11712 = env11713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env11712 == env11713) = true)

def env11714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21621,30082,16740,23809,1025,21620,4161,21792,30008,3,8328,64,23945,13624,12329,32041,20701,21793,257,33,13808,648]

theorem envBound11714 : H12AffineFastState.Bounded env11714 := by
  intro p hp
  have h : env11714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11705_11714 : H12AffineEnvironment.transform 17 23809 env11705 = env11714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env11705 == env11714) = true)

theorem identity11714 : scanCanonicalize (H12AffineFastState.compose env11714 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13729) := by decide +kernel

theorem selectedBound11714 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13729,8660,35,13509,10400,1025,8661,4161,8321,153,3,8328,64,10280,13624,12329,2184,9596,8320,257,33,13808,648]

theorem envBound11715 : H12AffineFastState.Bounded env11715 := by
  intro p hp
  have h : env11715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11714_11715 : H12AffineEnvironment.transform 13 13729 env11714 = env11715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13729 env11714 == env11715) = true)

theorem identity11715 : scanCanonicalize (H12AffineFastState.compose env11715 (packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11715 : packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env11716 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,13444,8433,35,13509,10400,1025,8432,4161,8321,153,3,8328,64,10280,13341,12329,2184,9305,8320,36,33,13525,648]

theorem envBound11716 : H12AffineFastState.Bounded env11716 := by
  intro p hp
  have h : env11716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11715_11716 : H12AffineEnvironment.transform 7 37 env11715 = env11716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11715 == env11716) = true)

theorem identity11716 : scanCanonicalize (H12AffineFastState.compose env11716 (packedSelected [1,6,8,12,14,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound11716 : packedSelected [1,6,8,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env11717 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,241,5237,0,35,5172,2129,1025,1,4161,112,153,3,121,64,2265,5356,4312,2184,1192,113,36,33,5156,648]

theorem envBound11717 : H12AffineFastState.Bounded env11717 := by
  intro p hp
  have h : env11717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11716_11717 : H12AffineEnvironment.transform 12 241 env11716 = env11717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env11716 == env11717) = true)

def env11718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318548,120015,338049,8328,64,357643,310349,102878,360927,358495,33109,257,338083,379143,286600]

theorem envBound11718 : H12AffineFastState.Bounded env11718 := by
  intro p hp
  have h : env11718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11702_11718 : H12AffineEnvironment.transform 23 338049 env11702 = env11718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338049 env11702 == env11718) = true)

theorem identity11718 : scanCanonicalize (H12AffineFastState.compose env11718 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(14+1) ^^^ 21757) := by decide +kernel

theorem selectedBound11718 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env11719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21757,65536,16876,262144,1025,21756,4161,264361,65586,338049,8328,64,357643,288944,83235,349474,358495,21928,257,338083,335354,286600]

theorem envBound11719 : H12AffineFastState.Bounded env11719 := by
  intro p hp
  have h : env11719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11718_11719 : H12AffineEnvironment.transform 14 21757 env11718 = env11719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21757 env11718 == env11719) = true)

def env11720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21757,65536,16876,10400,1025,21756,4161,8201,65586,65569,8328,64,89515,16400,83235,97666,86271,21928,257,65539,79194,30504]

theorem envBound11720 : H12AffineFastState.Bounded env11720 := by
  intro p hp
  have h : env11720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11719_11720 : H12AffineEnvironment.transform 17 10400 env11719 = env11720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env11719 == env11720) = true)

theorem identity11720 : scanCanonicalize (H12AffineFastState.compose env11720 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13728) := by decide +kernel

theorem selectedBound11720 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13728,8541,65536,13388,10400,1025,8540,4161,8201,65586,65569,8328,64,75787,13744,77955,67618,75103,8200,257,65539,79194,648]

theorem envBound11721 : H12AffineFastState.Bounded env11721 := by
  intro p hp
  have h : env11721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11720_11721 : H12AffineEnvironment.transform 13 13728 env11720 = env11721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env11720 == env11721) = true)

theorem identity11721 : scanCanonicalize (H12AffineFastState.compose env11721 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11721 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8541,65536,13388,10281,1025,8540,4161,8201,65586,65569,8193,64,75787,13625,77834,67618,75103,8200,257,65539,79194,513]

theorem envBound11722 : H12AffineFastState.Bounded env11722 := by
  intro p hp
  have h : env11722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11721_11722 : H12AffineEnvironment.transform 6 9 env11721 = env11722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11721 == env11722) = true)

theorem identity11722 : scanCanonicalize (H12AffineFastState.compose env11722 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound11722 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8541,8575,13388,10281,1025,8540,4161,8201,8525,8542,8193,64,2420,13625,4469,10589,1056,8200,257,8572,5157,513]

theorem envBound11723 : H12AffineFastState.Bounded env11723 := by
  intro p hp
  have h : env11723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11722_11723 : H12AffineEnvironment.transform 15 8575 env11722 = env11723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env11722 == env11723) = true)

theorem identity11723 : scanCanonicalize (H12AffineFastState.compose env11723 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound11723 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,1,35,5392,2421,1025,0,4161,341,17,2,349,64,2420,5221,4469,2049,1056,340,257,32,5157,513]

theorem envBound11724 : H12AffineFastState.Bounded env11724 := by
  intro p hp
  have h : env11724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11723_11724 : H12AffineEnvironment.transform 12 348 env11723 = env11724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env11723 == env11724) = true)

theorem identity11724 : scanCanonicalize (H12AffineFastState.compose env11724 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11724 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11725 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,348,5205,1,3,5392,2389,1025,0,4161,341,17,2,349,64,2388,5189,4437,2049,1024,340,257,0,5125,513]

theorem envBound11725 : H12AffineFastState.Bounded env11725 := by
  intro p hp
  have h : env11725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11724_11725 : H12AffineEnvironment.transform 4 0 env11724 = env11725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11724 == env11725) = true)

def env11726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21757,65536,16876,10401,1025,21756,4161,8200,65586,65568,8328,64,89514,16401,83235,97667,86270,21928,257,65538,79195,30505]

theorem envBound11726 : H12AffineFastState.Bounded env11726 := by
  intro p hp
  have h : env11726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11719_11726 : H12AffineEnvironment.transform 17 10401 env11719 = env11726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env11719 == env11726) = true)

theorem identity11726 : scanCanonicalize (H12AffineFastState.compose env11726 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound11726 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env11727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,1,65536,5392,10401,1025,0,4161,8200,65586,65568,8328,64,67926,5357,70111,76159,66562,340,257,65538,79195,9173]

theorem envBound11727 : H12AffineFastState.Bounded env11727 := by
  intro p hp
  have h : env11727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11726_11727 : H12AffineEnvironment.transform 13 5372 env11726 = env11727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env11726 == env11727) = true)

theorem identity11727 : scanCanonicalize (H12AffineFastState.compose env11727 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound11727 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env11728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,1,34,5392,10401,1025,0,4161,8200,16,2,8328,64,2420,5357,4605,10589,1056,340,257,32,13689,9173]

theorem envBound11728 : H12AffineFastState.Bounded env11728 := by
  intro p hp
  have h : env11728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11727_11728 : H12AffineEnvironment.transform 15 34 env11727 = env11728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env11727 == env11728) = true)

theorem identity11728 : scanCanonicalize (H12AffineFastState.compose env11728 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound11728 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env11729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5372,1,34,5392,2048,1025,0,4161,169,16,2,41,64,2420,5357,4605,2556,1056,340,257,32,5592,884]

theorem envBound11729 : H12AffineFastState.Bounded env11729 := by
  intro p hp
  have h : env11729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11728_11729 : H12AffineEnvironment.transform 12 161 env11728 = env11729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env11728 == env11729) = true)

theorem identity11729 : scanCanonicalize (H12AffineFastState.compose env11729 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11729 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11730 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5372,1,34,5221,2048,1025,0,4161,169,16,2,41,64,2049,5357,4232,2185,1056,33,116,32,5293,513]

theorem envBound11730 : H12AffineFastState.Bounded env11730 := by
  intro p hp
  have h : env11730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11729_11730 : H12AffineEnvironment.transform 7 117 env11729 = env11730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11729 == env11730) = true)

theorem identity11730 : scanCanonicalize (H12AffineFastState.compose env11730 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound11730 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11731 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,121,5156,1,34,5221,2048,1025,0,4161,113,16,2,41,64,2049,5173,4176,2129,1056,33,116,32,5237,513]

theorem envBound11731 : H12AffineFastState.Bounded env11731 := by
  intro p hp
  have h : env11731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11730_11731 : H12AffineEnvironment.transform 6 88 env11730 = env11731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11730 == env11731) = true)

def env11732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411973,213470,16777216,8328,64,16959643,16974300,102879,360927,16958927,17148373,257,16777251,16834951,17031704]

theorem envBound11732 : H12AffineFastState.Bounded env11732 := by
  intro p hp
  have h : env11732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11671_11732 : H12AffineEnvironment.transform 20 165201 env11671 = env11732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env11671 == env11732) = true)

theorem identity11732 : scanCanonicalize (H12AffineFastState.compose env11732 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound11732 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env11733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411973,213470,188871,8328,64,10588,122907,102879,360927,9224,477202,257,188900,131136,66527]

theorem envBound11733 : H12AffineFastState.Bounded env11733 := by
  intro p hp
  have h : env11733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11732_11733 : H12AffineEnvironment.transform 23 188871 env11732 = env11733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env11732 == env11733) = true)

def env11734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318549,120014,29911,8328,64,10588,122907,102879,360927,9224,384258,257,29940,38224,66527]

theorem envBound11734 : H12AffineFastState.Bounded env11734 := by
  intro p hp
  have h : env11734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11733_11734 : H12AffineEnvironment.transform 16 38160 env11733 = env11734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env11733 == env11734) = true)

theorem identity11734 : scanCanonicalize (H12AffineFastState.compose env11734 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound11734 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,4161,318549,8644,29911,8328,64,10588,5393,25813,292053,9224,272392,257,29940,38224,63189]

theorem envBound11735 : H12AffineFastState.Bounded env11735 := by
  intro p hp
  have h : env11735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11734_11735 : H12AffineEnvironment.transform 15 62730 env11734 = env11735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env11734 == env11735) = true)

def env11736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,4161,318549,8524,29791,8192,64,10588,5393,25693,291933,9224,272392,257,29820,38224,63069]

theorem envBound11736 : H12AffineFastState.Bounded env11736 := by
  intro p hp
  have h : env11736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11735_11736 : H12AffineEnvironment.transform 6 8 env11735 = env11736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11735 == env11736) = true)

theorem identity11736 : scanCanonicalize (H12AffineFastState.compose env11736 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound11736 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env11737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,24908,262144,1025,29789,4161,272393,8524,29791,8192,64,10588,5393,25693,291933,9224,272392,257,29820,24844,513]

theorem envBound11737 : H12AffineFastState.Bounded env11737 := by
  intro p hp
  have h : env11737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11736_11737 : H12AffineEnvironment.transform 14 29788 env11736 = env11737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env11736 == env11737) = true)

theorem identity11737 : scanCanonicalize (H12AffineFastState.compose env11737 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 30776) := by decide +kernel

theorem selectedBound11737 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env11738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,24908,30776,1025,29789,4161,20529,8524,29791,8192,64,10588,5393,25693,3173,9224,20528,257,29820,24844,513]

theorem envBound11738 : H12AffineFastState.Bounded env11738 := by
  intro p hp
  have h : env11738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11737_11738 : H12AffineEnvironment.transform 17 30776 env11737 = env11738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30776 env11737 == env11738) = true)

theorem identity11738 : scanCanonicalize (H12AffineFastState.compose env11738 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound11738 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,20496,342,17664,23668,1025,20497,4161,20529,1280,20499,1100,64,3344,5393,16401,3173,68,20528,257,20528,17728,513]

theorem envBound11739 : H12AffineFastState.Bounded env11739 := by
  intro p hp
  have h : env11739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11738_11739 : H12AffineEnvironment.transform 12 1100 env11738 = env11739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env11738 == env11739) = true)

theorem identity11739 : scanCanonicalize (H12AffineFastState.compose env11739 (packedSelected [2,6,17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound11739 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env11740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4113,1,342,5393,3173,1025,0,4161,32,1280,2,1100,64,3344,5393,4096,3173,68,33,257,33,5457,513]

theorem envBound11740 : H12AffineFastState.Bounded env11740 := by
  intro p hp
  have h : env11740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11739_11740 : H12AffineEnvironment.transform 13 4113 env11739 = env11740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env11739 == env11740) = true)

theorem identity11740 : scanCanonicalize (H12AffineFastState.compose env11740 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound11740 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env11741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,1100,1297,1,342,17,3173,1025,0,1345,32,1280,2,1100,64,3344,17,1280,3173,68,33,257,33,81,513]

theorem envBound11741 : H12AffineFastState.Bounded env11741 := by
  intro p hp
  have h : env11741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11740_11741 : H12AffineEnvironment.transform 11 1280 env11740 = env11741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env11740 == env11741) = true)

theorem identity11741 : scanCanonicalize (H12AffineFastState.compose env11741 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound11741 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11742 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1140,1100,1125,1,34,17,3173,1025,0,1077,32,1140,2,1100,64,3172,17,1140,3173,68,33,117,33,81,513]

theorem envBound11742 : H12AffineFastState.Bounded env11742 := by
  intro p hp
  have h : env11742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11741_11742 : H12AffineEnvironment.transform 7 116 env11741 = env11742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env11741 == env11742) = true)

theorem identity11742 : scanCanonicalize (H12AffineFastState.compose env11742 (packedSelected [1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound11742 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env11743 : List Nat := [2,4,8,16,32,64,8,116,512,516,2048,624,584,609,1,34,17,2657,517,0,561,32,624,2,584,64,2656,17,624,2657,68,33,117,33,81,513]

theorem envBound11743 : H12AffineFastState.Bounded env11743 := by
  intro p hp
  have h : env11743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11742_11743 : H12AffineEnvironment.transform 9 516 env11742 = env11743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env11742 == env11743) = true)

theorem identity11743 : scanCanonicalize (H12AffineFastState.compose env11743 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound11743 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env11744 : List Nat := [2,4,8,16,32,64,8,116,512,516,65,624,584,609,1,34,17,544,517,0,561,32,624,2,584,64,545,17,624,544,68,33,117,33,81,513]

theorem envBound11744 : H12AffineFastState.Bounded env11744 := by
  intro p hp
  have h : env11744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11743_11744 : H12AffineEnvironment.transform 10 65 env11743 = env11744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env11743 == env11744) = true)

theorem identity11744 : scanCanonicalize (H12AffineFastState.compose env11744 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11744 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env11745 : List Nat := [2,4,8,16,32,16,8,36,512,516,17,544,536,561,1,34,17,544,517,0,561,32,544,2,536,16,545,17,544,544,20,33,37,33,1,513]

theorem envBound11745 : H12AffineFastState.Bounded env11745 := by
  intro p hp
  have h : env11745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11744_11745 : H12AffineEnvironment.transform 5 16 env11744 = env11745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11744 == env11745) = true)

theorem identity11745 : scanCanonicalize (H12AffineFastState.compose env11745 (packedSelected [0,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11745 : packedSelected [0,12] rootPS < 2^1333 := by decide +kernel

def env11746 : List Nat := [2,4,8,0,32,0,8,36,512,516,1,544,520,545,1,34,1,544,517,0,545,32,544,2,520,0,545,1,544,544,4,33,37,33,1,513]

theorem envBound11746 : H12AffineFastState.Bounded env11746 := by
  intro p hp
  have h : env11746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11745_11746 : H12AffineEnvironment.transform 3 0 env11745 = env11746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11745 == env11746) = true)

theorem identity11746 : scanCanonicalize (H12AffineFastState.compose env11746 (packedSelected [15] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound11746 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env11747 : List Nat := [2,4,8,0,32,0,8,36,33,37,1,1,41,0,1,34,1,1,36,0,0,32,1,2,41,0,0,1,1,1,4,33,37,33,1,32]

theorem envBound11747 : H12AffineFastState.Bounded env11747 := by
  intro p hp
  have h : env11747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11746_11747 : H12AffineEnvironment.transform 8 33 env11746 = env11747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env11746 == env11747) = true)

theorem identity11747 : scanCanonicalize (H12AffineFastState.compose env11747 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11747 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11748 : List Nat := [2,4,8,0,0,0,8,4,1,5,1,1,9,0,1,2,1,1,4,0,0,0,1,2,9,0,0,1,1,1,4,1,5,1,1,0]

theorem envBound11748 : H12AffineFastState.Bounded env11748 := by
  intro p hp
  have h : env11748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11747_11748 : H12AffineEnvironment.transform 4 0 env11747 = env11748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11747 == env11748) = true)

def env11749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,4161,318549,8525,29790,8193,64,10588,5393,25692,291932,9224,272392,257,29821,38224,63068]

theorem envBound11749 : H12AffineFastState.Bounded env11749 := by
  intro p hp
  have h : env11749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11735_11749 : H12AffineEnvironment.transform 6 9 env11735 = env11749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11735 == env11749) = true)

theorem identity11749 : scanCanonicalize (H12AffineFastState.compose env11749 (packedSelected [1,10,14,19,28,35] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound11749 : packedSelected [1,10,14,19,28,35] rootPS < 2^1333 := by decide +kernel

def env11750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54359,38160,262144,1025,32769,4161,318549,16,21763,348,64,2049,5393,17665,283905,1365,264533,257,21792,38224,55041]

theorem envBound11750 : H12AffineFastState.Bounded env11750 := by
  intro p hp
  have h : env11750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11749_11750 : H12AffineEnvironment.transform 12 349 env11749 = env11750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env11749 == env11750) = true)

theorem identity11750 : scanCanonicalize (H12AffineFastState.compose env11750 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound11750 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env11751 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,343,16400,262144,1025,21761,4161,264533,16,21763,348,64,2049,5393,17665,283905,1365,264533,257,21792,16464,513]

theorem envBound11751 : H12AffineFastState.Bounded env11751 := by
  intro p hp
  have h : env11751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11750_11751 : H12AffineEnvironment.transform 14 21760 env11750 = env11751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env11750 == env11751) = true)

theorem identity11751 : scanCanonicalize (H12AffineFastState.compose env11751 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound11751 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env11752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,343,16400,2420,1025,21761,4161,33,16,21763,348,64,2049,5393,17665,23669,1365,33,257,21792,16464,513]

theorem envBound11752 : H12AffineFastState.Bounded env11752 := by
  intro p hp
  have h : env11752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11751_11752 : H12AffineEnvironment.transform 17 2420 env11751 = env11752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env11751 == env11752) = true)

theorem identity11752 : scanCanonicalize (H12AffineFastState.compose env11752 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound11752 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,343,5392,2420,1025,1,4161,33,16,3,348,64,2049,5393,4097,2421,1365,33,257,32,5456,513]

theorem envBound11753 : H12AffineFastState.Bounded env11753 := by
  intro p hp
  have h : env11753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11752_11753 : H12AffineEnvironment.transform 13 5376 env11752 = env11753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env11752 == env11753) = true)

theorem identity11753 : scanCanonicalize (H12AffineFastState.compose env11753 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound11753 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11754 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,349,4405,0,343,4389,2420,52,1,4161,33,16,3,348,64,2049,4388,4097,2421,352,33,257,32,4453,513]

theorem envBound11754 : H12AffineFastState.Bounded env11754 := by
  intro p hp
  have h : env11754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11753_11754 : H12AffineEnvironment.transform 9 53 env11753 = env11754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env11753 == env11754) = true)

theorem identity11754 : scanCanonicalize (H12AffineFastState.compose env11754 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound11754 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11755 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,4096,40,4160,0,34,4176,2049,52,1,4161,33,16,3,41,64,2049,4177,4097,2048,21,33,116,32,4112,513]

theorem envBound11755 : H12AffineFastState.Bounded env11755 := by
  intro p hp
  have h : env11755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11754_11755 : H12AffineEnvironment.transform 7 117 env11754 = env11755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env11754 == env11755) = true)

def env11756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318548,120015,29910,8328,64,10588,122907,102879,360927,9224,384259,257,29941,38225,66527]

theorem envBound11756 : H12AffineFastState.Bounded env11756 := by
  intro p hp
  have h : env11756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11733_11756 : H12AffineEnvironment.transform 16 38161 env11733 = env11756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env11733 == env11756) = true)

theorem identity11756 : scanCanonicalize (H12AffineFastState.compose env11756 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound11756 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env11757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25028,262144,1025,29908,4160,272513,73754,29910,8328,64,10588,70862,91402,357642,9224,338390,257,29941,24964,66527]

theorem envBound11757 : H12AffineFastState.Bounded env11757 := by
  intro p hp
  have h : env11757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11756_11757 : H12AffineEnvironment.transform 14 29909 env11756 = env11757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env11756 == env11757) = true)

def env11758 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,262144,1025,29828,4112,272513,73754,29830,8328,16,10508,70814,91402,357642,9224,338310,257,29861,24964,66447]

theorem envBound11758 : H12AffineFastState.Bounded env11758 := by
  intro p hp
  have h : env11758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11757_11758 : H12AffineEnvironment.transform 5 16 env11757 = env11758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11757 == env11758) = true)

theorem identity11758 : scanCanonicalize (H12AffineFastState.compose env11758 (packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound11758 : packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env11759 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21761,65536,16400,262144,1025,21760,4112,264453,65950,21762,268,16,2184,70814,83086,349326,1420,329730,257,21793,16384,66447]

theorem envBound11759 : H12AffineFastState.Bounded env11759 := by
  intro p hp
  have h : env11759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11758_11759 : H12AffineEnvironment.transform 12 388 env11758 = env11759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env11758 == env11759) = true)

theorem identity11759 : scanCanonicalize (H12AffineFastState.compose env11759 (packedSelected [16,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound11759 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env11760 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21761,65536,16400,67755,1025,21760,4112,65966,65950,21762,268,16,2184,70814,83086,23589,1420,169,257,21793,16384,66447]

theorem envBound11760 : H12AffineFastState.Bounded env11760 := by
  intro p hp
  have h : env11760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0