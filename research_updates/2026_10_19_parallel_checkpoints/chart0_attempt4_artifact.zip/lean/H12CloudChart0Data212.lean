import H12CloudChart0Data211

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity53669 : scanCanonicalize (H12AffineFastState.compose env53669 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound53669 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53670 : List Nat := [2,4,8,16,32,16,9,36,16,52,0,43,40,58,1,35,43,1,53,0,58,33,16,3,41,16,1,42,42,0,20,33,37,32,58,17]

theorem envBound53670 : H12AffineFastState.Bounded env53670 := by
  intro p hp
  have h : env53670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53669_53670 : H12AffineEnvironment.transform 8 16 env53669 = env53670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env53669 == env53670) = true)

theorem identity53670 : scanCanonicalize (H12AffineFastState.compose env53670 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound53670 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53671 : List Nat := [2,4,8,16,27,16,9,31,16,15,0,16,19,1,1,24,16,1,14,0,1,26,16,3,18,16,1,17,17,0,20,26,30,27,1,17]

theorem envBound53671 : H12AffineFastState.Bounded env53671 := by
  intro p hp
  have h : env53671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53670_53671 : H12AffineEnvironment.transform 4 27 env53670 = env53671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env53670 == env53671) = true)

def env53672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,4194304,169353,95496,8328,64,4464768,163976,45524,284040,156816,4350405,257,21793,46213,213831]

theorem envBound53672 : H12AffineFastState.Bounded env53672 := by
  intro p hp
  have h : env53672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53629_53672 : H12AffineEnvironment.transform 22 169353 env53629 = env53672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env53629 == env53672) = true)

def env53673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272512,169353,95496,8328,64,2048,163976,45524,284040,156816,411973,257,21793,46213,213831]

theorem envBound53673 : H12AffineFastState.Bounded env53673 := by
  intro p hp
  have h : env53673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53672_53673 : H12AffineEnvironment.transform 21 272512 env53672 = env53673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53672 == env53673) = true)

theorem identity53673 : scanCanonicalize (H12AffineFastState.compose env53673 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound53673 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,58516,272512,17,95496,8328,64,2048,5392,45524,284040,61704,318685,257,21793,46213,120543]

theorem envBound53674 : H12AffineFastState.Bounded env53674 := by
  intro p hp
  have h : env53674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53673_53674 : H12AffineEnvironment.transform 16 38296 env53673 = env53674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env53673 == env53674) = true)

def env53675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272392,17,95496,8192,64,2048,5392,45404,283904,61704,318549,257,21793,46093,120407]

theorem envBound53675 : H12AffineFastState.Bounded env53675 := by
  intro p hp
  have h : env53675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53674_53675 : H12AffineEnvironment.transform 6 8 env53674 = env53675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53674 == env53675) = true)

theorem identity53675 : scanCanonicalize (H12AffineFastState.compose env53675 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound53675 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,58396,32,17,95496,8192,64,2048,5392,45404,32040,61704,62589,257,21793,46093,120407]

theorem envBound53676 : H12AffineFastState.Bounded env53676 := by
  intro p hp
  have h : env53676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53675_53676 : H12AffineEnvironment.transform 17 10280 env53675 = env53676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53675 == env53676) = true)

theorem identity53676 : scanCanonicalize (H12AffineFastState.compose env53676 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound53676 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,38160,10280,1025,32769,58396,32,17,8542,8192,64,2048,5392,45404,32040,61704,62589,257,21793,46093,33281]

theorem envBound53677 : H12AffineFastState.Bounded env53677 := by
  intro p hp
  have h : env53677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53676_53677 : H12AffineEnvironment.transform 15 21590 env53676 = env53677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env53676 == env53677) = true)

theorem identity53677 : scanCanonicalize (H12AffineFastState.compose env53677 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound53677 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env53678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,21590,16401,10280,1025,21760,12573,32,17,8542,8192,64,2048,5392,25693,32040,9225,8572,257,21793,24844,22272]

theorem envBound53678 : H12AffineFastState.Bounded env53678 := by
  intro p hp
  have h : env53678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53677_53678 : H12AffineEnvironment.transform 14 21761 env53677 = env53678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env53677 == env53678) = true)

theorem identity53678 : scanCanonicalize (H12AffineFastState.compose env53678 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53678 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env53679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21590,16401,2420,1025,21760,4161,32,17,2,348,64,2048,5392,17665,23668,1365,32,257,21793,16464,22272]

theorem envBound53679 : H12AffineFastState.Bounded env53679 := by
  intro p hp
  have h : env53679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53678_53679 : H12AffineEnvironment.transform 12 348 env53678 = env53679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53678 == env53679) = true)

theorem identity53679 : scanCanonicalize (H12AffineFastState.compose env53679 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound53679 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env53680 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,16384,21588,21590,16401,2081,1025,21589,4161,32,17,2,9,64,2048,5189,17492,23668,1024,32,84,21620,16464,22101]

theorem envBound53680 : H12AffineFastState.Bounded env53680 := by
  intro p hp
  have h : env53680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53679_53680 : H12AffineEnvironment.transform 7 85 env53679 = env53680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env53679 == env53680) = true)

theorem identity53680 : scanCanonicalize (H12AffineFastState.compose env53680 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound53680 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env53681 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,5205,1,3,5188,2081,1025,0,4161,32,17,2,9,64,2048,5189,4097,2081,1024,32,84,33,5125,512]

theorem envBound53681 : H12AffineFastState.Bounded env53681 := by
  intro p hp
  have h : env53681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53680_53681 : H12AffineEnvironment.transform 13 5205 env53680 = env53681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env53680 == env53681) = true)

theorem identity53681 : scanCanonicalize (H12AffineFastState.compose env53681 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound53681 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53682 : List Nat := [2,4,8,16,32,64,8,85,512,20,2048,4096,9,4161,1,3,4176,2081,21,0,4161,32,17,2,9,64,2048,4177,4097,2081,20,32,84,33,4113,512]

theorem envBound53682 : H12AffineFastState.Bounded env53682 := by
  intro p hp
  have h : env53682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53681_53682 : H12AffineEnvironment.transform 9 20 env53681 = env53682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53681 == env53682) = true)

theorem identity53682 : scanCanonicalize (H12AffineFastState.compose env53682 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound53682 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53683 : List Nat := [2,4,8,16,32,64,8,85,512,20,2048,96,9,33,1,3,48,2081,21,0,33,32,17,2,9,64,2048,49,97,2081,20,32,84,33,113,512]

theorem envBound53683 : H12AffineFastState.Bounded env53683 := by
  intro p hp
  have h : env53683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53682_53683 : H12AffineEnvironment.transform 11 96 env53682 = env53683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env53682 == env53683) = true)

theorem identity53683 : scanCanonicalize (H12AffineFastState.compose env53683 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53683 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53684 : List Nat := [2,4,8,16,0,64,8,85,512,20,2048,64,9,1,1,3,16,2049,21,0,1,0,17,2,9,64,2048,17,65,2049,20,0,84,1,81,512]

theorem envBound53684 : H12AffineFastState.Bounded env53684 := by
  intro p hp
  have h : env53684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53683_53684 : H12AffineEnvironment.transform 4 0 env53683 = env53684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53683 == env53684) = true)

theorem identity53684 : scanCanonicalize (H12AffineFastState.compose env53684 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound53684 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53685 : List Nat := [2,4,8,16,0,64,8,85,81,20,2048,64,9,1,1,3,16,2049,21,0,1,0,17,2,9,64,2048,17,65,2049,20,0,84,1,81,81]

theorem envBound53685 : H12AffineFastState.Bounded env53685 := by
  intro p hp
  have h : env53685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53684_53685 : H12AffineEnvironment.transform 8 81 env53684 = env53685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env53684 == env53685) = true)

theorem identity53685 : scanCanonicalize (H12AffineFastState.compose env53685 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53685 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53686 : List Nat := [2,4,8,16,0,64,8,85,81,20,1,64,9,1,1,3,16,0,21,0,1,0,17,2,9,64,1,17,65,0,20,0,84,1,81,81]

theorem envBound53686 : H12AffineFastState.Bounded env53686 := by
  intro p hp
  have h : env53686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53685_53686 : H12AffineEnvironment.transform 10 1 env53685 = env53686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53685 == env53686) = true)

def env53687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,17,95496,8193,64,2048,5392,45405,283905,61704,318548,257,21793,46092,120406]

theorem envBound53687 : H12AffineFastState.Bounded env53687 := by
  intro p hp
  have h : env53687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53674_53687 : H12AffineEnvironment.transform 6 9 env53674 = env53687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53674 == env53687) = true)

theorem identity53687 : scanCanonicalize (H12AffineFastState.compose env53687 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound53687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35188,1025,32769,58397,41341,17,95496,8193,64,2048,5392,45405,56437,61704,21792,257,21793,46092,120406]

theorem envBound53688 : H12AffineFastState.Bounded env53688 := by
  intro p hp
  have h : env53688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53687_53688 : H12AffineEnvironment.transform 17 35188 env53687 = env53688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env53687 == env53688) = true)

theorem identity53688 : scanCanonicalize (H12AffineFastState.compose env53688 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53688 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env53689 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,37988,34817,1025,32769,58397,40968,17,95357,8193,64,2048,5221,45096,56437,61565,21589,116,21588,46092,120406]

theorem envBound53689 : H12AffineFastState.Bounded env53689 := by
  intro p hp
  have h : env53689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53688_53689 : H12AffineEnvironment.transform 7 117 env53688 = env53689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53688 == env53689) = true)

theorem identity53689 : scanCanonicalize (H12AffineFastState.compose env53689 (packedSelected [0,1,4,7,8,12,15,16,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound53689 : packedSelected [0,1,4,7,8,12,15,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env53690 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8312,65536,13340,10361,1025,8313,17509,112,17,95357,8193,64,2048,5221,4176,31757,20485,21589,116,21588,5236,95790]

theorem envBound53690 : H12AffineFastState.Bounded env53690 := by
  intro p hp
  have h : env53690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53689_53690 : H12AffineEnvironment.transform 14 8312 env53689 = env53690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env53689 == env53690) = true)

theorem identity53690 : scanCanonicalize (H12AffineFastState.compose env53690 (packedSelected [0,1,4,7,8,12,15,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound53690 : packedSelected [0,1,4,7,8,12,15,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53691 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8312,114,13340,10361,1025,8313,17509,112,17,29711,8193,64,2048,5221,4176,31757,20485,21589,116,21588,5236,30300]

theorem envBound53691 : H12AffineFastState.Bounded env53691 := by
  intro p hp
  have h : env53691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53690_53691 : H12AffineEnvironment.transform 15 114 env53690 = env53691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env53690 == env53691) = true)

theorem identity53691 : scanCanonicalize (H12AffineFastState.compose env53691 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound53691 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env53692 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,8312,114,13340,10361,1025,8313,4113,112,17,8315,8193,64,2048,5221,4176,10361,1137,33,116,32,5236,8744]

theorem envBound53692 : H12AffineFastState.Bounded env53692 := by
  intro p hp
  have h : env53692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53691_53692 : H12AffineEnvironment.transform 13 5236 env53691 = env53692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env53691 == env53692) = true)

theorem identity53692 : scanCanonicalize (H12AffineFastState.compose env53692 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound53692 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env53693 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,8192,4160,8312,114,12328,10361,53,8313,4113,112,17,8315,8193,64,2048,4177,4176,10361,69,33,116,32,4160,8744]

theorem envBound53693 : H12AffineFastState.Bounded env53693 := by
  intro p hp
  have h : env53693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53692_53693 : H12AffineEnvironment.transform 9 52 env53692 = env53693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53692 == env53693) = true)

theorem identity53693 : scanCanonicalize (H12AffineFastState.compose env53693 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound53693 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env53694 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,120,4160,0,114,4176,2049,53,1,4113,112,17,3,121,64,2048,4177,4176,2049,69,33,116,32,4160,592]

theorem envBound53694 : H12AffineFastState.Bounded env53694 := by
  intro p hp
  have h : env53694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53693_53694 : H12AffineEnvironment.transform 12 120 env53693 = env53694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env53693 == env53694) = true)

theorem identity53694 : scanCanonicalize (H12AffineFastState.compose env53694 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound53694 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env53695 : List Nat := [2,4,8,16,32,64,9,117,512,52,0,4096,120,4160,0,114,4176,1,53,1,4113,112,17,3,121,64,0,4177,4176,1,69,33,116,32,4160,592]

theorem envBound53695 : H12AffineFastState.Bounded env53695 := by
  intro p hp
  have h : env53695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53694_53695 : H12AffineEnvironment.transform 10 0 env53694 = env53695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53694 == env53695) = true)

theorem identity53695 : scanCanonicalize (H12AffineFastState.compose env53695 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound53695 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53696 : List Nat := [2,4,8,16,32,64,9,117,512,52,0,64,120,0,0,114,16,1,53,1,81,112,17,3,121,64,0,17,16,1,69,33,116,32,0,592]

theorem envBound53696 : H12AffineFastState.Bounded env53696 := by
  intro p hp
  have h : env53696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53695_53696 : H12AffineEnvironment.transform 11 64 env53695 = env53696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env53695 == env53696) = true)

theorem identity53696 : scanCanonicalize (H12AffineFastState.compose env53696 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53696 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env53697 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,17,41,0,0,35,16,1,53,1,0,33,17,3,40,17,0,17,16,1,20,33,37,32,0,513]

theorem envBound53697 : H12AffineFastState.Bounded env53697 := by
  intro p hp
  have h : env53697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53696_53697 : H12AffineEnvironment.transform 5 17 env53696 = env53697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53696 == env53697) = true)

theorem identity53697 : scanCanonicalize (H12AffineFastState.compose env53697 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53698 : List Nat := [2,4,2,16,32,17,3,36,512,52,0,17,35,0,0,35,16,1,53,1,0,33,17,3,34,17,0,17,16,1,20,33,37,32,0,513]

theorem envBound53698 : H12AffineFastState.Bounded env53698 := by
  intro p hp
  have h : env53698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53697_53698 : H12AffineEnvironment.transform 2 2 env53697 = env53698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53697 == env53698) = true)

def env53699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272513,169353,95496,8328,64,2049,163976,45524,284040,156816,411972,257,21793,46213,213831]

theorem envBound53699 : H12AffineFastState.Bounded env53699 := by
  intro p hp
  have h : env53699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53672_53699 : H12AffineEnvironment.transform 21 272513 env53672 = env53699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53672 == env53699) = true)

def env53700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272393,169217,95496,8192,64,2049,163840,45404,283904,156696,411972,257,21793,46093,213831]

theorem envBound53700 : H12AffineFastState.Bounded env53700 := by
  intro p hp
  have h : env53700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53699_53700 : H12AffineEnvironment.transform 6 8 env53699 = env53700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53699 == env53700) = true)

def env53701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272393,17,95496,8192,64,2049,5392,45404,283904,61704,318548,257,21793,46093,120407]

theorem envBound53701 : H12AffineFastState.Bounded env53701 := by
  intro p hp
  have h : env53701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53700_53701 : H12AffineEnvironment.transform 16 38160 env53700 = env53701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env53700 == env53701) = true)

theorem identity53701 : scanCanonicalize (H12AffineFastState.compose env53701 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound53701 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,58396,33,17,95496,8192,64,2049,5392,45404,32040,61704,62588,257,21793,46093,120407]

theorem envBound53702 : H12AffineFastState.Bounded env53702 := by
  intro p hp
  have h : env53702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53701_53702 : H12AffineEnvironment.transform 17 10280 env53701 = env53702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53701 == env53702) = true)

theorem identity53702 : scanCanonicalize (H12AffineFastState.compose env53702 (packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53702 : packedSelected [1,2,5,6,7,8,9,11,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,38160,2421,1025,32769,50497,33,17,87125,349,64,2049,5392,36865,23669,53333,54561,257,21793,38224,120407]

theorem envBound53703 : H12AffineFastState.Bounded env53703 := by
  intro p hp
  have h : env53703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53702_53703 : H12AffineEnvironment.transform 12 349 env53702 = env53703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53702 == env53703) = true)

theorem identity53703 : scanCanonicalize (H12AffineFastState.compose env53703 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound53703 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env53704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33110,38160,2421,1025,32769,50497,33,17,54531,349,64,2049,5392,36865,23669,53333,54561,257,21793,38224,22273]

theorem envBound53704 : H12AffineFastState.Bounded env53704 := by
  intro p hp
  have h : env53704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53703_53704 : H12AffineEnvironment.transform 15 33110 env53703 = env53704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env53703 == env53704) = true)

theorem identity53704 : scanCanonicalize (H12AffineFastState.compose env53704 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53704 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,342,5392,2421,1025,1,17729,33,17,21763,349,64,2049,5392,4097,23669,20565,21793,257,21793,5456,22273]

theorem envBound53705 : H12AffineFastState.Bounded env53705 := by
  intro p hp
  have h : env53705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53704_53705 : H12AffineEnvironment.transform 14 0 env53704 = env53705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53704 == env53705) = true)

theorem identity53705 : scanCanonicalize (H12AffineFastState.compose env53705 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53705 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53706 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,0,114,5172,2129,1025,1,17509,33,17,21543,121,64,2049,5172,4097,23669,20565,21509,37,21509,5236,22053]

theorem envBound53706 : H12AffineFastState.Bounded env53706 := by
  intro p hp
  have h : env53706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53705_53706 : H12AffineEnvironment.transform 7 36 env53705 = env53706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53705 == env53706) = true)

theorem identity53706 : scanCanonicalize (H12AffineFastState.compose env53706 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound53706 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env53707 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,121,16384,0,114,65,2129,1025,1,17509,33,17,16466,121,64,2049,65,1140,18432,17440,16496,37,16496,1,16976]

theorem envBound53707 : H12AffineFastState.Bounded env53707 := by
  intro p hp
  have h : env53707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53706_53707 : H12AffineEnvironment.transform 11 1141 env53706 = env53707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env53706 == env53707) = true)

theorem identity53707 : scanCanonicalize (H12AffineFastState.compose env53707 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound53707 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env53708 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,121,81,0,114,65,2129,1025,1,1076,33,17,3,121,64,2049,65,1140,2129,1137,33,37,33,1,513]

theorem envBound53708 : H12AffineFastState.Bounded env53708 := by
  intro p hp
  have h : env53708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53707_53708 : H12AffineEnvironment.transform 13 81 env53707 = env53708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env53707 == env53708) = true)

theorem identity53708 : scanCanonicalize (H12AffineFastState.compose env53708 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1598) := by decide +kernel

theorem selectedBound53708 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53709 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1598,1141,121,81,0,114,65,1647,1025,1,1076,33,17,3,121,64,1599,65,1140,1647,1137,33,37,33,1,513]

theorem envBound53709 : H12AffineFastState.Bounded env53709 := by
  intro p hp
  have h : env53709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53708_53709 : H12AffineEnvironment.transform 10 1598 env53708 = env53709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1598 env53708 == env53709) = true)

theorem identity53709 : scanCanonicalize (H12AffineFastState.compose env53709 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound53709 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53710 : List Nat := [2,4,8,16,32,64,8,36,512,20,554,97,121,81,0,114,65,635,21,1,32,33,17,3,121,64,555,65,96,635,101,33,37,33,1,513]

theorem envBound53710 : H12AffineFastState.Bounded env53710 := by
  intro p hp
  have h : env53710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53709_53710 : H12AffineEnvironment.transform 9 20 env53709 = env53710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53709 == env53710) = true)

theorem identity53710 : scanCanonicalize (H12AffineFastState.compose env53710 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53710 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53711 : List Nat := [2,4,8,16,32,16,8,36,512,20,554,49,41,1,0,34,17,555,21,1,32,33,17,3,41,16,555,17,48,555,53,33,37,33,1,513]

theorem envBound53711 : H12AffineFastState.Bounded env53711 := by
  intro p hp
  have h : env53711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53710_53711 : H12AffineEnvironment.transform 5 16 env53710 = env53711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53710 == env53711) = true)

theorem identity53711 : scanCanonicalize (H12AffineFastState.compose env53711 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound53711 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53712 : List Nat := [2,4,8,5,32,5,8,36,512,1,554,36,41,1,0,34,4,555,0,1,32,33,4,3,41,5,555,4,37,555,32,33,37,33,1,513]

theorem envBound53712 : H12AffineFastState.Bounded env53712 := by
  intro p hp
  have h : env53712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53711_53712 : H12AffineEnvironment.transform 3 5 env53711 = env53712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env53711 == env53712) = true)

def env53713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272393,16,95496,8192,64,2049,5393,45404,283904,61705,318549,257,21793,46093,120406]

theorem envBound53713 : H12AffineFastState.Bounded env53713 := by
  intro p hp
  have h : env53713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53700_53713 : H12AffineEnvironment.transform 16 38161 env53700 = env53713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env53700 == env53713) = true)

def env53714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1025,21761,12573,272393,16,95496,8192,64,2049,5393,25692,283904,9225,264533,257,21793,24845,66390]

theorem envBound53714 : H12AffineFastState.Bounded env53714 := by
  intro p hp
  have h : env53714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53713_53714 : H12AffineEnvironment.transform 14 21760 env53713 = env53714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env53713 == env53714) = true)

theorem identity53714 : scanCanonicalize (H12AffineFastState.compose env53714 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound53714 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,343,16401,262144,1025,21761,12573,272393,16,29791,8192,64,2049,5393,25692,283904,9225,264533,257,21793,24845,513]

theorem envBound53715 : H12AffineFastState.Bounded env53715 := by
  intro p hp
  have h : env53715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53714_53715 : H12AffineEnvironment.transform 15 343 env53714 = env53715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env53714 == env53715) = true)

theorem identity53715 : scanCanonicalize (H12AffineFastState.compose env53715 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound53715 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,343,16401,23669,1025,21761,12573,29820,16,29791,8192,64,2049,5393,25692,2421,9225,21792,257,21793,24845,513]

theorem envBound53716 : H12AffineFastState.Bounded env53716 := by
  intro p hp
  have h : env53716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53715_53716 : H12AffineEnvironment.transform 17 23669 env53715 = env53716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env53715 == env53716) = true)

theorem identity53716 : scanCanonicalize (H12AffineFastState.compose env53716 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53716 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,16401,23669,1025,21761,4160,21793,16,21762,349,64,2049,5393,17665,2421,1364,21792,257,21793,16464,513]

theorem envBound53717 : H12AffineFastState.Bounded env53717 := by
  intro p hp
  have h : env53717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53716_53717 : H12AffineEnvironment.transform 12 349 env53716 = env53717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53716 == env53717) = true)

theorem identity53717 : scanCanonicalize (H12AffineFastState.compose env53717 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound53717 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,80,343,5441,2341,1025,81,4160,113,16,82,349,64,2049,5393,4177,2421,1364,112,257,113,5376,513]

theorem envBound53718 : H12AffineFastState.Bounded env53718 := by
  intro p hp
  have h : env53718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53717_53718 : H12AffineEnvironment.transform 13 5456 env53717 = env53718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env53717 == env53718) = true)

theorem identity53718 : scanCanonicalize (H12AffineFastState.compose env53718 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound53718 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,367,4096,349,5456,80,343,5441,74,1025,81,4160,113,16,82,349,64,366,5393,4177,26,1364,112,257,113,5376,513]

theorem envBound53719 : H12AffineFastState.Bounded env53719 := by
  intro p hp
  have h : env53719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53718_53719 : H12AffineEnvironment.transform 10 367 env53718 = env53719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env53718 == env53719) = true)

theorem identity53719 : scanCanonicalize (H12AffineFastState.compose env53719 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 367) := by decide +kernel

theorem selectedBound53719 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env53720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,367,367,349,1087,80,343,1070,74,1025,81,303,113,16,82,349,64,366,1150,318,26,1364,112,257,113,1135,513]

theorem envBound53720 : H12AffineFastState.Bounded env53720 := by
  intro p hp
  have h : env53720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53719_53720 : H12AffineEnvironment.transform 11 367 env53719 = env53720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 367 env53719 == env53720) = true)

theorem identity53720 : scanCanonicalize (H12AffineFastState.compose env53720 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 330) := by decide +kernel

theorem selectedBound53720 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env53721 : List Nat := [2,4,8,16,32,64,8,256,512,330,367,367,349,373,80,343,356,74,331,81,303,113,16,82,349,64,366,308,318,26,30,112,257,113,293,513]

theorem envBound53721 : H12AffineFastState.Bounded env53721 := by
  intro p hp
  have h : env53721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53720_53721 : H12AffineEnvironment.transform 9 330 env53720 = env53721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 330 env53720 == env53721) = true)

theorem identity53721 : scanCanonicalize (H12AffineFastState.compose env53721 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 357) := by decide +kernel

theorem selectedBound53721 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53722 : List Nat := [2,4,8,16,32,64,8,256,357,330,367,367,349,373,80,343,356,74,331,81,303,113,16,82,349,64,366,308,318,26,30,112,257,113,293,356]

theorem envBound53722 : H12AffineFastState.Bounded env53722 := by
  intro p hp
  have h : env53722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53721_53722 : H12AffineEnvironment.transform 8 357 env53721 = env53722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 357 env53721 == env53722) = true)

theorem identity53722 : scanCanonicalize (H12AffineFastState.compose env53722 (packedSelected [1,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53722 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env53723 : List Nat := [2,4,8,0,32,64,8,256,357,330,367,367,333,357,64,327,356,74,331,65,303,97,0,66,333,64,366,292,302,10,14,96,257,97,293,356]

theorem envBound53723 : H12AffineFastState.Bounded env53723 := by
  intro p hp
  have h : env53723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53722_53723 : H12AffineEnvironment.transform 3 0 env53722 = env53723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53722 == env53723) = true)

theorem identity53723 : scanCanonicalize (H12AffineFastState.compose env53723 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound53723 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53724 : List Nat := [2,4,8,0,32,64,8,14,107,68,97,97,67,107,64,73,106,74,69,65,33,97,0,66,67,64,96,42,32,10,14,96,15,97,43,106]

theorem envBound53724 : H12AffineFastState.Bounded env53724 := by
  intro p hp
  have h : env53724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53723_53724 : H12AffineEnvironment.transform 7 14 env53723 = env53724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env53723 == env53724) = true)

theorem identity53724 : scanCanonicalize (H12AffineFastState.compose env53724 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

theorem selectedBound53724 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53725 : List Nat := [2,4,8,0,32,15,8,14,36,11,46,46,12,36,15,6,37,5,10,14,33,46,0,13,12,15,47,42,32,10,14,47,15,46,43,37]

theorem envBound53725 : H12AffineFastState.Bounded env53725 := by
  intro p hp
  have h : env53725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53724_53725 : H12AffineEnvironment.transform 5 15 env53724 = env53725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env53724 == env53725) = true)

theorem identity53725 : scanCanonicalize (H12AffineFastState.compose env53725 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound53725 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env53726 : List Nat := [2,4,8,0,9,15,8,14,13,11,7,7,12,13,15,6,12,5,10,14,8,7,0,13,12,15,6,3,9,10,14,6,15,7,2,12]

theorem envBound53726 : H12AffineFastState.Bounded env53726 := by
  intro p hp
  have h : env53726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53725_53726 : H12AffineEnvironment.transform 4 9 env53725 = env53726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env53725 == env53726) = true)

theorem identity53726 : scanCanonicalize (H12AffineFastState.compose env53726 (packedSelected [1,11] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound53726 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env53727 : List Nat := [2,4,0,0,1,7,0,6,5,3,7,7,4,5,7,6,4,5,2,6,0,7,0,5,4,7,6,3,1,2,6,6,7,7,2,4]

theorem envBound53727 : H12AffineFastState.Bounded env53727 := by
  intro p hp
  have h : env53727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53726_53727 : H12AffineEnvironment.transform 2 0 env53726 = env53727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env53726 == env53727) = true)

def env53728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1025,21760,12572,272393,16,95496,8192,64,2049,5393,25693,283904,9224,264532,257,21793,24844,66391]

theorem envBound53728 : H12AffineFastState.Bounded env53728 := by
  intro p hp
  have h : env53728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53713_53728 : H12AffineEnvironment.transform 14 21761 env53713 = env53728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env53713 == env53728) = true)

theorem identity53728 : scanCanonicalize (H12AffineFastState.compose env53728 (packedSelected [1,4,8,9,12,14,16,19,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound53728 : packedSelected [1,4,8,9,12,14,16,19,38] rootPS < 2^1333 := by decide +kernel

def env53729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16400,32040,1025,21760,12572,21793,16,95496,8192,64,2049,5393,25693,10280,9224,29820,257,21793,24844,66391]

theorem envBound53729 : H12AffineFastState.Bounded env53729 := by
  intro p hp
  have h : env53729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53728_53729 : H12AffineEnvironment.transform 17 32040 env53728 = env53729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env53728 == env53729) = true)

theorem identity53729 : scanCanonicalize (H12AffineFastState.compose env53729 (packedSelected [4,5,9,12,14,15,16,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound53729 : packedSelected [4,5,9,12,14,15,16,24,26] rootPS < 2^1333 := by decide +kernel

def env53730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8283,16400,32040,1025,21760,12572,21793,16,21843,8192,64,2049,5393,25693,10280,9224,29820,257,21793,24844,8972]

theorem envBound53730 : H12AffineFastState.Bounded env53730 := by
  intro p hp
  have h : env53730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53729_53730 : H12AffineEnvironment.transform 15 8283 env53729 = env53730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env53729 == env53730) = true)

theorem identity53730 : scanCanonicalize (H12AffineFastState.compose env53730 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound53730 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env53731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8460,8283,13341,2341,1025,8461,12572,8492,16,8542,8192,64,2049,5393,4176,10280,9224,113,257,8492,5377,8972]

theorem envBound53731 : H12AffineFastState.Bounded env53731 := by
  intro p hp
  have h : env53731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53730_53731 : H12AffineEnvironment.transform 13 13325 env53730 = env53731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env53730 == env53731) = true)

theorem identity53731 : scanCanonicalize (H12AffineFastState.compose env53731 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53731 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env53732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,0,343,5393,2341,1025,1,4112,32,16,82,268,64,2049,5393,4176,2340,1284,113,257,32,5377,512]

theorem envBound53732 : H12AffineFastState.Bounded env53732 := by
  intro p hp
  have h : env53732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53731_53732 : H12AffineEnvironment.transform 12 268 env53731 = env53732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53731 == env53732) = true)

theorem identity53732 : scanCanonicalize (H12AffineFastState.compose env53732 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53732 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53733 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,268,5377,0,343,5393,2308,1025,1,4112,1,16,82,268,64,2049,5393,4176,2309,1284,80,257,1,5377,512]

theorem envBound53733 : H12AffineFastState.Bounded env53733 := by
  intro p hp
  have h : env53733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53732_53733 : H12AffineEnvironment.transform 4 1 env53732 = env53733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53732 == env53733) = true)

theorem identity53733 : scanCanonicalize (H12AffineFastState.compose env53733 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53733 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53734 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,4096,268,4112,0,343,4096,2308,272,1,4112,1,16,82,268,64,2049,4096,4176,2309,21,80,257,1,4112,512]

theorem envBound53734 : H12AffineFastState.Bounded env53734 := by
  intro p hp
  have h : env53734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53733_53734 : H12AffineEnvironment.transform 9 273 env53733 = env53734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53733 == env53734) = true)

def env53735 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160012,272392,169216,95496,8193,64,2049,163841,45405,283905,156697,411972,257,21793,46092,213831]

theorem envBound53735 : H12AffineFastState.Bounded env53735 := by
  intro p hp
  have h : env53735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53699_53735 : H12AffineEnvironment.transform 6 9 env53699 = env53735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53699 == env53735) = true)

def env53736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58396,272392,16,95496,8193,64,2049,5393,45405,283905,61705,318548,257,21793,46092,120407]

theorem envBound53736 : H12AffineFastState.Bounded env53736 := by
  intro p hp
  have h : env53736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53735_53736 : H12AffineEnvironment.transform 16 38160 env53735 = env53736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env53735 == env53736) = true)

theorem identity53736 : scanCanonicalize (H12AffineFastState.compose env53736 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound53736 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,13389,262144,1025,8540,17729,272392,16,95496,8193,64,2049,5393,4096,283905,20564,294153,257,21793,5457,96010]

theorem envBound53737 : H12AffineFastState.Bounded env53737 := by
  intro p hp
  have h : env53737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53736_53737 : H12AffineEnvironment.transform 14 8541 env53736 = env53737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env53736 == env53737) = true)

theorem identity53737 : scanCanonicalize (H12AffineFastState.compose env53737 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound53737 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env53738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,13389,67618,1025,8540,17729,73770,16,95496,8193,64,2049,5393,4096,89379,20564,95531,257,21793,5457,96010]

theorem envBound53738 : H12AffineFastState.Bounded env53738 := by
  intro p hp
  have h : env53738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53737_53738 : H12AffineEnvironment.transform 17 67618 env53737 = env53738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env53737 == env53738) = true)

theorem identity53738 : scanCanonicalize (H12AffineFastState.compose env53738 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53738 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,65536,5393,67618,1025,0,17729,65910,16,87124,349,64,2049,5393,4096,89379,20564,87159,257,21793,5457,87638]

theorem envBound53739 : H12AffineFastState.Bounded env53739 := by
  intro p hp
  have h : env53739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53738_53739 : H12AffineEnvironment.transform 12 348 env53738 = env53739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53738 == env53739) = true)

theorem identity53739 : scanCanonicalize (H12AffineFastState.compose env53739 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound53739 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env53740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21795,5393,23809,1025,0,17729,21589,16,375,349,64,2049,5393,4096,2048,20564,340,257,21793,5457,885]

theorem envBound53740 : H12AffineFastState.Bounded env53740 := by
  intro p hp
  have h : env53740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53739_53740 : H12AffineEnvironment.transform 15 21795 env53739 = env53740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env53739 == env53740) = true)

theorem identity53740 : scanCanonicalize (H12AffineFastState.compose env53740 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53740 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env53741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,35,5393,2049,1025,0,4161,341,16,375,349,64,2049,5393,4096,2048,1364,340,257,33,5457,885]

theorem envBound53741 : H12AffineFastState.Bounded env53741 := by
  intro p hp
  have h : env53741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53740_53741 : H12AffineEnvironment.transform 13 5376 env53740 = env53741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53740 == env53741) = true)

theorem identity53741 : scanCanonicalize (H12AffineFastState.compose env53741 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53741 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53742 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5156,1,35,5173,2049,1025,0,4161,113,16,83,121,64,2049,5173,4096,2048,1136,112,37,33,5237,593]

theorem envBound53742 : H12AffineFastState.Bounded env53742 := by
  intro p hp
  have h : env53742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53741_53742 : H12AffineEnvironment.transform 7 36 env53741 = env53742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53741 == env53742) = true)

theorem identity53742 : scanCanonicalize (H12AffineFastState.compose env53742 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound53742 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53743 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,2112,120,3172,1,35,3189,2049,1025,0,2049,113,16,83,121,64,2049,3189,2112,2048,1136,112,37,33,3125,593]

theorem envBound53743 : H12AffineFastState.Bounded env53743 := by
  intro p hp
  have h : env53743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53742_53743 : H12AffineEnvironment.transform 11 2112 env53742 = env53743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env53742 == env53743) = true)

theorem identity53743 : scanCanonicalize (H12AffineFastState.compose env53743 (packedSelected [2,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound53743 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env53744 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,2112,120,2129,1,35,2112,2049,52,0,2049,113,16,83,121,64,2049,2112,2112,2048,69,112,37,33,2048,593]

theorem envBound53744 : H12AffineFastState.Bounded env53744 := by
  intro p hp
  have h : env53744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53743_53744 : H12AffineEnvironment.transform 9 53 env53743 = env53744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53743 == env53744) = true)

theorem identity53744 : scanCanonicalize (H12AffineFastState.compose env53744 (packedSelected [2,7] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound53744 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env53745 : List Nat := [2,4,8,16,32,64,9,36,81,53,2048,2112,120,2129,1,35,2112,2049,52,0,2049,113,16,83,121,64,2049,2112,2112,2048,69,112,37,33,2048,0]

theorem envBound53745 : H12AffineFastState.Bounded env53745 := by
  intro p hp
  have h : env53745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53744_53745 : H12AffineEnvironment.transform 8 81 env53744 = env53745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env53744 == env53745) = true)

def env53746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,58397,272392,17,95496,8193,64,2049,5392,45405,283905,61704,318549,257,21793,46092,120406]

theorem envBound53746 : H12AffineFastState.Bounded env53746 := by
  intro p hp
  have h : env53746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53735_53746 : H12AffineEnvironment.transform 16 38161 env53735 = env53746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env53735 == env53746) = true)

theorem identity53746 : scanCanonicalize (H12AffineFastState.compose env53746 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound53746 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35188,1025,32769,58397,41340,17,95496,8193,64,2049,5392,45405,56437,61704,21793,257,21793,46092,120406]

theorem envBound53747 : H12AffineFastState.Bounded env53747 := by
  intro p hp
  have h : env53747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53746_53747 : H12AffineEnvironment.transform 17 35188 env53746 = env53747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env53746 == env53747) = true)

theorem identity53747 : scanCanonicalize (H12AffineFastState.compose env53747 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound53747 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env53748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,65536,5220,2049,1025,372,25960,8201,17,95496,8193,64,2049,5392,12328,23808,28797,21793,257,21793,13689,87843]

theorem envBound53748 : H12AffineFastState.Bounded env53748 := by
  intro p hp
  have h : env53748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53747_53748 : H12AffineEnvironment.transform 14 373 env53747 = env53748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env53747 == env53748) = true)

theorem identity53748 : scanCanonicalize (H12AffineFastState.compose env53748 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound53748 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,21794,5220,2049,1025,372,25960,8201,17,8234,8193,64,2049,5392,12328,23808,28797,21793,257,21793,13689,513]

theorem envBound53749 : H12AffineFastState.Bounded env53749 := by
  intro p hp
  have h : env53749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53748_53749 : H12AffineEnvironment.transform 15 21794 env53748 = env53749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env53748 == env53749) = true)

theorem identity53749 : scanCanonicalize (H12AffineFastState.compose env53749 (packedSelected [11,18] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound53749 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env53750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,373,1331,5220,2049,1025,372,13689,8201,17,8234,8193,64,2049,5392,12328,3345,8300,1328,257,1328,13689,513]

theorem envBound53750 : H12AffineFastState.Bounded env53750 := by
  intro p hp
  have h : env53750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53749_53750 : H12AffineEnvironment.transform 13 4113 env53749 = env53750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env53749 == env53750) = true)

theorem identity53750 : scanCanonicalize (H12AffineFastState.compose env53750 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound53750 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53751 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,4113,373,343,4096,2049,101,372,12573,8201,17,8234,8193,64,2049,4468,12328,2421,8300,340,257,340,12573,513]

theorem envBound53751 : H12AffineFastState.Bounded env53751 := by
  intro p hp
  have h : env53751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53750_53751 : H12AffineEnvironment.transform 9 100 env53750 = env53751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env53750 == env53751) = true)

theorem identity53751 : scanCanonicalize (H12AffineFastState.compose env53751 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53751 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env53752 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,268,4113,373,343,4096,2049,101,372,4113,261,17,294,269,64,2049,4468,4388,2421,352,340,257,340,4113,513]

theorem envBound53752 : H12AffineFastState.Bounded env53752 := by
  intro p hp
  have h : env53752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53751_53752 : H12AffineEnvironment.transform 12 268 env53751 = env53752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53751 == env53752) = true)

theorem identity53752 : scanCanonicalize (H12AffineFastState.compose env53752 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53752 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53753 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,268,4113,292,262,4096,2049,52,293,4113,261,17,294,269,17,2049,4389,4388,2340,305,261,257,261,4113,513]

theorem envBound53753 : H12AffineFastState.Bounded env53753 := by
  intro p hp
  have h : env53753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53752_53753 : H12AffineEnvironment.transform 5 17 env53752 = env53753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53752 == env53753) = true)

theorem identity53753 : scanCanonicalize (H12AffineFastState.compose env53753 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound53753 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53754 : List Nat := [2,4,8,16,17,17,9,256,512,4,2048,4096,268,4113,277,262,4096,2049,5,276,4113,261,17,279,269,17,2049,4372,4373,2325,256,261,257,261,4113,513]

theorem envBound53754 : H12AffineFastState.Bounded env53754 := by
  intro p hp
  have h : env53754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53753_53754 : H12AffineEnvironment.transform 4 17 env53753 = env53754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env53753 == env53754) = true)

theorem identity53754 : scanCanonicalize (H12AffineFastState.compose env53754 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 262) := by decide +kernel

theorem selectedBound53754 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53755 : List Nat := [2,4,8,16,17,17,9,256,512,4,262,4096,268,4113,277,262,4096,263,5,276,4113,261,17,279,269,17,263,4372,4373,19,256,261,257,261,4113,513]

theorem envBound53755 : H12AffineFastState.Bounded env53755 := by
  intro p hp
  have h : env53755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53754_53755 : H12AffineEnvironment.transform 10 262 env53754 = env53755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 262 env53754 == env53755) = true)

theorem identity53755 : scanCanonicalize (H12AffineFastState.compose env53755 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound53755 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env53756 : List Nat := [2,4,8,16,17,17,9,256,19,4,262,4096,268,4113,277,262,4096,263,5,276,4113,261,17,279,269,17,263,4372,4373,19,256,261,257,261,4113,18]

theorem envBound53756 : H12AffineFastState.Bounded env53756 := by
  intro p hp
  have h : env53756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53755_53756 : H12AffineEnvironment.transform 8 19 env53755 = env53756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env53755 == env53756) = true)

theorem identity53756 : scanCanonicalize (H12AffineFastState.compose env53756 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound53756 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env53757 : List Nat := [2,4,8,16,17,17,9,30,19,4,24,4096,18,4113,11,24,4096,25,5,10,4113,27,17,9,19,17,25,4106,4107,19,30,27,31,27,4113,18]

theorem envBound53757 : H12AffineFastState.Bounded env53757 := by
  intro p hp
  have h : env53757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53756_53757 : H12AffineEnvironment.transform 7 30 env53756 = env53757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env53756 == env53757) = true)

theorem identity53757 : scanCanonicalize (H12AffineFastState.compose env53757 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53757 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env53758 : List Nat := [2,4,8,10,11,11,9,4,9,4,2,4096,8,4107,11,2,4096,3,5,10,4107,1,11,9,9,11,3,4106,4107,9,4,1,5,1,4107,8]

theorem envBound53758 : H12AffineFastState.Bounded env53758 := by
  intro p hp
  have h : env53758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53757_53758 : H12AffineEnvironment.transform 3 10 env53757 = env53758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53757 == env53758) = true)

theorem identity53758 : scanCanonicalize (H12AffineFastState.compose env53758 (packedSelected [1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53758 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env53759 : List Nat := [2,2,8,10,11,11,9,2,9,2,2,4096,8,4107,11,2,4096,3,3,10,4107,1,11,9,9,11,3,4106,4107,9,2,1,3,1,4107,8]

theorem envBound53759 : H12AffineFastState.Bounded env53759 := by
  intro p hp
  have h : env53759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53758_53759 : H12AffineEnvironment.transform 1 2 env53758 = env53759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53758 == env53759) = true)

theorem identity53759 : scanCanonicalize (H12AffineFastState.compose env53759 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound53759 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env53760 : List Nat := [2,2,1,3,2,2,0,2,0,2,2,4096,1,4098,2,2,4096,3,3,3,4098,1,2,0,0,2,3,4099,4098,0,2,1,3,1,4098,1]

theorem envBound53760 : H12AffineFastState.Bounded env53760 := by
  intro p hp
  have h : env53760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53759_53760 : H12AffineEnvironment.transform 2 1 env53759 = env53760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env53759 == env53760) = true)

theorem identity53760 : scanCanonicalize (H12AffineFastState.compose env53760 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound53760 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53761 : List Nat := [2,2,1,3,2,2,0,2,0,2,2,1,1,3,2,2,1,3,3,3,3,1,2,0,0,2,3,2,3,0,2,1,3,1,3,1]

theorem envBound53761 : H12AffineFastState.Bounded env53761 := by
  intro p hp
  have h : env53761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53760_53761 : H12AffineEnvironment.transform 11 1 env53760 = env53761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53760 == env53761) = true)

theorem identity53761 : scanCanonicalize (H12AffineFastState.compose env53761 (packedSelected [19] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53761 : packedSelected [19] rootPS < 2^1333 := by decide +kernel

def env53762 : List Nat := [0,0,1,1,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,0,0,0,0,1,0,1,0,0,1,1,1,1,1]

theorem envBound53762 : H12AffineFastState.Bounded env53762 := by
  intro p hp
  have h : env53762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53761_53762 : H12AffineEnvironment.transform 0 0 env53761 = env53762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53761 == env53762) = true)

def env53763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,8388608,8642689,8328,64,4464768,8393984,8528988,8830977,156816,12645453,257,21792,46212,213831]

theorem envBound53763 : H12AffineFastState.Bounded env53763 := by
  intro p hp
  have h : env53763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53628_53763 : H12AffineEnvironment.transform 20 160013 env53628 = env53763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160013 env53628 == env53763) = true)

def env53764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,169352,95497,8328,64,4464768,163976,45524,284041,156816,4350405,257,21792,46212,213831]

theorem envBound53764 : H12AffineFastState.Bounded env53764 := by
  intro p hp
  have h : env53764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53763_53764 : H12AffineEnvironment.transform 22 169352 env53763 = env53764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env53763 == env53764) = true)

def env53765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272512,169352,95497,8328,64,2048,163976,45524,284041,156816,411973,257,21792,46212,213831]

theorem envBound53765 : H12AffineFastState.Bounded env53765 := by
  intro p hp
  have h : env53765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53764_53765 : H12AffineEnvironment.transform 21 272512 env53764 = env53765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53764 == env53765) = true)

theorem identity53765 : scanCanonicalize (H12AffineFastState.compose env53765 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound53765 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,160013,272512,169352,41430,8328,64,2048,163976,45524,284041,156816,411973,257,21792,46212,169880]

theorem envBound53766 : H12AffineFastState.Bounded env53766 := by
  intro p hp
  have h : env53766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53765_53766 : H12AffineEnvironment.transform 15 54495 env53765 = env53766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env53765 == env53766) = true)

def env53767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,160013,272392,169216,41310,8192,64,2048,163840,45404,283905,156696,411973,257,21792,46092,169744]

theorem envBound53767 : H12AffineFastState.Bounded env53767 := by
  intro p hp
  have h : env53767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53766_53767 : H12AffineEnvironment.transform 6 8 env53766 = env53767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53766 == env53767) = true)

theorem identity53767 : scanCanonicalize (H12AffineFastState.compose env53767 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound53767 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env53768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,160013,21793,169216,41310,8192,64,2048,163840,45404,10280,156696,144492,257,21792,46092,169744]

theorem envBound53768 : H12AffineFastState.Bounded env53768 := by
  intro p hp
  have h : env53768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53767_53768 : H12AffineEnvironment.transform 17 32041 env53767 = env53768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env53767 == env53768) = true)

theorem identity53768 : scanCanonicalize (H12AffineFastState.compose env53768 (packedSelected [1,3,4,8,9,10,12,14,15,17,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound53768 : packedSelected [1,3,4,8,9,10,12,14,15,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env53769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,160013,21793,155997,21763,8192,64,2048,160861,17665,10280,156696,144492,257,21792,16465,156493]

theorem envBound53769 : H12AffineFastState.Bounded env53769 := by
  intro p hp
  have h : env53769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53768_53769 : H12AffineEnvironment.transform 14 29789 env53768 = env53769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env53768 == env53769) = true)

theorem identity53769 : scanCanonicalize (H12AffineFastState.compose env53769 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound53769 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env53770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,24632,32041,1025,29788,4405,21793,357,21763,8192,64,2048,5221,17665,10280,1056,21588,257,21792,16465,885]

theorem envBound53770 : H12AffineFastState.Bounded env53770 := by
  intro p hp
  have h : env53770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53769_53770 : H12AffineEnvironment.transform 16 24632 env53769 = env53770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env53769 == env53770) = true)

theorem identity53770 : scanCanonicalize (H12AffineFastState.compose env53770 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound53770 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,5220,2421,1025,0,4405,8573,357,8543,8192,64,2048,5221,12637,10280,1056,8200,257,8572,13325,885]

theorem envBound53771 : H12AffineFastState.Bounded env53771 := by
  intro p hp
  have h : env53771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53770_53771 : H12AffineEnvironment.transform 13 13404 env53770 = env53771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env53770 == env53771) = true)

def env53772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,160013,272393,169217,41311,8193,64,2048,163841,45405,283904,156697,411973,257,21792,46093,169745]

theorem envBound53772 : H12AffineFastState.Bounded env53772 := by
  intro p hp
  have h : env53772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53766_53772 : H12AffineEnvironment.transform 6 9 env53766 = env53772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53766 == env53772) = true)

theorem identity53772 : scanCanonicalize (H12AffineFastState.compose env53772 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound53772 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env53773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21621,35,131072,262144,1025,21620,160013,272393,147828,29994,8193,64,2048,152692,25896,283904,156697,411973,257,21792,24696,148324]

theorem envBound53773 : H12AffineFastState.Bounded env53773 := by
  intro p hp
  have h : env53773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53772_53773 : H12AffineEnvironment.transform 14 21621 env53772 = env53773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env53772 == env53773) = true)

theorem identity53773 : scanCanonicalize (H12AffineFastState.compose env53773 (packedSelected [1,3,4,9,10,14,16,17,19,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound53773 : packedSelected [1,3,4,9,10,14,16,17,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21621,35,131072,138340,1025,21620,160013,144493,147828,29994,8193,64,2048,152692,25896,149860,156697,21793,257,21792,24696,148324]

theorem envBound53774 : H12AffineFastState.Bounded env53774 := by
  intro p hp
  have h : env53774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53773_53774 : H12AffineEnvironment.transform 17 138340 env53773 = env53774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env53773 == env53774) = true)

theorem identity53774 : scanCanonicalize (H12AffineFastState.compose env53774 (packedSelected [0,1,4,7,8,12,15,16,17,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound53774 : packedSelected [0,1,4,7,8,12,15,16,17,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env53775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21621,35,16449,23589,1025,21620,12620,29740,309,29994,8193,64,2048,5173,25896,2341,9304,21793,257,21792,24696,805]

theorem envBound53775 : H12AffineFastState.Bounded env53775 := by
  intro p hp
  have h : env53775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53774_53775 : H12AffineEnvironment.transform 16 16449 env53774 = env53775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env53774 == env53775) = true)

theorem identity53775 : scanCanonicalize (H12AffineFastState.compose env53775 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound53775 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env53776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,8460,35,13624,10588,1025,8461,12620,341,309,83,8193,64,2048,5173,4177,2341,9304,8280,257,8281,5377,805]

theorem envBound53776 : H12AffineFastState.Bounded env53776 := by
  intro p hp
  have h : env53776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53775_53776 : H12AffineEnvironment.transform 13 13689 env53775 = env53776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env53775 == env53776) = true)

theorem identity53776 : scanCanonicalize (H12AffineFastState.compose env53776 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound53776 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5456,293,35,5393,2421,1025,292,4453,341,309,83,40,64,2048,5173,4177,2341,1137,113,257,112,5377,805]

theorem envBound53777 : H12AffineFastState.Bounded env53777 := by
  intro p hp
  have h : env53777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53776_53777 : H12AffineEnvironment.transform 12 41 env53776 = env53777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env53776 == env53777) = true)

theorem identity53777 : scanCanonicalize (H12AffineFastState.compose env53777 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound53777 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env53778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,41,2341,293,35,2404,2421,1025,292,3344,341,309,83,40,64,2048,2112,3108,2341,1137,113,257,112,2420,805]

theorem envBound53778 : H12AffineFastState.Bounded env53778 := by
  intro p hp
  have h : env53778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53777_53778 : H12AffineEnvironment.transform 11 3189 env53777 = env53778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env53777 == env53778) = true)

theorem identity53778 : scanCanonicalize (H12AffineFastState.compose env53778 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53778 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env53779 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3189,41,2049,1,35,2112,2129,1025,0,3124,113,17,83,40,64,2048,2112,3108,2049,1137,113,37,112,2128,513]

theorem envBound53779 : H12AffineFastState.Bounded env53779 := by
  intro p hp
  have h : env53779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53778_53779 : H12AffineEnvironment.transform 7 36 env53778 = env53779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53778 == env53779) = true)

theorem identity53779 : scanCanonicalize (H12AffineFastState.compose env53779 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53779 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53780 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3108,41,2049,1,35,2065,2048,1025,0,3124,32,17,2,40,17,2048,2065,3108,2049,1056,32,37,33,2049,513]

theorem envBound53780 : H12AffineFastState.Bounded env53780 := by
  intro p hp
  have h : env53780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53779_53780 : H12AffineEnvironment.transform 5 17 env53779 = env53780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53779 == env53780) = true)

theorem identity53780 : scanCanonicalize (H12AffineFastState.compose env53780 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound53780 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53781 : List Nat := [2,4,8,16,32,17,9,36,512,1024,0,1060,41,1,1,35,17,0,1025,0,1076,32,17,2,40,17,0,17,1060,1,1056,32,37,33,1,513]

theorem envBound53781 : H12AffineFastState.Bounded env53781 := by
  intro p hp
  have h : env53781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53780_53781 : H12AffineEnvironment.transform 10 0 env53780 = env53781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53780 == env53781) = true)

theorem identity53781 : scanCanonicalize (H12AffineFastState.compose env53781 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound53781 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53782 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,16,41,1,1,35,17,0,53,0,0,32,17,2,40,17,0,17,16,1,20,32,37,33,1,513]

theorem envBound53782 : H12AffineFastState.Bounded env53782 := by
  intro p hp
  have h : env53782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53781_53782 : H12AffineEnvironment.transform 9 52 env53781 = env53782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53781 == env53782) = true)

theorem identity53782 : scanCanonicalize (H12AffineFastState.compose env53782 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound53782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53783 : List Nat := [2,4,8,16,32,17,9,36,0,52,0,16,41,1,1,35,17,0,53,0,0,32,17,2,40,17,0,17,16,1,20,32,37,33,1,1]

theorem envBound53783 : H12AffineFastState.Bounded env53783 := by
  intro p hp
  have h : env53783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53782_53783 : H12AffineEnvironment.transform 8 0 env53782 = env53783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env53782 == env53783) = true)

theorem identity53783 : scanCanonicalize (H12AffineFastState.compose env53783 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53783 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53784 : List Nat := [2,4,8,16,10,17,9,14,0,30,0,16,3,1,1,9,17,0,31,0,0,10,17,2,2,17,0,17,16,1,20,10,15,11,1,1]

theorem envBound53784 : H12AffineFastState.Bounded env53784 := by
  intro p hp
  have h : env53784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53783_53784 : H12AffineEnvironment.transform 4 10 env53783 = env53784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53783 == env53784) = true)

def env53785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272513,169352,95497,8328,64,2049,163976,45524,284041,156816,411972,257,21792,46212,213831]

theorem envBound53785 : H12AffineFastState.Bounded env53785 := by
  intro p hp
  have h : env53785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53764_53785 : H12AffineEnvironment.transform 21 272513 env53764 = env53785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53764 == env53785) = true)

theorem identity53785 : scanCanonicalize (H12AffineFastState.compose env53785 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound53785 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272513,120014,95497,8328,64,2049,115150,45524,284041,75222,329730,257,21792,46212,513]

theorem envBound53786 : H12AffineFastState.Bounded env53786 := by
  intro p hp
  have h : env53786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53785_53786 : H12AffineEnvironment.transform 16 82246 env53785 = env53786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env53785 == env53786) = true)

def env53787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272393,119878,95497,8192,64,2049,115014,45404,283905,75102,329730,257,21792,46092,513]

theorem envBound53787 : H12AffineFastState.Bounded env53787 := by
  intro p hp
  have h : env53787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53786_53787 : H12AffineEnvironment.transform 6 8 env53786 = env53787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53786 == env53787) = true)

def env53788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,77899,33,119878,95497,8192,64,2049,115014,45404,32041,75102,73770,257,21792,46092,513]

theorem envBound53788 : H12AffineFastState.Bounded env53788 := by
  intro p hp
  have h : env53788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53787_53788 : H12AffineEnvironment.transform 17 10280 env53787 = env53788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53787 == env53788) = true)

theorem identity53788 : scanCanonicalize (H12AffineFastState.compose env53788 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53788 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env53789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,82246,10280,1025,0,77899,33,87111,95497,8192,64,2049,82247,12637,32041,75102,73770,257,21792,13325,513]

theorem envBound53789 : H12AffineFastState.Bounded env53789 := by
  intro p hp
  have h : env53789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53788_53789 : H12AffineEnvironment.transform 14 1 env53788 = env53789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53788 == env53789) = true)

theorem identity53789 : scanCanonicalize (H12AffineFastState.compose env53789 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53789 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env53790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,65536,82246,2421,1025,0,69910,33,87111,87124,349,64,2049,82247,4096,23668,66563,65911,257,21792,5456,513]

theorem envBound53790 : H12AffineFastState.Bounded env53790 := by
  intro p hp
  have h : env53790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53789_53790 : H12AffineEnvironment.transform 12 349 env53789 = env53790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53789 == env53790) = true)

theorem identity53790 : scanCanonicalize (H12AffineFastState.compose env53790 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound53790 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21510,5440,2421,1025,0,17680,33,65,82,349,64,2049,5441,4096,23668,20485,21873,257,21792,5456,513]

theorem envBound53791 : H12AffineFastState.Bounded env53791 := by
  intro p hp
  have h : env53791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53790_53791 : H12AffineEnvironment.transform 15 21510 env53790 = env53791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env53790 == env53791) = true)

theorem identity53791 : scanCanonicalize (H12AffineFastState.compose env53791 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53791 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,262,5440,2421,1025,0,4112,33,65,82,349,64,2049,5441,4096,2420,1285,113,257,32,5456,513]

theorem envBound53792 : H12AffineFastState.Bounded env53792 := by
  intro p hp
  have h : env53792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53791_53792 : H12AffineEnvironment.transform 13 5376 env53791 = env53792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53791 == env53792) = true)

theorem identity53792 : scanCanonicalize (H12AffineFastState.compose env53792 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53792 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53793 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,262,5392,2341,1025,0,4112,33,17,2,269,16,2049,5393,4096,2340,1285,33,257,32,5376,513]

theorem envBound53793 : H12AffineFastState.Bounded env53793 := by
  intro p hp
  have h : env53793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53792_53793 : H12AffineEnvironment.transform 5 16 env53792 = env53793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53792 == env53793) = true)

theorem identity53793 : scanCanonicalize (H12AffineFastState.compose env53793 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound53793 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53794 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4404,1,262,4388,2341,53,0,4112,33,17,2,269,16,2049,4389,4096,2340,305,33,257,32,4404,513]

theorem envBound53794 : H12AffineFastState.Bounded env53794 := by
  intro p hp
  have h : env53794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53793_53794 : H12AffineEnvironment.transform 9 52 env53793 = env53794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53793 == env53794) = true)

theorem identity53794 : scanCanonicalize (H12AffineFastState.compose env53794 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound53794 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53795 : List Nat := [2,4,8,16,32,16,8,256,512,52,522,4096,269,4404,1,262,4388,815,53,0,4112,33,17,2,269,16,523,4389,4096,814,305,33,257,32,4404,513]

theorem envBound53795 : H12AffineFastState.Bounded env53795 := by
  intro p hp
  have h : env53795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53794_53795 : H12AffineEnvironment.transform 10 522 env53794 = env53795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env53794 == env53795) = true)

theorem identity53795 : scanCanonicalize (H12AffineFastState.compose env53795 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 799) := by decide +kernel

theorem selectedBound53795 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53796 : List Nat := [2,4,8,16,32,16,8,256,512,52,522,799,269,555,1,262,571,815,53,0,783,33,17,2,269,16,523,570,799,814,305,33,257,32,555,513]

theorem envBound53796 : H12AffineFastState.Bounded env53796 := by
  intro p hp
  have h : env53796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53795_53796 : H12AffineEnvironment.transform 11 799 env53795 = env53796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 799 env53795 == env53796) = true)

def env53797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1025,32769,77899,32,119878,95497,8192,64,2049,115014,45404,32040,75102,73771,257,21792,46092,513]

theorem envBound53797 : H12AffineFastState.Bounded env53797 := by
  intro p hp
  have h : env53797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53787_53797 : H12AffineEnvironment.transform 17 10281 env53787 = env53797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53787 == env53797) = true)

theorem identity53797 : scanCanonicalize (H12AffineFastState.compose env53797 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound53797 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10281,1025,32769,58397,32,16,41311,8192,64,2049,5392,45404,32040,61704,62589,257,21792,46092,513]

theorem envBound53798 : H12AffineFastState.Bounded env53798 := by
  intro p hp
  have h : env53798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53797_53798 : H12AffineEnvironment.transform 15 54358 env53797 = env53798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env53797 == env53798) = true)

theorem identity53798 : scanCanonicalize (H12AffineFastState.compose env53798 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 7424) := by decide +kernel

theorem selectedBound53798 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env53799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,7424,18774,2064,10281,1025,7425,31005,32,16,15455,8192,64,2049,5392,11356,32040,27656,27005,257,21792,10508,513]

theorem envBound53799 : H12AffineFastState.Bounded env53799 := by
  intro p hp
  have h : env53799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53798_53799 : H12AffineEnvironment.transform 14 7424 env53798 = env53799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7424 env53798 == env53799) = true)

theorem identity53799 : scanCanonicalize (H12AffineFastState.compose env53799 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53799 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,7424,18774,2064,2421,1025,7425,22593,32,16,7427,348,64,2049,5392,3328,23668,19796,18465,257,21792,2128,513]

theorem envBound53800 : H12AffineFastState.Bounded env53800 := by
  intro p hp
  have h : env53800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53799_53800 : H12AffineEnvironment.transform 12 348 env53799 = env53800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53799 == env53800) = true)

theorem identity53800 : scanCanonicalize (H12AffineFastState.compose env53800 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound53800 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env53801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,1297,7424,3143,2064,2421,1025,7425,7504,32,16,7427,348,64,2049,5392,3328,6501,2117,3376,257,4145,2128,513]

theorem envBound53801 : H12AffineFastState.Bounded env53801 := by
  intro p hp
  have h : env53801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53800_53801 : H12AffineEnvironment.transform 13 1297 env53800 = env53801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env53800 == env53801) = true)

theorem identity53801 : scanCanonicalize (H12AffineFastState.compose env53801 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53801 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env53802 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,1,6160,2391,2064,2421,273,6161,6208,32,16,6163,348,64,2049,4096,2064,6501,2117,2080,257,4145,2128,513]

theorem envBound53802 : H12AffineFastState.Bounded env53802 := by
  intro p hp
  have h : env53802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53801_53802 : H12AffineEnvironment.transform 9 272 env53801 = env53802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53801 == env53802) = true)

theorem identity53802 : scanCanonicalize (H12AffineFastState.compose env53802 (packedSelected [3,5,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53802 : packedSelected [3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env53803 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,121,1,6160,2162,2064,2128,52,6161,6208,32,16,6163,121,64,2049,4096,2064,6208,2117,2080,36,4145,2128,513]

theorem envBound53803 : H12AffineFastState.Bounded env53803 := by
  intro p hp
  have h : env53803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53802_53803 : H12AffineEnvironment.transform 7 37 env53802 = env53803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53802 == env53803) = true)

theorem identity53803 : scanCanonicalize (H12AffineFastState.compose env53803 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound53803 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env53804 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,64,121,1,2128,2162,2064,2128,52,2129,2048,32,16,2131,121,64,2049,64,2064,2048,2117,2080,36,113,2128,513]

theorem envBound53804 : H12AffineFastState.Bounded env53804 := by
  intro p hp
  have h : env53804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53803_53804 : H12AffineEnvironment.transform 11 64 env53803 = env53804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env53803 == env53804) = true)

theorem identity53804 : scanCanonicalize (H12AffineFastState.compose env53804 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound53804 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env53805 : List Nat := [2,4,8,16,32,64,8,37,512,53,80,64,121,1,0,34,64,0,52,1,80,32,16,3,121,64,81,64,64,80,21,112,36,113,0,513]

theorem envBound53805 : H12AffineFastState.Bounded env53805 := by
  intro p hp
  have h : env53805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53804_53805 : H12AffineEnvironment.transform 10 80 env53804 = env53805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env53804 == env53805) = true)

theorem identity53805 : scanCanonicalize (H12AffineFastState.compose env53805 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound53805 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53806 : List Nat := [2,4,8,16,32,64,8,37,122,53,80,64,121,1,0,34,64,0,52,1,80,32,16,3,121,64,81,64,64,80,21,112,36,113,0,123]

theorem envBound53806 : H12AffineFastState.Bounded env53806 := by
  intro p hp
  have h : env53806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53805_53806 : H12AffineEnvironment.transform 8 122 env53805 = env53806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env53805 == env53806) = true)

theorem identity53806 : scanCanonicalize (H12AffineFastState.compose env53806 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound53806 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env53807 : List Nat := [2,4,8,16,26,64,8,31,64,15,80,64,67,1,0,24,64,0,14,1,80,26,16,3,67,64,81,64,64,80,21,74,30,75,0,65]

theorem envBound53807 : H12AffineFastState.Bounded env53807 := by
  intro p hp
  have h : env53807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53806_53807 : H12AffineEnvironment.transform 4 26 env53806 = env53807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env53806 == env53807) = true)

theorem identity53807 : scanCanonicalize (H12AffineFastState.compose env53807 (packedSelected [0,1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53807 : packedSelected [0,1,8] rootPS < 2^1333 := by decide +kernel

def env53808 : List Nat := [2,4,8,16,26,16,8,31,16,15,0,16,19,1,0,24,16,0,14,1,0,26,16,3,19,16,1,16,16,0,21,26,30,27,0,17]

theorem envBound53808 : H12AffineFastState.Bounded env53808 := by
  intro p hp
  have h : env53808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53807_53808 : H12AffineEnvironment.transform 5 16 env53807 = env53808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53807 == env53808) = true)

def env53809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272392,119879,95497,8193,64,2049,115015,45405,283904,75103,329730,257,21792,46093,513]

theorem envBound53809 : H12AffineFastState.Bounded env53809 := by
  intro p hp
  have h : env53809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53786_53809 : H12AffineEnvironment.transform 6 9 env53786 = env53809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53786 == env53809) = true)

theorem identity53809 : scanCanonicalize (H12AffineFastState.compose env53809 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53809 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env53810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82246,262144,1025,32769,69911,264532,119879,87125,349,64,2049,115015,36865,283904,66563,329730,257,21792,38225,513]

theorem envBound53810 : H12AffineFastState.Bounded env53810 := by
  intro p hp
  have h : env53810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53809_53810 : H12AffineEnvironment.transform 12 348 env53809 = env53810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53809 == env53810) = true)

theorem identity53810 : scanCanonicalize (H12AffineFastState.compose env53810 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound53810 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env53811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21840,65536,82246,262144,1025,21841,69911,264532,65815,87125,349,64,2049,70679,17745,283904,66563,329730,257,21792,16385,513]

theorem envBound53811 : H12AffineFastState.Bounded env53811 := by
  intro p hp
  have h : env53811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53810_53811 : H12AffineEnvironment.transform 14 21840 env53810 = env53811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env53810 == env53811) = true)

theorem identity53811 : scanCanonicalize (H12AffineFastState.compose env53811 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 23809) := by decide +kernel

theorem selectedBound53811 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21840,65536,82246,23809,1025,21841,69911,21589,65815,87125,349,64,2049,70679,17745,2049,66563,87299,257,21792,16385,513]

theorem envBound53812 : H12AffineFastState.Bounded env53812 := by
  intro p hp
  have h : env53812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53811_53812 : H12AffineEnvironment.transform 17 23809 env53811 = env53812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env53811 == env53812) = true)

theorem identity53812 : scanCanonicalize (H12AffineFastState.compose env53812 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53812 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env53813 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,65536,82198,23809,1025,21761,69911,21509,65815,87045,269,16,2049,70679,17665,2049,66563,87299,257,21792,16385,513]

theorem envBound53813 : H12AffineFastState.Bounded env53813 := by
  intro p hp
  have h : env53813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53812_53813 : H12AffineEnvironment.transform 5 16 env53812 = env53813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53812 == env53813) = true)

theorem identity53813 : scanCanonicalize (H12AffineFastState.compose env53813 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound53813 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env53814 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,4404,1076,65536,69666,3125,1025,1077,69911,1329,65815,66865,269,16,2049,70679,5173,2049,66563,66615,257,1044,4405,513]

theorem envBound53814 : H12AffineFastState.Bounded env53814 := by
  intro p hp
  have h : env53814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53813_53814 : H12AffineEnvironment.transform 13 4404 env53813 = env53814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env53813 == env53814) = true)

theorem identity53814 : scanCanonicalize (H12AffineFastState.compose env53814 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53814 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env53815 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4404,292,65536,69666,2341,273,293,69911,33,65815,65569,269,16,2049,69895,4389,2049,65811,65831,257,260,4405,513]

theorem envBound53815 : H12AffineFastState.Bounded env53815 := by
  intro p hp
  have h : env53815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53814_53815 : H12AffineEnvironment.transform 9 272 env53814 = env53815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53814 == env53815) = true)

theorem identity53815 : scanCanonicalize (H12AffineFastState.compose env53815 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound53815 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env53816 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4404,292,263,4389,2341,273,293,4112,33,16,294,269,16,2049,4096,4389,2049,20,32,257,260,4405,513]

theorem envBound53816 : H12AffineFastState.Bounded env53816 := by
  intro p hp
  have h : env53816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53815_53816 : H12AffineEnvironment.transform 15 263 env53815 = env53816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env53815 == env53816) = true)

theorem identity53816 : scanCanonicalize (H12AffineFastState.compose env53816 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53816 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53817 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4113,1,34,4096,2048,52,0,4112,33,16,3,40,16,2049,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound53817 : H12AffineFastState.Bounded env53817 := by
  intro p hp
  have h : env53817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53816_53817 : H12AffineEnvironment.transform 7 37 env53816 = env53817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53816 == env53817) = true)

theorem identity53817 : scanCanonicalize (H12AffineFastState.compose env53817 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound53817 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53818 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,0,41,17,1,34,0,2048,52,0,16,33,16,3,40,16,2049,0,0,2049,20,32,36,33,16,513]

theorem envBound53818 : H12AffineFastState.Bounded env53818 := by
  intro p hp
  have h : env53818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53817_53818 : H12AffineEnvironment.transform 11 0 env53817 = env53818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env53817 == env53818) = true)

theorem identity53818 : scanCanonicalize (H12AffineFastState.compose env53818 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound53818 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53819 : List Nat := [2,4,8,16,32,16,9,37,512,53,523,0,41,17,1,34,0,523,52,0,16,33,16,3,40,16,522,0,0,522,20,32,36,33,16,513]

theorem envBound53819 : H12AffineFastState.Bounded env53819 := by
  intro p hp
  have h : env53819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53818_53819 : H12AffineEnvironment.transform 10 523 env53818 = env53819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env53818 == env53819) = true)

def env53820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,169353,95496,8328,64,4464768,163977,45525,284040,156816,4350404,257,21792,46212,213831]

theorem envBound53820 : H12AffineFastState.Bounded env53820 := by
  intro p hp
  have h : env53820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53763_53820 : H12AffineEnvironment.transform 22 169353 env53763 = env53820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env53763 == env53820) = true)

def env53821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272512,169353,95496,8328,64,2048,163977,45525,284040,156816,411972,257,21792,46212,213831]

theorem envBound53821 : H12AffineFastState.Bounded env53821 := by
  intro p hp
  have h : env53821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53820_53821 : H12AffineEnvironment.transform 21 272512 env53820 = env53821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env53820 == env53821) = true)

theorem identity53821 : scanCanonicalize (H12AffineFastState.compose env53821 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound53821 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272512,169353,21762,8328,64,2048,163977,45525,284040,156816,411972,257,21792,46212,156493]

theorem envBound53822 : H12AffineFastState.Bounded env53822 := by
  intro p hp
  have h : env53822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53821_53822 : H12AffineEnvironment.transform 15 8202 env53821 = env53822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env53821 == env53822) = true)

def env53823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272392,169217,21762,8192,64,2048,163841,45405,283904,156696,411972,257,21792,46092,156493]

theorem envBound53823 : H12AffineFastState.Bounded env53823 := by
  intro p hp
  have h : env53823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53822_53823 : H12AffineEnvironment.transform 6 8 env53822 = env53823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53822 == env53823) = true)

theorem identity53823 : scanCanonicalize (H12AffineFastState.compose env53823 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 171109) := by decide +kernel

theorem selectedBound53823 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env53824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,171109,1025,32769,160013,177261,169217,21762,8192,64,2048,163841,45405,182629,156696,54561,257,21792,46092,156493]

theorem envBound53824 : H12AffineFastState.Bounded env53824 := by
  intro p hp
  have h : env53824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53823_53824 : H12AffineEnvironment.transform 17 171109 env53823 = env53824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171109 env53823 == env53824) = true)

theorem identity53824 : scanCanonicalize (H12AffineFastState.compose env53824 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound53824 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env53825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,23669,1025,32769,45341,29821,21777,21762,8192,64,2048,16401,45405,2421,41992,54561,257,21792,46092,41821]

theorem envBound53825 : H12AffineFastState.Bounded env53825 := by
  intro p hp
  have h : env53825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53824_53825 : H12AffineEnvironment.transform 16 49168 env53824 = env53825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env53824 == env53825) = true)

theorem identity53825 : scanCanonicalize (H12AffineFastState.compose env53825 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53825 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env53826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,24908,23669,1025,8541,4161,29821,21777,21762,8192,64,2048,16401,4097,2421,1364,29821,257,21792,5456,513]

theorem envBound53826 : H12AffineFastState.Bounded env53826 := by
  intro p hp
  have h : env53826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53825_53826 : H12AffineEnvironment.transform 14 8540 env53825 = env53826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53825 == env53826) = true)

def env53827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272393,169216,21762,8193,64,2048,163840,45404,283905,156697,411972,257,21792,46093,156493]

theorem envBound53827 : H12AffineFastState.Bounded env53827 := by
  intro p hp
  have h : env53827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53822_53827 : H12AffineEnvironment.transform 6 9 env53822 = env53827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53822 == env53827) = true)

theorem identity53827 : scanCanonicalize (H12AffineFastState.compose env53827 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 46393) := by decide +kernel

theorem selectedBound53827 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env53828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46393,262144,1025,32769,50228,272393,8249,21762,8193,64,2048,13625,45404,283905,53536,326781,257,21792,46093,54900]

theorem envBound53828 : H12AffineFastState.Bounded env53828 := by
  intro p hp
  have h : env53828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53827_53828 : H12AffineEnvironment.transform 16 46393 env53827 = env53828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46393 env53827 == env53828) = true)

theorem identity53828 : scanCanonicalize (H12AffineFastState.compose env53828 (packedSelected [0,3,4,10,14,20,22,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound53828 : packedSelected [0,3,4,10,14,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46393,32041,1025,32769,50228,21792,8249,21762,8193,64,2048,13625,45404,10280,53536,33108,257,21792,46093,54900]

theorem envBound53829 : H12AffineFastState.Bounded env53829 := by
  intro p hp
  have h : env53829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53828_53829 : H12AffineEnvironment.transform 17 32041 env53828 = env53829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env53828 == env53829) = true)

theorem identity53829 : scanCanonicalize (H12AffineFastState.compose env53829 (packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53829 : packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env53830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,46393,10281,1025,32769,37172,32,8249,2,8193,64,2048,13625,45404,10280,33824,33108,257,32,46093,33652]

theorem envBound53830 : H12AffineFastState.Bounded env53830 := by
  intro p hp
  have h : env53830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53829_53830 : H12AffineEnvironment.transform 13 5376 env53829 = env53830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53829 == env53830) = true)

theorem identity53830 : scanCanonicalize (H12AffineFastState.compose env53830 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9529) := by decide +kernel

theorem selectedBound53830 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9529,8202,4096,10281,1025,9528,13325,32,8249,2,8193,64,2048,13625,5221,10280,8473,9325,257,32,4404,9805]

theorem envBound53831 : H12AffineFastState.Bounded env53831 := by
  intro p hp
  have h : env53831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53830_53831 : H12AffineEnvironment.transform 14 9529 env53830 = env53831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9529 env53830 == env53831) = true)

theorem identity53831 : scanCanonicalize (H12AffineFastState.compose env53831 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound53831 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env53832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5376,1,1330,4096,3345,1025,0,4405,32,1281,2,1337,64,2048,4097,5221,3344,1057,341,257,32,4404,885]

theorem envBound53832 : H12AffineFastState.Bounded env53832 := by
  intro p hp
  have h : env53832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53831_53832 : H12AffineEnvironment.transform 12 1336 env53831 = env53832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env53831 == env53832) = true)

theorem identity53832 : scanCanonicalize (H12AffineFastState.compose env53832 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound53832 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env53833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,1336,2420,1,1330,3188,3345,1025,0,3393,32,1281,2,1337,64,2048,3189,2065,3344,1057,341,257,32,3392,885]

theorem envBound53833 : H12AffineFastState.Bounded env53833 := by
  intro p hp
  have h : env53833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53832_53833 : H12AffineEnvironment.transform 11 3188 env53832 = env53833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env53832 == env53833) = true)

theorem identity53833 : scanCanonicalize (H12AffineFastState.compose env53833 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound53833 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env53834 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2065,349,2420,1,343,2065,2420,100,0,2340,32,356,2,348,64,2048,2064,2065,2421,68,341,257,32,2341,885]

theorem envBound53834 : H12AffineFastState.Bounded env53834 := by
  intro p hp
  have h : env53834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53833_53834 : H12AffineEnvironment.transform 9 101 env53833 = env53834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env53833 == env53834) = true)

theorem identity53834 : scanCanonicalize (H12AffineFastState.compose env53834 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 11) := by decide +kernel

theorem selectedBound53834 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env53835 : List Nat := [2,4,8,16,32,64,9,11,512,101,2048,2065,86,2175,1,92,2065,2175,100,0,2095,32,111,2,87,64,2048,2064,2065,2174,68,94,10,32,2094,638]

theorem envBound53835 : H12AffineFastState.Bounded env53835 := by
  intro p hp
  have h : env53835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53834_53835 : H12AffineEnvironment.transform 7 11 env53834 = env53835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 11 env53834 == env53835) = true)

theorem identity53835 : scanCanonicalize (H12AffineFastState.compose env53835 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 82) := by decide +kernel

theorem selectedBound53835 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env53836 : List Nat := [2,4,8,16,32,64,9,11,82,101,2048,2065,86,2175,1,92,2065,2175,100,0,2095,32,111,2,87,64,2048,2064,2065,2174,68,94,10,32,2094,44]

theorem envBound53836 : H12AffineFastState.Bounded env53836 := by
  intro p hp
  have h : env53836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53835_53836 : H12AffineEnvironment.transform 8 82 env53835 = env53836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 82 env53835 == env53836) = true)

def env53837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272513,169353,95496,8328,64,2049,163977,45525,284040,156816,411973,257,21792,46212,213831]

theorem envBound53837 : H12AffineFastState.Bounded env53837 := by
  intro p hp
  have h : env53837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53820_53837 : H12AffineEnvironment.transform 21 272513 env53820 = env53837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env53820 == env53837) = true)

theorem identity53837 : scanCanonicalize (H12AffineFastState.compose env53837 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112018) := by decide +kernel

theorem selectedBound53837 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,115871,272513,73755,95496,8328,64,2049,79131,45525,284040,119042,392407,257,21792,46212,63189]

theorem envBound53838 : H12AffineFastState.Bounded env53838 := by
  intro p hp
  have h : env53838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53837_53838 : H12AffineEnvironment.transform 16 112018 env53837 = env53838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112018 env53837 == env53838) = true)

def env53839 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,115871,272513,73755,95496,8328,16,2049,79131,45445,284040,119042,392327,257,21792,46212,63109]

theorem envBound53839 : H12AffineFastState.Bounded env53839 := by
  intro p hp
  have h : env53839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53838_53839 : H12AffineEnvironment.transform 5 16 env53838 = env53839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53838 == env53839) = true)

theorem identity53839 : scanCanonicalize (H12AffineFastState.compose env53839 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound53839 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env53840 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,76078,1025,32769,115871,65967,73755,95496,8328,16,2049,79131,45445,97446,119042,54697,257,21792,46212,63109]

theorem envBound53840 : H12AffineFastState.Bounded env53840 := by
  intro p hp
  have h : env53840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53839_53840 : H12AffineEnvironment.transform 17 76078 env53839 = env53840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env53839 == env53840) = true)

theorem identity53840 : scanCanonicalize (H12AffineFastState.compose env53840 (packedSelected [3,5,8,10,16,17,19,20,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound53840 : packedSelected [3,5,8,10,16,17,19,20,26,28,31] rootPS < 2^1333 := by decide +kernel

def env53841 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,399,46109,10401,1025,32769,50448,32,8596,29831,8328,16,2049,13460,45445,32041,53389,54697,257,21792,46212,63109]

theorem envBound53841 : H12AffineFastState.Bounded env53841 := by
  intro p hp
  have h : env53841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53840_53841 : H12AffineEnvironment.transform 15 399 env53840 = env53841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env53840 == env53841) = true)

theorem identity53841 : scanCanonicalize (H12AffineFastState.compose env53841 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound53841 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env53842 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,137,399,13460,10401,1025,136,17817,32,8596,29831,8328,16,2049,13460,12556,32041,20484,21792,257,21792,13325,30220]

theorem envBound53842 : H12AffineFastState.Bounded env53842 := by
  intro p hp
  have h : env53842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53841_53842 : H12AffineEnvironment.transform 14 137 env53841 = env53842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env53841 == env53842) = true)

theorem identity53842 : scanCanonicalize (H12AffineFastState.compose env53842 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound53842 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env53843 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,137,399,5392,2341,1025,136,17817,32,16,21763,268,16,2049,5392,4232,23725,20484,21792,257,21792,5513,22408]

theorem envBound53843 : H12AffineFastState.Bounded env53843 := by
  intro p hp
  have h : env53843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53842_53843 : H12AffineEnvironment.transform 12 388 env53842 = env53843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env53842 == env53843) = true)

theorem identity53843 : scanCanonicalize (H12AffineFastState.compose env53843 (packedSelected [6,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound53843 : packedSelected [6,11,12,14] rootPS < 2^1333 := by decide +kernel

def env53844 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,2340,137,399,5392,2341,1025,136,3261,32,16,7207,268,16,2049,5392,4232,5513,6432,7172,257,7172,5513,7852]

theorem envBound53844 : H12AffineFastState.Bounded env53844 := by
  intro p hp
  have h : env53844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53843_53844 : H12AffineEnvironment.transform 13 2340 env53843 = env53844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env53843 == env53844) = true)

theorem identity53844 : scanCanonicalize (H12AffineFastState.compose env53844 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound53844 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53845 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3465,388,2340,137,399,2201,2341,1025,136,3261,32,16,430,268,16,2049,2201,3329,2048,1193,397,257,397,2048,805]

theorem envBound53845 : H12AffineFastState.Bounded env53845 := by
  intro p hp
  have h : env53845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53844_53845 : H12AffineEnvironment.transform 11 3465 env53844 = env53845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env53844 == env53845) = true)

theorem identity53845 : scanCanonicalize (H12AffineFastState.compose env53845 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53845 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53846 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3328,269,2340,0,262,2064,2341,1025,1,3124,32,16,295,268,16,2049,2064,3329,2048,1056,260,257,260,2048,805]

theorem envBound53846 : H12AffineFastState.Bounded env53846 := by
  intro p hp
  have h : env53846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53845_53846 : H12AffineEnvironment.transform 6 9 env53845 = env53846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53845 == env53846) = true)

theorem identity53846 : scanCanonicalize (H12AffineFastState.compose env53846 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound53846 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53847 : List Nat := [2,4,8,16,32,16,9,256,512,1024,303,1071,269,11,0,262,319,10,1025,1,1307,32,16,295,268,16,302,319,1070,303,1056,260,257,260,303,805]

theorem envBound53847 : H12AffineFastState.Bounded env53847 := by
  intro p hp
  have h : env53847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53846_53847 : H12AffineEnvironment.transform 10 303 env53846 = env53847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env53846 == env53847) = true)

theorem identity53847 : scanCanonicalize (H12AffineFastState.compose env53847 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound53847 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env53848 : List Nat := [2,4,8,16,27,16,9,256,512,1024,276,1044,269,11,0,262,260,10,1025,1,1307,27,16,284,268,16,277,260,1045,276,1051,260,257,260,276,798]

theorem envBound53848 : H12AffineFastState.Bounded env53848 := by
  intro p hp
  have h : env53848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53847_53848 : H12AffineEnvironment.transform 4 27 env53847 = env53848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env53847 == env53848) = true)

theorem identity53848 : scanCanonicalize (H12AffineFastState.compose env53848 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound53848 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env53849 : List Nat := [2,4,8,16,27,16,9,256,512,267,276,287,269,11,0,262,260,10,266,1,16,27,16,284,268,16,277,260,286,276,272,260,257,260,276,798]

theorem envBound53849 : H12AffineFastState.Bounded env53849 := by
  intro p hp
  have h : env53849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53848_53849 : H12AffineEnvironment.transform 9 267 env53848 = env53849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env53848 == env53849) = true)

def env53850 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,115871,272513,73755,95496,8328,17,2049,79131,45444,284040,119042,392326,257,21792,46212,63108]

theorem envBound53850 : H12AffineFastState.Bounded env53850 := by
  intro p hp
  have h : env53850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53838_53850 : H12AffineEnvironment.transform 5 17 env53838 = env53850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53838 == env53850) = true)

theorem identity53850 : scanCanonicalize (H12AffineFastState.compose env53850 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound53850 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env53851 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,64808,1025,32769,115871,54697,73755,95496,8328,17,2049,79131,45444,43168,119042,65966,257,21792,46212,63108]

theorem envBound53851 : H12AffineFastState.Bounded env53851 := by
  intro p hp
  have h : env53851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53850_53851 : H12AffineEnvironment.transform 17 64808 env53850 = env53851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env53850 == env53851) = true)

theorem identity53851 : scanCanonicalize (H12AffineFastState.compose env53851 (packedSelected [0,1,3,4,5,7,8,17,18,22,23,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53851 : packedSelected [0,1,3,4,5,7,8,17,18,22,23,26,31] rootPS < 2^1333 := by decide +kernel

def env53852 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,65536,112018,43048,1025,32769,102815,32937,73755,73736,8328,17,2049,79131,45444,43168,99330,65966,257,32,46212,41860]

theorem envBound53852 : H12AffineFastState.Bounded env53852 := by
  intro p hp
  have h : env53852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53851_53852 : H12AffineEnvironment.transform 13 5376 env53851 = env53852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53851 == env53852) = true)

theorem identity53852 : scanCanonicalize (H12AffineFastState.compose env53852 (packedSelected [3,10,17,18,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53852 : packedSelected [3,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env53853 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,8203,38297,43048,1025,32769,45460,32937,16,3,8328,17,2049,5392,45444,43168,41993,8613,257,32,46212,41860]

theorem envBound53853 : H12AffineFastState.Bounded env53853 := by
  intro p hp
  have h : env53853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53852_53853 : H12AffineEnvironment.transform 15 8203 env53852 = env53853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53852 == env53853) = true)

theorem identity53853 : scanCanonicalize (H12AffineFastState.compose env53853 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound53853 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53854 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,32768,399,38297,35244,1025,32769,36880,32937,16,3,268,17,2049,5392,36864,35108,34189,33,257,32,38144,33280]

theorem envBound53854 : H12AffineFastState.Bounded env53854 := by
  intro p hp
  have h : env53854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53853_53854 : H12AffineEnvironment.transform 12 388 env53853 = env53854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env53853 == env53854) = true)

theorem identity53854 : scanCanonicalize (H12AffineFastState.compose env53854 (packedSelected [0,1,2,4,8,11,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53854 : packedSelected [0,1,2,4,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env53855 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,388,4113,32768,399,37000,35244,272,32769,36880,32937,16,3,268,17,2049,4097,36864,35108,32924,33,257,32,36881,33280]

theorem envBound53855 : H12AffineFastState.Bounded env53855 := by
  intro p hp
  have h : env53855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53854_53855 : H12AffineEnvironment.transform 9 273 env53854 = env53855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53854 == env53855) = true)

theorem identity53855 : scanCanonicalize (H12AffineFastState.compose env53855 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53855 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53856 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,32768,262,36865,35109,272,32769,36880,32800,16,3,268,17,2049,4097,36864,35108,32789,33,257,32,36881,33280]

theorem envBound53856 : H12AffineFastState.Bounded env53856 := by
  intro p hp
  have h : env53856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53855_53856 : H12AffineEnvironment.transform 6 9 env53855 = env53856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53855 == env53856) = true)

theorem identity53856 : scanCanonicalize (H12AffineFastState.compose env53856 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53856 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53857 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,32768,35,36865,34816,53,32769,36880,32800,16,3,41,17,2049,4097,36864,34817,32789,33,36,32,36881,33280]

theorem envBound53857 : H12AffineFastState.Bounded env53857 := by
  intro p hp
  have h : env53857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53856_53857 : H12AffineEnvironment.transform 7 37 env53856 = env53857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53856 == env53857) = true)

theorem identity53857 : scanCanonicalize (H12AffineFastState.compose env53857 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53857 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53858 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,1,35,4096,2049,53,0,4113,33,16,3,41,17,2049,4097,4097,2048,20,33,36,32,4112,513]

theorem envBound53858 : H12AffineFastState.Bounded env53858 := by
  intro p hp
  have h : env53858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53857_53858 : H12AffineEnvironment.transform 14 1 env53857 = env53858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53857 == env53858) = true)

theorem identity53858 : scanCanonicalize (H12AffineFastState.compose env53858 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound53858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53859 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2576,40,2561,1,35,2576,2049,53,0,2561,33,16,3,41,17,2049,2577,2577,2048,20,33,36,32,2560,513]

theorem envBound53859 : H12AffineFastState.Bounded env53859 := by
  intro p hp
  have h : env53859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53858_53859 : H12AffineEnvironment.transform 11 2576 env53858 = env53859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env53858 == env53859) = true)

theorem identity53859 : scanCanonicalize (H12AffineFastState.compose env53859 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound53859 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53860 : List Nat := [2,4,8,16,32,17,9,37,512,52,554,58,40,43,1,35,58,555,53,0,43,33,16,3,41,17,555,59,59,554,20,33,36,32,42,513]

theorem envBound53860 : H12AffineFastState.Bounded env53860 := by
  intro p hp
  have h : env53860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53859_53860 : H12AffineEnvironment.transform 10 554 env53859 = env53860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env53859 == env53860) = true)

def env53861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356289,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound53861 : H12AffineFastState.Bounded env53861 := by
  intro p hp
  have h : env53861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53271_53861 : H12AffineEnvironment.transform 26 30393345 env53271 = env53861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env53271 == env53861) = true)

def env53862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound53862 : H12AffineFastState.Bounded env53862 := by
  intro p hp
  have h : env53862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53861_53862 : H12AffineEnvironment.transform 18 1024 env53861 = env53862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env53861 == env53862) = true)

theorem identity53862 : scanCanonicalize (H12AffineFastState.compose env53862 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2188736) := by decide +kernel

theorem selectedBound53862 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env53863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2188736,8328,64,15115713,57677,10507601,8830977,10543569,4194304,256,8429932,8405192,10601991]

theorem envBound53863 : H12AffineFastState.Bounded env53863 := by
  intro p hp
  have h : env53863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53862_53863 : H12AffineEnvironment.transform 23 2188736 env53862 = env53863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188736 env53862 == env53863) = true)

def env53864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,62540,2188736,8328,64,6705549,57677,2138397,406605,2102685,4194304,256,21792,46212,2175563]

theorem envBound53864 : H12AffineFastState.Bounded env53864 := by
  intro p hp
  have h : env53864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53863_53864 : H12AffineEnvironment.transform 22 62540 env53863 = env53864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62540 env53863 == env53864) = true)

def env53865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2101344,62540,2188736,8328,64,410093,57677,2138397,406605,2102685,2101344,256,21792,46212,2175563]

theorem envBound53865 : H12AffineFastState.Bounded env53865 := by
  intro p hp
  have h : env53865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53864_53865 : H12AffineEnvironment.transform 21 2101344 env53864 = env53865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101344 env53864 == env53865) = true)

def env53866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62540,73856,8328,64,410093,57677,58461,406605,20701,21792,256,21792,46212,96011]

theorem envBound53866 : H12AffineFastState.Bounded env53866 := by
  intro p hp
  have h : env53866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53865_53866 : H12AffineEnvironment.transform 20 17728 env53865 = env53866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env53865 == env53866) = true)

theorem identity53866 : scanCanonicalize (H12AffineFastState.compose env53866 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53866 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,62540,73736,8192,64,409957,57677,58461,406605,20565,21792,256,21792,46092,96011]

theorem envBound53867 : H12AffineFastState.Bounded env53867 := by
  intro p hp
  have h : env53867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53866_53867 : H12AffineEnvironment.transform 6 8 env53866 = env53867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53866 == env53867) = true)

def env53868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,17728,21792,62540,73736,8192,64,158029,57677,58461,138341,20565,21792,256,21792,46092,96011]

theorem envBound53868 : H12AffineFastState.Bounded env53868 := by
  intro p hp
  have h : env53868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53867_53868 : H12AffineEnvironment.transform 17 10280 env53867 = env53868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env53867 == env53868) = true)

theorem identity53868 : scanCanonicalize (H12AffineFastState.compose env53868 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound53868 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env53869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10280,1024,32769,17728,21792,62540,21762,8192,64,158029,57677,58461,138341,20565,21792,256,21792,46092,513]

theorem envBound53869 : H12AffineFastState.Bounded env53869 := by
  intro p hp
  have h : env53869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53868_53869 : H12AffineEnvironment.transform 15 29962 env53868 = env53869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env53868 == env53869) = true)

theorem identity53869 : scanCanonicalize (H12AffineFastState.compose env53869 (packedSelected [1,8,10,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound53869 : packedSelected [1,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env53870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,13340,10280,1024,32769,17728,21792,62540,21762,8192,64,23889,57677,58461,10361,20565,21792,256,21792,46092,513]

theorem envBound53870 : H12AffineFastState.Bounded env53870 := by
  intro p hp
  have h : env53870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53869_53870 : H12AffineEnvironment.transform 16 13340 env53869 = env53870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env53869 == env53870) = true)

theorem identity53870 : scanCanonicalize (H12AffineFastState.compose env53870 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound53870 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env53871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21540,29962,13340,10280,1024,21541,17728,21792,8296,21762,8192,64,23889,13673,12409,10361,20565,21792,256,21792,24616,513]

theorem envBound53871 : H12AffineFastState.Bounded env53871 := by
  intro p hp
  have h : env53871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53870_53871 : H12AffineEnvironment.transform 14 21540 env53870 = env53871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env53870 == env53871) = true)

theorem identity53871 : scanCanonicalize (H12AffineFastState.compose env53871 (packedSelected [0,1,4,7,8,9,10,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 11577) := by decide +kernel

theorem selectedBound53871 : packedSelected [0,1,4,7,8,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env53872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,11577,14621,6195,13340,10280,1024,14620,10361,14361,8296,14395,8192,64,12392,13673,12409,10361,15724,14361,256,14361,3345,513]

theorem envBound53872 : H12AffineFastState.Bounded env53872 := by
  intro p hp
  have h : env53872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53871_53872 : H12AffineEnvironment.transform 13 11577 env53871 = env53872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11577 env53871 == env53872) = true)

theorem identity53872 : scanCanonicalize (H12AffineFastState.compose env53872 (packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53872 : packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env53873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,3173,6209,6195,5440,2420,1024,6208,2341,6469,308,6503,348,64,4404,5173,4389,2341,7216,6469,256,6469,3345,513]

theorem envBound53873 : H12AffineFastState.Bounded env53873 := by
  intro p hp
  have h : env53873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53872_53873 : H12AffineEnvironment.transform 12 348 env53872 = env53873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53872 == env53873) = true)

theorem identity53873 : scanCanonicalize (H12AffineFastState.compose env53873 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53873 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53874 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,3124,6160,6195,5393,2341,1024,6161,2341,6420,308,6454,269,17,4404,5173,4389,2341,7216,6420,256,6420,3345,513]

theorem envBound53874 : H12AffineFastState.Bounded env53874 := by
  intro p hp
  have h : env53874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53873_53874 : H12AffineEnvironment.transform 5 17 env53873 = env53874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53873 == env53874) = true)

theorem identity53874 : scanCanonicalize (H12AffineFastState.compose env53874 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53874 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53875 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,3124,6160,6195,5172,2048,1024,6161,2048,6193,17,6163,40,17,4113,5173,4096,2048,7216,6193,37,6193,3124,513]

theorem envBound53875 : H12AffineFastState.Bounded env53875 := by
  intro p hp
  have h : env53875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53874_53875 : H12AffineEnvironment.transform 7 37 env53874 = env53875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53874 == env53875) = true)

theorem identity53875 : scanCanonicalize (H12AffineFastState.compose env53875 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound53875 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53876 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,3124,2080,2051,1028,2048,1024,2081,2048,2049,17,2083,40,17,33,1029,48,2048,3072,2049,37,2049,3124,513]

theorem envBound53876 : H12AffineFastState.Bounded env53876 := by
  intro p hp
  have h : env53876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53875_53876 : H12AffineEnvironment.transform 11 48 env53875 = env53876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env53875 == env53876) = true)

theorem identity53876 : scanCanonicalize (H12AffineFastState.compose env53876 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 26) := by decide +kernel

theorem selectedBound53876 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env53877 : List Nat := [2,4,8,16,32,17,8,37,512,26,2048,48,40,2094,2080,2051,30,2048,26,2081,2048,2049,17,2083,40,17,33,31,48,2048,2074,2049,37,2049,2094,513]

theorem envBound53877 : H12AffineFastState.Bounded env53877 := by
  intro p hp
  have h : env53877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53876_53877 : H12AffineEnvironment.transform 9 26 env53876 = env53877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 26 env53876 == env53877) = true)

theorem identity53877 : scanCanonicalize (H12AffineFastState.compose env53877 (packedSelected [0,1,5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound53877 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env53878 : List Nat := [2,4,6,16,32,17,6,37,512,20,2048,48,38,2080,2080,2051,16,2048,20,2081,2048,2049,17,2083,38,17,33,17,48,2048,2068,2049,37,2049,2080,513]

theorem envBound53878 : H12AffineFastState.Bounded env53878 := by
  intro p hp
  have h : env53878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53877_53878 : H12AffineEnvironment.transform 2 6 env53877 = env53878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env53877 == env53878) = true)

theorem identity53878 : scanCanonicalize (H12AffineFastState.compose env53878 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound53878 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53879 : List Nat := [2,4,6,16,32,17,6,37,512,20,33,48,38,1,1,34,16,33,20,0,33,32,17,2,38,17,33,17,48,33,53,32,37,32,1,513]

theorem envBound53879 : H12AffineFastState.Bounded env53879 := by
  intro p hp
  have h : env53879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53878_53879 : H12AffineEnvironment.transform 10 33 env53878 = env53879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env53878 == env53879) = true)

theorem identity53879 : scanCanonicalize (H12AffineFastState.compose env53879 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53879 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53880 : List Nat := [2,1,3,16,32,17,3,32,512,17,33,48,35,1,1,34,16,33,17,0,33,32,17,2,35,17,33,17,48,33,48,32,32,32,1,513]

theorem envBound53880 : H12AffineFastState.Bounded env53880 := by
  intro p hp
  have h : env53880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53879_53880 : H12AffineEnvironment.transform 1 1 env53879 = env53880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53879 == env53880) = true)

theorem identity53880 : scanCanonicalize (H12AffineFastState.compose env53880 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53880 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53881 : List Nat := [2,1,3,0,32,1,3,32,512,1,33,32,35,1,1,34,0,33,1,0,33,32,1,2,35,1,33,1,32,33,32,32,32,32,1,513]

theorem envBound53881 : H12AffineFastState.Bounded env53881 := by
  intro p hp
  have h : env53881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53880_53881 : H12AffineEnvironment.transform 3 0 env53880 = env53881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53880 == env53881) = true)

theorem identity53881 : scanCanonicalize (H12AffineFastState.compose env53881 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53881 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env53882 : List Nat := [2,1,3,0,0,1,3,0,512,1,1,0,3,1,1,2,0,1,1,0,1,0,1,2,3,1,1,1,0,1,0,0,0,0,1,513]

theorem envBound53882 : H12AffineFastState.Bounded env53882 := by
  intro p hp
  have h : env53882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53881_53882 : H12AffineEnvironment.transform 4 0 env53881 = env53882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53881 == env53882) = true)

theorem identity53882 : scanCanonicalize (H12AffineFastState.compose env53882 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound53882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53883 : List Nat := [2,1,3,0,0,1,3,0,3,1,1,0,3,1,1,2,0,1,1,0,1,0,1,2,3,1,1,1,0,1,0,0,0,0,1,2]

theorem envBound53883 : H12AffineFastState.Bounded env53883 := by
  intro p hp
  have h : env53883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53882_53883 : H12AffineEnvironment.transform 8 3 env53882 = env53883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env53882 == env53883) = true)

def env53884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,17728,21792,62540,73736,8192,64,158028,57677,58461,138340,20565,21792,256,21792,46092,96011]

theorem envBound53884 : H12AffineFastState.Bounded env53884 := by
  intro p hp
  have h : env53884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53867_53884 : H12AffineEnvironment.transform 17 10281 env53867 = env53884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env53867 == env53884) = true)

theorem identity53884 : scanCanonicalize (H12AffineFastState.compose env53884 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound53884 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1024,29789,17728,21792,16,73736,8192,64,158028,5393,4097,138340,20565,21792,256,21792,16464,96011]

theorem envBound53885 : H12AffineFastState.Bounded env53885 := by
  intro p hp
  have h : env53885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53884_53885 : H12AffineEnvironment.transform 14 29788 env53884 = env53885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env53884 == env53885) = true)

theorem identity53885 : scanCanonicalize (H12AffineFastState.compose env53885 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound53885 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,5392,10281,1024,29789,17728,21792,16,73736,8192,64,31836,5393,4097,2420,20565,21792,256,21792,16464,96011]

theorem envBound53886 : H12AffineFastState.Bounded env53886 := by
  intro p hp
  have h : env53886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53885_53886 : H12AffineEnvironment.transform 16 5392 env53885 = env53886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env53885 == env53886) = true)

theorem identity53886 : scanCanonicalize (H12AffineFastState.compose env53886 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13437) := by decide +kernel

theorem selectedBound53886 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13437,33,65536,5392,10281,1024,32,12605,8541,16,73736,8192,64,2081,5393,4097,2420,9256,8541,256,8541,13357,66422]

theorem envBound53887 : H12AffineFastState.Bounded env53887 := by
  intro p hp
  have h : env53887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53886_53887 : H12AffineEnvironment.transform 13 13437 env53886 = env53887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13437 env53886 == env53887) = true)

theorem identity53887 : scanCanonicalize (H12AffineFastState.compose env53887 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53887 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53888 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12653,33,65536,4096,10281,272,32,12605,8541,16,73736,8192,64,2081,4097,4097,2420,8504,8541,256,8541,12605,66422]

theorem envBound53888 : H12AffineFastState.Bounded env53888 := by
  intro p hp
  have h : env53888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53887_53888 : H12AffineEnvironment.transform 9 272 env53887 = env53888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53887 == env53888) = true)

theorem identity53888 : scanCanonicalize (H12AffineFastState.compose env53888 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound53888 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env53889 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12653,33,375,4096,10281,272,32,12605,8541,16,8575,8192,64,2081,4097,4097,2420,8504,8541,256,8541,12605,513]

theorem envBound53889 : H12AffineFastState.Bounded env53889 := by
  intro p hp
  have h : env53889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53888_53889 : H12AffineEnvironment.transform 15 375 env53888 = env53889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env53888 == env53889) = true)

theorem identity53889 : scanCanonicalize (H12AffineFastState.compose env53889 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound53889 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env53890 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,4096,8192,12653,33,375,4096,8312,272,32,12605,8541,16,8575,8192,64,112,4097,4097,293,8504,8541,256,8541,12605,513]

theorem envBound53890 : H12AffineFastState.Bounded env53890 := by
  intro p hp
  have h : env53890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53889_53890 : H12AffineEnvironment.transform 10 81 env53889 = env53890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env53889 == env53890) = true)

theorem identity53890 : scanCanonicalize (H12AffineFastState.compose env53890 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4429) := by decide +kernel

theorem selectedBound53890 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env53891 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,4096,4429,32,33,375,4096,4405,272,32,112,4112,16,4146,4429,64,112,4097,4097,293,4213,4112,256,4112,112,513]

theorem envBound53891 : H12AffineFastState.Bounded env53891 := by
  intro p hp
  have h : env53891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53890_53891 : H12AffineEnvironment.transform 12 4429 env53890 = env53891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4429 env53890 == env53891) = true)

theorem identity53891 : scanCanonicalize (H12AffineFastState.compose env53891 (packedSelected [1,2,3,5,8,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound53891 : packedSelected [1,2,3,5,8,14,15] rootPS < 2^1333 := by decide +kernel

def env53892 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,49,380,32,33,375,49,260,272,32,112,33,16,3,380,64,112,48,48,293,68,33,256,33,112,513]

theorem envBound53892 : H12AffineFastState.Bounded env53892 := by
  intro p hp
  have h : env53892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53891_53892 : H12AffineEnvironment.transform 11 49 env53891 = env53892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env53891 == env53892) = true)

theorem identity53892 : scanCanonicalize (H12AffineFastState.compose env53892 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53892 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53893 : List Nat := [2,4,8,16,32,64,8,4,512,20,81,49,120,32,33,115,49,0,20,32,112,33,16,3,120,64,112,48,48,33,68,33,4,33,112,513]

theorem envBound53893 : H12AffineFastState.Bounded env53893 := by
  intro p hp
  have h : env53893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53892_53893 : H12AffineEnvironment.transform 7 4 env53892 = env53893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53892 == env53893) = true)

theorem identity53893 : scanCanonicalize (H12AffineFastState.compose env53893 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound53893 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53894 : List Nat := [2,4,8,16,32,64,8,4,80,20,81,49,120,32,33,115,49,0,20,32,112,33,16,3,120,64,112,48,48,33,68,33,4,33,112,81]

theorem envBound53894 : H12AffineFastState.Bounded env53894 := by
  intro p hp
  have h : env53894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53893_53894 : H12AffineEnvironment.transform 8 80 env53893 = env53894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env53893 == env53894) = true)

theorem identity53894 : scanCanonicalize (H12AffineFastState.compose env53894 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound53894 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53895 : List Nat := [2,4,8,16,32,33,8,4,49,20,48,49,25,32,33,18,49,0,20,32,17,33,16,3,25,33,17,48,48,33,37,33,4,33,17,48]

theorem envBound53895 : H12AffineFastState.Bounded env53895 := by
  intro p hp
  have h : env53895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53894_53895 : H12AffineEnvironment.transform 5 33 env53894 = env53895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env53894 == env53895) = true)

theorem identity53895 : scanCanonicalize (H12AffineFastState.compose env53895 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound53895 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53896 : List Nat := [2,4,8,16,16,17,8,4,1,20,0,1,25,16,17,18,1,0,20,16,17,17,16,3,25,17,17,0,0,17,21,17,4,17,17,0]

theorem envBound53896 : H12AffineFastState.Bounded env53896 := by
  intro p hp
  have h : env53896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53895_53896 : H12AffineEnvironment.transform 4 16 env53895 = env53896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env53895 == env53896) = true)

def env53897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,62540,73857,8328,64,410093,57677,58460,406605,20700,21793,256,21792,46212,96010]

theorem envBound53897 : H12AffineFastState.Bounded env53897 := by
  intro p hp
  have h : env53897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53865_53897 : H12AffineEnvironment.transform 20 17729 env53865 = env53897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env53865 == env53897) = true)

theorem identity53897 : scanCanonicalize (H12AffineFastState.compose env53897 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89515) := by decide +kernel

theorem selectedBound53897 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env53898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89515,1024,32769,17729,21793,62540,73857,8328,64,203846,57677,58460,223718,20700,21793,256,21792,46212,96010]

theorem envBound53898 : H12AffineFastState.Bounded env53898 := by
  intro p hp
  have h : env53898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53897_53898 : H12AffineEnvironment.transform 17 89515 env53897 = env53898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89515 env53897 == env53898) = true)

def env53899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,89515,1024,29789,17729,21793,16,73857,8328,64,203846,5393,4096,223718,20700,21793,256,21792,16600,96010]

theorem envBound53899 : H12AffineFastState.Bounded env53899 := by
  intro p hp
  have h : env53899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53898_53899 : H12AffineEnvironment.transform 14 29788 env53898 = env53899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env53898 == env53899) = true)

theorem identity53899 : scanCanonicalize (H12AffineFastState.compose env53899 (packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound53899 : packedSelected [0,2,7,9,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env53900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,216,65536,131072,76079,1024,217,12741,8613,16,73857,8328,64,203846,5393,4096,204130,9304,8613,256,8612,13404,66446]

theorem envBound53900 : H12AffineFastState.Bounded env53900 := by
  intro p hp
  have h : env53900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53899_53900 : H12AffineEnvironment.transform 13 13444 env53899 = env53900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env53899 == env53900) = true)

def env53901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,65536,131072,76079,1024,81,12621,8493,16,73737,8192,64,203846,5393,4096,204130,9304,8493,256,8492,13404,66310]

theorem envBound53901 : H12AffineFastState.Bounded env53901 := by
  intro p hp
  have h : env53901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53900_53901 : H12AffineEnvironment.transform 6 8 env53900 = env53901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53900 == env53901) = true)

theorem identity53901 : scanCanonicalize (H12AffineFastState.compose env53901 (packedSelected [1,4,6,8,9,10,12,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound53901 : packedSelected [1,4,6,8,9,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env53902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,65536,79130,76079,1024,81,12621,8493,16,73737,8192,64,10588,5393,4096,10360,9304,8493,256,8492,13404,66310]

theorem envBound53902 : H12AffineFastState.Bounded env53902 := by
  intro p hp
  have h : env53902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53901_53902 : H12AffineEnvironment.transform 16 79130 env53901 = env53902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env53901 == env53902) = true)

theorem identity53902 : scanCanonicalize (H12AffineFastState.compose env53902 (packedSelected [2,3,4,5,6,10,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53902 : packedSelected [2,3,4,5,6,10,20,22] rootPS < 2^1333 := by decide +kernel

def env53903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,8203,5393,2340,1024,81,12621,8493,16,2,8192,64,10588,5393,4096,10360,9304,8493,256,8492,13404,8973]

theorem envBound53903 : H12AffineFastState.Bounded env53903 := by
  intro p hp
  have h : env53903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53902_53903 : H12AffineEnvironment.transform 15 8203 env53902 = env53903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53902 == env53903) = true)

theorem identity53903 : scanCanonicalize (H12AffineFastState.compose env53903 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound53903 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env53904 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13324,80,8203,5221,2128,1024,81,12345,8281,16,2,8192,64,10280,5221,4096,10360,9304,8281,116,8280,13404,8825]

theorem envBound53904 : H12AffineFastState.Bounded env53904 := by
  intro p hp
  have h : env53904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53903_53904 : H12AffineEnvironment.transform 7 116 env53903 = env53904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env53903 == env53904) = true)

theorem identity53904 : scanCanonicalize (H12AffineFastState.compose env53904 (packedSelected [4,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound53904 : packedSelected [4,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53905 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5156,80,35,5221,2128,1024,81,4113,113,16,2,40,64,2048,5221,4096,2128,1136,113,116,112,5236,593]

theorem envBound53905 : H12AffineFastState.Bounded env53905 := by
  intro p hp
  have h : env53905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53904_53905 : H12AffineEnvironment.transform 12 40 env53904 = env53905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env53904 == env53905) = true)

def env53906 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,8,5124,80,3,5189,2128,1024,81,4113,81,16,2,8,64,2048,5189,4096,2128,1104,81,84,80,5204,593]

theorem envBound53906 : H12AffineFastState.Bounded env53906 := by
  intro p hp
  have h : env53906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53905_53906 : H12AffineEnvironment.transform 4 0 env53905 = env53906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53905 == env53906) = true)

def env53907 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,2112,8,3140,80,3,3077,2128,1024,81,2129,81,16,2,8,64,2048,3077,2112,2128,1104,81,84,80,3092,593]

theorem envBound53907 : H12AffineFastState.Bounded env53907 := by
  intro p hp
  have h : env53907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53906_53907 : H12AffineEnvironment.transform 11 2112 env53906 = env53907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env53906 == env53907) = true)

theorem identity53907 : scanCanonicalize (H12AffineFastState.compose env53907 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53907 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env53908 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,2064,8,3092,0,3,3077,2048,1024,1,2049,1,16,2,8,16,2048,3077,2064,2048,1024,1,4,0,3092,513]

theorem envBound53908 : H12AffineFastState.Bounded env53908 := by
  intro p hp
  have h : env53908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53907_53908 : H12AffineEnvironment.transform 5 16 env53907 = env53908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53907 == env53908) = true)

def env53909 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,8,1044,0,3,1029,0,1024,1,1,1,16,2,8,16,0,1029,16,0,1024,1,4,0,1044,513]

theorem envBound53909 : H12AffineFastState.Bounded env53909 := by
  intro p hp
  have h : env53909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53908_53909 : H12AffineEnvironment.transform 10 0 env53908 = env53909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53908 == env53909) = true)

def env53910 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1,17,8,1045,0,3,1028,1,1024,1,0,1,16,2,8,16,1,1028,17,1,1024,1,4,0,1045,513]

theorem envBound53910 : H12AffineFastState.Bounded env53910 := by
  intro p hp
  have h : env53910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53908_53910 : H12AffineEnvironment.transform 10 1 env53908 = env53910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53908 == env53910) = true)

theorem identity53910 : scanCanonicalize (H12AffineFastState.compose env53910 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound53910 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53911 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,8,1,0,3,16,1,20,1,0,1,16,2,8,16,1,16,17,1,20,1,4,0,1,513]

theorem envBound53911 : H12AffineFastState.Bounded env53911 := by
  intro p hp
  have h : env53911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53910_53911 : H12AffineEnvironment.transform 9 20 env53910 = env53911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53910 == env53911) = true)

theorem identity53911 : scanCanonicalize (H12AffineFastState.compose env53911 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound53911 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53912 : List Nat := [2,4,8,16,0,16,8,4,10,20,1,17,8,1,0,3,16,1,20,1,0,1,16,2,8,16,1,16,17,1,20,1,4,0,1,11]

theorem envBound53912 : H12AffineFastState.Bounded env53912 := by
  intro p hp
  have h : env53912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53911_53912 : H12AffineEnvironment.transform 8 10 env53911 = env53912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env53911 == env53912) = true)

def leafEnv53912 : List Nat := [2,4,8,16,0,16,8,4,10,20,1,17,8,1,0,3,16,1,20,1,0,1,16,2,20,8,1,16,1,16,17,1,20,1,4,0,4,3,1,11,1,0,0]

def active53912 : List Nat := [0,1,2,3]

def tree53912 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53912 : H12WitnessSearch.Good tree53912 := H12GlobalWitnessIndex.good

theorem leafIdentity53912 : H12AffineFastState.composeSystem env53912 rootObs = leafEnv53912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53912 rootObs == leafEnv53912) = true)

theorem terminalChecked53912 : H12PackedTerminal.terminalCheckFast leafEnv53912 active53912 tree53912 = true := by decide +kernel

def env53913 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,2113,8,3141,80,3,3076,2128,1024,81,2128,81,16,2,8,64,2048,3076,2113,2128,1104,81,84,80,3093,593]

theorem envBound53913 : H12AffineFastState.Bounded env53913 := by
  intro p hp
  have h : env53913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53906_53913 : H12AffineEnvironment.transform 11 2113 env53906 = env53913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env53906 == env53913) = true)

def env53914 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,2065,8,3093,0,3,3076,2048,1024,1,2048,1,16,2,8,16,2048,3076,2065,2048,1024,1,4,0,3093,513]

theorem envBound53914 : H12AffineFastState.Bounded env53914 := by
  intro p hp
  have h : env53914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53913_53914 : H12AffineEnvironment.transform 5 16 env53913 = env53914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53913 == env53914) = true)

def env53915 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,8,1045,0,3,1028,0,1024,1,0,1,16,2,8,16,0,1028,17,0,1024,1,4,0,1045,513]

theorem envBound53915 : H12AffineFastState.Bounded env53915 := by
  intro p hp
  have h : env53915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53914_53915 : H12AffineEnvironment.transform 10 0 env53914 = env53915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53914 == env53915) = true)

theorem identity53915 : scanCanonicalize (H12AffineFastState.compose env53915 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound53915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53916 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,8,0,0,3,17,0,21,1,0,1,16,2,8,16,0,17,17,0,21,1,4,0,0,513]

theorem envBound53916 : H12AffineFastState.Bounded env53916 := by
  intro p hp
  have h : env53916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53915_53916 : H12AffineEnvironment.transform 9 21 env53915 = env53916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53915 == env53916) = true)

def env53917 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1,16,8,1044,0,3,1029,1,1024,1,1,1,16,2,8,16,1,1029,16,1,1024,1,4,0,1044,513]

theorem envBound53917 : H12AffineFastState.Bounded env53917 := by
  intro p hp
  have h : env53917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53914_53917 : H12AffineEnvironment.transform 10 1 env53914 = env53917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53914 == env53917) = true)

def env53918 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,16,8,0,0,3,17,1,20,1,1,1,16,2,8,16,1,17,16,1,20,1,4,0,0,513]

theorem envBound53918 : H12AffineFastState.Bounded env53918 := by
  intro p hp
  have h : env53918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53917_53918 : H12AffineEnvironment.transform 9 20 env53917 = env53918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53917 == env53918) = true)

theorem identity53918 : scanCanonicalize (H12AffineFastState.compose env53918 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound53918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53919 : List Nat := [2,4,8,16,0,16,8,4,10,20,1,16,8,0,0,3,17,1,20,1,1,1,16,2,8,16,1,17,16,1,20,1,4,0,0,11]

theorem envBound53919 : H12AffineFastState.Bounded env53919 := by
  intro p hp
  have h : env53919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53918_53919 : H12AffineEnvironment.transform 8 10 env53918 = env53919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env53918 == env53919) = true)

def leafEnv53919 : List Nat := [2,4,8,16,0,16,8,4,10,20,1,16,8,0,0,3,17,1,20,1,1,1,16,2,20,8,1,16,1,17,16,1,20,1,4,0,4,3,0,11,1,1,0]

def active53919 : List Nat := [0,1,2,3]

def tree53919 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53919 : H12WitnessSearch.Good tree53919 := H12GlobalWitnessIndex.good

theorem leafIdentity53919 : H12AffineFastState.composeSystem env53919 rootObs = leafEnv53919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53919 rootObs == leafEnv53919) = true)

theorem terminalChecked53919 : H12PackedTerminal.terminalCheckFast leafEnv53919 active53919 tree53919 = true := by decide +kernel

def env53920 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,16,8,1,0,3,16,1,21,1,1,1,16,2,8,16,1,16,16,1,21,1,4,0,1,513]

theorem envBound53920 : H12AffineFastState.Bounded env53920 := by
  intro p hp
  have h : env53920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53917_53920 : H12AffineEnvironment.transform 9 21 env53917 = env53920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53917 == env53920) = true)

def env53921 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,2064,8,3092,1,3,3076,2049,1024,0,2049,0,16,2,8,17,2048,3076,2064,2049,1025,0,5,1,3093,512]

theorem envBound53921 : H12AffineFastState.Bounded env53921 := by
  intro p hp
  have h : env53921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53913_53921 : H12AffineEnvironment.transform 5 17 env53913 = env53921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53913 == env53921) = true)

theorem identity53921 : scanCanonicalize (H12AffineFastState.compose env53921 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound53921 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53922 : List Nat := [2,4,8,16,0,17,8,5,512,21,2048,2064,8,2049,1,3,2065,2049,21,0,2049,0,16,2,8,17,2048,2065,2064,2049,20,0,5,1,2048,512]

theorem envBound53922 : H12AffineFastState.Bounded env53922 := by
  intro p hp
  have h : env53922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53921_53922 : H12AffineEnvironment.transform 9 21 env53921 = env53922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53921 == env53922) = true)

theorem identity53922 : scanCanonicalize (H12AffineFastState.compose env53922 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound53922 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53923 : List Nat := [2,4,8,16,0,17,8,5,0,21,2048,2064,8,2049,1,3,2065,2049,21,0,2049,0,16,2,8,17,2048,2065,2064,2049,20,0,5,1,2048,0]

theorem envBound53923 : H12AffineFastState.Bounded env53923 := by
  intro p hp
  have h : env53923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53922_53923 : H12AffineEnvironment.transform 8 0 env53922 = env53923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env53922 == env53923) = true)

theorem identity53923 : scanCanonicalize (H12AffineFastState.compose env53923 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound53923 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53924 : List Nat := [2,4,8,16,0,17,8,5,0,21,31,15,8,30,1,3,14,30,21,0,30,0,16,2,8,17,31,14,15,30,20,0,5,1,31,0]

theorem envBound53924 : H12AffineFastState.Bounded env53924 := by
  intro p hp
  have h : env53924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53923_53924 : H12AffineEnvironment.transform 10 31 env53923 = env53924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env53923 == env53924) = true)

def leafEnv53924 : List Nat := [2,4,8,16,0,17,8,5,0,21,31,15,8,30,1,3,14,30,21,0,30,0,16,2,20,8,1,17,31,14,15,30,20,0,5,1,4,3,31,0,1,31,0]

def active53924 : List Nat := [0,1,2,3]

def tree53924 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53924 : H12WitnessSearch.Good tree53924 := H12GlobalWitnessIndex.good

theorem leafIdentity53924 : H12AffineFastState.composeSystem env53924 rootObs = leafEnv53924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53924 rootObs == leafEnv53924) = true)

theorem terminalChecked53924 : H12PackedTerminal.terminalCheckFast leafEnv53924 active53924 tree53924 = true := by decide +kernel

def env53925 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,9,5125,80,2,5188,2128,1024,81,4113,80,16,2,9,64,2048,5188,4096,2128,1105,80,85,81,5205,593]

theorem envBound53925 : H12AffineFastState.Bounded env53925 := by
  intro p hp
  have h : env53925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53905_53925 : H12AffineEnvironment.transform 4 1 env53905 = env53925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53905 == env53925) = true)

theorem identity53925 : scanCanonicalize (H12AffineFastState.compose env53925 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53925 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53926 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,9,5125,0,2,5140,2048,1024,1,4113,0,16,2,9,16,2048,5140,4096,2048,1025,0,5,1,5125,513]

theorem envBound53926 : H12AffineFastState.Bounded env53926 := by
  intro p hp
  have h : env53926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53925_53926 : H12AffineEnvironment.transform 5 16 env53925 = env53926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53925 == env53926) = true)

def env53927 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,16,9,1045,0,2,1028,2048,1024,1,1,0,16,2,9,16,2048,1028,16,2048,1025,0,5,1,1045,513]

end H12CloudChart0