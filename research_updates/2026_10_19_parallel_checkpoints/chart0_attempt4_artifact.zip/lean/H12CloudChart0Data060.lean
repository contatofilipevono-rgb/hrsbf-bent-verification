import H12CloudChart0Data059

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound15077 : H12AffineFastState.Bounded env15077 := by
  intro p hp
  have h : env15077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15076_15077 : H12AffineEnvironment.transform 23 243088 env15076 = env15077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env15076 == env15077) = true)

def env15078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,254083,243088,8328,64,97546,139613,238994,336002,119042,272392,257,98814,90202,63189]

theorem envBound15078 : H12AffineFastState.Bounded env15078 := by
  intro p hp
  have h : env15078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15077_15078 : H12AffineEnvironment.transform 20 4160 env15077 = env15078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15077 == env15078) = true)

theorem identity15078 : scanCanonicalize (H12AffineFastState.compose env15078 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound15078 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,4160,329866,17,21762,8328,64,97546,115151,17664,336002,119042,272392,257,98814,90202,63189]

theorem envBound15079 : H12AffineFastState.Bounded env15079 := by
  intro p hp
  have h : env15079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15078_15079 : H12AffineEnvironment.transform 16 123026 env15078 = env15079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env15078 == env15079) = true)

def env15080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,329730,17,21762,8192,64,97546,115015,17664,335882,119042,272392,257,98678,90202,63069]

theorem envBound15080 : H12AffineFastState.Bounded env15080 := by
  intro p hp
  have h : env15080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15079_15080 : H12AffineEnvironment.transform 6 8 env15079 = env15080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15079 == env15080) = true)

theorem identity15080 : scanCanonicalize (H12AffineFastState.compose env15080 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound15080 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,32040,1025,32769,4160,95530,17,21762,8192,64,97546,115015,17664,89378,119042,21792,257,98678,90202,63069]

theorem envBound15081 : H12AffineFastState.Bounded env15081 := by
  intro p hp
  have h : env15081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15080_15081 : H12AffineEnvironment.transform 17 32040 env15080 = env15081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env15080 == env15081) = true)

theorem identity15081 : scanCanonicalize (H12AffineFastState.compose env15081 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15081 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env15082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,90139,32040,1025,0,4160,95530,17,21762,8192,64,97546,82246,17664,89378,86275,21792,257,65911,90202,30300]

theorem envBound15082 : H12AffineFastState.Bounded env15082 := by
  intro p hp
  have h : env15082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15081_15082 : H12AffineEnvironment.transform 14 1 env15081 = env15082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15081 == env15082) = true)

theorem identity15082 : scanCanonicalize (H12AffineFastState.compose env15082 (packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15082 : packedSelected [0,1,4,5,7,8,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env15083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,65536,82247,23668,1025,0,4160,87158,17,21762,348,64,89174,82246,17664,89378,86275,21792,257,65911,82182,22272]

theorem envBound15083 : H12AffineFastState.Bounded env15083 := by
  intro p hp
  have h : env15083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15082_15083 : H12AffineEnvironment.transform 12 348 env15082 = env15083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15082 == env15083) = true)

theorem identity15083 : scanCanonicalize (H12AffineFastState.compose env15083 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound15083 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env15084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21511,5440,23668,1025,0,4160,113,17,21762,348,64,2129,5441,17664,2341,1284,21792,257,21872,5377,22272]

theorem envBound15084 : H12AffineFastState.Bounded env15084 := by
  intro p hp
  have h : env15084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15083_15084 : H12AffineEnvironment.transform 15 21511 env15083 = env15084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env15083 == env15084) = true)

theorem identity15084 : scanCanonicalize (H12AffineFastState.compose env15084 (packedSelected [1,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound15084 : packedSelected [1,8,11] rootPS < 2^1333 := by decide +kernel

def env15085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,1344,1,4423,5440,6452,1025,0,4160,113,17,4162,348,64,2129,5441,64,2341,1284,4192,257,4144,5377,4672]

theorem envBound15085 : H12AffineFastState.Bounded env15085 := by
  intro p hp
  have h : env15085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15084_15085 : H12AffineEnvironment.transform 13 1344 env15084 = env15085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env15084 == env15085) = true)

theorem identity15085 : scanCanonicalize (H12AffineFastState.compose env15085 (packedSelected [2,6,7,9,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound15085 : packedSelected [2,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env15086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,348,1344,1,4423,5440,5236,1025,0,4160,113,17,4162,348,64,1297,5441,64,1125,1284,4192,257,4144,5377,4672]

theorem envBound15086 : H12AffineFastState.Bounded env15086 := by
  intro p hp
  have h : env15086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15085_15086 : H12AffineEnvironment.transform 10 1344 env15085 = env15086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env15085 == env15086) = true)

theorem identity15086 : scanCanonicalize (H12AffineFastState.compose env15086 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound15086 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env15087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,65,348,1344,1,262,1281,1077,1025,0,1,113,17,3,348,64,1297,1280,64,1125,1284,33,257,113,1344,513]

theorem envBound15087 : H12AffineFastState.Bounded env15087 := by
  intro p hp
  have h : env15087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15086_15087 : H12AffineEnvironment.transform 11 65 env15086 = env15087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env15086 == env15087) = true)

theorem identity15087 : scanCanonicalize (H12AffineFastState.compose env15087 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15087 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15088 : List Nat := [2,4,8,16,32,64,8,256,512,53,373,65,348,373,1,262,308,0,52,0,1,113,17,3,348,64,292,309,64,80,305,33,257,113,373,513]

theorem envBound15088 : H12AffineFastState.Bounded env15088 := by
  intro p hp
  have h : env15088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15087_15088 : H12AffineEnvironment.transform 9 53 env15087 = env15088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15087 == env15088) = true)

def env15089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,329731,17,21762,8193,64,97546,115014,17664,335883,119042,272392,257,98679,90202,63068]

theorem envBound15089 : H12AffineFastState.Bounded env15089 := by
  intro p hp
  have h : env15089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15079_15089 : H12AffineEnvironment.transform 6 9 env15079 = env15089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15079 == env15089) = true)

theorem identity15089 : scanCanonicalize (H12AffineFastState.compose env15089 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound15089 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,56437,1025,32769,4160,119926,17,21762,8193,64,97546,115014,17664,130174,119042,62589,257,98679,90202,63068]

theorem envBound15090 : H12AffineFastState.Bounded env15090 := by
  intro p hp
  have h : env15090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15089_15090 : H12AffineEnvironment.transform 17 56437 env15089 = env15090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env15089 == env15090) = true)

theorem identity15090 : scanCanonicalize (H12AffineFastState.compose env15090 (packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound15090 : packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env15091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,262,57629,56437,1025,32769,4160,54640,17,21762,8193,64,31756,49216,17664,64888,53252,62589,257,32881,24924,63068]

theorem envBound15091 : H12AffineFastState.Bounded env15091 := by
  intro p hp
  have h : env15091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15090_15091 : H12AffineEnvironment.transform 15 262 env15090 = env15091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env15090 == env15091) = true)

theorem identity15091 : scanCanonicalize (H12AffineFastState.compose env15091 (packedSelected [4,10,11,12,14,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15091 : packedSelected [4,10,11,12,14,19,22] rootPS < 2^1333 := by decide +kernel

def env15092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,262,24861,23669,1025,1,4160,21872,17,21762,8193,64,31756,16448,17664,32120,20484,29821,257,113,24924,30300]

theorem envBound15092 : H12AffineFastState.Bounded env15092 := by
  intro p hp
  have h : env15092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15091_15092 : H12AffineEnvironment.transform 14 0 env15091 = env15092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15091 == env15092) = true)

theorem identity15092 : scanCanonicalize (H12AffineFastState.compose env15092 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15092 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15093 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,262,24861,23588,1025,1,4113,21793,17,21762,8193,17,31756,16401,17664,32041,20484,29740,257,32,24845,30221]

theorem envBound15093 : H12AffineFastState.Bounded env15093 := by
  intro p hp
  have h : env15093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15092_15093 : H12AffineEnvironment.transform 5 17 env15092 = env15093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15092 == env15093) = true)

theorem identity15093 : scanCanonicalize (H12AffineFastState.compose env15093 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15093 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env15094 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,16384,0,262,24861,22544,53,1,4113,20757,17,20790,8193,17,30776,16401,16692,31005,20484,28696,257,32,24845,29241]

theorem envBound15094 : H12AffineFastState.Bounded env15094 := by
  intro p hp
  have h : env15094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15093_15094 : H12AffineEnvironment.transform 9 52 env15093 = env15094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15093 == env15094) = true)

theorem identity15094 : scanCanonicalize (H12AffineFastState.compose env15094 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound15094 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env15095 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,12572,0,262,4097,10508,53,1,4113,8201,17,8234,8193,17,2340,12557,12328,2049,8472,260,257,32,4113,805]

theorem envBound15095 : H12AffineFastState.Bounded env15095 := by
  intro p hp
  have h : env15095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15094_15095 : H12AffineEnvironment.transform 13 12572 env15094 = env15095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env15094 == env15095) = true)

theorem identity15095 : scanCanonicalize (H12AffineFastState.compose env15095 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15095 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env15096 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4113,0,262,4097,2049,53,1,4113,260,17,295,268,17,2340,4096,4389,2049,21,260,257,32,4113,805]

theorem envBound15096 : H12AffineFastState.Bounded env15096 := by
  intro p hp
  have h : env15096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15095_15096 : H12AffineEnvironment.transform 12 269 env15095 = env15096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15095 == env15096) = true)

theorem identity15096 : scanCanonicalize (H12AffineFastState.compose env15096 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound15096 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env15097 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2356,269,2341,0,262,2357,2049,53,1,2341,260,17,295,268,17,2340,2356,2065,2049,21,260,257,32,2341,805]

theorem envBound15097 : H12AffineFastState.Bounded env15097 := by
  intro p hp
  have h : env15097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15096_15097 : H12AffineEnvironment.transform 11 2356 env15096 = env15097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env15096 == env15097) = true)

def env15098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,254083,243088,8328,64,97546,139612,238995,336002,119042,272393,257,98815,90203,63189]

theorem envBound15098 : H12AffineFastState.Bounded env15098 := by
  intro p hp
  have h : env15098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15077_15098 : H12AffineEnvironment.transform 20 4161 env15077 = env15098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15077 == env15098) = true)

theorem identity15098 : scanCanonicalize (H12AffineFastState.compose env15098 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15098 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,452632,180360,169371,8328,64,23809,139612,165272,262281,61705,272393,257,41460,16464,63189]

theorem envBound15099 : H12AffineFastState.Bounded env15099 := by
  intro p hp
  have h : env15099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15098_15099 : H12AffineEnvironment.transform 15 8203 env15098 = env15099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15098 == env15099) = true)

theorem identity15099 : scanCanonicalize (H12AffineFastState.compose env15099 (packedSelected [1,4,7,9,12,15,19,27,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound15099 : packedSelected [1,4,7,9,12,15,19,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env15100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,57677,262144,1025,32769,4161,264533,8645,29910,8328,64,23809,49169,25813,262281,61705,272393,257,41460,16464,63189]

theorem envBound15100 : H12AffineFastState.Bounded env15100 := by
  intro p hp
  have h : env15100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15099_15100 : H12AffineEnvironment.transform 16 57677 env15099 = env15100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env15099 == env15100) = true)

theorem identity15100 : scanCanonicalize (H12AffineFastState.compose env15100 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound15100 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env15101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,57677,43049,1025,32769,4161,41340,8645,29910,8328,64,23809,49169,25813,43168,61705,32800,257,41460,16464,63189]

theorem envBound15101 : H12AffineFastState.Bounded env15101 := by
  intro p hp
  have h : env15101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15100_15101 : H12AffineEnvironment.transform 17 43049 env15100 = env15101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env15100 == env15101) = true)

theorem identity15101 : scanCanonicalize (H12AffineFastState.compose env15101 (packedSelected [1,3,5,8,10,18,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound15101 : packedSelected [1,3,5,8,10,18,23,26] rootPS < 2^1333 := by decide +kernel

def env15102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,8203,25029,10401,1025,137,4161,8692,8645,29910,8328,64,23809,16537,25813,10280,29057,168,257,8572,16464,30301]

theorem envBound15102 : H12AffineFastState.Bounded env15102 := by
  intro p hp
  have h : env15102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15101_15102 : H12AffineEnvironment.transform 14 136 env15101 = env15102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env15101 == env15102) = true)

theorem identity15102 : scanCanonicalize (H12AffineFastState.compose env15102 (packedSelected [3,10,17,18,19,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound15102 : packedSelected [3,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env15103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8203,5529,10401,1025,137,4161,8692,8645,138,8328,64,10589,13509,4233,10280,1501,168,257,8572,13324,513]

theorem envBound15103 : H12AffineFastState.Bounded env15103 := by
  intro p hp
  have h : env15103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15102_15103 : H12AffineEnvironment.transform 13 13404 env15102 = env15103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env15102 == env15103) = true)

theorem identity15103 : scanCanonicalize (H12AffineFastState.compose env15103 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15103 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env15104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8203,5392,10280,1025,0,4161,8573,8524,3,8193,64,10589,13388,4096,10280,1364,33,257,8572,13324,513]

theorem envBound15104 : H12AffineFastState.Bounded env15104 := by
  intro p hp
  have h : env15104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15103_15104 : H12AffineEnvironment.transform 6 9 env15103 = env15104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15103 == env15104) = true)

theorem identity15104 : scanCanonicalize (H12AffineFastState.compose env15104 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15104 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1025,0,4161,32,17,3,348,64,2048,5393,4096,2421,1364,33,257,33,5457,513]

theorem envBound15105 : H12AffineFastState.Bounded env15105 := by
  intro p hp
  have h : env15105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15104_15105 : H12AffineEnvironment.transform 12 349 env15104 = env15105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15104 == env15105) = true)

theorem identity15105 : scanCanonicalize (H12AffineFastState.compose env15105 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound15105 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,4096,349,5377,1,342,5392,1306,1025,0,4161,32,17,3,348,64,1135,5393,4096,1306,1364,33,257,33,5457,513]

theorem envBound15106 : H12AffineFastState.Bounded env15106 := by
  intro p hp
  have h : env15106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15105_15106 : H12AffineEnvironment.transform 10 1135 env15105 = env15106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env15105 == env15106) = true)

def env15107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254083,243089,8328,64,97547,2240796,2340306,336002,119043,2373705,257,2199999,2191387,63188]

theorem envBound15107 : H12AffineFastState.Bounded env15107 := by
  intro p hp
  have h : env15107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15076_15107 : H12AffineEnvironment.transform 23 243089 env15076 = env15107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env15076 == env15107) = true)

def env15108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,254083,243089,8328,64,97547,139612,238994,336002,119043,272393,257,98815,90203,63188]

theorem envBound15108 : H12AffineFastState.Bounded env15108 := by
  intro p hp
  have h : env15108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15107_15108 : H12AffineEnvironment.transform 20 4160 env15107 = env15108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15107 == env15108) = true)

theorem identity15108 : scanCanonicalize (H12AffineFastState.compose env15108 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound15108 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,452632,144477,155983,8328,64,43477,139612,160076,324700,1501,272393,257,21793,46213,63188]

theorem envBound15109 : H12AffineFastState.Bounded env15109 := by
  intro p hp
  have h : env15109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15108_15109 : H12AffineEnvironment.transform 15 54494 env15108 = env15109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env15108 == env15109) = true)

def env15110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146912,1025,32769,4160,54776,144477,155983,8328,64,43477,139612,160076,182716,1501,136681,257,21793,46213,63188]

theorem envBound15110 : H12AffineFastState.Bounded env15110 := by
  intro p hp
  have h : env15110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15109_15110 : H12AffineEnvironment.transform 17 146912 env15109 = env15110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env15109 == env15110) = true)

theorem identity15110 : scanCanonicalize (H12AffineFastState.compose env15110 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound15110 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env15111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,5393,10481,1025,32769,4160,54776,8524,29790,8328,64,43477,13389,25693,56493,1501,248,257,21793,46213,63188]

theorem envBound15111 : H12AffineFastState.Bounded env15111 := by
  intro p hp
  have h : env15111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15110_15111 : H12AffineEnvironment.transform 16 5393 env15110 = env15111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env15110 == env15111) = true)

theorem identity15111 : scanCanonicalize (H12AffineFastState.compose env15111 (packedSelected [3,4,7,9,11,14,16,18,19,20,23,24,27,31,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound15111 : packedSelected [3,4,7,9,11,14,16,18,19,20,23,24,27,31,32,35] rootPS < 2^1333 := by decide +kernel

def env15112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33111,5393,10481,1025,32769,4160,32881,8524,8663,8328,64,43477,13389,12756,35108,1501,248,257,168,46213,41821]

theorem envBound15112 : H12AffineFastState.Bounded env15112 := by
  intro p hp
  have h : env15112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15111_15112 : H12AffineEnvironment.transform 13 5513 env15111 = env15112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env15111 == env15112) = true)

theorem identity15112 : scanCanonicalize (H12AffineFastState.compose env15112 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15112 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env15113 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,33031,5393,10401,1025,32769,4112,32801,8476,8583,8328,16,43397,13341,12676,35108,1421,168,257,168,46213,41741]

theorem envBound15113 : H12AffineFastState.Bounded env15113 := by
  intro p hp
  have h : env15113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15112_15113 : H12AffineEnvironment.transform 5 16 env15112 = env15113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15112 == env15113) = true)

theorem identity15113 : scanCanonicalize (H12AffineFastState.compose env15113 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15113 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env15114 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,0,263,5393,10401,1025,1,4112,33,8476,8583,8328,16,10629,13341,12676,2340,1421,168,257,168,13445,8973]

theorem envBound15114 : H12AffineFastState.Bounded env15114 := by
  intro p hp
  have h : env15114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15113_15114 : H12AffineEnvironment.transform 14 0 env15113 = env15114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15113 == env15114) = true)

theorem identity15114 : scanCanonicalize (H12AffineFastState.compose env15114 (packedSelected [2,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2460) := by decide +kernel

theorem selectedBound15114 : packedSelected [2,11,14,15] rootPS < 2^1333 := by decide +kernel

def env15115 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2460,8192,3093,0,263,3213,10401,1025,1,2444,33,8476,8583,8328,16,10629,11649,10264,2340,1421,168,257,168,11545,8973]

theorem envBound15115 : H12AffineFastState.Bounded env15115 := by
  intro p hp
  have h : env15115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15114_15115 : H12AffineEnvironment.transform 11 2460 env15114 = env15115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2460 env15114 == env15115) = true)

theorem identity15115 : scanCanonicalize (H12AffineFastState.compose env15115 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15115 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env15116 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2325,8192,3093,0,263,3076,10280,1025,1,2309,33,8476,8462,8193,16,10508,11528,10264,2340,1284,33,257,33,11545,8973]

theorem envBound15116 : H12AffineFastState.Bounded env15116 := by
  intro p hp
  have h : env15116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15115_15116 : H12AffineEnvironment.transform 6 9 env15115 = env15116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15115 == env15116) = true)

theorem identity15116 : scanCanonicalize (H12AffineFastState.compose env15116 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound15116 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env15117 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1819,1550,8192,782,0,263,799,10035,1025,1,1566,33,8476,8462,8193,16,9751,8723,9987,1599,1284,33,257,33,8706,8973]

theorem envBound15117 : H12AffineFastState.Bounded env15117 := by
  intro p hp
  have h : env15117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15116_15117 : H12AffineEnvironment.transform 10 1819 env15116 = env15117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env15116 == env15117) = true)

theorem identity15117 : scanCanonicalize (H12AffineFastState.compose env15117 (packedSelected [2,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15117 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env15118 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1819,1550,269,782,0,263,799,1598,1025,1,1566,33,17,3,268,16,1818,798,1550,1599,1284,33,257,33,783,512]

theorem envBound15118 : H12AffineFastState.Bounded env15118 := by
  intro p hp
  have h : env15118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15117_15118 : H12AffineEnvironment.transform 12 269 env15117 = env15118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15117 == env15118) = true)

theorem identity15118 : scanCanonicalize (H12AffineFastState.compose env15118 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15118 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15119 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1567,1550,9,522,0,3,539,1598,1025,1,1566,33,17,3,8,16,1566,538,1550,1599,1024,33,5,33,523,512]

theorem envBound15119 : H12AffineFastState.Bounded env15119 := by
  intro p hp
  have h : env15119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15118_15119 : H12AffineEnvironment.transform 7 4 env15118 = env15119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15118 == env15119) = true)

theorem identity15119 : scanCanonicalize (H12AffineFastState.compose env15119 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15119 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15120 : List Nat := [2,4,8,16,0,16,9,4,512,1024,1567,1550,9,522,0,3,539,1566,1025,1,1566,1,17,3,8,16,1566,538,1550,1567,1024,1,5,1,523,512]

theorem envBound15120 : H12AffineFastState.Bounded env15120 := by
  intro p hp
  have h : env15120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15119_15120 : H12AffineEnvironment.transform 4 0 env15119 = env15120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15119 == env15120) = true)

theorem identity15120 : scanCanonicalize (H12AffineFastState.compose env15120 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 519) := by decide +kernel

theorem selectedBound15120 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15121 : List Nat := [2,4,8,16,0,16,9,4,512,519,24,9,9,522,0,3,539,25,518,1,25,1,17,3,8,16,25,538,9,24,519,1,5,1,523,512]

theorem envBound15121 : H12AffineFastState.Bounded env15121 := by
  intro p hp
  have h : env15121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15120_15121 : H12AffineEnvironment.transform 9 519 env15120 = env15121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 519 env15120 == env15121) = true)

theorem identity15121 : scanCanonicalize (H12AffineFastState.compose env15121 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound15121 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15122 : List Nat := [2,4,8,16,0,16,9,4,18,21,24,9,9,24,0,3,9,25,20,1,25,1,17,3,8,16,25,8,9,24,21,1,5,1,25,18]

theorem envBound15122 : H12AffineFastState.Bounded env15122 := by
  intro p hp
  have h : env15122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15121_15122 : H12AffineEnvironment.transform 8 18 env15121 = env15122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env15121 == env15122) = true)

theorem identity15122 : scanCanonicalize (H12AffineFastState.compose env15122 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound15122 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15123 : List Nat := [2,4,8,7,0,7,9,4,5,2,15,9,9,15,0,3,9,14,3,1,14,1,6,3,8,7,14,8,9,15,2,1,5,1,14,5]

theorem envBound15123 : H12AffineFastState.Bounded env15123 := by
  intro p hp
  have h : env15123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15122_15123 : H12AffineEnvironment.transform 3 7 env15122 = env15123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env15122 == env15123) = true)

def env15124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146913,1025,32769,4160,54777,144477,155983,8328,64,43477,139612,160076,182717,1501,136680,257,21793,46213,63188]

theorem envBound15124 : H12AffineFastState.Bounded env15124 := by
  intro p hp
  have h : env15124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15109_15124 : H12AffineEnvironment.transform 17 146913 env15109 = env15124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env15109 == env15124) = true)

theorem identity15124 : scanCanonicalize (H12AffineFastState.compose env15124 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound15124 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env15125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,5528,10361,1025,32769,4160,54777,8645,29911,8328,64,43477,13508,25812,56357,1501,112,257,21793,46213,63188]

theorem envBound15125 : H12AffineFastState.Bounded env15125 := by
  intro p hp
  have h : env15125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15124_15125 : H12AffineEnvironment.transform 16 5528 env15124 = env15125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env15124 == env15125) = true)

theorem identity15125 : scanCanonicalize (H12AffineFastState.compose env15125 (packedSelected [1,4,5,7,8,9,16,17,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound15125 : packedSelected [1,4,5,7,8,9,16,17,20,24,27] rootPS < 2^1333 := by decide +kernel

def env15126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8403,5528,10361,1025,29708,4160,8692,8645,29911,8328,64,24024,13508,25812,10280,1501,112,257,21793,16520,729]

theorem envBound15126 : H12AffineFastState.Bounded env15126 := by
  intro p hp
  have h : env15126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15125_15126 : H12AffineEnvironment.transform 14 29709 env15125 = env15126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env15125 == env15126) = true)

theorem identity15126 : scanCanonicalize (H12AffineFastState.compose env15126 (packedSelected [0,3,4,5,7,9,11,15,16,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15126 : packedSelected [0,3,4,5,7,9,11,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env15127 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,8322,5528,10280,1025,29708,4113,8613,8596,29830,8328,17,23945,13461,25733,10280,1420,33,257,21793,16520,648]

theorem envBound15127 : H12AffineFastState.Bounded env15127 := by
  intro p hp
  have h : env15127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15126_15127 : H12AffineEnvironment.transform 5 17 env15126 = env15127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15126 == env15127) = true)

theorem identity15127 : scanCanonicalize (H12AffineFastState.compose env15127 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound15127 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15128 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21896,263,5528,2477,1025,21897,4113,32,17,21763,269,17,23945,5392,17664,2477,1420,33,257,21793,16520,648]

theorem envBound15128 : H12AffineFastState.Bounded env15128 := by
  intro p hp
  have h : env15128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15127_15128 : H12AffineEnvironment.transform 12 389 env15127 = env15128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env15127 == env15128) = true)

theorem identity15128 : scanCanonicalize (H12AffineFastState.compose env15128 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15128 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env15129 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5377,137,263,5528,2477,1025,136,4113,32,17,2,269,17,2184,5392,4097,2477,1420,33,257,32,5513,648]

theorem envBound15129 : H12AffineFastState.Bounded env15129 := by
  intro p hp
  have h : env15129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15128_15129 : H12AffineEnvironment.transform 13 5377 env15128 = env15129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15128 == env15129) = true)

theorem identity15129 : scanCanonicalize (H12AffineFastState.compose env15129 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound15129 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env15130 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,40,5292,137,170,5173,2048,1025,136,4113,32,17,2,160,17,2184,5309,4097,2048,1057,33,172,32,5156,648]

theorem envBound15130 : H12AffineFastState.Bounded env15130 := by
  intro p hp
  have h : env15130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15129_15130 : H12AffineEnvironment.transform 7 173 env15129 = env15130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env15129 == env15130) = true)

theorem identity15130 : scanCanonicalize (H12AffineFastState.compose env15130 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15130 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env15131 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,1,34,5173,2048,1025,0,4113,32,17,2,40,17,2048,5173,4097,2048,1057,33,36,32,5156,512]

theorem envBound15131 : H12AffineFastState.Bounded env15131 := by
  intro p hp
  have h : env15131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15130_15131 : H12AffineEnvironment.transform 6 8 env15130 = env15131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15130 == env15131) = true)

theorem identity15131 : scanCanonicalize (H12AffineFastState.compose env15131 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15131 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15132 : List Nat := [2,4,8,16,32,17,8,37,512,21,2048,4096,40,4145,1,34,4128,2048,20,0,4113,32,17,2,40,17,2048,4128,4097,2048,52,33,36,32,4145,512]

theorem envBound15132 : H12AffineFastState.Bounded env15132 := by
  intro p hp
  have h : env15132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15131_15132 : H12AffineEnvironment.transform 9 21 env15131 = env15132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15131 == env15132) = true)

theorem identity15132 : scanCanonicalize (H12AffineFastState.compose env15132 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound15132 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15133 : List Nat := [2,4,8,16,32,17,8,37,512,21,523,4096,40,4145,1,34,4128,523,20,0,4113,32,17,2,40,17,523,4128,4097,523,52,33,36,32,4145,512]

theorem envBound15133 : H12AffineFastState.Bounded env15133 := by
  intro p hp
  have h : env15133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15132_15133 : H12AffineEnvironment.transform 10 523 env15132 = env15133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env15132 == env15133) = true)

theorem identity15133 : scanCanonicalize (H12AffineFastState.compose env15133 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound15133 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15134 : List Nat := [2,4,8,16,32,17,8,37,512,21,523,571,40,522,1,34,539,523,20,0,554,32,17,2,40,17,523,539,570,523,52,33,36,32,522,512]

theorem envBound15134 : H12AffineFastState.Bounded env15134 := by
  intro p hp
  have h : env15134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15133_15134 : H12AffineEnvironment.transform 11 571 env15133 = env15134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env15133 == env15134) = true)

theorem identity15134 : scanCanonicalize (H12AffineFastState.compose env15134 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound15134 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15135 : List Nat := [2,4,8,16,32,17,8,37,8,21,3,51,40,2,1,34,19,3,20,0,34,32,17,2,40,17,3,19,50,3,52,33,36,32,2,8]

theorem envBound15135 : H12AffineFastState.Bounded env15135 := by
  intro p hp
  have h : env15135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15134_15135 : H12AffineEnvironment.transform 8 8 env15134 = env15135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env15134 == env15135) = true)

theorem identity15135 : scanCanonicalize (H12AffineFastState.compose env15135 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15135 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env15136 : List Nat := [2,4,8,16,0,17,8,5,8,21,3,19,8,2,1,2,19,3,20,0,2,0,17,2,8,17,3,19,18,3,20,1,4,0,2,8]

theorem envBound15136 : H12AffineFastState.Bounded env15136 := by
  intro p hp
  have h : env15136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15135_15136 : H12AffineEnvironment.transform 4 0 env15135 = env15136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15135 == env15136) = true)

theorem identity15136 : scanCanonicalize (H12AffineFastState.compose env15136 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound15136 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15137 : List Nat := [2,4,8,6,0,7,8,5,8,3,3,5,8,2,1,2,5,3,2,0,2,0,7,2,8,7,3,5,4,3,2,1,4,0,2,8]

theorem envBound15137 : H12AffineFastState.Bounded env15137 := by
  intro p hp
  have h : env15137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15136_15137 : H12AffineEnvironment.transform 3 6 env15136 = env15137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env15136 == env15137) = true)

def env15138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,254083,243089,8328,64,97547,139613,238995,336002,119043,272392,257,98814,90202,63188]

theorem envBound15138 : H12AffineFastState.Bounded env15138 := by
  intro p hp
  have h : env15138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15107_15138 : H12AffineEnvironment.transform 20 4161 env15107 = env15138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15107 == env15138) = true)

theorem identity15138 : scanCanonicalize (H12AffineFastState.compose env15138 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound15138 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,4161,392287,62660,41430,8328,64,97547,79130,45524,336002,119043,272392,257,98814,90202,63188]

theorem envBound15139 : H12AffineFastState.Bounded env15139 := by
  intro p hp
  have h : env15139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15138_15139 : H12AffineEnvironment.transform 16 70727 env15138 = env15139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env15138 == env15139) = true)

theorem identity15139 : scanCanonicalize (H12AffineFastState.compose env15139 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound15139 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env15140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,70727,262144,1025,29908,4161,329866,17,21763,8328,64,97547,79130,17665,336002,75222,272392,257,95531,90202,513]

theorem envBound15140 : H12AffineFastState.Bounded env15140 := by
  intro p hp
  have h : env15140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15139_15140 : H12AffineEnvironment.transform 14 29909 env15139 = env15140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env15139 == env15140) = true)

def env15141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70727,262144,1025,8660,4161,329866,17,3,8328,64,75787,79130,4097,336002,75222,272392,257,73771,79194,513]

theorem envBound15141 : H12AffineFastState.Bounded env15141 := by
  intro p hp
  have h : env15141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15140_15141 : H12AffineEnvironment.transform 13 5376 env15140 = env15141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15140 == env15141) = true)

theorem identity15141 : scanCanonicalize (H12AffineFastState.compose env15141 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound15141 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70727,10401,1025,8660,4161,73771,17,3,8328,64,75787,79130,4097,67619,75222,169,257,73771,79194,513]

theorem envBound15142 : H12AffineFastState.Bounded env15142 := by
  intro p hp
  have h : env15142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15141_15142 : H12AffineEnvironment.transform 17 10401 env15141 = env15142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15141 == env15142) = true)

theorem identity15142 : scanCanonicalize (H12AffineFastState.compose env15142 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound15142 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env15143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8282,13341,10401,1025,8660,4161,113,17,3,8328,64,2129,5440,4097,10361,1420,169,257,113,5376,513]

theorem envBound15143 : H12AffineFastState.Bounded env15143 := by
  intro p hp
  have h : env15143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15142_15143 : H12AffineEnvironment.transform 15 8282 env15142 = env15143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env15142 == env15143) = true)

theorem identity15143 : scanCanonicalize (H12AffineFastState.compose env15143 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15143 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,217,342,5393,2477,1025,216,4161,113,17,3,388,64,2129,5440,4097,2421,1420,169,257,113,5376,513]

theorem envBound15144 : H12AffineFastState.Bounded env15144 := by
  intro p hp
  have h : env15144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15143_15144 : H12AffineEnvironment.transform 12 268 env15143 = env15144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15143 == env15144) = true)

def env15145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70727,262144,1025,8661,4161,329866,17,2,8328,64,75786,79130,4096,336002,75222,272392,257,73770,79195,513]

theorem envBound15145 : H12AffineFastState.Bounded env15145 := by
  intro p hp
  have h : env15145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15140_15145 : H12AffineEnvironment.transform 13 5377 env15140 = env15145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15140 == env15145) = true)

theorem identity15145 : scanCanonicalize (H12AffineFastState.compose env15145 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound15145 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70727,10280,1025,8661,4161,73890,17,2,8328,64,75786,79130,4096,67754,75222,32,257,73770,79195,513]

theorem envBound15146 : H12AffineFastState.Bounded env15146 := by
  intro p hp
  have h : env15146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15145_15146 : H12AffineEnvironment.transform 17 10280 env15145 = env15146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15145 == env15146) = true)

theorem identity15146 : scanCanonicalize (H12AffineFastState.compose env15146 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound15146 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,13509,10280,1025,8661,4161,32,17,2,8328,64,2184,5528,4096,10280,1364,32,257,168,5593,513]

theorem envBound15147 : H12AffineFastState.Bounded env15147 := by
  intro p hp
  have h : env15147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15146_15147 : H12AffineEnvironment.transform 15 8322 env15146 = env15147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env15146 == env15147) = true)

theorem identity15147 : scanCanonicalize (H12AffineFastState.compose env15147 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound15147 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env15148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,80,262,5441,2476,1025,81,4161,32,17,2,268,64,2184,5528,4096,2476,1364,32,257,168,5593,513]

theorem envBound15148 : H12AffineFastState.Bounded env15148 := by
  intro p hp
  have h : env15148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15147_15148 : H12AffineEnvironment.transform 12 388 env15147 = env15148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env15147 == env15148) = true)

theorem identity15148 : scanCanonicalize (H12AffineFastState.compose env15148 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15148 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env15149 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5377,1,262,5392,2476,1025,0,4112,32,17,2,268,17,2184,5528,4096,2476,1285,32,257,168,5512,513]

theorem envBound15149 : H12AffineFastState.Bounded env15149 := by
  intro p hp
  have h : env15149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15148_15149 : H12AffineEnvironment.transform 5 17 env15148 = env15149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15148 == env15149) = true)

theorem identity15149 : scanCanonicalize (H12AffineFastState.compose env15149 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound15149 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env15150 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2357,388,3124,1,262,3109,2476,1025,0,2341,32,17,2,268,17,2184,3245,2357,2476,1285,32,257,168,3261,513]

theorem envBound15150 : H12AffineFastState.Bounded env15150 := by
  intro p hp
  have h : env15150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15149_15150 : H12AffineEnvironment.transform 11 2357 env15149 = env15150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env15149 == env15150) = true)

theorem identity15150 : scanCanonicalize (H12AffineFastState.compose env15150 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound15150 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env15151 : List Nat := [2,4,8,16,32,17,128,52,512,1024,2048,2049,176,3124,1,50,3109,2200,1025,0,2065,32,17,2,56,17,2184,3245,2049,2200,1073,32,53,168,3261,513]

theorem envBound15151 : H12AffineFastState.Bounded env15151 := by
  intro p hp
  have h : env15151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15150_15151 : H12AffineEnvironment.transform 7 52 env15150 = env15151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env15150 == env15151) = true)

theorem identity15151 : scanCanonicalize (H12AffineFastState.compose env15151 (packedSelected [0,7,12] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound15151 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env15152 : List Nat := [2,4,8,16,32,17,128,52,512,188,2048,2049,176,2184,1,50,2201,2200,189,0,2065,32,17,2,56,17,2184,2065,2049,2200,141,32,53,168,2049,513]

theorem envBound15152 : H12AffineFastState.Bounded env15152 := by
  intro p hp
  have h : env15152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15151_15152 : H12AffineEnvironment.transform 9 188 env15151 = env15152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env15151 == env15152) = true)

theorem identity15152 : scanCanonicalize (H12AffineFastState.compose env15152 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15152 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env15153 : List Nat := [2,4,8,16,32,17,9,52,512,53,2048,2049,57,2049,1,50,2064,2065,52,0,2065,32,17,2,56,17,2049,2065,2049,2065,4,32,53,33,2049,513]

theorem envBound15153 : H12AffineFastState.Bounded env15153 := by
  intro p hp
  have h : env15153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15152_15153 : H12AffineEnvironment.transform 6 9 env15152 = env15153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15152 == env15153) = true)

def env15154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254083,16777216,8328,64,16959643,18973837,2340306,336002,16934034,19369433,257,19014702,19056010,16991045]

theorem envBound15154 : H12AffineFastState.Bounded env15154 := by
  intro p hp
  have h : env15154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15075_15154 : H12AffineEnvironment.transform 21 452633 env15075 = env15154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env15075 == env15154) = true)

def env15155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254083,243088,8328,64,97547,2240797,2340306,336002,119042,2373705,257,2199998,2191386,63189]

theorem envBound15155 : H12AffineFastState.Bounded env15155 := by
  intro p hp
  have h : env15155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15154_15155 : H12AffineEnvironment.transform 23 243088 env15154 = env15155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env15154 == env15155) = true)

def env15156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,254083,243088,8328,64,97547,139613,238994,336002,119042,272393,257,98814,90202,63189]

theorem envBound15156 : H12AffineFastState.Bounded env15156 := by
  intro p hp
  have h : env15156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15155_15156 : H12AffineEnvironment.transform 20 4160 env15155 = env15156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15155 == env15156) = true)

def env15157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4160,180409,254083,243088,8328,64,97547,139613,238994,67618,119042,169,257,98814,90202,63189]

theorem envBound15157 : H12AffineFastState.Bounded env15157 := by
  intro p hp
  have h : env15157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15156_15157 : H12AffineEnvironment.transform 17 10400 env15156 = env15157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env15156 == env15157) = true)

def env15158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180273,253963,242968,8192,64,97547,139613,238874,67618,119042,33,257,98678,90202,63069]

theorem envBound15158 : H12AffineFastState.Bounded env15158 := by
  intro p hp
  have h : env15158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15157_15158 : H12AffineEnvironment.transform 6 8 env15157 = env15158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15157 == env15158) = true)

theorem identity15158 : scanCanonicalize (H12AffineFastState.compose env15158 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound15158 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4160,95531,21777,2,8192,64,97547,103495,4096,67618,119042,33,257,98678,90202,63069]

theorem envBound15159 : H12AffineFastState.Bounded env15159 := by
  intro p hp
  have h : env15159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15158_15159 : H12AffineEnvironment.transform 16 111898 env15158 = env15159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env15158 == env15159) = true)

theorem identity15159 : scanCanonicalize (H12AffineFastState.compose env15159 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15159 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,103495,2421,1025,32769,4160,87158,21777,2,349,64,89174,103495,4096,67618,119042,33,257,98678,82183,55040]

theorem envBound15160 : H12AffineFastState.Bounded env15160 := by
  intro p hp
  have h : env15160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15159_15160 : H12AffineEnvironment.transform 12 349 env15159 = env15160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15159 == env15160) = true)

theorem identity15160 : scanCanonicalize (H12AffineFastState.compose env15160 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound15160 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,343,38160,2421,1025,32769,4160,21793,21777,2,349,64,23809,38160,4096,2421,53333,33,257,32801,16464,55040]

theorem envBound15161 : H12AffineFastState.Bounded env15161 := by
  intro p hp
  have h : env15161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15160_15161 : H12AffineEnvironment.transform 15 343 env15160 = env15161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env15160 == env15161) = true)

theorem identity15161 : scanCanonicalize (H12AffineFastState.compose env15161 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound15161 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env15162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,343,5440,2421,1025,81,4160,21793,21777,2,349,64,23809,5440,4096,2421,20485,33,257,113,16464,22352]

theorem envBound15162 : H12AffineFastState.Bounded env15162 := by
  intro p hp
  have h : env15162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15161_15162 : H12AffineEnvironment.transform 14 80 env15161 = env15162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env15161 == env15162) = true)

theorem identity15162 : scanCanonicalize (H12AffineFastState.compose env15162 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15162 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15163 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,16384,80,114,5221,2128,1025,81,4160,21508,21556,2,120,64,23588,5221,4096,2128,20485,33,36,113,16464,22133]

theorem envBound15163 : H12AffineFastState.Bounded env15163 := by
  intro p hp
  have h : env15163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15162_15163 : H12AffineEnvironment.transform 7 37 env15162 = env15163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15162 == env15163) = true)

theorem identity15163 : scanCanonicalize (H12AffineFastState.compose env15163 (packedSelected [3,5,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 3124) := by decide +kernel

theorem selectedBound15163 : packedSelected [3,5,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15164 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,120,3124,80,114,5221,2128,1025,81,4160,6192,6144,2,120,64,4112,5221,4096,2128,7217,33,36,113,3172,6721]

theorem envBound15164 : H12AffineFastState.Bounded env15164 := by
  intro p hp
  have h : env15164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15163_15164 : H12AffineEnvironment.transform 13 3124 env15163 = env15164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3124 env15163 == env15164) = true)

theorem identity15164 : scanCanonicalize (H12AffineFastState.compose env15164 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15164 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env15165 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,3124,1,35,5172,2049,1025,0,4113,6192,6144,2,41,17,4112,5172,4096,2049,7217,33,36,32,3125,6672]

theorem envBound15165 : H12AffineFastState.Bounded env15165 := by
  intro p hp
  have h : env15165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15164_15165 : H12AffineEnvironment.transform 5 17 env15164 = env15165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15164 == env15165) = true)

theorem identity15165 : scanCanonicalize (H12AffineFastState.compose env15165 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound15165 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15166 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2064,41,3124,1,35,3108,2049,1025,0,2049,32,16,2,41,17,2048,3108,2064,2049,1057,33,36,32,3125,512]

theorem envBound15166 : H12AffineFastState.Bounded env15166 := by
  intro p hp
  have h : env15166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15165_15166 : H12AffineEnvironment.transform 11 2064 env15165 = env15166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env15165 == env15166) = true)

theorem identity15166 : scanCanonicalize (H12AffineFastState.compose env15166 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound15166 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15167 : List Nat := [2,4,8,16,32,17,8,37,512,20,2048,2064,41,2080,1,35,2096,2049,21,0,2049,32,16,2,41,17,2048,2096,2064,2049,53,33,36,32,2081,512]

theorem envBound15167 : H12AffineFastState.Bounded env15167 := by
  intro p hp
  have h : env15167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15166_15167 : H12AffineEnvironment.transform 9 20 env15166 = env15167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env15166 == env15167) = true)

theorem identity15167 : scanCanonicalize (H12AffineFastState.compose env15167 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15167 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15168 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,2064,8,2049,1,2,2065,2049,21,0,2049,1,16,2,8,17,2048,2065,2064,2049,20,0,5,1,2048,512]

theorem envBound15168 : H12AffineFastState.Bounded env15168 := by
  intro p hp
  have h : env15168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15167_15168 : H12AffineEnvironment.transform 4 1 env15167 = env15168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15167 == env15168) = true)

theorem identity15168 : scanCanonicalize (H12AffineFastState.compose env15168 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15169 : List Nat := [2,4,8,16,1,17,8,4,1,20,2048,2064,8,2049,1,2,2065,2049,21,0,2049,1,16,2,8,17,2048,2065,2064,2049,20,0,5,1,2048,1]

theorem envBound15169 : H12AffineFastState.Bounded env15169 := by
  intro p hp
  have h : env15169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15168_15169 : H12AffineEnvironment.transform 8 1 env15168 = env15169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15168 == env15169) = true)

theorem identity15169 : scanCanonicalize (H12AffineFastState.compose env15169 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound15169 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15170 : List Nat := [2,1,8,16,1,17,8,1,1,17,2048,2064,8,2049,1,2,2065,2049,16,0,2049,1,16,2,8,17,2048,2065,2064,2049,17,0,0,1,2048,1]

theorem envBound15170 : H12AffineFastState.Bounded env15170 := by
  intro p hp
  have h : env15170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15169_15170 : H12AffineEnvironment.transform 1 1 env15169 = env15170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env15169 == env15170) = true)

def env15171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180272,253962,242969,8193,64,97547,139613,238875,67618,119042,32,257,98679,90202,63068]

theorem envBound15171 : H12AffineFastState.Bounded env15171 := by
  intro p hp
  have h : env15171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15157_15171 : H12AffineEnvironment.transform 6 9 env15157 = env15171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15157 == env15171) = true)

theorem identity15171 : scanCanonicalize (H12AffineFastState.compose env15171 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound15171 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10281,1025,32769,4160,119927,62541,41310,8193,64,97547,79130,45404,67618,119042,32,257,98679,90202,63068]

theorem envBound15172 : H12AffineFastState.Bounded env15172 := by
  intro p hp
  have h : env15172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15171_15172 : H12AffineEnvironment.transform 16 70727 env15171 = env15172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env15171 == env15172) = true)

theorem identity15172 : scanCanonicalize (H12AffineFastState.compose env15172 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound15172 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env15173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,70727,10281,1025,29788,4160,73770,16,21763,8193,64,97547,79130,17665,67618,75103,32,257,95530,90202,513]

theorem envBound15173 : H12AffineFastState.Bounded env15173 := by
  intro p hp
  have h : env15173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15172_15173 : H12AffineEnvironment.transform 14 29789 env15172 = env15173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env15172 == env15173) = true)

theorem identity15173 : scanCanonicalize (H12AffineFastState.compose env15173 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 16646) := by decide +kernel

theorem selectedBound15173 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env15174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,16646,21825,10281,1025,29788,4160,24876,16,21763,8193,64,15373,29724,17665,18724,25689,32,257,13356,8540,513]

theorem envBound15174 : H12AffineFastState.Bounded env15174 := by
  intro p hp
  have h : env15174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15173_15174 : H12AffineEnvironment.transform 15 16646 env15173 = env15174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 16646 env15173 == env15174) = true)

theorem identity15174 : scanCanonicalize (H12AffineFastState.compose env15174 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound15174 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env15175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,13658,8477,10281,1025,0,4160,5488,16,8543,8193,64,15373,64,12637,15736,4101,32,257,13356,8540,513]

theorem envBound15175 : H12AffineFastState.Bounded env15175 := by
  intro p hp
  have h : env15175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15174_15175 : H12AffineEnvironment.transform 13 13404 env15174 = env15175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env15174 == env15175) = true)

theorem identity15175 : scanCanonicalize (H12AffineFastState.compose env15175 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound15175 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5132,80,1,342,5393,7205,1025,0,4160,5488,16,5459,5133,64,2049,64,1361,2420,4101,32,257,32,5456,513]

theorem envBound15176 : H12AffineFastState.Bounded env15176 := by
  intro p hp
  have h : env15176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15175_15176 : H12AffineEnvironment.transform 12 5132 env15175 = env15176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env15175 == env15176) = true)

theorem identity15176 : scanCanonicalize (H12AffineFastState.compose env15176 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound15176 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,268,80,1,342,17,2341,1025,0,1344,112,16,83,269,64,2049,64,1361,2420,1285,32,257,32,80,513]

theorem envBound15177 : H12AffineFastState.Bounded env15177 := by
  intro p hp
  have h : env15177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15176_15177 : H12AffineEnvironment.transform 11 1280 env15176 = env15177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env15176 == env15177) = true)

def env15178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4160,180408,254083,243088,8328,64,97547,139613,238994,67619,119042,168,257,98814,90202,63189]

theorem envBound15178 : H12AffineFastState.Bounded env15178 := by
  intro p hp
  have h : env15178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15156_15178 : H12AffineEnvironment.transform 17 10401 env15156 = env15178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15156 == env15178) = true)

def env15179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180272,253963,242968,8192,64,97547,139613,238874,67619,119042,32,257,98678,90202,63069]

theorem envBound15179 : H12AffineFastState.Bounded env15179 := by
  intro p hp
  have h : env15179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15178_15179 : H12AffineEnvironment.transform 6 8 env15178 = env15179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15178 == env15179) = true)

theorem identity15179 : scanCanonicalize (H12AffineFastState.compose env15179 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15179 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1025,32769,4160,169265,242954,242968,8192,64,75786,139613,238874,67619,99331,32,257,98678,79195,41820]

theorem envBound15180 : H12AffineFastState.Bounded env15180 := by
  intro p hp
  have h : env15180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15179_15180 : H12AffineEnvironment.transform 13 5377 env15179 = env15180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15179 == env15180) = true)

theorem identity15180 : scanCanonicalize (H12AffineFastState.compose env15180 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 110602) := by decide +kernel

theorem selectedBound15180 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env15181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,110602,10281,1025,32769,4160,75067,1280,1298,8192,64,75786,102743,5392,67619,99331,32,257,98678,79195,41820]

theorem envBound15181 : H12AffineFastState.Bounded env15181 := by
  intro p hp
  have h : env15181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15180_15181 : H12AffineEnvironment.transform 16 110602 env15180 = env15181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 110602 env15180 == env15181) = true)

theorem identity15181 : scanCanonicalize (H12AffineFastState.compose env15181 (packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15181 : packedSelected [0,3,4,5,7,10,16,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env15182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,69975,10281,1025,8540,4160,75067,1280,1298,8192,64,75786,77834,5392,67619,75102,32,257,73771,79195,513]

theorem envBound15182 : H12AffineFastState.Bounded env15182 := by
  intro p hp
  have h : env15182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15181_15182 : H12AffineEnvironment.transform 14 8541 env15181 = env15182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15181 == env15182) = true)

theorem identity15182 : scanCanonicalize (H12AffineFastState.compose env15182 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 6194) := by decide +kernel

theorem selectedBound15182 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,6194,2405,10281,1025,8540,4160,15625,1280,1298,8192,64,12344,10296,5392,4113,15724,32,257,14361,11625,513]

theorem envBound15183 : H12AffineFastState.Bounded env15183 := by
  intro p hp
  have h : env15183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15182_15183 : H12AffineEnvironment.transform 15 6194 env15182 = env15183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6194 env15182 == env15183) = true)

theorem identity15183 : scanCanonicalize (H12AffineFastState.compose env15183 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound15183 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6201,5377,6500,6194,2405,4112,1025,6501,4160,1328,1280,1298,6201,64,2049,4097,5392,4113,1365,32,257,32,5456,513]

theorem envBound15184 : H12AffineFastState.Bounded env15184 := by
  intro p hp
  have h : env15184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15183_15184 : H12AffineEnvironment.transform 12 6201 env15183 = env15184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env15183 == env15184) = true)

theorem identity15184 : scanCanonicalize (H12AffineFastState.compose env15184 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound15184 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env15185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,357,2396,1124,2049,2391,2405,373,1025,2048,293,1328,1280,1298,2396,64,2049,356,1141,372,1365,32,257,32,1077,513]

theorem envBound15185 : H12AffineFastState.Bounded env15185 := by
  intro p hp
  have h : env15185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15184_15185 : H12AffineEnvironment.transform 11 357 env15184 = env15185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env15184 == env15185) = true)

theorem identity15185 : scanCanonicalize (H12AffineFastState.compose env15185 (packedSelected [2,6,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15185 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env15186 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,16,2089,1124,2049,2082,2064,0,1025,2048,80,1093,1141,1127,2089,64,2049,17,1141,1,1056,32,116,32,1077,513]

theorem envBound15186 : H12AffineFastState.Bounded env15186 := by
  intro p hp
  have h : env15186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15185_15186 : H12AffineEnvironment.transform 7 117 env15185 = env15186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15185 == env15186) = true)

theorem identity15186 : scanCanonicalize (H12AffineFastState.compose env15186 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound15186 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env15187 : List Nat := [2,4,8,16,32,64,8,117,512,1024,81,16,120,1124,80,115,65,0,1025,81,80,1093,1141,1127,120,64,80,17,1141,1,1056,32,116,32,1077,513]

theorem envBound15187 : H12AffineFastState.Bounded env15187 := by
  intro p hp
  have h : env15187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15186_15187 : H12AffineEnvironment.transform 10 81 env15186 = env15187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env15186 == env15187) = true)

theorem identity15187 : scanCanonicalize (H12AffineFastState.compose env15187 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15187 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15188 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,16,40,1076,0,35,17,0,1025,1,0,1045,1061,1079,40,16,0,17,1061,1,1056,32,36,32,1077,513]

theorem envBound15188 : H12AffineFastState.Bounded env15188 := by
  intro p hp
  have h : env15188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15187_15188 : H12AffineEnvironment.transform 5 16 env15187 = env15188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15187 == env15188) = true)

theorem identity15188 : scanCanonicalize (H12AffineFastState.compose env15188 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound15188 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15189 : List Nat := [2,4,8,16,32,16,8,37,512,36,1,16,40,16,0,35,17,0,37,1,0,49,1,19,40,16,0,17,1,1,4,32,36,32,17,513]

theorem envBound15189 : H12AffineFastState.Bounded env15189 := by
  intro p hp
  have h : env15189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15188_15189 : H12AffineEnvironment.transform 9 36 env15188 = env15189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env15188 == env15189) = true)

theorem identity15189 : scanCanonicalize (H12AffineFastState.compose env15189 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15189 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env15190 : List Nat := [2,4,8,1,32,1,8,37,512,36,1,1,40,1,0,35,0,0,37,1,0,32,1,2,40,1,0,0,1,1,4,32,36,32,0,513]

theorem envBound15190 : H12AffineFastState.Bounded env15190 := by
  intro p hp
  have h : env15190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15189_15190 : H12AffineEnvironment.transform 3 1 env15189 = env15190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15189 == env15190) = true)

theorem identity15190 : scanCanonicalize (H12AffineFastState.compose env15190 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15190 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15191 : List Nat := [2,4,8,1,1,1,8,4,512,5,1,1,9,1,0,2,0,0,4,1,0,1,1,2,9,1,0,0,1,1,4,1,5,1,0,513]

theorem envBound15191 : H12AffineFastState.Bounded env15191 := by
  intro p hp
  have h : env15191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15190_15191 : H12AffineEnvironment.transform 4 1 env15190 = env15191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15190 == env15191) = true)

def env15192 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180273,253962,242969,8193,64,97547,139613,238875,67619,119042,33,257,98679,90202,63068]

theorem envBound15192 : H12AffineFastState.Bounded env15192 := by
  intro p hp
  have h : env15192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15178_15192 : H12AffineEnvironment.transform 6 9 env15178 = env15192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15178 == env15192) = true)

theorem identity15192 : scanCanonicalize (H12AffineFastState.compose env15192 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound15192 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15193 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,4160,144492,201815,213316,8193,64,97547,139613,217414,67619,75103,33,257,95530,90202,513]

theorem envBound15193 : H12AffineFastState.Bounded env15193 := by
  intro p hp
  have h : env15193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15192_15193 : H12AffineEnvironment.transform 14 29789 env15192 = env15193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env15192 == env15193) = true)

theorem identity15193 : scanCanonicalize (H12AffineFastState.compose env15193 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound15193 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env15194 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,131072,10280,1025,29788,4160,144492,155997,144462,8193,64,2049,139613,140364,32041,20565,33,257,32,5456,513]

theorem envBound15194 : H12AffineFastState.Bounded env15194 := by
  intro p hp
  have h : env15194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15193_15194 : H12AffineEnvironment.transform 15 29962 env15193 = env15194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env15193 == env15194) = true)

theorem identity15194 : scanCanonicalize (H12AffineFastState.compose env15194 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15194 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env15195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21591,131072,2421,1025,21761,4160,136497,147456,136467,348,64,2049,131072,132369,23668,20565,33,257,32,5456,513]

theorem envBound15195 : H12AffineFastState.Bounded env15195 := by
  intro p hp
  have h : env15195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15194_15195 : H12AffineEnvironment.transform 12 349 env15194 = env15195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15194 == env15195) = true)

theorem identity15195 : scanCanonicalize (H12AffineFastState.compose env15195 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15195 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,131072,2421,1025,0,4160,136497,136449,136467,348,64,2049,131072,132369,2421,1364,33,257,32,5456,513]

theorem envBound15196 : H12AffineFastState.Bounded env15196 := by
  intro p hp
  have h : env15196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15195_15196 : H12AffineEnvironment.transform 13 5377 env15195 = env15196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15195 == env15196) = true)

theorem identity15196 : scanCanonicalize (H12AffineFastState.compose env15196 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound15196 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1025,0,4160,33,17,3,348,64,2049,5392,4097,2421,1364,33,257,32,5456,513]

theorem envBound15197 : H12AffineFastState.Bounded env15197 := by
  intro p hp
  have h : env15197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15196_15197 : H12AffineEnvironment.transform 16 5392 env15196 = env15197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env15196 == env15197) = true)

theorem identity15197 : scanCanonicalize (H12AffineFastState.compose env15197 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3418) := by decide +kernel

theorem selectedBound15197 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3418,349,2139,1,342,2122,2421,1025,0,3354,33,17,3,348,64,2049,2122,3419,2421,1364,33,257,32,2058,513]

theorem envBound15198 : H12AffineFastState.Bounded env15198 := by
  intro p hp
  have h : env15198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15197_15198 : H12AffineEnvironment.transform 11 3418 env15197 = env15198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3418 env15197 == env15198) = true)

theorem identity15198 : scanCanonicalize (H12AffineFastState.compose env15198 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound15198 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15199 : List Nat := [2,4,8,16,32,10,9,256,512,1024,2048,3344,279,2065,1,284,2048,2367,1025,0,3354,33,17,3,278,10,2049,2048,3345,2367,1310,33,257,32,2058,513]

theorem envBound15199 : H12AffineFastState.Bounded env15199 := by
  intro p hp
  have h : env15199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15198_15199 : H12AffineEnvironment.transform 5 10 env15198 = env15199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env15198 == env15199) = true)

theorem identity15199 : scanCanonicalize (H12AffineFastState.compose env15199 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15199 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env15200 : List Nat := [2,4,8,16,0,10,9,256,512,1024,2048,3344,279,2065,1,284,2048,2335,1025,0,3354,1,17,3,278,10,2049,2048,3345,2335,1310,1,257,0,2058,513]

theorem envBound15200 : H12AffineFastState.Bounded env15200 := by
  intro p hp
  have h : env15200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15199_15200 : H12AffineEnvironment.transform 4 0 env15199 = env15200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15199 == env15200) = true)

theorem identity15200 : scanCanonicalize (H12AffineFastState.compose env15200 (packedSelected [5,8,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound15200 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env15201 : List Nat := [2,4,8,10,0,10,9,256,512,1024,2048,3338,269,2059,1,262,2048,2309,1025,0,3328,1,11,3,268,10,2049,2048,3339,2309,1284,1,257,0,2058,513]

theorem envBound15201 : H12AffineFastState.Bounded env15201 := by
  intro p hp
  have h : env15201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15200_15201 : H12AffineEnvironment.transform 3 10 env15200 = env15201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env15200 == env15201) = true)

theorem identity15201 : scanCanonicalize (H12AffineFastState.compose env15201 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound15201 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15202 : List Nat := [2,4,8,10,0,10,9,14,512,1024,2048,3076,3,2059,1,8,2048,2059,1025,0,3086,1,11,3,2,10,2049,2048,3077,2059,1034,1,15,0,2058,513]

theorem envBound15202 : H12AffineFastState.Bounded env15202 := by
  intro p hp
  have h : env15202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15201_15202 : H12AffineEnvironment.transform 7 14 env15201 = env15202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env15201 == env15202) = true)

theorem identity15202 : scanCanonicalize (H12AffineFastState.compose env15202 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound15202 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15203 : List Nat := [2,4,8,10,0,10,9,14,10,1024,2048,3076,3,2059,1,8,2048,2059,1025,0,3086,1,11,3,2,10,2049,2048,3077,2059,1034,1,15,0,2058,11]

theorem envBound15203 : H12AffineFastState.Bounded env15203 := by
  intro p hp
  have h : env15203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15202_15203 : H12AffineEnvironment.transform 8 10 env15202 = env15203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env15202 == env15203) = true)

theorem identity15203 : scanCanonicalize (H12AffineFastState.compose env15203 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound15203 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15204 : List Nat := [2,4,8,10,0,10,9,14,10,1024,9,1037,3,2,1,8,9,2,1025,0,1031,1,11,3,2,10,8,9,1036,2,1034,1,15,0,3,11]

theorem envBound15204 : H12AffineFastState.Bounded env15204 := by
  intro p hp
  have h : env15204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15203_15204 : H12AffineEnvironment.transform 10 9 env15203 = env15204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env15203 == env15204) = true)

theorem identity15204 : scanCanonicalize (H12AffineFastState.compose env15204 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound15204 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15205 : List Nat := [2,4,8,10,0,10,9,14,10,6,9,11,3,2,1,8,9,2,7,0,1,1,11,3,2,10,8,9,10,2,12,1,15,0,3,11]

theorem envBound15205 : H12AffineFastState.Bounded env15205 := by
  intro p hp
  have h : env15205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15204_15205 : H12AffineEnvironment.transform 9 6 env15204 = env15205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env15204 == env15205) = true)

theorem identity15205 : scanCanonicalize (H12AffineFastState.compose env15205 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound15205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15206 : List Nat := [2,4,4,6,0,6,5,2,6,6,5,7,3,2,1,4,5,2,7,0,1,1,7,3,2,6,4,5,6,2,0,1,3,0,3,7]

theorem envBound15206 : H12AffineFastState.Bounded env15206 := by
  intro p hp
  have h : env15206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15205_15206 : H12AffineEnvironment.transform 2 4 env15205 = env15206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env15205 == env15206) = true)

theorem identity15206 : scanCanonicalize (H12AffineFastState.compose env15206 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound15206 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env15207 : List Nat := [0,4,4,4,0,4,5,0,4,4,5,5,1,0,1,4,5,0,5,0,1,1,5,1,0,4,4,5,4,0,0,1,1,0,1,5]

theorem envBound15207 : H12AffineFastState.Bounded env15207 := by
  intro p hp
  have h : env15207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15206_15207 : H12AffineEnvironment.transform 0 0 env15206 = env15207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env15206 == env15207) = true)

def env15208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,254083,243088,8328,64,97547,139612,238995,336002,119042,272392,257,98815,90203,63189]

theorem envBound15208 : H12AffineFastState.Bounded env15208 := by
  intro p hp
  have h : env15208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15155_15208 : H12AffineEnvironment.transform 20 4161 env15155 = env15208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15155 == env15208) = true)

theorem identity15208 : scanCanonicalize (H12AffineFastState.compose env15208 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound15208 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4161,272512,73754,95497,8328,64,97547,57797,91402,336002,119042,272392,257,98815,90203,63189]

theorem envBound15209 : H12AffineFastState.Bounded env15209 := by
  intro p hp
  have h : env15209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15208_15209 : H12AffineEnvironment.transform 16 49305 env15208 = env15209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env15208 == env15209) = true)

def env15210 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4113,272512,73754,95497,8328,16,97547,57749,91402,336002,119042,272392,257,98735,90123,63109]

theorem envBound15210 : H12AffineFastState.Bounded env15210 := by
  intro p hp
  have h : env15210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15209_15210 : H12AffineEnvironment.transform 5 16 env15209 = env15210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15209 == env15210) = true)

theorem identity15210 : scanCanonicalize (H12AffineFastState.compose env15210 (packedSelected [3,15,17,19,24,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound15210 : packedSelected [3,15,17,19,24,31,38] rootPS < 2^1333 := by decide +kernel

def env15211 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10280,1025,32769,4113,168,73754,95497,8328,16,97547,57749,91402,67754,119042,32,257,98735,90123,63109]

theorem envBound15211 : H12AffineFastState.Bounded env15211 := by
  intro p hp
  have h : env15211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15210_15211 : H12AffineEnvironment.transform 17 10280 env15210 = env15211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15210 == env15211) = true)

def env15212 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4112,272512,73754,95497,8328,17,97547,57748,91402,336002,119042,272392,257,98734,90122,63108]

theorem envBound15212 : H12AffineFastState.Bounded env15212 := by
  intro p hp
  have h : env15212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15209_15212 : H12AffineEnvironment.transform 5 17 env15209 = env15212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15209 == env15212) = true)

def env15213 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4112,272392,73754,95497,8192,17,97547,57628,91402,335882,119042,272392,257,98598,90122,62988]

theorem envBound15213 : H12AffineFastState.Bounded env15213 := by
  intro p hp
  have h : env15213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15212_15213 : H12AffineEnvironment.transform 6 8 env15212 = env15213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15212 == env15213) = true)

theorem identity15213 : scanCanonicalize (H12AffineFastState.compose env15213 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound15213 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env15214 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,49169,262144,1025,32769,4112,272392,62492,41231,8192,17,43277,57628,45324,324620,1284,272392,257,21792,46092,62988]

theorem envBound15214 : H12AffineFastState.Bounded env15214 := by
  intro p hp
  have h : env15214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15213_15214 : H12AffineEnvironment.transform 15 54278 env15213 = env15214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env15213 == env15214) = true)

theorem identity15214 : scanCanonicalize (H12AffineFastState.compose env15214 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound15214 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env15215 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,49169,43048,1025,32769,4112,32800,62492,41231,8192,17,43277,57628,45324,23588,1284,32800,257,21792,46092,62988]

theorem envBound15215 : H12AffineFastState.Bounded env15215 := by
  intro p hp
  have h : env15215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15214_15215 : H12AffineEnvironment.transform 17 43048 env15214 = env15215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env15214 == env15215) = true)

theorem identity15215 : scanCanonicalize (H12AffineFastState.compose env15215 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound15215 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15216 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29993,8495,13624,23809,1025,29992,4112,29961,309,21542,8192,17,23588,5173,17445,23588,1284,29961,257,21792,16677,805]

theorem envBound15216 : H12AffineFastState.Bounded env15216 := by
  intro p hp
  have h : env15216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15215_15216 : H12AffineEnvironment.transform 14 29993 env15215 = env15216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env15215 == env15216) = true)

theorem identity15216 : scanCanonicalize (H12AffineFastState.compose env15216 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15216 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env15217 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21540,34,5173,23809,1025,21541,4112,21508,309,21542,269,17,23588,5173,17445,23588,1284,21508,257,21792,16677,805]

theorem envBound15217 : H12AffineFastState.Bounded env15217 := by
  intro p hp
  have h : env15217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15216_15217 : H12AffineEnvironment.transform 12 269 env15216 = env15217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15216 == env15217) = true)

theorem identity15217 : scanCanonicalize (H12AffineFastState.compose env15217 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15217 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15218 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,9,16384,21540,34,5173,23557,1025,21541,4112,21508,49,21542,9,17,23588,5173,17445,23588,1024,21508,5,21540,16417,545]

theorem envBound15218 : H12AffineFastState.Bounded env15218 := by
  intro p hp
  have h : env15218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15217_15218 : H12AffineEnvironment.transform 7 4 env15217 = env15218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15217 == env15218) = true)

theorem identity15218 : scanCanonicalize (H12AffineFastState.compose env15218 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound15218 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15219 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,9,5156,0,34,5173,2081,1025,1,4112,32,49,2,9,17,2048,5173,4097,2048,1024,32,5,0,5125,545]

theorem envBound15219 : H12AffineFastState.Bounded env15219 := by
  intro p hp
  have h : env15219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15218_15219 : H12AffineEnvironment.transform 13 5156 env15218 = env15219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env15218 == env15219) = true)

theorem identity15219 : scanCanonicalize (H12AffineFastState.compose env15219 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound15219 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env15220 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,3102,9,2106,0,34,2091,2081,1025,1,3086,32,49,2,9,17,2048,2091,3103,2048,1024,32,5,0,2075,545]

theorem envBound15220 : H12AffineFastState.Bounded env15220 := by
  intro p hp
  have h : env15220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15219_15220 : H12AffineEnvironment.transform 11 3102 env15219 = env15220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env15219 == env15220) = true)

theorem identity15220 : scanCanonicalize (H12AffineFastState.compose env15220 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15220 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env15221 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,3102,9,2074,0,2,2059,2049,1025,1,3086,0,17,2,9,17,2048,2059,3103,2048,1024,0,5,0,2075,513]

theorem envBound15221 : H12AffineFastState.Bounded env15221 := by
  intro p hp
  have h : env15221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15220_15221 : H12AffineEnvironment.transform 4 0 env15220 = env15221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15220 == env15221) = true)

theorem identity15221 : scanCanonicalize (H12AffineFastState.compose env15221 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15221 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15222 : List Nat := [2,4,8,0,0,1,8,4,512,1024,2048,3086,9,2058,0,2,2059,2049,1025,1,3086,0,1,2,9,1,2048,2059,3087,2048,1024,0,5,0,2059,513]

theorem envBound15222 : H12AffineFastState.Bounded env15222 := by
  intro p hp
  have h : env15222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15221_15222 : H12AffineEnvironment.transform 3 0 env15221 = env15222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15221 == env15222) = true)

theorem identity15222 : scanCanonicalize (H12AffineFastState.compose env15222 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound15222 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15223 : List Nat := [2,4,8,0,0,1,8,4,512,1024,1541,523,9,1551,0,2,1550,1540,1025,1,523,0,1,2,9,1,1541,1550,522,1541,1024,0,5,0,1550,513]

theorem envBound15223 : H12AffineFastState.Bounded env15223 := by
  intro p hp
  have h : env15223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15222_15223 : H12AffineEnvironment.transform 10 1541 env15222 = env15223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env15222 == env15223) = true)

theorem identity15223 : scanCanonicalize (H12AffineFastState.compose env15223 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound15223 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15224 : List Nat := [2,3,8,0,0,1,8,3,512,1024,1538,523,9,1544,0,2,1545,1539,1025,1,523,0,1,2,9,1,1538,1545,522,1538,1024,0,2,0,1545,513]

theorem envBound15224 : H12AffineFastState.Bounded env15224 := by
  intro p hp
  have h : env15224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15223_15224 : H12AffineEnvironment.transform 1 3 env15223 = env15224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env15223 == env15224) = true)

theorem identity15224 : scanCanonicalize (H12AffineFastState.compose env15224 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15224 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env15225 : List Nat := [2,3,3,0,0,1,3,3,512,1024,1538,512,2,1539,0,2,1538,1539,1025,1,512,0,1,2,2,1,1538,1538,513,1538,1024,0,2,0,1538,513]

theorem envBound15225 : H12AffineFastState.Bounded env15225 := by
  intro p hp
  have h : env15225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15224_15225 : H12AffineEnvironment.transform 2 3 env15224 = env15225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15224 == env15225) = true)

def env15226 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4112,272393,73754,95497,8193,17,97547,57629,91402,335883,119042,272392,257,98599,90122,62989]

theorem envBound15226 : H12AffineFastState.Bounded env15226 := by
  intro p hp
  have h : env15226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15212_15226 : H12AffineEnvironment.transform 6 9 env15212 = env15226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15212 == env15226) = true)

theorem identity15226 : scanCanonicalize (H12AffineFastState.compose env15226 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound15226 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env15227 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40971,49168,262144,1025,32769,4112,272393,32785,54530,8193,17,56576,57629,50433,294912,28937,272392,257,8492,49153,62989]

theorem envBound15227 : H12AffineFastState.Bounded env15227 := by
  intro p hp
  have h : env15227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15226_15227 : H12AffineEnvironment.transform 15 40971 env15226 = env15227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env15226 == env15227) = true)

theorem identity15227 : scanCanonicalize (H12AffineFastState.compose env15227 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15227 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env15228 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,33030,49168,262144,1025,32769,4112,264452,32785,54530,268,17,56576,49168,50433,294912,20484,264453,257,33,49153,55040]

theorem envBound15228 : H12AffineFastState.Bounded env15228 := by
  intro p hp
  have h : env15228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15227_15228 : H12AffineEnvironment.transform 12 269 env15227 = env15228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15227 == env15228) = true)

theorem identity15228 : scanCanonicalize (H12AffineFastState.compose env15228 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound15228 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env15229 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,33030,49168,23588,1025,32769,4112,21792,32785,54530,268,17,56576,49168,50433,56356,20484,21793,257,33,49153,55040]

theorem envBound15229 : H12AffineFastState.Bounded env15229 := by
  intro p hp
  have h : env15229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15228_15229 : H12AffineEnvironment.transform 17 23588 env15228 = env15229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env15228 == env15229) = true)

theorem identity15229 : scanCanonicalize (H12AffineFastState.compose env15229 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound15229 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15230 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21761,21511,5393,23588,1025,21760,4112,21792,21776,3,268,17,2049,5393,4096,2341,20484,21793,257,33,5376,513]

theorem envBound15230 : H12AffineFastState.Bounded env15230 := by
  intro p hp
  have h : env15230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15229_15230 : H12AffineEnvironment.transform 14 21761 env15229 = env15230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env15229 == env15230) = true)

theorem identity15230 : scanCanonicalize (H12AffineFastState.compose env15230 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15230 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env15231 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,263,5393,2340,1025,0,4112,32,16,3,268,17,2049,5393,4096,2341,1284,33,257,33,5376,513]

theorem envBound15231 : H12AffineFastState.Bounded env15231 := by
  intro p hp
  have h : env15231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15230_15231 : H12AffineEnvironment.transform 13 5376 env15230 = env15231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15230 == env15231) = true)

theorem identity15231 : scanCanonicalize (H12AffineFastState.compose env15231 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15232 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4404,1,263,4389,2340,53,0,4112,32,16,3,268,17,2049,4389,4096,2341,304,33,257,33,4404,513]

theorem envBound15232 : H12AffineFastState.Bounded env15232 := by
  intro p hp
  have h : env15232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15231_15232 : H12AffineEnvironment.transform 9 52 env15231 = env15232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15231 == env15232) = true)

theorem identity15232 : scanCanonicalize (H12AffineFastState.compose env15232 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15232 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15233 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,1,34,4096,2049,53,0,4112,32,16,3,41,17,2049,4096,4096,2048,21,33,36,33,4113,513]

theorem envBound15233 : H12AffineFastState.Bounded env15233 := by
  intro p hp
  have h : env15233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15232_15233 : H12AffineEnvironment.transform 7 37 env15232 = env15233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15232 == env15233) = true)

theorem identity15233 : scanCanonicalize (H12AffineFastState.compose env15233 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound15233 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15234 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2577,40,2560,1,34,2577,2049,53,0,2561,32,16,3,41,17,2049,2577,2577,2048,21,33,36,33,2560,513]

theorem envBound15234 : H12AffineFastState.Bounded env15234 := by
  intro p hp
  have h : env15234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15233_15234 : H12AffineEnvironment.transform 11 2577 env15233 = env15234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env15233 == env15234) = true)

theorem identity15234 : scanCanonicalize (H12AffineFastState.compose env15234 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound15234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15235 : List Nat := [2,4,8,16,32,17,9,37,512,52,58,555,40,570,1,34,555,59,53,0,571,32,16,3,41,17,59,555,555,58,21,33,36,33,570,513]

theorem envBound15235 : H12AffineFastState.Bounded env15235 := by
  intro p hp
  have h : env15235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15234_15235 : H12AffineEnvironment.transform 10 58 env15234 = env15235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env15234 == env15235) = true)

theorem identity15235 : scanCanonicalize (H12AffineFastState.compose env15235 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound15235 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15236 : List Nat := [2,4,8,16,26,17,9,31,512,14,0,529,18,512,1,24,529,1,15,0,513,26,16,3,19,17,1,529,529,0,21,27,30,27,512,513]

theorem envBound15236 : H12AffineFastState.Bounded env15236 := by
  intro p hp
  have h : env15236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15235_15236 : H12AffineEnvironment.transform 4 26 env15235 = env15236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env15235 == env15236) = true)

theorem identity15236 : scanCanonicalize (H12AffineFastState.compose env15236 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15236 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15237 : List Nat := [2,4,8,16,26,17,9,31,1,14,0,16,18,1,1,24,16,1,15,0,0,26,16,3,19,17,1,16,16,0,21,27,30,27,1,0]

theorem envBound15237 : H12AffineFastState.Bounded env15237 := by
  intro p hp
  have h : env15237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15236_15237 : H12AffineEnvironment.transform 8 1 env15236 = env15237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15236 == env15237) = true)

def env15238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254083,243089,8328,64,97546,2240796,2340306,336002,119043,2373704,257,2199999,2191387,63188]

theorem envBound15238 : H12AffineFastState.Bounded env15238 := by
  intro p hp
  have h : env15238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15154_15238 : H12AffineEnvironment.transform 23 243089 env15154 = env15238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env15154 == env15238) = true)

def env15239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,254083,243089,8328,64,97546,139612,238994,336002,119043,272392,257,98815,90203,63188]

theorem envBound15239 : H12AffineFastState.Bounded env15239 := by
  intro p hp
  have h : env15239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15238_15239 : H12AffineEnvironment.transform 20 4160 env15238 = env15239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15238 == env15239) = true)

theorem identity15239 : scanCanonicalize (H12AffineFastState.compose env15239 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound15239 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318549,120015,98781,8328,64,97546,5392,102878,336002,119043,272392,257,98815,90203,63188]

theorem envBound15240 : H12AffineFastState.Bounded env15240 := by
  intro p hp
  have h : env15240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15239_15240 : H12AffineEnvironment.transform 16 13388 env15239 = env15240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env15239 == env15240) = true)

def env15241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10400,1025,32769,4160,62709,120015,98781,8328,64,97546,5392,102878,67618,119043,168,257,98815,90203,63188]

theorem envBound15241 : H12AffineFastState.Bounded env15241 := by
  intro p hp
  have h : env15241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15240_15241 : H12AffineEnvironment.transform 17 10400 env15240 = env15241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env15240 == env15241) = true)

theorem identity15241 : scanCanonicalize (H12AffineFastState.compose env15241 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 62591) := by decide +kernel

theorem selectedBound15241 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env15242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62591,13388,10400,1025,32769,4160,62709,8368,30114,8328,64,35189,5392,26017,64605,9596,168,257,30080,37924,63188]

theorem envBound15242 : H12AffineFastState.Bounded env15242 := by
  intro p hp
  have h : env15242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15241_15242 : H12AffineEnvironment.transform 15 62591 env15241 = env15242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62591 env15241 == env15242) = true)

theorem identity15242 : scanCanonicalize (H12AffineFastState.compose env15242 (packedSelected [0,2,6,7,14,16,23,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound15242 : packedSelected [0,2,6,7,14,16,23,32,35] rootPS < 2^1333 := by decide +kernel

def env15243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,32768,41091,13388,10400,1025,32769,4160,40969,8368,8542,8328,64,35189,5392,12637,43169,9596,168,257,8572,37924,41512]

theorem envBound15243 : H12AffineFastState.Bounded env15243 := by
  intro p hp
  have h : env15243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15242_15243 : H12AffineEnvironment.transform 13 5372 env15242 = env15243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env15242 == env15243) = true)

theorem identity15243 : scanCanonicalize (H12AffineFastState.compose env15243 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15243 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env15244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,1,8322,13388,10400,1025,0,4160,8200,8368,8542,8328,64,2420,5392,12637,10400,9596,168,257,8572,5157,8745]

theorem envBound15244 : H12AffineFastState.Bounded env15244 := by
  intro p hp
  have h : env15244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15243_15244 : H12AffineEnvironment.transform 14 1 env15243 = env15244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15243 == env15244) = true)

theorem identity15244 : scanCanonicalize (H12AffineFastState.compose env15244 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15244 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env15245 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5372,1,8322,13388,10400,1025,0,4160,8200,8368,8234,8328,64,2048,5220,12329,10400,9224,168,117,8200,5157,8745]

theorem envBound15245 : H12AffineFastState.Bounded env15245 := by
  intro p hp
  have h : env15245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15244_15245 : H12AffineEnvironment.transform 7 116 env15244 = env15245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15244 == env15245) = true)

def env15246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10401,1025,32769,4160,62708,120015,98781,8328,64,97546,5392,102878,67619,119043,169,257,98815,90203,63188]

theorem envBound15246 : H12AffineFastState.Bounded env15246 := by
  intro p hp
  have h : env15246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15240_15246 : H12AffineEnvironment.transform 17 10401 env15240 = env15246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15240 == env15246) = true)

theorem identity15246 : scanCanonicalize (H12AffineFastState.compose env15246 (packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound15246 : packedSelected [2,5,6,9,11,15,19,22,23,24,35,41] rootPS < 2^1333 := by decide +kernel

def env15247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,13388,10401,1025,136,4160,29821,87110,65876,8328,64,97546,5392,69975,67619,86410,169,257,65910,90203,30301]

theorem envBound15247 : H12AffineFastState.Bounded env15247 := by
  intro p hp
  have h : env15247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15246_15247 : H12AffineEnvironment.transform 14 137 env15246 = env15247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env15246 == env15247) = true)

theorem identity15247 : scanCanonicalize (H12AffineFastState.compose env15247 (packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound15247 : packedSelected [0,4,7,11,16,17,19,20,22,26,32] rootPS < 2^1333 := by decide +kernel

def env15248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,137,65536,5529,2420,1025,136,4160,21928,87110,65876,349,64,89311,5392,69975,67619,86410,169,257,65910,82318,22408]

theorem envBound15248 : H12AffineFastState.Bounded env15248 := by
  intro p hp
  have h : env15248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15247_15248 : H12AffineEnvironment.transform 12 469 env15247 = env15248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env15247 == env15248) = true)

theorem identity15248 : scanCanonicalize (H12AffineFastState.compose env15248 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15248 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,137,65536,5529,2420,1025,136,4160,168,65862,65876,349,64,68063,5392,69975,67619,66698,169,257,65910,70798,648]

theorem envBound15249 : H12AffineFastState.Bounded env15249 := by
  intro p hp
  have h : env15249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15248_15249 : H12AffineEnvironment.transform 13 5376 env15248 = env15249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15248 == env15249) = true)

theorem identity15249 : scanCanonicalize (H12AffineFastState.compose env15249 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound15249 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,137,262,5529,2420,1025,136,4160,168,64,82,349,64,2265,5392,4177,2341,1420,169,257,112,5512,648]

theorem envBound15250 : H12AffineFastState.Bounded env15250 := by
  intro p hp
  have h : env15250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15249_15250 : H12AffineEnvironment.transform 15 262 env15249 = env15250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env15249 == env15250) = true)

theorem identity15250 : scanCanonicalize (H12AffineFastState.compose env15250 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15250 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env15251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,262,5392,2420,1025,1,4160,33,64,82,349,64,2128,5392,4177,2341,1285,32,257,112,5377,513]

theorem envBound15251 : H12AffineFastState.Bounded env15251 := by
  intro p hp
  have h : env15251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15250_15251 : H12AffineEnvironment.transform 6 9 env15250 = env15251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15250 == env15251) = true)

theorem identity15251 : scanCanonicalize (H12AffineFastState.compose env15251 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15251 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15252 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,262,5392,2341,1025,1,4113,33,17,3,268,17,2049,5392,4096,2341,1285,32,257,33,5377,513]

theorem envBound15252 : H12AffineFastState.Bounded env15252 := by
  intro p hp
  have h : env15252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15251_15252 : H12AffineEnvironment.transform 5 17 env15251 = env15252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15251 == env15252) = true)

theorem identity15252 : scanCanonicalize (H12AffineFastState.compose env15252 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound15252 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15253 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,276,269,1044,0,262,1028,2341,1025,1,261,33,17,3,268,17,2049,1028,276,2341,1285,32,257,33,1045,513]

theorem envBound15253 : H12AffineFastState.Bounded env15253 := by
  intro p hp
  have h : env15253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15252_15253 : H12AffineEnvironment.transform 11 276 env15252 = env15253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env15252 == env15253) = true)

theorem identity15253 : scanCanonicalize (H12AffineFastState.compose env15253 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound15253 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15254 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,276,269,292,0,262,308,2341,305,1,261,33,17,3,268,17,2049,308,276,2341,53,32,257,33,293,513]

theorem envBound15254 : H12AffineFastState.Bounded env15254 := by
  intro p hp
  have h : env15254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15253_15254 : H12AffineEnvironment.transform 9 304 env15253 = env15254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env15253 == env15254) = true)

theorem identity15254 : scanCanonicalize (H12AffineFastState.compose env15254 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound15254 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15255 : List Nat := [2,4,8,16,32,17,9,256,293,304,2048,276,269,292,0,262,308,2341,305,1,261,33,17,3,268,17,2049,308,276,2341,53,32,257,33,293,292]

theorem envBound15255 : H12AffineFastState.Bounded env15255 := by
  intro p hp
  have h : env15255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15254_15255 : H12AffineEnvironment.transform 8 293 env15254 = env15255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env15254 == env15255) = true)

theorem identity15255 : scanCanonicalize (H12AffineFastState.compose env15255 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound15255 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15256 : List Nat := [2,4,8,16,16,17,9,256,277,256,2048,276,269,276,0,262,260,2325,257,1,261,17,17,3,268,17,2049,260,276,2325,5,16,257,17,277,276]

theorem envBound15256 : H12AffineFastState.Bounded env15256 := by
  intro p hp
  have h : env15256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15255_15256 : H12AffineEnvironment.transform 4 16 env15255 = env15256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env15255 == env15256) = true)

theorem identity15256 : scanCanonicalize (H12AffineFastState.compose env15256 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound15256 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15257 : List Nat := [2,4,8,16,16,17,9,256,277,256,16,276,269,276,0,262,260,261,257,1,261,17,17,3,268,17,17,260,276,261,5,16,257,17,277,276]

theorem envBound15257 : H12AffineFastState.Bounded env15257 := by
  intro p hp
  have h : env15257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15256_15257 : H12AffineEnvironment.transform 10 16 env15256 = env15257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env15256 == env15257) = true)

def env15258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,254083,243089,8328,64,97546,139613,238995,336002,119043,272393,257,98814,90202,63188]

theorem envBound15258 : H12AffineFastState.Bounded env15258 := by
  intro p hp
  have h : env15258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15238_15258 : H12AffineEnvironment.transform 20 4161 env15238 = env15258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15238 == env15258) = true)

theorem identity15258 : scanCanonicalize (H12AffineFastState.compose env15258 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound15258 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,400588,201814,213316,8328,64,97546,139613,217414,336002,75222,272393,257,95531,90202,513]

theorem envBound15259 : H12AffineFastState.Bounded env15259 := by
  intro p hp
  have h : env15259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15258_15259 : H12AffineEnvironment.transform 14 29909 env15258 = env15259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env15258 == env15259) = true)

def env15260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,400452,201814,213316,8192,64,97546,139613,217414,335882,75102,272393,257,95531,90202,513]

theorem envBound15260 : H12AffineFastState.Bounded env15260 := by
  intro p hp
  have h : env15260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15259_15260 : H12AffineEnvironment.transform 6 8 env15259 = env15260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15259 == env15260) = true)

theorem identity15260 : scanCanonicalize (H12AffineFastState.compose env15260 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound15260 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1025,29788,4161,359519,29773,8543,8192,64,97546,82246,12637,335882,75102,272393,257,95531,90202,513]

theorem envBound15261 : H12AffineFastState.Bounded env15261 := by
  intro p hp
  have h : env15261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15260_15261 : H12AffineEnvironment.transform 16 90139 env15260 = env15261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env15260 == env15261) = true)

theorem identity15261 : scanCanonicalize (H12AffineFastState.compose env15261 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 76911) := by decide +kernel

theorem selectedBound15261 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,76911,1025,29788,4161,20528,29773,8543,8192,64,97546,82246,12637,3173,75102,66662,257,95531,90202,513]

theorem envBound15262 : H12AffineFastState.Bounded env15262 := by
  intro p hp
  have h : env15262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15261_15262 : H12AffineEnvironment.transform 17 76911 env15261 = env15262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76911 env15261 == env15262) = true)

theorem identity15262 : scanCanonicalize (H12AffineFastState.compose env15262 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15262 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15263 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16401,3173,1025,29788,4161,20528,29773,8543,8192,64,23808,24908,12637,3173,1364,9324,257,21793,16464,513]

theorem envBound15263 : H12AffineFastState.Bounded env15263 := by
  intro p hp
  have h : env15263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15262_15263 : H12AffineEnvironment.transform 15 8202 env15262 = env15263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15262 == env15263) = true)

theorem identity15263 : scanCanonicalize (H12AffineFastState.compose env15263 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15263 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5393,3173,1025,8540,4161,1328,8525,8543,8192,64,2048,13388,12637,3173,1364,9324,257,33,5456,513]

theorem envBound15264 : H12AffineFastState.Bounded env15264 := by
  intro p hp
  have h : env15264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15263_15264 : H12AffineEnvironment.transform 13 5376 env15263 = env15264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15263 == env15264) = true)

theorem identity15264 : scanCanonicalize (H12AffineFastState.compose env15264 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound15264 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15265 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1296,1095,5393,3173,1025,1297,4161,1328,1280,1298,1101,64,2048,4097,5392,3173,1364,33,257,33,5456,513]

theorem envBound15265 : H12AffineFastState.Bounded env15265 := by
  intro p hp
  have h : env15265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15264_15265 : H12AffineEnvironment.transform 12 1101 env15264 = env15265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env15264 == env15265) = true)

theorem identity15265 : scanCanonicalize (H12AffineFastState.compose env15265 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound15265 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env15266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1101,81,1296,1095,64,3173,1025,1297,1296,1328,1280,1298,1101,64,2048,1360,65,3173,1364,33,257,33,1,513]

theorem envBound15266 : H12AffineFastState.Bounded env15266 := by
  intro p hp
  have h : env15266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15265_15266 : H12AffineEnvironment.transform 11 1361 env15265 = env15266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env15265 == env15266) = true)

theorem identity15266 : scanCanonicalize (H12AffineFastState.compose env15266 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15266 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15267 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,1101,81,1076,1095,64,3173,1025,1077,1076,1044,1060,1078,1101,64,2048,1140,65,3173,1136,33,37,33,1,513]

theorem envBound15267 : H12AffineFastState.Bounded env15267 := by
  intro p hp
  have h : env15267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15266_15267 : H12AffineEnvironment.transform 7 36 env15266 = env15267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15266 == env15267) = true)

theorem identity15267 : scanCanonicalize (H12AffineFastState.compose env15267 (packedSelected [2,6,12] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound15267 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env15268 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1077,1141,1101,81,1076,1095,64,80,1025,1077,1076,1044,1060,1078,1101,64,1077,1140,65,80,1136,33,37,33,1,513]

theorem envBound15268 : H12AffineFastState.Bounded env15268 := by
  intro p hp
  have h : env15268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15267_15268 : H12AffineEnvironment.transform 10 1077 env15267 = env15268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env15267 == env15268) = true)

theorem identity15268 : scanCanonicalize (H12AffineFastState.compose env15268 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15268 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env15269 : List Nat := [2,4,8,16,32,64,8,36,512,52,1,65,121,81,0,115,64,80,53,1,0,32,16,2,121,64,1,64,65,80,68,33,37,33,1,513]

theorem envBound15269 : H12AffineFastState.Bounded env15269 := by
  intro p hp
  have h : env15269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15268_15269 : H12AffineEnvironment.transform 9 52 env15268 = env15269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15268 == env15269) = true)

def env15270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,400453,201814,213316,8193,64,97546,139613,217414,335883,75103,272393,257,95531,90202,513]

theorem envBound15270 : H12AffineFastState.Bounded env15270 := by
  intro p hp
  have h : env15270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15259_15270 : H12AffineEnvironment.transform 6 9 env15259 = env15270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15259 == env15270) = true)

theorem identity15270 : scanCanonicalize (H12AffineFastState.compose env15270 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound15270 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,4161,156013,201814,213316,8193,64,97546,139613,217414,89379,75103,21793,257,95531,90202,513]

theorem envBound15271 : H12AffineFastState.Bounded env15271 := by
  intro p hp
  have h : env15271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15270_15271 : H12AffineEnvironment.transform 17 32040 env15270 = env15271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env15270 == env15271) = true)

theorem identity15271 : scanCanonicalize (H12AffineFastState.compose env15271 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15271 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env15272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,131072,23668,1025,21761,4161,147505,201814,213316,349,64,89174,131073,217414,89379,66563,21793,257,87159,82182,513]

theorem envBound15272 : H12AffineFastState.Bounded env15272 := by
  intro p hp
  have h : env15272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15271_15272 : H12AffineEnvironment.transform 12 348 env15271 = env15272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15271 == env15272) = true)

theorem identity15272 : scanCanonicalize (H12AffineFastState.compose env15272 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound15272 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,342,131072,23668,1025,21761,4161,147505,136448,147474,349,64,23808,131073,151568,23669,1365,21793,257,21793,16464,513]

theorem envBound15273 : H12AffineFastState.Bounded env15273 := by
  intro p hp
  have h : env15273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15272_15273 : H12AffineEnvironment.transform 15 342 env15272 = env15273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env15272 == env15273) = true)

theorem identity15273 : scanCanonicalize (H12AffineFastState.compose env15273 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15273 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15274 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,262,131072,23588,1025,21761,4113,147505,136448,147474,269,16,23808,131073,151568,23589,1285,21793,257,21793,16384,513]

theorem envBound15274 : H12AffineFastState.Bounded env15274 := by
  intro p hp
  have h : env15274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15273_15274 : H12AffineEnvironment.transform 5 16 env15273 = env15274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15273 == env15274) = true)

theorem identity15274 : scanCanonicalize (H12AffineFastState.compose env15274 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15274 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15275 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,131072,2340,1025,1,4113,136497,136448,136466,269,16,2048,131073,132368,2341,1285,33,257,33,5376,513]

theorem envBound15275 : H12AffineFastState.Bounded env15275 := by
  intro p hp
  have h : env15275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15274_15275 : H12AffineEnvironment.transform 13 5376 env15274 = env15275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15274 == env15275) = true)

theorem identity15275 : scanCanonicalize (H12AffineFastState.compose env15275 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound15275 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env15276 : List Nat := [2,4,8,16,32,16,9,256,512,1024,309,4096,268,5376,0,262,131072,17,1025,1,4113,136497,136448,136466,269,16,309,131073,132368,16,1285,33,257,33,5376,513]

theorem envBound15276 : H12AffineFastState.Bounded env15276 := by
  intro p hp
  have h : env15276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15275_15276 : H12AffineEnvironment.transform 10 309 env15275 = env15276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env15275 == env15276) = true)

theorem identity15276 : scanCanonicalize (H12AffineFastState.compose env15276 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 1077) := by decide +kernel

theorem selectedBound15276 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15277 : List Nat := [2,4,8,16,32,16,9,256,512,1024,309,4096,268,5376,0,262,1077,17,1025,1,4113,4356,4405,4391,269,16,309,1076,293,16,1285,33,257,33,5376,513]

theorem envBound15277 : H12AffineFastState.Bounded env15277 := by
  intro p hp
  have h : env15277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15276_15277 : H12AffineEnvironment.transform 16 1077 env15276 = env15277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1077 env15276 == env15277) = true)

def env15278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356289,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound15278 : H12AffineFastState.Bounded env15278 := by
  intro p hp
  have h : env15278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14987_15278 : H12AffineEnvironment.transform 26 30393345 env14987 = env15278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env14987 == env15278) = true)

def env15279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound15279 : H12AffineFastState.Bounded env15279 := by
  intro p hp
  have h : env15279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15278_15279 : H12AffineEnvironment.transform 18 1024 env15278 = env15279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env15278 == env15279) = true)

theorem identity15279 : scanCanonicalize (H12AffineFastState.compose env15279 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 91587) := by decide +kernel

theorem selectedBound15279 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,16777216,8328,64,29868033,16834895,8466578,8830977,25265169,20971522,256,25207150,25182410,25207751]

theorem envBound15280 : H12AffineFastState.Bounded env15280 := by
  intro p hp
  have h : env15280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15279_15280 : H12AffineEnvironment.transform 20 91587 env15279 = env15280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91587 env15279 == env15280) = true)

def env15281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,119892,8328,64,12981333,79131,8466578,8830977,8409157,4314198,256,8484154,8492190,8484755]

theorem envBound15281 : H12AffineFastState.Bounded env15281 := by
  intro p hp
  have h : env15281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15280_15281 : H12AffineEnvironment.transform 23 119892 env15280 = env15281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119892 env15280 == env15281) = true)

def env15282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98644,8328,64,12981333,79131,8466578,8819969,8389957,4292950,256,8462394,8492190,8462995]

theorem envBound15282 : H12AffineFastState.Bounded env15282 := by
  intro p hp
  have h : env15282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15281_15282 : H12AffineEnvironment.transform 13 5376 env15281 = env15282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15281 == env15282) = true)

def env15283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,8388608,98644,8328,64,8787061,79131,8466578,8819969,8389957,98678,256,8462394,8492190,8462995]

theorem envBound15283 : H12AffineFastState.Bounded env15283 := by
  intro p hp
  have h : env15283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15282_15283 : H12AffineEnvironment.transform 21 32 env15282 = env15283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15282 == env15283) = true)

theorem identity15283 : scanCanonicalize (H12AffineFastState.compose env15283 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15283 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,78019,32,8388608,73736,8328,64,8787061,79131,8466578,8795229,8389957,73770,256,8462394,8467906,8462995]

theorem envBound15284 : H12AffineFastState.Bounded env15284 := by
  intro p hp
  have h : env15284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15283_15284 : H12AffineEnvironment.transform 14 8540 env15283 = env15284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15283 == env15284) = true)

def env15285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10400,1024,8541,78019,32,8388608,73736,8328,64,8535253,79131,8466578,8527101,8389957,73770,256,8462394,8467906,8462995]

theorem envBound15285 : H12AffineFastState.Bounded env15285 := by
  intro p hp
  have h : env15285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15284_15285 : H12AffineEnvironment.transform 17 10400 env15284 = env15285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env15284 == env15285) = true)

theorem identity15285 : scanCanonicalize (H12AffineFastState.compose env15285 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound15285 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,131072,10400,1024,8541,4161,32,8388608,138,8328,64,8535253,5529,8392720,8527101,8389957,168,256,8388792,8394048,8389137]

theorem envBound15286 : H12AffineFastState.Bounded env15286 := by
  intro p hp
  have h : env15286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15285_15286 : H12AffineEnvironment.transform 15 8322 env15285 = env15286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env15285 == env15286) = true)

theorem identity15286 : scanCanonicalize (H12AffineFastState.compose env15286 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound15286 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,5529,10400,1024,8541,4161,32,8388608,138,8328,64,8399180,5529,8392720,8391012,8389957,168,256,8388792,8394048,8389137]

theorem envBound15287 : H12AffineFastState.Bounded env15287 := by
  intro p hp
  have h : env15287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15286_15287 : H12AffineEnvironment.transform 16 5529 env15286 = env15287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env15286 == env15287) = true)

theorem identity15287 : scanCanonicalize (H12AffineFastState.compose env15287 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 8477) := by decide +kernel

theorem selectedBound15287 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env15288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,5529,10400,1024,8541,4161,32,8477,138,8328,64,2129,5529,12557,10361,9304,168,256,8613,13405,8972]

theorem envBound15288 : H12AffineFastState.Bounded env15288 := by
  intro p hp
  have h : env15288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15287_15288 : H12AffineEnvironment.transform 22 8477 env15287 = env15288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8477 env15287 == env15288) = true)

theorem identity15288 : scanCanonicalize (H12AffineFastState.compose env15288 (packedSelected [0,1,3,4,5,7,8,11,12,14,15,18,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15288 : packedSelected [0,1,3,4,5,7,8,11,12,14,15,18,20,22] rootPS < 2^1333 := by decide +kernel

def env15289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10280,1024,8541,4161,32,8477,2,8192,64,2129,5393,12557,10361,9304,32,256,8493,13405,8972]

theorem envBound15289 : H12AffineFastState.Bounded env15289 := by
  intro p hp
  have h : env15289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15288_15289 : H12AffineEnvironment.transform 6 8 env15288 = env15289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15288 == env15289) = true)

def env15290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,78019,32,8388608,73736,8328,64,8535252,79131,8466578,8527100,8389957,73770,256,8462394,8467906,8462995]

theorem envBound15290 : H12AffineFastState.Bounded env15290 := by
  intro p hp
  have h : env15290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15284_15290 : H12AffineEnvironment.transform 17 10401 env15284 = env15290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15284 == env15290) = true)

theorem identity15290 : scanCanonicalize (H12AffineFastState.compose env15290 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73874) := by decide +kernel

theorem selectedBound15290 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,78019,32,73874,73736,8328,64,203846,79131,4096,212078,75223,73770,256,168,5456,513]

theorem envBound15291 : H12AffineFastState.Bounded env15291 := by
  intro p hp
  have h : env15291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15290_15291 : H12AffineEnvironment.transform 22 73874 env15290 = env15291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73874 env15290 == env15291) = true)

theorem identity15291 : scanCanonicalize (H12AffineFastState.compose env15291 (packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound15291 : packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env15292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,13388,10401,1024,8541,78019,32,73874,73736,8328,64,75786,79131,4096,67618,75223,73770,256,168,5456,513]

theorem envBound15292 : H12AffineFastState.Bounded env15292 := by
  intro p hp
  have h : env15292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15291_15292 : H12AffineEnvironment.transform 16 13388 env15291 = env15292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env15291 == env15292) = true)

theorem identity15292 : scanCanonicalize (H12AffineFastState.compose env15292 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound15292 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env15293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,136,65536,5528,2421,1024,137,69911,32,65862,66012,348,64,68062,70863,4096,67618,66563,66046,256,168,5456,513]

theorem envBound15293 : H12AffineFastState.Bounded env15293 := by
  intro p hp
  have h : env15293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15292_15293 : H12AffineEnvironment.transform 12 468 env15292 = env15293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env15292 == env15293) = true)

theorem identity15293 : scanCanonicalize (H12AffineFastState.compose env15293 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound15293 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env15294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,136,478,5528,2421,1024,137,4297,32,152,2,348,64,2048,5393,4096,2556,1501,32,256,168,5456,513]

theorem envBound15294 : H12AffineFastState.Bounded env15294 := by
  intro p hp
  have h : env15294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15293_15294 : H12AffineEnvironment.transform 15 478 env15293 = env15294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env15293 == env15294) = true)

theorem identity15294 : scanCanonicalize (H12AffineFastState.compose env15294 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound15294 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15295 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,421,5376,136,431,5528,2308,1024,137,4280,32,152,2,301,49,2048,5393,4096,2445,1452,32,256,168,5409,513]

theorem envBound15295 : H12AffineFastState.Bounded env15295 := by
  intro p hp
  have h : env15295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15294_15295 : H12AffineEnvironment.transform 5 49 env15294 = env15295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env15294 == env15295) = true)

theorem identity15295 : scanCanonicalize (H12AffineFastState.compose env15295 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15295 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env15296 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,300,5376,1,294,5393,2308,1024,0,4145,32,17,2,301,49,2048,5393,4096,2308,1317,32,256,33,5409,513]

theorem envBound15296 : H12AffineFastState.Bounded env15296 := by
  intro p hp
  have h : env15296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15295_15296 : H12AffineEnvironment.transform 6 9 env15295 = env15296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15295 == env15296) = true)

theorem identity15296 : scanCanonicalize (H12AffineFastState.compose env15296 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound15296 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15297 : List Nat := [2,4,8,16,32,49,9,256,260,1024,2048,4096,300,5376,1,294,5393,2308,1024,0,4145,32,17,2,301,49,2048,5393,4096,2308,1317,32,256,33,5409,261]

theorem envBound15297 : H12AffineFastState.Bounded env15297 := by
  intro p hp
  have h : env15297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15296_15297 : H12AffineEnvironment.transform 8 260 env15296 = env15297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env15296 == env15297) = true)

def env15298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,8388608,98644,8328,64,8787060,79131,8466578,8819969,8389957,98679,256,8462394,8492190,8462995]

theorem envBound15298 : H12AffineFastState.Bounded env15298 := by
  intro p hp
  have h : env15298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15282_15298 : H12AffineEnvironment.transform 21 33 env15282 = env15298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env15282 == env15298) = true)

theorem identity15298 : scanCanonicalize (H12AffineFastState.compose env15298 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound15298 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,41292,98644,8328,64,439608,79131,102878,406605,41993,98679,256,98678,79314,99295]

theorem envBound15299 : H12AffineFastState.Bounded env15299 := by
  intro p hp
  have h : env15299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15298_15299 : H12AffineEnvironment.transform 22 41292 env15298 = env15299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env15298 == env15299) = true)

theorem identity15299 : scanCanonicalize (H12AffineFastState.compose env15299 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound15299 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env15300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,78019,33,41292,98644,8328,64,203847,79131,102878,236850,41993,98679,256,98678,79314,99295]

theorem envBound15300 : H12AffineFastState.Bounded env15300 := by
  intro p hp
  have h : env15300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15299_15300 : H12AffineEnvironment.transform 17 108927 env15299 = env15300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env15299 == env15300) = true)

def env15301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67619,1024,8541,78019,33,16,73736,8328,64,203847,79131,77954,212078,1365,73771,256,73770,79314,74371]

theorem envBound15301 : H12AffineFastState.Bounded env15301 := by
  intro p hp
  have h : env15301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15300_15301 : H12AffineEnvironment.transform 14 8540 env15300 = env15301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15300 == env15301) = true)

theorem identity15301 : scanCanonicalize (H12AffineFastState.compose env15301 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound15301 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env15302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,13461,67619,1024,8541,78019,33,16,73736,8328,64,75986,79131,77954,67835,1365,73771,256,73770,79314,74371]

theorem envBound15302 : H12AffineFastState.Bounded env15302 := by
  intro p hp
  have h : env15302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15301_15302 : H12AffineEnvironment.transform 16 13461 env15301 = env15302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env15301 == env15302) = true)

theorem identity15302 : scanCanonicalize (H12AffineFastState.compose env15302 (packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound15302 : packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS < 2^1333 := by decide +kernel

def env15303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,398,13461,2477,1024,8541,12621,33,16,8582,8328,64,10588,13461,12556,2421,1365,8613,256,8612,13404,8973]

theorem envBound15303 : H12AffineFastState.Bounded env15303 := by
  intro p hp
  have h : env15303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15302_15303 : H12AffineEnvironment.transform 15 398 env15302 = env15303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env15302 == env15303) = true)

theorem identity15303 : scanCanonicalize (H12AffineFastState.compose env15303 (packedSelected [1,3,5,8,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound15303 : packedSelected [1,3,5,8,14,16] rootPS < 2^1333 := by decide +kernel

def env15304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,216,398,5393,2477,1024,217,4297,33,16,2,268,64,2264,5393,4232,2421,1365,33,256,32,5592,649]

theorem envBound15304 : H12AffineFastState.Bounded env15304 := by
  intro p hp
  have h : env15304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15303_15304 : H12AffineEnvironment.transform 12 388 env15303 = env15304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env15303 == env15304) = true)

theorem identity15304 : scanCanonicalize (H12AffineFastState.compose env15304 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound15304 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15305 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,41,5293,216,35,5308,2048,1024,217,4297,33,16,2,161,64,2264,5308,4232,2264,1272,33,173,32,5237,649]

theorem envBound15305 : H12AffineFastState.Bounded env15305 := by
  intro p hp
  have h : env15305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15304_15305 : H12AffineEnvironment.transform 7 173 env15304 = env15305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env15304 == env15305) = true)

theorem identity15305 : scanCanonicalize (H12AffineFastState.compose env15305 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15305 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env15306 : List Nat := [2,4,8,16,32,64,128,173,512,52,2048,4096,41,4249,216,35,4232,2048,52,217,4297,33,16,2,161,64,2264,4232,4232,2264,204,33,173,32,4161,649]

theorem envBound15306 : H12AffineFastState.Bounded env15306 := by
  intro p hp
  have h : env15306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15305_15306 : H12AffineEnvironment.transform 9 52 env15305 = env15306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15305 == env15306) = true)

def env15307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67618,1024,8540,78019,33,17,73737,8328,64,203847,79131,77955,212079,1364,73770,256,73771,79314,74370]

theorem envBound15307 : H12AffineFastState.Bounded env15307 := by
  intro p hp
  have h : env15307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15300_15307 : H12AffineEnvironment.transform 14 8541 env15300 = env15307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15300 == env15307) = true)

theorem identity15307 : scanCanonicalize (H12AffineFastState.compose env15307 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound15307 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env15308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,398,131072,2476,1024,8540,12621,33,17,8583,8328,64,138697,13461,12557,146913,1364,8612,256,8613,13404,8972]

theorem envBound15308 : H12AffineFastState.Bounded env15308 := by
  intro p hp
  have h : env15308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15307_15308 : H12AffineEnvironment.transform 15 398 env15307 = env15308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env15307 == env15308) = true)

theorem identity15308 : scanCanonicalize (H12AffineFastState.compose env15308 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15308 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,263,131072,2341,1024,8540,12621,33,17,8462,8193,64,138560,13340,12557,146792,1364,8493,256,8492,13404,8972]

theorem envBound15309 : H12AffineFastState.Bounded env15309 := by
  intro p hp
  have h : env15309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15308_15309 : H12AffineEnvironment.transform 6 9 env15308 = env15309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15308 == env15309) = true)

theorem identity15309 : scanCanonicalize (H12AffineFastState.compose env15309 (packedSelected [0,4,6,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound15309 : packedSelected [0,4,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env15310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,263,4097,2341,1024,8540,12621,33,17,8462,8193,64,3393,13340,12557,11625,1364,8493,256,8492,13404,8972]

theorem envBound15310 : H12AffineFastState.Bounded env15310 := by
  intro p hp
  have h : env15310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15309_15310 : H12AffineEnvironment.transform 16 4097 env15309 = env15310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env15309 == env15310) = true)

theorem identity15310 : scanCanonicalize (H12AffineFastState.compose env15310 (packedSelected [1,6,8,10,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound15310 : packedSelected [1,6,8,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env15311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,5376,1345,263,4097,2341,1024,1344,5457,33,17,1298,1053,64,3393,4096,5393,2421,1364,1329,256,1328,4160,1808]

theorem envBound15311 : H12AffineFastState.Bounded env15311 := by
  intro p hp
  have h : env15311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15310_15311 : H12AffineEnvironment.transform 12 1052 env15310 = env15311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env15310 == env15311) = true)

theorem identity15311 : scanCanonicalize (H12AffineFastState.compose env15311 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound15311 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env15312 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,121,4453,292,263,4097,2341,101,293,4404,33,17,375,120,64,2340,4096,4468,2421,305,340,256,341,4160,885]

theorem envBound15312 : H12AffineFastState.Bounded env15312 := by
  intro p hp
  have h : env15312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15311_15312 : H12AffineEnvironment.transform 9 101 env15311 = env15312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env15311 == env15312) = true)

theorem identity15312 : scanCanonicalize (H12AffineFastState.compose env15312 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15312 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15313 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,121,4112,81,114,4097,2128,101,80,4161,33,17,2,120,64,2129,4096,4097,2048,68,33,117,32,4160,512]

theorem envBound15313 : H12AffineFastState.Bounded env15313 := by
  intro p hp
  have h : env15313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15312_15313 : H12AffineEnvironment.transform 7 117 env15312 = env15313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15312 == env15313) = true)

theorem identity15313 : scanCanonicalize (H12AffineFastState.compose env15313 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound15313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15314 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,97,121,113,81,114,96,2128,101,80,32,33,17,2,120,64,2129,97,96,2048,68,33,117,32,33,512]

theorem envBound15314 : H12AffineFastState.Bounded env15314 := by
  intro p hp
  have h : env15314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15313_15314 : H12AffineEnvironment.transform 11 97 env15313 = env15314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env15313 == env15314) = true)

theorem identity15314 : scanCanonicalize (H12AffineFastState.compose env15314 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 36) := by decide +kernel

theorem selectedBound15314 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env15315 : List Nat := [2,4,8,16,32,64,9,117,512,101,36,97,121,113,81,114,96,116,101,80,32,33,17,2,120,64,117,97,96,36,68,33,117,32,33,512]

theorem envBound15315 : H12AffineFastState.Bounded env15315 := by
  intro p hp
  have h : env15315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15314_15315 : H12AffineEnvironment.transform 10 36 env15314 = env15315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 36 env15314 == env15315) = true)

theorem identity15315 : scanCanonicalize (H12AffineFastState.compose env15315 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15315 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15316 : List Nat := [2,4,8,16,0,64,9,85,512,69,4,65,89,81,81,82,64,84,69,80,0,1,17,2,88,64,85,65,64,4,68,1,85,0,1,512]

theorem envBound15316 : H12AffineFastState.Bounded env15316 := by
  intro p hp
  have h : env15316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15315_15316 : H12AffineEnvironment.transform 4 0 env15315 = env15316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15315 == env15316) = true)

theorem identity15316 : scanCanonicalize (H12AffineFastState.compose env15316 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound15316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15317 : List Nat := [2,0,8,16,0,64,9,81,512,65,0,65,89,81,81,82,64,80,65,80,0,1,17,2,88,64,81,65,64,0,64,1,81,0,1,512]

theorem envBound15317 : H12AffineFastState.Bounded env15317 := by
  intro p hp
  have h : env15317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15316_15317 : H12AffineEnvironment.transform 1 0 env15316 = env15317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env15316 == env15317) = true)

theorem identity15317 : scanCanonicalize (H12AffineFastState.compose env15317 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15318 : List Nat := [2,0,8,16,0,17,9,0,512,16,0,16,8,0,0,3,17,1,16,1,0,1,17,2,9,17,0,16,17,0,17,1,0,0,1,512]

theorem envBound15318 : H12AffineFastState.Bounded env15318 := by
  intro p hp
  have h : env15318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15317_15318 : H12AffineEnvironment.transform 5 17 env15317 = env15318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15317 == env15318) = true)

def env15319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98645,8328,64,12981333,79131,8466578,8819968,8389956,4292951,256,8462395,8492190,8462994]

theorem envBound15319 : H12AffineFastState.Bounded env15319 := by
  intro p hp
  have h : env15319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15281_15319 : H12AffineEnvironment.transform 13 5377 env15281 = env15319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15281 == env15319) = true)

def env15320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,8388608,98645,8328,64,8787061,79131,8466578,8819968,8389956,98679,256,8462395,8492190,8462994]

theorem envBound15320 : H12AffineFastState.Bounded env15320 := by
  intro p hp
  have h : env15320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15319_15320 : H12AffineEnvironment.transform 21 32 env15319 = env15320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15319 == env15320) = true)

def env15321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,8388608,98645,8192,64,8787061,79131,8466458,8819968,8389956,98679,256,8462395,8492054,8462874]

theorem envBound15321 : H12AffineFastState.Bounded env15321 := by
  intro p hp
  have h : env15321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15320_15321 : H12AffineEnvironment.transform 6 8 env15320 = env15321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15320 == env15321) = true)

def env15322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,16,98645,8192,64,398437,79131,77834,431376,1364,98679,256,73771,103430,74250]

theorem envBound15322 : H12AffineFastState.Bounded env15322 := by
  intro p hp
  have h : env15322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15321_15322 : H12AffineEnvironment.transform 22 16 env15321 = env15322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env15321 == env15322) = true)

theorem identity15322 : scanCanonicalize (H12AffineFastState.compose env15322 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound15322 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,45341,32,16,2,8192,64,398437,46156,45405,431376,1364,32,256,41340,5457,41821]

theorem envBound15323 : H12AffineFastState.Bounded env15323 := by
  intro p hp
  have h : env15323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15322_15323 : H12AffineEnvironment.transform 15 33111 env15322 = env15323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env15322 == env15323) = true)

theorem identity15323 : scanCanonicalize (H12AffineFastState.compose env15323 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound15323 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env15324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,5393,262144,1024,32769,45341,32,16,2,8192,64,262516,46156,45405,294913,1364,32,256,41340,5457,41821]

theorem envBound15324 : H12AffineFastState.Bounded env15324 := by
  intro p hp
  have h : env15324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15323_15324 : H12AffineEnvironment.transform 16 5393 env15323 = env15324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env15323 == env15324) = true)

theorem identity15324 : scanCanonicalize (H12AffineFastState.compose env15324 (packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 43357) := by decide +kernel

theorem selectedBound15324 : packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env15325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,5393,43357,1024,32769,45341,32,16,2,8192,64,43049,46156,45405,10588,1364,32,256,41340,5457,41821]

theorem envBound15325 : H12AffineFastState.Bounded env15325 := by
  intro p hp
  have h : env15325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15324_15325 : H12AffineEnvironment.transform 17 43357 env15324 = env15325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43357 env15324 == env15325) = true)

theorem identity15325 : scanCanonicalize (H12AffineFastState.compose env15325 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound15325 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env15326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8312,8495,5393,2341,1024,8313,4453,32,16,2,8192,64,2129,5172,4389,10588,1364,32,256,260,5457,805]

theorem envBound15326 : H12AffineFastState.Bounded env15326 := by
  intro p hp
  have h : env15326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15325_15326 : H12AffineEnvironment.transform 14 8312 env15325 = env15326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env15325 == env15326) = true)

theorem identity15326 : scanCanonicalize (H12AffineFastState.compose env15326 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15326 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env15327 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8312,8282,5220,2128,1024,8313,4112,32,16,2,8192,64,2129,5172,4176,10281,1057,32,117,113,5156,592]

theorem envBound15327 : H12AffineFastState.Bounded env15327 := by
  intro p hp
  have h : env15327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15326_15327 : H12AffineEnvironment.transform 7 117 env15326 = env15327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15326 == env15327) = true)

theorem identity15327 : scanCanonicalize (H12AffineFastState.compose env15327 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15327 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15328 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,80,114,5220,2128,1024,81,4112,32,16,2,40,64,2129,5172,4176,2049,1057,32,117,113,5156,592]

theorem envBound15328 : H12AffineFastState.Bounded env15328 := by
  intro p hp
  have h : env15328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15327_15328 : H12AffineEnvironment.transform 12 40 env15327 = env15328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15327 == env15328) = true)

theorem identity15328 : scanCanonicalize (H12AffineFastState.compose env15328 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15328 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env15329 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,34,5172,2048,1024,1,4112,32,16,2,40,16,2049,5172,4096,2049,1057,32,37,33,5156,512]

theorem envBound15329 : H12AffineFastState.Bounded env15329 := by
  intro p hp
  have h : env15329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15328_15329 : H12AffineEnvironment.transform 5 16 env15328 = env15329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15328 == env15329) = true)

theorem identity15329 : scanCanonicalize (H12AffineFastState.compose env15329 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15330 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,0,2,5140,2048,1024,1,4112,0,16,2,8,16,2049,5140,4096,2049,1025,0,5,1,5124,512]

theorem envBound15330 : H12AffineFastState.Bounded env15330 := by
  intro p hp
  have h : env15330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15329_15330 : H12AffineEnvironment.transform 4 0 env15329 = env15330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15329 == env15330) = true)

def env15331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,17,98645,8192,64,398436,79131,77835,431377,1365,98679,256,73770,103431,74251]

theorem envBound15331 : H12AffineFastState.Bounded env15331 := by
  intro p hp
  have h : env15331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15321_15331 : H12AffineEnvironment.transform 22 17 env15321 = env15331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env15321 == env15331) = true)

theorem identity15331 : scanCanonicalize (H12AffineFastState.compose env15331 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound15331 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108927,1024,32769,77898,32,17,98645,8192,64,245019,79131,77835,212078,1365,98679,256,73770,103431,74251]

theorem envBound15332 : H12AffineFastState.Bounded env15332 := by
  intro p hp
  have h : env15332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15331_15332 : H12AffineEnvironment.transform 17 108927 env15331 = env15332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env15331 == env15332) = true)

theorem identity15332 : scanCanonicalize (H12AffineFastState.compose env15332 (packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 111947) := by decide +kernel

theorem selectedBound15332 : packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env15333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,111947,108927,1024,32769,77898,32,17,98645,8192,64,2128,79131,77835,35109,1365,98679,256,73770,103431,74251]

theorem envBound15333 : H12AffineFastState.Bounded env15333 := by
  intro p hp
  have h : env15333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15332_15333 : H12AffineEnvironment.transform 16 111947 env15332 = env15333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111947 env15332 == env15333) = true)

theorem identity15333 : scanCanonicalize (H12AffineFastState.compose env15333 (packedSelected [3,11,14,16,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 34098) := by decide +kernel

theorem selectedBound15333 : packedSelected [3,11,14,16,18,24] rootPS < 2^1333 := by decide +kernel

def env15334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,34098,12409,11341,1024,32769,46456,32,17,1127,8192,64,2128,45097,46393,35109,1365,1093,256,42264,4405,42809]

theorem envBound15334 : H12AffineFastState.Bounded env15334 := by
  intro p hp
  have h : env15334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15333_15334 : H12AffineEnvironment.transform 15 34098 env15333 = env15334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34098 env15333 == env15334) = true)

theorem identity15334 : scanCanonicalize (H12AffineFastState.compose env15334 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound15334 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env15335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,372,1094,12409,11341,1024,373,13324,32,17,1127,8192,64,2128,12637,13389,2129,1365,1093,256,9324,4405,9805]

theorem envBound15335 : H12AffineFastState.Bounded env15335 := by
  intro p hp
  have h : env15335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15334_15335 : H12AffineEnvironment.transform 14 372 env15334 = env15335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env15334 == env15335) = true)

theorem identity15335 : scanCanonicalize (H12AffineFastState.compose env15335 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound15335 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0