import H12CloudChart0Data141

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def active36028 : List Nat := [0,1,2,8]

def tree36028 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36028 : H12WitnessSearch.Good tree36028 := H12GlobalWitnessIndex.good

theorem leafIdentity36028 : H12AffineFastState.composeSystem env36028 rootObs = leafEnv36028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36028 rootObs == leafEnv36028) = true)

theorem terminalChecked36028 : H12PackedTerminal.terminalCheckFast leafEnv36028 active36028 tree36028 = true := by decide +kernel

def env36029 : List Nat := [2,4,8,16,0,16,9,5,512,21,529,17,8,1,0,2,16,529,21,1,0,1,17,3,9,17,529,17,16,529,21,1,5,0,1,513]

theorem envBound36029 : H12AffineFastState.Bounded env36029 := by
  intro p hp
  have h : env36029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36026_36029 : H12AffineEnvironment.transform 9 21 env36026 = env36029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36026 == env36029) = true)

theorem identity36029 : scanCanonicalize (H12AffineFastState.compose env36029 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound36029 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36030 : List Nat := [2,4,8,16,0,16,9,5,17,21,0,17,8,1,0,2,16,0,21,1,0,1,17,3,9,17,0,17,16,0,21,1,5,0,1,16]

theorem envBound36030 : H12AffineFastState.Bounded env36030 := by
  intro p hp
  have h : env36030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36029_36030 : H12AffineEnvironment.transform 8 17 env36029 = env36030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36029 == env36030) = true)

def leafEnv36030 : List Nat := [2,4,8,16,0,16,9,5,17,21,0,17,8,1,0,2,16,0,21,1,0,1,17,3,21,9,1,17,0,17,16,0,21,1,5,0,4,3,1,16,1,0,0]

def active36030 : List Nat := [0,1,2,3]

def tree36030 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36030 : H12WitnessSearch.Good tree36030 := H12GlobalWitnessIndex.good

theorem leafIdentity36030 : H12AffineFastState.composeSystem env36030 rootObs = leafEnv36030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36030 rootObs == leafEnv36030) = true)

theorem terminalChecked36030 : H12PackedTerminal.terminalCheckFast leafEnv36030 active36030 tree36030 = true := by decide +kernel

def env36031 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247963,1024,32769,77899,253979,73755,95497,8328,65,245138,115150,17665,10368,119042,180376,256,41429,16464,63189]

theorem envBound36031 : H12AffineFastState.Bounded env36031 := by
  intro p hp
  have h : env36031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36009_36031 : H12AffineEnvironment.transform 4 1 env36009 = env36031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36009 == env36031) = true)

theorem identity36031 : scanCanonicalize (H12AffineFastState.compose env36031 (packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36031 : packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env36032 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,16384,32768,65536,131072,247963,1024,32769,69910,246086,65862,87124,469,65,236751,115150,17665,2525,119042,180376,256,32904,16464,55176]

theorem envBound36032 : H12AffineFastState.Bounded env36032 := by
  intro p hp
  have h : env36032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36031_36032 : H12AffineEnvironment.transform 12 349 env36031 = env36032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36031 == env36032) = true)

theorem identity36032 : scanCanonicalize (H12AffineFastState.compose env36032 (packedSelected [0,3,9,11,12,16,17,20,22,24,26,27,31,32,41] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36032 : packedSelected [0,3,9,11,12,16,17,20,22,24,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env36033 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5376,32768,65536,131072,236955,1024,32769,69910,234566,65862,65876,469,65,236751,103630,4097,2525,99330,169368,256,32904,5456,33416]

theorem envBound36033 : H12AffineFastState.Bounded env36033 := by
  intro p hp
  have h : env36033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36032_36033 : H12AffineEnvironment.transform 13 5376 env36032 = env36033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36032 == env36033) = true)

theorem identity36033 : scanCanonicalize (H12AffineFastState.compose env36033 (packedSelected [0,1,4,7,17,19,22,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound36033 : packedSelected [0,1,4,7,17,19,22,28,31] rootPS < 2^1333 := by decide +kernel

def env36034 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5376,32768,33246,131072,138309,1024,32769,37064,136600,32920,32906,469,65,138513,5392,4097,2525,1500,169368,256,32904,5456,33416]

theorem envBound36034 : H12AffineFastState.Bounded env36034 := by
  intro p hp
  have h : env36034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36033_36034 : H12AffineEnvironment.transform 15 33246 env36033 = env36034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env36033 == env36034) = true)

theorem identity36034 : scanCanonicalize (H12AffineFastState.compose env36034 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound36034 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36035 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5376,137,343,131072,138309,1024,136,4161,136600,17,3,469,65,138513,5392,4097,2525,1500,136465,256,1,5456,513]

theorem envBound36035 : H12AffineFastState.Bounded env36035 := by
  intro p hp
  have h : env36035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36034_36035 : H12AffineEnvironment.transform 14 137 env36034 = env36035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env36034 == env36035) = true)

theorem identity36035 : scanCanonicalize (H12AffineFastState.compose env36035 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound36035 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36036 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,349,5376,137,343,5393,2388,1024,136,4161,137,17,3,469,65,2048,5392,4097,2525,1500,0,256,1,5456,513]

theorem envBound36036 : H12AffineFastState.Bounded env36036 := by
  intro p hp
  have h : env36036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36035_36036 : H12AffineEnvironment.transform 16 5393 env36035 = env36036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env36035 == env36036) = true)

theorem identity36036 : scanCanonicalize (H12AffineFastState.compose env36036 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36036 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36037 : List Nat := [2,4,8,16,1,16,128,256,512,1024,2048,4096,269,5376,137,263,5393,2308,1024,136,4113,137,17,3,389,17,2048,5392,4097,2445,1420,0,256,1,5376,513]

theorem envBound36037 : H12AffineFastState.Bounded env36037 := by
  intro p hp
  have h : env36037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36036_36037 : H12AffineEnvironment.transform 5 16 env36036 = env36037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36036 == env36037) = true)

theorem identity36037 : scanCanonicalize (H12AffineFastState.compose env36037 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound36037 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36038 : List Nat := [2,4,8,16,1,16,128,141,512,1024,2048,4096,128,5261,137,138,5276,2185,1024,136,4113,137,17,3,8,17,2048,5277,4097,2048,1025,0,141,1,5261,513]

theorem envBound36038 : H12AffineFastState.Bounded env36038 := by
  intro p hp
  have h : env36038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36037_36038 : H12AffineEnvironment.transform 7 141 env36037 = env36038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env36037 == env36038) = true)

theorem identity36038 : scanCanonicalize (H12AffineFastState.compose env36038 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36038 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36039 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5124,0,3,5141,2048,1024,1,4113,0,17,3,8,17,2048,5140,4097,2048,1025,0,4,1,5124,513]

theorem envBound36039 : H12AffineFastState.Bounded env36039 := by
  intro p hp
  have h : env36039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36038_36039 : H12AffineEnvironment.transform 6 9 env36038 = env36039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36038 == env36039) = true)

def env36040 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1044,0,3,1029,2048,1024,1,1,0,17,3,8,17,2048,1028,17,2048,1025,0,4,1,1044,513]

theorem envBound36040 : H12AffineFastState.Bounded env36040 := by
  intro p hp
  have h : env36040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36039_36040 : H12AffineEnvironment.transform 11 16 env36039 = env36040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36039 == env36040) = true)

theorem identity36040 : scanCanonicalize (H12AffineFastState.compose env36040 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound36040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36041 : List Nat := [2,4,8,16,1,16,9,4,512,1024,528,16,9,1044,0,3,1029,528,1024,1,1,0,17,3,8,17,528,1028,17,528,1025,0,4,1,1044,513]

theorem envBound36041 : H12AffineFastState.Bounded env36041 := by
  intro p hp
  have h : env36041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36040_36041 : H12AffineEnvironment.transform 10 528 env36040 = env36041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env36040 == env36041) = true)

def env36042 : List Nat := [2,4,8,16,1,16,9,4,512,20,528,16,9,0,0,3,17,528,20,1,1,0,17,3,8,17,528,16,17,528,21,0,4,1,0,513]

theorem envBound36042 : H12AffineFastState.Bounded env36042 := by
  intro p hp
  have h : env36042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36041_36042 : H12AffineEnvironment.transform 9 20 env36041 = env36042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36041 == env36042) = true)

theorem identity36042 : scanCanonicalize (H12AffineFastState.compose env36042 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound36042 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36043 : List Nat := [2,4,8,16,1,16,9,4,17,20,1,16,9,0,0,3,17,1,20,1,1,0,17,3,8,17,1,16,17,1,21,0,4,1,0,16]

theorem envBound36043 : H12AffineFastState.Bounded env36043 := by
  intro p hp
  have h : env36043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36042_36043 : H12AffineEnvironment.transform 8 17 env36042 = env36043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36042 == env36043) = true)

def leafEnv36043 : List Nat := [2,4,8,16,1,16,9,4,17,20,1,16,9,0,0,3,17,1,20,1,1,0,17,3,21,8,1,17,1,16,17,1,21,0,4,1,4,2,0,16,1,1,0]

def active36043 : List Nat := [0,1,2,3]

def tree36043 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36043 : H12WitnessSearch.Good tree36043 := H12GlobalWitnessIndex.good

theorem leafIdentity36043 : H12AffineFastState.composeSystem env36043 rootObs = leafEnv36043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36043 rootObs == leafEnv36043) = true)

theorem terminalChecked36043 : H12PackedTerminal.terminalCheckFast leafEnv36043 active36043 tree36043 = true := by decide +kernel

def env36044 : List Nat := [2,4,8,16,1,16,9,4,512,21,528,16,9,1,0,3,16,528,21,1,1,0,17,3,8,17,528,17,17,528,20,0,4,1,1,513]

theorem envBound36044 : H12AffineFastState.Bounded env36044 := by
  intro p hp
  have h : env36044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36041_36044 : H12AffineEnvironment.transform 9 21 env36041 = env36044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36041 == env36044) = true)

theorem identity36044 : scanCanonicalize (H12AffineFastState.compose env36044 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36044 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36045 : List Nat := [2,4,8,10,1,10,9,4,512,15,522,10,9,1,0,3,10,522,15,1,1,0,11,3,8,11,522,11,11,522,14,0,4,1,1,513]

theorem envBound36045 : H12AffineFastState.Bounded env36045 := by
  intro p hp
  have h : env36045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36044_36045 : H12AffineEnvironment.transform 3 10 env36044 = env36045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36044 == env36045) = true)

def leafEnv36045 : List Nat := [2,4,8,10,1,10,9,4,512,15,522,10,9,1,0,3,10,522,15,1,1,0,11,3,14,8,1,11,522,11,11,522,14,0,4,1,4,2,1,513,1,1,0]

def active36045 : List Nat := [0,1,2,8]

def tree36045 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36045 : H12WitnessSearch.Good tree36045 := H12GlobalWitnessIndex.good

theorem leafIdentity36045 : H12AffineFastState.composeSystem env36045 rootObs = leafEnv36045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36045 rootObs == leafEnv36045) = true)

theorem terminalChecked36045 : H12PackedTerminal.terminalCheckFast leafEnv36045 active36045 tree36045 = true := by decide +kernel

def env36046 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1045,0,3,1028,2048,1024,1,0,0,17,3,8,17,2048,1029,16,2048,1025,0,4,1,1045,513]

theorem envBound36046 : H12AffineFastState.Bounded env36046 := by
  intro p hp
  have h : env36046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36039_36046 : H12AffineEnvironment.transform 11 17 env36039 = env36046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env36039 == env36046) = true)

theorem identity36046 : scanCanonicalize (H12AffineFastState.compose env36046 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound36046 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36047 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1540,17,9,1045,0,3,1028,1540,1024,1,0,0,17,3,8,17,1540,1029,16,1540,1025,0,4,1,1045,513]

theorem envBound36047 : H12AffineFastState.Bounded env36047 := by
  intro p hp
  have h : env36047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36046_36047 : H12AffineEnvironment.transform 10 1540 env36046 = env36047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env36046 == env36047) = true)

def env36048 : List Nat := [2,4,8,16,1,16,9,4,512,20,528,17,9,1,0,3,16,528,20,1,0,0,17,3,8,17,528,17,16,528,21,0,4,1,1,513]

theorem envBound36048 : H12AffineFastState.Bounded env36048 := by
  intro p hp
  have h : env36048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36047_36048 : H12AffineEnvironment.transform 9 20 env36047 = env36048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36047 == env36048) = true)

theorem identity36048 : scanCanonicalize (H12AffineFastState.compose env36048 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36049 : List Nat := [2,4,8,16,1,16,9,4,16,20,0,17,9,1,0,3,16,0,20,1,0,0,17,3,8,17,0,17,16,0,21,0,4,1,1,17]

theorem envBound36049 : H12AffineFastState.Bounded env36049 := by
  intro p hp
  have h : env36049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36048_36049 : H12AffineEnvironment.transform 8 16 env36048 = env36049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36048 == env36049) = true)

def leafEnv36049 : List Nat := [2,4,8,16,1,16,9,4,16,20,0,17,9,1,0,3,16,0,20,1,0,0,17,3,21,8,1,17,0,17,16,0,21,0,4,1,4,2,1,17,1,0,0]

def active36049 : List Nat := [0,1,2,3]

def tree36049 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36049 : H12WitnessSearch.Good tree36049 := H12GlobalWitnessIndex.good

theorem leafIdentity36049 : H12AffineFastState.composeSystem env36049 rootObs = leafEnv36049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36049 rootObs == leafEnv36049) = true)

theorem terminalChecked36049 : H12PackedTerminal.terminalCheckFast leafEnv36049 active36049 tree36049 = true := by decide +kernel

def env36050 : List Nat := [2,4,8,16,1,16,9,4,512,21,529,17,9,0,0,3,17,529,21,1,0,0,17,3,8,17,529,16,16,529,20,0,4,1,0,513]

theorem envBound36050 : H12AffineFastState.Bounded env36050 := by
  intro p hp
  have h : env36050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36047_36050 : H12AffineEnvironment.transform 9 21 env36047 = env36050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36047 == env36050) = true)

theorem identity36050 : scanCanonicalize (H12AffineFastState.compose env36050 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36050 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36051 : List Nat := [2,4,8,11,1,11,9,4,512,14,522,10,9,0,0,3,10,522,14,1,0,0,10,3,8,10,522,11,11,522,15,0,4,1,0,513]

theorem envBound36051 : H12AffineFastState.Bounded env36051 := by
  intro p hp
  have h : env36051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36050_36051 : H12AffineEnvironment.transform 3 11 env36050 = env36051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36050 == env36051) = true)

def leafEnv36051 : List Nat := [2,4,8,11,1,11,9,4,512,14,522,10,9,0,0,3,10,522,14,1,0,0,10,3,15,8,1,10,522,11,11,522,15,0,4,1,4,2,0,513,1,0,0]

def active36051 : List Nat := [0,1,2,8]

def tree36051 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36051 : H12WitnessSearch.Good tree36051 := H12GlobalWitnessIndex.good

theorem leafIdentity36051 : H12AffineFastState.composeSystem env36051 rootObs = leafEnv36051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36051 rootObs == leafEnv36051) = true)

theorem terminalChecked36051 : H12PackedTerminal.terminalCheckFast leafEnv36051 active36051 tree36051 = true := by decide +kernel

def env36052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452769,441779,8328,65,245139,115150,17665,10401,119042,329730,256,485710,493802,63189]

theorem envBound36052 : H12AffineFastState.Bounded env36052 := by
  intro p hp
  have h : env36052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36007_36052 : H12AffineEnvironment.transform 21 272513 env36007 = env36052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env36007 == env36052) = true)

theorem identity36052 : scanCanonicalize (H12AffineFastState.compose env36052 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36052 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456945,272513,452769,441779,8328,65,171416,57797,17665,10401,61705,272393,256,411973,436449,63189]

theorem envBound36053 : H12AffineFastState.Bounded env36053 := by
  intro p hp
  have h : env36053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36052_36053 : H12AffineEnvironment.transform 15 8203 env36052 = env36053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36052 == env36053) = true)

def env36054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456825,272393,452649,441659,8192,65,171280,57677,17665,10281,61705,272393,256,411973,436329,63069]

theorem envBound36054 : H12AffineFastState.Bounded env36054 := by
  intro p hp
  have h : env36054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36053_36054 : H12AffineEnvironment.transform 6 8 env36053 = env36054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36053 == env36054) = true)

theorem identity36054 : scanCanonicalize (H12AffineFastState.compose env36054 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 43356) := by decide +kernel

theorem selectedBound36054 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env36055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,43356,1024,32769,151845,33109,147829,136295,8192,65,171280,57677,17665,10281,61705,33109,256,188441,131381,63069]

theorem envBound36055 : H12AffineFastState.Bounded env36055 := by
  intro p hp
  have h : env36055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36054_36055 : H12AffineEnvironment.transform 17 43356 env36054 = env36055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43356 env36054 == env36055) = true)

theorem identity36055 : scanCanonicalize (H12AffineFastState.compose env36055 (packedSelected [0,6,16,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound36055 : packedSelected [0,6,16,20,27] rootPS < 2^1333 := by decide +kernel

def env36056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,32768,35,131072,35188,1024,32769,151845,33109,147829,136295,40,65,171280,49509,17665,2049,53537,33109,256,180273,131381,54901]

theorem envBound36056 : H12AffineFastState.Bounded env36056 := by
  intro p hp
  have h : env36056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36055_36056 : H12AffineEnvironment.transform 12 40 env36055 = env36056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env36055 == env36056) = true)

theorem identity36056 : scanCanonicalize (H12AffineFastState.compose env36056 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 49508) := by decide +kernel

theorem selectedBound36056 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,32768,35,49508,35188,1024,32769,36929,33109,32785,54531,40,65,23668,49509,17665,2049,53537,33109,256,341,49233,54901]

theorem envBound36057 : H12AffineFastState.Bounded env36057 := by
  intro p hp
  have h : env36057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36056_36057 : H12AffineEnvironment.transform 16 49508 env36056 = env36057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49508 env36056 == env36057) = true)

def env36058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,456824,272392,452648,441658,8193,65,171281,57676,17665,10280,61705,272393,256,411973,436328,63068]

theorem envBound36058 : H12AffineFastState.Bounded env36058 := by
  intro p hp
  have h : env36058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36053_36058 : H12AffineEnvironment.transform 6 9 env36053 = env36058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36053 == env36058) = true)

theorem identity36058 : scanCanonicalize (H12AffineFastState.compose env36058 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound36058 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env36059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46156,262144,1024,32769,281652,272392,285796,264566,8193,65,10589,57676,17665,10280,61705,272393,256,326921,269348,63068]

theorem envBound36059 : H12AffineFastState.Bounded env36059 := by
  intro p hp
  have h : env36059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36058_36059 : H12AffineEnvironment.transform 16 46156 env36058 = env36059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env36058 == env36059) = true)

theorem identity36059 : scanCanonicalize (H12AffineFastState.compose env36059 (packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound36059 : packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env36060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,46156,35188,1024,32769,50496,41340,54544,32770,8193,65,10589,57676,17665,10280,61705,41341,256,29821,38224,63068]

theorem envBound36060 : H12AffineFastState.Bounded env36060 := by
  intro p hp
  have h : env36060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36059_36060 : H12AffineEnvironment.transform 17 35188 env36059 = env36060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env36059 == env36060) = true)

theorem identity36060 : scanCanonicalize (H12AffineFastState.compose env36060 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36060 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,343,38160,35188,1024,32769,50496,32800,54544,32770,349,65,2049,49168,17665,2420,53333,32801,256,21793,38224,55040]

theorem envBound36061 : H12AffineFastState.Bounded env36061 := by
  intro p hp
  have h : env36061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36060_36061 : H12AffineEnvironment.transform 12 348 env36060 = env36061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36060 == env36061) = true)

theorem identity36061 : scanCanonicalize (H12AffineFastState.compose env36061 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound36061 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21841,343,16449,23589,1024,21840,4113,21873,65,21843,349,65,2049,5441,17665,2420,1284,21872,256,21793,16385,593]

theorem envBound36062 : H12AffineFastState.Bounded env36062 := by
  intro p hp
  have h : env36062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36061_36062 : H12AffineEnvironment.transform 14 21841 env36061 = env36062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env36061 == env36062) = true)

theorem identity36062 : scanCanonicalize (H12AffineFastState.compose env36062 (packedSelected [4,6,7,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound36062 : packedSelected [4,6,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env36063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4112,1345,343,4177,3125,1024,1344,4113,1377,65,1347,349,65,2049,5441,5393,2420,1284,1376,256,1329,4113,593]

theorem envBound36063 : H12AffineFastState.Bounded env36063 := by
  intro p hp
  have h : env36063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36062_36063 : H12AffineEnvironment.transform 13 4112 env36062 = env36063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env36062 == env36063) = true)

theorem identity36063 : scanCanonicalize (H12AffineFastState.compose env36063 (packedSelected [0,2,6,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound36063 : packedSelected [0,2,6,9,12] rootPS < 2^1333 := by decide +kernel

def env36064 : List Nat := [2,4,8,16,32,64,9,256,512,68,2048,4096,348,4112,261,343,4177,2161,68,260,4113,293,65,263,349,65,2049,4357,4437,2420,320,292,256,373,4113,593]

theorem envBound36064 : H12AffineFastState.Bounded env36064 := by
  intro p hp
  have h : env36064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36063_36064 : H12AffineEnvironment.transform 9 68 env36063 = env36064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env36063 == env36064) = true)

theorem identity36064 : scanCanonicalize (H12AffineFastState.compose env36064 (packedSelected [0,3,4,5,6,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36064 : packedSelected [0,3,4,5,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env36065 : List Nat := [2,4,8,16,32,16,9,256,512,20,2048,4096,268,4112,261,263,4097,2081,20,260,4113,293,17,263,269,17,2049,4357,4357,2340,272,292,256,293,4113,513]

theorem envBound36065 : H12AffineFastState.Bounded env36065 := by
  intro p hp
  have h : env36065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36064_36065 : H12AffineEnvironment.transform 5 16 env36064 = env36065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36064 == env36065) = true)

theorem identity36065 : scanCanonicalize (H12AffineFastState.compose env36065 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound36065 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36066 : List Nat := [2,4,8,16,32,16,9,256,512,20,260,4096,268,4112,261,263,4097,293,20,260,4113,293,17,263,269,17,261,4357,4357,32,272,292,256,293,4113,513]

theorem envBound36066 : H12AffineFastState.Bounded env36066 := by
  intro p hp
  have h : env36066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36065_36066 : H12AffineEnvironment.transform 10 260 env36065 = env36066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env36065 == env36066) = true)

def env36067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound36067 : H12AffineFastState.Bounded env36067 := by
  intro p hp
  have h : env36067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35834_36067 : H12AffineEnvironment.transform 18 1025 env35834 = env36067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env35834 == env36067) = true)

theorem identity36067 : scanCanonicalize (H12AffineFastState.compose env36067 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 347491) := by decide +kernel

theorem selectedBound36067 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,16777216,8328,65,29868033,17091054,8722482,8830977,25265168,21244066,257,25463247,25454698,25207750]

theorem envBound36068 : H12AffineFastState.Bounded env36068 := by
  intro p hp
  have h : env36068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36067_36068 : H12AffineEnvironment.transform 20 347491 env36067 = env36068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347491 env36067 == env36068) = true)

def env36069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,392436,8328,65,12729589,79130,8722482,8830977,8681700,4314198,257,8484155,8492190,8740658]

theorem envBound36069 : H12AffineFastState.Bounded env36069 := by
  intro p hp
  have h : env36069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36068_36069 : H12AffineEnvironment.transform 23 392436 env36068 = env36069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392436 env36068 == env36069) = true)

def env36070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,8388608,98780,8328,65,12729589,79130,8480026,8568105,8390092,4314198,257,8484155,8492190,8462874]

theorem envBound36070 : H12AffineFastState.Bounded env36070 := by
  intro p hp
  have h : env36070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36069_36070 : H12AffineEnvironment.transform 17 32040 env36069 = env36070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env36069 == env36070) = true)

def env36071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,16,98780,8328,65,4340965,79130,91402,179513,1500,4314198,257,95531,103566,74250]

theorem envBound36071 : H12AffineFastState.Bounded env36071 := by
  intro p hp
  have h : env36071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36070_36071 : H12AffineEnvironment.transform 22 16 env36070 = env36071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env36070 == env36071) = true)

theorem identity36071 : scanCanonicalize (H12AffineFastState.compose env36071 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound36071 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,41340,16,98780,8328,65,171417,79130,91402,179513,1500,95530,257,95531,103566,74250]

theorem envBound36072 : H12AffineFastState.Bounded env36072 := by
  intro p hp
  have h : env36072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36071_36072 : H12AffineEnvironment.transform 21 41340 env36071 = env36072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env36071 == env36072) = true)

theorem identity36072 : scanCanonicalize (H12AffineFastState.compose env36072 (packedSelected [0,5,8,9,11,14,15,22,24,26,27,28,31,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound36072 : packedSelected [0,5,8,9,11,14,15,22,24,26,27,28,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env36073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21647,131072,32040,1025,32769,25796,41340,16,54611,8328,65,171417,24981,12677,179513,1500,8613,257,8612,49153,30341]

theorem envBound36073 : H12AffineFastState.Bounded env36073 := by
  intro p hp
  have h : env36073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36072_36073 : H12AffineEnvironment.transform 15 21647 env36072 = env36073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env36072 == env36073) = true)

theorem identity36073 : scanCanonicalize (H12AffineFastState.compose env36073 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36073 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env36074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,21647,131072,23588,1025,32769,17864,32880,16,54611,388,65,171417,16537,4233,171061,1500,169,257,168,49153,22409]

theorem envBound36074 : H12AffineFastState.Bounded env36074 := by
  intro p hp
  have h : env36074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36073_36074 : H12AffineEnvironment.transform 12 268 env36073 = env36074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36073 == env36074) = true)

theorem identity36074 : scanCanonicalize (H12AffineFastState.compose env36074 (packedSelected [0,3,4,7,10,11,12,15,17,18,19,22,24] rootPS)) = affineNative (2^(16+1) ^^^ 38344) := by decide +kernel

theorem selectedBound36074 : packedSelected [0,3,4,7,10,11,12,15,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env36075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,21647,38344,23588,1025,32769,17864,32880,16,54611,388,65,2129,16537,4233,2557,1500,169,257,168,49153,22409]

theorem envBound36075 : H12AffineFastState.Bounded env36075 := by
  intro p hp
  have h : env36075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36074_36075 : H12AffineEnvironment.transform 16 38344 env36074 = env36075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38344 env36074 == env36075) = true)

theorem identity36075 : scanCanonicalize (H12AffineFastState.compose env36075 (packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound36075 : packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env36076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,81,21647,5529,23588,1025,80,17864,33,16,21762,388,65,2129,16537,4233,2557,1500,169,257,168,16464,22409]

theorem envBound36076 : H12AffineFastState.Bounded env36076 := by
  intro p hp
  have h : env36076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36075_36076 : H12AffineEnvironment.transform 14 81 env36075 = env36076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env36075 == env36076) = true)

theorem identity36076 : scanCanonicalize (H12AffineFastState.compose env36076 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound36076 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env36077 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,240,16384,81,21647,5221,23588,1025,80,17460,33,16,21758,120,65,2129,16537,4233,2049,1056,169,253,168,16464,22133]

theorem envBound36077 : H12AffineFastState.Bounded env36077 := by
  intro p hp
  have h : env36077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36076_36077 : H12AffineEnvironment.transform 7 252 env36076 = env36077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env36076 == env36077) = true)

theorem identity36077 : scanCanonicalize (H12AffineFastState.compose env36077 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound36077 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env36078 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,240,5372,81,115,5221,2264,1025,80,4296,33,16,2,120,65,2129,5221,4233,2049,1056,169,253,168,5292,649]

theorem envBound36078 : H12AffineFastState.Bounded env36078 := by
  intro p hp
  have h : env36078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36077_36078 : H12AffineEnvironment.transform 13 5372 env36077 = env36078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env36077 == env36078) = true)

theorem identity36078 : scanCanonicalize (H12AffineFastState.compose env36078 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36078 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36079 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,81,115,5221,2129,1025,80,4161,33,16,2,120,65,2129,5221,4096,2049,1056,32,116,33,5157,512]

theorem envBound36079 : H12AffineFastState.Bounded env36079 := by
  intro p hp
  have h : env36079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36078_36079 : H12AffineEnvironment.transform 6 9 env36078 = env36079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36078 == env36079) = true)

theorem identity36079 : scanCanonicalize (H12AffineFastState.compose env36079 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36079 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36080 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,88,5204,81,82,5188,2129,1025,80,4161,0,16,2,89,65,2129,5188,4096,2049,1025,1,85,0,5124,512]

theorem envBound36080 : H12AffineFastState.Bounded env36080 := by
  intro p hp
  have h : env36080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36079_36080 : H12AffineEnvironment.transform 4 1 env36079 = env36080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36079 == env36080) = true)

theorem identity36080 : scanCanonicalize (H12AffineFastState.compose env36080 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36080 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36081 : List Nat := [2,4,8,16,1,64,9,84,512,1024,0,4096,88,5204,81,82,5188,81,1025,80,4161,0,16,2,89,65,81,5188,4096,1,1025,1,85,0,5124,512]

theorem envBound36081 : H12AffineFastState.Bounded env36081 := by
  intro p hp
  have h : env36081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36080_36081 : H12AffineEnvironment.transform 10 0 env36080 = env36081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36080 == env36081) = true)

def env36082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98780,8328,65,4340964,79130,91403,179512,1501,4314198,257,95530,103567,74251]

theorem envBound36082 : H12AffineFastState.Bounded env36082 := by
  intro p hp
  have h : env36082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36070_36082 : H12AffineEnvironment.transform 22 17 env36070 = env36082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env36070 == env36082) = true)

theorem identity36082 : scanCanonicalize (H12AffineFastState.compose env36082 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound36082 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32040,1025,29909,77899,4194304,17,95496,8328,65,4340964,79130,91403,149996,1501,4268162,257,95530,90203,74251]

theorem envBound36083 : H12AffineFastState.Bounded env36083 := by
  intro p hp
  have h : env36083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36082_36083 : H12AffineEnvironment.transform 14 29908 env36082 = env36083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env36082 == env36083) = true)

def env36084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10280,1025,8661,77899,4194304,17,73736,8328,65,4340964,79130,77835,138476,1501,4268162,257,73770,79195,74251]

theorem envBound36084 : H12AffineFastState.Bounded env36084 := by
  intro p hp
  have h : env36084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36083_36084 : H12AffineEnvironment.transform 13 5376 env36083 = env36084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36083 == env36084) = true)

theorem identity36084 : scanCanonicalize (H12AffineFastState.compose env36084 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36084 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1025,8541,77899,4194304,17,73736,8192,65,4340844,79130,77835,138340,1365,4268042,257,73770,79195,74251]

theorem envBound36085 : H12AffineFastState.Bounded env36085 := by
  intro p hp
  have h : env36085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36084_36085 : H12AffineEnvironment.transform 6 8 env36084 = env36085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36084 == env36085) = true)

theorem identity36085 : scanCanonicalize (H12AffineFastState.compose env36085 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36085 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10280,1025,8541,4161,4194304,17,2,8192,65,4340844,5392,4097,138340,1365,4194304,257,32,5457,513]

theorem envBound36086 : H12AffineFastState.Bounded env36086 := by
  intro p hp
  have h : env36086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36085_36086 : H12AffineEnvironment.transform 15 8202 env36085 = env36086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36085 == env36086) = true)

theorem identity36086 : scanCanonicalize (H12AffineFastState.compose env36086 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound36086 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10280,1025,8541,4161,136496,17,2,8192,65,10588,5392,4097,138340,1365,136496,257,32,5457,513]

theorem envBound36087 : H12AffineFastState.Bounded env36087 := by
  intro p hp
  have h : env36087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36086_36087 : H12AffineEnvironment.transform 21 136496 env36086 = env36087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env36086 == env36087) = true)

theorem identity36087 : scanCanonicalize (H12AffineFastState.compose env36087 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound36087 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10280,1025,8541,4161,33,17,2,8192,65,10588,5392,4097,2421,1365,33,257,32,5457,513]

theorem envBound36088 : H12AffineFastState.Bounded env36088 := by
  intro p hp
  have h : env36088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36087_36088 : H12AffineEnvironment.transform 16 5393 env36087 = env36088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env36087 == env36088) = true)

theorem identity36088 : scanCanonicalize (H12AffineFastState.compose env36088 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound36088 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,380,5376,32,374,5393,2388,1025,33,4161,33,17,2,380,65,2080,5392,4097,2421,1365,33,257,32,5457,513]

theorem envBound36089 : H12AffineFastState.Bounded env36089 := by
  intro p hp
  have h : env36089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36088_36089 : H12AffineEnvironment.transform 12 380 env36088 = env36089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env36088 == env36089) = true)

theorem identity36089 : scanCanonicalize (H12AffineFastState.compose env36089 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36089 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env36090 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,301,5376,32,295,5393,2309,1025,33,4112,33,17,2,301,16,2080,5392,4097,2340,1284,33,257,32,5376,513]

theorem envBound36090 : H12AffineFastState.Bounded env36090 := by
  intro p hp
  have h : env36090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36089_36090 : H12AffineEnvironment.transform 5 17 env36089 = env36090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36089 == env36090) = true)

theorem identity36090 : scanCanonicalize (H12AffineFastState.compose env36090 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound36090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36091 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,4096,301,4388,32,295,4405,2309,37,33,4112,33,17,2,301,16,2080,4404,4097,2340,288,33,257,32,4388,513]

theorem envBound36091 : H12AffineFastState.Bounded env36091 := by
  intro p hp
  have h : env36091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36090_36091 : H12AffineEnvironment.transform 9 36 env36090 = env36091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env36090 == env36091) = true)

theorem identity36091 : scanCanonicalize (H12AffineFastState.compose env36091 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound36091 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36092 : List Nat := [2,4,8,16,32,17,8,256,512,36,561,4096,301,4388,32,295,4405,820,37,33,4112,33,17,2,301,16,529,4404,4097,789,288,33,257,32,4388,513]

theorem envBound36092 : H12AffineFastState.Bounded env36092 := by
  intro p hp
  have h : env36092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36091_36092 : H12AffineEnvironment.transform 10 561 env36091 = env36092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env36091 == env36092) = true)

def env36093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10281,1025,8660,77899,4194304,17,73737,8328,65,4340964,79130,77834,138477,1501,4268162,257,73771,79194,74251]

theorem envBound36093 : H12AffineFastState.Bounded env36093 := by
  intro p hp
  have h : env36093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36083_36093 : H12AffineEnvironment.transform 13 5377 env36083 = env36093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36083 == env36093) = true)

theorem identity36093 : scanCanonicalize (H12AffineFastState.compose env36093 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound36093 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,5392,10281,1025,8660,77899,4194304,17,73737,8328,65,4205044,79130,77834,2557,1501,4268162,257,73771,79194,74251]

theorem envBound36094 : H12AffineFastState.Bounded env36094 := by
  intro p hp
  have h : env36094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36093_36094 : H12AffineEnvironment.transform 16 5392 env36093 = env36094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env36093 == env36094) = true)

theorem identity36094 : scanCanonicalize (H12AffineFastState.compose env36094 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound36094 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,9498,5392,10281,1025,8660,5457,4194304,17,1299,8328,65,4205044,4096,5392,2557,1501,4195736,257,1329,4160,1809]

theorem envBound36095 : H12AffineFastState.Bounded env36095 := by
  intro p hp
  have h : env36095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36094_36095 : H12AffineEnvironment.transform 15 9498 env36094 = env36095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env36094 == env36095) = true)

theorem identity36095 : scanCanonicalize (H12AffineFastState.compose env36095 (packedSelected [0,4,7,22,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound36095 : packedSelected [0,4,7,22,23,32] rootPS < 2^1333 := by decide +kernel

def env36096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1336,5377,1261,34,5392,3345,1025,1260,5457,4194304,17,1299,1456,65,4197580,4096,5392,2557,1501,4195736,257,1329,4160,1809]

theorem envBound36096 : H12AffineFastState.Bounded env36096 := by
  intro p hp
  have h : env36096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36095_36096 : H12AffineEnvironment.transform 12 1336 env36095 = env36096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env36095 == env36096) = true)

theorem identity36096 : scanCanonicalize (H12AffineFastState.compose env36096 (packedSelected [0,2,6,12,14,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36096 : packedSelected [0,2,6,12,14,27,38] rootPS < 2^1333 := by decide +kernel

def env36097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5377,1124,34,5392,3345,1025,1125,5457,4194304,17,1299,1337,65,4197445,4096,5392,2420,1364,4195601,257,1329,4160,1809]

theorem envBound36097 : H12AffineFastState.Bounded env36097 := by
  intro p hp
  have h : env36097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36096_36097 : H12AffineEnvironment.transform 6 9 env36096 = env36097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36096 == env36097) = true)

theorem identity36097 : scanCanonicalize (H12AffineFastState.compose env36097 (packedSelected [0,4,7,11,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 1329) := by decide +kernel

theorem selectedBound36097 : packedSelected [0,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env36098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5377,1124,34,5392,3345,1025,1125,5457,1329,17,1299,1337,65,2420,4096,5392,2420,1364,32,257,1329,4160,1809]

theorem envBound36098 : H12AffineFastState.Bounded env36098 := by
  intro p hp
  have h : env36098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36097_36098 : H12AffineEnvironment.transform 21 1329 env36097 = env36098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1329 env36097 == env36098) = true)

theorem identity36098 : scanCanonicalize (H12AffineFastState.compose env36098 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound36098 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env36099 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,41,4112,373,34,4097,2048,272,372,4160,32,17,2,40,65,2420,4096,4097,2420,69,32,257,32,4160,512]

theorem envBound36099 : H12AffineFastState.Bounded env36099 := by
  intro p hp
  have h : env36099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36098_36099 : H12AffineEnvironment.transform 9 273 env36098 = env36099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env36098 == env36099) = true)

theorem identity36099 : scanCanonicalize (H12AffineFastState.compose env36099 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36100 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,41,4112,293,34,4097,2048,272,292,4112,32,17,2,40,17,2340,4096,4097,2340,21,32,257,32,4112,512]

theorem envBound36100 : H12AffineFastState.Bounded env36100 := by
  intro p hp
  have h : env36100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36099_36100 : H12AffineEnvironment.transform 5 16 env36099 = env36100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36099 == env36100) = true)

theorem identity36100 : scanCanonicalize (H12AffineFastState.compose env36100 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36100 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36101 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8,4112,260,3,4097,2048,272,261,4112,1,17,2,9,17,2309,4096,4097,2309,21,1,257,1,4112,512]

theorem envBound36101 : H12AffineFastState.Bounded env36101 := by
  intro p hp
  have h : env36101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36100_36101 : H12AffineEnvironment.transform 4 1 env36100 = env36101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36100 == env36101) = true)

theorem identity36101 : scanCanonicalize (H12AffineFastState.compose env36101 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36101 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36102 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,4096,8,4112,0,3,4097,2048,20,1,4112,1,17,2,9,17,2049,4096,4097,2049,21,1,5,1,4112,512]

theorem envBound36102 : H12AffineFastState.Bounded env36102 := by
  intro p hp
  have h : env36102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36101_36102 : H12AffineEnvironment.transform 7 4 env36101 = env36102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36101 == env36102) = true)

theorem identity36102 : scanCanonicalize (H12AffineFastState.compose env36102 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound36102 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36103 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,0,0,3,17,2048,20,1,0,1,17,2,9,17,2049,16,17,2049,21,1,5,1,0,512]

theorem envBound36103 : H12AffineFastState.Bounded env36103 := by
  intro p hp
  have h : env36103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36102_36103 : H12AffineEnvironment.transform 11 16 env36102 = env36103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36102 == env36103) = true)

theorem identity36103 : scanCanonicalize (H12AffineFastState.compose env36103 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound36103 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36104 : List Nat := [2,4,8,16,1,16,9,4,512,21,543,16,8,0,0,3,17,543,20,1,0,1,17,2,9,17,542,16,17,542,21,1,5,1,0,512]

theorem envBound36104 : H12AffineFastState.Bounded env36104 := by
  intro p hp
  have h : env36104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36103_36104 : H12AffineEnvironment.transform 10 543 env36103 = env36104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env36103 == env36104) = true)

theorem identity36104 : scanCanonicalize (H12AffineFastState.compose env36104 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36104 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36105 : List Nat := [2,4,8,16,1,16,9,4,0,21,31,16,8,0,0,3,17,31,20,1,0,1,17,2,9,17,30,16,17,30,21,1,5,1,0,0]

theorem envBound36105 : H12AffineFastState.Bounded env36105 := by
  intro p hp
  have h : env36105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36104_36105 : H12AffineEnvironment.transform 8 0 env36104 = env36105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36104 == env36105) = true)

theorem identity36105 : scanCanonicalize (H12AffineFastState.compose env36105 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36105 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36106 : List Nat := [2,4,8,0,1,0,9,4,0,5,15,0,8,0,0,3,1,15,4,1,0,1,1,2,9,1,14,0,1,14,5,1,5,1,0,0]

theorem envBound36106 : H12AffineFastState.Bounded env36106 := by
  intro p hp
  have h : env36106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36105_36106 : H12AffineEnvironment.transform 3 0 env36105 = env36106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36105 == env36106) = true)

def env36107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,8388608,98781,8328,65,12729589,79130,8480027,8568104,8390093,4314198,257,8484155,8492190,8462875]

theorem envBound36107 : H12AffineFastState.Bounded env36107 := by
  intro p hp
  have h : env36107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36069_36107 : H12AffineEnvironment.transform 17 32041 env36069 = env36107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env36069 == env36107) = true)

def env36108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,16,98781,8328,65,4340965,79130,91403,179512,1501,4314198,257,95531,103566,74251]

theorem envBound36108 : H12AffineFastState.Bounded env36108 := by
  intro p hp
  have h : env36108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36107_36108 : H12AffineEnvironment.transform 22 16 env36107 = env36108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env36107 == env36108) = true)

theorem identity36108 : scanCanonicalize (H12AffineFastState.compose env36108 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21929) := by decide +kernel

theorem selectedBound36108 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,21929,16,98781,8328,65,158028,79130,91403,179512,1501,98815,257,95531,103566,74251]

theorem envBound36109 : H12AffineFastState.Bounded env36109 := by
  intro p hp
  have h : env36109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36108_36109 : H12AffineEnvironment.transform 21 21929 env36108 = env36109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21929 env36108 == env36109) = true)

theorem identity36109 : scanCanonicalize (H12AffineFastState.compose env36109 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36109 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env36110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4160,21929,16,41431,8328,65,158028,5392,17665,179512,1501,41461,257,21793,46212,513]

theorem envBound36110 : H12AffineFastState.Bounded env36110 := by
  intro p hp
  have h : env36110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36109_36110 : H12AffineEnvironment.transform 15 8202 env36109 = env36110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36109 == env36110) = true)

theorem identity36110 : scanCanonicalize (H12AffineFastState.compose env36110 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound36110 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,32041,1025,32769,4160,21929,16,41431,8328,65,10589,5392,17665,64809,1501,41461,257,21793,46212,513]

theorem envBound36111 : H12AffineFastState.Bounded env36111 := by
  intro p hp
  have h : env36111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36110_36111 : H12AffineEnvironment.transform 16 16401 env36110 = env36111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36110 == env36111) = true)

def env36112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98781,8328,65,4340964,79130,91402,179513,1500,4314198,257,95530,103567,74250]

theorem envBound36112 : H12AffineFastState.Bounded env36112 := by
  intro p hp
  have h : env36112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36107_36112 : H12AffineEnvironment.transform 22 17 env36107 = env36112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env36107 == env36112) = true)

def env36113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98645,8192,65,4340844,79130,91402,179513,1364,4314198,257,95530,103431,74250]

theorem envBound36113 : H12AffineFastState.Bounded env36113 := by
  intro p hp
  have h : env36113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36112_36113 : H12AffineEnvironment.transform 6 8 env36112 = env36113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36112 == env36113) = true)

theorem identity36113 : scanCanonicalize (H12AffineFastState.compose env36113 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36113 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,4194304,17,41310,8192,65,4340844,5393,17665,179513,1364,4256861,257,21793,46092,513]

theorem envBound36114 : H12AffineFastState.Bounded env36114 := by
  intro p hp
  have h : env36114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36113_36114 : H12AffineEnvironment.transform 15 8203 env36113 = env36114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36113 == env36114) = true)

theorem identity36114 : scanCanonicalize (H12AffineFastState.compose env36114 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound36114 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env36115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4161,4194304,17,21763,8192,65,4340844,5393,17665,149860,1364,4194304,257,21793,16465,513]

theorem envBound36115 : H12AffineFastState.Bounded env36115 := by
  intro p hp
  have h : env36115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36114_36115 : H12AffineEnvironment.transform 14 29789 env36114 = env36115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env36114 == env36115) = true)

theorem identity36115 : scanCanonicalize (H12AffineFastState.compose env36115 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound36115 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env36116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4161,21873,17,21763,8192,65,157981,5393,17665,149860,1364,21873,257,21793,16465,513]

theorem envBound36116 : H12AffineFastState.Bounded env36116 := by
  intro p hp
  have h : env36116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36115_36116 : H12AffineEnvironment.transform 21 21873 env36115 = env36116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env36115 == env36116) = true)

theorem identity36116 : scanCanonicalize (H12AffineFastState.compose env36116 (packedSelected [0,2,4,6,7,9,11,14,32] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound36116 : packedSelected [0,2,4,6,7,9,11,14,32] rootPS < 2^1333 := by decide +kernel

def env36117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8203,131072,10361,1025,8460,4161,33,17,83,8192,65,146509,5393,4177,138292,1364,33,257,113,5377,513]

theorem envBound36117 : H12AffineFastState.Bounded env36117 := by
  intro p hp
  have h : env36117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36116_36117 : H12AffineEnvironment.transform 13 5456 env36116 = env36117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env36116 == env36117) = true)

theorem identity36117 : scanCanonicalize (H12AffineFastState.compose env36117 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound36117 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env36118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8203,13389,10361,1025,8460,4161,33,17,83,8192,65,2048,5393,4177,10361,1364,33,257,113,5377,513]

theorem envBound36118 : H12AffineFastState.Bounded env36118 := by
  intro p hp
  have h : env36118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36117_36118 : H12AffineEnvironment.transform 16 13389 env36117 = env36118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env36117 == env36118) = true)

theorem identity36118 : scanCanonicalize (H12AffineFastState.compose env36118 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36118 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36119 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,13340,10280,1025,8460,4112,33,17,2,8192,16,2048,5393,4096,10280,1285,33,257,32,5377,513]

theorem envBound36119 : H12AffineFastState.Bounded env36119 := by
  intro p hp
  have h : env36119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36118_36119 : H12AffineEnvironment.transform 5 17 env36118 = env36119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36118 == env36119) = true)

theorem identity36119 : scanCanonicalize (H12AffineFastState.compose env36119 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36119 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36120 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5393,2341,1025,1,4112,33,17,2,269,16,2048,5393,4096,2341,1285,33,257,32,5377,513]

theorem envBound36120 : H12AffineFastState.Bounded env36120 := by
  intro p hp
  have h : env36120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36119_36120 : H12AffineEnvironment.transform 12 269 env36119 = env36120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36119 == env36120) = true)

theorem identity36120 : scanCanonicalize (H12AffineFastState.compose env36120 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36121 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,0,35,5172,2048,1025,1,4112,33,17,2,40,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound36121 : H12AffineFastState.Bounded env36121 := by
  intro p hp
  have h : env36121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36120_36121 : H12AffineEnvironment.transform 7 37 env36120 = env36121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36120 == env36121) = true)

def env36122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98644,8193,65,4340845,79130,91402,179513,1365,4314198,257,95530,103430,74250]

theorem envBound36122 : H12AffineFastState.Bounded env36122 := by
  intro p hp
  have h : env36122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36112_36122 : H12AffineEnvironment.transform 6 9 env36112 = env36122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36112 == env36122) = true)

theorem identity36122 : scanCanonicalize (H12AffineFastState.compose env36122 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36122 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,32041,1025,8541,77898,4194304,17,73736,8193,65,4340845,79130,91402,138341,1365,4289802,257,95530,79194,74250]

theorem envBound36123 : H12AffineFastState.Bounded env36123 := by
  intro p hp
  have h : env36123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36122_36123 : H12AffineEnvironment.transform 14 8540 env36122 = env36123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36122 == env36123) = true)

theorem identity36123 : scanCanonicalize (H12AffineFastState.compose env36123 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound36123 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,32041,1025,8541,77898,136497,17,73736,8193,65,10588,79130,91402,138341,1365,221243,257,95530,79194,74250]

theorem envBound36124 : H12AffineFastState.Bounded env36124 := by
  intro p hp
  have h : env36124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36123_36124 : H12AffineEnvironment.transform 21 136497 env36123 = env36124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env36123 == env36124) = true)

def env36125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,32041,1025,8541,77898,21793,17,73736,8193,65,10588,79130,91402,23669,1365,73771,257,95530,79194,74250]

theorem envBound36125 : H12AffineFastState.Bounded env36125 := by
  intro p hp
  have h : env36125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36124_36125 : H12AffineEnvironment.transform 16 16400 env36124 = env36125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36124 == env36125) = true)

theorem identity36125 : scanCanonicalize (H12AffineFastState.compose env36125 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36125 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,34,16400,32041,1025,8541,12392,21793,17,8234,8193,65,10588,13624,25896,23669,1365,8201,257,29960,13688,8744]

theorem envBound36126 : H12AffineFastState.Bounded env36126 := by
  intro p hp
  have h : env36126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36125_36126 : H12AffineEnvironment.transform 15 34 env36125 = env36126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36125 == env36126) = true)

theorem identity36126 : scanCanonicalize (H12AffineFastState.compose env36126 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound36126 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,34,5220,10589,1025,8541,12392,341,17,8234,8193,65,10588,13624,12636,2049,1365,8201,257,8572,13688,8744]

theorem envBound36127 : H12AffineFastState.Bounded env36127 := by
  intro p hp
  have h : env36127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36126_36127 : H12AffineEnvironment.transform 13 5236 env36126 = env36127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env36126 == env36127) = true)

theorem identity36127 : scanCanonicalize (H12AffineFastState.compose env36127 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36127 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env36128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,373,34,5220,2420,1025,372,4161,341,17,3,40,65,2421,5393,4469,2049,1365,32,257,341,5457,513]

theorem envBound36128 : H12AffineFastState.Bounded env36128 := by
  intro p hp
  have h : env36128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36127_36128 : H12AffineEnvironment.transform 12 41 env36127 = env36128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36127 == env36128) = true)

theorem identity36128 : scanCanonicalize (H12AffineFastState.compose env36128 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36128 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36129 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,5236,81,34,5220,2128,1025,80,4161,113,17,3,40,65,2129,5173,4177,2049,1137,32,37,113,5237,513]

theorem envBound36129 : H12AffineFastState.Bounded env36129 := by
  intro p hp
  have h : env36129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36128_36129 : H12AffineEnvironment.transform 7 36 env36128 = env36129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36128 == env36129) = true)

theorem identity36129 : scanCanonicalize (H12AffineFastState.compose env36129 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36129 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36130 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,41,4112,81,34,4096,2128,101,80,4161,113,17,3,40,65,2129,4177,4177,2049,21,32,37,113,4113,513]

theorem envBound36130 : H12AffineFastState.Bounded env36130 := by
  intro p hp
  have h : env36130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36129_36130 : H12AffineEnvironment.transform 9 100 env36129 = env36130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36129 == env36130) = true)

def env36131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,32041,1025,8541,77898,21792,17,73736,8193,65,10588,79130,91402,23668,1365,73770,257,95530,79194,74250]

theorem envBound36131 : H12AffineFastState.Bounded env36131 := by
  intro p hp
  have h : env36131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36124_36131 : H12AffineEnvironment.transform 16 16401 env36124 = env36131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36124 == env36131) = true)

theorem identity36131 : scanCanonicalize (H12AffineFastState.compose env36131 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound36131 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,374,16401,32041,1025,8541,12604,21792,17,8574,8193,65,10588,13420,25724,23668,1365,8540,257,29788,13356,9084]

theorem envBound36132 : H12AffineFastState.Bounded env36132 := by
  intro p hp
  have h : env36132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36131_36132 : H12AffineEnvironment.transform 15 374 env36131 = env36132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env36131 == env36132) = true)

def env36133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,392437,8328,65,12729588,79131,8722482,8830977,8681701,4314199,257,8484154,8492191,8740659]

theorem envBound36133 : H12AffineFastState.Bounded env36133 := by
  intro p hp
  have h : env36133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36068_36133 : H12AffineEnvironment.transform 23 392437 env36068 = env36133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392437 env36068 == env36133) = true)

def env36134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,8388608,98781,8328,65,12729588,79131,8480026,8568105,8390093,4314199,257,8484154,8492191,8462875]

theorem envBound36134 : H12AffineFastState.Bounded env36134 := by
  intro p hp
  have h : env36134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36133_36134 : H12AffineEnvironment.transform 17 32040 env36133 = env36134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env36133 == env36134) = true)

def env36135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,16,98781,8328,65,4340964,79131,91402,179513,1501,4314199,257,95530,103567,74251]

theorem envBound36135 : H12AffineFastState.Bounded env36135 := by
  intro p hp
  have h : env36135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36134_36135 : H12AffineEnvironment.transform 22 16 env36134 = env36135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env36134 == env36135) = true)

theorem identity36135 : scanCanonicalize (H12AffineFastState.compose env36135 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95650) := by decide +kernel

theorem selectedBound36135 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,95650,16,98781,8328,65,215366,79131,91402,179513,1501,41461,257,95530,103567,74251]

theorem envBound36136 : H12AffineFastState.Bounded env36136 := by
  intro p hp
  have h : env36136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36135_36136 : H12AffineEnvironment.transform 21 95650 env36135 = env36136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95650 env36135 == env36136) = true)

def env36137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,95530,16,98645,8192,65,215366,79131,91402,179513,1365,41341,257,95530,103431,74251]

theorem envBound36137 : H12AffineFastState.Bounded env36137 := by
  intro p hp
  have h : env36137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36136_36137 : H12AffineEnvironment.transform 6 8 env36136 = env36137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36136 == env36137) = true)

theorem identity36137 : scanCanonicalize (H12AffineFastState.compose env36137 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36137 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,77899,73770,16,98645,8192,65,203846,79131,77834,179513,1365,41341,257,73770,103431,74251]

theorem envBound36138 : H12AffineFastState.Bounded env36138 := by
  intro p hp
  have h : env36138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36137_36138 : H12AffineEnvironment.transform 13 5376 env36137 = env36138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36137 == env36138) = true)

theorem identity36138 : scanCanonicalize (H12AffineFastState.compose env36138 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36138 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env36139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10280,1025,32769,4160,33,16,41310,8192,65,146509,5392,4097,179513,1365,41341,257,33,46092,512]

theorem envBound36139 : H12AffineFastState.Bounded env36139 := by
  intro p hp
  have h : env36139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36138_36139 : H12AffineEnvironment.transform 15 8203 env36138 = env36139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36138 == env36139) = true)

theorem identity36139 : scanCanonicalize (H12AffineFastState.compose env36139 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound36139 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5376,32768,1330,131072,3345,1025,32769,4160,33,16,33895,1337,65,137588,5392,4097,169984,1365,33860,257,33,37173,512]

theorem envBound36140 : H12AffineFastState.Bounded env36140 := by
  intro p hp
  have h : env36140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36139_36140 : H12AffineEnvironment.transform 12 1337 env36139 = env36140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env36139 == env36140) = true)

theorem identity36140 : scanCanonicalize (H12AffineFastState.compose env36140 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 4113) := by decide +kernel

theorem selectedBound36140 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env36141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5376,4113,1330,131072,3345,1025,4112,4160,33,16,5238,1337,65,137588,5392,4097,133137,1365,5205,257,33,292,512]

theorem envBound36141 : H12AffineFastState.Bounded env36141 := by
  intro p hp
  have h : env36141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36140_36141 : H12AffineEnvironment.transform 14 4113 env36140 = env36141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4113 env36140 == env36141) = true)

theorem identity36141 : scanCanonicalize (H12AffineFastState.compose env36141 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound36141 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env36142 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1281,1337,1,1296,1330,131072,3345,1025,1297,1345,33,16,375,1337,65,134261,17,1280,133137,1365,340,257,33,292,512]

theorem envBound36142 : H12AffineFastState.Bounded env36142 := by
  intro p hp
  have h : env36142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36141_36142 : H12AffineEnvironment.transform 11 1281 env36141 = env36142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env36141 == env36142) = true)

theorem identity36142 : scanCanonicalize (H12AffineFastState.compose env36142 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound36142 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,1281,1337,1,1296,1330,131072,1125,1025,1297,1345,33,16,375,1337,65,132353,17,1280,131429,1365,340,257,33,292,512]

theorem envBound36143 : H12AffineFastState.Bounded env36143 := by
  intro p hp
  have h : env36143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36142_36143 : H12AffineEnvironment.transform 10 372 env36142 = env36143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env36142 == env36143) = true)

theorem identity36143 : scanCanonicalize (H12AffineFastState.compose env36143 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound36143 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env36144 : List Nat := [2,4,8,16,32,64,8,256,512,273,372,16,40,1,1,35,131072,372,272,0,80,33,16,375,40,65,131088,17,17,131429,68,340,257,33,292,512]

theorem envBound36144 : H12AffineFastState.Bounded env36144 := by
  intro p hp
  have h : env36144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36143_36144 : H12AffineEnvironment.transform 9 273 env36143 = env36144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env36143 == env36144) = true)

theorem identity36144 : scanCanonicalize (H12AffineFastState.compose env36144 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound36144 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36145 : List Nat := [2,4,8,16,32,64,8,85,512,68,33,16,40,1,1,35,131072,33,69,0,80,33,16,34,40,65,131088,17,17,131120,68,1,84,33,113,512]

theorem envBound36145 : H12AffineFastState.Bounded env36145 := by
  intro p hp
  have h : env36145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36144_36145 : H12AffineEnvironment.transform 7 85 env36144 = env36145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env36144 == env36145) = true)

theorem identity36145 : scanCanonicalize (H12AffineFastState.compose env36145 (packedSelected [4,6,7] rootPS)) = affineNative (2^(16+1) ^^^ 48) := by decide +kernel

theorem selectedBound36145 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env36146 : List Nat := [2,4,8,16,32,64,8,85,512,68,33,16,40,1,1,35,48,33,69,0,80,33,16,34,40,65,32,17,17,0,68,1,84,33,113,512]

theorem envBound36146 : H12AffineFastState.Bounded env36146 := by
  intro p hp
  have h : env36146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36145_36146 : H12AffineEnvironment.transform 16 48 env36145 = env36146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 48 env36145 == env36146) = true)

theorem identity36146 : scanCanonicalize (H12AffineFastState.compose env36146 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36146 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36147 : List Nat := [2,4,8,16,32,17,8,4,512,21,33,16,40,1,1,35,48,33,20,0,1,33,16,34,40,16,32,17,17,0,21,1,5,33,32,512]

theorem envBound36147 : H12AffineFastState.Bounded env36147 := by
  intro p hp
  have h : env36147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36146_36147 : H12AffineEnvironment.transform 5 17 env36146 = env36147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36146 == env36147) = true)

theorem identity36147 : scanCanonicalize (H12AffineFastState.compose env36147 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36147 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36148 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,16,9,1,1,2,17,0,20,0,1,0,16,3,9,16,1,17,17,0,21,1,5,0,1,512]

theorem envBound36148 : H12AffineFastState.Bounded env36148 := by
  intro p hp
  have h : env36148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36147_36148 : H12AffineEnvironment.transform 4 1 env36147 = env36148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36147 == env36148) = true)

theorem identity36148 : scanCanonicalize (H12AffineFastState.compose env36148 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound36148 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36149 : List Nat := [2,4,8,16,1,17,8,4,5,21,0,16,9,1,1,2,17,0,20,0,1,0,16,3,9,16,1,17,17,0,21,1,5,0,1,5]

theorem envBound36149 : H12AffineFastState.Bounded env36149 := by
  intro p hp
  have h : env36149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36148_36149 : H12AffineEnvironment.transform 8 5 env36148 = env36149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env36148 == env36149) = true)

theorem identity36149 : scanCanonicalize (H12AffineFastState.compose env36149 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound36149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36150 : List Nat := [2,4,1,16,1,17,1,4,5,21,0,16,0,1,1,2,17,0,20,0,1,0,16,3,0,16,1,17,17,0,21,1,5,0,1,5]

theorem envBound36150 : H12AffineFastState.Bounded env36150 := by
  intro p hp
  have h : env36150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36149_36150 : H12AffineEnvironment.transform 2 1 env36149 = env36150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env36149 == env36150) = true)

theorem identity36150 : scanCanonicalize (H12AffineFastState.compose env36150 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36150 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36151 : List Nat := [2,2,1,16,1,17,1,2,3,19,0,16,0,1,1,2,17,0,18,0,1,0,16,3,0,16,1,17,17,0,19,1,3,0,1,3]

theorem envBound36151 : H12AffineFastState.Bounded env36151 := by
  intro p hp
  have h : env36151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36150_36151 : H12AffineEnvironment.transform 1 2 env36150 = env36151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36150 == env36151) = true)

def env36152 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,95531,16,98644,8193,65,215366,79131,91402,179513,1364,41340,257,95530,103430,74251]

theorem envBound36152 : H12AffineFastState.Bounded env36152 := by
  intro p hp
  have h : env36152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36136_36152 : H12AffineEnvironment.transform 6 9 env36136 = env36152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36136 == env36152) = true)

theorem identity36152 : scanCanonicalize (H12AffineFastState.compose env36152 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound36152 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36153 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,77899,95531,16,95497,8193,65,215366,79131,91402,149860,1364,21793,257,95530,90203,74251]

theorem envBound36153 : H12AffineFastState.Bounded env36153 := by
  intro p hp
  have h : env36153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36152_36153 : H12AffineEnvironment.transform 14 29789 env36152 = env36153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env36152 == env36153) = true)

theorem identity36153 : scanCanonicalize (H12AffineFastState.compose env36153 (packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36153 : packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env36154 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,21792,16,21762,8193,65,158029,5392,17665,149860,1364,21793,257,21793,16464,512]

theorem envBound36154 : H12AffineFastState.Bounded env36154 := by
  intro p hp
  have h : env36154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36153_36154 : H12AffineEnvironment.transform 15 8203 env36153 = env36154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36153 == env36154) = true)

theorem identity36154 : scanCanonicalize (H12AffineFastState.compose env36154 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound36154 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36155 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,373,8203,131072,2048,1025,372,4160,8200,16,8234,8193,65,138341,5392,12329,146508,1364,8201,257,8201,13688,512]

theorem envBound36155 : H12AffineFastState.Bounded env36155 := by
  intro p hp
  have h : env36155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36154_36155 : H12AffineEnvironment.transform 13 13608 env36154 = env36155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env36154 == env36155) = true)

theorem identity36155 : scanCanonicalize (H12AffineFastState.compose env36155 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36155 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5157,373,262,131072,2048,1025,372,4160,261,16,295,268,65,138341,5392,4388,138561,1364,260,257,260,5237,512]

theorem envBound36156 : H12AffineFastState.Bounded env36156 := by
  intro p hp
  have h : env36156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36155_36156 : H12AffineEnvironment.transform 12 269 env36155 = env36156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36155 == env36156) = true)

theorem identity36156 : scanCanonicalize (H12AffineFastState.compose env36156 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36156 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env36157 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5157,292,262,131072,2048,1025,293,4113,261,16,295,268,16,138292,5392,4388,138512,1285,260,257,260,5156,512]

theorem envBound36157 : H12AffineFastState.Bounded env36157 := by
  intro p hp
  have h : env36157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36156_36157 : H12AffineEnvironment.transform 5 17 env36156 = env36157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36156 == env36157) = true)

theorem identity36157 : scanCanonicalize (H12AffineFastState.compose env36157 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36157 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36158 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5125,260,262,131072,2048,1025,261,4113,261,16,263,268,16,138260,5392,4356,138512,1285,260,257,260,5124,512]

theorem envBound36158 : H12AffineFastState.Bounded env36158 := by
  intro p hp
  have h : env36158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36157_36158 : H12AffineEnvironment.transform 4 0 env36157 = env36158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36157 == env36158) = true)

theorem identity36158 : scanCanonicalize (H12AffineFastState.compose env36158 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound36158 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36159 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,269,5125,260,262,5140,2048,1025,261,4113,261,16,263,268,16,2048,5392,4356,2308,1285,260,257,260,5124,512]

theorem envBound36159 : H12AffineFastState.Bounded env36159 := by
  intro p hp
  have h : env36159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36158_36159 : H12AffineEnvironment.transform 16 5140 env36158 = env36159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env36158 == env36159) = true)

theorem identity36159 : scanCanonicalize (H12AffineFastState.compose env36159 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound36159 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36160 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1280,4096,269,5125,260,262,5140,1280,1025,261,4113,261,16,263,268,16,1280,5392,4356,1028,1285,260,257,260,5124,512]

theorem envBound36160 : H12AffineFastState.Bounded env36160 := by
  intro p hp
  have h : env36160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36159_36160 : H12AffineEnvironment.transform 10 1280 env36159 = env36160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env36159 == env36160) = true)

theorem identity36160 : scanCanonicalize (H12AffineFastState.compose env36160 (packedSelected [3,8] rootPS)) = affineNative (2^(11+1) ^^^ 1809) := by decide +kernel

theorem selectedBound36160 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env36161 : List Nat := [2,4,8,16,0,17,9,256,512,1024,1280,1809,269,788,260,262,773,1280,1025,261,1792,261,16,263,268,16,1280,513,1557,1028,1285,260,257,260,789,512]

theorem envBound36161 : H12AffineFastState.Bounded env36161 := by
  intro p hp
  have h : env36161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36160_36161 : H12AffineEnvironment.transform 11 1809 env36160 = env36161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1809 env36160 == env36161) = true)

theorem identity36161 : scanCanonicalize (H12AffineFastState.compose env36161 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound36161 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env36162 : List Nat := [2,4,8,16,0,17,9,256,512,532,788,261,269,788,260,262,773,788,533,261,276,261,16,263,268,16,788,513,1,528,785,260,257,260,789,512]

theorem envBound36162 : H12AffineFastState.Bounded env36162 := by
  intro p hp
  have h : env36162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36161_36162 : H12AffineEnvironment.transform 9 532 env36161 = env36162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env36161 == env36162) = true)

theorem identity36162 : scanCanonicalize (H12AffineFastState.compose env36162 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound36162 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env36163 : List Nat := [2,4,8,16,0,17,9,256,276,256,0,261,269,0,260,262,17,0,257,261,276,261,16,263,268,16,0,277,1,260,5,260,257,260,1,276]

theorem envBound36163 : H12AffineFastState.Bounded env36163 := by
  intro p hp
  have h : env36163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36162_36163 : H12AffineEnvironment.transform 8 276 env36162 = env36163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env36162 == env36163) = true)

theorem identity36163 : scanCanonicalize (H12AffineFastState.compose env36163 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36163 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env36164 : List Nat := [2,4,8,0,0,1,9,256,260,256,0,261,269,0,260,262,1,0,257,261,260,261,0,263,268,0,0,261,1,260,5,260,257,260,1,260]

theorem envBound36164 : H12AffineFastState.Bounded env36164 := by
  intro p hp
  have h : env36164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36163_36164 : H12AffineEnvironment.transform 3 0 env36163 = env36164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36163 == env36164) = true)

def env36165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98781,8328,65,4340965,79131,91403,179512,1500,4314199,257,95531,103566,74250]

theorem envBound36165 : H12AffineFastState.Bounded env36165 := by
  intro p hp
  have h : env36165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36134_36165 : H12AffineEnvironment.transform 22 17 env36134 = env36165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env36134 == env36165) = true)

theorem identity36165 : scanCanonicalize (H12AffineFastState.compose env36165 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36165 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,4194304,17,41430,8328,65,4340965,5392,17664,179512,1500,4256860,257,21792,46213,513]

theorem envBound36166 : H12AffineFastState.Bounded env36166 := by
  intro p hp
  have h : env36166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36165_36166 : H12AffineEnvironment.transform 15 8203 env36165 = env36166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36165 == env36166) = true)

theorem identity36166 : scanCanonicalize (H12AffineFastState.compose env36166 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41380) := by decide +kernel

theorem selectedBound36166 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41380,17,41430,8328,65,171329,5392,17664,179512,1500,22008,257,21792,46213,513]

theorem envBound36167 : H12AffineFastState.Bounded env36167 := by
  intro p hp
  have h : env36167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36166_36167 : H12AffineEnvironment.transform 21 41380 env36166 = env36167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41380 env36166 == env36167) = true)

def env36168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41260,17,41310,8192,65,171329,5392,17664,179512,1364,21872,257,21792,46093,513]

theorem envBound36168 : H12AffineFastState.Bounded env36168 := by
  intro p hp
  have h : env36168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36167_36168 : H12AffineEnvironment.transform 6 8 env36167 = env36168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36167 == env36168) = true)

theorem identity36168 : scanCanonicalize (H12AffineFastState.compose env36168 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound36168 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env36169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32040,1025,29789,4160,21872,17,21762,8192,65,157981,5392,17664,149860,1364,21872,257,21792,16465,513]

theorem envBound36169 : H12AffineFastState.Bounded env36169 := by
  intro p hp
  have h : env36169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36168_36169 : H12AffineEnvironment.transform 14 29788 env36168 = env36169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env36168 == env36169) = true)

theorem identity36169 : scanCanonicalize (H12AffineFastState.compose env36169 (packedSelected [0,2,4,6,7,9,11,14,32] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound36169 : packedSelected [0,2,4,6,7,9,11,14,32] rootPS < 2^1333 := by decide +kernel

def env36170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,8203,131072,10361,1025,8460,4160,33,17,83,8192,65,146508,5392,4177,138293,1364,33,257,113,5376,513]

theorem envBound36170 : H12AffineFastState.Bounded env36170 := by
  intro p hp
  have h : env36170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36169_36170 : H12AffineEnvironment.transform 13 5457 env36169 = env36170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env36169 == env36170) = true)

theorem identity36170 : scanCanonicalize (H12AffineFastState.compose env36170 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound36170 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env36171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,8203,13388,10361,1025,8460,4160,33,17,83,8192,65,2048,5392,4177,10361,1364,33,257,113,5376,513]

theorem envBound36171 : H12AffineFastState.Bounded env36171 := by
  intro p hp
  have h : env36171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36170_36171 : H12AffineEnvironment.transform 16 13388 env36170 = env36171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env36170 == env36171) = true)

theorem identity36171 : scanCanonicalize (H12AffineFastState.compose env36171 (packedSelected [2,3,4,5,6,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36171 : packedSelected [2,3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env36172 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8203,13341,10280,1025,8460,4113,33,17,2,8192,16,2048,5392,4096,10280,1285,33,257,32,5376,513]

theorem envBound36172 : H12AffineFastState.Bounded env36172 := by
  intro p hp
  have h : env36172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36171_36172 : H12AffineEnvironment.transform 5 17 env36171 = env36172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36171 == env36172) = true)

theorem identity36172 : scanCanonicalize (H12AffineFastState.compose env36172 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36172 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36173 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,262,5392,2341,1025,1,4113,33,17,2,269,16,2048,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound36173 : H12AffineFastState.Bounded env36173 := by
  intro p hp
  have h : env36173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36172_36173 : H12AffineEnvironment.transform 12 269 env36172 = env36173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36172 == env36173) = true)

theorem identity36173 : scanCanonicalize (H12AffineFastState.compose env36173 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36173 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36174 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,0,35,5173,2048,1025,1,4113,33,17,2,40,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound36174 : H12AffineFastState.Bounded env36174 := by
  intro p hp
  have h : env36174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36173_36174 : H12AffineEnvironment.transform 7 37 env36173 = env36174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36173 == env36174) = true)

def env36175 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1045,0,35,1029,2048,1025,1,33,33,17,2,40,16,2048,1029,48,2048,1056,33,36,32,1045,513]

theorem envBound36175 : H12AffineFastState.Bounded env36175 := by
  intro p hp
  have h : env36175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36174_36175 : H12AffineEnvironment.transform 11 48 env36174 = env36175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36174 == env36175) = true)

theorem identity36175 : scanCanonicalize (H12AffineFastState.compose env36175 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound36175 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36176 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,48,40,1045,0,35,1029,32,1025,1,33,33,17,2,40,16,32,1029,48,32,1056,33,36,32,1045,513]

theorem envBound36176 : H12AffineFastState.Bounded env36176 := by
  intro p hp
  have h : env36176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36175_36176 : H12AffineEnvironment.transform 10 32 env36175 = env36176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env36175 == env36176) = true)

def env36177 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,40,33,0,35,49,32,53,1,33,33,17,2,40,16,32,49,48,32,20,33,36,32,33,513]

theorem envBound36177 : H12AffineFastState.Bounded env36177 := by
  intro p hp
  have h : env36177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36176_36177 : H12AffineEnvironment.transform 9 52 env36176 = env36177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36176 == env36177) = true)

theorem identity36177 : scanCanonicalize (H12AffineFastState.compose env36177 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound36177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36178 : List Nat := [2,4,8,16,32,17,8,37,10,52,32,48,40,33,0,35,49,32,53,1,33,33,17,2,40,16,32,49,48,32,20,33,36,32,33,11]

theorem envBound36178 : H12AffineFastState.Bounded env36178 := by
  intro p hp
  have h : env36178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36177_36178 : H12AffineEnvironment.transform 8 10 env36177 = env36178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env36177 == env36178) = true)

def leafEnv36178 : List Nat := [2,4,8,16,32,17,8,37,10,52,32,48,40,33,0,35,49,32,53,1,33,33,17,2,21,40,1,16,32,49,48,32,20,33,36,32,5,35,33,11,1,33,0]

def active36178 : List Nat := [0,1,2,3,4]

def tree36178 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36178 : H12WitnessSearch.Good tree36178 := H12GlobalWitnessIndex.good

theorem leafIdentity36178 : H12AffineFastState.composeSystem env36178 rootObs = leafEnv36178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36178 rootObs == leafEnv36178) = true)

theorem terminalChecked36178 : H12PackedTerminal.terminalCheckFast leafEnv36178 active36178 tree36178 = true := by decide +kernel

def env36179 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,48,40,32,0,35,48,32,52,1,33,33,17,2,40,16,32,48,48,32,21,33,36,32,32,513]

theorem envBound36179 : H12AffineFastState.Bounded env36179 := by
  intro p hp
  have h : env36179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36176_36179 : H12AffineEnvironment.transform 9 53 env36176 = env36179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36176 == env36179) = true)

theorem identity36179 : scanCanonicalize (H12AffineFastState.compose env36179 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36180 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,9,1,0,2,17,1,21,1,0,0,17,2,9,16,1,17,17,1,21,0,5,1,1,513]

theorem envBound36180 : H12AffineFastState.Bounded env36180 := by
  intro p hp
  have h : env36180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36179_36180 : H12AffineEnvironment.transform 4 1 env36179 = env36180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36179 == env36180) = true)

def leafEnv36180 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,9,1,0,2,17,1,21,1,0,0,17,2,20,9,1,16,1,17,17,1,21,0,5,1,5,2,1,513,1,0,0]

def active36180 : List Nat := [0,1,2,3,8]

def tree36180 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36180 : H12WitnessSearch.Good tree36180 := H12GlobalWitnessIndex.good

theorem leafIdentity36180 : H12AffineFastState.composeSystem env36180 rootObs = leafEnv36180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36180 rootObs == leafEnv36180) = true)

theorem terminalChecked36180 : H12PackedTerminal.terminalCheckFast leafEnv36180 active36180 tree36180 = true := by decide +kernel

def env36181 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1044,0,35,1028,2048,1025,1,32,33,17,2,40,16,2048,1028,49,2048,1056,33,36,32,1044,513]

theorem envBound36181 : H12AffineFastState.Bounded env36181 := by
  intro p hp
  have h : env36181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36174_36181 : H12AffineEnvironment.transform 11 49 env36174 = env36181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36174 == env36181) = true)

theorem identity36181 : scanCanonicalize (H12AffineFastState.compose env36181 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound36181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36182 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1045,49,40,1044,0,35,1028,1045,1025,1,32,33,17,2,40,16,1045,1028,49,1045,1056,33,36,32,1044,513]

theorem envBound36182 : H12AffineFastState.Bounded env36182 := by
  intro p hp
  have h : env36182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36181_36182 : H12AffineEnvironment.transform 10 1045 env36181 = env36182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env36181 == env36182) = true)

def env36183 : List Nat := [2,4,8,16,32,17,8,37,512,52,33,49,40,32,0,35,48,33,53,1,32,33,17,2,40,16,33,48,49,33,20,33,36,32,32,513]

theorem envBound36183 : H12AffineFastState.Bounded env36183 := by
  intro p hp
  have h : env36183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36182_36183 : H12AffineEnvironment.transform 9 52 env36182 = env36183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36182 == env36183) = true)

theorem identity36183 : scanCanonicalize (H12AffineFastState.compose env36183 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound36183 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36184 : List Nat := [2,4,8,16,32,17,8,37,11,52,33,49,40,32,0,35,48,33,53,1,32,33,17,2,40,16,33,48,49,33,20,33,36,32,32,10]

theorem envBound36184 : H12AffineFastState.Bounded env36184 := by
  intro p hp
  have h : env36184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36183_36184 : H12AffineEnvironment.transform 8 11 env36183 = env36184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env36183 == env36184) = true)

def leafEnv36184 : List Nat := [2,4,8,16,32,17,8,37,11,52,33,49,40,32,0,35,48,33,53,1,32,33,17,2,21,40,1,16,33,48,49,33,20,33,36,32,5,35,32,10,1,32,0]

def active36184 : List Nat := [0,1,2,3,4]

def tree36184 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36184 : H12WitnessSearch.Good tree36184 := H12GlobalWitnessIndex.good

theorem leafIdentity36184 : H12AffineFastState.composeSystem env36184 rootObs = leafEnv36184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36184 rootObs == leafEnv36184) = true)

theorem terminalChecked36184 : H12PackedTerminal.terminalCheckFast leafEnv36184 active36184 tree36184 = true := by decide +kernel

def env36185 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,40,33,0,35,49,32,52,1,32,33,17,2,40,16,32,49,49,32,21,33,36,32,33,513]

theorem envBound36185 : H12AffineFastState.Bounded env36185 := by
  intro p hp
  have h : env36185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36182_36185 : H12AffineEnvironment.transform 9 53 env36182 = env36185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36182 == env36185) = true)

theorem identity36185 : scanCanonicalize (H12AffineFastState.compose env36185 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36186 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,16,9,0,0,2,16,1,21,1,1,0,17,2,9,16,1,16,16,1,21,0,5,1,0,513]

theorem envBound36186 : H12AffineFastState.Bounded env36186 := by
  intro p hp
  have h : env36186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36185_36186 : H12AffineEnvironment.transform 4 1 env36185 = env36186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36185 == env36186) = true)

def leafEnv36186 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,16,9,0,0,2,16,1,21,1,1,0,17,2,20,9,1,16,1,16,16,1,21,0,5,1,5,2,0,513,1,1,0]

def active36186 : List Nat := [0,1,2,3,8]

def tree36186 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36186 : H12WitnessSearch.Good tree36186 := H12GlobalWitnessIndex.good

theorem leafIdentity36186 : H12AffineFastState.composeSystem env36186 rootObs = leafEnv36186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36186 rootObs == leafEnv36186) = true)

theorem terminalChecked36186 : H12PackedTerminal.terminalCheckFast leafEnv36186 active36186 tree36186 = true := by decide +kernel

def env36187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41261,17,41311,8193,65,171329,5392,17664,179512,1365,21873,257,21792,46092,513]

theorem envBound36187 : H12AffineFastState.Bounded env36187 := by
  intro p hp
  have h : env36187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36167_36187 : H12AffineEnvironment.transform 6 9 env36167 = env36187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36167 == env36187) = true)

theorem identity36187 : scanCanonicalize (H12AffineFastState.compose env36187 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36187 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,131072,32040,1025,8541,4160,113,17,3,8193,65,146461,5392,17664,138340,1365,21873,257,21792,5456,513]

theorem envBound36188 : H12AffineFastState.Bounded env36188 := by
  intro p hp
  have h : env36188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36187_36188 : H12AffineEnvironment.transform 14 8540 env36187 = env36188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36187 == env36188) = true)

theorem identity36188 : scanCanonicalize (H12AffineFastState.compose env36188 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound36188 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,32040,1025,8541,4160,113,17,3,8193,65,31757,5392,17664,23668,1365,21873,257,21792,5456,513]

theorem envBound36189 : H12AffineFastState.Bounded env36189 := by
  intro p hp
  have h : env36189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36188_36189 : H12AffineEnvironment.transform 16 16400 env36188 = env36189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36188 == env36189) = true)

theorem identity36189 : scanCanonicalize (H12AffineFastState.compose env36189 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound36189 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8540,8203,13672,2128,1025,8541,4160,113,17,3,8193,65,2421,5392,12408,10508,1365,8201,257,8280,5456,513]

theorem envBound36190 : H12AffineFastState.Bounded env36190 := by
  intro p hp
  have h : env36190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36189_36190 : H12AffineEnvironment.transform 13 13688 env36189 = env36190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env36189 == env36190) = true)

theorem identity36190 : scanCanonicalize (H12AffineFastState.compose env36190 (packedSelected [5,8,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36190 : packedSelected [5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env36191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5236,80,263,5220,2128,1025,81,4160,113,17,3,269,65,2421,5392,4468,2048,1365,261,257,340,5456,513]

theorem envBound36191 : H12AffineFastState.Bounded env36191 := by
  intro p hp
  have h : env36191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36190_36191 : H12AffineEnvironment.transform 12 268 env36190 = env36191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36190 == env36191) = true)

theorem identity36191 : scanCanonicalize (H12AffineFastState.compose env36191 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36191 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env36192 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,268,4161,80,263,4177,2128,52,81,4160,113,17,3,269,65,2421,4389,4468,2048,352,261,257,340,4453,513]

theorem envBound36192 : H12AffineFastState.Bounded env36192 := by
  intro p hp
  have h : env36192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36191_36192 : H12AffineEnvironment.transform 9 53 env36191 = env36192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36191 == env36192) = true)

theorem identity36192 : scanCanonicalize (H12AffineFastState.compose env36192 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36192 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36193 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,4096,40,4161,80,35,4177,2128,52,81,4160,113,17,3,41,65,2129,4097,4176,2048,68,33,37,112,4161,513]

theorem envBound36193 : H12AffineFastState.Bounded env36193 := by
  intro p hp
  have h : env36193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36192_36193 : H12AffineEnvironment.transform 7 36 env36192 = env36193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36192 == env36193) = true)

theorem identity36193 : scanCanonicalize (H12AffineFastState.compose env36193 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound36193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36194 : List Nat := [2,4,8,16,32,49,9,36,512,53,2048,4096,40,4144,33,35,4128,2081,52,32,4145,0,17,3,41,48,2080,4097,4129,2048,53,33,37,1,4144,513]

theorem envBound36194 : H12AffineFastState.Bounded env36194 := by
  intro p hp
  have h : env36194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36193_36194 : H12AffineEnvironment.transform 5 49 env36193 = env36194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env36193 == env36194) = true)

theorem identity36194 : scanCanonicalize (H12AffineFastState.compose env36194 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound36194 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36195 : List Nat := [2,4,8,16,32,49,9,36,512,53,2048,49,40,1,33,35,17,2081,52,32,0,0,17,3,41,48,2080,48,16,2048,53,33,37,1,1,513]

theorem envBound36195 : H12AffineFastState.Bounded env36195 := by
  intro p hp
  have h : env36195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36194_36195 : H12AffineEnvironment.transform 11 49 env36194 = env36195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36194 == env36195) = true)

theorem identity36195 : scanCanonicalize (H12AffineFastState.compose env36195 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36195 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36196 : List Nat := [2,4,8,16,16,1,9,20,512,5,2048,1,24,1,17,19,17,2065,4,16,0,0,17,3,25,0,2064,0,16,2048,5,17,21,1,1,513]

theorem envBound36196 : H12AffineFastState.Bounded env36196 := by
  intro p hp
  have h : env36196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36195_36196 : H12AffineEnvironment.transform 4 16 env36195 = env36196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36195 == env36196) = true)

theorem identity36196 : scanCanonicalize (H12AffineFastState.compose env36196 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36196 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36197 : List Nat := [2,4,8,16,16,1,9,20,512,5,0,1,24,1,17,19,17,17,4,16,0,0,17,3,25,0,16,0,16,0,5,17,21,1,1,513]

theorem envBound36197 : H12AffineFastState.Bounded env36197 := by
  intro p hp
  have h : env36197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36196_36197 : H12AffineEnvironment.transform 10 0 env36196 = env36197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36196 == env36197) = true)

theorem identity36197 : scanCanonicalize (H12AffineFastState.compose env36197 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36197 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36198 : List Nat := [2,4,8,16,16,1,9,20,0,5,0,1,24,1,17,19,17,17,4,16,0,0,17,3,25,0,16,0,16,0,5,17,21,1,1,1]

theorem envBound36198 : H12AffineFastState.Bounded env36198 := by
  intro p hp
  have h : env36198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36197_36198 : H12AffineEnvironment.transform 8 0 env36197 = env36198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36197 == env36198) = true)

theorem identity36198 : scanCanonicalize (H12AffineFastState.compose env36198 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36198 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36199 : List Nat := [2,4,8,0,0,1,9,4,0,5,0,1,8,1,1,3,1,1,4,0,0,0,1,3,9,0,0,0,0,0,5,1,5,1,1,1]

theorem envBound36199 : H12AffineFastState.Bounded env36199 := by
  intro p hp
  have h : env36199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36198_36199 : H12AffineEnvironment.transform 3 0 env36198 = env36199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36198 == env36199) = true)

def env36200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,8388608,98780,8328,65,12729588,79131,8480027,8568104,8390092,4314199,257,8484154,8492191,8462874]

theorem envBound36200 : H12AffineFastState.Bounded env36200 := by
  intro p hp
  have h : env36200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36133_36200 : H12AffineEnvironment.transform 17 32041 env36133 = env36200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env36133 == env36200) = true)

def env36201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,16,98780,8328,65,4340964,79131,91403,179512,1500,4314199,257,95530,103567,74250]

theorem envBound36201 : H12AffineFastState.Bounded env36201 := by
  intro p hp
  have h : env36201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36200_36201 : H12AffineEnvironment.transform 22 16 env36200 = env36201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env36200 == env36201) = true)

theorem identity36201 : scanCanonicalize (H12AffineFastState.compose env36201 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound36201 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,98679,16,98780,8328,65,245139,79131,91403,179512,1500,21792,257,95530,103567,74250]

theorem envBound36202 : H12AffineFastState.Bounded env36202 := by
  intro p hp
  have h : env36202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36201_36202 : H12AffineEnvironment.transform 21 98679 env36201 = env36202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env36201 == env36202) = true)

def env36203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,98679,16,98644,8192,65,245019,79131,91403,179512,1364,21792,257,95530,103431,74250]

theorem envBound36203 : H12AffineFastState.Bounded env36203 := by
  intro p hp
  have h : env36203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36202_36203 : H12AffineEnvironment.transform 6 8 env36202 = env36203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36202 == env36203) = true)

theorem identity36203 : scanCanonicalize (H12AffineFastState.compose env36203 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36203 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,77898,98679,16,98644,8192,65,245019,79131,77834,179512,1364,33,257,73771,103431,74250]

theorem envBound36204 : H12AffineFastState.Bounded env36204 := by
  intro p hp
  have h : env36204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36203_36204 : H12AffineEnvironment.transform 13 5377 env36203 = env36204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36203 == env36204) = true)

theorem identity36204 : scanCanonicalize (H12AffineFastState.compose env36204 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79178) := by decide +kernel

theorem selectedBound36204 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79178,10280,1025,32769,77898,98679,16,98644,8192,65,34897,79131,77834,100466,1364,33,257,73771,103431,74250]

theorem envBound36205 : H12AffineFastState.Bounded env36205 := by
  intro p hp
  have h : env36205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36204_36205 : H12AffineEnvironment.transform 16 79178 env36204 = env36205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79178 env36204 == env36205) = true)

theorem identity36205 : scanCanonicalize (H12AffineFastState.compose env36205 (packedSelected [0,7,9,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound36205 : packedSelected [0,7,9,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env36206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33030,46156,10280,1025,32769,45388,113,16,82,8192,65,34897,46109,45324,2420,1364,33,257,41261,5377,41740]

theorem envBound36206 : H12AffineFastState.Bounded env36206 := by
  intro p hp
  have h : env36206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36205_36206 : H12AffineEnvironment.transform 15 33030 env36205 = env36206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env36205 == env36206) = true)

theorem identity36206 : scanCanonicalize (H12AffineFastState.compose env36206 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36206 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36207 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33030,46108,10280,1025,32769,45340,33,16,2,8192,17,34817,46109,45324,2340,1284,33,257,41261,5377,41740]

theorem envBound36207 : H12AffineFastState.Bounded env36207 := by
  intro p hp
  have h : env36207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36206_36207 : H12AffineEnvironment.transform 5 16 env36206 = env36207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36206 == env36207) = true)

theorem identity36207 : scanCanonicalize (H12AffineFastState.compose env36207 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound36207 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env36208 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5432,5377,32768,33030,33060,7440,1025,32769,33828,33,16,2,5432,17,34817,33061,33844,2340,1284,33,257,37909,5377,38452]

theorem envBound36208 : H12AffineFastState.Bounded env36208 := by
  intro p hp
  have h : env36208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36207_36208 : H12AffineEnvironment.transform 12 5432 env36207 = env36208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env36207 == env36208) = true)

theorem identity36208 : scanCanonicalize (H12AffineFastState.compose env36208 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 5173) := by decide +kernel

theorem selectedBound36208 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36209 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5432,5377,5173,5427,5393,7440,1025,5172,4113,33,16,2,5432,17,7220,5392,4097,2340,1284,33,257,32,5377,513]

theorem envBound36209 : H12AffineFastState.Bounded env36209 := by
  intro p hp
  have h : env36209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36208_36209 : H12AffineEnvironment.transform 14 5173 env36208 = env36209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5173 env36208 == env36209) = true)

theorem identity36209 : scanCanonicalize (H12AffineFastState.compose env36209 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound36209 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36210 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1077,269,308,0,262,292,2341,1025,1,1060,33,16,2,269,17,2049,293,1076,2340,1284,33,257,32,308,513]

theorem envBound36210 : H12AffineFastState.Bounded env36210 := by
  intro p hp
  have h : env36210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36209_36210 : H12AffineEnvironment.transform 11 1077 env36209 = env36210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env36209 == env36210) = true)

theorem identity36210 : scanCanonicalize (H12AffineFastState.compose env36210 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound36210 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36211 : List Nat := [2,4,8,16,32,16,8,256,512,785,2048,804,269,308,0,262,292,2341,784,1,821,33,16,2,269,17,2049,293,805,2340,533,33,257,32,308,513]

theorem envBound36211 : H12AffineFastState.Bounded env36211 := by
  intro p hp
  have h : env36211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36210_36211 : H12AffineEnvironment.transform 9 785 env36210 = env36211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env36210 == env36211) = true)

theorem identity36211 : scanCanonicalize (H12AffineFastState.compose env36211 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound36211 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36212 : List Nat := [2,4,8,16,32,16,8,256,512,785,292,804,269,308,0,262,292,1,784,1,821,33,16,2,269,17,293,293,805,0,533,33,257,32,308,513]

theorem envBound36212 : H12AffineFastState.Bounded env36212 := by
  intro p hp
  have h : env36212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36211_36212 : H12AffineEnvironment.transform 10 292 env36211 = env36212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env36211 == env36212) = true)

theorem identity36212 : scanCanonicalize (H12AffineFastState.compose env36212 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound36212 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36213 : List Nat := [2,4,8,16,32,16,8,53,512,548,17,529,56,1,0,51,17,1,549,1,512,33,16,2,56,17,16,16,528,0,533,33,52,32,1,513]

theorem envBound36213 : H12AffineFastState.Bounded env36213 := by
  intro p hp
  have h : env36213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36212_36213 : H12AffineEnvironment.transform 7 53 env36212 = env36213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env36212 == env36213) = true)

def env36214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,98679,16,98645,8193,65,245018,79131,91403,179512,1365,21792,257,95530,103430,74250]

theorem envBound36214 : H12AffineFastState.Bounded env36214 := by
  intro p hp
  have h : env36214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36202_36214 : H12AffineEnvironment.transform 6 9 env36202 = env36214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36202 == env36214) = true)

theorem identity36214 : scanCanonicalize (H12AffineFastState.compose env36214 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound36214 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32041,1025,29789,77898,95531,16,95497,8193,65,215366,79131,91403,149860,1365,21792,257,95530,90202,74250]

theorem envBound36215 : H12AffineFastState.Bounded env36215 := by
  intro p hp
  have h : env36215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36214_36215 : H12AffineEnvironment.transform 14 29788 env36214 = env36215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env36214 == env36215) = true)

theorem identity36215 : scanCanonicalize (H12AffineFastState.compose env36215 (packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36215 : packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env36216 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32008,1025,29789,77898,95498,16,95497,8193,65,215366,79131,91403,149829,1365,21761,257,95499,90202,74250]

theorem envBound36216 : H12AffineFastState.Bounded env36216 := by
  intro p hp
  have h : env36216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36215_36216 : H12AffineEnvironment.transform 4 1 env36215 = env36216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36215 == env36216) = true)

theorem identity36216 : scanCanonicalize (H12AffineFastState.compose env36216 (packedSelected [1,3,4,5,6,7,8,9,10,11,14,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound36216 : packedSelected [1,3,4,5,6,7,8,9,10,11,14,18,19,27] rootPS < 2^1333 := by decide +kernel

def env36217 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,16384,29788,30043,131072,32008,1025,29789,17681,81,16,82,8193,65,146461,16448,4176,149829,1365,21761,257,80,5377,22353]

theorem envBound36217 : H12AffineFastState.Bounded env36217 := by
  intro p hp
  have h : env36217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36216_36217 : H12AffineEnvironment.transform 15 30043 env36216 = env36217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env36216 == env36217) = true)

theorem identity36217 : scanCanonicalize (H12AffineFastState.compose env36217 (packedSelected [1,3,5,6,8,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound36217 : packedSelected [1,3,5,6,8,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env36218 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,5457,8461,8202,131072,10329,1025,8460,4160,81,16,82,8193,65,146461,5393,4176,138260,1365,80,257,80,5377,512]

theorem envBound36218 : H12AffineFastState.Bounded env36218 := by
  intro p hp
  have h : env36218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36217_36218 : H12AffineEnvironment.transform 13 5457 env36217 = env36218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env36217 == env36218) = true)

theorem identity36218 : scanCanonicalize (H12AffineFastState.compose env36218 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 5141) := by decide +kernel

theorem selectedBound36218 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36219 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,5457,8461,8202,5141,10329,1025,8460,4160,81,16,82,8193,65,10248,5393,4176,2049,1365,80,257,80,5377,512]

theorem envBound36219 : H12AffineFastState.Bounded env36219 := by
  intro p hp
  have h : env36219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36218_36219 : H12AffineEnvironment.transform 16 5141 env36218 = env36219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5141 env36218 == env36219) = true)

theorem identity36219 : scanCanonicalize (H12AffineFastState.compose env36219 (packedSelected [2,6,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound36219 : packedSelected [2,6,11,12,15] rootPS < 2^1333 := by decide +kernel

def env36220 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,325,8192,1044,8461,8202,1360,10329,1025,8460,261,81,16,82,8193,65,10248,1108,277,2049,1365,80,257,80,1092,512]

theorem envBound36220 : H12AffineFastState.Bounded env36220 := by
  intro p hp
  have h : env36220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36219_36220 : H12AffineEnvironment.transform 11 325 env36219 = env36220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env36219 == env36220) = true)

theorem identity36220 : scanCanonicalize (H12AffineFastState.compose env36220 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36220 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36221 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,325,349,1044,80,343,1360,2308,1025,81,261,81,16,82,348,65,2389,1108,277,2049,1365,80,257,80,1092,512]

theorem envBound36221 : H12AffineFastState.Bounded env36221 := by
  intro p hp
  have h : env36221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36220_36221 : H12AffineEnvironment.transform 12 349 env36220 = env36221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36220 == env36221) = true)

theorem identity36221 : scanCanonicalize (H12AffineFastState.compose env36221 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36221 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36222 : List Nat := [2,4,8,16,1,64,9,5,512,1024,2048,64,88,1044,80,82,1109,2049,1025,81,0,81,16,82,89,65,2128,1108,16,2049,1104,80,4,80,1092,512]

theorem envBound36222 : H12AffineFastState.Bounded env36222 := by
  intro p hp
  have h : env36222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36221_36222 : H12AffineEnvironment.transform 7 5 env36221 = env36222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36221 == env36222) = true)

theorem identity36222 : scanCanonicalize (H12AffineFastState.compose env36222 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36222 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36223 : List Nat := [2,4,8,16,1,64,9,5,512,4,2048,64,88,16,80,82,81,2049,5,81,0,81,16,82,89,65,2128,80,16,2049,84,80,4,80,64,512]

theorem envBound36223 : H12AffineFastState.Bounded env36223 := by
  intro p hp
  have h : env36223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36222_36223 : H12AffineEnvironment.transform 9 4 env36222 = env36223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36222 == env36223) = true)

theorem identity36223 : scanCanonicalize (H12AffineFastState.compose env36223 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound36223 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36224 : List Nat := [2,4,8,16,1,64,9,5,512,4,528,64,88,16,80,82,81,529,5,81,0,81,16,82,89,65,576,80,16,529,84,80,4,80,64,512]

theorem envBound36224 : H12AffineFastState.Bounded env36224 := by
  intro p hp
  have h : env36224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36223_36224 : H12AffineEnvironment.transform 10 528 env36223 = env36224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env36223 == env36224) = true)

theorem identity36224 : scanCanonicalize (H12AffineFastState.compose env36224 (packedSelected [1,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36224 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env36225 : List Nat := [2,4,8,16,1,64,9,5,1,4,17,64,88,16,80,82,81,16,5,81,0,81,16,82,89,65,65,80,16,16,84,80,4,80,64,1]

theorem envBound36225 : H12AffineFastState.Bounded env36225 := by
  intro p hp
  have h : env36225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36224_36225 : H12AffineEnvironment.transform 8 1 env36224 = env36225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36224 == env36225) = true)

theorem identity36225 : scanCanonicalize (H12AffineFastState.compose env36225 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36225 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36226 : List Nat := [2,4,8,16,1,16,9,5,1,4,17,16,8,16,0,2,1,16,5,1,0,1,16,2,9,17,17,0,16,16,4,0,4,0,16,1]

theorem envBound36226 : H12AffineFastState.Bounded env36226 := by
  intro p hp
  have h : env36226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36225_36226 : H12AffineEnvironment.transform 5 16 env36225 = env36226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36225 == env36226) = true)

theorem identity36226 : scanCanonicalize (H12AffineFastState.compose env36226 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound36226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36227 : List Nat := [2,4,8,5,1,5,9,5,1,4,4,5,8,5,0,2,1,5,5,1,0,1,5,2,9,4,4,0,5,5,4,0,4,0,5,1]

theorem envBound36227 : H12AffineFastState.Bounded env36227 := by
  intro p hp
  have h : env36227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36226_36227 : H12AffineEnvironment.transform 3 5 env36226 = env36227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env36226 == env36227) = true)

theorem identity36227 : scanCanonicalize (H12AffineFastState.compose env36227 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36228 : List Nat := [2,1,8,0,1,0,9,0,1,1,1,0,8,0,0,2,1,0,0,1,0,1,0,2,9,1,1,0,0,0,1,0,1,0,0,1]

theorem envBound36228 : H12AffineFastState.Bounded env36228 := by
  intro p hp
  have h : env36228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36227_36228 : H12AffineEnvironment.transform 1 1 env36227 = env36228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36227 == env36228) = true)

theorem identity36228 : scanCanonicalize (H12AffineFastState.compose env36228 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound36228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36229 : List Nat := [2,1,1,0,1,0,0,0,1,1,1,0,1,0,0,2,1,0,0,1,0,1,0,2,0,1,1,0,0,0,1,0,1,0,0,1]

theorem envBound36229 : H12AffineFastState.Bounded env36229 := by
  intro p hp
  have h : env36229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36228_36229 : H12AffineEnvironment.transform 2 1 env36228 = env36229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env36228 == env36229) = true)

theorem identity36229 : scanCanonicalize (H12AffineFastState.compose env36229 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36229 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36230 : List Nat := [1,1,1,0,1,0,0,0,1,1,1,0,1,0,0,1,1,0,0,1,0,1,0,1,0,1,1,0,0,0,1,0,1,0,0,1]

theorem envBound36230 : H12AffineFastState.Bounded env36230 := by
  intro p hp
  have h : env36230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36229_36230 : H12AffineEnvironment.transform 0 1 env36229 = env36230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36229 == env36230) = true)

def env36231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98780,8328,65,4340965,79131,91402,179513,1501,4314199,257,95531,103566,74251]

theorem envBound36231 : H12AffineFastState.Bounded env36231 := by
  intro p hp
  have h : env36231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36200_36231 : H12AffineEnvironment.transform 22 17 env36200 = env36231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env36200 == env36231) = true)

theorem identity36231 : scanCanonicalize (H12AffineFastState.compose env36231 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound36231 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,32041,1025,32769,58517,4194304,17,21763,8328,65,4340965,57796,45525,179513,1501,4194440,257,41460,16465,63188]

theorem envBound36232 : H12AffineFastState.Bounded env36232 := by
  intro p hp
  have h : env36232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36231_36232 : H12AffineEnvironment.transform 15 54495 env36231 = env36232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env36231 == env36232) = true)

def env36233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,58397,4194304,17,21763,8192,65,4340845,57676,45405,179513,1365,4194304,257,41340,16465,63068]

theorem envBound36233 : H12AffineFastState.Bounded env36233 := by
  intro p hp
  have h : env36233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36232_36233 : H12AffineEnvironment.transform 6 8 env36232 = env36233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36232 == env36233) = true)

theorem identity36233 : scanCanonicalize (H12AffineFastState.compose env36233 (packedSelected [0,1,9,14,19,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound36233 : packedSelected [0,1,9,14,19,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env36234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,4160,4194304,17,21763,8192,65,4340845,5393,17664,149860,1365,4194304,257,21793,16465,513]

theorem envBound36234 : H12AffineFastState.Bounded env36234 := by
  intro p hp
  have h : env36234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36233_36234 : H12AffineEnvironment.transform 14 29789 env36233 = env36234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env36233 == env36234) = true)

theorem identity36234 : scanCanonicalize (H12AffineFastState.compose env36234 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound36234 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env36235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,4160,147505,17,21763,8192,65,31836,5393,17664,149860,1365,147505,257,21793,16465,513]

theorem envBound36235 : H12AffineFastState.Bounded env36235 := by
  intro p hp
  have h : env36235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36234_36235 : H12AffineEnvironment.transform 21 147505 env36234 = env36235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env36234 == env36235) = true)

theorem identity36235 : scanCanonicalize (H12AffineFastState.compose env36235 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36235 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env36236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,10281,1025,8540,4160,136497,17,3,8192,65,10588,5393,4096,138340,1365,136497,257,33,5457,513]

theorem envBound36236 : H12AffineFastState.Bounded env36236 := by
  intro p hp
  have h : env36236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36235_36236 : H12AffineEnvironment.transform 13 5376 env36235 = env36236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36235 == env36236) = true)

theorem identity36236 : scanCanonicalize (H12AffineFastState.compose env36236 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound36236 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,13388,10281,1025,8540,4160,8573,17,3,8192,65,10588,5393,4096,10280,1365,8573,257,33,5457,513]

theorem envBound36237 : H12AffineFastState.Bounded env36237 := by
  intro p hp
  have h : env36237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36236_36237 : H12AffineEnvironment.transform 16 13388 env36236 = env36237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env36236 == env36237) = true)

theorem identity36237 : scanCanonicalize (H12AffineFastState.compose env36237 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound36237 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36238 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8541,8202,12637,10281,272,8540,4160,8573,17,3,8192,65,10588,4096,4096,10280,68,8573,257,33,4160,513]

theorem envBound36238 : H12AffineFastState.Bounded env36238 := by
  intro p hp
  have h : env36238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36237_36238 : H12AffineEnvironment.transform 9 273 env36237 = env36238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env36237 == env36238) = true)

theorem identity36238 : scanCanonicalize (H12AffineFastState.compose env36238 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound36238 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36239 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,8192,4113,8541,8202,12637,8313,272,8540,4160,8573,17,3,8192,65,8460,4096,4096,8312,68,8573,257,33,4160,513]

theorem envBound36239 : H12AffineFastState.Bounded env36239 := by
  intro p hp
  have h : env36239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36238_36239 : H12AffineEnvironment.transform 10 80 env36238 = env36239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env36238 == env36239) = true)

theorem identity36239 : scanCanonicalize (H12AffineFastState.compose env36239 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36239 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36240 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,348,4113,1,342,4097,293,272,0,4160,33,17,3,348,65,80,4096,4096,292,68,33,257,33,4160,513]

theorem envBound36240 : H12AffineFastState.Bounded env36240 := by
  intro p hp
  have h : env36240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36239_36240 : H12AffineEnvironment.transform 12 348 env36239 = env36240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36239 == env36240) = true)

theorem identity36240 : scanCanonicalize (H12AffineFastState.compose env36240 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound36240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36241 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,308,348,293,1,342,309,293,272,0,372,33,17,3,348,65,80,308,308,292,68,33,257,33,372,513]

theorem envBound36241 : H12AffineFastState.Bounded env36241 := by
  intro p hp
  have h : env36241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36240_36241 : H12AffineEnvironment.transform 11 308 env36240 = env36241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env36240 == env36241) = true)

theorem identity36241 : scanCanonicalize (H12AffineFastState.compose env36241 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 383) := by decide +kernel

theorem selectedBound36241 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36242 : List Nat := [2,4,8,16,32,64,8,256,383,273,80,308,348,293,1,342,309,293,272,0,372,33,17,3,348,65,80,308,308,292,68,33,257,33,372,382]

theorem envBound36242 : H12AffineFastState.Bounded env36242 := by
  intro p hp
  have h : env36242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36241_36242 : H12AffineEnvironment.transform 8 383 env36241 = env36242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 383 env36241 == env36242) = true)

theorem identity36242 : scanCanonicalize (H12AffineFastState.compose env36242 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound36242 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36243 : List Nat := [2,4,8,16,32,48,8,256,271,273,32,308,300,293,1,294,309,293,272,0,260,33,17,3,300,49,32,308,308,292,52,33,257,33,260,270]

theorem envBound36243 : H12AffineFastState.Bounded env36243 := by
  intro p hp
  have h : env36243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36242_36243 : H12AffineEnvironment.transform 5 48 env36242 = env36243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env36242 == env36243) = true)

theorem identity36243 : scanCanonicalize (H12AffineFastState.compose env36243 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36243 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36244 : List Nat := [2,4,8,16,32,48,8,37,42,52,32,17,9,0,1,3,16,0,53,0,33,33,17,3,9,49,32,17,17,1,52,33,36,33,33,43]

theorem envBound36244 : H12AffineFastState.Bounded env36244 := by
  intro p hp
  have h : env36244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36243_36244 : H12AffineEnvironment.transform 7 37 env36243 = env36244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36243 == env36244) = true)

theorem identity36244 : scanCanonicalize (H12AffineFastState.compose env36244 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36244 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36245 : List Nat := [2,4,8,16,0,16,8,5,10,20,0,17,9,0,1,3,16,0,21,0,1,1,17,3,9,17,0,17,17,1,20,1,4,1,1,11]

theorem envBound36245 : H12AffineFastState.Bounded env36245 := by
  intro p hp
  have h : env36245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36244_36245 : H12AffineEnvironment.transform 4 0 env36244 = env36245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36244 == env36245) = true)

theorem identity36245 : scanCanonicalize (H12AffineFastState.compose env36245 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36245 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36246 : List Nat := [2,0,8,16,0,16,8,1,10,16,0,17,9,0,1,3,16,0,17,0,1,1,17,3,9,17,0,17,17,1,16,1,0,1,1,11]

theorem envBound36246 : H12AffineFastState.Bounded env36246 := by
  intro p hp
  have h : env36246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36245_36246 : H12AffineEnvironment.transform 1 0 env36245 = env36246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36245 == env36246) = true)

theorem identity36246 : scanCanonicalize (H12AffineFastState.compose env36246 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36247 : List Nat := [0,0,8,16,0,16,8,1,8,16,0,17,9,0,1,1,16,0,17,0,1,1,17,1,9,17,0,17,17,1,16,1,0,1,1,9]

theorem envBound36247 : H12AffineFastState.Bounded env36247 := by
  intro p hp
  have h : env36247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36246_36247 : H12AffineEnvironment.transform 0 0 env36246 = env36247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36246 == env36247) = true)

def env36248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,58396,4194304,17,21763,8193,65,4340844,57677,45404,179513,1364,4194305,257,41341,16465,63069]

theorem envBound36248 : H12AffineFastState.Bounded env36248 := by
  intro p hp
  have h : env36248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36232_36248 : H12AffineEnvironment.transform 6 9 env36232 = env36248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36232 == env36248) = true)

theorem identity36248 : scanCanonicalize (H12AffineFastState.compose env36248 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36248 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,131072,32041,1025,8541,17728,4194304,17,21763,8193,65,4340844,16401,4096,138341,1364,4194305,257,33,16465,22273]

theorem envBound36249 : H12AffineFastState.Bounded env36249 := by
  intro p hp
  have h : env36249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36248_36249 : H12AffineEnvironment.transform 14 8540 env36248 = env36249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36248 == env36249) = true)

theorem identity36249 : scanCanonicalize (H12AffineFastState.compose env36249 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound36249 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,16401,32041,1025,8541,17728,4194304,17,21763,8193,65,4226173,16401,4096,23668,1364,4194305,257,33,16465,22273]

theorem envBound36250 : H12AffineFastState.Bounded env36250 := by
  intro p hp
  have h : env36250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36249_36250 : H12AffineEnvironment.transform 16 16401 env36249 = env36250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36249 == env36250) = true)

theorem identity36250 : scanCanonicalize (H12AffineFastState.compose env36250 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 29960) := by decide +kernel

theorem selectedBound36250 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env36251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,16401,32041,1025,8541,17728,29960,17,21763,8193,65,2421,16401,4096,23668,1364,29961,257,33,16465,22273]

theorem envBound36251 : H12AffineFastState.Bounded env36251 := by
  intro p hp
  have h : env36251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36250_36251 : H12AffineEnvironment.transform 21 29960 env36250 = env36251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29960 env36250 == env36251) = true)

theorem identity36251 : scanCanonicalize (H12AffineFastState.compose env36251 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36251 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env36252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21590,16401,23669,1025,1,17728,21588,17,21763,349,65,2421,16401,4096,23668,1364,21589,257,33,16465,22273]

theorem envBound36252 : H12AffineFastState.Bounded env36252 := by
  intro p hp
  have h : env36252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36251_36252 : H12AffineEnvironment.transform 12 348 env36251 = env36252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36251 == env36252) = true)

theorem identity36252 : scanCanonicalize (H12AffineFastState.compose env36252 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36252 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env36253 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,16384,0,21590,16401,23669,1025,1,17460,21588,17,21623,41,65,2049,16401,4096,23668,1056,21589,117,33,16465,22133]

theorem envBound36253 : H12AffineFastState.Bounded env36253 := by
  intro p hp
  have h : env36253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36252_36253 : H12AffineEnvironment.transform 7 116 env36252 = env36253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36252 == env36253) = true)

theorem identity36253 : scanCanonicalize (H12AffineFastState.compose env36253 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound36253 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36254 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,0,35,5220,2048,1025,1,4161,33,17,2,41,65,2049,5220,4096,2049,1056,32,117,33,5156,512]

theorem envBound36254 : H12AffineFastState.Bounded env36254 := by
  intro p hp
  have h : env36254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36253_36254 : H12AffineEnvironment.transform 13 5237 env36253 = env36254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env36253 == env36254) = true)

theorem identity36254 : scanCanonicalize (H12AffineFastState.compose env36254 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36254 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36255 : List Nat := [2,4,8,16,0,64,9,84,512,1024,2048,4096,8,5205,0,3,5188,2048,1025,1,4161,1,17,2,9,65,2049,5188,4096,2049,1024,0,85,1,5124,512]

theorem envBound36255 : H12AffineFastState.Bounded env36255 := by
  intro p hp
  have h : env36255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36254_36255 : H12AffineEnvironment.transform 4 0 env36254 = env36255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36254 == env36255) = true)

theorem identity36255 : scanCanonicalize (H12AffineFastState.compose env36255 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36255 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36256 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,8,5124,0,3,5141,2048,1025,1,4112,1,17,2,9,16,2049,5141,4096,2049,1024,0,4,1,5124,512]

theorem envBound36256 : H12AffineFastState.Bounded env36256 := by
  intro p hp
  have h : env36256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36255_36256 : H12AffineEnvironment.transform 5 17 env36255 = env36256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36255 == env36256) = true)

theorem identity36256 : scanCanonicalize (H12AffineFastState.compose env36256 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36256 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36257 : List Nat := [2,4,8,16,0,17,9,5,0,1024,2048,4096,8,5124,0,3,5141,2048,1025,1,4112,1,17,2,9,16,2049,5141,4096,2049,1024,0,4,1,5124,0]

theorem envBound36257 : H12AffineFastState.Bounded env36257 := by
  intro p hp
  have h : env36257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36256_36257 : H12AffineEnvironment.transform 8 0 env36256 = env36257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36256 == env36257) = true)

theorem identity36257 : scanCanonicalize (H12AffineFastState.compose env36257 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound36257 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36258 : List Nat := [2,4,8,16,0,17,9,5,0,1024,2048,1044,8,16,0,3,1,2048,1025,1,1028,1,17,2,9,16,2049,1,1044,2049,1024,0,4,1,16,0]

theorem envBound36258 : H12AffineFastState.Bounded env36258 := by
  intro p hp
  have h : env36258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36257_36258 : H12AffineEnvironment.transform 11 1044 env36257 = env36258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env36257 == env36258) = true)

theorem identity36258 : scanCanonicalize (H12AffineFastState.compose env36258 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound36258 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env36259 : List Nat := [2,4,8,16,0,17,9,5,0,21,2048,1,8,16,0,3,1,2048,20,1,17,1,17,2,9,16,2049,1,1,2049,21,0,4,1,16,0]

theorem envBound36259 : H12AffineFastState.Bounded env36259 := by
  intro p hp
  have h : env36259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36258_36259 : H12AffineEnvironment.transform 9 21 env36258 = env36259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36258 == env36259) = true)

def env36260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356289,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound36260 : H12AffineFastState.Bounded env36260 := by
  intro p hp
  have h : env36260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35833_36260 : H12AffineEnvironment.transform 26 30393345 env35833 = env36260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env35833 == env36260) = true)

def env36261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound36261 : H12AffineFastState.Bounded env36261 := by
  intro p hp
  have h : env36261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36260_36261 : H12AffineEnvironment.transform 18 1024 env36260 = env36261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env36260 == env36261) = true)

theorem identity36261 : scanCanonicalize (H12AffineFastState.compose env36261 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 509987) := by decide +kernel

theorem selectedBound36261 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,509987,16777216,8328,65,20973602,18973836,2596210,67618,17189939,23160256,256,19270799,19328298,17263588]

theorem envBound36262 : H12AffineFastState.Bounded env36262 := by
  intro p hp
  have h : env36262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36261_36262 : H12AffineEnvironment.transform 22 509987 env36261 = env36262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 509987 env36261 == env36262) = true)

def env36263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509987,16777216,8328,65,16959642,18973836,2596210,67618,17189939,19113336,256,19270799,19328298,17263588]

theorem envBound36263 : H12AffineFastState.Bounded env36263 := by
  intro p hp
  have h : env36263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36262_36263 : H12AffineEnvironment.transform 21 180408 env36262 = env36263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env36262 == env36263) = true)

def env36264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,509987,498992,8328,65,349610,2496956,2596210,67618,119043,2373704,256,2199999,2191386,63188]

theorem envBound36264 : H12AffineFastState.Bounded env36264 := by
  intro p hp
  have h : env36264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36263_36264 : H12AffineEnvironment.transform 23 498992 env36263 = env36264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env36263 == env36264) = true)

def env36265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,509987,498992,8328,65,349610,395772,494898,67618,119043,272392,256,98815,90202,63188]

theorem envBound36265 : H12AffineFastState.Bounded env36265 := by
  intro p hp
  have h : env36265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36264_36265 : H12AffineEnvironment.transform 20 4160 env36264 = env36265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36264 == env36265) = true)

theorem identity36265 : scanCanonicalize (H12AffineFastState.compose env36265 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound36265 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,144493,474358,485861,8328,65,349610,395772,489959,67618,75222,272392,256,95530,90202,513]

theorem envBound36266 : H12AffineFastState.Bounded env36266 := by
  intro p hp
  have h : env36266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36265_36266 : H12AffineEnvironment.transform 14 29909 env36265 = env36266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env36265 == env36266) = true)

def env36267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,144493,474238,485741,8192,65,349474,395636,489839,67618,75102,272392,256,95530,90202,513]

theorem envBound36267 : H12AffineFastState.Bounded env36267 := by
  intro p hp
  have h : env36267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36266_36267 : H12AffineEnvironment.transform 6 8 env36266 = env36267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36266 == env36267) = true)

theorem identity36267 : scanCanonicalize (H12AffineFastState.compose env36267 (packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound36267 : packedSelected [0,1,3,7,11,15,17,19,20,24,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env36268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1024,29788,4160,144493,213334,201797,8192,65,75786,160860,197703,67618,75102,21792,256,95530,90202,513]

theorem envBound36268 : H12AffineFastState.Bounded env36268 := by
  intro p hp
  have h : env36268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36267_36268 : H12AffineEnvironment.transform 17 32040 env36267 = env36268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env36267 == env36268) = true)

theorem identity36268 : scanCanonicalize (H12AffineFastState.compose env36268 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound36268 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env36269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,131072,32040,1024,29788,4160,144493,136448,147475,8192,65,31836,160860,151569,23668,28936,21792,256,8572,13324,513]

theorem envBound36269 : H12AffineFastState.Bounded env36269 := by
  intro p hp
  have h : env36269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36268_36269 : H12AffineEnvironment.transform 15 21590 env36268 = env36269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env36268 == env36269) = true)

theorem identity36269 : scanCanonicalize (H12AffineFastState.compose env36269 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36269 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21590,131072,23669,1024,21761,4160,136496,136448,147475,349,65,23809,152833,151569,23668,20565,21792,256,33,5457,513]

theorem envBound36270 : H12AffineFastState.Bounded env36270 := by
  intro p hp
  have h : env36270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36269_36270 : H12AffineEnvironment.transform 12 349 env36269 = env36270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36269 == env36270) = true)

theorem identity36270 : scanCanonicalize (H12AffineFastState.compose env36270 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound36270 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21590,5392,23669,1024,21761,4160,32,16,21763,349,65,23809,16401,17665,23668,20565,21792,256,33,5457,513]

theorem envBound36271 : H12AffineFastState.Bounded env36271 := by
  intro p hp
  have h : env36271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36270_36271 : H12AffineEnvironment.transform 16 5392 env36270 = env36271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env36270 == env36271) = true)

theorem identity36271 : scanCanonicalize (H12AffineFastState.compose env36271 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36271 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36272 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,16384,21760,21590,5392,23637,1024,21761,4160,0,16,21763,349,65,23809,16401,17665,23636,20565,21760,256,1,5457,513]

theorem envBound36272 : H12AffineFastState.Bounded env36272 := by
  intro p hp
  have h : env36272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36271_36272 : H12AffineEnvironment.transform 4 0 env36271 = env36272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36271 == env36272) = true)

theorem identity36272 : scanCanonicalize (H12AffineFastState.compose env36272 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36272 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36273 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,5376,0,342,5392,2389,1024,1,4160,0,16,3,349,65,2049,5393,4097,2388,1365,0,256,1,5457,513]

theorem envBound36273 : H12AffineFastState.Bounded env36273 := by
  intro p hp
  have h : env36273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36272_36273 : H12AffineEnvironment.transform 13 5376 env36272 = env36273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36272 == env36273) = true)

theorem identity36273 : scanCanonicalize (H12AffineFastState.compose env36273 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 832) := by decide +kernel

theorem selectedBound36273 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36274 : List Nat := [2,4,8,16,0,64,8,256,512,832,2048,4096,349,4672,0,342,4688,2389,832,1,4160,0,16,3,349,65,2049,4689,4097,2388,533,0,256,1,4625,513]

theorem envBound36274 : H12AffineFastState.Bounded env36274 := by
  intro p hp
  have h : env36274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36273_36274 : H12AffineEnvironment.transform 9 832 env36273 = env36274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 832 env36273 == env36274) = true)

theorem identity36274 : scanCanonicalize (H12AffineFastState.compose env36274 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36274 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36275 : List Nat := [2,4,8,16,0,17,8,256,512,785,2048,4096,268,4625,0,263,4609,2308,785,1,4113,0,16,3,268,16,2049,4608,4097,2309,533,0,256,1,4625,513]

theorem envBound36275 : H12AffineFastState.Bounded env36275 := by
  intro p hp
  have h : env36275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36274_36275 : H12AffineEnvironment.transform 5 17 env36274 = env36275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36274 == env36275) = true)

theorem identity36275 : scanCanonicalize (H12AffineFastState.compose env36275 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound36275 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36276 : List Nat := [2,4,8,16,0,17,8,256,512,785,2048,260,268,789,0,263,773,2308,785,1,277,0,16,3,268,16,2049,772,261,2309,533,0,256,1,789,513]

theorem envBound36276 : H12AffineFastState.Bounded env36276 := by
  intro p hp
  have h : env36276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36275_36276 : H12AffineEnvironment.transform 11 260 env36275 = env36276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env36275 == env36276) = true)

theorem identity36276 : scanCanonicalize (H12AffineFastState.compose env36276 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound36276 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36277 : List Nat := [2,4,8,16,0,17,8,256,512,785,260,260,268,789,0,263,773,0,785,1,277,0,16,3,268,16,261,772,261,1,533,0,256,1,789,513]

theorem envBound36277 : H12AffineFastState.Bounded env36277 := by
  intro p hp
  have h : env36277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36276_36277 : H12AffineEnvironment.transform 10 260 env36276 = env36277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env36276 == env36277) = true)

end H12CloudChart0