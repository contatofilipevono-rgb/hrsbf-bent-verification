import H12CloudChart0Data040

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans10223_10224 : H12AffineEnvironment.transform 14 136 env10223 = env10224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env10223 == env10224) = true)

theorem identity10224 : scanCanonicalize (H12AffineFastState.compose env10224 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound10224 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env10225 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,5156,136,171,5309,2049,1025,137,4249,32,16,3,161,17,2185,5172,4096,2049,1057,33,173,32,5292,649]

theorem envBound10225 : H12AffineFastState.Bounded env10225 := by
  intro p hp
  have h : env10225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10224_10225 : H12AffineEnvironment.transform 13 5156 env10224 = env10225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env10224 == env10225) = true)

theorem identity10225 : scanCanonicalize (H12AffineFastState.compose env10225 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10225 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env10226 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,1,34,5172,2049,1025,0,4112,32,16,3,40,17,2048,5172,4096,2049,1057,33,36,32,5157,512]

theorem envBound10226 : H12AffineFastState.Bounded env10226 := by
  intro p hp
  have h : env10226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10225_10226 : H12AffineEnvironment.transform 6 9 env10225 = env10226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10225 == env10226) = true)

theorem identity10226 : scanCanonicalize (H12AffineFastState.compose env10226 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound10226 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10227 : List Nat := [2,4,8,16,32,17,9,37,512,20,2048,4096,41,4144,1,34,4128,2049,21,0,4112,32,16,3,40,17,2048,4128,4096,2049,53,33,36,32,4145,512]

theorem envBound10227 : H12AffineFastState.Bounded env10227 := by
  intro p hp
  have h : env10227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10226_10227 : H12AffineEnvironment.transform 9 20 env10226 = env10227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env10226 == env10227) = true)

def env10228 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,33,2411556,2114834,8328,17,75786,115103,301349,2125113,331047,73890,257,2444699,2468926,273057]

theorem envBound10228 : H12AffineFastState.Bounded env10228 := by
  intro p hp
  have h : env10228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10217_10228 : H12AffineEnvironment.transform 21 33 env10217 = env10228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env10217 == env10228) = true)

theorem identity10228 : scanCanonicalize (H12AffineFastState.compose env10228 (packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound10228 : packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env10229 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,65536,24860,262144,1025,0,2097152,33,2378789,2114834,8328,17,75786,82334,268580,2125113,331047,73890,257,2444699,2436159,273057]

theorem envBound10229 : H12AffineFastState.Bounded env10229 := by
  intro p hp
  have h : env10229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10228_10229 : H12AffineEnvironment.transform 14 1 env10228 = env10229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env10228 == env10229) = true)

theorem identity10229 : scanCanonicalize (H12AffineFastState.compose env10229 (packedSelected [0,4,5,7,9,10,12,16,18,24] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound10229 : packedSelected [0,4,5,7,9,10,12,16,18,24] rootPS < 2^1333 := by decide +kernel

def env10230 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,65536,24860,67755,1025,0,2097152,33,2180238,2114834,8328,17,75786,82334,70031,2125113,1420,73890,257,2114864,2106516,74250]

theorem envBound10230 : H12AffineFastState.Bounded env10230 := by
  intro p hp
  have h : env10230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10229_10230 : H12AffineEnvironment.transform 17 67755 env10229 = env10230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env10229 == env10230) = true)

theorem identity10230 : scanCanonicalize (H12AffineFastState.compose env10230 (packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10230 : packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env10231 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,1,65536,16401,67755,1025,0,2097152,33,2180238,2114834,389,17,67847,82334,70031,2116660,1420,65967,257,2114864,2098585,66311]

theorem envBound10231 : H12AffineFastState.Bounded env10231 := by
  intro p hp
  have h : env10231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10230_10231 : H12AffineEnvironment.transform 12 269 env10230 = env10231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10230 == env10231) = true)

theorem identity10231 : scanCanonicalize (H12AffineFastState.compose env10231 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10231 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env10232 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,65536,16401,67618,1025,0,2097152,33,2180103,2114834,268,17,67847,82199,69894,2116660,1285,65830,257,2114864,2098448,66311]

theorem envBound10232 : H12AffineFastState.Bounded env10232 := by
  intro p hp
  have h : env10232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10231_10232 : H12AffineEnvironment.transform 6 9 env10231 = env10232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10231 == env10232) = true)

theorem identity10232 : scanCanonicalize (H12AffineFastState.compose env10232 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(20+1) ^^^ 4404) := by decide +kernel

theorem selectedBound10232 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env10233 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,65536,16401,67618,1025,0,4404,33,87347,21542,268,17,67847,82199,69894,23808,1285,65830,257,21508,5156,66311]

theorem envBound10233 : H12AffineFastState.Bounded env10233 := by
  intro p hp
  have h : env10233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10232_10233 : H12AffineEnvironment.transform 20 4404 env10232 = env10233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4404 env10232 == env10233) = true)

theorem identity10233 : scanCanonicalize (H12AffineFastState.compose env10233 (packedSelected [1,3,5,6,7,8,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound10233 : packedSelected [1,3,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env10234 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,16401,2341,1025,0,4404,33,21556,21542,268,17,2048,16400,4097,23808,1285,33,257,21508,5156,512]

theorem envBound10234 : H12AffineFastState.Bounded env10234 := by
  intro p hp
  have h : env10234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10233_10234 : H12AffineEnvironment.transform 15 263 env10233 = env10234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env10233 == env10234) = true)

theorem identity10234 : scanCanonicalize (H12AffineFastState.compose env10234 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound10234 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10235 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5124,1,263,5141,2341,1025,0,4404,33,48,34,268,17,2048,5140,4097,2308,1285,33,257,0,5156,512]

theorem envBound10235 : H12AffineFastState.Bounded env10235 := by
  intro p hp
  have h : env10235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10234_10235 : H12AffineEnvironment.transform 13 5124 env10234 = env10235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env10234 == env10235) = true)

theorem identity10235 : scanCanonicalize (H12AffineFastState.compose env10235 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound10235 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env10236 : List Nat := [2,4,8,16,32,17,9,256,512,21,2048,4096,269,4113,1,263,4096,2341,20,0,4404,33,48,34,268,17,2048,4097,4097,2308,272,33,257,0,4145,512]

theorem envBound10236 : H12AffineFastState.Bounded env10236 := by
  intro p hp
  have h : env10236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10235_10236 : H12AffineEnvironment.transform 9 21 env10235 = env10236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env10235 == env10236) = true)

theorem identity10236 : scanCanonicalize (H12AffineFastState.compose env10236 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10236 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env10237 : List Nat := [2,4,8,16,1,17,9,256,512,21,2048,4096,269,4113,1,263,4096,2308,20,0,4373,0,17,3,268,17,2048,4097,4097,2308,272,0,257,0,4112,512]

theorem envBound10237 : H12AffineFastState.Bounded env10237 := by
  intro p hp
  have h : env10237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10236_10237 : H12AffineEnvironment.transform 4 1 env10236 = env10237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10236 == env10237) = true)

theorem identity10237 : scanCanonicalize (H12AffineFastState.compose env10237 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound10237 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10238 : List Nat := [2,4,8,16,1,17,9,256,512,21,4,4096,269,4113,1,263,4096,256,20,0,4373,0,17,3,268,17,4,4097,4097,256,272,0,257,0,4112,512]

theorem envBound10238 : H12AffineFastState.Bounded env10238 := by
  intro p hp
  have h : env10238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10237_10238 : H12AffineEnvironment.transform 10 4 env10237 = env10238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env10237 == env10238) = true)

theorem identity10238 : scanCanonicalize (H12AffineFastState.compose env10238 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound10238 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10239 : List Nat := [2,4,8,16,1,17,9,256,512,21,4,17,269,0,1,263,17,256,20,0,260,0,17,3,268,17,4,16,16,256,272,0,257,0,1,512]

theorem envBound10239 : H12AffineFastState.Bounded env10239 := by
  intro p hp
  have h : env10239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10238_10239 : H12AffineEnvironment.transform 11 17 env10238 = env10239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env10238 == env10239) = true)

def env10240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356289,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound10240 : H12AffineFastState.Bounded env10240 := by
  intro p hp
  have h : env10240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9860_10240 : H12AffineEnvironment.transform 26 30393345 env9860 = env10240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env9860 == env10240) = true)

def env10241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound10241 : H12AffineFastState.Bounded env10241 := by
  intro p hp
  have h : env10241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10240_10241 : H12AffineEnvironment.transform 18 1024 env10240 = env10241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10240 == env10241) = true)

theorem identity10241 : scanCanonicalize (H12AffineFastState.compose env10241 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8429902) := by decide +kernel

theorem selectedBound10241 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8328,64,4677967,10560962,10507600,8830977,75103,14795919,256,2188771,2196550,649]

theorem envBound10242 : H12AffineFastState.Bounded env10242 := by
  intro p hp
  have h : env10242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10241_10242 : H12AffineEnvironment.transform 23 8429902 env10241 = env10242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8429902 env10241 == env10242) = true)

def env10243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8192,64,4677967,10560842,10507600,8830977,75103,14795783,256,2188651,2196550,513]

theorem envBound10243 : H12AffineFastState.Bounded env10243 := by
  intro p hp
  have h : env10243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10242_10243 : H12AffineEnvironment.transform 6 8 env10242 = env10243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10242 == env10243) = true)

def env10244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41310,8192,64,4677967,2172250,2118976,442385,75103,6407191,256,2188651,2196550,513]

theorem envBound10244 : H12AffineFastState.Bounded env10244 := by
  intro p hp
  have h : env10244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10243_10244 : H12AffineEnvironment.transform 22 16 env10243 = env10244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env10243 == env10244) = true)

def env10245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4677967,115014,45404,442385,75103,4268043,256,98679,90202,513]

theorem envBound10245 : H12AffineFastState.Bounded env10245 := by
  intro p hp
  have h : env10245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10244_10245 : H12AffineEnvironment.transform 20 58396 env10244 = env10245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env10244 == env10245) = true)

theorem identity10245 : scanCanonicalize (H12AffineFastState.compose env10245 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10245 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4604228,57677,45404,442385,1364,4194304,256,41340,16465,513]

theorem envBound10246 : H12AffineFastState.Bounded env10246 := by
  intro p hp
  have h : env10246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10245_10246 : H12AffineEnvironment.transform 15 8203 env10245 = env10246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10245 == env10246) = true)

theorem identity10246 : scanCanonicalize (H12AffineFastState.compose env10246 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419913) := by decide +kernel

theorem selectedBound10246 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env10247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58396,419913,16,41310,8192,64,10509,57677,45404,442385,1364,419913,256,41340,16465,513]

theorem envBound10247 : H12AffineFastState.Bounded env10247 := by
  intro p hp
  have h : env10247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10246_10247 : H12AffineEnvironment.transform 21 419913 env10246 = env10247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419913 env10246 == env10247) = true)

def env10248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58396,272393,16,41310,8192,64,10509,57677,45404,294993,1364,272393,256,41340,16465,513]

theorem envBound10248 : H12AffineFastState.Bounded env10248 := by
  intro p hp
  have h : env10248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10247_10248 : H12AffineEnvironment.transform 16 16448 env10247 = env10248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env10247 == env10248) = true)

theorem identity10248 : scanCanonicalize (H12AffineFastState.compose env10248 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10248 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,342,16448,262144,1024,32769,50497,264532,16,32771,349,64,2128,49168,36865,294993,1364,264532,256,32801,16465,513]

theorem envBound10249 : H12AffineFastState.Bounded env10249 := by
  intro p hp
  have h : env10249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10248_10249 : H12AffineEnvironment.transform 12 349 env10248 = env10249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10248 == env10249) = true)

theorem identity10249 : scanCanonicalize (H12AffineFastState.compose env10249 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound10249 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,342,16448,2341,1024,32769,50497,113,16,32771,349,64,2128,49168,36865,35188,1364,113,256,32801,16465,513]

theorem envBound10250 : H12AffineFastState.Bounded env10250 := by
  intro p hp
  have h : env10250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10249_10250 : H12AffineEnvironment.transform 17 2341 env10249 = env10250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env10249 == env10250) = true)

theorem identity10250 : scanCanonicalize (H12AffineFastState.compose env10250 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound10250 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env10251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,342,16448,2341,1024,81,17681,113,16,83,349,64,2128,16448,4177,2340,1364,113,256,113,16465,513]

theorem envBound10251 : H12AffineFastState.Bounded env10251 := by
  intro p hp
  have h : env10251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10250_10251 : H12AffineEnvironment.transform 14 80 env10250 = env10251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env10250 == env10251) = true)

theorem identity10251 : scanCanonicalize (H12AffineFastState.compose env10251 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound10251 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env10252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,349,16384,80,342,16448,2341,1024,81,17681,113,16,83,349,64,2128,16448,2113,2340,1364,113,256,113,16465,513]

theorem envBound10252 : H12AffineFastState.Bounded env10252 := by
  intro p hp
  have h : env10252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10251_10252 : H12AffineEnvironment.transform 11 2064 env10251 = env10252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env10251 == env10252) = true)

theorem identity10252 : scanCanonicalize (H12AffineFastState.compose env10252 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound10252 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env10253 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,2064,349,16384,80,342,16448,2341,100,81,16757,113,16,83,349,64,2128,16448,2113,2340,304,113,256,113,16465,513]

theorem envBound10253 : H12AffineFastState.Bounded env10253 := by
  intro p hp
  have h : env10253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10252_10253 : H12AffineEnvironment.transform 9 100 env10252 = env10253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env10252 == env10253) = true)

theorem identity10253 : scanCanonicalize (H12AffineFastState.compose env10253 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound10253 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env10254 : List Nat := [2,4,8,16,32,64,8,256,512,100,292,308,349,16384,80,342,16448,1,100,81,16757,113,16,83,349,64,372,16448,357,0,304,113,256,113,16465,513]

theorem envBound10254 : H12AffineFastState.Bounded env10254 := by
  intro p hp
  have h : env10254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10253_10254 : H12AffineEnvironment.transform 10 292 env10253 = env10254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env10253 == env10254) = true)

theorem identity10254 : scanCanonicalize (H12AffineFastState.compose env10254 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 373) := by decide +kernel

theorem selectedBound10254 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env10255 : List Nat := [2,4,8,16,32,64,8,256,512,100,292,308,349,373,80,342,309,1,100,81,0,113,16,83,349,64,372,309,357,0,304,113,256,113,292,513]

theorem envBound10255 : H12AffineFastState.Bounded env10255 := by
  intro p hp
  have h : env10255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10254_10255 : H12AffineEnvironment.transform 13 373 env10254 = env10255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 373 env10254 == env10255) = true)

def env10256 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58396,272392,16,41310,8192,64,10509,57677,45404,294992,1364,272392,256,41340,16465,513]

theorem envBound10256 : H12AffineFastState.Bounded env10256 := by
  intro p hp
  have h : env10256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10247_10256 : H12AffineEnvironment.transform 16 16449 env10247 = env10256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env10247 == env10256) = true)

theorem identity10256 : scanCanonicalize (H12AffineFastState.compose env10256 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10256 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10257 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58396,272392,16,41230,8192,16,10509,57629,45324,294912,1284,272392,256,41260,16385,513]

theorem envBound10257 : H12AffineFastState.Bounded env10257 := by
  intro p hp
  have h : env10257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10256_10257 : H12AffineEnvironment.transform 5 16 env10256 = env10257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10256 == env10257) = true)

theorem identity10257 : scanCanonicalize (H12AffineFastState.compose env10257 (packedSelected [5,6,8] rootPS)) = affineNative (2^(17+1) ^^^ 23840) := by decide +kernel

theorem selectedBound10257 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env10258 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,23840,1024,32769,58396,29992,16,41230,8192,16,10509,57629,45324,56608,1284,29992,256,41260,16385,513]

theorem envBound10258 : H12AffineFastState.Bounded env10258 := by
  intro p hp
  have h : env10258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10257_10258 : H12AffineEnvironment.transform 17 23840 env10257 = env10258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23840 env10257 == env10258) = true)

theorem identity10258 : scanCanonicalize (H12AffineFastState.compose env10258 (packedSelected [1,6,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10258 : packedSelected [1,6,24] rootPS < 2^1333 := by decide +kernel

def env10259 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16401,23840,1024,32769,50448,21540,16,32770,268,16,2049,49169,36864,56608,1284,21540,256,32800,16385,513]

theorem envBound10259 : H12AffineFastState.Bounded env10259 := by
  intro p hp
  have h : env10259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10258_10259 : H12AffineEnvironment.transform 12 268 env10258 = env10259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10258 == env10259) = true)

theorem identity10259 : scanCanonicalize (H12AffineFastState.compose env10259 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound10259 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10260 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5124,32768,263,5141,2340,1024,32769,37140,32,16,32770,268,16,2049,37909,36864,35108,1284,32,256,32800,5125,513]

theorem envBound10260 : H12AffineFastState.Bounded env10260 := by
  intro p hp
  have h : env10260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10259_10260 : H12AffineEnvironment.transform 13 5124 env10259 = env10260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env10259 == env10260) = true)

theorem identity10260 : scanCanonicalize (H12AffineFastState.compose env10260 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound10260 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env10261 : List Nat := [2,4,8,16,32,16,8,256,512,1024,276,4096,268,5124,32768,263,5141,48,1024,32769,37140,32,16,32770,268,16,277,37909,36864,32816,1284,32,256,32800,5125,513]

theorem envBound10261 : H12AffineFastState.Bounded env10261 := by
  intro p hp
  have h : env10261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10260_10261 : H12AffineEnvironment.transform 10 276 env10260 = env10261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env10260 == env10261) = true)

theorem identity10261 : scanCanonicalize (H12AffineFastState.compose env10261 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10261 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env10262 : List Nat := [2,4,8,16,32,16,8,256,512,1024,276,4096,268,5124,0,263,5141,48,1024,1,4372,32,16,2,268,16,277,5141,4096,48,1284,32,256,32,5125,513]

theorem envBound10262 : H12AffineFastState.Bounded env10262 := by
  intro p hp
  have h : env10262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10261_10262 : H12AffineEnvironment.transform 14 0 env10261 = env10262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10261 == env10262) = true)

theorem identity10262 : scanCanonicalize (H12AffineFastState.compose env10262 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10262 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10263 : List Nat := [2,4,8,16,1,16,8,256,512,1024,276,4096,268,5124,0,263,5141,17,1024,1,4372,1,16,2,268,16,277,5141,4096,17,1284,1,256,1,5125,513]

theorem envBound10263 : H12AffineFastState.Bounded env10263 := by
  intro p hp
  have h : env10263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10262_10263 : H12AffineEnvironment.transform 4 1 env10262 = env10263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10262 == env10263) = true)

theorem identity10263 : scanCanonicalize (H12AffineFastState.compose env10263 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound10263 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10264 : List Nat := [2,4,8,16,1,16,8,256,512,1024,276,17,268,1045,0,263,1028,17,1024,1,261,1,16,2,268,16,277,1028,17,17,1284,1,256,1,1044,513]

theorem envBound10264 : H12AffineFastState.Bounded env10264 := by
  intro p hp
  have h : env10264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10263_10264 : H12AffineEnvironment.transform 11 17 env10263 = env10264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env10263 == env10264) = true)

theorem identity10264 : scanCanonicalize (H12AffineFastState.compose env10264 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound10264 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10265 : List Nat := [2,4,8,16,1,16,8,256,261,1024,276,17,268,1045,0,263,1028,17,1024,1,261,1,16,2,268,16,277,1028,17,17,1284,1,256,1,1044,260]

theorem envBound10265 : H12AffineFastState.Bounded env10265 := by
  intro p hp
  have h : env10265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10264_10265 : H12AffineEnvironment.transform 8 261 env10264 = env10265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env10264 == env10265) = true)

theorem identity10265 : scanCanonicalize (H12AffineFastState.compose env10265 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound10265 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10266 : List Nat := [2,4,8,16,1,16,8,256,261,256,276,17,268,277,0,263,260,17,256,1,261,1,16,2,268,16,277,260,17,17,4,1,256,1,276,260]

theorem envBound10266 : H12AffineFastState.Bounded env10266 := by
  intro p hp
  have h : env10266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10265_10266 : H12AffineEnvironment.transform 9 256 env10265 = env10266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env10265 == env10266) = true)

def env10267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41310,8192,64,4677967,115015,45405,442385,75103,4268042,256,98678,90203,513]

theorem envBound10267 : H12AffineFastState.Bounded env10267 := by
  intro p hp
  have h : env10267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10244_10267 : H12AffineEnvironment.transform 20 58397 env10244 = env10267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env10244 == env10267) = true)

def env10268 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8192,16,4677919,114967,45325,442385,75023,4268042,256,98598,90123,513]

theorem envBound10268 : H12AffineFastState.Bounded env10268 := by
  intro p hp
  have h : env10268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10267_10268 : H12AffineEnvironment.transform 5 16 env10267 = env10268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10267 == env10268) = true)

def env10269 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41230,8192,16,4409655,114967,45325,190521,75023,4268042,256,98598,90123,513]

theorem envBound10269 : H12AffineFastState.Bounded env10269 := by
  intro p hp
  have h : env10269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10268_10269 : H12AffineEnvironment.transform 17 10280 env10268 = env10269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10268 == env10269) = true)

theorem identity10269 : scanCanonicalize (H12AffineFastState.compose env10269 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 65831) := by decide +kernel

theorem selectedBound10269 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env10270 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,65831,16,41230,8192,16,149520,114967,45325,190521,75023,8493,256,98598,90123,513]

theorem envBound10270 : H12AffineFastState.Bounded env10270 := by
  intro p hp
  have h : env10270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10269_10270 : H12AffineEnvironment.transform 21 65831 env10269 = env10270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65831 env10269 == env10270) = true)

theorem identity10270 : scanCanonicalize (H12AffineFastState.compose env10270 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound10270 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env10271 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,58397,65831,16,41230,8192,16,34817,114967,45325,10280,75023,8493,256,98598,90123,513]

theorem envBound10271 : H12AffineFastState.Bounded env10271 := by
  intro p hp
  have h : env10271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10270_10271 : H12AffineEnvironment.transform 16 49169 env10270 = env10271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env10270 == env10271) = true)

theorem identity10271 : scanCanonicalize (H12AffineFastState.compose env10271 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound10271 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10272 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,49169,10280,1024,32769,58397,41261,16,41230,8192,16,34817,24861,45325,10280,34053,8493,256,8492,49153,513]

theorem envBound10272 : H12AffineFastState.Bounded env10272 := by
  intro p hp
  have h : env10272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10271_10272 : H12AffineEnvironment.transform 15 40970 env10271 = env10272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env10271 == env10272) = true)

def env10273 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41230,8192,16,4409654,114967,45325,190520,75023,4268042,256,98598,90123,513]

theorem envBound10273 : H12AffineFastState.Bounded env10273 := by
  intro p hp
  have h : env10273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10268_10273 : H12AffineEnvironment.transform 17 10281 env10268 = env10273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10268 == env10273) = true)

theorem identity10273 : scanCanonicalize (H12AffineFastState.compose env10273 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 199939) := by decide +kernel

theorem selectedBound10273 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env10274 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,199939,16,41230,8192,16,17461,114967,45325,190520,75023,142601,256,98598,90123,513]

theorem envBound10274 : H12AffineFastState.Bounded env10274 := by
  intro p hp
  have h : env10274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10273_10274 : H12AffineEnvironment.transform 21 199939 env10273 = env10274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 199939 env10273 == env10274) = true)

theorem identity10274 : scanCanonicalize (H12AffineFastState.compose env10274 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound10274 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env10275 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,58397,27929,16,41230,8192,16,17461,114967,45325,100386,75023,85267,256,98598,90123,513]

theorem envBound10275 : H12AffineFastState.Bounded env10275 := by
  intro p hp
  have h : env10275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10274_10275 : H12AffineEnvironment.transform 16 90138 env10274 = env10275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env10274 == env10275) = true)

theorem identity10275 : scanCanonicalize (H12AffineFastState.compose env10275 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 24879) := by decide +kernel

theorem selectedBound10275 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env10276 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,24879,309,10281,1024,32769,58397,27929,16,41230,8192,16,17461,41016,45325,59661,17440,11324,256,57353,292,513]

theorem envBound10276 : H12AffineFastState.Bounded env10276 := by
  intro p hp
  have h : env10276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10275_10276 : H12AffineEnvironment.transform 15 24879 env10275 = env10276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24879 env10275 == env10276) = true)

theorem identity10276 : scanCanonicalize (H12AffineFastState.compose env10276 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound10276 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10277 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,293,32768,8202,309,10281,1024,32769,42296,11324,16,41230,8192,16,1296,41016,45325,43048,1285,11324,256,41260,292,513]

theorem envBound10277 : H12AffineFastState.Bounded env10277 := by
  intro p hp
  have h : env10277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10276_10277 : H12AffineEnvironment.transform 13 293 env10276 = env10277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env10276 == env10277) = true)

theorem identity10277 : scanCanonicalize (H12AffineFastState.compose env10277 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound10277 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10278 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,8192,293,32768,8202,309,10281,1024,32769,42296,11324,16,41230,8192,16,1296,41016,41016,43048,1285,11324,256,41260,292,513]

theorem envBound10278 : H12AffineFastState.Bounded env10278 := by
  intro p hp
  have h : env10278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10277_10278 : H12AffineEnvironment.transform 11 309 env10277 = env10278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env10277 == env10278) = true)

theorem identity10278 : scanCanonicalize (H12AffineFastState.compose env10278 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound10278 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env10279 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,309,8192,293,32768,8202,309,8232,1024,32769,42296,9277,16,41230,8192,16,1296,41016,41016,41001,1285,9277,256,41260,292,513]

theorem envBound10279 : H12AffineFastState.Bounded env10279 := by
  intro p hp
  have h : env10279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10278_10279 : H12AffineEnvironment.transform 10 1 env10278 = env10279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env10278 == env10279) = true)

theorem identity10279 : scanCanonicalize (H12AffineFastState.compose env10279 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10279 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10280 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,16,8192,0,32768,8202,16,8232,1024,32769,42013,9277,16,41003,8192,16,1077,41016,41016,41001,1056,9277,37,40969,1,513]

theorem envBound10280 : H12AffineFastState.Bounded env10280 := by
  intro p hp
  have h : env10280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10279_10280 : H12AffineEnvironment.transform 7 37 env10279 = env10280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10279 == env10280) = true)

theorem identity10280 : scanCanonicalize (H12AffineFastState.compose env10280 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(14+1) ^^^ 513) := by decide +kernel

theorem selectedBound10280 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env10281 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,16,8192,0,513,8202,16,8232,1024,512,9756,9277,16,8746,8192,16,1077,8761,8761,8744,1056,9277,37,8712,1,513]

theorem envBound10281 : H12AffineFastState.Bounded env10281 := by
  intro p hp
  have h : env10281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10280_10281 : H12AffineEnvironment.transform 14 513 env10280 = env10281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env10280 == env10281) = true)

theorem identity10281 : scanCanonicalize (H12AffineFastState.compose env10281 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound10281 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env10282 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,16,57,0,513,51,16,17,1024,512,1573,1028,16,531,57,16,1077,512,512,529,1056,1028,37,561,1,513]

theorem envBound10282 : H12AffineFastState.Bounded env10282 := by
  intro p hp
  have h : env10282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10281_10282 : H12AffineEnvironment.transform 12 57 env10281 = env10282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env10281 == env10282) = true)

theorem identity10282 : scanCanonicalize (H12AffineFastState.compose env10282 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound10282 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env10283 : List Nat := [2,4,8,16,32,16,8,37,512,565,1,16,57,0,513,51,16,17,565,512,16,561,16,531,57,16,512,512,512,529,533,561,37,561,1,513]

theorem envBound10283 : H12AffineFastState.Bounded env10283 := by
  intro p hp
  have h : env10283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10282_10283 : H12AffineEnvironment.transform 9 565 env10282 = env10283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env10282 == env10283) = true)

theorem identity10283 : scanCanonicalize (H12AffineFastState.compose env10283 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound10283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10284 : List Nat := [2,4,8,16,32,16,8,37,33,20,1,16,57,0,32,51,16,17,20,33,16,16,16,50,57,16,33,33,33,48,52,16,37,16,1,32]

theorem envBound10284 : H12AffineFastState.Bounded env10284 := by
  intro p hp
  have h : env10284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10283_10284 : H12AffineEnvironment.transform 8 33 env10283 = env10284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env10283 == env10284) = true)

theorem identity10284 : scanCanonicalize (H12AffineFastState.compose env10284 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10284 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env10285 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,16,24,0,1,18,16,17,20,0,16,16,16,19,24,16,0,0,0,17,21,16,4,16,1,1]

theorem envBound10285 : H12AffineFastState.Bounded env10285 := by
  intro p hp
  have h : env10285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10284_10285 : H12AffineEnvironment.transform 4 1 env10284 = env10285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10284 == env10285) = true)

def env10286 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8192,17,4677918,114966,45324,442385,75022,4268042,256,98599,90122,513]

theorem envBound10286 : H12AffineFastState.Bounded env10286 := by
  intro p hp
  have h : env10286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10267_10286 : H12AffineEnvironment.transform 5 17 env10267 = env10286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10267 == env10286) = true)

theorem identity10286 : scanCanonicalize (H12AffineFastState.compose env10286 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10286 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env10287 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41231,8192,17,4409654,114966,45324,190521,75022,4268042,256,98599,90122,513]

theorem envBound10287 : H12AffineFastState.Bounded env10287 := by
  intro p hp
  have h : env10287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10286_10287 : H12AffineEnvironment.transform 17 10280 env10286 = env10287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10286 == env10287) = true)

theorem identity10287 : scanCanonicalize (H12AffineFastState.compose env10287 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound10287 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env10288 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,4194304,16,41231,8192,17,4204845,114966,45324,100386,75022,4268042,256,98599,90122,513]

theorem envBound10288 : H12AffineFastState.Bounded env10288 := by
  intro p hp
  have h : env10288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10287_10288 : H12AffineEnvironment.transform 16 90139 env10287 = env10288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env10287 == env10288) = true)

theorem identity10288 : scanCanonicalize (H12AffineFastState.compose env10288 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 65831) := by decide +kernel

theorem selectedBound10288 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env10289 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,65831,16,41231,8192,17,75786,114966,45324,100386,75022,8493,256,98599,90122,513]

theorem envBound10289 : H12AffineFastState.Bounded env10289 := by
  intro p hp
  have h : env10289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10288_10289 : H12AffineEnvironment.transform 21 65831 env10288 = env10289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65831 env10288 == env10289) = true)

theorem identity10289 : scanCanonicalize (H12AffineFastState.compose env10289 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound10289 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10290 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33031,57628,10280,1024,32769,58397,32800,16,41231,8192,17,43277,16401,45324,2341,41993,8493,256,32,57613,513]

theorem envBound10290 : H12AffineFastState.Bounded env10290 := by
  intro p hp
  have h : env10290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10289_10290 : H12AffineEnvironment.transform 15 33031 env10289 = env10290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env10289 == env10290) = true)

theorem identity10290 : scanCanonicalize (H12AffineFastState.compose env10290 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10290 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10291 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,33031,49169,2341,1024,32769,50448,32800,16,32770,269,17,34816,16401,36865,2341,34052,32,256,32,49152,513]

theorem envBound10291 : H12AffineFastState.Bounded env10291 := by
  intro p hp
  have h : env10291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10290_10291 : H12AffineEnvironment.transform 12 269 env10290 = env10291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10290 == env10291) = true)

theorem identity10291 : scanCanonicalize (H12AffineFastState.compose env10291 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound10291 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10292 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,32768,33031,37941,2341,1024,32769,37172,32800,16,32770,269,17,34816,5173,36865,2341,34052,32,256,32,37924,513]

theorem envBound10292 : H12AffineFastState.Bounded env10292 := by
  intro p hp
  have h : env10292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10291_10292 : H12AffineEnvironment.transform 13 5156 env10291 = env10292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env10291 == env10292) = true)

theorem identity10292 : scanCanonicalize (H12AffineFastState.compose env10292 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound10292 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env10293 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,269,5156,32768,33031,37941,1296,1024,32769,37172,32800,16,32770,269,17,33845,5173,36865,1296,34052,32,256,32,37924,513]

theorem envBound10293 : H12AffineFastState.Bounded env10293 := by
  intro p hp
  have h : env10293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10292_10293 : H12AffineEnvironment.transform 10 1077 env10292 = env10293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env10292 == env10293) = true)

theorem identity10293 : scanCanonicalize (H12AffineFastState.compose env10293 (packedSelected [2,4,7] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound10293 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env10294 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,269,5156,32,295,5141,1296,1024,33,4372,0,16,34,269,17,1045,5173,4129,1296,1316,32,256,32,5124,513]

theorem envBound10294 : H12AffineFastState.Bounded env10294 := by
  intro p hp
  have h : env10294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10293_10294 : H12AffineEnvironment.transform 14 32 env10293 = env10294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env10293 == env10294) = true)

def env10295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41311,8192,64,4677967,2172251,2118977,442384,75103,6407190,256,2188651,2196550,513]

theorem envBound10295 : H12AffineFastState.Bounded env10295 := by
  intro p hp
  have h : env10295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10243_10295 : H12AffineEnvironment.transform 22 17 env10243 = env10295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env10243 == env10295) = true)

theorem identity10295 : scanCanonicalize (H12AffineFastState.compose env10295 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound10295 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,17,41311,8192,64,4456789,2172251,2118977,368650,75103,6407190,256,2188651,2196550,513]

theorem envBound10296 : H12AffineFastState.Bounded env10296 := by
  intro p hp
  have h : env10296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10295_10296 : H12AffineEnvironment.transform 16 90138 env10295 = env10296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env10295 == env10296) = true)

theorem identity10296 : scanCanonicalize (H12AffineFastState.compose env10296 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound10296 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,262144,1024,32769,2097152,4194304,17,41311,8192,64,4456789,2139149,2118977,270684,41993,6309184,256,2155581,2098448,513]

theorem envBound10297 : H12AffineFastState.Bounded env10297 := by
  intro p hp
  have h : env10297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10296_10297 : H12AffineEnvironment.transform 15 33110 env10296 = env10297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env10296 == env10297) = true)

theorem identity10297 : scanCanonicalize (H12AffineFastState.compose env10297 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10297 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,2097152,4194304,17,41311,8192,64,4204925,2139149,2118977,2420,41993,6309184,256,2155581,2098448,513]

theorem envBound10298 : H12AffineFastState.Bounded env10298 := by
  intro p hp
  have h : env10298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10297_10298 : H12AffineEnvironment.transform 17 10280 env10297 = env10298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10297 == env10298) = true)

theorem identity10298 : scanCanonicalize (H12AffineFastState.compose env10298 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound10298 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env10299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,25676,4194304,17,41311,8192,64,4204925,49217,12557,2420,41993,4202764,256,32881,24924,513]

theorem envBound10299 : H12AffineFastState.Bounded env10299 := by
  intro p hp
  have h : env10299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10298_10299 : H12AffineEnvironment.transform 20 25676 env10298 = env10299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env10298 == env10299) = true)

theorem identity10299 : scanCanonicalize (H12AffineFastState.compose env10299 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound10299 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,25676,8493,17,41311,8192,64,2128,49217,12557,2420,41993,33,256,32881,24924,513]

theorem envBound10300 : H12AffineFastState.Bounded env10300 := by
  intro p hp
  have h : env10300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10299_10300 : H12AffineEnvironment.transform 21 8493 env10299 = env10300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env10299 == env10300) = true)

theorem identity10300 : scanCanonicalize (H12AffineFastState.compose env10300 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10300 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1024,8541,25676,8493,17,3,8192,64,2128,24861,12557,2420,1365,33,256,8493,24924,513]

theorem envBound10301 : H12AffineFastState.Bounded env10301 := by
  intro p hp
  have h : env10301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10300_10301 : H12AffineEnvironment.transform 14 8540 env10300 = env10301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10300 == env10301) = true)

theorem identity10301 : scanCanonicalize (H12AffineFastState.compose env10301 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10301 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env10302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,80,262,16400,2340,1024,81,17728,33,17,3,268,64,2128,16401,4097,2420,1365,33,256,33,16464,513]

theorem envBound10302 : H12AffineFastState.Bounded env10302 := by
  intro p hp
  have h : env10302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10301_10302 : H12AffineEnvironment.transform 12 268 env10301 = env10302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10301 == env10302) = true)

theorem identity10302 : scanCanonicalize (H12AffineFastState.compose env10302 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1392) := by decide +kernel

theorem selectedBound10302 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1392,268,16384,80,262,16400,2340,1024,81,17728,33,17,3,268,64,2128,16401,1393,2420,1365,33,256,33,16464,513]

theorem envBound10303 : H12AffineFastState.Bounded env10303 := by
  intro p hp
  have h : env10303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10302_10303 : H12AffineEnvironment.transform 11 1392 env10302 = env10303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1392 env10302 == env10303) = true)

theorem identity10303 : scanCanonicalize (H12AffineFastState.compose env10303 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2625) := by decide +kernel

theorem selectedBound10303 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env10304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1392,268,2625,80,262,2641,2340,1024,81,3841,33,17,3,268,64,2128,2640,1393,2420,1365,33,256,33,2577,513]

theorem envBound10304 : H12AffineFastState.Bounded env10304 := by
  intro p hp
  have h : env10304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10303_10304 : H12AffineEnvironment.transform 13 2625 env10303 = env10304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2625 env10303 == env10304) = true)

theorem identity10304 : scanCanonicalize (H12AffineFastState.compose env10304 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound10304 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env10305 : List Nat := [2,4,8,16,32,64,8,256,277,1024,2048,1392,268,2388,80,262,2372,2340,1024,81,3092,33,17,3,268,64,2128,2373,1393,2420,1365,33,256,33,2308,276]

theorem envBound10305 : H12AffineFastState.Bounded env10305 := by
  intro p hp
  have h : env10305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10304_10305 : H12AffineEnvironment.transform 8 277 env10304 = env10305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env10304 == env10305) = true)

theorem identity10305 : scanCanonicalize (H12AffineFastState.compose env10305 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10305 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10306 : List Nat := [2,4,8,16,32,64,8,84,65,1024,2048,1060,88,2048,80,82,2064,2160,1024,81,3092,33,17,3,88,64,2128,2065,1061,2080,1025,33,84,33,2128,64]

theorem envBound10306 : H12AffineFastState.Bounded env10306 := by
  intro p hp
  have h : env10306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10305_10306 : H12AffineEnvironment.transform 7 84 env10305 = env10306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10305 == env10306) = true)

theorem identity10306 : scanCanonicalize (H12AffineFastState.compose env10306 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10306 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env10307 : List Nat := [2,4,8,16,32,17,8,5,16,1024,2048,1060,9,2048,1,3,2064,2081,1024,0,3092,33,17,3,9,17,2049,2065,1061,2080,1025,33,5,33,2049,17]

theorem envBound10307 : H12AffineFastState.Bounded env10307 := by
  intro p hp
  have h : env10307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10306_10307 : H12AffineEnvironment.transform 5 17 env10306 = env10307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10306 == env10307) = true)

def env10308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429902,8193,64,4677967,10560843,10507600,8830977,75103,14795782,256,2188650,2196550,512]

theorem envBound10308 : H12AffineFastState.Bounded env10308 := by
  intro p hp
  have h : env10308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10242_10308 : H12AffineEnvironment.transform 6 9 env10242 = env10308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10242 == env10308) = true)

theorem identity10308 : scanCanonicalize (H12AffineFastState.compose env10308 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4235629) := by decide +kernel

theorem selectedBound10308 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,4235629,4194339,8193,64,4677967,6390822,6353981,4612460,75103,2188651,256,2188650,2196550,512]

theorem envBound10309 : H12AffineFastState.Bounded env10309 := by
  intro p hp
  have h : env10309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10308_10309 : H12AffineEnvironment.transform 22 4235629 env10308 = env10309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235629 env10308 == env10309) = true)

theorem identity10309 : scanCanonicalize (H12AffineFastState.compose env10309 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 188781) := by decide +kernel

theorem selectedBound10309 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,188781,147456,188750,8193,64,360482,2319691,2233680,294913,75103,2188651,256,2188650,2196550,512]

theorem envBound10310 : H12AffineFastState.Bounded env10310 := by
  intro p hp
  have h : env10310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10309_10310 : H12AffineEnvironment.transform 21 188781 env10309 = env10310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188781 env10309 == env10310) = true)

theorem identity10310 : scanCanonicalize (H12AffineFastState.compose env10310 (packedSelected [1,5,8,11,17,18,19,21,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10310 : packedSelected [1,5,8,11,17,18,19,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env10311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,188781,147456,188750,8193,64,108554,2319691,2233680,43049,75103,2188651,256,2188650,2196550,512]

theorem envBound10311 : H12AffineFastState.Bounded env10311 := by
  intro p hp
  have h : env10311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10310_10311 : H12AffineEnvironment.transform 17 10280 env10310 = env10311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10310 == env10311) = true)

theorem identity10311 : scanCanonicalize (H12AffineFastState.compose env10311 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound10311 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,32,41293,3,8193,64,108554,2196486,2159645,43049,75103,2188651,256,2188650,2196550,512]

theorem envBound10312 : H12AffineFastState.Bounded env10312 := by
  intro p hp
  have h : env10312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10311_10312 : H12AffineEnvironment.transform 16 57677 env10311 = env10312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env10311 == env10312) = true)

theorem identity10312 : scanCanonicalize (H12AffineFastState.compose env10312 (packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 91419) := by decide +kernel

theorem selectedBound10312 : packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env10313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,91419,32,41293,3,8193,64,108554,57629,102662,43049,75103,112,256,113,57693,512]

theorem envBound10313 : H12AffineFastState.Bounded env10313 := by
  intro p hp
  have h : env10313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10312_10313 : H12AffineEnvironment.transform 20 91419 env10312 = env10313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91419 env10312 == env10313) = true)

theorem identity10313 : scanCanonicalize (H12AffineFastState.compose env10313 (packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound10313 : packedSelected [2,3,4,5,6,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env10314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,57677,10280,1024,32769,50448,32,41293,3,8193,64,2049,57629,12557,43049,34132,112,256,113,57693,512]

theorem envBound10314 : H12AffineFastState.Bounded env10314 := by
  intro p hp
  have h : env10314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10313_10314 : H12AffineEnvironment.transform 15 40971 env10313 = env10314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env10313 == env10314) = true)

theorem identity10314 : scanCanonicalize (H12AffineFastState.compose env10314 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5489) := by decide +kernel

theorem selectedBound10314 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5489,32768,40971,46140,10280,1024,32769,36961,32,41293,3,8193,64,2049,46188,12557,43049,34132,112,256,113,46124,512]

theorem envBound10315 : H12AffineFastState.Bounded env10315 := by
  intro p hp
  have h : env10315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10314_10315 : H12AffineEnvironment.transform 13 5489 env10314 = env10315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5489 env10314 == env10315) = true)

theorem identity10315 : scanCanonicalize (H12AffineFastState.compose env10315 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound10315 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10316 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5489,293,8494,13593,10280,1024,292,4420,32,8296,3,8193,64,2049,13641,12557,10508,1137,112,256,113,13577,512]

theorem envBound10316 : H12AffineFastState.Bounded env10316 := by
  intro p hp
  have h : env10316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10315_10316 : H12AffineEnvironment.transform 14 293 env10315 = env10316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env10315 == env10316) = true)

theorem identity10316 : scanCanonicalize (H12AffineFastState.compose env10316 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10316 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env10317 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5204,0,8203,13372,10280,1024,1,4193,32,8296,3,8193,64,2049,13420,12328,10281,1137,112,37,113,13356,512]

theorem envBound10317 : H12AffineFastState.Bounded env10317 := by
  intro p hp
  have h : env10317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10316_10317 : H12AffineEnvironment.transform 7 37 env10316 = env10317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10316 == env10317) = true)

theorem identity10317 : scanCanonicalize (H12AffineFastState.compose env10317 (packedSelected [0,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound10317 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env10318 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,9,5204,0,2,5173,2081,1024,1,4193,32,97,3,8,64,2049,5221,4129,2080,1137,112,37,113,5157,512]

theorem envBound10318 : H12AffineFastState.Bounded env10318 := by
  intro p hp
  have h : env10318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10317_10318 : H12AffineEnvironment.transform 12 9 env10317 = env10318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env10317 == env10318) = true)

theorem identity10318 : scanCanonicalize (H12AffineFastState.compose env10318 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10318 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10319 : List Nat := [2,4,8,16,1,64,9,4,512,1024,2048,4096,9,5204,0,2,5140,2048,1024,1,4160,1,64,3,8,64,2049,5188,4096,2049,1104,81,4,80,5124,512]

theorem envBound10319 : H12AffineFastState.Bounded env10319 := by
  intro p hp
  have h : env10319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10318_10319 : H12AffineEnvironment.transform 4 1 env10318 = env10319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10318 == env10319) = true)

theorem identity10319 : scanCanonicalize (H12AffineFastState.compose env10319 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10319 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env10320 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5124,0,2,5140,2048,1024,1,4112,1,16,3,8,16,2049,5140,4096,2049,1024,1,4,0,5124,512]

theorem envBound10320 : H12AffineFastState.Bounded env10320 := by
  intro p hp
  have h : env10320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10319_10320 : H12AffineEnvironment.transform 5 16 env10319 = env10320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10319 == env10320) = true)

def env10321 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,9,1044,0,2,1028,2048,1024,1,0,1,16,3,8,16,2049,1028,16,2049,1024,1,4,0,1044,512]

theorem envBound10321 : H12AffineFastState.Bounded env10321 := by
  intro p hp
  have h : env10321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10320_10321 : H12AffineEnvironment.transform 11 16 env10320 = env10321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env10320 == env10321) = true)

theorem identity10321 : scanCanonicalize (H12AffineFastState.compose env10321 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound10321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10322 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,9,0,0,2,16,2048,20,1,0,1,16,3,8,16,2049,16,16,2049,20,1,4,0,0,512]

theorem envBound10322 : H12AffineFastState.Bounded env10322 := by
  intro p hp
  have h : env10322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10321_10322 : H12AffineEnvironment.transform 9 20 env10321 = env10322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env10321 == env10322) = true)

theorem identity10322 : scanCanonicalize (H12AffineFastState.compose env10322 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound10322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10323 : List Nat := [2,4,8,4,1,4,9,4,512,0,2048,4,9,0,0,2,4,2048,0,1,0,1,4,3,8,4,2049,4,4,2049,0,1,4,0,0,512]

theorem envBound10323 : H12AffineFastState.Bounded env10323 := by
  intro p hp
  have h : env10323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10322_10323 : H12AffineEnvironment.transform 3 4 env10322 = env10323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env10322 == env10323) = true)

def leafEnv10323 : List Nat := [2,4,8,4,1,4,9,4,512,0,2048,4,9,0,0,2,4,2048,0,1,0,1,4,3,0,8,1,4,2049,4,4,2049,0,1,4,0,4,3,0,512,1,0,0]

def active10323 : List Nat := [0,1,2,8,10]

def tree10323 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10323 : H12WitnessSearch.Good tree10323 := H12GlobalWitnessIndex.good

theorem leafIdentity10323 : H12AffineFastState.composeSystem env10323 rootObs = leafEnv10323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10323 rootObs == leafEnv10323) = true)

theorem terminalChecked10323 : H12PackedTerminal.terminalCheckFast leafEnv10323 active10323 tree10323 = true := by decide +kernel

def env10324 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,9,1045,0,2,1029,2048,1024,1,1,1,16,3,8,16,2049,1029,17,2049,1024,1,4,0,1045,512]

theorem envBound10324 : H12AffineFastState.Bounded env10324 := by
  intro p hp
  have h : env10324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10320_10324 : H12AffineEnvironment.transform 11 17 env10320 = env10324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env10320 == env10324) = true)

def env10325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound10325 : H12AffineFastState.Bounded env10325 := by
  intro p hp
  have h : env10325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10240_10325 : H12AffineEnvironment.transform 18 1025 env10240 = env10325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10240 == env10325) = true)

theorem identity10325 : scanCanonicalize (H12AffineFastState.compose env10325 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound10325 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29655503,18973837,10507600,8749519,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound10326 : H12AffineFastState.Bounded env10326 := by
  intro p hp
  have h : env10326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10325_10326 : H12AffineEnvironment.transform 16 82383 env10325 = env10326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env10325 == env10326) = true)

def env10327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6623299,8393985,10507600,8749519,2102685,12645453,257,21792,46212,2175562]

theorem envBound10327 : H12AffineFastState.Bounded env10327 := by
  intro p hp
  have h : env10327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10326_10327 : H12AffineEnvironment.transform 23 10588556 env10326 = env10327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env10326 == env10327) = true)

def env10328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6623299,2098513,17664,2462111,2102685,6349853,257,21792,46212,2175562]

theorem envBound10328 : H12AffineFastState.Bounded env10328 := by
  intro p hp
  have h : env10328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10327_10328 : H12AffineEnvironment.transform 22 2101328 env10327 = env10328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env10327 == env10328) = true)

def env10329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2177219,2098513,17664,2462111,2102685,2411677,257,21792,46212,2175562]

theorem envBound10329 : H12AffineFastState.Bounded env10329 := by
  intro p hp
  have h : env10329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10328_10329 : H12AffineEnvironment.transform 21 272512 env10328 = env10329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10328 == env10329) = true)

theorem identity10329 : scanCanonicalize (H12AffineFastState.compose env10329 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound10329 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115871,272512,120015,98780,8328,64,64604,115150,17664,283904,119042,329730,257,21792,46212,63189]

theorem envBound10330 : H12AffineFastState.Bounded env10330 := by
  intro p hp
  have h : env10330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10329_10330 : H12AffineEnvironment.transform 20 115871 env10329 = env10330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env10329 == env10330) = true)

def env10331 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,115871,272512,119967,98700,8328,16,64524,115102,17664,283904,119042,329730,257,21792,46212,63109]

theorem envBound10331 : H12AffineFastState.Bounded env10331 := by
  intro p hp
  have h : env10331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10330_10331 : H12AffineEnvironment.transform 5 16 env10330 = env10331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10330 == env10331) = true)

theorem identity10331 : scanCanonicalize (H12AffineFastState.compose env10331 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 64928) := by decide +kernel

theorem selectedBound10331 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env10332 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,64928,1025,32769,115871,54560,119967,98700,8328,16,64524,115102,17664,43168,119042,128418,257,21792,46212,63109]

theorem envBound10332 : H12AffineFastState.Bounded env10332 := by
  intro p hp
  have h : env10332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10331_10332 : H12AffineEnvironment.transform 17 64928 env10331 = env10332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64928 env10331 == env10332) = true)

theorem identity10332 : scanCanonicalize (H12AffineFastState.compose env10332 (packedSelected [4,5,7,8,9,10,16,17,18,20,23,24,26,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10332 : packedSelected [4,5,7,8,9,10,16,17,18,20,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env10333 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,65536,70814,43169,1025,32769,102814,32801,98718,98700,8328,16,43277,103583,4097,43168,99331,106659,257,33,46212,41860]

theorem envBound10333 : H12AffineFastState.Bounded env10333 := by
  intro p hp
  have h : env10333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10332_10333 : H12AffineEnvironment.transform 13 5377 env10332 = env10333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10332 == env10333) = true)

theorem identity10333 : scanCanonicalize (H12AffineFastState.compose env10333 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound10333 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env10334 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,65536,70814,2340,1025,8580,77851,8612,73755,73737,8328,16,2184,79130,4097,2341,75142,65830,257,33,5377,513]

theorem envBound10334 : H12AffineFastState.Bounded env10334 := by
  intro p hp
  have h : env10334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10333_10334 : H12AffineEnvironment.transform 14 8581 env10333 = env10334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env10333 == env10334) = true)

theorem identity10334 : scanCanonicalize (H12AffineFastState.compose env10334 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound10334 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env10335 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,0,65536,70814,2340,1025,1,70046,33,65950,65932,269,16,2184,70815,4097,2341,66563,65830,257,33,5377,513]

theorem envBound10335 : H12AffineFastState.Bounded env10335 := by
  intro p hp
  have h : env10335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10334_10335 : H12AffineEnvironment.transform 12 389 env10334 = env10335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env10334 == env10335) = true)

theorem identity10335 : scanCanonicalize (H12AffineFastState.compose env10335 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound10335 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env10336 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,0,262,5528,2340,1025,1,4248,33,152,138,269,16,2184,5529,4097,2341,1285,32,257,33,5377,513]

theorem envBound10336 : H12AffineFastState.Bounded env10336 := by
  intro p hp
  have h : env10336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10335_10336 : H12AffineEnvironment.transform 15 262 env10335 = env10336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env10335 == env10336) = true)

theorem identity10336 : scanCanonicalize (H12AffineFastState.compose env10336 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10336 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10337 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,262,5392,2340,1025,1,4112,33,16,2,269,16,2048,5393,4097,2341,1285,32,257,33,5377,513]

theorem envBound10337 : H12AffineFastState.Bounded env10337 := by
  intro p hp
  have h : env10337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10336_10337 : H12AffineEnvironment.transform 6 8 env10336 = env10337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10336 == env10337) = true)

theorem identity10337 : scanCanonicalize (H12AffineFastState.compose env10337 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound10337 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10338 : List Nat := [2,4,8,16,17,16,8,256,512,1024,2048,4096,269,5377,0,262,5392,2325,1025,1,4112,16,16,2,269,16,2048,5393,4097,2324,1285,17,257,16,5377,513]

theorem envBound10338 : H12AffineFastState.Bounded env10338 := by
  intro p hp
  have h : env10338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10337_10338 : H12AffineEnvironment.transform 4 17 env10337 = env10338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env10337 == env10338) = true)

theorem identity10338 : scanCanonicalize (H12AffineFastState.compose env10338 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound10338 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10339 : List Nat := [2,4,8,16,17,16,8,256,512,1024,2048,1557,269,788,0,262,773,2325,1025,1,1541,16,16,2,269,16,2048,772,1556,2324,1285,17,257,16,788,513]

theorem envBound10339 : H12AffineFastState.Bounded env10339 := by
  intro p hp
  have h : env10339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10338_10339 : H12AffineEnvironment.transform 11 1557 env10338 = env10339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env10338 == env10339) = true)

theorem identity10339 : scanCanonicalize (H12AffineFastState.compose env10339 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound10339 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10340 : List Nat := [2,4,8,16,17,16,8,256,512,1024,1540,1557,269,788,0,262,773,1809,1025,1,1541,16,16,2,269,16,1540,772,1556,1808,1285,17,257,16,788,513]

theorem envBound10340 : H12AffineFastState.Bounded env10340 := by
  intro p hp
  have h : env10340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10339_10340 : H12AffineEnvironment.transform 10 1540 env10339 = env10340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env10339 == env10340) = true)

theorem identity10340 : scanCanonicalize (H12AffineFastState.compose env10340 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10340 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10341 : List Nat := [2,4,8,16,17,16,8,5,512,1024,1540,1557,8,529,0,3,512,1556,1025,1,1541,16,16,2,8,16,1540,513,1556,1557,1024,17,4,16,529,513]

theorem envBound10341 : H12AffineFastState.Bounded env10341 := by
  intro p hp
  have h : env10341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10340_10341 : H12AffineEnvironment.transform 7 5 env10340 = env10341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10340 == env10341) = true)

theorem identity10341 : scanCanonicalize (H12AffineFastState.compose env10341 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound10341 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10342 : List Nat := [2,4,8,16,17,16,8,5,512,21,529,512,8,529,0,3,512,513,20,1,528,16,16,2,8,16,529,513,513,512,21,17,4,16,529,513]

theorem envBound10342 : H12AffineFastState.Bounded env10342 := by
  intro p hp
  have h : env10342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10341_10342 : H12AffineEnvironment.transform 9 21 env10341 = env10342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env10341 == env10342) = true)

theorem identity10342 : scanCanonicalize (H12AffineFastState.compose env10342 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10342 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10343 : List Nat := [2,4,8,16,17,16,8,5,0,21,17,0,8,17,0,3,0,1,20,1,16,16,16,2,8,16,17,1,1,0,21,17,4,16,17,1]

theorem envBound10343 : H12AffineFastState.Bounded env10343 := by
  intro p hp
  have h : env10343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10342_10343 : H12AffineEnvironment.transform 8 0 env10342 = env10343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10342 == env10343) = true)

theorem identity10343 : scanCanonicalize (H12AffineFastState.compose env10343 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10344 : List Nat := [2,4,8,11,10,11,8,5,0,14,10,0,8,10,0,3,0,1,15,1,11,11,11,2,8,11,10,1,1,0,14,10,4,11,10,1]

theorem envBound10344 : H12AffineFastState.Bounded env10344 := by
  intro p hp
  have h : env10344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10343_10344 : H12AffineEnvironment.transform 3 11 env10343 = env10344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10343 == env10344) = true)

def env10345 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,115871,272512,119966,98701,8328,17,64525,115103,17664,283904,119042,329730,257,21792,46212,63108]

theorem envBound10345 : H12AffineFastState.Bounded env10345 := by
  intro p hp
  have h : env10345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10330_10345 : H12AffineEnvironment.transform 5 17 env10330 = env10345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10330 == env10345) = true)

theorem identity10345 : scanCanonicalize (H12AffineFastState.compose env10345 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 100386) := by decide +kernel

theorem selectedBound10345 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env10346 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,100386,1025,32769,115871,106658,119966,98701,8328,17,64525,115103,17664,122146,119042,32800,257,21792,46212,63108]

theorem envBound10346 : H12AffineFastState.Bounded env10346 := by
  intro p hp
  have h : env10346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10345_10346 : H12AffineEnvironment.transform 17 100386 env10345 = env10346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100386 env10345 == env10346) = true)

theorem identity10346 : scanCanonicalize (H12AffineFastState.compose env10346 (packedSelected [4,5,7,8,9,10,16,17,18,20,23,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound10346 : packedSelected [4,5,7,8,9,10,16,17,18,20,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env10347 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,65536,82334,76199,1025,8580,91418,65831,95515,73736,8328,17,23944,90138,17664,97447,94343,8613,257,21792,5377,22273]

theorem envBound10347 : H12AffineFastState.Bounded env10347 := by
  intro p hp
  have h : env10347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10346_10347 : H12AffineEnvironment.transform 14 8581 env10346 = env10347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env10346 == env10347) = true)

theorem identity10347 : scanCanonicalize (H12AffineFastState.compose env10347 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound10347 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env10348 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8322,24860,2341,1025,8580,17816,8613,21913,138,8328,17,23944,16536,17664,23589,20485,8613,257,21792,5377,22273]

theorem envBound10348 : H12AffineFastState.Bounded env10348 := by
  intro p hp
  have h : env10348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10347_10348 : H12AffineEnvironment.transform 15 8322 env10347 = env10348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env10347 == env10348) = true)

theorem identity10348 : scanCanonicalize (H12AffineFastState.compose env10348 (packedSelected [1,4,8,9,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10348 : packedSelected [1,4,8,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env10349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,136,399,16401,2341,1025,137,17816,168,21913,138,389,17,23944,16536,17664,23589,20485,168,257,21792,5377,22273]

theorem envBound10349 : H12AffineFastState.Bounded env10349 := by
  intro p hp
  have h : env10349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10348_10349 : H12AffineEnvironment.transform 12 269 env10348 = env10349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10348 == env10349) = true)

theorem identity10349 : scanCanonicalize (H12AffineFastState.compose env10349 (packedSelected [1,3,4,5,8,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10349 : packedSelected [1,3,4,5,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env10350 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1025,1,17680,32,21777,2,269,17,23808,16400,17664,23589,20485,32,257,21792,5377,22273]

theorem envBound10350 : H12AffineFastState.Bounded env10350 := by
  intro p hp
  have h : env10350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10349_10350 : H12AffineEnvironment.transform 6 8 env10349 = env10350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10349 == env10350) = true)

theorem identity10350 : scanCanonicalize (H12AffineFastState.compose env10350 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10350 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env10351 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,9,16384,0,3,16401,2081,1025,1,17428,32,21525,2,9,17,23556,16400,17412,23589,20485,32,5,21540,5125,22021]

theorem envBound10351 : H12AffineFastState.Bounded env10351 := by
  intro p hp
  have h : env10351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10350_10351 : H12AffineEnvironment.transform 7 4 env10350 = env10351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10350 == env10351) = true)

theorem identity10351 : scanCanonicalize (H12AffineFastState.compose env10351 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10351 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env10352 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,9,16384,0,3,16401,2049,1025,1,17428,0,21525,2,9,17,23556,16400,17412,23557,20485,0,5,21508,5125,22021]

theorem envBound10352 : H12AffineFastState.Bounded env10352 := by
  intro p hp
  have h : env10352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10351_10352 : H12AffineEnvironment.transform 4 0 env10351 = env10352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10351 == env10352) = true)

theorem identity10352 : scanCanonicalize (H12AffineFastState.compose env10352 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound10352 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10353 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,9,5125,0,3,5140,2049,1025,1,4113,0,16,2,9,17,2049,5141,4097,2048,1024,0,5,1,5125,512]

theorem envBound10353 : H12AffineFastState.Bounded env10353 := by
  intro p hp
  have h : env10353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10352_10353 : H12AffineEnvironment.transform 13 5125 env10352 = env10353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env10352 == env10353) = true)

def env10354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2177218,2098513,17664,2462111,2102685,2411676,257,21792,46212,2175562]

theorem envBound10354 : H12AffineFastState.Bounded env10354 := by
  intro p hp
  have h : env10354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10328_10354 : H12AffineEnvironment.transform 21 272513 env10328 = env10354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10328 == env10354) = true)

theorem identity10354 : scanCanonicalize (H12AffineFastState.compose env10354 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound10354 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38161,262144,1025,32769,2097152,272513,2101328,21762,8328,64,2157596,2098513,17664,2377025,2102685,2411676,257,21792,46212,2156180]

theorem envBound10355 : H12AffineFastState.Bounded env10355 := by
  intro p hp
  have h : env10355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10354_10355 : H12AffineEnvironment.transform 15 54494 env10354 = env10355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env10354 == env10355) = true)

def env10356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,2097152,272393,2101328,21762,8192,64,2157596,2098513,17664,2377025,2102549,2411540,257,21792,46092,2156060]

theorem envBound10356 : H12AffineFastState.Bounded env10356 := by
  intro p hp
  have h : env10356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10355_10356 : H12AffineEnvironment.transform 6 8 env10355 = env10356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10355 == env10356) = true)

theorem identity10356 : scanCanonicalize (H12AffineFastState.compose env10356 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 314688) := by decide +kernel

theorem selectedBound10356 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env10357 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,314688,272393,318736,21762,8192,64,270684,313361,17664,34817,317525,340,257,21792,46092,273244]

theorem envBound10357 : H12AffineFastState.Bounded env10357 := by
  intro p hp
  have h : env10357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10356_10357 : H12AffineEnvironment.transform 20 314688 env10356 = env10357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314688 env10356 == env10357) = true)

theorem identity10357 : scanCanonicalize (H12AffineFastState.compose env10357 (packedSelected [0,2,3,4,5,6,8,9,10,20,23,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound10357 : packedSelected [0,2,3,4,5,6,8,9,10,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10358 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21620,34,16741,262144,1025,21621,268596,272393,264548,21762,8192,64,270684,269413,17664,23669,265249,340,257,21792,24696,273244]

theorem envBound10358 : H12AffineFastState.Bounded env10358 := by
  intro p hp
  have h : env10358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10357_10358 : H12AffineEnvironment.transform 14 21620 env10357 = env10358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env10357 == env10358) = true)

theorem identity10358 : scanCanonicalize (H12AffineFastState.compose env10358 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10358 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10359 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,372,34,5221,262144,1025,373,268596,272393,264548,2,8192,64,270684,269413,4096,2421,265249,340,257,32,13688,273244]

theorem envBound10359 : H12AffineFastState.Bounded env10359 := by
  intro p hp
  have h : env10359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10358_10359 : H12AffineEnvironment.transform 13 5376 env10358 = env10359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10358 == env10359) = true)

theorem identity10359 : scanCanonicalize (H12AffineFastState.compose env10359 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound10359 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env10360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,372,34,5221,2048,1025,373,4404,8201,356,2,8192,64,10588,5221,4096,2421,1057,340,257,32,13688,9052]

theorem envBound10360 : H12AffineFastState.Bounded env10360 := by
  intro p hp
  have h : env10360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10359_10360 : H12AffineEnvironment.transform 17 2048 env10359 = env10360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env10359 == env10360) = true)

theorem identity10360 : scanCanonicalize (H12AffineFastState.compose env10360 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10360 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env10361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,372,34,5221,2048,1025,373,4404,261,356,2,268,64,2128,5221,4096,2421,1057,340,257,32,5236,592]

theorem envBound10361 : H12AffineFastState.Bounded env10361 := by
  intro p hp
  have h : env10361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10360_10361 : H12AffineEnvironment.transform 12 268 env10360 = env10361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10360 == env10361) = true)

theorem identity10361 : scanCanonicalize (H12AffineFastState.compose env10361 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound10361 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,268,3392,372,34,3109,2048,1025,373,2420,261,356,2,268,64,2128,3109,2112,2421,1057,340,257,32,3124,592]

theorem envBound10362 : H12AffineFastState.Bounded env10362 := by
  intro p hp
  have h : env10362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10361_10362 : H12AffineEnvironment.transform 11 2112 env10361 = env10362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env10361 == env10362) = true)

theorem identity10362 : scanCanonicalize (H12AffineFastState.compose env10362 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound10362 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env10363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,356,268,1124,372,34,1281,292,1025,373,80,261,356,2,268,64,372,1281,356,81,1057,340,257,32,1296,592]

theorem envBound10363 : H12AffineFastState.Bounded env10363 := by
  intro p hp
  have h : env10363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10362_10363 : H12AffineEnvironment.transform 10 292 env10362 = env10363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env10362 == env10363) = true)

def env10364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,2097152,272392,2101328,21762,8193,64,2157596,2098513,17664,2377025,2102548,2411541,257,21792,46093,2156061]

theorem envBound10364 : H12AffineFastState.Bounded env10364 := by
  intro p hp
  have h : env10364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10355_10364 : H12AffineEnvironment.transform 6 9 env10355 = env10364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10355 == env10364) = true)

theorem identity10364 : scanCanonicalize (H12AffineFastState.compose env10364 (packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound10364 : packedSelected [1,4,5,9,12,14,19,20,24,26,28,31,38] rootPS < 2^1333 := by decide +kernel

def env10365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,25629,272392,29773,21762,8193,64,34817,24908,17664,270684,28937,305160,257,21792,46093,33280]

theorem envBound10365 : H12AffineFastState.Bounded env10365 := by
  intro p hp
  have h : env10365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10364_10365 : H12AffineEnvironment.transform 20 25629 env10364 = env10365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env10364 == env10365) = true)

theorem identity10365 : scanCanonicalize (H12AffineFastState.compose env10365 (packedSelected [1,3,5,8,19,31] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound10365 : packedSelected [1,3,5,8,19,31] rootPS < 2^1333 := by decide +kernel

def env10366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,23668,1025,32769,25629,29820,29773,21762,8193,64,34817,24908,17664,32040,28937,62588,257,21792,46093,33280]

theorem envBound10366 : H12AffineFastState.Bounded env10366 := by
  intro p hp
  have h : env10366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10365_10366 : H12AffineEnvironment.transform 17 23668 env10365 = env10366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env10365 == env10366) = true)

theorem identity10366 : scanCanonicalize (H12AffineFastState.compose env10366 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound10366 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,5392,23668,1025,0,25629,29820,29773,21762,8193,64,2048,24908,17664,32040,28937,29821,257,21792,13324,513]

theorem envBound10367 : H12AffineFastState.Bounded env10367 := by
  intro p hp
  have h : env10367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10366_10367 : H12AffineEnvironment.transform 14 1 env10366 = env10367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env10366 == env10367) = true)

theorem identity10367 : scanCanonicalize (H12AffineFastState.compose env10367 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound10367 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8202,5392,10280,1025,0,4161,32,17,8542,8193,64,2048,5392,12636,2420,1365,33,257,8572,13324,513]

theorem envBound10368 : H12AffineFastState.Bounded env10368 := by
  intro p hp
  have h : env10368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10367_10368 : H12AffineEnvironment.transform 13 13404 env10367 = env10368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env10367 == env10368) = true)

theorem identity10368 : scanCanonicalize (H12AffineFastState.compose env10368 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10368 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,1,263,5392,2341,1025,0,4161,32,17,83,268,64,2048,5392,4177,2420,1365,33,257,113,5377,513]

theorem envBound10369 : H12AffineFastState.Bounded env10369 := by
  intro p hp
  have h : env10369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10368_10369 : H12AffineEnvironment.transform 12 269 env10368 = env10369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10368 == env10369) = true)

theorem identity10369 : scanCanonicalize (H12AffineFastState.compose env10369 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound10369 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env10370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,529,4096,269,5457,1,263,5392,820,1025,0,4161,32,17,83,268,64,529,5392,4177,869,1365,33,257,113,5377,513]

theorem envBound10370 : H12AffineFastState.Bounded env10370 := by
  intro p hp
  have h : env10370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10369_10370 : H12AffineEnvironment.transform 10 529 env10369 = env10370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env10369 == env10370) = true)

theorem identity10370 : scanCanonicalize (H12AffineFastState.compose env10370 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10370 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env10371 : List Nat := [2,4,8,16,32,16,9,256,512,1024,529,4096,269,5377,1,263,5392,820,1025,0,4113,32,17,3,268,16,529,5392,4097,821,1285,33,257,33,5377,513]

theorem envBound10371 : H12AffineFastState.Bounded env10371 := by
  intro p hp
  have h : env10371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10370_10371 : H12AffineEnvironment.transform 5 16 env10370 = env10371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10370 == env10371) = true)

theorem identity10371 : scanCanonicalize (H12AffineFastState.compose env10371 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10372 : List Nat := [2,4,8,16,0,16,9,256,512,1024,529,4096,269,5377,1,263,5392,788,1025,0,4113,0,17,3,268,16,529,5392,4097,789,1285,1,257,1,5377,513]

theorem envBound10372 : H12AffineFastState.Bounded env10372 := by
  intro p hp
  have h : env10372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10371_10372 : H12AffineEnvironment.transform 4 0 env10371 = env10372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10371 == env10372) = true)

theorem identity10372 : scanCanonicalize (H12AffineFastState.compose env10372 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1307) := by decide +kernel

theorem selectedBound10372 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10373 : List Nat := [2,4,8,16,0,16,9,256,512,1024,529,1307,269,26,1,263,11,788,1025,0,1290,0,17,3,268,16,529,11,1306,789,1285,1,257,1,26,513]

theorem envBound10373 : H12AffineFastState.Bounded env10373 := by
  intro p hp
  have h : env10373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10372_10373 : H12AffineEnvironment.transform 11 1307 env10372 = env10373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1307 env10372 == env10373) = true)

theorem identity10373 : scanCanonicalize (H12AffineFastState.compose env10373 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound10373 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10374 : List Nat := [2,4,8,16,0,16,9,256,512,31,529,260,269,26,1,263,11,788,30,0,277,0,17,3,268,16,529,11,261,789,282,1,257,1,26,513]

theorem envBound10374 : H12AffineFastState.Bounded env10374 := by
  intro p hp
  have h : env10374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10373_10374 : H12AffineEnvironment.transform 9 31 env10373 = env10374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env10373 == env10374) = true)

theorem identity10374 : scanCanonicalize (H12AffineFastState.compose env10374 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 286) := by decide +kernel

theorem selectedBound10374 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10375 : List Nat := [2,4,8,16,0,16,9,256,286,31,271,260,269,26,1,263,11,10,30,0,277,0,17,3,268,16,271,11,261,11,282,1,257,1,26,287]

theorem envBound10375 : H12AffineFastState.Bounded env10375 := by
  intro p hp
  have h : env10375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10374_10375 : H12AffineEnvironment.transform 8 286 env10374 = env10375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 286 env10374 == env10375) = true)

theorem identity10375 : scanCanonicalize (H12AffineFastState.compose env10375 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10375 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10376 : List Nat := [2,4,8,16,0,16,9,5,27,31,10,1,8,26,1,2,11,10,30,0,16,0,17,3,9,16,10,11,0,11,31,1,4,1,26,26]

theorem envBound10376 : H12AffineFastState.Bounded env10376 := by
  intro p hp
  have h : env10376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10375_10376 : H12AffineEnvironment.transform 7 5 env10375 = env10376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10375 == env10376) = true)

theorem identity10376 : scanCanonicalize (H12AffineFastState.compose env10376 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound10376 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10377 : List Nat := [2,4,8,7,0,7,9,5,12,8,10,1,8,13,1,2,11,10,9,0,7,0,6,3,9,7,10,11,0,11,8,1,4,1,13,13]

theorem envBound10377 : H12AffineFastState.Bounded env10377 := by
  intro p hp
  have h : env10377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10376_10377 : H12AffineEnvironment.transform 3 7 env10376 = env10377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env10376 == env10377) = true)

theorem identity10377 : scanCanonicalize (H12AffineFastState.compose env10377 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound10377 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env10378 : List Nat := [2,4,4,7,0,7,5,5,0,4,6,1,4,1,1,2,7,6,5,0,7,0,6,3,5,7,6,7,0,7,4,1,4,1,1,1]

theorem envBound10378 : H12AffineFastState.Bounded env10378 := by
  intro p hp
  have h : env10378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10377_10378 : H12AffineEnvironment.transform 2 4 env10377 = env10378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env10377 == env10378) = true)

theorem identity10378 : scanCanonicalize (H12AffineFastState.compose env10378 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10378 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10379 : List Nat := [0,4,4,5,0,5,5,5,0,4,4,1,4,1,1,0,5,4,5,0,5,0,4,1,5,5,4,5,0,5,4,1,4,1,1,1]

theorem envBound10379 : H12AffineFastState.Bounded env10379 := by
  intro p hp
  have h : env10379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10378_10379 : H12AffineEnvironment.transform 0 0 env10378 = env10379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10378 == env10379) = true)

def env10380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6623299,2098512,17665,2462110,2102685,6349852,257,21792,46212,2175562]

theorem envBound10380 : H12AffineFastState.Bounded env10380 := by
  intro p hp
  have h : env10380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10327_10380 : H12AffineEnvironment.transform 22 2101329 env10327 = env10380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env10327 == env10380) = true)

def env10381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2177219,2098512,17665,2462110,2102685,2411676,257,21792,46212,2175562]

theorem envBound10381 : H12AffineFastState.Bounded env10381 := by
  intro p hp
  have h : env10381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10380_10381 : H12AffineEnvironment.transform 21 272512 env10380 = env10381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10380 == env10381) = true)

theorem identity10381 : scanCanonicalize (H12AffineFastState.compose env10381 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound10381 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,77899,272512,73754,98781,8328,64,2184,79131,17665,303573,75222,392407,257,21792,46212,513]

theorem envBound10382 : H12AffineFastState.Bounded env10382 := by
  intro p hp
  have h : env10382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10381_10382 : H12AffineEnvironment.transform 20 77899 env10381 = env10382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env10381 == env10382) = true)

def env10383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77899,272392,73754,98645,8192,64,2048,79131,17665,303453,75102,392287,257,21792,46092,513]

theorem envBound10383 : H12AffineFastState.Bounded env10383 := by
  intro p hp
  have h : env10383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10382_10383 : H12AffineEnvironment.transform 6 8 env10382 = env10383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10382 == env10383) = true)

theorem identity10383 : scanCanonicalize (H12AffineFastState.compose env10383 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10383 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,262144,1025,32769,69910,264533,65863,98645,349,64,2048,70726,17665,294912,66563,384258,257,21792,38225,513]

theorem envBound10384 : H12AffineFastState.Bounded env10384 := by
  intro p hp
  have h : env10384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10383_10384 : H12AffineEnvironment.transform 12 349 env10383 = env10384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10383 == env10384) = true)

theorem identity10384 : scanCanonicalize (H12AffineFastState.compose env10384 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound10384 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env10385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,35189,1025,32769,69910,32800,65863,98645,349,64,2048,70726,17665,2421,66563,87159,257,21792,38225,513]

theorem envBound10385 : H12AffineFastState.Bounded env10385 := by
  intro p hp
  have h : env10385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10384_10385 : H12AffineEnvironment.transform 17 35189 env10384 = env10385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env10384 == env10385) = true)

theorem identity10385 : scanCanonicalize (H12AffineFastState.compose env10385 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10385 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,65536,70726,35189,1025,32769,69910,32800,65863,98645,349,64,2048,70726,4096,2421,66563,65910,257,33,38225,513]

theorem envBound10386 : H12AffineFastState.Bounded env10386 := by
  intro p hp
  have h : env10386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10385_10386 : H12AffineEnvironment.transform 13 5377 env10385 = env10386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10385 == env10386) = true)

theorem identity10386 : scanCanonicalize (H12AffineFastState.compose env10386 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10386 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1296,65536,70726,3173,1025,1297,69910,1328,65863,66629,349,64,2048,70726,4096,2421,66563,65910,257,33,4161,513]

theorem envBound10387 : H12AffineFastState.Bounded env10387 := by
  intro p hp
  have h : env10387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10386_10387 : H12AffineEnvironment.transform 14 1296 env10386 = env10387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env10386 == env10387) = true)

theorem identity10387 : scanCanonicalize (H12AffineFastState.compose env10387 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10387 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env10388 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1125,65536,70726,3173,1025,1124,69731,1093,65586,66629,40,64,2048,70726,4096,2048,66563,65539,116,33,4161,513]

theorem envBound10388 : H12AffineFastState.Bounded env10388 := by
  intro p hp
  have h : env10388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10387_10388 : H12AffineEnvironment.transform 7 117 env10387 = env10388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10387 == env10388) = true)

theorem identity10388 : scanCanonicalize (H12AffineFastState.compose env10388 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound10388 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env10389 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1125,1095,4097,3173,1025,1124,5156,1093,1141,2,40,64,2048,4097,4096,2048,68,1092,116,33,4161,513]

theorem envBound10389 : H12AffineFastState.Bounded env10389 := by
  intro p hp
  have h : env10389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10388_10389 : H12AffineEnvironment.transform 15 1095 env10388 = env10389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env10388 == env10389) = true)

theorem identity10389 : scanCanonicalize (H12AffineFastState.compose env10389 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound10389 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10390 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,40,4112,1,35,4097,2049,101,0,4160,33,17,2,40,64,2048,4097,4096,2048,68,32,116,33,4161,513]

theorem envBound10390 : H12AffineFastState.Bounded env10390 := by
  intro p hp
  have h : env10390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10389_10390 : H12AffineEnvironment.transform 9 100 env10389 = env10390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env10389 == env10390) = true)

theorem identity10390 : scanCanonicalize (H12AffineFastState.compose env10390 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound10390 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10391 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,48,40,32,1,35,49,2049,101,0,112,33,17,2,40,64,2048,49,48,2048,68,32,116,33,113,513]

theorem envBound10391 : H12AffineFastState.Bounded env10391 := by
  intro p hp
  have h : env10391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10390_10391 : H12AffineEnvironment.transform 11 48 env10390 = env10391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env10390 == env10391) = true)

theorem identity10391 : scanCanonicalize (H12AffineFastState.compose env10391 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10391 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10392 : List Nat := [2,4,8,16,0,64,8,85,512,68,2048,16,8,0,1,3,17,2049,69,0,80,1,17,2,8,64,2048,17,16,2048,68,0,84,1,81,513]

theorem envBound10392 : H12AffineFastState.Bounded env10392 := by
  intro p hp
  have h : env10392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10391_10392 : H12AffineEnvironment.transform 4 0 env10391 = env10392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10391 == env10392) = true)

theorem identity10392 : scanCanonicalize (H12AffineFastState.compose env10392 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound10392 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10393 : List Nat := [2,4,8,16,0,64,8,85,512,68,592,16,8,0,1,3,17,593,69,0,80,1,17,2,8,64,592,17,16,592,68,0,84,1,81,513]

theorem envBound10393 : H12AffineFastState.Bounded env10393 := by
  intro p hp
  have h : env10393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10392_10393 : H12AffineEnvironment.transform 10 592 env10392 = env10393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env10392 == env10393) = true)

theorem identity10393 : scanCanonicalize (H12AffineFastState.compose env10393 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10393 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10394 : List Nat := [2,4,8,16,0,17,8,4,512,21,513,16,8,0,1,3,17,512,20,0,1,1,17,2,8,17,513,17,16,513,21,0,5,1,0,513]

theorem envBound10394 : H12AffineFastState.Bounded env10394 := by
  intro p hp
  have h : env10394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10393_10394 : H12AffineEnvironment.transform 5 17 env10393 = env10394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10393 == env10394) = true)

theorem identity10394 : scanCanonicalize (H12AffineFastState.compose env10394 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound10394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10395 : List Nat := [2,4,8,16,0,17,8,4,11,21,10,16,8,0,1,3,17,11,20,0,1,1,17,2,8,17,10,17,16,10,21,0,5,1,0,10]

theorem envBound10395 : H12AffineFastState.Bounded env10395 := by
  intro p hp
  have h : env10395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10394_10395 : H12AffineEnvironment.transform 8 11 env10394 = env10395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env10394 == env10395) = true)

theorem identity10395 : scanCanonicalize (H12AffineFastState.compose env10395 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10395 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10396 : List Nat := [2,4,8,11,0,10,8,4,11,14,10,11,8,0,1,3,10,11,15,0,1,1,10,2,8,10,10,10,11,10,14,0,5,1,0,10]

theorem envBound10396 : H12AffineFastState.Bounded env10396 := by
  intro p hp
  have h : env10396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10395_10396 : H12AffineEnvironment.transform 3 11 env10395 = env10396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10395 == env10396) = true)

theorem identity10396 : scanCanonicalize (H12AffineFastState.compose env10396 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10396 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10397 : List Nat := [2,4,2,1,0,0,2,4,1,4,0,1,2,0,1,3,0,1,5,0,1,1,0,2,2,0,0,0,1,0,4,0,5,1,0,0]

theorem envBound10397 : H12AffineFastState.Bounded env10397 := by
  intro p hp
  have h : env10397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10396_10397 : H12AffineEnvironment.transform 2 2 env10396 = env10397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10396 == env10397) = true)

def env10398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272393,73754,98644,8193,64,2049,79131,17665,303452,75103,392286,257,21792,46093,513]

theorem envBound10398 : H12AffineFastState.Bounded env10398 := by
  intro p hp
  have h : env10398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10382_10398 : H12AffineEnvironment.transform 6 9 env10382 = env10398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10382 == env10398) = true)

theorem identity10398 : scanCanonicalize (H12AffineFastState.compose env10398 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound10398 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env10399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67619,1025,32769,77899,73770,73754,98644,8193,64,2049,79131,17665,108927,75103,62589,257,21792,46093,513]

theorem envBound10399 : H12AffineFastState.Bounded env10399 := by
  intro p hp
  have h : env10399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10398_10399 : H12AffineEnvironment.transform 17 67619 env10398 = env10399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env10398 == env10399) = true)

theorem identity10399 : scanCanonicalize (H12AffineFastState.compose env10399 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10399 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env10400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,65536,82246,67619,1025,8460,77899,73770,73754,73817,8193,64,2049,79131,17665,67698,75103,21872,257,21792,5376,513]

theorem envBound10400 : H12AffineFastState.Bounded env10400 := by
  intro p hp
  have h : env10400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10399_10400 : H12AffineEnvironment.transform 14 8461 env10399 = env10400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env10399 == env10400) = true)

theorem identity10400 : scanCanonicalize (H12AffineFastState.compose env10400 (packedSelected [0,1,2,4,5,6,7,8,9,14,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound10400 : packedSelected [0,1,2,4,5,6,7,8,9,14,18,23,24] rootPS < 2^1333 := by decide +kernel

def env10401 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8461,65536,79179,67619,1025,8460,77899,73770,73754,73817,8193,64,2049,79131,12556,67698,75103,8573,257,8493,5376,513]

theorem envBound10401 : H12AffineFastState.Bounded env10401 := by
  intro p hp
  have h : env10401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10400_10401 : H12AffineEnvironment.transform 13 13325 env10400 = env10401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env10400 == env10401) = true)

theorem identity10401 : scanCanonicalize (H12AffineFastState.compose env10401 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound10401 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env10402 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8461,262,13389,2341,1025,8460,12621,8492,8476,8543,8193,64,2049,13341,12556,2420,9305,8573,257,8493,5376,513]

theorem envBound10402 : H12AffineFastState.Bounded env10402 := by
  intro p hp
  have h : env10402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10401_10402 : H12AffineEnvironment.transform 15 262 env10401 = env10402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env10401 == env10402) = true)

theorem identity10402 : scanCanonicalize (H12AffineFastState.compose env10402 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10402 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10403 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8461,262,13341,2341,1025,8460,12573,8492,8476,8463,8193,16,2049,13341,12556,2340,9225,8493,257,8493,5376,513]

theorem envBound10403 : H12AffineFastState.Bounded env10403 := by
  intro p hp
  have h : env10403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10402_10403 : H12AffineEnvironment.transform 5 16 env10402 = env10403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10402 == env10403) = true)

theorem identity10403 : scanCanonicalize (H12AffineFastState.compose env10403 (packedSelected [1,2,3,4,5,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound10403 : packedSelected [1,2,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env10404 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,8192,10280,8461,262,10296,2341,1025,8460,11576,8492,8476,8463,8193,16,2049,10296,11561,2340,9225,8493,257,8493,2341,513]

theorem envBound10404 : H12AffineFastState.Bounded env10404 := by
  intro p hp
  have h : env10404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10403_10404 : H12AffineEnvironment.transform 11 3109 env10403 = env10404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env10403 == env10404) = true)

theorem identity10404 : scanCanonicalize (H12AffineFastState.compose env10404 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound10404 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env10405 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,1052,3124,1297,262,3108,2341,1025,1296,2340,1328,1280,1299,1053,16,2049,3108,2357,2340,21,1329,257,1329,2341,513]

theorem envBound10405 : H12AffineFastState.Bounded env10405 := by
  intro p hp
  have h : env10405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10404_10405 : H12AffineEnvironment.transform 12 1052 env10404 = env10405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env10404 == env10405) = true)

theorem identity10405 : scanCanonicalize (H12AffineFastState.compose env10405 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound10405 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env10406 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2356,269,2341,0,262,2357,2341,272,1,2340,33,17,2,268,16,2049,2357,2357,2340,21,32,257,32,2341,513]

theorem envBound10406 : H12AffineFastState.Bounded env10406 := by
  intro p hp
  have h : env10406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10405_10406 : H12AffineEnvironment.transform 9 273 env10405 = env10406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env10405 == env10406) = true)

theorem identity10406 : scanCanonicalize (H12AffineFastState.compose env10406 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound10406 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10407 : List Nat := [2,4,8,16,16,16,9,256,512,273,2048,2308,269,2325,0,262,2309,2325,272,1,2324,17,17,2,268,16,2049,2309,2309,2324,21,16,257,16,2325,513]

theorem envBound10407 : H12AffineFastState.Bounded env10407 := by
  intro p hp
  have h : env10407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10406_10407 : H12AffineEnvironment.transform 4 16 env10406 = env10407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env10406 == env10407) = true)

theorem identity10407 : scanCanonicalize (H12AffineFastState.compose env10407 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound10407 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10408 : List Nat := [2,4,8,16,16,16,9,256,512,273,11,271,269,286,0,262,270,286,272,1,287,17,17,2,268,16,10,270,270,287,21,16,257,16,286,513]

theorem envBound10408 : H12AffineFastState.Bounded env10408 := by
  intro p hp
  have h : env10408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10407_10408 : H12AffineEnvironment.transform 10 11 env10407 = env10408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env10407 == env10408) = true)

theorem identity10408 : scanCanonicalize (H12AffineFastState.compose env10408 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound10408 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10409 : List Nat := [2,4,8,16,16,16,9,256,260,273,11,271,269,286,0,262,270,286,272,1,287,17,17,2,268,16,10,270,270,287,21,16,257,16,286,261]

theorem envBound10409 : H12AffineFastState.Bounded env10409 := by
  intro p hp
  have h : env10409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10408_10409 : H12AffineEnvironment.transform 8 260 env10408 = env10409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env10408 == env10409) = true)

theorem identity10409 : scanCanonicalize (H12AffineFastState.compose env10409 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound10409 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10410 : List Nat := [2,4,8,16,16,16,9,15,11,30,11,0,2,17,0,9,1,17,31,1,16,17,17,2,3,16,10,1,1,16,21,16,14,16,17,10]

theorem envBound10410 : H12AffineFastState.Bounded env10410 := by
  intro p hp
  have h : env10410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10409_10410 : H12AffineEnvironment.transform 7 15 env10409 = env10410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env10409 == env10410) = true)

theorem identity10410 : scanCanonicalize (H12AffineFastState.compose env10410 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound10410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10411 : List Nat := [2,4,8,4,4,4,9,15,11,10,11,0,2,5,0,9,1,5,11,1,4,5,5,2,3,4,10,1,1,4,1,4,14,4,5,10]

theorem envBound10411 : H12AffineFastState.Bounded env10411 := by
  intro p hp
  have h : env10411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10410_10411 : H12AffineEnvironment.transform 3 4 env10410 = env10411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env10410 == env10411) = true)

theorem identity10411 : scanCanonicalize (H12AffineFastState.compose env10411 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10411 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10412 : List Nat := [2,4,3,4,4,4,2,4,0,1,0,0,2,5,0,2,1,5,0,1,4,5,5,2,3,4,1,1,1,4,1,4,5,4,5,1]

theorem envBound10412 : H12AffineFastState.Bounded env10412 := by
  intro p hp
  have h : env10412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10411_10412 : H12AffineEnvironment.transform 2 3 env10411 = env10412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10411 == env10412) = true)

theorem identity10412 : scanCanonicalize (H12AffineFastState.compose env10412 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10412 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10413 : List Nat := [0,4,1,4,4,4,0,4,0,1,0,0,0,5,0,0,1,5,0,1,4,5,5,0,1,4,1,1,1,4,1,4,5,4,5,1]

theorem envBound10413 : H12AffineFastState.Bounded env10413 := by
  intro p hp
  have h : env10413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10412_10413 : H12AffineEnvironment.transform 0 0 env10412 = env10413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10412 == env10413) = true)

def env10414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2177218,2098512,17665,2462110,2102685,2411677,257,21792,46212,2175562]

theorem envBound10414 : H12AffineFastState.Bounded env10414 := by
  intro p hp
  have h : env10414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10380_10414 : H12AffineEnvironment.transform 21 272513 env10380 = env10414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10380 == env10414) = true)

theorem identity10414 : scanCanonicalize (H12AffineFastState.compose env10414 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10414 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,262144,1025,32769,2097152,272513,2101329,41430,8328,64,2103497,2098512,17665,2404757,2102685,2411677,257,21792,46212,2101825]

theorem envBound10415 : H12AffineFastState.Bounded env10415 := by
  intro p hp
  have h : env10415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10414_10415 : H12AffineEnvironment.transform 15 8203 env10414 = env10415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10414 == env10415) = true)

theorem identity10415 : scanCanonicalize (H12AffineFastState.compose env10415 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10415 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env10416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25028,262144,1025,8541,2097152,272513,2101329,138,8328,64,2103497,2098512,17665,2363593,2102685,2387393,257,21792,5592,2101825]

theorem envBound10416 : H12AffineFastState.Bounded env10416 := by
  intro p hp
  have h : env10416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10415_10416 : H12AffineEnvironment.transform 14 8540 env10415 = env10416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10415 == env10416) = true)

theorem identity10416 : scanCanonicalize (H12AffineFastState.compose env10416 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10416 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env10417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24909,262144,1025,8541,2097152,272392,2101329,3,8193,64,2103360,2098512,17665,2363456,2102548,2387272,257,21792,5457,2101825]

theorem envBound10417 : H12AffineFastState.Bounded env10417 := by
  intro p hp
  have h : env10417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10416_10417 : H12AffineEnvironment.transform 6 9 env10416 = env10417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10416 == env10417) = true)

theorem identity10417 : scanCanonicalize (H12AffineFastState.compose env10417 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10588) := by decide +kernel

theorem selectedBound10417 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env10418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24909,10588,1025,8541,2097152,340,2101329,3,8193,64,2103360,2098512,17665,2111772,2102548,2114580,257,21792,5457,2101825]

theorem envBound10418 : H12AffineFastState.Bounded env10418 := by
  intro p hp
  have h : env10418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10417_10418 : H12AffineEnvironment.transform 17 10588 env10417 = env10418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10588 env10417 == env10418) = true)

theorem identity10418 : scanCanonicalize (H12AffineFastState.compose env10418 (packedSelected [1,4,5,6,8,14,17,20,22,24] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10418 : packedSelected [1,4,5,6,8,14,17,20,22,24] rootPS < 2^1333 := by decide +kernel

def env10419 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,8203,24633,10280,1025,8233,2097152,32,2101329,3,8193,64,2103360,2098212,17525,2111592,2102368,2114580,117,21588,5157,2101825]

theorem envBound10419 : H12AffineFastState.Bounded env10419 := by
  intro p hp
  have h : env10419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10418_10419 : H12AffineEnvironment.transform 7 116 env10418 = env10419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10418 == env10419) = true)

theorem identity10419 : scanCanonicalize (H12AffineFastState.compose env10419 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound10419 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10420 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8232,8203,24633,10280,1025,8233,4160,32,17,3,8193,64,2048,5220,17525,10280,1056,21588,117,21588,5157,513]

theorem envBound10420 : H12AffineFastState.Bounded env10420 := by
  intro p hp
  have h : env10420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10419_10420 : H12AffineEnvironment.transform 20 4160 env10419 = env10420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10419 == env10420) = true)

theorem identity10420 : scanCanonicalize (H12AffineFastState.compose env10420 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound10420 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env10421 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,81,114,16448,2129,1025,80,4160,32,17,3,120,64,2048,5220,17525,2129,1056,21588,117,21588,5157,513]

theorem envBound10421 : H12AffineFastState.Bounded env10421 := by
  intro p hp
  have h : env10421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10420_10421 : H12AffineEnvironment.transform 12 121 env10420 = env10421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env10420 == env10421) = true)

theorem identity10421 : scanCanonicalize (H12AffineFastState.compose env10421 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 7205) := by decide +kernel

theorem selectedBound10421 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env10422 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,7205,81,114,7269,2129,1025,80,4160,32,17,3,120,64,2048,5220,6224,2129,1056,2161,117,2161,5157,513]

theorem envBound10422 : H12AffineFastState.Bounded env10422 := by
  intro p hp
  have h : env10422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10421_10422 : H12AffineEnvironment.transform 13 7205 env10421 = env10422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7205 env10421 == env10422) = true)

theorem identity10422 : scanCanonicalize (H12AffineFastState.compose env10422 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound10422 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10423 : List Nat := [2,4,8,16,32,64,9,116,512,1024,80,4096,121,5237,81,114,5173,1,1025,80,4160,32,17,3,120,64,80,5220,4096,1,1056,33,117,33,5157,513]

theorem envBound10423 : H12AffineFastState.Bounded env10423 := by
  intro p hp
  have h : env10423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10422_10423 : H12AffineEnvironment.transform 10 80 env10422 = env10423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env10422 == env10423) = true)

theorem identity10423 : scanCanonicalize (H12AffineFastState.compose env10423 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound10423 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env10424 : List Nat := [2,4,8,16,32,64,9,116,512,1024,80,64,121,1077,81,114,1141,1,1025,80,0,32,17,3,120,64,80,1060,64,1,1056,33,117,33,1125,513]

theorem envBound10424 : H12AffineFastState.Bounded env10424 := by
  intro p hp
  have h : env10424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10423_10424 : H12AffineEnvironment.transform 11 64 env10423 = env10424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env10423 == env10424) = true)

theorem identity10424 : scanCanonicalize (H12AffineFastState.compose env10424 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10424 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env10425 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1,17,40,1077,0,35,1060,1,1025,1,0,32,17,3,41,17,1,1060,17,1,1056,33,36,33,1076,513]

theorem envBound10425 : H12AffineFastState.Bounded env10425 := by
  intro p hp
  have h : env10425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10424_10425 : H12AffineEnvironment.transform 5 17 env10424 = env10425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10424 == env10425) = true)

theorem identity10425 : scanCanonicalize (H12AffineFastState.compose env10425 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10425 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10426 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,17,40,0,0,35,17,1,52,1,0,32,17,3,41,17,1,17,17,1,21,33,36,33,1,513]

theorem envBound10426 : H12AffineFastState.Bounded env10426 := by
  intro p hp
  have h : env10426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10425_10426 : H12AffineEnvironment.transform 9 53 env10425 = env10426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10425 == env10426) = true)

theorem identity10426 : scanCanonicalize (H12AffineFastState.compose env10426 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound10426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10427 : List Nat := [2,4,8,16,32,17,9,37,33,53,1,17,40,0,0,35,17,1,52,1,0,32,17,3,41,17,1,17,17,1,21,33,36,33,1,32]

theorem envBound10427 : H12AffineFastState.Bounded env10427 := by
  intro p hp
  have h : env10427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10426_10427 : H12AffineEnvironment.transform 8 33 env10426 = env10427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env10426 == env10427) = true)

def env10428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6623298,8393984,10507600,8749519,2102684,12645452,257,21793,46213,2175563]

theorem envBound10428 : H12AffineFastState.Bounded env10428 := by
  intro p hp
  have h : env10428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10326_10428 : H12AffineEnvironment.transform 23 10588557 env10326 = env10428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env10326 == env10428) = true)

def env10429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6623298,2098512,17664,2462111,2102684,6349852,257,21793,46213,2175563]

theorem envBound10429 : H12AffineFastState.Bounded env10429 := by
  intro p hp
  have h : env10429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10428_10429 : H12AffineEnvironment.transform 22 2101328 env10428 = env10429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env10428 == env10429) = true)

def env10430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2177218,2098512,17664,2462111,2102684,2411676,257,21793,46213,2175563]

theorem envBound10430 : H12AffineFastState.Bounded env10430 := by
  intro p hp
  have h : env10430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10429_10430 : H12AffineEnvironment.transform 21 272512 env10429 = env10430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10429 == env10430) = true)

def env10431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,2097152,272392,2101328,98645,8192,64,2177098,2098512,17664,2461975,2102548,2411540,257,21793,46093,2175563]

theorem envBound10431 : H12AffineFastState.Bounded env10431 := by
  intro p hp
  have h : env10431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10430_10431 : H12AffineEnvironment.transform 6 8 env10430 = env10431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10430 == env10431) = true)

theorem identity10431 : scanCanonicalize (H12AffineFastState.compose env10431 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound10431 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env10432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16400,262144,1025,32769,2097152,272392,2101328,32770,8192,64,2111773,2098512,17664,2396224,2102548,2411540,257,21793,46093,2110236]

theorem envBound10432 : H12AffineFastState.Bounded env10432 := by
  intro p hp
  have h : env10432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10431_10432 : H12AffineEnvironment.transform 15 343 env10431 = env10432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env10431 == env10432) = true)

theorem identity10432 : scanCanonicalize (H12AffineFastState.compose env10432 (packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10432 : packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16400,10280,1025,32769,2097152,32,2101328,32770,8192,64,2111773,2098512,17664,2144360,2102548,2155580,257,21793,46093,2110236]

theorem envBound10433 : H12AffineFastState.Bounded env10433 := by
  intro p hp
  have h : env10433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10432_10433 : H12AffineEnvironment.transform 17 10280 env10432 = env10433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10432 == env10433) = true)

theorem identity10433 : scanCanonicalize (H12AffineFastState.compose env10433 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,343,16400,10280,1025,1,2097152,32,2101328,2,8192,64,2111773,2098512,17664,2111592,2102548,2122812,257,21793,13325,2110236]

theorem envBound10434 : H12AffineFastState.Bounded env10434 := by
  intro p hp
  have h : env10434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10433_10434 : H12AffineEnvironment.transform 14 0 env10433 = env10434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10433 == env10434) = true)

theorem identity10434 : scanCanonicalize (H12AffineFastState.compose env10434 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10434 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env10435 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,0,115,16400,10280,1025,1,2097152,32,2101328,2,8192,64,2111545,2098292,17444,2111592,2102320,2122812,37,21509,13325,2110008]

theorem envBound10435 : H12AffineFastState.Bounded env10435 := by
  intro p hp
  have h : env10435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10434_10435 : H12AffineEnvironment.transform 7 36 env10434 = env10435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10434 == env10435) = true)

theorem identity10435 : scanCanonicalize (H12AffineFastState.compose env10435 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound10435 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env10436 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,0,115,16400,2129,1025,1,2097152,32,2101328,2,121,64,2103360,2098292,17444,2103313,2102320,2114629,37,21509,5236,2101825]

theorem envBound10436 : H12AffineFastState.Bounded env10436 := by
  intro p hp
  have h : env10436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10435_10436 : H12AffineEnvironment.transform 12 121 env10435 = env10436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env10435 == env10436) = true)

theorem identity10436 : scanCanonicalize (H12AffineFastState.compose env10436 (packedSelected [2,4,6,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound10436 : packedSelected [2,4,6,9,14] rootPS < 2^1333 := by decide +kernel

def env10437 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5156,0,115,5172,2129,1025,1,2097152,32,2101328,2,121,64,2103360,2098292,4096,2103313,2102320,2101345,37,33,5236,2101825]

theorem envBound10437 : H12AffineFastState.Bounded env10437 := by
  intro p hp
  have h : env10437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10436_10437 : H12AffineEnvironment.transform 13 5156 env10436 = env10437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env10436 == env10437) = true)

theorem identity10437 : scanCanonicalize (H12AffineFastState.compose env10437 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound10437 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env10438 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5156,0,115,5172,2129,1025,1,4160,32,16,2,121,64,2048,5172,4096,2129,1136,33,37,33,5236,513]

theorem envBound10438 : H12AffineFastState.Bounded env10438 := by
  intro p hp
  have h : env10438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10437_10438 : H12AffineEnvironment.transform 20 4160 env10437 = env10438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10437 == env10438) = true)

theorem identity10438 : scanCanonicalize (H12AffineFastState.compose env10438 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10438 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10439 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,121,4112,0,115,4096,2129,53,1,4160,32,16,2,121,64,2048,4096,4096,2129,68,33,37,33,4160,513]

theorem envBound10439 : H12AffineFastState.Bounded env10439 := by
  intro p hp
  have h : env10439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10438_10439 : H12AffineEnvironment.transform 9 52 env10438 = env10439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10438 == env10439) = true)

theorem identity10439 : scanCanonicalize (H12AffineFastState.compose env10439 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10440 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,40,4112,0,34,4096,2048,53,1,4113,32,16,2,40,17,2048,4096,4096,2048,21,33,37,33,4113,513]

theorem envBound10440 : H12AffineFastState.Bounded env10440 := by
  intro p hp
  have h : env10440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10439_10440 : H12AffineEnvironment.transform 5 17 env10439 = env10440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10439 == env10440) = true)

theorem identity10440 : scanCanonicalize (H12AffineFastState.compose env10440 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10441 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,4096,40,4112,0,34,4096,0,53,1,4113,32,16,2,40,17,0,4096,4096,0,21,33,37,33,4113,513]

theorem envBound10441 : H12AffineFastState.Bounded env10441 := by
  intro p hp
  have h : env10441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10440_10441 : H12AffineEnvironment.transform 10 0 env10440 = env10441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10440 == env10441) = true)

theorem identity10441 : scanCanonicalize (H12AffineFastState.compose env10441 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 523) := by decide +kernel

theorem selectedBound10441 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10442 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,523,40,539,0,34,523,0,53,1,538,32,16,2,40,17,0,523,523,0,21,33,37,33,538,513]

theorem envBound10442 : H12AffineFastState.Bounded env10442 := by
  intro p hp
  have h : env10442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10441_10442 : H12AffineEnvironment.transform 11 523 env10441 = env10442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 523 env10441 == env10442) = true)

theorem identity10442 : scanCanonicalize (H12AffineFastState.compose env10442 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound10442 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10443 : List Nat := [2,4,8,16,32,17,8,36,27,52,0,16,40,0,0,34,16,0,53,1,1,32,16,2,40,17,0,16,16,0,21,33,37,33,1,26]

theorem envBound10443 : H12AffineFastState.Bounded env10443 := by
  intro p hp
  have h : env10443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10442_10443 : H12AffineEnvironment.transform 8 27 env10442 = env10443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env10442 == env10443) = true)

def env10444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272393,2101328,98644,8193,64,2177099,2098512,17664,2461974,2102549,2411541,257,21793,46092,2175563]

theorem envBound10444 : H12AffineFastState.Bounded env10444 := by
  intro p hp
  have h : env10444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10430_10444 : H12AffineEnvironment.transform 6 9 env10430 = env10444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10430 == env10444) = true)

theorem identity10444 : scanCanonicalize (H12AffineFastState.compose env10444 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound10444 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env10445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77898,272393,73754,98644,8193,64,2049,79130,17664,303452,75103,392287,257,21793,46092,513]

theorem envBound10445 : H12AffineFastState.Bounded env10445 := by
  intro p hp
  have h : env10445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10444_10445 : H12AffineEnvironment.transform 20 77898 env10444 = env10445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env10444 == env10445) = true)

theorem identity10445 : scanCanonicalize (H12AffineFastState.compose env10445 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound10445 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env10446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67619,1025,32769,77898,73770,73754,98644,8193,64,2049,79130,17664,108927,75103,62588,257,21793,46092,513]

theorem envBound10446 : H12AffineFastState.Bounded env10446 := by
  intro p hp
  have h : env10446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10445_10446 : H12AffineEnvironment.transform 17 67619 env10445 = env10446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env10445 == env10446) = true)

theorem identity10446 : scanCanonicalize (H12AffineFastState.compose env10446 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound10446 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env10447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33030,49216,35109,1025,32769,45388,41260,41244,82,8193,64,2049,46108,17664,10361,42073,62588,257,21793,46092,513]

theorem envBound10447 : H12AffineFastState.Bounded env10447 := by
  intro p hp
  have h : env10447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10446_10447 : H12AffineEnvironment.transform 15 33030 env10446 = env10447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env10446 == env10447) = true)

theorem identity10447 : scanCanonicalize (H12AffineFastState.compose env10447 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound10447 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21511,5441,23588,1025,21760,25677,29741,29725,82,8193,64,2049,24861,17664,10361,29016,8573,257,21793,24845,513]

theorem envBound10448 : H12AffineFastState.Bounded env10448 := by
  intro p hp
  have h : env10448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10447_10448 : H12AffineEnvironment.transform 14 21761 env10447 = env10448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env10447 == env10448) = true)

theorem identity10448 : scanCanonicalize (H12AffineFastState.compose env10448 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10448 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env10449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,21511,5441,23588,1025,21760,17681,21873,21825,82,349,64,2049,16449,17664,2341,20484,33,257,21793,16465,513]

theorem envBound10449 : H12AffineFastState.Bounded env10449 := by
  intro p hp
  have h : env10449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10448_10449 : H12AffineEnvironment.transform 12 348 env10448 = env10449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10448 == env10449) = true)

theorem identity10449 : scanCanonicalize (H12AffineFastState.compose env10449 (packedSelected [0,1,2,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound10449 : packedSelected [0,1,2,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env10450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1060,348,16384,16677,16419,357,18432,1025,16676,17681,16725,16741,82,349,64,2049,16449,17664,2341,17440,33,257,16645,16465,513]

theorem envBound10450 : H12AffineFastState.Bounded env10450 := by
  intro p hp
  have h : env10450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10449_10450 : H12AffineEnvironment.transform 11 1060 env10449 = env10450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env10449 == env10450) = true)

theorem identity10450 : scanCanonicalize (H12AffineFastState.compose env10450 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10450 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10451 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1060,40,16384,16465,16419,17,18432,1025,16464,17509,16417,16401,82,41,64,2049,16449,17524,2129,17440,33,117,16497,16465,513]

theorem envBound10451 : H12AffineFastState.Bounded env10451 := by
  intro p hp
  have h : env10451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10450_10451 : H12AffineEnvironment.transform 7 116 env10450 = env10451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10450 == env10451) = true)

theorem identity10451 : scanCanonicalize (H12AffineFastState.compose env10451 (packedSelected [1,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound10451 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env10452 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1060,40,80,1,115,17,2128,1025,0,1077,113,65,82,41,64,2049,17,1060,2129,1136,33,117,33,1,513]

theorem envBound10452 : H12AffineFastState.Bounded env10452 := by
  intro p hp
  have h : env10452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10451_10452 : H12AffineEnvironment.transform 13 80 env10451 = env10452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env10451 == env10452) = true)

theorem identity10452 : scanCanonicalize (H12AffineFastState.compose env10452 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10452 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10453 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,1060,40,1,1,34,17,2049,1025,0,1077,32,16,3,41,17,2049,17,1060,2048,1057,33,36,33,1,513]

theorem envBound10453 : H12AffineFastState.Bounded env10453 := by
  intro p hp
  have h : env10453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10452_10453 : H12AffineEnvironment.transform 5 17 env10452 = env10453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10452 == env10453) = true)

theorem identity10453 : scanCanonicalize (H12AffineFastState.compose env10453 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10453 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10454 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,17,40,1,1,34,17,2049,52,0,0,32,16,3,41,17,2049,17,17,2048,20,33,36,33,1,513]

theorem envBound10454 : H12AffineFastState.Bounded env10454 := by
  intro p hp
  have h : env10454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10453_10454 : H12AffineEnvironment.transform 9 53 env10453 = env10454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10453 == env10454) = true)

theorem identity10454 : scanCanonicalize (H12AffineFastState.compose env10454 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound10454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10455 : List Nat := [2,4,8,16,32,17,9,37,512,53,513,17,40,1,1,34,17,512,52,0,0,32,16,3,41,17,512,17,17,513,20,33,36,33,1,513]

theorem envBound10455 : H12AffineFastState.Bounded env10455 := by
  intro p hp
  have h : env10455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10454_10455 : H12AffineEnvironment.transform 10 513 env10454 = env10455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env10454 == env10455) = true)

theorem identity10455 : scanCanonicalize (H12AffineFastState.compose env10455 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound10455 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10456 : List Nat := [2,4,8,16,32,17,9,37,59,53,58,17,40,1,1,34,17,59,52,0,0,32,16,3,41,17,59,17,17,58,20,33,36,33,1,58]

theorem envBound10456 : H12AffineFastState.Bounded env10456 := by
  intro p hp
  have h : env10456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10455_10456 : H12AffineEnvironment.transform 8 59 env10455 = env10456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env10455 == env10456) = true)

theorem identity10456 : scanCanonicalize (H12AffineFastState.compose env10456 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound10456 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10457 : List Nat := [2,4,8,16,26,17,9,31,1,15,0,17,18,1,1,24,17,1,14,0,0,26,16,3,19,17,1,17,17,0,20,27,30,27,1,0]

theorem envBound10457 : H12AffineFastState.Bounded env10457 := by
  intro p hp
  have h : env10457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10456_10457 : H12AffineEnvironment.transform 4 26 env10456 = env10457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env10456 == env10457) = true)

def env10458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2177219,2098512,17664,2462111,2102684,2411677,257,21793,46213,2175563]

theorem envBound10458 : H12AffineFastState.Bounded env10458 := by
  intro p hp
  have h : env10458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10429_10458 : H12AffineEnvironment.transform 21 272513 env10429 = env10458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10429 == env10458) = true)

theorem identity10458 : scanCanonicalize (H12AffineFastState.compose env10458 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound10458 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,4161,272513,17,98781,8328,64,75906,5393,17664,360926,1501,318684,257,21793,46213,74250]

theorem envBound10459 : H12AffineFastState.Bounded env10459 := by
  intro p hp
  have h : env10459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10458_10459 : H12AffineEnvironment.transform 20 4161 env10458 = env10459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10458 == env10459) = true)

theorem identity10459 : scanCanonicalize (H12AffineFastState.compose env10459 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10459 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env10460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,262144,1025,32769,4161,272513,17,41430,8328,64,2185,5393,17664,303573,1501,318684,257,21793,46213,513]

theorem envBound10460 : H12AffineFastState.Bounded env10460 := by
  intro p hp
  have h : env10460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10459_10460 : H12AffineEnvironment.transform 15 8203 env10459 = env10460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10459 == env10460) = true)

theorem identity10460 : scanCanonicalize (H12AffineFastState.compose env10460 (packedSelected [3,4,9,10,14,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound10460 : packedSelected [3,4,9,10,14,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env10461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25028,262144,1025,8541,4161,272513,17,138,8328,64,2185,5393,17664,262281,1501,294272,257,21793,5593,513]

theorem envBound10461 : H12AffineFastState.Bounded env10461 := by
  intro p hp
  have h : env10461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10460_10461 : H12AffineEnvironment.transform 14 8540 env10460 = env10461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env10460 == env10461) = true)

theorem identity10461 : scanCanonicalize (H12AffineFastState.compose env10461 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10461 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25028,10280,1025,8541,4161,169,17,138,8328,64,2185,5393,17664,10401,1501,21928,257,21793,5593,513]

theorem envBound10462 : H12AffineFastState.Bounded env10462 := by
  intro p hp
  have h : env10462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10461_10462 : H12AffineEnvironment.transform 17 10280 env10461 = env10462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10461 == env10462) = true)

theorem identity10462 : scanCanonicalize (H12AffineFastState.compose env10462 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound10462 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,8203,5529,10280,1025,8541,4161,169,17,138,8328,64,2185,5393,12637,10401,1501,8693,257,8572,5593,513]

theorem envBound10463 : H12AffineFastState.Bounded env10463 := by
  intro p hp
  have h : env10463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10462_10463 : H12AffineEnvironment.transform 13 13405 env10462 = env10463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env10462 == env10463) = true)

theorem identity10463 : scanCanonicalize (H12AffineFastState.compose env10463 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10463 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8203,5392,10280,1025,8541,4161,32,17,3,8193,64,2048,5393,12637,10280,1364,8572,257,8572,5456,513]

theorem envBound10464 : H12AffineFastState.Bounded env10464 := by
  intro p hp
  have h : env10464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10463_10464 : H12AffineEnvironment.transform 6 9 env10463 = env10464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10463 == env10464) = true)

theorem identity10464 : scanCanonicalize (H12AffineFastState.compose env10464 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound10464 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,373,34,5392,2049,1025,372,4161,32,17,3,40,64,2048,5393,4468,2049,1364,341,257,341,5456,513]

theorem envBound10465 : H12AffineFastState.Bounded env10465 := by
  intro p hp
  have h : env10465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10464_10465 : H12AffineEnvironment.transform 12 41 env10464 = env10465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env10464 == env10465) = true)

theorem identity10465 : scanCanonicalize (H12AffineFastState.compose env10465 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound10465 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env10466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,4096,41,5236,373,34,5392,293,1025,372,4161,32,17,3,40,64,292,5393,4468,293,1364,341,257,341,5456,513]

theorem envBound10466 : H12AffineFastState.Bounded env10466 := by
  intro p hp
  have h : env10466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10465_10466 : H12AffineEnvironment.transform 10 292 env10465 = env10466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env10465 == env10466) = true)

theorem identity10466 : scanCanonicalize (H12AffineFastState.compose env10466 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10466 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env10467 : List Nat := [2,4,8,16,32,64,9,36,512,1024,0,4096,41,5236,81,34,5172,1,1025,80,4161,32,17,3,40,64,0,5173,4176,1,1136,113,37,113,5236,513]

theorem envBound10467 : H12AffineFastState.Bounded env10467 := by
  intro p hp
  have h : env10467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10466_10467 : H12AffineEnvironment.transform 7 36 env10466 = env10467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10466 == env10467) = true)

theorem identity10467 : scanCanonicalize (H12AffineFastState.compose env10467 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound10467 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env10468 : List Nat := [2,4,8,16,32,64,9,36,512,1024,0,16,41,1124,81,34,1060,1,1025,80,81,32,17,3,40,64,0,1061,64,1,1136,113,37,113,1124,513]

theorem envBound10468 : H12AffineFastState.Bounded env10468 := by
  intro p hp
  have h : env10468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10467_10468 : H12AffineEnvironment.transform 11 16 env10467 = env10468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env10467 == env10468) = true)

theorem identity10468 : scanCanonicalize (H12AffineFastState.compose env10468 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10468 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10469 : List Nat := [2,4,8,16,32,16,9,36,512,1024,0,16,41,1076,1,34,1060,1,1025,0,1,32,17,3,40,16,0,1061,16,1,1056,33,37,33,1076,513]

theorem envBound10469 : H12AffineFastState.Bounded env10469 := by
  intro p hp
  have h : env10469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10468_10469 : H12AffineEnvironment.transform 5 16 env10468 = env10469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10468 == env10469) = true)

theorem identity10469 : scanCanonicalize (H12AffineFastState.compose env10469 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound10469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10470 : List Nat := [2,4,8,16,32,16,9,36,512,36,0,16,41,16,1,34,0,1,37,0,1,32,17,3,40,16,0,1,16,1,4,33,37,33,16,513]

theorem envBound10470 : H12AffineFastState.Bounded env10470 := by
  intro p hp
  have h : env10470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10469_10470 : H12AffineEnvironment.transform 9 36 env10469 = env10470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env10469 == env10470) = true)

theorem identity10470 : scanCanonicalize (H12AffineFastState.compose env10470 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound10470 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10471 : List Nat := [2,4,8,10,32,10,9,36,512,36,0,10,41,10,1,34,0,1,37,0,1,32,11,3,40,10,0,1,10,1,4,33,37,33,10,513]

theorem envBound10471 : H12AffineFastState.Bounded env10471 := by
  intro p hp
  have h : env10471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10470_10471 : H12AffineEnvironment.transform 3 10 env10470 = env10471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env10470 == env10471) = true)

theorem identity10471 : scanCanonicalize (H12AffineFastState.compose env10471 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound10471 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10472 : List Nat := [2,4,8,10,11,10,9,15,512,15,0,10,2,10,1,9,0,1,14,0,1,11,11,3,3,10,0,1,10,1,4,10,14,10,10,513]

theorem envBound10472 : H12AffineFastState.Bounded env10472 := by
  intro p hp
  have h : env10472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10471_10472 : H12AffineEnvironment.transform 4 11 env10471 = env10472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env10471 == env10472) = true)

theorem identity10472 : scanCanonicalize (H12AffineFastState.compose env10472 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound10472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10473 : List Nat := [2,0,8,10,11,10,9,11,512,11,0,10,2,10,1,9,0,1,10,0,1,11,11,3,3,10,0,1,10,1,0,10,10,10,10,513]

theorem envBound10473 : H12AffineFastState.Bounded env10473 := by
  intro p hp
  have h : env10473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10472_10473 : H12AffineEnvironment.transform 1 0 env10472 = env10473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env10472 == env10473) = true)

def env10474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6623298,2098513,17665,2462110,2102684,6349853,257,21793,46213,2175563]

theorem envBound10474 : H12AffineFastState.Bounded env10474 := by
  intro p hp
  have h : env10474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10428_10474 : H12AffineEnvironment.transform 22 2101329 env10428 = env10474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env10428 == env10474) = true)

def env10475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2177218,2098513,17665,2462110,2102684,2411677,257,21793,46213,2175563]

theorem envBound10475 : H12AffineFastState.Bounded env10475 := by
  intro p hp
  have h : env10475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10474_10475 : H12AffineEnvironment.transform 21 272512 env10474 = env10475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10474 == env10475) = true)

theorem identity10475 : scanCanonicalize (H12AffineFastState.compose env10475 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound10475 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,82383,262144,1025,29908,2097152,272512,2101329,95497,8328,64,2177218,2098513,17665,2450763,2102684,2373704,257,21793,16464,2175563]

theorem envBound10476 : H12AffineFastState.Bounded env10476 := by
  intro p hp
  have h : env10476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10475_10476 : H12AffineEnvironment.transform 14 29909 env10475 = env10476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env10475 == env10476) = true)

def env10477 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82335,262144,1025,29828,2097152,272512,2101249,95497,8328,16,2177170,2098433,17665,2450715,2102684,2373656,257,21793,16384,2175515]

theorem envBound10477 : H12AffineFastState.Bounded env10477 := by
  intro p hp
  have h : env10477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10476_10477 : H12AffineEnvironment.transform 5 16 env10476 = env10477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10476 == env10477) = true)

theorem identity10477 : scanCanonicalize (H12AffineFastState.compose env10477 (packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound10477 : packedSelected [4,5,7,8,9,11,16,19,20,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10478 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82335,262144,1025,29828,25628,272512,29725,95497,8328,16,89230,24861,17665,327943,29056,285700,257,21793,16384,87559]

theorem envBound10478 : H12AffineFastState.Bounded env10478 := by
  intro p hp
  have h : env10478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10477_10478 : H12AffineEnvironment.transform 20 25628 env10477 = env10478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env10477 == env10478) = true)

theorem identity10478 : scanCanonicalize (H12AffineFastState.compose env10478 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound10478 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10479 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,82335,67754,1025,29828,25628,73770,29725,95497,8328,16,89230,24861,17665,2477,29056,87214,257,21793,16384,87559]

end H12CloudChart0