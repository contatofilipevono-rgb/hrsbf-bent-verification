import H12CloudChart0Data029

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound7427 : H12AffineFastState.Bounded env7427 := by
  intro p hp
  have h : env7427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7426_7427 : H12AffineEnvironment.transform 15 8323 env7426 = env7427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env7426 == env7427) = true)

theorem identity7427 : scanCanonicalize (H12AffineFastState.compose env7427 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 16030) := by decide +kernel

theorem selectedBound7427 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env7428 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,8323,16030,262144,524288,8201,811711,33,525497,139,8328,525544,262176,539239,529656,2080,1024,1,525565,1,16384,512]

theorem envBound7428 : H12AffineFastState.Bounded env7428 := by
  intro p hp
  have h : env7428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7427_7428 : H12AffineEnvironment.transform 16 16030 env7427 = env7428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16030 env7427 == env7428) = true)

def env7429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,13182097,8328,67108864,13444154,268435456,268570625,2080,71827765,13108377,525568,1,34359738368,4268707]

theorem envBound7429 : H12AffineFastState.Bounded env7429 := by
  intro p hp
  have h : env7429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7395_7429 : H12AffineEnvironment.transform 23 13182097 env7395 = env7429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 13182097 env7395 == env7429) = true)

def env7430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,525328,4268161,8328,67108864,4530218,268435456,268570625,2080,71827765,4194441,525568,1,34359738368,4268707]

theorem envBound7430 : H12AffineFastState.Bounded env7430 := by
  intro p hp
  have h : env7430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7429_7430 : H12AffineEnvironment.transform 22 525328 env7429 = env7430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env7429 == env7430) = true)

def env7431 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,524288,8540,2097152,4194304,525328,4268073,8224,67108864,4530218,268435456,268570625,2080,71827765,4194337,525568,1,34359738368,4268555]

theorem envBound7431 : H12AffineFastState.Bounded env7431 := by
  intro p hp
  have h : env7431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7430_7431 : H12AffineEnvironment.transform 6 40 env7430 = env7431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7430 == env7431) = true)

theorem identity7431 : scanCanonicalize (H12AffineFastState.compose env7431 (packedSelected [0,1,3,5,7,8,9,10,13,14,17,19,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 73739) := by decide +kernel

theorem selectedBound7431 : packedSelected [0,1,3,5,7,8,9,10,13,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env7432 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,524288,8540,2097152,73739,525328,34,8224,67108864,262177,268435456,268570625,2080,67707198,73770,525568,1,34359738368,512]

theorem envBound7432 : H12AffineFastState.Bounded env7432 := by
  intro p hp
  have h : env7432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7431_7432 : H12AffineEnvironment.transform 21 73739 env7431 = env7432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73739 env7431 == env7432) = true)

theorem identity7432 : scanCanonicalize (H12AffineFastState.compose env7432 (packedSelected [3,5,10] rootPS)) = affineNative (2^(27+1) ^^^ 69943587) := by decide +kernel

theorem selectedBound7432 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7433 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,524288,8540,2097152,73739,525328,34,8224,67108864,262177,69943587,69816610,2080,67707198,73770,525568,1,34359738368,512]

theorem envBound7433 : H12AffineFastState.Bounded env7433 := by
  intro p hp
  have h : env7433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7432_7433 : H12AffineEnvironment.transform 27 69943587 env7432 = env7433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 69943587 env7432 == env7433) = true)

theorem identity7433 : scanCanonicalize (H12AffineFastState.compose env7433 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound7433 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7434 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,73739,525328,34,8224,67108864,262177,69943415,69816438,2080,67706986,73770,525396,1,34359738368,512]

theorem envBound7434 : H12AffineFastState.Bounded env7434 := by
  intro p hp
  have h : env7434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7433_7434 : H12AffineEnvironment.transform 7 84 env7433 = env7434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7433 == env7434) = true)

theorem identity7434 : scanCanonicalize (H12AffineFastState.compose env7434 (packedSelected [1,8,19] rootPS)) = affineNative (2^(25+1) ^^^ 599147) := by decide +kernel

theorem selectedBound7434 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env7435 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,73739,525328,34,8224,599147,262177,2253852,2126877,2080,1025,73770,525396,1,34359738368,512]

theorem envBound7435 : H12AffineFastState.Bounded env7435 := by
  intro p hp
  have h : env7435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7434_7435 : H12AffineEnvironment.transform 25 599147 env7434 = env7435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 599147 env7434 == env7435) = true)

def env7436 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,4194304,525328,4268072,8225,67108864,4530218,268435456,268570625,2080,71827765,4194336,525568,1,34359738368,4268554]

theorem envBound7436 : H12AffineFastState.Bounded env7436 := by
  intro p hp
  have h : env7436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7430_7436 : H12AffineEnvironment.transform 6 41 env7430 = env7436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7430 == env7436) = true)

theorem identity7436 : scanCanonicalize (H12AffineFastState.compose env7436 (packedSelected [0,1,3,5,7,8,9,10,13,14,17,19,20,22] rootPS)) = affineNative (2^(25+1) ^^^ 4719925) := by decide +kernel

theorem selectedBound7436 : packedSelected [0,1,3,5,7,8,9,10,13,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env7437 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,4194304,525328,4268072,8225,4719925,4530218,268435456,268570625,2080,1024,4194336,525568,1,34359738368,4268554]

theorem envBound7437 : H12AffineFastState.Bounded env7437 := by
  intro p hp
  have h : env7437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7436_7437 : H12AffineEnvironment.transform 25 4719925 env7436 = env7437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 4719925 env7436 == env7437) = true)

theorem identity7437 : scanCanonicalize (H12AffineFastState.compose env7437 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(34+1) ^^^ 6824249) := by decide +kernel

theorem selectedBound7437 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env7438 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,4194304,525328,4268072,8225,4719925,4530218,268435456,268570625,2080,1024,4194336,525568,1,6824249,4268554]

theorem envBound7438 : H12AffineFastState.Bounded env7438 := by
  intro p hp
  have h : env7438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7437_7438 : H12AffineEnvironment.transform 34 6824249 env7437 = env7438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 6824249 env7437 == env7438) = true)

theorem identity7438 : scanCanonicalize (H12AffineFastState.compose env7438 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 73738) := by decide +kernel

theorem selectedBound7438 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env7439 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,73738,525328,34,8225,599359,262176,268435456,268570625,2080,1024,73770,525568,1,2687283,512]

theorem envBound7439 : H12AffineFastState.Bounded env7439 := by
  intro p hp
  have h : env7439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7438_7439 : H12AffineEnvironment.transform 21 73738 env7438 = env7439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73738 env7438 == env7439) = true)

theorem identity7439 : scanCanonicalize (H12AffineFastState.compose env7439 (packedSelected [3,5,10] rootPS)) = affineNative (2^(27+1) ^^^ 2253852) := by decide +kernel

theorem selectedBound7439 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7440 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,73738,525328,34,8225,599359,262176,2253852,2126877,2080,1024,73770,525568,1,2687283,512]

theorem envBound7440 : H12AffineFastState.Bounded env7440 := by
  intro p hp
  have h : env7440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7439_7440 : H12AffineEnvironment.transform 27 2253852 env7439 = env7440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 2253852 env7439 == env7440) = true)

theorem identity7440 : scanCanonicalize (H12AffineFastState.compose env7440 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7440 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7441 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,73738,525328,34,8225,599146,262176,2253852,2126877,2080,1024,73770,525397,1,2687078,512]

theorem envBound7441 : H12AffineFastState.Bounded env7441 := by
  intro p hp
  have h : env7441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7440_7441 : H12AffineEnvironment.transform 7 85 env7440 = env7441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7440 == env7441) = true)

theorem identity7441 : scanCanonicalize (H12AffineFastState.compose env7441 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound7441 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7442 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,131072,2081,524288,8200,2097152,73738,525328,34,8225,599146,2049,2253852,2126877,2080,1024,73770,525397,1,2687078,512]

theorem envBound7442 : H12AffineFastState.Bounded env7442 := by
  intro p hp
  have h : env7442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7441_7442 : H12AffineEnvironment.transform 17 2081 env7441 = env7442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env7441 == env7442) = true)

theorem identity7442 : scanCanonicalize (H12AffineFastState.compose env7442 (packedSelected [1,3,4,5,8,9,11,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7442 : packedSelected [1,3,4,5,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env7443 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,8235,131072,2081,524288,8200,2097152,33,525328,34,8225,525377,2049,2253852,2126877,2080,1024,1,525397,1,2629709,512]

theorem envBound7443 : H12AffineFastState.Bounded env7443 := by
  intro p hp
  have h : env7443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7442_7443 : H12AffineEnvironment.transform 15 8235 env7442 = env7443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7442 == env7443) = true)

theorem identity7443 : scanCanonicalize (H12AffineFastState.compose env7443 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 3654) := by decide +kernel

theorem selectedBound7443 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7444 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,3654,16384,3662,3693,131072,2081,524288,3662,2097152,33,525328,34,3687,525377,2049,2247258,2120283,2080,1024,1,525397,1,2625035,512]

theorem envBound7444 : H12AffineFastState.Bounded env7444 := by
  intro p hp
  have h : env7444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7443_7444 : H12AffineEnvironment.transform 12 3654 env7443 = env7444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3654 env7443 == env7444) = true)

theorem identity7444 : scanCanonicalize (H12AffineFastState.compose env7444 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 544266) := by decide +kernel

theorem selectedBound7444 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7445 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,3654,16384,3662,3693,131072,2081,524288,3662,544266,33,525328,34,3687,525377,2049,656464,529489,2080,1024,1,525397,1,16385,512]

theorem envBound7445 : H12AffineFastState.Bounded env7445 := by
  intro p hp
  have h : env7445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7444_7445 : H12AffineEnvironment.transform 20 544266 env7444 = env7445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 544266 env7444 == env7445) = true)

theorem identity7445 : scanCanonicalize (H12AffineFastState.compose env7445 (packedSelected [0,2,4] rootPS)) = affineNative (2^(18+1) ^^^ 147540) := by decide +kernel

theorem selectedBound7445 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env7446 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,3654,16384,3662,3693,131072,2081,147540,3662,134750,33,148548,34,3687,148501,2049,17412,152581,2080,1024,1,148481,1,16385,512]

theorem envBound7446 : H12AffineFastState.Bounded env7446 := by
  intro p hp
  have h : env7446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7445_7446 : H12AffineEnvironment.transform 18 147540 env7445 = env7446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 147540 env7445 == env7446) = true)

theorem identity7446 : scanCanonicalize (H12AffineFastState.compose env7446 (packedSelected [1,5] rootPS)) = affineNative (2^(16+1) ^^^ 6666) := by decide +kernel

theorem selectedBound7446 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7447 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,3654,16384,3662,3693,6666,2081,23134,3662,5204,33,24142,34,3687,24095,2049,17412,19983,2080,1024,1,24075,1,16385,512]

theorem envBound7447 : H12AffineFastState.Bounded env7447 := by
  intro p hp
  have h : env7447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7446_7447 : H12AffineEnvironment.transform 16 6666 env7446 = env7447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6666 env7446 == env7447) = true)

theorem identity7447 : scanCanonicalize (H12AffineFastState.compose env7447 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 7694) := by decide +kernel

theorem selectedBound7447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7448 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,3654,7694,3662,3693,6666,2081,1104,3662,5204,33,64,34,3687,17,2049,6666,4097,2080,1024,1,5,1,7695,512]

theorem envBound7448 : H12AffineFastState.Bounded env7448 := by
  intro p hp
  have h : env7448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7447_7448 : H12AffineEnvironment.transform 13 7694 env7447 = env7448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7694 env7447 == env7448) = true)

def env7449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,525329,4268160,8328,67108864,4530219,268435456,268570625,2080,71827765,4194440,525568,1,34359738368,4268707]

theorem envBound7449 : H12AffineFastState.Bounded env7449 := by
  intro p hp
  have h : env7449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7429_7449 : H12AffineEnvironment.transform 22 525329 env7429 = env7449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env7429 == env7449) = true)

theorem identity7449 : scanCanonicalize (H12AffineFastState.compose env7449 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7449 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env7450 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,525329,4268160,8328,67108864,4530219,268435456,268570625,2080,71827657,4194440,525564,1,34359738368,4268707]

theorem envBound7450 : H12AffineFastState.Bounded env7450 := by
  intro p hp
  have h : env7450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7449_7450 : H12AffineEnvironment.transform 7 252 env7449 = env7450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7449 == env7450) = true)

theorem identity7450 : scanCanonicalize (H12AffineFastState.compose env7450 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(34+1) ^^^ 273302745) := by decide +kernel

theorem selectedBound7450 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env7451 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,525329,4268160,8328,67108864,4530219,268435456,268570625,2080,71827657,4194440,525564,1,273302745,4268707]

theorem envBound7451 : H12AffineFastState.Bounded env7451 := by
  intro p hp
  have h : env7451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7450_7451 : H12AffineEnvironment.transform 34 273302745 env7450 = env7451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 273302745 env7450 == env7451) = true)

def env7452 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,525329,4268072,8224,67108864,4530219,268435456,268570625,2080,71827553,4194336,525396,1,273302641,4268555]

theorem envBound7452 : H12AffineFastState.Bounded env7452 := by
  intro p hp
  have h : env7452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7451_7452 : H12AffineEnvironment.transform 6 40 env7451 = env7452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7451 == env7452) = true)

theorem identity7452 : scanCanonicalize (H12AffineFastState.compose env7452 (packedSelected [17,21] rootPS)) = affineNative (2^(25+1) ^^^ 4719713) := by decide +kernel

theorem selectedBound7452 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env7453 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,525329,4268072,8224,4719713,4530219,268435456,268570625,2080,1024,4194336,525396,1,273302641,4268555]

theorem envBound7453 : H12AffineFastState.Bounded env7453 := by
  intro p hp
  have h : env7453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7452_7453 : H12AffineEnvironment.transform 25 4719713 env7452 = env7453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 4719713 env7452 == env7453) = true)

theorem identity7453 : scanCanonicalize (H12AffineFastState.compose env7453 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 82998) := by decide +kernel

theorem selectedBound7453 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env7454 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,82998,4194304,525329,4268072,8224,4719713,4530219,268435456,268570625,2080,1024,4194336,525396,1,273302641,4268555]

theorem envBound7454 : H12AffineFastState.Bounded env7454 := by
  intro p hp
  have h : env7454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7453_7454 : H12AffineEnvironment.transform 20 82998 env7453 = env7454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82998 env7453 == env7454) = true)

theorem identity7454 : scanCanonicalize (H12AffineFastState.compose env7454 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound7454 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env7455 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,131072,2081,524288,8200,82998,4194304,525329,4268072,8224,4719713,4270090,268435456,268570625,2080,1024,4194336,525396,1,273302641,4268555]

theorem envBound7455 : H12AffineFastState.Bounded env7455 := by
  intro p hp
  have h : env7455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7454_7455 : H12AffineEnvironment.transform 17 2081 env7454 = env7455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env7454 == env7455) = true)

theorem identity7455 : scanCanonicalize (H12AffineFastState.compose env7455 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 73739) := by decide +kernel

theorem selectedBound7455 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7456 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8200,65536,131072,2081,524288,8200,82998,73739,525329,35,8224,599146,2049,268435456,268570625,2080,1024,73771,525396,1,269182074,512]

theorem envBound7456 : H12AffineFastState.Bounded env7456 := by
  intro p hp
  have h : env7456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7455_7456 : H12AffineEnvironment.transform 21 73739 env7455 = env7456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73739 env7455 == env7456) = true)

def env7457 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,16384,0,65536,131072,2081,524288,0,82998,65539,525329,35,40,590946,2049,268435456,268570625,2080,1024,65571,525396,1,269173874,512]

theorem envBound7457 : H12AffineFastState.Bounded env7457 := by
  intro p hp
  have h : env7457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7456_7457 : H12AffineEnvironment.transform 12 8 env7456 = env7457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env7456 == env7457) = true)

theorem identity7457 : scanCanonicalize (H12AffineFastState.compose env7457 (packedSelected [13] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound7457 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7458 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,16384,0,34,131072,2081,524288,0,17428,33,525329,35,40,525376,2049,268435456,268570625,2080,1024,1,525396,1,269108304,512]

theorem envBound7458 : H12AffineFastState.Bounded env7458 := by
  intro p hp
  have h : env7458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7457_7458 : H12AffineEnvironment.transform 15 34 env7457 = env7458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env7457 == env7458) = true)

theorem identity7458 : scanCanonicalize (H12AffineFastState.compose env7458 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1615) := by decide +kernel

theorem selectedBound7458 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7459 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1615,4096,8,16384,0,34,131072,1646,524288,0,17428,33,525329,35,40,525376,1614,268435456,268570625,1647,1024,1,525396,1,269108304,512]

theorem envBound7459 : H12AffineFastState.Bounded env7459 := by
  intro p hp
  have h : env7459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7458_7459 : H12AffineEnvironment.transform 10 1615 env7458 = env7459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1615 env7458 == env7459) = true)

theorem identity7459 : scanCanonicalize (H12AffineFastState.compose env7459 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 135189) := by decide +kernel

theorem selectedBound7459 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7460 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1615,4096,8,16384,0,34,131072,1646,135189,0,17428,33,136196,35,40,136277,1614,268435456,268570625,1647,1024,1,136257,1,268457029,512]

theorem envBound7460 : H12AffineFastState.Bounded env7460 := by
  intro p hp
  have h : env7460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7459_7460 : H12AffineEnvironment.transform 18 135189 env7459 = env7460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 135189 env7459 == env7460) = true)

theorem identity7460 : scanCanonicalize (H12AffineFastState.compose env7460 (packedSelected [2,11] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound7460 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env7461 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1615,4096,8,4161,0,34,131072,1646,135189,0,5205,33,136196,35,40,136277,1614,268435456,268570625,1647,1024,1,136257,1,268436484,512]

theorem envBound7461 : H12AffineFastState.Bounded env7461 := by
  intro p hp
  have h : env7461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7460_7461 : H12AffineEnvironment.transform 13 4161 env7460 = env7461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env7460 == env7461) = true)

theorem identity7461 : scanCanonicalize (H12AffineFastState.compose env7461 (packedSelected [2,18] rootPS)) = affineNative (2^(27+1) ^^^ 5188) := by decide +kernel

theorem selectedBound7461 : packedSelected [2,18] rootPS < 2^1333 := by decide +kernel

def env7462 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1615,4096,8,4161,0,34,131072,1646,135189,0,5205,33,136196,35,40,136277,1614,5188,132165,1647,1024,1,136257,1,4160,512]

theorem envBound7462 : H12AffineFastState.Bounded env7462 := by
  intro p hp
  have h : env7462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7461_7462 : H12AffineEnvironment.transform 27 5188 env7461 = env7462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 5188 env7461 == env7462) = true)

def env7463 : List Nat := [2,4,8,16,32,64,40,84,512,52,635,4096,8,4161,0,34,131072,602,135189,0,4193,33,135216,35,40,135265,634,4208,131185,603,52,1,135285,1,4160,512]

theorem envBound7463 : H12AffineFastState.Bounded env7463 := by
  intro p hp
  have h : env7463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7462_7463 : H12AffineEnvironment.transform 9 52 env7462 = env7463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env7462 == env7463) = true)

theorem identity7463 : scanCanonicalize (H12AffineFastState.compose env7463 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 586) := by decide +kernel

theorem selectedBound7463 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7464 : List Nat := [2,4,8,16,32,64,40,84,512,52,635,586,8,523,0,34,131072,602,131679,0,555,33,131706,35,40,131627,634,570,131185,603,52,1,131647,1,522,512]

theorem envBound7464 : H12AffineFastState.Bounded env7464 := by
  intro p hp
  have h : env7464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7463_7464 : H12AffineEnvironment.transform 11 586 env7463 = env7464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 586 env7463 == env7464) = true)

def env7465 : List Nat := [2,4,8,16,32,48,40,36,512,52,523,570,8,523,0,34,131072,554,131631,0,555,33,131594,35,40,131627,522,570,131073,555,52,1,131647,1,522,512]

theorem envBound7465 : H12AffineFastState.Bounded env7465 := by
  intro p hp
  have h : env7465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7464_7465 : H12AffineEnvironment.transform 5 48 env7464 = env7465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7464 == env7465) = true)

theorem identity7465 : scanCanonicalize (H12AffineFastState.compose env7465 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound7465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7466 : List Nat := [2,4,8,16,32,48,40,36,44,52,39,22,8,39,0,34,131072,6,131075,0,7,33,131110,35,40,131079,38,22,131073,7,52,1,131091,1,38,44]

theorem envBound7466 : H12AffineFastState.Bounded env7466 := by
  intro p hp
  have h : env7466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7465_7466 : H12AffineEnvironment.transform 8 44 env7465 = env7466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env7465 == env7466) = true)

def leafEnv7466 : List Nat := [2,4,8,16,32,48,40,36,44,52,39,22,8,39,0,34,131072,6,131075,0,7,33,131110,35,131074,40,1,131079,38,22,131073,7,52,1,131091,1,131122,3,38,44,1,6,0]

def active7466 : List Nat := [0,1,2,3,4,16]

def tree7466 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7466 : H12WitnessSearch.Good tree7466 := H12GlobalWitnessIndex.good

theorem leafIdentity7466 : H12AffineFastState.composeSystem env7466 rootObs = leafEnv7466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7466 rootObs == leafEnv7466) = true)

theorem terminalChecked7466 : H12PackedTerminal.terminalCheckFast leafEnv7466 active7466 tree7466 = true := by decide +kernel

def env7467 : List Nat := [2,4,8,16,32,49,40,37,512,52,522,571,8,523,0,34,131072,555,131630,0,555,33,131595,35,40,131627,523,570,131072,554,52,1,131647,1,522,512]

theorem envBound7467 : H12AffineFastState.Bounded env7467 := by
  intro p hp
  have h : env7467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7464_7467 : H12AffineEnvironment.transform 5 49 env7464 = env7467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7464 == env7467) = true)

theorem identity7467 : scanCanonicalize (H12AffineFastState.compose env7467 (packedSelected [0] rootPS)) = affineNative (2^(16+1) ^^^ 23) := by decide +kernel

theorem selectedBound7467 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7468 : List Nat := [2,4,8,16,32,49,40,37,512,52,522,571,8,523,0,34,23,555,569,0,555,33,540,35,40,572,523,570,23,554,52,1,552,1,522,512]

theorem envBound7468 : H12AffineFastState.Bounded env7468 := by
  intro p hp
  have h : env7468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7467_7468 : H12AffineEnvironment.transform 16 23 env7467 = env7468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 23 env7467 == env7468) = true)

def leafEnv7468 : List Nat := [2,4,8,16,32,49,40,37,512,52,522,571,8,523,0,34,23,555,569,0,555,33,540,35,568,40,1,572,523,570,23,554,52,1,552,1,520,3,522,512,1,554,0]

def active7468 : List Nat := [0,1,2,3,4,8]

def tree7468 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7468 : H12WitnessSearch.Good tree7468 := H12GlobalWitnessIndex.good

theorem leafIdentity7468 : H12AffineFastState.composeSystem env7468 rootObs = leafEnv7468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7468 rootObs == leafEnv7468) = true)

theorem terminalChecked7468 : H12PackedTerminal.terminalCheckFast leafEnv7468 active7468 tree7468 = true := by decide +kernel

def env7469 : List Nat := [2,4,8,16,32,64,40,84,512,53,634,4096,8,4161,0,34,131072,603,135189,0,4192,33,135217,35,40,135264,635,4209,131184,602,53,1,135284,1,4160,512]

theorem envBound7469 : H12AffineFastState.Bounded env7469 := by
  intro p hp
  have h : env7469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7462_7469 : H12AffineEnvironment.transform 9 53 env7462 = env7469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env7462 == env7469) = true)

def env7470 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,9,16384,1,65536,131072,2081,524288,1,82998,65538,525329,35,41,590947,2049,268435456,268570625,2080,1024,65570,525396,1,269173875,512]

theorem envBound7470 : H12AffineFastState.Bounded env7470 := by
  intro p hp
  have h : env7470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7456_7470 : H12AffineEnvironment.transform 12 9 env7456 = env7470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env7456 == env7470) = true)

theorem identity7470 : scanCanonicalize (H12AffineFastState.compose env7470 (packedSelected [1,2,3,5,6,8,11,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound7470 : packedSelected [1,2,3,5,6,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env7471 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,9,16384,1,35,131072,2081,524288,1,17429,33,525329,35,41,525376,2049,268435456,268570625,2080,1024,1,525396,1,269108304,512]

theorem envBound7471 : H12AffineFastState.Bounded env7471 := by
  intro p hp
  have h : env7471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7470_7471 : H12AffineEnvironment.transform 15 35 env7470 = env7471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env7470 == env7471) = true)

theorem identity7471 : scanCanonicalize (H12AffineFastState.compose env7471 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1614) := by decide +kernel

theorem selectedBound7471 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7472 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1614,4096,9,16384,1,35,131072,1647,524288,1,17429,33,525329,35,41,525376,1615,268435456,268570625,1646,1024,1,525396,1,269108304,512]

theorem envBound7472 : H12AffineFastState.Bounded env7472 := by
  intro p hp
  have h : env7472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7471_7472 : H12AffineEnvironment.transform 10 1614 env7471 = env7472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1614 env7471 == env7472) = true)

theorem identity7472 : scanCanonicalize (H12AffineFastState.compose env7472 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 135188) := by decide +kernel

theorem selectedBound7472 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7473 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1614,4096,9,16384,1,35,131072,1647,135188,1,17429,33,136197,35,41,136276,1615,268435456,268570625,1646,1024,1,136256,1,268457028,512]

theorem envBound7473 : H12AffineFastState.Bounded env7473 := by
  intro p hp
  have h : env7473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7472_7473 : H12AffineEnvironment.transform 18 135188 env7472 = env7473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 135188 env7472 == env7473) = true)

theorem identity7473 : scanCanonicalize (H12AffineFastState.compose env7473 (packedSelected [2,11] rootPS)) = affineNative (2^(27+1) ^^^ 17413) := by decide +kernel

theorem selectedBound7473 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env7474 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1614,4096,9,16384,1,35,131072,1647,135188,1,17429,33,136197,35,41,136276,1615,17413,152580,1646,1024,1,136256,1,4161,512]

theorem envBound7474 : H12AffineFastState.Bounded env7474 := by
  intro p hp
  have h : env7474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7473_7474 : H12AffineEnvironment.transform 27 17413 env7473 = env7474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 17413 env7473 == env7474) = true)

theorem identity7474 : scanCanonicalize (H12AffineFastState.compose env7474 (packedSelected [5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound7474 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env7475 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1614,4096,9,4160,1,35,131072,1647,135188,1,5205,33,136197,35,41,136276,1615,5189,132164,1646,1024,1,136256,1,4161,512]

theorem envBound7475 : H12AffineFastState.Bounded env7475 := by
  intro p hp
  have h : env7475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7474_7475 : H12AffineEnvironment.transform 13 4160 env7474 = env7475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env7474 == env7475) = true)

def env7476 : List Nat := [2,4,8,16,32,64,40,84,512,52,634,4096,9,4160,1,35,131072,603,135188,1,4193,33,135217,35,41,135264,635,4209,131184,602,52,1,135284,1,4161,512]

theorem envBound7476 : H12AffineFastState.Bounded env7476 := by
  intro p hp
  have h : env7476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7475_7476 : H12AffineEnvironment.transform 9 52 env7475 = env7476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env7475 == env7476) = true)

def env7477 : List Nat := [2,4,8,16,32,64,40,84,512,53,635,4096,9,4160,1,35,131072,602,135188,1,4192,33,135216,35,41,135265,634,4208,131185,603,53,1,135285,1,4161,512]

theorem envBound7477 : H12AffineFastState.Bounded env7477 := by
  intro p hp
  have h : env7477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7475_7477 : H12AffineEnvironment.transform 9 53 env7475 = env7477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env7475 == env7477) = true)

theorem identity7477 : scanCanonicalize (H12AffineFastState.compose env7477 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound7477 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7478 : List Nat := [2,4,8,16,32,64,40,84,512,53,635,587,9,523,1,35,131072,602,131679,1,555,33,131707,35,41,131626,634,571,131185,603,53,1,131646,1,522,512]

theorem envBound7478 : H12AffineFastState.Bounded env7478 := by
  intro p hp
  have h : env7478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7477_7478 : H12AffineEnvironment.transform 11 587 env7477 = env7478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env7477 == env7478) = true)

def env7479 : List Nat := [2,4,8,16,32,48,40,36,512,53,523,571,9,523,1,35,131072,554,131631,1,555,33,131595,35,41,131626,522,571,131073,555,53,1,131646,1,522,512]

theorem envBound7479 : H12AffineFastState.Bounded env7479 := by
  intro p hp
  have h : env7479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7478_7479 : H12AffineEnvironment.transform 5 48 env7478 = env7479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7478 == env7479) = true)

theorem identity7479 : scanCanonicalize (H12AffineFastState.compose env7479 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound7479 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7480 : List Nat := [2,4,8,16,32,48,40,36,45,53,38,22,9,38,1,35,131072,7,131074,1,6,33,131110,35,41,131079,39,22,131073,6,53,1,131091,1,39,45]

theorem envBound7480 : H12AffineFastState.Bounded env7480 := by
  intro p hp
  have h : env7480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7479_7480 : H12AffineEnvironment.transform 8 45 env7479 = env7480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env7479 == env7480) = true)

def leafEnv7480 : List Nat := [2,4,8,16,32,48,40,36,45,53,38,22,9,38,1,35,131072,7,131074,1,6,33,131110,35,131075,41,1,131079,39,22,131073,6,53,1,131091,1,131122,2,39,45,1,7,0]

def active7480 : List Nat := [0,1,2,3,4,16]

def tree7480 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7480 : H12WitnessSearch.Good tree7480 := H12GlobalWitnessIndex.good

theorem leafIdentity7480 : H12AffineFastState.composeSystem env7480 rootObs = leafEnv7480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7480 rootObs == leafEnv7480) = true)

theorem terminalChecked7480 : H12PackedTerminal.terminalCheckFast leafEnv7480 active7480 tree7480 = true := by decide +kernel

def env7481 : List Nat := [2,4,8,16,32,49,40,37,512,53,522,570,9,523,1,35,131072,555,131630,1,555,33,131594,35,41,131626,523,571,131072,554,53,1,131646,1,522,512]

theorem envBound7481 : H12AffineFastState.Bounded env7481 := by
  intro p hp
  have h : env7481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7478_7481 : H12AffineEnvironment.transform 5 49 env7478 = env7481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7478 == env7481) = true)

theorem identity7481 : scanCanonicalize (H12AffineFastState.compose env7481 (packedSelected [0] rootPS)) = affineNative (2^(16+1) ^^^ 22) := by decide +kernel

theorem selectedBound7481 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7482 : List Nat := [2,4,8,16,32,49,40,37,512,53,522,570,9,523,1,35,22,555,568,1,555,33,540,35,41,572,523,571,22,554,53,1,552,1,522,512]

theorem envBound7482 : H12AffineFastState.Bounded env7482 := by
  intro p hp
  have h : env7482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7481_7482 : H12AffineEnvironment.transform 16 22 env7481 = env7482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 22 env7481 == env7482) = true)

def leafEnv7482 : List Nat := [2,4,8,16,32,49,40,37,512,53,522,570,9,523,1,35,22,555,568,1,555,33,540,35,569,41,1,572,523,571,22,554,53,1,552,1,520,2,522,512,1,554,0]

def active7482 : List Nat := [0,1,2,3,4,8]

def tree7482 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7482 : H12WitnessSearch.Good tree7482 := H12GlobalWitnessIndex.good

theorem leafIdentity7482 : H12AffineFastState.composeSystem env7482 rootObs = leafEnv7482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7482 rootObs == leafEnv7482) = true)

theorem terminalChecked7482 : H12PackedTerminal.terminalCheckFast leafEnv7482 active7482 tree7482 = true := by decide +kernel

def env7483 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,525329,4268073,8225,67108864,4530219,268435456,268570625,2080,71827552,4194337,525397,1,273302640,4268554]

theorem envBound7483 : H12AffineFastState.Bounded env7483 := by
  intro p hp
  have h : env7483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7451_7483 : H12AffineEnvironment.transform 6 41 env7451 = env7483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7451 == env7483) = true)

theorem identity7483 : scanCanonicalize (H12AffineFastState.compose env7483 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 73738) := by decide +kernel

theorem selectedBound7483 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env7484 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,73738,525329,35,8225,67108864,262177,268435456,268570625,2080,67706986,73771,525397,1,269182074,512]

theorem envBound7484 : H12AffineFastState.Bounded env7484 := by
  intro p hp
  have h : env7484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7483_7484 : H12AffineEnvironment.transform 21 73738 env7483 = env7484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73738 env7483 == env7484) = true)

theorem identity7484 : scanCanonicalize (H12AffineFastState.compose env7484 (packedSelected [3,5,10] rootPS)) = affineNative (2^(25+1) ^^^ 2646108) := by decide +kernel

theorem selectedBound7484 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7485 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,73738,525329,35,8225,2646108,262177,268435456,268570625,2080,2179126,73771,525397,1,269182074,512]

theorem envBound7485 : H12AffineFastState.Bounded env7485 := by
  intro p hp
  have h : env7485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7484_7485 : H12AffineEnvironment.transform 25 2646108 env7484 = env7485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2646108 env7484 == env7485) = true)

theorem identity7485 : scanCanonicalize (H12AffineFastState.compose env7485 (packedSelected [1,8,19] rootPS)) = affineNative (2^(20+1) ^^^ 82999) := by decide +kernel

theorem selectedBound7485 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env7486 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,82999,73738,525329,35,8225,599147,262177,268435456,268570625,2080,1025,73771,525397,1,269182074,512]

theorem envBound7486 : H12AffineFastState.Bounded env7486 := by
  intro p hp
  have h : env7486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7485_7486 : H12AffineEnvironment.transform 20 82999 env7485 = env7486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82999 env7485 == env7486) = true)

def env7487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,67108864,17039530,268435456,268570625,2080,92349861,13108376,525568,1,34359738368,25691699]

theorem envBound7487 : H12AffineFastState.Bounded env7487 := by
  intro p hp
  have h : env7487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7394_7487 : H12AffineEnvironment.transform 14 8693 env7394 = env7487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env7394 == env7487) = true)

theorem identity7487 : scanCanonicalize (H12AffineFastState.compose env7487 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913971) := by decide +kernel

theorem selectedBound7487 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env7488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,8913971,8328,67108864,9176217,268435456,268570625,2080,67707286,13108376,525568,1,34359738368,512]

theorem envBound7488 : H12AffineFastState.Bounded env7488 := by
  intro p hp
  have h : env7488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7487_7488 : H12AffineEnvironment.transform 23 8913971 env7487 = env7488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913971 env7487 == env7488) = true)

theorem identity7488 : scanCanonicalize (H12AffineFastState.compose env7488 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 12583024) := by decide +kernel

theorem selectedBound7488 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env7489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,8913971,8328,12583024,9176217,268435456,268570625,2080,13181414,13108376,525568,1,34359738368,512]

theorem envBound7489 : H12AffineFastState.Bounded env7489 := by
  intro p hp
  have h : env7489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7488_7489 : H12AffineEnvironment.transform 25 12583024 env7488 = env7489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 12583024 env7488 == env7489) = true)

theorem identity7489 : scanCanonicalize (H12AffineFastState.compose env7489 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 74078) := by decide +kernel

theorem selectedBound7489 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env7490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,74078,8388608,8913971,8328,8462638,9176217,268435456,268570625,2080,8913080,8988102,525568,1,34359738368,512]

theorem envBound7490 : H12AffineFastState.Bounded env7490 := by
  intro p hp
  have h : env7490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7489_7490 : H12AffineEnvironment.transform 21 74078 env7489 = env7490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74078 env7489 == env7490) = true)

theorem identity7490 : scanCanonicalize (H12AffineFastState.compose env7490 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 541945) := by decide +kernel

theorem selectedBound7490 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env7491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,74078,8388608,8913971,8328,8462638,9176217,268435456,268570625,2080,8913080,8988102,525568,1,541945,512]

theorem envBound7491 : H12AffineFastState.Bounded env7491 := by
  intro p hp
  have h : env7491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7490_7491 : H12AffineEnvironment.transform 34 541945 env7490 = env7491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 541945 env7490 == env7491) = true)

def env7492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,17080671,268435456,268570625,2081,92374096,13149548,525568,0,34359738368,25733062]

theorem envBound7492 : H12AffineFastState.Bounded env7492 := by
  intro p hp
  have h : env7492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7393_7492 : H12AffineEnvironment.transform 29 2081 env7393 = env7492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2081 env7393 == env7492) = true)

def env7493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,67108864,17039531,268435456,268570625,2081,92349860,13108376,525568,0,34359738368,25691698]

theorem envBound7493 : H12AffineFastState.Bounded env7493 := by
  intro p hp
  have h : env7493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7492_7493 : H12AffineEnvironment.transform 14 8692 env7492 = env7493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env7492 == env7493) = true)

theorem identity7493 : scanCanonicalize (H12AffineFastState.compose env7493 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913970) := by decide +kernel

theorem selectedBound7493 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env7494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913970,8328,67108864,9176217,268435456,268570625,2081,67707286,13108376,525568,0,34359738368,512]

theorem envBound7494 : H12AffineFastState.Bounded env7494 := by
  intro p hp
  have h : env7494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7493_7494 : H12AffineEnvironment.transform 23 8913970 env7493 = env7494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913970 env7493 == env7494) = true)

theorem identity7494 : scanCanonicalize (H12AffineFastState.compose env7494 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 12583024) := by decide +kernel

theorem selectedBound7494 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env7495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913970,8328,12583024,9176217,268435456,268570625,2081,13181414,13108376,525568,0,34359738368,512]

theorem envBound7495 : H12AffineFastState.Bounded env7495 := by
  intro p hp
  have h : env7495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7494_7495 : H12AffineEnvironment.transform 25 12583024 env7494 = env7495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 12583024 env7494 == env7495) = true)

theorem identity7495 : scanCanonicalize (H12AffineFastState.compose env7495 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 74078) := by decide +kernel

theorem selectedBound7495 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env7496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,74078,8388608,8913970,8328,8462638,9176217,268435456,268570625,2081,8913080,8988102,525568,0,34359738368,512]

theorem envBound7496 : H12AffineFastState.Bounded env7496 := by
  intro p hp
  have h : env7496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7495_7496 : H12AffineEnvironment.transform 21 74078 env7495 = env7496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74078 env7495 == env7496) = true)

theorem identity7496 : scanCanonicalize (H12AffineFastState.compose env7496 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 541944) := by decide +kernel

theorem selectedBound7496 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env7497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,74078,8388608,8913970,8328,8462638,9176217,268435456,268570625,2081,8913080,8988102,525568,0,541944,512]

theorem envBound7497 : H12AffineFastState.Bounded env7497 := by
  intro p hp
  have h : env7497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7496_7497 : H12AffineEnvironment.transform 34 541944 env7496 = env7497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 541944 env7496 == env7497) = true)

def env7498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,67108864,17039530,268435456,268570625,2081,92349861,13108377,525568,0,34359738368,25691699]

theorem envBound7498 : H12AffineFastState.Bounded env7498 := by
  intro p hp
  have h : env7498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7492_7498 : H12AffineEnvironment.transform 14 8693 env7492 = env7498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env7492 == env7498) = true)

def env7499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,13182096,8328,67108864,13444154,268435456,268570625,2081,71827765,13108377,525568,0,34359738368,4268707]

theorem envBound7499 : H12AffineFastState.Bounded env7499 := by
  intro p hp
  have h : env7499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7498_7499 : H12AffineEnvironment.transform 23 13182096 env7498 = env7499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 13182096 env7498 == env7499) = true)

def env7500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,525328,4268160,8328,67108864,4530218,268435456,268570625,2081,71827765,4194441,525568,0,34359738368,4268707]

theorem envBound7500 : H12AffineFastState.Bounded env7500 := by
  intro p hp
  have h : env7500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7499_7500 : H12AffineEnvironment.transform 22 525328 env7499 = env7500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env7499 == env7500) = true)

def env7501 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,4194304,525328,4268072,8224,67108864,4530218,268435456,268570625,2081,71827765,4194337,525568,0,34359738368,4268555]

theorem envBound7501 : H12AffineFastState.Bounded env7501 := by
  intro p hp
  have h : env7501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7500_7501 : H12AffineEnvironment.transform 6 40 env7500 = env7501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7500 == env7501) = true)

theorem identity7501 : scanCanonicalize (H12AffineFastState.compose env7501 (packedSelected [0,1,3,5,7,8,9,10,13,14,17,19,20,22] rootPS)) = affineNative (2^(25+1) ^^^ 4719924) := by decide +kernel

theorem selectedBound7501 : packedSelected [0,1,3,5,7,8,9,10,13,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env7502 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,4194304,525328,4268072,8224,4719924,4530218,268435456,268570625,2081,1025,4194337,525568,0,34359738368,4268555]

theorem envBound7502 : H12AffineFastState.Bounded env7502 := by
  intro p hp
  have h : env7502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7501_7502 : H12AffineEnvironment.transform 25 4719924 env7501 = env7502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 4719924 env7501 == env7502) = true)

theorem identity7502 : scanCanonicalize (H12AffineFastState.compose env7502 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(34+1) ^^^ 2687283) := by decide +kernel

theorem selectedBound7502 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env7503 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,4194304,525328,4268072,8224,4719924,4530218,268435456,268570625,2081,1025,4194337,525568,0,2687283,4268555]

theorem envBound7503 : H12AffineFastState.Bounded env7503 := by
  intro p hp
  have h : env7503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7502_7503 : H12AffineEnvironment.transform 34 2687283 env7502 = env7503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2687283 env7502 == env7503) = true)

theorem identity7503 : scanCanonicalize (H12AffineFastState.compose env7503 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 73739) := by decide +kernel

theorem selectedBound7503 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env7504 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,73739,525328,35,8224,599359,262177,268435456,268570625,2081,1025,73770,525568,0,2687283,512]

theorem envBound7504 : H12AffineFastState.Bounded env7504 := by
  intro p hp
  have h : env7504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7503_7504 : H12AffineEnvironment.transform 21 73739 env7503 = env7504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73739 env7503 == env7504) = true)

theorem identity7504 : scanCanonicalize (H12AffineFastState.compose env7504 (packedSelected [3,5,10] rootPS)) = affineNative (2^(27+1) ^^^ 2253852) := by decide +kernel

theorem selectedBound7504 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7505 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,73739,525328,35,8224,599359,262177,2253852,2126877,2081,1025,73770,525568,0,2687283,512]

theorem envBound7505 : H12AffineFastState.Bounded env7505 := by
  intro p hp
  have h : env7505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7504_7505 : H12AffineEnvironment.transform 27 2253852 env7504 = env7505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 2253852 env7504 == env7505) = true)

theorem identity7505 : scanCanonicalize (H12AffineFastState.compose env7505 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound7505 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7506 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,73739,525328,35,8224,599147,262177,2253852,2126877,2081,1025,73770,525396,0,2687079,512]

theorem envBound7506 : H12AffineFastState.Bounded env7506 := by
  intro p hp
  have h : env7506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7505_7506 : H12AffineEnvironment.transform 7 84 env7505 = env7506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7505 == env7506) = true)

theorem identity7506 : scanCanonicalize (H12AffineFastState.compose env7506 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound7506 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7507 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,131072,2080,524288,8201,2097152,73739,525328,35,8224,599147,2049,2253852,2126877,2081,1025,73770,525396,0,2687079,512]

theorem envBound7507 : H12AffineFastState.Bounded env7507 := by
  intro p hp
  have h : env7507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7506_7507 : H12AffineEnvironment.transform 17 2080 env7506 = env7507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env7506 == env7507) = true)

theorem identity7507 : scanCanonicalize (H12AffineFastState.compose env7507 (packedSelected [1,3,4,5,8,9,11,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7507 : packedSelected [1,3,4,5,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env7508 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,8234,131072,2080,524288,8201,2097152,33,525328,35,8224,525377,2049,2253852,2126877,2081,1025,0,525396,0,2629709,512]

theorem envBound7508 : H12AffineFastState.Bounded env7508 := by
  intro p hp
  have h : env7508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7507_7508 : H12AffineEnvironment.transform 15 8234 env7507 = env7508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7507 == env7508) = true)

theorem identity7508 : scanCanonicalize (H12AffineFastState.compose env7508 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 3655) := by decide +kernel

theorem selectedBound7508 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7509 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,3655,16384,3662,3693,131072,2080,524288,3662,2097152,33,525328,35,3687,525377,2049,2247259,2120282,2081,1025,0,525396,0,2625034,512]

theorem envBound7509 : H12AffineFastState.Bounded env7509 := by
  intro p hp
  have h : env7509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7508_7509 : H12AffineEnvironment.transform 12 3655 env7508 = env7509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3655 env7508 == env7509) = true)

theorem identity7509 : scanCanonicalize (H12AffineFastState.compose env7509 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 544267) := by decide +kernel

theorem selectedBound7509 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7510 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,3655,16384,3662,3693,131072,2080,524288,3662,544267,33,525328,35,3687,525377,2049,656464,529489,2081,1025,0,525396,0,16385,512]

theorem envBound7510 : H12AffineFastState.Bounded env7510 := by
  intro p hp
  have h : env7510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7509_7510 : H12AffineEnvironment.transform 20 544267 env7509 = env7510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 544267 env7509 == env7510) = true)

theorem identity7510 : scanCanonicalize (H12AffineFastState.compose env7510 (packedSelected [0,2,4] rootPS)) = affineNative (2^(18+1) ^^^ 147540) := by decide +kernel

theorem selectedBound7510 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env7511 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,3655,16384,3662,3693,131072,2080,147540,3662,134751,33,148548,35,3687,148501,2049,17412,152581,2081,1025,0,148480,0,16385,512]

theorem envBound7511 : H12AffineFastState.Bounded env7511 := by
  intro p hp
  have h : env7511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7510_7511 : H12AffineEnvironment.transform 18 147540 env7510 = env7511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 147540 env7510 == env7511) = true)

theorem identity7511 : scanCanonicalize (H12AffineFastState.compose env7511 (packedSelected [1,5] rootPS)) = affineNative (2^(16+1) ^^^ 6667) := by decide +kernel

theorem selectedBound7511 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7512 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,3655,16384,3662,3693,6667,2080,23135,3662,5204,33,24143,35,3687,24094,2049,17412,19982,2081,1025,0,24075,0,16385,512]

theorem envBound7512 : H12AffineFastState.Bounded env7512 := by
  intro p hp
  have h : env7512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7511_7512 : H12AffineEnvironment.transform 16 6667 env7511 = env7512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6667 env7511 == env7512) = true)

theorem identity7512 : scanCanonicalize (H12AffineFastState.compose env7512 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound7512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7513 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,3655,7695,3662,3693,6667,2080,1104,3662,5204,33,64,35,3687,17,2049,6667,4097,2081,1025,0,4,0,7694,512]

theorem envBound7513 : H12AffineFastState.Bounded env7513 := by
  intro p hp
  have h : env7513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7512_7513 : H12AffineEnvironment.transform 13 7695 env7512 = env7513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env7512 == env7513) = true)

def env7514 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,524288,8540,2097152,4194304,525328,4268073,8225,67108864,4530218,268435456,268570625,2081,71827765,4194336,525568,0,34359738368,4268554]

theorem envBound7514 : H12AffineFastState.Bounded env7514 := by
  intro p hp
  have h : env7514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7500_7514 : H12AffineEnvironment.transform 6 41 env7500 = env7514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7500 == env7514) = true)

theorem identity7514 : scanCanonicalize (H12AffineFastState.compose env7514 (packedSelected [0,1,3,5,7,8,9,10,13,14,17,19,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 73738) := by decide +kernel

theorem selectedBound7514 : packedSelected [0,1,3,5,7,8,9,10,13,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env7515 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,524288,8540,2097152,73738,525328,35,8225,67108864,262176,268435456,268570625,2081,67707199,73770,525568,0,34359738368,512]

theorem envBound7515 : H12AffineFastState.Bounded env7515 := by
  intro p hp
  have h : env7515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7514_7515 : H12AffineEnvironment.transform 21 73738 env7514 = env7515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73738 env7514 == env7515) = true)

theorem identity7515 : scanCanonicalize (H12AffineFastState.compose env7515 (packedSelected [3,5,10] rootPS)) = affineNative (2^(27+1) ^^^ 69943587) := by decide +kernel

theorem selectedBound7515 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7516 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,524288,8540,2097152,73738,525328,35,8225,67108864,262176,69943587,69816610,2081,67707199,73770,525568,0,34359738368,512]

theorem envBound7516 : H12AffineFastState.Bounded env7516 := by
  intro p hp
  have h : env7516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7515_7516 : H12AffineEnvironment.transform 27 69943587 env7515 = env7516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 69943587 env7515 == env7516) = true)

theorem identity7516 : scanCanonicalize (H12AffineFastState.compose env7516 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound7516 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7517 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,73738,525328,35,8225,67108864,262176,69943414,69816439,2081,67706986,73770,525397,0,34359738368,512]

theorem envBound7517 : H12AffineFastState.Bounded env7517 := by
  intro p hp
  have h : env7517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7516_7517 : H12AffineEnvironment.transform 7 85 env7516 = env7517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7516 == env7517) = true)

theorem identity7517 : scanCanonicalize (H12AffineFastState.compose env7517 (packedSelected [1,8,19] rootPS)) = affineNative (2^(25+1) ^^^ 599146) := by decide +kernel

theorem selectedBound7517 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env7518 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,73738,525328,35,8225,599146,262176,2253852,2126877,2081,1024,73770,525397,0,34359738368,512]

theorem envBound7518 : H12AffineFastState.Bounded env7518 := by
  intro p hp
  have h : env7518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7517_7518 : H12AffineEnvironment.transform 25 599146 env7517 = env7518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 599146 env7517 == env7518) = true)

def env7519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,525329,4268161,8328,67108864,4530219,268435456,268570625,2081,71827765,4194440,525568,0,34359738368,4268707]

theorem envBound7519 : H12AffineFastState.Bounded env7519 := by
  intro p hp
  have h : env7519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7499_7519 : H12AffineEnvironment.transform 22 525329 env7499 = env7519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env7499 == env7519) = true)

theorem identity7519 : scanCanonicalize (H12AffineFastState.compose env7519 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7519 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env7520 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,525329,4268161,8328,67108864,4530219,268435456,268570625,2081,71827657,4194440,525564,0,34359738368,4268707]

theorem envBound7520 : H12AffineFastState.Bounded env7520 := by
  intro p hp
  have h : env7520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7519_7520 : H12AffineEnvironment.transform 7 252 env7519 = env7520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7519 == env7520) = true)

theorem identity7520 : scanCanonicalize (H12AffineFastState.compose env7520 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(34+1) ^^^ 273302744) := by decide +kernel

theorem selectedBound7520 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env7521 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,525329,4268161,8328,67108864,4530219,268435456,268570625,2081,71827657,4194440,525564,0,273302744,4268707]

theorem envBound7521 : H12AffineFastState.Bounded env7521 := by
  intro p hp
  have h : env7521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7520_7521 : H12AffineEnvironment.transform 34 273302744 env7520 = env7521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 273302744 env7520 == env7521) = true)

def env7522 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,525329,4268073,8224,67108864,4530219,268435456,268570625,2081,71827553,4194336,525396,0,273302640,4268555]

theorem envBound7522 : H12AffineFastState.Bounded env7522 := by
  intro p hp
  have h : env7522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7521_7522 : H12AffineEnvironment.transform 6 40 env7521 = env7522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7521 == env7522) = true)

theorem identity7522 : scanCanonicalize (H12AffineFastState.compose env7522 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 73739) := by decide +kernel

theorem selectedBound7522 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env7523 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,73739,525329,34,8224,67108864,262176,268435456,268570625,2081,67706986,73771,525396,0,269182075,512]

theorem envBound7523 : H12AffineFastState.Bounded env7523 := by
  intro p hp
  have h : env7523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7522_7523 : H12AffineEnvironment.transform 21 73739 env7522 = env7523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73739 env7522 == env7523) = true)

theorem identity7523 : scanCanonicalize (H12AffineFastState.compose env7523 (packedSelected [3,5,10] rootPS)) = affineNative (2^(25+1) ^^^ 2646108) := by decide +kernel

theorem selectedBound7523 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7524 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,73739,525329,34,8224,2646108,262176,268435456,268570625,2081,2179126,73771,525396,0,269182075,512]

theorem envBound7524 : H12AffineFastState.Bounded env7524 := by
  intro p hp
  have h : env7524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7523_7524 : H12AffineEnvironment.transform 25 2646108 env7523 = env7524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2646108 env7523 == env7524) = true)

theorem identity7524 : scanCanonicalize (H12AffineFastState.compose env7524 (packedSelected [1,8,19] rootPS)) = affineNative (2^(20+1) ^^^ 82998) := by decide +kernel

theorem selectedBound7524 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env7525 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,82998,73739,525329,34,8224,599146,262176,268435456,268570625,2081,1024,73771,525396,0,269182075,512]

theorem envBound7525 : H12AffineFastState.Bounded env7525 := by
  intro p hp
  have h : env7525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7524_7525 : H12AffineEnvironment.transform 20 82998 env7524 = env7525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82998 env7524 == env7525) = true)

def env7526 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,525329,4268072,8225,67108864,4530219,268435456,268570625,2081,71827552,4194337,525397,0,273302641,4268554]

theorem envBound7526 : H12AffineFastState.Bounded env7526 := by
  intro p hp
  have h : env7526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7521_7526 : H12AffineEnvironment.transform 6 41 env7521 = env7526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7521 == env7526) = true)

theorem identity7526 : scanCanonicalize (H12AffineFastState.compose env7526 (packedSelected [17,21] rootPS)) = affineNative (2^(25+1) ^^^ 4719713) := by decide +kernel

theorem selectedBound7526 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env7527 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,4194304,525329,4268072,8225,4719713,4530219,268435456,268570625,2081,1025,4194337,525397,0,273302641,4268554]

theorem envBound7527 : H12AffineFastState.Bounded env7527 := by
  intro p hp
  have h : env7527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7526_7527 : H12AffineEnvironment.transform 25 4719713 env7526 = env7527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 4719713 env7526 == env7527) = true)

theorem identity7527 : scanCanonicalize (H12AffineFastState.compose env7527 (packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 2122813) := by decide +kernel

theorem selectedBound7527 : packedSelected [0,1,3,5,7,8,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env7528 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,524288,8201,2097152,2122813,525329,2180117,8225,2646108,2442262,268435456,268570625,2081,1025,2122780,525397,0,271196236,2180663]

theorem envBound7528 : H12AffineFastState.Bounded env7528 := by
  intro p hp
  have h : env7528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7527_7528 : H12AffineEnvironment.transform 21 2122813 env7527 = env7528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122813 env7527 == env7528) = true)

theorem identity7528 : scanCanonicalize (H12AffineFastState.compose env7528 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound7528 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env7529 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,131072,2080,524288,8201,2097152,2122813,525329,2180117,8225,2646108,2182198,268435456,268570625,2081,1025,2122780,525397,0,271196236,2180663]

theorem envBound7529 : H12AffineFastState.Bounded env7529 := by
  intro p hp
  have h : env7529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7528_7529 : H12AffineEnvironment.transform 17 2080 env7528 = env7529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env7528 == env7529) = true)

theorem identity7529 : scanCanonicalize (H12AffineFastState.compose env7529 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 82999) := by decide +kernel

theorem selectedBound7529 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env7530 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8192,16384,8201,65536,131072,2080,524288,8201,82999,73738,525329,34,8225,599147,2049,268435456,268570625,2081,1025,73771,525397,0,269182075,512]

theorem envBound7530 : H12AffineFastState.Bounded env7530 := by
  intro p hp
  have h : env7530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7529_7530 : H12AffineEnvironment.transform 20 82999 env7529 = env7530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82999 env7529 == env7530) = true)

def env7531 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8,16384,1,65536,131072,2080,524288,1,82999,65538,525329,34,41,590947,2049,268435456,268570625,2081,1025,65571,525397,0,269173875,512]

theorem envBound7531 : H12AffineFastState.Bounded env7531 := by
  intro p hp
  have h : env7531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7530_7531 : H12AffineEnvironment.transform 12 8 env7530 = env7531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env7530 == env7531) = true)

theorem identity7531 : scanCanonicalize (H12AffineFastState.compose env7531 (packedSelected [1,2,3,5,6,8,11,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound7531 : packedSelected [1,2,3,5,6,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env7532 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,8,16384,1,35,131072,2080,524288,1,17428,33,525329,34,41,525376,2049,268435456,268570625,2081,1025,0,525397,0,269108304,512]

theorem envBound7532 : H12AffineFastState.Bounded env7532 := by
  intro p hp
  have h : env7532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7531_7532 : H12AffineEnvironment.transform 15 35 env7531 = env7532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env7531 == env7532) = true)

theorem identity7532 : scanCanonicalize (H12AffineFastState.compose env7532 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1614) := by decide +kernel

theorem selectedBound7532 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7533 : List Nat := [2,4,8,16,32,64,41,85,512,1024,1614,4096,8,16384,1,35,131072,1646,524288,1,17428,33,525329,34,41,525376,1615,268435456,268570625,1647,1025,0,525397,0,269108304,512]

theorem envBound7533 : H12AffineFastState.Bounded env7533 := by
  intro p hp
  have h : env7533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7532_7533 : H12AffineEnvironment.transform 10 1614 env7532 = env7533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1614 env7532 == env7533) = true)

theorem identity7533 : scanCanonicalize (H12AffineFastState.compose env7533 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 135189) := by decide +kernel

theorem selectedBound7533 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7534 : List Nat := [2,4,8,16,32,64,41,85,512,1024,1614,4096,8,16384,1,35,131072,1646,135189,1,17428,33,136196,34,41,136277,1615,268435456,268570625,1647,1025,0,136256,0,268457029,512]

theorem envBound7534 : H12AffineFastState.Bounded env7534 := by
  intro p hp
  have h : env7534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7533_7534 : H12AffineEnvironment.transform 18 135189 env7533 = env7534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 135189 env7533 == env7534) = true)

theorem identity7534 : scanCanonicalize (H12AffineFastState.compose env7534 (packedSelected [2,11] rootPS)) = affineNative (2^(27+1) ^^^ 17413) := by decide +kernel

theorem selectedBound7534 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env7535 : List Nat := [2,4,8,16,32,64,41,85,512,1024,1614,4096,8,16384,1,35,131072,1646,135189,1,17428,33,136196,34,41,136277,1615,17413,152580,1647,1025,0,136256,0,4160,512]

theorem envBound7535 : H12AffineFastState.Bounded env7535 := by
  intro p hp
  have h : env7535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7534_7535 : H12AffineEnvironment.transform 27 17413 env7534 = env7535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 17413 env7534 == env7535) = true)

theorem identity7535 : scanCanonicalize (H12AffineFastState.compose env7535 (packedSelected [5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound7535 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env7536 : List Nat := [2,4,8,16,32,64,41,85,512,1024,1614,4096,8,4161,1,35,131072,1646,135189,1,5205,33,136196,34,41,136277,1615,5188,132165,1647,1025,0,136256,0,4160,512]

theorem envBound7536 : H12AffineFastState.Bounded env7536 := by
  intro p hp
  have h : env7536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7535_7536 : H12AffineEnvironment.transform 13 4161 env7535 = env7536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env7535 == env7536) = true)

def env7537 : List Nat := [2,4,8,16,32,64,41,85,512,52,634,4096,8,4161,1,35,131072,602,135189,1,4193,33,135216,34,41,135265,635,4208,131185,603,53,0,135284,0,4160,512]

theorem envBound7537 : H12AffineFastState.Bounded env7537 := by
  intro p hp
  have h : env7537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7536_7537 : H12AffineEnvironment.transform 9 52 env7536 = env7537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env7536 == env7537) = true)

def env7538 : List Nat := [2,4,8,16,32,64,41,85,512,53,635,4096,8,4161,1,35,131072,603,135189,1,4192,33,135217,34,41,135264,634,4209,131184,602,52,0,135285,0,4160,512]

theorem envBound7538 : H12AffineFastState.Bounded env7538 := by
  intro p hp
  have h : env7538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7536_7538 : H12AffineEnvironment.transform 9 53 env7536 = env7538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env7536 == env7538) = true)

theorem identity7538 : scanCanonicalize (H12AffineFastState.compose env7538 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound7538 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7539 : List Nat := [2,4,8,16,32,64,41,85,512,53,635,587,8,522,1,35,131072,603,131678,1,555,33,131706,34,41,131627,634,570,131184,602,52,0,131646,0,523,512]

theorem envBound7539 : H12AffineFastState.Bounded env7539 := by
  intro p hp
  have h : env7539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7538_7539 : H12AffineEnvironment.transform 11 587 env7538 = env7539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env7538 == env7539) = true)

def env7540 : List Nat := [2,4,8,16,32,48,41,37,512,53,523,571,8,522,1,35,131072,555,131630,1,555,33,131594,34,41,131627,522,570,131072,554,52,0,131646,0,523,512]

theorem envBound7540 : H12AffineFastState.Bounded env7540 := by
  intro p hp
  have h : env7540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7539_7540 : H12AffineEnvironment.transform 5 48 env7539 = env7540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7539 == env7540) = true)

theorem identity7540 : scanCanonicalize (H12AffineFastState.compose env7540 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound7540 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7541 : List Nat := [2,4,8,16,32,48,41,37,44,53,39,23,8,38,1,35,131072,7,131074,1,7,33,131110,34,41,131079,38,22,131072,6,52,0,131090,0,39,44]

theorem envBound7541 : H12AffineFastState.Bounded env7541 := by
  intro p hp
  have h : env7541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7540_7541 : H12AffineEnvironment.transform 8 44 env7540 = env7541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env7540 == env7541) = true)

def leafEnv7541 : List Nat := [2,4,8,16,32,48,41,37,44,53,39,23,8,38,1,35,131072,7,131074,1,7,33,131110,34,131074,41,1,131079,38,22,131072,6,52,0,131090,0,131122,3,39,44,1,6,0]

def active7541 : List Nat := [0,1,2,3,4,16]

def tree7541 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7541 : H12WitnessSearch.Good tree7541 := H12GlobalWitnessIndex.good

theorem leafIdentity7541 : H12AffineFastState.composeSystem env7541 rootObs = leafEnv7541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7541 rootObs == leafEnv7541) = true)

theorem terminalChecked7541 : H12PackedTerminal.terminalCheckFast leafEnv7541 active7541 tree7541 = true := by decide +kernel

def env7542 : List Nat := [2,4,8,16,32,49,41,36,512,53,522,570,8,522,1,35,131072,554,131631,1,555,33,131595,34,41,131627,523,570,131073,555,52,0,131646,0,523,512]

theorem envBound7542 : H12AffineFastState.Bounded env7542 := by
  intro p hp
  have h : env7542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7539_7542 : H12AffineEnvironment.transform 5 49 env7539 = env7542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7539 == env7542) = true)

theorem identity7542 : scanCanonicalize (H12AffineFastState.compose env7542 (packedSelected [0] rootPS)) = affineNative (2^(16+1) ^^^ 22) := by decide +kernel

theorem selectedBound7542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7543 : List Nat := [2,4,8,16,32,49,41,36,512,53,522,570,8,522,1,35,22,554,569,1,555,33,541,34,41,573,523,570,23,555,52,0,552,0,523,512]

theorem envBound7543 : H12AffineFastState.Bounded env7543 := by
  intro p hp
  have h : env7543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7542_7543 : H12AffineEnvironment.transform 16 22 env7542 = env7543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 22 env7542 == env7543) = true)

def leafEnv7543 : List Nat := [2,4,8,16,32,49,41,36,512,53,522,570,8,522,1,35,22,554,569,1,555,33,541,34,569,41,1,573,523,570,23,555,52,0,552,0,521,3,523,512,1,554,0]

def active7543 : List Nat := [0,1,2,3,4,8]

def tree7543 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7543 : H12WitnessSearch.Good tree7543 := H12GlobalWitnessIndex.good

theorem leafIdentity7543 : H12AffineFastState.composeSystem env7543 rootObs = leafEnv7543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7543 rootObs == leafEnv7543) = true)

theorem terminalChecked7543 : H12PackedTerminal.terminalCheckFast leafEnv7543 active7543 tree7543 = true := by decide +kernel

def env7544 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,9,16384,0,65536,131072,2080,524288,0,82999,65539,525329,34,40,590946,2049,268435456,268570625,2081,1025,65570,525397,0,269173874,512]

theorem envBound7544 : H12AffineFastState.Bounded env7544 := by
  intro p hp
  have h : env7544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7530_7544 : H12AffineEnvironment.transform 12 9 env7530 = env7544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env7530 == env7544) = true)

theorem identity7544 : scanCanonicalize (H12AffineFastState.compose env7544 (packedSelected [13] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound7544 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7545 : List Nat := [2,4,8,16,32,64,41,85,512,1024,2048,4096,9,16384,0,34,131072,2080,524288,0,17429,33,525329,34,40,525376,2049,268435456,268570625,2081,1025,0,525397,0,269108304,512]

theorem envBound7545 : H12AffineFastState.Bounded env7545 := by
  intro p hp
  have h : env7545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7544_7545 : H12AffineEnvironment.transform 15 34 env7544 = env7545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env7544 == env7545) = true)

theorem identity7545 : scanCanonicalize (H12AffineFastState.compose env7545 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1615) := by decide +kernel

theorem selectedBound7545 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7546 : List Nat := [2,4,8,16,32,64,41,85,512,1024,1615,4096,9,16384,0,34,131072,1647,524288,0,17429,33,525329,34,40,525376,1614,268435456,268570625,1646,1025,0,525397,0,269108304,512]

theorem envBound7546 : H12AffineFastState.Bounded env7546 := by
  intro p hp
  have h : env7546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7545_7546 : H12AffineEnvironment.transform 10 1615 env7545 = env7546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1615 env7545 == env7546) = true)

theorem identity7546 : scanCanonicalize (H12AffineFastState.compose env7546 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 135188) := by decide +kernel

theorem selectedBound7546 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7547 : List Nat := [2,4,8,16,32,64,41,85,512,1024,1615,4096,9,16384,0,34,131072,1647,135188,0,17429,33,136197,34,40,136276,1614,268435456,268570625,1646,1025,0,136257,0,268457028,512]

theorem envBound7547 : H12AffineFastState.Bounded env7547 := by
  intro p hp
  have h : env7547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7546_7547 : H12AffineEnvironment.transform 18 135188 env7546 = env7547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 135188 env7546 == env7547) = true)

theorem identity7547 : scanCanonicalize (H12AffineFastState.compose env7547 (packedSelected [2,11] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound7547 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env7548 : List Nat := [2,4,8,16,32,64,41,85,512,1024,1615,4096,9,4160,0,34,131072,1647,135188,0,5205,33,136197,34,40,136276,1614,268435456,268570625,1646,1025,0,136257,0,268436484,512]

theorem envBound7548 : H12AffineFastState.Bounded env7548 := by
  intro p hp
  have h : env7548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7547_7548 : H12AffineEnvironment.transform 13 4160 env7547 = env7548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env7547 == env7548) = true)

theorem identity7548 : scanCanonicalize (H12AffineFastState.compose env7548 (packedSelected [2,18] rootPS)) = affineNative (2^(27+1) ^^^ 5189) := by decide +kernel

theorem selectedBound7548 : packedSelected [2,18] rootPS < 2^1333 := by decide +kernel

def env7549 : List Nat := [2,4,8,16,32,64,41,85,512,1024,1615,4096,9,4160,0,34,131072,1647,135188,0,5205,33,136197,34,40,136276,1614,5189,132164,1646,1025,0,136257,0,4161,512]

theorem envBound7549 : H12AffineFastState.Bounded env7549 := by
  intro p hp
  have h : env7549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7548_7549 : H12AffineEnvironment.transform 27 5189 env7548 = env7549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 5189 env7548 == env7549) = true)

def env7550 : List Nat := [2,4,8,16,32,64,41,85,512,52,635,4096,9,4160,0,34,131072,603,135188,0,4193,33,135217,34,40,135264,634,4209,131184,602,53,0,135285,0,4161,512]

theorem envBound7550 : H12AffineFastState.Bounded env7550 := by
  intro p hp
  have h : env7550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7549_7550 : H12AffineEnvironment.transform 9 52 env7549 = env7550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env7549 == env7550) = true)

theorem identity7550 : scanCanonicalize (H12AffineFastState.compose env7550 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 586) := by decide +kernel

theorem selectedBound7550 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7551 : List Nat := [2,4,8,16,32,64,41,85,512,52,635,586,9,522,0,34,131072,603,131678,0,555,33,131707,34,40,131626,634,571,131184,602,53,0,131647,0,523,512]

theorem envBound7551 : H12AffineFastState.Bounded env7551 := by
  intro p hp
  have h : env7551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7550_7551 : H12AffineEnvironment.transform 11 586 env7550 = env7551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 586 env7550 == env7551) = true)

def env7552 : List Nat := [2,4,8,16,32,48,41,37,512,52,523,570,9,522,0,34,131072,555,131630,0,555,33,131595,34,40,131626,522,571,131072,554,53,0,131647,0,523,512]

theorem envBound7552 : H12AffineFastState.Bounded env7552 := by
  intro p hp
  have h : env7552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7551_7552 : H12AffineEnvironment.transform 5 48 env7551 = env7552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7551 == env7552) = true)

theorem identity7552 : scanCanonicalize (H12AffineFastState.compose env7552 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound7552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7553 : List Nat := [2,4,8,16,32,48,41,37,44,52,39,22,9,38,0,34,131072,7,131074,0,7,33,131111,34,40,131078,38,23,131072,6,53,0,131091,0,39,44]

theorem envBound7553 : H12AffineFastState.Bounded env7553 := by
  intro p hp
  have h : env7553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7552_7553 : H12AffineEnvironment.transform 8 44 env7552 = env7553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env7552 == env7553) = true)

def leafEnv7553 : List Nat := [2,4,8,16,32,48,41,37,44,52,39,22,9,38,0,34,131072,7,131074,0,7,33,131111,34,131074,40,1,131078,38,23,131072,6,53,0,131091,0,131123,2,39,44,1,6,0]

def active7553 : List Nat := [0,1,2,3,4,16]

def tree7553 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7553 : H12WitnessSearch.Good tree7553 := H12GlobalWitnessIndex.good

theorem leafIdentity7553 : H12AffineFastState.composeSystem env7553 rootObs = leafEnv7553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7553 rootObs == leafEnv7553) = true)

theorem terminalChecked7553 : H12PackedTerminal.terminalCheckFast leafEnv7553 active7553 tree7553 = true := by decide +kernel

def env7554 : List Nat := [2,4,8,16,32,49,41,36,512,52,522,571,9,522,0,34,131072,554,131631,0,555,33,131594,34,40,131626,523,571,131073,555,53,0,131647,0,523,512]

theorem envBound7554 : H12AffineFastState.Bounded env7554 := by
  intro p hp
  have h : env7554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7551_7554 : H12AffineEnvironment.transform 5 49 env7551 = env7554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7551 == env7554) = true)

theorem identity7554 : scanCanonicalize (H12AffineFastState.compose env7554 (packedSelected [0] rootPS)) = affineNative (2^(16+1) ^^^ 22) := by decide +kernel

theorem selectedBound7554 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7555 : List Nat := [2,4,8,16,32,49,41,36,512,52,522,571,9,522,0,34,22,554,569,0,555,33,540,34,40,572,523,571,23,555,53,0,553,0,523,512]

theorem envBound7555 : H12AffineFastState.Bounded env7555 := by
  intro p hp
  have h : env7555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7554_7555 : H12AffineEnvironment.transform 16 22 env7554 = env7555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 22 env7554 == env7555) = true)

def leafEnv7555 : List Nat := [2,4,8,16,32,49,41,36,512,52,522,571,9,522,0,34,22,554,569,0,555,33,540,34,569,40,1,572,523,571,23,555,53,0,553,0,520,2,523,512,1,554,0]

def active7555 : List Nat := [0,1,2,3,4,8]

def tree7555 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7555 : H12WitnessSearch.Good tree7555 := H12GlobalWitnessIndex.good

theorem leafIdentity7555 : H12AffineFastState.composeSystem env7555 rootObs = leafEnv7555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7555 rootObs == leafEnv7555) = true)

theorem terminalChecked7555 : H12PackedTerminal.terminalCheckFast leafEnv7555 active7555 tree7555 = true := by decide +kernel

def env7556 : List Nat := [2,4,8,16,32,64,41,85,512,53,634,4096,9,4160,0,34,131072,602,135188,0,4192,33,135216,34,40,135265,635,4208,131185,603,52,0,135284,0,4161,512]

theorem envBound7556 : H12AffineFastState.Bounded env7556 := by
  intro p hp
  have h : env7556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7549_7556 : H12AffineEnvironment.transform 9 53 env7549 = env7556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env7549 == env7556) = true)

def env7557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,13182097,8328,67108864,13444155,268435456,268570625,2081,71827764,13108377,525568,0,34359738368,4268706]

theorem envBound7557 : H12AffineFastState.Bounded env7557 := by
  intro p hp
  have h : env7557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7498_7557 : H12AffineEnvironment.transform 23 13182097 env7498 = env7557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 13182097 env7498 == env7557) = true)

theorem identity7557 : scanCanonicalize (H12AffineFastState.compose env7557 (packedSelected [3,5,8,10,12,15,17,21,28,31,38,41] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound7557 : packedSelected [3,5,8,10,12,15,17,21,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env7558 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,8388608,13182097,8328,67108864,13444155,268435456,268570625,2081,71827657,13108377,525565,0,34359738368,4268706]

theorem envBound7558 : H12AffineFastState.Bounded env7558 := by
  intro p hp
  have h : env7558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7557_7558 : H12AffineEnvironment.transform 7 253 env7557 = env7558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7557 == env7558) = true)

def env7559 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,8388608,13182097,8328,8388688,13444155,268435456,268570625,2081,13107353,13108377,525565,0,34359738368,4268706]

theorem envBound7559 : H12AffineFastState.Bounded env7559 := by
  intro p hp
  have h : env7559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7558_7559 : H12AffineEnvironment.transform 25 8388688 env7558 = env7559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8388688 env7558 == env7559) = true)

theorem identity7559 : scanCanonicalize (H12AffineFastState.compose env7559 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(34+1) ^^^ 269182074) := by decide +kernel

theorem selectedBound7559 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env7560 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,8388608,13182097,8328,8388688,13444155,268435456,268570625,2081,13107353,13108377,525565,0,269182074,4268706]

theorem envBound7560 : H12AffineFastState.Bounded env7560 := by
  intro p hp
  have h : env7560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7559_7560 : H12AffineEnvironment.transform 34 269182074 env7559 = env7560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 269182074 env7559 == env7560) = true)

theorem identity7560 : scanCanonicalize (H12AffineFastState.compose env7560 (packedSelected [0,1,3,5,7,8,9,10,13,14,19,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound7560 : packedSelected [0,1,3,5,7,8,9,10,13,14,19,20,21,22] rootPS < 2^1333 := by decide +kernel

def env7561 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,73890,8388608,8913971,8328,8388688,9176217,268435456,268570625,2081,8986683,8987707,525565,0,269182074,512]

theorem envBound7561 : H12AffineFastState.Bounded env7561 := by
  intro p hp
  have h : env7561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7560_7561 : H12AffineEnvironment.transform 21 73890 env7560 = env7561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env7560 == env7561) = true)

theorem identity7561 : scanCanonicalize (H12AffineFastState.compose env7561 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound7561 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env7562 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8322,131072,262144,524288,8200,2097152,32,8388608,8913971,8328,8388688,9176217,268435456,268570625,2081,8913081,8914105,525565,0,269108472,512]

theorem envBound7562 : H12AffineFastState.Bounded env7562 := by
  intro p hp
  have h : env7562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7561_7562 : H12AffineEnvironment.transform 15 8322 env7561 = env7562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env7561 == env7562) = true)

theorem identity7562 : scanCanonicalize (H12AffineFastState.compose env7562 (packedSelected [13,17] rootPS)) = affineNative (2^(22+1) ^^^ 525497) := by decide +kernel

theorem selectedBound7562 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env7563 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8322,131072,262144,524288,8200,2097152,32,525497,138,8328,525545,262176,268435456,268570625,2081,1024,0,525565,0,269108472,512]

theorem envBound7563 : H12AffineFastState.Bounded env7563 := by
  intro p hp
  have h : env7563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7562_7563 : H12AffineEnvironment.transform 22 525497 env7562 = env7563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525497 env7562 == env7563) = true)

def env7564 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,8388608,13182097,8328,8388689,13444155,268435456,268570625,2081,13107352,13108377,525565,0,34359738368,4268706]

theorem envBound7564 : H12AffineFastState.Bounded env7564 := by
  intro p hp
  have h : env7564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7558_7564 : H12AffineEnvironment.transform 25 8388689 env7558 = env7564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8388689 env7558 == env7564) = true)

theorem identity7564 : scanCanonicalize (H12AffineFastState.compose env7564 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(27+1) ^^^ 4924506) := by decide +kernel

theorem selectedBound7564 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env7565 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,2097152,4194304,8388608,13182097,8328,8388689,13444155,4924506,4797531,2081,13107352,13108377,525565,0,34359738368,4268706]

theorem envBound7565 : H12AffineFastState.Bounded env7565 := by
  intro p hp
  have h : env7565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7564_7565 : H12AffineEnvironment.transform 27 4924506 env7564 = env7565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 4924506 env7564 == env7565) = true)

def env7566 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,941088,4194304,8388608,13182097,8328,8388689,13444155,4924506,4797531,2081,13107352,13108377,525565,0,34359738368,4268706]

theorem envBound7566 : H12AffineFastState.Bounded env7566 := by
  intro p hp
  have h : env7566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7565_7566 : H12AffineEnvironment.transform 20 941088 env7565 = env7566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 941088 env7565 == env7566) = true)

theorem identity7566 : scanCanonicalize (H12AffineFastState.compose env7566 (packedSelected [1,2,4,5,6,10,11,12,13,15,17,20,21,22,23,24,28] rootPS)) = affineNative (2^(34+1) ^^^ 13124761) := by decide +kernel

theorem selectedBound7566 : packedSelected [1,2,4,5,6,10,11,12,13,15,17,20,21,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env7567 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,941088,4194304,8388608,13182097,8328,8388689,13444155,4924506,4797531,2081,13107352,13108377,525565,0,13124761,4268706]

theorem envBound7567 : H12AffineFastState.Bounded env7567 := by
  intro p hp
  have h : env7567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7566_7567 : H12AffineEnvironment.transform 34 13124761 env7566 = env7567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 13124761 env7566 == env7567) = true)

theorem identity7567 : scanCanonicalize (H12AffineFastState.compose env7567 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,14,15,23] rootPS)) = affineNative (2^(22+1) ^^^ 525496) := by decide +kernel

theorem selectedBound7567 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env7568 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,941088,4194304,525496,4268073,8328,525545,4530307,4924506,4797531,2081,4195360,4194337,525565,0,4210721,4268706]

theorem envBound7568 : H12AffineFastState.Bounded env7568 := by
  intro p hp
  have h : env7568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7567_7568 : H12AffineEnvironment.transform 22 525496 env7567 = env7568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525496 env7567 == env7568) = true)

theorem identity7568 : scanCanonicalize (H12AffineFastState.compose env7568 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound7568 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env7569 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,941088,33,525496,73736,8328,525545,336034,730235,603258,2081,1025,0,525565,0,16384,74371]

theorem envBound7569 : H12AffineFastState.Bounded env7569 := by
  intro p hp
  have h : env7569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7568_7569 : H12AffineEnvironment.transform 21 33 env7568 = env7569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7568 == env7569) = true)

theorem identity7569 : scanCanonicalize (H12AffineFastState.compose env7569 (packedSelected [0,3,4,5,6,7,9,10,12,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound7569 : packedSelected [0,3,4,5,6,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env7570 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8323,131072,262144,524288,8200,941088,33,525496,139,8328,525545,262177,656632,529657,2081,1025,0,525565,0,16384,512]

theorem envBound7570 : H12AffineFastState.Bounded env7570 := by
  intro p hp
  have h : env7570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7569_7570 : H12AffineEnvironment.transform 15 8323 env7569 = env7570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env7569 == env7570) = true)

theorem identity7570 : scanCanonicalize (H12AffineFastState.compose env7570 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 16031) := by decide +kernel

theorem selectedBound7570 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env7571 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8323,16031,262144,524288,8200,811711,33,525496,139,8328,525545,262177,539239,529657,2081,1025,0,525565,0,16384,512]

theorem envBound7571 : H12AffineFastState.Bounded env7571 := by
  intro p hp
  have h : env7571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7570_7571 : H12AffineEnvironment.transform 16 16031 env7570 = env7571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16031 env7570 == env7571) = true)

def env7572 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,941089,4194304,8388608,13182097,8328,8388689,13444155,4924506,4797531,2081,13107352,13108377,525565,0,34359738368,4268706]

theorem envBound7572 : H12AffineFastState.Bounded env7572 := by
  intro p hp
  have h : env7572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7565_7572 : H12AffineEnvironment.transform 20 941089 env7565 = env7572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 941089 env7565 == env7572) = true)

theorem identity7572 : scanCanonicalize (H12AffineFastState.compose env7572 (packedSelected [1,2,4,5,6,10,11,12,13,15,17,20,21,22,23,24,28] rootPS)) = affineNative (2^(34+1) ^^^ 13198362) := by decide +kernel

theorem selectedBound7572 : packedSelected [1,2,4,5,6,10,11,12,13,15,17,20,21,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env7573 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,524288,8200,941089,4194304,8388608,13182097,8328,8388689,13444155,4924506,4797531,2081,13107352,13108377,525565,0,13198362,4268706]

theorem envBound7573 : H12AffineFastState.Bounded env7573 := by
  intro p hp
  have h : env7573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7572_7573 : H12AffineEnvironment.transform 34 13198362 env7572 = env7573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 13198362 env7572 == env7573) = true)

theorem identity7573 : scanCanonicalize (H12AffineFastState.compose env7573 (packedSelected [1,3,5,8,10,13,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound7573 : packedSelected [1,3,5,8,10,13,19,21] rootPS < 2^1333 := by decide +kernel

def env7574 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8323,131072,262144,524288,8200,941089,4194304,8388608,13108242,8328,8388689,13370552,4850905,4723928,2081,13107352,13108377,525565,0,13124761,4194849]

theorem envBound7574 : H12AffineFastState.Bounded env7574 := by
  intro p hp
  have h : env7574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7573_7574 : H12AffineEnvironment.transform 15 8323 env7573 = env7574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env7573 == env7574) = true)

theorem identity7574 : scanCanonicalize (H12AffineFastState.compose env7574 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(22+1) ^^^ 4719769) := by decide +kernel

theorem selectedBound7574 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env7575 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8323,131072,262144,524288,8200,941089,4194304,4719769,139,8328,4719816,262177,4850905,4723928,2081,1025,0,525565,0,16384,4194849]

theorem envBound7575 : H12AffineFastState.Bounded env7575 := by
  intro p hp
  have h : env7575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7574_7575 : H12AffineEnvironment.transform 22 4719769 env7574 = env7575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4719769 env7574 == env7575) = true)

theorem identity7575 : scanCanonicalize (H12AffineFastState.compose env7575 (packedSelected [0,4,6,7,9,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound7575 : packedSelected [0,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env7576 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8323,131072,262144,524288,8200,941089,33,525496,139,8328,525545,262177,656632,529657,2081,1025,0,525565,0,16384,512]

theorem envBound7576 : H12AffineFastState.Bounded env7576 := by
  intro p hp
  have h : env7576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7575_7576 : H12AffineEnvironment.transform 21 33 env7575 = env7576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7575 == env7576) = true)

theorem identity7576 : scanCanonicalize (H12AffineFastState.compose env7576 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 16030) := by decide +kernel

theorem selectedBound7576 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env7577 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8323,16030,262144,524288,8200,811711,33,525496,139,8328,525545,262177,539238,529657,2081,1025,0,525565,0,16384,512]

theorem envBound7577 : H12AffineFastState.Bounded env7577 := by
  intro p hp
  have h : env7577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7576_7577 : H12AffineEnvironment.transform 16 16030 env7576 = env7577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16030 env7576 == env7577) = true)

theorem identity7577 : scanCanonicalize (H12AffineFastState.compose env7577 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(18+1) ^^^ 10775) := by decide +kernel

theorem selectedBound7577 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env7578 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8323,16030,262144,10775,8200,280744,33,11951,139,8328,12030,262177,4209,16110,2081,1025,0,12010,0,16384,512]

theorem envBound7578 : H12AffineFastState.Bounded env7578 := by
  intro p hp
  have h : env7578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7577_7578 : H12AffineEnvironment.transform 18 10775 env7577 = env7578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 10775 env7577 == env7578) = true)

theorem identity7578 : scanCanonicalize (H12AffineFastState.compose env7578 (packedSelected [2,14] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound7578 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env7579 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,8323,16030,2081,10775,8200,16521,33,11951,139,8328,12030,2048,4209,16110,2081,1025,0,12010,0,16384,512]

theorem envBound7579 : H12AffineFastState.Bounded env7579 := by
  intro p hp
  have h : env7579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7578_7579 : H12AffineEnvironment.transform 17 2081 env7578 = env7579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env7578 == env7579) = true)

theorem identity7579 : scanCanonicalize (H12AffineFastState.compose env7579 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound7579 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7580 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5236,8200,8323,16030,2081,10775,8200,5373,33,11951,139,8328,12030,2048,4209,16110,2081,1025,0,12010,0,5236,512]

theorem envBound7580 : H12AffineFastState.Bounded env7580 := by
  intro p hp
  have h : env7580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7579_7580 : H12AffineEnvironment.transform 13 5236 env7579 = env7580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env7579 == env7580) = true)

theorem identity7580 : scanCanonicalize (H12AffineFastState.compose env7580 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound7580 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7581 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,6200,5236,6192,6331,1702,2081,4655,6192,5373,33,5783,139,6320,5830,2048,4209,1750,2081,1025,0,5842,0,5236,512]

theorem envBound7581 : H12AffineFastState.Bounded env7581 := by
  intro p hp
  have h : env7581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7580_7581 : H12AffineEnvironment.transform 12 6200 env7580 = env7581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env7580 == env7581) = true)

def env7582 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,6200,5236,6192,6163,1550,2081,4655,6192,5205,33,5695,35,6168,5742,2048,4209,1662,2081,1025,0,5754,0,5236,512]

theorem envBound7582 : H12AffineFastState.Bounded env7582 := by
  intro p hp
  have h : env7582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7581_7582 : H12AffineEnvironment.transform 6 40 env7581 = env7582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7581 == env7582) = true)

theorem identity7582 : scanCanonicalize (H12AffineFastState.compose env7582 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound7582 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7583 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,3188,1100,2048,1092,1127,1550,2081,3675,1092,2081,33,2635,35,1132,2586,2048,3077,1662,2081,1025,0,2574,0,2048,512]

theorem envBound7583 : H12AffineFastState.Bounded env7583 := by
  intro p hp
  have h : env7583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7582_7583 : H12AffineEnvironment.transform 11 3188 env7582 = env7583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env7582 == env7583) = true)

def env7584 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,6200,5236,6192,6162,1551,2081,4655,6192,5204,33,5694,34,6169,5743,2048,4209,1663,2081,1025,0,5755,0,5236,512]

theorem envBound7584 : H12AffineFastState.Bounded env7584 := by
  intro p hp
  have h : env7584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7581_7584 : H12AffineEnvironment.transform 6 41 env7581 = env7584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7581 == env7584) = true)

theorem identity7584 : scanCanonicalize (H12AffineFastState.compose env7584 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound7584 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7585 : List Nat := [2,4,8,16,32,64,41,84,512,1024,523,4096,4659,5236,4667,4633,1551,554,4655,4667,5204,33,5694,34,4626,5743,523,4209,1663,554,1025,0,5755,0,5236,512]

theorem envBound7585 : H12AffineFastState.Bounded env7585 := by
  intro p hp
  have h : env7585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7584_7585 : H12AffineEnvironment.transform 10 523 env7584 = env7585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env7584 == env7585) = true)

def env7586 : List Nat := [2,4,8,16,32,48,41,36,512,1024,523,4096,4659,5124,4667,4633,1551,554,4655,4667,5156,33,5694,34,4626,5663,523,4097,1551,554,1025,0,5643,0,5124,512]

theorem envBound7586 : H12AffineFastState.Bounded env7586 := by
  intro p hp
  have h : env7586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7585_7586 : H12AffineEnvironment.transform 5 48 env7585 = env7586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env7585 == env7586) = true)

theorem identity7586 : scanCanonicalize (H12AffineFastState.compose env7586 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 525) := by decide +kernel

theorem selectedBound7586 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7587 : List Nat := [2,4,8,16,32,48,41,36,512,1024,523,525,62,1545,54,20,1551,554,34,54,1577,33,1075,34,31,1042,523,524,1551,554,1025,0,1030,0,1545,512]

theorem envBound7587 : H12AffineFastState.Bounded env7587 := by
  intro p hp
  have h : env7587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7586_7587 : H12AffineEnvironment.transform 11 525 env7586 = env7587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 525 env7586 == env7587) = true)

def leafEnv7587 : List Nat := [2,4,8,16,32,48,41,36,512,1024,523,525,62,1545,54,20,1551,554,34,54,1577,33,1075,34,34,31,1,1042,523,524,1551,554,1025,0,1030,0,1063,52,1545,512,1,1577,0]

def active7587 : List Nat := [0,1,2,3,4,8,9]

def tree7587 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7587 : H12WitnessSearch.Good tree7587 := H12GlobalWitnessIndex.good

theorem leafIdentity7587 : H12AffineFastState.composeSystem env7587 rootObs = leafEnv7587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7587 rootObs == leafEnv7587) = true)

theorem terminalChecked7587 : H12PackedTerminal.terminalCheckFast leafEnv7587 active7587 tree7587 = true := by decide +kernel

def env7588 : List Nat := [2,4,8,16,32,49,41,37,512,1024,523,4096,4659,5125,4667,4633,1551,554,4655,4667,5157,33,5694,34,4626,5662,523,4096,1550,554,1025,0,5642,0,5125,512]

theorem envBound7588 : H12AffineFastState.Bounded env7588 := by
  intro p hp
  have h : env7588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7585_7588 : H12AffineEnvironment.transform 5 49 env7585 = env7588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7585 == env7588) = true)

theorem identity7588 : scanCanonicalize (H12AffineFastState.compose env7588 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound7588 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7589 : List Nat := [2,4,8,16,22,7,31,19,512,1024,523,4096,4613,5125,4621,4633,1551,540,4633,4621,5139,23,5640,20,4626,5662,523,4096,1550,540,1025,0,5642,0,5125,512]

theorem envBound7589 : H12AffineFastState.Bounded env7589 := by
  intro p hp
  have h : env7589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7588_7589 : H12AffineEnvironment.transform 4 22 env7588 = env7589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env7588 == env7589) = true)

def leafEnv7589 : List Nat := [2,4,8,16,22,7,31,19,512,1024,523,4096,4613,5125,4621,4633,1551,540,4633,4621,5139,23,5640,20,4633,4626,1,5662,523,4096,1550,540,1025,0,5642,0,5660,4623,5125,512,1,5139,0]

def active7589 : List Nat := [0,1,2,3,8,9,11]

def tree7589 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7589 : H12WitnessSearch.Good tree7589 := H12GlobalWitnessIndex.good

theorem leafIdentity7589 : H12AffineFastState.composeSystem env7589 rootObs = leafEnv7589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7589 rootObs == leafEnv7589) = true)

theorem terminalChecked7589 : H12PackedTerminal.terminalCheckFast leafEnv7589 active7589 tree7589 = true := by decide +kernel

def env7590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,1073741824,2147483648,3309906204,525568,1073743904,34359738368,25733063]

theorem envBound7590 : H12AffineFastState.Bounded env7590 := by
  intro p hp
  have h : env7590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6667_7590 : H12AffineEnvironment.transform 24 8329 env6667 = env7590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env6667 == env7590) = true)

theorem identity7590 : scanCanonicalize (H12AffineFastState.compose env7590 (packedSelected [6,25] rootPS)) = affineNative (2^(30+1) ^^^ 1283820763) := by decide +kernel

theorem selectedBound7590 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env7591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,1073741824,1283820763,164406727,525568,1073743904,34359738368,25733063]

theorem envBound7591 : H12AffineFastState.Bounded env7591 := by
  intro p hp
  have h : env7591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7590_7591 : H12AffineEnvironment.transform 30 1283820763 env7590 = env7591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 1283820763 env7590 == env7591) = true)

theorem identity7591 : scanCanonicalize (H12AffineFastState.compose env7591 (packedSelected [3,5,24,34] rootPS)) = affineNative (2^(29+1) ^^^ 956700811) := by decide +kernel

theorem selectedBound7591 : packedSelected [3,5,24,34] rootPS < 2^1333 := by decide +kernel

def env7592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,956700811,897815632,164406727,525568,956698795,34359738368,25733063]

theorem envBound7592 : H12AffineFastState.Bounded env7592 := by
  intro p hp
  have h : env7592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7591_7592 : H12AffineEnvironment.transform 29 956700811 env7591 = env7592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 956700811 env7591 == env7592) = true)

def env7593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,268570624,151259275,92374096,164406727,525568,151257259,34359738368,25733063]

theorem envBound7593 : H12AffineFastState.Bounded env7593 := by
  intro p hp
  have h : env7593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7592_7593 : H12AffineEnvironment.transform 28 268570624 env7592 = env7593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570624 env7592 == env7593) = true)

def env7594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,268570625,151259274,92374097,164406727,525568,151257258,34359738368,25733063]

theorem envBound7594 : H12AffineFastState.Bounded env7594 := by
  intro p hp
  have h : env7594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7592_7594 : H12AffineEnvironment.transform 28 268570625 env7592 = env7594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env7592 == env7594) = true)

theorem identity7594 : scanCanonicalize (H12AffineFastState.compose env7594 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(22+1) ^^^ 660496) := by decide +kernel

theorem selectedBound7594 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env7595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,660496,16777216,8329,67108864,134217728,268435456,268570625,151259274,84643905,155627991,525568,151257258,34359738368,16954327]

theorem envBound7595 : H12AffineFastState.Bounded env7595 := by
  intro p hp
  have h : env7595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7594_7595 : H12AffineEnvironment.transform 22 660496 env7594 = env7595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 660496 env7594 == env7595) = true)

def env7596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,525804,16777216,8329,67108864,134217728,268435456,268435965,151259274,84509117,155492395,525568,151257258,34359738368,16818731]

theorem envBound7596 : H12AffineFastState.Bounded env7596 := by
  intro p hp
  have h : env7596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7595_7596 : H12AffineEnvironment.transform 16 4604 env7595 = env7596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4604 env7595 == env7596) = true)

theorem identity7596 : scanCanonicalize (H12AffineFastState.compose env7596 (packedSelected [5,8,12,13,15,17,24,26,28,31,38,41] rootPS)) = affineNative (2^(34+1) ^^^ 73441596) := by decide +kernel

theorem selectedBound7596 : packedSelected [5,8,12,13,15,17,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env7597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,525804,16777216,8329,67108864,134217728,268435456,268435965,151259274,84509117,155492395,525568,151257258,73441596,16818731]

theorem envBound7597 : H12AffineFastState.Bounded env7597 := by
  intro p hp
  have h : env7597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7596_7597 : H12AffineEnvironment.transform 34 73441596 env7596 = env7597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 73441596 env7596 == env7597) = true)

def env7598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,16777216,8329,67108864,134217728,268435456,268435965,151259274,84484169,155451871,525568,151257258,73400520,16778207]

theorem envBound7598 : H12AffineFastState.Bounded env7598 := by
  intro p hp
  have h : env7598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7597_7598 : H12AffineEnvironment.transform 14 8692 env7597 = env7598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env7597 == env7598) = true)

def env7599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,16777216,8329,67108864,134217728,138678440,138678613,151259274,84484169,155451871,525568,151257258,73400520,16778207]

theorem envBound7599 : H12AffineFastState.Bounded env7599 := by
  intro p hp
  have h : env7599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7598_7599 : H12AffineEnvironment.transform 27 138678440 env7598 = env7599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 138678440 env7598 == env7599) = true)

theorem identity7599 : scanCanonicalize (H12AffineFastState.compose env7599 (packedSelected [9,14,22] rootPS)) = affineNative (2^(26+1) ^^^ 71571417) := by decide +kernel

theorem selectedBound7599 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env7600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,16777216,8329,67108864,71571417,67110769,67110540,88088403,84484169,83891718,525568,88086387,73400520,16778207]

theorem envBound7600 : H12AffineFastState.Bounded env7600 := by
  intro p hp
  have h : env7600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7599_7600 : H12AffineEnvironment.transform 26 71571417 env7599 = env7600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 71571417 env7599 == env7600) = true)

def env7601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,524288,8692,2097152,4194304,525804,16777216,8329,17375308,21837717,17377085,17376960,4800287,5,603722,525568,4798271,23666820,16778207]

theorem envBound7601 : H12AffineFastState.Bounded env7601 := by
  intro p hp
  have h : env7601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7600_7601 : H12AffineEnvironment.transform 25 17375308 env7600 = env7601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17375308 env7600 == env7601) = true)

def env7602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5016,8692,2097152,4194304,5748,16777216,8329,16856020,21308429,16856229,16856408,4271239,5,75218,5784,4269223,23147292,16778207]

theorem envBound7602 : H12AffineFastState.Bounded env7602 := by
  intro p hp
  have h : env7602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7601_7602 : H12AffineEnvironment.transform 18 5016 env7601 = env7602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5016 env7601 == env7602) = true)

def env7603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5016,8692,2097152,32,5748,16777216,8329,16856020,17114157,16856229,16856408,76967,5,75218,5784,74887,18953020,16778207]

theorem envBound7603 : H12AffineFastState.Bounded env7603 := by
  intro p hp
  have h : env7603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7602_7603 : H12AffineEnvironment.transform 21 32 env7602 = env7603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7602 == env7603) = true)

theorem identity7603 : scanCanonicalize (H12AffineFastState.compose env7603 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(23+1) ^^^ 2383463) := by decide +kernel

theorem selectedBound7603 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5016,8692,2097152,32,5748,2383463,8329,2452915,2193994,2452162,2452287,76967,5,75218,5784,74887,355675,2383288]

theorem envBound7604 : H12AffineFastState.Bounded env7604 := by
  intro p hp
  have h : env7604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7603_7604 : H12AffineEnvironment.transform 23 2383463 env7603 = env7604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2383463 env7603 == env7604) = true)

def env7605 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,65536,4264,262144,4812,8352,2097152,32,5748,2383463,8329,2452711,2193994,2452162,2452075,76967,5,74886,5784,74887,355343,2383084]

theorem envBound7605 : H12AffineFastState.Bounded env7605 := by
  intro p hp
  have h : env7605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7604_7605 : H12AffineEnvironment.transform 7 84 env7604 = env7605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7604 == env7605) = true)

theorem identity7605 : scanCanonicalize (H12AffineFastState.compose env7605 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7605 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7606 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,8234,4264,262144,4812,8352,2097152,32,5748,2383463,8329,2378957,2120288,2378472,2378305,3213,5,1196,5784,1197,281637,2383084]

theorem envBound7606 : H12AffineFastState.Bounded env7606 := by
  intro p hp
  have h : env7606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7605_7606 : H12AffineEnvironment.transform 15 8234 env7605 = env7606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7605 == env7606) = true)

theorem identity7606 : scanCanonicalize (H12AffineFastState.compose env7606 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 286277) := by decide +kernel

theorem selectedBound7606 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7607 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,8234,4264,262144,4812,8352,286277,32,5748,34,8329,4744,263205,5293,5124,3213,5,1196,5784,1197,281637,681]

theorem envBound7607 : H12AffineFastState.Bounded env7607 := by
  intro p hp
  have h : env7607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7606_7607 : H12AffineEnvironment.transform 20 286277 env7606 = env7607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286277 env7606 == env7607) = true)

theorem identity7607 : scanCanonicalize (H12AffineFastState.compose env7607 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 6856) := by decide +kernel

theorem selectedBound7607 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7608 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,8234,4264,6856,4812,8352,17549,32,5748,34,8329,4744,7917,5293,5124,3213,5,1196,5784,1197,22253,681]

theorem envBound7608 : H12AffineFastState.Bounded env7608 := by
  intro p hp
  have h : env7608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7607_7608 : H12AffineEnvironment.transform 17 6856 env7607 = env7608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6856 env7607 == env7608) = true)

theorem identity7608 : scanCanonicalize (H12AffineFastState.compose env7608 (packedSelected [0,2,3,5,6,9,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 664) := by decide +kernel

theorem selectedBound7608 : packedSelected [0,2,3,5,6,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env7609 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,664,8192,16384,8352,8234,560,2128,84,8352,17549,32,1260,34,8329,16,3189,1589,1692,3213,5,1196,1024,1197,17525,681]

theorem envBound7609 : H12AffineFastState.Bounded env7609 := by
  intro p hp
  have h : env7609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7608_7609 : H12AffineEnvironment.transform 11 664 env7608 = env7609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 664 env7608 == env7609) = true)

theorem identity7609 : scanCanonicalize (H12AffineFastState.compose env7609 (packedSelected [2,3,4,5,6,7,11,13,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7609 : packedSelected [2,3,4,5,6,7,11,13,14,15] rootPS < 2^1333 := by decide +kernel

def env7610 : List Nat := [2,4,8,16,32,49,128,37,512,1024,2048,664,8192,16384,8352,8234,560,2081,37,8352,17549,32,1181,34,8329,16,3076,1589,1692,3213,5,1196,1024,1197,17412,681]

theorem envBound7610 : H12AffineFastState.Bounded env7610 := by
  intro p hp
  have h : env7610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7609_7610 : H12AffineEnvironment.transform 5 49 env7609 = env7610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7609 == env7610) = true)

theorem identity7610 : scanCanonicalize (H12AffineFastState.compose env7610 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7610 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env7611 : List Nat := [2,4,8,16,32,49,128,37,512,4,2048,664,8192,16384,8352,8234,560,2081,37,8352,16521,32,153,34,8329,16,2048,561,664,2185,5,168,4,169,16384,681]

theorem envBound7611 : H12AffineFastState.Bounded env7611 := by
  intro p hp
  have h : env7611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7610_7611 : H12AffineEnvironment.transform 9 4 env7610 = env7611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7610 == env7611) = true)

theorem identity7611 : scanCanonicalize (H12AffineFastState.compose env7611 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2730) := by decide +kernel

theorem selectedBound7611 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env7612 : List Nat := [2,4,8,16,32,49,128,37,512,4,2048,664,2730,16384,2570,2688,560,2081,37,2570,16521,32,153,34,2595,16,2048,561,664,2185,5,168,4,169,16384,681]

theorem envBound7612 : H12AffineFastState.Bounded env7612 := by
  intro p hp
  have h : env7612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7611_7612 : H12AffineEnvironment.transform 12 2730 env7611 = env7612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2730 env7611 == env7612) = true)

theorem identity7612 : scanCanonicalize (H12AffineFastState.compose env7612 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound7612 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env7613 : List Nat := [2,4,8,16,32,49,128,37,512,4,522,664,160,16384,0,138,560,555,37,0,16521,32,153,34,41,16,522,561,664,643,5,168,4,169,16384,681]

theorem envBound7613 : H12AffineFastState.Bounded env7613 := by
  intro p hp
  have h : env7613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7612_7613 : H12AffineEnvironment.transform 10 522 env7612 = env7613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env7612 == env7613) = true)

theorem identity7613 : scanCanonicalize (H12AffineFastState.compose env7613 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound7613 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env7614 : List Nat := [2,4,8,16,26,11,128,31,512,4,522,664,154,16384,0,138,522,529,31,0,16521,26,153,24,19,16,522,523,664,643,5,146,4,147,16384,659]

theorem envBound7614 : H12AffineFastState.Bounded env7614 := by
  intro p hp
  have h : env7614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7613_7614 : H12AffineEnvironment.transform 4 26 env7613 = env7614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env7613 == env7614) = true)

theorem identity7614 : scanCanonicalize (H12AffineFastState.compose env7614 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound7614 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env7615 : List Nat := [2,4,8,16,26,11,19,31,512,4,522,523,9,16384,0,25,522,529,31,0,16410,26,10,24,19,16,522,523,523,528,5,1,4,0,16384,512]

theorem envBound7615 : H12AffineFastState.Bounded env7615 := by
  intro p hp
  have h : env7615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7614_7615 : H12AffineEnvironment.transform 6 19 env7614 = env7615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env7614 == env7615) = true)

theorem identity7615 : scanCanonicalize (H12AffineFastState.compose env7615 (packedSelected [0,1] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound7615 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env7616 : List Nat := [2,4,8,16,26,11,19,31,512,4,522,523,9,513,0,25,522,529,31,0,539,26,10,24,19,16,522,523,523,528,5,1,4,0,513,512]

theorem envBound7616 : H12AffineFastState.Bounded env7616 := by
  intro p hp
  have h : env7616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7615_7616 : H12AffineEnvironment.transform 13 513 env7615 = env7616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env7615 == env7616) = true)

theorem identity7616 : scanCanonicalize (H12AffineFastState.compose env7616 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound7616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7617 : List Nat := [2,4,8,16,26,11,19,31,26,4,16,17,9,27,0,25,16,11,31,0,1,26,10,24,19,16,16,17,17,10,5,1,4,0,27,26]

theorem envBound7617 : H12AffineFastState.Bounded env7617 := by
  intro p hp
  have h : env7617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7616_7617 : H12AffineEnvironment.transform 8 26 env7616 = env7617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env7616 == env7617) = true)

def leafEnv7617 : List Nat := [2,4,8,16,26,11,19,31,26,4,16,17,9,27,0,25,16,11,31,0,1,26,10,24,30,19,1,16,16,17,17,10,5,1,4,0,31,2,27,26,1,0,0]

def active7617 : List Nat := [0,1,2,3]

def tree7617 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7617 : H12WitnessSearch.Good tree7617 := H12GlobalWitnessIndex.good

theorem leafIdentity7617 : H12AffineFastState.composeSystem env7617 rootObs = leafEnv7617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7617 rootObs == leafEnv7617) = true)

theorem terminalChecked7617 : H12PackedTerminal.terminalCheckFast leafEnv7617 active7617 tree7617 = true := by decide +kernel

def env7618 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8353,65536,4265,262144,4813,8353,2097152,32,5748,2383463,8329,2452710,2193994,2452162,2452074,76967,5,74887,5784,74887,355342,2383085]

theorem envBound7618 : H12AffineFastState.Bounded env7618 := by
  intro p hp
  have h : env7618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7604_7618 : H12AffineEnvironment.transform 7 85 env7604 = env7618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7604 == env7618) = true)

theorem identity7618 : scanCanonicalize (H12AffineFastState.compose env7618 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound7618 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7619 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,4709,8201,2097152,32,5748,2383463,8225,2452558,2193994,2452074,2452074,76815,5,74799,5680,74799,355342,2382917]

theorem envBound7619 : H12AffineFastState.Bounded env7619 := by
  intro p hp
  have h : env7619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7618_7619 : H12AffineEnvironment.transform 6 40 env7618 = env7619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7618 == env7619) = true)

theorem identity7619 : scanCanonicalize (H12AffineFastState.compose env7619 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 360046) := by decide +kernel

theorem selectedBound7619 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7620 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,4709,8201,360046,32,5748,73737,8225,4640,263204,5124,5124,76815,5,74799,5680,74799,355342,74283]

theorem envBound7620 : H12AffineFastState.Bounded env7620 := by
  intro p hp
  have h : env7620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7619_7620 : H12AffineEnvironment.transform 20 360046 env7619 = env7620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360046 env7619 == env7620) = true)

theorem identity7620 : scanCanonicalize (H12AffineFastState.compose env7620 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7620 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7621 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,8235,4097,262144,4709,8201,286277,32,5748,34,8225,4640,263204,5124,5124,3108,5,1028,5680,1028,281637,512]

theorem envBound7621 : H12AffineFastState.Bounded env7621 := by
  intro p hp
  have h : env7621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7620_7621 : H12AffineEnvironment.transform 15 8235 env7620 = env7621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7620 == env7621) = true)

theorem identity7621 : scanCanonicalize (H12AffineFastState.compose env7621 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound7621 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7622 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,2081,8201,8235,4097,262144,4709,8201,267876,32,5748,34,8225,4640,263204,5124,5124,3108,5,1028,5680,1028,263172,512]

theorem envBound7622 : H12AffineFastState.Bounded env7622 := by
  intro p hp
  have h : env7622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7621_7622 : H12AffineEnvironment.transform 13 2081 env7621 = env7622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env7621 == env7622) = true)

theorem identity7622 : scanCanonicalize (H12AffineFastState.compose env7622 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound7622 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7623 : List Nat := [2,4,8,16,32,64,40,85,512,5,2048,4096,8192,2081,8201,8235,4097,262144,4709,8201,266849,32,4721,34,8225,4640,262177,4097,4097,2081,5,1,4661,1,262145,512]

theorem envBound7623 : H12AffineFastState.Bounded env7623 := by
  intro p hp
  have h : env7623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7622_7623 : H12AffineEnvironment.transform 9 5 env7622 = env7623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env7622 == env7623) = true)

theorem identity7623 : scanCanonicalize (H12AffineFastState.compose env7623 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(17+1) ^^^ 2107) := by decide +kernel

theorem selectedBound7623 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7624 : List Nat := [2,4,8,16,32,64,40,85,512,5,2048,4096,8192,2081,8201,8235,4097,2107,4709,8201,6746,32,4721,34,8225,4640,2074,4097,4097,2081,5,1,4661,1,2106,512]

theorem envBound7624 : H12AffineFastState.Bounded env7624 := by
  intro p hp
  have h : env7624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7623_7624 : H12AffineEnvironment.transform 17 2107 env7623 = env7624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2107 env7623 == env7624) = true)

def env7625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5016,8692,2097152,33,5748,16777216,8329,16856020,17114156,16856229,16856408,76966,5,75218,5784,74886,18953021,16778207]

theorem envBound7625 : H12AffineFastState.Bounded env7625 := by
  intro p hp
  have h : env7625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7602_7625 : H12AffineEnvironment.transform 21 33 env7602 = env7625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7602 == env7625) = true)

theorem identity7625 : scanCanonicalize (H12AffineFastState.compose env7625 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(23+1) ^^^ 2383666) := by decide +kernel

theorem selectedBound7625 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5016,8692,2097152,33,5748,2383666,8329,2452710,2194206,2452375,2452074,76966,5,75218,5784,74886,355343,2383085]

theorem envBound7626 : H12AffineFastState.Bounded env7626 := by
  intro p hp
  have h : env7626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7625_7626 : H12AffineEnvironment.transform 23 2383666 env7625 = env7626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2383666 env7625 == env7626) = true)

def env7627 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,65536,4264,262144,4812,8352,2097152,33,5748,2383462,8329,2452710,2193994,2452163,2452074,76966,5,74886,5784,74886,355343,2383085]

theorem envBound7627 : H12AffineFastState.Bounded env7627 := by
  intro p hp
  have h : env7627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7626_7627 : H12AffineEnvironment.transform 7 84 env7626 = env7627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7626 == env7627) = true)

theorem identity7627 : scanCanonicalize (H12AffineFastState.compose env7627 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7627 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7628 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,4709,8201,2097152,33,5748,2383462,8224,2452559,2193994,2452074,2452074,76815,5,74799,5681,74799,355343,2382916]

theorem envBound7628 : H12AffineFastState.Bounded env7628 := by
  intro p hp
  have h : env7628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7627_7628 : H12AffineEnvironment.transform 6 41 env7627 = env7628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7627 == env7628) = true)

theorem identity7628 : scanCanonicalize (H12AffineFastState.compose env7628 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 360046) := by decide +kernel

theorem selectedBound7628 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7629 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,4709,8201,360046,33,5748,73736,8224,4641,263204,5124,5124,76815,5,74799,5681,74799,355343,74282]

theorem envBound7629 : H12AffineFastState.Bounded env7629 := by
  intro p hp
  have h : env7629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7628_7629 : H12AffineEnvironment.transform 20 360046 env7628 = env7629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360046 env7628 == env7629) = true)

theorem identity7629 : scanCanonicalize (H12AffineFastState.compose env7629 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7629 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7630 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,8234,4097,262144,4709,8201,286276,33,5748,34,8224,4641,263204,5124,5124,3109,5,1029,5681,1029,281637,512]

theorem envBound7630 : H12AffineFastState.Bounded env7630 := by
  intro p hp
  have h : env7630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7629_7630 : H12AffineEnvironment.transform 15 8234 env7629 = env7630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7629 == env7630) = true)

theorem identity7630 : scanCanonicalize (H12AffineFastState.compose env7630 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 30221) := by decide +kernel

theorem selectedBound7630 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7631 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,16384,8201,8234,4097,30221,4709,8201,10313,33,5748,34,8224,4641,29225,5124,5124,3109,5,1029,5681,1029,14888,512]

theorem envBound7631 : H12AffineFastState.Bounded env7631 := by
  intro p hp
  have h : env7631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7630_7631 : H12AffineEnvironment.transform 17 30221 env7630 = env7631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30221 env7630 == env7631) = true)

theorem identity7631 : scanCanonicalize (H12AffineFastState.compose env7631 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 10265) := by decide +kernel

theorem selectedBound7631 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7632 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,10265,8201,8234,4097,7700,4709,8201,10313,33,5748,34,8224,4641,6704,5124,5124,3109,5,1029,5681,1029,14888,512]

theorem envBound7632 : H12AffineFastState.Bounded env7632 := by
  intro p hp
  have h : env7632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7631_7632 : H12AffineEnvironment.transform 13 10265 env7631 = env7632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10265 env7631 == env7632) = true)

theorem identity7632 : scanCanonicalize (H12AffineFastState.compose env7632 (packedSelected [0,1,5,7,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound7632 : packedSelected [0,1,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env7633 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,561,8192,10265,8201,8234,560,3109,84,8201,10313,33,1093,34,8224,16,2049,1589,1589,3109,5,1029,1024,1029,10265,512]

theorem envBound7633 : H12AffineFastState.Bounded env7633 := by
  intro p hp
  have h : env7633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7632_7633 : H12AffineEnvironment.transform 11 561 env7632 = env7633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env7632 == env7633) = true)

theorem identity7633 : scanCanonicalize (H12AffineFastState.compose env7633 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound7633 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env7634 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,561,2168,97,2161,2130,560,3109,84,2161,49,33,1093,34,2136,16,2049,1589,1589,3109,5,1029,1024,1029,97,512]

theorem envBound7634 : H12AffineFastState.Bounded env7634 := by
  intro p hp
  have h : env7634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7633_7634 : H12AffineEnvironment.transform 12 2168 env7633 = env7634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env7633 == env7634) = true)

theorem identity7634 : scanCanonicalize (H12AffineFastState.compose env7634 (packedSelected [1,3,14] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7634 : packedSelected [1,3,14] rootPS < 2^1333 := by decide +kernel

def env7635 : List Nat := [2,4,8,16,32,64,41,84,512,4,2048,561,2168,97,2161,2130,560,2081,84,2161,49,33,65,34,2136,16,2049,561,561,2081,5,1,4,1,97,512]

theorem envBound7635 : H12AffineFastState.Bounded env7635 := by
  intro p hp
  have h : env7635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7634_7635 : H12AffineEnvironment.transform 9 4 env7634 = env7635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7634 == env7635) = true)

theorem identity7635 : scanCanonicalize (H12AffineFastState.compose env7635 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound7635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7636 : List Nat := [2,4,8,16,32,27,41,15,512,4,2048,561,2083,58,2090,2057,560,2081,15,2090,49,33,26,34,2051,16,2049,561,561,2081,5,1,4,1,58,512]

theorem envBound7636 : H12AffineFastState.Bounded env7636 := by
  intro p hp
  have h : env7636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7635_7636 : H12AffineEnvironment.transform 5 27 env7635 = env7636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env7635 == env7636) = true)

theorem identity7636 : scanCanonicalize (H12AffineFastState.compose env7636 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound7636 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7637 : List Nat := [2,4,8,16,32,27,41,15,17,4,2048,32,2083,58,2090,2057,33,2081,15,2090,49,33,26,34,2051,16,2049,32,32,2081,5,1,4,1,58,17]

theorem envBound7637 : H12AffineFastState.Bounded env7637 := by
  intro p hp
  have h : env7637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7636_7637 : H12AffineEnvironment.transform 8 17 env7636 = env7637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env7636 == env7637) = true)

def env7638 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8353,65536,4265,262144,4813,8353,2097152,33,5748,2383463,8329,2452710,2193995,2452162,2452074,76966,5,74887,5784,74886,355343,2383085]

theorem envBound7638 : H12AffineFastState.Bounded env7638 := by
  intro p hp
  have h : env7638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7626_7638 : H12AffineEnvironment.transform 7 85 env7626 = env7638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7626 == env7638) = true)

theorem identity7638 : scanCanonicalize (H12AffineFastState.compose env7638 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7638 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7639 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8353,8235,4265,262144,4813,8353,2097152,33,5748,2383463,8329,2378957,2120288,2378473,2378305,3213,5,1196,5784,1197,281636,2383085]

theorem envBound7639 : H12AffineFastState.Bounded env7639 := by
  intro p hp
  have h : env7639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7638_7639 : H12AffineEnvironment.transform 15 8235 env7638 = env7639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7638 == env7639) = true)

theorem identity7639 : scanCanonicalize (H12AffineFastState.compose env7639 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 286277) := by decide +kernel

theorem selectedBound7639 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7640 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8353,8235,4265,262144,4813,8353,286277,33,5748,34,8329,4744,263205,5292,5124,3213,5,1196,5784,1197,281636,680]

theorem envBound7640 : H12AffineFastState.Bounded env7640 := by
  intro p hp
  have h : env7640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7639_7640 : H12AffineEnvironment.transform 20 286277 env7639 = env7640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 286277 env7639 == env7640) = true)

theorem identity7640 : scanCanonicalize (H12AffineFastState.compose env7640 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 7884) := by decide +kernel

theorem selectedBound7640 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7641 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8353,8235,4265,7884,4813,8353,16521,33,5748,34,8329,4744,6889,5292,5124,3213,5,1196,5784,1197,21224,680]

theorem envBound7641 : H12AffineFastState.Bounded env7641 := by
  intro p hp
  have h : env7641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7640_7641 : H12AffineEnvironment.transform 17 7884 env7640 = env7641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7884 env7640 == env7641) = true)

theorem identity7641 : scanCanonicalize (H12AffineFastState.compose env7641 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound7641 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env7642 : List Nat := [2,4,8,16,32,64,128,85,512,172,2048,4096,8192,16384,8353,8235,4265,6752,4813,8353,16521,33,4824,34,8329,4744,6889,4096,4264,2081,5,0,4660,1,21224,680]

theorem envBound7642 : H12AffineFastState.Bounded env7642 := by
  intro p hp
  have h : env7642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7641_7642 : H12AffineEnvironment.transform 9 172 env7641 = env7642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env7641 == env7642) = true)

theorem identity7642 : scanCanonicalize (H12AffineFastState.compose env7642 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 171) := by decide +kernel

theorem selectedBound7642 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env7643 : List Nat := [2,4,8,16,32,64,128,85,512,172,2048,4096,171,16384,10,128,4265,6752,4813,10,16521,33,4824,34,34,4744,6889,4096,4264,2081,5,0,4660,1,21224,680]

theorem envBound7643 : H12AffineFastState.Bounded env7643 := by
  intro p hp
  have h : env7643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7642_7643 : H12AffineEnvironment.transform 12 171 env7642 = env7643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 171 env7642 == env7643) = true)

theorem identity7643 : scanCanonicalize (H12AffineFastState.compose env7643 (packedSelected [3,4,5,6,7,13] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound7643 : packedSelected [3,4,5,6,7,13] rootPS < 2^1333 := by decide +kernel

def env7644 : List Nat := [2,4,8,16,32,64,128,85,512,172,2048,4096,171,512,10,128,4265,6752,4813,10,649,33,4824,34,34,4744,6889,4096,4264,2081,5,0,4660,1,4328,680]

theorem envBound7644 : H12AffineFastState.Bounded env7644 := by
  intro p hp
  have h : env7644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7643_7644 : H12AffineEnvironment.transform 13 512 env7643 = env7644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env7643 == env7644) = true)

theorem identity7644 : scanCanonicalize (H12AffineFastState.compose env7644 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound7644 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7645 : List Nat := [2,4,8,16,32,64,88,85,512,116,2048,4096,115,512,10,88,4209,6752,4629,10,593,33,4608,34,34,4688,6705,4096,4208,2081,5,0,4660,1,4144,624]

theorem envBound7645 : H12AffineFastState.Bounded env7645 := by
  intro p hp
  have h : env7645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7644_7645 : H12AffineEnvironment.transform 6 88 env7644 = env7645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env7644 == env7645) = true)

theorem identity7645 : scanCanonicalize (H12AffineFastState.compose env7645 (packedSelected [11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7645 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env7646 : List Nat := [2,4,8,16,32,49,41,36,512,5,2048,4096,2,512,10,41,4096,6673,4629,10,544,33,4608,34,34,4641,6705,4096,4097,2081,5,0,4660,1,4144,513]

theorem envBound7646 : H12AffineFastState.Bounded env7646 := by
  intro p hp
  have h : env7646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7645_7646 : H12AffineEnvironment.transform 5 49 env7645 = env7646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7645 == env7646) = true)

theorem identity7646 : scanCanonicalize (H12AffineFastState.compose env7646 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 570) := by decide +kernel

theorem selectedBound7646 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7647 : List Nat := [2,4,8,16,32,49,41,36,512,5,570,4096,2,512,10,41,4096,4139,4629,10,544,33,4608,34,34,4641,4107,4096,4097,539,5,0,4660,1,4144,513]

theorem envBound7647 : H12AffineFastState.Bounded env7647 := by
  intro p hp
  have h : env7647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7646_7647 : H12AffineEnvironment.transform 10 570 env7646 = env7647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 570 env7646 == env7647) = true)

theorem identity7647 : scanCanonicalize (H12AffineFastState.compose env7647 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound7647 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env7648 : List Nat := [2,4,8,16,32,49,41,36,512,5,570,539,2,512,10,41,539,560,14,10,544,33,27,34,34,58,528,539,538,539,5,0,47,1,555,513]

theorem envBound7648 : H12AffineFastState.Bounded env7648 := by
  intro p hp
  have h : env7648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7647_7648 : H12AffineEnvironment.transform 11 539 env7647 = env7648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env7647 == env7648) = true)

theorem identity7648 : scanCanonicalize (H12AffineFastState.compose env7648 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound7648 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env7649 : List Nat := [2,4,8,16,10,27,3,14,512,5,528,539,2,512,10,3,539,538,14,10,522,11,27,8,8,16,528,539,538,539,5,0,5,1,513,513]

theorem envBound7649 : H12AffineFastState.Bounded env7649 := by
  intro p hp
  have h : env7649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7648_7649 : H12AffineEnvironment.transform 4 10 env7648 = env7649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env7648 == env7649) = true)

theorem identity7649 : scanCanonicalize (H12AffineFastState.compose env7649 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound7649 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7650 : List Nat := [2,4,8,16,10,27,3,14,1,5,17,26,2,1,10,3,26,27,14,10,11,11,27,8,8,16,17,26,27,26,5,0,5,1,0,0]

theorem envBound7650 : H12AffineFastState.Bounded env7650 := by
  intro p hp
  have h : env7650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7649_7650 : H12AffineEnvironment.transform 8 1 env7649 = env7650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env7649 == env7650) = true)

theorem identity7650 : scanCanonicalize (H12AffineFastState.compose env7650 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound7650 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7651 : List Nat := [2,4,8,15,10,4,3,14,1,5,14,5,2,1,10,3,5,4,14,10,11,11,4,8,8,15,14,5,4,5,5,0,5,1,0,0]

theorem envBound7651 : H12AffineFastState.Bounded env7651 := by
  intro p hp
  have h : env7651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7650_7651 : H12AffineEnvironment.transform 3 15 env7650 = env7651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env7650 == env7651) = true)

theorem identity7651 : scanCanonicalize (H12AffineFastState.compose env7651 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound7651 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7652 : List Nat := [2,0,8,11,10,0,3,10,1,1,10,1,2,1,10,3,1,0,10,10,11,11,0,8,8,11,10,1,0,1,1,0,1,1,0,0]

theorem envBound7652 : H12AffineFastState.Bounded env7652 := by
  intro p hp
  have h : env7652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7651_7652 : H12AffineEnvironment.transform 1 0 env7651 = env7652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env7651 == env7652) = true)

theorem identity7652 : scanCanonicalize (H12AffineFastState.compose env7652 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound7652 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env7653 : List Nat := [2,0,3,0,1,0,3,1,1,1,1,1,2,1,1,3,1,0,1,1,0,0,0,3,3,0,1,1,0,1,1,0,1,1,0,0]

theorem envBound7653 : H12AffineFastState.Bounded env7653 := by
  intro p hp
  have h : env7653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7652_7653 : H12AffineEnvironment.transform 2 3 env7652 = env7653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env7652 == env7653) = true)

def env7654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5017,8692,2097152,4194304,5749,16777216,8329,16856021,21308428,16856228,16856409,4271238,5,75219,5785,4269222,23147293,16778207]

theorem envBound7654 : H12AffineFastState.Bounded env7654 := by
  intro p hp
  have h : env7654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7601_7654 : H12AffineEnvironment.transform 18 5017 env7601 = env7654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5017 env7601 == env7654) = true)

def env7655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5017,8692,2097152,32,5749,16777216,8329,16856021,17114156,16856228,16856409,76966,5,75219,5785,74886,18953021,16778207]

theorem envBound7655 : H12AffineFastState.Bounded env7655 := by
  intro p hp
  have h : env7655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7654_7655 : H12AffineEnvironment.transform 21 32 env7654 = env7655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env7654 == env7655) = true)

theorem identity7655 : scanCanonicalize (H12AffineFastState.compose env7655 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 360250) := by decide +kernel

theorem selectedBound7655 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5017,8692,360250,32,5749,16777216,8329,16856021,17114156,16856228,16856409,76966,5,75219,5785,74886,17058823,16778207]

theorem envBound7656 : H12AffineFastState.Bounded env7656 := by
  intro p hp
  have h : env7656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7655_7656 : H12AffineEnvironment.transform 20 360250 env7655 = env7656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 360250 env7655 == env7656) = true)

def env7657 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,65536,4264,262144,4813,8352,360046,32,5749,16777216,8329,16855681,17114156,16856228,16856077,76966,5,74887,5785,74886,17058823,16777867]

theorem envBound7657 : H12AffineFastState.Bounded env7657 := by
  intro p hp
  have h : env7657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7656_7657 : H12AffineEnvironment.transform 7 84 env7656 = env7657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env7656 == env7657) = true)

theorem identity7657 : scanCanonicalize (H12AffineFastState.compose env7657 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound7657 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7658 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,8235,4264,262144,4813,8352,286277,32,5749,16777216,8329,16781994,17040391,16782479,16782374,3213,5,1196,5785,1197,17058823,16777867]

theorem envBound7658 : H12AffineFastState.Bounded env7658 := by
  intro p hp
  have h : env7658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7657_7658 : H12AffineEnvironment.transform 15 8235 env7657 = env7658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env7657 == env7658) = true)

theorem identity7658 : scanCanonicalize (H12AffineFastState.compose env7658 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 34) := by decide +kernel

theorem selectedBound7658 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7659 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,8235,4264,262144,4813,8352,286277,32,5749,34,8329,4744,263205,5293,5124,3213,5,1196,5785,1197,281637,681]

theorem envBound7659 : H12AffineFastState.Bounded env7659 := by
  intro p hp
  have h : env7659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7658_7659 : H12AffineEnvironment.transform 23 34 env7658 = env7659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34 env7658 == env7659) = true)

theorem identity7659 : scanCanonicalize (H12AffineFastState.compose env7659 (packedSelected [11,12,13,15,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 6752) := by decide +kernel

theorem selectedBound7659 : packedSelected [11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env7660 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,16384,8352,8235,4264,6752,4813,8352,17445,32,5749,34,8329,4744,7749,5293,5124,3213,5,1196,5785,1197,22085,681]

theorem envBound7660 : H12AffineFastState.Bounded env7660 := by
  intro p hp
  have h : env7660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7659_7660 : H12AffineEnvironment.transform 17 6752 env7659 = env7660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6752 env7659 == env7660) = true)

theorem identity7660 : scanCanonicalize (H12AffineFastState.compose env7660 (packedSelected [2,3,4,5,6,7,11,14,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound7660 : packedSelected [2,3,4,5,6,7,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env7661 : List Nat := [2,4,8,16,32,64,128,84,512,221,2048,4096,8192,16384,8352,8235,4264,6752,4813,8352,16632,32,4776,34,8329,4744,6808,4208,4313,2128,5,113,4676,112,21144,681]

theorem envBound7661 : H12AffineFastState.Bounded env7661 := by
  intro p hp
  have h : env7661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7660_7661 : H12AffineEnvironment.transform 9 221 env7660 = env7661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env7660 == env7661) = true)

theorem identity7661 : scanCanonicalize (H12AffineFastState.compose env7661 (packedSelected [13,21] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound7661 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env7662 : List Nat := [2,4,8,16,32,49,128,37,512,172,2048,4096,8192,16384,8352,8235,4264,6673,4796,8352,16521,32,4776,34,8329,4744,6808,4097,4264,2081,5,0,4661,1,21144,681]

theorem envBound7662 : H12AffineFastState.Bounded env7662 := by
  intro p hp
  have h : env7662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7661_7662 : H12AffineEnvironment.transform 5 49 env7661 = env7662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env7661 == env7662) = true)

theorem identity7662 : scanCanonicalize (H12AffineFastState.compose env7662 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound7662 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env7663 : List Nat := [2,4,8,16,26,11,128,31,512,150,2048,4096,8192,16384,8346,8209,4242,6673,4742,8346,16521,26,4754,24,8329,4744,6808,4097,4242,2075,5,0,4623,1,21144,659]

theorem envBound7663 : H12AffineFastState.Bounded env7663 := by
  intro p hp
  have h : env7663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7662_7663 : H12AffineEnvironment.transform 4 26 env7662 = env7663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env7662 == env7663) = true)

theorem identity7663 : scanCanonicalize (H12AffineFastState.compose env7663 (packedSelected [3,4,5,6,7,13] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound7663 : packedSelected [3,4,5,6,7,13] rootPS < 2^1333 := by decide +kernel

def env7664 : List Nat := [2,4,8,16,26,11,128,31,512,150,2048,4096,8192,513,8346,8209,4242,6673,4742,8346,648,26,4754,24,8329,4744,6808,4097,4242,2075,5,0,4623,1,4249,659]

theorem envBound7664 : H12AffineFastState.Bounded env7664 := by
  intro p hp
  have h : env7664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7663_7664 : H12AffineEnvironment.transform 13 513 env7663 = env7664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env7663 == env7664) = true)

theorem identity7664 : scanCanonicalize (H12AffineFastState.compose env7664 (packedSelected [2,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound7664 : packedSelected [2,11,14,23] rootPS < 2^1333 := by decide +kernel

def env7665 : List Nat := [2,4,8,16,26,11,128,31,512,150,2048,665,8192,513,8346,8209,523,2184,31,8346,648,26,11,24,8329,17,2049,664,523,2075,5,0,150,1,512,659]

theorem envBound7665 : H12AffineFastState.Bounded env7665 := by
  intro p hp
  have h : env7665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7664_7665 : H12AffineEnvironment.transform 11 665 env7664 = env7665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env7664 == env7665) = true)

theorem identity7665 : scanCanonicalize (H12AffineFastState.compose env7665 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 154) := by decide +kernel

theorem selectedBound7665 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env7666 : List Nat := [2,4,8,16,26,11,128,31,512,150,2048,665,154,513,0,139,523,2184,31,0,648,26,11,24,19,17,2049,664,523,2075,5,0,150,1,512,659]

theorem envBound7666 : H12AffineFastState.Bounded env7666 := by
  intro p hp
  have h : env7666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7665_7666 : H12AffineEnvironment.transform 12 154 env7665 = env7666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 154 env7665 == env7666) = true)

theorem identity7666 : scanCanonicalize (H12AffineFastState.compose env7666 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 664) := by decide +kernel

theorem selectedBound7666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7667 : List Nat := [2,4,8,16,26,11,128,31,512,150,664,665,154,513,0,139,523,528,31,0,648,26,11,24,19,17,665,664,523,643,5,0,150,1,512,659]

theorem envBound7667 : H12AffineFastState.Bounded env7667 := by
  intro p hp
  have h : env7667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7666_7667 : H12AffineEnvironment.transform 10 664 env7666 = env7667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 664 env7666 == env7667) = true)

theorem identity7667 : scanCanonicalize (H12AffineFastState.compose env7667 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound7667 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env7668 : List Nat := [2,4,8,16,26,11,19,31,512,5,523,522,9,513,0,24,523,528,31,0,539,26,11,24,19,17,522,523,523,528,5,0,5,1,512,512]

theorem envBound7668 : H12AffineFastState.Bounded env7668 := by
  intro p hp
  have h : env7668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7667_7668 : H12AffineEnvironment.transform 6 19 env7667 = env7668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env7667 == env7668) = true)

theorem identity7668 : scanCanonicalize (H12AffineFastState.compose env7668 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound7668 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7669 : List Nat := [2,4,8,16,26,11,19,31,26,5,17,16,9,27,0,24,17,10,31,0,1,26,11,24,19,17,16,17,17,10,5,0,5,1,26,26]

theorem envBound7669 : H12AffineFastState.Bounded env7669 := by
  intro p hp
  have h : env7669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7668_7669 : H12AffineEnvironment.transform 8 26 env7668 = env7669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env7668 == env7669) = true)

def leafEnv7669 : List Nat := [2,4,8,16,26,11,19,31,26,5,17,16,9,27,0,24,17,10,31,0,1,26,11,24,31,19,1,17,16,17,17,10,5,0,5,1,30,3,26,26,1,1,0]

def active7669 : List Nat := [0,1,2,3]

def tree7669 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7669 : H12WitnessSearch.Good tree7669 := H12GlobalWitnessIndex.good

theorem leafIdentity7669 : H12AffineFastState.composeSystem env7669 rootObs = leafEnv7669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7669 rootObs == leafEnv7669) = true)

theorem terminalChecked7669 : H12PackedTerminal.terminalCheckFast leafEnv7669 active7669 tree7669 = true := by decide +kernel

def env7670 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,16384,8353,65536,4265,262144,4812,8353,360047,32,5749,16777216,8329,16855680,17114156,16856228,16856076,76966,5,74886,5785,74886,17058823,16777866]

theorem envBound7670 : H12AffineFastState.Bounded env7670 := by
  intro p hp
  have h : env7670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7656_7670 : H12AffineEnvironment.transform 7 85 env7656 = env7670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env7656 == env7670) = true)

theorem identity7670 : scanCanonicalize (H12AffineFastState.compose env7670 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound7670 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env7671 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,4708,8201,360047,32,5749,16777216,8225,16855592,17114156,16856076,16856076,76814,5,74798,5681,74798,17058823,16777762]

theorem envBound7671 : H12AffineFastState.Bounded env7671 := by
  intro p hp
  have h : env7671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7670_7671 : H12AffineEnvironment.transform 6 40 env7670 = env7671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7670 == env7671) = true)

theorem identity7671 : scanCanonicalize (H12AffineFastState.compose env7671 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(23+1) ^^^ 73736) := by decide +kernel

theorem selectedBound7671 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7672 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,65536,4097,262144,4708,8201,360047,32,5749,73736,8225,4640,263204,5124,5124,76814,5,74798,5681,74798,355343,74282]

theorem envBound7672 : H12AffineFastState.Bounded env7672 := by
  intro p hp
  have h : env7672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7671_7672 : H12AffineEnvironment.transform 23 73736 env7671 = env7672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73736 env7671 == env7672) = true)

theorem identity7672 : scanCanonicalize (H12AffineFastState.compose env7672 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound7672 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7673 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,16384,8201,8234,4097,262144,4708,8201,286277,32,5749,34,8225,4640,263204,5124,5124,3108,5,1028,5681,1028,281637,512]

theorem envBound7673 : H12AffineFastState.Bounded env7673 := by
  intro p hp
  have h : env7673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7672_7673 : H12AffineEnvironment.transform 15 8234 env7672 = env7673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env7672 == env7673) = true)

theorem identity7673 : scanCanonicalize (H12AffineFastState.compose env7673 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 7780) := by decide +kernel

theorem selectedBound7673 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env7674 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,8192,7780,8201,8234,4097,262144,4708,8201,262177,32,5749,34,8225,4640,263204,5124,5124,3108,5,1028,5681,1028,266817,512]

theorem envBound7674 : H12AffineFastState.Bounded env7674 := by
  intro p hp
  have h : env7674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7673_7674 : H12AffineEnvironment.transform 13 7780 env7673 = env7674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7780 env7673 == env7674) = true)

theorem identity7674 : scanCanonicalize (H12AffineFastState.compose env7674 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound7674 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7675 : List Nat := [2,4,8,16,32,64,40,85,512,4,2048,4096,8192,6752,8201,8234,4097,262144,4708,8201,262177,32,4721,34,8225,4640,262176,4096,4096,2080,5,0,4661,0,266817,512]

theorem envBound7675 : H12AffineFastState.Bounded env7675 := by
  intro p hp
  have h : env7675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7674_7675 : H12AffineEnvironment.transform 9 4 env7674 = env7675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env7674 == env7675) = true)

theorem identity7675 : scanCanonicalize (H12AffineFastState.compose env7675 (packedSelected [0,4] rootPS)) = affineNative (2^(17+1) ^^^ 6778) := by decide +kernel

theorem selectedBound7675 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7676 : List Nat := [2,4,8,16,32,64,40,85,512,4,2048,4096,8192,6752,8201,8234,4097,6778,4708,8201,6747,32,4721,34,8225,4640,6746,4096,4096,2080,5,0,4661,0,2107,512]

theorem envBound7676 : H12AffineFastState.Bounded env7676 := by
  intro p hp
  have h : env7676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7675_7676 : H12AffineEnvironment.transform 17 6778 env7675 = env7676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6778 env7675 == env7676) = true)

theorem identity7676 : scanCanonicalize (H12AffineFastState.compose env7676 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound7676 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env7677 : List Nat := [2,4,8,16,32,43,40,62,512,4,2048,4096,8192,6667,8201,8234,4097,6673,4623,8201,6704,32,4634,34,8225,4640,6705,4096,4096,2080,5,0,4661,0,2107,512]

theorem envBound7677 : H12AffineFastState.Bounded env7677 := by
  intro p hp
  have h : env7677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7676_7677 : H12AffineEnvironment.transform 5 43 env7676 = env7677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env7676 == env7677) = true)

def env7678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5017,8692,2097152,33,5749,16777216,8329,16856021,17114157,16856228,16856409,76967,5,75219,5785,74887,18953020,16778207]

theorem envBound7678 : H12AffineFastState.Bounded env7678 := by
  intro p hp
  have h : env7678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7654_7678 : H12AffineEnvironment.transform 21 33 env7654 = env7678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env7654 == env7678) = true)

theorem identity7678 : scanCanonicalize (H12AffineFastState.compose env7678 (packedSelected [0,7,11,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 360047) := by decide +kernel

theorem selectedBound7678 : packedSelected [0,7,11,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env7679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,4604,262144,5017,8692,360047,33,5749,16777216,8329,16856021,17114157,16856228,16856409,76967,5,75219,5785,74887,17059155,16778207]

end H12CloudChart0