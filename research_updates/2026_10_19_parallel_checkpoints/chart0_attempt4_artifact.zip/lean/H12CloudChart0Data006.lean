import H12CloudChart0Data005

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans1455_1456 : H12AffineEnvironment.transform 15 8575 env1455 = env1456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env1455 == env1456) = true)

def env1457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,16384,8692,65536,16892,262144,1025,8692,2097152,292,445,16777216,8328,493,262436,16384,16,2080,16852468,0,257,0,16892,16778126]

theorem envBound1457 : H12AffineFastState.Bounded env1457 := by
  intro p hp
  have h : env1457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1454_1457 : H12AffineEnvironment.transform 11 493 env1454 = env1457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env1454 == env1457) = true)

theorem identity1457 : scanCanonicalize (H12AffineFastState.compose env1457 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 73969) := by decide +kernel

theorem selectedBound1457 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,16384,8692,65536,16892,262144,1025,8692,2097152,292,445,73969,8328,493,262436,16384,16,2080,1285,0,257,0,16892,74623]

theorem envBound1458 : H12AffineFastState.Bounded env1458 := by
  intro p hp
  have h : env1458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1457_1458 : H12AffineEnvironment.transform 23 73969 env1457 = env1458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73969 env1457 == env1458) = true)

theorem identity1458 : scanCanonicalize (H12AffineFastState.compose env1458 (packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2524) := by decide +kernel

theorem selectedBound1458 : packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env1459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,16384,8692,65536,16892,2524,1025,8692,2097152,292,445,73969,8328,493,2296,16384,16,2080,1285,0,257,0,16892,74623]

theorem envBound1459 : H12AffineFastState.Bounded env1459 := by
  intro p hp
  have h : env1459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1458_1459 : H12AffineEnvironment.transform 17 2524 env1458 = env1459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2524 env1458 == env1459) = true)

theorem identity1459 : scanCanonicalize (H12AffineFastState.compose env1459 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1459 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env1460 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8432,65536,16632,2264,1025,8432,2097152,32,185,73969,8328,233,2296,16384,16,2080,1025,0,5,0,16632,74363]

theorem envBound1460 : H12AffineFastState.Bounded env1460 := by
  intro p hp
  have h : env1460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1459_1460 : H12AffineEnvironment.transform 7 4 env1459 = env1460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1459 == env1460) = true)

theorem identity1460 : scanCanonicalize (H12AffineFastState.compose env1460 (packedSelected [2,6,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound1460 : packedSelected [2,6,11,15,17] rootPS < 2^1333 := by decide +kernel

def env1461 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8432,8314,16632,2264,1025,8432,2097152,32,185,139,8328,233,2296,16384,16,2080,1025,0,5,0,16632,513]

theorem envBound1461 : H12AffineFastState.Bounded env1461 := by
  intro p hp
  have h : env1461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1460_1461 : H12AffineEnvironment.transform 15 8314 env1460 = env1461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env1460 == env1461) = true)

theorem identity1461 : scanCanonicalize (H12AffineFastState.compose env1461 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(20+1) ^^^ 3767) := by decide +kernel

theorem selectedBound1461 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1462 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,16384,8432,8314,16632,2264,1025,8432,3767,32,185,139,8328,233,2296,16384,16,2080,1025,0,5,0,16632,513]

theorem envBound1462 : H12AffineFastState.Bounded env1462 := by
  intro p hp
  have h : env1462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1461_1462 : H12AffineEnvironment.transform 20 3767 env1461 = env1462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3767 env1461 == env1462) = true)

theorem identity1462 : scanCanonicalize (H12AffineFastState.compose env1462 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(13+1) ^^^ 2296) := by decide +kernel

theorem selectedBound1462 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1463 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,233,8192,2296,8432,8314,2048,2264,1025,8432,3767,32,185,139,8328,233,2296,2296,16,2080,1025,0,5,0,2048,513]

theorem envBound1463 : H12AffineFastState.Bounded env1463 := by
  intro p hp
  have h : env1463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1462_1463 : H12AffineEnvironment.transform 13 2296 env1462 = env1463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2296 env1462 == env1463) = true)

theorem identity1463 : scanCanonicalize (H12AffineFastState.compose env1463 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 1670) := by decide +kernel

theorem selectedBound1463 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env1464 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1670,233,8192,1662,8432,8314,1670,1630,1025,8432,49,32,185,139,8328,233,1662,1662,16,1702,1025,0,5,0,1670,513]

theorem envBound1464 : H12AffineFastState.Bounded env1464 := by
  intro p hp
  have h : env1464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1463_1464 : H12AffineEnvironment.transform 10 1670 env1463 = env1464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1670 env1463 == env1464) = true)

theorem identity1464 : scanCanonicalize (H12AffineFastState.compose env1464 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1236) := by decide +kernel

theorem selectedBound1464 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1465 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1670,233,1236,1662,1060,1198,1670,1630,1025,1060,49,32,185,139,1116,233,1662,1662,16,1702,1025,0,5,0,1670,513]

theorem envBound1465 : H12AffineFastState.Bounded env1465 := by
  intro p hp
  have h : env1465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1464_1465 : H12AffineEnvironment.transform 12 1236 env1464 = env1465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1236 env1464 == env1465) = true)

theorem identity1465 : scanCanonicalize (H12AffineFastState.compose env1465 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 679) := by decide +kernel

theorem selectedBound1465 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1466 : List Nat := [2,4,8,16,32,64,128,4,512,679,33,233,627,217,643,521,33,249,678,643,49,32,185,139,763,233,217,217,16,1,678,0,5,0,33,513]

theorem envBound1466 : H12AffineFastState.Bounded env1466 := by
  intro p hp
  have h : env1466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1465_1466 : H12AffineEnvironment.transform 9 679 env1465 = env1466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 679 env1465 == env1466) = true)

theorem identity1466 : scanCanonicalize (H12AffineFastState.compose env1466 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound1466 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1467 : List Nat := [2,4,8,16,32,48,128,4,512,679,33,153,515,169,643,521,33,137,678,643,49,32,185,139,651,153,169,169,16,1,678,0,5,0,33,513]

theorem envBound1467 : H12AffineFastState.Bounded env1467 := by
  intro p hp
  have h : env1467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1466_1467 : H12AffineEnvironment.transform 5 48 env1466 = env1467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env1466 == env1467) = true)

theorem identity1467 : scanCanonicalize (H12AffineFastState.compose env1467 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound1467 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1468 : List Nat := [2,4,8,16,32,48,128,4,162,5,33,153,161,169,33,171,33,137,4,33,49,32,185,139,41,153,169,169,16,1,4,0,5,0,33,163]

theorem envBound1468 : H12AffineFastState.Bounded env1468 := by
  intro p hp
  have h : env1468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1467_1468 : H12AffineEnvironment.transform 8 162 env1467 = env1468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env1467 == env1468) = true)

theorem identity1468 : scanCanonicalize (H12AffineFastState.compose env1468 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound1468 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1469 : List Nat := [2,4,8,16,8,24,128,4,138,5,9,153,137,129,9,131,9,137,4,9,25,8,145,139,1,153,129,129,16,1,4,0,5,0,9,139]

theorem envBound1469 : H12AffineFastState.Bounded env1469 := by
  intro p hp
  have h : env1469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1468_1469 : H12AffineEnvironment.transform 4 8 env1468 = env1469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env1468 == env1469) = true)

theorem identity1469 : scanCanonicalize (H12AffineFastState.compose env1469 (packedSelected [6,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound1469 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env1470 : List Nat := [2,4,8,16,8,24,9,4,3,5,9,16,0,8,9,10,9,0,4,9,25,8,24,2,1,16,8,8,16,1,4,0,5,0,9,2]

theorem envBound1470 : H12AffineFastState.Bounded env1470 := by
  intro p hp
  have h : env1470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1469_1470 : H12AffineEnvironment.transform 6 9 env1469 = env1470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env1469 == env1470) = true)

theorem identity1470 : scanCanonicalize (H12AffineFastState.compose env1470 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound1470 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1471 : List Nat := [2,4,8,9,8,1,9,4,3,5,9,9,0,8,9,10,9,0,4,9,0,8,1,2,1,9,8,8,9,1,4,0,5,0,9,2]

theorem envBound1471 : H12AffineFastState.Bounded env1471 := by
  intro p hp
  have h : env1471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1470_1471 : H12AffineEnvironment.transform 3 9 env1470 = env1471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env1470 == env1471) = true)

def env1472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,2097152,4194304,147521,16777216,8328,147473,409816,16384,151553,2080,16852468,4341976,257,0,131073,16925298]

theorem envBound1472 : H12AffineFastState.Bounded env1472 := by
  intro p hp
  have h : env1472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1451_1472 : H12AffineEnvironment.transform 34 131073 env1451 = env1472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1451 == env1472) = true)

theorem identity1472 : scanCanonicalize (H12AffineFastState.compose env1472 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 147473) := by decide +kernel

theorem selectedBound1472 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,1025,8692,147473,4194304,147521,16777216,8328,147473,409816,16384,151553,2080,16852468,4341976,257,0,131073,16925298]

theorem envBound1473 : H12AffineFastState.Bounded env1473 := by
  intro p hp
  have h : env1473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1472_1473 : H12AffineEnvironment.transform 20 147473 env1472 = env1473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 147473 env1472 == env1473) = true)

theorem identity1473 : scanCanonicalize (H12AffineFastState.compose env1473 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1473 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1025,8692,147473,4194304,147521,16777216,8328,147473,409816,16384,151553,2080,16778639,4341976,257,0,131073,16925298]

theorem envBound1474 : H12AffineFastState.Bounded env1474 := by
  intro p hp
  have h : env1474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1473_1474 : H12AffineEnvironment.transform 15 8315 env1473 = env1474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1473 == env1474) = true)

def env1475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1025,8692,147473,147672,147521,16777216,8328,147473,409816,16384,151553,2080,16778639,0,257,0,131073,16925298]

theorem envBound1475 : H12AffineFastState.Bounded env1475 := by
  intro p hp
  have h : env1475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1474_1475 : H12AffineEnvironment.transform 21 147672 env1474 = env1475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env1474 == env1475) = true)

theorem identity1475 : scanCanonicalize (H12AffineFastState.compose env1475 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147830) := by decide +kernel

theorem selectedBound1475 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1025,8692,147473,147672,147521,147830,8328,147473,409816,16384,151553,2080,148729,0,257,0,131073,772]

theorem envBound1476 : H12AffineFastState.Bounded env1476 := by
  intro p hp
  have h : env1476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1475_1476 : H12AffineEnvironment.transform 23 147830 env1475 = env1476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147830 env1475 == env1476) = true)

theorem identity1476 : scanCanonicalize (H12AffineFastState.compose env1476 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound1476 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,16632,262144,1025,8692,233,32,185,398,8328,233,262176,16384,4345,2080,1025,0,257,0,16633,772]

theorem envBound1477 : H12AffineFastState.Bounded env1477 := by
  intro p hp
  have h : env1477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1476_1477 : H12AffineEnvironment.transform 16 16632 env1476 = env1477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1476 == env1477) = true)

theorem identity1477 : scanCanonicalize (H12AffineFastState.compose env1477 (packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound1477 : packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env1478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,16632,2264,1025,8692,233,32,185,398,8328,233,2296,16384,4345,2080,1025,0,257,0,16633,772]

theorem envBound1478 : H12AffineFastState.Bounded env1478 := by
  intro p hp
  have h : env1478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1477_1478 : H12AffineEnvironment.transform 17 2264 env1477 = env1478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env1477 == env1478) = true)

theorem identity1478 : scanCanonicalize (H12AffineFastState.compose env1478 (packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound1478 : packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS < 2^1333 := by decide +kernel

def env1479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1085,16384,1481,1094,16632,2264,1025,1481,233,32,185,398,1205,233,2296,16384,4345,2080,1025,0,257,0,16633,772]

theorem envBound1479 : H12AffineFastState.Bounded env1479 := by
  intro p hp
  have h : env1479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1478_1479 : H12AffineEnvironment.transform 12 1085 env1478 = env1479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env1478 == env1479) = true)

theorem identity1479 : scanCanonicalize (H12AffineFastState.compose env1479 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound1479 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env1480 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1085,16384,1125,1094,16632,2264,1025,1125,233,32,185,34,1205,233,2296,16384,4345,2080,1025,0,173,0,16633,680]

theorem envBound1480 : H12AffineFastState.Bounded env1480 := by
  intro p hp
  have h : env1480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1479_1480 : H12AffineEnvironment.transform 7 172 env1479 = env1480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env1479 == env1480) = true)

theorem identity1480 : scanCanonicalize (H12AffineFastState.compose env1480 (packedSelected [0,1,4,5,6,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2096) := by decide +kernel

theorem selectedBound1480 : packedSelected [0,1,4,5,6,11,15] rootPS < 2^1333 := by decide +kernel

def env1481 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1085,2096,1125,1094,2248,2264,1025,1125,233,32,185,34,1205,233,2296,2096,4345,2080,1025,0,173,0,2249,680]

theorem envBound1481 : H12AffineFastState.Bounded env1481 := by
  intro p hp
  have h : env1481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1480_1481 : H12AffineEnvironment.transform 13 2096 env1480 = env1481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2096 env1480 == env1481) = true)

theorem identity1481 : scanCanonicalize (H12AffineFastState.compose env1481 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound1481 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env1482 : List Nat := [2,4,8,16,32,64,128,172,512,220,2048,4096,225,2096,185,154,2248,2264,221,185,233,32,185,34,105,233,2296,2096,4345,2080,221,0,173,0,2249,680]

theorem envBound1482 : H12AffineFastState.Bounded env1482 := by
  intro p hp
  have h : env1482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1481_1482 : H12AffineEnvironment.transform 9 220 env1481 = env1482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env1481 == env1482) = true)

theorem identity1482 : scanCanonicalize (H12AffineFastState.compose env1482 (packedSelected [0,1,3,5,7,8,10,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 2297) := by decide +kernel

theorem selectedBound1482 : packedSelected [0,1,3,5,7,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env1483 : List Nat := [2,4,8,16,32,64,128,172,512,220,2048,2297,225,2096,185,154,2248,2264,221,185,233,32,185,34,105,233,2296,2096,2048,2080,221,0,173,0,2249,680]

theorem envBound1483 : H12AffineFastState.Bounded env1483 := by
  intro p hp
  have h : env1483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1482_1483 : H12AffineEnvironment.transform 11 2297 env1482 = env1483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2297 env1482 == env1483) = true)

theorem identity1483 : scanCanonicalize (H12AffineFastState.compose env1483 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1483 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env1484 : List Nat := [2,4,8,16,32,64,120,84,512,36,2048,2049,25,2096,65,98,2096,2080,37,65,17,32,65,34,105,17,2048,2096,2048,2080,37,0,85,0,2097,592]

theorem envBound1484 : H12AffineFastState.Bounded env1484 := by
  intro p hp
  have h : env1484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1483_1484 : H12AffineEnvironment.transform 6 120 env1483 = env1484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1483 == env1484) = true)

theorem identity1484 : scanCanonicalize (H12AffineFastState.compose env1484 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound1484 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env1485 : List Nat := [2,4,8,16,32,16,40,4,512,36,2048,2049,25,2096,17,50,2096,2080,37,17,17,32,17,34,57,17,2048,2096,2048,2080,37,0,5,0,2097,512]

theorem envBound1485 : H12AffineFastState.Bounded env1485 := by
  intro p hp
  have h : env1485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1484_1485 : H12AffineEnvironment.transform 5 16 env1484 = env1485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env1484 == env1485) = true)

theorem identity1485 : scanCanonicalize (H12AffineFastState.compose env1485 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound1485 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1486 : List Nat := [2,4,8,16,32,16,40,4,512,36,16,17,25,32,17,50,32,48,37,17,17,32,17,34,57,17,16,32,16,48,37,0,5,0,33,512]

theorem envBound1486 : H12AffineFastState.Bounded env1486 := by
  intro p hp
  have h : env1486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1485_1486 : H12AffineEnvironment.transform 10 16 env1485 = env1486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env1485 == env1486) = true)

theorem identity1486 : scanCanonicalize (H12AffineFastState.compose env1486 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound1486 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1487 : List Nat := [2,4,8,16,7,16,15,4,512,3,16,17,25,7,17,21,7,23,2,17,17,7,17,5,30,17,16,7,16,23,2,0,5,0,6,512]

theorem envBound1487 : H12AffineFastState.Bounded env1487 := by
  intro p hp
  have h : env1487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1486_1487 : H12AffineEnvironment.transform 4 7 env1486 = env1487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env1486 == env1487) = true)

theorem identity1487 : scanCanonicalize (H12AffineFastState.compose env1487 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1487 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1488 : List Nat := [2,4,5,16,7,16,2,4,512,3,16,17,20,7,17,21,7,23,2,17,17,7,17,5,19,17,16,7,16,23,2,0,5,0,6,512]

theorem envBound1488 : H12AffineFastState.Bounded env1488 := by
  intro p hp
  have h : env1488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1487_1488 : H12AffineEnvironment.transform 2 5 env1487 = env1488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1487 == env1488) = true)

theorem identity1488 : scanCanonicalize (H12AffineFastState.compose env1488 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound1488 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env1489 : List Nat := [2,3,2,16,0,16,2,3,512,3,16,17,19,0,17,18,0,16,2,17,17,0,17,2,19,17,16,0,16,16,2,0,2,0,1,512]

theorem envBound1489 : H12AffineFastState.Bounded env1489 := by
  intro p hp
  have h : env1489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1488_1489 : H12AffineEnvironment.transform 1 3 env1488 = env1489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env1488 == env1489) = true)

def env1490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,8315,131072,262144,1025,8692,147473,147673,147521,16777216,8328,147473,409816,16384,151553,2080,16778639,1,257,0,131073,16925298]

theorem envBound1490 : H12AffineFastState.Bounded env1490 := by
  intro p hp
  have h : env1490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1474_1490 : H12AffineEnvironment.transform 21 147673 env1474 = env1490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env1474 == env1490) = true)

theorem identity1490 : scanCanonicalize (H12AffineFastState.compose env1490 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1490 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1491 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8432,8315,131072,262144,1025,8432,147473,147673,147521,16777216,8328,147473,409816,16384,151553,2080,16778379,1,5,0,131073,16925298]

theorem envBound1491 : H12AffineFastState.Bounded env1491 := by
  intro p hp
  have h : env1491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1490_1491 : H12AffineEnvironment.transform 7 4 env1490 = env1491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1490 == env1491) = true)

def env1492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914001,9176216,16384,151553,2080,17375732,13108377,525568,0,34359738368,25691699]

theorem envBound1492 : H12AffineFastState.Bounded env1492 := by
  intro p hp
  have h : env1492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1318_1492 : H12AffineEnvironment.transform 14 8693 env1318 = env1492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env1318 == env1492) = true)

theorem identity1492 : scanCanonicalize (H12AffineFastState.compose env1492 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913971) := by decide +kernel

theorem selectedBound1492 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env1493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,8913971,8328,8914001,9176216,16384,151553,2080,8463815,13108377,525568,0,34359738368,512]

theorem envBound1493 : H12AffineFastState.Bounded env1493 := by
  intro p hp
  have h : env1493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1492_1493 : H12AffineEnvironment.transform 23 8913971 env1492 = env1493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913971 env1492 == env1493) = true)

theorem identity1493 : scanCanonicalize (H12AffineFastState.compose env1493 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525345) := by decide +kernel

theorem selectedBound1493 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,525345,8388608,8913971,8328,8914001,9176216,16384,151553,2080,8463815,8388792,525568,0,34359738368,512]

theorem envBound1494 : H12AffineFastState.Bounded env1494 := by
  intro p hp
  have h : env1494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1493_1494 : H12AffineEnvironment.transform 21 525345 env1493 = env1494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525345 env1493 == env1494) = true)

theorem identity1494 : scanCanonicalize (H12AffineFastState.compose env1494 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75135) := by decide +kernel

theorem selectedBound1494 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env1495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75135,8693,2097152,74078,8388608,8462668,8328,8462638,8724967,16384,151553,2080,8463815,8388792,73855,0,34359738368,512]

theorem envBound1495 : H12AffineFastState.Bounded env1495 := by
  intro p hp
  have h : env1495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1494_1495 : H12AffineEnvironment.transform 18 75135 env1494 = env1495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75135 env1494 == env1495) = true)

theorem identity1495 : scanCanonicalize (H12AffineFastState.compose env1495 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131332) := by decide +kernel

theorem selectedBound1495 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75135,8693,2097152,74078,8388608,8462668,8328,8462638,8724967,16384,151553,2080,8463815,8388792,73855,0,131332,512]

theorem envBound1496 : H12AffineFastState.Bounded env1496 := by
  intro p hp
  have h : env1496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1495_1496 : H12AffineEnvironment.transform 34 131332 env1495 = env1496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131332 env1495 == env1496) = true)

def env1497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75135,8693,2097152,74078,184,74228,8328,74134,336223,16384,151553,2080,75135,0,73855,0,131332,512]

theorem envBound1497 : H12AffineFastState.Bounded env1497 := by
  intro p hp
  have h : env1497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1496_1497 : H12AffineEnvironment.transform 22 184 env1496 = env1497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env1496 == env1497) = true)

theorem identity1497 : scanCanonicalize (H12AffineFastState.compose env1497 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223323) := by decide +kernel

theorem selectedBound1497 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env1498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,223323,75135,8693,2097152,74078,184,74228,8328,74134,149764,16384,151553,2080,75135,0,73855,0,131332,512]

theorem envBound1498 : H12AffineFastState.Bounded env1498 := by
  intro p hp
  have h : env1498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1497_1498 : H12AffineEnvironment.transform 17 223323 env1497 = env1498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223323 env1497 == env1498) = true)

def env1499 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74883,8201,2097152,73890,184,73736,8328,73834,149752,16384,151553,2080,74883,0,73855,0,131320,512]

theorem envBound1499 : H12AffineFastState.Bounded env1499 := by
  intro p hp
  have h : env1499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1498_1499 : H12AffineEnvironment.transform 7 252 env1498 = env1499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1498 == env1499) = true)

theorem identity1499 : scanCanonicalize (H12AffineFastState.compose env1499 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151552) := by decide +kernel

theorem selectedBound1499 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1500 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,131072,223323,74883,8201,151552,73890,184,73736,8328,73834,149752,16384,151553,2080,74883,0,73855,0,131320,512]

theorem envBound1500 : H12AffineFastState.Bounded env1500 := by
  intro p hp
  have h : env1500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1499_1500 : H12AffineEnvironment.transform 20 151552 env1499 = env1500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151552 env1499 == env1500) = true)

theorem identity1500 : scanCanonicalize (H12AffineFastState.compose env1500 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90235) := by decide +kernel

theorem selectedBound1500 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1501 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,65536,90235,2080,74883,8201,77947,73890,184,73736,8328,73834,75907,16384,77946,2080,74883,0,73855,0,90243,512]

theorem envBound1501 : H12AffineFastState.Bounded env1501 := by
  intro p hp
  have h : env1501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1500_1501 : H12AffineEnvironment.transform 16 90235 env1500 = env1501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90235 env1500 == env1501) = true)

theorem identity1501 : scanCanonicalize (H12AffineFastState.compose env1501 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound1501 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1502 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8201,8323,16632,2080,1024,8201,4344,33,184,139,8328,233,2048,16384,4345,2080,1024,0,252,0,16384,512]

theorem envBound1502 : H12AffineFastState.Bounded env1502 := by
  intro p hp
  have h : env1502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1501_1502 : H12AffineEnvironment.transform 15 8323 env1501 = env1502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env1501 == env1502) = true)

theorem identity1502 : scanCanonicalize (H12AffineFastState.compose env1502 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound1502 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1503 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8201,8323,5260,2080,1024,8201,4344,33,184,139,8328,233,2048,5236,4345,2080,1024,0,252,0,5236,512]

theorem envBound1503 : H12AffineFastState.Bounded env1503 := by
  intro p hp
  have h : env1503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1502_1503 : H12AffineEnvironment.transform 13 5236 env1502 = env1503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env1502 == env1503) = true)

theorem identity1503 : scanCanonicalize (H12AffineFastState.compose env1503 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound1503 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1504 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,8192,603,8201,8323,675,2080,1024,8201,1751,33,184,139,8328,233,2048,603,1750,2080,1024,0,252,0,603,512]

theorem envBound1504 : H12AffineFastState.Bounded env1504 := by
  intro p hp
  have h : env1504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1503_1504 : H12AffineEnvironment.transform 11 1583 env1503 = env1504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env1503 == env1504) = true)

theorem identity1504 : scanCanonicalize (H12AffineFastState.compose env1504 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound1504 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1505 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,3822,603,3815,3693,675,2080,1024,3815,1751,33,184,139,3686,233,2048,603,1750,2080,1024,0,252,0,603,512]

theorem envBound1505 : H12AffineFastState.Bounded env1505 := by
  intro p hp
  have h : env1505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1504_1505 : H12AffineEnvironment.transform 12 3822 env1504 = env1505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env1504 == env1505) = true)

theorem identity1505 : scanCanonicalize (H12AffineFastState.compose env1505 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound1505 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1506 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,554,2795,603,2786,2664,675,2080,5,2786,722,33,184,139,2659,233,2048,603,723,2080,5,0,252,0,603,512]

theorem envBound1506 : H12AffineFastState.Bounded env1506 := by
  intro p hp
  have h : env1506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1505_1506 : H12AffineEnvironment.transform 9 5 env1505 = env1506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env1505 == env1506) = true)

theorem identity1506 : scanCanonicalize (H12AffineFastState.compose env1506 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound1506 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1507 : List Nat := [2,4,8,16,32,64,121,5,512,5,2048,554,2578,603,2587,2664,602,2080,5,2587,555,33,65,114,2659,16,2048,603,554,2080,5,0,5,0,603,512]

theorem envBound1507 : H12AffineFastState.Bounded env1507 := by
  intro p hp
  have h : env1507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1506_1507 : H12AffineEnvironment.transform 6 121 env1506 = env1507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env1506 == env1507) = true)

theorem identity1507 : scanCanonicalize (H12AffineFastState.compose env1507 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound1507 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1508 : List Nat := [2,4,8,16,32,64,121,5,512,5,608,554,114,603,123,8,602,576,5,123,555,33,65,114,3,16,608,603,554,576,5,0,5,0,603,512]

theorem envBound1508 : H12AffineFastState.Bounded env1508 := by
  intro p hp
  have h : env1508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1507_1508 : H12AffineEnvironment.transform 10 608 env1507 = env1508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env1507 == env1508) = true)

theorem identity1508 : scanCanonicalize (H12AffineFastState.compose env1508 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound1508 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1509 : List Nat := [2,4,8,16,27,64,66,5,512,5,603,529,73,603,64,8,602,576,5,64,528,26,65,73,3,16,603,603,529,576,5,0,5,0,603,512]

theorem envBound1509 : H12AffineFastState.Bounded env1509 := by
  intro p hp
  have h : env1509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1508_1509 : H12AffineEnvironment.transform 4 27 env1508 = env1509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env1508 == env1509) = true)

def env1510 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74882,8200,2097152,73891,184,73737,8328,73835,149753,16384,151553,2080,74882,0,73855,0,131321,512]

theorem envBound1510 : H12AffineFastState.Bounded env1510 := by
  intro p hp
  have h : env1510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1498_1510 : H12AffineEnvironment.transform 7 253 env1498 = env1510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1498 == env1510) = true)

theorem identity1510 : scanCanonicalize (H12AffineFastState.compose env1510 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78035) := by decide +kernel

theorem selectedBound1510 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1511 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,223323,74882,8200,78035,73891,184,73737,8328,73835,149753,16384,151553,2080,74882,0,73855,0,131321,512]

theorem envBound1511 : H12AffineFastState.Bounded env1511 := by
  intro p hp
  have h : env1511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1510_1511 : H12AffineEnvironment.transform 20 78035 env1510 = env1511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78035 env1510 == env1511) = true)

theorem identity1511 : scanCanonicalize (H12AffineFastState.compose env1511 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7694) := by decide +kernel

theorem selectedBound1511 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1512 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7694,8200,65536,131072,210517,74882,8200,78035,73891,184,73737,8328,73835,136951,7694,134671,2080,74882,0,73855,0,131321,512]

theorem envBound1512 : H12AffineFastState.Bounded env1512 := by
  intro p hp
  have h : env1512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1511_1512 : H12AffineEnvironment.transform 13 7694 env1511 = env1512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7694 env1511 == env1512) = true)

def env1513 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,131072,205377,74882,8200,74951,73891,184,73737,8328,73835,131811,2586,134671,2080,74882,0,73855,0,131321,512]

theorem envBound1513 : H12AffineFastState.Bounded env1513 := by
  intro p hp
  have h : env1513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1512_1513 : H12AffineEnvironment.transform 11 1044 env1512 = env1513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env1512 == env1513) = true)

def env1514 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76384,2081,74882,8200,74951,73891,184,73737,8328,73835,75907,2586,74863,2080,74882,0,73855,0,76441,512]

theorem envBound1514 : H12AffineFastState.Bounded env1514 := by
  intro p hp
  have h : env1514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1513_1514 : H12AffineEnvironment.transform 16 76384 env1513 = env1514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1513 == env1514) = true)

theorem identity1514 : scanCanonicalize (H12AffineFastState.compose env1514 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound1514 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1515 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2586,3614,65536,66678,2081,68244,3614,68305,69301,184,69151,3742,69245,67221,2586,68217,2080,68244,0,69225,0,66703,512]

theorem envBound1515 : H12AffineFastState.Bounded env1515 := by
  intro p hp
  have h : env1515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1514_1515 : H12AffineEnvironment.transform 12 3606 env1514 = env1515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env1514 == env1515) = true)

theorem identity1515 : scanCanonicalize (H12AffineFastState.compose env1515 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound1515 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1516 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2586,3614,3732,2786,2081,1024,3614,1093,33,184,139,3742,233,2049,2586,1261,2080,1024,0,253,0,2587,512]

theorem envBound1516 : H12AffineFastState.Bounded env1516 := by
  intro p hp
  have h : env1516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1515_1516 : H12AffineEnvironment.transform 15 3732 env1515 = env1516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env1515 == env1516) = true)

theorem identity1516 : scanCanonicalize (H12AffineFastState.compose env1516 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound1516 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1517 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,65,2627,2586,2635,2753,2786,2081,85,2635,16,33,184,139,2763,233,2049,2586,184,2080,85,0,253,0,2587,512]

theorem envBound1517 : H12AffineFastState.Bounded env1517 := by
  intro p hp
  have h : env1517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1516_1517 : H12AffineEnvironment.transform 9 85 env1516 = env1517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env1516 == env1517) = true)

theorem identity1517 : scanCanonicalize (H12AffineFastState.compose env1517 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1517 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1518 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,65,2627,2586,2635,2664,2635,2081,85,2635,16,33,17,34,2658,64,2049,2586,17,2080,85,0,84,0,2587,512]

theorem envBound1518 : H12AffineFastState.Bounded env1518 := by
  intro p hp
  have h : env1518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1517_1518 : H12AffineEnvironment.transform 6 41 env1517 = env1518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1517 == env1518) = true)

def env1519 : List Nat := [2,4,8,16,16,64,25,84,512,85,2048,65,2627,2586,2635,2648,2635,2065,85,2635,16,17,17,18,2642,64,2049,2586,17,2064,85,0,84,0,2587,512]

theorem envBound1519 : H12AffineFastState.Bounded env1519 := by
  intro p hp
  have h : env1519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1518_1519 : H12AffineEnvironment.transform 4 16 env1518 = env1519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1518 == env1519) = true)

def env1520 : List Nat := [2,4,8,16,16,64,25,84,512,85,0,65,579,538,587,600,587,17,85,587,16,17,17,18,594,64,1,538,17,16,85,0,84,0,539,512]

theorem envBound1520 : H12AffineFastState.Bounded env1520 := by
  intro p hp
  have h : env1520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1519_1520 : H12AffineEnvironment.transform 10 0 env1519 = env1520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1519 == env1520) = true)

theorem identity1520 : scanCanonicalize (H12AffineFastState.compose env1520 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1520 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1521 : List Nat := [2,4,8,13,13,64,4,73,512,72,0,65,579,519,587,581,587,12,72,587,13,12,12,15,591,64,1,519,12,13,72,0,73,0,518,512]

theorem envBound1521 : H12AffineFastState.Bounded env1521 := by
  intro p hp
  have h : env1521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1520_1521 : H12AffineEnvironment.transform 3 13 env1520 = env1521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1520 == env1521) = true)

def env1522 : List Nat := [2,4,8,13,13,0,4,9,512,8,0,1,515,519,523,517,523,12,8,523,13,12,12,15,527,0,1,519,12,13,8,0,9,0,518,512]

theorem envBound1522 : H12AffineFastState.Bounded env1522 := by
  intro p hp
  have h : env1522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1521_1522 : H12AffineEnvironment.transform 5 0 env1521 = env1522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1521 == env1522) = true)

def leafEnv1522 : List Nat := [2,4,8,13,13,0,4,9,512,8,0,1,515,519,523,517,523,12,8,523,13,12,12,15,9,527,1,0,1,519,12,13,8,0,9,0,5,520,518,512,1,12,0]

def active1522 : List Nat := [0,1,2,8]

def tree1522 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1522 : H12WitnessSearch.Good tree1522 := H12GlobalWitnessIndex.good

theorem leafIdentity1522 : H12AffineFastState.composeSystem env1522 rootObs = leafEnv1522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1522 rootObs == leafEnv1522) = true)

theorem terminalChecked1522 : H12PackedTerminal.terminalCheckFast leafEnv1522 active1522 tree1522 = true := by decide +kernel

def env1523 : List Nat := [2,4,8,13,13,1,4,8,512,9,0,0,514,519,522,516,522,12,9,522,13,12,12,15,526,1,1,519,12,13,9,0,8,0,518,512]

theorem envBound1523 : H12AffineFastState.Bounded env1523 := by
  intro p hp
  have h : env1523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1521_1523 : H12AffineEnvironment.transform 5 1 env1521 = env1523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1521 == env1523) = true)

theorem identity1523 : scanCanonicalize (H12AffineFastState.compose env1523 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1523 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1524 : List Nat := [2,4,8,13,13,1,4,8,6,9,0,0,4,1,12,2,12,12,9,12,13,12,12,15,8,1,1,1,12,13,9,0,8,0,0,6]

theorem envBound1524 : H12AffineFastState.Bounded env1524 := by
  intro p hp
  have h : env1524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1523_1524 : H12AffineEnvironment.transform 8 6 env1523 = env1524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1523 == env1524) = true)

def leafEnv1524 : List Nat := [2,4,8,13,13,1,4,8,6,9,0,0,4,1,12,2,12,12,9,12,13,12,12,15,8,8,1,1,1,1,12,13,9,0,8,0,5,15,0,6,1,12,0]

def active1524 : List Nat := [0,1,2]

def tree1524 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1524 : H12WitnessSearch.Good tree1524 := H12GlobalWitnessIndex.good

theorem leafIdentity1524 : H12AffineFastState.composeSystem env1524 rootObs = leafEnv1524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1524 rootObs == leafEnv1524) = true)

theorem terminalChecked1524 : H12PackedTerminal.terminalCheckFast leafEnv1524 active1524 tree1524 = true := by decide +kernel

def env1525 : List Nat := [2,4,8,16,16,64,25,84,512,85,1,65,578,539,586,601,586,16,85,586,16,17,17,18,595,64,0,539,17,17,85,0,84,0,538,512]

theorem envBound1525 : H12AffineFastState.Bounded env1525 := by
  intro p hp
  have h : env1525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1519_1525 : H12AffineEnvironment.transform 10 1 env1519 = env1525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1519 == env1525) = true)

theorem identity1525 : scanCanonicalize (H12AffineFastState.compose env1525 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1525 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1526 : List Nat := [2,4,5,16,16,64,20,84,512,85,1,65,578,534,583,596,583,16,85,583,16,17,17,18,595,64,0,534,17,17,85,0,84,0,535,512]

theorem envBound1526 : H12AffineFastState.Bounded env1526 := by
  intro p hp
  have h : env1526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1525_1526 : H12AffineEnvironment.transform 2 5 env1525 = env1526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1525 == env1526) = true)

def env1527 : List Nat := [2,4,5,16,16,0,20,20,512,21,1,1,514,534,519,532,519,16,21,519,16,17,17,18,531,0,0,534,17,17,21,0,20,0,535,512]

theorem envBound1527 : H12AffineFastState.Bounded env1527 := by
  intro p hp
  have h : env1527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1526_1527 : H12AffineEnvironment.transform 5 0 env1526 = env1527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1526 == env1527) = true)

theorem identity1527 : scanCanonicalize (H12AffineFastState.compose env1527 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1527 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1528 : List Nat := [2,4,5,16,16,0,20,20,23,21,1,1,21,1,16,3,16,16,21,16,16,17,17,18,4,0,0,1,17,17,21,0,20,0,0,23]

theorem envBound1528 : H12AffineFastState.Bounded env1528 := by
  intro p hp
  have h : env1528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1527_1528 : H12AffineEnvironment.transform 8 23 env1527 = env1528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1527 == env1528) = true)

def leafEnv1528 : List Nat := [2,4,5,16,16,0,20,20,23,21,1,1,21,1,16,3,16,16,21,16,16,17,17,18,20,4,1,0,0,1,17,17,21,0,20,0,5,19,0,23,1,17,0]

def active1528 : List Nat := [0,1,3]

def tree1528 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1528 : H12WitnessSearch.Good tree1528 := H12GlobalWitnessIndex.good

theorem leafIdentity1528 : H12AffineFastState.composeSystem env1528 rootObs = leafEnv1528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1528 rootObs == leafEnv1528) = true)

theorem terminalChecked1528 : H12PackedTerminal.terminalCheckFast leafEnv1528 active1528 tree1528 = true := by decide +kernel

def env1529 : List Nat := [2,4,5,16,16,1,20,21,512,20,1,0,515,534,518,533,518,16,20,518,16,17,17,18,530,1,0,534,17,17,20,0,21,0,535,512]

theorem envBound1529 : H12AffineFastState.Bounded env1529 := by
  intro p hp
  have h : env1529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1526_1529 : H12AffineEnvironment.transform 5 1 env1526 = env1529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1526 == env1529) = true)

def leafEnv1529 : List Nat := [2,4,5,16,16,1,20,21,512,20,1,0,515,534,518,533,518,16,20,518,16,17,17,18,21,530,1,1,0,534,17,17,20,0,21,0,5,517,535,512,1,17,0]

def active1529 : List Nat := [0,1,3,8]

def tree1529 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1529 : H12WitnessSearch.Good tree1529 := H12GlobalWitnessIndex.good

theorem leafIdentity1529 : H12AffineFastState.composeSystem env1529 rootObs = leafEnv1529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1529 rootObs == leafEnv1529) = true)

theorem terminalChecked1529 : H12PackedTerminal.terminalCheckFast leafEnv1529 active1529 tree1529 = true := by decide +kernel

def env1530 : List Nat := [2,4,8,16,17,64,24,84,512,85,2048,65,2627,2586,2635,2649,2635,2064,85,2635,16,16,17,19,2643,64,2049,2586,17,2065,85,0,84,0,2587,512]

theorem envBound1530 : H12AffineFastState.Bounded env1530 := by
  intro p hp
  have h : env1530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1518_1530 : H12AffineEnvironment.transform 4 17 env1518 = env1530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1518 == env1530) = true)

def env1531 : List Nat := [2,4,8,16,17,64,24,84,512,85,0,65,579,538,587,601,587,16,85,587,16,16,17,19,595,64,1,538,17,17,85,0,84,0,539,512]

theorem envBound1531 : H12AffineFastState.Bounded env1531 := by
  intro p hp
  have h : env1531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1530_1531 : H12AffineEnvironment.transform 10 0 env1530 = env1531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1530 == env1531) = true)

theorem identity1531 : scanCanonicalize (H12AffineFastState.compose env1531 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 87) := by decide +kernel

theorem selectedBound1531 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1532 : List Nat := [2,4,8,16,17,64,24,84,87,85,0,65,20,77,28,14,28,16,85,28,16,16,17,19,4,64,1,77,17,17,85,0,84,0,76,87]

theorem envBound1532 : H12AffineFastState.Bounded env1532 := by
  intro p hp
  have h : env1532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1531_1532 : H12AffineEnvironment.transform 8 87 env1531 = env1532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 87 env1531 == env1532) = true)

def env1533 : List Nat := [2,4,8,16,17,0,24,20,23,21,0,1,20,13,28,14,28,16,21,28,16,16,17,19,4,0,1,13,17,17,21,0,20,0,12,23]

theorem envBound1533 : H12AffineFastState.Bounded env1533 := by
  intro p hp
  have h : env1533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1532_1533 : H12AffineEnvironment.transform 5 0 env1532 = env1533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1532 == env1533) = true)

def leafEnv1533 : List Nat := [2,4,8,16,17,0,24,20,23,21,0,1,20,13,28,14,28,16,21,28,16,16,17,19,20,4,1,0,1,13,17,17,21,0,20,0,5,31,12,23,1,17,0]

def active1533 : List Nat := [0,1,2,3]

def tree1533 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1533 : H12WitnessSearch.Good tree1533 := H12GlobalWitnessIndex.good

theorem leafIdentity1533 : H12AffineFastState.composeSystem env1533 rootObs = leafEnv1533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1533 rootObs == leafEnv1533) = true)

theorem terminalChecked1533 : H12PackedTerminal.terminalCheckFast leafEnv1533 active1533 tree1533 = true := by decide +kernel

def env1534 : List Nat := [2,4,8,16,17,1,24,21,22,20,0,0,20,12,28,14,28,16,20,28,16,16,17,19,4,1,1,12,17,17,20,0,21,0,13,22]

theorem envBound1534 : H12AffineFastState.Bounded env1534 := by
  intro p hp
  have h : env1534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1532_1534 : H12AffineEnvironment.transform 5 1 env1532 = env1534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1532 == env1534) = true)

theorem identity1534 : scanCanonicalize (H12AffineFastState.compose env1534 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1534 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1535 : List Nat := [2,4,4,16,17,1,20,21,22,20,0,0,20,0,16,2,16,16,20,16,16,16,17,19,4,1,1,0,17,17,20,0,21,0,1,22]

theorem envBound1535 : H12AffineFastState.Bounded env1535 := by
  intro p hp
  have h : env1535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1534_1535 : H12AffineEnvironment.transform 2 4 env1534 = env1535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1534 == env1535) = true)

def leafEnv1535 : List Nat := [2,4,4,16,17,1,20,21,22,20,0,0,20,0,16,2,16,16,20,16,16,16,17,19,21,4,1,1,1,0,17,17,20,0,21,0,5,19,1,22,1,17,0]

def active1535 : List Nat := [0,1,3]

def tree1535 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1535 : H12WitnessSearch.Good tree1535 := H12GlobalWitnessIndex.good

theorem leafIdentity1535 : H12AffineFastState.composeSystem env1535 rootObs = leafEnv1535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1535 rootObs == leafEnv1535) = true)

theorem terminalChecked1535 : H12PackedTerminal.terminalCheckFast leafEnv1535 active1535 tree1535 = true := by decide +kernel

def env1536 : List Nat := [2,4,8,16,17,64,24,84,512,85,1,65,578,539,586,600,586,17,85,586,16,16,17,19,594,64,0,539,17,16,85,0,84,0,538,512]

theorem envBound1536 : H12AffineFastState.Bounded env1536 := by
  intro p hp
  have h : env1536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1530_1536 : H12AffineEnvironment.transform 10 1 env1530 = env1536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1530 == env1536) = true)

theorem identity1536 : scanCanonicalize (H12AffineFastState.compose env1536 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound1536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1537 : List Nat := [2,4,8,16,17,64,24,84,71,85,1,65,5,92,13,31,13,17,85,13,16,16,17,19,21,64,0,92,17,16,85,0,84,0,93,71]

theorem envBound1537 : H12AffineFastState.Bounded env1537 := by
  intro p hp
  have h : env1537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1536_1537 : H12AffineEnvironment.transform 8 71 env1536 = env1537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env1536 == env1537) = true)

def env1538 : List Nat := [2,4,8,16,17,0,24,20,7,21,1,1,5,28,13,31,13,17,21,13,16,16,17,19,21,0,0,28,17,16,21,0,20,0,29,7]

theorem envBound1538 : H12AffineFastState.Bounded env1538 := by
  intro p hp
  have h : env1538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1537_1538 : H12AffineEnvironment.transform 5 0 env1537 = env1538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1537 == env1538) = true)

theorem identity1538 : scanCanonicalize (H12AffineFastState.compose env1538 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound1538 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1539 : List Nat := [2,4,8,12,13,0,4,8,7,9,1,1,5,0,13,3,13,13,9,13,12,12,13,15,9,0,0,0,13,12,9,0,8,0,1,7]

theorem envBound1539 : H12AffineFastState.Bounded env1539 := by
  intro p hp
  have h : env1539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1538_1539 : H12AffineEnvironment.transform 3 12 env1538 = env1539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1538 == env1539) = true)

def leafEnv1539 : List Nat := [2,4,8,12,13,0,4,8,7,9,1,1,5,0,13,3,13,13,9,13,12,12,13,15,8,9,1,0,0,0,13,12,9,0,8,0,5,14,1,7,1,13,0]

def active1539 : List Nat := [0,1,2]

def tree1539 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1539 : H12WitnessSearch.Good tree1539 := H12GlobalWitnessIndex.good

theorem leafIdentity1539 : H12AffineFastState.composeSystem env1539 rootObs = leafEnv1539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1539 rootObs == leafEnv1539) = true)

theorem terminalChecked1539 : H12PackedTerminal.terminalCheckFast leafEnv1539 active1539 tree1539 = true := by decide +kernel

def env1540 : List Nat := [2,4,8,16,17,1,24,21,6,20,1,0,5,29,13,31,13,17,20,13,16,16,17,19,21,1,0,29,17,16,20,0,21,0,28,6]

theorem envBound1540 : H12AffineFastState.Bounded env1540 := by
  intro p hp
  have h : env1540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1537_1540 : H12AffineEnvironment.transform 5 1 env1537 = env1540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1537 == env1540) = true)

def leafEnv1540 : List Nat := [2,4,8,16,17,1,24,21,6,20,1,0,5,29,13,31,13,17,20,13,16,16,17,19,21,21,1,1,0,29,17,16,20,0,21,0,5,14,28,6,1,17,0]

def active1540 : List Nat := [0,1,2,3]

def tree1540 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1540 : H12WitnessSearch.Good tree1540 := H12GlobalWitnessIndex.good

theorem leafIdentity1540 : H12AffineFastState.composeSystem env1540 rootObs = leafEnv1540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1540 rootObs == leafEnv1540) = true)

theorem terminalChecked1540 : H12PackedTerminal.terminalCheckFast leafEnv1540 active1540 tree1540 = true := by decide +kernel

def env1541 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,65536,76385,2080,74882,8200,74951,73891,184,73737,8328,73835,75906,2586,74862,2080,74882,0,73855,0,76440,512]

theorem envBound1541 : H12AffineFastState.Bounded env1541 := by
  intro p hp
  have h : env1541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1513_1541 : H12AffineEnvironment.transform 16 76385 env1513 = env1541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1513 == env1541) = true)

theorem identity1541 : scanCanonicalize (H12AffineFastState.compose env1541 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound1541 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1542 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2586,8200,99,10754,2080,9441,8200,9380,8384,184,8298,8328,8200,10465,2586,9229,2080,9441,0,8220,0,11003,512]

theorem envBound1542 : H12AffineFastState.Bounded env1542 := by
  intro p hp
  have h : env1542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1541_1542 : H12AffineEnvironment.transform 15 99 env1541 = env1542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env1541 == env1542) = true)

def env1543 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,131072,205376,74882,8200,74950,73891,184,73737,8328,73835,131810,2587,134671,2080,74882,0,73855,0,131321,512]

theorem envBound1543 : H12AffineFastState.Bounded env1543 := by
  intro p hp
  have h : env1543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1512_1543 : H12AffineEnvironment.transform 11 1045 env1512 = env1543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env1512 == env1543) = true)

def env1544 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76384,2080,74882,8200,74950,73891,184,73737,8328,73835,75906,2587,74863,2080,74882,0,73855,0,76441,512]

theorem envBound1544 : H12AffineFastState.Bounded env1544 := by
  intro p hp
  have h : env1544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1543_1544 : H12AffineEnvironment.transform 16 76384 env1543 = env1544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1543 == env1544) = true)

theorem identity1544 : scanCanonicalize (H12AffineFastState.compose env1544 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound1544 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1545 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,225,2587,233,65536,68225,2080,66659,233,66599,65602,184,65768,105,65674,67683,2587,66702,2080,66659,0,65694,0,68216,512]

theorem envBound1545 : H12AffineFastState.Bounded env1545 := by
  intro p hp
  have h : env1545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1544_1545 : H12AffineEnvironment.transform 12 225 env1544 = env1545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env1544 == env1545) = true)

def env1546 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,65536,76385,2081,74882,8200,74950,73891,184,73737,8328,73835,75907,2587,74862,2080,74882,0,73855,0,76440,512]

theorem envBound1546 : H12AffineFastState.Bounded env1546 := by
  intro p hp
  have h : env1546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1543_1546 : H12AffineEnvironment.transform 16 76385 env1543 = env1546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1543 == env1546) = true)

theorem identity1546 : scanCanonicalize (H12AffineFastState.compose env1546 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound1546 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1547 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2587,8200,3732,9461,2081,10774,8200,10834,11831,184,11933,8328,12031,9751,2587,11002,2080,10774,0,12011,0,9228,512]

theorem envBound1547 : H12AffineFastState.Bounded env1547 := by
  intro p hp
  have h : env1547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1546_1547 : H12AffineEnvironment.transform 15 3732 env1546 = env1547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env1546 == env1547) = true)

theorem identity1547 : scanCanonicalize (H12AffineFastState.compose env1547 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound1547 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1548 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3606,2587,3614,3732,2787,2081,1024,3614,1092,33,184,139,3742,233,2049,2587,1260,2080,1024,0,253,0,2586,512]

theorem envBound1548 : H12AffineFastState.Bounded env1548 := by
  intro p hp
  have h : env1548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1547_1548 : H12AffineEnvironment.transform 12 3606 env1547 = env1548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env1547 == env1548) = true)

theorem identity1548 : scanCanonicalize (H12AffineFastState.compose env1548 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound1548 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1549 : List Nat := [2,4,8,16,32,64,128,253,512,85,2048,64,2627,2587,2635,2753,2787,2081,85,2635,17,33,184,139,2763,233,2049,2587,185,2080,85,0,253,0,2586,512]

theorem envBound1549 : H12AffineFastState.Bounded env1549 := by
  intro p hp
  have h : env1549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1548_1549 : H12AffineEnvironment.transform 9 85 env1548 = env1549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env1548 == env1549) = true)

theorem identity1549 : scanCanonicalize (H12AffineFastState.compose env1549 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1549 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1550 : List Nat := [2,4,8,16,32,64,41,84,512,85,2048,64,2627,2587,2635,2664,2634,2081,85,2635,17,33,17,34,2658,64,2049,2587,16,2080,85,0,84,0,2586,512]

theorem envBound1550 : H12AffineFastState.Bounded env1550 := by
  intro p hp
  have h : env1550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1549_1550 : H12AffineEnvironment.transform 6 41 env1549 = env1550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1549 == env1550) = true)

def env1551 : List Nat := [2,4,8,16,16,64,25,84,512,85,2048,64,2627,2587,2635,2648,2634,2065,85,2635,17,17,17,18,2642,64,2049,2587,16,2064,85,0,84,0,2586,512]

theorem envBound1551 : H12AffineFastState.Bounded env1551 := by
  intro p hp
  have h : env1551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1550_1551 : H12AffineEnvironment.transform 4 16 env1550 = env1551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1550 == env1551) = true)

def env1552 : List Nat := [2,4,8,16,16,64,25,84,512,85,0,64,579,539,587,600,586,17,85,587,17,17,17,18,594,64,1,539,16,16,85,0,84,0,538,512]

theorem envBound1552 : H12AffineFastState.Bounded env1552 := by
  intro p hp
  have h : env1552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1551_1552 : H12AffineEnvironment.transform 10 0 env1551 = env1552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1551 == env1552) = true)

theorem identity1552 : scanCanonicalize (H12AffineFastState.compose env1552 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1553 : List Nat := [2,4,8,16,16,64,25,84,22,85,0,64,85,13,93,78,92,17,85,93,17,17,17,18,68,64,1,13,16,16,85,0,84,0,12,22]

theorem envBound1553 : H12AffineFastState.Bounded env1553 := by
  intro p hp
  have h : env1553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1552_1553 : H12AffineEnvironment.transform 8 22 env1552 = env1553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1552 == env1553) = true)

def env1554 : List Nat := [2,4,8,16,16,0,25,20,22,21,0,0,21,13,29,14,28,17,21,29,17,17,17,18,4,0,1,13,16,16,21,0,20,0,12,22]

theorem envBound1554 : H12AffineFastState.Bounded env1554 := by
  intro p hp
  have h : env1554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1553_1554 : H12AffineEnvironment.transform 5 0 env1553 = env1554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1553 == env1554) = true)

theorem identity1554 : scanCanonicalize (H12AffineFastState.compose env1554 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound1554 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1555 : List Nat := [2,4,5,16,16,0,20,20,22,21,0,0,21,0,16,3,17,17,21,16,17,17,17,18,4,0,1,0,16,16,21,0,20,0,1,22]

theorem envBound1555 : H12AffineFastState.Bounded env1555 := by
  intro p hp
  have h : env1555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1554_1555 : H12AffineEnvironment.transform 2 5 env1554 = env1555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1554 == env1555) = true)

def leafEnv1555 : List Nat := [2,4,5,16,16,0,20,20,22,21,0,0,21,0,16,3,17,17,21,16,17,17,17,18,20,4,1,0,1,0,16,16,21,0,20,0,5,19,1,22,1,16,0]

def active1555 : List Nat := [0,1,3]

def tree1555 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1555 : H12WitnessSearch.Good tree1555 := H12GlobalWitnessIndex.good

theorem leafIdentity1555 : H12AffineFastState.composeSystem env1555 rootObs = leafEnv1555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1555 rootObs == leafEnv1555) = true)

theorem terminalChecked1555 : H12PackedTerminal.terminalCheckFast leafEnv1555 active1555 tree1555 = true := by decide +kernel

def env1556 : List Nat := [2,4,8,16,16,1,25,21,22,20,0,1,20,13,28,15,29,17,20,28,17,17,17,18,5,1,1,13,16,16,20,0,21,0,12,22]

theorem envBound1556 : H12AffineFastState.Bounded env1556 := by
  intro p hp
  have h : env1556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1553_1556 : H12AffineEnvironment.transform 5 1 env1553 = env1556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1553 == env1556) = true)

def leafEnv1556 : List Nat := [2,4,8,16,16,1,25,21,22,20,0,1,20,13,28,15,29,17,20,28,17,17,17,18,21,5,1,1,1,13,16,16,20,0,21,0,5,31,12,22,1,16,0]

def active1556 : List Nat := [0,1,2,3]

def tree1556 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1556 : H12WitnessSearch.Good tree1556 := H12GlobalWitnessIndex.good

theorem leafIdentity1556 : H12AffineFastState.composeSystem env1556 rootObs = leafEnv1556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1556 rootObs == leafEnv1556) = true)

theorem terminalChecked1556 : H12PackedTerminal.terminalCheckFast leafEnv1556 active1556 tree1556 = true := by decide +kernel

def env1557 : List Nat := [2,4,8,16,16,64,25,84,512,85,1,64,578,538,586,601,587,16,85,586,17,17,17,18,595,64,0,538,16,17,85,0,84,0,539,512]

theorem envBound1557 : H12AffineFastState.Bounded env1557 := by
  intro p hp
  have h : env1557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1551_1557 : H12AffineEnvironment.transform 10 1 env1551 = env1557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1551 == env1557) = true)

theorem identity1557 : scanCanonicalize (H12AffineFastState.compose env1557 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1557 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1558 : List Nat := [2,4,8,16,16,64,25,84,7,85,1,64,69,29,77,94,76,16,85,77,17,17,17,18,84,64,0,29,16,17,85,0,84,0,28,7]

theorem envBound1558 : H12AffineFastState.Bounded env1558 := by
  intro p hp
  have h : env1558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1557_1558 : H12AffineEnvironment.transform 8 7 env1557 = env1558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1557 == env1558) = true)

def env1559 : List Nat := [2,4,8,16,16,0,25,20,7,21,1,0,5,29,13,30,12,16,21,13,17,17,17,18,20,0,0,29,16,17,21,0,20,0,28,7]

theorem envBound1559 : H12AffineFastState.Bounded env1559 := by
  intro p hp
  have h : env1559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1558_1559 : H12AffineEnvironment.transform 5 0 env1558 = env1559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1558 == env1559) = true)

def leafEnv1559 : List Nat := [2,4,8,16,16,0,25,20,7,21,1,0,5,29,13,30,12,16,21,13,17,17,17,18,20,20,1,0,0,29,16,17,21,0,20,0,5,14,28,7,1,16,0]

def active1559 : List Nat := [0,1,2,3]

def tree1559 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1559 : H12WitnessSearch.Good tree1559 := H12GlobalWitnessIndex.good

theorem leafIdentity1559 : H12AffineFastState.composeSystem env1559 rootObs = leafEnv1559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1559 rootObs == leafEnv1559) = true)

theorem terminalChecked1559 : H12PackedTerminal.terminalCheckFast leafEnv1559 active1559 tree1559 = true := by decide +kernel

def env1560 : List Nat := [2,4,8,16,16,1,25,21,7,20,1,1,4,29,12,31,13,16,20,12,17,17,17,18,21,1,0,29,16,17,20,0,21,0,28,7]

theorem envBound1560 : H12AffineFastState.Bounded env1560 := by
  intro p hp
  have h : env1560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1558_1560 : H12AffineEnvironment.transform 5 1 env1558 = env1560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1558 == env1560) = true)

theorem identity1560 : scanCanonicalize (H12AffineFastState.compose env1560 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1561 : List Nat := [2,4,8,13,13,1,4,8,7,9,1,1,4,0,12,2,13,13,9,12,12,12,12,15,8,1,0,0,13,12,9,0,8,0,1,7]

theorem envBound1561 : H12AffineFastState.Bounded env1561 := by
  intro p hp
  have h : env1561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1560_1561 : H12AffineEnvironment.transform 3 13 env1560 = env1561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1560 == env1561) = true)

def leafEnv1561 : List Nat := [2,4,8,13,13,1,4,8,7,9,1,1,4,0,12,2,13,13,9,12,12,12,12,15,8,8,1,1,0,0,13,12,9,0,8,0,5,15,1,7,1,13,0]

def active1561 : List Nat := [0,1,2]

def tree1561 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1561 : H12WitnessSearch.Good tree1561 := H12GlobalWitnessIndex.good

theorem leafIdentity1561 : H12AffineFastState.composeSystem env1561 rootObs = leafEnv1561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1561 rootObs == leafEnv1561) = true)

theorem terminalChecked1561 : H12PackedTerminal.terminalCheckFast leafEnv1561 active1561 tree1561 = true := by decide +kernel

def env1562 : List Nat := [2,4,8,16,17,64,24,84,512,85,2048,64,2627,2587,2635,2649,2634,2064,85,2635,17,16,17,19,2643,64,2049,2587,16,2065,85,0,84,0,2586,512]

theorem envBound1562 : H12AffineFastState.Bounded env1562 := by
  intro p hp
  have h : env1562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1550_1562 : H12AffineEnvironment.transform 4 17 env1550 = env1562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1550 == env1562) = true)

def env1563 : List Nat := [2,4,8,16,17,64,24,84,512,85,0,64,579,539,587,601,586,16,85,587,17,16,17,19,595,64,1,539,16,17,85,0,84,0,538,512]

theorem envBound1563 : H12AffineFastState.Bounded env1563 := by
  intro p hp
  have h : env1563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1562_1563 : H12AffineEnvironment.transform 10 0 env1562 = env1563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1562 == env1563) = true)

theorem identity1563 : scanCanonicalize (H12AffineFastState.compose env1563 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound1563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1564 : List Nat := [2,4,8,16,17,28,24,8,512,9,0,28,543,539,535,517,534,16,9,535,17,16,17,19,527,28,1,539,16,17,9,0,8,0,538,512]

theorem envBound1564 : H12AffineFastState.Bounded env1564 := by
  intro p hp
  have h : env1564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1563_1564 : H12AffineEnvironment.transform 5 28 env1563 = env1564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env1563 == env1564) = true)

def env1565 : List Nat := [2,4,8,12,13,0,4,8,512,9,0,0,515,519,523,517,522,12,9,523,13,12,13,15,527,0,1,519,12,13,9,0,8,0,518,512]

theorem envBound1565 : H12AffineFastState.Bounded env1565 := by
  intro p hp
  have h : env1565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1564_1565 : H12AffineEnvironment.transform 3 12 env1564 = env1565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1564 == env1565) = true)

theorem identity1565 : scanCanonicalize (H12AffineFastState.compose env1565 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1565 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1566 : List Nat := [2,4,8,12,13,0,4,8,6,9,0,0,5,1,13,3,12,12,9,13,13,12,13,15,9,0,1,1,12,13,9,0,8,0,0,6]

theorem envBound1566 : H12AffineFastState.Bounded env1566 := by
  intro p hp
  have h : env1566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1565_1566 : H12AffineEnvironment.transform 8 6 env1565 = env1566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1565 == env1566) = true)

def leafEnv1566 : List Nat := [2,4,8,12,13,0,4,8,6,9,0,0,5,1,13,3,12,12,9,13,13,12,13,15,8,9,1,0,1,1,12,13,9,0,8,0,5,14,0,6,1,12,0]

def active1566 : List Nat := [0,1,2]

def tree1566 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1566 : H12WitnessSearch.Good tree1566 := H12GlobalWitnessIndex.good

theorem leafIdentity1566 : H12AffineFastState.composeSystem env1566 rootObs = leafEnv1566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1566 rootObs == leafEnv1566) = true)

theorem terminalChecked1566 : H12PackedTerminal.terminalCheckFast leafEnv1566 active1566 tree1566 = true := by decide +kernel

def env1567 : List Nat := [2,4,8,13,12,1,5,8,512,9,0,1,514,518,522,517,523,13,9,522,12,13,12,14,527,1,1,518,13,12,9,0,8,0,519,512]

theorem envBound1567 : H12AffineFastState.Bounded env1567 := by
  intro p hp
  have h : env1567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1564_1567 : H12AffineEnvironment.transform 3 13 env1564 = env1567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1564 == env1567) = true)

def leafEnv1567 : List Nat := [2,4,8,13,12,1,5,8,512,9,0,1,514,518,522,517,523,13,9,522,12,13,12,14,8,527,1,1,1,518,13,12,9,0,8,0,5,521,519,512,1,13,0]

def active1567 : List Nat := [0,1,2,8]

def tree1567 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1567 : H12WitnessSearch.Good tree1567 := H12GlobalWitnessIndex.good

theorem leafIdentity1567 : H12AffineFastState.composeSystem env1567 rootObs = leafEnv1567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1567 rootObs == leafEnv1567) = true)

theorem terminalChecked1567 : H12PackedTerminal.terminalCheckFast leafEnv1567 active1567 tree1567 = true := by decide +kernel

def env1568 : List Nat := [2,4,8,16,17,64,24,84,512,85,1,64,578,538,586,600,587,17,85,586,17,16,17,19,594,64,0,538,16,16,85,0,84,0,539,512]

theorem envBound1568 : H12AffineFastState.Bounded env1568 := by
  intro p hp
  have h : env1568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1562_1568 : H12AffineEnvironment.transform 10 1 env1562 = env1568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1562 == env1568) = true)

theorem identity1568 : scanCanonicalize (H12AffineFastState.compose env1568 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound1568 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1569 : List Nat := [2,4,8,16,17,13,24,25,512,24,1,13,527,538,519,533,518,17,24,519,17,16,17,19,543,13,0,538,16,16,24,0,25,0,539,512]

theorem envBound1569 : H12AffineFastState.Bounded env1569 := by
  intro p hp
  have h : env1569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1568_1569 : H12AffineEnvironment.transform 5 13 env1568 = env1569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env1568 == env1569) = true)

def env1570 : List Nat := [2,4,4,16,17,1,20,21,512,20,1,1,515,534,519,533,518,17,20,519,17,16,17,19,531,1,0,534,16,16,20,0,21,0,535,512]

theorem envBound1570 : H12AffineFastState.Bounded env1570 := by
  intro p hp
  have h : env1570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1569_1570 : H12AffineEnvironment.transform 2 4 env1569 = env1570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1569 == env1570) = true)

theorem identity1570 : scanCanonicalize (H12AffineFastState.compose env1570 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1571 : List Nat := [2,4,4,16,17,1,20,21,23,20,1,1,20,1,16,2,17,17,20,16,17,16,17,19,4,1,0,1,16,16,20,0,21,0,0,23]

theorem envBound1571 : H12AffineFastState.Bounded env1571 := by
  intro p hp
  have h : env1571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1570_1571 : H12AffineEnvironment.transform 8 23 env1570 = env1571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1570 == env1571) = true)

def leafEnv1571 : List Nat := [2,4,4,16,17,1,20,21,23,20,1,1,20,1,16,2,17,17,20,16,17,16,17,19,21,4,1,1,0,1,16,16,20,0,21,0,5,19,0,23,1,16,0]

def active1571 : List Nat := [0,1,3]

def tree1571 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1571 : H12WitnessSearch.Good tree1571 := H12GlobalWitnessIndex.good

theorem leafIdentity1571 : H12AffineFastState.composeSystem env1571 rootObs = leafEnv1571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1571 rootObs == leafEnv1571) = true)

theorem terminalChecked1571 : H12PackedTerminal.terminalCheckFast leafEnv1571 active1571 tree1571 = true := by decide +kernel

def env1572 : List Nat := [2,4,5,16,17,0,21,20,512,21,1,0,514,535,519,533,518,17,21,519,17,16,17,19,530,0,0,535,16,16,21,0,20,0,534,512]

theorem envBound1572 : H12AffineFastState.Bounded env1572 := by
  intro p hp
  have h : env1572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1569_1572 : H12AffineEnvironment.transform 2 5 env1569 = env1572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1569 == env1572) = true)

def leafEnv1572 : List Nat := [2,4,5,16,17,0,21,20,512,21,1,0,514,535,519,533,518,17,21,519,17,16,17,19,20,530,1,0,0,535,16,16,21,0,20,0,5,516,534,512,1,16,0]

def active1572 : List Nat := [0,1,3,8]

def tree1572 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1572 : H12WitnessSearch.Good tree1572 := H12GlobalWitnessIndex.good

theorem leafIdentity1572 : H12AffineFastState.composeSystem env1572 rootObs = leafEnv1572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1572 rootObs == leafEnv1572) = true)

theorem terminalChecked1572 : H12PackedTerminal.terminalCheckFast leafEnv1572 active1572 tree1572 = true := by decide +kernel

def env1573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,75135,8693,2097152,74078,185,74229,8328,74135,336222,16384,151553,2080,75134,1,73855,0,131332,512]

theorem envBound1573 : H12AffineFastState.Bounded env1573 := by
  intro p hp
  have h : env1573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1496_1573 : H12AffineEnvironment.transform 22 185 env1496 = env1573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env1496 == env1573) = true)

theorem identity1573 : scanCanonicalize (H12AffineFastState.compose env1573 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound1573 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1574 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8200,65536,131072,262144,74882,8200,2097152,73891,185,73736,8328,73834,336035,16384,151553,2080,74883,1,73855,0,131321,512]

theorem envBound1574 : H12AffineFastState.Bounded env1574 := by
  intro p hp
  have h : env1574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1573_1574 : H12AffineEnvironment.transform 7 253 env1573 = env1574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1573 == env1574) = true)

def env1575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,9176216,16385,151552,2081,17399809,13149549,525568,1,34359738368,25733062]

theorem envBound1575 : H12AffineFastState.Bounded env1575 := by
  intro p hp
  have h : env1575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1317_1575 : H12AffineEnvironment.transform 27 16385 env1317 = env1575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env1317 == env1575) = true)

def env1576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914001,9176216,16385,151552,2081,17375733,13108377,525568,1,34359738368,25691698]

theorem envBound1576 : H12AffineFastState.Bounded env1576 := by
  intro p hp
  have h : env1576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1575_1576 : H12AffineEnvironment.transform 14 8692 env1575 = env1576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env1575 == env1576) = true)

theorem identity1576 : scanCanonicalize (H12AffineFastState.compose env1576 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913970) := by decide +kernel

theorem selectedBound1576 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env1577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913970,8328,8914001,9176216,16385,151552,2081,8463815,13108377,525568,1,34359738368,512]

theorem envBound1577 : H12AffineFastState.Bounded env1577 := by
  intro p hp
  have h : env1577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1576_1577 : H12AffineEnvironment.transform 23 8913970 env1576 = env1577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913970 env1576 == env1577) = true)

theorem identity1577 : scanCanonicalize (H12AffineFastState.compose env1577 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525345) := by decide +kernel

theorem selectedBound1577 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,525345,8388608,8913970,8328,8914001,9176216,16385,151552,2081,8463815,8388792,525568,1,34359738368,512]

theorem envBound1578 : H12AffineFastState.Bounded env1578 := by
  intro p hp
  have h : env1578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1577_1578 : H12AffineEnvironment.transform 21 525345 env1577 = env1578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525345 env1577 == env1578) = true)

theorem identity1578 : scanCanonicalize (H12AffineFastState.compose env1578 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75135) := by decide +kernel

theorem selectedBound1578 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env1579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,8388608,8462669,8328,8462638,8724967,16385,151552,2081,8463815,8388792,73855,1,34359738368,512]

theorem envBound1579 : H12AffineFastState.Bounded env1579 := by
  intro p hp
  have h : env1579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1578_1579 : H12AffineEnvironment.transform 18 75135 env1578 = env1579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75135 env1578 == env1579) = true)

theorem identity1579 : scanCanonicalize (H12AffineFastState.compose env1579 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131332) := by decide +kernel

theorem selectedBound1579 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,8388608,8462669,8328,8462638,8724967,16385,151552,2081,8463815,8388792,73855,1,131332,512]

theorem envBound1580 : H12AffineFastState.Bounded env1580 := by
  intro p hp
  have h : env1580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1579_1580 : H12AffineEnvironment.transform 34 131332 env1579 = env1580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131332 env1579 == env1580) = true)

def env1581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,184,74229,8328,74134,336223,16385,151552,2081,75135,0,73855,1,131332,512]

theorem envBound1581 : H12AffineFastState.Bounded env1581 := by
  intro p hp
  have h : env1581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1580_1581 : H12AffineEnvironment.transform 22 184 env1580 = env1581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env1580 == env1581) = true)

theorem identity1581 : scanCanonicalize (H12AffineFastState.compose env1581 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound1581 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1582 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,74882,8201,2097152,73891,184,73736,8328,73835,336034,16385,151552,2081,74882,0,73855,1,131321,512]

theorem envBound1582 : H12AffineFastState.Bounded env1582 := by
  intro p hp
  have h : env1582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1581_1582 : H12AffineEnvironment.transform 7 253 env1581 = env1582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1581 == env1582) = true)

def env1583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75135,8692,2097152,74078,185,74228,8328,74135,336222,16385,151552,2081,75134,1,73855,1,131332,512]

theorem envBound1583 : H12AffineFastState.Bounded env1583 := by
  intro p hp
  have h : env1583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1580_1583 : H12AffineEnvironment.transform 22 185 env1580 = env1583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env1580 == env1583) = true)

theorem identity1583 : scanCanonicalize (H12AffineFastState.compose env1583 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223322) := by decide +kernel

theorem selectedBound1583 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env1584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,223322,75135,8692,2097152,74078,185,74228,8328,74135,149764,16385,151552,2081,75134,1,73855,1,131332,512]

theorem envBound1584 : H12AffineFastState.Bounded env1584 := by
  intro p hp
  have h : env1584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1583_1584 : H12AffineEnvironment.transform 17 223322 env1583 = env1584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223322 env1583 == env1584) = true)

def env1585 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74883,8200,2097152,73890,185,73736,8328,73835,149752,16385,151552,2081,74882,1,73855,1,131320,512]

theorem envBound1585 : H12AffineFastState.Bounded env1585 := by
  intro p hp
  have h : env1585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1584_1585 : H12AffineEnvironment.transform 7 252 env1584 = env1585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1584 == env1585) = true)

theorem identity1585 : scanCanonicalize (H12AffineFastState.compose env1585 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151552) := by decide +kernel

theorem selectedBound1585 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1586 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74883,8200,151552,73890,185,73736,8328,73835,149752,16385,151552,2081,74882,1,73855,1,131320,512]

theorem envBound1586 : H12AffineFastState.Bounded env1586 := by
  intro p hp
  have h : env1586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1585_1586 : H12AffineEnvironment.transform 20 151552 env1585 = env1586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151552 env1585 == env1586) = true)

theorem identity1586 : scanCanonicalize (H12AffineFastState.compose env1586 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90235) := by decide +kernel

theorem selectedBound1586 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1587 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,90235,2081,74883,8200,77947,73890,185,73736,8328,73835,75907,16385,77947,2081,74882,1,73855,1,90243,512]

theorem envBound1587 : H12AffineFastState.Bounded env1587 := by
  intro p hp
  have h : env1587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1586_1587 : H12AffineEnvironment.transform 16 90235 env1586 = env1587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90235 env1586 == env1587) = true)

theorem identity1587 : scanCanonicalize (H12AffineFastState.compose env1587 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound1587 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1588 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,8323,16632,2081,1024,8200,4344,33,185,139,8328,232,2048,16385,4344,2081,1025,1,252,1,16384,512]

theorem envBound1588 : H12AffineFastState.Bounded env1588 := by
  intro p hp
  have h : env1588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1587_1588 : H12AffineEnvironment.transform 15 8323 env1587 = env1588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env1587 == env1588) = true)

theorem identity1588 : scanCanonicalize (H12AffineFastState.compose env1588 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound1588 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1589 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5237,8200,8323,5261,2081,1024,8200,4344,33,185,139,8328,232,2048,5236,4344,2081,1025,1,252,1,5237,512]

theorem envBound1589 : H12AffineFastState.Bounded env1589 := by
  intro p hp
  have h : env1589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1588_1589 : H12AffineEnvironment.transform 13 5237 env1588 = env1589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env1588 == env1589) = true)

theorem identity1589 : scanCanonicalize (H12AffineFastState.compose env1589 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound1589 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1590 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,8192,602,8200,8323,674,2081,1024,8200,1751,33,185,139,8328,232,2048,603,1751,2081,1025,1,252,1,602,512]

theorem envBound1590 : H12AffineFastState.Bounded env1590 := by
  intro p hp
  have h : env1590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1589_1590 : H12AffineEnvironment.transform 11 1583 env1589 = env1590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env1589 == env1590) = true)

theorem identity1590 : scanCanonicalize (H12AffineFastState.compose env1590 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound1590 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1591 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,3822,602,3814,3693,674,2081,1024,3814,1751,33,185,139,3686,232,2048,603,1751,2081,1025,1,252,1,602,512]

theorem envBound1591 : H12AffineFastState.Bounded env1591 := by
  intro p hp
  have h : env1591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1590_1591 : H12AffineEnvironment.transform 12 3822 env1590 = env1591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env1590 == env1591) = true)

theorem identity1591 : scanCanonicalize (H12AffineFastState.compose env1591 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound1591 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1592 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,555,2794,602,2786,2665,674,2081,4,2786,723,33,185,139,2658,232,2048,603,723,2081,5,1,252,1,602,512]

theorem envBound1592 : H12AffineFastState.Bounded env1592 := by
  intro p hp
  have h : env1592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1591_1592 : H12AffineEnvironment.transform 9 4 env1591 = env1592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env1591 == env1592) = true)

theorem identity1592 : scanCanonicalize (H12AffineFastState.compose env1592 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1592 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1593 : List Nat := [2,4,8,16,32,64,120,4,512,4,2048,555,2578,602,2586,2665,602,2081,4,2586,555,33,65,115,2658,16,2048,603,555,2081,5,1,4,1,602,512]

theorem envBound1593 : H12AffineFastState.Bounded env1593 := by
  intro p hp
  have h : env1593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1592_1593 : H12AffineEnvironment.transform 6 120 env1592 = env1593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1592 == env1593) = true)

theorem identity1593 : scanCanonicalize (H12AffineFastState.compose env1593 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound1593 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1594 : List Nat := [2,4,8,16,32,64,120,4,512,4,608,555,114,602,122,9,602,577,4,122,555,33,65,115,2,16,608,603,555,577,5,1,4,1,602,512]

theorem envBound1594 : H12AffineFastState.Bounded env1594 := by
  intro p hp
  have h : env1594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1593_1594 : H12AffineEnvironment.transform 10 608 env1593 = env1594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env1593 == env1594) = true)

theorem identity1594 : scanCanonicalize (H12AffineFastState.compose env1594 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound1594 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1595 : List Nat := [2,4,8,16,26,64,66,4,512,4,602,529,72,602,64,9,602,577,4,64,529,27,65,73,2,16,602,603,529,577,5,1,4,1,602,512]

theorem envBound1595 : H12AffineFastState.Bounded env1595 := by
  intro p hp
  have h : env1595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1594_1595 : H12AffineEnvironment.transform 4 26 env1594 = env1595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env1594 == env1595) = true)

def env1596 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74882,8201,2097152,73891,185,73737,8328,73834,149753,16385,151552,2081,74883,1,73855,1,131321,512]

theorem envBound1596 : H12AffineFastState.Bounded env1596 := by
  intro p hp
  have h : env1596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1584_1596 : H12AffineEnvironment.transform 7 253 env1584 = env1596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1584 == env1596) = true)

theorem identity1596 : scanCanonicalize (H12AffineFastState.compose env1596 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78034) := by decide +kernel

theorem selectedBound1596 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1597 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74882,8201,78034,73891,185,73737,8328,73834,149753,16385,151552,2081,74883,1,73855,1,131321,512]

theorem envBound1597 : H12AffineFastState.Bounded env1597 := by
  intro p hp
  have h : env1597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1596_1597 : H12AffineEnvironment.transform 20 78034 env1596 = env1597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78034 env1596 == env1597) = true)

theorem identity1597 : scanCanonicalize (H12AffineFastState.compose env1597 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound1597 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1598 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7695,8201,65536,131072,210517,74882,8201,78034,73891,185,73737,8328,73834,136950,7694,134671,2081,74883,1,73855,1,131321,512]

theorem envBound1598 : H12AffineFastState.Bounded env1598 := by
  intro p hp
  have h : env1598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1597_1598 : H12AffineEnvironment.transform 13 7695 env1597 = env1598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env1597 == env1598) = true)

def env1599 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,131072,205377,74882,8201,74950,73891,185,73737,8328,73834,131810,2586,134671,2081,74883,1,73855,1,131321,512]

theorem envBound1599 : H12AffineFastState.Bounded env1599 := by
  intro p hp
  have h : env1599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1598_1599 : H12AffineEnvironment.transform 11 1044 env1598 = env1599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env1598 == env1599) = true)

def env1600 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76384,2081,74882,8201,74950,73891,185,73737,8328,73834,75906,2586,74863,2081,74883,1,73855,1,76441,512]

theorem envBound1600 : H12AffineFastState.Bounded env1600 := by
  intro p hp
  have h : env1600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1599_1600 : H12AffineEnvironment.transform 16 76384 env1599 = env1600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1599 == env1600) = true)

theorem identity1600 : scanCanonicalize (H12AffineFastState.compose env1600 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound1600 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1601 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,99,10755,2081,9441,8201,9381,8384,185,8298,8328,8201,10465,2586,9228,2081,9440,1,8220,1,11002,512]

theorem envBound1601 : H12AffineFastState.Bounded env1601 := by
  intro p hp
  have h : env1601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1600_1601 : H12AffineEnvironment.transform 15 99 env1600 = env1601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env1600 == env1601) = true)

def env1602 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76385,2080,74882,8201,74950,73891,185,73737,8328,73834,75907,2586,74862,2081,74883,1,73855,1,76440,512]

theorem envBound1602 : H12AffineFastState.Bounded env1602 := by
  intro p hp
  have h : env1602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1599_1602 : H12AffineEnvironment.transform 16 76385 env1599 = env1602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1599 == env1602) = true)

theorem identity1602 : scanCanonicalize (H12AffineFastState.compose env1602 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound1602 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1603 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2587,3614,65536,66678,2080,68245,3614,68305,69300,185,69150,3743,69245,67220,2586,68217,2081,68244,1,69224,1,66703,512]

theorem envBound1603 : H12AffineFastState.Bounded env1603 := by
  intro p hp
  have h : env1603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1602_1603 : H12AffineEnvironment.transform 12 3607 env1602 = env1603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env1602 == env1603) = true)

theorem identity1603 : scanCanonicalize (H12AffineFastState.compose env1603 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound1603 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1604 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3607,2587,3614,3733,2787,2080,1024,3614,1092,33,185,139,3743,232,2049,2586,1260,2081,1025,1,253,1,2586,512]

theorem envBound1604 : H12AffineFastState.Bounded env1604 := by
  intro p hp
  have h : env1604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1603_1604 : H12AffineEnvironment.transform 15 3733 env1603 = env1604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env1603 == env1604) = true)

theorem identity1604 : scanCanonicalize (H12AffineFastState.compose env1604 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1604 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1605 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,64,2627,2587,2634,2753,2787,2080,84,2634,16,33,185,139,2763,232,2049,2586,184,2081,85,1,253,1,2586,512]

theorem envBound1605 : H12AffineFastState.Bounded env1605 := by
  intro p hp
  have h : env1605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1604_1605 : H12AffineEnvironment.transform 9 84 env1604 = env1605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1604 == env1605) = true)

theorem identity1605 : scanCanonicalize (H12AffineFastState.compose env1605 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1605 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1606 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,64,2627,2587,2634,2665,2635,2080,84,2634,16,33,17,35,2659,64,2049,2586,16,2081,85,1,85,1,2586,512]

theorem envBound1606 : H12AffineFastState.Bounded env1606 := by
  intro p hp
  have h : env1606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1605_1606 : H12AffineEnvironment.transform 6 40 env1605 = env1606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1605 == env1606) = true)

def env1607 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,64,2627,2587,2634,2649,2635,2064,84,2634,16,17,17,19,2643,64,2049,2586,16,2065,85,1,85,1,2586,512]

theorem envBound1607 : H12AffineFastState.Bounded env1607 := by
  intro p hp
  have h : env1607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1606_1607 : H12AffineEnvironment.transform 4 16 env1606 = env1607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1606 == env1607) = true)

def env1608 : List Nat := [2,4,8,16,16,64,24,85,512,84,0,64,579,539,586,601,587,16,84,586,16,17,17,19,595,64,1,538,16,17,85,1,85,1,538,512]

theorem envBound1608 : H12AffineFastState.Bounded env1608 := by
  intro p hp
  have h : env1608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1607_1608 : H12AffineEnvironment.transform 10 0 env1607 = env1608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1607 == env1608) = true)

theorem identity1608 : scanCanonicalize (H12AffineFastState.compose env1608 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1609 : List Nat := [2,4,8,16,16,64,24,85,6,84,0,64,69,29,76,95,77,16,84,76,16,17,17,19,85,64,1,28,16,17,85,1,85,1,28,6]

theorem envBound1609 : H12AffineFastState.Bounded env1609 := by
  intro p hp
  have h : env1609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1608_1609 : H12AffineEnvironment.transform 8 6 env1608 = env1609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1608 == env1609) = true)

def env1610 : List Nat := [2,4,8,16,16,0,24,21,6,20,0,0,5,29,12,31,13,16,20,12,16,17,17,19,21,0,1,28,16,17,21,1,21,1,28,6]

theorem envBound1610 : H12AffineFastState.Bounded env1610 := by
  intro p hp
  have h : env1610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1609_1610 : H12AffineEnvironment.transform 5 0 env1609 = env1610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1609 == env1610) = true)

def leafEnv1610 : List Nat := [2,4,8,16,16,0,24,21,6,20,0,0,5,29,12,31,13,16,20,12,16,17,17,19,20,21,1,0,1,28,16,17,21,1,21,1,5,14,28,6,1,17,0]

def active1610 : List Nat := [0,1,2,3]

def tree1610 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1610 : H12WitnessSearch.Good tree1610 := H12GlobalWitnessIndex.good

theorem leafIdentity1610 : H12AffineFastState.composeSystem env1610 rootObs = leafEnv1610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1610 rootObs == leafEnv1610) = true)

theorem terminalChecked1610 : H12PackedTerminal.terminalCheckFast leafEnv1610 active1610 tree1610 = true := by decide +kernel

def env1611 : List Nat := [2,4,8,16,16,1,24,20,6,21,0,1,4,29,13,30,12,16,21,13,16,17,17,19,20,1,1,28,16,17,20,1,20,1,28,6]

theorem envBound1611 : H12AffineFastState.Bounded env1611 := by
  intro p hp
  have h : env1611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1609_1611 : H12AffineEnvironment.transform 5 1 env1609 = env1611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1609 == env1611) = true)

theorem identity1611 : scanCanonicalize (H12AffineFastState.compose env1611 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1611 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1612 : List Nat := [2,4,8,13,13,1,5,9,6,8,0,1,4,0,13,3,12,13,8,13,13,12,12,14,9,1,1,1,13,12,9,1,9,1,1,6]

theorem envBound1612 : H12AffineFastState.Bounded env1612 := by
  intro p hp
  have h : env1612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1611_1612 : H12AffineEnvironment.transform 3 13 env1611 = env1612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1611 == env1612) = true)

def leafEnv1612 : List Nat := [2,4,8,13,13,1,5,9,6,8,0,1,4,0,13,3,12,13,8,13,13,12,12,14,8,9,1,1,1,1,13,12,9,1,9,1,5,15,1,6,1,12,0]

def active1612 : List Nat := [0,1,2]

def tree1612 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1612 : H12WitnessSearch.Good tree1612 := H12GlobalWitnessIndex.good

theorem leafIdentity1612 : H12AffineFastState.composeSystem env1612 rootObs = leafEnv1612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1612 rootObs == leafEnv1612) = true)

theorem terminalChecked1612 : H12PackedTerminal.terminalCheckFast leafEnv1612 active1612 tree1612 = true := by decide +kernel

def env1613 : List Nat := [2,4,8,16,16,64,24,85,512,84,1,64,578,538,587,600,586,17,84,587,16,17,17,19,594,64,0,539,16,16,85,1,85,1,539,512]

theorem envBound1613 : H12AffineFastState.Bounded env1613 := by
  intro p hp
  have h : env1613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1607_1613 : H12AffineEnvironment.transform 10 1 env1607 = env1613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1607 == env1613) = true)

theorem identity1613 : scanCanonicalize (H12AffineFastState.compose env1613 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1614 : List Nat := [2,4,8,16,16,64,24,85,22,84,1,64,84,12,93,78,92,17,84,93,16,17,17,19,68,64,0,13,16,16,85,1,85,1,13,22]

theorem envBound1614 : H12AffineFastState.Bounded env1614 := by
  intro p hp
  have h : env1614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1613_1614 : H12AffineEnvironment.transform 8 22 env1613 = env1614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1613 == env1614) = true)

def env1615 : List Nat := [2,4,8,16,16,0,24,21,22,20,1,0,20,12,29,14,28,17,20,29,16,17,17,19,4,0,0,13,16,16,21,1,21,1,13,22]

theorem envBound1615 : H12AffineFastState.Bounded env1615 := by
  intro p hp
  have h : env1615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1614_1615 : H12AffineEnvironment.transform 5 0 env1614 = env1615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1614 == env1615) = true)

theorem identity1615 : scanCanonicalize (H12AffineFastState.compose env1615 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1615 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1616 : List Nat := [2,4,4,16,16,0,20,21,22,20,1,0,20,0,17,2,16,17,20,17,16,17,17,19,4,0,0,1,16,16,21,1,21,1,1,22]

theorem envBound1616 : H12AffineFastState.Bounded env1616 := by
  intro p hp
  have h : env1616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1615_1616 : H12AffineEnvironment.transform 2 4 env1615 = env1616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1615 == env1616) = true)

def leafEnv1616 : List Nat := [2,4,4,16,16,0,20,21,22,20,1,0,20,0,17,2,16,17,20,17,16,17,17,19,20,4,1,0,0,1,16,16,21,1,21,1,5,19,1,22,1,17,0]

def active1616 : List Nat := [0,1,3]

def tree1616 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1616 : H12WitnessSearch.Good tree1616 := H12GlobalWitnessIndex.good

theorem leafIdentity1616 : H12AffineFastState.composeSystem env1616 rootObs = leafEnv1616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1616 rootObs == leafEnv1616) = true)

theorem terminalChecked1616 : H12PackedTerminal.terminalCheckFast leafEnv1616 active1616 tree1616 = true := by decide +kernel

def env1617 : List Nat := [2,4,8,16,16,1,24,20,22,21,1,1,21,12,28,15,29,17,21,28,16,17,17,19,5,1,0,13,16,16,20,1,20,1,13,22]

theorem envBound1617 : H12AffineFastState.Bounded env1617 := by
  intro p hp
  have h : env1617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1614_1617 : H12AffineEnvironment.transform 5 1 env1614 = env1617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1614 == env1617) = true)

def leafEnv1617 : List Nat := [2,4,8,16,16,1,24,20,22,21,1,1,21,12,28,15,29,17,21,28,16,17,17,19,21,5,1,1,0,13,16,16,20,1,20,1,5,30,13,22,1,17,0]

def active1617 : List Nat := [0,1,2,3]

def tree1617 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1617 : H12WitnessSearch.Good tree1617 := H12GlobalWitnessIndex.good

theorem leafIdentity1617 : H12AffineFastState.composeSystem env1617 rootObs = leafEnv1617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1617 rootObs == leafEnv1617) = true)

theorem terminalChecked1617 : H12PackedTerminal.terminalCheckFast leafEnv1617 active1617 tree1617 = true := by decide +kernel

def env1618 : List Nat := [2,4,8,16,17,64,25,85,512,84,2048,64,2627,2587,2634,2648,2635,2065,84,2634,16,16,17,18,2642,64,2049,2586,16,2064,85,1,85,1,2586,512]

theorem envBound1618 : H12AffineFastState.Bounded env1618 := by
  intro p hp
  have h : env1618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1606_1618 : H12AffineEnvironment.transform 4 17 env1606 = env1618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1606 == env1618) = true)

def env1619 : List Nat := [2,4,8,16,17,64,25,85,512,84,0,64,579,539,586,600,587,17,84,586,16,16,17,18,594,64,1,538,16,16,85,1,85,1,538,512]

theorem envBound1619 : H12AffineFastState.Bounded env1619 := by
  intro p hp
  have h : env1619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1618_1619 : H12AffineEnvironment.transform 10 0 env1618 = env1619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1618 == env1619) = true)

theorem identity1619 : scanCanonicalize (H12AffineFastState.compose env1619 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound1619 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1620 : List Nat := [2,4,8,16,17,13,25,24,512,25,0,13,526,539,519,533,518,17,25,519,16,16,17,18,543,13,1,538,16,16,24,1,24,1,538,512]

theorem envBound1620 : H12AffineFastState.Bounded env1620 := by
  intro p hp
  have h : env1620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1619_1620 : H12AffineEnvironment.transform 5 13 env1619 = env1620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env1619 == env1620) = true)

def env1621 : List Nat := [2,4,4,16,17,1,21,20,512,21,0,1,514,535,519,533,518,17,21,519,16,16,17,18,531,1,1,534,16,16,20,1,20,1,534,512]

theorem envBound1621 : H12AffineFastState.Bounded env1621 := by
  intro p hp
  have h : env1621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1620_1621 : H12AffineEnvironment.transform 2 4 env1620 = env1621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1620 == env1621) = true)

theorem identity1621 : scanCanonicalize (H12AffineFastState.compose env1621 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1621 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1622 : List Nat := [2,4,4,16,17,1,21,20,22,21,0,1,20,1,17,3,16,17,21,17,16,16,17,18,5,1,1,0,16,16,20,1,20,1,0,22]

theorem envBound1622 : H12AffineFastState.Bounded env1622 := by
  intro p hp
  have h : env1622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1621_1622 : H12AffineEnvironment.transform 8 22 env1621 = env1622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1621 == env1622) = true)

def leafEnv1622 : List Nat := [2,4,4,16,17,1,21,20,22,21,0,1,20,1,17,3,16,17,21,17,16,16,17,18,21,5,1,1,1,0,16,16,20,1,20,1,5,19,0,22,1,17,0]

def active1622 : List Nat := [0,1,3]

def tree1622 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1622 : H12WitnessSearch.Good tree1622 := H12GlobalWitnessIndex.good

theorem leafIdentity1622 : H12AffineFastState.composeSystem env1622 rootObs = leafEnv1622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1622 rootObs == leafEnv1622) = true)

theorem terminalChecked1622 : H12PackedTerminal.terminalCheckFast leafEnv1622 active1622 tree1622 = true := by decide +kernel

def env1623 : List Nat := [2,4,5,16,17,0,20,21,512,20,0,0,515,534,519,533,518,17,20,519,16,16,17,18,530,0,1,535,16,16,21,1,21,1,535,512]

theorem envBound1623 : H12AffineFastState.Bounded env1623 := by
  intro p hp
  have h : env1623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1620_1623 : H12AffineEnvironment.transform 2 5 env1620 = env1623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1620 == env1623) = true)

def leafEnv1623 : List Nat := [2,4,5,16,17,0,20,21,512,20,0,0,515,534,519,533,518,17,20,519,16,16,17,18,20,530,1,0,1,535,16,16,21,1,21,1,5,517,535,512,1,17,0]

def active1623 : List Nat := [0,1,3,8]

def tree1623 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1623 : H12WitnessSearch.Good tree1623 := H12GlobalWitnessIndex.good

theorem leafIdentity1623 : H12AffineFastState.composeSystem env1623 rootObs = leafEnv1623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1623 rootObs == leafEnv1623) = true)

theorem terminalChecked1623 : H12PackedTerminal.terminalCheckFast leafEnv1623 active1623 tree1623 = true := by decide +kernel

def env1624 : List Nat := [2,4,8,16,17,64,25,85,512,84,1,64,578,538,587,601,586,16,84,587,16,16,17,18,595,64,0,539,16,17,85,1,85,1,539,512]

theorem envBound1624 : H12AffineFastState.Bounded env1624 := by
  intro p hp
  have h : env1624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1618_1624 : H12AffineEnvironment.transform 10 1 env1618 = env1624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1618 == env1624) = true)

theorem identity1624 : scanCanonicalize (H12AffineFastState.compose env1624 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound1624 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1625 : List Nat := [2,4,8,16,17,29,25,8,512,9,1,29,543,538,534,516,535,16,9,534,16,16,17,18,526,29,0,539,16,17,8,1,8,1,539,512]

theorem envBound1625 : H12AffineFastState.Bounded env1625 := by
  intro p hp
  have h : env1625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1624_1625 : H12AffineEnvironment.transform 5 29 env1624 = env1625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env1624 == env1625) = true)

def env1626 : List Nat := [2,4,8,12,13,1,5,8,512,9,1,1,515,518,522,516,523,12,9,522,12,12,13,14,526,1,0,519,12,13,8,1,8,1,519,512]

theorem envBound1626 : H12AffineFastState.Bounded env1626 := by
  intro p hp
  have h : env1626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1625_1626 : H12AffineEnvironment.transform 3 12 env1625 = env1626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1625 == env1626) = true)

def leafEnv1626 : List Nat := [2,4,8,12,13,1,5,8,512,9,1,1,515,518,522,516,523,12,9,522,12,12,13,14,9,526,1,1,0,519,12,13,8,1,8,1,5,520,519,512,1,13,0]

def active1626 : List Nat := [0,1,2,8]

def tree1626 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1626 : H12WitnessSearch.Good tree1626 := H12GlobalWitnessIndex.good

theorem leafIdentity1626 : H12AffineFastState.composeSystem env1626 rootObs = leafEnv1626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1626 rootObs == leafEnv1626) = true)

theorem terminalChecked1626 : H12PackedTerminal.terminalCheckFast leafEnv1626 active1626 tree1626 = true := by decide +kernel

def env1627 : List Nat := [2,4,8,13,12,0,4,8,512,9,1,0,514,519,523,516,522,13,9,523,13,13,12,15,526,0,0,518,13,12,8,1,8,1,518,512]

theorem envBound1627 : H12AffineFastState.Bounded env1627 := by
  intro p hp
  have h : env1627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1625_1627 : H12AffineEnvironment.transform 3 13 env1625 = env1627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1625 == env1627) = true)

theorem identity1627 : scanCanonicalize (H12AffineFastState.compose env1627 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1627 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1628 : List Nat := [2,4,8,13,12,0,4,8,6,9,1,0,4,1,13,2,12,13,9,13,13,13,12,15,8,0,0,0,13,12,8,1,8,1,0,6]

theorem envBound1628 : H12AffineFastState.Bounded env1628 := by
  intro p hp
  have h : env1628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1627_1628 : H12AffineEnvironment.transform 8 6 env1627 = env1628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1627 == env1628) = true)

def leafEnv1628 : List Nat := [2,4,8,13,12,0,4,8,6,9,1,0,4,1,13,2,12,13,9,13,13,13,12,15,9,8,1,0,0,0,13,12,8,1,8,1,5,15,0,6,1,12,0]

def active1628 : List Nat := [0,1,2]

def tree1628 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1628 : H12WitnessSearch.Good tree1628 := H12GlobalWitnessIndex.good

theorem leafIdentity1628 : H12AffineFastState.composeSystem env1628 rootObs = leafEnv1628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1628 rootObs == leafEnv1628) = true)

theorem terminalChecked1628 : H12PackedTerminal.terminalCheckFast leafEnv1628 active1628 tree1628 = true := by decide +kernel

def env1629 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,131072,205376,74882,8201,74951,73891,185,73737,8328,73834,131811,2587,134671,2081,74883,1,73855,1,131321,512]

theorem envBound1629 : H12AffineFastState.Bounded env1629 := by
  intro p hp
  have h : env1629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1598_1629 : H12AffineEnvironment.transform 11 1045 env1598 = env1629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env1598 == env1629) = true)

def env1630 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76384,2080,74882,8201,74951,73891,185,73737,8328,73834,75907,2587,74863,2081,74883,1,73855,1,76441,512]

theorem envBound1630 : H12AffineFastState.Bounded env1630 := by
  intro p hp
  have h : env1630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1629_1630 : H12AffineEnvironment.transform 16 76384 env1629 = env1630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1629 == env1630) = true)

theorem identity1630 : scanCanonicalize (H12AffineFastState.compose env1630 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3733) := by decide +kernel

theorem selectedBound1630 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1631 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,3733,9461,2080,10775,8201,10834,11830,185,11932,8328,12031,9750,2587,11002,2081,10774,1,12010,1,9228,512]

theorem envBound1631 : H12AffineFastState.Bounded env1631 := by
  intro p hp
  have h : env1631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1630_1631 : H12AffineEnvironment.transform 15 3733 env1630 = env1631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3733 env1630 == env1631) = true)

theorem identity1631 : scanCanonicalize (H12AffineFastState.compose env1631 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3607) := by decide +kernel

theorem selectedBound1631 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1632 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3607,2586,3614,3733,2786,2080,1024,3614,1093,33,185,139,3743,232,2049,2587,1261,2081,1025,1,253,1,2587,512]

theorem envBound1632 : H12AffineFastState.Bounded env1632 := by
  intro p hp
  have h : env1632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1631_1632 : H12AffineEnvironment.transform 12 3607 env1631 = env1632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3607 env1631 == env1632) = true)

theorem identity1632 : scanCanonicalize (H12AffineFastState.compose env1632 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1632 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1633 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,65,2627,2586,2634,2753,2786,2080,84,2634,17,33,185,139,2763,232,2049,2587,185,2081,85,1,253,1,2587,512]

theorem envBound1633 : H12AffineFastState.Bounded env1633 := by
  intro p hp
  have h : env1633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1632_1633 : H12AffineEnvironment.transform 9 84 env1632 = env1633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1632 == env1633) = true)

theorem identity1633 : scanCanonicalize (H12AffineFastState.compose env1633 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1633 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1634 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,65,2627,2586,2634,2665,2634,2080,84,2634,17,33,17,35,2659,64,2049,2587,17,2081,85,1,85,1,2587,512]

theorem envBound1634 : H12AffineFastState.Bounded env1634 := by
  intro p hp
  have h : env1634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1633_1634 : H12AffineEnvironment.transform 6 40 env1633 = env1634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1633 == env1634) = true)

def env1635 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,65,2627,2586,2634,2649,2634,2064,84,2634,17,17,17,19,2643,64,2049,2587,17,2065,85,1,85,1,2587,512]

theorem envBound1635 : H12AffineFastState.Bounded env1635 := by
  intro p hp
  have h : env1635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1634_1635 : H12AffineEnvironment.transform 4 16 env1634 = env1635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1634 == env1635) = true)

def env1636 : List Nat := [2,4,8,16,16,64,24,85,512,84,0,65,579,538,586,601,586,16,84,586,17,17,17,19,595,64,1,539,17,17,85,1,85,1,539,512]

theorem envBound1636 : H12AffineFastState.Bounded env1636 := by
  intro p hp
  have h : env1636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1635_1636 : H12AffineEnvironment.transform 10 0 env1635 = env1636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1635 == env1636) = true)

theorem identity1636 : scanCanonicalize (H12AffineFastState.compose env1636 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1636 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1637 : List Nat := [2,4,4,16,16,64,20,85,512,84,0,65,579,534,582,597,582,16,84,582,17,17,17,19,595,64,1,535,17,17,85,1,85,1,535,512]

theorem envBound1637 : H12AffineFastState.Bounded env1637 := by
  intro p hp
  have h : env1637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1636_1637 : H12AffineEnvironment.transform 2 4 env1636 = env1637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1636 == env1637) = true)

def env1638 : List Nat := [2,4,4,16,16,0,20,21,512,20,0,1,515,534,518,533,518,16,20,518,17,17,17,19,531,0,1,535,17,17,21,1,21,1,535,512]

theorem envBound1638 : H12AffineFastState.Bounded env1638 := by
  intro p hp
  have h : env1638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1637_1638 : H12AffineEnvironment.transform 5 0 env1637 = env1638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1637 == env1638) = true)

theorem identity1638 : scanCanonicalize (H12AffineFastState.compose env1638 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1638 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1639 : List Nat := [2,4,4,16,16,0,20,21,23,20,0,1,20,1,17,2,17,16,20,17,17,17,17,19,4,0,1,0,17,17,21,1,21,1,0,23]

theorem envBound1639 : H12AffineFastState.Bounded env1639 := by
  intro p hp
  have h : env1639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1638_1639 : H12AffineEnvironment.transform 8 23 env1638 = env1639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1638 == env1639) = true)

def leafEnv1639 : List Nat := [2,4,4,16,16,0,20,21,23,20,0,1,20,1,17,2,17,16,20,17,17,17,17,19,20,4,1,0,1,0,17,17,21,1,21,1,5,19,0,23,1,16,0]

def active1639 : List Nat := [0,1,3]

def tree1639 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1639 : H12WitnessSearch.Good tree1639 := H12GlobalWitnessIndex.good

theorem leafIdentity1639 : H12AffineFastState.composeSystem env1639 rootObs = leafEnv1639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1639 rootObs == leafEnv1639) = true)

theorem terminalChecked1639 : H12PackedTerminal.terminalCheckFast leafEnv1639 active1639 tree1639 = true := by decide +kernel

def env1640 : List Nat := [2,4,4,16,16,1,20,20,512,21,0,0,514,534,519,532,519,16,21,519,17,17,17,19,530,1,1,535,17,17,20,1,20,1,535,512]

theorem envBound1640 : H12AffineFastState.Bounded env1640 := by
  intro p hp
  have h : env1640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1637_1640 : H12AffineEnvironment.transform 5 1 env1637 = env1640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1637 == env1640) = true)

def leafEnv1640 : List Nat := [2,4,4,16,16,1,20,20,512,21,0,0,514,534,519,532,519,16,21,519,17,17,17,19,21,530,1,1,1,535,17,17,20,1,20,1,5,517,535,512,1,16,0]

def active1640 : List Nat := [0,1,3,8]

def tree1640 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1640 : H12WitnessSearch.Good tree1640 := H12GlobalWitnessIndex.good

theorem leafIdentity1640 : H12AffineFastState.composeSystem env1640 rootObs = leafEnv1640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1640 rootObs == leafEnv1640) = true)

theorem terminalChecked1640 : H12PackedTerminal.terminalCheckFast leafEnv1640 active1640 tree1640 = true := by decide +kernel

def env1641 : List Nat := [2,4,8,16,16,64,24,85,512,84,1,65,578,539,587,600,587,17,84,587,17,17,17,19,594,64,0,538,17,16,85,1,85,1,538,512]

theorem envBound1641 : H12AffineFastState.Bounded env1641 := by
  intro p hp
  have h : env1641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1635_1641 : H12AffineEnvironment.transform 10 1 env1635 = env1641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1635 == env1641) = true)

theorem identity1641 : scanCanonicalize (H12AffineFastState.compose env1641 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1642 : List Nat := [2,4,8,13,13,64,5,72,512,73,1,65,578,518,587,581,587,12,73,587,12,12,12,14,591,64,0,519,12,13,72,1,72,1,519,512]

theorem envBound1642 : H12AffineFastState.Bounded env1642 := by
  intro p hp
  have h : env1642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1641_1642 : H12AffineEnvironment.transform 3 13 env1641 = env1642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1641 == env1642) = true)

def env1643 : List Nat := [2,4,8,13,13,0,5,8,512,9,1,1,514,518,523,517,523,12,9,523,12,12,12,14,527,0,0,519,12,13,8,1,8,1,519,512]

theorem envBound1643 : H12AffineFastState.Bounded env1643 := by
  intro p hp
  have h : env1643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1642_1643 : H12AffineEnvironment.transform 5 0 env1642 = env1643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1642 == env1643) = true)

def leafEnv1643 : List Nat := [2,4,8,13,13,0,5,8,512,9,1,1,514,518,523,517,523,12,9,523,12,12,12,14,9,527,1,0,0,519,12,13,8,1,8,1,5,521,519,512,1,13,0]

def active1643 : List Nat := [0,1,2,8]

def tree1643 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1643 : H12WitnessSearch.Good tree1643 := H12GlobalWitnessIndex.good

theorem leafIdentity1643 : H12AffineFastState.composeSystem env1643 rootObs = leafEnv1643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1643 rootObs == leafEnv1643) = true)

theorem terminalChecked1643 : H12PackedTerminal.terminalCheckFast leafEnv1643 active1643 tree1643 = true := by decide +kernel

def env1644 : List Nat := [2,4,8,13,13,1,5,9,512,8,1,0,515,518,522,516,522,12,8,522,12,12,12,14,526,1,0,519,12,13,9,1,9,1,519,512]

theorem envBound1644 : H12AffineFastState.Bounded env1644 := by
  intro p hp
  have h : env1644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1642_1644 : H12AffineEnvironment.transform 5 1 env1642 = env1644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1642 == env1644) = true)

theorem identity1644 : scanCanonicalize (H12AffineFastState.compose env1644 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1645 : List Nat := [2,4,8,13,13,1,5,9,7,8,1,0,4,1,13,3,13,12,8,13,12,12,12,14,9,1,0,0,12,13,9,1,9,1,0,7]

theorem envBound1645 : H12AffineFastState.Bounded env1645 := by
  intro p hp
  have h : env1645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1644_1645 : H12AffineEnvironment.transform 8 7 env1644 = env1645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1644 == env1645) = true)

def leafEnv1645 : List Nat := [2,4,8,13,13,1,5,9,7,8,1,0,4,1,13,3,13,12,8,13,12,12,12,14,8,9,1,1,0,0,12,13,9,1,9,1,5,15,0,7,1,13,0]

def active1645 : List Nat := [0,1,2]

def tree1645 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1645 : H12WitnessSearch.Good tree1645 := H12GlobalWitnessIndex.good

theorem leafIdentity1645 : H12AffineFastState.composeSystem env1645 rootObs = leafEnv1645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1645 rootObs == leafEnv1645) = true)

theorem terminalChecked1645 : H12PackedTerminal.terminalCheckFast leafEnv1645 active1645 tree1645 = true := by decide +kernel

def env1646 : List Nat := [2,4,8,16,17,64,25,85,512,84,2048,65,2627,2586,2634,2648,2634,2065,84,2634,17,16,17,18,2642,64,2049,2587,17,2064,85,1,85,1,2587,512]

theorem envBound1646 : H12AffineFastState.Bounded env1646 := by
  intro p hp
  have h : env1646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1634_1646 : H12AffineEnvironment.transform 4 17 env1634 = env1646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1634 == env1646) = true)

def env1647 : List Nat := [2,4,8,16,17,64,25,85,512,84,0,65,579,538,586,600,586,17,84,586,17,16,17,18,594,64,1,539,17,16,85,1,85,1,539,512]

theorem envBound1647 : H12AffineFastState.Bounded env1647 := by
  intro p hp
  have h : env1647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1646_1647 : H12AffineEnvironment.transform 10 0 env1646 = env1647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1646 == env1647) = true)

theorem identity1647 : scanCanonicalize (H12AffineFastState.compose env1647 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound1647 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1648 : List Nat := [2,4,8,16,17,64,25,85,71,84,0,65,4,93,13,31,13,17,84,13,17,16,17,18,21,64,1,92,17,16,85,1,85,1,92,71]

theorem envBound1648 : H12AffineFastState.Bounded env1648 := by
  intro p hp
  have h : env1648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1647_1648 : H12AffineEnvironment.transform 8 71 env1647 = env1648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env1647 == env1648) = true)

def env1649 : List Nat := [2,4,8,16,17,0,25,21,7,20,0,1,4,29,13,31,13,17,20,13,17,16,17,18,21,0,1,28,17,16,21,1,21,1,28,7]

theorem envBound1649 : H12AffineFastState.Bounded env1649 := by
  intro p hp
  have h : env1649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1648_1649 : H12AffineEnvironment.transform 5 0 env1648 = env1649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1648 == env1649) = true)

theorem identity1649 : scanCanonicalize (H12AffineFastState.compose env1649 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1649 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1650 : List Nat := [2,4,8,13,12,0,4,8,7,9,0,1,4,0,13,2,13,12,9,13,12,13,12,15,8,0,1,1,12,13,8,1,8,1,1,7]

theorem envBound1650 : H12AffineFastState.Bounded env1650 := by
  intro p hp
  have h : env1650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1649_1650 : H12AffineEnvironment.transform 3 13 env1649 = env1650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1649 == env1650) = true)

def leafEnv1650 : List Nat := [2,4,8,13,12,0,4,8,7,9,0,1,4,0,13,2,13,12,9,13,12,13,12,15,9,8,1,0,1,1,12,13,8,1,8,1,5,15,1,7,1,13,0]

def active1650 : List Nat := [0,1,2]

def tree1650 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1650 : H12WitnessSearch.Good tree1650 := H12GlobalWitnessIndex.good

theorem leafIdentity1650 : H12AffineFastState.composeSystem env1650 rootObs = leafEnv1650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1650 rootObs == leafEnv1650) = true)

theorem terminalChecked1650 : H12PackedTerminal.terminalCheckFast leafEnv1650 active1650 tree1650 = true := by decide +kernel

def env1651 : List Nat := [2,4,8,16,17,1,25,20,6,21,0,0,4,28,13,31,13,17,21,13,17,16,17,18,21,1,1,29,17,16,20,1,20,1,29,6]

theorem envBound1651 : H12AffineFastState.Bounded env1651 := by
  intro p hp
  have h : env1651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1648_1651 : H12AffineEnvironment.transform 5 1 env1648 = env1651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1648 == env1651) = true)

def leafEnv1651 : List Nat := [2,4,8,16,17,1,25,20,6,21,0,0,4,28,13,31,13,17,21,13,17,16,17,18,21,21,1,1,1,29,17,16,20,1,20,1,5,15,29,6,1,16,0]

def active1651 : List Nat := [0,1,2,3]

def tree1651 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1651 : H12WitnessSearch.Good tree1651 := H12GlobalWitnessIndex.good

theorem leafIdentity1651 : H12AffineFastState.composeSystem env1651 rootObs = leafEnv1651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1651 rootObs == leafEnv1651) = true)

theorem terminalChecked1651 : H12PackedTerminal.terminalCheckFast leafEnv1651 active1651 tree1651 = true := by decide +kernel

def env1652 : List Nat := [2,4,8,16,17,64,25,85,512,84,1,65,578,539,587,601,587,16,84,587,17,16,17,18,595,64,0,538,17,17,85,1,85,1,538,512]

theorem envBound1652 : H12AffineFastState.Bounded env1652 := by
  intro p hp
  have h : env1652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1646_1652 : H12AffineEnvironment.transform 10 1 env1646 = env1652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1646 == env1652) = true)

theorem identity1652 : scanCanonicalize (H12AffineFastState.compose env1652 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound1652 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1653 : List Nat := [2,4,8,16,17,64,25,85,86,84,1,65,20,77,29,15,29,16,84,29,17,16,17,18,5,64,0,76,17,17,85,1,85,1,76,86]

theorem envBound1653 : H12AffineFastState.Bounded env1653 := by
  intro p hp
  have h : env1653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1652_1653 : H12AffineEnvironment.transform 8 86 env1652 = env1653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env1652 == env1653) = true)

def env1654 : List Nat := [2,4,8,16,17,0,25,21,22,20,1,1,20,13,29,15,29,16,20,29,17,16,17,18,5,0,0,12,17,17,21,1,21,1,12,22]

theorem envBound1654 : H12AffineFastState.Bounded env1654 := by
  intro p hp
  have h : env1654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1653_1654 : H12AffineEnvironment.transform 5 0 env1653 = env1654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1653 == env1654) = true)

def leafEnv1654 : List Nat := [2,4,8,16,17,0,25,21,22,20,1,1,20,13,29,15,29,16,20,29,17,16,17,18,20,5,1,0,0,12,17,17,21,1,21,1,5,31,12,22,1,16,0]

def active1654 : List Nat := [0,1,2,3]

def tree1654 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1654 : H12WitnessSearch.Good tree1654 := H12GlobalWitnessIndex.good

theorem leafIdentity1654 : H12AffineFastState.composeSystem env1654 rootObs = leafEnv1654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1654 rootObs == leafEnv1654) = true)

theorem terminalChecked1654 : H12PackedTerminal.terminalCheckFast leafEnv1654 active1654 tree1654 = true := by decide +kernel

def env1655 : List Nat := [2,4,8,16,17,1,25,20,23,21,1,0,20,12,29,15,29,16,21,29,17,16,17,18,5,1,0,13,17,17,20,1,20,1,13,23]

theorem envBound1655 : H12AffineFastState.Bounded env1655 := by
  intro p hp
  have h : env1655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1653_1655 : H12AffineEnvironment.transform 5 1 env1653 = env1655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1653 == env1655) = true)

theorem identity1655 : scanCanonicalize (H12AffineFastState.compose env1655 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1656 : List Nat := [2,4,4,16,17,1,21,20,23,21,1,0,20,0,17,3,17,16,21,17,17,16,17,18,5,1,0,1,17,17,20,1,20,1,1,23]

theorem envBound1656 : H12AffineFastState.Bounded env1656 := by
  intro p hp
  have h : env1656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1655_1656 : H12AffineEnvironment.transform 2 4 env1655 = env1656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1655 == env1656) = true)

def leafEnv1656 : List Nat := [2,4,4,16,17,1,21,20,23,21,1,0,20,0,17,3,17,16,21,17,17,16,17,18,21,5,1,1,0,1,17,17,20,1,20,1,5,19,1,23,1,16,0]

def active1656 : List Nat := [0,1,3]

def tree1656 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1656 : H12WitnessSearch.Good tree1656 := H12GlobalWitnessIndex.good

theorem leafIdentity1656 : H12AffineFastState.composeSystem env1656 rootObs = leafEnv1656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1656 rootObs == leafEnv1656) = true)

theorem terminalChecked1656 : H12PackedTerminal.terminalCheckFast leafEnv1656 active1656 tree1656 = true := by decide +kernel

def env1657 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76385,2081,74882,8201,74951,73891,185,73737,8328,73834,75906,2587,74862,2081,74883,1,73855,1,76440,512]

theorem envBound1657 : H12AffineFastState.Bounded env1657 := by
  intro p hp
  have h : env1657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1629_1657 : H12AffineEnvironment.transform 16 76385 env1629 = env1657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1629 == env1657) = true)

theorem identity1657 : scanCanonicalize (H12AffineFastState.compose env1657 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound1657 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1658 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,225,2586,232,65536,68224,2081,66659,232,66598,65602,185,65768,105,65675,67683,2587,66703,2081,66658,1,65694,1,68217,512]

theorem envBound1658 : H12AffineFastState.Bounded env1658 := by
  intro p hp
  have h : env1658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1657_1658 : H12AffineEnvironment.transform 12 225 env1657 = env1658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env1657 == env1658) = true)

def env1659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914001,9176216,16385,151552,2081,17375732,13108376,525568,1,34359738368,25691699]

theorem envBound1659 : H12AffineFastState.Bounded env1659 := by
  intro p hp
  have h : env1659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1575_1659 : H12AffineEnvironment.transform 14 8693 env1575 = env1659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env1575 == env1659) = true)

def env1660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147520,16777216,8328,672785,935128,16385,151552,2081,17375732,4867288,525568,1,34359738368,17450611]

theorem envBound1660 : H12AffineFastState.Bounded env1660 := by
  intro p hp
  have h : env1660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1659_1660 : H12AffineEnvironment.transform 22 147520 env1659 = env1660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env1659 == env1660) = true)

def env1661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2081,16852468,4341976,256,1,34359738368,16925299]

theorem envBound1661 : H12AffineFastState.Bounded env1661 := by
  intro p hp
  have h : env1661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1660_1661 : H12AffineEnvironment.transform 18 1024 env1660 = env1661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1660 == env1661) = true)

def env1662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2081,16852468,4341976,256,1,131072,16925299]

theorem envBound1662 : H12AffineFastState.Bounded env1662 := by
  intro p hp
  have h : env1662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1661_1662 : H12AffineEnvironment.transform 34 131072 env1661 = env1662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1661 == env1662) = true)

theorem identity1662 : scanCanonicalize (H12AffineFastState.compose env1662 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6497405) := by decide +kernel

theorem selectedBound1662 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,6497405,8328,147473,409816,16385,151552,2081,6422921,4341976,256,1,131072,6383118]

theorem envBound1663 : H12AffineFastState.Bounded env1663 := by
  intro p hp
  have h : env1663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1662_1663 : H12AffineEnvironment.transform 23 6497405 env1662 = env1663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6497405 env1662 == env1663) = true)

theorem identity1663 : scanCanonicalize (H12AffineFastState.compose env1663 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 2303223) := by decide +kernel

theorem selectedBound1663 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,2303223,147520,138,8328,147473,409816,16385,151552,2081,75134,2188335,256,1,131072,148217]

theorem envBound1664 : H12AffineFastState.Bounded env1664 := by
  intro p hp
  have h : env1664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1663_1664 : H12AffineEnvironment.transform 21 2303223 env1663 = env1664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2303223 env1663 == env1664) = true)

theorem identity1664 : scanCanonicalize (H12AffineFastState.compose env1664 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 91602) := by decide +kernel

theorem selectedBound1664 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env1665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,91602,147749,147520,138,8328,147473,409816,16385,151552,2081,75134,509,256,1,131072,148217]

theorem envBound1665 : H12AffineFastState.Bounded env1665 := by
  intro p hp
  have h : env1665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1664_1665 : H12AffineEnvironment.transform 20 91602 env1664 = env1665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91602 env1664 == env1665) = true)

theorem identity1665 : scanCanonicalize (H12AffineFastState.compose env1665 (packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1665 : packedSelected [0,1,5,7,8,9,11,17,18,19,20,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env1666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,131072,262144,1024,8693,17580,147749,147520,138,8328,147473,409816,16385,151552,2081,1024,509,256,1,131072,148217]

theorem envBound1666 : H12AffineFastState.Bounded env1666 := by
  intro p hp
  have h : env1666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1665_1666 : H12AffineEnvironment.transform 15 8574 env1665 = env1666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1665 == env1666) = true)

def env1667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16632,262144,1024,8693,17580,477,184,138,8328,233,262176,16385,4344,2081,1024,509,256,1,16632,513]

theorem envBound1667 : H12AffineFastState.Bounded env1667 := by
  intro p hp
  have h : env1667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1666_1667 : H12AffineEnvironment.transform 16 16632 env1666 = env1667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1666 == env1667) = true)

theorem identity1667 : scanCanonicalize (H12AffineFastState.compose env1667 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound1667 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13576,8693,8574,13808,262144,1024,8693,12708,477,184,138,8328,233,262176,13577,4344,2081,1024,509,256,1,13808,513]

theorem envBound1668 : H12AffineFastState.Bounded env1668 := by
  intro p hp
  have h : env1668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1667_1668 : H12AffineEnvironment.transform 13 13576 env1667 = env1668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env1667 == env1668) = true)

theorem identity1668 : scanCanonicalize (H12AffineFastState.compose env1668 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound1668 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,9,5377,508,375,5625,262144,1024,508,4525,477,184,138,129,233,262176,5376,4344,2081,1024,509,256,1,5625,513]

theorem envBound1669 : H12AffineFastState.Bounded env1669 := by
  intro p hp
  have h : env1669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1668_1669 : H12AffineEnvironment.transform 12 9 env1668 = env1669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env1668 == env1669) = true)

theorem identity1669 : scanCanonicalize (H12AffineFastState.compose env1669 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound1669 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1670 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,9,5140,233,98,5356,262144,1024,233,4280,200,184,138,129,233,262176,5141,4344,2081,1024,232,21,1,5356,513]

theorem envBound1670 : H12AffineFastState.Bounded env1670 := by
  intro p hp
  have h : env1670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1669_1670 : H12AffineEnvironment.transform 7 21 env1669 = env1670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env1669 == env1670) = true)

theorem identity1670 : scanCanonicalize (H12AffineFastState.compose env1670 (packedSelected [1,2,8,10,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound1670 : packedSelected [1,2,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env1671 : List Nat := [2,4,8,16,32,0,128,21,512,1024,2048,4096,9,5140,169,34,5292,262144,1024,169,4280,136,184,138,129,169,262176,5141,4280,2081,1024,168,21,1,5292,513]

theorem envBound1671 : H12AffineFastState.Bounded env1671 := by
  intro p hp
  have h : env1671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1670_1671 : H12AffineEnvironment.transform 5 0 env1670 = env1671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1670 == env1671) = true)

def env1672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,262144,1024,8693,17580,476,185,138,8328,232,262177,16385,4345,2081,1024,509,256,1,16633,512]

theorem envBound1672 : H12AffineFastState.Bounded env1672 := by
  intro p hp
  have h : env1672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1666_1672 : H12AffineEnvironment.transform 16 16633 env1666 = env1672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1666 == env1672) = true)

theorem identity1672 : scanCanonicalize (H12AffineFastState.compose env1672 (packedSelected [0,2,4,6,7,9,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound1672 : packedSelected [0,2,4,6,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,10281,1024,8693,17580,476,185,138,8328,232,10248,16385,4345,2081,1024,509,256,1,16633,512]

theorem envBound1673 : H12AffineFastState.Bounded env1673 := by
  intro p hp
  have h : env1673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1672_1673 : H12AffineEnvironment.transform 17 10281 env1672 = env1673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env1672 == env1673) = true)

theorem identity1673 : scanCanonicalize (H12AffineFastState.compose env1673 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound1673 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env1674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,16384,81,218,16633,2445,1024,81,17580,476,185,138,300,232,2476,16385,4345,2081,1024,509,256,1,16633,512]

theorem envBound1674 : H12AffineFastState.Bounded env1674 := by
  intro p hp
  have h : env1674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1673_1674 : H12AffineEnvironment.transform 12 420 env1673 = env1674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env1673 == env1674) = true)

theorem identity1674 : scanCanonicalize (H12AffineFastState.compose env1674 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound1674 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env1675 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,4096,420,16384,16,155,16568,2445,1024,16,17580,413,185,138,300,169,2476,16385,4280,2081,1024,444,256,1,16568,512]

theorem envBound1675 : H12AffineFastState.Bounded env1675 := by
  intro p hp
  have h : env1675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1674_1675 : H12AffineEnvironment.transform 5 1 env1674 = env1675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1674 == env1675) = true)

def env1676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147473,409816,16385,151552,2081,16852468,4341976,256,1,131073,16925299]

theorem envBound1676 : H12AffineFastState.Bounded env1676 := by
  intro p hp
  have h : env1676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1661_1676 : H12AffineEnvironment.transform 34 131073 env1661 = env1676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1661 == env1676) = true)

theorem identity1676 : scanCanonicalize (H12AffineFastState.compose env1676 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4404348) := by decide +kernel

theorem selectedBound1676 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,4404348,8328,147473,409816,16385,151552,2081,4329864,4341976,256,1,131073,4290063]

theorem envBound1677 : H12AffineFastState.Bounded env1677 := by
  intro p hp
  have h : env1677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1676_1677 : H12AffineEnvironment.transform 23 4404348 env1676 = env1677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4404348 env1676 == env1677) = true)

theorem identity1677 : scanCanonicalize (H12AffineFastState.compose env1677 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5544) := by decide +kernel

theorem selectedBound1677 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,5544,262144,1024,8693,2097152,4194304,21992,4268500,8328,21945,284016,16385,17832,2081,4195360,4216176,256,1,5545,4290063]

theorem envBound1678 : H12AffineFastState.Bounded env1678 := by
  intro p hp
  have h : env1678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1677_1678 : H12AffineEnvironment.transform 16 5544 env1677 = env1678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5544 env1677 == env1678) = true)

theorem identity1678 : scanCanonicalize (H12AffineFastState.compose env1678 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1678 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,5544,262144,1024,8693,2097152,4194304,21992,4194474,8328,21945,284016,16385,17832,2081,4195360,4216176,256,1,5545,4216689]

theorem envBound1679 : H12AffineFastState.Bounded env1679 := by
  intro p hp
  have h : env1679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1678_1679 : H12AffineEnvironment.transform 15 8574 env1678 = env1679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1678 == env1679) = true)

def env1680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8693,8574,5544,262144,1024,8693,2097152,4194304,184,4194474,8328,233,262176,5457,4344,2081,4195360,4194336,256,1,5545,4194849]

theorem envBound1680 : H12AffineFastState.Bounded env1680 := by
  intro p hp
  have h : env1680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1679_1680 : H12AffineEnvironment.transform 13 5456 env1679 = env1680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env1679 == env1680) = true)

def env1681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8693,8574,5544,262144,1024,8693,2097152,4194304,185,4194474,8328,232,262177,5456,4345,2081,4195360,4194337,256,1,5545,4194848]

theorem envBound1681 : H12AffineFastState.Bounded env1681 := by
  intro p hp
  have h : env1681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1679_1681 : H12AffineEnvironment.transform 13 5457 env1679 = env1681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env1679 == env1681) = true)

theorem identity1681 : scanCanonicalize (H12AffineFastState.compose env1681 (packedSelected [1,3,4,5,8,9,10,13,19,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 264273) := by decide +kernel

theorem selectedBound1681 : packedSelected [1,3,4,5,8,9,10,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env1682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8693,8574,5544,262144,1024,8693,2097152,264273,185,264443,8328,232,262177,5456,4345,2081,265329,264304,256,1,5545,264817]

theorem envBound1682 : H12AffineFastState.Bounded env1682 := by
  intro p hp
  have h : env1682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1681_1682 : H12AffineEnvironment.transform 21 264273 env1681 = env1682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264273 env1681 == env1682) = true)

theorem identity1682 : scanCanonicalize (H12AffineFastState.compose env1682 (packedSelected [1,4,5,8,9,19,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound1682 : packedSelected [1,4,5,8,9,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env1683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8693,8574,5544,2264,1024,8693,2097152,137,185,35,8328,232,2297,5456,4345,2081,1193,168,256,1,5545,681]

theorem envBound1683 : H12AffineFastState.Bounded env1683 := by
  intro p hp
  have h : env1683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1682_1683 : H12AffineEnvironment.transform 17 2264 env1682 = env1683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env1682 == env1683) = true)

theorem identity1683 : scanCanonicalize (H12AffineFastState.compose env1683 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(20+1) ^^^ 12621) := by decide +kernel

theorem selectedBound1683 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env1684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8693,8574,5544,2264,1024,8693,12621,137,185,35,8328,232,2297,5456,4345,2081,1193,168,256,1,5545,681]

theorem envBound1684 : H12AffineFastState.Bounded env1684 := by
  intro p hp
  have h : env1684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1683_1684 : H12AffineEnvironment.transform 20 12621 env1683 = env1684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12621 env1683 == env1684) = true)

theorem identity1684 : scanCanonicalize (H12AffineFastState.compose env1684 (packedSelected [0,2,3,5,6,7,10,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1684 : packedSelected [0,2,3,5,6,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env1685 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,5457,8541,8574,5376,2160,1024,8541,12621,33,17,35,8224,64,2129,5456,4177,2081,1025,0,256,1,5377,513]

theorem envBound1685 : H12AffineFastState.Bounded env1685 := by
  intro p hp
  have h : env1685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1684_1685 : H12AffineEnvironment.transform 6 40 env1684 = env1685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1684 == env1685) = true)

theorem identity1685 : scanCanonicalize (H12AffineFastState.compose env1685 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound1685 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env1686 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,3329,8192,2128,8541,8574,2049,2160,1024,8541,11340,33,17,35,8224,64,2129,2129,3408,2081,1025,0,256,1,2048,513]

theorem envBound1686 : H12AffineFastState.Bounded env1686 := by
  intro p hp
  have h : env1686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1685_1686 : H12AffineEnvironment.transform 11 3329 env1685 = env1686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env1685 == env1686) = true)

theorem identity1686 : scanCanonicalize (H12AffineFastState.compose env1686 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound1686 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env1687 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,3329,2168,2128,2341,2310,2049,2160,1024,2341,1076,33,17,35,2136,64,2129,2129,3408,2081,1025,0,256,1,2048,513]

theorem envBound1687 : H12AffineFastState.Bounded env1687 := by
  intro p hp
  have h : env1687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1686_1687 : H12AffineEnvironment.transform 12 2168 env1686 = env1687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env1686 == env1687) = true)

theorem identity1687 : scanCanonicalize (H12AffineFastState.compose env1687 (packedSelected [2,10] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound1687 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env1688 : List Nat := [2,4,8,16,32,64,40,256,512,1024,33,1312,89,113,260,295,32,81,1024,260,1076,33,17,35,121,64,112,112,1393,0,1025,0,256,1,33,513]

theorem envBound1688 : H12AffineFastState.Bounded env1688 := by
  intro p hp
  have h : env1688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1687_1688 : H12AffineEnvironment.transform 10 33 env1687 = env1688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env1687 == env1688) = true)

theorem identity1688 : scanCanonicalize (H12AffineFastState.compose env1688 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound1688 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env1689 : List Nat := [2,4,8,16,32,16,40,256,512,1024,33,1312,9,33,260,295,32,1,1024,260,1076,33,17,35,41,16,32,32,1313,0,1025,0,256,1,33,513]

theorem envBound1689 : H12AffineFastState.Bounded env1689 := by
  intro p hp
  have h : env1689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1688_1689 : H12AffineEnvironment.transform 5 16 env1688 = env1689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env1688 == env1689) = true)

theorem identity1689 : scanCanonicalize (H12AffineFastState.compose env1689 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound1689 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env1690 : List Nat := [2,4,8,16,32,16,40,256,292,1024,33,1312,9,33,260,295,32,1,1024,260,1076,33,17,35,41,16,32,32,1313,0,1025,0,256,1,33,293]

theorem envBound1690 : H12AffineFastState.Bounded env1690 := by
  intro p hp
  have h : env1690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1689_1690 : H12AffineEnvironment.transform 8 292 env1689 = env1690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env1689 == env1690) = true)

theorem identity1690 : scanCanonicalize (H12AffineFastState.compose env1690 (packedSelected [1,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound1690 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env1691 : List Nat := [2,4,8,16,32,16,40,256,292,30,33,318,9,33,260,295,32,1,30,260,42,33,17,35,41,16,32,32,319,0,31,0,256,1,33,293]

theorem envBound1691 : H12AffineFastState.Bounded env1691 := by
  intro p hp
  have h : env1691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1690_1691 : H12AffineEnvironment.transform 9 30 env1690 = env1691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env1690 == env1691) = true)

theorem identity1691 : scanCanonicalize (H12AffineFastState.compose env1691 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound1691 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env1692 : List Nat := [2,4,8,16,32,16,40,30,58,30,33,32,9,33,26,57,32,1,30,26,42,33,17,35,41,16,32,32,33,0,31,0,30,1,33,59]

theorem envBound1692 : H12AffineFastState.Bounded env1692 := by
  intro p hp
  have h : env1692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1691_1692 : H12AffineEnvironment.transform 7 30 env1691 = env1692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env1691 == env1692) = true)

theorem identity1692 : scanCanonicalize (H12AffineFastState.compose env1692 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound1692 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env1693 : List Nat := [2,4,8,16,13,16,5,30,23,30,12,13,9,12,26,20,13,1,30,26,7,12,17,14,4,16,13,13,12,0,31,0,30,1,12,22]

theorem envBound1693 : H12AffineFastState.Bounded env1693 := by
  intro p hp
  have h : env1693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1692_1693 : H12AffineEnvironment.transform 4 13 env1692 = env1693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env1692 == env1693) = true)

theorem identity1693 : scanCanonicalize (H12AffineFastState.compose env1693 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound1693 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env1694 : List Nat := [2,4,8,10,13,10,5,4,13,4,12,13,9,12,0,14,13,1,4,0,7,12,11,14,4,10,13,13,12,0,5,0,4,1,12,12]

theorem envBound1694 : H12AffineFastState.Bounded env1694 := by
  intro p hp
  have h : env1694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1693_1694 : H12AffineEnvironment.transform 3 10 env1693 = env1694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env1693 == env1694) = true)

def env1695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16385,151552,2081,16852469,4341977,257,1,34359738368,16925298]

end H12CloudChart0