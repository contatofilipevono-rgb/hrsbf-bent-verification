import H12CloudChart0Data188

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity47863 : scanCanonicalize (H12AffineFastState.compose env47863 (packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound47863 : packedSelected [0,4,7,11,14,15,18,19,22,23,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env47864 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,49304,262144,1024,32769,314421,272512,272561,41351,8328,16,292257,277936,45444,10281,317865,62509,256,21793,46213,273056]

theorem envBound47864 : H12AffineFastState.Bounded env47864 := by
  intro p hp
  have h : env47864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47863_47864 : H12AffineEnvironment.transform 16 49304 env47863 = env47864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env47863 == env47864) = true)

theorem identity47864 : scanCanonicalize (H12AffineFastState.compose env47864 (packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 15777) := by decide +kernel

theorem selectedBound47864 : packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env47865 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,15777,26926,32057,262144,1024,15776,291220,272512,272561,7206,8328,16,292257,277936,3109,10281,287752,18828,256,21793,2340,273056]

theorem envBound47865 : H12AffineFastState.Bounded env47865 := by
  intro p hp
  have h : env47865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47864_47865 : H12AffineEnvironment.transform 14 15777 env47864 = env47865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15777 env47864 == env47865) = true)

theorem identity47865 : scanCanonicalize (H12AffineFastState.compose env47865 (packedSelected [0,1,3,4,5,7,8,9,11,14,17,19,26] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound47865 : packedSelected [0,1,3,4,5,7,8,9,11,14,17,19,26] rootPS < 2^1333 := by decide +kernel

def env47866 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,3384,16384,4249,17430,20481,262144,1024,4248,285868,263608,263561,7206,3504,16,284825,266376,3109,1297,280880,18828,256,21793,2340,264088]

theorem envBound47866 : H12AffineFastState.Bounded env47866 := by
  intro p hp
  have h : env47866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47865_47866 : H12AffineEnvironment.transform 12 3384 env47865 = env47866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env47865 == env47866) = true)

theorem identity47866 : scanCanonicalize (H12AffineFastState.compose env47866 (packedSelected [2,5,6,7,9,16,17,18,19,22,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 4113) := by decide +kernel

theorem selectedBound47866 : packedSelected [2,5,6,7,9,16,17,18,19,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env47867 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,3384,16384,4249,17430,20481,4113,1024,4248,19645,5545,5528,7206,3504,16,18568,153,3109,1297,22817,18828,256,21793,2340,6025]

theorem envBound47867 : H12AffineFastState.Bounded env47867 := by
  intro p hp
  have h : env47867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47866_47867 : H12AffineEnvironment.transform 17 4113 env47866 = env47867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4113 env47866 == env47867) = true)

theorem identity47867 : scanCanonicalize (H12AffineFastState.compose env47867 (packedSelected [1,2,3,4,5,6,8,10,12,14,15,17,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47867 : packedSelected [1,2,3,4,5,6,8,10,12,14,15,17,19,22] rootPS < 2^1333 := by decide +kernel

def env47868 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,2088,16384,4249,16646,20481,4113,272,4248,18861,4281,4232,6454,2208,16,18568,153,2357,1,22817,18828,256,20529,2340,4761]

theorem envBound47868 : H12AffineFastState.Bounded env47868 := by
  intro p hp
  have h : env47868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47867_47868 : H12AffineEnvironment.transform 9 272 env47867 = env47868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47867 == env47868) = true)

theorem identity47868 : scanCanonicalize (H12AffineFastState.compose env47868 (packedSelected [1,2,4,6,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound47868 : packedSelected [1,2,4,6,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env47869 : List Nat := [2,4,8,16,32,17,128,173,512,189,2048,4096,2088,16384,4249,16555,20481,4113,189,4248,18432,4281,4232,6299,2208,16,18568,153,2200,1,22668,18465,173,20529,2185,4761]

theorem envBound47869 : H12AffineFastState.Bounded env47869 := by
  intro p hp
  have h : env47869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47868_47869 : H12AffineEnvironment.transform 7 173 env47868 = env47869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env47868 == env47869) = true)

theorem identity47869 : scanCanonicalize (H12AffineFastState.compose env47869 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound47869 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env47870 : List Nat := [2,4,8,16,32,17,128,173,512,189,0,4096,40,16384,4249,16555,20481,4113,189,4248,16384,4281,4232,4251,160,16,16520,153,152,1,20620,16417,173,20529,137,4761]

theorem envBound47870 : H12AffineFastState.Bounded env47870 := by
  intro p hp
  have h : env47870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47869_47870 : H12AffineEnvironment.transform 10 0 env47869 = env47870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env47869 == env47870) = true)

theorem identity47870 : scanCanonicalize (H12AffineFastState.compose env47870 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound47870 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env47871 : List Nat := [2,4,8,16,32,17,128,173,512,189,0,4096,40,0,4249,171,4097,4113,189,4248,0,4281,4232,4251,160,16,136,153,152,1,4236,33,173,4145,137,4761]

theorem envBound47871 : H12AffineFastState.Bounded env47871 := by
  intro p hp
  have h : env47871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47870_47871 : H12AffineEnvironment.transform 13 0 env47870 = env47871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env47870 == env47871) = true)

theorem identity47871 : scanCanonicalize (H12AffineFastState.compose env47871 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound47871 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env47872 : List Nat := [2,4,8,16,32,17,128,173,512,189,0,1,40,0,152,171,0,16,189,153,0,184,137,154,160,16,136,153,152,1,141,33,173,48,137,664]

theorem envBound47872 : H12AffineFastState.Bounded env47872 := by
  intro p hp
  have h : env47872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47871_47872 : H12AffineEnvironment.transform 11 1 env47871 = env47872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env47871 == env47872) = true)

theorem identity47872 : scanCanonicalize (H12AffineFastState.compose env47872 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47872 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env47873 : List Nat := [2,4,8,0,32,1,128,173,512,173,0,1,40,0,136,171,0,0,173,137,0,168,137,138,160,0,136,137,136,1,141,33,173,32,137,648]

theorem envBound47873 : H12AffineFastState.Bounded env47873 := by
  intro p hp
  have h : env47873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47872_47873 : H12AffineEnvironment.transform 3 0 env47872 = env47873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47872 == env47873) = true)

theorem identity47873 : scanCanonicalize (H12AffineFastState.compose env47873 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47873 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47874 : List Nat := [2,4,8,0,32,1,8,37,512,37,0,1,40,0,0,35,0,0,37,1,0,32,1,2,40,0,0,1,0,1,5,33,37,32,1,512]

theorem envBound47874 : H12AffineFastState.Bounded env47874 := by
  intro p hp
  have h : env47874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47873_47874 : H12AffineEnvironment.transform 6 8 env47873 = env47874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47873 == env47874) = true)

theorem identity47874 : scanCanonicalize (H12AffineFastState.compose env47874 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47874 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47875 : List Nat := [2,4,8,0,1,1,8,4,512,4,0,1,9,0,0,2,0,0,4,1,0,1,1,2,9,0,0,1,0,1,5,0,4,1,1,512]

theorem envBound47875 : H12AffineFastState.Bounded env47875 := by
  intro p hp
  have h : env47875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47874_47875 : H12AffineEnvironment.transform 4 1 env47874 = env47875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47874 == env47875) = true)

theorem identity47875 : scanCanonicalize (H12AffineFastState.compose env47875 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound47875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47876 : List Nat := [2,4,8,0,1,1,8,4,5,4,0,1,9,0,0,2,0,0,4,1,0,1,1,2,9,0,0,1,0,1,5,0,4,1,1,5]

theorem envBound47876 : H12AffineFastState.Bounded env47876 := by
  intro p hp
  have h : env47876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47875_47876 : H12AffineEnvironment.transform 8 5 env47875 = env47876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env47875 == env47876) = true)

theorem identity47876 : scanCanonicalize (H12AffineFastState.compose env47876 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47876 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47877 : List Nat := [2,1,8,0,1,1,8,1,0,1,0,1,9,0,0,2,0,0,1,1,0,1,1,2,9,0,0,1,0,1,0,0,1,1,1,0]

theorem envBound47877 : H12AffineFastState.Bounded env47877 := by
  intro p hp
  have h : env47877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47876_47877 : H12AffineEnvironment.transform 1 1 env47876 = env47877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47876 == env47877) = true)

def env47878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396461,272513,452649,95496,8328,65,292256,458024,45525,10281,399665,144613,256,21793,46213,474854]

theorem envBound47878 : H12AffineFastState.Bounded env47878 := by
  intro p hp
  have h : env47878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47851_47878 : H12AffineEnvironment.transform 21 272513 env47851 = env47878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47851 == env47878) = true)

theorem identity47878 : scanCanonicalize (H12AffineFastState.compose env47878 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212199) := by decide +kernel

theorem selectedBound47878 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212199,1024,32769,77898,201830,120014,95496,8328,65,215367,115151,45525,10281,75222,144613,256,21793,46213,513]

theorem envBound47879 : H12AffineFastState.Bounded env47879 := by
  intro p hp
  have h : env47879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47878_47879 : H12AffineEnvironment.transform 17 212199 env47878 = env47879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212199 env47878 == env47879) = true)

def env47880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,77898,201830,119878,95496,8192,65,215367,115015,45405,10281,75102,144493,256,21793,46093,513]

theorem envBound47880 : H12AffineFastState.Bounded env47880 := by
  intro p hp
  have h : env47880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47879_47880 : H12AffineEnvironment.transform 6 8 env47879 = env47880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47879 == env47880) = true)

theorem identity47880 : scanCanonicalize (H12AffineFastState.compose env47880 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound47880 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env47881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,10280,1024,32769,77898,33,119878,95496,8192,65,23808,115015,45405,10281,75102,73770,256,21793,46093,513]

theorem envBound47881 : H12AffineFastState.Bounded env47881 := by
  intro p hp
  have h : env47881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47880_47881 : H12AffineEnvironment.transform 16 70727 env47880 = env47881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env47880 == env47881) = true)

theorem identity47881 : scanCanonicalize (H12AffineFastState.compose env47881 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound47881 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env47882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,57677,10280,1024,32769,50496,33,8524,32770,8192,65,23808,13389,45405,10281,53332,54560,256,21793,46093,513]

theorem envBound47882 : H12AffineFastState.Bounded env47882 := by
  intro p hp
  have h : env47882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47881_47882 : H12AffineEnvironment.transform 15 62730 env47881 = env47882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env47881 == env47882) = true)

theorem identity47882 : scanCanonicalize (H12AffineFastState.compose env47882 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47882 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env47883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,54279,49216,2341,1024,32769,50496,33,65,32770,269,65,23808,5440,36944,2340,53332,54560,256,21793,38144,513]

theorem envBound47883 : H12AffineFastState.Bounded env47883 := by
  intro p hp
  have h : env47883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47882_47883 : H12AffineEnvironment.transform 12 269 env47882 = env47883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47882 == env47883) = true)

theorem identity47883 : scanCanonicalize (H12AffineFastState.compose env47883 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47883 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env47884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,33031,38208,2341,1024,32769,36928,33,65,32770,269,65,2048,5440,36944,2340,34132,32800,256,33,38144,513]

theorem envBound47884 : H12AffineFastState.Bounded env47884 := by
  intro p hp
  have h : env47884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47883_47884 : H12AffineEnvironment.transform 13 5376 env47883 = env47884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47883 == env47884) = true)

def env47885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77898,201830,119879,95496,8193,65,215367,115014,45404,10281,75103,144492,256,21793,46092,513]

theorem envBound47885 : H12AffineFastState.Bounded env47885 := by
  intro p hp
  have h : env47885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47879_47885 : H12AffineEnvironment.transform 6 9 env47879 = env47885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47879 == env47885) = true)

theorem identity47885 : scanCanonicalize (H12AffineFastState.compose env47885 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound47885 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env47886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,23668,1024,32769,77898,29820,119879,95496,8193,65,10589,115014,45404,10281,75103,87158,256,21793,46092,513]

theorem envBound47886 : H12AffineFastState.Bounded env47886 := by
  intro p hp
  have h : env47886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47885_47886 : H12AffineEnvironment.transform 16 90138 env47885 = env47886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env47885 == env47886) = true)

theorem identity47886 : scanCanonicalize (H12AffineFastState.compose env47886 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound47886 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env47887 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41050,49216,23668,1024,32769,36880,29820,29725,54610,8193,65,10589,24860,45404,10281,34053,62508,256,21793,46092,513]

theorem envBound47887 : H12AffineFastState.Bounded env47887 := by
  intro p hp
  have h : env47887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47886_47887 : H12AffineEnvironment.transform 15 41050 env47886 = env47887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env47886 == env47887) = true)

theorem identity47887 : scanCanonicalize (H12AffineFastState.compose env47887 (packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound47887 : packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env47888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1124,9278,17444,23668,1024,1125,5236,29820,29725,20790,8193,65,10589,24860,13624,10281,353,28744,256,21793,12392,513]

theorem envBound47888 : H12AffineFastState.Bounded env47888 := by
  intro p hp
  have h : env47888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47887_47888 : H12AffineEnvironment.transform 14 1124 env47887 = env47888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env47887 == env47888) = true)

theorem identity47888 : scanCanonicalize (H12AffineFastState.compose env47888 (packedSelected [0,1,3,4,7,8,9,10,12,14,15,24] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound47888 : packedSelected [0,1,3,4,7,8,9,10,12,14,15,24] rootPS < 2^1333 := by decide +kernel

def env47889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12344,1124,9278,13340,11340,1024,1125,5236,1092,1061,8462,8193,65,10589,4388,13624,10281,353,112,256,9497,12392,513]

theorem envBound47889 : H12AffineFastState.Bounded env47889 := by
  intro p hp
  have h : env47889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47888_47889 : H12AffineEnvironment.transform 13 12344 env47888 = env47889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env47888 == env47889) = true)

theorem identity47889 : scanCanonicalize (H12AffineFastState.compose env47889 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound47889 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env47890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1053,5157,1124,35,4097,2129,1024,1125,5236,1092,1061,1299,1052,65,3392,4388,4389,3124,353,112,256,260,5237,513]

theorem envBound47890 : H12AffineFastState.Bounded env47890 := by
  intro p hp
  have h : env47890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47889_47890 : H12AffineEnvironment.transform 12 1053 env47889 = env47890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env47889 == env47890) = true)

theorem identity47890 : scanCanonicalize (H12AffineFastState.compose env47890 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47890 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env47891 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,1053,5157,1124,35,4097,2129,1024,1125,5236,1092,1061,1126,1052,65,3125,4177,4176,3124,20,112,117,113,5237,513]

theorem envBound47891 : H12AffineFastState.Bounded env47891 := by
  intro p hp
  have h : env47891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47890_47891 : H12AffineEnvironment.transform 7 117 env47890 = env47891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47890 == env47891) = true)

theorem identity47891 : scanCanonicalize (H12AffineFastState.compose env47891 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47891 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47892 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,121,4161,0,35,4097,2129,100,1,4112,32,65,2,120,65,2129,4177,4176,2128,20,112,117,113,4113,513]

theorem envBound47892 : H12AffineFastState.Bounded env47892 := by
  intro p hp
  have h : env47892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47891_47892 : H12AffineEnvironment.transform 9 100 env47891 = env47892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47891 == env47892) = true)

theorem identity47892 : scanCanonicalize (H12AffineFastState.compose env47892 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47892 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47893 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,40,4112,0,35,4097,2048,53,1,4112,32,16,2,41,16,2048,4096,4097,2049,20,33,36,32,4113,513]

theorem envBound47893 : H12AffineFastState.Bounded env47893 := by
  intro p hp
  have h : env47893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47892_47893 : H12AffineEnvironment.transform 5 17 env47892 = env47893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47892 == env47893) = true)

theorem identity47893 : scanCanonicalize (H12AffineFastState.compose env47893 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47893 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47894 : List Nat := [2,4,8,16,32,17,9,36,0,53,2048,4096,40,4112,0,35,4097,2048,53,1,4112,32,16,2,41,16,2048,4096,4097,2049,20,33,36,32,4113,1]

theorem envBound47894 : H12AffineFastState.Bounded env47894 := by
  intro p hp
  have h : env47894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47893_47894 : H12AffineEnvironment.transform 8 0 env47893 = env47894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47893 == env47894) = true)

theorem identity47894 : scanCanonicalize (H12AffineFastState.compose env47894 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound47894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47895 : List Nat := [2,4,8,16,32,17,9,36,0,53,2048,2091,40,2107,0,35,2090,2048,53,1,2107,32,16,2,41,16,2048,2091,2090,2049,20,33,36,32,2106,1]

theorem envBound47895 : H12AffineFastState.Bounded env47895 := by
  intro p hp
  have h : env47895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47894_47895 : H12AffineEnvironment.transform 11 2091 env47894 = env47895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env47894 == env47895) = true)

theorem identity47895 : scanCanonicalize (H12AffineFastState.compose env47895 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound47895 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47896 : List Nat := [2,4,8,16,32,17,9,36,0,53,42,1,40,17,0,35,0,42,53,1,17,32,16,2,41,16,42,1,0,43,20,33,36,32,16,1]

theorem envBound47896 : H12AffineFastState.Bounded env47896 := by
  intro p hp
  have h : env47896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47895_47896 : H12AffineEnvironment.transform 10 42 env47895 = env47896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env47895 == env47896) = true)

theorem identity47896 : scanCanonicalize (H12AffineFastState.compose env47896 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47896 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47897 : List Nat := [2,4,8,1,32,0,9,36,0,36,42,1,40,0,0,35,0,42,36,1,0,32,1,2,41,1,42,1,0,43,5,33,36,32,1,1]

theorem envBound47897 : H12AffineFastState.Bounded env47897 := by
  intro p hp
  have h : env47897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47896_47897 : H12AffineEnvironment.transform 3 1 env47896 = env47897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47896 == env47897) = true)

theorem identity47897 : scanCanonicalize (H12AffineFastState.compose env47897 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound47897 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47898 : List Nat := [2,4,8,1,10,0,9,14,0,14,0,1,2,0,0,9,0,0,14,1,0,10,1,2,3,1,0,1,0,1,5,11,14,10,1,1]

theorem envBound47898 : H12AffineFastState.Bounded env47898 := by
  intro p hp
  have h : env47898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47897_47898 : H12AffineEnvironment.transform 4 10 env47897 = env47898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env47897 == env47898) = true)

def env47899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265168,23160257,257,27378860,27337993,25207750]

theorem envBound47899 : H12AffineFastState.Bounded env47899 := by
  intro p hp
  have h : env47899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47672_47899 : H12AffineEnvironment.transform 18 1025 env47672 = env47899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env47672 == env47899) = true)

theorem identity47899 : scanCanonicalize (H12AffineFastState.compose env47899 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10873900) := by decide +kernel

theorem selectedBound47899 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10873900,8328,65,6433837,8677536,10507601,8830977,2385980,12880365,257,272512,313637,2445290]

theorem envBound47900 : H12AffineFastState.Bounded env47900 := by
  intro p hp
  have h : env47900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47899_47900 : H12AffineEnvironment.transform 23 10873900 env47899 = env47900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10873900 env47899 == env47900) = true)

def env47901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,8388608,10588556,8328,65,6433837,8393984,10507601,8568225,2102684,12645453,257,21792,46213,2175562]

theorem envBound47901 : H12AffineFastState.Bounded env47901 := by
  intro p hp
  have h : env47901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47900_47901 : H12AffineEnvironment.transform 17 32160 env47900 = env47901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env47900 == env47901) = true)

def env47902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,2101328,98780,8328,65,6433837,2098512,17665,2272753,2102684,6349853,257,21792,46213,2175562]

theorem envBound47902 : H12AffineFastState.Bounded env47902 := by
  intro p hp
  have h : env47902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47901_47902 : H12AffineEnvironment.transform 22 2101328 env47901 = env47902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env47901 == env47902) = true)

def env47903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,4194304,16,98780,8328,65,4340845,5392,17665,179633,1500,4256861,257,21792,46213,74250]

theorem envBound47903 : H12AffineFastState.Bounded env47903 := by
  intro p hp
  have h : env47903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47902_47903 : H12AffineEnvironment.transform 20 4160 env47902 = env47903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47902 == env47903) = true)

theorem identity47903 : scanCanonicalize (H12AffineFastState.compose env47903 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95530) := by decide +kernel

theorem selectedBound47903 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,95530,16,98780,8328,65,215367,5392,17665,179633,1500,98679,257,21792,46213,74250]

theorem envBound47904 : H12AffineFastState.Bounded env47904 := by
  intro p hp
  have h : env47904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47903_47904 : H12AffineEnvironment.transform 21 95530 env47903 = env47904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95530 env47903 == env47904) = true)

def env47905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,95530,16,98644,8192,65,215367,5392,17665,179513,1364,98679,257,21792,46093,74250]

theorem envBound47905 : H12AffineFastState.Bounded env47905 := by
  intro p hp
  have h : env47905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47904_47905 : H12AffineEnvironment.transform 6 8 env47904 = env47905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47904 == env47905) = true)

theorem identity47905 : scanCanonicalize (H12AffineFastState.compose env47905 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound47905 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,4160,95530,16,95497,8192,65,215367,5392,17665,149860,1364,95530,257,21792,16464,74250]

theorem envBound47906 : H12AffineFastState.Bounded env47906 := by
  intro p hp
  have h : env47906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47905_47906 : H12AffineEnvironment.transform 14 29789 env47905 = env47906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env47905 == env47906) = true)

theorem identity47906 : scanCanonicalize (H12AffineFastState.compose env47906 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47906 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env47907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,21793,16,21762,8192,65,158028,5392,17665,149860,1364,21793,257,21792,16464,513]

theorem envBound47907 : H12AffineFastState.Bounded env47907 := by
  intro p hp
  have h : env47907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47906_47907 : H12AffineEnvironment.transform 15 8203 env47906 = env47907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47906 == env47907) = true)

theorem identity47907 : scanCanonicalize (H12AffineFastState.compose env47907 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 12557) := by decide +kernel

theorem selectedBound47907 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,12557,32040,1025,29788,4160,21793,16,21762,8192,65,22593,5392,17665,30825,1364,21793,257,21792,16464,513]

theorem envBound47908 : H12AffineFastState.Bounded env47908 := by
  intro p hp
  have h : env47908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47907_47908 : H12AffineEnvironment.transform 16 12557 env47907 = env47908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12557 env47907 == env47908) = true)

theorem identity47908 : scanCanonicalize (H12AffineFastState.compose env47908 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound47908 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env47909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,1345,8203,12557,3124,1025,1344,4160,9277,16,9246,8192,65,10589,5392,13341,2421,1364,9277,257,9276,12620,513]

theorem envBound47909 : H12AffineFastState.Bounded env47909 := by
  intro p hp
  have h : env47909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47908_47909 : H12AffineEnvironment.transform 13 12572 env47908 = env47909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env47908 == env47909) = true)

theorem identity47909 : scanCanonicalize (H12AffineFastState.compose env47909 (packedSelected [0,2,4,5,7,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound47909 : packedSelected [0,2,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env47910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,4096,8192,12572,1345,8203,12557,1344,1025,1344,4160,9277,16,9246,8192,65,8233,5392,13341,1,1364,9277,257,9276,12620,513]

theorem envBound47910 : H12AffineFastState.Bounded env47910 := by
  intro p hp
  have h : env47910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47909_47910 : H12AffineEnvironment.transform 10 372 env47909 = env47910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env47909 == env47910) = true)

theorem identity47910 : scanCanonicalize (H12AffineFastState.compose env47910 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 4429) := by decide +kernel

theorem selectedBound47910 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env47911 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,4096,4429,81,1345,4422,64,1344,1025,1344,4160,5488,16,5459,4429,65,4452,5392,1360,1,1364,5488,257,5489,1,513]

theorem envBound47911 : H12AffineFastState.Bounded env47911 := by
  intro p hp
  have h : env47911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47910_47911 : H12AffineEnvironment.transform 12 4429 env47910 = env47911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4429 env47910 == env47911) = true)

theorem identity47911 : scanCanonicalize (H12AffineFastState.compose env47911 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound47911 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env47912 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,64,269,81,1345,262,64,1344,1025,1344,0,1328,16,1299,269,65,292,1360,1360,1,1364,1328,257,1329,1,513]

theorem envBound47912 : H12AffineFastState.Bounded env47912 := by
  intro p hp
  have h : env47912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47911_47912 : H12AffineEnvironment.transform 11 64 env47911 = env47912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env47911 == env47912) = true)

theorem identity47912 : scanCanonicalize (H12AffineFastState.compose env47912 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47912 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47913 : List Nat := [2,4,8,16,32,64,8,256,512,100,372,64,269,81,293,262,64,292,101,292,0,340,16,375,269,65,292,308,308,1,304,340,257,341,1,513]

theorem envBound47913 : H12AffineFastState.Bounded env47913 := by
  intro p hp
  have h : env47913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47912_47913 : H12AffineEnvironment.transform 9 100 env47912 = env47913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47912 == env47913) = true)

def env47914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,95530,16,98645,8193,65,215367,5392,17665,179512,1365,98679,257,21792,46092,74250]

theorem envBound47914 : H12AffineFastState.Bounded env47914 := by
  intro p hp
  have h : env47914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47904_47914 : H12AffineEnvironment.transform 6 9 env47904 = env47914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47904 == env47914) = true)

theorem identity47914 : scanCanonicalize (H12AffineFastState.compose env47914 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47914 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47915 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,4160,73771,16,98645,8193,65,203846,5392,4096,179512,1365,98679,257,33,46092,74250]

theorem envBound47915 : H12AffineFastState.Bounded env47915 := by
  intro p hp
  have h : env47915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47914_47915 : H12AffineEnvironment.transform 13 5377 env47914 = env47915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47914 == env47915) = true)

theorem identity47915 : scanCanonicalize (H12AffineFastState.compose env47915 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47915 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env47916 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,10280,1025,32769,4160,33,16,41311,8193,65,146508,5392,4096,179512,1365,41341,257,33,46092,512]

theorem envBound47916 : H12AffineFastState.Bounded env47916 := by
  intro p hp
  have h : env47916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47915_47916 : H12AffineEnvironment.transform 15 8202 env47915 = env47916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47915 == env47916) = true)

theorem identity47916 : scanCanonicalize (H12AffineFastState.compose env47916 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound47916 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1125,8202,131072,10280,1025,1124,4160,33,16,9530,8193,65,146508,5392,4096,145757,1365,9496,257,33,12393,512]

theorem envBound47917 : H12AffineFastState.Bounded env47917 := by
  intro p hp
  have h : env47917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47916_47917 : H12AffineEnvironment.transform 14 1125 env47916 = env47917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env47916 == env47917) = true)

theorem identity47917 : scanCanonicalize (H12AffineFastState.compose env47917 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound47917 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env47918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,8192,373,1125,8202,131072,10280,1025,1124,1076,33,16,9530,8193,65,141368,356,1140,142633,1365,9496,257,33,9245,512]

theorem envBound47918 : H12AffineFastState.Bounded env47918 := by
  intro p hp
  have h : env47918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47917_47918 : H12AffineEnvironment.transform 11 1140 env47917 = env47918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env47917 == env47918) = true)

theorem identity47918 : scanCanonicalize (H12AffineFastState.compose env47918 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound47918 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env47919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,1100,373,1125,1094,131072,3172,1025,1124,1076,33,16,374,1101,65,134260,356,1140,133477,1365,340,257,33,81,512]

theorem envBound47919 : H12AffineFastState.Bounded env47919 := by
  intro p hp
  have h : env47919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47918_47919 : H12AffineEnvironment.transform 12 1100 env47918 = env47919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env47918 == env47919) = true)

theorem identity47919 : scanCanonicalize (H12AffineFastState.compose env47919 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 2356) := by decide +kernel

theorem selectedBound47919 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,1100,373,1125,1094,2356,3172,1025,1124,1076,33,16,374,1101,65,1344,356,1140,81,1365,340,257,33,81,512]

theorem envBound47920 : H12AffineFastState.Bounded env47920 := by
  intro p hp
  have h : env47920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47919_47920 : H12AffineEnvironment.transform 16 2356 env47919 = env47920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2356 env47919 == env47920) = true)

theorem identity47920 : scanCanonicalize (H12AffineFastState.compose env47920 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47920 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47921 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,1052,293,1077,1046,2356,3124,1025,1076,1076,33,16,294,1053,17,1296,308,1060,1,1285,260,257,33,1,512]

theorem envBound47921 : H12AffineFastState.Bounded env47921 := by
  intro p hp
  have h : env47921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47920_47921 : H12AffineEnvironment.transform 5 16 env47920 = env47921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47920 == env47921) = true)

theorem identity47921 : scanCanonicalize (H12AffineFastState.compose env47921 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound47921 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47922 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,1060,1052,293,1077,1046,1281,1,1025,1076,1076,33,16,294,1053,17,1296,308,1060,1,1285,260,257,33,1,512]

theorem envBound47922 : H12AffineFastState.Bounded env47922 := by
  intro p hp
  have h : env47922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47921_47922 : H12AffineEnvironment.transform 10 1077 env47921 = env47922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env47921 == env47922) = true)

theorem identity47922 : scanCanonicalize (H12AffineFastState.compose env47922 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound47922 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47923 : List Nat := [2,4,8,16,32,16,9,256,512,304,261,276,300,293,261,294,49,1,305,260,260,33,16,294,301,17,32,308,276,1,53,260,257,33,1,512]

theorem envBound47923 : H12AffineFastState.Bounded env47923 := by
  intro p hp
  have h : env47923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47922_47923 : H12AffineEnvironment.transform 9 304 env47922 = env47923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env47922 == env47923) = true)

theorem identity47923 : scanCanonicalize (H12AffineFastState.compose env47923 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47923 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47924 : List Nat := [2,4,8,16,32,16,9,4,512,52,1,16,40,33,1,34,49,1,53,0,0,33,16,34,41,17,32,48,16,1,53,0,5,33,1,512]

theorem envBound47924 : H12AffineFastState.Bounded env47924 := by
  intro p hp
  have h : env47924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47923_47924 : H12AffineEnvironment.transform 7 4 env47923 = env47924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47923 == env47924) = true)

theorem identity47924 : scanCanonicalize (H12AffineFastState.compose env47924 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47924 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47925 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,8,1,1,2,17,1,21,0,0,1,16,2,9,17,0,16,16,1,21,0,5,1,1,512]

theorem envBound47925 : H12AffineFastState.Bounded env47925 := by
  intro p hp
  have h : env47925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47924_47925 : H12AffineEnvironment.transform 4 0 env47924 = env47925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47924 == env47925) = true)

theorem identity47925 : scanCanonicalize (H12AffineFastState.compose env47925 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound47925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47926 : List Nat := [2,4,8,5,0,5,9,4,512,1,1,5,8,1,1,2,4,1,0,0,0,1,5,2,9,4,0,5,5,1,0,0,5,1,1,512]

theorem envBound47926 : H12AffineFastState.Bounded env47926 := by
  intro p hp
  have h : env47926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47925_47926 : H12AffineEnvironment.transform 3 5 env47925 = env47926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env47925 == env47926) = true)

theorem identity47926 : scanCanonicalize (H12AffineFastState.compose env47926 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound47926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47927 : List Nat := [2,4,1,5,0,5,0,4,512,1,1,5,1,1,1,2,4,1,0,0,0,1,5,2,0,4,0,5,5,1,0,0,5,1,1,512]

theorem envBound47927 : H12AffineFastState.Bounded env47927 := by
  intro p hp
  have h : env47927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47926_47927 : H12AffineEnvironment.transform 2 1 env47926 = env47927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env47926 == env47927) = true)

theorem identity47927 : scanCanonicalize (H12AffineFastState.compose env47927 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound47927 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47928 : List Nat := [2,4,1,5,0,5,0,4,3,1,1,5,1,1,1,2,4,1,0,0,0,1,5,2,0,4,0,5,5,1,0,0,5,1,1,3]

theorem envBound47928 : H12AffineFastState.Bounded env47928 := by
  intro p hp
  have h : env47928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47927_47928 : H12AffineEnvironment.transform 8 3 env47927 = env47928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env47927 == env47928) = true)

def env47929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,4194304,17,98780,8328,65,4340844,5393,17665,179632,1501,4256860,257,21792,46213,74251]

theorem envBound47929 : H12AffineFastState.Bounded env47929 := by
  intro p hp
  have h : env47929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47902_47929 : H12AffineEnvironment.transform 20 4161 env47902 = env47929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47902 == env47929) = true)

theorem identity47929 : scanCanonicalize (H12AffineFastState.compose env47929 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47929 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,4194304,17,41430,8328,65,4340844,5393,17665,179632,1501,4256860,257,21792,46213,513]

theorem envBound47930 : H12AffineFastState.Bounded env47930 := by
  intro p hp
  have h : env47930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47929_47930 : H12AffineEnvironment.transform 15 8202 env47929 = env47930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47929 == env47930) = true)

theorem identity47930 : scanCanonicalize (H12AffineFastState.compose env47930 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound47930 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env47931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,41260,17,41430,8328,65,171328,5393,17665,179632,1501,21872,257,21792,46213,513]

theorem envBound47931 : H12AffineFastState.Bounded env47931 := by
  intro p hp
  have h : env47931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47930_47931 : H12AffineEnvironment.transform 21 41260 env47930 = env47931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env47930 == env47931) = true)

def env47932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4161,41260,17,41310,8192,65,171328,5393,17665,179512,1365,21872,257,21792,46093,513]

theorem envBound47932 : H12AffineFastState.Bounded env47932 := by
  intro p hp
  have h : env47932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47931_47932 : H12AffineEnvironment.transform 6 8 env47931 = env47932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47931 == env47932) = true)

theorem identity47932 : scanCanonicalize (H12AffineFastState.compose env47932 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47932 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,32040,1025,8541,4161,112,17,2,8192,65,146460,5393,17665,138340,1365,21872,257,21792,5457,513]

theorem envBound47933 : H12AffineFastState.Bounded env47933 := by
  intro p hp
  have h : env47933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47932_47933 : H12AffineEnvironment.transform 14 8540 env47932 = env47933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47932 == env47933) = true)

theorem identity47933 : scanCanonicalize (H12AffineFastState.compose env47933 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 17664) := by decide +kernel

theorem selectedBound47933 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env47934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,17664,32040,1025,8541,4161,112,17,2,8192,65,31004,5393,17665,22884,1365,21872,257,21792,5457,513]

theorem envBound47934 : H12AffineFastState.Bounded env47934 := by
  intro p hp
  have h : env47934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47933_47934 : H12AffineEnvironment.transform 16 17664 env47933 = env47934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17664 env47933 == env47934) = true)

theorem identity47934 : scanCanonicalize (H12AffineFastState.compose env47934 (packedSelected [9,14,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47934 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env47935 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8540,8202,16400,30776,273,8541,4161,112,17,2,8192,65,31004,4097,16401,22884,69,20576,257,20528,4161,513]

theorem envBound47935 : H12AffineFastState.Bounded env47935 := by
  intro p hp
  have h : env47935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47934_47935 : H12AffineEnvironment.transform 9 272 env47934 = env47935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47934 == env47935) = true)

theorem identity47935 : scanCanonicalize (H12AffineFastState.compose env47935 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound47935 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env47936 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4404,8540,8202,4388,10508,273,8541,4161,112,17,2,8192,65,10280,4097,4389,2128,69,340,257,260,4161,513]

theorem envBound47936 : H12AffineFastState.Bounded env47936 := by
  intro p hp
  have h : env47936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47935_47936 : H12AffineEnvironment.transform 13 4404 env47935 = env47936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env47935 == env47936) = true)

theorem identity47936 : scanCanonicalize (H12AffineFastState.compose env47936 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound47936 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env47937 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4404,372,34,4388,2340,273,373,4161,112,17,2,40,65,2048,4097,4389,2128,69,340,257,260,4161,513]

theorem envBound47937 : H12AffineFastState.Bounded env47937 := by
  intro p hp
  have h : env47937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47936_47937 : H12AffineEnvironment.transform 12 40 env47936 = env47937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env47936 == env47937) = true)

theorem identity47937 : scanCanonicalize (H12AffineFastState.compose env47937 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47937 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47938 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,40,4112,80,34,4096,2048,53,81,4161,112,17,2,40,65,2048,4097,4097,2128,69,112,37,32,4161,513]

theorem envBound47938 : H12AffineFastState.Bounded env47938 := by
  intro p hp
  have h : env47938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47937_47938 : H12AffineEnvironment.transform 7 36 env47937 = env47938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47937 == env47938) = true)

theorem identity47938 : scanCanonicalize (H12AffineFastState.compose env47938 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound47938 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env47939 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,513,40,529,80,34,513,2048,53,81,576,112,17,2,40,65,2048,512,512,2128,69,112,37,32,576,513]

theorem envBound47939 : H12AffineFastState.Bounded env47939 := by
  intro p hp
  have h : env47939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47938_47939 : H12AffineEnvironment.transform 11 513 env47938 = env47939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env47938 == env47939) = true)

theorem identity47939 : scanCanonicalize (H12AffineFastState.compose env47939 (packedSelected [0,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound47939 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env47940 : List Nat := [2,4,8,16,32,64,8,36,512,52,577,513,40,529,80,34,513,577,53,81,576,112,17,2,40,65,577,512,512,529,69,112,37,32,576,513]

theorem envBound47940 : H12AffineFastState.Bounded env47940 := by
  intro p hp
  have h : env47940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47939_47940 : H12AffineEnvironment.transform 10 577 env47939 = env47940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env47939 == env47940) = true)

theorem identity47940 : scanCanonicalize (H12AffineFastState.compose env47940 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound47940 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47941 : List Nat := [2,4,8,16,32,49,8,36,512,52,560,513,40,529,33,34,513,560,53,32,561,1,17,2,40,48,560,512,512,529,52,1,37,32,561,513]

theorem envBound47941 : H12AffineFastState.Bounded env47941 := by
  intro p hp
  have h : env47941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47940_47941 : H12AffineEnvironment.transform 5 49 env47940 = env47941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env47940 == env47941) = true)

theorem identity47941 : scanCanonicalize (H12AffineFastState.compose env47941 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47941 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47942 : List Nat := [2,4,8,16,0,17,8,4,512,20,528,513,8,529,1,2,513,528,21,0,529,1,17,2,8,16,528,512,512,529,20,1,5,0,529,513]

theorem envBound47942 : H12AffineFastState.Bounded env47942 := by
  intro p hp
  have h : env47942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47941_47942 : H12AffineEnvironment.transform 4 0 env47941 = env47942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47941 == env47942) = true)

theorem identity47942 : scanCanonicalize (H12AffineFastState.compose env47942 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47943 : List Nat := [2,4,8,16,0,17,8,4,0,20,16,1,8,17,1,2,1,16,21,0,17,1,17,2,8,16,16,0,0,17,20,1,5,0,17,1]

theorem envBound47943 : H12AffineFastState.Bounded env47943 := by
  intro p hp
  have h : env47943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47942_47943 : H12AffineEnvironment.transform 8 0 env47942 = env47943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47942 == env47943) = true)

theorem identity47943 : scanCanonicalize (H12AffineFastState.compose env47943 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47943 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47944 : List Nat := [2,4,8,1,0,0,8,4,0,5,1,1,8,0,1,2,1,1,4,0,0,1,0,2,8,1,1,0,0,0,5,1,5,0,0,1]

theorem envBound47944 : H12AffineFastState.Bounded env47944 := by
  intro p hp
  have h : env47944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47943_47944 : H12AffineEnvironment.transform 3 1 env47943 = env47944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47943 == env47944) = true)

def env47945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4161,41260,17,41311,8193,65,171328,5393,17665,179513,1364,21872,257,21792,46092,513]

theorem envBound47945 : H12AffineFastState.Bounded env47945 := by
  intro p hp
  have h : env47945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47931_47945 : H12AffineEnvironment.transform 6 9 env47931 = env47945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47931 == env47945) = true)

theorem identity47945 : scanCanonicalize (H12AffineFastState.compose env47945 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound47945 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env47946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32041,1025,29788,4161,21873,17,21762,8193,65,157981,5393,17665,149860,1364,21872,257,21792,16465,513]

theorem envBound47946 : H12AffineFastState.Bounded env47946 := by
  intro p hp
  have h : env47946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47945_47946 : H12AffineEnvironment.transform 14 29789 env47945 = env47946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env47945 == env47946) = true)

theorem identity47946 : scanCanonicalize (H12AffineFastState.compose env47946 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47946 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env47947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,10280,1025,8541,4161,112,17,3,8193,65,146460,5393,4096,138341,1364,113,257,33,5456,513]

theorem envBound47947 : H12AffineFastState.Bounded env47947 := by
  intro p hp
  have h : env47947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47946_47947 : H12AffineEnvironment.transform 13 5377 env47946 = env47947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47946 == env47947) = true)

theorem identity47947 : scanCanonicalize (H12AffineFastState.compose env47947 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47947 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47948 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10280,1025,8460,4112,33,17,3,8193,16,146460,5393,4096,138292,1285,32,257,33,5377,513]

theorem envBound47948 : H12AffineFastState.Bounded env47948 := by
  intro p hp
  have h : env47948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47947_47948 : H12AffineEnvironment.transform 5 17 env47947 = env47948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47947 == env47948) = true)

theorem identity47948 : scanCanonicalize (H12AffineFastState.compose env47948 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound47948 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47949 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8202,13340,10280,1025,8460,4112,33,17,3,8193,16,2048,5393,4096,10280,1285,32,257,33,5377,513]

theorem envBound47949 : H12AffineFastState.Bounded env47949 := by
  intro p hp
  have h : env47949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47948_47949 : H12AffineEnvironment.transform 16 13340 env47948 = env47949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env47948 == env47949) = true)

theorem identity47949 : scanCanonicalize (H12AffineFastState.compose env47949 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47949 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env47950 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5393,2341,1025,1,4112,33,17,3,268,16,2048,5393,4096,2341,1285,32,257,33,5377,513]

theorem envBound47950 : H12AffineFastState.Bounded env47950 := by
  intro p hp
  have h : env47950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47949_47950 : H12AffineEnvironment.transform 12 269 env47949 = env47950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47949 == env47950) = true)

theorem identity47950 : scanCanonicalize (H12AffineFastState.compose env47950 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47951 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,35,5173,2049,1025,1,4112,33,17,3,40,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound47951 : H12AffineFastState.Bounded env47951 := by
  intro p hp
  have h : env47951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47950_47951 : H12AffineEnvironment.transform 7 36 env47950 = env47951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47950 == env47951) = true)

def env47952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,2101329,98781,8328,65,6433837,2098513,17664,2272752,2102684,6349852,257,21792,46213,2175562]

theorem envBound47952 : H12AffineFastState.Bounded env47952 := by
  intro p hp
  have h : env47952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47901_47952 : H12AffineEnvironment.transform 22 2101329 env47901 = env47952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env47901 == env47952) = true)

def env47953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,4194304,17,98781,8328,65,4340845,5393,17664,179632,1500,4256860,257,21792,46213,74250]

theorem envBound47953 : H12AffineFastState.Bounded env47953 := by
  intro p hp
  have h : env47953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47952_47953 : H12AffineEnvironment.transform 20 4160 env47952 = env47953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47952 == env47953) = true)

theorem identity47953 : scanCanonicalize (H12AffineFastState.compose env47953 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound47953 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,32160,1025,32769,4160,4194304,17,21762,8328,65,4340845,5393,17664,179632,1500,4256860,257,21792,46213,63189]

theorem envBound47954 : H12AffineFastState.Bounded env47954 := by
  intro p hp
  have h : env47954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47953_47954 : H12AffineEnvironment.transform 15 54495 env47953 = env47954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env47953 == env47954) = true)

def env47955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,4160,4194304,17,21762,8192,65,4340845,5393,17664,179512,1364,4256860,257,21792,46093,63069]

theorem envBound47955 : H12AffineFastState.Bounded env47955 := by
  intro p hp
  have h : env47955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47954_47955 : H12AffineEnvironment.transform 6 8 env47954 = env47955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47954 == env47955) = true)

theorem identity47955 : scanCanonicalize (H12AffineFastState.compose env47955 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47955 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,131072,32040,1025,8541,4160,4194304,17,21762,8192,65,4340845,5393,17664,138340,1364,4216064,257,21792,5457,22273]

theorem envBound47956 : H12AffineFastState.Bounded env47956 := by
  intro p hp
  have h : env47956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47955_47956 : H12AffineEnvironment.transform 14 8540 env47955 = env47956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47955 == env47956) = true)

theorem identity47956 : scanCanonicalize (H12AffineFastState.compose env47956 (packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,19,20,22,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 29740) := by decide +kernel

theorem selectedBound47956 : packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,19,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env47957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,131072,32040,1025,8541,4160,29740,17,21762,8192,65,149569,5393,17664,138340,1364,8492,257,21792,5457,22273]

theorem envBound47957 : H12AffineFastState.Bounded env47957 := by
  intro p hp
  have h : env47957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47956_47957 : H12AffineEnvironment.transform 21 29740 env47956 = env47957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29740 env47956 == env47957) = true)

theorem identity47957 : scanCanonicalize (H12AffineFastState.compose env47957 (packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound47957 : packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env47958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,8192,16384,8540,27007,131072,24924,1025,8541,3124,26712,17,18806,8192,65,149569,2405,17664,131088,1364,8492,257,18772,2341,19317]

theorem envBound47958 : H12AffineFastState.Bounded env47958 := by
  intro p hp
  have h : env47958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47957_47958 : H12AffineEnvironment.transform 11 3188 env47957 = env47958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env47957 == env47958) = true)

theorem identity47958 : scanCanonicalize (H12AffineFastState.compose env47958 (packedSelected [0,2,3,4,5,6,7,11,12,14,16,19,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47958 : packedSelected [0,2,3,4,5,6,7,11,12,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env47959 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,8192,16384,8461,26926,131072,24845,1025,8460,3124,26633,17,18727,8192,16,149520,2356,17664,131088,1285,8492,257,18693,2341,19236]

theorem envBound47959 : H12AffineFastState.Bounded env47959 := by
  intro p hp
  have h : env47959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47958_47959 : H12AffineEnvironment.transform 5 17 env47958 = env47959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47958 == env47959) = true)

theorem identity47959 : scanCanonicalize (H12AffineFastState.compose env47959 (packedSelected [0,1,2,4,6,7,8,9,10,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 27661) := by decide +kernel

theorem selectedBound47959 : packedSelected [0,1,2,4,6,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env47960 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,8192,16384,8461,26926,27661,24845,1025,8460,3124,26633,17,18727,8192,16,9245,2356,17664,27677,1285,8492,257,18693,2341,19236]

theorem envBound47960 : H12AffineFastState.Bounded env47960 := by
  intro p hp
  have h : env47960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47959_47960 : H12AffineEnvironment.transform 16 27661 env47959 = env47960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 27661 env47959 == env47960) = true)

theorem identity47960 : scanCanonicalize (H12AffineFastState.compose env47960 (packedSelected [2,6,11,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 3345) := by decide +kernel

theorem selectedBound47960 : packedSelected [2,6,11,14,16] rootPS < 2^1333 := by decide +kernel

def env47961 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,8192,3345,8461,9279,8476,11292,1025,8460,3124,9496,17,1078,8192,16,9245,2356,2065,8460,1285,8492,257,1044,2341,1589]

theorem envBound47961 : H12AffineFastState.Bounded env47961 := by
  intro p hp
  have h : env47961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47960_47961 : H12AffineEnvironment.transform 13 3345 env47960 = env47961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3345 env47960 == env47961) = true)

theorem identity47961 : scanCanonicalize (H12AffineFastState.compose env47961 (packedSelected [2,3,4,5,6,9,10,18] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound47961 : packedSelected [2,3,4,5,6,9,10,18] rootPS < 2^1333 := by decide +kernel

def env47962 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,17,8192,293,8461,9279,8476,8232,1025,8460,0,9496,17,1078,8192,16,9245,1280,1061,8460,1285,8492,257,1044,1297,1589]

theorem envBound47962 : H12AffineFastState.Bounded env47962 := by
  intro p hp
  have h : env47962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47961_47962 : H12AffineEnvironment.transform 10 1076 env47961 = env47962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env47961 == env47962) = true)

theorem identity47962 : scanCanonicalize (H12AffineFastState.compose env47962 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound47962 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env47963 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,17,1336,293,1077,263,1060,1296,1025,1076,0,32,17,1078,1336,16,293,1280,1061,1076,1285,1044,257,1044,1297,1589]

theorem envBound47963 : H12AffineFastState.Bounded env47963 := by
  intro p hp
  have h : env47963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47962_47963 : H12AffineEnvironment.transform 12 1336 env47962 = env47963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env47962 == env47963) = true)

theorem identity47963 : scanCanonicalize (H12AffineFastState.compose env47963 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound47963 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env47964 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1076,17,1336,293,1077,263,1060,1296,1025,1076,0,32,17,1078,1336,16,293,1280,1061,1076,1285,1044,257,1044,1297,1060]

theorem envBound47964 : H12AffineFastState.Bounded env47964 := by
  intro p hp
  have h : env47964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47963_47964 : H12AffineEnvironment.transform 8 17 env47963 = env47964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env47963 == env47964) = true)

theorem identity47964 : scanCanonicalize (H12AffineFastState.compose env47964 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47964 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env47965 : List Nat := [2,4,8,16,32,17,8,4,17,1024,1076,17,1084,33,1077,3,1060,1044,1025,1076,0,32,17,1078,1084,16,33,1028,1061,1076,1025,1044,5,1044,1045,1060]

theorem envBound47965 : H12AffineFastState.Bounded env47965 := by
  intro p hp
  have h : env47965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47964_47965 : H12AffineEnvironment.transform 7 4 env47964 = env47965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47964 == env47965) = true)

theorem identity47965 : scanCanonicalize (H12AffineFastState.compose env47965 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47965 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47966 : List Nat := [2,4,8,0,32,1,8,4,1,1024,1060,1,1068,33,1061,3,1060,1028,1025,1060,0,32,1,1062,1068,0,33,1028,1061,1060,1025,1028,5,1028,1029,1060]

theorem envBound47966 : H12AffineFastState.Bounded env47966 := by
  intro p hp
  have h : env47966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47965_47966 : H12AffineEnvironment.transform 3 0 env47965 = env47966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47965 == env47966) = true)

def env47967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,4160,4194304,17,21762,8193,65,4340845,5393,17664,179513,1365,4256860,257,21792,46092,63068]

theorem envBound47967 : H12AffineFastState.Bounded env47967 := by
  intro p hp
  have h : env47967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47954_47967 : H12AffineEnvironment.transform 6 9 env47954 = env47967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47954 == env47967) = true)

theorem identity47967 : scanCanonicalize (H12AffineFastState.compose env47967 (packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound47967 : packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env47968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4160,4194304,17,21762,8193,65,4340845,5393,17664,149860,1365,4194305,257,21792,16465,513]

theorem envBound47968 : H12AffineFastState.Bounded env47968 := by
  intro p hp
  have h : env47968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47967_47968 : H12AffineEnvironment.transform 14 29789 env47967 = env47968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env47967 == env47968) = true)

theorem identity47968 : scanCanonicalize (H12AffineFastState.compose env47968 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound47968 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env47969 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4160,147505,17,21762,8193,65,31836,5393,17664,149860,1365,147504,257,21792,16465,513]

theorem envBound47969 : H12AffineFastState.Bounded env47969 := by
  intro p hp
  have h : env47969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47968_47969 : H12AffineEnvironment.transform 21 147505 env47968 = env47969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env47968 == env47969) = true)

def env47970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,4194304,16,98781,8328,65,4340844,5392,17664,179633,1501,4256861,257,21792,46213,74251]

theorem envBound47970 : H12AffineFastState.Bounded env47970 := by
  intro p hp
  have h : env47970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47952_47970 : H12AffineEnvironment.transform 20 4161 env47952 = env47970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47952 == env47970) = true)

theorem identity47970 : scanCanonicalize (H12AffineFastState.compose env47970 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98815) := by decide +kernel

theorem selectedBound47970 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,98815,16,98781,8328,65,245139,5392,17664,179633,1501,95650,257,21792,46213,74251]

theorem envBound47971 : H12AffineFastState.Bounded env47971 := by
  intro p hp
  have h : env47971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47970_47971 : H12AffineEnvironment.transform 21 98815 env47970 = env47971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98815 env47970 == env47971) = true)

def env47972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,98679,16,98645,8192,65,245019,5392,17664,179513,1365,95530,257,21792,46093,74251]

theorem envBound47972 : H12AffineFastState.Bounded env47972 := by
  intro p hp
  have h : env47972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47971_47972 : H12AffineEnvironment.transform 6 8 env47971 = env47972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47971 == env47972) = true)

theorem identity47972 : scanCanonicalize (H12AffineFastState.compose env47972 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound47972 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32040,1025,29788,4161,95530,16,95496,8192,65,215366,5392,17664,149860,1365,95530,257,21792,16464,74251]

theorem envBound47973 : H12AffineFastState.Bounded env47973 := by
  intro p hp
  have h : env47973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47972_47973 : H12AffineEnvironment.transform 14 29789 env47972 = env47973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env47972 == env47973) = true)

theorem identity47973 : scanCanonicalize (H12AffineFastState.compose env47973 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47973 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env47974 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29789,65536,131072,31836,1025,29788,4161,95326,16,95356,8192,65,215090,5220,17524,149520,1057,95326,117,21588,16464,74251]

theorem envBound47974 : H12AffineFastState.Bounded env47974 := by
  intro p hp
  have h : env47974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47973_47974 : H12AffineEnvironment.transform 7 116 env47973 = env47974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47973 == env47974) = true)

theorem identity47974 : scanCanonicalize (H12AffineFastState.compose env47974 (packedSelected [0,1,3,5,6,8,10,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47974 : packedSelected [0,1,3,5,6,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env47975 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29789,8203,131072,31836,1025,29788,4161,21589,16,21623,8192,65,157753,5220,17524,149520,1057,21589,117,21588,16464,512]

theorem envBound47975 : H12AffineFastState.Bounded env47975 := by
  intro p hp
  have h : env47975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47974_47975 : H12AffineEnvironment.transform 15 8203 env47974 = env47975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47974 == env47975) = true)

theorem identity47975 : scanCanonicalize (H12AffineFastState.compose env47975 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 24648) := by decide +kernel

theorem selectedBound47975 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47976 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29789,8203,24648,31836,1025,29788,4161,21589,16,21623,8192,65,2161,5220,17524,10328,1057,21589,117,21588,16464,512]

theorem envBound47976 : H12AffineFastState.Bounded env47976 := by
  intro p hp
  have h : env47976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47975_47976 : H12AffineEnvironment.transform 16 24648 env47975 = env47976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24648 env47975 == env47976) = true)

theorem identity47976 : scanCanonicalize (H12AffineFastState.compose env47976 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound47976 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env47977 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,16384,21541,115,16432,23588,1025,21540,4161,21589,16,21623,120,65,2161,5220,17524,2080,1057,21589,117,21588,16464,512]

theorem envBound47977 : H12AffineFastState.Bounded env47977 := by
  intro p hp
  have h : env47977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47976_47977 : H12AffineEnvironment.transform 12 120 env47976 = env47977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env47976 == env47977) = true)

theorem identity47977 : scanCanonicalize (H12AffineFastState.compose env47977 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound47977 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env47978 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5236,81,115,5188,2128,1025,80,4161,33,16,3,120,65,2161,5220,4096,2080,1057,33,117,32,5156,512]

theorem envBound47978 : H12AffineFastState.Bounded env47978 := by
  intro p hp
  have h : env47978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47977_47978 : H12AffineEnvironment.transform 13 5236 env47977 = env47978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env47977 == env47978) = true)

theorem identity47978 : scanCanonicalize (H12AffineFastState.compose env47978 (packedSelected [0,1,3,4,5,8,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47978 : packedSelected [0,1,3,4,5,8,19] rootPS < 2^1333 := by decide +kernel

def env47979 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,88,5204,81,83,5188,2128,1025,80,4161,1,16,3,88,65,2129,5188,4096,2048,1025,1,85,0,5124,512]

theorem envBound47979 : H12AffineFastState.Bounded env47979 := by
  intro p hp
  have h : env47979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47978_47979 : H12AffineEnvironment.transform 4 0 env47978 = env47979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47978 == env47979) = true)

theorem identity47979 : scanCanonicalize (H12AffineFastState.compose env47979 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound47979 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47980 : List Nat := [2,4,8,16,0,64,8,84,512,1024,80,4096,88,5204,81,83,5188,0,1025,80,4161,1,16,3,88,65,1,5188,4096,80,1025,1,85,0,5124,512]

theorem envBound47980 : H12AffineFastState.Bounded env47980 := by
  intro p hp
  have h : env47980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47979_47980 : H12AffineEnvironment.transform 10 80 env47979 = env47980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env47979 == env47980) = true)

def env47981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,98678,16,98644,8193,65,245018,5392,17664,179512,1364,95531,257,21792,46092,74251]

theorem envBound47981 : H12AffineFastState.Bounded env47981 := by
  intro p hp
  have h : env47981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47971_47981 : H12AffineEnvironment.transform 6 9 env47971 = env47981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47971 == env47981) = true)

theorem identity47981 : scanCanonicalize (H12AffineFastState.compose env47981 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47981 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,4161,98678,16,98644,8193,65,245018,5392,4097,179512,1364,73770,257,33,46092,74251]

theorem envBound47982 : H12AffineFastState.Bounded env47982 := by
  intro p hp
  have h : env47982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47981_47982 : H12AffineEnvironment.transform 13 5377 env47981 = env47982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47981 == env47982) = true)

theorem identity47982 : scanCanonicalize (H12AffineFastState.compose env47982 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound47982 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env47983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5441,10280,1025,32769,4161,98678,16,98644,8193,65,108635,5392,4097,43129,1364,73770,257,33,46092,74251]

theorem envBound47983 : H12AffineFastState.Bounded env47983 := by
  intro p hp
  have h : env47983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47982_47983 : H12AffineEnvironment.transform 16 5441 env47982 = env47983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env47982 == env47983) = true)

theorem identity47983 : scanCanonicalize (H12AffineFastState.compose env47983 (packedSelected [4,9,12,14,15,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound47983 : packedSelected [4,9,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env47984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8461,65536,5441,10280,1025,8460,4161,73851,16,73817,8193,65,67926,5392,4097,2420,1364,73770,257,33,5377,74251]

theorem envBound47984 : H12AffineFastState.Bounded env47984 := by
  intro p hp
  have h : env47984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47983_47984 : H12AffineEnvironment.transform 14 8461 env47983 = env47984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env47983 == env47984) = true)

theorem identity47984 : scanCanonicalize (H12AffineFastState.compose env47984 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound47984 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env47985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8461,8282,5441,10280,1025,8460,4161,33,16,3,8193,65,10508,5392,4097,2420,1364,112,257,33,5377,593]

theorem envBound47985 : H12AffineFastState.Bounded env47985 := by
  intro p hp
  have h : env47985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47984_47985 : H12AffineEnvironment.transform 15 8282 env47984 = env47985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env47984 == env47985) = true)

theorem identity47985 : scanCanonicalize (H12AffineFastState.compose env47985 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 5481) := by decide +kernel

theorem selectedBound47985 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env47986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5481,5377,5220,5427,5441,7489,1025,5221,4161,33,16,3,5480,65,7269,5392,4097,2420,1364,112,257,33,5377,593]

theorem envBound47986 : H12AffineFastState.Bounded env47986 := by
  intro p hp
  have h : env47986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47985_47986 : H12AffineEnvironment.transform 12 5481 env47985 = env47986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5481 env47985 == env47986) = true)

theorem identity47986 : scanCanonicalize (H12AffineFastState.compose env47986 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47986 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47987 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5433,5377,5172,5427,5393,7441,1025,5173,4113,33,16,3,5432,17,7221,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound47987 : H12AffineFastState.Bounded env47987 := by
  intro p hp
  have h : env47987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47986_47987 : H12AffineEnvironment.transform 5 16 env47986 = env47987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47986 == env47987) = true)

theorem identity47987 : scanCanonicalize (H12AffineFastState.compose env47987 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound47987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47988 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1076,269,309,0,263,293,2341,1025,1,1061,33,16,3,268,17,2049,292,1077,2340,1284,32,257,33,309,513]

theorem envBound47988 : H12AffineFastState.Bounded env47988 := by
  intro p hp
  have h : env47988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47987_47988 : H12AffineEnvironment.transform 11 1076 env47987 = env47988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env47987 == env47988) = true)

theorem identity47988 : scanCanonicalize (H12AffineFastState.compose env47988 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound47988 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47989 : List Nat := [2,4,8,16,32,16,9,256,512,784,2048,804,269,309,0,263,293,2341,785,1,821,33,16,3,268,17,2049,292,805,2340,532,32,257,33,309,513]

theorem envBound47989 : H12AffineFastState.Bounded env47989 := by
  intro p hp
  have h : env47989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47988_47989 : H12AffineEnvironment.transform 9 784 env47988 = env47989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env47988 == env47989) = true)

theorem identity47989 : scanCanonicalize (H12AffineFastState.compose env47989 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound47989 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47990 : List Nat := [2,4,8,16,32,16,9,256,512,784,293,804,269,309,0,263,293,0,785,1,821,33,16,3,268,17,292,292,805,1,532,32,257,33,309,513]

theorem envBound47990 : H12AffineFastState.Bounded env47990 := by
  intro p hp
  have h : env47990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47989_47990 : H12AffineEnvironment.transform 10 293 env47989 = env47990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env47989 == env47990) = true)

theorem identity47990 : scanCanonicalize (H12AffineFastState.compose env47990 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound47990 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47991 : List Nat := [2,4,8,16,32,16,9,52,512,548,17,528,57,1,0,51,17,0,549,1,513,33,16,3,56,17,16,16,529,1,532,32,53,33,1,513]

theorem envBound47991 : H12AffineFastState.Bounded env47991 := by
  intro p hp
  have h : env47991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47990_47991 : H12AffineEnvironment.transform 7 52 env47990 = env47991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env47990 == env47991) = true)

def env47992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,8388608,10588557,8328,65,6433837,8393985,10507601,8568224,2102685,12645452,257,21793,46212,2175563]

theorem envBound47992 : H12AffineFastState.Bounded env47992 := by
  intro p hp
  have h : env47992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47900_47992 : H12AffineEnvironment.transform 17 32161 env47900 = env47992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env47900 == env47992) = true)

def env47993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,2101328,98781,8328,65,6433837,2098513,17665,2272752,2102685,6349852,257,21793,46212,2175563]

theorem envBound47993 : H12AffineFastState.Bounded env47993 := by
  intro p hp
  have h : env47993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47992_47993 : H12AffineEnvironment.transform 22 2101328 env47992 = env47993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env47992 == env47993) = true)

def env47994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,4194304,16,98781,8328,65,4340845,5393,17665,179632,1501,4256860,257,21793,46212,74251]

theorem envBound47994 : H12AffineFastState.Bounded env47994 := by
  intro p hp
  have h : env47994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47993_47994 : H12AffineEnvironment.transform 20 4160 env47993 = env47994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47993 == env47994) = true)

theorem identity47994 : scanCanonicalize (H12AffineFastState.compose env47994 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41461) := by decide +kernel

theorem selectedBound47994 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,41461,16,98781,8328,65,171416,5393,17665,179632,1501,21929,257,21793,46212,74251]

theorem envBound47995 : H12AffineFastState.Bounded env47995 := by
  intro p hp
  have h : env47995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47994_47995 : H12AffineEnvironment.transform 21 41461 env47994 = env47995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41461 env47994 == env47995) = true)

def env47996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,41341,16,98645,8192,65,171280,5393,17665,179512,1365,21793,257,21793,46092,74251]

theorem envBound47996 : H12AffineFastState.Bounded env47996 := by
  intro p hp
  have h : env47996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47995_47996 : H12AffineEnvironment.transform 6 8 env47995 = env47996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47995 == env47996) = true)

theorem identity47996 : scanCanonicalize (H12AffineFastState.compose env47996 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound47996 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32041,1025,29789,4160,21793,16,95497,8192,65,158028,5393,17665,149860,1365,21793,257,21793,16464,74251]

theorem envBound47997 : H12AffineFastState.Bounded env47997 := by
  intro p hp
  have h : env47997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47996_47997 : H12AffineEnvironment.transform 14 29788 env47996 = env47997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env47996 == env47997) = true)

theorem identity47997 : scanCanonicalize (H12AffineFastState.compose env47997 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound47997 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,131072,32041,1025,29789,4160,21793,16,29791,8192,65,158028,5393,17665,149860,1365,21793,257,21793,16464,9053]

theorem envBound47998 : H12AffineFastState.Bounded env47998 := by
  intro p hp
  have h : env47998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47997_47998 : H12AffineEnvironment.transform 15 342 env47997 = env47998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env47997 == env47998) = true)

theorem identity47998 : scanCanonicalize (H12AffineFastState.compose env47998 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound47998 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env47999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,342,5393,32041,1025,29789,4160,21793,16,29791,8192,65,31837,5393,17665,23669,1365,21793,257,21793,16464,9053]

theorem envBound47999 : H12AffineFastState.Bounded env47999 := by
  intro p hp
  have h : env47999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47998_47999 : H12AffineEnvironment.transform 16 5393 env47998 = env47999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env47998 == env47999) = true)

theorem identity47999 : scanCanonicalize (H12AffineFastState.compose env47999 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47999 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,342,5393,2420,1025,0,4160,8572,16,2,8192,65,2048,5393,12636,10280,1365,8572,257,8572,13325,9053]

theorem envBound48000 : H12AffineFastState.Bounded env48000 := by
  intro p hp
  have h : env48000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47999_48000 : H12AffineEnvironment.transform 13 13405 env47999 = env48000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47999 == env48000) = true)

theorem identity48000 : scanCanonicalize (H12AffineFastState.compose env48000 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound48000 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2357,8192,11624,1,342,3108,2420,1025,0,2421,8572,16,2,8192,65,2048,3108,10345,10280,1365,8572,257,8572,11576,9053]

theorem envBound48001 : H12AffineFastState.Bounded env48001 := by
  intro p hp
  have h : env48001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48000_48001 : H12AffineEnvironment.transform 11 2357 env48000 = env48001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env48000 == env48001) = true)

theorem identity48001 : scanCanonicalize (H12AffineFastState.compose env48001 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound48001 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env48002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2357,2089,1345,1,342,3108,2420,1025,0,2421,2389,16,2,2089,65,2048,3108,64,1,1365,2389,257,2389,1297,2932]

theorem envBound48002 : H12AffineFastState.Bounded env48002 := by
  intro p hp
  have h : env48002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48001_48002 : H12AffineEnvironment.transform 12 2089 env48001 = env48002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env48001 == env48002) = true)

theorem identity48002 : scanCanonicalize (H12AffineFastState.compose env48002 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound48002 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env48003 : List Nat := [2,4,8,16,32,1,8,256,512,1024,2048,2357,2089,1280,1,279,3108,2357,1025,0,2356,2324,16,2,2089,0,2048,3108,1,1,1300,2324,257,2324,1297,2869]

theorem envBound48003 : H12AffineFastState.Bounded env48003 := by
  intro p hp
  have h : env48003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48002_48003 : H12AffineEnvironment.transform 5 1 env48002 = env48003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48002 == env48003) = true)

theorem identity48003 : scanCanonicalize (H12AffineFastState.compose env48003 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound48003 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env48004 : List Nat := [2,4,8,16,32,1,8,256,512,1024,1281,1076,1320,1280,1,279,293,1076,1025,0,1077,1045,16,2,1320,0,1281,293,1,1,1300,1045,257,1045,1297,1588]

theorem envBound48004 : H12AffineFastState.Bounded env48004 := by
  intro p hp
  have h : env48004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48003_48004 : H12AffineEnvironment.transform 10 1281 env48003 = env48004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env48003 == env48004) = true)

theorem identity48004 : scanCanonicalize (H12AffineFastState.compose env48004 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48004 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env48005 : List Nat := [2,4,8,16,32,1,8,256,512,53,308,1,285,309,1,279,293,1,52,0,0,32,16,2,285,0,308,293,1,1,289,32,257,32,292,513]

theorem envBound48005 : H12AffineFastState.Bounded env48005 := by
  intro p hp
  have h : env48005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48004_48005 : H12AffineEnvironment.transform 9 53 env48004 = env48005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48004 == env48005) = true)

theorem identity48005 : scanCanonicalize (H12AffineFastState.compose env48005 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound48005 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48006 : List Nat := [2,4,8,16,32,1,8,256,17,53,308,1,285,309,1,279,293,1,52,0,0,32,16,2,285,0,308,293,1,1,289,32,257,32,292,16]

theorem envBound48006 : H12AffineFastState.Bounded env48006 := by
  intro p hp
  have h : env48006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48005_48006 : H12AffineEnvironment.transform 8 17 env48005 = env48006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env48005 == env48006) = true)

theorem identity48006 : scanCanonicalize (H12AffineFastState.compose env48006 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48006 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env48007 : List Nat := [2,4,8,16,32,1,8,37,17,53,17,1,56,16,1,50,0,1,52,0,0,32,16,2,56,0,17,0,1,1,4,32,36,32,1,16]

theorem envBound48007 : H12AffineFastState.Bounded env48007 := by
  intro p hp
  have h : env48007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48006_48007 : H12AffineEnvironment.transform 7 37 env48006 = env48007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48006 == env48007) = true)

theorem identity48007 : scanCanonicalize (H12AffineFastState.compose env48007 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound48007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48008 : List Nat := [2,4,8,16,17,1,8,20,17,4,17,1,9,16,1,3,0,1,5,0,0,17,16,2,9,0,17,0,1,1,4,17,21,17,1,16]

theorem envBound48008 : H12AffineFastState.Bounded env48008 := by
  intro p hp
  have h : env48008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48007_48008 : H12AffineEnvironment.transform 4 17 env48007 = env48008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env48007 == env48008) = true)

def env48009 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,41340,16,98644,8193,65,171281,5393,17665,179513,1364,21792,257,21793,46093,74251]

theorem envBound48009 : H12AffineFastState.Bounded env48009 := by
  intro p hp
  have h : env48009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47995_48009 : H12AffineEnvironment.transform 6 9 env47995 = env48009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47995 == env48009) = true)

theorem identity48009 : scanCanonicalize (H12AffineFastState.compose env48009 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48009 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4160,41340,16,98644,8193,65,171281,5393,4097,179513,1364,32,257,33,46093,74251]

theorem envBound48010 : H12AffineFastState.Bounded env48010 := by
  intro p hp
  have h : env48010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48009_48010 : H12AffineEnvironment.transform 13 5376 env48009 = env48010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48009 == env48010) = true)

theorem identity48010 : scanCanonicalize (H12AffineFastState.compose env48010 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound48010 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,262,131072,10280,1025,32769,4160,41340,16,32850,8193,65,171281,5393,4097,179513,1364,32,257,33,46093,8973]

theorem envBound48011 : H12AffineFastState.Bounded env48011 := by
  intro p hp
  have h : env48011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48010_48011 : H12AffineEnvironment.transform 15 262 env48010 = env48011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env48010 == env48011) = true)

theorem identity48011 : scanCanonicalize (H12AffineFastState.compose env48011 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48011 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env48012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,262,131072,10280,1025,1,4160,8572,16,82,8193,65,138513,5393,4097,146745,1364,32,257,33,13325,8973]

theorem envBound48012 : H12AffineFastState.Bounded env48012 := by
  intro p hp
  have h : env48012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48011_48012 : H12AffineEnvironment.transform 14 0 env48011 = env48012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48011 == env48012) = true)

theorem identity48012 : scanCanonicalize (H12AffineFastState.compose env48012 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48012 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,0,262,131072,2341,1025,1,4160,113,16,82,268,65,138513,5393,4097,138292,1364,32,257,33,5376,512]

theorem envBound48013 : H12AffineFastState.Bounded env48013 := by
  intro p hp
  have h : env48013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48012_48013 : H12AffineEnvironment.transform 12 269 env48012 = env48013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48012 == env48013) = true)

theorem identity48013 : scanCanonicalize (H12AffineFastState.compose env48013 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 5425) := by decide +kernel

theorem selectedBound48013 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,0,262,5425,2341,1025,1,4160,113,16,82,268,65,2080,5393,4097,2309,1364,32,257,33,5376,512]

theorem envBound48014 : H12AffineFastState.Bounded env48014 := by
  intro p hp
  have h : env48014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48013_48014 : H12AffineEnvironment.transform 16 5425 env48013 = env48014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5425 env48013 == env48014) = true)

theorem identity48014 : scanCanonicalize (H12AffineFastState.compose env48014 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound48014 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env48015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,269,0,0,262,49,2341,1025,1,1344,113,16,82,268,65,2080,17,1281,2309,1364,32,257,33,0,512]

theorem envBound48015 : H12AffineFastState.Bounded env48015 := by
  intro p hp
  have h : env48015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48014_48015 : H12AffineEnvironment.transform 11 1280 env48014 = env48015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env48014 == env48015) = true)

theorem identity48015 : scanCanonicalize (H12AffineFastState.compose env48015 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound48015 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env48016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,1280,269,0,0,262,49,80,1025,1,1344,113,16,82,268,65,341,17,1281,112,1364,32,257,33,0,512]

theorem envBound48016 : H12AffineFastState.Bounded env48016 := by
  intro p hp
  have h : env48016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48015_48016 : H12AffineEnvironment.transform 10 373 env48015 = env48016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env48015 == env48016) = true)

theorem identity48016 : scanCanonicalize (H12AffineFastState.compose env48016 (packedSelected [6,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48016 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env48017 : List Nat := [2,4,8,16,32,64,9,256,512,52,373,308,269,0,0,262,49,80,53,1,372,113,16,82,268,65,341,17,309,112,352,32,257,33,0,512]

theorem envBound48017 : H12AffineFastState.Bounded env48017 := by
  intro p hp
  have h : env48017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48016_48017 : H12AffineEnvironment.transform 9 52 env48016 = env48017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48016 == env48017) = true)

theorem identity48017 : scanCanonicalize (H12AffineFastState.compose env48017 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48017 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env48018 : List Nat := [2,4,8,16,32,64,9,37,512,52,80,17,40,0,0,35,49,80,53,1,81,113,16,82,41,65,112,17,16,112,69,32,36,33,0,512]

theorem envBound48018 : H12AffineFastState.Bounded env48018 := by
  intro p hp
  have h : env48018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48017_48018 : H12AffineEnvironment.transform 7 37 env48017 = env48018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48017 == env48018) = true)

theorem identity48018 : scanCanonicalize (H12AffineFastState.compose env48018 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound48018 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env48019 : List Nat := [2,4,8,16,32,48,9,37,512,52,32,17,40,0,0,35,49,32,53,1,33,1,16,34,41,49,0,17,16,0,53,32,36,33,0,512]

theorem envBound48019 : H12AffineFastState.Bounded env48019 := by
  intro p hp
  have h : env48019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48018_48019 : H12AffineEnvironment.transform 5 48 env48018 = env48019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env48018 == env48019) = true)

def env48020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,4194304,17,98781,8328,65,4340844,5392,17665,179633,1500,4256861,257,21793,46212,74250]

theorem envBound48020 : H12AffineFastState.Bounded env48020 := by
  intro p hp
  have h : env48020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47993_48020 : H12AffineEnvironment.transform 20 4161 env47993 = env48020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47993 == env48020) = true)

theorem identity48020 : scanCanonicalize (H12AffineFastState.compose env48020 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound48020 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32161,1025,29908,4161,4194304,17,95496,8328,65,4340844,5392,17665,149860,1500,4194440,257,21793,16465,74250]

theorem envBound48021 : H12AffineFastState.Bounded env48021 := by
  intro p hp
  have h : env48021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48020_48021 : H12AffineEnvironment.transform 14 29909 env48020 = env48021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env48020 == env48021) = true)

def env48022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1025,8660,4161,4194304,17,73736,8328,65,4340844,5392,4097,138340,1500,4194440,257,33,5457,74250]

theorem envBound48022 : H12AffineFastState.Bounded env48022 := by
  intro p hp
  have h : env48022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48021_48022 : H12AffineEnvironment.transform 13 5376 env48021 = env48022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48021 == env48022) = true)

theorem identity48022 : scanCanonicalize (H12AffineFastState.compose env48022 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48022 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1025,8541,4161,4194304,17,73736,8193,65,4340844,5392,4097,138340,1365,4194305,257,33,5457,74250]

theorem envBound48023 : H12AffineFastState.Bounded env48023 := by
  intro p hp
  have h : env48023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48022_48023 : H12AffineEnvironment.transform 6 9 env48022 = env48023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48022 == env48023) = true)

theorem identity48023 : scanCanonicalize (H12AffineFastState.compose env48023 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 210234) := by decide +kernel

theorem selectedBound48023 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env48024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10280,1025,8541,4161,210234,17,73736,8193,65,67926,5392,4097,138340,1365,210235,257,33,5457,74250]

theorem envBound48024 : H12AffineFastState.Bounded env48024 := by
  intro p hp
  have h : env48024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48023_48024 : H12AffineEnvironment.transform 21 210234 env48023 = env48024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210234 env48023 == env48024) = true)

theorem identity48024 : scanCanonicalize (H12AffineFastState.compose env48024 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48024 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env48025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10280,1025,8541,4161,136496,17,2,8193,65,10588,5392,4097,138340,1365,136497,257,33,5457,512]

theorem envBound48025 : H12AffineFastState.Bounded env48025 := by
  intro p hp
  have h : env48025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48024_48025 : H12AffineEnvironment.transform 15 8202 env48024 = env48025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48024 == env48025) = true)

theorem identity48025 : scanCanonicalize (H12AffineFastState.compose env48025 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound48025 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5376,113,295,131072,2309,1025,112,4161,136496,17,2,300,65,2161,5392,4097,138340,1365,136497,257,33,5457,512]

theorem envBound48026 : H12AffineFastState.Bounded env48026 := by
  intro p hp
  have h : env48026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48025_48026 : H12AffineEnvironment.transform 12 301 env48025 = env48026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env48025 == env48026) = true)

theorem identity48026 : scanCanonicalize (H12AffineFastState.compose env48026 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound48026 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env48027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1361,301,81,113,295,131072,2309,1025,112,1296,131169,17,2,300,65,2161,65,1360,133429,1365,131168,257,33,0,512]

theorem envBound48027 : H12AffineFastState.Bounded env48027 := by
  intro p hp
  have h : env48027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48026_48027 : H12AffineEnvironment.transform 11 1361 env48026 = env48027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env48026 == env48027) = true)

theorem identity48027 : scanCanonicalize (H12AffineFastState.compose env48027 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound48027 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env48028 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,276,301,81,113,295,131072,2309,68,112,341,131169,17,2,300,65,2161,65,277,133429,272,131168,257,33,0,512]

theorem envBound48028 : H12AffineFastState.Bounded env48028 := by
  intro p hp
  have h : env48028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48027_48028 : H12AffineEnvironment.transform 9 69 env48027 = env48028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env48027 == env48028) = true)

theorem identity48028 : scanCanonicalize (H12AffineFastState.compose env48028 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 2113) := by decide +kernel

theorem selectedBound48028 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env48029 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,276,301,81,113,295,2113,2309,68,112,341,2080,17,2,300,65,2161,65,277,372,272,2081,257,33,0,512]

theorem envBound48029 : H12AffineFastState.Bounded env48029 := by
  intro p hp
  have h : env48029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48028_48029 : H12AffineEnvironment.transform 16 2113 env48028 = env48029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2113 env48028 == env48029) = true)

theorem identity48029 : scanCanonicalize (H12AffineFastState.compose env48029 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound48029 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env48030 : List Nat := [2,4,8,16,32,64,9,256,512,69,373,276,301,81,113,295,308,112,68,112,341,341,17,2,300,65,260,65,277,372,272,340,257,33,0,512]

theorem envBound48030 : H12AffineFastState.Bounded env48030 := by
  intro p hp
  have h : env48030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48029_48030 : H12AffineEnvironment.transform 10 373 env48029 = env48030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env48029 == env48030) = true)

theorem identity48030 : scanCanonicalize (H12AffineFastState.compose env48030 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48030 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env48031 : List Nat := [2,4,8,16,32,17,9,256,512,20,292,276,301,0,32,295,308,33,21,33,260,260,17,2,300,16,260,16,277,293,272,261,257,33,0,512]

theorem envBound48031 : H12AffineFastState.Bounded env48031 := by
  intro p hp
  have h : env48031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48030_48031 : H12AffineEnvironment.transform 5 17 env48030 = env48031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48030 == env48031) = true)

theorem identity48031 : scanCanonicalize (H12AffineFastState.compose env48031 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound48031 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48032 : List Nat := [2,4,8,16,32,17,9,5,512,20,33,17,40,0,32,34,49,33,21,33,1,1,17,2,41,16,1,16,16,32,21,0,4,33,0,512]

theorem envBound48032 : H12AffineFastState.Bounded env48032 := by
  intro p hp
  have h : env48032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48031_48032 : H12AffineEnvironment.transform 7 5 env48031 = env48032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env48031 == env48032) = true)

theorem identity48032 : scanCanonicalize (H12AffineFastState.compose env48032 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48032 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48033 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,0,1,3,16,0,21,0,1,1,17,2,8,16,1,16,16,1,21,0,4,0,0,512]

theorem envBound48033 : H12AffineFastState.Bounded env48033 := by
  intro p hp
  have h : env48033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48032_48033 : H12AffineEnvironment.transform 4 1 env48032 = env48033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48032 == env48033) = true)

theorem identity48033 : scanCanonicalize (H12AffineFastState.compose env48033 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48034 : List Nat := [2,0,8,16,1,17,9,1,512,16,0,17,9,0,1,3,16,0,17,0,1,1,17,2,8,16,1,16,16,1,17,0,0,0,0,512]

theorem envBound48034 : H12AffineFastState.Bounded env48034 := by
  intro p hp
  have h : env48034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48033_48034 : H12AffineEnvironment.transform 1 0 env48033 = env48034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48033 == env48034) = true)

theorem identity48034 : scanCanonicalize (H12AffineFastState.compose env48034 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48035 : List Nat := [0,0,8,16,1,17,9,1,512,16,0,17,9,0,1,1,16,0,17,0,1,1,17,0,8,16,1,16,16,1,17,0,0,0,0,512]

theorem envBound48035 : H12AffineFastState.Bounded env48035 := by
  intro p hp
  have h : env48035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48034_48035 : H12AffineEnvironment.transform 0 0 env48034 = env48035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48034 == env48035) = true)

theorem identity48035 : scanCanonicalize (H12AffineFastState.compose env48035 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48035 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48036 : List Nat := [0,0,8,0,1,1,9,1,512,0,0,1,9,0,1,1,0,0,1,0,1,1,1,0,8,0,1,0,0,1,1,0,0,0,0,512]

theorem envBound48036 : H12AffineFastState.Bounded env48036 := by
  intro p hp
  have h : env48036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48035_48036 : H12AffineEnvironment.transform 3 0 env48035 = env48036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48035 == env48036) = true)

theorem identity48036 : scanCanonicalize (H12AffineFastState.compose env48036 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound48036 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48037 : List Nat := [0,0,1,0,1,1,0,1,512,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,1,0,1,0,0,1,1,0,0,0,0,512]

theorem envBound48037 : H12AffineFastState.Bounded env48037 := by
  intro p hp
  have h : env48037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48036_48037 : H12AffineEnvironment.transform 2 1 env48036 = env48037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env48036 == env48037) = true)

theorem identity48037 : scanCanonicalize (H12AffineFastState.compose env48037 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48037 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48038 : List Nat := [0,0,1,0,1,1,0,1,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,0,1,0,1,0,0,1,1,0,0,0,0,0]

theorem envBound48038 : H12AffineFastState.Bounded env48038 := by
  intro p hp
  have h : env48038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48037_48038 : H12AffineEnvironment.transform 8 0 env48037 = env48038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48037 == env48038) = true)

def env48039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1025,8661,4161,4194304,17,73737,8328,65,4340844,5392,4096,138341,1500,4194440,257,32,5456,74250]

theorem envBound48039 : H12AffineFastState.Bounded env48039 := by
  intro p hp
  have h : env48039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48021_48039 : H12AffineEnvironment.transform 13 5377 env48021 = env48039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48021 == env48039) = true)

theorem identity48039 : scanCanonicalize (H12AffineFastState.compose env48039 (packedSelected [0,3,4,5,7,8,10,11,12,15,16,18,20,22,23,28,31,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 210355) := by decide +kernel

theorem selectedBound48039 : packedSelected [0,3,4,5,7,8,10,11,12,15,16,18,20,22,23,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env48040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10400,1025,8661,4161,210355,17,73737,8328,65,68063,5392,4096,138341,1500,210235,257,32,5456,74250]

theorem envBound48040 : H12AffineFastState.Bounded env48040 := by
  intro p hp
  have h : env48040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48039_48040 : H12AffineEnvironment.transform 21 210355 env48039 = env48040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210355 env48039 == env48040) = true)

theorem identity48040 : scanCanonicalize (H12AffineFastState.compose env48040 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound48040 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env48041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,5392,10400,1025,8661,4161,73891,17,73737,8328,65,68063,5392,4096,2421,1500,73771,257,32,5456,74250]

theorem envBound48041 : H12AffineFastState.Bounded env48041 := by
  intro p hp
  have h : env48041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48040_48041 : H12AffineEnvironment.transform 16 5392 env48040 = env48041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48040 == env48041) = true)

theorem identity48041 : scanCanonicalize (H12AffineFastState.compose env48041 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound48041 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env48042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,399,5392,10400,1025,8661,4161,8492,17,8582,8328,65,2128,5392,4096,2421,1500,8612,257,32,5456,9093]

theorem envBound48042 : H12AffineFastState.Bounded env48042 := by
  intro p hp
  have h : env48042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48041_48042 : H12AffineEnvironment.transform 15 399 env48041 = env48042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env48041 == env48042) = true)

theorem identity48042 : scanCanonicalize (H12AffineFastState.compose env48042 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48042 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env48043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,399,5392,2556,1025,137,4161,112,17,218,468,65,2128,5392,4096,2421,1500,248,257,32,5456,729]

theorem envBound48043 : H12AffineFastState.Bounded env48043 := by
  intro p hp
  have h : env48043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48042_48043 : H12AffineEnvironment.transform 12 348 env48042 = env48043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48042 == env48043) = true)

theorem identity48043 : scanCanonicalize (H12AffineFastState.compose env48043 (packedSelected [0,1,4,7,8,9,10,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48043 : packedSelected [0,1,4,7,8,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48044 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,41,5236,136,250,5221,2185,1025,137,4161,112,17,218,161,65,2128,5221,4096,2048,1193,248,116,32,5157,729]

theorem envBound48044 : H12AffineFastState.Bounded env48044 := by
  intro p hp
  have h : env48044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48043_48044 : H12AffineEnvironment.transform 7 117 env48043 = env48044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48043 == env48044) = true)

theorem identity48044 : scanCanonicalize (H12AffineFastState.compose env48044 (packedSelected [2,4,6,9,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound48044 : packedSelected [2,4,6,9,12,18] rootPS < 2^1333 := by decide +kernel

def env48045 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,4096,41,4112,136,250,4097,2185,101,137,4161,112,17,218,161,65,2128,4097,4096,2048,205,248,116,32,4161,729]

theorem envBound48045 : H12AffineFastState.Bounded env48045 := by
  intro p hp
  have h : env48045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48044_48045 : H12AffineEnvironment.transform 9 100 env48044 = env48045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env48044 == env48045) = true)

theorem identity48045 : scanCanonicalize (H12AffineFastState.compose env48045 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48045 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env48046 : List Nat := [2,4,8,16,32,16,128,37,512,52,2048,4096,41,4112,136,170,4097,2185,53,137,4113,32,17,138,161,17,2048,4097,4096,2048,157,168,36,32,4113,649]

theorem envBound48046 : H12AffineFastState.Bounded env48046 := by
  intro p hp
  have h : env48046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48045_48046 : H12AffineEnvironment.transform 5 16 env48045 = env48046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48045 == env48046) = true)

theorem identity48046 : scanCanonicalize (H12AffineFastState.compose env48046 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound48046 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env48047 : List Nat := [2,4,8,16,32,16,128,37,136,52,2048,4096,41,4112,136,170,4097,2185,53,137,4113,32,17,138,161,17,2048,4097,4096,2048,157,168,36,32,4113,1]

theorem envBound48047 : H12AffineFastState.Bounded env48047 := by
  intro p hp
  have h : env48047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48046_48047 : H12AffineEnvironment.transform 8 136 env48046 = env48047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env48046 == env48047) = true)

theorem identity48047 : scanCanonicalize (H12AffineFastState.compose env48047 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound48047 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env48048 : List Nat := [2,4,8,16,32,16,128,37,136,52,2048,2064,41,2048,136,170,2065,2185,53,137,2049,32,17,138,161,17,2048,2065,2064,2048,157,168,36,32,2049,1]

theorem envBound48048 : H12AffineFastState.Bounded env48048 := by
  intro p hp
  have h : env48048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48047_48048 : H12AffineEnvironment.transform 11 2064 env48047 = env48048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env48047 == env48048) = true)

theorem identity48048 : scanCanonicalize (H12AffineFastState.compose env48048 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48048 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env48049 : List Nat := [2,4,8,16,1,16,128,4,136,21,2048,2064,8,2048,136,139,2065,2185,20,137,2049,1,17,138,128,17,2048,2065,2064,2048,157,137,5,1,2049,1]

theorem envBound48049 : H12AffineFastState.Bounded env48049 := by
  intro p hp
  have h : env48049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48048_48049 : H12AffineEnvironment.transform 4 1 env48048 = env48049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48048 == env48049) = true)

theorem identity48049 : scanCanonicalize (H12AffineFastState.compose env48049 (packedSelected [0,1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48049 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env48050 : List Nat := [2,4,8,16,1,16,9,4,1,21,2048,2064,8,2048,1,2,2065,2048,20,0,2049,1,17,3,9,17,2048,2065,2064,2048,20,0,5,1,2049,1]

theorem envBound48050 : H12AffineFastState.Bounded env48050 := by
  intro p hp
  have h : env48050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48049_48050 : H12AffineEnvironment.transform 6 9 env48049 = env48050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48049 == env48050) = true)

theorem identity48050 : scanCanonicalize (H12AffineFastState.compose env48050 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound48050 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48051 : List Nat := [2,4,8,16,1,16,9,4,1,21,31,15,8,31,1,2,14,31,20,0,30,1,17,3,9,17,31,14,15,31,20,0,5,1,30,1]

theorem envBound48051 : H12AffineFastState.Bounded env48051 := by
  intro p hp
  have h : env48051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48050_48051 : H12AffineEnvironment.transform 10 31 env48050 = env48051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env48050 == env48051) = true)

def leafEnv48051 : List Nat := [2,4,8,16,1,16,9,4,1,21,31,15,8,31,1,2,14,31,20,0,30,1,17,3,21,9,1,17,31,14,15,31,20,0,5,1,5,3,30,1,1,31,0]

def active48051 : List Nat := [0,1,2,3]

def tree48051 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48051 : H12WitnessSearch.Good tree48051 := H12GlobalWitnessIndex.good

theorem leafIdentity48051 : H12AffineFastState.composeSystem env48051 rootObs = leafEnv48051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48051 rootObs == leafEnv48051) = true)

theorem terminalChecked48051 : H12PackedTerminal.terminalCheckFast leafEnv48051 active48051 tree48051 = true := by decide +kernel

def env48052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,2101329,98780,8328,65,6433837,2098512,17664,2272753,2102685,6349853,257,21793,46212,2175563]

theorem envBound48052 : H12AffineFastState.Bounded env48052 := by
  intro p hp
  have h : env48052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47992_48052 : H12AffineEnvironment.transform 22 2101329 env47992 = env48052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env47992 == env48052) = true)

def env48053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,4194304,17,98780,8328,65,4340845,5392,17664,179633,1501,4256861,257,21793,46212,74251]

theorem envBound48053 : H12AffineFastState.Bounded env48053 := by
  intro p hp
  have h : env48053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48052_48053 : H12AffineEnvironment.transform 20 4160 env48052 = env48053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48052 == env48053) = true)

def env48054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,17,98644,8192,65,4340845,5392,17664,179513,1365,4256861,257,21793,46092,74251]

theorem envBound48054 : H12AffineFastState.Bounded env48054 := by
  intro p hp
  have h : env48054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48053_48054 : H12AffineEnvironment.transform 6 8 env48053 = env48054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48053 == env48054) = true)

theorem identity48054 : scanCanonicalize (H12AffineFastState.compose env48054 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48054 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,32041,1025,8541,4160,4194304,17,73736,8192,65,4340845,5392,17664,138341,1365,4216065,257,21793,5456,74251]

theorem envBound48055 : H12AffineFastState.Bounded env48055 := by
  intro p hp
  have h : env48055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48054_48055 : H12AffineEnvironment.transform 14 8540 env48054 = env48055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48054 == env48055) = true)

theorem identity48055 : scanCanonicalize (H12AffineFastState.compose env48055 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound48055 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env48056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,32041,1025,8541,4160,4194304,17,73736,8192,65,4283511,5392,17664,97407,1365,4216065,257,21793,5456,74251]

theorem envBound48056 : H12AffineFastState.Bounded env48056 := by
  intro p hp
  have h : env48056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48055_48056 : H12AffineEnvironment.transform 16 90138 env48055 = env48056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env48055 == env48056) = true)

theorem identity48056 : scanCanonicalize (H12AffineFastState.compose env48056 (packedSelected [0,3,5,7,9,10,12,14,20,22,38] rootPS)) = affineNative (2^(21+1) ^^^ 21589) := by decide +kernel

theorem selectedBound48056 : packedSelected [0,3,5,7,9,10,12,14,20,22,38] rootPS < 2^1333 := by decide +kernel

def env48057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90138,32041,1025,8541,4160,21589,17,73736,8192,65,67618,5392,17664,97407,1365,340,257,21793,5456,74251]

theorem envBound48057 : H12AffineFastState.Bounded env48057 := by
  intro p hp
  have h : env48057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48056_48057 : H12AffineEnvironment.transform 21 21589 env48056 = env48057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21589 env48056 == env48057) = true)

theorem identity48057 : scanCanonicalize (H12AffineFastState.compose env48057 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound48057 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env48058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8574,16740,32041,1025,8541,4160,21589,17,374,8192,65,10588,5392,17664,23809,1365,340,257,21793,5456,885]

theorem envBound48058 : H12AffineFastState.Bounded env48058 := by
  intro p hp
  have h : env48058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48057_48058 : H12AffineEnvironment.transform 15 8574 env48057 = env48058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env48057 == env48058) = true)

theorem identity48058 : scanCanonicalize (H12AffineFastState.compose env48058 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound48058 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env48059 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8232,8202,16400,31837,1025,8233,4160,21589,17,2,8192,65,10280,5220,17524,23669,1057,32,117,21589,5156,513]

theorem envBound48059 : H12AffineFastState.Bounded env48059 := by
  intro p hp
  have h : env48059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48058_48059 : H12AffineEnvironment.transform 7 116 env48058 = env48059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48058 == env48059) = true)

theorem identity48059 : scanCanonicalize (H12AffineFastState.compose env48059 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound48059 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48060 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5157,8232,8202,5173,10360,1025,8233,4160,112,17,2,8192,65,10280,5220,4177,2128,1057,32,117,112,5156,513]

theorem envBound48060 : H12AffineFastState.Bounded env48060 := by
  intro p hp
  have h : env48060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48059_48060 : H12AffineEnvironment.transform 13 5157 env48059 = env48060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env48059 == env48060) = true)

theorem identity48060 : scanCanonicalize (H12AffineFastState.compose env48060 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound48060 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48061 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,4161,8232,8202,4177,10360,101,8233,4160,112,17,2,8192,65,10280,4096,4177,2128,69,32,117,112,4160,513]

theorem envBound48061 : H12AffineFastState.Bounded env48061 := by
  intro p hp
  have h : env48061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48060_48061 : H12AffineEnvironment.transform 9 100 env48060 = env48061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env48060 == env48061) = true)

theorem identity48061 : scanCanonicalize (H12AffineFastState.compose env48061 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound48061 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48062 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,40,4161,0,34,4177,2128,101,1,4160,112,17,2,40,65,2048,4096,4177,2128,69,32,117,112,4160,513]

theorem envBound48062 : H12AffineFastState.Bounded env48062 := by
  intro p hp
  have h : env48062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48061_48062 : H12AffineEnvironment.transform 12 40 env48061 = env48062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env48061 == env48062) = true)

theorem identity48062 : scanCanonicalize (H12AffineFastState.compose env48062 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound48062 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48063 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,17,40,80,0,34,64,2128,101,1,81,112,17,2,40,65,2048,17,64,2128,69,32,117,112,81,513]

theorem envBound48063 : H12AffineFastState.Bounded env48063 := by
  intro p hp
  have h : env48063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48062_48063 : H12AffineEnvironment.transform 11 17 env48062 = env48063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env48062 == env48063) = true)

theorem identity48063 : scanCanonicalize (H12AffineFastState.compose env48063 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound48063 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48064 : List Nat := [2,4,8,16,32,64,8,116,512,100,0,17,40,80,0,34,64,80,101,1,81,112,17,2,40,65,0,17,64,80,69,32,117,112,81,513]

theorem envBound48064 : H12AffineFastState.Bounded env48064 := by
  intro p hp
  have h : env48064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48063_48064 : H12AffineEnvironment.transform 10 0 env48063 = env48064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env48063 == env48064) = true)

def env48065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98645,8193,65,4340845,5392,17664,179512,1364,4256861,257,21793,46093,74251]

theorem envBound48065 : H12AffineFastState.Bounded env48065 := by
  intro p hp
  have h : env48065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48053_48065 : H12AffineEnvironment.transform 6 9 env48053 = env48065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48053 == env48065) = true)

theorem identity48065 : scanCanonicalize (H12AffineFastState.compose env48065 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48065 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env48066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4160,4194304,17,41311,8193,65,4340845,5392,17664,179512,1364,4256861,257,21793,46093,513]

theorem envBound48066 : H12AffineFastState.Bounded env48066 := by
  intro p hp
  have h : env48066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48065_48066 : H12AffineEnvironment.transform 15 8202 env48065 = env48066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48065 == env48066) = true)

theorem identity48066 : scanCanonicalize (H12AffineFastState.compose env48066 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound48066 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env48067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32040,1025,29789,4160,4194304,17,21763,8193,65,4340845,5392,17664,149860,1364,4194305,257,21793,16465,513]

theorem envBound48067 : H12AffineFastState.Bounded env48067 := by
  intro p hp
  have h : env48067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48066_48067 : H12AffineEnvironment.transform 14 29788 env48066 = env48067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env48066 == env48067) = true)

theorem identity48067 : scanCanonicalize (H12AffineFastState.compose env48067 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound48067 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env48068 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32040,1025,29789,4160,21872,17,21763,8193,65,157981,5392,17664,149860,1364,21873,257,21793,16465,513]

theorem envBound48068 : H12AffineFastState.Bounded env48068 := by
  intro p hp
  have h : env48068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48067_48068 : H12AffineEnvironment.transform 21 21872 env48067 = env48068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env48067 == env48068) = true)

theorem identity48068 : scanCanonicalize (H12AffineFastState.compose env48068 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48068 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env48069 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10280,1025,8541,4160,112,17,3,8193,65,146461,5392,4096,138340,1364,113,257,33,5457,513]

theorem envBound48069 : H12AffineFastState.Bounded env48069 := by
  intro p hp
  have h : env48069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48068_48069 : H12AffineEnvironment.transform 13 5376 env48068 = env48069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48068 == env48069) = true)

theorem identity48069 : scanCanonicalize (H12AffineFastState.compose env48069 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48069 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48070 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,10280,1025,8460,4113,33,17,3,8193,16,146461,5392,4096,138293,1285,32,257,33,5376,513]

theorem envBound48070 : H12AffineFastState.Bounded env48070 := by
  intro p hp
  have h : env48070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48069_48070 : H12AffineEnvironment.transform 5 17 env48069 = env48070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48069 == env48070) = true)

theorem identity48070 : scanCanonicalize (H12AffineFastState.compose env48070 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48070 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48071 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,263,131072,2341,1025,1,4113,33,17,3,268,16,138512,5392,4096,138293,1285,32,257,33,5376,513]

theorem envBound48071 : H12AffineFastState.Bounded env48071 := by
  intro p hp
  have h : env48071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48070_48071 : H12AffineEnvironment.transform 12 269 env48070 = env48071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48070 == env48071) = true)

theorem identity48071 : scanCanonicalize (H12AffineFastState.compose env48071 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound48071 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48072 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,263,5172,2341,1025,1,4113,33,17,3,268,16,2340,5392,4096,2049,1285,32,257,33,5376,513]

theorem envBound48072 : H12AffineFastState.Bounded env48072 := by
  intro p hp
  have h : env48072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48071_48072 : H12AffineEnvironment.transform 16 5172 env48071 = env48072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env48071 == env48072) = true)

theorem identity48072 : scanCanonicalize (H12AffineFastState.compose env48072 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48072 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env48073 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,35,5172,2049,1025,1,4113,33,17,3,40,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound48073 : H12AffineFastState.Bounded env48073 := by
  intro p hp
  have h : env48073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48072_48073 : H12AffineEnvironment.transform 7 36 env48072 = env48073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48072 == env48073) = true)

def env48074 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1044,0,35,1028,2049,1025,1,33,33,17,3,40,16,2048,1028,48,2049,1057,32,37,33,1044,513]

theorem envBound48074 : H12AffineFastState.Bounded env48074 := by
  intro p hp
  have h : env48074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48073_48074 : H12AffineEnvironment.transform 11 48 env48073 = env48074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48073 == env48074) = true)

theorem identity48074 : scanCanonicalize (H12AffineFastState.compose env48074 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound48074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48075 : List Nat := [2,4,8,16,32,17,9,36,512,20,2048,48,41,0,0,35,16,2049,21,1,33,33,17,3,40,16,2048,16,48,2049,53,32,37,33,0,513]

theorem envBound48075 : H12AffineFastState.Bounded env48075 := by
  intro p hp
  have h : env48075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48074_48075 : H12AffineEnvironment.transform 9 20 env48074 = env48075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env48074 == env48075) = true)

def env48076 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,16,9,0,0,3,16,2049,21,1,1,1,17,3,8,16,2048,16,16,2049,21,0,5,1,0,513]

theorem envBound48076 : H12AffineFastState.Bounded env48076 := by
  intro p hp
  have h : env48076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48075_48076 : H12AffineEnvironment.transform 4 0 env48075 = env48076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48075 == env48076) = true)

theorem identity48076 : scanCanonicalize (H12AffineFastState.compose env48076 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound48076 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48077 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,0,0,3,16,0,21,1,1,1,17,3,8,16,1,16,16,0,21,0,5,1,0,513]

theorem envBound48077 : H12AffineFastState.Bounded env48077 := by
  intro p hp
  have h : env48077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48076_48077 : H12AffineEnvironment.transform 10 1 env48076 = env48077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env48076 == env48077) = true)

def leafEnv48077 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,0,0,3,16,0,21,1,1,1,17,3,20,8,1,16,1,16,16,0,21,0,5,1,5,2,0,513,1,1,0]

def active48077 : List Nat := [0,1,2,3,8]

def tree48077 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48077 : H12WitnessSearch.Good tree48077 := H12GlobalWitnessIndex.good

theorem leafIdentity48077 : H12AffineFastState.composeSystem env48077 rootObs = leafEnv48077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48077 rootObs == leafEnv48077) = true)

theorem terminalChecked48077 : H12PackedTerminal.terminalCheckFast leafEnv48077 active48077 tree48077 = true := by decide +kernel

def env48078 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,0,0,2,16,2049,21,1,0,0,17,3,9,16,2048,16,17,2049,20,1,4,0,0,513]

theorem envBound48078 : H12AffineFastState.Bounded env48078 := by
  intro p hp
  have h : env48078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48075_48078 : H12AffineEnvironment.transform 4 1 env48075 = env48078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48075 == env48078) = true)

theorem identity48078 : scanCanonicalize (H12AffineFastState.compose env48078 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound48078 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48079 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,17,8,0,0,2,16,522,21,1,0,0,17,3,9,16,523,16,17,522,20,1,4,0,0,513]

theorem envBound48079 : H12AffineFastState.Bounded env48079 := by
  intro p hp
  have h : env48079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48078_48079 : H12AffineEnvironment.transform 10 523 env48078 = env48079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env48078 == env48079) = true)

def leafEnv48079 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,17,8,0,0,2,16,522,21,1,0,0,17,3,21,9,1,16,523,16,17,522,20,1,4,0,5,3,0,513,1,0,0]

def active48079 : List Nat := [0,1,2,3,8]

def tree48079 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48079 : H12WitnessSearch.Good tree48079 := H12GlobalWitnessIndex.good

theorem leafIdentity48079 : H12AffineFastState.composeSystem env48079 rootObs = leafEnv48079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48079 rootObs == leafEnv48079) = true)

theorem terminalChecked48079 : H12PackedTerminal.terminalCheckFast leafEnv48079 active48079 tree48079 = true := by decide +kernel

def env48080 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1045,0,35,1029,2049,1025,1,32,33,17,3,40,16,2048,1029,49,2049,1057,32,37,33,1045,513]

theorem envBound48080 : H12AffineFastState.Bounded env48080 := by
  intro p hp
  have h : env48080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48073_48080 : H12AffineEnvironment.transform 11 49 env48073 = env48080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48073 == env48080) = true)

theorem identity48080 : scanCanonicalize (H12AffineFastState.compose env48080 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48081 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,17,9,1045,0,3,1029,2049,1025,1,0,1,17,3,8,16,2048,1029,17,2049,1025,0,5,1,1045,513]

theorem envBound48081 : H12AffineFastState.Bounded env48081 := by
  intro p hp
  have h : env48081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48080_48081 : H12AffineEnvironment.transform 4 0 env48080 = env48081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48080 == env48081) = true)

def env48082 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,17,9,1,0,3,17,2049,21,1,0,1,17,3,8,16,2048,17,17,2049,21,0,5,1,1,513]

theorem envBound48082 : H12AffineFastState.Bounded env48082 := by
  intro p hp
  have h : env48082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48081_48082 : H12AffineEnvironment.transform 9 20 env48081 = env48082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env48081 == env48082) = true)

theorem identity48082 : scanCanonicalize (H12AffineFastState.compose env48082 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound48082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48083 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,1,0,3,17,1,21,1,0,1,17,3,8,16,0,17,17,1,21,0,5,1,1,513]

theorem envBound48083 : H12AffineFastState.Bounded env48083 := by
  intro p hp
  have h : env48083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48082_48083 : H12AffineEnvironment.transform 10 0 env48082 = env48083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env48082 == env48083) = true)

def leafEnv48083 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,1,0,3,17,1,21,1,0,1,17,3,20,8,1,16,0,17,17,1,21,0,5,1,5,2,1,513,1,0,0]

def active48083 : List Nat := [0,1,2,3,8]

def tree48083 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48083 : H12WitnessSearch.Good tree48083 := H12GlobalWitnessIndex.good

theorem leafIdentity48083 : H12AffineFastState.composeSystem env48083 rootObs = leafEnv48083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48083 rootObs == leafEnv48083) = true)

theorem terminalChecked48083 : H12PackedTerminal.terminalCheckFast leafEnv48083 active48083 tree48083 = true := by decide +kernel

def env48084 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,17,9,0,0,3,16,2049,20,1,0,1,17,3,8,16,2048,16,17,2049,20,0,5,1,0,513]

theorem envBound48084 : H12AffineFastState.Bounded env48084 := by
  intro p hp
  have h : env48084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48081_48084 : H12AffineEnvironment.transform 9 21 env48081 = env48084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env48081 == env48084) = true)

theorem identity48084 : scanCanonicalize (H12AffineFastState.compose env48084 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound48084 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48085 : List Nat := [2,4,8,16,0,17,9,4,512,21,522,17,9,0,0,3,16,523,20,1,0,1,17,3,8,16,522,16,17,523,20,0,5,1,0,513]

theorem envBound48085 : H12AffineFastState.Bounded env48085 := by
  intro p hp
  have h : env48085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48084_48085 : H12AffineEnvironment.transform 10 522 env48084 = env48085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env48084 == env48085) = true)

def leafEnv48085 : List Nat := [2,4,8,16,0,17,9,4,512,21,522,17,9,0,0,3,16,523,20,1,0,1,17,3,21,8,1,16,522,16,17,523,20,0,5,1,5,2,0,513,1,0,0]

def active48085 : List Nat := [0,1,2,3,8]

def tree48085 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48085 : H12WitnessSearch.Good tree48085 := H12GlobalWitnessIndex.good

theorem leafIdentity48085 : H12AffineFastState.composeSystem env48085 rootObs = leafEnv48085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48085 rootObs == leafEnv48085) = true)

theorem terminalChecked48085 : H12PackedTerminal.terminalCheckFast leafEnv48085 active48085 tree48085 = true := by decide +kernel

def env48086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,4194304,16,98780,8328,65,4340844,5393,17664,179632,1500,4256860,257,21793,46212,74250]

theorem envBound48086 : H12AffineFastState.Bounded env48086 := by
  intro p hp
  have h : env48086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48052_48086 : H12AffineEnvironment.transform 20 4161 env48052 = env48086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48052 == env48086) = true)

theorem identity48086 : scanCanonicalize (H12AffineFastState.compose env48086 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21792) := by decide +kernel

theorem selectedBound48086 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,21792,16,98780,8328,65,158028,5393,17664,179632,1500,41340,257,21793,46212,74250]

theorem envBound48087 : H12AffineFastState.Bounded env48087 := by
  intro p hp
  have h : env48087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48086_48087 : H12AffineEnvironment.transform 21 21792 env48086 = env48087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env48086 == env48087) = true)

theorem identity48087 : scanCanonicalize (H12AffineFastState.compose env48087 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48087 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env48088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32161,1025,32769,4161,21792,16,41431,8328,65,158028,5393,17664,179632,1500,41340,257,21793,46212,513]

theorem envBound48088 : H12AffineFastState.Bounded env48088 := by
  intro p hp
  have h : env48088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48087_48088 : H12AffineEnvironment.transform 15 8203 env48087 = env48088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48087 == env48088) = true)

theorem identity48088 : scanCanonicalize (H12AffineFastState.compose env48088 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound48088 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,32161,1025,32769,4161,21792,16,41431,8328,65,10589,5393,17664,64929,1500,41340,257,21793,46212,513]

theorem envBound48089 : H12AffineFastState.Bounded env48089 := by
  intro p hp
  have h : env48089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48088_48089 : H12AffineEnvironment.transform 16 16401 env48088 = env48089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env48088 == env48089) = true)

theorem identity48089 : scanCanonicalize (H12AffineFastState.compose env48089 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound48089 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env48090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,216,8203,16401,32161,1025,217,4161,21792,16,8463,8328,65,10589,5393,17664,32121,1500,8612,257,21793,13404,513]

theorem envBound48090 : H12AffineFastState.Bounded env48090 := by
  intro p hp
  have h : env48090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48089_48090 : H12AffineEnvironment.transform 14 216 env48089 = env48090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env48089 == env48090) = true)

theorem identity48090 : scanCanonicalize (H12AffineFastState.compose env48090 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48090 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env48091 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,136,8203,16401,32161,1025,137,4113,21792,16,8463,8328,17,10509,5393,17664,32041,1420,8612,257,21793,13324,513]

theorem envBound48091 : H12AffineFastState.Bounded env48091 := by
  intro p hp
  have h : env48091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48090_48091 : H12AffineEnvironment.transform 5 16 env48090 = env48091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48090 == env48091) = true)

theorem identity48091 : scanCanonicalize (H12AffineFastState.compose env48091 (packedSelected [0,1,4,5,6,7,9,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 11413) := by decide +kernel

theorem selectedBound48091 : packedSelected [0,1,4,5,6,7,9,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48092 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,11413,136,8203,11396,4404,1025,137,4113,14773,16,8463,8328,17,10509,5393,10645,4540,1420,8612,257,14772,13324,513]

theorem envBound48092 : H12AffineFastState.Bounded env48092 := by
  intro p hp
  have h : env48092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48091_48092 : H12AffineEnvironment.transform 13 11413 env48091 = env48092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11413 env48091 == env48092) = true)

theorem identity48092 : scanCanonicalize (H12AffineFastState.compose env48092 (packedSelected [1,4,5,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound48092 : packedSelected [1,4,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env48093 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1196,8192,11413,136,8203,11396,1432,1025,137,1213,11545,16,8463,8328,17,10509,445,10645,1296,1420,8612,257,11544,8352,513]

theorem envBound48093 : H12AffineFastState.Bounded env48093 := by
  intro p hp
  have h : env48093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48092_48093 : H12AffineEnvironment.transform 11 1196 env48092 = env48093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env48092 == env48093) = true)

theorem identity48093 : scanCanonicalize (H12AffineFastState.compose env48093 (packedSelected [0,5,6,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound48093 : packedSelected [0,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env48094 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1196,2316,1433,136,2311,1416,1432,1025,137,1213,1045,16,2051,2436,17,1,445,153,1296,1420,2216,257,1044,2476,513]

theorem envBound48094 : H12AffineFastState.Bounded env48094 := by
  intro p hp
  have h : env48094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48093_48094 : H12AffineEnvironment.transform 12 2316 env48093 = env48094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env48093 == env48094) = true)

theorem identity48094 : scanCanonicalize (H12AffineFastState.compose env48094 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound48094 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env48095 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1196,2209,1076,136,2218,1061,1077,1025,137,1213,1045,16,2051,2089,17,1,16,153,1213,1057,2216,172,1044,2049,513]

theorem envBound48095 : H12AffineFastState.Bounded env48095 := by
  intro p hp
  have h : env48095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48094_48095 : H12AffineEnvironment.transform 7 173 env48094 = env48095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env48094 == env48095) = true)

theorem identity48095 : scanCanonicalize (H12AffineFastState.compose env48095 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound48095 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env48096 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1213,1196,1052,1076,136,1047,1061,1077,1025,137,1213,1045,16,1214,1172,17,1,16,153,1213,1057,1045,172,1044,1212,513]

theorem envBound48096 : H12AffineFastState.Bounded env48096 := by
  intro p hp
  have h : env48096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48095_48096 : H12AffineEnvironment.transform 10 1213 env48095 = env48096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env48095 == env48096) = true)

theorem identity48096 : scanCanonicalize (H12AffineFastState.compose env48096 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound48096 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48097 : List Nat := [2,4,8,16,32,16,128,173,512,188,1,16,160,136,136,171,153,137,189,137,1,169,16,2,40,17,1,16,153,1,157,169,172,168,0,513]

theorem envBound48097 : H12AffineFastState.Bounded env48097 := by
  intro p hp
  have h : env48097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48096_48097 : H12AffineEnvironment.transform 9 188 env48096 = env48097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env48096 == env48097) = true)

def env48098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356289,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound48098 : H12AffineFastState.Bounded env48098 := by
  intro p hp
  have h : env48098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47671_48098 : H12AffineEnvironment.transform 26 30393345 env47671 = env48098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env47671 == env48098) = true)

def env48099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound48099 : H12AffineFastState.Bounded env48099 := by
  intro p hp
  have h : env48099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48098_48099 : H12AffineEnvironment.transform 18 1024 env48098 = env48099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env48098 == env48099) = true)

theorem identity48099 : scanCanonicalize (H12AffineFastState.compose env48099 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 485741) := by decide +kernel

theorem selectedBound48099 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,485741,8328,65,12626284,2551264,10507601,8830977,8842621,6687917,256,10923457,10898532,8899242]

theorem envBound48100 : H12AffineFastState.Bounded env48100 := by
  intro p hp
  have h : env48100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48099_48100 : H12AffineEnvironment.transform 23 485741 env48099 = env48100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 485741 env48099 == env48100) = true)

def env48101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2554080,485741,8328,65,6705548,2551264,437681,2111713,2102685,6687917,256,21793,46212,2175562]

theorem envBound48101 : H12AffineFastState.Bounded env48101 := by
  intro p hp
  have h : env48101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48100_48101 : H12AffineEnvironment.transform 22 2554080 env48100 = env48101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2554080 env48100 == env48101) = true)

def env48102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101328,98781,8328,65,6338876,2098512,17665,2111713,2102685,6349853,256,21793,46212,2175562]

theorem envBound48102 : H12AffineFastState.Bounded env48102 := by
  intro p hp
  have h : env48102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48101_48102 : H12AffineEnvironment.transform 17 190640 env48101 = env48102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env48101 == env48102) = true)

def env48103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,16,98781,8328,65,4237692,5392,17665,10401,1501,4256861,256,21793,46212,74250]

theorem envBound48103 : H12AffineFastState.Bounded env48103 := by
  intro p hp
  have h : env48103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48102_48103 : H12AffineEnvironment.transform 20 4160 env48102 = env48103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48102 == env48103) = true)

theorem identity48103 : scanCanonicalize (H12AffineFastState.compose env48103 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48103 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4160,4194304,16,41430,8328,65,4237692,5392,17665,10401,1501,4256861,256,21793,46212,513]

theorem envBound48104 : H12AffineFastState.Bounded env48104 := by
  intro p hp
  have h : env48104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48103_48104 : H12AffineEnvironment.transform 15 8203 env48103 = env48104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48103 == env48104) = true)

theorem identity48104 : scanCanonicalize (H12AffineFastState.compose env48104 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound48104 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4160,32801,16,41430,8328,65,10589,5392,17665,10401,1501,29820,256,21793,46212,513]

theorem envBound48105 : H12AffineFastState.Bounded env48105 := by
  intro p hp
  have h : env48105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48104_48105 : H12AffineEnvironment.transform 21 32801 env48104 = env48105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env48104 == env48105) = true)

theorem identity48105 : scanCanonicalize (H12AffineFastState.compose env48105 (packedSelected [0,3,4,7,10,11,17,18,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound48105 : packedSelected [0,3,4,7,10,11,17,18,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env48106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,35188,1024,32769,4160,32801,16,41430,8328,65,10589,5392,17665,10401,1501,29820,256,21793,46212,513]

theorem envBound48106 : H12AffineFastState.Bounded env48106 := by
  intro p hp
  have h : env48106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48105_48106 : H12AffineEnvironment.transform 16 25028 env48105 = env48106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env48105 == env48106) = true)

theorem identity48106 : scanCanonicalize (H12AffineFastState.compose env48106 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48106 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env48107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,35188,1024,32769,4160,32801,16,41311,8193,65,10589,5392,17665,10280,1364,29820,256,21793,46093,513]

theorem envBound48107 : H12AffineFastState.Bounded env48107 := by
  intro p hp
  have h : env48107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48106_48107 : H12AffineEnvironment.transform 6 9 env48106 = env48107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48106 == env48107) = true)

theorem identity48107 : scanCanonicalize (H12AffineFastState.compose env48107 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound48107 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,24909,32041,1024,29788,4160,29820,16,21762,8193,65,10589,5392,17665,10280,1364,29820,256,21793,16464,513]

theorem envBound48108 : H12AffineFastState.Bounded env48108 := by
  intro p hp
  have h : env48108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48107_48108 : H12AffineEnvironment.transform 14 29789 env48107 = env48108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env48107 == env48108) = true)

theorem identity48108 : scanCanonicalize (H12AffineFastState.compose env48108 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound48108 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8203,5393,2421,1024,0,4160,32,16,8542,8193,65,10589,5392,12637,10280,1364,32,256,8573,13324,513]

theorem envBound48109 : H12AffineFastState.Bounded env48109 := by
  intro p hp
  have h : env48109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48108_48109 : H12AffineEnvironment.transform 13 13404 env48108 = env48109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env48108 == env48109) = true)

theorem identity48109 : scanCanonicalize (H12AffineFastState.compose env48109 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48109 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5393,2421,1024,0,4160,32,16,3,348,65,2048,5392,4096,2421,1364,32,256,32,5457,513]

theorem envBound48110 : H12AffineFastState.Bounded env48110 := by
  intro p hp
  have h : env48110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48109_48110 : H12AffineEnvironment.transform 12 349 env48109 = env48110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48109 == env48110) = true)

theorem identity48110 : scanCanonicalize (H12AffineFastState.compose env48110 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound48110 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,4096,349,5377,1,342,5393,1306,1024,0,4160,32,16,3,348,65,1135,5392,4096,1306,1364,32,256,32,5457,513]

theorem envBound48111 : H12AffineFastState.Bounded env48111 := by
  intro p hp
  have h : env48111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48110_48111 : H12AffineEnvironment.transform 10 1135 env48110 = env48111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env48110 == env48111) = true)

theorem identity48111 : scanCanonicalize (H12AffineFastState.compose env48111 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound48111 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,373,349,1140,1,342,1124,1306,1024,0,309,32,16,3,348,65,1135,1125,373,1306,1364,32,256,32,1060,513]

theorem envBound48112 : H12AffineFastState.Bounded env48112 := by
  intro p hp
  have h : env48112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48111_48112 : H12AffineEnvironment.transform 11 373 env48111 = env48112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env48111 == env48112) = true)

theorem identity48112 : scanCanonicalize (H12AffineFastState.compose env48112 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48112 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env48113 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1135,0,40,1140,1,35,1124,1135,1024,0,64,32,16,3,41,65,1135,1125,0,1135,1057,32,117,32,1060,513]

theorem envBound48113 : H12AffineFastState.Bounded env48113 := by
  intro p hp
  have h : env48113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48112_48113 : H12AffineEnvironment.transform 7 117 env48112 = env48113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48112 == env48113) = true)

theorem identity48113 : scanCanonicalize (H12AffineFastState.compose env48113 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound48113 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48114 : List Nat := [2,4,8,16,32,64,9,117,512,110,1,0,40,26,1,35,10,1,110,0,64,32,16,3,41,65,1,11,0,1,79,32,117,32,74,513]

theorem envBound48114 : H12AffineFastState.Bounded env48114 := by
  intro p hp
  have h : env48114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48113_48114 : H12AffineEnvironment.transform 9 110 env48113 = env48114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env48113 == env48114) = true)

theorem identity48114 : scanCanonicalize (H12AffineFastState.compose env48114 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

end H12CloudChart0