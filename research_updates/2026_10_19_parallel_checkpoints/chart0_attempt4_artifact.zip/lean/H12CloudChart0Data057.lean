import H12CloudChart0Data056

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound14313 : H12AffineFastState.Bounded env14313 := by
  intro p hp
  have h : env14313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14312_14313 : H12AffineEnvironment.transform 11 2064 env14312 = env14313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env14312 == env14313) = true)

theorem identity14313 : scanCanonicalize (H12AffineFastState.compose env14313 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound14313 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14314 : List Nat := [2,4,8,16,32,17,9,5,512,46,11,27,8,17,1,35,32,43,47,0,11,33,49,35,9,17,11,32,26,43,15,0,4,32,17,512]

theorem envBound14314 : H12AffineFastState.Bounded env14314 := by
  intro p hp
  have h : env14314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14313_14314 : H12AffineEnvironment.transform 10 11 env14313 = env14314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env14313 == env14314) = true)

theorem identity14314 : scanCanonicalize (H12AffineFastState.compose env14314 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound14314 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env14315 : List Nat := [2,4,8,10,32,11,9,5,512,46,11,1,8,11,1,35,32,43,47,0,11,33,43,35,9,11,11,32,0,43,15,0,4,32,11,512]

theorem envBound14315 : H12AffineFastState.Bounded env14315 := by
  intro p hp
  have h : env14315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14314_14315 : H12AffineEnvironment.transform 3 10 env14314 = env14315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env14314 == env14315) = true)

theorem identity14315 : scanCanonicalize (H12AffineFastState.compose env14315 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound14315 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env14316 : List Nat := [2,4,8,10,32,11,9,5,2,46,11,1,8,11,1,35,32,43,47,0,11,33,43,35,9,11,11,32,0,43,15,0,4,32,11,2]

theorem envBound14316 : H12AffineFastState.Bounded env14316 := by
  intro p hp
  have h : env14316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14315_14316 : H12AffineEnvironment.transform 8 2 env14315 = env14316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env14315 == env14316) = true)

theorem identity14316 : scanCanonicalize (H12AffineFastState.compose env14316 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound14316 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env14317 : List Nat := [2,4,8,10,13,11,9,5,2,3,11,1,8,11,1,14,13,6,2,0,11,12,6,14,9,11,11,13,0,6,15,0,4,13,11,2]

theorem envBound14317 : H12AffineFastState.Bounded env14317 := by
  intro p hp
  have h : env14317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14316_14317 : H12AffineEnvironment.transform 4 13 env14316 = env14317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env14316 == env14317) = true)

theorem identity14317 : scanCanonicalize (H12AffineFastState.compose env14317 (packedSelected [0,1,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound14317 : packedSelected [0,1,10] rootPS < 2^1333 := by decide +kernel

def env14318 : List Nat := [2,4,4,6,1,7,5,5,2,3,7,1,4,7,1,2,1,6,2,0,7,0,6,2,5,7,7,1,0,6,3,0,4,1,7,2]

theorem envBound14318 : H12AffineFastState.Bounded env14318 := by
  intro p hp
  have h : env14318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14317_14318 : H12AffineEnvironment.transform 2 4 env14317 = env14318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env14317 == env14318) = true)

theorem identity14318 : scanCanonicalize (H12AffineFastState.compose env14318 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound14318 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14319 : List Nat := [0,4,4,4,1,5,5,5,0,1,5,1,4,5,1,0,1,4,0,0,5,0,4,0,5,5,5,1,0,4,1,0,4,1,5,0]

theorem envBound14319 : H12AffineFastState.Bounded env14319 := by
  intro p hp
  have h : env14319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14318_14319 : H12AffineEnvironment.transform 0 0 env14318 = env14319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env14318 == env14319) = true)

def env14320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534865,156117,2114883,8328,64,215367,115150,2241669,303572,2334855,2592082,257,254011,197022,2262864]

theorem envBound14320 : H12AffineFastState.Bounded env14320 := by
  intro p hp
  have h : env14320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14260_14320 : H12AffineEnvironment.transform 21 2534865 env14260 = env14320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534865 env14260 == env14320) = true)

def env14321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156117,21763,8328,64,215367,115150,140485,303572,241863,498962,257,254011,197022,169744]

theorem envBound14321 : H12AffineFastState.Bounded env14321 := by
  intro p hp
  have h : env14321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14320_14321 : H12AffineEnvironment.transform 20 4160 env14320 = env14321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14320 == env14321) = true)

theorem identity14321 : scanCanonicalize (H12AffineFastState.compose env14321 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound14321 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,4160,329867,120015,21763,8328,64,64605,115150,102879,303572,1501,272392,257,21793,46212,74250]

theorem envBound14322 : H12AffineFastState.Bounded env14322 := by
  intro p hp
  have h : env14322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14321_14322 : H12AffineEnvironment.transform 16 111898 env14321 = env14322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env14321 == env14322) = true)

def env14323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10400,1025,32769,4160,73771,120015,21763,8328,64,64605,115150,102879,35188,1501,168,257,21793,46212,74250]

theorem envBound14323 : H12AffineFastState.Bounded env14323 := by
  intro p hp
  have h : env14323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14322_14323 : H12AffineEnvironment.transform 17 10400 env14322 = env14323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env14322 == env14323) = true)

def env14324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4160,73771,119879,21763,8192,64,64605,115014,102743,35188,1365,32,257,21793,46092,74250]

theorem envBound14324 : H12AffineFastState.Bounded env14324 := by
  intro p hp
  have h : env14324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14323_14324 : H12AffineEnvironment.transform 6 8 env14323 = env14324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14323 == env14324) = true)

theorem identity14324 : scanCanonicalize (H12AffineFastState.compose env14324 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound14324 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,13388,10280,1025,32769,4160,41341,21777,21763,8192,64,64605,16400,4097,35188,1365,32,257,21793,46092,41820]

theorem envBound14325 : H12AffineFastState.Bounded env14325 := by
  intro p hp
  have h : env14325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14324_14325 : H12AffineEnvironment.transform 15 33110 env14324 = env14325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env14324 == env14325) = true)

def env14326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10281,1025,32769,4160,73771,119878,21763,8193,64,64605,115015,102742,35188,1364,33,257,21793,46093,74250]

theorem envBound14326 : H12AffineFastState.Bounded env14326 := by
  intro p hp
  have h : env14326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14323_14326 : H12AffineEnvironment.transform 6 9 env14323 = env14326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14323 == env14326) = true)

theorem identity14326 : scanCanonicalize (H12AffineFastState.compose env14326 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14326 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10281,1025,32769,4160,32,62541,21763,8193,64,64605,57676,45405,35188,1364,33,257,21793,46093,513]

theorem envBound14327 : H12AffineFastState.Bounded env14327 := by
  intro p hp
  have h : env14327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14326_14327 : H12AffineEnvironment.transform 15 8203 env14326 = env14327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14326 == env14327) = true)

theorem identity14327 : scanCanonicalize (H12AffineFastState.compose env14327 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14327 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env14328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,263,38161,2341,1025,32769,4160,32,54593,21763,269,64,56657,49216,36945,35188,1364,33,257,21793,38145,513]

theorem envBound14328 : H12AffineFastState.Bounded env14328 := by
  intro p hp
  have h : env14328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14327_14328 : H12AffineEnvironment.transform 12 268 env14327 = env14328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14327 == env14328) = true)

theorem identity14328 : scanCanonicalize (H12AffineFastState.compose env14328 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14328 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14329 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,263,38161,2341,1025,32769,4113,32,54544,21763,269,17,56576,49169,36864,35109,1285,33,257,21793,38145,513]

theorem envBound14329 : H12AffineFastState.Bounded env14329 := by
  intro p hp
  have h : env14329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14328_14329 : H12AffineEnvironment.transform 5 17 env14328 = env14329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14328 == env14329) = true)

theorem identity14329 : scanCanonicalize (H12AffineFastState.compose env14329 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound14329 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14330 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,263,16400,2341,1025,21760,4113,32,17,21763,269,17,2049,5392,17665,23588,1285,33,257,21793,16384,513]

theorem envBound14330 : H12AffineFastState.Bounded env14330 := by
  intro p hp
  have h : env14330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14329_14330 : H12AffineEnvironment.transform 14 21761 env14329 = env14330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env14329 == env14330) = true)

def env14331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10401,1025,32769,4160,73770,120015,21763,8328,64,64605,115150,102879,35189,1501,169,257,21793,46212,74250]

theorem envBound14331 : H12AffineFastState.Bounded env14331 := by
  intro p hp
  have h : env14331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14322_14331 : H12AffineEnvironment.transform 17 10401 env14322 = env14331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env14322 == env14331) = true)

def env14332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10281,1025,32769,4160,73770,119879,21763,8192,64,64605,115014,102743,35189,1365,33,257,21793,46092,74250]

theorem envBound14332 : H12AffineFastState.Bounded env14332 := by
  intro p hp
  have h : env14332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14331_14332 : H12AffineEnvironment.transform 6 8 env14331 = env14332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14331 == env14332) = true)

theorem identity14332 : scanCanonicalize (H12AffineFastState.compose env14332 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14332 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,111898,10281,1025,32769,4160,73770,98630,2,8192,64,43356,103495,102743,35189,1365,33,257,32,46092,74250]

theorem envBound14333 : H12AffineFastState.Bounded env14333 := by
  intro p hp
  have h : env14333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14332_14333 : H12AffineEnvironment.transform 13 5377 env14332 = env14333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14332 == env14333) = true)

theorem identity14333 : scanCanonicalize (H12AffineFastState.compose env14333 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound14333 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env14334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,13389,10281,1025,32769,4160,41341,17,2,8192,64,43356,5392,4096,35189,1365,33,257,32,46092,41821]

theorem envBound14334 : H12AffineFastState.Bounded env14334 := by
  intro p hp
  have h : env14334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14333_14334 : H12AffineEnvironment.transform 15 33111 env14333 = env14334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env14333 == env14334) = true)

theorem identity14334 : scanCanonicalize (H12AffineFastState.compose env14334 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14334 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env14335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,33111,5393,2421,1025,32769,4160,32801,17,2,348,64,34816,5392,4096,35189,1365,33,257,32,38224,33281]

theorem envBound14335 : H12AffineFastState.Bounded env14335 := by
  intro p hp
  have h : env14335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14334_14335 : H12AffineEnvironment.transform 12 348 env14334 = env14335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14334 == env14335) = true)

theorem identity14335 : scanCanonicalize (H12AffineFastState.compose env14335 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound14335 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env14336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,373,34,5393,2421,1025,372,4160,340,17,2,348,64,2421,5392,4096,2048,1365,33,257,32,5157,884]

theorem envBound14336 : H12AffineFastState.Bounded env14336 := by
  intro p hp
  have h : env14336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14335_14336 : H12AffineEnvironment.transform 14 373 env14335 = env14336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env14335 == env14336) = true)

theorem identity14336 : scanCanonicalize (H12AffineFastState.compose env14336 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14336 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env14337 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,1,34,5221,2049,1025,0,4160,32,17,2,40,64,2049,5220,4096,2048,1057,33,117,32,5157,512]

theorem envBound14337 : H12AffineFastState.Bounded env14337 := by
  intro p hp
  have h : env14337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14336_14337 : H12AffineEnvironment.transform 7 116 env14336 = env14337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14336 == env14337) = true)

theorem identity14337 : scanCanonicalize (H12AffineFastState.compose env14337 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound14337 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14338 : List Nat := [2,4,8,16,32,64,8,116,512,1024,555,4096,40,5237,1,34,5221,554,1025,0,4160,32,17,2,40,64,554,5220,4096,555,1057,33,117,32,5157,512]

theorem envBound14338 : H12AffineFastState.Bounded env14338 := by
  intro p hp
  have h : env14338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14337_14338 : H12AffineEnvironment.transform 10 555 env14337 = env14338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env14337 == env14338) = true)

theorem identity14338 : scanCanonicalize (H12AffineFastState.compose env14338 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound14338 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14339 : List Nat := [2,4,8,16,32,49,8,5,512,1024,555,4096,40,5124,1,34,5140,554,1025,0,4145,32,17,2,40,49,554,5141,4096,555,1057,33,4,32,5157,512]

theorem envBound14339 : H12AffineFastState.Bounded env14339 := by
  intro p hp
  have h : env14339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14338_14339 : H12AffineEnvironment.transform 5 49 env14338 = env14339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env14338 == env14339) = true)

theorem identity14339 : scanCanonicalize (H12AffineFastState.compose env14339 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14339 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env14340 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,4096,8,5124,1,2,5140,522,1025,0,4113,0,17,2,8,17,522,5141,4096,523,1025,1,4,0,5125,512]

theorem envBound14340 : H12AffineFastState.Bounded env14340 := by
  intro p hp
  have h : env14340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14339_14340 : H12AffineEnvironment.transform 4 0 env14339 = env14340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14339 == env14340) = true)

def env14341 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,16,8,1044,1,2,1028,522,1025,0,1,0,17,2,8,17,522,1029,16,523,1025,1,4,0,1045,512]

theorem envBound14341 : H12AffineFastState.Bounded env14341 := by
  intro p hp
  have h : env14341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14340_14341 : H12AffineEnvironment.transform 11 16 env14340 = env14341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env14340 == env14341) = true)

theorem identity14341 : scanCanonicalize (H12AffineFastState.compose env14341 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound14341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14342 : List Nat := [2,4,8,16,0,17,8,5,512,522,523,16,8,542,1,2,526,522,523,0,1,0,17,2,8,17,522,527,16,523,523,1,4,0,543,512]

theorem envBound14342 : H12AffineFastState.Bounded env14342 := by
  intro p hp
  have h : env14342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14341_14342 : H12AffineEnvironment.transform 9 522 env14341 = env14342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env14341 == env14342) = true)

def env14343 : List Nat := [2,4,8,4,0,5,8,5,512,522,523,4,8,522,1,2,526,522,523,0,1,0,5,2,8,5,522,527,4,523,523,1,4,0,523,512]

theorem envBound14343 : H12AffineFastState.Bounded env14343 := by
  intro p hp
  have h : env14343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14342_14343 : H12AffineEnvironment.transform 3 4 env14342 = env14343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14342 == env14343) = true)

theorem identity14343 : scanCanonicalize (H12AffineFastState.compose env14343 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14344 : List Nat := [1,4,8,4,0,5,8,5,512,521,520,4,8,521,1,1,525,521,520,0,1,0,5,1,8,5,521,524,4,520,520,1,4,0,520,512]

theorem envBound14344 : H12AffineFastState.Bounded env14344 := by
  intro p hp
  have h : env14344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14343_14344 : H12AffineEnvironment.transform 0 1 env14343 = env14344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14343 == env14344) = true)

def leafEnv14344 : List Nat := [1,4,8,4,0,5,8,5,512,521,520,4,8,521,1,1,525,521,520,0,1,0,5,1,520,8,1,5,521,524,4,520,520,1,4,0,4,1,520,512,1,0,0]

def active14344 : List Nat := [1,2,8]

def tree14344 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14344 : H12WitnessSearch.Good tree14344 := H12GlobalWitnessIndex.good

theorem leafIdentity14344 : H12AffineFastState.composeSystem env14344 rootObs = leafEnv14344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14344 rootObs == leafEnv14344) = true)

theorem terminalChecked14344 : H12PackedTerminal.terminalCheckFast leafEnv14344 active14344 tree14344 = true := by decide +kernel

def env14345 : List Nat := [2,4,8,5,0,4,8,5,512,522,523,5,8,523,1,2,526,522,523,0,1,0,4,2,8,4,522,527,5,523,523,1,4,0,522,512]

theorem envBound14345 : H12AffineFastState.Bounded env14345 := by
  intro p hp
  have h : env14345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14342_14345 : H12AffineEnvironment.transform 3 5 env14342 = env14345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env14342 == env14345) = true)

theorem identity14345 : scanCanonicalize (H12AffineFastState.compose env14345 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound14345 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14346 : List Nat := [2,4,8,5,0,4,8,5,9,3,2,5,8,2,1,2,7,3,2,0,1,0,4,2,8,4,3,6,5,2,2,1,4,0,3,9]

theorem envBound14346 : H12AffineFastState.Bounded env14346 := by
  intro p hp
  have h : env14346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14345_14346 : H12AffineEnvironment.transform 8 9 env14345 = env14346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env14345 == env14346) = true)

def leafEnv14346 : List Nat := [2,4,8,5,0,4,8,5,9,3,2,5,8,2,1,2,7,3,2,0,1,0,4,2,2,8,1,4,3,6,5,2,2,1,4,0,4,2,3,9,1,0,0]

def active14346 : List Nat := [0,1,2]

def tree14346 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14346 : H12WitnessSearch.Good tree14346 := H12GlobalWitnessIndex.good

theorem leafIdentity14346 : H12AffineFastState.composeSystem env14346 rootObs = leafEnv14346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14346 rootObs == leafEnv14346) = true)

theorem terminalChecked14346 : H12PackedTerminal.terminalCheckFast leafEnv14346 active14346 tree14346 = true := by decide +kernel

def env14347 : List Nat := [2,4,8,16,0,17,8,5,512,1024,523,17,8,1045,1,2,1029,522,1025,0,0,0,17,2,8,17,522,1028,17,523,1025,1,4,0,1044,512]

theorem envBound14347 : H12AffineFastState.Bounded env14347 := by
  intro p hp
  have h : env14347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14340_14347 : H12AffineEnvironment.transform 11 17 env14340 = env14347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14340 == env14347) = true)

theorem identity14347 : scanCanonicalize (H12AffineFastState.compose env14347 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound14347 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14348 : List Nat := [2,4,8,16,0,17,8,5,31,1024,20,17,8,1045,1,2,1029,21,1025,0,0,0,17,2,8,17,21,1028,17,20,1025,1,4,0,1044,31]

theorem envBound14348 : H12AffineFastState.Bounded env14348 := by
  intro p hp
  have h : env14348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14347_14348 : H12AffineEnvironment.transform 8 31 env14347 = env14348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env14347 == env14348) = true)

def env14349 : List Nat := [2,4,8,16,0,17,8,5,31,0,20,17,8,21,1,2,5,21,1,0,0,0,17,2,8,17,21,4,17,20,1,1,4,0,20,31]

theorem envBound14349 : H12AffineFastState.Bounded env14349 := by
  intro p hp
  have h : env14349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14348_14349 : H12AffineEnvironment.transform 9 0 env14348 = env14349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env14348 == env14349) = true)

theorem identity14349 : scanCanonicalize (H12AffineFastState.compose env14349 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14350 : List Nat := [1,4,8,16,0,17,8,5,28,0,20,17,8,21,1,1,5,21,1,0,0,0,17,1,8,17,21,4,17,20,1,1,4,0,20,28]

theorem envBound14350 : H12AffineFastState.Bounded env14350 := by
  intro p hp
  have h : env14350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14349_14350 : H12AffineEnvironment.transform 0 1 env14349 = env14350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14349 == env14350) = true)

def leafEnv14350 : List Nat := [1,4,8,16,0,17,8,5,28,0,20,17,8,21,1,1,5,21,1,0,0,0,17,1,1,8,1,17,21,4,17,20,1,1,4,0,4,1,20,28,1,1,0]

def active14350 : List Nat := [1,2,3]

def tree14350 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14350 : H12WitnessSearch.Good tree14350 := H12GlobalWitnessIndex.good

theorem leafIdentity14350 : H12AffineFastState.composeSystem env14350 rootObs = leafEnv14350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14350 rootObs == leafEnv14350) = true)

theorem terminalChecked14350 : H12PackedTerminal.terminalCheckFast leafEnv14350 active14350 tree14350 = true := by decide +kernel

def env14351 : List Nat := [2,4,8,16,0,17,8,5,31,1,20,17,8,20,1,2,4,21,0,0,0,0,17,2,8,17,21,5,17,20,0,1,4,0,21,31]

theorem envBound14351 : H12AffineFastState.Bounded env14351 := by
  intro p hp
  have h : env14351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14348_14351 : H12AffineEnvironment.transform 9 1 env14348 = env14351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env14348 == env14351) = true)

theorem identity14351 : scanCanonicalize (H12AffineFastState.compose env14351 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound14351 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14352 : List Nat := [2,4,8,7,0,6,8,5,8,1,3,6,8,3,1,2,4,2,0,0,0,0,6,2,8,6,2,5,6,3,0,1,4,0,2,8]

theorem envBound14352 : H12AffineFastState.Bounded env14352 := by
  intro p hp
  have h : env14352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14351_14352 : H12AffineEnvironment.transform 3 7 env14351 = env14352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env14351 == env14352) = true)

def leafEnv14352 : List Nat := [2,4,8,7,0,6,8,5,8,1,3,6,8,3,1,2,4,2,0,0,0,0,6,2,0,8,1,6,2,5,6,3,0,1,4,0,4,2,2,8,1,1,0]

def active14352 : List Nat := [0,1,2]

def tree14352 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14352 : H12WitnessSearch.Good tree14352 := H12GlobalWitnessIndex.good

theorem leafIdentity14352 : H12AffineFastState.composeSystem env14352 rootObs = leafEnv14352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14352 rootObs == leafEnv14352) = true)

theorem terminalChecked14352 : H12PackedTerminal.terminalCheckFast leafEnv14352 active14352 tree14352 = true := by decide +kernel

def env14353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4160,73770,119878,21763,8193,64,64605,115015,102742,35189,1364,32,257,21793,46093,74250]

theorem envBound14353 : H12AffineFastState.Bounded env14353 := by
  intro p hp
  have h : env14353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14331_14353 : H12AffineEnvironment.transform 6 9 env14331 = env14353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14331 == env14353) = true)

theorem identity14353 : scanCanonicalize (H12AffineFastState.compose env14353 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound14353 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,82247,10280,1025,29788,4160,73770,73755,21763,8193,64,2048,79130,91403,32040,1364,32,257,21793,16464,74250]

theorem envBound14354 : H12AffineFastState.Bounded env14354 := by
  intro p hp
  have h : env14354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14353_14354 : H12AffineEnvironment.transform 14 29789 env14353 = env14354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env14353 == env14354) = true)

theorem identity14354 : scanCanonicalize (H12AffineFastState.compose env14354 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound14354 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env14355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,343,16400,10280,1025,29788,4160,8573,8524,21763,8193,64,2048,13389,25692,32040,1364,32,257,21793,16464,9053]

theorem envBound14355 : H12AffineFastState.Bounded env14355 := by
  intro p hp
  have h : env14355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14354_14355 : H12AffineEnvironment.transform 15 343 env14354 = env14355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env14354 == env14355) = true)

theorem identity14355 : scanCanonicalize (H12AffineFastState.compose env14355 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound14355 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12620,1297,343,12636,10280,1025,1296,4160,8573,8524,9295,8193,64,2048,13389,5392,3172,1364,32,257,9325,12572,9053]

theorem envBound14356 : H12AffineFastState.Bounded env14356 := by
  intro p hp
  have h : env14356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14355_14356 : H12AffineEnvironment.transform 13 12620 env14355 = env14356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env14355 == env14356) = true)

theorem identity14356 : scanCanonicalize (H12AffineFastState.compose env14356 (packedSelected [0,2,6,7,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound14356 : packedSelected [0,2,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env14357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7465,3173,1297,343,3189,5377,1025,1296,4160,7252,7269,6502,7464,64,2048,2404,5392,3172,1364,32,257,6468,3125,7796]

theorem envBound14357 : H12AffineFastState.Bounded env14357 := by
  intro p hp
  have h : env14357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14356_14357 : H12AffineEnvironment.transform 12 7465 env14356 = env14357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env14356 == env14357) = true)

theorem identity14357 : scanCanonicalize (H12AffineFastState.compose env14357 (packedSelected [2,4,5,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound14357 : packedSelected [2,4,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env14358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,523,4096,5922,1646,1297,343,1662,5377,1025,1296,4160,5727,5742,4973,5923,64,523,879,5392,1647,1364,32,257,4943,1598,5247]

theorem envBound14358 : H12AffineFastState.Bounded env14358 := by
  intro p hp
  have h : env14358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14357_14358 : H12AffineEnvironment.transform 10 523 env14357 = env14358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env14357 == env14358) = true)

theorem identity14358 : scanCanonicalize (H12AffineFastState.compose env14358 (packedSelected [1,3,4,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14358 : packedSelected [1,3,4,9,14] rootPS < 2^1333 := by decide +kernel

def env14359 : List Nat := [2,4,8,16,32,64,9,256,512,53,523,4096,4887,603,292,343,587,4404,52,293,4160,4714,4699,4973,4886,64,523,879,4389,602,353,32,257,4943,523,4170]

theorem envBound14359 : H12AffineFastState.Bounded env14359 := by
  intro p hp
  have h : env14359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14358_14359 : H12AffineEnvironment.transform 9 53 env14358 = env14359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14358 == env14359) = true)

theorem identity14359 : scanCanonicalize (H12AffineFastState.compose env14359 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14359 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env14360 : List Nat := [2,4,8,16,32,64,9,36,512,53,523,4096,4659,603,0,115,587,4112,52,1,4160,4714,4699,4681,4658,64,523,587,4097,602,69,32,37,4715,523,4170]

theorem envBound14360 : H12AffineFastState.Bounded env14360 := by
  intro p hp
  have h : env14360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14359_14360 : H12AffineEnvironment.transform 7 36 env14359 = env14360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14359 == env14360) = true)

theorem identity14360 : scanCanonicalize (H12AffineFastState.compose env14360 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound14360 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14361 : List Nat := [2,4,8,16,32,64,9,36,512,53,523,538,41,603,0,115,587,522,52,1,602,112,65,83,40,64,523,587,539,602,69,32,37,113,523,592]

theorem envBound14361 : H12AffineFastState.Bounded env14361 := by
  intro p hp
  have h : env14361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14360_14361 : H12AffineEnvironment.transform 11 538 env14360 = env14361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env14360 == env14361) = true)

theorem identity14361 : scanCanonicalize (H12AffineFastState.compose env14361 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14361 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14362 : List Nat := [2,4,8,16,1,64,9,5,512,20,523,538,8,603,0,82,587,522,21,1,602,81,65,83,9,64,523,587,539,602,69,1,4,80,523,592]

theorem envBound14362 : H12AffineFastState.Bounded env14362 := by
  intro p hp
  have h : env14362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14361_14362 : H12AffineEnvironment.transform 4 1 env14361 = env14362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14361 == env14362) = true)

theorem identity14362 : scanCanonicalize (H12AffineFastState.compose env14362 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14362 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14363 : List Nat := [2,4,8,16,1,17,9,5,512,20,523,538,8,522,0,3,538,522,21,1,523,0,16,2,9,17,523,538,539,523,20,1,4,1,523,513]

theorem envBound14363 : H12AffineFastState.Bounded env14363 := by
  intro p hp
  have h : env14363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14362_14363 : H12AffineEnvironment.transform 5 17 env14362 = env14363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14362 == env14363) = true)

theorem identity14363 : scanCanonicalize (H12AffineFastState.compose env14363 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound14363 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14364 : List Nat := [2,4,8,4,1,5,9,5,512,0,523,526,8,522,0,3,526,522,1,1,523,0,4,2,9,5,523,526,527,523,0,1,4,1,523,513]

theorem envBound14364 : H12AffineFastState.Bounded env14364 := by
  intro p hp
  have h : env14364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14363_14364 : H12AffineEnvironment.transform 3 4 env14363 = env14364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14363 == env14364) = true)

theorem identity14364 : scanCanonicalize (H12AffineFastState.compose env14364 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound14364 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14365 : List Nat := [0,4,8,4,1,5,9,5,512,0,521,524,8,520,0,1,524,520,1,1,521,0,4,0,9,5,521,524,525,521,0,1,4,1,521,513]

theorem envBound14365 : H12AffineFastState.Bounded env14365 := by
  intro p hp
  have h : env14365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14364_14365 : H12AffineEnvironment.transform 0 0 env14364 = env14365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env14364 == env14365) = true)

theorem identity14365 : scanCanonicalize (H12AffineFastState.compose env14365 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound14365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14366 : List Nat := [0,4,8,4,1,5,9,5,8,0,1,4,8,0,0,1,4,0,1,1,1,0,4,0,9,5,1,4,5,1,0,1,4,1,1,9]

theorem envBound14366 : H12AffineFastState.Bounded env14366 := by
  intro p hp
  have h : env14366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14365_14366 : H12AffineEnvironment.transform 8 8 env14365 = env14366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env14365 == env14366) = true)

def env14367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156117,21762,8328,64,215367,115150,140484,303572,241862,498963,257,254011,197022,169745]

theorem envBound14367 : H12AffineFastState.Bounded env14367 := by
  intro p hp
  have h : env14367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14320_14367 : H12AffineEnvironment.transform 20 4161 env14320 = env14367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14320 == env14367) = true)

theorem identity14367 : scanCanonicalize (H12AffineFastState.compose env14367 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14367 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,441744,156117,21762,8328,64,158028,57797,140484,303572,168141,441624,257,180272,139669,169745]

theorem envBound14368 : H12AffineFastState.Bounded env14368 := by
  intro p hp
  have h : env14368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14367_14368 : H12AffineEnvironment.transform 15 8203 env14367 = env14368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14367 == env14368) = true)

theorem identity14368 : scanCanonicalize (H12AffineFastState.compose env14368 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound14368 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env14369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,4161,272512,62661,21762,8328,64,64604,57797,45524,303572,1501,272392,257,21792,46213,513]

theorem envBound14369 : H12AffineFastState.Bounded env14369 := by
  intro p hp
  have h : env14369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14368_14369 : H12AffineEnvironment.transform 16 38160 env14368 = env14369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env14368 == env14369) = true)

theorem identity14369 : scanCanonicalize (H12AffineFastState.compose env14369 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound14369 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env14370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,38160,262144,1025,32769,4161,264532,54545,21762,348,64,56712,49169,36864,294912,1501,264668,257,21792,38225,513]

theorem envBound14370 : H12AffineFastState.Bounded env14370 := by
  intro p hp
  have h : env14370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14369_14370 : H12AffineEnvironment.transform 12 468 env14369 = env14370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env14369 == env14370) = true)

theorem identity14370 : scanCanonicalize (H12AffineFastState.compose env14370 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound14370 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env14371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,38160,2557,1025,32769,4161,169,54545,21762,348,64,56712,49169,36864,35325,1501,33,257,21792,38225,513]

theorem envBound14371 : H12AffineFastState.Bounded env14371 := by
  intro p hp
  have h : env14371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14370_14371 : H12AffineEnvironment.transform 17 2557 env14370 = env14371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env14370 == env14371) = true)

theorem identity14371 : scanCanonicalize (H12AffineFastState.compose env14371 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound14371 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,479,16400,2557,1025,21761,4161,169,17,21762,348,64,2184,5393,17664,23805,1501,33,257,21792,16465,513]

theorem envBound14372 : H12AffineFastState.Bounded env14372 := by
  intro p hp
  have h : env14372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14371_14372 : H12AffineEnvironment.transform 14 21760 env14371 = env14372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env14371 == env14372) = true)

theorem identity14372 : scanCanonicalize (H12AffineFastState.compose env14372 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14372 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14373 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,343,16400,2421,1025,21761,4161,33,17,21762,348,64,2048,5393,17664,23669,1365,33,257,21792,16465,513]

theorem envBound14373 : H12AffineFastState.Bounded env14373 := by
  intro p hp
  have h : env14373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14372_14373 : H12AffineEnvironment.transform 6 8 env14372 = env14373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14372 == env14373) = true)

theorem identity14373 : scanCanonicalize (H12AffineFastState.compose env14373 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7285) := by decide +kernel

theorem selectedBound14373 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14374 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,7285,2421,343,7269,2421,1025,2420,4161,33,17,2423,348,64,2048,5393,6517,0,1365,33,257,2389,7204,513]

theorem envBound14374 : H12AffineFastState.Bounded env14374 := by
  intro p hp
  have h : env14374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14373_14374 : H12AffineEnvironment.transform 13 7285 env14373 = env14374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7285 env14373 == env14374) = true)

theorem identity14374 : scanCanonicalize (H12AffineFastState.compose env14374 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound14374 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env14375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3103,348,106,2421,343,122,2421,1025,2420,3166,33,17,2423,348,64,2048,2318,1386,0,1365,33,257,2389,59,513]

theorem envBound14375 : H12AffineFastState.Bounded env14375 := by
  intro p hp
  have h : env14375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14374_14375 : H12AffineEnvironment.transform 11 3103 env14374 = env14375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env14374 == env14375) = true)

theorem identity14375 : scanCanonicalize (H12AffineFastState.compose env14375 (packedSelected [0,2,3,7,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound14375 : packedSelected [0,2,3,7,8,14] rootPS < 2^1333 := by decide +kernel

def env14376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,123,348,106,1297,343,122,1297,1025,1296,58,33,17,1299,348,64,1124,1386,1386,0,1365,33,257,1329,59,513]

theorem envBound14376 : H12AffineFastState.Bounded env14376 := by
  intro p hp
  have h : env14376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14375_14376 : H12AffineEnvironment.transform 10 1124 env14375 = env14376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env14375 == env14376) = true)

theorem identity14376 : scanCanonicalize (H12AffineFastState.compose env14376 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 378) := by decide +kernel

theorem selectedBound14376 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14377 : List Nat := [2,4,8,16,32,64,8,256,512,378,286,123,348,106,107,343,122,107,379,106,58,33,17,105,348,64,286,16,16,0,47,33,257,75,59,513]

theorem envBound14377 : H12AffineFastState.Bounded env14377 := by
  intro p hp
  have h : env14377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14376_14377 : H12AffineEnvironment.transform 9 378 env14376 = env14377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 378 env14376 == env14377) = true)

theorem identity14377 : scanCanonicalize (H12AffineFastState.compose env14377 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound14377 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14378 : List Nat := [2,4,8,16,32,64,8,111,512,21,113,123,51,106,107,56,122,107,20,106,58,33,17,105,51,64,113,16,16,0,47,33,110,75,59,513]

theorem envBound14378 : H12AffineFastState.Bounded env14378 := by
  intro p hp
  have h : env14378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14377_14378 : H12AffineEnvironment.transform 7 111 env14377 = env14378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env14377 == env14378) = true)

theorem identity14378 : scanCanonicalize (H12AffineFastState.compose env14378 (packedSelected [1,2,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14378 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env14379 : List Nat := [2,4,3,16,32,64,3,100,512,21,113,112,51,97,96,51,113,96,20,97,49,33,17,98,51,64,113,16,16,0,36,33,101,64,48,513]

theorem envBound14379 : H12AffineFastState.Bounded env14379 := by
  intro p hp
  have h : env14379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14378_14379 : H12AffineEnvironment.transform 2 3 env14378 = env14379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14378 == env14379) = true)

theorem identity14379 : scanCanonicalize (H12AffineFastState.compose env14379 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound14379 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14380 : List Nat := [2,4,3,16,32,64,3,100,35,21,113,112,51,97,96,51,113,96,20,97,49,33,17,98,51,64,113,16,16,0,36,33,101,64,48,34]

theorem envBound14380 : H12AffineFastState.Bounded env14380 := by
  intro p hp
  have h : env14380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14379_14380 : H12AffineEnvironment.transform 8 35 env14379 = env14380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env14379 == env14380) = true)

theorem identity14380 : scanCanonicalize (H12AffineFastState.compose env14380 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14380 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env14381 : List Nat := [2,4,3,16,1,64,3,69,2,21,80,81,18,64,65,18,80,65,20,64,16,0,17,67,18,64,80,16,16,0,5,0,68,64,17,3]

theorem envBound14381 : H12AffineFastState.Bounded env14381 := by
  intro p hp
  have h : env14381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14380_14381 : H12AffineEnvironment.transform 4 1 env14380 = env14381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14380 == env14381) = true)

theorem identity14381 : scanCanonicalize (H12AffineFastState.compose env14381 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14382 : List Nat := [2,4,3,0,1,64,3,69,2,5,64,65,2,64,65,2,64,65,4,64,0,0,1,67,2,64,64,0,0,0,5,0,68,64,1,3]

theorem envBound14382 : H12AffineFastState.Bounded env14382 := by
  intro p hp
  have h : env14382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14381_14382 : H12AffineEnvironment.transform 3 0 env14381 = env14382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14381 == env14382) = true)

theorem identity14382 : scanCanonicalize (H12AffineFastState.compose env14382 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound14382 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14383 : List Nat := [2,4,3,0,1,7,3,2,2,5,7,6,2,7,6,2,7,6,4,7,0,0,1,4,2,7,7,0,0,0,5,0,3,7,1,3]

theorem envBound14383 : H12AffineFastState.Bounded env14383 := by
  intro p hp
  have h : env14383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14382_14383 : H12AffineEnvironment.transform 5 7 env14382 = env14383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env14382 == env14383) = true)

def env14384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254785,25265168,145662401,525568,140903597,27337992,25733063]

theorem envBound14384 : H12AffineFastState.Bounded env14384 := by
  intro p hp
  have h : env14384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13644_14384 : H12AffineEnvironment.transform 25 65 env13644 = env14384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env13644 == env14384) = true)

def env14385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356289,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound14385 : H12AffineFastState.Bounded env14385 := by
  intro p hp
  have h : env14385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14384_14385 : H12AffineEnvironment.transform 26 30393344 env14384 = env14385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env14384 == env14385) = true)

def env14386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound14386 : H12AffineFastState.Bounded env14386 := by
  intro p hp
  have h : env14386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14385_14386 : H12AffineEnvironment.transform 18 1024 env14385 = env14386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14385 == env14386) = true)

theorem identity14386 : scanCanonicalize (H12AffineFastState.compose env14386 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 485879) := by decide +kernel

theorem selectedBound14386 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,485879,16777216,8328,65,21015031,18973836,2571430,109046,17231335,23160257,256,19311962,19287295,17287728]

theorem envBound14387 : H12AffineFastState.Bounded env14387 := by
  intro p hp
  have h : env14387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14386_14387 : H12AffineEnvironment.transform 22 485879 env14386 = env14387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 485879 env14386 == env14387) = true)

def env14388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156012,485879,16777216,8328,65,16959643,18973836,2571430,109046,17231335,19072173,256,19311962,19287295,17287728]

theorem envBound14388 : H12AffineFastState.Bounded env14388 := by
  intro p hp
  have h : env14388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14387_14388 : H12AffineEnvironment.transform 21 156012 env14387 = env14388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env14387 == env14388) = true)

def env14389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485879,16777216,8328,65,16959643,17246708,102878,109046,17231335,17148373,256,16777250,16834951,17287728]

theorem envBound14389 : H12AffineFastState.Bounded env14389 := by
  intro p hp
  have h : env14389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14388_14389 : H12AffineEnvironment.transform 20 437624 env14388 = env14389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env14388 == env14389) = true)

theorem identity14389 : scanCanonicalize (H12AffineFastState.compose env14389 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound14389 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env14390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,115871,156012,16,16777216,8328,65,16959643,16793619,102878,109046,16876544,16957490,256,16777250,16834951,16819159]

theorem envBound14390 : H12AffineFastState.Bounded env14390 := by
  intro p hp
  have h : env14390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14389_14390 : H12AffineEnvironment.transform 17 223719 env14389 = env14390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env14389 == env14390) = true)

def env14391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,115871,156012,16,95496,8328,65,245139,79131,102878,109046,61704,243002,256,95530,103567,120543]

theorem envBound14391 : H12AffineFastState.Bounded env14391 := by
  intro p hp
  have h : env14391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14390_14391 : H12AffineEnvironment.transform 23 95496 env14390 = env14391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env14390 == env14391) = true)

def env14392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115735,156012,16,95496,8192,65,245019,79131,102742,108926,61704,243002,256,95530,103431,120407]

theorem envBound14392 : H12AffineFastState.Bounded env14392 := by
  intro p hp
  have h : env14392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14391_14392 : H12AffineEnvironment.transform 6 8 env14391 = env14392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14391 == env14392) = true)

theorem identity14392 : scanCanonicalize (H12AffineFastState.compose env14392 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound14392 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,89379,1024,32769,115735,21792,16,95496,8192,65,100695,79131,102742,108926,61704,98678,256,95530,103431,120407]

theorem envBound14393 : H12AffineFastState.Bounded env14393 := by
  intro p hp
  have h : env14393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14392_14393 : H12AffineEnvironment.transform 16 13388 env14392 = env14393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env14392 == env14393) = true)

theorem identity14393 : scanCanonicalize (H12AffineFastState.compose env14393 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound14393 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env14394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21591,13388,2420,1024,32769,36928,21792,16,8543,8192,65,56576,24908,50433,64809,61704,54561,256,8573,49232,33280]

theorem envBound14394 : H12AffineFastState.Bounded env14394 := by
  intro p hp
  have h : env14394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14393_14394 : H12AffineEnvironment.transform 15 21591 env14393 = env14394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env14393 == env14394) = true)

def env14395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115734,156012,16,95496,8193,65,245018,79131,102743,108927,61704,243002,256,95530,103430,120406]

theorem envBound14395 : H12AffineFastState.Bounded env14395 := by
  intro p hp
  have h : env14395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14391_14395 : H12AffineEnvironment.transform 6 9 env14391 = env14395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14391 == env14395) = true)

theorem identity14395 : scanCanonicalize (H12AffineFastState.compose env14395 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound14395 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,130174,1024,32769,115734,62588,16,95496,8193,65,75786,79131,102743,108927,61704,73770,256,95530,103430,120406]

theorem envBound14396 : H12AffineFastState.Bounded env14396 := by
  intro p hp
  have h : env14396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14395_14396 : H12AffineEnvironment.transform 16 38160 env14395 = env14396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env14395 == env14396) = true)

theorem identity14396 : scanCanonicalize (H12AffineFastState.compose env14396 (packedSelected [1,3,8,9,12,16,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound14396 : packedSelected [1,3,8,9,12,16,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env14397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,263,38160,64889,1024,32769,50449,62588,16,29711,8193,65,10509,13340,36944,43128,61704,8493,256,29741,38145,55121]

theorem envBound14397 : H12AffineFastState.Bounded env14397 := by
  intro p hp
  have h : env14397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14396_14397 : H12AffineEnvironment.transform 15 263 env14396 = env14397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env14396 == env14397) = true)

theorem identity14397 : scanCanonicalize (H12AffineFastState.compose env14397 (packedSelected [0,1,2,6,7,8,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound14397 : packedSelected [0,1,2,6,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env14398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,263,38160,35109,1024,32769,45389,32800,16,83,8193,65,10509,13340,36944,43128,34132,8493,256,113,38145,41741]

theorem envBound14398 : H12AffineFastState.Bounded env14398 := by
  intro p hp
  have h : env14398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14397_14398 : H12AffineEnvironment.transform 13 13404 env14397 = env14398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env14397 == env14398) = true)

theorem identity14398 : scanCanonicalize (H12AffineFastState.compose env14398 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound14398 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env14399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,80,263,5440,2421,1024,81,12573,112,16,83,8193,65,10509,13340,4096,10280,1284,8493,256,113,5457,9053]

theorem envBound14399 : H12AffineFastState.Bounded env14399 := by
  intro p hp
  have h : env14399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14398_14399 : H12AffineEnvironment.transform 14 80 env14398 = env14399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env14398 == env14399) = true)

theorem identity14399 : scanCanonicalize (H12AffineFastState.compose env14399 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound14399 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env14400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5157,80,263,5440,2421,1024,81,4452,112,16,83,120,65,2420,5221,4096,2129,1284,340,256,113,5457,804]

theorem envBound14400 : H12AffineFastState.Bounded env14400 := by
  intro p hp
  have h : env14400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14399_14400 : H12AffineEnvironment.transform 12 121 env14399 = env14400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env14399 == env14400) = true)

theorem identity14400 : scanCanonicalize (H12AffineFastState.compose env14400 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14400 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env14401 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5157,80,115,5172,2049,1024,81,4112,112,16,83,120,65,2048,5221,4096,2129,1136,32,116,113,5157,592]

theorem envBound14401 : H12AffineFastState.Bounded env14401 := by
  intro p hp
  have h : env14401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14400_14401 : H12AffineEnvironment.transform 7 116 env14400 = env14401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14400 == env14401) = true)

theorem identity14401 : scanCanonicalize (H12AffineFastState.compose env14401 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound14401 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env14402 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3109,121,2048,80,115,2065,2049,1024,81,3125,112,16,83,120,65,2048,2112,3109,2129,1136,32,116,113,2048,592]

theorem envBound14402 : H12AffineFastState.Bounded env14402 := by
  intro p hp
  have h : env14402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14401_14402 : H12AffineEnvironment.transform 11 3109 env14401 = env14402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env14401 == env14402) = true)

theorem identity14402 : scanCanonicalize (H12AffineFastState.compose env14402 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound14402 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env14403 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,2113,121,2048,80,115,2065,2049,100,81,2129,112,16,83,120,65,2048,2112,2113,2129,20,32,116,113,2048,592]

theorem envBound14403 : H12AffineFastState.Bounded env14403 := by
  intro p hp
  have h : env14403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14402_14403 : H12AffineEnvironment.transform 9 100 env14402 = env14403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env14402 == env14403) = true)

theorem identity14403 : scanCanonicalize (H12AffineFastState.compose env14403 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14403 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env14404 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2065,41,2048,0,35,2065,2049,52,1,2049,32,16,3,40,17,2048,2064,2065,2049,20,32,36,33,2048,512]

theorem envBound14404 : H12AffineFastState.Bounded env14404 := by
  intro p hp
  have h : env14404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14403_14404 : H12AffineEnvironment.transform 5 16 env14403 = env14404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14403 == env14404) = true)

theorem identity14404 : scanCanonicalize (H12AffineFastState.compose env14404 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 37) := by decide +kernel

theorem selectedBound14404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14405 : List Nat := [2,4,8,16,32,16,9,36,512,52,37,52,41,37,0,35,52,36,52,1,36,32,16,3,40,17,37,53,52,36,20,32,36,33,37,512]

theorem envBound14405 : H12AffineFastState.Bounded env14405 := by
  intro p hp
  have h : env14405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14404_14405 : H12AffineEnvironment.transform 10 37 env14404 = env14405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 37 env14404 == env14405) = true)

theorem identity14405 : scanCanonicalize (H12AffineFastState.compose env14405 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound14405 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14406 : List Nat := [2,4,8,16,32,16,9,36,12,52,37,52,41,37,0,35,52,36,52,1,36,32,16,3,40,17,37,53,52,36,20,32,36,33,37,12]

theorem envBound14406 : H12AffineFastState.Bounded env14406 := by
  intro p hp
  have h : env14406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14405_14406 : H12AffineEnvironment.transform 8 12 env14405 = env14406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env14405 == env14406) = true)

theorem identity14406 : scanCanonicalize (H12AffineFastState.compose env14406 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14406 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14407 : List Nat := [2,4,8,16,0,16,9,4,12,20,5,20,9,5,0,3,20,4,20,1,4,0,16,3,8,17,5,21,20,4,20,0,4,1,5,12]

theorem envBound14407 : H12AffineFastState.Bounded env14407 := by
  intro p hp
  have h : env14407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14406_14407 : H12AffineEnvironment.transform 4 0 env14406 = env14407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14406 == env14407) = true)

theorem identity14407 : scanCanonicalize (H12AffineFastState.compose env14407 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14407 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14408 : List Nat := [1,4,8,16,0,16,9,4,12,20,5,20,9,5,0,0,20,4,20,1,4,0,16,0,8,17,5,21,20,4,20,0,4,1,5,12]

theorem envBound14408 : H12AffineFastState.Bounded env14408 := by
  intro p hp
  have h : env14408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14407_14408 : H12AffineEnvironment.transform 0 1 env14407 = env14408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14407 == env14408) = true)

def env14409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,115871,156012,16,95497,8328,65,245138,79130,102878,109046,61705,243003,256,95531,103566,120542]

theorem envBound14409 : H12AffineFastState.Bounded env14409 := by
  intro p hp
  have h : env14409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14390_14409 : H12AffineEnvironment.transform 23 95497 env14390 = env14409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env14390 == env14409) = true)

theorem identity14409 : scanCanonicalize (H12AffineFastState.compose env14409 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound14409 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179512,1024,32769,4160,156012,16,41430,8328,65,158029,57797,17665,32041,61705,156132,256,41460,16465,513]

theorem envBound14410 : H12AffineFastState.Bounded env14410 := by
  intro p hp
  have h : env14410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14409_14410 : H12AffineEnvironment.transform 15 54495 env14409 = env14410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env14409 == env14410) = true)

def env14411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4160,156012,16,41310,8192,65,158029,57677,17665,32041,61705,156012,256,41340,16465,513]

theorem envBound14411 : H12AffineFastState.Bounded env14411 := by
  intro p hp
  have h : env14411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14410_14411 : H12AffineEnvironment.transform 6 8 env14410 = env14411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14410 == env14411) = true)

theorem identity14411 : scanCanonicalize (H12AffineFastState.compose env14411 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound14411 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,35189,1024,32769,4160,21793,16,41310,8192,65,23808,57677,17665,32041,61705,21793,256,41340,16465,513]

theorem envBound14412 : H12AffineFastState.Bounded env14412 := by
  intro p hp
  have h : env14412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14411_14412 : H12AffineEnvironment.transform 16 13389 env14411 = env14412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env14411 == env14412) = true)

theorem identity14412 : scanCanonicalize (H12AffineFastState.compose env14412 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound14412 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env14413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9292,28699,13389,11577,1024,9293,4160,21793,16,1298,8192,65,23808,17665,17665,32041,21829,21793,256,1328,16465,513]

theorem envBound14413 : H12AffineFastState.Bounded env14413 := by
  intro p hp
  have h : env14413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14412_14413 : H12AffineEnvironment.transform 14 9292 env14412 = env14413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env14412 == env14413) = true)

theorem identity14413 : scanCanonicalize (H12AffineFastState.compose env14413 (packedSelected [3,5,9,10,14,22] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound14413 : packedSelected [3,5,9,10,14,22] rootPS < 2^1333 := by decide +kernel

def env14414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,1,21590,4096,2420,1024,0,4160,21793,16,1298,1101,65,23808,17665,17665,22884,21829,21793,256,1328,16465,513]

theorem envBound14414 : H12AffineFastState.Bounded env14414 := by
  intro p hp
  have h : env14414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14413_14414 : H12AffineEnvironment.transform 12 1101 env14413 = env14414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env14413 == env14414) = true)

def env14415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4160,156012,16,41311,8193,65,158029,57676,17665,32041,61705,156013,256,41341,16465,513]

theorem envBound14415 : H12AffineFastState.Bounded env14415 := by
  intro p hp
  have h : env14415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14410_14415 : H12AffineEnvironment.transform 6 9 env14410 = env14415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14410 == env14415) = true)

theorem identity14415 : scanCanonicalize (H12AffineFastState.compose env14415 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound14415 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10281,1024,32769,4160,62589,16,41311,8193,65,64604,57676,17665,32041,61705,62588,256,41341,16465,513]

theorem envBound14416 : H12AffineFastState.Bounded env14416 := by
  intro p hp
  have h : env14416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14415_14416 : H12AffineEnvironment.transform 16 38161 env14415 = env14416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env14415 == env14416) = true)

theorem identity14416 : scanCanonicalize (H12AffineFastState.compose env14416 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14416 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env14417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,38161,10281,1024,32769,4160,41340,16,41311,8193,65,43357,46157,4096,10280,41992,41341,256,41341,5456,513]

theorem envBound14417 : H12AffineFastState.Bounded env14417 := by
  intro p hp
  have h : env14417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14416_14417 : H12AffineEnvironment.transform 13 5377 env14416 = env14417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14416 == env14417) = true)

theorem identity14417 : scanCanonicalize (H12AffineFastState.compose env14417 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound14417 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,372,35,5221,10281,1024,373,4160,8200,16,8235,8193,65,10281,13625,4096,10280,9596,8201,256,8201,5456,513]

theorem envBound14418 : H12AffineFastState.Bounded env14418 := by
  intro p hp
  have h : env14418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14417_14418 : H12AffineEnvironment.transform 14 372 env14417 = env14418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env14417 == env14418) = true)

theorem identity14418 : scanCanonicalize (H12AffineFastState.compose env14418 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14418 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env14419 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,81,35,5221,10281,1024,80,4160,8200,16,8235,8193,65,10281,13340,4096,10280,9305,8201,37,8201,5237,513]

theorem envBound14419 : H12AffineFastState.Bounded env14419 := by
  intro p hp
  have h : env14419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14418_14419 : H12AffineEnvironment.transform 7 37 env14418 = env14419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14418 == env14419) = true)

theorem identity14419 : scanCanonicalize (H12AffineFastState.compose env14419 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14419 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14420 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5156,81,35,5221,2049,1024,80,4160,32,16,3,41,65,2049,5172,4096,2048,1137,33,37,33,5237,513]

theorem envBound14420 : H12AffineFastState.Bounded env14420 := by
  intro p hp
  have h : env14420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14419_14420 : H12AffineEnvironment.transform 12 40 env14419 = env14420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14419 == env14420) = true)

theorem identity14420 : scanCanonicalize (H12AffineFastState.compose env14420 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound14420 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env14421 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,64,40,1124,81,35,1061,2049,1024,80,0,32,16,3,41,65,2049,1140,64,2048,1137,33,37,33,1077,513]

theorem envBound14421 : H12AffineFastState.Bounded env14421 := by
  intro p hp
  have h : env14421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14420_14421 : H12AffineEnvironment.transform 11 64 env14420 = env14421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env14420 == env14421) = true)

theorem identity14421 : scanCanonicalize (H12AffineFastState.compose env14421 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound14421 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env14422 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1125,64,40,1124,81,35,1061,1124,1024,80,0,32,16,3,41,65,1124,1140,64,1125,1137,33,37,33,1077,513]

theorem envBound14422 : H12AffineFastState.Bounded env14422 := by
  intro p hp
  have h : env14422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14421_14422 : H12AffineEnvironment.transform 10 1125 env14421 = env14422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env14421 == env14422) = true)

theorem identity14422 : scanCanonicalize (H12AffineFastState.compose env14422 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14422 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env14423 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1077,16,40,1076,1,35,1061,1076,1024,0,0,32,16,3,41,17,1076,1060,16,1077,1057,33,37,33,1077,513]

theorem envBound14423 : H12AffineFastState.Bounded env14423 := by
  intro p hp
  have h : env14423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14422_14423 : H12AffineEnvironment.transform 5 16 env14422 = env14423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14422 == env14423) = true)

theorem identity14423 : scanCanonicalize (H12AffineFastState.compose env14423 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14423 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14424 : List Nat := [2,4,8,0,32,0,9,37,512,1024,1061,0,40,1060,1,35,1061,1060,1024,0,0,32,0,3,41,1,1060,1060,0,1061,1057,33,37,33,1061,513]

theorem envBound14424 : H12AffineFastState.Bounded env14424 := by
  intro p hp
  have h : env14424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14423_14424 : H12AffineEnvironment.transform 3 0 env14423 = env14424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14423 == env14424) = true)

theorem identity14424 : scanCanonicalize (H12AffineFastState.compose env14424 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound14424 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14425 : List Nat := [2,4,8,0,32,0,9,37,512,47,10,0,40,11,1,35,10,11,47,0,0,32,0,3,41,1,11,11,0,10,14,33,37,33,10,513]

theorem envBound14425 : H12AffineFastState.Bounded env14425 := by
  intro p hp
  have h : env14425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14424_14425 : H12AffineEnvironment.transform 9 47 env14424 = env14425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env14424 == env14425) = true)

theorem identity14425 : scanCanonicalize (H12AffineFastState.compose env14425 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14425 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14426 : List Nat := [2,4,8,0,10,0,9,15,512,5,10,0,2,11,1,9,10,11,5,0,0,10,0,3,3,1,11,11,0,10,14,11,15,11,10,513]

theorem envBound14426 : H12AffineFastState.Bounded env14426 := by
  intro p hp
  have h : env14426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14425_14426 : H12AffineEnvironment.transform 4 10 env14425 = env14426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14425 == env14426) = true)

theorem identity14426 : scanCanonicalize (H12AffineFastState.compose env14426 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound14426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14427 : List Nat := [2,4,8,0,10,0,9,15,15,5,10,0,2,11,1,9,10,11,5,0,0,10,0,3,3,1,11,11,0,10,14,11,15,11,10,14]

theorem envBound14427 : H12AffineFastState.Bounded env14427 := by
  intro p hp
  have h : env14427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14426_14427 : H12AffineEnvironment.transform 8 15 env14426 = env14427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env14426 == env14427) = true)

theorem identity14427 : scanCanonicalize (H12AffineFastState.compose env14427 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14427 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env14428 : List Nat := [2,4,3,0,1,0,2,4,4,5,1,0,2,0,1,2,1,0,5,0,0,1,0,3,3,1,0,0,0,1,5,0,4,0,1,5]

theorem envBound14428 : H12AffineFastState.Bounded env14428 := by
  intro p hp
  have h : env14428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14427_14428 : H12AffineEnvironment.transform 2 3 env14427 = env14428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14427 == env14428) = true)

theorem identity14428 : scanCanonicalize (H12AffineFastState.compose env14428 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound14428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14429 : List Nat := [1,4,0,0,1,0,1,4,4,5,1,0,1,0,1,1,1,0,5,0,0,1,0,0,0,1,0,0,0,1,5,0,4,0,1,5]

theorem envBound14429 : H12AffineFastState.Bounded env14429 := by
  intro p hp
  have h : env14429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14428_14429 : H12AffineEnvironment.transform 0 1 env14428 = env14429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env14428 == env14429) = true)

def env14430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485879,16777216,8328,65,16959643,17246709,102879,109046,17231335,17148372,256,16777251,16834950,17287728]

theorem envBound14430 : H12AffineFastState.Bounded env14430 := by
  intro p hp
  have h : env14430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14388_14430 : H12AffineEnvironment.transform 20 437625 env14388 = env14430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env14388 == env14430) = true)

theorem identity14430 : scanCanonicalize (H12AffineFastState.compose env14430 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 362529) := by decide +kernel

theorem selectedBound14430 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env14431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485879,362529,8328,65,475322,172500,102879,109046,222662,8693,256,362498,354727,147985]

theorem envBound14431 : H12AffineFastState.Bounded env14431 := by
  intro p hp
  have h : env14431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14430_14431 : H12AffineEnvironment.transform 23 362529 env14430 = env14431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 362529 env14430 == env14431) = true)

def env14432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,322921,8572,338407,362529,8328,65,327850,57796,102879,109046,75222,8693,256,362498,354727,513]

theorem envBound14432 : H12AffineFastState.Bounded env14432 := by
  intro p hp
  have h : env14432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14431_14432 : H12AffineEnvironment.transform 16 16400 env14431 = env14432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14431 == env14432) = true)

theorem identity14432 : scanCanonicalize (H12AffineFastState.compose env14432 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14432 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,322921,8572,264684,305194,8328,65,270497,57796,45524,35325,1501,8693,256,305161,281004,513]

theorem envBound14433 : H12AffineFastState.Bounded env14433 := by
  intro p hp
  have h : env14433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14432_14433 : H12AffineEnvironment.transform 15 8203 env14432 = env14433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14432 == env14433) = true)

theorem identity14433 : scanCanonicalize (H12AffineFastState.compose env14433 (packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound14433 : packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env14434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,50633,8572,8524,32906,8328,65,2049,57796,45524,35325,1501,8693,256,32937,24844,513]

theorem envBound14434 : H12AffineFastState.Bounded env14434 := by
  intro p hp
  have h : env14434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14433_14434 : H12AffineEnvironment.transform 17 10400 env14433 = env14434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env14433 == env14434) = true)

theorem identity14434 : scanCanonicalize (H12AffineFastState.compose env14434 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14434 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env14435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,16400,10400,1024,1,17865,8572,8524,138,8328,65,2049,25028,12756,2557,1501,8693,256,169,24844,513]

theorem envBound14435 : H12AffineFastState.Bounded env14435 := by
  intro p hp
  have h : env14435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14434_14435 : H12AffineEnvironment.transform 14 0 env14434 = env14435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14434 == env14435) = true)

theorem identity14435 : scanCanonicalize (H12AffineFastState.compose env14435 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound14435 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env14436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,0,398,16400,2341,1024,1,17865,249,201,138,269,65,2049,16449,4177,2557,1501,112,256,169,16521,513]

theorem envBound14436 : H12AffineFastState.Bounded env14436 := by
  intro p hp
  have h : env14436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14435_14436 : H12AffineEnvironment.transform 12 389 env14435 = env14436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env14435 == env14436) = true)

theorem identity14436 : scanCanonicalize (H12AffineFastState.compose env14436 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14436 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env14437 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,0,398,16400,2341,1024,1,17816,168,152,138,269,16,2049,16400,4096,2476,1420,33,256,169,16521,513]

theorem envBound14437 : H12AffineFastState.Bounded env14437 := by
  intro p hp
  have h : env14437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14436_14437 : H12AffineEnvironment.transform 5 17 env14436 = env14437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14436 == env14437) = true)

theorem identity14437 : scanCanonicalize (H12AffineFastState.compose env14437 (packedSelected [5,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound14437 : packedSelected [5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env14438 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3245,389,16384,0,398,16400,2341,1024,1,17816,168,152,138,269,16,2049,16400,3245,2476,1420,33,256,169,16521,513]

theorem envBound14438 : H12AffineFastState.Bounded env14438 := by
  intro p hp
  have h : env14438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14437_14438 : H12AffineEnvironment.transform 11 3245 env14437 = env14438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env14437 == env14438) = true)

theorem identity14438 : scanCanonicalize (H12AffineFastState.compose env14438 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound14438 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14439 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,2065,389,16384,0,398,16400,2341,188,1,16676,168,152,138,269,16,2049,16400,2065,2476,304,33,256,169,16521,513]

theorem envBound14439 : H12AffineFastState.Bounded env14439 := by
  intro p hp
  have h : env14439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14438_14439 : H12AffineEnvironment.transform 9 188 env14438 = env14439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env14438 == env14439) = true)

theorem identity14439 : scanCanonicalize (H12AffineFastState.compose env14439 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14439 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env14440 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2065,268,16384,0,263,16400,2341,53,1,16676,33,17,3,269,16,2049,16400,2065,2341,304,33,256,32,16384,513]

theorem envBound14440 : H12AffineFastState.Bounded env14440 := by
  intro p hp
  have h : env14440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14439_14440 : H12AffineEnvironment.transform 6 9 env14439 = env14440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14439 == env14440) = true)

theorem identity14440 : scanCanonicalize (H12AffineFastState.compose env14440 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound14440 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14441 : List Nat := [2,4,8,16,32,17,9,20,512,53,2048,2065,24,16384,0,19,16400,2097,53,1,16432,33,17,3,25,16,2049,16400,2065,2097,36,33,20,32,16384,513]

theorem envBound14441 : H12AffineFastState.Bounded env14441 := by
  intro p hp
  have h : env14441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14440_14441 : H12AffineEnvironment.transform 7 20 env14440 = env14441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env14440 == env14441) = true)

theorem identity14441 : scanCanonicalize (H12AffineFastState.compose env14441 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound14441 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14442 : List Nat := [2,4,8,16,32,17,9,20,512,53,2048,2065,24,512,0,19,528,2097,53,1,560,33,17,3,25,16,2049,528,2065,2097,36,33,20,32,512,513]

theorem envBound14442 : H12AffineFastState.Bounded env14442 := by
  intro p hp
  have h : env14442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14441_14442 : H12AffineEnvironment.transform 13 512 env14441 = env14442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env14441 == env14442) = true)

theorem identity14442 : scanCanonicalize (H12AffineFastState.compose env14442 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound14442 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14443 : List Nat := [2,4,8,16,32,17,9,20,512,53,49,32,24,512,0,19,528,0,53,1,560,33,17,3,25,16,48,528,32,0,36,33,20,32,512,513]

theorem envBound14443 : H12AffineFastState.Bounded env14443 := by
  intro p hp
  have h : env14443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14442_14443 : H12AffineEnvironment.transform 10 49 env14442 = env14443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env14442 == env14443) = true)

theorem identity14443 : scanCanonicalize (H12AffineFastState.compose env14443 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14443 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14444 : List Nat := [2,4,8,16,1,17,9,20,512,20,16,1,24,512,0,19,528,0,20,1,529,0,17,3,25,16,17,528,1,0,5,0,20,1,512,513]

theorem envBound14444 : H12AffineFastState.Bounded env14444 := by
  intro p hp
  have h : env14444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14443_14444 : H12AffineEnvironment.transform 4 1 env14443 = env14444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14443 == env14444) = true)

theorem identity14444 : scanCanonicalize (H12AffineFastState.compose env14444 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14445 : List Nat := [2,4,8,1,1,0,9,5,512,5,1,1,9,512,0,2,513,0,5,1,512,0,0,3,8,1,0,513,1,0,5,0,5,1,512,513]

theorem envBound14445 : H12AffineFastState.Bounded env14445 := by
  intro p hp
  have h : env14445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14444_14445 : H12AffineEnvironment.transform 3 1 env14444 = env14445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14444 == env14445) = true)

theorem identity14445 : scanCanonicalize (H12AffineFastState.compose env14445 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14445 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env14446 : List Nat := [2,4,8,1,1,0,9,5,1,5,1,1,9,1,0,2,0,0,5,1,1,0,0,3,8,1,0,0,1,0,5,0,5,1,1,0]

theorem envBound14446 : H12AffineFastState.Bounded env14446 := by
  intro p hp
  have h : env14446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14445_14446 : H12AffineEnvironment.transform 8 1 env14445 = env14446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14445 == env14446) = true)

def env14447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,322920,8573,338406,362529,8328,65,327851,57797,102879,109046,75223,8693,256,362498,354727,512]

theorem envBound14447 : H12AffineFastState.Bounded env14447 := by
  intro p hp
  have h : env14447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14431_14447 : H12AffineEnvironment.transform 16 16401 env14431 = env14447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14431 == env14447) = true)

theorem identity14447 : scanCanonicalize (H12AffineFastState.compose env14447 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound14447 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,122146,1024,32769,77898,8573,62660,21763,8328,65,56713,57797,102879,109046,75223,8693,256,21792,46213,512]

theorem envBound14448 : H12AffineFastState.Bounded env14448 := by
  intro p hp
  have h : env14448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14447_14448 : H12AffineEnvironment.transform 17 122146 env14447 = env14448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env14447 == env14448) = true)

theorem identity14448 : scanCanonicalize (H12AffineFastState.compose env14448 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound14448 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env14449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,16401,76278,1024,29909,77898,8573,16,21763,8328,65,10589,5393,91403,89378,75223,8693,256,21792,16465,512]

theorem envBound14449 : H12AffineFastState.Bounded env14449 := by
  intro p hp
  have h : env14449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14448_14449 : H12AffineEnvironment.transform 14 29908 env14448 = env14449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env14448 == env14449) = true)

theorem identity14449 : scanCanonicalize (H12AffineFastState.compose env14449 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound14449 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,34,16401,10708,1024,29909,12392,8573,16,21763,8328,65,10589,5393,25897,23808,9717,8693,256,21792,16465,512]

theorem envBound14450 : H12AffineFastState.Bounded env14450 := by
  intro p hp
  have h : env14450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14449_14450 : H12AffineEnvironment.transform 15 34 env14449 = env14450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env14449 == env14450) = true)

theorem identity14450 : scanCanonicalize (H12AffineFastState.compose env14450 (packedSelected [1,2,3,4,8,10,12,14,15,17,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

theorem selectedBound14450 : packedSelected [1,2,3,4,8,10,12,14,15,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env14451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,32,34,13541,10708,1024,33,12392,8573,16,8695,8328,65,10589,5393,4573,10740,9717,8693,256,8660,13477,512]

theorem envBound14451 : H12AffineFastState.Bounded env14451 := by
  intro p hp
  have h : env14451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14450_14451 : H12AffineEnvironment.transform 13 13556 env14450 = env14451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env14450 == env14451) = true)

theorem identity14451 : scanCanonicalize (H12AffineFastState.compose env14451 (packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound14451 : packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS < 2^1333 := by decide +kernel

def env14452 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,13556,32,34,13541,10368,1024,33,12392,8233,16,8355,8328,65,10249,5189,4233,10400,9377,8353,84,8320,13477,512]

theorem envBound14452 : H12AffineFastState.Bounded env14452 := by
  intro p hp
  have h : env14452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14451_14452 : H12AffineEnvironment.transform 7 84 env14451 = env14452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env14451 == env14452) = true)

theorem identity14452 : scanCanonicalize (H12AffineFastState.compose env14452 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14452 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env14453 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,40,5340,32,34,5325,2216,1024,33,4160,1,16,139,160,65,2081,5189,4233,2184,1161,137,84,168,5261,512]

theorem envBound14453 : H12AffineFastState.Bounded env14453 := by
  intro p hp
  have h : env14453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14452_14453 : H12AffineEnvironment.transform 12 40 env14452 = env14453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14452 == env14453) = true)

theorem identity14453 : scanCanonicalize (H12AffineFastState.compose env14453 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound14453 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env14454 : List Nat := [2,4,8,16,32,64,128,84,512,1024,1076,4096,40,5340,32,34,5325,1180,1024,33,4160,1,16,139,160,65,1045,5189,4233,1212,1161,137,84,168,5261,512]

theorem envBound14454 : H12AffineFastState.Bounded env14454 := by
  intro p hp
  have h : env14454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14453_14454 : H12AffineEnvironment.transform 10 1076 env14453 = env14454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env14453 == env14454) = true)

theorem identity14454 : scanCanonicalize (H12AffineFastState.compose env14454 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound14454 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env14455 : List Nat := [2,4,8,16,32,64,89,84,512,1024,1076,4096,40,5125,32,34,5140,1093,1024,33,4160,1,16,82,121,65,1045,5189,4176,1125,1104,80,84,113,5204,512]

theorem envBound14455 : H12AffineFastState.Bounded env14455 := by
  intro p hp
  have h : env14455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14454_14455 : H12AffineEnvironment.transform 6 89 env14454 = env14455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env14454 == env14455) = true)

theorem identity14455 : scanCanonicalize (H12AffineFastState.compose env14455 (packedSelected [5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound14455 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env14456 : List Nat := [2,4,8,16,32,64,89,84,122,1024,1076,4096,40,5125,32,34,5140,1093,1024,33,4160,1,16,82,121,65,1045,5189,4176,1125,1104,80,84,113,5204,122]

theorem envBound14456 : H12AffineFastState.Bounded env14456 := by
  intro p hp
  have h : env14456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14455_14456 : H12AffineEnvironment.transform 8 122 env14455 = env14456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env14455 == env14456) = true)

theorem identity14456 : scanCanonicalize (H12AffineFastState.compose env14456 (packedSelected [1,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound14456 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env14457 : List Nat := [2,4,8,16,32,64,89,84,122,1024,1076,1060,40,33,32,34,48,1093,1024,33,1124,1,16,82,121,65,1045,97,1140,1125,1104,80,84,113,112,122]

theorem envBound14457 : H12AffineFastState.Bounded env14457 := by
  intro p hp
  have h : env14457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14456_14457 : H12AffineEnvironment.transform 11 1060 env14456 = env14457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env14456 == env14457) = true)

theorem identity14457 : scanCanonicalize (H12AffineFastState.compose env14457 (packedSelected [1,4] rootPS)) = affineNative (2^(9+1) ^^^ 102) := by decide +kernel

theorem selectedBound14457 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env14458 : List Nat := [2,4,8,16,32,64,89,84,122,102,82,66,40,33,32,34,48,35,102,33,2,1,16,82,121,65,115,97,18,3,54,80,84,113,112,122]

theorem envBound14458 : H12AffineFastState.Bounded env14458 := by
  intro p hp
  have h : env14458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14457_14458 : H12AffineEnvironment.transform 9 102 env14457 = env14458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 102 env14457 == env14458) = true)

theorem identity14458 : scanCanonicalize (H12AffineFastState.compose env14458 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound14458 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14459 : List Nat := [2,4,8,16,3,64,89,84,89,69,82,66,11,2,3,1,19,0,69,2,2,1,16,82,90,65,80,66,18,3,21,80,84,82,83,89]

theorem envBound14459 : H12AffineFastState.Bounded env14459 := by
  intro p hp
  have h : env14459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14458_14459 : H12AffineEnvironment.transform 4 3 env14458 = env14459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env14458 == env14459) = true)

theorem identity14459 : scanCanonicalize (H12AffineFastState.compose env14459 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14459 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14460 : List Nat := [2,4,8,16,3,17,8,5,8,20,3,19,11,2,3,1,19,0,20,2,2,1,16,3,11,16,1,19,18,3,21,1,5,3,2,8]

theorem envBound14460 : H12AffineFastState.Bounded env14460 := by
  intro p hp
  have h : env14460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14459_14460 : H12AffineEnvironment.transform 5 17 env14459 = env14460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14459 == env14460) = true)

theorem identity14460 : scanCanonicalize (H12AffineFastState.compose env14460 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound14460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14461 : List Nat := [2,4,8,12,3,13,8,5,8,8,3,15,11,2,3,1,15,0,8,2,2,1,12,3,11,12,1,15,14,3,9,1,5,3,2,8]

theorem envBound14461 : H12AffineFastState.Bounded env14461 := by
  intro p hp
  have h : env14461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14460_14461 : H12AffineEnvironment.transform 3 12 env14460 = env14461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env14460 == env14461) = true)

theorem identity14461 : scanCanonicalize (H12AffineFastState.compose env14461 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound14461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14462 : List Nat := [0,4,8,12,1,13,8,5,8,8,1,13,9,0,1,1,13,0,8,0,0,1,12,1,9,12,1,13,12,1,9,1,5,1,0,8]

theorem envBound14462 : H12AffineFastState.Bounded env14462 := by
  intro p hp
  have h : env14462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14461_14462 : H12AffineEnvironment.transform 0 0 env14461 = env14462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env14461 == env14462) = true)

def env14463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156013,485879,16777216,8328,65,16959642,18973836,2571430,109046,17231335,19072172,256,19311962,19287295,17287728]

theorem envBound14463 : H12AffineFastState.Bounded env14463 := by
  intro p hp
  have h : env14463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14387_14463 : H12AffineEnvironment.transform 21 156013 env14387 = env14463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env14387 == env14463) = true)

def env14464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485879,16777216,8328,65,16959642,17246708,102878,109046,17231335,17148372,256,16777250,16834951,17287728]

theorem envBound14464 : H12AffineFastState.Bounded env14464 := by
  intro p hp
  have h : env14464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14463_14464 : H12AffineEnvironment.transform 20 437624 env14463 = env14464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env14463 == env14464) = true)

def env14465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485879,510000,8328,65,327850,57796,102878,109046,75223,156132,256,509970,469431,512]

theorem envBound14465 : H12AffineFastState.Bounded env14465 := by
  intro p hp
  have h : env14465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14464_14465 : H12AffineEnvironment.transform 23 510000 env14464 = env14465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510000 env14464 == env14465) = true)

theorem identity14465 : scanCanonicalize (H12AffineFastState.compose env14465 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound14465 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156013,120015,95496,8328,65,245138,57796,102878,109046,75223,156132,256,95530,103567,512]

theorem envBound14466 : H12AffineFastState.Bounded env14466 := by
  intro p hp
  have h : env14466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14465_14466 : H12AffineEnvironment.transform 17 179512 env14465 = env14466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env14465 == env14466) = true)

theorem identity14466 : scanCanonicalize (H12AffineFastState.compose env14466 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103630) := by decide +kernel

theorem selectedBound14466 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env14467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103630,76278,1024,32769,4160,128419,120015,95496,8328,65,10588,57796,102878,109046,75223,128298,256,95530,103567,512]

theorem envBound14467 : H12AffineFastState.Bounded env14467 := by
  intro p hp
  have h : env14467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14466_14467 : H12AffineEnvironment.transform 16 103630 env14466 = env14467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103630 env14466 == env14467) = true)

theorem identity14467 : scanCanonicalize (H12AffineFastState.compose env14467 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound14467 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env14468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16400,64808,1024,32769,4160,8573,17,41430,8328,65,10588,57796,17664,32040,61705,8692,256,41460,16465,512]

theorem envBound14468 : H12AffineFastState.Bounded env14468 := by
  intro p hp
  have h : env14468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14467_14468 : H12AffineEnvironment.transform 15 54494 env14467 = env14468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env14467 == env14468) = true)

theorem identity14468 : scanCanonicalize (H12AffineFastState.compose env14468 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14468 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,32768,54494,16400,56576,1024,32769,4160,341,17,33278,160,65,2420,49644,17664,23808,53537,476,256,33244,16465,512]

theorem envBound14469 : H12AffineFastState.Bounded env14469 := by
  intro p hp
  have h : env14469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14468_14469 : H12AffineEnvironment.transform 12 40 env14468 = env14469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14468 == env14469) = true)

theorem identity14469 : scanCanonicalize (H12AffineFastState.compose env14469 (packedSelected [2,4,5,12,14,15,17,18,19,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21928) := by decide +kernel

theorem selectedBound14469 : packedSelected [2,4,5,12,14,15,17,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env14470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,21928,374,16400,2216,1024,21929,4160,341,17,21590,160,65,2420,5188,17664,23808,1161,476,256,21620,16465,512]

theorem envBound14470 : H12AffineFastState.Bounded env14470 := by
  intro p hp
  have h : env14470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14469_14470 : H12AffineEnvironment.transform 14 21928 env14469 = env14470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21928 env14469 == env14470) = true)

theorem identity14470 : scanCanonicalize (H12AffineFastState.compose env14470 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound14470 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env14471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5376,168,374,5392,2216,1024,169,4160,341,17,342,160,65,2420,5188,4096,2048,1161,476,256,372,5457,512]

theorem envBound14471 : H12AffineFastState.Bounded env14471 := by
  intro p hp
  have h : env14471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14470_14471 : H12AffineEnvironment.transform 13 5376 env14470 = env14471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env14470 == env14471) = true)

theorem identity14471 : scanCanonicalize (H12AffineFastState.compose env14471 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound14471 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env14472 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,40,5376,168,263,5392,2216,1024,169,4145,292,17,295,160,48,2309,5173,4096,2048,1161,429,256,261,5408,512]

theorem envBound14472 : H12AffineFastState.Bounded env14472 := by
  intro p hp
  have h : env14472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14471_14472 : H12AffineEnvironment.transform 5 49 env14471 = env14472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env14471 == env14472) = true)

theorem identity14472 : scanCanonicalize (H12AffineFastState.compose env14472 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound14472 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14473 : List Nat := [2,4,8,16,32,49,128,172,512,1024,2048,4096,40,5292,168,171,5308,2216,1024,169,4145,136,17,139,160,48,2217,5173,4096,2048,1161,1,172,169,5260,512]

theorem envBound14473 : H12AffineFastState.Bounded env14473 := by
  intro p hp
  have h : env14473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14472_14473 : H12AffineEnvironment.transform 7 172 env14472 = env14473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env14472 == env14473) = true)

theorem identity14473 : scanCanonicalize (H12AffineFastState.compose env14473 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound14473 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14474 : List Nat := [2,4,8,16,32,49,128,172,512,1024,1213,4096,40,5292,168,171,5308,1045,1024,169,4145,136,17,139,160,48,1044,5173,4096,1213,1161,1,172,169,5260,512]

theorem envBound14474 : H12AffineFastState.Bounded env14474 := by
  intro p hp
  have h : env14474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14473_14474 : H12AffineEnvironment.transform 10 1213 env14473 = env14474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env14473 == env14474) = true)

theorem identity14474 : scanCanonicalize (H12AffineFastState.compose env14474 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound14474 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env14475 : List Nat := [2,4,8,16,32,49,128,172,512,21,168,4096,40,4281,168,171,4265,0,21,169,4145,136,17,139,160,48,1,4128,4096,168,156,1,172,169,4249,512]

theorem envBound14475 : H12AffineFastState.Bounded env14475 := by
  intro p hp
  have h : env14475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14474_14475 : H12AffineEnvironment.transform 9 21 env14474 = env14475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env14474 == env14475) = true)

theorem identity14475 : scanCanonicalize (H12AffineFastState.compose env14475 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound14475 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env14476 : List Nat := [2,4,8,16,32,49,128,172,512,21,168,17,40,168,168,171,184,0,21,169,32,136,17,139,160,48,1,49,17,168,156,1,172,169,136,512]

theorem envBound14476 : H12AffineFastState.Bounded env14476 := by
  intro p hp
  have h : env14476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14475_14476 : H12AffineEnvironment.transform 11 17 env14475 = env14476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env14475 == env14476) = true)

theorem identity14476 : scanCanonicalize (H12AffineFastState.compose env14476 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14476 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env14477 : List Nat := [2,4,8,16,32,49,9,37,512,21,33,17,40,33,33,34,49,0,21,32,32,1,17,2,41,48,1,49,17,33,21,1,37,32,1,512]

theorem envBound14477 : H12AffineFastState.Bounded env14477 := by
  intro p hp
  have h : env14477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14476_14477 : H12AffineEnvironment.transform 6 9 env14476 = env14477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14476 == env14477) = true)

def env14478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485879,510001,8328,65,327851,57797,102878,109046,75222,156133,256,509971,469430,513]

theorem envBound14478 : H12AffineFastState.Bounded env14478 := by
  intro p hp
  have h : env14478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14464_14478 : H12AffineEnvironment.transform 23 510001 env14464 = env14478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510001 env14464 == env14478) = true)

def env14479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485759,510001,8192,65,327715,57677,102742,108926,75102,156013,256,509971,469310,513]

theorem envBound14479 : H12AffineFastState.Bounded env14479 := by
  intro p hp
  have h : env14479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14478_14479 : H12AffineEnvironment.transform 6 8 env14478 = env14479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14478 == env14479) = true)

theorem identity14479 : scanCanonicalize (H12AffineFastState.compose env14479 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14479 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env14480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,380259,65910,264548,305194,8192,65,327715,57677,102742,108926,75102,65910,256,305160,280869,513]

theorem envBound14480 : H12AffineFastState.Bounded env14480 := by
  intro p hp
  have h : env14480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14479_14480 : H12AffineEnvironment.transform 16 90139 env14479 = env14480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14479 == env14480) = true)

theorem identity14480 : scanCanonicalize (H12AffineFastState.compose env14480 (packedSelected [0,1,4,5,8,9,11,15,17,18,20,23,24,27,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound14480 : packedSelected [0,1,4,5,8,9,11,15,17,18,20,23,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env14481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,65536,77914,262144,1024,32769,367906,65910,264548,305194,8192,65,327715,45324,102742,108926,75102,65910,256,305160,268644,513]

theorem envBound14481 : H12AffineFastState.Bounded env14481 := by
  intro p hp
  have h : env14481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14480_14481 : H12AffineEnvironment.transform 13 4161 env14480 = env14481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env14480 == env14481) = true)

theorem identity14481 : scanCanonicalize (H12AffineFastState.compose env14481 (packedSelected [0,7,8,10,17,18,20,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound14481 : packedSelected [0,7,8,10,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env14482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,8282,4096,262144,1024,32769,310648,8492,264548,305194,8192,65,270457,45324,45324,35108,1284,8492,256,305160,268644,513]

theorem envBound14482 : H12AffineFastState.Bounded env14482 := by
  intro p hp
  have h : env14482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14481_14482 : H12AffineEnvironment.transform 15 8282 env14481 = env14482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env14481 == env14482) = true)

theorem identity14482 : scanCanonicalize (H12AffineFastState.compose env14482 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound14482 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env14483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,8282,4096,35189,1024,32769,13325,8492,32785,8543,8192,65,43276,45324,45324,35108,1284,8492,256,8573,36881,513]

theorem envBound14483 : H12AffineFastState.Bounded env14483 := by
  intro p hp
  have h : env14483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14482_14483 : H12AffineEnvironment.transform 17 35189 env14482 = env14483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env14482 == env14483) = true)

def env14484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485758,510001,8193,65,327714,57676,102743,108927,75103,156012,256,509971,469311,513]

theorem envBound14484 : H12AffineFastState.Bounded env14484 := by
  intro p hp
  have h : env14484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14478_14484 : H12AffineEnvironment.transform 6 9 env14478 = env14484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14478 == env14484) = true)

theorem identity14484 : scanCanonicalize (H12AffineFastState.compose env14484 (packedSelected [0,3,10,11,14,15,16,17,18,19,20,23,24,27,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14484 : packedSelected [0,3,10,11,14,15,16,17,18,19,20,23,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env14485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,396324,156013,485758,485741,8193,65,327714,16400,77835,67619,75103,156012,256,485711,469311,513]

theorem envBound14485 : H12AffineFastState.Bounded env14485 := by
  intro p hp
  have h : env14485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14484_14485 : H12AffineEnvironment.transform 14 8540 env14484 = env14485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14484 == env14485) = true)

theorem identity14485 : scanCanonicalize (H12AffineFastState.compose env14485 (packedSelected [1,3,7,14,16,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 223551) := by decide +kernel

theorem selectedBound14485 : packedSelected [1,3,7,14,16,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env14486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223551,1024,8541,91419,156013,65,82,8193,65,157981,16400,77835,67619,75103,156012,256,112,16384,513]

theorem envBound14486 : H12AffineFastState.Bounded env14486 := by
  intro p hp
  have h : env14486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14485_14486 : H12AffineEnvironment.transform 17 223551 env14485 = env14486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223551 env14485 == env14486) = true)

theorem identity14486 : scanCanonicalize (H12AffineFastState.compose env14486 (packedSelected [2,6,16,17,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14486 : packedSelected [2,6,16,17,20] rootPS < 2^1333 := by decide +kernel

def env14487 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,223551,1024,8461,91419,155965,17,2,8193,17,157981,16400,77835,67619,75023,155964,256,32,16384,513]

theorem envBound14487 : H12AffineFastState.Bounded env14487 := by
  intro p hp
  have h : env14487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14486_14487 : H12AffineEnvironment.transform 5 16 env14486 = env14487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14486 == env14487) = true)

theorem identity14487 : scanCanonicalize (H12AffineFastState.compose env14487 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound14487 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14488 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,65536,16400,76079,1024,8461,91419,8493,17,2,8193,17,10509,16400,77835,67619,75023,8492,256,32,16384,513]

theorem envBound14488 : H12AffineFastState.Bounded env14488 := by
  intro p hp
  have h : env14488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14487_14488 : H12AffineEnvironment.transform 16 16400 env14487 = env14488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14487 == env14488) = true)

theorem identity14488 : scanCanonicalize (H12AffineFastState.compose env14488 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14488 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14489 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,65536,16400,67619,1024,1,82967,33,17,2,269,17,2049,16400,69895,67619,66563,32,256,32,16384,513]

theorem envBound14489 : H12AffineFastState.Bounded env14489 := by
  intro p hp
  have h : env14489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14488_14489 : H12AffineEnvironment.transform 12 268 env14488 = env14489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14488 == env14489) = true)

theorem identity14489 : scanCanonicalize (H12AffineFastState.compose env14489 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound14489 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14490 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2049,268,16384,0,65536,16400,67619,1024,1,82967,33,17,2,269,17,2049,16400,67846,67619,66563,32,256,32,16384,513]

theorem envBound14490 : H12AffineFastState.Bounded env14490 := by
  intro p hp
  have h : env14490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14489_14490 : H12AffineEnvironment.transform 11 2049 env14489 = env14490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env14489 == env14490) = true)

theorem identity14490 : scanCanonicalize (H12AffineFastState.compose env14490 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound14490 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env14491 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1281,1280,268,16384,0,65536,16400,66850,1024,1,82967,33,17,2,269,17,1280,16400,66567,66850,66563,32,256,32,16384,513]

theorem envBound14491 : H12AffineFastState.Bounded env14491 := by
  intro p hp
  have h : env14491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14490_14491 : H12AffineEnvironment.transform 10 1281 env14490 = env14491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env14490 == env14491) = true)

theorem identity14491 : scanCanonicalize (H12AffineFastState.compose env14491 (packedSelected [0,2,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 17415) := by decide +kernel

theorem selectedBound14491 : packedSelected [0,2,9,10] rootPS < 2^1333 := by decide +kernel

def env14492 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1281,1280,268,16384,0,17415,16400,16677,1024,1,16,33,17,2,269,17,1280,16400,16384,16677,16388,32,256,32,16384,513]

theorem envBound14492 : H12AffineFastState.Bounded env14492 := by
  intro p hp
  have h : env14492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14491_14492 : H12AffineEnvironment.transform 15 17415 env14491 = env14492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17415 env14491 == env14492) = true)

theorem identity14492 : scanCanonicalize (H12AffineFastState.compose env14492 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound14492 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env14493 : List Nat := [2,4,8,16,32,16,9,256,512,37,292,293,268,16384,0,16418,16400,16677,37,1,16,33,17,2,269,17,293,16400,16384,16677,16388,32,256,32,16384,513]

theorem envBound14493 : H12AffineFastState.Bounded env14493 := by
  intro p hp
  have h : env14493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14492_14493 : H12AffineEnvironment.transform 9 37 env14492 = env14493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env14492 == env14493) = true)

theorem identity14493 : scanCanonicalize (H12AffineFastState.compose env14493 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound14493 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14494 : List Nat := [2,4,8,16,32,16,9,256,512,37,292,293,268,293,0,263,309,0,37,1,16,33,17,2,269,17,293,309,293,0,289,32,256,32,293,513]

theorem envBound14494 : H12AffineFastState.Bounded env14494 := by
  intro p hp
  have h : env14494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14493_14494 : H12AffineEnvironment.transform 13 293 env14493 = env14494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env14493 == env14494) = true)

theorem identity14494 : scanCanonicalize (H12AffineFastState.compose env14494 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound14494 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14495 : List Nat := [2,4,8,16,32,16,9,256,292,37,292,293,268,293,0,263,309,0,37,1,16,33,17,2,269,17,293,309,293,0,289,32,256,32,293,293]

theorem envBound14495 : H12AffineFastState.Bounded env14495 := by
  intro p hp
  have h : env14495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14494_14495 : H12AffineEnvironment.transform 8 292 env14494 = env14495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env14494 == env14495) = true)

theorem identity14495 : scanCanonicalize (H12AffineFastState.compose env14495 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14495 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14496 : List Nat := [2,4,8,1,32,1,9,256,292,37,292,293,268,293,0,263,292,0,37,1,1,33,0,2,269,0,293,292,293,0,289,32,256,32,293,293]

theorem envBound14496 : H12AffineFastState.Bounded env14496 := by
  intro p hp
  have h : env14496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14495_14496 : H12AffineEnvironment.transform 3 1 env14495 = env14496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14495 == env14496) = true)

theorem identity14496 : scanCanonicalize (H12AffineFastState.compose env14496 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14496 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14497 : List Nat := [2,4,8,1,1,1,9,256,261,4,261,260,268,260,0,263,261,0,4,1,1,0,0,2,269,0,260,261,260,0,256,1,256,1,260,260]

theorem envBound14497 : H12AffineFastState.Bounded env14497 := by
  intro p hp
  have h : env14497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14496_14497 : H12AffineEnvironment.transform 4 1 env14496 = env14497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14496 == env14497) = true)

theorem identity14497 : scanCanonicalize (H12AffineFastState.compose env14497 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14497 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14498 : List Nat := [2,4,8,1,1,1,9,4,1,4,1,0,8,0,0,3,1,0,4,1,1,0,0,2,9,0,0,1,0,0,4,1,4,1,0,0]

theorem envBound14498 : H12AffineFastState.Bounded env14498 := by
  intro p hp
  have h : env14498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14497_14498 : H12AffineEnvironment.transform 7 4 env14497 = env14498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14497 == env14498) = true)

def env14499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485879,16777216,8328,65,16959642,17246709,102879,109046,17231335,17148373,256,16777251,16834950,17287728]

theorem envBound14499 : H12AffineFastState.Bounded env14499 := by
  intro p hp
  have h : env14499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14463_14499 : H12AffineEnvironment.transform 20 437625 env14463 = env14499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env14463 == env14499) = true)

theorem identity14499 : scanCanonicalize (H12AffineFastState.compose env14499 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound14499 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env14500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485879,188870,8328,65,10588,378931,102879,109046,265249,477203,256,188901,131136,338934]

theorem envBound14500 : H12AffineFastState.Bounded env14500 := by
  intro p hp
  have h : env14500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14499_14500 : H12AffineEnvironment.transform 23 188870 env14499 = env14500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env14499 == env14500) = true)

def env14501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156013,120015,188870,8328,65,10588,226571,102879,109046,176409,128299,256,188901,131136,235214]

theorem envBound14501 : H12AffineFastState.Bounded env14501 := by
  intro p hp
  have h : env14501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14500_14501 : H12AffineEnvironment.transform 17 179512 env14500 = env14501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env14500 == env14501) = true)

theorem identity14501 : scanCanonicalize (H12AffineFastState.compose env14501 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound14501 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149996,1024,29909,4161,156013,73755,136466,8328,65,10588,226571,91403,89378,148941,66047,256,136497,131136,221722]

theorem envBound14502 : H12AffineFastState.Bounded env14502 := by
  intro p hp
  have h : env14502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14501_14502 : H12AffineEnvironment.transform 14 29908 env14501 = env14502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env14501 == env14502) = true)

def env14503 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,149948,1024,29829,4113,155965,73755,136466,8328,17,10508,226571,91403,89378,148893,65967,256,136497,131088,221722]

theorem envBound14503 : H12AffineFastState.Bounded env14503 := by
  intro p hp
  have h : env14503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14502_14503 : H12AffineEnvironment.transform 5 16 env14502 = env14503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14502 == env14503) = true)

theorem identity14503 : scanCanonicalize (H12AffineFastState.compose env14503 (packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound14503 : packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env14504 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,79130,97446,1024,29829,4113,87079,73755,73736,8328,17,10508,16401,91403,89378,94343,65967,256,73771,79114,22272]

theorem envBound14504 : H12AffineFastState.Bounded env14504 := by
  intro p hp
  have h : env14504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14503_14504 : H12AffineEnvironment.transform 16 79130 env14503 = env14504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env14503 == env14504) = true)

theorem identity14504 : scanCanonicalize (H12AffineFastState.compose env14504 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound14504 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env14505 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,5528,23588,1024,29829,4113,29861,153,138,8328,17,10508,16401,17801,32160,20485,8493,256,169,5512,22272]

theorem envBound14505 : H12AffineFastState.Bounded env14505 := by
  intro p hp
  have h : env14505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14504_14505 : H12AffineEnvironment.transform 15 8322 env14504 = env14505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env14504 == env14505) = true)

theorem identity14505 : scanCanonicalize (H12AffineFastState.compose env14505 (packedSelected [3,4,8,9,10,11,12,14,15,16,17,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound14505 : packedSelected [3,4,8,9,10,11,12,14,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env14506 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29828,8322,5172,23588,1024,29829,4113,29861,153,138,8328,17,10400,16401,17445,31756,20485,8321,172,169,5156,22188]

theorem envBound14506 : H12AffineFastState.Bounded env14506 := by
  intro p hp
  have h : env14506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14505_14506 : H12AffineEnvironment.transform 7 172 env14505 = env14506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env14505 == env14506) = true)

theorem identity14506 : scanCanonicalize (H12AffineFastState.compose env14506 (packedSelected [0,2,4,5,6,7,8,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound14506 : packedSelected [0,2,4,5,6,7,8,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14507 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5156,8352,8322,5172,2048,1024,8353,4113,8321,153,138,8328,17,10400,5173,4097,10280,1057,8321,172,169,5156,648]

theorem envBound14507 : H12AffineFastState.Bounded env14507 := by
  intro p hp
  have h : env14507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14506_14507 : H12AffineEnvironment.transform 13 5156 env14506 = env14507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env14506 == env14507) = true)

theorem identity14507 : scanCanonicalize (H12AffineFastState.compose env14507 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound14507 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14508 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,129,5156,33,3,5172,2048,1024,32,4113,0,153,138,9,17,2081,5173,4097,2217,1057,0,172,169,5156,648]

theorem envBound14508 : H12AffineFastState.Bounded env14508 := by
  intro p hp
  have h : env14508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14507_14508 : H12AffineEnvironment.transform 12 129 env14507 = env14508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env14507 == env14508) = true)

theorem identity14508 : scanCanonicalize (H12AffineFastState.compose env14508 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound14508 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14509 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,41,5156,33,3,5172,2048,1024,32,4113,0,49,34,9,17,2081,5173,4097,2049,1057,0,4,1,5156,544]

theorem envBound14509 : H12AffineFastState.Bounded env14509 := by
  intro p hp
  have h : env14509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14508_14509 : H12AffineEnvironment.transform 6 40 env14508 = env14509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env14508 == env14509) = true)

theorem identity14509 : scanCanonicalize (H12AffineFastState.compose env14509 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14509 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env14510 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5124,1,3,5140,2048,1024,0,4113,0,17,2,9,17,2049,5141,4097,2049,1025,0,4,1,5124,512]

theorem envBound14510 : H12AffineFastState.Bounded env14510 := by
  intro p hp
  have h : env14510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14509_14510 : H12AffineEnvironment.transform 4 0 env14509 = env14510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14509 == env14510) = true)

def env14511 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,149949,1024,29828,4112,155964,73755,136466,8328,16,10509,226571,91403,89378,148892,65966,256,136497,131089,221722]

theorem envBound14511 : H12AffineFastState.Bounded env14511 := by
  intro p hp
  have h : env14511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14502_14511 : H12AffineEnvironment.transform 5 17 env14502 = env14511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14502 == env14511) = true)

theorem identity14511 : scanCanonicalize (H12AffineFastState.compose env14511 (packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14511 : packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env14512 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,131072,149813,1024,29708,4112,155964,73755,136466,8192,16,10509,226571,91403,89378,148756,65830,256,136497,131089,221722]

theorem envBound14512 : H12AffineFastState.Bounded env14512 := by
  intro p hp
  have h : env14512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14511_14512 : H12AffineEnvironment.transform 6 8 env14511 = env14512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14511 == env14512) = true)

theorem identity14512 : scanCanonicalize (H12AffineFastState.compose env14512 (packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound14512 : packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env14513 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,21794,131072,149813,1024,29708,4112,155964,30009,136466,8192,16,10509,139305,12329,2048,148756,21508,256,136497,131089,145208]

theorem envBound14513 : H12AffineFastState.Bounded env14513 := by
  intro p hp
  have h : env14513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14512_14513 : H12AffineEnvironment.transform 15 21794 env14512 = env14513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env14512 == env14513) = true)

theorem identity14513 : scanCanonicalize (H12AffineFastState.compose env14513 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound14513 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env14514 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,21794,13625,31756,1024,29708,4112,21509,30009,8235,8192,16,10509,5392,12329,2048,28717,21508,256,8200,13608,513]

theorem envBound14514 : H12AffineFastState.Bounded env14514 := by
  intro p hp
  have h : env14514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14513_14514 : H12AffineEnvironment.transform 16 13625 env14513 = env14514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env14513 == env14514) = true)

theorem identity14514 : scanCanonicalize (H12AffineFastState.compose env14514 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound14514 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14515 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,12344,1077,9498,13625,3124,1024,1076,4112,9277,1281,8235,8192,16,10509,5392,12329,2048,21,9276,256,8200,13608,513]

theorem envBound14515 : H12AffineFastState.Bounded env14515 := by
  intro p hp
  have h : env14515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14514_14515 : H12AffineEnvironment.transform 13 12344 env14514 = env14515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env14514 == env14515) = true)

theorem identity14515 : scanCanonicalize (H12AffineFastState.compose env14515 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14515 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env14516 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,8192,12344,0,8495,12556,2049,53,1,4112,8200,308,8235,8192,16,10509,4389,12329,2048,21,8201,256,8200,12573,513]

theorem envBound14516 : H12AffineFastState.Bounded env14516 := by
  intro p hp
  have h : env14516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14515_14516 : H12AffineEnvironment.transform 9 53 env14515 = env14516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14515 == env14516) = true)

def env14517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156013,120014,188870,8328,65,10588,226570,102879,109046,176408,128298,256,188901,131136,235215]

theorem envBound14517 : H12AffineFastState.Bounded env14517 := by
  intro p hp
  have h : env14517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14500_14517 : H12AffineEnvironment.transform 17 179513 env14500 = env14517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env14500 == env14517) = true)

theorem identity14517 : scanCanonicalize (H12AffineFastState.compose env14517 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound14517 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122146,1024,32769,4160,65910,120014,98781,8328,65,10588,5393,102879,109046,119043,128298,256,98814,90203,63188]

theorem envBound14518 : H12AffineFastState.Bounded env14518 := by
  intro p hp
  have h : env14518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14517_14518 : H12AffineEnvironment.transform 16 90139 env14517 = env14518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env14517 == env14518) = true)

def env14519 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122146,1024,32769,4160,65910,119878,98645,8192,65,10588,5393,102743,108926,119043,128298,256,98678,90203,63068]

theorem envBound14519 : H12AffineFastState.Bounded env14519 := by
  intro p hp
  have h : env14519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14518_14519 : H12AffineEnvironment.transform 6 8 env14518 = env14519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14518 == env14519) = true)

theorem identity14519 : scanCanonicalize (H12AffineFastState.compose env14519 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound14519 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,76159,1024,29788,4160,65910,73755,95496,8192,65,10588,5393,91402,89379,75102,65911,256,95531,90203,513]

theorem envBound14520 : H12AffineFastState.Bounded env14520 := by
  intro p hp
  have h : env14520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14519_14520 : H12AffineEnvironment.transform 14 29789 env14519 = env14520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env14519 == env14520) = true)

theorem identity14520 : scanCanonicalize (H12AffineFastState.compose env14520 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14520 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env14521 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16400,2420,1024,29788,4160,8573,16,21763,8192,65,10588,5393,17665,32040,1365,8572,256,21792,16464,513]

theorem envBound14521 : H12AffineFastState.Bounded env14521 := by
  intro p hp
  have h : env14521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14520_14521 : H12AffineEnvironment.transform 15 8203 env14520 = env14521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14520 == env14521) = true)

theorem identity14521 : scanCanonicalize (H12AffineFastState.compose env14521 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound14521 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14522 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,20496,1094,16400,2420,1024,20497,4160,1328,16,21763,1101,65,3345,5393,17665,22885,1365,1329,256,21792,16464,513]

theorem envBound14522 : H12AffineFastState.Bounded env14522 := by
  intro p hp
  have h : env14522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14521_14522 : H12AffineEnvironment.transform 12 1101 env14521 = env14522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env14521 == env14522) = true)

def env14523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122146,1024,32769,4160,65910,119879,98644,8193,65,10588,5393,102742,108927,119043,128298,256,98679,90203,63069]

theorem envBound14523 : H12AffineFastState.Bounded env14523 := by
  intro p hp
  have h : env14523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14518_14523 : H12AffineEnvironment.transform 6 9 env14518 = env14523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14518 == env14523) = true)

theorem identity14523 : scanCanonicalize (H12AffineFastState.compose env14523 (packedSelected [4,5,9,12,15,16,19,24,35] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound14523 : packedSelected [4,5,9,12,15,16,19,24,35] rootPS < 2^1333 := by decide +kernel

def env14524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,76159,1024,29788,4160,65910,73754,95497,8193,65,10588,5393,91403,89378,75102,65911,256,95530,90203,512]

theorem envBound14524 : H12AffineFastState.Bounded env14524 := by
  intro p hp
  have h : env14524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14523_14524 : H12AffineEnvironment.transform 14 29789 env14523 = env14524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env14523 == env14524) = true)

theorem identity14524 : scanCanonicalize (H12AffineFastState.compose env14524 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound14524 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,34,24633,10589,1024,29788,4160,340,8248,29995,8193,65,10588,5393,25897,23808,9596,341,256,29960,24697,512]

theorem envBound14525 : H12AffineFastState.Bounded env14525 := by
  intro p hp
  have h : env14525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14524_14525 : H12AffineEnvironment.transform 15 34 env14524 = env14525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env14524 == env14525) = true)

theorem identity14525 : scanCanonicalize (H12AffineFastState.compose env14525 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound14525 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,34,5220,10589,1024,1,4160,340,8248,374,8193,65,10588,5393,4468,10589,9596,341,256,341,5156,512]

theorem envBound14526 : H12AffineFastState.Bounded env14526 := by
  intro p hp
  have h : env14526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14525_14526 : H12AffineEnvironment.transform 13 13405 env14525 = env14526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env14525 == env14526) = true)

theorem identity14526 : scanCanonicalize (H12AffineFastState.compose env14526 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound14526 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14527 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,12572,0,34,4389,10589,321,1,4160,340,8248,374,8193,65,10588,4176,4468,10589,8253,341,256,341,4453,512]

theorem envBound14527 : H12AffineFastState.Bounded env14527 := by
  intro p hp
  have h : env14527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14526_14527 : H12AffineEnvironment.transform 9 321 env14526 = env14527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env14526 == env14527) = true)

theorem identity14527 : scanCanonicalize (H12AffineFastState.compose env14527 (packedSelected [0,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 886) := by decide +kernel

theorem selectedBound14527 : packedSelected [0,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env14528 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,886,4714,0,34,4389,2603,321,1,4160,340,846,374,887,65,2602,4176,4468,2603,843,341,256,341,4453,512]

theorem envBound14528 : H12AffineFastState.Bounded env14528 := by
  intro p hp
  have h : env14528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14527_14528 : H12AffineEnvironment.transform 12 886 env14527 = env14528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 886 env14527 == env14528) = true)

theorem identity14528 : scanCanonicalize (H12AffineFastState.compose env14528 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound14528 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env14529 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2097,886,2651,0,34,2324,2603,321,1,2161,340,846,374,887,65,2602,2145,2373,2603,843,341,256,341,2388,512]

theorem envBound14529 : H12AffineFastState.Bounded env14529 := by
  intro p hp
  have h : env14529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14528_14529 : H12AffineEnvironment.transform 11 2097 env14528 = env14529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env14528 == env14529) = true)

theorem identity14529 : scanCanonicalize (H12AffineFastState.compose env14529 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound14529 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env14530 : List Nat := [2,4,8,16,32,64,9,256,512,321,293,276,886,894,0,34,49,782,321,1,340,340,846,374,887,65,783,324,96,782,843,341,256,341,113,512]

theorem envBound14530 : H12AffineFastState.Bounded env14530 := by
  intro p hp
  have h : env14530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14529_14530 : H12AffineEnvironment.transform 10 293 env14529 = env14530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env14529 == env14530) = true)

theorem identity14530 : scanCanonicalize (H12AffineFastState.compose env14530 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound14530 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14531 : List Nat := [2,4,8,16,32,64,9,256,302,321,293,276,88,80,0,34,49,32,321,1,340,340,96,374,89,65,33,324,96,32,101,341,256,341,113,302]

theorem envBound14531 : H12AffineFastState.Bounded env14531 := by
  intro p hp
  have h : env14531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14530_14531 : H12AffineEnvironment.transform 8 302 env14530 = env14531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env14530 == env14531) = true)

theorem identity14531 : scanCanonicalize (H12AffineFastState.compose env14531 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 92) := by decide +kernel

theorem selectedBound14531 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14532 : List Nat := [2,4,8,16,32,64,9,92,114,29,121,72,88,80,0,34,49,32,29,1,8,8,96,42,89,65,33,24,96,32,101,9,92,9,113,114]

theorem envBound14532 : H12AffineFastState.Bounded env14532 := by
  intro p hp
  have h : env14532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14531_14532 : H12AffineEnvironment.transform 7 92 env14531 = env14532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 92 env14531 == env14532) = true)

theorem identity14532 : scanCanonicalize (H12AffineFastState.compose env14532 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14532 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14533 : List Nat := [2,4,8,16,32,17,9,13,35,29,40,25,9,1,0,34,49,32,29,1,8,8,49,42,8,16,33,24,49,32,52,9,13,9,32,35]

theorem envBound14533 : H12AffineFastState.Bounded env14533 := by
  intro p hp
  have h : env14533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14532_14533 : H12AffineEnvironment.transform 5 17 env14532 = env14533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14532 == env14533) = true)

theorem identity14533 : scanCanonicalize (H12AffineFastState.compose env14533 (packedSelected [0,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound14533 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env14534 : List Nat := [2,4,1,16,32,17,0,4,35,20,33,16,0,1,0,34,49,32,20,1,1,1,49,35,1,16,33,17,49,32,52,0,4,0,32,35]

theorem envBound14534 : H12AffineFastState.Bounded env14534 := by
  intro p hp
  have h : env14534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14533_14534 : H12AffineEnvironment.transform 2 1 env14533 = env14534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env14533 == env14534) = true)

def env14535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265168,23160257,257,27378860,27337992,25207750]

theorem envBound14535 : H12AffineFastState.Bounded env14535 := by
  intro p hp
  have h : env14535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14385_14535 : H12AffineEnvironment.transform 18 1025 env14385 = env14535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14385 == env14535) = true)

theorem identity14535 : scanCanonicalize (H12AffineFastState.compose env14535 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 297335) := by decide +kernel

theorem selectedBound14535 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8328,65,12798326,2428410,10507601,8830976,8719719,6679734,257,10833371,10857599,8661681]

theorem envBound14536 : H12AffineFastState.Bounded env14536 := by
  intro p hp
  have h : env14536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14535_14536 : H12AffineEnvironment.transform 23 297335 env14535 = env14536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297335 env14535 == env14536) = true)

def env14537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12798326,2428274,10507601,8830976,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound14537 : H12AffineFastState.Bounded env14537 := by
  intro p hp
  have h : env14537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14536_14537 : H12AffineEnvironment.transform 6 8 env14536 = env14537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14536 == env14537) = true)

def env14538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12650854,2428274,10507601,8683536,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound14538 : H12AffineFastState.Bounded env14538 := by
  intro p hp
  have h : env14538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14537_14538 : H12AffineEnvironment.transform 16 16400 env14537 = env14538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14537 == env14538) = true)

theorem identity14538 : scanCanonicalize (H12AffineFastState.compose env14538 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound14538 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env14539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,17,297335,8192,65,4262263,2428274,2118976,294913,331126,6679614,257,2444610,2468974,272936]

theorem envBound14539 : H12AffineFastState.Bounded env14539 := by
  intro p hp
  have h : env14539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14538_14539 : H12AffineEnvironment.transform 22 17 env14538 = env14539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14538 == env14539) = true)

theorem identity14539 : scanCanonicalize (H12AffineFastState.compose env14539 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound14539 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41310,8192,65,4262263,2172251,2118976,43048,75103,6407191,257,2188651,2196551,513]

theorem envBound14540 : H12AffineFastState.Bounded env14540 := by
  intro p hp
  have h : env14540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14539_14540 : H12AffineEnvironment.transform 17 10281 env14539 = env14540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14539 == env14540) = true)

def env14541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58396,4194304,17,41310,8192,65,4262263,115015,45404,43048,75103,4268043,257,98679,90203,513]

theorem envBound14541 : H12AffineFastState.Bounded env14541 := by
  intro p hp
  have h : env14541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14540_14541 : H12AffineEnvironment.transform 20 58396 env14540 = env14541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env14540 == env14541) = true)

theorem identity14541 : scanCanonicalize (H12AffineFastState.compose env14541 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14541 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1025,32769,58396,4194304,17,41310,8192,65,4204924,57676,45404,43048,1364,4194304,257,41340,16464,513]

theorem envBound14542 : H12AffineFastState.Bounded env14542 := by
  intro p hp
  have h : env14542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14541_14542 : H12AffineEnvironment.transform 15 8203 env14541 = env14542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14541 == env14542) = true)

theorem identity14542 : scanCanonicalize (H12AffineFastState.compose env14542 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound14542 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env14543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1025,32769,58396,113,17,41310,8192,65,10509,57676,45404,43048,1364,113,257,41340,16464,513]

theorem envBound14543 : H12AffineFastState.Bounded env14543 := by
  intro p hp
  have h : env14543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14542_14543 : H12AffineEnvironment.transform 21 113 env14542 = env14543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env14542 == env14543) = true)

theorem identity14543 : scanCanonicalize (H12AffineFastState.compose env14543 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound14543 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,343,16400,2421,1025,32769,50496,113,17,32770,348,65,2129,49168,36864,35188,1364,113,257,32800,16464,513]

theorem envBound14544 : H12AffineFastState.Bounded env14544 := by
  intro p hp
  have h : env14544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14543_14544 : H12AffineEnvironment.transform 12 348 env14543 = env14544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env14543 == env14544) = true)

theorem identity14544 : scanCanonicalize (H12AffineFastState.compose env14544 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14544 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14545 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16400,2341,1025,32769,50448,33,17,32770,268,17,2049,49168,36864,35108,1284,33,257,32800,16384,513]

theorem envBound14545 : H12AffineFastState.Bounded env14545 := by
  intro p hp
  have h : env14545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14544_14545 : H12AffineEnvironment.transform 5 16 env14544 = env14545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14544 == env14545) = true)

theorem identity14545 : scanCanonicalize (H12AffineFastState.compose env14545 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound14545 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14546 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,263,16400,2341,1025,0,17681,33,17,3,268,17,2049,16401,4097,2341,1284,33,257,33,16384,513]

theorem envBound14546 : H12AffineFastState.Bounded env14546 := by
  intro p hp
  have h : env14546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14545_14546 : H12AffineEnvironment.transform 14 1 env14545 = env14546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env14545 == env14546) = true)

theorem identity14546 : scanCanonicalize (H12AffineFastState.compose env14546 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound14546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14547 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5393,2341,1025,0,4112,33,17,3,268,17,2049,5392,4097,2341,1284,33,257,33,5377,513]

theorem envBound14547 : H12AffineFastState.Bounded env14547 := by
  intro p hp
  have h : env14547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14546_14547 : H12AffineEnvironment.transform 13 5377 env14546 = env14547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env14546 == env14547) = true)

theorem identity14547 : scanCanonicalize (H12AffineFastState.compose env14547 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound14547 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14548 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,268,1077,1,263,1061,2341,1025,0,292,33,17,3,268,17,2049,1060,309,2341,1284,33,257,33,1077,513]

theorem envBound14548 : H12AffineFastState.Bounded env14548 := by
  intro p hp
  have h : env14548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14547_14548 : H12AffineEnvironment.transform 11 308 env14547 = env14548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env14547 == env14548) = true)

def env14549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58397,4194304,17,41310,8192,65,4262263,115014,45405,43048,75103,4268042,257,98678,90202,513]

theorem envBound14549 : H12AffineFastState.Bounded env14549 := by
  intro p hp
  have h : env14549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14540_14549 : H12AffineEnvironment.transform 20 58397 env14540 = env14549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env14540 == env14549) = true)

theorem identity14549 : scanCanonicalize (H12AffineFastState.compose env14549 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound14549 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env14550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,17729,4194304,17,2,8192,65,4262263,90138,4097,2420,75103,4268042,257,73770,90202,513]

theorem envBound14550 : H12AffineFastState.Bounded env14550 := by
  intro p hp
  have h : env14550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14549_14550 : H12AffineEnvironment.transform 14 8540 env14549 = env14550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env14549 == env14550) = true)

theorem identity14550 : scanCanonicalize (H12AffineFastState.compose env14550 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound14550 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env14551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,263,16400,10281,1025,8541,17729,4194304,17,2,8192,65,4196464,24861,4097,2420,9304,4202765,257,8493,24925,513]

theorem envBound14551 : H12AffineFastState.Bounded env14551 := by
  intro p hp
  have h : env14551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14550_14551 : H12AffineEnvironment.transform 15 263 env14550 = env14551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env14550 == env14551) = true)

theorem identity14551 : scanCanonicalize (H12AffineFastState.compose env14551 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound14551 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env14552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,263,16400,10281,1025,8541,17729,113,17,2,8192,65,2049,24861,4097,2420,9304,8572,257,8493,24925,513]

theorem envBound14552 : H12AffineFastState.Bounded env14552 := by
  intro p hp
  have h : env14552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14551_14552 : H12AffineEnvironment.transform 21 113 env14551 = env14552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env14551 == env14552) = true)

theorem identity14552 : scanCanonicalize (H12AffineFastState.compose env14552 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14552 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14553 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,263,16400,10281,1025,8461,17681,33,17,2,8192,17,2049,24861,4097,2340,9224,8492,257,8493,24845,513]

theorem envBound14553 : H12AffineFastState.Bounded env14553 := by
  intro p hp
  have h : env14553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14552_14553 : H12AffineEnvironment.transform 5 16 env14552 = env14553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14552 == env14553) = true)

def env14554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297335,8192,65,12650855,2428274,10507601,8683537,8719719,6679614,257,10833235,10857599,8661561]

theorem envBound14554 : H12AffineFastState.Bounded env14554 := by
  intro p hp
  have h : env14554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14537_14554 : H12AffineEnvironment.transform 16 16401 env14537 = env14554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14537 == env14554) = true)

theorem identity14554 : scanCanonicalize (H12AffineFastState.compose env14554 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound14554 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env14555 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,8388608,41310,8192,65,12650855,2172251,10507601,8431672,8463694,6407191,257,10577274,10585174,8389136]

theorem envBound14555 : H12AffineFastState.Bounded env14555 := by
  intro p hp
  have h : env14555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14554_14555 : H12AffineEnvironment.transform 17 10281 env14554 = env14555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14554 == env14555) = true)

theorem identity14555 : scanCanonicalize (H12AffineFastState.compose env14555 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound14555 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41310,8192,65,4262262,2172251,2118976,43049,75103,6407191,257,2188651,2196551,513]

theorem envBound14556 : H12AffineFastState.Bounded env14556 := by
  intro p hp
  have h : env14556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14555_14556 : H12AffineEnvironment.transform 22 17 env14555 = env14556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env14555 == env14556) = true)

theorem identity14556 : scanCanonicalize (H12AffineFastState.compose env14556 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound14556 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env14557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,115735,4194304,17,41310,8192,65,4262262,57676,102743,43049,75103,4194304,257,41340,16464,513]

theorem envBound14557 : H12AffineFastState.Bounded env14557 := by
  intro p hp
  have h : env14557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14556_14557 : H12AffineEnvironment.transform 20 115735 env14556 = env14557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env14556 == env14557) = true)

theorem identity14557 : scanCanonicalize (H12AffineFastState.compose env14557 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound14557 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env14558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16401,10281,1025,32769,50496,4194304,17,41310,8192,65,4196385,57676,36864,43049,9224,4194304,257,41340,16464,513]

theorem envBound14558 : H12AffineFastState.Bounded env14558 := by
  intro p hp
  have h : env14558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14557_14558 : H12AffineEnvironment.transform 15 343 env14557 = env14558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env14557 == env14558) = true)

theorem identity14558 : scanCanonicalize (H12AffineFastState.compose env14558 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound14558 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env14559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,16401,10281,1025,8540,25629,4194304,17,3,8192,65,4196385,16401,12637,2420,9224,4194304,257,33,16464,513]

theorem envBound14559 : H12AffineFastState.Bounded env14559 := by
  intro p hp
  have h : env14559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14558_14559 : H12AffineEnvironment.transform 14 8541 env14558 = env14559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env14558 == env14559) = true)

theorem identity14559 : scanCanonicalize (H12AffineFastState.compose env14559 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound14559 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env14560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,16401,10281,1025,8540,25629,8572,17,3,8192,65,10589,16401,12637,2420,9224,8572,257,33,16464,513]

theorem envBound14560 : H12AffineFastState.Bounded env14560 := by
  intro p hp
  have h : env14560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14559_14560 : H12AffineEnvironment.transform 21 8572 env14559 = env14560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env14559 == env14560) = true)

theorem identity14560 : scanCanonicalize (H12AffineFastState.compose env14560 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1313) := by decide +kernel

theorem selectedBound14560 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env14561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1313,8541,343,1328,10281,1025,8540,8508,8572,17,3,8192,65,10589,1328,12637,2420,9224,8572,257,33,1393,513]

theorem envBound14561 : H12AffineFastState.Bounded env14561 := by
  intro p hp
  have h : env14561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14560_14561 : H12AffineEnvironment.transform 13 1313 env14560 = env14561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1313 env14560 == env14561) = true)

theorem identity14561 : scanCanonicalize (H12AffineFastState.compose env14561 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14561 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env14562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,1313,0,343,1328,2420,1025,1,97,33,17,3,349,65,2048,1328,4096,2420,1365,33,257,33,1393,513]

theorem envBound14562 : H12AffineFastState.Bounded env14562 := by
  intro p hp
  have h : env14562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14561_14562 : H12AffineEnvironment.transform 12 349 env14561 = env14562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14561 == env14562) = true)

theorem identity14562 : scanCanonicalize (H12AffineFastState.compose env14562 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound14562 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14563 : List Nat := [2,4,8,16,32,64,8,256,512,784,2048,4096,349,561,0,343,544,2420,785,1,97,33,17,3,349,65,2048,544,4096,2420,581,33,257,33,609,513]

theorem envBound14563 : H12AffineFastState.Bounded env14563 := by
  intro p hp
  have h : env14563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14562_14563 : H12AffineEnvironment.transform 9 784 env14562 = env14563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env14562 == env14563) = true)

def env14564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12798326,2428275,10507601,8830976,8719719,6679615,257,10833234,10857599,8661560]

theorem envBound14564 : H12AffineFastState.Bounded env14564 := by
  intro p hp
  have h : env14564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14536_14564 : H12AffineEnvironment.transform 6 9 env14536 = env14564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14536 == env14564) = true)

def env14565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297335,8193,65,12650854,2428275,10507601,8683536,8719719,6679615,257,10833234,10857599,8661560]

theorem envBound14565 : H12AffineFastState.Bounded env14565 := by
  intro p hp
  have h : env14565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14564_14565 : H12AffineEnvironment.transform 16 16400 env14564 = env14565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env14564 == env14565) = true)

theorem identity14565 : scanCanonicalize (H12AffineFastState.compose env14565 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound14565 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env14566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,41293,297335,8193,65,4302891,2428275,2159644,270685,371754,6679615,257,2485279,2428210,297845]

theorem envBound14566 : H12AffineFastState.Bounded env14566 := by
  intro p hp
  have h : env14566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14565_14566 : H12AffineEnvironment.transform 22 41293 env14565 = env14566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env14565 == env14566) = true)

theorem identity14566 : scanCanonicalize (H12AffineFastState.compose env14566 (packedSelected [0,9,14,17,21,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14566 : packedSelected [0,9,14,17,21,22,27,35] rootPS < 2^1333 := by decide +kernel

def env14567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,2097152,4194304,41293,297335,8193,65,4229152,2370936,2159644,270685,298017,6605876,257,2411540,2370873,297845]

theorem envBound14567 : H12AffineFastState.Bounded env14567 := by
  intro p hp
  have h : env14567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14566_14567 : H12AffineEnvironment.transform 15 8203 env14566 = env14567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14566 == env14567) = true)

theorem identity14567 : scanCanonicalize (H12AffineFastState.compose env14567 (packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS)) = affineNative (2^(20+1) ^^^ 290104) := by decide +kernel

theorem selectedBound14567 : packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env14568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,290104,4194304,41293,297335,8193,65,4229152,16448,301348,270685,298017,4235532,257,41260,16385,297845]

theorem envBound14568 : H12AffineFastState.Bounded env14568 := by
  intro p hp
  have h : env14568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0