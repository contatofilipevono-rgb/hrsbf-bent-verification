import H12CloudChart0Data215

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound54691 : H12AffineFastState.Bounded env54691 := by
  intro p hp
  have h : env54691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54688_54691 : H12AffineEnvironment.transform 9 53 env54688 = env54691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54688 == env54691) = true)

def env54692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,243002,17,98645,8193,65,215366,5393,17665,32041,1364,213350,256,21793,46092,74250]

theorem envBound54692 : H12AffineFastState.Bounded env54692 := by
  intro p hp
  have h : env54692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54673_54692 : H12AffineEnvironment.transform 6 9 env54673 = env54692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54673 == env54692) = true)

theorem identity54692 : scanCanonicalize (H12AffineFastState.compose env54692 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound54692 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138340,1024,8540,4160,201831,17,73736,8193,65,215366,5393,17665,32041,1364,213350,256,21793,5457,74250]

theorem envBound54693 : H12AffineFastState.Bounded env54693 := by
  intro p hp
  have h : env54693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54692_54693 : H12AffineEnvironment.transform 14 8541 env54692 = env54693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env54692 == env54693) = true)

theorem identity54693 : scanCanonicalize (H12AffineFastState.compose env54693 (packedSelected [0,1,6,7,10,14,20,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 90431) := by decide +kernel

theorem selectedBound54693 : packedSelected [0,1,6,7,10,14,20,26,28] rootPS < 2^1333 := by decide +kernel

def env54694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90431,97627,1024,8540,4160,30040,17,73736,8193,65,10361,5393,17665,32041,1364,8281,256,21793,5457,74250]

theorem envBound54694 : H12AffineFastState.Bounded env54694 := by
  intro p hp
  have h : env54694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54693_54694 : H12AffineEnvironment.transform 16 90431 env54693 = env54694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90431 env54693 == env54694) = true)

theorem identity54694 : scanCanonicalize (H12AffineFastState.compose env54694 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 29742) := by decide +kernel

theorem selectedBound54694 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29742,5393,2421,1024,8540,4160,30040,17,21542,8193,65,10361,5393,17665,32041,1364,8281,256,21793,5457,22052]

theorem envBound54695 : H12AffineFastState.Bounded env54695 := by
  intro p hp
  have h : env54695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54694_54695 : H12AffineEnvironment.transform 15 29742 env54694 = env54695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29742 env54694 == env54695) = true)

theorem identity54695 : scanCanonicalize (H12AffineFastState.compose env54695 (packedSelected [2,3,5,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound54695 : packedSelected [2,3,5,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env54696 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,8541,343,5393,2421,1024,8540,4160,33,17,8543,8193,65,10361,5393,12408,2128,1364,8281,256,8280,5457,9053]

theorem envBound54696 : H12AffineFastState.Bounded env54696 := by
  intro p hp
  have h : env54696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54695_54696 : H12AffineEnvironment.transform 13 13689 env54695 = env54696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env54695 == env54696) = true)

theorem identity54696 : scanCanonicalize (H12AffineFastState.compose env54696 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54696 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env54697 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5157,1,343,5393,2421,1024,0,4160,33,17,3,349,65,2341,5393,4388,2128,1364,261,256,260,5457,513]

theorem envBound54697 : H12AffineFastState.Bounded env54697 := by
  intro p hp
  have h : env54697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54696_54697 : H12AffineEnvironment.transform 12 348 env54696 = env54697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54696 == env54697) = true)

theorem identity54697 : scanCanonicalize (H12AffineFastState.compose env54697 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54697 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54698 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5157,1,115,5173,2129,1024,0,4160,33,17,3,121,65,2049,5173,4096,2128,1136,33,36,32,5237,513]

theorem envBound54698 : H12AffineFastState.Bounded env54698 := by
  intro p hp
  have h : env54698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54697_54698 : H12AffineEnvironment.transform 7 36 env54697 = env54698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54697 == env54698) = true)

theorem identity54698 : scanCanonicalize (H12AffineFastState.compose env54698 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54698 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54699 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,34,5173,2048,1024,0,4113,33,17,3,40,16,2049,5173,4096,2049,1057,33,36,32,5156,513]

theorem envBound54699 : H12AffineFastState.Bounded env54699 := by
  intro p hp
  have h : env54699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54698_54699 : H12AffineEnvironment.transform 5 17 env54698 = env54699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54698 == env54699) = true)

theorem identity54699 : scanCanonicalize (H12AffineFastState.compose env54699 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54699 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54700 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4112,1,34,4096,2048,53,0,4113,33,17,3,40,16,2049,4096,4096,2049,20,33,36,32,4113,513]

theorem envBound54700 : H12AffineFastState.Bounded env54700 := by
  intro p hp
  have h : env54700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54699_54700 : H12AffineEnvironment.transform 9 53 env54699 = env54700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54699 == env54700) = true)

theorem identity54700 : scanCanonicalize (H12AffineFastState.compose env54700 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2058) := by decide +kernel

theorem selectedBound54700 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54701 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2058,41,2074,1,34,2058,2048,53,0,2075,33,17,3,40,16,2049,2058,2058,2049,20,33,36,32,2075,513]

theorem envBound54701 : H12AffineFastState.Bounded env54701 := by
  intro p hp
  have h : env54701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54700_54701 : H12AffineEnvironment.transform 11 2058 env54700 = env54701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2058 env54700 == env54701) = true)

theorem identity54701 : scanCanonicalize (H12AffineFastState.compose env54701 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54701 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54702 : List Nat := [2,4,8,11,32,10,9,36,512,46,2048,2058,41,2049,1,34,2058,2048,46,0,2048,33,10,3,40,11,2049,2058,2058,2049,15,33,36,32,2048,513]

theorem envBound54702 : H12AffineFastState.Bounded env54702 := by
  intro p hp
  have h : env54702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54701_54702 : H12AffineEnvironment.transform 3 11 env54701 = env54702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54701 == env54702) = true)

def env54703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,4194304,16,98780,8328,65,4258941,5392,17665,32161,1500,4256861,256,21793,46213,74251]

theorem envBound54703 : H12AffineFastState.Bounded env54703 := by
  intro p hp
  have h : env54703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54671_54703 : H12AffineEnvironment.transform 20 4161 env54671 = env54703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54671 == env54703) = true)

theorem identity54703 : scanCanonicalize (H12AffineFastState.compose env54703 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54703 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179632,1024,32769,4161,4194304,16,41430,8328,65,4258941,5392,17665,32161,1500,4256861,256,21793,46213,513]

theorem envBound54704 : H12AffineFastState.Bounded env54704 := by
  intro p hp
  have h : env54704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54703_54704 : H12AffineEnvironment.transform 15 8202 env54703 = env54704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54703 == env54704) = true)

theorem identity54704 : scanCanonicalize (H12AffineFastState.compose env54704 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 169265) := by decide +kernel

theorem selectedBound54704 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179632,1024,32769,4161,169265,16,41430,8328,65,158028,5392,17665,32161,1500,156012,256,21793,46213,513]

theorem envBound54705 : H12AffineFastState.Bounded env54705 := by
  intro p hp
  have h : env54705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54704_54705 : H12AffineEnvironment.transform 21 169265 env54704 = env54705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env54704 == env54705) = true)

theorem identity54705 : scanCanonicalize (H12AffineFastState.compose env54705 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54705 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env54706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4161,169265,16,41310,8192,65,158028,5392,17665,32041,1364,156012,256,21793,46093,513]

theorem envBound54706 : H12AffineFastState.Bounded env54706 := by
  intro p hp
  have h : env54706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54705_54706 : H12AffineEnvironment.transform 6 8 env54705 = env54706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54705 == env54706) = true)

theorem identity54706 : scanCanonicalize (H12AffineFastState.compose env54706 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound54706 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10280,1024,32769,4161,33,16,41310,8192,65,64604,5392,17665,32041,1364,62588,256,21793,46093,513]

theorem envBound54707 : H12AffineFastState.Bounded env54707 := by
  intro p hp
  have h : env54707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54706_54707 : H12AffineEnvironment.transform 16 38160 env54706 = env54707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env54706 == env54707) = true)

theorem identity54707 : scanCanonicalize (H12AffineFastState.compose env54707 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54707 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env54708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,5392,10280,1024,1,4161,33,16,8542,8192,65,31836,5392,17665,32041,1364,29820,256,21793,13325,513]

theorem envBound54708 : H12AffineFastState.Bounded env54708 := by
  intro p hp
  have h : env54708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54707_54708 : H12AffineEnvironment.transform 14 0 env54707 = env54708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54707 == env54708) = true)

theorem identity54708 : scanCanonicalize (H12AffineFastState.compose env54708 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54708 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,342,5392,2420,1024,1,4161,33,16,2,348,65,23808,5392,17665,23669,1364,21792,256,21793,5457,513]

theorem envBound54709 : H12AffineFastState.Bounded env54709 := by
  intro p hp
  have h : env54709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54708_54709 : H12AffineEnvironment.transform 12 348 env54708 = env54709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54708 == env54709) = true)

theorem identity54709 : scanCanonicalize (H12AffineFastState.compose env54709 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54709 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54710 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,348,16384,0,342,5392,2389,1024,1,4161,0,16,2,348,65,23808,5392,17665,23636,1364,21761,256,21760,5457,513]

theorem envBound54710 : H12AffineFastState.Bounded env54710 := by
  intro p hp
  have h : env54710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54709_54710 : H12AffineEnvironment.transform 4 1 env54709 = env54710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54709 == env54710) = true)

theorem identity54710 : scanCanonicalize (H12AffineFastState.compose env54710 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54710 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54711 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,348,5377,0,342,5392,2389,1024,1,4161,0,16,2,348,65,2049,5392,4096,2389,1364,0,256,1,5457,513]

theorem envBound54711 : H12AffineFastState.Bounded env54711 := by
  intro p hp
  have h : env54711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54710_54711 : H12AffineEnvironment.transform 13 5377 env54710 = env54711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54710 == env54711) = true)

theorem identity54711 : scanCanonicalize (H12AffineFastState.compose env54711 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound54711 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54712 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,1029,348,260,0,342,277,2389,1024,1,1092,0,16,2,348,65,2049,277,1029,2389,1364,0,256,1,340,513]

theorem envBound54712 : H12AffineFastState.Bounded env54712 := by
  intro p hp
  have h : env54712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54711_54712 : H12AffineEnvironment.transform 11 1029 env54711 = env54712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env54711 == env54712) = true)

theorem identity54712 : scanCanonicalize (H12AffineFastState.compose env54712 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54712 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54713 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1,1029,348,260,0,342,277,340,1024,1,1092,0,16,2,348,65,0,277,1029,340,1364,0,256,1,340,513]

theorem envBound54713 : H12AffineFastState.Bounded env54713 := by
  intro p hp
  have h : env54713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54712_54713 : H12AffineEnvironment.transform 10 1 env54712 = env54713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54712 == env54713) = true)

theorem identity54713 : scanCanonicalize (H12AffineFastState.compose env54713 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound54713 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54714 : List Nat := [2,4,8,16,1,64,8,256,512,336,1,341,348,260,0,342,277,340,336,1,276,0,16,2,348,65,0,277,341,340,4,0,256,1,340,513]

theorem envBound54714 : H12AffineFastState.Bounded env54714 := by
  intro p hp
  have h : env54714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54713_54714 : H12AffineEnvironment.transform 9 336 env54713 = env54714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env54713 == env54714) = true)

theorem identity54714 : scanCanonicalize (H12AffineFastState.compose env54714 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound54714 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env54715 : List Nat := [2,4,8,16,1,64,8,256,261,336,1,341,348,260,0,342,277,340,336,1,276,0,16,2,348,65,0,277,341,340,4,0,256,1,340,260]

theorem envBound54715 : H12AffineFastState.Bounded env54715 := by
  intro p hp
  have h : env54715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54714_54715 : H12AffineEnvironment.transform 8 261 env54714 = env54715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env54714 == env54715) = true)

theorem identity54715 : scanCanonicalize (H12AffineFastState.compose env54715 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54715 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env54716 : List Nat := [2,4,8,0,1,64,8,256,261,320,1,325,332,260,0,326,261,324,320,1,260,0,0,2,332,65,0,261,325,324,4,0,256,1,324,260]

theorem envBound54716 : H12AffineFastState.Bounded env54716 := by
  intro p hp
  have h : env54716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54715_54716 : H12AffineEnvironment.transform 3 0 env54715 = env54716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54715 == env54716) = true)

theorem identity54716 : scanCanonicalize (H12AffineFastState.compose env54716 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound54716 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env54717 : List Nat := [2,4,8,0,1,0,8,256,261,256,1,261,268,260,0,262,261,260,256,1,260,0,0,2,268,1,0,261,261,260,4,0,256,1,260,260]

theorem envBound54717 : H12AffineFastState.Bounded env54717 := by
  intro p hp
  have h : env54717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54716_54717 : H12AffineEnvironment.transform 5 0 env54716 = env54717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54716 == env54717) = true)

theorem identity54717 : scanCanonicalize (H12AffineFastState.compose env54717 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54717 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54718 : List Nat := [2,4,8,0,1,0,8,4,1,4,1,1,8,0,0,2,1,0,4,1,0,0,0,2,8,1,0,1,1,0,4,0,4,1,0,0]

theorem envBound54718 : H12AffineFastState.Bounded env54718 := by
  intro p hp
  have h : env54718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54717_54718 : H12AffineEnvironment.transform 7 4 env54717 = env54718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54717 == env54718) = true)

def env54719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,2097152,4194304,2101328,98781,8328,65,6351933,2098512,17664,2125280,2102685,6349853,256,21793,46213,2175562]

theorem envBound54719 : H12AffineFastState.Bounded env54719 := by
  intro p hp
  have h : env54719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54670_54719 : H12AffineEnvironment.transform 17 179633 env54670 = env54719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env54670 == env54719) = true)

def env54720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,4194304,16,98781,8328,65,4258941,5392,17664,32160,1501,4256861,256,21793,46213,74250]

theorem envBound54720 : H12AffineFastState.Bounded env54720 := by
  intro p hp
  have h : env54720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54719_54720 : H12AffineEnvironment.transform 20 4160 env54719 = env54720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54719 == env54720) = true)

theorem identity54720 : scanCanonicalize (H12AffineFastState.compose env54720 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound54720 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179633,1024,32769,4160,4194304,16,21763,8328,65,4258941,5392,17664,32160,1501,4256861,256,21793,46213,63188]

theorem envBound54721 : H12AffineFastState.Bounded env54721 := by
  intro p hp
  have h : env54721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54720_54721 : H12AffineEnvironment.transform 15 54494 env54720 = env54721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env54720 == env54721) = true)

def env54722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4160,4194304,16,21763,8192,65,4258941,5392,17664,32040,1365,4256861,256,21793,46093,63068]

theorem envBound54722 : H12AffineFastState.Bounded env54722 := by
  intro p hp
  have h : env54722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54721_54722 : H12AffineEnvironment.transform 6 8 env54721 = env54722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54721 == env54722) = true)

theorem identity54722 : scanCanonicalize (H12AffineFastState.compose env54722 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound54722 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54723 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10280,1024,32769,4160,4194304,16,21763,8192,65,4258941,5392,17664,32040,1365,4256861,256,21793,46093,63068]

theorem envBound54723 : H12AffineFastState.Bounded env54723 := by
  intro p hp
  have h : env54723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54722_54723 : H12AffineEnvironment.transform 16 38161 env54722 = env54723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env54722 == env54723) = true)

theorem identity54723 : scanCanonicalize (H12AffineFastState.compose env54723 (packedSelected [0,3,4,5,7,10,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 32881) := by decide +kernel

theorem selectedBound54723 : packedSelected [0,3,4,5,7,10,18,22,23] rootPS < 2^1333 := by decide +kernel

def env54724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10280,1024,32769,4160,32881,16,21763,8192,65,31756,5392,17664,32040,1365,29740,256,21793,46093,63068]

theorem envBound54724 : H12AffineFastState.Bounded env54724 := by
  intro p hp
  have h : env54724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54723_54724 : H12AffineEnvironment.transform 21 32881 env54723 = env54724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32881 env54723 == env54724) = true)

theorem identity54724 : scanCanonicalize (H12AffineFastState.compose env54724 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54724 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21590,5393,10280,1024,1,4160,113,16,21763,8192,65,31756,5392,17664,32040,1365,29740,256,21793,13325,30300]

theorem envBound54725 : H12AffineFastState.Bounded env54725 := by
  intro p hp
  have h : env54725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54724_54725 : H12AffineEnvironment.transform 14 0 env54724 = env54725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54724 == env54725) = true)

theorem identity54725 : scanCanonicalize (H12AffineFastState.compose env54725 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54725 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env54726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,343,5393,10280,1024,1,4160,113,16,2,8192,65,10509,5392,4097,10281,1365,8493,256,32,13325,9053]

theorem envBound54726 : H12AffineFastState.Bounded env54726 := by
  intro p hp
  have h : env54726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54725_54726 : H12AffineEnvironment.transform 13 5377 env54725 = env54726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54725 == env54726) = true)

theorem identity54726 : scanCanonicalize (H12AffineFastState.compose env54726 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54726 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,343,5393,2420,1024,1,4160,113,16,2,348,65,2129,5392,4097,2421,1365,113,256,32,5457,513]

theorem envBound54727 : H12AffineFastState.Bounded env54727 := by
  intro p hp
  have h : env54727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54726_54727 : H12AffineEnvironment.transform 12 348 env54726 = env54727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54726 == env54727) = true)

theorem identity54727 : scanCanonicalize (H12AffineFastState.compose env54727 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54727 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54728 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5393,2341,1024,1,4113,32,16,2,269,16,2048,5392,4097,2340,1284,32,256,32,5376,513]

theorem envBound54728 : H12AffineFastState.Bounded env54728 := by
  intro p hp
  have h : env54728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54727_54728 : H12AffineEnvironment.transform 5 17 env54727 = env54728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54727 == env54728) = true)

theorem identity54728 : scanCanonicalize (H12AffineFastState.compose env54728 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound54728 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54729 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,32,269,1313,0,262,1329,2341,1024,1,49,32,16,2,269,16,2048,1328,33,2340,1284,32,256,32,1312,513]

theorem envBound54729 : H12AffineFastState.Bounded env54729 := by
  intro p hp
  have h : env54729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54728_54729 : H12AffineEnvironment.transform 11 32 env54728 = env54729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env54728 == env54729) = true)

theorem identity54729 : scanCanonicalize (H12AffineFastState.compose env54729 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound54729 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54730 : List Nat := [2,4,8,16,32,17,8,256,512,801,2048,32,269,512,0,262,528,2341,801,1,49,32,16,2,269,16,2048,529,33,2340,549,32,256,32,513,513]

theorem envBound54730 : H12AffineFastState.Bounded env54730 := by
  intro p hp
  have h : env54730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54729_54730 : H12AffineEnvironment.transform 9 801 env54729 = env54730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env54729 == env54730) = true)

theorem identity54730 : scanCanonicalize (H12AffineFastState.compose env54730 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54730 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54731 : List Nat := [2,4,8,16,32,17,8,256,512,801,1,32,269,512,0,262,528,292,801,1,49,32,16,2,269,16,1,529,33,293,549,32,256,32,513,513]

theorem envBound54731 : H12AffineFastState.Bounded env54731 := by
  intro p hp
  have h : env54731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54730_54731 : H12AffineEnvironment.transform 10 1 env54730 = env54731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54730 == env54731) = true)

theorem identity54731 : scanCanonicalize (H12AffineFastState.compose env54731 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54731 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54732 : List Nat := [2,4,8,16,32,17,8,256,16,305,1,32,269,16,0,262,0,292,305,1,49,32,16,2,269,16,1,1,33,293,53,32,256,32,17,17]

theorem envBound54732 : H12AffineFastState.Bounded env54732 := by
  intro p hp
  have h : env54732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54731_54732 : H12AffineEnvironment.transform 8 16 env54731 = env54732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54731 == env54732) = true)

theorem identity54732 : scanCanonicalize (H12AffineFastState.compose env54732 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54732 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54733 : List Nat := [2,4,8,16,32,17,8,4,16,53,1,32,9,16,0,2,0,32,53,1,49,32,16,2,9,16,1,1,33,33,53,32,4,32,17,17]

theorem envBound54733 : H12AffineFastState.Bounded env54733 := by
  intro p hp
  have h : env54733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54732_54733 : H12AffineEnvironment.transform 7 4 env54732 = env54733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54732 == env54733) = true)

theorem identity54733 : scanCanonicalize (H12AffineFastState.compose env54733 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54734 : List Nat := [2,4,8,1,32,0,8,4,1,36,1,32,9,1,0,2,0,32,36,1,32,32,1,2,9,1,1,1,33,33,36,32,4,32,0,0]

theorem envBound54734 : H12AffineFastState.Bounded env54734 := by
  intro p hp
  have h : env54734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54733_54734 : H12AffineEnvironment.transform 3 1 env54733 = env54734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54733 == env54734) = true)

theorem identity54734 : scanCanonicalize (H12AffineFastState.compose env54734 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54734 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54735 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,0,9,1,0,2,0,0,4,1,0,0,1,2,9,1,1,1,1,1,4,0,4,0,0,0]

theorem envBound54735 : H12AffineFastState.Bounded env54735 := by
  intro p hp
  have h : env54735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54734_54735 : H12AffineEnvironment.transform 4 0 env54734 = env54735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54734 == env54735) = true)

def env54736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4160,4194304,16,21763,8193,65,4258941,5392,17664,32041,1364,4256861,256,21793,46092,63069]

theorem envBound54736 : H12AffineFastState.Bounded env54736 := by
  intro p hp
  have h : env54736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54721_54736 : H12AffineEnvironment.transform 6 9 env54721 = env54736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54721 == env54736) = true)

theorem identity54736 : scanCanonicalize (H12AffineFastState.compose env54736 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound54736 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,35188,1024,32769,4160,4194304,16,21763,8193,65,4258941,5392,17664,32041,1364,4256861,256,21793,46092,63069]

theorem envBound54737 : H12AffineFastState.Bounded env54737 := by
  intro p hp
  have h : env54737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54736_54737 : H12AffineEnvironment.transform 16 13388 env54736 = env54737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env54736 == env54737) = true)

theorem identity54737 : scanCanonicalize (H12AffineFastState.compose env54737 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54737 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env54738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,13388,35188,1024,32769,4160,4194304,16,2,8193,65,4237692,5392,4097,10280,1364,4235612,256,32,46092,41820]

theorem envBound54738 : H12AffineFastState.Bounded env54738 := by
  intro p hp
  have h : env54738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54737_54738 : H12AffineEnvironment.transform 13 5377 env54737 = env54738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54737 == env54738) = true)

theorem identity54738 : scanCanonicalize (H12AffineFastState.compose env54738 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound54738 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env54739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32768,33110,5220,35188,1024,32769,4160,4194304,16,2,41,65,4229460,5392,4097,2048,1364,4227444,256,32,37924,33652]

theorem envBound54739 : H12AffineFastState.Bounded env54739 := by
  intro p hp
  have h : env54739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54738_54739 : H12AffineEnvironment.transform 12 40 env54738 = env54739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env54738 == env54739) = true)

theorem identity54739 : scanCanonicalize (H12AffineFastState.compose env54739 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound54739 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env54740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32768,33110,5220,35188,1024,32769,4160,32,16,2,41,65,35188,5392,4097,2048,1364,33108,256,32,37924,33652]

theorem envBound54740 : H12AffineFastState.Bounded env54740 := by
  intro p hp
  have h : env54740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54739_54740 : H12AffineEnvironment.transform 21 32 env54739 = env54740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env54739 == env54740) = true)

theorem identity54740 : scanCanonicalize (H12AffineFastState.compose env54740 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound54740 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32,374,5220,2388,1024,33,4160,32,16,2,41,65,2388,5392,4097,2048,1364,372,256,32,5124,852]

theorem envBound54741 : H12AffineFastState.Bounded env54741 := by
  intro p hp
  have h : env54741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54740_54741 : H12AffineEnvironment.transform 14 32 env54740 = env54741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env54740 == env54741) = true)

theorem identity54741 : scanCanonicalize (H12AffineFastState.compose env54741 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound54741 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env54742 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,40,5204,32,35,5220,2049,1024,33,4160,32,16,2,41,65,2049,5189,4097,2048,1025,33,85,32,5124,513]

theorem envBound54742 : H12AffineFastState.Bounded env54742 := by
  intro p hp
  have h : env54742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54741_54742 : H12AffineEnvironment.transform 7 85 env54741 = env54742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env54741 == env54742) = true)

theorem identity54742 : scanCanonicalize (H12AffineFastState.compose env54742 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound54742 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54743 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,40,5156,32,35,5140,2049,1024,33,4144,32,16,2,41,49,2049,5173,4097,2048,1025,33,37,32,5124,513]

theorem envBound54743 : H12AffineFastState.Bounded env54743 := by
  intro p hp
  have h : env54743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54742_54743 : H12AffineEnvironment.transform 5 48 env54742 = env54743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env54742 == env54743) = true)

theorem identity54743 : scanCanonicalize (H12AffineFastState.compose env54743 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound54743 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54744 : List Nat := [2,4,8,16,32,48,9,37,512,1024,512,4096,40,5156,32,35,5140,513,1024,33,4144,32,16,2,41,49,513,5173,4097,512,1025,33,37,32,5124,513]

theorem envBound54744 : H12AffineFastState.Bounded env54744 := by
  intro p hp
  have h : env54744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54743_54744 : H12AffineEnvironment.transform 10 512 env54743 = env54744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env54743 == env54744) = true)

theorem identity54744 : scanCanonicalize (H12AffineFastState.compose env54744 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54744 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54745 : List Nat := [2,4,8,0,32,32,9,37,512,1024,512,4096,40,5156,32,35,5124,513,1024,33,4128,32,0,2,41,33,513,5157,4097,512,1025,33,37,32,5124,513]

theorem envBound54745 : H12AffineFastState.Bounded env54745 := by
  intro p hp
  have h : env54745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54744_54745 : H12AffineEnvironment.transform 3 0 env54744 = env54745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54744 == env54745) = true)

theorem identity54745 : scanCanonicalize (H12AffineFastState.compose env54745 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54745 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54746 : List Nat := [2,4,8,0,1,1,9,4,512,1024,512,4096,9,5125,1,2,5124,513,1024,0,4097,1,0,2,8,0,513,5124,4097,512,1025,0,4,1,5124,513]

theorem envBound54746 : H12AffineFastState.Bounded env54746 := by
  intro p hp
  have h : env54746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54745_54746 : H12AffineEnvironment.transform 4 1 env54745 = env54746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54745 == env54746) = true)

theorem identity54746 : scanCanonicalize (H12AffineFastState.compose env54746 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound54746 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54747 : List Nat := [2,4,8,0,1,1,9,4,512,5,512,4096,9,4096,1,2,4097,513,5,0,4097,1,0,2,8,0,513,4097,4097,512,4,0,4,1,4097,513]

theorem envBound54747 : H12AffineFastState.Bounded env54747 := by
  intro p hp
  have h : env54747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54746_54747 : H12AffineEnvironment.transform 9 5 env54746 = env54747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env54746 == env54747) = true)

theorem identity54747 : scanCanonicalize (H12AffineFastState.compose env54747 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54748 : List Nat := [2,0,8,0,1,1,9,0,512,1,512,4096,9,4096,1,2,4097,513,1,0,4097,1,0,2,8,0,513,4097,4097,512,0,0,0,1,4097,513]

theorem envBound54748 : H12AffineFastState.Bounded env54748 := by
  intro p hp
  have h : env54748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54747_54748 : H12AffineEnvironment.transform 1 0 env54747 = env54748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54747 == env54748) = true)

theorem identity54748 : scanCanonicalize (H12AffineFastState.compose env54748 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 3) := by decide +kernel

theorem selectedBound54748 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54749 : List Nat := [2,0,8,0,1,1,9,0,512,1,512,3,9,3,1,2,2,513,1,0,2,1,0,2,8,0,513,2,2,512,0,0,0,1,2,513]

theorem envBound54749 : H12AffineFastState.Bounded env54749 := by
  intro p hp
  have h : env54749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54748_54749 : H12AffineEnvironment.transform 11 3 env54748 = env54749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3 env54748 == env54749) = true)

theorem identity54749 : scanCanonicalize (H12AffineFastState.compose env54749 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54749 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54750 : List Nat := [2,0,3,0,1,1,2,0,512,1,512,3,2,3,1,2,2,513,1,0,2,1,0,2,3,0,513,2,2,512,0,0,0,1,2,513]

theorem envBound54750 : H12AffineFastState.Bounded env54750 := by
  intro p hp
  have h : env54750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54749_54750 : H12AffineEnvironment.transform 2 3 env54749 = env54750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54749 == env54750) = true)

def env54751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,4194304,17,98781,8328,65,4258940,5393,17664,32161,1500,4256860,256,21793,46213,74251]

theorem envBound54751 : H12AffineFastState.Bounded env54751 := by
  intro p hp
  have h : env54751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54719_54751 : H12AffineEnvironment.transform 20 4161 env54719 = env54751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54719 == env54751) = true)

theorem identity54751 : scanCanonicalize (H12AffineFastState.compose env54751 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213487) := by decide +kernel

theorem selectedBound54751 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,213487,17,98781,8328,65,245139,5393,17664,32161,1500,243123,256,21793,46213,74251]

theorem envBound54752 : H12AffineFastState.Bounded env54752 := by
  intro p hp
  have h : env54752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54751_54752 : H12AffineEnvironment.transform 21 213487 env54751 = env54752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213487 env54751 == env54752) = true)

def env54753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,213351,17,98645,8192,65,245019,5393,17664,32041,1364,243003,256,21793,46093,74251]

theorem envBound54753 : H12AffineFastState.Bounded env54753 := by
  intro p hp
  have h : env54753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54752_54753 : H12AffineEnvironment.transform 6 8 env54752 = env54753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54752 == env54753) = true)

theorem identity54753 : scanCanonicalize (H12AffineFastState.compose env54753 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54753 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54754 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179513,1024,32769,4161,201831,17,98645,8192,65,245019,5393,4096,10281,1364,243003,256,33,46093,74251]

theorem envBound54754 : H12AffineFastState.Bounded env54754 := by
  intro p hp
  have h : env54754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54753_54754 : H12AffineEnvironment.transform 13 5376 env54753 = env54754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54753 == env54754) = true)

theorem identity54754 : scanCanonicalize (H12AffineFastState.compose env54754 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54754 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env54755 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,65536,131072,171108,1024,32769,4161,201831,17,98645,349,65,236614,5393,4096,2420,1364,234598,256,33,38224,66390]

theorem envBound54755 : H12AffineFastState.Bounded env54755 := by
  intro p hp
  have h : env54755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54754_54755 : H12AffineEnvironment.transform 12 349 env54754 = env54755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54754 == env54755) = true)

theorem identity54755 : scanCanonicalize (H12AffineFastState.compose env54755 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54755 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env54756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,65536,131072,138341,1024,0,4161,201831,17,65876,349,65,203847,5393,4096,2420,1364,201831,256,33,5457,66390]

theorem envBound54756 : H12AffineFastState.Bounded env54756 := by
  intro p hp
  have h : env54756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54755_54756 : H12AffineEnvironment.transform 14 1 env54755 = env54756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54755 == env54756) = true)

theorem identity54756 : scanCanonicalize (H12AffineFastState.compose env54756 (packedSelected [0,1,3,4,5,6,7,9,12,15,19,28] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound54756 : packedSelected [0,1,3,4,5,6,7,9,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env54757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,65536,70679,67698,1024,0,4161,112,17,65876,349,65,2128,5393,4096,2420,1364,112,256,33,5457,66390]

theorem envBound54757 : H12AffineFastState.Bounded env54757 := by
  intro p hp
  have h : env54757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54756_54757 : H12AffineEnvironment.transform 16 70679 env54756 = env54757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env54756 == env54757) = true)

theorem identity54757 : scanCanonicalize (H12AffineFastState.compose env54757 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound54757 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,262,5393,2420,1024,0,4161,112,17,82,349,65,2128,5393,4096,2420,1364,112,256,33,5457,592]

theorem envBound54758 : H12AffineFastState.Bounded env54758 := by
  intro p hp
  have h : env54758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54757_54758 : H12AffineEnvironment.transform 15 262 env54757 = env54758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env54757 == env54758) = true)

theorem identity54758 : scanCanonicalize (H12AffineFastState.compose env54758 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound54758 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,349,2421,1,262,2404,2420,1024,0,3124,112,17,82,349,65,2128,2404,3189,2420,1364,112,256,33,2340,592]

theorem envBound54759 : H12AffineFastState.Bounded env54759 := by
  intro p hp
  have h : env54759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54758_54759 : H12AffineEnvironment.transform 11 3189 env54758 = env54759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env54758 == env54759) = true)

theorem identity54759 : scanCanonicalize (H12AffineFastState.compose env54759 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound54759 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env54760 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3189,41,2049,1,114,2064,2048,1024,0,3124,112,17,82,41,65,2128,2064,3189,2048,1056,112,116,33,2128,592]

theorem envBound54760 : H12AffineFastState.Bounded env54760 := by
  intro p hp
  have h : env54760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54759_54760 : H12AffineEnvironment.transform 7 116 env54759 = env54760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env54759 == env54760) = true)

def env54761 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,213350,17,98644,8193,65,245018,5393,17664,32040,1365,243002,256,21793,46092,74251]

theorem envBound54761 : H12AffineFastState.Bounded env54761 := by
  intro p hp
  have h : env54761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54752_54761 : H12AffineEnvironment.transform 6 9 env54752 = env54761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54752 == env54761) = true)

theorem identity54761 : scanCanonicalize (H12AffineFastState.compose env54761 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound54761 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138341,1024,8540,4161,213350,17,73737,8193,65,203847,5393,17664,32040,1365,201831,256,21793,5457,74251]

theorem envBound54762 : H12AffineFastState.Bounded env54762 := by
  intro p hp
  have h : env54762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54761_54762 : H12AffineEnvironment.transform 14 8541 env54761 = env54762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env54761 == env54762) = true)

theorem identity54762 : scanCanonicalize (H12AffineFastState.compose env54762 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90186) := by decide +kernel

theorem selectedBound54762 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90186,97327,1024,8540,4161,8492,17,73737,8193,65,31757,5393,17664,32040,1365,29741,256,21793,5457,74251]

theorem envBound54763 : H12AffineFastState.Bounded env54763 := by
  intro p hp
  have h : env54763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54762_54763 : H12AffineEnvironment.transform 16 90186 env54762 = env54763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90186 env54762 == env54763) = true)

theorem identity54763 : scanCanonicalize (H12AffineFastState.compose env54763 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound54763 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env54764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,65536,79130,76159,1024,8540,4161,8492,17,73737,8193,65,10589,5393,4176,10360,1365,8573,256,113,5457,74251]

theorem envBound54764 : H12AffineFastState.Bounded env54764 := by
  intro p hp
  have h : env54764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54763_54764 : H12AffineEnvironment.transform 13 5456 env54763 = env54764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env54763 == env54764) = true)

theorem identity54764 : scanCanonicalize (H12AffineFastState.compose env54764 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54764 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env54765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,80,65536,70679,67698,1024,81,4161,33,17,65796,268,65,2128,5393,4176,2421,1365,112,256,113,5457,66310]

theorem envBound54765 : H12AffineFastState.Bounded env54765 := by
  intro p hp
  have h : env54765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54764_54765 : H12AffineEnvironment.transform 12 269 env54764 = env54765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54764 == env54765) = true)

theorem identity54765 : scanCanonicalize (H12AffineFastState.compose env54765 (packedSelected [0,2,4,6,7,9,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54765 : packedSelected [0,2,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env54766 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,269,4160,80,65536,69895,67698,272,81,4161,33,17,65796,268,65,2128,4097,4176,2421,69,112,256,113,4161,66310]

theorem envBound54766 : H12AffineFastState.Bounded env54766 := by
  intro p hp
  have h : env54766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54765_54766 : H12AffineEnvironment.transform 9 272 env54765 = env54766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54765 == env54766) = true)

theorem identity54766 : scanCanonicalize (H12AffineFastState.compose env54766 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound54766 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env54767 : List Nat := [2,4,8,16,32,64,9,85,512,69,2048,4096,88,4160,80,65536,69714,67698,69,81,4161,33,17,65617,89,65,2128,4097,4176,2080,69,112,85,113,4161,66131]

theorem envBound54767 : H12AffineFastState.Bounded env54767 := by
  intro p hp
  have h : env54767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54766_54767 : H12AffineEnvironment.transform 7 85 env54766 = env54767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env54766 == env54767) = true)

theorem identity54767 : scanCanonicalize (H12AffineFastState.compose env54767 (packedSelected [0,1,2,6,7,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54767 : packedSelected [0,1,2,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env54768 : List Nat := [2,4,8,16,32,17,9,4,512,20,2048,4096,9,4113,1,65536,69635,67619,20,0,4112,33,17,65536,8,16,2049,4097,4097,2080,20,33,4,32,4112,66050]

theorem envBound54768 : H12AffineFastState.Bounded env54768 := by
  intro p hp
  have h : env54768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54767_54768 : H12AffineEnvironment.transform 5 17 env54767 = env54768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54767 == env54768) = true)

theorem identity54768 : scanCanonicalize (H12AffineFastState.compose env54768 (packedSelected [0,2,4] rootPS)) = affineNative (2^(15+1) ^^^ 4611) := by decide +kernel

theorem selectedBound54768 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env54769 : List Nat := [2,4,8,16,32,17,9,4,512,20,2048,4096,9,4113,1,4611,512,6688,20,0,4112,33,17,4611,8,16,2049,4097,4097,2080,20,33,4,32,4112,4097]

theorem envBound54769 : H12AffineFastState.Bounded env54769 := by
  intro p hp
  have h : env54769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54768_54769 : H12AffineEnvironment.transform 15 4611 env54768 = env54769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4611 env54768 == env54769) = true)

theorem identity54769 : scanCanonicalize (H12AffineFastState.compose env54769 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound54769 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env54770 : List Nat := [2,4,8,16,32,17,9,4,512,20,2048,512,9,529,1,3,512,2080,20,0,528,33,17,3,8,16,2049,513,513,2080,20,33,4,32,528,513]

theorem envBound54770 : H12AffineFastState.Bounded env54770 := by
  intro p hp
  have h : env54770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54769_54770 : H12AffineEnvironment.transform 11 512 env54769 = env54770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env54769 == env54770) = true)

theorem identity54770 : scanCanonicalize (H12AffineFastState.compose env54770 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54770 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54771 : List Nat := [2,4,8,16,16,17,9,4,512,20,2048,512,9,529,1,3,512,2064,20,0,528,17,17,3,8,16,2049,513,513,2064,20,17,4,16,528,513]

theorem envBound54771 : H12AffineFastState.Bounded env54771 := by
  intro p hp
  have h : env54771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54770_54771 : H12AffineEnvironment.transform 4 16 env54770 = env54771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54770 == env54771) = true)

theorem identity54771 : scanCanonicalize (H12AffineFastState.compose env54771 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound54771 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54772 : List Nat := [2,4,8,16,16,17,9,4,512,20,26,512,9,529,1,3,512,10,20,0,528,17,17,3,8,16,27,513,513,10,20,17,4,16,528,513]

theorem envBound54772 : H12AffineFastState.Bounded env54772 := by
  intro p hp
  have h : env54772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54771_54772 : H12AffineEnvironment.transform 10 26 env54771 = env54772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env54771 == env54772) = true)

def env54773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534881,474221,8328,65,6705549,2537696,456881,2125280,2102684,6707629,256,21792,46212,2175563]

theorem envBound54773 : H12AffineFastState.Bounded env54773 := by
  intro p hp
  have h : env54773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54669_54773 : H12AffineEnvironment.transform 23 474221 env54669 = env54773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474221 env54669 == env54773) = true)

def env54774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,2097152,4194304,2101329,98781,8328,65,6351933,2098512,17665,2125280,2102684,6349853,256,21792,46212,2175563]

theorem envBound54774 : H12AffineFastState.Bounded env54774 := by
  intro p hp
  have h : env54774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54773_54774 : H12AffineEnvironment.transform 17 179632 env54773 = env54774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env54773 == env54774) = true)

def env54775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,4194304,17,98781,8328,65,4258941,5392,17665,32160,1500,4256861,256,21792,46212,74251]

theorem envBound54775 : H12AffineFastState.Bounded env54775 := by
  intro p hp
  have h : env54775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54774_54775 : H12AffineEnvironment.transform 20 4160 env54774 = env54775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54774 == env54775) = true)

theorem identity54775 : scanCanonicalize (H12AffineFastState.compose env54775 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156133) := by decide +kernel

theorem selectedBound54775 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,156133,17,98781,8328,65,171416,5392,17665,32160,1500,169400,256,21792,46212,74251]

theorem envBound54776 : H12AffineFastState.Bounded env54776 := by
  intro p hp
  have h : env54776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54775_54776 : H12AffineEnvironment.transform 21 156133 env54775 = env54776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env54775 == env54776) = true)

def env54777 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,156013,17,98645,8192,65,171280,5392,17665,32040,1364,169264,256,21792,46092,74251]

theorem envBound54777 : H12AffineFastState.Bounded env54777 := by
  intro p hp
  have h : env54777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54776_54777 : H12AffineEnvironment.transform 6 8 env54776 = env54777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54776 == env54777) = true)

theorem identity54777 : scanCanonicalize (H12AffineFastState.compose env54777 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound54777 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env54778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,179512,1024,32769,4160,156013,17,62558,8192,65,171280,5392,17665,32040,1364,169264,256,21792,46092,22272]

theorem envBound54778 : H12AffineFastState.Bounded env54778 := by
  intro p hp
  have h : env54778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54777_54778 : H12AffineEnvironment.transform 15 29963 env54777 = env54778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env54777 == env54778) = true)

theorem identity54778 : scanCanonicalize (H12AffineFastState.compose env54778 (packedSelected [1,16,19,20,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54778 : packedSelected [1,16,19,20,28,31] rootPS < 2^1333 := by decide +kernel

def env54779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,21590,131072,171109,1024,32769,4160,147504,17,54531,349,65,171280,5392,17665,23669,1364,169264,256,21792,38225,22272]

theorem envBound54779 : H12AffineFastState.Bounded env54779 := by
  intro p hp
  have h : env54779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54778_54779 : H12AffineEnvironment.transform 12 349 env54778 = env54779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54778 == env54779) = true)

theorem identity54779 : scanCanonicalize (H12AffineFastState.compose env54779 (packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound54779 : packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env54780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21590,131072,149861,1024,21761,4160,147504,17,3,349,65,149520,5392,17665,23669,1364,147504,256,21792,16465,22272]

theorem envBound54780 : H12AffineFastState.Bounded env54780 := by
  intro p hp
  have h : env54780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54779_54780 : H12AffineEnvironment.transform 14 21760 env54779 = env54780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env54779 == env54780) = true)

theorem identity54780 : scanCanonicalize (H12AffineFastState.compose env54780 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54780 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env54781 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21760,21511,131072,149812,1024,21761,4113,147504,17,3,268,16,149520,5392,17665,23588,1285,147504,256,21792,16384,22272]

theorem envBound54781 : H12AffineFastState.Bounded env54781 := by
  intro p hp
  have h : env54781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54780_54781 : H12AffineEnvironment.transform 5 17 env54780 = env54781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54780 == env54781) = true)

theorem identity54781 : scanCanonicalize (H12AffineFastState.compose env54781 (packedSelected [1,8,10,11,14,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54781 : packedSelected [1,8,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env54782 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,16384,20496,20759,131072,149812,272,20497,4113,147504,17,3,268,16,149520,4096,16401,22836,21,147504,256,20528,16384,21008]

theorem envBound54782 : H12AffineFastState.Bounded env54782 := by
  intro p hp
  have h : env54782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54781_54782 : H12AffineEnvironment.transform 9 272 env54781 = env54782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54781 == env54782) = true)

theorem identity54782 : scanCanonicalize (H12AffineFastState.compose env54782 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound54782 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env54783 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,16384,20496,20759,4097,22837,272,20497,4113,20529,17,3,268,16,22545,4096,16401,22836,21,20529,256,20528,16384,21008]

theorem envBound54783 : H12AffineFastState.Bounded env54783 := by
  intro p hp
  have h : env54783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54782_54783 : H12AffineEnvironment.transform 16 4097 env54782 = env54783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env54782 == env54783) = true)

theorem identity54783 : scanCanonicalize (H12AffineFastState.compose env54783 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound54783 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env54784 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,4112,0,263,4097,2341,272,1,4113,33,17,3,268,16,2049,4096,4097,2340,21,33,256,32,4112,512]

theorem envBound54784 : H12AffineFastState.Bounded env54784 := by
  intro p hp
  have h : env54784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54783_54784 : H12AffineEnvironment.transform 13 4112 env54783 = env54784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env54783 == env54784) = true)

theorem identity54784 : scanCanonicalize (H12AffineFastState.compose env54784 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54785 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,40,4112,0,35,4097,2049,52,1,4113,33,17,3,40,16,2049,4096,4097,2048,21,33,36,32,4112,512]

theorem envBound54785 : H12AffineFastState.Bounded env54785 := by
  intro p hp
  have h : env54785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54784_54785 : H12AffineEnvironment.transform 7 36 env54784 = env54785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54784 == env54785) = true)

theorem identity54785 : scanCanonicalize (H12AffineFastState.compose env54785 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound54785 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54786 : List Nat := [2,4,8,16,32,17,8,36,512,52,33,4096,40,4112,0,35,4097,32,52,1,4113,33,17,3,40,16,32,4096,4097,33,21,33,36,32,4112,512]

theorem envBound54786 : H12AffineFastState.Bounded env54786 := by
  intro p hp
  have h : env54786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54785_54786 : H12AffineEnvironment.transform 10 33 env54785 = env54786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env54785 == env54786) = true)

theorem identity54786 : scanCanonicalize (H12AffineFastState.compose env54786 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 565) := by decide +kernel

theorem selectedBound54786 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54787 : List Nat := [2,4,8,16,32,17,8,36,512,52,33,565,40,549,0,35,564,32,52,1,548,33,17,3,40,16,32,565,564,33,21,33,36,32,549,512]

theorem envBound54787 : H12AffineFastState.Bounded env54787 := by
  intro p hp
  have h : env54787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54786_54787 : H12AffineEnvironment.transform 11 565 env54786 = env54787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 565 env54786 == env54787) = true)

theorem identity54787 : scanCanonicalize (H12AffineFastState.compose env54787 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54787 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54788 : List Nat := [2,4,8,16,1,17,8,5,512,21,0,532,9,516,0,2,533,1,21,1,517,0,17,3,9,16,1,532,533,0,21,0,5,1,516,512]

theorem envBound54788 : H12AffineFastState.Bounded env54788 := by
  intro p hp
  have h : env54788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54787_54788 : H12AffineEnvironment.transform 4 1 env54787 = env54788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54787 == env54788) = true)

theorem identity54788 : scanCanonicalize (H12AffineFastState.compose env54788 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound54788 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54789 : List Nat := [2,4,8,16,1,17,8,5,1,21,0,21,9,5,0,2,20,1,21,1,4,0,17,3,9,16,1,21,20,0,21,0,5,1,5,1]

theorem envBound54789 : H12AffineFastState.Bounded env54789 := by
  intro p hp
  have h : env54789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54788_54789 : H12AffineEnvironment.transform 8 1 env54788 = env54789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env54788 == env54789) = true)

theorem identity54789 : scanCanonicalize (H12AffineFastState.compose env54789 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound54789 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env54790 : List Nat := [2,4,8,4,1,5,8,5,1,1,0,1,9,5,0,2,0,1,1,1,4,0,5,3,9,4,1,1,0,0,1,0,5,1,5,1]

theorem envBound54790 : H12AffineFastState.Bounded env54790 := by
  intro p hp
  have h : env54790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54789_54790 : H12AffineEnvironment.transform 3 4 env54789 = env54790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env54789 == env54790) = true)

def env54791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156012,17,98644,8193,65,171281,5392,17665,32041,1365,169265,256,21792,46093,74251]

theorem envBound54791 : H12AffineFastState.Bounded env54791 := by
  intro p hp
  have h : env54791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54776_54791 : H12AffineEnvironment.transform 6 9 env54776 = env54791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54776 == env54791) = true)

theorem identity54791 : scanCanonicalize (H12AffineFastState.compose env54791 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound54791 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138340,1024,8540,4160,156012,17,73737,8193,65,146508,5392,17665,32041,1365,144492,256,21792,5456,74251]

theorem envBound54792 : H12AffineFastState.Bounded env54792 := by
  intro p hp
  have h : env54792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54791_54792 : H12AffineEnvironment.transform 14 8541 env54791 = env54792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env54791 == env54792) = true)

theorem identity54792 : scanCanonicalize (H12AffineFastState.compose env54792 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound54792 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env54793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8283,131072,138340,1024,8540,4160,156012,17,82,8193,65,146508,5392,17665,32041,1365,144492,256,21792,5456,592]

theorem envBound54793 : H12AffineFastState.Bounded env54793 := by
  intro p hp
  have h : env54793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54792_54793 : H12AffineEnvironment.transform 15 8283 env54792 = env54793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env54792 == env54793) = true)

theorem identity54793 : scanCanonicalize (H12AffineFastState.compose env54793 (packedSelected [0,1,3,4,7,16,20,22,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54793 : packedSelected [0,1,3,4,7,16,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env54794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,263,131072,138340,1024,0,4160,147504,17,82,349,65,138512,5392,17665,23669,1365,136496,256,21792,5456,592]

theorem envBound54794 : H12AffineFastState.Bounded env54794 := by
  intro p hp
  have h : env54794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54793_54794 : H12AffineEnvironment.transform 12 348 env54793 = env54794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54793 == env54794) = true)

theorem identity54794 : scanCanonicalize (H12AffineFastState.compose env54794 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound54794 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,263,16401,23669,1024,0,4160,33,17,82,349,65,23809,5392,17665,23669,1365,21793,256,21792,5456,592]

theorem envBound54795 : H12AffineFastState.Bounded env54795 := by
  intro p hp
  have h : env54795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54794_54795 : H12AffineEnvironment.transform 16 16401 env54794 = env54795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env54794 == env54795) = true)

theorem identity54795 : scanCanonicalize (H12AffineFastState.compose env54795 (packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound54795 : packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env54796 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,348,16384,1,263,16401,22544,101,0,4160,33,17,82,349,65,22884,4469,16740,22544,304,20804,256,20805,4405,592]

theorem envBound54796 : H12AffineFastState.Bounded env54796 := by
  intro p hp
  have h : env54796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54795_54796 : H12AffineEnvironment.transform 9 101 env54795 = env54796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env54795 == env54796) = true)

theorem identity54796 : scanCanonicalize (H12AffineFastState.compose env54796 (packedSelected [2,6,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54796 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env54797 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,16384,1,263,16401,22544,52,0,4113,33,17,3,268,16,22837,4388,16693,22544,304,20757,256,20756,4405,513]

theorem envBound54797 : H12AffineFastState.Bounded env54797 := by
  intro p hp
  have h : env54797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54796_54797 : H12AffineEnvironment.transform 5 17 env54796 = env54797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54796 == env54797) = true)

theorem identity54797 : scanCanonicalize (H12AffineFastState.compose env54797 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6965) := by decide +kernel

theorem selectedBound54797 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54798 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,6965,1,263,6948,805,52,0,4113,33,17,3,268,16,512,4388,6656,805,304,2592,256,2593,4405,513]

theorem envBound54798 : H12AffineFastState.Bounded env54798 := by
  intro p hp
  have h : env54798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54797_54798 : H12AffineEnvironment.transform 13 6965 env54797 = env54798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6965 env54797 == env54798) = true)

theorem identity54798 : scanCanonicalize (H12AffineFastState.compose env54798 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound54798 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env54799 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,529,269,2340,1,263,2357,805,52,0,512,33,17,3,268,16,512,821,2065,805,304,2592,256,2593,804,513]

theorem envBound54799 : H12AffineFastState.Bounded env54799 := by
  intro p hp
  have h : env54799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54798_54799 : H12AffineEnvironment.transform 11 529 env54798 = env54799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env54798 == env54799) = true)

theorem identity54799 : scanCanonicalize (H12AffineFastState.compose env54799 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound54799 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env54800 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,529,269,529,1,263,512,805,52,0,512,33,17,3,268,16,512,821,804,805,304,277,256,276,804,513]

theorem envBound54800 : H12AffineFastState.Bounded env54800 := by
  intro p hp
  have h : env54800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54799_54800 : H12AffineEnvironment.transform 10 821 env54799 = env54800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env54799 == env54800) = true)

theorem identity54800 : scanCanonicalize (H12AffineFastState.compose env54800 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound54800 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54801 : List Nat := [2,4,8,16,32,17,9,53,512,52,512,529,56,529,1,50,512,528,52,0,512,33,17,3,57,16,512,512,529,528,5,32,53,33,529,513]

theorem envBound54801 : H12AffineFastState.Bounded env54801 := by
  intro p hp
  have h : env54801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54800_54801 : H12AffineEnvironment.transform 7 53 env54800 = env54801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env54800 == env54801) = true)

theorem identity54801 : scanCanonicalize (H12AffineFastState.compose env54801 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54801 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54802 : List Nat := [2,4,8,1,32,0,9,36,512,37,512,512,41,512,1,35,512,513,37,0,512,33,0,3,40,1,512,512,512,513,5,32,36,33,512,513]

theorem envBound54802 : H12AffineFastState.Bounded env54802 := by
  intro p hp
  have h : env54802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54801_54802 : H12AffineEnvironment.transform 3 1 env54801 = env54802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54801 == env54802) = true)

theorem identity54802 : scanCanonicalize (H12AffineFastState.compose env54802 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound54802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54803 : List Nat := [2,4,8,1,32,0,9,36,0,37,0,0,41,0,1,35,0,1,37,0,0,33,0,3,40,1,0,0,0,1,5,32,36,33,0,1]

theorem envBound54803 : H12AffineFastState.Bounded env54803 := by
  intro p hp
  have h : env54803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54802_54803 : H12AffineEnvironment.transform 8 0 env54802 = env54803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env54802 == env54803) = true)

theorem identity54803 : scanCanonicalize (H12AffineFastState.compose env54803 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54804 : List Nat := [2,4,8,1,10,0,9,14,0,15,0,0,3,0,1,9,0,1,15,0,0,11,0,3,2,1,0,0,0,1,5,10,14,11,0,1]

theorem envBound54804 : H12AffineFastState.Bounded env54804 := by
  intro p hp
  have h : env54804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54803_54804 : H12AffineEnvironment.transform 4 10 env54803 = env54804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54803 == env54804) = true)

def env54805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,4194304,16,98781,8328,65,4258940,5393,17665,32161,1501,4256860,256,21792,46212,74250]

theorem envBound54805 : H12AffineFastState.Bounded env54805 := by
  intro p hp
  have h : env54805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54774_54805 : H12AffineEnvironment.transform 20 4161 env54774 = env54805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54774 == env54805) = true)

theorem identity54805 : scanCanonicalize (H12AffineFastState.compose env54805 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound54805 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149860,1024,29909,4161,4194304,16,95497,8328,65,4196520,5393,17665,32161,1501,4194440,256,21792,16464,74250]

theorem envBound54806 : H12AffineFastState.Bounded env54806 := by
  intro p hp
  have h : env54806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54805_54806 : H12AffineEnvironment.transform 14 29908 env54805 = env54806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env54805 == env54806) = true)

def env54807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138340,1024,8661,4161,4194304,16,73737,8328,65,4196520,5393,4097,10401,1501,4194440,256,32,5456,74250]

theorem envBound54807 : H12AffineFastState.Bounded env54807 := by
  intro p hp
  have h : env54807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54806_54807 : H12AffineEnvironment.transform 13 5376 env54806 = env54807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54806 == env54807) = true)

theorem identity54807 : scanCanonicalize (H12AffineFastState.compose env54807 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound54807 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13508,10400,1024,8661,4161,4194304,16,73737,8328,65,4196520,5393,4097,10401,1501,4194440,256,32,5456,74250]

theorem envBound54808 : H12AffineFastState.Bounded env54808 := by
  intro p hp
  have h : env54808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54807_54808 : H12AffineEnvironment.transform 16 13508 env54807 = env54808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env54807 == env54808) = true)

theorem identity54808 : scanCanonicalize (H12AffineFastState.compose env54808 (packedSelected [0,1,2,5,6,10,12,14,15,18,24,27,28,32] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54808 : packedSelected [0,1,2,5,6,10,12,14,15,18,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env54809 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,65536,13460,10400,1024,8581,4113,4194304,16,73737,8328,17,4196520,5393,4097,10401,1421,4194440,256,32,5376,74250]

theorem envBound54809 : H12AffineFastState.Bounded env54809 := by
  intro p hp
  have h : env54809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54808_54809 : H12AffineEnvironment.transform 5 16 env54808 = env54809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54808 == env54809) = true)

theorem identity54809 : scanCanonicalize (H12AffineFastState.compose env54809 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound54809 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env54810 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8580,262,13460,10400,1024,8581,4113,4194304,16,8463,8328,17,4196520,5393,4097,10401,1421,4194440,256,32,5376,8972]

theorem envBound54810 : H12AffineFastState.Bounded env54810 := by
  intro p hp
  have h : env54810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54809_54810 : H12AffineEnvironment.transform 15 262 env54809 = env54810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env54809 == env54810) = true)

theorem identity54810 : scanCanonicalize (H12AffineFastState.compose env54810 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54810 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54811 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,137,262,5529,2477,1024,136,4113,4194304,16,2,389,17,4196520,5393,4097,2476,1421,4194440,256,32,5376,513]

theorem envBound54811 : H12AffineFastState.Bounded env54811 := by
  intro p hp
  have h : env54811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54810_54811 : H12AffineEnvironment.transform 12 269 env54810 = env54811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54810 == env54811) = true)

theorem identity54811 : scanCanonicalize (H12AffineFastState.compose env54811 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound54811 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env54812 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,137,262,5529,2477,1024,136,4113,169,16,2,389,17,2049,5393,4097,2476,1421,33,256,32,5376,513]

theorem envBound54812 : H12AffineFastState.Bounded env54812 := by
  intro p hp
  have h : env54812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54811_54812 : H12AffineEnvironment.transform 21 169 env54811 = env54812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env54811 == env54812) = true)

theorem identity54812 : scanCanonicalize (H12AffineFastState.compose env54812 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound54812 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env54813 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,4096,269,4541,137,262,4388,2477,189,136,4113,169,16,2,389,17,2049,4524,4097,2476,304,33,256,32,4541,513]

theorem envBound54813 : H12AffineFastState.Bounded env54813 := by
  intro p hp
  have h : env54813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54812_54813 : H12AffineEnvironment.transform 9 189 env54812 = env54813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env54812 == env54813) = true)

theorem identity54813 : scanCanonicalize (H12AffineFastState.compose env54813 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound54813 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env54814 : List Nat := [2,4,8,16,32,16,128,173,512,189,2048,4096,160,4112,137,171,4233,2048,189,136,4113,169,16,2,40,17,2049,4097,4097,2049,157,33,173,32,4112,513]

theorem envBound54814 : H12AffineFastState.Bounded env54814 := by
  intro p hp
  have h : env54814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54813_54814 : H12AffineEnvironment.transform 7 173 env54813 = env54814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54813 == env54814) = true)

theorem identity54814 : scanCanonicalize (H12AffineFastState.compose env54814 (packedSelected [11,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54814 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env54815 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,40,4112,1,35,4097,2048,53,0,4113,33,16,2,40,17,2049,4097,4097,2049,21,33,37,32,4112,513]

theorem envBound54815 : H12AffineFastState.Bounded env54815 := by
  intro p hp
  have h : env54815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54814_54815 : H12AffineEnvironment.transform 6 8 env54814 = env54815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54814 == env54815) = true)

theorem identity54815 : scanCanonicalize (H12AffineFastState.compose env54815 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound54815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54816 : List Nat := [2,4,8,16,32,16,8,37,5,53,2048,4096,40,4112,1,35,4097,2048,53,0,4113,33,16,2,40,17,2049,4097,4097,2049,21,33,37,32,4112,4]

theorem envBound54816 : H12AffineFastState.Bounded env54816 := by
  intro p hp
  have h : env54816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54815_54816 : H12AffineEnvironment.transform 8 5 env54815 = env54816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env54815 == env54816) = true)

theorem identity54816 : scanCanonicalize (H12AffineFastState.compose env54816 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 6) := by decide +kernel

theorem selectedBound54816 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54817 : List Nat := [2,4,8,16,32,16,8,37,5,53,2048,6,40,22,1,35,7,2048,53,0,23,33,16,2,40,17,2049,7,7,2049,21,33,37,32,22,4]

theorem envBound54817 : H12AffineFastState.Bounded env54817 := by
  intro p hp
  have h : env54817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54816_54817 : H12AffineEnvironment.transform 11 6 env54816 = env54817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 6 env54816 == env54817) = true)

def env54818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138341,1024,8660,4161,4194304,16,73736,8328,65,4196520,5393,4096,10400,1501,4194440,256,33,5457,74250]

theorem envBound54818 : H12AffineFastState.Bounded env54818 := by
  intro p hp
  have h : env54818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54806_54818 : H12AffineEnvironment.transform 13 5377 env54806 = env54818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54806 == env54818) = true)

theorem identity54818 : scanCanonicalize (H12AffineFastState.compose env54818 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound54818 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,10280,1024,8660,4161,4194304,16,73736,8328,65,4196520,5393,4096,10400,1501,4194440,256,33,5457,74250]

theorem envBound54819 : H12AffineFastState.Bounded env54819 := by
  intro p hp
  have h : env54819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54818_54819 : H12AffineEnvironment.transform 16 13389 env54818 = env54819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env54818 == env54819) = true)

theorem identity54819 : scanCanonicalize (H12AffineFastState.compose env54819 (packedSelected [2,3,5,6,7,9,10,16,22,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound54819 : packedSelected [2,3,5,6,7,9,10,16,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env54820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,0,65536,5528,2557,1024,1,4161,4194304,16,66013,349,65,4196520,5393,4096,2421,1501,4194440,256,33,5457,66527]

theorem envBound54820 : H12AffineFastState.Bounded env54820 := by
  intro p hp
  have h : env54820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54819_54820 : H12AffineEnvironment.transform 12 469 env54819 = env54820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env54819 == env54820) = true)

theorem identity54820 : scanCanonicalize (H12AffineFastState.compose env54820 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound54820 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env54821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,0,478,5528,2557,1024,1,4161,4194304,16,3,349,65,4196520,5393,4096,2421,1501,4194440,256,33,5457,513]

theorem envBound54821 : H12AffineFastState.Bounded env54821 := by
  intro p hp
  have h : env54821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54820_54821 : H12AffineEnvironment.transform 15 478 env54820 = env54821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env54820 == env54821) = true)

theorem identity54821 : scanCanonicalize (H12AffineFastState.compose env54821 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound54821 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,0,478,5528,2557,1024,1,4161,113,16,3,349,65,2265,5393,4096,2421,1501,249,256,33,5457,513]

theorem envBound54822 : H12AffineFastState.Bounded env54822 := by
  intro p hp
  have h : env54822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54821_54822 : H12AffineEnvironment.transform 21 113 env54821 = env54822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env54821 == env54822) = true)

theorem identity54822 : scanCanonicalize (H12AffineFastState.compose env54822 (packedSelected [0,4,7,9,11,14,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54822 : packedSelected [0,4,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env54823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1024,1,4161,113,16,3,349,65,2129,5393,4096,2421,1365,113,256,33,5457,513]

theorem envBound54823 : H12AffineFastState.Bounded env54823 := by
  intro p hp
  have h : env54823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54822_54823 : H12AffineEnvironment.transform 6 8 env54822 = env54823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54822 == env54823) = true)

def env54824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,2097152,4194304,2101328,98780,8328,65,6351932,2098513,17664,2125280,2102684,6349852,256,21792,46212,2175563]

theorem envBound54824 : H12AffineFastState.Bounded env54824 := by
  intro p hp
  have h : env54824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54773_54824 : H12AffineEnvironment.transform 17 179633 env54773 = env54824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env54773 == env54824) = true)

def env54825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,4194304,16,98780,8328,65,4258940,5393,17664,32160,1500,4256860,256,21792,46212,74251]

theorem envBound54825 : H12AffineFastState.Bounded env54825 := by
  intro p hp
  have h : env54825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54824_54825 : H12AffineEnvironment.transform 20 4160 env54824 = env54825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54824 == env54825) = true)

def env54826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,16,98644,8192,65,4258940,5393,17664,32040,1364,4256860,256,21792,46092,74251]

theorem envBound54826 : H12AffineFastState.Bounded env54826 := by
  intro p hp
  have h : env54826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54825_54826 : H12AffineEnvironment.transform 6 8 env54825 = env54826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54825 == env54826) = true)

theorem identity54826 : scanCanonicalize (H12AffineFastState.compose env54826 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound54826 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4160,4194304,16,98644,8192,65,4258940,5393,17664,32040,1364,4256860,256,21792,46092,74251]

theorem envBound54827 : H12AffineFastState.Bounded env54827 := by
  intro p hp
  have h : env54827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54826_54827 : H12AffineEnvironment.transform 16 38161 env54826 = env54827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env54826 == env54827) = true)

theorem identity54827 : scanCanonicalize (H12AffineFastState.compose env54827 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound54827 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env54828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4160,33,16,98644,8192,65,64605,5393,17664,32040,1364,62589,256,21792,46092,74251]

theorem envBound54828 : H12AffineFastState.Bounded env54828 := by
  intro p hp
  have h : env54828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54827_54828 : H12AffineEnvironment.transform 21 33 env54827 = env54828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env54827 == env54828) = true)

theorem identity54828 : scanCanonicalize (H12AffineFastState.compose env54828 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54828 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env54829 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10280,1024,32769,4160,33,16,98644,8192,65,43356,5393,4097,10281,1364,41340,256,33,46092,74251]

theorem envBound54829 : H12AffineFastState.Bounded env54829 := by
  intro p hp
  have h : env54829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54828_54829 : H12AffineEnvironment.transform 13 5377 env54828 = env54829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54828 == env54829) = true)

theorem identity54829 : scanCanonicalize (H12AffineFastState.compose env54829 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound54829 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env54830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,40971,38161,10280,1024,32769,4160,33,16,8543,8192,65,43356,5393,4097,10281,1364,41340,256,33,46092,33280]

theorem envBound54830 : H12AffineFastState.Bounded env54830 := by
  intro p hp
  have h : env54830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54829_54830 : H12AffineEnvironment.transform 15 40971 env54829 = env54830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env54829 == env54830) = true)

theorem identity54830 : scanCanonicalize (H12AffineFastState.compose env54830 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54830 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env54831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8202,5392,10280,1024,0,4160,33,16,8543,8192,65,10589,5393,4097,10281,1364,8573,256,33,13325,513]

theorem envBound54831 : H12AffineFastState.Bounded env54831 := by
  intro p hp
  have h : env54831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54830_54831 : H12AffineEnvironment.transform 14 1 env54830 = env54831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54830 == env54831) = true)

theorem identity54831 : scanCanonicalize (H12AffineFastState.compose env54831 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54831 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5392,2420,1024,0,4160,33,16,3,348,65,2049,5393,4097,2421,1364,33,256,33,5457,513]

theorem envBound54832 : H12AffineFastState.Bounded env54832 := by
  intro p hp
  have h : env54832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54831_54832 : H12AffineEnvironment.transform 12 348 env54831 = env54832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54831 == env54832) = true)

theorem identity54832 : scanCanonicalize (H12AffineFastState.compose env54832 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54832 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54833 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,262,5392,2340,1024,0,4112,33,16,3,268,17,2049,5393,4097,2341,1284,33,256,33,5377,513]

theorem envBound54833 : H12AffineFastState.Bounded env54833 := by
  intro p hp
  have h : env54833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54832_54833 : H12AffineEnvironment.transform 5 16 env54832 = env54833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54832 == env54833) = true)

theorem identity54833 : scanCanonicalize (H12AffineFastState.compose env54833 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound54833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54834 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1312,268,33,1,262,48,2340,1024,0,1328,33,16,3,268,17,2049,49,1313,2341,1284,33,256,33,33,513]

theorem envBound54834 : H12AffineFastState.Bounded env54834 := by
  intro p hp
  have h : env54834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54833_54834 : H12AffineEnvironment.transform 11 1312 env54833 = env54834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env54833 == env54834) = true)

theorem identity54834 : scanCanonicalize (H12AffineFastState.compose env54834 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound54834 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54835 : List Nat := [2,4,8,16,32,16,8,256,512,1024,804,1312,268,33,1,262,48,512,1024,0,1328,33,16,3,268,17,805,49,1313,513,1284,33,256,33,33,513]

theorem envBound54835 : H12AffineFastState.Bounded env54835 := by
  intro p hp
  have h : env54835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54834_54835 : H12AffineEnvironment.transform 10 804 env54834 = env54835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env54834 == env54835) = true)

theorem identity54835 : scanCanonicalize (H12AffineFastState.compose env54835 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound54835 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54836 : List Nat := [2,4,8,16,32,16,8,256,512,769,804,545,268,33,1,262,48,512,769,0,561,33,16,3,268,17,805,49,544,513,517,33,256,33,33,513]

theorem envBound54836 : H12AffineFastState.Bounded env54836 := by
  intro p hp
  have h : env54836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54835_54836 : H12AffineEnvironment.transform 9 769 env54835 = env54836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env54835 == env54836) = true)

theorem identity54836 : scanCanonicalize (H12AffineFastState.compose env54836 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54836 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54837 : List Nat := [2,4,8,16,32,16,8,256,16,273,308,49,268,33,1,262,48,16,273,0,33,33,16,3,268,17,309,49,48,17,21,33,256,33,33,17]

theorem envBound54837 : H12AffineFastState.Bounded env54837 := by
  intro p hp
  have h : env54837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54836_54837 : H12AffineEnvironment.transform 8 16 env54836 = env54837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54836 == env54837) = true)

theorem identity54837 : scanCanonicalize (H12AffineFastState.compose env54837 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54837 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54838 : List Nat := [2,4,8,16,32,16,8,4,16,21,48,49,8,33,1,2,48,16,21,0,33,33,16,3,8,17,49,49,48,17,21,33,4,33,33,17]

theorem envBound54838 : H12AffineFastState.Bounded env54838 := by
  intro p hp
  have h : env54838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54837_54838 : H12AffineEnvironment.transform 7 4 env54837 = env54838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54837 == env54838) = true)

theorem identity54838 : scanCanonicalize (H12AffineFastState.compose env54838 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54838 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54839 : List Nat := [2,4,8,16,16,16,8,4,16,21,0,1,8,17,1,2,0,16,21,0,17,17,16,3,8,17,1,1,0,17,21,17,4,17,17,17]

theorem envBound54839 : H12AffineFastState.Bounded env54839 := by
  intro p hp
  have h : env54839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54838_54839 : H12AffineEnvironment.transform 4 16 env54838 = env54839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54838 == env54839) = true)

theorem identity54839 : scanCanonicalize (H12AffineFastState.compose env54839 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54839 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54840 : List Nat := [2,4,3,16,16,16,3,4,16,21,0,1,3,17,1,2,0,16,21,0,17,17,16,3,3,17,1,1,0,17,21,17,4,17,17,17]

theorem envBound54840 : H12AffineFastState.Bounded env54840 := by
  intro p hp
  have h : env54840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54839_54840 : H12AffineEnvironment.transform 2 3 env54839 = env54840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54839 == env54840) = true)

def env54841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,16,98645,8193,65,4258940,5393,17664,32041,1365,4256860,256,21792,46093,74251]

theorem envBound54841 : H12AffineFastState.Bounded env54841 := by
  intro p hp
  have h : env54841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54825_54841 : H12AffineEnvironment.transform 6 9 env54825 = env54841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54825 == env54841) = true)

theorem identity54841 : scanCanonicalize (H12AffineFastState.compose env54841 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound54841 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,35188,1024,32769,4160,4194304,16,98645,8193,65,4258940,5393,17664,32041,1365,4256860,256,21792,46093,74251]

theorem envBound54842 : H12AffineFastState.Bounded env54842 := by
  intro p hp
  have h : env54842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54841_54842 : H12AffineEnvironment.transform 16 13388 env54841 = env54842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env54841 == env54842) = true)

theorem identity54842 : scanCanonicalize (H12AffineFastState.compose env54842 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound54842 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env54843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,13388,35188,1024,32769,4160,4194304,16,98645,8193,65,4229153,5393,12637,2420,1365,4227073,256,8573,46093,74251]

theorem envBound54843 : H12AffineFastState.Bounded env54843 := by
  intro p hp
  have h : env54843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54842_54843 : H12AffineEnvironment.transform 13 13405 env54842 = env54843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env54842 == env54843) = true)

theorem identity54843 : scanCanonicalize (H12AffineFastState.compose env54843 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54843 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8202,13388,35188,1024,32769,4160,4194304,16,41311,8193,65,4229153,5393,12637,2420,1365,4227073,256,8573,46093,513]

theorem envBound54844 : H12AffineFastState.Bounded env54844 := by
  intro p hp
  have h : env54844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54843_54844 : H12AffineEnvironment.transform 15 8202 env54843 = env54844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54843 == env54844) = true)

theorem identity54844 : scanCanonicalize (H12AffineFastState.compose env54844 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound54844 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env54845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,9292,8202,13388,11576,1024,9293,4160,4194304,16,1299,8193,65,4205677,5393,12637,2420,1365,4203597,256,8573,4161,513]

theorem envBound54845 : H12AffineFastState.Bounded env54845 := by
  intro p hp
  have h : env54845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54844_54845 : H12AffineEnvironment.transform 14 9292 env54844 = env54845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env54844 == env54845) = true)

theorem identity54845 : scanCanonicalize (H12AffineFastState.compose env54845 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 5417) := by decide +kernel

theorem selectedBound54845 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env54846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5417,372,4453,5411,357,6161,1024,4452,4160,4194304,16,1299,5416,65,4200772,5393,1140,2420,1365,4198756,256,5204,4161,513]

theorem envBound54846 : H12AffineFastState.Bounded env54846 := by
  intro p hp
  have h : env54846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54845_54846 : H12AffineEnvironment.transform 12 5417 env54845 = env54846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5417 env54845 == env54846) = true)

theorem identity54846 : scanCanonicalize (H12AffineFastState.compose env54846 (packedSelected [0,27] rootPS)) = affineNative (2^(21+1) ^^^ 1328) := by decide +kernel

theorem selectedBound54846 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env54847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5417,372,4453,5411,357,6161,1024,4452,4160,1328,16,1299,5416,65,7284,5393,1140,2420,1365,5204,256,5204,4161,513]

theorem envBound54847 : H12AffineFastState.Bounded env54847 := by
  intro p hp
  have h : env54847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54846_54847 : H12AffineEnvironment.transform 21 1328 env54846 = env54847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1328 env54846 == env54847) = true)

def env54848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,4194304,17,98780,8328,65,4258941,5392,17664,32161,1501,4256861,256,21792,46212,74250]

theorem envBound54848 : H12AffineFastState.Bounded env54848 := by
  intro p hp
  have h : env54848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54824_54848 : H12AffineEnvironment.transform 20 4161 env54824 = env54848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54824 == env54848) = true)

theorem identity54848 : scanCanonicalize (H12AffineFastState.compose env54848 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169264) := by decide +kernel

theorem selectedBound54848 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,169264,17,98780,8328,65,158029,5392,17664,32161,1501,156013,256,21792,46212,74250]

theorem envBound54849 : H12AffineFastState.Bounded env54849 := by
  intro p hp
  have h : env54849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54848_54849 : H12AffineEnvironment.transform 21 169264 env54848 = env54849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env54848 == env54849) = true)

theorem identity54849 : scanCanonicalize (H12AffineFastState.compose env54849 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54849 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179633,1024,32769,4161,169264,17,41431,8328,65,158029,5392,17664,32161,1501,156013,256,21792,46212,513]

theorem envBound54850 : H12AffineFastState.Bounded env54850 := by
  intro p hp
  have h : env54850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54849_54850 : H12AffineEnvironment.transform 15 8203 env54849 = env54850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54849 == env54850) = true)

theorem identity54850 : scanCanonicalize (H12AffineFastState.compose env54850 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound54850 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,64929,1024,32769,4161,54560,17,41431,8328,65,10589,5392,17664,32161,1501,8573,256,21792,46212,513]

theorem envBound54851 : H12AffineFastState.Bounded env54851 := by
  intro p hp
  have h : env54851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54850_54851 : H12AffineEnvironment.transform 16 16400 env54850 = env54851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env54850 == env54851) = true)

theorem identity54851 : scanCanonicalize (H12AffineFastState.compose env54851 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound54851 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env54852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,16400,2477,1024,29709,4161,8492,17,21979,8328,65,10589,5392,17664,32161,1501,8573,256,21792,16520,513]

theorem envBound54852 : H12AffineFastState.Bounded env54852 := by
  intro p hp
  have h : env54852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54851_54852 : H12AffineEnvironment.transform 14 29708 env54851 = env54852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env54851 == env54852) = true)

def env54853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,16384,20924,1467,16400,2477,1024,20925,4161,1180,17,21979,1336,65,3309,5392,17664,22545,1501,1229,256,21792,16520,513]

theorem envBound54853 : H12AffineFastState.Bounded env54853 := by
  intro p hp
  have h : env54853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54852_54853 : H12AffineEnvironment.transform 12 1456 env54852 = env54853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env54852 == env54853) = true)

theorem identity54853 : scanCanonicalize (H12AffineFastState.compose env54853 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound54853 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,5236,1480,1467,5220,2477,1024,1481,4161,1180,17,431,1336,65,3309,5392,4468,3173,1501,1229,256,340,5372,513]

theorem envBound54854 : H12AffineFastState.Bounded env54854 := by
  intro p hp
  have h : env54854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54853_54854 : H12AffineEnvironment.transform 13 5236 env54853 = env54854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env54853 == env54854) = true)

theorem identity54854 : scanCanonicalize (H12AffineFastState.compose env54854 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54854 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env54855 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,1221,5236,1213,1230,5220,2264,1024,1212,4161,1180,17,218,1101,65,3309,5221,4097,3173,1192,1229,117,33,5372,513]

theorem envBound54855 : H12AffineFastState.Bounded env54855 := by
  intro p hp
  have h : env54855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54854_54855 : H12AffineEnvironment.transform 7 117 env54854 = env54855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54854 == env54855) = true)

theorem identity54855 : scanCanonicalize (H12AffineFastState.compose env54855 (packedSelected [3,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound54855 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env54856 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,1053,5236,1125,1046,5220,2048,1024,1124,4161,1092,17,2,1101,65,3125,5221,4097,3173,1136,1045,117,33,5156,513]

theorem envBound54856 : H12AffineFastState.Bounded env54856 := by
  intro p hp
  have h : env54856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54855_54856 : H12AffineEnvironment.transform 6 88 env54855 = env54856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env54855 == env54856) = true)

theorem identity54856 : scanCanonicalize (H12AffineFastState.compose env54856 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54856 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env54857 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,1053,5156,1077,1046,5172,2048,1024,1076,4113,1044,17,2,1053,17,3125,5173,4097,3125,1056,1045,37,33,5156,513]

theorem envBound54857 : H12AffineFastState.Bounded env54857 := by
  intro p hp
  have h : env54857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54856_54857 : H12AffineEnvironment.transform 5 16 env54856 = env54857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54856 == env54857) = true)

theorem identity54857 : scanCanonicalize (H12AffineFastState.compose env54857 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54857 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54858 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,40,4113,0,35,4097,2048,53,1,4113,33,17,2,40,17,2048,4096,4097,2048,21,32,37,33,4113,513]

theorem envBound54858 : H12AffineFastState.Bounded env54858 := by
  intro p hp
  have h : env54858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54857_54858 : H12AffineEnvironment.transform 9 53 env54857 = env54858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54857 == env54858) = true)

theorem identity54858 : scanCanonicalize (H12AffineFastState.compose env54858 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound54858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54859 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,4096,40,4113,0,35,4097,32,53,1,4113,33,17,2,40,17,32,4096,4097,32,21,32,37,33,4113,513]

theorem envBound54859 : H12AffineFastState.Bounded env54859 := by
  intro p hp
  have h : env54859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54858_54859 : H12AffineEnvironment.transform 10 32 env54858 = env54859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env54858 == env54859) = true)

def env54860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,16384,20925,1466,16400,2477,1024,20924,4161,1181,17,21979,1337,65,3308,5392,17664,22544,1501,1228,256,21792,16520,513]

theorem envBound54860 : H12AffineFastState.Bounded env54860 := by
  intro p hp
  have h : env54860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54852_54860 : H12AffineEnvironment.transform 12 1457 env54852 = env54860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env54852 == env54860) = true)

theorem identity54860 : scanCanonicalize (H12AffineFastState.compose env54860 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound54860 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54861 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,1052,16384,20496,1047,16400,2048,1024,20497,4161,1181,17,21622,1172,65,3308,5309,17581,22544,1136,1228,173,21645,16520,513]

theorem envBound54861 : H12AffineFastState.Bounded env54861 := by
  intro p hp
  have h : env54861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54860_54861 : H12AffineEnvironment.transform 7 173 env54860 = env54861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54860 == env54861) = true)

theorem identity54861 : scanCanonicalize (H12AffineFastState.compose env54861 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound54861 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env54862 : List Nat := [2,4,8,16,32,64,128,173,512,100,2048,4096,120,16384,20496,115,16400,2048,100,20497,4161,249,17,20498,240,65,2184,4313,16585,22544,20,168,173,20713,16520,513]

theorem envBound54862 : H12AffineFastState.Bounded env54862 := by
  intro p hp
  have h : env54862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54861_54862 : H12AffineEnvironment.transform 9 100 env54861 = env54862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env54861 == env54862) = true)

theorem identity54862 : scanCanonicalize (H12AffineFastState.compose env54862 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound54862 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54863 : List Nat := [2,4,8,16,32,64,128,173,512,100,2048,4096,120,4248,136,115,4232,2048,100,137,4161,249,17,138,240,65,2184,4313,4177,2184,20,168,173,113,4112,513]

theorem envBound54863 : H12AffineFastState.Bounded env54863 := by
  intro p hp
  have h : env54863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54862_54863 : H12AffineEnvironment.transform 13 4248 env54862 = env54863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env54862 == env54863) = true)

theorem identity54863 : scanCanonicalize (H12AffineFastState.compose env54863 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound54863 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54864 : List Nat := [2,4,8,16,32,64,88,117,512,100,2048,4096,120,4160,80,115,4176,2048,100,81,4161,33,17,82,40,65,2128,4097,4177,2128,20,112,117,113,4112,513]

theorem envBound54864 : H12AffineFastState.Bounded env54864 := by
  intro p hp
  have h : env54864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54863_54864 : H12AffineEnvironment.transform 6 88 env54863 = env54864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env54863 == env54864) = true)

def env54865 : List Nat := [2,4,8,16,32,64,88,117,512,100,96,4096,120,4160,80,115,4176,96,100,81,4161,33,17,82,40,65,48,4097,4177,48,20,112,117,113,4112,513]

theorem envBound54865 : H12AffineFastState.Bounded env54865 := by
  intro p hp
  have h : env54865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54864_54865 : H12AffineEnvironment.transform 10 96 env54864 = env54865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env54864 == env54865) = true)

theorem identity54865 : scanCanonicalize (H12AffineFastState.compose env54865 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound54865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54866 : List Nat := [2,4,8,16,32,64,88,117,512,100,96,32,120,96,80,115,112,96,100,81,97,33,17,82,40,65,48,33,113,48,20,112,117,113,48,513]

theorem envBound54866 : H12AffineFastState.Bounded env54866 := by
  intro p hp
  have h : env54866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54865_54866 : H12AffineEnvironment.transform 11 32 env54865 = env54866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env54865 == env54866) = true)

def env54867 : List Nat := [2,4,8,16,32,16,8,37,512,52,48,32,40,48,0,35,32,48,52,1,49,33,17,2,40,17,48,33,33,48,20,32,37,33,48,513]

theorem envBound54867 : H12AffineFastState.Bounded env54867 := by
  intro p hp
  have h : env54867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54866_54867 : H12AffineEnvironment.transform 5 16 env54866 = env54867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54866 == env54867) = true)

theorem identity54867 : scanCanonicalize (H12AffineFastState.compose env54867 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound54867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54868 : List Nat := [2,4,8,16,32,16,8,37,58,52,48,32,40,48,0,35,32,48,52,1,49,33,17,2,40,17,48,33,33,48,20,32,37,33,48,59]

theorem envBound54868 : H12AffineFastState.Bounded env54868 := by
  intro p hp
  have h : env54868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54867_54868 : H12AffineEnvironment.transform 8 58 env54867 = env54868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env54867 == env54868) = true)

def leafEnv54868 : List Nat := [2,4,8,16,32,16,8,37,58,52,48,32,40,48,0,35,32,48,52,1,49,33,17,2,20,40,1,17,48,33,33,48,20,32,37,33,4,35,48,59,1,49,0]

def active54868 : List Nat := [0,1,2,3,4]

def tree54868 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54868 : H12WitnessSearch.Good tree54868 := H12GlobalWitnessIndex.good

theorem leafIdentity54868 : H12AffineFastState.composeSystem env54868 rootObs = leafEnv54868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54868 rootObs == leafEnv54868) = true)

theorem terminalChecked54868 : H12PackedTerminal.terminalCheckFast leafEnv54868 active54868 tree54868 = true := by decide +kernel

def env54869 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,32,41,49,1,34,33,49,53,0,48,33,17,3,40,16,48,33,32,48,20,33,36,32,48,513]

theorem envBound54869 : H12AffineFastState.Bounded env54869 := by
  intro p hp
  have h : env54869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54866_54869 : H12AffineEnvironment.transform 5 17 env54866 = env54869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54866 == env54869) = true)

def leafEnv54869 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,32,41,49,1,34,33,49,53,0,48,33,17,3,20,40,1,16,48,33,32,48,20,33,36,32,4,35,48,513,1,49,0]

def active54869 : List Nat := [0,1,2,3,4,8]

def tree54869 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54869 : H12WitnessSearch.Good tree54869 := H12GlobalWitnessIndex.good

theorem leafIdentity54869 : H12AffineFastState.composeSystem env54869 rootObs = leafEnv54869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54869 rootObs == leafEnv54869) = true)

theorem terminalChecked54869 : H12PackedTerminal.terminalCheckFast leafEnv54869 active54869 tree54869 = true := by decide +kernel

def env54870 : List Nat := [2,4,8,16,32,64,88,117,512,100,97,4096,120,4160,80,115,4176,97,100,81,4161,33,17,82,40,65,49,4097,4177,49,20,112,117,113,4112,513]

theorem envBound54870 : H12AffineFastState.Bounded env54870 := by
  intro p hp
  have h : env54870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54864_54870 : H12AffineEnvironment.transform 10 97 env54864 = env54870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env54864 == env54870) = true)

theorem identity54870 : scanCanonicalize (H12AffineFastState.compose env54870 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound54870 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54871 : List Nat := [2,4,8,16,32,64,88,117,512,100,97,113,120,49,80,115,33,97,100,81,48,33,17,82,40,65,49,112,32,49,20,112,117,113,97,513]

theorem envBound54871 : H12AffineFastState.Bounded env54871 := by
  intro p hp
  have h : env54871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54870_54871 : H12AffineEnvironment.transform 11 113 env54870 = env54871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env54870 == env54871) = true)

theorem identity54871 : scanCanonicalize (H12AffineFastState.compose env54871 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54871 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54872 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,33,40,49,0,35,33,49,52,1,48,33,17,2,40,17,49,32,32,49,20,32,37,33,49,513]

theorem envBound54872 : H12AffineFastState.Bounded env54872 := by
  intro p hp
  have h : env54872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54871_54872 : H12AffineEnvironment.transform 5 16 env54871 = env54872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54871 == env54872) = true)

theorem identity54872 : scanCanonicalize (H12AffineFastState.compose env54872 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound54872 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54873 : List Nat := [2,4,8,16,32,16,8,37,59,52,49,33,40,49,0,35,33,49,52,1,48,33,17,2,40,17,49,32,32,49,20,32,37,33,49,58]

theorem envBound54873 : H12AffineFastState.Bounded env54873 := by
  intro p hp
  have h : env54873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54872_54873 : H12AffineEnvironment.transform 8 59 env54872 = env54873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env54872 == env54873) = true)

def leafEnv54873 : List Nat := [2,4,8,16,32,16,8,37,59,52,49,33,40,49,0,35,33,49,52,1,48,33,17,2,20,40,1,17,49,32,32,49,20,32,37,33,4,35,49,58,1,48,0]

def active54873 : List Nat := [0,1,2,3,4]

def tree54873 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54873 : H12WitnessSearch.Good tree54873 := H12GlobalWitnessIndex.good

theorem leafIdentity54873 : H12AffineFastState.composeSystem env54873 rootObs = leafEnv54873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54873 rootObs == leafEnv54873) = true)

theorem terminalChecked54873 : H12PackedTerminal.terminalCheckFast leafEnv54873 active54873 tree54873 = true := by decide +kernel

def env54874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound54874 : H12AffineFastState.Bounded env54874 := by
  intro p hp
  have h : env54874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54667_54874 : H12AffineEnvironment.transform 18 1025 env54667 = env54874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env54667 == env54874) = true)

theorem identity54874 : scanCanonicalize (H12AffineFastState.compose env54874 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2444640) := by decide +kernel

theorem selectedBound54874 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2444640,8328,65,14847328,313836,10507600,8830976,10799472,4466848,257,8686029,8677480,10874534]

theorem envBound54875 : H12AffineFastState.Bounded env54875 := by
  intro p hp
  have h : env54875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54874_54875 : H12AffineEnvironment.transform 23 2444640 env54874 = env54875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444640 env54874 == env54875) = true)

def env54876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318700,2444640,8328,65,6705548,313836,2394556,138476,2102684,4466848,257,21793,46212,2175562]

theorem envBound54876 : H12AffineFastState.Bounded env54876 := by
  intro p hp
  have h : env54876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54875_54876 : H12AffineEnvironment.transform 22 318700 env54875 = env54876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318700 env54875 == env54876) = true)

def env54877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318700,466224,8328,65,4456924,313836,449004,138476,148940,4466848,257,21793,46212,221722]

theorem envBound54877 : H12AffineFastState.Bounded env54877 := by
  intro p hp
  have h : env54877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54876_54877 : H12AffineEnvironment.transform 20 151632 env54876 = env54877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env54876 == env54877) = true)

theorem identity54877 : scanCanonicalize (H12AffineFastState.compose env54877 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound54877 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env54878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77899,4194304,318700,294187,8328,65,4456924,313836,375287,97527,75223,4466848,257,21793,46212,513]

theorem envBound54878 : H12AffineFastState.Bounded env54878 := by
  intro p hp
  have h : env54878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54877_54878 : H12AffineEnvironment.transform 16 90139 env54877 = env54878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env54877 == env54878) = true)

def env54879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,262144,1025,29909,77899,4194304,272440,294187,8328,65,4456924,277816,347427,97527,75223,4466848,257,21793,16464,513]

theorem envBound54879 : H12AffineFastState.Bounded env54879 := by
  intro p hp
  have h : env54879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54878_54879 : H12AffineEnvironment.transform 14 29908 env54878 = env54879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env54878 == env54879) = true)

def env54880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,262144,1025,29909,77899,272512,272440,294187,8328,65,10588,277816,347427,97527,75223,32,257,21793,16464,513]

theorem envBound54880 : H12AffineFastState.Bounded env54880 := by
  intro p hp
  have h : env54880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54879_54880 : H12AffineEnvironment.transform 21 272512 env54879 = env54880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54879 == env54880) = true)

theorem identity54880 : scanCanonicalize (H12AffineFastState.compose env54880 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54880 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,16401,262144,1025,29909,4161,272512,272440,294187,8328,65,10588,277816,290089,23805,1501,32,257,21793,16464,513]

theorem envBound54881 : H12AffineFastState.Bounded env54881 := by
  intro p hp
  have h : env54881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54880_54881 : H12AffineEnvironment.transform 15 8202 env54880 = env54881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54880 == env54881) = true)

theorem identity54881 : scanCanonicalize (H12AffineFastState.compose env54881 (packedSelected [7,11,14,18,20,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 32120) := by decide +kernel

theorem selectedBound54881 : packedSelected [7,11,14,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env54882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,16401,32120,1025,29909,4161,22008,21824,83,8328,65,10588,16448,4177,23805,1501,32,257,21793,16464,513]

theorem envBound54882 : H12AffineFastState.Bounded env54882 := by
  intro p hp
  have h : env54882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54881_54882 : H12AffineEnvironment.transform 17 32120 env54881 = env54882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32120 env54881 == env54882) = true)

theorem identity54882 : scanCanonicalize (H12AffineFastState.compose env54882 (packedSelected [1,3,17,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound54882 : packedSelected [1,3,17,24,28] rootPS < 2^1333 := by decide +kernel

def env54883 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29709,8202,16401,32120,1025,29708,4161,21793,21824,83,8273,65,10588,16448,4177,23588,1284,32,257,21793,16464,513]

theorem envBound54883 : H12AffineFastState.Bounded env54883 := by
  intro p hp
  have h : env54883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54882_54883 : H12AffineEnvironment.transform 6 89 env54882 = env54883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env54882 == env54883) = true)

theorem identity54883 : scanCanonicalize (H12AffineFastState.compose env54883 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound54883 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env54884 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13324,1,8202,13341,2420,1025,0,4161,8493,8524,83,8273,65,10588,13388,4177,10280,1284,32,257,8493,13404,513]

theorem envBound54884 : H12AffineFastState.Bounded env54884 := by
  intro p hp
  have h : env54884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54883_54884 : H12AffineEnvironment.transform 13 13324 env54883 = env54884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env54883 == env54884) = true)

theorem identity54884 : scanCanonicalize (H12AffineFastState.compose env54884 (packedSelected [0,1,4,6,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54884 : packedSelected [0,1,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54885 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,1,8202,13341,2341,1025,0,4112,8493,8477,2,8192,16,10509,13341,4096,10280,1284,32,257,8493,13325,513]

theorem envBound54885 : H12AffineFastState.Bounded env54885 := by
  intro p hp
  have h : env54885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54884_54885 : H12AffineEnvironment.transform 5 17 env54884 = env54885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54884 == env54885) = true)

theorem identity54885 : scanCanonicalize (H12AffineFastState.compose env54885 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54885 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54886 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1025,0,4112,33,17,2,268,16,2049,5393,4096,2340,1284,32,257,33,5377,513]

theorem envBound54886 : H12AffineFastState.Bounded env54886 := by
  intro p hp
  have h : env54886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54885_54886 : H12AffineEnvironment.transform 12 268 env54885 = env54886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54885 == env54886) = true)

theorem identity54886 : scanCanonicalize (H12AffineFastState.compose env54886 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound54886 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54887 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,268,4113,1,262,4096,2341,272,0,4112,33,17,2,268,16,2049,4096,4096,2340,21,32,257,33,4112,513]

theorem envBound54887 : H12AffineFastState.Bounded env54887 := by
  intro p hp
  have h : env54887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54886_54887 : H12AffineEnvironment.transform 9 273 env54886 = env54887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54886 == env54887) = true)

def env54888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,262144,1025,29909,77899,272513,272440,294187,8328,65,10589,277816,347427,97527,75223,33,257,21793,16464,513]

theorem envBound54888 : H12AffineFastState.Bounded env54888 := by
  intro p hp
  have h : env54888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54879_54888 : H12AffineEnvironment.transform 21 272513 env54879 = env54888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54879 == env54888) = true)

theorem identity54888 : scanCanonicalize (H12AffineFastState.compose env54888 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound54888 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,67619,1025,29909,77899,73890,73755,95496,8328,65,10589,79131,17664,97527,75223,33,257,21793,16464,513]

theorem envBound54889 : H12AffineFastState.Bounded env54889 := by
  intro p hp
  have h : env54889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54888_54889 : H12AffineEnvironment.transform 17 67619 env54888 = env54889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env54888 == env54889) = true)

def env54890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,67619,1025,29789,77899,73770,73755,95496,8192,65,10589,79131,17664,97407,75103,33,257,21793,16464,513]

theorem envBound54890 : H12AffineFastState.Bounded env54890 := by
  intro p hp
  have h : env54890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54889_54890 : H12AffineEnvironment.transform 6 8 env54889 = env54890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54889 == env54890) = true)

theorem identity54890 : scanCanonicalize (H12AffineFastState.compose env54890 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound54890 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5393,32041,1025,29789,17729,21792,21777,2,8192,65,10589,16401,17664,2421,20565,33,257,21793,16464,513]

theorem envBound54891 : H12AffineFastState.Bounded env54891 := by
  intro p hp
  have h : env54891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54890_54891 : H12AffineEnvironment.transform 15 29962 env54890 = env54891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env54890 == env54891) = true)

theorem identity54891 : scanCanonicalize (H12AffineFastState.compose env54891 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound54891 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8461,8283,5393,10360,1025,8460,4112,113,64,2,8192,65,10589,5440,4177,2421,1284,33,257,112,5377,513]

theorem envBound54892 : H12AffineFastState.Bounded env54892 := by
  intro p hp
  have h : env54892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54891_54892 : H12AffineEnvironment.transform 13 5457 env54891 = env54892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env54891 == env54892) = true)

theorem identity54892 : scanCanonicalize (H12AffineFastState.compose env54892 (packedSelected [0,1,4,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound54892 : packedSelected [0,1,4,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env54893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,3393,8461,8283,3329,10360,1025,8460,2048,113,64,2,8192,65,10589,3408,2113,2421,1284,33,257,112,3345,513]

theorem envBound54893 : H12AffineFastState.Bounded env54893 := by
  intro p hp
  have h : env54893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54892_54893 : H12AffineEnvironment.transform 11 2064 env54892 = env54893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env54892 == env54893) = true)

theorem identity54893 : scanCanonicalize (H12AffineFastState.compose env54893 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound54893 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env54894 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2064,8192,2340,8461,8283,2404,10360,100,8460,2048,113,64,2,8192,65,10589,2357,2113,2421,353,33,257,112,2420,513]

theorem envBound54894 : H12AffineFastState.Bounded env54894 := by
  intro p hp
  have h : env54894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54893_54894 : H12AffineEnvironment.transform 9 101 env54893 = env54894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env54893 == env54894) = true)

theorem identity54894 : scanCanonicalize (H12AffineFastState.compose env54894 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound54894 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54895 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,8192,2128,8313,8283,2064,10360,100,8312,2048,113,64,2,8192,65,10281,2113,2113,2049,21,33,117,112,2048,513]

theorem envBound54895 : H12AffineFastState.Bounded env54895 := by
  intro p hp
  have h : env54895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54894_54895 : H12AffineEnvironment.transform 7 116 env54894 = env54895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env54894 == env54895) = true)

theorem identity54895 : scanCanonicalize (H12AffineFastState.compose env54895 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound54895 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54896 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,2089,2128,2128,2162,2064,81,100,2129,2048,113,64,2,2089,65,0,2113,2113,2049,21,33,117,112,2048,513]

theorem envBound54896 : H12AffineFastState.Bounded env54896 := by
  intro p hp
  have h : env54896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54895_54896 : H12AffineEnvironment.transform 12 2089 env54895 = env54896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env54895 == env54896) = true)

theorem identity54896 : scanCanonicalize (H12AffineFastState.compose env54896 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound54896 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env54897 : List Nat := [2,4,8,16,32,64,8,116,81,101,2048,2064,2089,2128,2128,2162,2064,81,100,2129,2048,113,64,2,2089,65,0,2113,2113,2049,21,33,117,112,2048,80]

theorem envBound54897 : H12AffineFastState.Bounded env54897 := by
  intro p hp
  have h : env54897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54896_54897 : H12AffineEnvironment.transform 8 81 env54896 = env54897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env54896 == env54897) = true)

theorem identity54897 : scanCanonicalize (H12AffineFastState.compose env54897 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound54897 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env54898 : List Nat := [2,4,8,16,32,64,8,116,81,101,80,64,121,0,0,34,64,81,100,1,80,113,64,2,121,65,0,17,17,81,21,33,117,112,80,80]

theorem envBound54898 : H12AffineFastState.Bounded env54898 := by
  intro p hp
  have h : env54898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54897_54898 : H12AffineEnvironment.transform 10 80 env54897 = env54898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env54897 == env54898) = true)

theorem identity54898 : scanCanonicalize (H12AffineFastState.compose env54898 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54898 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env54899 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,17,40,0,0,34,17,0,53,1,1,32,17,2,40,16,0,17,17,0,21,33,36,33,1,1]

theorem envBound54899 : H12AffineFastState.Bounded env54899 := by
  intro p hp
  have h : env54899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54898_54899 : H12AffineEnvironment.transform 5 17 env54898 = env54899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54898 == env54899) = true)

theorem identity54899 : scanCanonicalize (H12AffineFastState.compose env54899 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54899 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54900 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,17,9,0,0,3,17,0,20,1,1,1,17,2,9,16,0,17,17,0,21,0,5,0,1,1]

theorem envBound54900 : H12AffineFastState.Bounded env54900 := by
  intro p hp
  have h : env54900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54899_54900 : H12AffineEnvironment.transform 4 1 env54899 = env54900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54899 == env54900) = true)

theorem identity54900 : scanCanonicalize (H12AffineFastState.compose env54900 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54900 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env54901 : List Nat := [2,4,8,0,1,1,8,4,0,5,1,1,9,0,0,3,1,0,4,1,1,1,1,2,9,0,0,1,1,0,5,0,5,0,1,1]

theorem envBound54901 : H12AffineFastState.Bounded env54901 := by
  intro p hp
  have h : env54901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54900_54901 : H12AffineEnvironment.transform 3 0 env54900 = env54901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54900 == env54901) = true)

def env54902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,67619,1025,29788,77899,73771,73755,95496,8193,65,10589,79131,17664,97406,75102,33,257,21793,16464,513]

theorem envBound54902 : H12AffineFastState.Bounded env54902 := by
  intro p hp
  have h : env54902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54889_54902 : H12AffineEnvironment.transform 6 9 env54889 = env54902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54889 == env54902) = true)

theorem identity54902 : scanCanonicalize (H12AffineFastState.compose env54902 (packedSelected [2,6,7,14,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54902 : packedSelected [2,6,7,14,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env54903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,65536,82198,67619,1025,21841,69958,65830,65814,87045,268,65,2128,70678,17664,89459,66643,33,257,21793,16464,513]

theorem envBound54903 : H12AffineFastState.Bounded env54903 := by
  intro p hp
  have h : env54903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54902_54903 : H12AffineEnvironment.transform 12 269 env54902 = env54903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54902 == env54903) = true)

theorem identity54903 : scanCanonicalize (H12AffineFastState.compose env54903 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound54903 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env54904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21840,21510,5392,23589,1025,21841,17728,21792,21776,3,268,65,2128,16400,17664,2421,20565,33,257,21793,16464,513]

theorem envBound54904 : H12AffineFastState.Bounded env54904 := by
  intro p hp
  have h : env54904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54903_54904 : H12AffineEnvironment.transform 15 21510 env54903 = env54904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env54903 == env54904) = true)

theorem identity54904 : scanCanonicalize (H12AffineFastState.compose env54904 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound54904 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,0,342,5392,2421,1025,1,4112,112,64,3,268,65,2128,5440,4176,2421,1285,33,257,113,5376,513]

theorem envBound54905 : H12AffineFastState.Bounded env54905 := by
  intro p hp
  have h : env54905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54904_54905 : H12AffineEnvironment.transform 13 5456 env54904 = env54905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env54904 == env54905) = true)

theorem identity54905 : scanCanonicalize (H12AffineFastState.compose env54905 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound54905 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,269,80,0,342,16,2421,1025,1,1296,112,64,3,268,65,2128,64,1360,2421,1285,33,257,113,0,513]

theorem envBound54906 : H12AffineFastState.Bounded env54906 := by
  intro p hp
  have h : env54906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54905_54906 : H12AffineEnvironment.transform 11 1280 env54905 = env54906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env54905 == env54906) = true)

theorem identity54906 : scanCanonicalize (H12AffineFastState.compose env54906 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound54906 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54907 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,357,269,80,0,342,16,2421,100,1,373,112,64,3,268,65,2128,64,309,2421,352,33,257,113,0,513]

theorem envBound54907 : H12AffineFastState.Bounded env54907 := by
  intro p hp
  have h : env54907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54906_54907 : H12AffineEnvironment.transform 9 101 env54906 = env54907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env54906 == env54907) = true)

theorem identity54907 : scanCanonicalize (H12AffineFastState.compose env54907 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound54907 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env54908 : List Nat := [2,4,8,16,32,64,9,256,512,101,292,357,269,80,0,342,16,81,100,1,373,112,64,3,268,65,372,64,309,81,352,33,257,113,0,513]

theorem envBound54908 : H12AffineFastState.Bounded env54908 := by
  intro p hp
  have h : env54908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54907_54908 : H12AffineEnvironment.transform 10 292 env54907 = env54908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env54907 == env54908) = true)

theorem identity54908 : scanCanonicalize (H12AffineFastState.compose env54908 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54908 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54909 : List Nat := [2,4,8,16,32,64,9,36,512,101,0,65,41,80,0,114,16,81,100,1,81,112,64,3,40,65,80,64,17,81,68,33,37,113,0,513]

theorem envBound54909 : H12AffineFastState.Bounded env54909 := by
  intro p hp
  have h : env54909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54908_54909 : H12AffineEnvironment.transform 7 36 env54908 = env54909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54908 == env54909) = true)

theorem identity54909 : scanCanonicalize (H12AffineFastState.compose env54909 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54909 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54910 : List Nat := [2,4,8,16,16,64,9,20,512,85,0,65,25,80,0,66,16,81,84,1,81,64,64,3,24,65,80,64,17,81,68,17,21,65,0,513]

theorem envBound54910 : H12AffineFastState.Bounded env54910 := by
  intro p hp
  have h : env54910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54909_54910 : H12AffineEnvironment.transform 4 16 env54909 = env54910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54909 == env54910) = true)

theorem identity54910 : scanCanonicalize (H12AffineFastState.compose env54910 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound54910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54911 : List Nat := [2,4,8,16,16,64,9,20,1,85,0,65,25,80,0,66,16,81,84,1,81,64,64,3,24,65,80,64,17,81,68,17,21,65,0,0]

theorem envBound54911 : H12AffineFastState.Bounded env54911 := by
  intro p hp
  have h : env54911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54910_54911 : H12AffineEnvironment.transform 8 1 env54910 = env54911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env54910 == env54911) = true)

theorem identity54911 : scanCanonicalize (H12AffineFastState.compose env54911 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54911 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54912 : List Nat := [2,4,8,16,16,16,9,20,1,5,0,17,25,0,0,18,16,1,4,1,1,16,16,3,24,17,0,16,17,1,20,17,21,17,0,0]

theorem envBound54912 : H12AffineFastState.Bounded env54912 := by
  intro p hp
  have h : env54912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54911_54912 : H12AffineEnvironment.transform 5 16 env54911 = env54912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54911 == env54912) = true)

def env54913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,262144,1025,29908,77899,4194304,272441,294187,8328,65,4456924,277817,347426,97527,75223,4466848,257,21793,16465,513]

theorem envBound54913 : H12AffineFastState.Bounded env54913 := by
  intro p hp
  have h : env54913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54878_54913 : H12AffineEnvironment.transform 14 29909 env54878 = env54913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env54878 == env54913) = true)

def env54914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,262144,1025,29908,77899,272512,272441,294187,8328,65,10588,277817,347426,97527,75223,32,257,21793,16465,513]

theorem envBound54914 : H12AffineFastState.Bounded env54914 := by
  intro p hp
  have h : env54914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54913_54914 : H12AffineEnvironment.transform 21 272512 env54913 = env54914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54913 == env54914) = true)

theorem identity54914 : scanCanonicalize (H12AffineFastState.compose env54914 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54914 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,10280,1025,29908,77899,168,17,21763,8328,65,10588,5393,91402,97527,75223,32,257,21793,16465,513]

theorem envBound54915 : H12AffineFastState.Bounded env54915 := by
  intro p hp
  have h : env54915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54914_54915 : H12AffineEnvironment.transform 17 10280 env54914 = env54915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54914 == env54915) = true)

theorem identity54915 : scanCanonicalize (H12AffineFastState.compose env54915 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound54915 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env54916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,479,25028,10280,1025,29908,12692,168,17,21763,8328,65,10588,5393,25813,32040,9224,32,257,21793,16465,513]

theorem envBound54916 : H12AffineFastState.Bounded env54916 := by
  intro p hp
  have h : env54916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54915_54916 : H12AffineEnvironment.transform 15 479 env54915 = env54916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env54915 == env54916) = true)

theorem identity54916 : scanCanonicalize (H12AffineFastState.compose env54916 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound54916 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env54917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,0,479,5393,10280,1025,1,12692,168,17,8662,8328,65,10588,5393,4096,2557,9224,32,257,8692,13444,513]

theorem envBound54917 : H12AffineFastState.Bounded env54917 := by
  intro p hp
  have h : env54917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54916_54917 : H12AffineEnvironment.transform 13 13525 env54916 = env54917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env54916 == env54917) = true)

theorem identity54917 : scanCanonicalize (H12AffineFastState.compose env54917 (packedSelected [1,2,5,6,8,17,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54917 : packedSelected [1,2,5,6,8,17,24] rootPS < 2^1333 := by decide +kernel

def env54918 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,0,398,5393,10280,1025,1,12692,168,17,8583,8328,16,10509,5393,4096,2476,9224,32,257,8613,13444,513]

theorem envBound54918 : H12AffineFastState.Bounded env54918 := by
  intro p hp
  have h : env54918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54917_54918 : H12AffineEnvironment.transform 5 17 env54917 = env54918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54917 == env54918) = true)

theorem identity54918 : scanCanonicalize (H12AffineFastState.compose env54918 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound54918 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54919 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,0,398,5393,2476,1025,1,4112,168,17,3,268,16,2185,5393,4096,2476,1420,32,257,33,5376,513]

theorem envBound54919 : H12AffineFastState.Bounded env54919 := by
  intro p hp
  have h : env54919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54918_54919 : H12AffineEnvironment.transform 12 388 env54918 = env54919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env54918 == env54919) = true)

theorem identity54919 : scanCanonicalize (H12AffineFastState.compose env54919 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54919 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env54920 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,263,5393,2341,1025,1,4112,33,17,3,268,16,2048,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound54920 : H12AffineFastState.Bounded env54920 := by
  intro p hp
  have h : env54920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54919_54920 : H12AffineEnvironment.transform 6 9 env54919 = env54920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54919 == env54920) = true)

theorem identity54920 : scanCanonicalize (H12AffineFastState.compose env54920 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54920 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54921 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,35,5173,2049,1025,1,4112,33,17,3,40,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound54921 : H12AffineFastState.Bounded env54921 := by
  intro p hp
  have h : env54921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54920_54921 : H12AffineEnvironment.transform 7 36 env54920 = env54921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54920 == env54921) = true)

def env54922 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1044,0,35,1029,2049,1025,1,32,33,17,3,40,16,2048,1029,48,2049,1057,32,37,33,1044,513]

theorem envBound54922 : H12AffineFastState.Bounded env54922 := by
  intro p hp
  have h : env54922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54921_54922 : H12AffineEnvironment.transform 11 48 env54921 = env54922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54921 == env54922) = true)

theorem identity54922 : scanCanonicalize (H12AffineFastState.compose env54922 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54922 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54923 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,16,9,1044,0,3,1029,2049,1025,1,0,1,17,3,8,16,2048,1029,16,2049,1025,0,5,1,1044,513]

theorem envBound54923 : H12AffineFastState.Bounded env54923 := by
  intro p hp
  have h : env54923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54922_54923 : H12AffineEnvironment.transform 4 0 env54922 = env54923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54922 == env54923) = true)

def env54924 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,16,9,0,0,3,17,2049,21,1,0,1,17,3,8,16,2048,17,16,2049,21,0,5,1,0,513]

theorem envBound54924 : H12AffineFastState.Bounded env54924 := by
  intro p hp
  have h : env54924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54923_54924 : H12AffineEnvironment.transform 9 20 env54923 = env54924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env54923 == env54924) = true)

theorem identity54924 : scanCanonicalize (H12AffineFastState.compose env54924 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound54924 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54925 : List Nat := [2,4,8,16,0,17,9,4,512,20,522,16,9,0,0,3,17,523,21,1,0,1,17,3,8,16,522,17,16,523,21,0,5,1,0,513]

theorem envBound54925 : H12AffineFastState.Bounded env54925 := by
  intro p hp
  have h : env54925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54924_54925 : H12AffineEnvironment.transform 10 522 env54924 = env54925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env54924 == env54925) = true)

def leafEnv54925 : List Nat := [2,4,8,16,0,17,9,4,512,20,522,16,9,0,0,3,17,523,21,1,0,1,17,3,20,8,1,16,522,17,16,523,21,0,5,1,5,2,0,513,1,0,0]

def active54925 : List Nat := [0,1,2,3,8]

def tree54925 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54925 : H12WitnessSearch.Good tree54925 := H12GlobalWitnessIndex.good

theorem leafIdentity54925 : H12AffineFastState.composeSystem env54925 rootObs = leafEnv54925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54925 rootObs == leafEnv54925) = true)

theorem terminalChecked54925 : H12PackedTerminal.terminalCheckFast leafEnv54925 active54925 tree54925 = true := by decide +kernel

def env54926 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,16,9,1,0,3,16,2049,20,1,0,1,17,3,8,16,2048,16,16,2049,20,0,5,1,1,513]

theorem envBound54926 : H12AffineFastState.Bounded env54926 := by
  intro p hp
  have h : env54926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54923_54926 : H12AffineEnvironment.transform 9 21 env54923 = env54926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env54923 == env54926) = true)

theorem identity54926 : scanCanonicalize (H12AffineFastState.compose env54926 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound54926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54927 : List Nat := [2,4,8,16,0,17,9,4,512,21,0,16,9,1,0,3,16,1,20,1,0,1,17,3,8,16,0,16,16,1,20,0,5,1,1,513]

theorem envBound54927 : H12AffineFastState.Bounded env54927 := by
  intro p hp
  have h : env54927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54926_54927 : H12AffineEnvironment.transform 10 0 env54926 = env54927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env54926 == env54927) = true)

def leafEnv54927 : List Nat := [2,4,8,16,0,17,9,4,512,21,0,16,9,1,0,3,16,1,20,1,0,1,17,3,21,8,1,16,0,16,16,1,20,0,5,1,5,2,1,513,1,0,0]

def active54927 : List Nat := [0,1,2,3,8]

def tree54927 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54927 : H12WitnessSearch.Good tree54927 := H12GlobalWitnessIndex.good

theorem leafIdentity54927 : H12AffineFastState.composeSystem env54927 rootObs = leafEnv54927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54927 rootObs == leafEnv54927) = true)

theorem terminalChecked54927 : H12PackedTerminal.terminalCheckFast leafEnv54927 active54927 tree54927 = true := by decide +kernel

def env54928 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1045,0,35,1028,2049,1025,1,33,33,17,3,40,16,2048,1028,49,2049,1057,32,37,33,1045,513]

theorem envBound54928 : H12AffineFastState.Bounded env54928 := by
  intro p hp
  have h : env54928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54921_54928 : H12AffineEnvironment.transform 11 49 env54921 = env54928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54921 == env54928) = true)

theorem identity54928 : scanCanonicalize (H12AffineFastState.compose env54928 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound54928 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54929 : List Nat := [2,4,8,16,32,17,9,36,512,21,2048,49,41,0,0,35,17,2049,20,1,33,33,17,3,40,16,2048,17,49,2049,52,32,37,33,0,513]

theorem envBound54929 : H12AffineFastState.Bounded env54929 := by
  intro p hp
  have h : env54929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54928_54929 : H12AffineEnvironment.transform 9 21 env54928 = env54929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env54928 == env54929) = true)

def env54930 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,17,9,0,0,3,17,2049,20,1,1,1,17,3,8,16,2048,17,17,2049,20,0,5,1,0,513]

theorem envBound54930 : H12AffineFastState.Bounded env54930 := by
  intro p hp
  have h : env54930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54929_54930 : H12AffineEnvironment.transform 4 0 env54929 = env54930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54929 == env54930) = true)

theorem identity54930 : scanCanonicalize (H12AffineFastState.compose env54930 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54930 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54931 : List Nat := [2,4,8,16,0,17,9,4,512,21,1,17,9,0,0,3,17,0,20,1,1,1,17,3,8,16,1,17,17,0,20,0,5,1,0,513]

theorem envBound54931 : H12AffineFastState.Bounded env54931 := by
  intro p hp
  have h : env54931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54930_54931 : H12AffineEnvironment.transform 10 1 env54930 = env54931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54930 == env54931) = true)

def leafEnv54931 : List Nat := [2,4,8,16,0,17,9,4,512,21,1,17,9,0,0,3,17,0,20,1,1,1,17,3,21,8,1,16,1,17,17,0,20,0,5,1,5,2,0,513,1,1,0]

def active54931 : List Nat := [0,1,2,3,8]

def tree54931 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54931 : H12WitnessSearch.Good tree54931 := H12GlobalWitnessIndex.good

theorem leafIdentity54931 : H12AffineFastState.composeSystem env54931 rootObs = leafEnv54931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54931 rootObs == leafEnv54931) = true)

theorem terminalChecked54931 : H12PackedTerminal.terminalCheckFast leafEnv54931 active54931 tree54931 = true := by decide +kernel

def env54932 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,0,0,2,17,2049,20,1,0,0,17,3,9,16,2048,17,16,2049,21,1,4,0,0,513]

theorem envBound54932 : H12AffineFastState.Bounded env54932 := by
  intro p hp
  have h : env54932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54929_54932 : H12AffineEnvironment.transform 4 1 env54929 = env54932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54929 == env54932) = true)

theorem identity54932 : scanCanonicalize (H12AffineFastState.compose env54932 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound54932 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54933 : List Nat := [2,4,8,16,1,17,9,5,512,21,523,16,8,0,0,2,17,522,20,1,0,0,17,3,9,16,523,17,16,522,21,1,4,0,0,513]

theorem envBound54933 : H12AffineFastState.Bounded env54933 := by
  intro p hp
  have h : env54933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54932_54933 : H12AffineEnvironment.transform 10 523 env54932 = env54933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env54932 == env54933) = true)

def leafEnv54933 : List Nat := [2,4,8,16,1,17,9,5,512,21,523,16,8,0,0,2,17,522,20,1,0,0,17,3,20,9,1,16,523,17,16,522,21,1,4,0,5,3,0,513,1,0,0]

def active54933 : List Nat := [0,1,2,3,8]

def tree54933 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54933 : H12WitnessSearch.Good tree54933 := H12GlobalWitnessIndex.good

theorem leafIdentity54933 : H12AffineFastState.composeSystem env54933 rootObs = leafEnv54933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54933 rootObs == leafEnv54933) = true)

theorem terminalChecked54933 : H12PackedTerminal.terminalCheckFast leafEnv54933 active54933 tree54933 = true := by decide +kernel

def env54934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,262144,1025,29908,77899,272513,272441,294187,8328,65,10589,277817,347426,97527,75223,33,257,21793,16465,513]

theorem envBound54934 : H12AffineFastState.Bounded env54934 := by
  intro p hp
  have h : env54934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54913_54934 : H12AffineEnvironment.transform 21 272513 env54913 = env54934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54913 == env54934) = true)

def env54935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,32160,1025,29908,77899,21793,21913,139,8328,65,10589,16537,77954,97527,75223,33,257,21793,16465,513]

theorem envBound54935 : H12AffineFastState.Bounded env54935 := by
  intro p hp
  have h : env54935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54934_54935 : H12AffineEnvironment.transform 17 32160 env54934 = env54935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env54934 == env54935) = true)

theorem identity54935 : scanCanonicalize (H12AffineFastState.compose env54935 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54935 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79130,10401,1025,8661,77899,32,152,139,8328,65,10589,5528,77954,76278,75223,33,257,32,5456,513]

theorem envBound54936 : H12AffineFastState.Bounded env54936 := by
  intro p hp
  have h : env54936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54935_54936 : H12AffineEnvironment.transform 13 5377 env54935 = env54936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54935 == env54936) = true)

theorem identity54936 : scanCanonicalize (H12AffineFastState.compose env54936 (packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound54936 : packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env54937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8283,5441,10401,1025,8661,4112,32,152,139,8328,65,10589,5528,4313,2477,1420,33,257,32,5456,513]

theorem envBound54937 : H12AffineFastState.Bounded env54937 := by
  intro p hp
  have h : env54937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54936_54937 : H12AffineEnvironment.transform 15 8283 env54936 = env54937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env54936 == env54937) = true)

theorem identity54937 : scanCanonicalize (H12AffineFastState.compose env54937 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound54937 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env54938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5377,80,479,5441,2341,1025,81,4112,32,152,139,268,65,2265,5528,4313,2477,1420,33,257,32,5456,513]

theorem envBound54938 : H12AffineFastState.Bounded env54938 := by
  intro p hp
  have h : env54938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54937_54938 : H12AffineEnvironment.transform 12 388 env54937 = env54938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env54937 == env54938) = true)

theorem identity54938 : scanCanonicalize (H12AffineFastState.compose env54938 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound54938 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54939 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,240,5237,80,171,5173,2129,1025,81,4112,32,152,139,120,65,2265,5356,4313,2265,1272,33,117,32,5156,513]

theorem envBound54939 : H12AffineFastState.Bounded env54939 := by
  intro p hp
  have h : env54939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54938_54939 : H12AffineEnvironment.transform 7 116 env54938 = env54939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env54938 == env54939) = true)

def env54940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,32161,1025,29908,77899,21792,21912,138,8328,65,10589,16536,77955,97527,75223,33,257,21793,16465,513]

theorem envBound54940 : H12AffineFastState.Bounded env54940 := by
  intro p hp
  have h : env54940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54934_54940 : H12AffineEnvironment.transform 17 32161 env54934 = env54940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env54934 == env54940) = true)

theorem identity54940 : scanCanonicalize (H12AffineFastState.compose env54940 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound54940 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,79250,10280,1025,8541,77899,169,17,138,8328,65,10589,5393,77955,76158,75223,33,257,168,5592,513]

theorem envBound54941 : H12AffineFastState.Bounded env54941 := by
  intro p hp
  have h : env54941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54940_54941 : H12AffineEnvironment.transform 13 5513 env54940 = env54941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env54940 == env54941) = true)

end H12CloudChart0