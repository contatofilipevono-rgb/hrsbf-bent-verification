import H12CloudChart0Data013

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound3438 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env3439 : List Nat := [2,4,8,0,32,1,41,4,512,15,512,10,34,513,10,547,10,513,14,10,11,0,1,3,2,0,11,512,513,42,548,523,5,523,43,512]

theorem envBound3439 : H12AffineFastState.Bounded env3439 := by
  intro p hp
  have h : env3439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3438_3439 : H12AffineEnvironment.transform 10 512 env3438 = env3439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env3438 == env3439) = true)

theorem identity3439 : scanCanonicalize (H12AffineFastState.compose env3439 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3439 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3440 : List Nat := [2,4,8,0,0,1,9,4,512,15,512,10,2,513,10,515,10,513,14,10,11,0,1,3,2,0,11,512,513,10,516,523,5,523,11,512]

theorem envBound3440 : H12AffineFastState.Bounded env3440 := by
  intro p hp
  have h : env3440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3439_3440 : H12AffineEnvironment.transform 4 0 env3439 = env3440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3439 == env3440) = true)

def env3441 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1025,32768,4097,46212,8388608,41003,8329,8388609,323712,16385,16385,22561,62624,8406020,173,20480,8433824,8389121]

theorem envBound3441 : H12AffineFastState.Bounded env3441 := by
  intro p hp
  have h : env3441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3429_3441 : H12AffineEnvironment.transform 3 1 env3429 = env3441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3429 == env3441) = true)

def env3442 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28714,4097,262144,1025,8352,4097,5156,8388608,139,8329,8388609,282656,16385,16385,22561,21504,8406020,173,20480,8392704,8389121]

theorem envBound3442 : H12AffineFastState.Bounded env3442 := by
  intro p hp
  have h : env3442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3441_3442 : H12AffineEnvironment.transform 14 8352 env3441 = env3442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3441 == env3442) = true)

theorem identity3442 : scanCanonicalize (H12AffineFastState.compose env3442 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound3442 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3443 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28714,4097,2081,1025,8352,4097,5156,8388608,139,8329,8388609,22529,16385,16385,22561,21504,8406020,173,20480,8392704,8389121]

theorem envBound3443 : H12AffineFastState.Bounded env3443 := by
  intro p hp
  have h : env3443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3442_3443 : H12AffineEnvironment.transform 17 2081 env3442 = env3443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env3442 == env3443) = true)

theorem identity3443 : scanCanonicalize (H12AffineFastState.compose env3443 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(22+1) ^^^ 9871) := by decide +kernel

theorem selectedBound3443 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env3444 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28714,4097,2081,1025,8352,4097,5156,9871,139,8329,9870,22529,16385,16385,22561,21504,25227,173,20480,13967,9358]

theorem envBound3444 : H12AffineFastState.Bounded env3444 := by
  intro p hp
  have h : env3444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3443_3444 : H12AffineEnvironment.transform 22 9871 env3443 = env3444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9871 env3443 == env3444) = true)

theorem identity3444 : scanCanonicalize (H12AffineFastState.compose env3444 (packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 7815) := by decide +kernel

theorem selectedBound3444 : packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env3445 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,7815,8352,11949,4097,2081,1025,8352,4097,5156,9871,139,8329,9870,1670,7814,7814,1702,2695,15372,173,3719,13967,9358]

theorem envBound3445 : H12AffineFastState.Bounded env3445 := by
  intro p hp
  have h : env3445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3444_3445 : H12AffineEnvironment.transform 13 7815 env3444 = env3445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7815 env3444 == env3445) = true)

theorem identity3445 : scanCanonicalize (H12AffineFastState.compose env3445 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4643) := by decide +kernel

theorem selectedBound3445 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env3446 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,4643,7815,4739,7310,4097,2081,1025,4739,4097,5156,5292,139,4778,5293,1670,7814,7814,1702,2695,3631,173,3719,1196,5805]

theorem envBound3446 : H12AffineFastState.Bounded env3446 := by
  intro p hp
  have h : env3446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3445_3446 : H12AffineEnvironment.transform 12 4643 env3445 = env3446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4643 env3445 == env3446) = true)

theorem identity3446 : scanCanonicalize (H12AffineFastState.compose env3446 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound3446 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env3447 : List Nat := [2,4,8,1,32,0,128,172,42,1024,2048,4096,4105,7341,4265,7310,4097,2081,1025,4265,4097,5156,5292,139,4224,5293,1196,7340,7340,1164,2221,3077,173,3245,1196,5255]

theorem envBound3447 : H12AffineFastState.Bounded env3447 := by
  intro p hp
  have h : env3447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3446_3447 : H12AffineEnvironment.transform 8 42 env3446 = env3447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env3446 == env3447) = true)

def env3448 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28715,4097,262144,1025,8353,4097,5157,8388608,138,8329,8388609,282657,16385,16385,22561,21505,8406020,173,20480,8392705,8389121]

theorem envBound3448 : H12AffineFastState.Bounded env3448 := by
  intro p hp
  have h : env3448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3441_3448 : H12AffineEnvironment.transform 14 8353 env3441 = env3448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3441 == env3448) = true)

theorem identity3448 : scanCanonicalize (H12AffineFastState.compose env3448 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 19596) := by decide +kernel

theorem selectedBound3448 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3449 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28715,4097,19596,1025,8353,4097,5157,8388608,138,8329,8388609,7341,16385,16385,22561,21505,8406020,173,20480,8392705,8389121]

theorem envBound3449 : H12AffineFastState.Bounded env3449 := by
  intro p hp
  have h : env3449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3448_3449 : H12AffineEnvironment.transform 17 19596 env3448 = env3449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19596 env3448 == env3449) = true)

theorem identity3449 : scanCanonicalize (H12AffineFastState.compose env3449 (packedSelected [2,3,5,6,10,13,17,21] rootPS)) = affineNative (2^(12+1) ^^^ 2050) := by decide +kernel

theorem selectedBound3449 : packedSelected [2,3,5,6,10,13,17,21] rootPS < 2^1333 := by decide +kernel

def env3450 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,2050,16384,2211,22569,4097,19596,1025,2211,4097,5157,8388608,138,2187,8388609,7341,16385,16385,22561,21505,8406020,173,20480,8392705,8389121]

theorem envBound3450 : H12AffineFastState.Bounded env3450 := by
  intro p hp
  have h : env3450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3449_3450 : H12AffineEnvironment.transform 12 2050 env3449 = env3450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2050 env3449 == env3450) = true)

theorem identity3450 : scanCanonicalize (H12AffineFastState.compose env3450 (packedSelected [2,4,9,11,20,23] rootPS)) = affineNative (2^(22+1) ^^^ 5124) := by decide +kernel

theorem selectedBound3450 : packedSelected [2,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env3451 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,2050,16384,2211,22569,4097,19596,1025,2211,4097,5157,5124,138,2187,5125,7341,16385,16385,22561,21505,20480,173,20480,1029,5637]

theorem envBound3451 : H12AffineFastState.Bounded env3451 := by
  intro p hp
  have h : env3451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3450_3451 : H12AffineEnvironment.transform 22 5124 env3450 = env3451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5124 env3450 == env3451) = true)

theorem identity3451 : scanCanonicalize (H12AffineFastState.compose env3451 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 2571) := by decide +kernel

theorem selectedBound3451 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3452 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,2050,2571,2211,4642,4097,1671,1025,2211,4097,5157,5124,138,2187,5125,7341,2570,2570,4650,7690,6667,173,6667,1029,5637]

theorem envBound3452 : H12AffineFastState.Bounded env3452 := by
  intro p hp
  have h : env3452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3451_3452 : H12AffineEnvironment.transform 13 2571 env3451 = env3452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2571 env3451 == env3452) = true)

theorem identity3452 : scanCanonicalize (H12AffineFastState.compose env3452 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound3452 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env3453 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,648,2050,2571,2211,170,649,1671,1025,2211,649,1709,1676,138,2187,1677,3621,2570,2570,162,3202,2179,173,2179,1029,1165]

theorem envBound3453 : H12AffineFastState.Bounded env3453 := by
  intro p hp
  have h : env3453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3452_3453 : H12AffineEnvironment.transform 11 648 env3452 = env3453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env3452 == env3453) = true)

theorem identity3453 : scanCanonicalize (H12AffineFastState.compose env3453 (packedSelected [0,1,3,5,6,7,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3453 : packedSelected [0,1,3,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env3454 : List Nat := [2,4,8,1,32,0,40,4,512,1024,2048,544,2050,2571,2059,2,545,1583,1025,2059,545,1541,1572,34,2083,1573,3621,2570,2570,10,3114,2091,5,2091,1029,1061]

theorem envBound3454 : H12AffineFastState.Bounded env3454 := by
  intro p hp
  have h : env3454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3453_3454 : H12AffineEnvironment.transform 6 40 env3453 = env3454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3453 == env3454) = true)

theorem identity3454 : scanCanonicalize (H12AffineFastState.compose env3454 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound3454 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3455 : List Nat := [2,4,8,1,32,0,40,4,512,1024,42,544,40,545,33,2,545,1583,1025,33,545,1541,1572,34,9,1573,1551,544,544,10,1024,1,5,1,1029,1061]

theorem envBound3455 : H12AffineFastState.Bounded env3455 := by
  intro p hp
  have h : env3455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3454_3455 : H12AffineEnvironment.transform 10 42 env3454 = env3455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env3454 == env3455) = true)

theorem identity3455 : scanCanonicalize (H12AffineFastState.compose env3455 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3455 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3456 : List Nat := [2,4,8,1,32,0,40,4,512,5,42,544,40,545,33,2,545,554,4,33,545,512,545,34,9,544,522,544,544,10,5,1,5,1,0,32]

theorem envBound3456 : H12AffineFastState.Bounded env3456 := by
  intro p hp
  have h : env3456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3455_3456 : H12AffineEnvironment.transform 9 5 env3455 = env3456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3455 == env3456) = true)

def env3457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41003,8329,11015248,849105,268435456,268435965,547952,2699306,12644668,525568,545873,8479126,8914924]

theorem envBound3457 : H12AffineFastState.Bounded env3457 := by
  intro p hp
  have h : env3457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2955_3457 : H12AffineEnvironment.transform 26 849105 env2955 = env3457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 849105 env2955 == env3457) = true)

def env3458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849105,268435456,268435965,547952,598058,12644668,525568,545873,8479126,8914924]

theorem envBound3458 : H12AffineFastState.Bounded env3458 := by
  intro p hp
  have h : env3458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3457_3458 : H12AffineEnvironment.transform 20 4096 env3457 = env3458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env3457 == env3458) = true)

def env3459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849105,16384,16893,547952,598058,12644668,525568,545873,8479126,8914924]

theorem envBound3459 : H12AffineFastState.Bounded env3459 := by
  intro p hp
  have h : env3459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3458_3459 : H12AffineEnvironment.transform 27 16384 env3458 = env3459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env3458 == env3459) = true)

def env3460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323793,16384,16893,22640,74794,12644668,256,20561,8479126,8389612]

theorem envBound3460 : H12AffineFastState.Bounded env3460 := by
  intro p hp
  have h : env3460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3459_3460 : H12AffineEnvironment.transform 18 1024 env3459 = env3460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3459 == env3460) = true)

theorem identity3460 : scanCanonicalize (H12AffineFastState.compose env3460 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound3460 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1212,8192,16384,32768,65536,1344,262144,1024,32768,1212,4194304,8388608,41003,8329,8388688,320621,16384,16893,19660,74794,12641664,256,17645,8479126,8389612]

theorem envBound3461 : H12AffineFastState.Bounded env3461 := by
  intro p hp
  have h : env3461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3460_3461 : H12AffineEnvironment.transform 11 1212 env3460 = env3461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env3460 == env3461) = true)

def env3462 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,4194304,8388608,41003,8329,8388608,320573,16384,16813,19612,74794,12641664,256,17597,8479126,8389564]

theorem envBound3462 : H12AffineFastState.Bounded env3462 := by
  intro p hp
  have h : env3462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3461_3462 : H12AffineEnvironment.transform 5 16 env3461 = env3462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3461 == env3462) = true)

theorem identity3462 : scanCanonicalize (H12AffineFastState.compose env3462 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound3462 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3463 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,4194304,444,41003,8329,444,320573,16384,16813,19612,74794,4252732,256,17597,90154,512]

theorem envBound3463 : H12AffineFastState.Bounded env3463 := by
  intro p hp
  have h : env3463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3462_3463 : H12AffineEnvironment.transform 22 444 env3462 = env3463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env3462 == env3463) = true)

theorem identity3463 : scanCanonicalize (H12AffineFastState.compose env3463 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3463 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3464 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,41348,444,41003,8329,444,320573,16384,16813,19612,74794,17848,256,17597,90154,512]

theorem envBound3464 : H12AffineFastState.Bounded env3464 := by
  intro p hp
  have h : env3464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3463_3464 : H12AffineEnvironment.transform 21 41348 env3463 = env3464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3463 == env3464) = true)

theorem identity3464 : scanCanonicalize (H12AffineFastState.compose env3464 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound3464 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3465 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,33543,1296,262144,1024,32768,1212,41348,444,41003,8329,444,320573,16384,16813,19612,42797,17848,256,17597,58157,512]

theorem envBound3465 : H12AffineFastState.Bounded env3465 := by
  intro p hp
  have h : env3465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3464_3465 : H12AffineEnvironment.transform 15 33543 env3464 = env3465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env3464 == env3465) = true)

theorem identity3465 : scanCanonicalize (H12AffineFastState.compose env3465 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26425) := by decide +kernel

theorem selectedBound3465 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3466 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25662,1296,262144,1024,26425,1212,18109,444,18194,8329,444,262916,16384,16813,19612,16404,17848,256,17597,1044,512]

theorem envBound3466 : H12AffineFastState.Bounded env3466 := by
  intro p hp
  have h : env3466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3465_3466 : H12AffineEnvironment.transform 14 26425 env3465 = env3466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26425 env3465 == env3466) = true)

theorem identity3466 : scanCanonicalize (H12AffineFastState.compose env3466 (packedSelected [0,8,10,12,15,18,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 20157) := by decide +kernel

theorem selectedBound3466 : packedSelected [0,8,10,12,15,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env3467 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25662,1296,20157,1024,26425,1212,18109,444,18194,8329,444,19897,16384,16813,19612,16404,17848,256,17597,1044,512]

theorem envBound3467 : H12AffineFastState.Bounded env3467 := by
  intro p hp
  have h : env3467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3466_3467 : H12AffineEnvironment.transform 17 20157 env3466 = env3467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20157 env3466 == env3467) = true)

def env3468 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1212,8192,16384,32768,65536,1297,262144,1024,32768,1212,4194304,8388608,41003,8329,8388609,320572,16384,16812,19613,74794,12641664,256,17596,8479126,8389565]

theorem envBound3468 : H12AffineFastState.Bounded env3468 := by
  intro p hp
  have h : env3468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3461_3468 : H12AffineEnvironment.transform 5 17 env3461 = env3468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3461 == env3468) = true)

def env3469 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1212,8192,16384,32768,65536,1197,262144,1024,32768,1212,4194304,8388608,41003,8329,8388609,320572,16384,16400,19613,74794,12641340,188,17596,8478762,8389121]

theorem envBound3469 : H12AffineFastState.Bounded env3469 := by
  intro p hp
  have h : env3469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3468_3469 : H12AffineEnvironment.transform 7 188 env3468 = env3469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3468 == env3469) = true)

theorem identity3469 : scanCanonicalize (H12AffineFastState.compose env3469 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound3469 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3470 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1212,8192,16384,32768,65536,1197,262144,1024,32768,1212,4194304,4194353,41003,8329,4194352,320572,16384,16400,19613,74794,58381,188,17596,4284443,4194864]

theorem envBound3470 : H12AffineFastState.Bounded env3470 := by
  intro p hp
  have h : env3470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3469_3470 : H12AffineEnvironment.transform 22 4194353 env3469 = env3470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env3469 == env3470) = true)

def env3471 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,16384,32768,65536,1197,262144,1024,32768,1196,4194304,4194337,41003,8329,4194336,320556,16384,16384,19597,74794,58381,172,17580,4284427,4194848]

theorem envBound3471 : H12AffineFastState.Bounded env3471 := by
  intro p hp
  have h : env3471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3470_3471 : H12AffineEnvironment.transform 3 0 env3470 = env3471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3470 == env3471) = true)

theorem identity3471 : scanCanonicalize (H12AffineFastState.compose env3471 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 50319) := by decide +kernel

theorem selectedBound3471 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3472 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,16384,32768,50319,1197,262144,1024,32768,1196,4194304,4194337,41003,8329,4194336,320556,16384,16384,19597,57509,58381,172,17580,4236420,4194848]

theorem envBound3472 : H12AffineFastState.Bounded env3472 := by
  intro p hp
  have h : env3472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3471_3472 : H12AffineEnvironment.transform 15 50319 env3471 = env3472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50319 env3471 == env3472) = true)

theorem identity3472 : scanCanonicalize (H12AffineFastState.compose env3472 (packedSelected [0,5,7,9,17,20,21,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 19493) := by decide +kernel

theorem selectedBound3472 : packedSelected [0,5,7,9,17,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env3473 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,16384,32768,50319,1197,19493,1024,32768,1196,4194304,4194337,41003,8329,4194336,43017,16384,16384,19597,57509,58381,172,17580,4236420,4194848]

theorem envBound3473 : H12AffineFastState.Bounded env3473 := by
  intro p hp
  have h : env3473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3472_3473 : H12AffineEnvironment.transform 17 19493 env3472 = env3473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19493 env3472 == env3473) = true)

theorem identity3473 : scanCanonicalize (H12AffineFastState.compose env3473 (packedSelected [0,4,7,13,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound3473 : packedSelected [0,4,7,13,21,22] rootPS < 2^1333 := by decide +kernel

def env3474 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,16384,32768,50319,1197,19493,1024,32768,1196,41000,40969,41003,8329,40968,43017,16384,16384,19597,57509,58381,172,17580,1196,41480]

theorem envBound3474 : H12AffineFastState.Bounded env3474 := by
  intro p hp
  have h : env3474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3473_3474 : H12AffineEnvironment.transform 21 41000 env3473 = env3474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env3473 == env3474) = true)

theorem identity3474 : scanCanonicalize (H12AffineFastState.compose env3474 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound3474 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env3475 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,1677,32768,33282,1197,2728,1024,32768,1196,41000,40969,41003,8329,40968,43017,1677,1677,2560,42536,41600,172,545,1196,41480]

theorem envBound3475 : H12AffineFastState.Bounded env3475 := by
  intro p hp
  have h : env3475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3474_3475 : H12AffineEnvironment.transform 13 1677 env3474 = env3475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env3474 == env3475) = true)

theorem identity3475 : scanCanonicalize (H12AffineFastState.compose env3475 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3475 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env3476 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,1029,8192,1572,32768,33282,1028,2561,1024,32768,1029,41000,40969,41003,8224,40968,43017,1572,1572,2560,42536,41513,5,545,1029,41480]

theorem envBound3476 : H12AffineFastState.Bounded env3476 := by
  intro p hp
  have h : env3476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3475_3476 : H12AffineEnvironment.transform 6 41 env3475 = env3476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3475 == env3476) = true)

theorem identity3476 : scanCanonicalize (H12AffineFastState.compose env3476 (packedSelected [5,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 11815) := by decide +kernel

theorem selectedBound3476 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3477 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,1029,8192,1572,11815,11301,1028,2561,1024,11815,1029,3599,3630,3596,8224,3631,1582,1572,1572,2560,2063,3086,5,545,1029,3119]

theorem envBound3477 : H12AffineFastState.Bounded env3477 := by
  intro p hp
  have h : env3477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3476_3477 : H12AffineEnvironment.transform 14 11815 env3476 = env3477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11815 env3476 == env3477) = true)

theorem identity3477 : scanCanonicalize (H12AffineFastState.compose env3477 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound3477 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3478 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1071,1029,8192,1572,8712,8202,1028,1582,1024,8712,1029,544,513,547,8224,512,1582,1572,1572,1583,1056,33,5,545,1029,0]

theorem envBound3478 : H12AffineFastState.Bounded env3478 := by
  intro p hp
  have h : env3478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3477_3478 : H12AffineEnvironment.transform 10 1071 env3477 = env3478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env3477 == env3478) = true)

theorem identity3478 : scanCanonicalize (H12AffineFastState.compose env3478 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound3478 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env3479 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1071,1029,40,1572,544,34,1028,1582,1024,544,1029,544,513,547,8,512,1582,1572,1572,1583,1056,33,5,545,1029,0]

theorem envBound3479 : H12AffineFastState.Bounded env3479 := by
  intro p hp
  have h : env3479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3478_3479 : H12AffineEnvironment.transform 12 40 env3478 = env3479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env3478 == env3479) = true)

theorem identity3479 : scanCanonicalize (H12AffineFastState.compose env3479 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound3479 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env3480 : List Nat := [2,4,8,0,32,1,41,5,43,1024,1071,1029,40,1039,11,34,1028,1029,1024,11,1029,11,42,8,8,43,1029,1039,1039,1028,1056,33,5,10,1029,0]

theorem envBound3480 : H12AffineFastState.Bounded env3480 := by
  intro p hp
  have h : env3480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3479_3480 : H12AffineEnvironment.transform 8 43 env3479 = env3480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env3479 == env3480) = true)

theorem identity3480 : scanCanonicalize (H12AffineFastState.compose env3480 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound3480 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env3481 : List Nat := [2,4,8,0,32,1,41,5,43,47,0,42,40,32,11,34,43,42,47,11,42,11,42,8,8,43,42,32,32,43,15,33,5,10,42,0]

theorem envBound3481 : H12AffineFastState.Bounded env3481 := by
  intro p hp
  have h : env3481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3480_3481 : H12AffineEnvironment.transform 9 47 env3480 = env3481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env3480 == env3481) = true)

theorem identity3481 : scanCanonicalize (H12AffineFastState.compose env3481 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3481 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3482 : List Nat := [2,4,8,0,11,1,2,5,0,4,0,1,3,11,11,9,0,1,4,11,1,11,1,8,8,0,1,11,11,0,15,10,5,10,1,0]

theorem envBound3482 : H12AffineFastState.Bounded env3482 := by
  intro p hp
  have h : env3482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3481_3482 : H12AffineEnvironment.transform 4 11 env3481 = env3482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3481 == env3482) = true)

theorem identity3482 : scanCanonicalize (H12AffineFastState.compose env3482 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3482 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3483 : List Nat := [2,4,2,0,1,1,2,5,0,4,0,1,3,1,1,3,0,1,4,1,1,1,1,2,2,0,1,1,1,0,5,0,5,0,1,0]

theorem envBound3483 : H12AffineFastState.Bounded env3483 := by
  intro p hp
  have h : env3483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3482_3483 : H12AffineEnvironment.transform 2 2 env3482 = env3483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3482 == env3483) = true)

def env3484 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,32768,65536,1197,262144,1024,32768,1197,4194304,4194336,41003,8329,4194337,320557,16384,16385,19596,74794,58381,173,17581,4284426,4194849]

theorem envBound3484 : H12AffineFastState.Bounded env3484 := by
  intro p hp
  have h : env3484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3470_3484 : H12AffineEnvironment.transform 3 1 env3470 = env3484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3470 == env3484) = true)

theorem identity3484 : scanCanonicalize (H12AffineFastState.compose env3484 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound3484 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3485 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8201,65536,1197,262144,1024,8201,1197,4194304,4194336,34,8329,4194337,279588,16384,16385,19596,74794,17412,173,17581,4284426,4194849]

theorem envBound3485 : H12AffineFastState.Bounded env3485 := by
  intro p hp
  have h : env3485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3484_3485 : H12AffineEnvironment.transform 14 8201 env3484 = env3485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env3484 == env3485) = true)

theorem identity3485 : scanCanonicalize (H12AffineFastState.compose env3485 (packedSelected [0,1,3,7,8,9,10,18,20,22,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 281772) := by decide +kernel

theorem selectedBound3485 : packedSelected [0,1,3,7,8,9,10,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env3486 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8201,65536,1197,262144,1024,8201,1197,281772,281740,34,8329,281741,279588,16384,16385,19596,74794,17412,173,17581,339110,282253]

theorem envBound3486 : H12AffineFastState.Bounded env3486 := by
  intro p hp
  have h : env3486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3485_3486 : H12AffineEnvironment.transform 21 281772 env3485 = env3486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 281772 env3485 == env3486) = true)

theorem identity3486 : scanCanonicalize (H12AffineFastState.compose env3486 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 25734) := by decide +kernel

theorem selectedBound3486 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env3487 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8201,25734,1197,262144,1024,8201,1197,281772,281740,34,8329,281741,279588,16384,16385,19596,16556,17412,173,17581,280608,282253]

theorem envBound3487 : H12AffineFastState.Bounded env3487 := by
  intro p hp
  have h : env3487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3486_3487 : H12AffineEnvironment.transform 15 25734 env3486 = env3487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25734 env3486 == env3487) = true)

theorem identity3487 : scanCanonicalize (H12AffineFastState.compose env3487 (packedSelected [1,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2211) := by decide +kernel

theorem selectedBound3487 : packedSelected [1,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env3488 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,2211,8201,11301,1197,262144,1024,8201,1197,263183,263215,34,8329,263214,265351,2211,2210,1071,2063,3239,173,3086,262275,263726]

theorem envBound3488 : H12AffineFastState.Bounded env3488 := by
  intro p hp
  have h : env3488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3487_3488 : H12AffineEnvironment.transform 13 2211 env3487 = env3488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2211 env3487 == env3488) = true)

theorem identity3488 : scanCanonicalize (H12AffineFastState.compose env3488 (packedSelected [2,10,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 11271) := by decide +kernel

theorem selectedBound3488 : packedSelected [2,10,15,17] rootPS < 2^1333 := by decide +kernel

def env3489 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,2211,8201,11301,1197,11271,1024,8201,1197,10248,10280,34,8329,10281,8320,2211,2210,1071,2063,3239,173,3086,11396,10793]

theorem envBound3489 : H12AffineFastState.Bounded env3489 := by
  intro p hp
  have h : env3489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3488_3489 : H12AffineEnvironment.transform 17 11271 env3488 = env3489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11271 env3488 == env3489) = true)

theorem identity3489 : scanCanonicalize (H12AffineFastState.compose env3489 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3489 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env3490 : List Nat := [2,4,8,1,32,0,128,173,1,1024,2048,1197,8192,2211,8201,11301,1197,11271,1024,8201,1197,10248,10280,34,8329,10281,8320,2211,2210,1071,2063,3239,173,3086,11396,10280]

theorem envBound3490 : H12AffineFastState.Bounded env3490 := by
  intro p hp
  have h : env3490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3489_3490 : H12AffineEnvironment.transform 8 1 env3489 = env3490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3489 == env3490) = true)

theorem identity3490 : scanCanonicalize (H12AffineFastState.compose env3490 (packedSelected [0,1,2,3,5,8,9,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1159) := by decide +kernel

theorem selectedBound3490 : packedSelected [0,1,2,3,5,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env3491 : List Nat := [2,4,8,1,32,0,128,173,1,1024,1159,1197,8192,1060,8201,8354,1197,8320,1024,8201,1197,9359,9391,34,8329,9390,8320,1060,1061,1071,1160,32,173,137,8195,9391]

theorem envBound3491 : H12AffineFastState.Bounded env3491 := by
  intro p hp
  have h : env3491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3490_3491 : H12AffineEnvironment.transform 10 1159 env3490 = env3491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1159 env3490 == env3491) = true)

theorem identity3491 : scanCanonicalize (H12AffineFastState.compose env3491 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound3491 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env3492 : List Nat := [2,4,8,1,32,0,128,173,1,1024,1159,1197,1062,1060,1071,1156,1197,1190,1024,1071,1197,169,137,34,1199,136,1190,1060,1061,1071,1160,32,173,137,1061,137]

theorem envBound3492 : H12AffineFastState.Bounded env3492 := by
  intro p hp
  have h : env3492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3491_3492 : H12AffineEnvironment.transform 12 1062 env3491 = env3492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env3491 == env3492) = true)

theorem identity3492 : scanCanonicalize (H12AffineFastState.compose env3492 (packedSelected [2,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound3492 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env3493 : List Nat := [2,4,8,1,32,0,128,173,1,5,130,168,35,33,42,129,168,163,5,42,168,169,137,34,170,136,163,33,32,42,141,32,173,137,32,137]

theorem envBound3493 : H12AffineFastState.Bounded env3493 := by
  intro p hp
  have h : env3493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3492_3493 : H12AffineEnvironment.transform 9 5 env3492 = env3493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env3492 == env3493) = true)

theorem identity3493 : scanCanonicalize (H12AffineFastState.compose env3493 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3493 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env3494 : List Nat := [2,4,2,1,32,0,128,167,1,5,130,162,35,33,32,129,162,163,5,32,162,163,131,34,160,130,163,33,32,32,135,32,167,131,32,131]

theorem envBound3494 : H12AffineFastState.Bounded env3494 := by
  intro p hp
  have h : env3494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3493_3494 : H12AffineEnvironment.transform 2 2 env3493 = env3494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3493 == env3494) = true)

theorem identity3494 : scanCanonicalize (H12AffineFastState.compose env3494 (packedSelected [1,8,20] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound3494 : packedSelected [1,8,20] rootPS < 2^1333 := by decide +kernel

def env3495 : List Nat := [2,4,2,1,32,0,34,5,1,5,32,0,35,33,32,35,0,1,5,32,0,1,33,34,2,32,1,33,32,32,37,32,5,33,32,33]

theorem envBound3495 : H12AffineFastState.Bounded env3495 := by
  intro p hp
  have h : env3495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3494_3495 : H12AffineEnvironment.transform 6 34 env3494 = env3495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env3494 == env3495) = true)

theorem identity3495 : scanCanonicalize (H12AffineFastState.compose env3495 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3495 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env3496 : List Nat := [2,4,2,1,1,0,3,5,1,5,1,0,2,0,1,2,0,1,5,1,0,1,0,3,2,1,1,0,1,1,4,1,5,0,1,0]

theorem envBound3496 : H12AffineFastState.Bounded env3496 := by
  intro p hp
  have h : env3496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3495_3496 : H12AffineEnvironment.transform 4 1 env3495 = env3496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3495 == env3496) = true)

theorem identity3496 : scanCanonicalize (H12AffineFastState.compose env3496 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3497 : List Nat := [2,0,2,1,1,0,3,1,1,1,1,0,2,0,1,2,0,1,1,1,0,1,0,3,2,1,1,0,1,1,0,1,1,0,1,0]

theorem envBound3497 : H12AffineFastState.Bounded env3497 := by
  intro p hp
  have h : env3497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3496_3497 : H12AffineEnvironment.transform 1 0 env3496 = env3497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3496 == env3497) = true)

def env3498 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1212,8192,16384,32768,65536,1196,262144,1024,32768,1212,4194304,8388608,41003,8329,8388609,320572,16384,16401,19613,74794,12641341,189,17596,8478763,8389120]

theorem envBound3498 : H12AffineFastState.Bounded env3498 := by
  intro p hp
  have h : env3498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3468_3498 : H12AffineEnvironment.transform 7 189 env3468 = env3498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env3468 == env3498) = true)

theorem identity3498 : scanCanonicalize (H12AffineFastState.compose env3498 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50215) := by decide +kernel

theorem selectedBound3498 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env3499 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1212,8192,16384,32768,50215,1196,262144,1024,32768,1212,4194304,8388608,41003,8329,8388609,320572,16384,16401,19613,57357,12641341,189,17596,8430604,8389120]

theorem envBound3499 : H12AffineFastState.Bounded env3499 := by
  intro p hp
  have h : env3499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3498_3499 : H12AffineEnvironment.transform 15 50215 env3498 = env3499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50215 env3498 == env3499) = true)

def env3500 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1212,8192,16384,32768,50215,1196,262144,1024,32768,1212,4194304,4235392,41003,8329,4235393,320572,16384,16401,19613,57357,17597,189,17596,4195468,4235904]

theorem envBound3500 : H12AffineFastState.Bounded env3500 := by
  intro p hp
  have h : env3500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3499_3500 : H12AffineEnvironment.transform 22 4235392 env3499 = env3500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235392 env3499 == env3500) = true)

theorem identity3500 : scanCanonicalize (H12AffineFastState.compose env3500 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3500 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3501 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,32768,50215,1196,262144,1024,32768,1197,4194304,4235392,41003,8329,4235393,320557,16384,16384,19596,57357,17580,172,17581,4195468,4235904]

theorem envBound3501 : H12AffineFastState.Bounded env3501 := by
  intro p hp
  have h : env3501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3500_3501 : H12AffineEnvironment.transform 3 1 env3500 = env3501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3500 == env3501) = true)

theorem identity3501 : scanCanonicalize (H12AffineFastState.compose env3501 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound3501 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3502 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,32768,50215,1196,262144,1024,32768,1197,41000,168,41003,8329,169,320557,16384,16384,19596,57357,17580,172,17581,42148,680]

theorem envBound3502 : H12AffineFastState.Bounded env3502 := by
  intro p hp
  have h : env3502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3501_3502 : H12AffineEnvironment.transform 21 41000 env3501 = env3502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env3501 == env3502) = true)

theorem identity3502 : scanCanonicalize (H12AffineFastState.compose env3502 (packedSelected [0,3,5,7,10,17,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 19973) := by decide +kernel

theorem selectedBound3502 : packedSelected [0,3,5,7,10,17,20,21] rootPS < 2^1333 := by decide +kernel

def env3503 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,32768,50215,1196,19973,1024,32768,1197,41000,168,41003,8329,169,43560,16384,16384,19596,57357,17580,172,17581,42148,680]

theorem envBound3503 : H12AffineFastState.Bounded env3503 := by
  intro p hp
  have h : env3503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3502_3503 : H12AffineEnvironment.transform 17 19973 env3502 = env3503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19973 env3502 == env3503) = true)

theorem identity3503 : scanCanonicalize (H12AffineFastState.compose env3503 (packedSelected [1,3,11,13,17,23] rootPS)) = affineNative (2^(14+1) ^^^ 8713) := by decide +kernel

theorem selectedBound3503 : packedSelected [1,3,11,13,17,23] rootPS < 2^1333 := by decide +kernel

def env3504 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,8713,26158,1196,19973,1024,8713,1197,545,168,546,8329,169,2081,16384,16384,19596,16900,17580,172,17581,1709,680]

theorem envBound3504 : H12AffineFastState.Bounded env3504 := by
  intro p hp
  have h : env3504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3503_3504 : H12AffineEnvironment.transform 14 8713 env3503 = env3504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8713 env3503 == env3504) = true)

theorem identity3504 : scanCanonicalize (H12AffineFastState.compose env3504 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 1165) := by decide +kernel

theorem selectedBound3504 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3505 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,1165,8713,8867,1196,2696,1024,8713,1197,545,168,546,8329,169,2081,1165,1165,2049,1673,33,172,32,1709,680]

theorem envBound3505 : H12AffineFastState.Bounded env3505 := by
  intro p hp
  have h : env3505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3504_3505 : H12AffineEnvironment.transform 13 1165 env3504 = env3505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1165 env3504 == env3505) = true)

theorem identity3505 : scanCanonicalize (H12AffineFastState.compose env3505 (packedSelected [0,2,6] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound3505 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env3506 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,161,1165,680,514,1196,2696,1024,680,1197,545,168,546,40,169,2081,1165,1165,2049,1673,33,172,32,1709,680]

theorem envBound3506 : H12AffineFastState.Bounded env3506 := by
  intro p hp
  have h : env3506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3505_3506 : H12AffineEnvironment.transform 12 161 env3505 = env3506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env3505 == env3506) = true)

theorem identity3506 : scanCanonicalize (H12AffineFastState.compose env3506 (packedSelected [2,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound3506 : packedSelected [2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3507 : List Nat := [2,4,8,1,32,0,128,172,512,46,2048,131,161,163,680,514,130,2696,46,680,131,545,168,546,40,169,2081,163,163,2049,679,33,172,32,643,680]

theorem envBound3507 : H12AffineFastState.Bounded env3507 := by
  intro p hp
  have h : env3507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3506_3507 : H12AffineEnvironment.transform 9 46 env3506 = env3507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env3506 == env3507) = true)

theorem identity3507 : scanCanonicalize (H12AffineFastState.compose env3507 (packedSelected [0,1,2,3,4,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3507 : packedSelected [0,1,2,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env3508 : List Nat := [2,4,8,1,32,0,128,172,0,46,2048,131,161,163,168,2,130,2184,46,168,131,33,168,34,40,169,2081,163,163,2049,167,33,172,32,131,168]

theorem envBound3508 : H12AffineFastState.Bounded env3508 := by
  intro p hp
  have h : env3508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3507_3508 : H12AffineEnvironment.transform 8 0 env3507 = env3508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3507 == env3508) = true)

theorem identity3508 : scanCanonicalize (H12AffineFastState.compose env3508 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound3508 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env3509 : List Nat := [2,4,8,1,1,0,128,141,0,15,2048,131,128,130,137,2,130,2184,15,137,131,0,137,3,9,136,2048,130,130,2049,134,0,141,1,131,137]

theorem envBound3509 : H12AffineFastState.Bounded env3509 := by
  intro p hp
  have h : env3509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3508_3509 : H12AffineEnvironment.transform 4 1 env3508 = env3509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env3508 == env3509) = true)

theorem identity3509 : scanCanonicalize (H12AffineFastState.compose env3509 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound3509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3510 : List Nat := [2,4,8,1,1,0,9,4,0,15,2048,10,9,11,0,2,11,2049,15,0,10,0,0,3,9,1,2048,11,11,2049,15,0,4,1,10,0]

theorem envBound3510 : H12AffineFastState.Bounded env3510 := by
  intro p hp
  have h : env3510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3509_3510 : H12AffineEnvironment.transform 6 9 env3509 = env3510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env3509 == env3510) = true)

theorem identity3510 : scanCanonicalize (H12AffineFastState.compose env3510 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound3510 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3511 : List Nat := [2,4,8,1,1,0,9,4,0,15,10,10,9,11,0,2,11,11,15,0,10,0,0,3,9,1,10,11,11,11,15,0,4,1,10,0]

theorem envBound3511 : H12AffineFastState.Bounded env3511 := by
  intro p hp
  have h : env3511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3510_3511 : H12AffineEnvironment.transform 10 10 env3510 = env3511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env3510 == env3511) = true)

def env3512 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1212,8192,16384,32768,50215,1196,262144,1024,32768,1212,4194304,4235393,41003,8329,4235392,320572,16384,16401,19613,57357,17596,189,17596,4195469,4235905]

theorem envBound3512 : H12AffineFastState.Bounded env3512 := by
  intro p hp
  have h : env3512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3499_3512 : H12AffineEnvironment.transform 22 4235393 env3499 = env3512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235393 env3499 == env3512) = true)

theorem identity3512 : scanCanonicalize (H12AffineFastState.compose env3512 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound3512 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3513 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1028,8192,16384,32768,50215,1044,262144,1024,32768,1028,4194304,4235321,41003,8241,4235320,320572,16384,16401,19493,57357,17412,5,17412,4195381,4235833]

theorem envBound3513 : H12AffineFastState.Bounded env3513 := by
  intro p hp
  have h : env3513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3512_3513 : H12AffineEnvironment.transform 6 56 env3512 = env3513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env3512 == env3513) = true)

theorem identity3513 : scanCanonicalize (H12AffineFastState.compose env3513 (packedSelected [5,13,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8217) := by decide +kernel

theorem selectedBound3513 : packedSelected [5,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env3514 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1028,8192,16384,8217,25662,1044,262144,1024,8217,1028,4194304,4194336,50,8241,4194337,279589,16384,16401,19493,16404,17412,5,17412,4195381,4194848]

theorem envBound3514 : H12AffineFastState.Bounded env3514 := by
  intro p hp
  have h : env3514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3513_3514 : H12AffineEnvironment.transform 14 8217 env3513 = env3514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8217 env3513 == env3514) = true)

theorem identity3514 : scanCanonicalize (H12AffineFastState.compose env3514 (packedSelected [0,2,4,6,7,9,10,12] rootPS)) = affineNative (2^(17+1) ^^^ 2618) := by decide +kernel

theorem selectedBound3514 : packedSelected [0,2,4,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env3515 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1028,8192,16384,8217,25662,1044,2618,1024,8217,1028,4194304,4194336,50,8241,4194337,19999,16384,16401,19493,16404,17412,5,17412,4195381,4194848]

theorem envBound3515 : H12AffineFastState.Bounded env3515 := by
  intro p hp
  have h : env3515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3514_3515 : H12AffineEnvironment.transform 17 2618 env3514 = env3515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2618 env3514 == env3515) = true)

theorem identity3515 : scanCanonicalize (H12AffineFastState.compose env3515 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3515 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env3516 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,16384,8200,25647,1029,2603,1024,8200,1028,4194304,4194336,35,8224,4194337,19982,16384,16384,19493,16389,17412,5,17412,4195364,4194848]

theorem envBound3516 : H12AffineFastState.Bounded env3516 := by
  intro p hp
  have h : env3516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3515_3516 : H12AffineEnvironment.transform 3 1 env3515 = env3516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3515 == env3516) = true)

theorem identity3516 : scanCanonicalize (H12AffineFastState.compose env3516 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 522) := by decide +kernel

theorem selectedBound3516 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env3517 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,16384,8200,25647,1029,2603,1024,8200,1028,522,554,35,8224,555,19982,16384,16384,19493,16389,17412,5,17412,1582,42]

theorem envBound3517 : H12AffineFastState.Bounded env3517 := by
  intro p hp
  have h : env3517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3516_3517 : H12AffineEnvironment.transform 21 522 env3516 = env3517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 522 env3516 == env3517) = true)

theorem identity3517 : scanCanonicalize (H12AffineFastState.compose env3517 (packedSelected [0,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 10786) := by decide +kernel

theorem selectedBound3517 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env3518 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,10786,8200,3597,1029,2603,1024,8200,1028,522,554,35,8224,555,9260,10786,10786,9735,10791,11814,5,11814,1582,42]

theorem envBound3518 : H12AffineFastState.Bounded env3518 := by
  intro p hp
  have h : env3518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3517_3518 : H12AffineEnvironment.transform 13 10786 env3517 = env3518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10786 env3517 == env3518) = true)

theorem identity3518 : scanCanonicalize (H12AffineFastState.compose env3518 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 514) := by decide +kernel

theorem selectedBound3518 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env3519 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,514,2080,522,3597,1029,2603,1024,522,1028,522,554,35,546,555,1582,2080,2080,1029,2085,3108,5,3108,1582,42]

theorem envBound3519 : H12AffineFastState.Bounded env3519 := by
  intro p hp
  have h : env3519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3518_3519 : H12AffineEnvironment.transform 12 514 env3518 = env3519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 514 env3518 == env3519) = true)

theorem identity3519 : scanCanonicalize (H12AffineFastState.compose env3519 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound3519 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3520 : List Nat := [2,4,8,1,32,0,41,5,512,1024,1582,1028,514,1550,522,35,1029,1029,1024,522,1028,522,554,35,546,555,1582,1550,1550,1029,1547,522,5,522,1582,42]

theorem envBound3520 : H12AffineFastState.Bounded env3520 := by
  intro p hp
  have h : env3520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3519_3520 : H12AffineEnvironment.transform 10 1582 env3519 = env3520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env3519 == env3520) = true)

theorem identity3520 : scanCanonicalize (H12AffineFastState.compose env3520 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 527) := by decide +kernel

theorem selectedBound3520 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3521 : List Nat := [2,4,8,1,32,0,41,5,512,527,33,523,514,1,522,35,522,522,527,522,523,522,554,35,546,555,33,1,1,522,4,522,5,522,33,42]

theorem envBound3521 : H12AffineFastState.Bounded env3521 := by
  intro p hp
  have h : env3521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3520_3521 : H12AffineEnvironment.transform 9 527 env3520 = env3521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 527 env3520 == env3521) = true)

theorem identity3521 : scanCanonicalize (H12AffineFastState.compose env3521 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3521 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3522 : List Nat := [2,4,8,1,10,0,3,5,512,527,11,523,514,1,522,9,522,522,527,522,523,522,512,9,520,513,11,1,1,522,4,522,5,522,11,0]

theorem envBound3522 : H12AffineFastState.Bounded env3522 := by
  intro p hp
  have h : env3522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3521_3522 : H12AffineEnvironment.transform 4 10 env3521 = env3522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3521 == env3522) = true)

theorem identity3522 : scanCanonicalize (H12AffineFastState.compose env3522 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3523 : List Nat := [2,4,8,1,10,0,3,5,0,15,11,11,2,1,10,9,10,10,15,10,11,10,0,9,8,1,11,1,1,10,4,10,5,10,11,0]

theorem envBound3523 : H12AffineFastState.Bounded env3523 := by
  intro p hp
  have h : env3523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3522_3523 : H12AffineEnvironment.transform 8 0 env3522 = env3523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3522 == env3523) = true)

theorem identity3523 : scanCanonicalize (H12AffineFastState.compose env3523 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3523 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3524 : List Nat := [2,4,3,1,1,0,3,5,0,4,0,0,2,1,1,2,1,1,4,1,0,1,0,2,3,1,0,1,1,1,4,1,5,1,0,0]

theorem envBound3524 : H12AffineFastState.Bounded env3524 := by
  intro p hp
  have h : env3524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3523_3524 : H12AffineEnvironment.transform 2 3 env3523 = env3524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3523 == env3524) = true)

def env3525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323792,16384,16893,22641,74795,12644668,257,20560,8479126,8389613]

theorem envBound3525 : H12AffineFastState.Bounded env3525 := by
  intro p hp
  have h : env3525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3459_3525 : H12AffineEnvironment.transform 18 1025 env3459 = env3525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3459 == env3525) = true)

theorem identity3525 : scanCanonicalize (H12AffineFastState.compose env3525 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 20925) := by decide +kernel

theorem selectedBound3525 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,20925,41003,8329,20972,323792,16384,16893,22641,74795,4235393,257,20560,77867,21072]

theorem envBound3526 : H12AffineFastState.Bounded env3526 := by
  intro p hp
  have h : env3526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3525_3526 : H12AffineEnvironment.transform 22 20925 env3525 = env3526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20925 env3525 == env3526) = true)

def env3527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4604,262144,1025,32768,4096,4194304,445,41003,8329,492,303312,4096,4605,2161,74795,4235393,257,80,77867,592]

theorem envBound3527 : H12AffineFastState.Bounded env3527 := by
  intro p hp
  have h : env3527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3526_3527 : H12AffineEnvironment.transform 13 4096 env3526 = env3527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3526 == env3527) = true)

theorem identity3527 : scanCanonicalize (H12AffineFastState.compose env3527 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3527 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3528 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1025,32768,4096,4194304,445,41003,8329,444,303232,4096,4525,2081,74795,4235393,257,0,77867,512]

theorem envBound3528 : H12AffineFastState.Bounded env3528 := by
  intro p hp
  have h : env3528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3527_3528 : H12AffineEnvironment.transform 5 16 env3527 = env3528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3527 == env3528) = true)

theorem identity3528 : scanCanonicalize (H12AffineFastState.compose env3528 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound3528 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3529 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1025,32768,4096,41349,445,41003,8329,444,303232,4096,4525,2081,74795,260,257,0,77867,512]

theorem envBound3529 : H12AffineFastState.Bounded env3529 := by
  intro p hp
  have h : env3529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3528_3529 : H12AffineEnvironment.transform 21 41349 env3528 = env3529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env3528 == env3529) = true)

theorem identity3529 : scanCanonicalize (H12AffineFastState.compose env3529 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38843) := by decide +kernel

theorem selectedBound3529 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3530 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,38843,4524,262144,1025,32768,4096,41349,445,41003,8329,444,303232,4096,4525,2081,45968,260,257,0,42896,512]

theorem envBound3530 : H12AffineFastState.Bounded env3530 := by
  intro p hp
  have h : env3530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3529_3530 : H12AffineEnvironment.transform 15 38843 env3529 = env3530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38843 env3529 == env3530) = true)

theorem identity3530 : scanCanonicalize (H12AffineFastState.compose env3530 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14137) := by decide +kernel

theorem selectedBound3530 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3531 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,14137,8322,4524,262144,1025,14137,4096,5820,445,5906,8329,444,268217,4096,4525,2081,1193,260,257,0,4265,512]

theorem envBound3531 : H12AffineFastState.Bounded env3531 := by
  intro p hp
  have h : env3531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3530_3531 : H12AffineEnvironment.transform 14 14137 env3530 = env3531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14137 env3530 == env3531) = true)

theorem identity3531 : scanCanonicalize (H12AffineFastState.compose env3531 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(17+1) ^^^ 7953) := by decide +kernel

theorem selectedBound3531 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env3532 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,14137,8322,4524,7953,1025,14137,4096,5820,445,5906,8329,444,2216,4096,4525,2081,1193,260,257,0,4265,512]

theorem envBound3532 : H12AffineFastState.Bounded env3532 := by
  intro p hp
  have h : env3532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3531_3532 : H12AffineEnvironment.transform 17 7953 env3531 = env3532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7953 env3531 == env3532) = true)

theorem identity3532 : scanCanonicalize (H12AffineFastState.compose env3532 (packedSelected [0,3,4,5,7,9,10,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound3532 : packedSelected [0,3,4,5,7,9,10,18,23] rootPS < 2^1333 := by decide +kernel

def env3533 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,4096,13972,8322,4097,7868,1025,13972,4096,5820,16,5823,8329,17,2216,4096,4096,2081,1193,169,172,0,4265,512]

theorem envBound3533 : H12AffineFastState.Bounded env3533 := by
  intro p hp
  have h : env3533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3532_3533 : H12AffineEnvironment.transform 7 173 env3532 = env3533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3532 == env3533) = true)

theorem identity3533 : scanCanonicalize (H12AffineFastState.compose env3533 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound3533 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3534 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2195,8192,2195,11783,8322,2194,1583,1025,11783,2195,3631,16,3628,8329,17,2216,2195,2195,2081,1193,169,172,0,2106,512]

theorem envBound3534 : H12AffineFastState.Bounded env3534 := by
  intro p hp
  have h : env3534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3533_3534 : H12AffineEnvironment.transform 11 2195 env3533 = env3534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env3533 == env3534) = true)

def env3535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4604,262144,1025,32768,4096,4194304,444,41003,8329,493,303313,4097,4604,2160,74795,4235393,257,81,77867,593]

theorem envBound3535 : H12AffineFastState.Bounded env3535 := by
  intro p hp
  have h : env3535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3526_3535 : H12AffineEnvironment.transform 13 4097 env3526 = env3535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env3526 == env3535) = true)

def env3536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4604,262144,1025,32768,4096,41088,444,41003,8329,493,303313,4097,4604,2160,74795,1,257,81,77867,593]

theorem envBound3536 : H12AffineFastState.Bounded env3536 := by
  intro p hp
  have h : env3536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3535_3536 : H12AffineEnvironment.transform 21 41088 env3535 = env3536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3535 == env3536) = true)

theorem identity3536 : scanCanonicalize (H12AffineFastState.compose env3536 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound3536 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3537 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,4097,32768,65536,4264,262144,1025,32768,4096,41088,232,41003,8329,185,303313,4097,4264,2160,74795,1,85,81,77867,593]

theorem envBound3537 : H12AffineFastState.Bounded env3537 := by
  intro p hp
  have h : env3537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3536_3537 : H12AffineEnvironment.transform 7 84 env3536 = env3537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env3536 == env3537) = true)

theorem identity3537 : scanCanonicalize (H12AffineFastState.compose env3537 (packedSelected [0,5,7,8,10,11,13,17,18,20,23,24,26,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 106039) := by decide +kernel

theorem selectedBound3537 : packedSelected [0,5,7,8,10,11,13,17,18,20,23,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env3538 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,4097,32768,65536,4264,106039,1025,32768,4096,41088,232,41003,8329,185,81638,4097,4264,2160,74795,1,85,81,77867,593]

theorem envBound3538 : H12AffineFastState.Bounded env3538 := by
  intro p hp
  have h : env3538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3537_3538 : H12AffineEnvironment.transform 17 106039 env3537 = env3538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 106039 env3537 == env3538) = true)

def env3539 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,32768,65536,4096,106039,1025,32768,4096,41000,64,41003,8225,17,81486,4097,4096,2160,74795,1,85,81,77867,593]

theorem envBound3539 : H12AffineFastState.Bounded env3539 := by
  intro p hp
  have h : env3539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3538_3539 : H12AffineEnvironment.transform 6 40 env3538 = env3539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3538 == env3539) = true)

theorem identity3539 : scanCanonicalize (H12AffineFastState.compose env3539 (packedSelected [0,7,17,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound3539 : packedSelected [0,7,17,20,21] rootPS < 2^1333 := by decide +kernel

def env3540 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,32768,32803,4096,7700,1025,32768,4096,41000,64,41003,8225,17,48749,4097,4096,2160,41992,1,85,81,45064,593]

theorem envBound3540 : H12AffineFastState.Bounded env3540 := by
  intro p hp
  have h : env3540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3539_3540 : H12AffineEnvironment.transform 15 32803 env3539 = env3540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env3539 == env3540) = true)

theorem identity3540 : scanCanonicalize (H12AffineFastState.compose env3540 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound3540 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3541 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,13885,13854,4096,7700,1025,13885,4096,5653,64,5654,8225,17,2128,4097,4096,2160,4661,1,85,81,1589,593]

theorem envBound3541 : H12AffineFastState.Bounded env3541 := by
  intro p hp
  have h : env3541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3540_3541 : H12AffineEnvironment.transform 14 13885 env3540 = env3541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env3540 == env3541) = true)

theorem identity3541 : scanCanonicalize (H12AffineFastState.compose env3541 (packedSelected [0,1,2,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound3541 : packedSelected [0,1,2,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env3542 : List Nat := [2,4,8,16,32,10,40,30,512,1024,2048,4096,8192,4097,13885,13854,4096,7700,1025,13885,4096,5653,10,5654,8225,17,2074,4097,4096,2106,4661,1,31,27,1589,539]

theorem envBound3542 : H12AffineFastState.Bounded env3542 := by
  intro p hp
  have h : env3542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3541_3542 : H12AffineEnvironment.transform 5 10 env3541 = env3542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env3541 == env3542) = true)

theorem identity3542 : scanCanonicalize (H12AffineFastState.compose env3542 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3542 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env3543 : List Nat := [2,4,8,16,32,10,40,30,512,1024,2048,1588,8192,1589,8201,8234,1588,2080,1025,8201,1588,33,10,34,8225,17,2074,1589,1588,2106,1025,1,31,27,1589,539]

theorem envBound3543 : H12AffineFastState.Bounded env3543 := by
  intro p hp
  have h : env3543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3542_3543 : H12AffineEnvironment.transform 11 1588 env3542 = env3543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3542 == env3543) = true)

theorem identity3543 : scanCanonicalize (H12AffineFastState.compose env3543 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound3543 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3544 : List Nat := [2,4,8,16,32,10,40,30,512,1024,1556,1588,8192,1589,8201,8234,1588,1588,1025,8201,1588,33,10,34,8225,17,1550,1589,1588,1582,1025,1,31,27,1589,539]

theorem envBound3544 : H12AffineFastState.Bounded env3544 := by
  intro p hp
  have h : env3544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3543_3544 : H12AffineEnvironment.transform 10 1556 env3543 = env3544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env3543 == env3544) = true)

theorem identity3544 : scanCanonicalize (H12AffineFastState.compose env3544 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3544 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3545 : List Nat := [2,4,8,10,32,10,40,4,512,1024,1550,1582,8192,1583,8201,8234,1582,1582,1025,8201,1582,33,10,34,8225,11,1550,1583,1582,1582,1025,1,5,1,1583,513]

theorem envBound3545 : H12AffineFastState.Bounded env3545 := by
  intro p hp
  have h : env3545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3544_3545 : H12AffineEnvironment.transform 3 10 env3544 = env3545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3544 == env3545) = true)

theorem identity3545 : scanCanonicalize (H12AffineFastState.compose env3545 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound3545 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3546 : List Nat := [2,4,8,10,32,10,40,4,512,1024,1550,1582,1031,1583,1038,1069,1582,1582,1025,1038,1582,33,10,34,1062,11,1550,1583,1582,1582,1025,1,5,1,1583,513]

theorem envBound3546 : H12AffineFastState.Bounded env3546 := by
  intro p hp
  have h : env3546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3545_3546 : H12AffineEnvironment.transform 12 1031 env3545 = env3546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env3545 == env3546) = true)

theorem identity3546 : scanCanonicalize (H12AffineFastState.compose env3546 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound3546 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3547 : List Nat := [2,4,8,10,32,10,40,4,15,1024,1025,1057,1031,1056,1038,1069,1057,1057,1025,1038,1057,33,10,34,1062,11,1025,1056,1057,1057,1025,1,5,1,1056,14]

theorem envBound3547 : H12AffineFastState.Bounded env3547 := by
  intro p hp
  have h : env3547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3546_3547 : H12AffineEnvironment.transform 8 15 env3546 = env3547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env3546 == env3547) = true)

theorem identity3547 : scanCanonicalize (H12AffineFastState.compose env3547 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3547 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3548 : List Nat := [2,4,2,0,32,0,34,4,5,1024,1025,1057,1031,1056,1028,1063,1057,1057,1025,1028,1057,33,0,34,1062,1,1025,1056,1057,1057,1025,1,5,1,1056,4]

theorem envBound3548 : H12AffineFastState.Bounded env3548 := by
  intro p hp
  have h : env3548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3547_3548 : H12AffineEnvironment.transform 2 2 env3547 = env3548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3547 == env3548) = true)

theorem identity3548 : scanCanonicalize (H12AffineFastState.compose env3548 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3548 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3549 : List Nat := [2,0,2,0,32,0,34,0,1,1024,1025,1057,1027,1056,1024,1059,1057,1057,1025,1024,1057,33,0,34,1058,1,1025,1056,1057,1057,1025,1,1,1,1056,0]

theorem envBound3549 : H12AffineFastState.Bounded env3549 := by
  intro p hp
  have h : env3549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3548_3549 : H12AffineEnvironment.transform 1 0 env3548 = env3549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3548 == env3549) = true)

theorem identity3549 : scanCanonicalize (H12AffineFastState.compose env3549 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound3549 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3550 : List Nat := [2,0,2,0,32,0,34,0,1,32,33,1,35,0,32,3,1,1,33,32,1,33,0,34,2,1,33,0,1,1,33,1,1,1,0,0]

theorem envBound3550 : H12AffineFastState.Bounded env3550 := by
  intro p hp
  have h : env3550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3549_3550 : H12AffineEnvironment.transform 9 32 env3549 = env3550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env3549 == env3550) = true)

def leafEnv3550 : List Nat := [2,0,2,0,32,0,34,0,1,32,33,1,35,0,32,3,1,1,33,32,1,33,0,34,32,2,1,1,33,0,1,1,33,1,1,1,1,34,0,0,1,1,0]

def active3550 : List Nat := [0,4]

def tree3550 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3550 : H12WitnessSearch.Good tree3550 := H12GlobalWitnessIndex.good

theorem leafIdentity3550 : H12AffineFastState.composeSystem env3550 rootObs = leafEnv3550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3550 rootObs == leafEnv3550) = true)

theorem terminalChecked3550 : H12PackedTerminal.terminalCheckFast leafEnv3550 active3550 tree3550 = true := by decide +kernel

def env3551 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,4097,32768,65536,4097,106039,1025,32768,4096,41001,65,41003,8224,16,81487,4097,4097,2160,74795,1,85,81,77867,593]

theorem envBound3551 : H12AffineFastState.Bounded env3551 := by
  intro p hp
  have h : env3551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3538_3551 : H12AffineEnvironment.transform 6 41 env3538 = env3551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3538 == env3551) = true)

theorem identity3551 : scanCanonicalize (H12AffineFastState.compose env3551 (packedSelected [0,7,17,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound3551 : packedSelected [0,7,17,20,21] rootPS < 2^1333 := by decide +kernel

def env3552 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,4097,32768,8314,4097,48717,1025,32768,4096,41001,65,41003,8224,16,7733,4097,4097,2160,1105,1,85,81,4177,593]

theorem envBound3552 : H12AffineFastState.Bounded env3552 := by
  intro p hp
  have h : env3552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3551_3552 : H12AffineEnvironment.transform 15 8314 env3551 = env3552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env3551 == env3552) = true)

theorem identity3552 : scanCanonicalize (H12AffineFastState.compose env3552 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1637) := by decide +kernel

theorem selectedBound3552 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3553 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1637,8192,1636,32768,8314,1636,43048,1025,32768,1637,41001,65,41003,8224,16,2128,1636,1636,2160,1105,1,85,81,1588,593]

theorem envBound3553 : H12AffineFastState.Bounded env3553 := by
  intro p hp
  have h : env3553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3552_3553 : H12AffineEnvironment.transform 11 1637 env3552 = env3553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1637 env3552 == env3553) = true)

theorem identity3553 : scanCanonicalize (H12AffineFastState.compose env3553 (packedSelected [6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8226) := by decide +kernel

theorem selectedBound3553 : packedSelected [6,10] rootPS < 2^1333 := by decide +kernel

def env3554 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1637,8192,1636,8226,8314,1636,2058,1025,8226,1637,11,65,9,8224,16,2128,1636,1636,2160,1105,1,85,81,1588,593]

theorem envBound3554 : H12AffineFastState.Bounded env3554 := by
  intro p hp
  have h : env3554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3553_3554 : H12AffineEnvironment.transform 14 8226 env3553 = env3554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8226 env3553 == env3554) = true)

theorem identity3554 : scanCanonicalize (H12AffineFastState.compose env3554 (packedSelected [2,3,5,6,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound3554 : packedSelected [2,3,5,6,11,18] rootPS < 2^1333 := by decide +kernel

def env3555 : List Nat := [2,4,8,16,32,43,41,63,512,1024,2048,1550,8192,1551,8226,8209,1551,2058,1025,8226,1550,11,42,9,8224,16,2107,1551,1551,2075,1082,1,62,58,1588,570]

theorem envBound3555 : H12AffineFastState.Bounded env3555 := by
  intro p hp
  have h : env3555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3554_3555 : H12AffineEnvironment.transform 5 43 env3554 = env3555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env3554 == env3555) = true)

theorem identity3555 : scanCanonicalize (H12AffineFastState.compose env3555 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3555 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env3556 : List Nat := [2,4,8,16,11,0,2,20,512,1024,2048,1550,8192,1551,8201,8209,1551,2058,1025,8201,1550,11,1,9,8203,16,2064,1551,1551,2075,1041,1,21,17,1567,529]

theorem envBound3556 : H12AffineFastState.Bounded env3556 := by
  intro p hp
  have h : env3556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3555_3556 : H12AffineEnvironment.transform 4 11 env3555 = env3556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3555 == env3556) = true)

theorem identity3556 : scanCanonicalize (H12AffineFastState.compose env3556 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound3556 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env3557 : List Nat := [2,4,8,16,11,0,2,20,512,1024,2048,1550,8,1551,1,25,1551,2058,1025,1,1550,11,1,9,3,16,2064,1551,1551,2075,1041,1,21,17,1567,529]

theorem envBound3557 : H12AffineFastState.Bounded env3557 := by
  intro p hp
  have h : env3557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3556_3557 : H12AffineEnvironment.transform 12 8 env3556 = env3557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env3556 == env3557) = true)

theorem identity3557 : scanCanonicalize (H12AffineFastState.compose env3557 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound3557 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env3558 : List Nat := [2,4,8,16,11,0,2,20,512,1024,512,1550,8,1551,1,25,1551,522,1025,1,1550,11,1,9,3,16,528,1551,1551,539,1041,1,21,17,1567,529]

theorem envBound3558 : H12AffineFastState.Bounded env3558 := by
  intro p hp
  have h : env3558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3557_3558 : H12AffineEnvironment.transform 10 512 env3557 = env3558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env3557 == env3558) = true)

theorem identity3558 : scanCanonicalize (H12AffineFastState.compose env3558 (packedSelected [2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3558 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env3559 : List Nat := [2,4,8,1,11,0,2,5,512,1024,512,1550,8,1551,1,8,1551,522,1025,1,1550,11,1,9,3,1,513,1551,1551,522,1024,1,4,0,1550,512]

theorem envBound3559 : H12AffineFastState.Bounded env3559 := by
  intro p hp
  have h : env3559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3558_3559 : H12AffineEnvironment.transform 3 1 env3558 = env3559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3558 == env3559) = true)

theorem identity3559 : scanCanonicalize (H12AffineFastState.compose env3559 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound3559 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3560 : List Nat := [2,4,8,1,11,0,2,5,1,1024,1,1039,8,1038,1,8,1038,11,1025,1,1039,11,1,9,3,1,0,1038,1038,11,1024,1,4,0,1039,1]

theorem envBound3560 : H12AffineFastState.Bounded env3560 := by
  intro p hp
  have h : env3560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3559_3560 : H12AffineEnvironment.transform 8 1 env3559 = env3560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3559 == env3560) = true)

theorem identity3560 : scanCanonicalize (H12AffineFastState.compose env3560 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3561 : List Nat := [2,4,3,1,0,0,2,5,1,1024,1,1028,3,1029,1,3,1029,0,1025,1,1028,0,1,2,3,1,0,1029,1029,0,1024,1,4,0,1028,1]

theorem envBound3561 : H12AffineFastState.Bounded env3561 := by
  intro p hp
  have h : env3561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3560_3561 : H12AffineEnvironment.transform 2 3 env3560 = env3561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3560 == env3561) = true)

def env3562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4604,262144,1025,32768,4096,41089,444,41003,8329,493,303313,4097,4604,2160,74795,0,257,81,77867,593]

theorem envBound3562 : H12AffineFastState.Bounded env3562 := by
  intro p hp
  have h : env3562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3535_3562 : H12AffineEnvironment.transform 21 41089 env3535 = env3562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3535 == env3562) = true)

theorem identity3562 : scanCanonicalize (H12AffineFastState.compose env3562 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3562 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3563 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,4097,32768,65536,4344,262144,1025,32768,4096,41089,184,41003,8329,233,303313,4097,4344,2160,74795,0,5,81,77867,593]

theorem envBound3563 : H12AffineFastState.Bounded env3563 := by
  intro p hp
  have h : env3563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3562_3563 : H12AffineEnvironment.transform 7 4 env3562 = env3563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3562 == env3563) = true)

theorem identity3563 : scanCanonicalize (H12AffineFastState.compose env3563 (packedSelected [0,7,11,13,17,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 38591) := by decide +kernel

theorem selectedBound3563 : packedSelected [0,7,11,13,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3564 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,4097,32768,38591,4344,262144,1025,32768,4096,41089,184,41003,8329,233,303313,4097,4344,2160,45716,0,5,81,42644,593]

theorem envBound3564 : H12AffineFastState.Bounded env3564 := by
  intro p hp
  have h : env3564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3563_3564 : H12AffineEnvironment.transform 15 38591 env3563 = env3564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38591 env3563 == env3564) = true)

def env3565 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,32768,38471,4096,262144,1025,32768,4096,41081,64,41003,8305,17,303145,4097,4096,2160,45676,0,5,81,42604,593]

theorem envBound3565 : H12AffineFastState.Bounded env3565 := by
  intro p hp
  have h : env3565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3564_3565 : H12AffineEnvironment.transform 6 120 env3564 = env3565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env3564 == env3565) = true)

theorem identity3565 : scanCanonicalize (H12AffineFastState.compose env3565 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 7748) := by decide +kernel

theorem selectedBound3565 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3566 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,32768,38471,4096,7748,1025,32768,4096,41081,64,41003,8305,17,48749,4097,4096,2160,45676,0,5,81,42604,593]

theorem envBound3566 : H12AffineFastState.Bounded env3566 := by
  intro p hp
  have h : env3566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3565_3566 : H12AffineEnvironment.transform 17 7748 env3565 = env3566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7748 env3565 == env3566) = true)

theorem identity3566 : scanCanonicalize (H12AffineFastState.compose env3566 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13932) := by decide +kernel

theorem selectedBound3566 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env3567 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,13932,8235,4096,7748,1025,13932,4096,5653,64,5703,8305,17,2049,4097,4096,2160,1024,0,5,81,4096,593]

theorem envBound3567 : H12AffineFastState.Bounded env3567 := by
  intro p hp
  have h : env3567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3566_3567 : H12AffineEnvironment.transform 14 13932 env3566 = env3567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13932 env3566 == env3567) = true)

theorem identity3567 : scanCanonicalize (H12AffineFastState.compose env3567 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound3567 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3568 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,1030,4097,4714,1069,4096,7748,1025,4714,4096,5653,64,5703,1143,17,2049,4097,4096,2160,1024,0,5,81,4096,593]

theorem envBound3568 : H12AffineFastState.Bounded env3568 := by
  intro p hp
  have h : env3568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3567_3568 : H12AffineEnvironment.transform 12 1030 env3567 = env3568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env3567 == env3568) = true)

theorem identity3568 : scanCanonicalize (H12AffineFastState.compose env3568 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3568 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3569 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,1030,4097,4666,1069,4096,7700,1025,4666,4096,5653,16,5655,1063,17,2049,4097,4096,2080,1024,0,5,1,4096,513]

theorem envBound3569 : H12AffineFastState.Bounded env3569 := by
  intro p hp
  have h : env3569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3568_3569 : H12AffineEnvironment.transform 5 16 env3568 = env3569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3568 == env3569) = true)

theorem identity3569 : scanCanonicalize (H12AffineFastState.compose env3569 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound3569 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env3570 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,544,1030,545,26,1069,544,3124,1025,26,544,1077,16,1079,1063,17,2049,545,544,2080,1024,0,5,1,544,513]

theorem envBound3570 : H12AffineFastState.Bounded env3570 := by
  intro p hp
  have h : env3570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3569_3570 : H12AffineEnvironment.transform 11 544 env3569 = env3570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env3569 == env3570) = true)

theorem identity3570 : scanCanonicalize (H12AffineFastState.compose env3570 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound3570 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3571 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1550,544,1030,545,26,1069,544,570,1025,26,544,1077,16,1079,1063,17,1551,545,544,1582,1024,0,5,1,544,513]

theorem envBound3571 : H12AffineFastState.Bounded env3571 := by
  intro p hp
  have h : env3571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3570_3571 : H12AffineEnvironment.transform 10 1550 env3570 = env3571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env3570 == env3571) = true)

theorem identity3571 : scanCanonicalize (H12AffineFastState.compose env3571 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 560) := by decide +kernel

theorem selectedBound3571 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env3572 : List Nat := [2,4,8,16,32,16,40,4,512,560,62,544,566,545,26,541,544,570,561,26,544,517,16,519,535,17,63,545,544,30,560,0,5,1,544,513]

theorem envBound3572 : H12AffineFastState.Bounded env3572 := by
  intro p hp
  have h : env3572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3571_3572 : H12AffineEnvironment.transform 9 560 env3571 = env3572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 560 env3571 == env3572) = true)

theorem identity3572 : scanCanonicalize (H12AffineFastState.compose env3572 (packedSelected [3,7] rootPS)) = affineNative (2^(8+1) ^^^ 63) := by decide +kernel

theorem selectedBound3572 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env3573 : List Nat := [2,4,8,16,32,16,40,4,63,15,62,31,9,30,26,34,31,5,14,26,31,58,16,56,40,17,63,30,31,30,15,0,5,1,31,62]

theorem envBound3573 : H12AffineFastState.Bounded env3573 := by
  intro p hp
  have h : env3573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3572_3573 : H12AffineEnvironment.transform 8 63 env3572 = env3573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 63 env3572 == env3573) = true)

theorem identity3573 : scanCanonicalize (H12AffineFastState.compose env3573 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3573 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3574 : List Nat := [2,4,8,10,32,10,40,4,37,15,36,5,9,4,0,34,5,5,14,0,5,32,10,34,40,11,37,4,5,4,15,0,5,1,5,36]

theorem envBound3574 : H12AffineFastState.Bounded env3574 := by
  intro p hp
  have h : env3574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3573_3574 : H12AffineEnvironment.transform 3 10 env3573 = env3574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3573 == env3574) = true)

theorem identity3574 : scanCanonicalize (H12AffineFastState.compose env3574 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3574 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env3575 : List Nat := [2,4,8,10,0,10,8,4,5,15,4,5,9,4,0,2,5,5,14,0,5,0,10,2,8,11,5,4,5,4,15,0,5,1,5,4]

theorem envBound3575 : H12AffineFastState.Bounded env3575 := by
  intro p hp
  have h : env3575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3574_3575 : H12AffineEnvironment.transform 4 0 env3574 = env3575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3574 == env3575) = true)

theorem identity3575 : scanCanonicalize (H12AffineFastState.compose env3575 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3576 : List Nat := [2,4,2,0,0,0,2,4,5,5,4,5,3,4,0,2,5,5,4,0,5,0,0,2,2,1,5,4,5,4,5,0,5,1,5,4]

theorem envBound3576 : H12AffineFastState.Bounded env3576 := by
  intro p hp
  have h : env3576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3575_3576 : H12AffineEnvironment.transform 2 2 env3575 = env3576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3575 == env3576) = true)

def env3577 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,32768,38470,4097,262144,1025,32768,4096,41080,65,41003,8304,16,303144,4097,4097,2160,45677,0,5,81,42605,593]

theorem envBound3577 : H12AffineFastState.Bounded env3577 := by
  intro p hp
  have h : env3577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3564_3577 : H12AffineEnvironment.transform 6 121 env3564 = env3577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env3564 == env3577) = true)

theorem identity3577 : scanCanonicalize (H12AffineFastState.compose env3577 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 48668) := by decide +kernel

theorem selectedBound3577 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3578 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,32768,38470,4097,48668,1025,32768,4096,41080,65,41003,8304,16,7732,4097,4097,2160,45677,0,5,81,42605,593]

theorem envBound3578 : H12AffineFastState.Bounded env3578 := by
  intro p hp
  have h : env3578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3577_3578 : H12AffineEnvironment.transform 17 48668 env3577 = env3578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48668 env3577 == env3578) = true)

theorem identity3578 : scanCanonicalize (H12AffineFastState.compose env3578 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13933) := by decide +kernel

theorem selectedBound3578 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env3579 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,13933,8235,4097,2161,1025,13933,4096,5653,65,5702,8304,16,7732,4097,4097,2160,1024,0,5,81,4096,593]

theorem envBound3579 : H12AffineFastState.Bounded env3579 := by
  intro p hp
  have h : env3579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3578_3579 : H12AffineEnvironment.transform 14 13933 env3578 = env3579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13933 env3578 == env3579) = true)

theorem identity3579 : scanCanonicalize (H12AffineFastState.compose env3579 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4626) := by decide +kernel

theorem selectedBound3579 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3580 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,4626,4097,1151,4665,4097,2161,1025,1151,4096,5653,65,5702,4706,16,7732,4097,4097,2160,1024,0,5,81,4096,593]

theorem envBound3580 : H12AffineFastState.Bounded env3580 := by
  intro p hp
  have h : env3580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3579_3580 : H12AffineEnvironment.transform 12 4626 env3579 = env3580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4626 env3579 == env3580) = true)

theorem identity3580 : scanCanonicalize (H12AffineFastState.compose env3580 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3580 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3581 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,4626,4097,1071,4665,4097,2081,1025,1071,4096,5653,17,5654,4658,16,7732,4097,4097,2080,1024,0,5,1,4096,513]

theorem envBound3581 : H12AffineFastState.Bounded env3581 := by
  intro p hp
  have h : env3581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3580_3581 : H12AffineEnvironment.transform 5 16 env3580 = env3581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3580 == env3581) = true)

theorem identity3581 : scanCanonicalize (H12AffineFastState.compose env3581 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound3581 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env3582 : List Nat := [2,4,8,16,32,16,41,4,512,1024,539,4096,4626,4097,1071,4665,4097,570,1025,1071,4096,5653,17,5654,4658,16,5167,4097,4097,571,1024,0,5,1,4096,513]

theorem envBound3582 : H12AffineFastState.Bounded env3582 := by
  intro p hp
  have h : env3582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3581_3582 : H12AffineEnvironment.transform 10 539 env3581 = env3582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env3581 == env3582) = true)

theorem identity3582 : scanCanonicalize (H12AffineFastState.compose env3582 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound3582 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3583 : List Nat := [2,4,8,16,32,16,41,4,512,1024,539,544,50,545,1071,25,545,570,1025,1071,544,1077,17,1078,18,16,1551,545,545,571,1024,0,5,1,544,513]

theorem envBound3583 : H12AffineFastState.Bounded env3583 := by
  intro p hp
  have h : env3583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3582_3583 : H12AffineEnvironment.transform 11 544 env3582 = env3583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env3582 == env3583) = true)

theorem identity3583 : scanCanonicalize (H12AffineFastState.compose env3583 (packedSelected [0,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound3583 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env3584 : List Nat := [2,4,8,16,32,16,41,4,4,1024,31,36,50,37,1071,25,37,62,1025,1071,36,1077,17,1078,18,16,1035,37,37,63,1024,0,5,1,36,5]

theorem envBound3584 : H12AffineFastState.Bounded env3584 := by
  intro p hp
  have h : env3584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3583_3584 : H12AffineEnvironment.transform 8 4 env3583 = env3584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env3583 == env3584) = true)

theorem identity3584 : scanCanonicalize (H12AffineFastState.compose env3584 (packedSelected [1,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound3584 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env3585 : List Nat := [2,4,8,16,32,16,41,4,4,46,31,36,50,37,1,25,37,62,47,1,36,27,17,24,18,16,37,37,37,63,46,0,5,1,36,5]

theorem envBound3585 : H12AffineFastState.Bounded env3585 := by
  intro p hp
  have h : env3585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3584_3585 : H12AffineEnvironment.transform 9 46 env3584 = env3585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env3584 == env3585) = true)

theorem identity3585 : scanCanonicalize (H12AffineFastState.compose env3585 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3585 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env3586 : List Nat := [2,4,8,16,26,16,19,4,4,20,31,30,8,31,1,25,31,4,21,1,30,27,17,24,18,16,31,31,31,5,20,0,5,1,30,5]

theorem envBound3586 : H12AffineFastState.Bounded env3586 := by
  intro p hp
  have h : env3586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3585_3586 : H12AffineEnvironment.transform 4 26 env3585 = env3586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3585 == env3586) = true)

theorem identity3586 : scanCanonicalize (H12AffineFastState.compose env3586 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound3586 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3587 : List Nat := [2,4,8,15,5,15,12,4,4,11,0,1,8,0,1,6,0,4,10,1,1,4,14,7,13,15,0,0,0,5,11,0,5,1,1,5]

theorem envBound3587 : H12AffineFastState.Bounded env3587 := by
  intro p hp
  have h : env3587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3586_3587 : H12AffineEnvironment.transform 3 15 env3586 = env3587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env3586 == env3587) = true)

theorem identity3587 : scanCanonicalize (H12AffineFastState.compose env3587 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3588 : List Nat := [2,4,3,4,5,4,7,4,4,0,0,1,3,0,1,6,0,4,1,1,1,4,5,7,6,4,0,0,0,5,0,0,5,1,1,5]

theorem envBound3588 : H12AffineFastState.Bounded env3588 := by
  intro p hp
  have h : env3588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3587_3588 : H12AffineEnvironment.transform 2 3 env3587 = env3588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3587 == env3588) = true)

theorem identity3588 : scanCanonicalize (H12AffineFastState.compose env3588 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3588 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3589 : List Nat := [2,1,3,1,0,1,2,1,1,0,0,1,3,0,1,3,0,1,1,1,1,1,0,2,3,1,0,0,0,0,0,0,0,1,1,0]

theorem envBound3589 : H12AffineFastState.Bounded env3589 := by
  intro p hp
  have h : env3589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3588_3589 : H12AffineEnvironment.transform 1 1 env3588 = env3589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3588 == env3589) = true)

def env3590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849105,16385,16892,547952,598058,12644668,525568,545873,8479126,8914924]

theorem envBound3590 : H12AffineFastState.Bounded env3590 := by
  intro p hp
  have h : env3590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3458_3590 : H12AffineEnvironment.transform 27 16385 env3458 = env3590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env3458 == env3590) = true)

def env3591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323793,16385,16892,22640,74794,12644668,256,20561,8479126,8389612]

theorem envBound3591 : H12AffineFastState.Bounded env3591 := by
  intro p hp
  have h : env3591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3590_3591 : H12AffineEnvironment.transform 18 1024 env3590 = env3591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3590 == env3591) = true)

theorem identity3591 : scanCanonicalize (H12AffineFastState.compose env3591 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4240428) := by decide +kernel

theorem selectedBound3591 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,4240428,41003,8329,4240508,323793,16385,16892,22640,74794,17680,256,20561,4314554,4241344]

theorem envBound3592 : H12AffineFastState.Bounded env3592 := by
  intro p hp
  have h : env3592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3591_3592 : H12AffineEnvironment.transform 22 4240428 env3591 = env3592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240428 env3591 == env3592) = true)

def env3593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,46528,492,41003,8329,444,323793,16385,16892,22640,74794,17680,256,20561,90234,512]

theorem envBound3593 : H12AffineFastState.Bounded env3593 := by
  intro p hp
  have h : env3593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3592_3593 : H12AffineEnvironment.transform 21 46528 env3592 = env3593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46528 env3592 == env3593) = true)

theorem identity3593 : scanCanonicalize (H12AffineFastState.compose env3593 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound3593 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,32768,65536,1465,262144,1024,32768,1093,41349,492,41003,8329,444,320660,16385,16892,19509,74794,17680,256,17428,90234,512]

theorem envBound3594 : H12AffineFastState.Bounded env3594 := by
  intro p hp
  have h : env3594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3593_3594 : H12AffineEnvironment.transform 11 1093 env3593 = env3594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env3593 == env3594) = true)

theorem identity3594 : scanCanonicalize (H12AffineFastState.compose env3594 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33790) := by decide +kernel

theorem selectedBound3594 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,32768,33790,1465,262144,1024,32768,1093,41349,492,41003,8329,444,320660,16385,16892,19509,42964,17680,256,17428,58244,512]

theorem envBound3595 : H12AffineFastState.Bounded env3595 := by
  intro p hp
  have h : env3595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3594_3595 : H12AffineEnvironment.transform 15 33790 env3594 = env3595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33790 env3594 == env3595) = true)

theorem identity3595 : scanCanonicalize (H12AffineFastState.compose env3595 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26424) := by decide +kernel

theorem selectedBound3595 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,26424,25798,1465,262144,1024,26424,1093,18109,492,18195,8329,444,263084,16385,16892,19509,16620,17680,256,17428,1212,512]

theorem envBound3596 : H12AffineFastState.Bounded env3596 := by
  intro p hp
  have h : env3596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3595_3596 : H12AffineEnvironment.transform 14 26424 env3595 = env3596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26424 env3595 == env3596) = true)

def env3597 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,1093,8192,16384,26424,25662,1345,262144,1024,26424,1093,17989,276,18195,8305,324,262996,16385,16644,19509,16404,17680,256,17428,1092,512]

theorem envBound3597 : H12AffineFastState.Bounded env3597 := by
  intro p hp
  have h : env3597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3596_3597 : H12AffineEnvironment.transform 6 120 env3596 = env3597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env3596 == env3597) = true)

theorem identity3597 : scanCanonicalize (H12AffineFastState.compose env3597 (packedSelected [0,27] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3597 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env3598 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,1093,8192,16384,26173,25662,1092,262144,1024,26173,1093,17989,17,17942,8305,65,262737,16385,16385,19509,16404,17429,5,17428,1092,512]

theorem envBound3598 : H12AffineFastState.Bounded env3598 := by
  intro p hp
  have h : env3598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3597_3598 : H12AffineEnvironment.transform 7 5 env3597 = env3598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3597 == env3598) = true)

theorem identity3598 : scanCanonicalize (H12AffineFastState.compose env3598 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 16411) := by decide +kernel

theorem selectedBound3598 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3599 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,1093,8192,16384,26173,25662,1092,16411,1024,26173,1093,17989,17,17942,8305,65,16970,16385,16385,19509,16404,17429,5,17428,1092,512]

theorem envBound3599 : H12AffineFastState.Bounded env3599 := by
  intro p hp
  have h : env3599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3598_3599 : H12AffineEnvironment.transform 17 16411 env3598 = env3599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16411 env3598 == env3599) = true)

theorem identity3599 : scanCanonicalize (H12AffineFastState.compose env3599 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3599 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3600 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,8192,16384,26173,25662,1044,16411,1024,26173,1045,17941,17,17942,8225,17,16922,16385,16385,19509,16404,17429,5,17428,1044,512]

theorem envBound3600 : H12AffineFastState.Bounded env3600 := by
  intro p hp
  have h : env3600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3599_3600 : H12AffineEnvironment.transform 5 16 env3599 = env3600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3599 == env3600) = true)

theorem identity3600 : scanCanonicalize (H12AffineFastState.compose env3600 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 11805) := by decide +kernel

theorem selectedBound3600 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env3601 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,8192,11805,2080,2595,1044,11782,1024,2080,1045,10248,17,10251,8225,17,11271,11804,11804,8744,11785,10760,5,10761,1044,512]

theorem envBound3601 : H12AffineFastState.Bounded env3601 := by
  intro p hp
  have h : env3601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3600_3601 : H12AffineEnvironment.transform 13 11805 env3600 = env3601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11805 env3600 == env3601) = true)

theorem identity3601 : scanCanonicalize (H12AffineFastState.compose env3601 (packedSelected [0,2,3,12] rootPS)) = affineNative (2^(12+1) ^^^ 1564) := by decide +kernel

theorem selectedBound3601 : packedSelected [0,2,3,12] rootPS < 2^1333 := by decide +kernel

def env3602 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,1564,2049,2080,2595,1044,2074,1024,2080,1045,3604,17,3607,1597,17,2587,2048,2048,1076,2069,3092,5,3093,1044,512]

theorem envBound3602 : H12AffineFastState.Bounded env3602 := by
  intro p hp
  have h : env3602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3601_3602 : H12AffineEnvironment.transform 12 1564 env3601 = env3602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1564 env3601 == env3602) = true)

theorem identity3602 : scanCanonicalize (H12AffineFastState.compose env3602 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound3602 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env3603 : List Nat := [2,4,8,16,32,16,40,5,512,1024,1039,1045,1564,1038,1071,1580,1044,1045,1024,1071,1045,539,17,536,1597,17,1556,1039,1039,1076,1050,27,5,26,1044,512]

theorem envBound3603 : H12AffineFastState.Bounded env3603 := by
  intro p hp
  have h : env3603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3602_3603 : H12AffineEnvironment.transform 10 1039 env3602 = env3603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env3602 == env3603) = true)

theorem identity3603 : scanCanonicalize (H12AffineFastState.compose env3603 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound3603 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env3604 : List Nat := [2,4,8,16,32,16,40,5,512,564,571,545,40,570,539,24,544,545,564,539,545,539,17,536,9,17,32,571,571,512,558,27,5,26,544,512]

theorem envBound3604 : H12AffineFastState.Bounded env3604 := by
  intro p hp
  have h : env3604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3603_3604 : H12AffineEnvironment.transform 9 564 env3603 = env3604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env3603 == env3604) = true)

theorem identity3604 : scanCanonicalize (H12AffineFastState.compose env3604 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3604 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3605 : List Nat := [2,4,8,16,32,16,40,5,0,52,59,33,40,58,27,24,32,33,52,27,33,27,17,24,9,17,32,59,59,0,46,27,5,26,32,0]

theorem envBound3605 : H12AffineFastState.Bounded env3605 := by
  intro p hp
  have h : env3605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3604_3605 : H12AffineEnvironment.transform 8 0 env3604 = env3605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3604 == env3605) = true)

theorem identity3605 : scanCanonicalize (H12AffineFastState.compose env3605 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3605 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3606 : List Nat := [2,4,8,16,26,16,18,5,0,14,1,27,18,0,27,24,26,27,14,27,27,27,17,24,9,17,26,1,1,0,20,27,5,26,26,0]

theorem envBound3606 : H12AffineFastState.Bounded env3606 := by
  intro p hp
  have h : env3606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3605_3606 : H12AffineEnvironment.transform 4 26 env3605 = env3606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3605 == env3606) = true)

theorem identity3606 : scanCanonicalize (H12AffineFastState.compose env3606 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3606 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3607 : List Nat := [2,4,8,11,1,11,9,5,0,14,1,0,9,0,0,3,1,0,14,0,0,0,10,3,9,10,1,1,1,0,15,0,5,1,1,0]

theorem envBound3607 : H12AffineFastState.Bounded env3607 := by
  intro p hp
  have h : env3607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3606_3607 : H12AffineEnvironment.transform 3 11 env3606 = env3607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3606 == env3607) = true)

def env3608 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,1093,8192,16384,26424,25663,1344,262144,1024,26424,1093,17988,277,18195,8304,325,262997,16385,16645,19509,16405,17680,256,17428,1093,512]

theorem envBound3608 : H12AffineFastState.Bounded env3608 := by
  intro p hp
  have h : env3608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3596_3608 : H12AffineEnvironment.transform 6 121 env3596 = env3608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env3596 == env3608) = true)

def env3609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,46529,493,41003,8329,445,323793,16385,16892,22640,74794,17680,256,20561,90235,513]

theorem envBound3609 : H12AffineFastState.Bounded env3609 := by
  intro p hp
  have h : env3609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3592_3609 : H12AffineEnvironment.transform 21 46529 env3592 = env3609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46529 env3592 == env3609) = true)

theorem identity3609 : scanCanonicalize (H12AffineFastState.compose env3609 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3609 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3610 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,46481,445,41003,8329,445,323713,16385,16812,22560,74794,17680,256,20481,90155,513]

theorem envBound3610 : H12AffineFastState.Bounded env3610 := by
  intro p hp
  have h : env3610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3609_3610 : H12AffineEnvironment.transform 5 16 env3609 = env3610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3609 == env3610) = true)

theorem identity3610 : scanCanonicalize (H12AffineFastState.compose env3610 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3610 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3611 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,65536,4264,262144,1024,32768,4096,46229,185,41003,8329,185,323713,16385,16552,22560,74794,17428,4,20481,90155,513]

theorem envBound3611 : H12AffineFastState.Bounded env3611 := by
  intro p hp
  have h : env3611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3610_3611 : H12AffineEnvironment.transform 7 4 env3610 = env3611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3610 == env3611) = true)

theorem identity3611 : scanCanonicalize (H12AffineFastState.compose env3611 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound3611 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env3612 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,25663,4264,262144,1024,32768,4096,46229,185,41003,8329,185,323713,16385,16552,22560,16405,17428,4,20481,1044,513]

theorem envBound3612 : H12AffineFastState.Bounded env3612 := by
  intro p hp
  have h : env3612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3611_3612 : H12AffineEnvironment.transform 15 25663 env3611 = env3612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env3611 == env3612) = true)

theorem identity3612 : scanCanonicalize (H12AffineFastState.compose env3612 (packedSelected [1,2,5,10,11,13,23] rootPS)) = affineNative (2^(17+1) ^^^ 43136) := by decide +kernel

theorem selectedBound3612 : packedSelected [1,2,5,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env3613 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,25663,4264,43136,1024,32768,4096,46229,185,41003,8329,185,22529,16385,16552,22560,16405,17428,4,20481,1044,513]

theorem envBound3613 : H12AffineFastState.Bounded env3613 := by
  intro p hp
  have h : env3613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3612_3613 : H12AffineEnvironment.transform 17 43136 env3612 = env3613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43136 env3612 == env3613) = true)

theorem identity3613 : scanCanonicalize (H12AffineFastState.compose env3613 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound3613 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env3614 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1213,8192,16384,32768,25663,1045,43136,1024,32768,1213,41000,185,41003,8329,185,19644,16385,16552,19613,16405,17428,4,17596,1044,513]

theorem envBound3614 : H12AffineFastState.Bounded env3614 := by
  intro p hp
  have h : env3614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3613_3614 : H12AffineEnvironment.transform 11 1213 env3613 = env3614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env3613 == env3614) = true)

theorem identity3614 : scanCanonicalize (H12AffineFastState.compose env3614 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 2179) := by decide +kernel

theorem selectedBound3614 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env3615 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1213,8192,2179,32768,11452,1045,43136,1024,32768,1213,41000,185,41003,8329,185,1087,2178,2091,1054,2198,3223,4,3135,1044,513]

theorem envBound3615 : H12AffineFastState.Bounded env3615 := by
  intro p hp
  have h : env3615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3614_3615 : H12AffineEnvironment.transform 13 2179 env3614 = env3615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2179 env3614 == env3615) = true)

theorem identity3615 : scanCanonicalize (H12AffineFastState.compose env3615 (packedSelected [3,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 2568) := by decide +kernel

theorem selectedBound3615 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env3616 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1213,2568,2179,32768,1716,1045,33416,1024,32768,1213,35360,185,35363,2689,185,1087,2178,2091,1054,2198,3223,4,3135,1044,513]

theorem envBound3616 : H12AffineFastState.Bounded env3616 := by
  intro p hp
  have h : env3616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3615_3616 : H12AffineEnvironment.transform 12 2568 env3615 = env3616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2568 env3615 == env3616) = true)

theorem identity3616 : scanCanonicalize (H12AffineFastState.compose env3616 (packedSelected [1,3,6,13] rootPS)) = affineNative (2^(14+1) ^^^ 2728) := by decide +kernel

theorem selectedBound3616 : packedSelected [1,3,6,13] rootPS < 2^1333 := by decide +kernel

def env3617 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1213,2568,2179,2728,1716,1045,2080,1024,2728,1213,136,185,139,2689,185,1087,2178,2091,1054,2198,3223,4,3135,1044,513]

theorem envBound3617 : H12AffineFastState.Bounded env3617 := by
  intro p hp
  have h : env3617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3616_3617 : H12AffineEnvironment.transform 14 2728 env3616 = env3617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2728 env3616 == env3617) = true)

theorem identity3617 : scanCanonicalize (H12AffineFastState.compose env3617 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1599) := by decide +kernel

theorem selectedBound3617 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env3618 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1599,1213,1079,1724,1175,1716,1045,1567,1024,1175,1213,136,185,139,1214,185,1087,1725,1556,1054,1705,680,4,512,1044,513]

theorem envBound3618 : H12AffineFastState.Bounded env3618 := by
  intro p hp
  have h : env3618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3617_3618 : H12AffineEnvironment.transform 10 1599 env3617 = env3618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1599 env3617 == env3618) = true)

theorem identity3618 : scanCanonicalize (H12AffineFastState.compose env3618 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound3618 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env3619 : List Nat := [2,4,8,16,32,16,128,4,136,1024,1207,1213,1079,1076,1175,1084,1045,1175,1024,1175,1213,136,185,139,1214,185,1087,1077,1180,1054,1057,32,4,136,1044,137]

theorem envBound3619 : H12AffineFastState.Bounded env3619 := by
  intro p hp
  have h : env3619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3618_3619 : H12AffineEnvironment.transform 8 136 env3618 = env3619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env3618 == env3619) = true)

theorem identity3619 : scanCanonicalize (H12AffineFastState.compose env3619 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3619 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3620 : List Nat := [2,4,8,16,32,16,40,4,32,1024,1055,1045,1079,1076,1087,1084,1045,1087,1024,1087,1045,32,17,35,1046,17,1087,1077,1076,1054,1057,32,4,32,1044,33]

theorem envBound3620 : H12AffineFastState.Bounded env3620 := by
  intro p hp
  have h : env3620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3619_3620 : H12AffineEnvironment.transform 6 40 env3619 = env3620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3619 == env3620) = true)

theorem identity3620 : scanCanonicalize (H12AffineFastState.compose env3620 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3621 : List Nat := [2,4,8,16,32,16,40,4,32,15,16,26,56,59,48,51,26,48,15,48,26,32,17,35,25,17,48,58,59,17,46,32,4,32,27,33]

theorem envBound3621 : H12AffineFastState.Bounded env3621 := by
  intro p hp
  have h : env3621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3620_3621 : H12AffineEnvironment.transform 9 15 env3620 = env3621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3620 == env3621) = true)

theorem identity3621 : scanCanonicalize (H12AffineFastState.compose env3621 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound3621 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3622 : List Nat := [2,4,8,16,5,16,13,4,5,15,16,26,29,30,21,22,26,21,15,21,26,5,17,6,25,17,21,31,30,17,11,5,4,5,27,4]

theorem envBound3622 : H12AffineFastState.Bounded env3622 := by
  intro p hp
  have h : env3622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3621_3622 : H12AffineEnvironment.transform 4 5 env3621 = env3622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env3621 == env3622) = true)

theorem identity3622 : scanCanonicalize (H12AffineFastState.compose env3622 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3622 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3623 : List Nat := [2,4,8,11,5,11,13,4,5,15,11,1,6,5,14,13,1,14,15,14,1,5,10,6,2,10,14,4,5,10,11,5,4,5,0,4]

theorem envBound3623 : H12AffineFastState.Bounded env3623 := by
  intro p hp
  have h : env3623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3622_3623 : H12AffineEnvironment.transform 3 11 env3622 = env3623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3622 == env3623) = true)

theorem identity3623 : scanCanonicalize (H12AffineFastState.compose env3623 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3623 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3624 : List Nat := [2,4,3,0,5,0,6,4,5,4,0,1,6,5,5,6,1,5,4,5,1,5,1,6,2,1,5,4,5,1,0,5,4,5,0,4]

theorem envBound3624 : H12AffineFastState.Bounded env3624 := by
  intro p hp
  have h : env3624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3623_3624 : H12AffineEnvironment.transform 2 3 env3623 = env3624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3623 == env3624) = true)

def leafEnv3624 : List Nat := [2,4,3,0,5,0,6,4,5,4,0,1,6,5,5,6,1,5,4,5,1,5,1,6,1,2,1,1,5,4,5,1,0,5,4,5,5,3,0,4,1,5,0]

def active3624 : List Nat := [0,1]

def tree3624 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3624 : H12WitnessSearch.Good tree3624 := H12GlobalWitnessIndex.good

theorem leafIdentity3624 : H12AffineFastState.composeSystem env3624 rootObs = leafEnv3624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3624 rootObs == leafEnv3624) = true)

theorem terminalChecked3624 : H12PackedTerminal.terminalCheckFast leafEnv3624 active3624 tree3624 = true := by decide +kernel

def env3625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323792,16385,16892,22641,74795,12644668,257,20560,8479126,8389613]

theorem envBound3625 : H12AffineFastState.Bounded env3625 := by
  intro p hp
  have h : env3625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3590_3625 : H12AffineEnvironment.transform 18 1025 env3590 = env3625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3590 == env3625) = true)

theorem identity3625 : scanCanonicalize (H12AffineFastState.compose env3625 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 61740) := by decide +kernel

theorem selectedBound3625 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,61740,8388608,41003,8329,8388689,323792,16385,16892,22641,74795,8388624,257,20560,8479126,8389613]

theorem envBound3626 : H12AffineFastState.Bounded env3626 := by
  intro p hp
  have h : env3626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3625_3626 : H12AffineEnvironment.transform 21 61740 env3625 = env3626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61740 env3625 == env3626) = true)

def env3627 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,61740,8388608,41003,8329,8388609,323712,16385,16812,22561,74795,8388624,257,20480,8479126,8389565]

theorem envBound3627 : H12AffineFastState.Bounded env3627 := by
  intro p hp
  have h : env3627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3626_3627 : H12AffineEnvironment.transform 5 16 env3626 = env3627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3626 == env3627) = true)

theorem identity3627 : scanCanonicalize (H12AffineFastState.compose env3627 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3627 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3628 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,61740,445,41003,8329,444,323712,16385,16812,22561,74795,429,257,20480,90155,512]

theorem envBound3628 : H12AffineFastState.Bounded env3628 := by
  intro p hp
  have h : env3628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3627_3628 : H12AffineEnvironment.transform 22 445 env3627 = env3628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3627 == env3628) = true)

theorem identity3628 : scanCanonicalize (H12AffineFastState.compose env3628 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound3628 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3629 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1025,32768,4096,41348,445,41003,8329,444,303144,4265,4356,2185,74795,429,257,168,77955,512]

theorem envBound3629 : H12AffineFastState.Bounded env3629 := by
  intro p hp
  have h : env3629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3628_3629 : H12AffineEnvironment.transform 13 4264 env3628 = env3629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env3628 == env3629) = true)

theorem identity3629 : scanCanonicalize (H12AffineFastState.compose env3629 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38843) := by decide +kernel

theorem selectedBound3629 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3630 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,38843,4524,262144,1025,32768,4096,41348,445,41003,8329,444,303144,4265,4356,2185,45968,429,257,168,42808,512]

theorem envBound3630 : H12AffineFastState.Bounded env3630 := by
  intro p hp
  have h : env3630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3629_3630 : H12AffineEnvironment.transform 15 38843 env3629 = env3630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38843 env3629 == env3630) = true)

theorem identity3630 : scanCanonicalize (H12AffineFastState.compose env3630 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14224) := by decide +kernel

theorem selectedBound3630 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3631 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,14224,8235,4524,262144,1025,14224,4096,5652,445,6075,8329,444,268216,4265,4356,2185,1024,429,257,168,4264,512]

theorem envBound3631 : H12AffineFastState.Bounded env3631 := by
  intro p hp
  have h : env3631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3630_3631 : H12AffineEnvironment.transform 14 14224 env3630 = env3631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14224 env3630 == env3631) = true)

theorem identity3631 : scanCanonicalize (H12AffineFastState.compose env3631 (packedSelected [0,1,5,8,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2444) := by decide +kernel

theorem selectedBound3631 : packedSelected [0,1,5,8,24,27] rootPS < 2^1333 := by decide +kernel

def env3632 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,14224,8235,4524,2444,1025,14224,4096,5652,445,6075,8329,444,7732,4265,4356,2185,1024,429,257,168,4264,512]

theorem envBound3632 : H12AffineFastState.Bounded env3632 := by
  intro p hp
  have h : env3632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3631_3632 : H12AffineEnvironment.transform 17 2444 env3631 = env3632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2444 env3631 == env3632) = true)

theorem identity3632 : scanCanonicalize (H12AffineFastState.compose env3632 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound3632 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env3633 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4264,13884,8235,4096,2080,1025,13884,4096,5652,17,5655,8329,16,7732,4265,4264,2185,1024,1,173,168,4264,512]

theorem envBound3633 : H12AffineFastState.Bounded env3633 := by
  intro p hp
  have h : env3633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3632_3633 : H12AffineEnvironment.transform 7 172 env3632 = env3633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3632 == env3633) = true)

theorem identity3633 : scanCanonicalize (H12AffineFastState.compose env3633 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound3633 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3634 : List Nat := [2,4,8,16,32,16,128,172,512,1024,674,4096,8192,4264,13884,8235,4096,642,1025,13884,4096,5652,17,5655,8329,16,5270,4265,4264,555,1024,1,173,168,4264,512]

theorem envBound3634 : H12AffineFastState.Bounded env3634 := by
  intro p hp
  have h : env3634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3633_3634 : H12AffineEnvironment.transform 10 674 env3633 = env3634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env3633 == env3634) = true)

theorem identity3634 : scanCanonicalize (H12AffineFastState.compose env3634 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound3634 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3635 : List Nat := [2,4,8,16,32,16,128,172,512,1024,674,1692,8192,1588,8352,8235,1692,642,1025,8352,1692,136,17,139,8329,16,522,1589,1588,555,1024,1,173,168,1588,512]

theorem envBound3635 : H12AffineFastState.Bounded env3635 := by
  intro p hp
  have h : env3635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3634_3635 : H12AffineEnvironment.transform 11 1692 env3634 = env3635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env3634 == env3635) = true)

theorem identity3635 : scanCanonicalize (H12AffineFastState.compose env3635 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 18) := by decide +kernel

theorem selectedBound3635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3636 : List Nat := [2,4,8,16,32,16,128,172,512,1024,674,1692,18,1588,178,57,1692,642,1025,178,1692,136,17,139,155,16,522,1589,1588,555,1024,1,173,168,1588,512]

theorem envBound3636 : H12AffineFastState.Bounded env3636 := by
  intro p hp
  have h : env3636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3635_3636 : H12AffineEnvironment.transform 12 18 env3635 = env3636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 18 env3635 == env3636) = true)

theorem identity3636 : scanCanonicalize (H12AffineFastState.compose env3636 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3636 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3637 : List Nat := [2,4,8,16,32,16,40,4,512,1024,522,1588,18,1588,26,57,1588,554,1025,26,1588,32,17,35,51,16,522,1589,1588,555,1024,1,5,0,1588,512]

theorem envBound3637 : H12AffineFastState.Bounded env3637 := by
  intro p hp
  have h : env3637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3636_3637 : H12AffineEnvironment.transform 6 40 env3636 = env3637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3636 == env3637) = true)

theorem identity3637 : scanCanonicalize (H12AffineFastState.compose env3637 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound3637 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3638 : List Nat := [2,4,8,16,16,16,24,4,512,1024,522,1540,18,1540,26,9,1540,538,1025,26,1540,16,17,19,3,16,522,1541,1540,539,1024,1,5,0,1540,512]

theorem envBound3638 : H12AffineFastState.Bounded env3638 := by
  intro p hp
  have h : env3638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3637_3638 : H12AffineEnvironment.transform 4 16 env3637 = env3638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env3637 == env3638) = true)

theorem identity3638 : scanCanonicalize (H12AffineFastState.compose env3638 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3638 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env3639 : List Nat := [2,4,2,16,16,16,18,4,512,1024,512,1540,18,1540,16,3,1540,528,1025,16,1540,16,17,19,3,16,512,1541,1540,529,1024,1,5,0,1540,512]

theorem envBound3639 : H12AffineFastState.Bounded env3639 := by
  intro p hp
  have h : env3639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3638_3639 : H12AffineEnvironment.transform 2 2 env3638 = env3639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3638 == env3639) = true)

theorem identity3639 : scanCanonicalize (H12AffineFastState.compose env3639 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3639 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3640 : List Nat := [2,4,2,0,0,0,2,4,512,1024,512,1540,2,1540,0,3,1540,512,1025,0,1540,0,1,3,3,0,512,1541,1540,513,1024,1,5,0,1540,512]

theorem envBound3640 : H12AffineFastState.Bounded env3640 := by
  intro p hp
  have h : env3640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3639_3640 : H12AffineEnvironment.transform 3 0 env3639 = env3640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3639 == env3640) = true)

theorem identity3640 : scanCanonicalize (H12AffineFastState.compose env3640 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3641 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1028,2,1028,0,3,1028,0,1025,0,1028,0,1,3,3,0,0,1029,1028,1,1024,1,5,0,1028,0]

theorem envBound3641 : H12AffineFastState.Bounded env3641 := by
  intro p hp
  have h : env3641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3640_3641 : H12AffineEnvironment.transform 8 0 env3640 = env3641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3640 == env3641) = true)

def leafEnv3641 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1028,2,1028,0,3,1028,0,1025,0,1028,0,1,3,1025,3,1,0,0,1029,1028,1,1024,1,5,0,5,3,1028,0,1,1029,0]

def active3641 : List Nat := [0,1,9]

def tree3641 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3641 : H12WitnessSearch.Good tree3641 := H12GlobalWitnessIndex.good

theorem leafIdentity3641 : H12AffineFastState.composeSystem env3641 rootObs = leafEnv3641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3641 rootObs == leafEnv3641) = true)

theorem terminalChecked3641 : H12PackedTerminal.terminalCheckFast leafEnv3641 active3641 tree3641 = true := by decide +kernel

def env3642 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,61740,8388608,41003,8329,8388608,323713,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3642 : H12AffineFastState.Bounded env3642 := by
  intro p hp
  have h : env3642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3626_3642 : H12AffineEnvironment.transform 5 17 env3626 = env3642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3626 == env3642) = true)

def env3643 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,262144,1025,8352,4096,20876,8388608,139,8329,8388608,282657,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3643 : H12AffineFastState.Bounded env3643 := by
  intro p hp
  have h : env3643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3642_3643 : H12AffineEnvironment.transform 14 8352 env3642 = env3643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3642 == env3643) = true)

theorem identity3643 : scanCanonicalize (H12AffineFastState.compose env3643 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 96527) := by decide +kernel

theorem selectedBound3643 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3644 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,96527,1025,8352,4096,20876,8388608,139,8329,8388608,76078,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3644 : H12AffineFastState.Bounded env3644 := by
  intro p hp
  have h : env3644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3643_3644 : H12AffineEnvironment.transform 17 96527 env3643 = env3644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96527 env3643 == env3644) = true)

theorem identity3644 : scanCanonicalize (H12AffineFastState.compose env3644 (packedSelected [1,3,7,13,20,21,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 20925) := by decide +kernel

theorem selectedBound3644 : packedSelected [1,3,7,13,20,21,24,27,28] rootPS < 2^1333 := by decide +kernel

def env3645 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,96527,1025,8352,4096,20876,20925,139,8329,20925,76078,16385,16813,22560,74795,20909,257,20481,77867,20993]

theorem envBound3645 : H12AffineFastState.Bounded env3645 := by
  intro p hp
  have h : env3645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3644_3645 : H12AffineEnvironment.transform 22 20925 env3644 = env3645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20925 env3644 == env3645) = true)

theorem identity3645 : scanCanonicalize (H12AffineFastState.compose env3645 (packedSelected [4,9,11,13,18,20,21,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 29063) := by decide +kernel

theorem selectedBound3645 : packedSelected [4,9,11,13,18,20,21,23,32] rootPS < 2^1333 := by decide +kernel

def env3646 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,29063,4525,2184,1025,8352,4096,20876,20925,139,8329,20925,22697,16385,16813,22560,21932,20909,257,20481,16812,20993]

theorem envBound3646 : H12AffineFastState.Bounded env3646 := by
  intro p hp
  have h : env3646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3645_3646 : H12AffineEnvironment.transform 15 29063 env3645 = env3646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29063 env3645 == env3646) = true)

theorem identity3646 : scanCanonicalize (H12AffineFastState.compose env3646 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 10154) := by decide +kernel

theorem selectedBound3646 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env3647 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,10154,8352,5677,4525,2184,1025,8352,4096,13862,13847,139,8329,13847,16131,10155,9735,16266,12806,13831,257,14251,9734,13739]

theorem envBound3647 : H12AffineFastState.Bounded env3647 := by
  intro p hp
  have h : env3647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3646_3647 : H12AffineEnvironment.transform 13 10154 env3646 = env3647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10154 env3646 == env3647) = true)

theorem identity3647 : scanCanonicalize (H12AffineFastState.compose env3647 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound3647 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env3648 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,9750,8352,5677,4113,2184,1025,8352,4096,13862,13847,139,8329,13847,16063,9751,9735,15926,12806,13831,189,13847,9734,13335]

theorem envBound3648 : H12AffineFastState.Bounded env3648 := by
  intro p hp
  have h : env3648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3647_3648 : H12AffineEnvironment.transform 7 188 env3647 = env3648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3647 == env3648) = true)

theorem identity3648 : scanCanonicalize (H12AffineFastState.compose env3648 (packedSelected [0,1,2,5,6,7,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound3648 : packedSelected [0,1,2,5,6,7,10,13] rootPS < 2^1333 := by decide +kernel

def env3649 : List Nat := [2,4,8,16,32,17,128,188,512,1024,560,4096,8192,9750,8352,5677,4113,696,1025,8352,4096,13862,13847,139,8329,13847,13455,9751,9735,13318,12806,13831,189,13847,9734,13335]

theorem envBound3649 : H12AffineFastState.Bounded env3649 := by
  intro p hp
  have h : env3649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3648_3649 : H12AffineEnvironment.transform 10 560 env3648 = env3649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env3648 == env3649) = true)

theorem identity3649 : scanCanonicalize (H12AffineFastState.compose env3649 (packedSelected [0,1,2,3,6,7,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 177) := by decide +kernel

theorem selectedBound3649 : packedSelected [0,1,2,3,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env3650 : List Nat := [2,4,8,16,32,17,128,188,512,1024,560,4096,177,1703,17,5677,4113,696,1025,17,4096,5783,5798,139,56,5798,5182,1702,1718,5303,4791,5814,189,5798,1719,5286]

theorem envBound3650 : H12AffineFastState.Bounded env3650 := by
  intro p hp
  have h : env3650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3649_3650 : H12AffineEnvironment.transform 12 177 env3649 = env3650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 177 env3649 == env3650) = true)

theorem identity3650 : scanCanonicalize (H12AffineFastState.compose env3650 (packedSelected [0,1,2,5,6,7,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound3650 : packedSelected [0,1,2,5,6,7,10,17] rootPS < 2^1333 := by decide +kernel

def env3651 : List Nat := [2,4,8,16,32,17,128,188,512,1024,560,1551,177,1703,17,34,1566,696,1025,17,1551,152,169,139,56,169,561,1702,1718,696,1208,185,189,169,1719,681]

theorem envBound3651 : H12AffineFastState.Bounded env3651 := by
  intro p hp
  have h : env3651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3650_3651 : H12AffineEnvironment.transform 11 1551 env3650 = env3651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env3650 == env3651) = true)

theorem identity3651 : scanCanonicalize (H12AffineFastState.compose env3651 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3651 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env3652 : List Nat := [2,4,8,16,27,17,128,135,512,1024,523,1551,138,1692,17,25,1566,643,1025,17,1551,152,146,139,3,146,522,1693,1677,643,1155,130,134,146,1676,658]

theorem envBound3652 : H12AffineFastState.Bounded env3652 := by
  intro p hp
  have h : env3652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3651_3652 : H12AffineEnvironment.transform 4 27 env3651 = env3652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3651 == env3652) = true)

theorem identity3652 : scanCanonicalize (H12AffineFastState.compose env3652 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3652 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3653 : List Nat := [2,4,8,1,10,0,128,135,512,1024,523,1551,138,1677,0,8,1551,643,1025,0,1551,137,131,139,3,131,522,1676,1677,643,1155,130,134,131,1676,643]

theorem envBound3653 : H12AffineFastState.Bounded env3653 := by
  intro p hp
  have h : env3653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3652_3653 : H12AffineEnvironment.transform 3 1 env3652 = env3653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3652 == env3653) = true)

theorem identity3653 : scanCanonicalize (H12AffineFastState.compose env3653 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound3653 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3654 : List Nat := [2,4,8,1,10,0,9,14,512,1024,523,1551,3,1540,0,8,1551,522,1025,0,1551,0,10,2,3,10,522,1541,1540,522,1034,11,15,10,1541,522]

theorem envBound3654 : H12AffineFastState.Bounded env3654 := by
  intro p hp
  have h : env3654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3653_3654 : H12AffineEnvironment.transform 6 9 env3653 = env3654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env3653 == env3654) = true)

theorem identity3654 : scanCanonicalize (H12AffineFastState.compose env3654 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3654 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3655 : List Nat := [2,4,2,1,0,0,3,4,512,1024,513,1541,3,1540,0,2,1541,512,1025,0,1541,0,0,2,3,0,512,1541,1540,512,1024,1,5,0,1541,512]

theorem envBound3655 : H12AffineFastState.Bounded env3655 := by
  intro p hp
  have h : env3655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3654_3655 : H12AffineEnvironment.transform 2 2 env3654 = env3655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3654 == env3655) = true)

theorem identity3655 : scanCanonicalize (H12AffineFastState.compose env3655 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3655 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3656 : List Nat := [2,4,2,1,0,0,3,4,0,1024,1,1029,3,1028,0,2,1029,0,1025,0,1029,0,0,2,3,0,0,1029,1028,0,1024,1,5,0,1029,0]

theorem envBound3656 : H12AffineFastState.Bounded env3656 := by
  intro p hp
  have h : env3656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3655_3656 : H12AffineEnvironment.transform 8 0 env3655 = env3656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3655 == env3656) = true)

def leafEnv3656 : List Nat := [2,4,2,1,0,0,3,4,0,1024,1,1029,3,1028,0,2,1029,0,1025,0,1029,0,0,2,1025,3,1,0,0,1029,1028,0,1024,1,5,0,5,3,1029,0,1,1029,0]

def active3656 : List Nat := [0,1,9]

def tree3656 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3656 : H12WitnessSearch.Good tree3656 := H12GlobalWitnessIndex.good

theorem leafIdentity3656 : H12AffineFastState.composeSystem env3656 rootObs = leafEnv3656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3656 rootObs == leafEnv3656) = true)

theorem terminalChecked3656 : H12PackedTerminal.terminalCheckFast leafEnv3656 active3656 tree3656 = true := by decide +kernel

def env3657 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,262144,1025,8353,4096,20877,8388608,138,8329,8388608,282656,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3657 : H12AffineFastState.Bounded env3657 := by
  intro p hp
  have h : env3657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3642_3657 : H12AffineEnvironment.transform 14 8353 env3642 = env3657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3642 == env3657) = true)

theorem identity3657 : scanCanonicalize (H12AffineFastState.compose env3657 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 96267) := by decide +kernel

theorem selectedBound3657 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3658 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,96267,1025,8353,4096,20877,8388608,138,8329,8388608,75819,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3658 : H12AffineFastState.Bounded env3658 := by
  intro p hp
  have h : env3658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3657_3658 : H12AffineEnvironment.transform 17 96267 env3657 = env3658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96267 env3657 == env3658) = true)

theorem identity3658 : scanCanonicalize (H12AffineFastState.compose env3658 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 28714) := by decide +kernel

theorem selectedBound3658 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env3659 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,28714,4525,2081,1025,8353,4096,20877,8388608,138,8329,8388608,22529,16385,16813,22560,21505,8388624,257,20481,8393148,8389564]

theorem envBound3659 : H12AffineFastState.Bounded env3659 := by
  intro p hp
  have h : env3659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3658_3659 : H12AffineEnvironment.transform 15 28714 env3658 = env3659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28714 env3658 == env3659) = true)

theorem identity3659 : scanCanonicalize (H12AffineFastState.compose env3659 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 7946) := by decide +kernel

theorem selectedBound3659 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env3660 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,7946,8353,12064,4525,2081,1025,8353,4096,3719,8388608,138,8329,8388608,1803,7947,7847,1834,2827,8388624,257,3851,8393148,8389564]

theorem envBound3660 : H12AffineFastState.Bounded env3660 := by
  intro p hp
  have h : env3660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3659_3660 : H12AffineEnvironment.transform 13 7946 env3659 = env3660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7946 env3659 == env3660) = true)

theorem identity3660 : scanCanonicalize (H12AffineFastState.compose env3660 (packedSelected [4,9,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3660 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env3661 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,7695,8353,11813,4264,2081,1025,8353,4096,3719,8388608,138,8329,8388608,1550,7694,7847,1583,2574,8388624,4,3598,8392889,8389305]

theorem envBound3661 : H12AffineFastState.Bounded env3661 := by
  intro p hp
  have h : env3661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3660_3661 : H12AffineEnvironment.transform 7 5 env3660 = env3661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3660 == env3661) = true)

theorem identity3661 : scanCanonicalize (H12AffineFastState.compose env3661 (packedSelected [0,1,7,8,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3661 : packedSelected [0,1,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env3662 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,7695,8201,11813,4096,2081,1025,8201,4096,3631,8388608,34,8225,8388608,1550,7694,7695,1583,2574,8388624,4,3598,8392721,8389137]

theorem envBound3662 : H12AffineFastState.Bounded env3662 := by
  intro p hp
  have h : env3662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3661_3662 : H12AffineEnvironment.transform 6 40 env3661 = env3662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3661 == env3662) = true)

theorem identity3662 : scanCanonicalize (H12AffineFastState.compose env3662 (packedSelected [2,6] rootPS)) = affineNative (2^(22+1) ^^^ 3620) := by decide +kernel

theorem selectedBound3662 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3663 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,7695,8201,11813,4096,2081,1025,8201,4096,3631,3620,34,8225,3620,1550,7694,7695,1583,2574,3636,4,3598,7733,3125]

theorem envBound3663 : H12AffineFastState.Bounded env3663 := by
  intro p hp
  have h : env3663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3662_3663 : H12AffineEnvironment.transform 22 3620 env3662 = env3663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 3620 env3662 == env3663) = true)

theorem identity3663 : scanCanonicalize (H12AffineFastState.compose env3663 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound3663 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3664 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1589,8192,2106,8201,11813,1589,2081,1025,8201,1589,3631,3620,34,8225,3620,1550,2107,2106,1583,2574,3636,4,3598,2048,3125]

theorem envBound3664 : H12AffineFastState.Bounded env3664 := by
  intro p hp
  have h : env3664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3663_3664 : H12AffineEnvironment.transform 11 1589 env3663 = env3664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env3663 == env3664) = true)

theorem identity3664 : scanCanonicalize (H12AffineFastState.compose env3664 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound3664 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env3665 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1076,1589,8192,1038,8201,8721,1589,1045,1025,8201,1589,539,528,34,8225,528,1550,1039,1038,1583,1594,512,4,570,1076,1]

theorem envBound3665 : H12AffineFastState.Bounded env3665 := by
  intro p hp
  have h : env3665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3664_3665 : H12AffineEnvironment.transform 10 1076 env3664 = env3665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env3664 == env3665) = true)

theorem identity3665 : scanCanonicalize (H12AffineFastState.compose env3665 (packedSelected [4,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound3665 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env3666 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1076,1589,1053,1038,1044,1548,1589,1045,1025,1044,1589,539,528,34,1084,528,1550,1039,1038,1583,1594,512,4,570,1076,1]

theorem envBound3666 : H12AffineFastState.Bounded env3666 := by
  intro p hp
  have h : env3666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3665_3666 : H12AffineEnvironment.transform 12 1053 env3665 = env3666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env3665 == env3666) = true)

theorem identity3666 : scanCanonicalize (H12AffineFastState.compose env3666 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3666 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env3667 : List Nat := [2,4,8,16,26,17,18,5,512,1024,1038,1551,1053,1038,1044,1548,1551,1045,1025,1044,1551,539,528,24,1030,528,1550,1039,1038,1557,1536,512,4,512,1038,1]

theorem envBound3667 : H12AffineFastState.Bounded env3667 := by
  intro p hp
  have h : env3667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3666_3667 : H12AffineEnvironment.transform 4 26 env3666 = env3667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3666 == env3667) = true)

theorem identity3667 : scanCanonicalize (H12AffineFastState.compose env3667 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3668 : List Nat := [2,4,8,16,26,17,18,5,512,14,0,513,19,0,26,514,513,27,15,26,513,539,528,24,8,528,512,1,0,539,526,512,4,512,0,1]

theorem envBound3668 : H12AffineFastState.Bounded env3668 := by
  intro p hp
  have h : env3668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3667_3668 : H12AffineEnvironment.transform 9 14 env3667 = env3668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3667 == env3668) = true)

def env3669 : List Nat := [2,4,8,16,26,17,18,5,0,14,0,1,19,0,26,2,1,27,15,26,1,27,16,24,8,16,0,1,0,27,14,0,4,0,0,1]

theorem envBound3669 : H12AffineFastState.Bounded env3669 := by
  intro p hp
  have h : env3669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3668_3669 : H12AffineEnvironment.transform 8 0 env3668 = env3669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3668 == env3669) = true)

theorem identity3669 : scanCanonicalize (H12AffineFastState.compose env3669 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound3669 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3670 : List Nat := [2,4,8,4,14,5,6,5,0,14,0,1,7,0,14,2,1,15,15,14,1,15,4,12,8,4,0,1,0,15,14,0,4,0,0,1]

theorem envBound3670 : H12AffineFastState.Bounded env3670 := by
  intro p hp
  have h : env3670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3669_3670 : H12AffineEnvironment.transform 3 4 env3669 = env3670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env3669 == env3670) = true)

theorem identity3670 : scanCanonicalize (H12AffineFastState.compose env3670 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3670 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3671 : List Nat := [2,1,8,1,11,0,3,0,0,11,0,1,2,0,11,2,1,10,10,11,1,10,1,9,8,1,0,1,0,10,11,0,1,0,0,1]

theorem envBound3671 : H12AffineFastState.Bounded env3671 := by
  intro p hp
  have h : env3671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3670_3671 : H12AffineEnvironment.transform 1 1 env3670 = env3671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3670 == env3671) = true)

def leafEnv3671 : List Nat := [2,1,8,1,11,0,3,0,0,11,0,1,2,0,11,2,1,10,10,11,1,10,1,9,10,8,1,1,0,1,0,10,11,0,1,0,0,8,0,1,1,1,0]

def active3671 : List Nat := [0,2]

def tree3671 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3671 : H12WitnessSearch.Good tree3671 := H12GlobalWitnessIndex.good

theorem leafIdentity3671 : H12AffineFastState.composeSystem env3671 rootObs = leafEnv3671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3671 rootObs == leafEnv3671) = true)

theorem terminalChecked3671 : H12PackedTerminal.terminalCheckFast leafEnv3671 active3671 tree3671 = true := by decide +kernel

def env3672 : List Nat := [2,4,8,16,26,17,18,5,1,14,0,0,19,0,26,3,0,27,15,26,0,26,17,24,8,17,1,1,0,26,15,1,4,1,0,1]

theorem envBound3672 : H12AffineFastState.Bounded env3672 := by
  intro p hp
  have h : env3672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3668_3672 : H12AffineEnvironment.transform 8 1 env3668 = env3672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3668 == env3672) = true)

def env3673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849105,268435456,268435965,547952,598059,12644668,525568,545873,8479126,8914924]

theorem envBound3673 : H12AffineFastState.Bounded env3673 := by
  intro p hp
  have h : env3673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3457_3673 : H12AffineEnvironment.transform 20 4097 env3457 = env3673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env3457 == env3673) = true)

def env3674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849105,16384,16893,547952,598059,12644668,525568,545873,8479126,8914924]

theorem envBound3674 : H12AffineFastState.Bounded env3674 := by
  intro p hp
  have h : env3674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3673_3674 : H12AffineEnvironment.transform 27 16384 env3673 = env3674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env3673 == env3674) = true)

def env3675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,323793,16384,16893,22640,74795,12644668,256,20561,8479126,8389612]

theorem envBound3675 : H12AffineFastState.Bounded env3675 := by
  intro p hp
  have h : env3675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3674_3675 : H12AffineEnvironment.transform 18 1024 env3674 = env3675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3674 == env3675) = true)

theorem identity3675 : scanCanonicalize (H12AffineFastState.compose env3675 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 20804) := by decide +kernel

theorem selectedBound3675 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,20804,41003,8329,20757,323793,16384,16893,22640,74795,4235384,256,20561,78034,21160]

theorem envBound3676 : H12AffineFastState.Bounded env3676 := by
  intro p hp
  have h : env3676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3675_3676 : H12AffineEnvironment.transform 22 20804 env3675 = env3676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20804 env3675 == env3676) = true)

def env3677 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,20756,41003,8329,20757,323713,16384,16813,22560,74795,4235304,256,20481,77954,21160]

theorem envBound3677 : H12AffineFastState.Bounded env3677 := by
  intro p hp
  have h : env3677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3676_3677 : H12AffineEnvironment.transform 5 16 env3676 = env3677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3676 == env3677) = true)

theorem identity3677 : scanCanonicalize (H12AffineFastState.compose env3677 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound3677 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3678 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1024,32768,4097,4194304,444,41003,8329,445,303145,4264,4357,2184,74795,4235304,256,169,77954,512]

theorem envBound3678 : H12AffineFastState.Bounded env3678 := by
  intro p hp
  have h : env3678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3677_3678 : H12AffineEnvironment.transform 13 4264 env3677 = env3678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env3677 == env3678) = true)

theorem identity3678 : scanCanonicalize (H12AffineFastState.compose env3678 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3678 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3679 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1024,32768,4097,41348,444,41003,8329,445,303145,4264,4357,2184,74795,428,256,169,77954,512]

theorem envBound3679 : H12AffineFastState.Bounded env3679 := by
  intro p hp
  have h : env3679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3678_3679 : H12AffineEnvironment.transform 21 41348 env3678 = env3679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3678 == env3679) = true)

theorem identity3679 : scanCanonicalize (H12AffineFastState.compose env3679 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38842) := by decide +kernel

theorem selectedBound3679 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3680 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,38842,4524,262144,1024,32768,4097,41348,444,41003,8329,445,303145,4264,4357,2184,45969,428,256,169,42808,512]

theorem envBound3680 : H12AffineFastState.Bounded env3680 := by
  intro p hp
  have h : env3680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3679_3680 : H12AffineEnvironment.transform 15 38842 env3679 = env3680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38842 env3679 == env3680) = true)

theorem identity3680 : scanCanonicalize (H12AffineFastState.compose env3680 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14224) := by decide +kernel

theorem selectedBound3680 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3681 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,14224,8234,4524,262144,1024,14224,4097,5652,444,6075,8329,445,268217,4264,4357,2184,1025,428,256,169,4264,512]

theorem envBound3681 : H12AffineFastState.Bounded env3681 := by
  intro p hp
  have h : env3681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3680_3681 : H12AffineEnvironment.transform 14 14224 env3680 = env3681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14224 env3680 == env3681) = true)

theorem identity3681 : scanCanonicalize (H12AffineFastState.compose env3681 (packedSelected [0,1,5,8,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound3681 : packedSelected [0,1,5,8,24,27] rootPS < 2^1333 := by decide +kernel

def env3682 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,14224,8234,4524,2341,1024,14224,4097,5652,444,6075,8329,445,7836,4264,4357,2184,1025,428,256,169,4264,512]

theorem envBound3682 : H12AffineFastState.Bounded env3682 := by
  intro p hp
  have h : env3682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3681_3682 : H12AffineEnvironment.transform 17 2341 env3681 = env3682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env3681 == env3682) = true)

theorem identity3682 : scanCanonicalize (H12AffineFastState.compose env3682 (packedSelected [0,3,4,5,7,9,10,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound3682 : packedSelected [0,3,4,5,7,9,10,18,23] rootPS < 2^1333 := by decide +kernel

def env3683 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1945,8192,1841,8201,8234,1589,2341,1024,8201,1944,397,444,34,8329,445,2309,1841,1692,2184,1025,428,256,169,1841,512]

theorem envBound3683 : H12AffineFastState.Bounded env3683 := by
  intro p hp
  have h : env3683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3682_3683 : H12AffineEnvironment.transform 11 1945 env3682 = env3683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env3682 == env3683) = true)

theorem identity3683 : scanCanonicalize (H12AffineFastState.compose env3683 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3683 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3684 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1840,8192,1841,8201,8234,1589,2341,1024,8201,1841,292,277,34,8224,276,2309,1841,1589,2081,1025,261,256,0,1841,512]

theorem envBound3684 : H12AffineFastState.Bounded env3684 := by
  intro p hp
  have h : env3684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3683_3684 : H12AffineEnvironment.transform 6 41 env3683 = env3684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3683 == env3684) = true)

theorem identity3684 : scanCanonicalize (H12AffineFastState.compose env3684 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound3684 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3685 : List Nat := [2,4,8,16,32,16,41,256,512,273,2048,545,8192,544,8201,8234,804,2341,273,8201,544,292,277,34,8224,276,2309,544,804,2081,272,261,256,0,544,512]

theorem envBound3685 : H12AffineFastState.Bounded env3685 := by
  intro p hp
  have h : env3685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3684_3685 : H12AffineEnvironment.transform 9 273 env3684 = env3685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env3684 == env3685) = true)

theorem identity3685 : scanCanonicalize (H12AffineFastState.compose env3685 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3685 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3686 : List Nat := [2,4,8,16,26,16,19,256,512,273,2048,539,8192,538,8201,8208,798,2335,273,8201,538,286,277,24,8218,276,2309,538,798,2075,272,261,256,0,538,512]

theorem envBound3686 : H12AffineFastState.Bounded env3686 := by
  intro p hp
  have h : env3686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3685_3686 : H12AffineEnvironment.transform 4 26 env3685 = env3686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3685 == env3686) = true)

def env3687 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,20757,41003,8329,20757,323712,16384,16812,22561,74795,4235305,256,20480,77955,21160]

theorem envBound3687 : H12AffineFastState.Bounded env3687 := by
  intro p hp
  have h : env3687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3676_3687 : H12AffineEnvironment.transform 5 17 env3676 = env3687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3676 == env3687) = true)

def env3688 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,20741,41003,8329,20741,323712,16384,16812,22561,74795,4235305,256,20480,77955,21160]

theorem envBound3688 : H12AffineFastState.Bounded env3688 := by
  intro p hp
  have h : env3688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3687_3688 : H12AffineEnvironment.transform 3 0 env3687 = env3688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3687 == env3688) = true)

theorem identity3688 : scanCanonicalize (H12AffineFastState.compose env3688 (packedSelected [0,2,3,9,10,11,13,18,21,22,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 43308) := by decide +kernel

theorem selectedBound3688 : packedSelected [0,2,3,9,10,11,13,18,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3689 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,43308,1024,32768,4097,4194304,20741,41003,8329,20741,22956,16384,16812,22561,74795,4235305,256,20480,77955,21160]

theorem envBound3689 : H12AffineFastState.Bounded env3689 := by
  intro p hp
  have h : env3689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3688_3689 : H12AffineEnvironment.transform 17 43308 env3688 = env3689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43308 env3688 == env3689) = true)

def env3690 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,43308,1024,32768,4097,61568,20741,41003,8329,20741,22956,16384,16812,22561,74795,20649,256,20480,77955,21160]

theorem envBound3690 : H12AffineFastState.Bounded env3690 := by
  intro p hp
  have h : env3690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0