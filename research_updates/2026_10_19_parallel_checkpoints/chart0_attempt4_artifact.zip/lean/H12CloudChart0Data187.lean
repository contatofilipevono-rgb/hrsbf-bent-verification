import H12CloudChart0Data186

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity47355 : scanCanonicalize (H12AffineFastState.compose env47355 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47355 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env47356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,2097152,4194304,16,16777216,8328,64,21039476,18949585,2118976,2420,16852317,23160256,256,18965984,18949401,16777867]

theorem envBound47356 : H12AffineFastState.Bounded env47356 := by
  intro p hp
  have h : env47356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47355_47356 : H12AffineEnvironment.transform 14 8540 env47355 = env47356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47355 == env47356) = true)

def env47357 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1024,8233,2097152,4194304,16,16777216,8328,64,21039104,18949285,2118708,2048,16852009,23159988,116,18965652,18949229,16777867]

theorem envBound47357 : H12AffineFastState.Bounded env47357 := by
  intro p hp
  have h : env47357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47356_47357 : H12AffineEnvironment.transform 7 116 env47356 = env47357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47356 == env47357) = true)

theorem identity47357 : scanCanonicalize (H12AffineFastState.compose env47357 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 17597) := by decide +kernel

theorem selectedBound47357 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env47358 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1024,8233,17597,4194304,16,16777216,8328,64,21039104,16867352,4233,2048,16852009,21045257,116,16850985,16867536,16777867]

theorem envBound47358 : H12AffineFastState.Bounded env47358 := by
  intro p hp
  have h : env47358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47357_47358 : H12AffineEnvironment.transform 20 17597 env47357 = env47358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17597 env47357 == env47358) = true)

theorem identity47358 : scanCanonicalize (H12AffineFastState.compose env47358 (packedSelected [0,3,9,10,11,14,17,18,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(23+1) ^^^ 4194475) := by decide +kernel

theorem selectedBound47358 : packedSelected [0,3,9,10,11,14,17,18,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env47359 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1024,8233,17597,4194304,16,4194475,8328,64,67755,4284595,4233,2048,4269186,73890,116,4268162,4284539,4194848]

theorem envBound47359 : H12AffineFastState.Bounded env47359 := by
  intro p hp
  have h : env47359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47358_47359 : H12AffineEnvironment.transform 23 4194475 env47358 = env47359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4194475 env47358 == env47359) = true)

theorem identity47359 : scanCanonicalize (H12AffineFastState.compose env47359 (packedSelected [0,3,7,9,10,11,14,17,18,20,22,23,24,26,32] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound47359 : packedSelected [0,3,7,9,10,11,14,17,18,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env47360 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1024,8233,17597,33,16,138,8328,64,67755,90258,4233,2048,74915,73890,116,73891,90202,513]

theorem envBound47360 : H12AffineFastState.Bounded env47360 := by
  intro p hp
  have h : env47360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47359_47360 : H12AffineEnvironment.transform 21 33 env47359 = env47360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47359 == env47360) = true)

theorem identity47360 : scanCanonicalize (H12AffineFastState.compose env47360 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29863) := by decide +kernel

theorem selectedBound47360 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env47361 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,8232,29863,16400,10281,1024,8233,17597,33,16,138,8328,64,31756,5173,4233,2048,20484,21509,116,21508,5373,513]

theorem envBound47361 : H12AffineFastState.Bounded env47361 := by
  intro p hp
  have h : env47361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47360_47361 : H12AffineEnvironment.transform 15 29863 env47360 = env47361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29863 env47360 == env47361) = true)

theorem identity47361 : scanCanonicalize (H12AffineFastState.compose env47361 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound47361 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env47362 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5293,8232,8202,5309,10281,1024,8233,4112,33,16,138,8328,64,10401,5173,4233,2048,1193,168,116,169,5373,513]

theorem envBound47362 : H12AffineFastState.Bounded env47362 := by
  intro p hp
  have h : env47362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47361_47362 : H12AffineEnvironment.transform 13 5293 env47361 = env47362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env47361 == env47362) = true)

theorem identity47362 : scanCanonicalize (H12AffineFastState.compose env47362 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47362 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47363 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,8192,5293,8232,8202,5309,10281,1024,8233,4112,33,16,138,8328,17,10401,5173,4233,2048,1193,168,37,169,5292,513]

theorem envBound47363 : H12AffineFastState.Bounded env47363 := by
  intro p hp
  have h : env47363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47362_47363 : H12AffineEnvironment.transform 5 17 env47362 = env47363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47362 == env47363) = true)

theorem identity47363 : scanCanonicalize (H12AffineFastState.compose env47363 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound47363 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47364 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,1053,5293,1077,1047,5309,3124,1024,1076,4112,33,16,138,1173,17,3260,5173,4233,2048,1193,168,37,169,5292,513]

theorem envBound47364 : H12AffineFastState.Bounded env47364 := by
  intro p hp
  have h : env47364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47363_47364 : H12AffineEnvironment.transform 12 1053 env47363 = env47364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env47363 == env47364) = true)

theorem identity47364 : scanCanonicalize (H12AffineFastState.compose env47364 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2058) := by decide +kernel

theorem selectedBound47364 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env47365 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,2058,1053,3239,1077,1047,3255,3124,1024,1076,2074,33,16,138,1173,17,3260,3135,2179,2048,1193,168,37,169,3238,513]

theorem envBound47365 : H12AffineFastState.Bounded env47365 := by
  intro p hp
  have h : env47365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47364_47365 : H12AffineEnvironment.transform 11 2058 env47364 = env47365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2058 env47364 == env47365) = true)

theorem identity47365 : scanCanonicalize (H12AffineFastState.compose env47365 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound47365 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47366 : List Nat := [2,4,8,16,32,17,128,37,512,1024,152,146,1053,1087,1077,1047,1071,1196,1024,1076,130,33,16,138,1173,17,1060,1191,27,152,1193,168,37,169,1086,513]

theorem envBound47366 : H12AffineFastState.Bounded env47366 := by
  intro p hp
  have h : env47366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47365_47366 : H12AffineEnvironment.transform 10 152 env47365 = env47366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env47365 == env47366) = true)

theorem identity47366 : scanCanonicalize (H12AffineFastState.compose env47366 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound47366 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env47367 : List Nat := [2,4,8,16,32,17,128,37,512,189,152,146,160,130,136,170,146,17,189,137,130,33,16,138,40,17,153,26,27,152,20,168,37,169,131,513]

theorem envBound47367 : H12AffineFastState.Bounded env47367 := by
  intro p hp
  have h : env47367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47366_47367 : H12AffineEnvironment.transform 9 189 env47366 = env47367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env47366 == env47367) = true)

theorem identity47367 : scanCanonicalize (H12AffineFastState.compose env47367 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound47367 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47368 : List Nat := [2,4,8,16,32,17,128,37,3,189,152,146,160,130,136,170,146,17,189,137,130,33,16,138,40,17,153,26,27,152,20,168,37,169,131,2]

theorem envBound47368 : H12AffineFastState.Bounded env47368 := by
  intro p hp
  have h : env47368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47367_47368 : H12AffineEnvironment.transform 8 3 env47367 = env47368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env47367 == env47368) = true)

theorem identity47368 : scanCanonicalize (H12AffineFastState.compose env47368 (packedSelected [0,1,5] rootPS)) = affineNative (2^(6+1) ^^^ 12) := by decide +kernel

theorem selectedBound47368 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env47369 : List Nat := [2,4,8,16,32,17,12,37,3,49,20,30,44,14,4,38,30,17,49,5,14,33,16,6,40,17,21,26,27,20,20,36,37,37,15,2]

theorem envBound47369 : H12AffineFastState.Bounded env47369 := by
  intro p hp
  have h : env47369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47368_47369 : H12AffineEnvironment.transform 6 12 env47368 = env47369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 12 env47368 == env47369) = true)

theorem identity47369 : scanCanonicalize (H12AffineFastState.compose env47369 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound47369 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env47370 : List Nat := [2,4,8,16,14,17,12,11,3,31,20,30,2,14,4,8,30,17,31,5,14,15,16,6,6,17,21,26,27,20,20,10,11,11,15,2]

theorem envBound47370 : H12AffineFastState.Bounded env47370 := by
  intro p hp
  have h : env47370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47369_47370 : H12AffineEnvironment.transform 4 14 env47369 = env47370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env47369 == env47370) = true)

theorem identity47370 : scanCanonicalize (H12AffineFastState.compose env47370 (packedSelected [0,1,8] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound47370 : packedSelected [0,1,8] rootPS < 2^1333 := by decide +kernel

def env47371 : List Nat := [2,4,8,15,14,14,12,11,3,0,11,1,2,14,4,8,1,14,0,5,14,15,15,6,6,14,10,5,4,11,11,10,11,11,15,2]

theorem envBound47371 : H12AffineFastState.Bounded env47371 := by
  intro p hp
  have h : env47371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47370_47371 : H12AffineEnvironment.transform 3 15 env47370 = env47371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env47370 == env47371) = true)

theorem identity47371 : scanCanonicalize (H12AffineFastState.compose env47371 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47371 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47372 : List Nat := [2,1,8,10,11,11,9,11,3,0,11,1,2,11,1,8,1,11,0,0,11,10,10,3,3,11,10,0,1,11,11,10,11,11,10,2]

theorem envBound47372 : H12AffineFastState.Bounded env47372 := by
  intro p hp
  have h : env47372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47371_47372 : H12AffineEnvironment.transform 1 1 env47371 = env47372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47371 == env47372) = true)

theorem identity47372 : scanCanonicalize (H12AffineFastState.compose env47372 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47373 : List Nat := [2,1,2,0,1,1,3,1,3,0,1,1,2,1,1,2,1,1,0,0,1,0,0,3,3,1,0,0,1,1,1,0,1,1,0,2]

theorem envBound47373 : H12AffineFastState.Bounded env47373 := by
  intro p hp
  have h : env47373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47372_47373 : H12AffineEnvironment.transform 2 2 env47372 = env47373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47372 == env47373) = true)

theorem identity47373 : scanCanonicalize (H12AffineFastState.compose env47373 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47373 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47374 : List Nat := [1,1,1,0,1,1,0,1,0,0,1,1,1,1,1,1,1,1,0,0,1,0,0,0,0,1,0,0,1,1,1,0,1,1,0,1]

theorem envBound47374 : H12AffineFastState.Bounded env47374 := by
  intro p hp
  have h : env47374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47373_47374 : H12AffineEnvironment.transform 0 1 env47373 = env47374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47373 == env47374) = true)

def env47375 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1024,8232,2097152,4194304,16,16777216,8328,64,21039105,18949284,2118709,2049,16852008,23159989,117,18965653,18949228,16777867]

theorem envBound47375 : H12AffineFastState.Bounded env47375 := by
  intro p hp
  have h : env47375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47356_47375 : H12AffineEnvironment.transform 7 117 env47356 = env47375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47356 == env47375) = true)

theorem identity47375 : scanCanonicalize (H12AffineFastState.compose env47375 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(23+1) ^^^ 2114614) := by decide +kernel

theorem selectedBound47375 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env47376 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1024,8232,2097152,4194304,16,2114614,8328,64,6376503,90258,2118709,2049,2187294,4268163,117,73891,90202,2115261]

theorem envBound47376 : H12AffineFastState.Bounded env47376 := by
  intro p hp
  have h : env47376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47375_47376 : H12AffineEnvironment.transform 23 2114614 env47375 = env47376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2114614 env47375 == env47376) = true)

theorem identity47376 : scanCanonicalize (H12AffineFastState.compose env47376 (packedSelected [0,3,9,10,11,14,17,18,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(21+1) ^^^ 2114717) := by decide +kernel

theorem selectedBound47376 : packedSelected [0,3,9,10,11,14,17,18,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env47377 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1024,8232,2097152,2114717,16,2114614,8328,64,67754,90258,2118709,2049,2187294,2188318,117,73891,90202,2115261]

theorem envBound47377 : H12AffineFastState.Bounded env47377 := by
  intro p hp
  have h : env47377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47376_47377 : H12AffineEnvironment.transform 21 2114717 env47376 = env47377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114717 env47376 == env47377) = true)

theorem identity47377 : scanCanonicalize (H12AffineFastState.compose env47377 (packedSelected [0,3,7,9,10,11,14,17,18,20,22,23,24,26,32] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound47377 : packedSelected [0,3,7,9,10,11,14,17,18,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env47378 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1024,8232,17596,33,16,138,8328,64,67754,90258,4233,2049,74914,73890,117,73891,90202,513]

theorem envBound47378 : H12AffineFastState.Bounded env47378 := by
  intro p hp
  have h : env47378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47377_47378 : H12AffineEnvironment.transform 20 17596 env47377 = env47378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env47377 == env47378) = true)

theorem identity47378 : scanCanonicalize (H12AffineFastState.compose env47378 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound47378 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env47379 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,8233,29743,16400,10281,1024,8232,17596,33,16,138,8328,64,31877,5309,4233,2049,20621,21645,117,21644,5237,513]

theorem envBound47379 : H12AffineFastState.Bounded env47379 := by
  intro p hp
  have h : env47379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47378_47379 : H12AffineEnvironment.transform 15 29743 env47378 = env47379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env47378 == env47379) = true)

theorem identity47379 : scanCanonicalize (H12AffineFastState.compose env47379 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound47379 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env47380 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5293,8233,8322,5309,10281,1024,8232,4113,33,16,138,8328,64,10280,5309,4233,2049,1056,32,117,33,5237,513]

theorem envBound47380 : H12AffineFastState.Bounded env47380 := by
  intro p hp
  have h : env47380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47379_47380 : H12AffineEnvironment.transform 13 5293 env47379 = env47380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env47379 == env47380) = true)

theorem identity47380 : scanCanonicalize (H12AffineFastState.compose env47380 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound47380 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47381 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,136,8192,1061,8233,8322,1077,10281,1024,8232,153,33,16,138,8328,64,10280,1077,1,2049,1056,32,117,33,1277,513]

theorem envBound47381 : H12AffineFastState.Bounded env47381 := by
  intro p hp
  have h : env47381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47380_47381 : H12AffineEnvironment.transform 11 136 env47380 = env47381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env47380 == env47381) = true)

theorem identity47381 : scanCanonicalize (H12AffineFastState.compose env47381 (packedSelected [2,4,9] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound47381 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env47382 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,136,240,1061,217,114,1077,2265,1024,216,153,33,16,138,120,64,2264,1077,1,2049,1056,32,117,33,1277,513]

theorem envBound47382 : H12AffineFastState.Bounded env47382 := by
  intro p hp
  have h : env47382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47381_47382 : H12AffineEnvironment.transform 12 240 env47381 = env47382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env47381 == env47382) = true)

theorem identity47382 : scanCanonicalize (H12AffineFastState.compose env47382 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound47382 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env47383 : List Nat := [2,4,8,16,32,64,128,117,512,189,2048,136,240,152,217,114,136,2265,189,216,153,33,16,138,120,64,2264,136,1,2049,157,32,117,33,64,513]

theorem envBound47383 : H12AffineFastState.Bounded env47383 := by
  intro p hp
  have h : env47383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47382_47383 : H12AffineEnvironment.transform 9 189 env47382 = env47383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env47382 == env47383) = true)

theorem identity47383 : scanCanonicalize (H12AffineFastState.compose env47383 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound47383 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47384 : List Nat := [2,4,8,16,32,64,128,117,512,189,65,136,240,152,217,114,136,152,189,216,153,33,16,138,120,64,153,136,1,64,157,32,117,33,64,513]

theorem envBound47384 : H12AffineFastState.Bounded env47384 := by
  intro p hp
  have h : env47384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47383_47384 : H12AffineEnvironment.transform 10 65 env47383 = env47384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env47383 == env47384) = true)

theorem identity47384 : scanCanonicalize (H12AffineFastState.compose env47384 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47384 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env47385 : List Nat := [2,4,8,16,32,16,128,37,512,189,17,136,160,152,137,34,136,152,189,136,153,33,16,138,40,16,153,136,1,16,157,32,37,33,16,513]

theorem envBound47385 : H12AffineFastState.Bounded env47385 := by
  intro p hp
  have h : env47385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47384_47385 : H12AffineEnvironment.transform 5 16 env47384 = env47385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47384 == env47385) = true)

theorem identity47385 : scanCanonicalize (H12AffineFastState.compose env47385 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47385 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47386 : List Nat := [2,4,8,16,32,16,9,37,512,52,17,1,41,17,0,34,1,17,52,1,16,33,16,3,40,16,16,1,1,16,20,32,37,33,16,513]

theorem envBound47386 : H12AffineFastState.Bounded env47386 := by
  intro p hp
  have h : env47386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47385_47386 : H12AffineEnvironment.transform 6 9 env47385 = env47386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47385 == env47386) = true)

theorem identity47386 : scanCanonicalize (H12AffineFastState.compose env47386 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47387 : List Nat := [2,4,8,16,17,16,9,20,512,5,17,1,24,17,0,19,1,17,5,1,16,16,16,3,25,16,16,1,1,16,20,17,20,16,16,513]

theorem envBound47387 : H12AffineFastState.Bounded env47387 := by
  intro p hp
  have h : env47387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47386_47387 : H12AffineEnvironment.transform 4 17 env47386 = env47387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47386 == env47387) = true)

theorem identity47387 : scanCanonicalize (H12AffineFastState.compose env47387 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47388 : List Nat := [2,4,8,16,17,16,9,20,1,5,17,1,24,17,0,19,1,17,5,1,16,16,16,3,25,16,16,1,1,16,20,17,20,16,16,0]

theorem envBound47388 : H12AffineFastState.Bounded env47388 := by
  intro p hp
  have h : env47388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47387_47388 : H12AffineEnvironment.transform 8 1 env47387 = env47388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47387 == env47388) = true)

theorem identity47388 : scanCanonicalize (H12AffineFastState.compose env47388 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47389 : List Nat := [2,4,8,0,1,0,9,4,1,5,1,1,8,1,0,3,1,1,5,1,0,0,0,3,9,0,0,1,1,0,4,1,4,0,0,0]

theorem envBound47389 : H12AffineFastState.Bounded env47389 := by
  intro p hp
  have h : env47389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47388_47389 : H12AffineEnvironment.transform 3 0 env47388 = env47389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47388 == env47389) = true)

def env47390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,262144,1024,32769,2097152,4194304,41292,16777216,8328,64,21331968,18973837,2159644,294912,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound47390 : H12AffineFastState.Bounded env47390 := by
  intro p hp
  have h : env47390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47340_47390 : H12AffineEnvironment.transform 16 57677 env47340 = env47390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env47340 == env47390) = true)

theorem identity47390 : scanCanonicalize (H12AffineFastState.compose env47390 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound47390 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env47391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,262144,1024,32769,2097152,4194304,41292,138,8328,64,4554890,2196487,2159644,294912,75223,6382922,256,2188650,2196687,513]

theorem envBound47391 : H12AffineFastState.Bounded env47391 := by
  intro p hp
  have h : env47391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47390_47391 : H12AffineEnvironment.transform 23 138 env47390 = env47391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env47390 == env47391) = true)

def env47392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,138,8328,64,4303010,2196487,2159644,43048,75223,6382922,256,2188650,2196687,513]

theorem envBound47392 : H12AffineFastState.Bounded env47392 := by
  intro p hp
  have h : env47392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47391_47392 : H12AffineEnvironment.transform 17 10280 env47391 = env47392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47391 == env47392) = true)

def env47393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,2,8192,64,4302890,2196487,2159644,43048,75103,6382922,256,2188650,2196551,513]

theorem envBound47393 : H12AffineFastState.Bounded env47393 := by
  intro p hp
  have h : env47393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47392_47393 : H12AffineEnvironment.transform 6 8 env47392 = env47393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47392 == env47393) = true)

theorem identity47393 : scanCanonicalize (H12AffineFastState.compose env47393 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound47393 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env47394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,2097152,4194304,41292,2,8192,64,4204924,2098513,2159644,43048,41993,6349852,256,2155580,2098449,513]

theorem envBound47394 : H12AffineFastState.Bounded env47394 := by
  intro p hp
  have h : env47394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47393_47394 : H12AffineEnvironment.transform 15 33110 env47393 = env47394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env47393 == env47394) = true)

theorem identity47394 : scanCanonicalize (H12AffineFastState.compose env47394 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound47394 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env47395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,5457,4194304,41292,2,8192,64,4204924,4096,57677,43048,41993,4256077,256,61805,4160,513]

theorem envBound47395 : H12AffineFastState.Bounded env47395 := by
  intro p hp
  have h : env47395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47394_47395 : H12AffineEnvironment.transform 20 5457 env47394 = env47395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env47394 == env47395) = true)

theorem identity47395 : scanCanonicalize (H12AffineFastState.compose env47395 (packedSelected [11,17,23] rootPS)) = affineNative (2^(21+1) ^^^ 9325) := by decide +kernel

theorem selectedBound47395 : packedSelected [11,17,23] rootPS < 2^1333 := by decide +kernel

def env47396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,5457,9325,41292,2,8192,64,3345,4096,57677,43048,41993,54560,256,61805,4160,513]

theorem envBound47396 : H12AffineFastState.Bounded env47396 := by
  intro p hp
  have h : env47396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47395_47396 : H12AffineEnvironment.transform 21 9325 env47395 = env47396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9325 env47395 == env47396) = true)

theorem identity47396 : scanCanonicalize (H12AffineFastState.compose env47396 (packedSelected [4,7,9,11,17,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 28957) := by decide +kernel

theorem selectedBound47396 : packedSelected [4,7,9,11,17,18,27] rootPS < 2^1333 := by decide +kernel

def env47397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,28957,28747,4176,10280,1024,28956,5457,9325,20561,2,8192,64,3345,4096,4176,22837,21780,9277,256,112,4160,513]

theorem envBound47397 : H12AffineFastState.Bounded env47397 := by
  intro p hp
  have h : env47397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47396_47397 : H12AffineEnvironment.transform 14 28957 env47396 = env47397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28957 env47396 == env47397) = true)

theorem identity47397 : scanCanonicalize (H12AffineFastState.compose env47397 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 6209) := by decide +kernel

theorem selectedBound47397 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env47398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,6209,10588,10250,4176,10280,1024,10589,5457,9325,2064,2,8192,64,3345,4096,4176,372,3413,9277,256,112,4160,513]

theorem envBound47398 : H12AffineFastState.Bounded env47398 := by
  intro p hp
  have h : env47398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47397_47398 : H12AffineEnvironment.transform 13 6209 env47397 = env47398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6209 env47397 == env47398) = true)

theorem identity47398 : scanCanonicalize (H12AffineFastState.compose env47398 (packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 4152) := by decide +kernel

theorem selectedBound47398 : packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env47399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4152,6209,6500,6194,4176,6160,1024,6501,5457,5205,2064,2,4152,64,3345,4096,4176,372,3413,5125,256,112,4160,513]

theorem envBound47399 : H12AffineFastState.Bounded env47399 := by
  intro p hp
  have h : env47399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47398_47399 : H12AffineEnvironment.transform 12 4152 env47398 = env47399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4152 env47398 == env47399) = true)

theorem identity47399 : scanCanonicalize (H12AffineFastState.compose env47399 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound47399 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env47400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,1101,3124,3345,3143,1061,3173,1024,3344,292,32,2064,2,1101,64,3345,1141,1061,372,3413,112,256,112,1077,513]

theorem envBound47400 : H12AffineFastState.Bounded env47400 := by
  intro p hp
  have h : env47400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47399_47400 : H12AffineEnvironment.transform 11 1141 env47399 = env47400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env47399 == env47400) = true)

theorem identity47400 : scanCanonicalize (H12AffineFastState.compose env47400 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47400 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47401 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1141,1101,3124,3172,3143,1061,3173,1024,3173,81,32,2064,2,1101,64,3172,1141,1061,1,3104,112,117,112,1077,513]

theorem envBound47401 : H12AffineFastState.Bounded env47401 := by
  intro p hp
  have h : env47401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47400_47401 : H12AffineEnvironment.transform 7 117 env47400 = env47401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47400 == env47401) = true)

theorem identity47401 : scanCanonicalize (H12AffineFastState.compose env47401 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound47401 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env47402 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1125,1141,1101,81,1,34,1061,0,1024,0,81,32,1141,2,1101,64,1,1141,1061,1,69,112,117,112,1077,513]

theorem envBound47402 : H12AffineFastState.Bounded env47402 := by
  intro p hp
  have h : env47402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47401_47402 : H12AffineEnvironment.transform 10 1125 env47401 = env47402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env47401 == env47402) = true)

def env47403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,3,8193,64,4302891,2196487,2159644,43048,75102,6382922,256,2188650,2196550,513]

theorem envBound47403 : H12AffineFastState.Bounded env47403 := by
  intro p hp
  have h : env47403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47392_47403 : H12AffineEnvironment.transform 6 9 env47392 = env47403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47392 == env47403) = true)

theorem identity47403 : scanCanonicalize (H12AffineFastState.compose env47403 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47403 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env47404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,2097152,4194304,16,3,8193,64,4262263,2172251,2118976,2420,75102,6382922,256,2188650,2172186,513]

theorem envBound47404 : H12AffineFastState.Bounded env47404 := by
  intro p hp
  have h : env47404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47403_47404 : H12AffineEnvironment.transform 14 8540 env47403 = env47404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47403 == env47404) = true)

theorem identity47404 : scanCanonicalize (H12AffineFastState.compose env47404 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound47404 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env47405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1024,8541,91467,4194304,16,3,8193,64,4262263,16400,77835,2420,75102,4194305,256,33,16465,513]

theorem envBound47405 : H12AffineFastState.Bounded env47405 := by
  intro p hp
  have h : env47405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47404_47405 : H12AffineEnvironment.transform 20 91467 env47404 = env47405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env47404 == env47405) = true)

theorem identity47405 : scanCanonicalize (H12AffineFastState.compose env47405 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound47405 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env47406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,16401,10280,1024,8541,25629,4194304,16,3,8193,64,4196385,16400,12637,2420,9224,4194305,256,33,16465,513]

theorem envBound47406 : H12AffineFastState.Bounded env47406 := by
  intro p hp
  have h : env47406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47405_47406 : H12AffineEnvironment.transform 15 342 env47405 = env47406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env47405 == env47406) = true)

theorem identity47406 : scanCanonicalize (H12AffineFastState.compose env47406 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47406 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,342,16401,2420,1024,1,17729,4194304,16,3,349,64,4196385,16400,4097,2420,1364,4194305,256,33,16465,513]

theorem envBound47407 : H12AffineFastState.Bounded env47407 := by
  intro p hp
  have h : env47407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47406_47407 : H12AffineEnvironment.transform 12 348 env47406 = env47407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47406 == env47407) = true)

theorem identity47407 : scanCanonicalize (H12AffineFastState.compose env47407 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47407 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47408 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1024,1,17680,4194304,16,3,268,17,4196385,16400,4097,2341,1285,4194305,256,33,16384,513]

theorem envBound47408 : H12AffineFastState.Bounded env47408 := by
  intro p hp
  have h : env47408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47407_47408 : H12AffineEnvironment.transform 5 17 env47407 = env47408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47407 == env47408) = true)

theorem identity47408 : scanCanonicalize (H12AffineFastState.compose env47408 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21508) := by decide +kernel

theorem selectedBound47408 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47409 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1024,1,17680,21508,16,3,268,17,23589,16400,4097,2341,1285,21509,256,33,16384,513]

theorem envBound47409 : H12AffineFastState.Bounded env47409 := by
  intro p hp
  have h : env47409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47408_47409 : H12AffineEnvironment.transform 21 21508 env47408 = env47409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21508 env47408 == env47409) = true)

theorem identity47409 : scanCanonicalize (H12AffineFastState.compose env47409 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound47409 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47410 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5157,0,263,5172,2341,1024,1,4405,33,16,3,268,17,2048,5173,4097,2341,1285,32,256,33,5157,513]

theorem envBound47410 : H12AffineFastState.Bounded env47410 := by
  intro p hp
  have h : env47410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47409_47410 : H12AffineEnvironment.transform 13 5157 env47409 = env47410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env47409 == env47410) = true)

def env47411 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,269,2837,0,263,2820,2341,1024,1,3589,33,16,3,268,17,2048,2821,3889,2341,1285,32,256,33,2837,513]

theorem envBound47411 : H12AffineFastState.Bounded env47411 := by
  intro p hp
  have h : env47411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47410_47411 : H12AffineEnvironment.transform 11 3888 env47410 = env47411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env47410 == env47411) = true)

def env47412 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,269,1045,0,263,1028,1573,1024,1,261,33,16,3,268,17,1792,1029,49,1573,1285,32,256,33,1045,513]

theorem envBound47412 : H12AffineFastState.Bounded env47412 := by
  intro p hp
  have h : env47412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47411_47412 : H12AffineEnvironment.transform 10 1792 env47411 = env47412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env47411 == env47412) = true)

theorem identity47412 : scanCanonicalize (H12AffineFastState.compose env47412 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47413 : List Nat := [2,4,8,16,32,17,9,256,512,272,528,48,269,261,0,263,276,821,272,1,261,33,16,3,268,17,528,277,49,821,21,32,256,33,261,513]

theorem envBound47413 : H12AffineFastState.Bounded env47413 := by
  intro p hp
  have h : env47413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47412_47413 : H12AffineEnvironment.transform 9 272 env47412 = env47413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47412 == env47413) = true)

def env47414 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,41,33,0,35,48,529,52,1,33,33,16,3,40,17,528,49,49,529,21,32,36,33,33,513]

theorem envBound47414 : H12AffineFastState.Bounded env47414 := by
  intro p hp
  have h : env47414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47413_47414 : H12AffineEnvironment.transform 7 36 env47413 = env47414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47413 == env47414) = true)

def env47415 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,48,40,32,0,34,49,528,53,1,32,33,16,3,41,17,528,48,49,528,21,32,37,33,32,513]

theorem envBound47415 : H12AffineFastState.Bounded env47415 := by
  intro p hp
  have h : env47415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47413_47415 : H12AffineEnvironment.transform 7 37 env47413 = env47415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47413 == env47415) = true)

theorem identity47415 : scanCanonicalize (H12AffineFastState.compose env47415 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47416 : List Nat := [2,4,8,16,32,17,9,37,43,53,59,48,40,32,0,34,49,59,53,1,32,33,16,3,41,17,59,48,49,59,21,32,37,33,32,42]

theorem envBound47416 : H12AffineFastState.Bounded env47416 := by
  intro p hp
  have h : env47416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47415_47416 : H12AffineEnvironment.transform 8 43 env47415 = env47416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47415 == env47416) = true)

def leafEnv47416 : List Nat := [2,4,8,16,32,17,9,37,43,53,59,48,40,32,0,34,49,59,53,1,32,33,16,3,21,41,1,17,59,48,49,59,21,32,37,33,4,35,32,42,1,32,0]

def active47416 : List Nat := [0,1,2,3,4]

def tree47416 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47416 : H12WitnessSearch.Good tree47416 := H12GlobalWitnessIndex.good

theorem leafIdentity47416 : H12AffineFastState.composeSystem env47416 rootObs = leafEnv47416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47416 rootObs == leafEnv47416) = true)

theorem terminalChecked47416 : H12PackedTerminal.terminalCheckFast leafEnv47416 active47416 tree47416 = true := by decide +kernel

def env47417 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,269,1044,0,263,1029,1572,1024,1,260,33,16,3,268,17,1793,1028,48,1572,1285,32,256,33,1044,513]

theorem envBound47417 : H12AffineFastState.Bounded env47417 := by
  intro p hp
  have h : env47417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47411_47417 : H12AffineEnvironment.transform 10 1793 env47411 = env47417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env47411 == env47417) = true)

def env47418 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,269,2836,0,263,2821,2341,1024,1,3588,33,16,3,268,17,2048,2820,3888,2341,1285,32,256,33,2836,513]

theorem envBound47418 : H12AffineFastState.Bounded env47418 := by
  intro p hp
  have h : env47418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47410_47418 : H12AffineEnvironment.transform 11 3889 env47410 = env47418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env47410 == env47418) = true)

def env47419 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,269,1044,0,263,1029,1573,1024,1,260,33,16,3,268,17,1792,1028,48,1573,1285,32,256,33,1044,513]

theorem envBound47419 : H12AffineFastState.Bounded env47419 := by
  intro p hp
  have h : env47419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47418_47419 : H12AffineEnvironment.transform 10 1792 env47418 = env47419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env47418 == env47419) = true)

theorem identity47419 : scanCanonicalize (H12AffineFastState.compose env47419 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47420 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1573,49,40,1044,0,34,1029,1573,1024,1,33,33,16,3,41,17,1573,1028,48,1573,1056,32,37,33,1044,513]

theorem envBound47420 : H12AffineFastState.Bounded env47420 := by
  intro p hp
  have h : env47420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47419_47420 : H12AffineEnvironment.transform 7 37 env47419 = env47420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47419 == env47420) = true)

def env47421 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,49,40,32,0,34,49,529,52,1,33,33,16,3,41,17,529,48,48,529,20,32,37,33,32,513]

theorem envBound47421 : H12AffineFastState.Bounded env47421 := by
  intro p hp
  have h : env47421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47420_47421 : H12AffineEnvironment.transform 9 52 env47420 = env47421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47420 == env47421) = true)

def env47422 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,49,40,33,0,34,48,528,53,1,33,33,16,3,41,17,528,49,48,528,21,32,37,33,33,513]

theorem envBound47422 : H12AffineFastState.Bounded env47422 := by
  intro p hp
  have h : env47422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47420_47422 : H12AffineEnvironment.transform 9 53 env47420 = env47422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47420 == env47422) = true)

theorem identity47422 : scanCanonicalize (H12AffineFastState.compose env47422 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound47422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47423 : List Nat := [2,4,8,16,32,17,9,37,42,53,58,49,40,33,0,34,48,58,53,1,33,33,16,3,41,17,58,49,48,58,21,32,37,33,33,43]

theorem envBound47423 : H12AffineFastState.Bounded env47423 := by
  intro p hp
  have h : env47423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47422_47423 : H12AffineEnvironment.transform 8 42 env47422 = env47423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env47422 == env47423) = true)

def leafEnv47423 : List Nat := [2,4,8,16,32,17,9,37,42,53,58,49,40,33,0,34,48,58,53,1,33,33,16,3,21,41,1,17,58,49,48,58,21,32,37,33,4,35,33,43,1,33,0]

def active47423 : List Nat := [0,1,2,3,4]

def tree47423 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47423 : H12WitnessSearch.Good tree47423 := H12GlobalWitnessIndex.good

theorem leafIdentity47423 : H12AffineFastState.composeSystem env47423 rootObs = leafEnv47423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47423 rootObs == leafEnv47423) = true)

theorem terminalChecked47423 : H12PackedTerminal.terminalCheckFast leafEnv47423 active47423 tree47423 = true := by decide +kernel

def env47424 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,269,1045,0,263,1028,1572,1024,1,261,33,16,3,268,17,1793,1029,49,1572,1285,32,256,33,1045,513]

theorem envBound47424 : H12AffineFastState.Bounded env47424 := by
  intro p hp
  have h : env47424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47418_47424 : H12AffineEnvironment.transform 10 1793 env47418 = env47424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env47418 == env47424) = true)

theorem identity47424 : scanCanonicalize (H12AffineFastState.compose env47424 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47424 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47425 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,48,269,33,0,263,48,528,52,1,261,33,16,3,268,17,821,49,49,528,305,32,256,33,33,513]

theorem envBound47425 : H12AffineFastState.Bounded env47425 := by
  intro p hp
  have h : env47425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47424_47425 : H12AffineEnvironment.transform 9 52 env47424 = env47425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47424 == env47425) = true)

def env47426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10281,1024,32769,2097152,4194304,41292,138,8328,64,4303011,2196487,2159644,43049,75223,6382922,256,2188650,2196687,513]

theorem envBound47426 : H12AffineFastState.Bounded env47426 := by
  intro p hp
  have h : env47426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47391_47426 : H12AffineEnvironment.transform 17 10281 env47391 = env47426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env47391 == env47426) = true)

theorem identity47426 : scanCanonicalize (H12AffineFastState.compose env47426 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47426 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env47427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10281,1024,8541,2097152,4194304,16,138,8328,64,4262399,2172251,2118976,2421,75223,6382922,256,2188650,2172307,513]

theorem envBound47427 : H12AffineFastState.Bounded env47427 := by
  intro p hp
  have h : env47427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47426_47427 : H12AffineEnvironment.transform 14 8540 env47426 = env47427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47426 == env47427) = true)

theorem identity47427 : scanCanonicalize (H12AffineFastState.compose env47427 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47427 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env47428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10281,1024,8541,2097152,4194304,16,138,8328,64,4205045,2098513,2118976,2421,1501,6309184,256,2114912,2098585,513]

theorem envBound47428 : H12AffineFastState.Bounded env47428 := by
  intro p hp
  have h : env47428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47427_47428 : H12AffineEnvironment.transform 15 8202 env47427 = env47428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47427 == env47428) = true)

theorem identity47428 : scanCanonicalize (H12AffineFastState.compose env47428 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound47428 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8540,8202,4096,10281,1024,8541,2097152,4194304,16,138,8328,64,4205045,2098513,2098513,2421,1501,6296913,256,2102641,2098585,513]

theorem envBound47429 : H12AffineFastState.Bounded env47429 := by
  intro p hp
  have h : env47429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47428_47429 : H12AffineEnvironment.transform 13 4113 env47428 = env47429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env47428 == env47429) = true)

theorem identity47429 : scanCanonicalize (H12AffineFastState.compose env47429 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 5593) := by decide +kernel

theorem selectedBound47429 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env47430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8540,8202,4096,10281,1024,8541,5593,4194304,16,138,8328,64,4205045,4232,4232,2421,1501,4194440,256,168,4160,513]

theorem envBound47430 : H12AffineFastState.Bounded env47430 := by
  intro p hp
  have h : env47430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47429_47430 : H12AffineEnvironment.transform 20 5593 env47429 = env47430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5593 env47429 == env47430) = true)

theorem identity47430 : scanCanonicalize (H12AffineFastState.compose env47430 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound47430 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env47431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,8540,8202,4096,10281,1024,8541,5593,113,16,138,8328,64,10628,4232,4232,2421,1501,249,256,168,4160,513]

theorem envBound47431 : H12AffineFastState.Bounded env47431 := by
  intro p hp
  have h : env47431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47430_47431 : H12AffineEnvironment.transform 21 113 env47430 = env47431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env47430 == env47431) = true)

theorem identity47431 : scanCanonicalize (H12AffineFastState.compose env47431 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound47431 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env47432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,4113,217,399,4096,2476,1024,216,5593,113,16,138,269,64,2049,4232,4232,2421,1501,249,256,168,4160,513]

theorem envBound47432 : H12AffineFastState.Bounded env47432 := by
  intro p hp
  have h : env47432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47431_47432 : H12AffineEnvironment.transform 12 389 env47431 = env47432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env47431 == env47432) = true)

theorem identity47432 : scanCanonicalize (H12AffineFastState.compose env47432 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound47432 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47433 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,4113,1,343,4096,2420,1024,0,5377,113,16,82,269,64,2049,4176,4176,2421,1285,33,256,112,4160,513]

theorem envBound47433 : H12AffineFastState.Bounded env47433 := by
  intro p hp
  have h : env47433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47432_47433 : H12AffineEnvironment.transform 6 88 env47432 = env47433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env47432 == env47433) = true)

theorem identity47433 : scanCanonicalize (H12AffineFastState.compose env47433 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47433 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47434 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,4096,349,4113,1,343,4096,2420,273,0,4112,113,16,82,269,64,2049,4176,4176,2421,20,33,256,112,4160,513]

theorem envBound47434 : H12AffineFastState.Bounded env47434 := by
  intro p hp
  have h : env47434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47433_47434 : H12AffineEnvironment.transform 9 273 env47433 = env47434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47433 == env47434) = true)

theorem identity47434 : scanCanonicalize (H12AffineFastState.compose env47434 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47434 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47435 : List Nat := [2,4,8,16,32,64,88,117,512,100,2048,4096,40,4113,1,34,4096,2049,100,0,4112,113,16,82,120,64,2049,4176,4176,2048,20,33,117,112,4160,513]

theorem envBound47435 : H12AffineFastState.Bounded env47435 := by
  intro p hp
  have h : env47435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47434_47435 : H12AffineEnvironment.transform 7 117 env47434 = env47435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47434 == env47435) = true)

theorem identity47435 : scanCanonicalize (H12AffineFastState.compose env47435 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47435 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47436 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,4113,1,34,4096,2049,52,0,4112,33,16,2,40,16,2049,4096,4096,2048,20,33,37,32,4112,513]

theorem envBound47436 : H12AffineFastState.Bounded env47436 := by
  intro p hp
  have h : env47436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47435_47436 : H12AffineEnvironment.transform 5 16 env47435 = env47436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47435 == env47436) = true)

theorem identity47436 : scanCanonicalize (H12AffineFastState.compose env47436 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound47436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47437 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,4096,40,4113,1,34,4096,48,52,0,4112,33,16,2,40,16,48,4096,4096,49,20,33,37,32,4112,513]

theorem envBound47437 : H12AffineFastState.Bounded env47437 := by
  intro p hp
  have h : env47437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47436_47437 : H12AffineEnvironment.transform 10 49 env47436 = env47437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env47436 == env47437) = true)

theorem identity47437 : scanCanonicalize (H12AffineFastState.compose env47437 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound47437 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47438 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,40,49,1,34,32,48,52,0,48,33,16,2,40,16,48,32,32,49,20,33,37,32,48,513]

theorem envBound47438 : H12AffineFastState.Bounded env47438 := by
  intro p hp
  have h : env47438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47437_47438 : H12AffineEnvironment.transform 11 32 env47437 = env47438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env47437 == env47438) = true)

def leafEnv47438 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,40,49,1,34,32,48,52,0,48,33,16,2,20,40,1,16,48,32,32,49,20,33,37,32,4,34,48,513,1,49,0]

def active47438 : List Nat := [0,1,2,3,4,8]

def tree47438 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47438 : H12WitnessSearch.Good tree47438 := H12GlobalWitnessIndex.good

theorem leafIdentity47438 : H12AffineFastState.composeSystem env47438 rootObs = leafEnv47438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47438 rootObs == leafEnv47438) = true)

theorem terminalChecked47438 : H12PackedTerminal.terminalCheckFast leafEnv47438 active47438 tree47438 = true := by decide +kernel

def env47439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound47439 : H12AffineFastState.Bounded env47439 := by
  intro p hp
  have h : env47439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47338_47439 : H12AffineEnvironment.transform 18 1025 env47338 = env47439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env47338 == env47439) = true)

theorem identity47439 : scanCanonicalize (H12AffineFastState.compose env47439 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 213453) := by decide +kernel

theorem selectedBound47439 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,213453,8328,64,12878285,2278721,10507600,8830976,8570332,6431757,257,10650976,10642628,8643083]

theorem envBound47440 : H12AffineFastState.Bounded env47440 := by
  intro p hp
  have h : env47440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47439_47440 : H12AffineEnvironment.transform 23 213453 env47439 = env47440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 213453 env47439 == env47440) = true)

def env47441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281536,213453,8328,64,6705549,2278721,165136,2363456,2102684,6431757,257,21792,46212,2175563]

theorem envBound47441 : H12AffineFastState.Bounded env47441 := by
  intro p hp
  have h : env47441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47440_47441 : H12AffineEnvironment.transform 22 2281536 env47440 = env47441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281536 env47440 == env47441) = true)

def env47442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6590877,2098513,17664,2363456,2102684,6349853,257,21792,46212,2175563]

theorem envBound47442 : H12AffineFastState.Bounded env47442 := by
  intro p hp
  have h : env47442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47441_47442 : H12AffineEnvironment.transform 16 49168 env47441 = env47442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47441 == env47442) = true)

def env47443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2144541,2098513,17664,2363456,2102684,2411677,257,21792,46212,2175563]

theorem envBound47443 : H12AffineFastState.Bounded env47443 := by
  intro p hp
  have h : env47443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47442_47443 : H12AffineEnvironment.transform 21 272512 env47442 = env47443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47442 == env47443) = true)

theorem identity47443 : scanCanonicalize (H12AffineFastState.compose env47443 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound47443 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49168,262144,1025,32769,2097152,272512,2101328,21762,8328,64,2144541,2098513,17664,2363456,2102684,2411677,257,21792,46212,2156180]

theorem envBound47444 : H12AffineFastState.Bounded env47444 := by
  intro p hp
  have h : env47444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47443_47444 : H12AffineEnvironment.transform 15 54495 env47443 = env47444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env47443 == env47444) = true)

def env47445 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,262144,1025,32769,2097152,272392,2101328,21762,8192,64,2144541,2098513,17664,2363456,2102548,2411541,257,21792,46092,2156060]

theorem envBound47445 : H12AffineFastState.Bounded env47445 := by
  intro p hp
  have h : env47445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47444_47445 : H12AffineEnvironment.transform 6 8 env47444 = env47445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47444 == env47445) = true)

theorem identity47445 : scanCanonicalize (H12AffineFastState.compose env47445 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound47445 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env47446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,262144,1025,32769,25629,272392,29773,21762,8192,64,56576,24908,17664,291933,28937,305160,257,21792,46092,33281]

theorem envBound47446 : H12AffineFastState.Bounded env47446 := by
  intro p hp
  have h : env47446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47445_47446 : H12AffineEnvironment.transform 20 25629 env47445 = env47446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env47445 == env47446) = true)

theorem identity47446 : scanCanonicalize (H12AffineFastState.compose env47446 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound47446 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env47447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,43048,1025,32769,25629,32800,29773,21762,8192,64,56576,24908,17664,56437,28937,32,257,21792,46092,33281]

theorem envBound47447 : H12AffineFastState.Bounded env47447 := by
  intro p hp
  have h : env47447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47446_47447 : H12AffineEnvironment.transform 17 43048 env47446 = env47447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env47446 == env47447) = true)

theorem identity47447 : scanCanonicalize (H12AffineFastState.compose env47447 (packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47447 : packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env47448 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,49168,43048,1025,32769,25629,32800,29725,21762,8192,16,56576,24860,17664,56357,28937,32,257,21792,46092,33281]

theorem envBound47448 : H12AffineFastState.Bounded env47448 := by
  intro p hp
  have h : env47448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47447_47448 : H12AffineEnvironment.transform 5 16 env47447 = env47448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47447 == env47448) = true)

theorem identity47448 : scanCanonicalize (H12AffineFastState.compose env47448 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound47448 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env47449 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,32768,40971,46108,43048,1025,32769,4113,32800,17,8462,8192,16,43276,5392,12556,43049,1285,32,257,8492,46092,33281]

theorem envBound47449 : H12AffineFastState.Bounded env47449 := by
  intro p hp
  have h : env47449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47448_47449 : H12AffineEnvironment.transform 13 13324 env47448 = env47449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env47448 == env47449) = true)

theorem identity47449 : scanCanonicalize (H12AffineFastState.compose env47449 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound47449 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env47450 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,8203,13340,10280,1025,1,4113,32,17,8462,8192,16,10508,5392,12556,10281,1285,32,257,8492,13324,513]

theorem envBound47450 : H12AffineFastState.Bounded env47450 := by
  intro p hp
  have h : env47450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47449_47450 : H12AffineEnvironment.transform 14 0 env47449 = env47450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env47449 == env47450) = true)

theorem identity47450 : scanCanonicalize (H12AffineFastState.compose env47450 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 7741) := by decide +kernel

theorem selectedBound47450 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env47451 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7741,2609,0,7734,2593,5653,1025,1,4113,32,17,7987,7741,16,5937,5392,3889,5652,1285,32,257,7953,2609,513]

theorem envBound47451 : H12AffineFastState.Bounded env47451 := by
  intro p hp
  have h : env47451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47450_47451 : H12AffineEnvironment.transform 12 7741 env47450 = env47451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7741 env47450 == env47451) = true)

theorem identity47451 : scanCanonicalize (H12AffineFastState.compose env47451 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 3888) := by decide +kernel

theorem selectedBound47451 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47452 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,269,2609,0,262,2593,2341,1025,1,3873,32,17,3,269,16,2049,2592,3889,2340,1285,32,257,33,2609,513]

theorem envBound47452 : H12AffineFastState.Bounded env47452 := by
  intro p hp
  have h : env47452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47451_47452 : H12AffineEnvironment.transform 11 3888 env47451 = env47452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env47451 == env47452) = true)

theorem identity47452 : scanCanonicalize (H12AffineFastState.compose env47452 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound47452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47453 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1589,261,269,1028,0,262,1044,1808,1025,1,276,32,17,3,269,16,1588,1045,260,1809,1285,32,257,33,1028,513]

theorem envBound47453 : H12AffineFastState.Bounded env47453 := by
  intro p hp
  have h : env47453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47452_47453 : H12AffineEnvironment.transform 10 1589 env47452 = env47453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env47452 == env47453) = true)

theorem identity47453 : scanCanonicalize (H12AffineFastState.compose env47453 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound47453 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47454 : List Nat := [2,4,8,16,32,16,8,256,512,785,292,261,269,789,0,262,773,1,784,1,276,32,17,3,269,16,293,772,260,0,532,32,257,33,789,513]

theorem envBound47454 : H12AffineFastState.Bounded env47454 := by
  intro p hp
  have h : env47454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47453_47454 : H12AffineEnvironment.transform 9 785 env47453 = env47454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env47453 == env47454) = true)

theorem identity47454 : scanCanonicalize (H12AffineFastState.compose env47454 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47454 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47455 : List Nat := [2,4,8,0,32,0,8,256,512,769,292,261,269,773,0,262,773,1,768,1,260,32,1,3,269,0,293,772,260,0,516,32,257,33,773,513]

theorem envBound47455 : H12AffineFastState.Bounded env47455 := by
  intro p hp
  have h : env47455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47454_47455 : H12AffineEnvironment.transform 3 0 env47454 = env47455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47454 == env47455) = true)

theorem identity47455 : scanCanonicalize (H12AffineFastState.compose env47455 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound47455 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47456 : List Nat := [2,4,8,0,32,0,8,256,261,4,292,261,269,0,0,262,0,1,5,1,260,32,1,3,269,0,293,1,260,0,257,32,257,33,0,260]

theorem envBound47456 : H12AffineFastState.Bounded env47456 := by
  intro p hp
  have h : env47456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47455_47456 : H12AffineEnvironment.transform 8 261 env47455 = env47456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env47455 == env47456) = true)

theorem identity47456 : scanCanonicalize (H12AffineFastState.compose env47456 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47456 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env47457 : List Nat := [2,4,8,0,1,0,8,256,261,4,261,261,269,0,0,262,0,1,5,1,260,1,1,3,269,0,260,1,260,0,257,1,257,0,0,260]

theorem envBound47457 : H12AffineFastState.Bounded env47457 := by
  intro p hp
  have h : env47457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47456_47457 : H12AffineEnvironment.transform 4 1 env47456 = env47457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47456 == env47457) = true)

theorem identity47457 : scanCanonicalize (H12AffineFastState.compose env47457 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47457 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47458 : List Nat := [2,4,8,0,1,0,8,5,0,4,0,0,8,0,0,3,0,1,5,1,1,1,1,3,8,0,1,1,1,0,4,1,4,0,0,1]

theorem envBound47458 : H12AffineFastState.Bounded env47458 := by
  intro p hp
  have h : env47458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47457_47458 : H12AffineEnvironment.transform 7 5 env47457 = env47458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47457 == env47458) = true)

def env47459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1025,32769,2097152,272393,2101328,21762,8193,64,2144541,2098513,17664,2363456,2102549,2411540,257,21792,46093,2156061]

theorem envBound47459 : H12AffineFastState.Bounded env47459 := by
  intro p hp
  have h : env47459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47444_47459 : H12AffineEnvironment.transform 6 9 env47444 = env47459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47444 == env47459) = true)

theorem identity47459 : scanCanonicalize (H12AffineFastState.compose env47459 (packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound47459 : packedSelected [7,8,12,14,19,20,26,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env47460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,29823,24633,262144,1025,8232,2097152,272393,2101328,21762,8193,64,2103604,2098513,17664,2363456,2102549,2387005,257,21792,5156,2115124]

theorem envBound47460 : H12AffineFastState.Bounded env47460 := by
  intro p hp
  have h : env47460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47459_47460 : H12AffineEnvironment.transform 14 8233 env47459 = env47460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env47459 == env47460) = true)

theorem identity47460 : scanCanonicalize (H12AffineFastState.compose env47460 (packedSelected [0,1,4,8,14,15,16,17,22,26,27,41] rootPS)) = affineNative (2^(20+1) ^^^ 281653) := by decide +kernel

theorem selectedBound47460 : packedSelected [0,1,4,8,14,15,16,17,22,26,27,41] rootPS < 2^1333 := by decide +kernel

def env47461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,29823,24633,262144,1025,8232,281653,272393,285797,21762,8193,64,283905,280932,17664,23669,284960,8200,257,21792,5156,264705]

theorem envBound47461 : H12AffineFastState.Bounded env47461 := by
  intro p hp
  have h : env47461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47460_47461 : H12AffineEnvironment.transform 20 281653 env47460 = env47461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281653 env47460 == env47461) = true)

theorem identity47461 : scanCanonicalize (H12AffineFastState.compose env47461 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound47461 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env47462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,29823,24633,2420,1025,8232,17729,8573,21777,21762,8193,64,23669,16400,17664,23669,20564,8200,257,21792,5156,885]

theorem envBound47462 : H12AffineFastState.Bounded env47462 := by
  intro p hp
  have h : env47462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47461_47462 : H12AffineEnvironment.transform 17 2420 env47461 = env47462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env47461 == env47462) = true)

theorem identity47462 : scanCanonicalize (H12AffineFastState.compose env47462 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound47462 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env47463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,8233,343,5393,2420,1025,8232,12393,8573,8249,8234,8193,64,10589,13624,12328,10589,9596,8200,257,8200,5156,885]

theorem envBound47463 : H12AffineFastState.Bounded env47463 := by
  intro p hp
  have h : env47463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47462_47463 : H12AffineEnvironment.transform 13 13608 env47462 = env47463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env47462 == env47463) = true)

theorem identity47463 : scanCanonicalize (H12AffineFastState.compose env47463 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound47463 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env47464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,1,343,5393,2420,1025,0,4161,341,17,2,41,64,2421,5392,4096,2421,1364,32,257,32,5156,885]

theorem envBound47464 : H12AffineFastState.Bounded env47464 := by
  intro p hp
  have h : env47464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47463_47464 : H12AffineEnvironment.transform 12 40 env47463 = env47464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env47463 == env47464) = true)

theorem identity47464 : scanCanonicalize (H12AffineFastState.compose env47464 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47464 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47465 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8,5376,1,343,5393,2388,1025,0,4161,341,17,2,9,64,2389,5392,4096,2389,1364,0,257,0,5124,853]

theorem envBound47465 : H12AffineFastState.Bounded env47465 := by
  intro p hp
  have h : env47465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47464_47465 : H12AffineEnvironment.transform 4 0 env47464 = env47465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47464 == env47465) = true)

theorem identity47465 : scanCanonicalize (H12AffineFastState.compose env47465 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound47465 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47466 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1028,8,260,1,343,277,2388,1025,0,1093,341,17,2,9,64,2389,276,1028,2389,1364,0,257,0,0,853]

theorem envBound47466 : H12AffineFastState.Bounded env47466 := by
  intro p hp
  have h : env47466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47465_47466 : H12AffineEnvironment.transform 11 1028 env47465 = env47466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env47465 == env47466) = true)

theorem identity47466 : scanCanonicalize (H12AffineFastState.compose env47466 (packedSelected [0,4,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 351) := by decide +kernel

theorem selectedBound47466 : packedSelected [0,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env47467 : List Nat := [2,4,8,16,0,64,9,256,512,351,2048,347,8,260,1,343,277,2388,350,0,282,341,17,2,9,64,2389,276,347,2389,11,0,257,0,0,853]

theorem envBound47467 : H12AffineFastState.Bounded env47467 := by
  intro p hp
  have h : env47467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47466_47467 : H12AffineEnvironment.transform 9 351 env47466 = env47467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 351 env47466 == env47467) = true)

theorem identity47467 : scanCanonicalize (H12AffineFastState.compose env47467 (packedSelected [3,5,6,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound47467 : packedSelected [3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env47468 : List Nat := [2,4,8,16,0,27,9,256,512,260,2048,256,8,260,1,268,277,2319,261,0,282,270,17,2,9,27,2318,276,256,2318,11,0,257,0,0,782]

theorem envBound47468 : H12AffineFastState.Bounded env47468 := by
  intro p hp
  have h : env47468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47467_47468 : H12AffineEnvironment.transform 5 27 env47467 = env47468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env47467 == env47468) = true)

theorem identity47468 : scanCanonicalize (H12AffineFastState.compose env47468 (packedSelected [2,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound47468 : packedSelected [2,7,12] rootPS < 2^1333 := by decide +kernel

def env47469 : List Nat := [2,4,8,16,0,27,9,256,512,260,0,256,8,260,1,268,277,271,261,0,282,270,17,2,9,27,270,276,256,270,11,0,257,0,0,782]

theorem envBound47469 : H12AffineFastState.Bounded env47469 := by
  intro p hp
  have h : env47469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47468_47469 : H12AffineEnvironment.transform 10 0 env47468 = env47469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env47468 == env47469) = true)

theorem identity47469 : scanCanonicalize (H12AffineFastState.compose env47469 (packedSelected [0,3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47469 : packedSelected [0,3,5,6] rootPS < 2^1333 := by decide +kernel

def env47470 : List Nat := [2,4,8,0,0,11,9,256,512,260,0,256,8,260,1,268,261,271,261,0,266,270,1,2,9,11,270,260,256,270,11,0,257,0,0,782]

theorem envBound47470 : H12AffineFastState.Bounded env47470 := by
  intro p hp
  have h : env47470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47469_47470 : H12AffineEnvironment.transform 3 0 env47469 = env47470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47469 == env47470) = true)

theorem identity47470 : scanCanonicalize (H12AffineFastState.compose env47470 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound47470 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env47471 : List Nat := [2,4,7,0,0,4,6,256,512,260,0,256,7,260,1,259,261,256,261,0,261,257,1,2,6,4,257,260,256,257,4,0,257,0,0,769]

theorem envBound47471 : H12AffineFastState.Bounded env47471 := by
  intro p hp
  have h : env47471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47470_47471 : H12AffineEnvironment.transform 2 7 env47470 = env47471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env47470 == env47471) = true)

theorem identity47471 : scanCanonicalize (H12AffineFastState.compose env47471 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound47471 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47472 : List Nat := [2,0,3,0,0,0,2,256,512,256,0,256,3,256,1,259,257,256,257,0,257,257,1,2,2,0,257,256,256,257,0,0,257,0,0,769]

theorem envBound47472 : H12AffineFastState.Bounded env47472 := by
  intro p hp
  have h : env47472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47471_47472 : H12AffineEnvironment.transform 1 0 env47471 = env47472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env47471 == env47472) = true)

theorem identity47472 : scanCanonicalize (H12AffineFastState.compose env47472 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound47472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47473 : List Nat := [2,0,3,0,0,0,2,1,512,1,0,1,3,1,1,2,0,1,0,0,0,0,1,2,2,0,0,1,1,0,0,0,0,0,0,512]

theorem envBound47473 : H12AffineFastState.Bounded env47473 := by
  intro p hp
  have h : env47473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47472_47473 : H12AffineEnvironment.transform 7 1 env47472 = env47473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env47472 == env47473) = true)

theorem identity47473 : scanCanonicalize (H12AffineFastState.compose env47473 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47473 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47474 : List Nat := [1,0,0,0,0,0,1,1,512,1,0,1,0,1,1,1,0,1,0,0,0,0,1,1,1,0,0,1,1,0,0,0,0,0,0,512]

theorem envBound47474 : H12AffineFastState.Bounded env47474 := by
  intro p hp
  have h : env47474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47473_47474 : H12AffineEnvironment.transform 0 1 env47473 = env47474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47473 == env47474) = true)

def env47475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2144540,2098513,17664,2363456,2102684,2411676,257,21792,46212,2175563]

theorem envBound47475 : H12AffineFastState.Bounded env47475 := by
  intro p hp
  have h : env47475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47442_47475 : H12AffineEnvironment.transform 21 272513 env47442 = env47475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47442 == env47475) = true)

theorem identity47475 : scanCanonicalize (H12AffineFastState.compose env47475 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound47475 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115870,272513,120014,98781,8328,64,97666,115151,17664,382174,119042,329730,257,21792,46212,63189]

theorem envBound47476 : H12AffineFastState.Bounded env47476 := by
  intro p hp
  have h : env47476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47475_47476 : H12AffineEnvironment.transform 20 115870 env47475 = env47476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env47475 == env47476) = true)

def env47477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115734,272393,119878,98645,8192,64,97546,115015,17664,382038,119042,329730,257,21792,46092,63069]

theorem envBound47477 : H12AffineFastState.Bounded env47477 := by
  intro p hp
  have h : env47477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47476_47477 : H12AffineEnvironment.transform 6 8 env47476 = env47477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47476 == env47477) = true)

theorem identity47477 : scanCanonicalize (H12AffineFastState.compose env47477 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound47477 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env47478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,5392,262144,1025,21761,69910,272393,65862,87125,8192,64,97546,70727,17664,328022,66562,329730,257,21792,24844,9053]

theorem envBound47478 : H12AffineFastState.Bounded env47478 := by
  intro p hp
  have h : env47478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47477_47478 : H12AffineEnvironment.transform 14 21760 env47477 = env47478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env47477 == env47478) = true)

theorem identity47478 : scanCanonicalize (H12AffineFastState.compose env47478 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound47478 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env47479 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,5392,76159,1025,21761,69910,65910,65862,87125,8192,64,97546,70727,17664,10281,66562,8573,257,21792,24844,9053]

theorem envBound47479 : H12AffineFastState.Bounded env47479 := by
  intro p hp
  have h : env47479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47478_47479 : H12AffineEnvironment.transform 17 76159 env47478 = env47479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env47478 == env47479) = true)

theorem identity47479 : scanCanonicalize (H12AffineFastState.compose env47479 (packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47479 : packedSelected [3,4,7,9,10,16,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env47480 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,5392,2420,1025,21761,12573,8573,8525,29790,8192,64,23809,13388,17664,10281,9225,8573,257,21792,24844,9053]

theorem envBound47480 : H12AffineFastState.Bounded env47480 := by
  intro p hp
  have h : env47480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47479_47480 : H12AffineEnvironment.transform 15 8203 env47479 = env47480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47479 == env47480) = true)

theorem identity47480 : scanCanonicalize (H12AffineFastState.compose env47480 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound47480 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env47481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8461,8203,5392,2420,1025,8460,12573,8573,8525,83,8192,64,10508,13388,12557,10281,9225,8573,257,8493,5377,9053]

theorem envBound47481 : H12AffineFastState.Bounded env47481 := by
  intro p hp
  have h : env47481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47480_47481 : H12AffineEnvironment.transform 13 13325 env47480 = env47481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env47480 == env47481) = true)

theorem identity47481 : scanCanonicalize (H12AffineFastState.compose env47481 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47481 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env47482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,0,262,5392,2420,1025,1,4112,112,64,83,269,64,2049,5441,4096,2340,1284,112,257,32,5377,592]

theorem envBound47482 : H12AffineFastState.Bounded env47482 := by
  intro p hp
  have h : env47482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47481_47482 : H12AffineEnvironment.transform 12 269 env47481 = env47482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47481 == env47482) = true)

theorem identity47482 : scanCanonicalize (H12AffineFastState.compose env47482 (packedSelected [0,1,3,4,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 357) := by decide +kernel

theorem selectedBound47482 : packedSelected [0,1,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,357,4096,269,5376,0,262,5392,17,1025,1,4112,112,64,83,269,64,356,5441,4096,65,1284,112,257,32,5377,592]

theorem envBound47483 : H12AffineFastState.Bounded env47483 := by
  intro p hp
  have h : env47483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47482_47483 : H12AffineEnvironment.transform 10 357 env47482 = env47483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 357 env47482 == env47483) = true)

theorem identity47483 : scanCanonicalize (H12AffineFastState.compose env47483 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47483 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47484 : List Nat := [2,4,8,16,32,16,8,256,512,1024,309,4096,269,5376,0,262,5392,17,1025,1,4112,32,16,3,269,16,308,5393,4096,17,1284,32,257,32,5377,512]

theorem envBound47484 : H12AffineFastState.Bounded env47484 := by
  intro p hp
  have h : env47484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47483_47484 : H12AffineEnvironment.transform 5 16 env47483 = env47484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47483 == env47484) = true)

theorem identity47484 : scanCanonicalize (H12AffineFastState.compose env47484 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound47484 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47485 : List Nat := [2,4,8,16,32,16,8,256,512,1024,309,1328,269,48,0,262,32,17,1025,1,1312,32,16,3,269,16,308,33,1328,17,1284,32,257,32,49,512]

theorem envBound47485 : H12AffineFastState.Bounded env47485 := by
  intro p hp
  have h : env47485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47484_47485 : H12AffineEnvironment.transform 11 1328 env47484 = env47485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env47484 == env47485) = true)

theorem identity47485 : scanCanonicalize (H12AffineFastState.compose env47485 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 283) := by decide +kernel

theorem selectedBound47485 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47486 : List Nat := [2,4,8,16,32,16,8,256,512,283,309,43,269,48,0,262,32,17,282,1,59,32,16,3,269,16,308,33,43,17,31,32,257,32,49,512]

theorem envBound47486 : H12AffineFastState.Bounded env47486 := by
  intro p hp
  have h : env47486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47485_47486 : H12AffineEnvironment.transform 9 283 env47485 = env47486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 283 env47485 == env47486) = true)

theorem identity47486 : scanCanonicalize (H12AffineFastState.compose env47486 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound47486 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47487 : List Nat := [2,4,8,16,32,16,8,63,512,36,10,43,50,48,0,57,32,17,37,1,59,32,16,3,50,16,11,33,43,17,31,32,62,32,49,512]

theorem envBound47487 : H12AffineFastState.Bounded env47487 := by
  intro p hp
  have h : env47487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47486_47487 : H12AffineEnvironment.transform 7 63 env47486 = env47487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env47486 == env47487) = true)

theorem identity47487 : scanCanonicalize (H12AffineFastState.compose env47487 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47487 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47488 : List Nat := [2,4,8,16,0,16,8,31,512,4,10,11,18,16,0,25,0,17,5,1,27,0,16,3,18,16,11,1,11,17,31,0,30,0,17,512]

theorem envBound47488 : H12AffineFastState.Bounded env47488 := by
  intro p hp
  have h : env47488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47487_47488 : H12AffineEnvironment.transform 4 0 env47487 = env47488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47487 == env47488) = true)

def env47489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115735,272392,119879,98644,8193,64,97547,115014,17664,382039,119042,329730,257,21792,46093,63068]

theorem envBound47489 : H12AffineFastState.Bounded env47489 := by
  intro p hp
  have h : env47489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47476_47489 : H12AffineEnvironment.transform 6 9 env47476 = env47489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47476 == env47489) = true)

theorem identity47489 : scanCanonicalize (H12AffineFastState.compose env47489 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound47489 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env47490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,35,49168,262144,1025,32769,50228,272392,54372,33143,8193,64,32040,49509,17664,316532,53537,264225,257,21792,46093,63068]

theorem envBound47490 : H12AffineFastState.Bounded env47490 := by
  intro p hp
  have h : env47490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47489_47490 : H12AffineEnvironment.transform 15 35 env47489 = env47490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env47489 == env47490) = true)

theorem identity47490 : scanCanonicalize (H12AffineFastState.compose env47490 (packedSelected [0,3,4,10,16,22,24,26,27,35] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound47490 : packedSelected [0,3,4,10,16,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env47491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,35,37989,262144,1025,32769,36929,272392,32785,33143,8193,64,10589,38160,4469,294913,34132,264225,257,341,46093,41513]

theorem envBound47491 : H12AffineFastState.Bounded env47491 := by
  intro p hp
  have h : env47491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47490_47491 : H12AffineEnvironment.transform 13 5237 env47490 = env47491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env47490 == env47491) = true)

theorem identity47491 : scanCanonicalize (H12AffineFastState.compose env47491 (packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound47491 : packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env47492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,35,37989,35188,1025,32769,36929,41340,32785,33143,8193,64,10589,38160,4469,2421,34132,33109,257,341,46093,41513]

theorem envBound47492 : H12AffineFastState.Bounded env47492 := by
  intro p hp
  have h : env47492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47491_47492 : H12AffineEnvironment.transform 17 35188 env47491 = env47492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env47491 == env47492) = true)

theorem identity47492 : scanCanonicalize (H12AffineFastState.compose env47492 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound47492 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env47493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5237,32768,35,37989,35188,1025,32769,36929,33108,32785,33143,41,64,2421,38160,4469,2421,34132,33109,257,341,37925,33281]

theorem envBound47493 : H12AffineFastState.Bounded env47493 := by
  intro p hp
  have h : env47493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47492_47493 : H12AffineEnvironment.transform 12 40 env47492 = env47493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env47492 == env47493) = true)

theorem identity47493 : scanCanonicalize (H12AffineFastState.compose env47493 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47493 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47494 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,40,5237,32768,35,37989,34896,1025,32769,36929,32880,32785,32851,41,64,2129,37940,4177,2129,33904,32881,37,113,37925,33281]

theorem envBound47494 : H12AffineFastState.Bounded env47494 := by
  intro p hp
  have h : env47494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47493_47494 : H12AffineEnvironment.transform 7 36 env47493 = env47494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47493 == env47494) = true)

theorem identity47494 : scanCanonicalize (H12AffineFastState.compose env47494 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound47494 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env47495 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,2065,40,3172,32768,35,35956,34896,1025,32769,34896,32880,32785,32851,41,64,2129,35877,2112,2129,33904,32881,37,113,35892,33281]

theorem envBound47495 : H12AffineFastState.Bounded env47495 := by
  intro p hp
  have h : env47495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47494_47495 : H12AffineEnvironment.transform 11 2065 env47494 = env47495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env47494 == env47495) = true)

theorem identity47495 : scanCanonicalize (H12AffineFastState.compose env47495 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47495 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env47496 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,2065,40,2049,32768,35,34833,34896,100,32769,34896,32880,32785,32851,41,64,2129,34880,2112,2129,32789,32881,37,113,34897,33281]

theorem envBound47496 : H12AffineFastState.Bounded env47496 := by
  intro p hp
  have h : env47496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47495_47496 : H12AffineEnvironment.transform 9 101 env47495 = env47496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47495 == env47496) = true)

theorem identity47496 : scanCanonicalize (H12AffineFastState.compose env47496 (packedSelected [2,4,7] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound47496 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env47497 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,2065,40,2049,2049,35,16,81,100,2048,81,2161,2064,2130,41,64,2129,65,2112,2129,2068,2160,37,113,80,2560]

theorem envBound47497 : H12AffineFastState.Bounded env47497 := by
  intro p hp
  have h : env47497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47496_47497 : H12AffineEnvironment.transform 14 2049 env47496 = env47497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env47496 == env47497) = true)

theorem identity47497 : scanCanonicalize (H12AffineFastState.compose env47497 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound47497 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env47498 : List Nat := [2,4,8,16,32,64,9,36,512,101,81,64,40,80,80,35,16,81,100,81,81,32,65,3,41,64,0,65,17,0,69,33,37,113,80,593]

theorem envBound47498 : H12AffineFastState.Bounded env47498 := by
  intro p hp
  have h : env47498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47497_47498 : H12AffineEnvironment.transform 10 81 env47497 = env47498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env47497 == env47498) = true)

theorem identity47498 : scanCanonicalize (H12AffineFastState.compose env47498 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound47498 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env47499 : List Nat := [2,4,8,16,32,64,9,36,97,101,81,64,40,80,80,35,16,81,100,81,81,32,65,3,41,64,0,65,17,0,69,33,37,113,80,48]

theorem envBound47499 : H12AffineFastState.Bounded env47499 := by
  intro p hp
  have h : env47499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47498_47499 : H12AffineEnvironment.transform 8 97 env47498 = env47499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env47498 == env47499) = true)

theorem identity47499 : scanCanonicalize (H12AffineFastState.compose env47499 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47499 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env47500 : List Nat := [2,4,8,16,0,64,9,4,65,69,81,64,8,80,80,3,16,81,68,81,81,0,65,3,9,64,0,65,17,0,69,1,5,81,80,16]

theorem envBound47500 : H12AffineFastState.Bounded env47500 := by
  intro p hp
  have h : env47500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47499_47500 : H12AffineEnvironment.transform 4 0 env47499 = env47500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47499 == env47500) = true)

theorem identity47500 : scanCanonicalize (H12AffineFastState.compose env47500 (packedSelected [0,1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47500 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env47501 : List Nat := [2,4,8,16,0,16,9,4,17,21,1,16,8,0,0,3,16,1,20,1,1,0,17,3,9,16,0,17,17,0,21,1,5,1,0,16]

theorem envBound47501 : H12AffineFastState.Bounded env47501 := by
  intro p hp
  have h : env47501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47500_47501 : H12AffineEnvironment.transform 5 16 env47500 = env47501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47500 == env47501) = true)

theorem identity47501 : scanCanonicalize (H12AffineFastState.compose env47501 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47501 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47502 : List Nat := [2,4,8,0,0,0,9,4,1,5,1,0,8,0,0,3,0,1,4,1,1,0,1,3,9,0,0,1,1,0,5,1,5,1,0,0]

theorem envBound47502 : H12AffineFastState.Bounded env47502 := by
  intro p hp
  have h : env47502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47501_47502 : H12AffineEnvironment.transform 3 0 env47501 = env47502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47501 == env47502) = true)

def env47503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6590876,2098512,17665,2363456,2102684,6349852,257,21792,46212,2175563]

theorem envBound47503 : H12AffineFastState.Bounded env47503 := by
  intro p hp
  have h : env47503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47441_47503 : H12AffineEnvironment.transform 16 49169 env47441 = env47503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env47441 == env47503) = true)

def env47504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2144540,2098512,17665,2363456,2102684,2411676,257,21792,46212,2175563]

theorem envBound47504 : H12AffineFastState.Bounded env47504 := by
  intro p hp
  have h : env47504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47503_47504 : H12AffineEnvironment.transform 21 272512 env47503 = env47504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47503 == env47504) = true)

theorem identity47504 : scanCanonicalize (H12AffineFastState.compose env47504 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47504 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272512,2101329,41430,8328,64,2144540,2098512,17665,2363456,2102684,2411676,257,21792,46212,2101825]

theorem envBound47505 : H12AffineFastState.Bounded env47505 := by
  intro p hp
  have h : env47505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47504_47505 : H12AffineEnvironment.transform 15 8202 env47504 = env47505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47504 == env47505) = true)

theorem identity47505 : scanCanonicalize (H12AffineFastState.compose env47505 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 268733) := by decide +kernel

theorem selectedBound47505 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,268733,272512,264684,41430,8328,64,303265,269549,17665,2557,265249,54561,257,21792,46212,265212]

theorem envBound47506 : H12AffineFastState.Bounded env47506 := by
  intro p hp
  have h : env47506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47505_47506 : H12AffineEnvironment.transform 20 268733 env47505 = env47506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268733 env47505 == env47506) = true)

theorem identity47506 : scanCanonicalize (H12AffineFastState.compose env47506 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47506 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env47507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16400,262144,1025,0,268733,272512,264684,8663,8328,64,270496,269549,17665,2557,265249,21792,257,21792,13445,265212]

theorem envBound47507 : H12AffineFastState.Bounded env47507 := by
  intro p hp
  have h : env47507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47506_47507 : H12AffineEnvironment.transform 14 1 env47506 = env47507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47506 == env47507) = true)

theorem identity47507 : scanCanonicalize (H12AffineFastState.compose env47507 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47507 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,1,8202,5392,262144,1025,0,268733,272512,264684,8663,8328,64,270496,269549,4097,2557,265249,32,257,32,13445,265212]

theorem envBound47508 : H12AffineFastState.Bounded env47508 := by
  intro p hp
  have h : env47508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47507_47508 : H12AffineEnvironment.transform 13 5376 env47507 = env47508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47507 == env47508) = true)

theorem identity47508 : scanCanonicalize (H12AffineFastState.compose env47508 (packedSelected [0,2,7,9,11,16,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound47508 : packedSelected [0,2,7,9,11,16,17,18,22] rootPS < 2^1333 := by decide +kernel

def env47509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5376,1,34,5392,262144,1025,0,268733,264360,264684,511,160,64,262280,269549,4097,2557,265249,32,257,32,5293,265212]

theorem envBound47509 : H12AffineFastState.Bounded env47509 := by
  intro p hp
  have h : env47509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47508_47509 : H12AffineEnvironment.transform 12 40 env47508 = env47509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env47508 == env47509) = true)

theorem identity47509 : scanCanonicalize (H12AffineFastState.compose env47509 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47509 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env47510 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,5237,1,34,5221,262144,1025,0,268488,264360,264345,138,160,64,262280,269549,4097,2184,265249,32,116,32,5293,264841]

theorem envBound47510 : H12AffineFastState.Bounded env47510 := by
  intro p hp
  have h : env47510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47509_47510 : H12AffineEnvironment.transform 7 117 env47509 = env47510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47509 == env47510) = true)

theorem identity47510 : scanCanonicalize (H12AffineFastState.compose env47510 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound47510 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47511 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,5237,1,34,5221,2049,1025,0,4297,169,152,138,160,64,2185,5356,4097,2184,1056,32,116,32,5293,648]

theorem envBound47511 : H12AffineFastState.Bounded env47511 := by
  intro p hp
  have h : env47511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47510_47511 : H12AffineEnvironment.transform 17 2049 env47510 = env47511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env47510 == env47511) = true)

theorem identity47511 : scanCanonicalize (H12AffineFastState.compose env47511 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47511 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47512 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,4096,40,4113,1,34,4097,2049,101,0,4297,169,152,138,160,64,2185,4232,4097,2184,68,32,116,32,4297,648]

theorem envBound47512 : H12AffineFastState.Bounded env47512 := by
  intro p hp
  have h : env47512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47511_47512 : H12AffineEnvironment.transform 9 100 env47511 = env47512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47511 == env47512) = true)

theorem identity47512 : scanCanonicalize (H12AffineFastState.compose env47512 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 201) := by decide +kernel

theorem selectedBound47512 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env47513 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,201,40,216,1,34,200,2049,101,0,0,169,152,138,160,64,2185,65,200,2184,68,32,116,32,0,648]

theorem envBound47513 : H12AffineFastState.Bounded env47513 := by
  intro p hp
  have h : env47513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47512_47513 : H12AffineEnvironment.transform 11 201 env47512 = env47513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 201 env47512 == env47513) = true)

theorem identity47513 : scanCanonicalize (H12AffineFastState.compose env47513 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound47513 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47514 : List Nat := [2,4,8,16,32,64,40,117,512,100,2048,97,40,112,1,34,96,2049,101,0,0,1,48,34,8,64,2081,65,96,2080,68,32,116,32,0,544]

theorem envBound47514 : H12AffineFastState.Bounded env47514 := by
  intro p hp
  have h : env47514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47513_47514 : H12AffineEnvironment.transform 6 40 env47513 = env47514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env47513 == env47514) = true)

theorem identity47514 : scanCanonicalize (H12AffineFastState.compose env47514 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound47514 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47515 : List Nat := [2,4,8,16,32,0,40,53,512,36,2048,33,40,48,1,34,32,2049,37,0,0,1,48,34,8,0,2081,1,32,2080,4,32,52,32,0,544]

theorem envBound47515 : H12AffineFastState.Bounded env47515 := by
  intro p hp
  have h : env47515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47514_47515 : H12AffineEnvironment.transform 5 0 env47514 = env47515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env47514 == env47515) = true)

theorem identity47515 : scanCanonicalize (H12AffineFastState.compose env47515 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound47515 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47516 : List Nat := [2,4,8,16,32,0,40,53,512,36,48,33,40,48,1,34,32,49,37,0,0,1,48,34,8,0,17,1,32,16,4,32,52,32,0,544]

theorem envBound47516 : H12AffineFastState.Bounded env47516 := by
  intro p hp
  have h : env47516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47515_47516 : H12AffineEnvironment.transform 10 48 env47515 = env47516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env47515 == env47516) = true)

theorem identity47516 : scanCanonicalize (H12AffineFastState.compose env47516 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47516 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47517 : List Nat := [2,4,8,0,32,0,40,37,512,36,32,33,40,32,1,34,32,33,37,0,0,1,32,34,8,0,1,1,32,0,4,32,36,32,0,544]

theorem envBound47517 : H12AffineFastState.Bounded env47517 := by
  intro p hp
  have h : env47517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47516_47517 : H12AffineEnvironment.transform 3 0 env47516 = env47517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47516 == env47517) = true)

def env47518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2144541,2098512,17665,2363456,2102684,2411677,257,21792,46212,2175563]

theorem envBound47518 : H12AffineFastState.Bounded env47518 := by
  intro p hp
  have h : env47518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47503_47518 : H12AffineEnvironment.transform 21 272513 env47503 = env47518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47503 == env47518) = true)

theorem identity47518 : scanCanonicalize (H12AffineFastState.compose env47518 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound47518 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77898,272513,73755,98780,8328,64,100695,79130,17665,335882,75222,392407,257,21792,46212,513]

theorem envBound47519 : H12AffineFastState.Bounded env47519 := by
  intro p hp
  have h : env47519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47518_47519 : H12AffineEnvironment.transform 20 77898 env47518 = env47519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env47518 == env47519) = true)

def env47520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77898,272393,73755,98644,8192,64,100695,79130,17665,335882,75102,392287,257,21792,46092,513]

theorem envBound47520 : H12AffineFastState.Bounded env47520 := by
  intro p hp
  have h : env47520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47519_47520 : H12AffineEnvironment.transform 6 8 env47519 = env47520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47519 == env47520) = true)

theorem identity47520 : scanCanonicalize (H12AffineFastState.compose env47520 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound47520 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env47521 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,77898,41340,73755,98644,8192,64,100695,79130,17665,108927,75102,95530,257,21792,46092,513]

theorem envBound47521 : H12AffineFastState.Bounded env47521 := by
  intro p hp
  have h : env47521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47520_47521 : H12AffineEnvironment.transform 17 35189 env47520 = env47521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env47520 == env47521) = true)

theorem identity47521 : scanCanonicalize (H12AffineFastState.compose env47521 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47521 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env47522 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,35189,1025,32769,4160,41340,17,41310,8192,64,43357,5392,17665,35189,1364,21792,257,21792,46092,513]

theorem envBound47522 : H12AffineFastState.Bounded env47522 := by
  intro p hp
  have h : env47522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47521_47522 : H12AffineEnvironment.transform 15 8202 env47521 = env47522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47521 == env47522) = true)

theorem identity47522 : scanCanonicalize (H12AffineFastState.compose env47522 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47522 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47523 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8202,46156,35189,1025,32769,4160,41340,17,41310,8192,64,43357,5392,12636,35189,1364,8573,257,8573,46092,513]

theorem envBound47523 : H12AffineFastState.Bounded env47523 := by
  intro p hp
  have h : env47523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47522_47523 : H12AffineEnvironment.transform 13 13405 env47522 = env47523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47522 == env47523) = true)

theorem identity47523 : scanCanonicalize (H12AffineFastState.compose env47523 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47523 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47524 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,343,38161,35189,1025,32769,4160,32801,17,32771,349,64,34816,5392,4097,35189,1364,32,257,32,38225,513]

theorem envBound47524 : H12AffineFastState.Bounded env47524 := by
  intro p hp
  have h : env47524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47523_47524 : H12AffineEnvironment.transform 12 349 env47523 = env47524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47523 == env47524) = true)

theorem identity47524 : scanCanonicalize (H12AffineFastState.compose env47524 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound47524 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47525 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5393,2421,1025,1,4160,33,17,3,349,64,2048,5392,4097,2421,1364,32,257,32,5457,513]

theorem envBound47525 : H12AffineFastState.Bounded env47525 := by
  intro p hp
  have h : env47525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47524_47525 : H12AffineEnvironment.transform 14 0 env47524 = env47525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env47524 == env47525) = true)

theorem identity47525 : scanCanonicalize (H12AffineFastState.compose env47525 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47525 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47526 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4112,0,343,4097,2421,273,1,4160,33,17,3,349,64,2048,4096,4097,2421,68,32,257,32,4161,513]

theorem envBound47526 : H12AffineFastState.Bounded env47526 := by
  intro p hp
  have h : env47526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47525_47526 : H12AffineEnvironment.transform 9 272 env47525 = env47526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47525 == env47526) = true)

theorem identity47526 : scanCanonicalize (H12AffineFastState.compose env47526 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound47526 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47527 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,48,349,32,0,343,49,2421,273,1,112,33,17,3,349,64,2048,48,49,2421,68,32,257,32,113,513]

theorem envBound47527 : H12AffineFastState.Bounded env47527 := by
  intro p hp
  have h : env47527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47526_47527 : H12AffineEnvironment.transform 11 48 env47526 = env47527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47526 == env47527) = true)

theorem identity47527 : scanCanonicalize (H12AffineFastState.compose env47527 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47527 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47528 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,48,40,32,0,34,49,2048,100,1,112,33,17,3,40,64,2048,48,49,2048,68,32,116,32,113,513]

theorem envBound47528 : H12AffineFastState.Bounded env47528 := by
  intro p hp
  have h : env47528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47527_47528 : H12AffineEnvironment.transform 7 117 env47527 = env47528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47527 == env47528) = true)

theorem identity47528 : scanCanonicalize (H12AffineFastState.compose env47528 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound47528 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47529 : List Nat := [2,4,8,16,32,64,8,117,512,101,576,48,40,32,0,34,49,576,100,1,112,33,17,3,40,64,576,48,49,576,68,32,116,32,113,513]

theorem envBound47529 : H12AffineFastState.Bounded env47529 := by
  intro p hp
  have h : env47529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47528_47529 : H12AffineEnvironment.transform 10 576 env47528 = env47529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env47528 == env47529) = true)

theorem identity47529 : scanCanonicalize (H12AffineFastState.compose env47529 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound47529 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47530 : List Nat := [2,4,8,16,32,43,8,30,512,14,555,48,40,32,0,34,49,555,15,1,27,33,17,3,40,43,555,48,49,555,47,32,31,32,26,513]

theorem envBound47530 : H12AffineFastState.Bounded env47530 := by
  intro p hp
  have h : env47530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47529_47530 : H12AffineEnvironment.transform 5 43 env47529 = env47530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env47529 == env47530) = true)

theorem identity47530 : scanCanonicalize (H12AffineFastState.compose env47530 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound47530 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env47531 : List Nat := [2,4,8,16,32,43,8,30,42,14,1,48,40,32,0,34,49,1,15,1,27,33,17,3,40,43,1,48,49,1,47,32,31,32,26,43]

theorem envBound47531 : H12AffineFastState.Bounded env47531 := by
  intro p hp
  have h : env47531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47530_47531 : H12AffineEnvironment.transform 8 42 env47530 = env47531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env47530 == env47531) = true)

theorem identity47531 : scanCanonicalize (H12AffineFastState.compose env47531 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47532 : List Nat := [2,4,2,16,32,33,2,20,32,4,1,48,34,32,0,34,49,1,5,1,17,33,17,3,34,33,1,48,49,1,37,32,21,32,16,33]

theorem envBound47532 : H12AffineFastState.Bounded env47532 := by
  intro p hp
  have h : env47532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47531_47532 : H12AffineEnvironment.transform 2 2 env47531 = env47532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47531 == env47532) = true)

theorem identity47532 : scanCanonicalize (H12AffineFastState.compose env47532 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47532 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env47533 : List Nat := [2,4,2,16,0,1,2,20,0,4,1,16,2,0,0,2,17,1,5,1,17,1,17,3,2,1,1,16,17,1,5,0,21,0,16,1]

theorem envBound47533 : H12AffineFastState.Bounded env47533 := by
  intro p hp
  have h : env47533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47532_47533 : H12AffineEnvironment.transform 4 0 env47532 = env47533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47532 == env47533) = true)

theorem identity47533 : scanCanonicalize (H12AffineFastState.compose env47533 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47533 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47534 : List Nat := [2,4,2,0,0,1,2,4,0,4,1,0,2,0,0,2,1,1,5,1,1,1,1,3,2,1,1,0,1,1,5,0,5,0,0,1]

theorem envBound47534 : H12AffineFastState.Bounded env47534 := by
  intro p hp
  have h : env47534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47533_47534 : H12AffineEnvironment.transform 3 0 env47533 = env47534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47533 == env47534) = true)

def env47535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77898,272392,73755,98645,8193,64,100695,79130,17665,335882,75103,392286,257,21792,46093,513]

theorem envBound47535 : H12AffineFastState.Bounded env47535 := by
  intro p hp
  have h : env47535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47519_47535 : H12AffineEnvironment.transform 6 9 env47519 = env47535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47519 == env47535) = true)

theorem identity47535 : scanCanonicalize (H12AffineFastState.compose env47535 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound47535 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env47536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,49169,262144,1025,32769,36928,272392,32785,8543,8193,64,10589,38160,17665,294912,34133,285780,257,21792,46093,513]

theorem envBound47536 : H12AffineFastState.Bounded env47536 := by
  intro p hp
  have h : env47536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47535_47536 : H12AffineEnvironment.transform 15 40970 env47535 = env47536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env47535 == env47536) = true)

theorem identity47536 : scanCanonicalize (H12AffineFastState.compose env47536 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound47536 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env47537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1344,9546,17745,262144,1025,1345,5376,272392,1361,8543,8193,64,10589,4176,17665,263488,21,285780,257,21792,12621,513]

theorem envBound47537 : H12AffineFastState.Bounded env47537 := by
  intro p hp
  have h : env47537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47536_47537 : H12AffineEnvironment.transform 14 1344 env47536 = env47537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env47536 == env47537) = true)

theorem identity47537 : scanCanonicalize (H12AffineFastState.compose env47537 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound47537 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env47538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,1344,9546,4096,262144,1025,1345,5376,272392,1361,8543,8193,64,10589,4176,4176,263488,21,264453,257,113,12621,513]

theorem envBound47538 : H12AffineFastState.Bounded env47538 := by
  intro p hp
  have h : env47538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47537_47538 : H12AffineEnvironment.transform 13 5457 env47537 = env47538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env47537 == env47538) = true)

theorem identity47538 : scanCanonicalize (H12AffineFastState.compose env47538 (packedSelected [17,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound47538 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env47539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,1344,9546,4096,2421,1025,1345,5376,8573,1361,8543,8193,64,10589,4176,4176,3125,21,112,257,113,12621,513]

theorem envBound47539 : H12AffineFastState.Bounded env47539 := by
  intro p hp
  have h : env47539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47538_47539 : H12AffineEnvironment.transform 17 2421 env47538 = env47539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env47538 == env47539) = true)

theorem identity47539 : scanCanonicalize (H12AffineFastState.compose env47539 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound47539 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47540 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,4405,292,8494,4096,2421,101,293,4452,8573,309,8543,8193,64,10589,4176,4176,2129,21,112,257,113,12621,513]

theorem envBound47540 : H12AffineFastState.Bounded env47540 := by
  intro p hp
  have h : env47540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47539_47540 : H12AffineEnvironment.transform 9 100 env47539 = env47540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env47539 == env47540) = true)

theorem identity47540 : scanCanonicalize (H12AffineFastState.compose env47540 (packedSelected [0,4,5,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound47540 : packedSelected [0,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env47541 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2112,8192,2421,292,8494,2112,2421,101,293,2340,8573,309,8543,8193,64,10589,2064,2064,2129,21,112,257,113,10509,513]

theorem envBound47541 : H12AffineFastState.Bounded env47541 := by
  intro p hp
  have h : env47541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47540_47541 : H12AffineEnvironment.transform 11 2112 env47540 = env47541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env47540 == env47541) = true)

theorem identity47541 : scanCanonicalize (H12AffineFastState.compose env47541 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47541 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env47542 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2112,41,2421,292,263,2112,2421,101,293,2340,340,309,374,40,64,2420,2064,2064,2129,21,112,257,113,2340,513]

theorem envBound47542 : H12AffineFastState.Bounded env47542 := by
  intro p hp
  have h : env47542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47541_47542 : H12AffineEnvironment.transform 12 41 env47541 = env47542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47541 == env47542) = true)

theorem identity47542 : scanCanonicalize (H12AffineFastState.compose env47542 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47542 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47543 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,2112,41,2128,1,34,2112,2128,101,0,2049,113,16,83,40,64,2129,2064,2064,2129,21,112,36,113,2049,513]

theorem envBound47543 : H12AffineFastState.Bounded env47543 := by
  intro p hp
  have h : env47543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47542_47543 : H12AffineEnvironment.transform 7 37 env47542 = env47543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47542 == env47543) = true)

theorem identity47543 : scanCanonicalize (H12AffineFastState.compose env47543 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47543 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47544 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2064,41,2048,1,34,2064,2048,53,0,2049,33,16,3,40,16,2049,2064,2064,2049,21,32,36,33,2049,513]

theorem envBound47544 : H12AffineFastState.Bounded env47544 := by
  intro p hp
  have h : env47544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47543_47544 : H12AffineEnvironment.transform 5 16 env47543 = env47544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47543 == env47544) = true)

theorem identity47544 : scanCanonicalize (H12AffineFastState.compose env47544 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound47544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47545 : List Nat := [2,4,8,16,32,16,9,37,512,52,17,1,41,17,1,34,1,17,53,0,16,33,16,3,40,16,16,1,1,16,21,32,36,33,16,513]

theorem envBound47545 : H12AffineFastState.Bounded env47545 := by
  intro p hp
  have h : env47545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47544_47545 : H12AffineEnvironment.transform 10 17 env47544 = env47545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env47544 == env47545) = true)

theorem identity47545 : scanCanonicalize (H12AffineFastState.compose env47545 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound47545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47546 : List Nat := [2,4,8,16,32,16,9,37,27,52,17,1,41,17,1,34,1,17,53,0,16,33,16,3,40,16,16,1,1,16,21,32,36,33,16,26]

theorem envBound47546 : H12AffineFastState.Bounded env47546 := by
  intro p hp
  have h : env47546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47545_47546 : H12AffineEnvironment.transform 8 27 env47545 = env47546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env47545 == env47546) = true)

def env47547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2281537,213453,8328,64,6705548,2278721,165137,2363457,2102685,6431757,257,21793,46213,2175562]

theorem envBound47547 : H12AffineFastState.Bounded env47547 := by
  intro p hp
  have h : env47547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47440_47547 : H12AffineEnvironment.transform 22 2281537 env47440 = env47547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2281537 env47440 == env47547) = true)

def env47548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6590876,2098513,17665,2363457,2102685,6349853,257,21793,46213,2175562]

theorem envBound47548 : H12AffineFastState.Bounded env47548 := by
  intro p hp
  have h : env47548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47547_47548 : H12AffineEnvironment.transform 16 49168 env47547 = env47548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env47547 == env47548) = true)

def env47549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2144540,2098513,17665,2363457,2102685,2411677,257,21793,46213,2175562]

theorem envBound47549 : H12AffineFastState.Bounded env47549 := by
  intro p hp
  have h : env47549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47548_47549 : H12AffineEnvironment.transform 21 272512 env47548 = env47549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env47548 == env47549) = true)

theorem identity47549 : scanCanonicalize (H12AffineFastState.compose env47549 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound47549 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58517,272512,62660,98781,8328,64,23945,57796,17665,324820,61704,272392,257,21793,46213,120543]

theorem envBound47550 : H12AffineFastState.Bounded env47550 := by
  intro p hp
  have h : env47550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47549_47550 : H12AffineEnvironment.transform 20 58517 env47549 = env47550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env47549 == env47550) = true)

def env47551 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58517,272512,62612,98701,8328,16,23945,57748,17665,324740,61704,272392,257,21793,46213,120463]

theorem envBound47551 : H12AffineFastState.Bounded env47551 := by
  intro p hp
  have h : env47551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47550_47551 : H12AffineEnvironment.transform 5 16 env47550 = env47551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47550 == env47551) = true)

theorem identity47551 : scanCanonicalize (H12AffineFastState.compose env47551 (packedSelected [10,15,17,19,26,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47551 : packedSelected [10,15,17,19,26,31,38] rootPS < 2^1333 := by decide +kernel

def env47552 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,58517,168,62612,98701,8328,16,23945,57748,17665,56492,61704,32,257,21793,46213,120463]

theorem envBound47552 : H12AffineFastState.Bounded env47552 := by
  intro p hp
  have h : env47552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47551_47552 : H12AffineEnvironment.transform 17 10280 env47551 = env47552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47551 == env47552) = true)

theorem identity47552 : scanCanonicalize (H12AffineFastState.compose env47552 (packedSelected [1,2,3,5,6,7,9,11,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound47552 : packedSelected [1,2,3,5,6,7,9,11,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env47553 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,40971,49168,10280,1025,32769,58517,168,62612,8582,8328,16,23945,57748,17665,56492,61704,32,257,21793,46213,30340]

theorem envBound47553 : H12AffineFastState.Bounded env47553 := by
  intro p hp
  have h : env47553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47552_47553 : H12AffineEnvironment.transform 15 40971 env47552 = env47553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env47552 == env47553) = true)

theorem identity47553 : scanCanonicalize (H12AffineFastState.compose env47553 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound47553 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env47554 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,32768,40971,46109,10280,1025,32769,37016,168,32921,8582,8328,16,10628,38297,12556,43169,34053,32,257,8492,46213,649]

theorem envBound47554 : H12AffineFastState.Bounded env47554 := by
  intro p hp
  have h : env47554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47553_47554 : H12AffineEnvironment.transform 13 13325 env47553 = env47554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env47553 == env47554) = true)

theorem identity47554 : scanCanonicalize (H12AffineFastState.compose env47554 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound47554 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47555 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,0,8203,13341,10280,1025,1,4248,168,153,8582,8328,16,10628,5529,12556,10401,1285,32,257,8492,13445,649]

theorem envBound47555 : H12AffineFastState.Bounded env47555 := by
  intro p hp
  have h : env47555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47554_47555 : H12AffineEnvironment.transform 14 0 env47554 = env47555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env47554 == env47555) = true)

theorem identity47555 : scanCanonicalize (H12AffineFastState.compose env47555 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47555 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47556 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,8203,13341,10280,1025,1,4112,32,17,8462,8192,16,10508,5393,12556,10281,1285,32,257,8492,13325,513]

theorem envBound47556 : H12AffineFastState.Bounded env47556 := by
  intro p hp
  have h : env47556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47555_47556 : H12AffineEnvironment.transform 6 8 env47555 = env47556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47555 == env47556) = true)

theorem identity47556 : scanCanonicalize (H12AffineFastState.compose env47556 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3889) := by decide +kernel

theorem selectedBound47556 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env47557 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,8192,11068,0,8203,11052,10280,1025,1,3873,32,17,8462,8192,16,10508,2592,11837,10281,1285,32,257,8492,11068,513]

theorem envBound47557 : H12AffineFastState.Bounded env47557 := by
  intro p hp
  have h : env47557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47556_47557 : H12AffineEnvironment.transform 11 3889 env47556 = env47557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env47556 == env47557) = true)

theorem identity47557 : scanCanonicalize (H12AffineFastState.compose env47557 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47557 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47558 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,269,2609,0,262,2593,2341,1025,1,3873,32,17,3,269,16,2049,2592,3888,2340,1285,32,257,33,2609,513]

theorem envBound47558 : H12AffineFastState.Bounded env47558 := by
  intro p hp
  have h : env47558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47557_47558 : H12AffineEnvironment.transform 12 269 env47557 = env47558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47557 == env47558) = true)

theorem identity47558 : scanCanonicalize (H12AffineFastState.compose env47558 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound47558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47559 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1588,261,269,1029,0,262,1045,1809,1025,1,277,32,17,3,269,16,1589,1044,260,1808,1285,32,257,33,1029,513]

theorem envBound47559 : H12AffineFastState.Bounded env47559 := by
  intro p hp
  have h : env47559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47558_47559 : H12AffineEnvironment.transform 10 1588 env47558 = env47559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env47558 == env47559) = true)

theorem identity47559 : scanCanonicalize (H12AffineFastState.compose env47559 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound47559 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47560 : List Nat := [2,4,8,16,32,16,8,256,512,784,292,261,269,789,0,262,773,1,785,1,277,32,17,3,269,16,293,772,260,0,533,32,257,33,789,513]

theorem envBound47560 : H12AffineFastState.Bounded env47560 := by
  intro p hp
  have h : env47560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47559_47560 : H12AffineEnvironment.transform 9 784 env47559 = env47560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env47559 == env47560) = true)

theorem identity47560 : scanCanonicalize (H12AffineFastState.compose env47560 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47560 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47561 : List Nat := [2,4,8,0,32,0,8,256,512,768,292,261,269,773,0,262,773,1,769,1,261,32,1,3,269,0,293,772,260,0,517,32,257,33,773,513]

theorem envBound47561 : H12AffineFastState.Bounded env47561 := by
  intro p hp
  have h : env47561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47560_47561 : H12AffineEnvironment.transform 3 0 env47560 = env47561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47560 == env47561) = true)

theorem identity47561 : scanCanonicalize (H12AffineFastState.compose env47561 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound47561 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47562 : List Nat := [2,4,8,0,32,0,8,256,261,5,292,261,269,0,0,262,0,1,4,1,261,32,1,3,269,0,293,1,260,0,256,32,257,33,0,260]

theorem envBound47562 : H12AffineFastState.Bounded env47562 := by
  intro p hp
  have h : env47562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47561_47562 : H12AffineEnvironment.transform 8 261 env47561 = env47562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env47561 == env47562) = true)

def env47563 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58517,272512,62613,98700,8328,17,23945,57749,17665,324741,61704,272392,257,21793,46213,120462]

theorem envBound47563 : H12AffineFastState.Bounded env47563 := by
  intro p hp
  have h : env47563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47550_47563 : H12AffineEnvironment.transform 5 17 env47550 = env47563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47550 == env47563) = true)

def env47564 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272392,62493,98564,8192,17,23809,57629,17665,324621,61704,272392,257,21793,46093,120326]

theorem envBound47564 : H12AffineFastState.Bounded env47564 := by
  intro p hp
  have h : env47564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47563_47564 : H12AffineEnvironment.transform 6 8 env47563 = env47564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47563 == env47564) = true)

theorem identity47564 : scanCanonicalize (H12AffineFastState.compose env47564 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound47564 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env47565 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,32040,1025,32769,58397,21792,62493,98564,8192,17,23809,57629,17665,35109,61704,21792,257,21793,46093,120326]

theorem envBound47565 : H12AffineFastState.Bounded env47565 := by
  intro p hp
  have h : env47565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47564_47565 : H12AffineEnvironment.transform 17 32040 env47564 = env47565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env47564 == env47565) = true)

theorem identity47565 : scanCanonicalize (H12AffineFastState.compose env47565 (packedSelected [0,4,7,17,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound47565 : packedSelected [0,4,7,17,19,22,26] rootPS < 2^1333 := by decide +kernel

def env47566 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,62731,49168,32040,1025,32769,58397,21792,62493,29711,8192,17,23809,57629,17665,35109,61704,21792,257,21793,46093,8973]

theorem envBound47566 : H12AffineFastState.Bounded env47566 := by
  intro p hp
  have h : env47566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47565_47566 : H12AffineEnvironment.transform 15 62731 env47565 = env47566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env47565 == env47566) = true)

theorem identity47566 : scanCanonicalize (H12AffineFastState.compose env47566 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound47566 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env47567 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,32768,33031,46108,2340,1025,32769,36881,8492,32785,3,8192,17,10509,38161,12557,35109,34052,8492,257,8493,46093,8973]

theorem envBound47567 : H12AffineFastState.Bounded env47567 := by
  intro p hp
  have h : env47567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47566_47567 : H12AffineEnvironment.transform 13 13324 env47566 = env47567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env47566 == env47567) = true)

theorem identity47567 : scanCanonicalize (H12AffineFastState.compose env47567 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47567 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env47568 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,32768,33031,38160,2340,1025,32769,36881,32,32785,3,268,17,2049,38161,4097,35109,34052,32,257,33,38145,513]

theorem envBound47568 : H12AffineFastState.Bounded env47568 := by
  intro p hp
  have h : env47568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47567_47568 : H12AffineEnvironment.transform 12 268 env47567 = env47568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47567 == env47568) = true)

theorem identity47568 : scanCanonicalize (H12AffineFastState.compose env47568 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47568 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47569 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,262,5393,2340,1025,0,4112,32,16,3,268,17,2049,5392,4097,2340,1285,32,257,33,5376,513]

theorem envBound47569 : H12AffineFastState.Bounded env47569 := by
  intro p hp
  have h : env47569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47568_47569 : H12AffineEnvironment.transform 14 1 env47568 = env47569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47568 == env47569) = true)

theorem identity47569 : scanCanonicalize (H12AffineFastState.compose env47569 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound47569 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47570 : List Nat := [2,4,8,16,32,17,8,52,512,1024,2048,4096,56,5172,1,50,5157,2064,1025,0,4112,32,16,3,56,17,2049,5156,4097,2064,1073,32,53,33,5172,513]

theorem envBound47570 : H12AffineFastState.Bounded env47570 := by
  intro p hp
  have h : env47570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47569_47570 : H12AffineEnvironment.transform 7 52 env47569 = env47570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env47569 == env47570) = true)

theorem identity47570 : scanCanonicalize (H12AffineFastState.compose env47570 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound47570 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47571 : List Nat := [2,4,8,16,32,17,8,52,512,1024,2048,1572,56,528,1,50,513,2064,1025,0,1588,32,16,3,56,17,2049,512,1573,2064,1073,32,53,33,528,513]

theorem envBound47571 : H12AffineFastState.Bounded env47571 := by
  intro p hp
  have h : env47571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47570_47571 : H12AffineEnvironment.transform 11 1572 env47570 = env47571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env47570 == env47571) = true)

theorem identity47571 : scanCanonicalize (H12AffineFastState.compose env47571 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound47571 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47572 : List Nat := [2,4,8,16,32,17,8,52,512,1024,1589,1572,56,528,1,50,513,1573,1025,0,1588,32,16,3,56,17,1588,512,1573,1573,1073,32,53,33,528,513]

theorem envBound47572 : H12AffineFastState.Bounded env47572 := by
  intro p hp
  have h : env47572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47571_47572 : H12AffineEnvironment.transform 10 1589 env47571 = env47572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env47571 == env47572) = true)

theorem identity47572 : scanCanonicalize (H12AffineFastState.compose env47572 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47572 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47573 : List Nat := [2,4,8,16,32,17,8,52,512,52,513,528,56,528,1,50,513,529,53,0,512,32,16,3,56,17,512,512,529,529,5,32,53,33,528,513]

theorem envBound47573 : H12AffineFastState.Bounded env47573 := by
  intro p hp
  have h : env47573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47572_47573 : H12AffineEnvironment.transform 9 52 env47572 = env47573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47572 == env47573) = true)

theorem identity47573 : scanCanonicalize (H12AffineFastState.compose env47573 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47573 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env47574 : List Nat := [2,4,8,0,32,1,8,36,512,36,513,512,40,512,1,34,513,513,37,0,512,32,0,3,40,1,512,512,513,513,5,32,37,33,512,513]

theorem envBound47574 : H12AffineFastState.Bounded env47574 := by
  intro p hp
  have h : env47574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47573_47574 : H12AffineEnvironment.transform 3 0 env47573 = env47574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47573 == env47574) = true)

theorem identity47574 : scanCanonicalize (H12AffineFastState.compose env47574 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47574 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47575 : List Nat := [2,4,8,0,0,1,8,4,512,4,513,512,8,512,1,2,513,513,5,0,512,0,0,3,8,1,512,512,513,513,5,0,5,1,512,513]

theorem envBound47575 : H12AffineFastState.Bounded env47575 := by
  intro p hp
  have h : env47575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47574_47575 : H12AffineEnvironment.transform 4 0 env47574 = env47575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47574 == env47575) = true)

def env47576 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272393,62492,98565,8193,17,23808,57628,17665,324620,61704,272392,257,21793,46092,120327]

theorem envBound47576 : H12AffineFastState.Bounded env47576 := by
  intro p hp
  have h : env47576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47563_47576 : H12AffineEnvironment.transform 6 9 env47563 = env47576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47563 == env47576) = true)

theorem identity47576 : scanCanonicalize (H12AffineFastState.compose env47576 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound47576 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env47577 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,97326,1025,32769,58396,87079,62492,98565,8193,17,23808,57628,17665,100386,61704,87078,257,21793,46092,120327]

theorem envBound47577 : H12AffineFastState.Bounded env47577 := by
  intro p hp
  have h : env47577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47576_47577 : H12AffineEnvironment.transform 17 97326 env47576 = env47577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env47576 == env47577) = true)

theorem identity47577 : scanCanonicalize (H12AffineFastState.compose env47577 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47577 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env47578 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,32768,65536,49168,89379,1025,32769,50449,87079,54545,98565,268,17,23808,49169,17665,100386,53253,87078,257,21793,38145,120327]

theorem envBound47578 : H12AffineFastState.Bounded env47578 := by
  intro p hp
  have h : env47578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47577_47578 : H12AffineEnvironment.transform 12 269 env47577 = env47578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47577 == env47578) = true)

theorem identity47578 : scanCanonicalize (H12AffineFastState.compose env47578 (packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound47578 : packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env47579 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21541,65536,5173,89379,1025,21540,4404,87079,308,87328,268,17,23808,5172,17665,89095,1056,87078,257,21793,16676,66082]

theorem envBound47579 : H12AffineFastState.Bounded env47579 := by
  intro p hp
  have h : env47579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47578_47579 : H12AffineEnvironment.transform 14 21541 env47578 = env47579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env47578 == env47579) = true)

theorem identity47579 : scanCanonicalize (H12AffineFastState.compose env47579 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound47579 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env47580 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21541,21510,5173,2341,1025,21540,4404,33,308,294,268,17,23808,5172,17665,2049,1056,32,257,21793,16676,22052]

theorem envBound47580 : H12AffineFastState.Bounded env47580 := by
  intro p hp
  have h : env47580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47579_47580 : H12AffineEnvironment.transform 15 21510 env47579 = env47580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env47579 == env47580) = true)

theorem identity47580 : scanCanonicalize (H12AffineFastState.compose env47580 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47580 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47581 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,293,262,5173,2341,1025,292,4404,33,308,294,268,17,2048,5172,4097,2049,1056,32,257,33,5156,804]

theorem envBound47581 : H12AffineFastState.Bounded env47581 := by
  intro p hp
  have h : env47581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47580_47581 : H12AffineEnvironment.transform 13 5376 env47580 = env47581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47580 == env47581) = true)

theorem identity47581 : scanCanonicalize (H12AffineFastState.compose env47581 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound47581 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47582 : List Nat := [2,4,8,16,32,17,9,256,512,1024,788,4096,269,5376,293,262,5173,561,1025,292,4404,33,308,294,268,17,788,5172,4097,789,1056,32,257,33,5156,804]

theorem envBound47582 : H12AffineFastState.Bounded env47582 := by
  intro p hp
  have h : env47582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47581_47582 : H12AffineEnvironment.transform 10 788 env47581 = env47582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env47581 == env47582) = true)

theorem identity47582 : scanCanonicalize (H12AffineFastState.compose env47582 (packedSelected [3,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound47582 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env47583 : List Nat := [2,4,8,16,32,17,9,256,512,36,788,4096,269,4388,293,262,4113,561,37,292,4404,33,308,294,268,17,788,4112,4097,789,4,32,257,33,4096,804]

theorem envBound47583 : H12AffineFastState.Bounded env47583 := by
  intro p hp
  have h : env47583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47582_47583 : H12AffineEnvironment.transform 9 36 env47582 = env47583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env47582 == env47583) = true)

theorem identity47583 : scanCanonicalize (H12AffineFastState.compose env47583 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47583 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47584 : List Nat := [2,4,8,16,32,17,9,5,512,36,529,4096,8,4129,32,3,4113,561,37,33,4145,33,49,35,9,17,529,4112,4097,528,4,32,4,33,4096,545]

theorem envBound47584 : H12AffineFastState.Bounded env47584 := by
  intro p hp
  have h : env47584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47583_47584 : H12AffineEnvironment.transform 7 5 env47583 = env47584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47583 == env47584) = true)

theorem identity47584 : scanCanonicalize (H12AffineFastState.compose env47584 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47584 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47585 : List Nat := [2,4,8,16,0,17,9,5,512,4,529,4096,8,4097,0,3,4113,529,5,1,4113,1,17,3,9,17,529,4112,4097,528,4,0,4,1,4096,513]

theorem envBound47585 : H12AffineFastState.Bounded env47585 := by
  intro p hp
  have h : env47585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47584_47585 : H12AffineEnvironment.transform 4 0 env47584 = env47585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47584 == env47585) = true)

theorem identity47585 : scanCanonicalize (H12AffineFastState.compose env47585 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound47585 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47586 : List Nat := [2,4,8,16,0,17,9,5,512,4,529,0,8,1,0,3,17,529,5,1,17,1,17,3,9,17,529,16,1,528,4,0,4,1,0,513]

theorem envBound47586 : H12AffineFastState.Bounded env47586 := by
  intro p hp
  have h : env47586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47585_47586 : H12AffineEnvironment.transform 11 0 env47585 = env47586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env47585 == env47586) = true)

theorem identity47586 : scanCanonicalize (H12AffineFastState.compose env47586 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound47586 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47587 : List Nat := [2,4,8,16,0,17,9,5,17,4,0,0,8,1,0,3,17,0,5,1,17,1,17,3,9,17,0,16,1,1,4,0,4,1,0,16]

theorem envBound47587 : H12AffineFastState.Bounded env47587 := by
  intro p hp
  have h : env47587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47586_47587 : H12AffineEnvironment.transform 8 17 env47586 = env47587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env47586 == env47587) = true)

def env47588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2144541,2098513,17665,2363457,2102685,2411676,257,21793,46213,2175562]

theorem envBound47588 : H12AffineFastState.Bounded env47588 := by
  intro p hp
  have h : env47588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47548_47588 : H12AffineEnvironment.transform 21 272513 env47548 = env47588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env47548 == env47588) = true)

theorem identity47588 : scanCanonicalize (H12AffineFastState.compose env47588 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound47588 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,262144,1025,29908,2097152,272513,2101329,95496,8328,64,2117064,2098513,17665,2363457,2102685,2373705,257,21793,16464,2175562]

theorem envBound47589 : H12AffineFastState.Bounded env47589 := by
  intro p hp
  have h : env47589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47588_47589 : H12AffineEnvironment.transform 14 29909 env47588 = env47589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env47588 == env47589) = true)

def env47590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,262144,1025,29788,2097152,272393,2101329,95496,8192,64,2116928,2098513,17665,2363457,2102549,2373705,257,21793,16464,2175562]

theorem envBound47590 : H12AffineFastState.Bounded env47590 := by
  intro p hp
  have h : env47590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47589_47590 : H12AffineEnvironment.transform 6 8 env47589 = env47590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47589 == env47590) = true)

theorem identity47590 : scanCanonicalize (H12AffineFastState.compose env47590 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound47590 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env47591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,2420,1025,29788,2097152,8573,2101329,95496,8192,64,2116928,2098513,17665,2103605,2102549,2109757,257,21793,16464,2175562]

theorem envBound47591 : H12AffineFastState.Bounded env47591 := by
  intro p hp
  have h : env47591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47590_47591 : H12AffineEnvironment.transform 17 2420 env47590 = env47591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env47590 == env47591) = true)

theorem identity47591 : scanCanonicalize (H12AffineFastState.compose env47591 (packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound47591 : packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,2420,1025,29788,12572,8573,8525,95496,8192,64,31836,13389,17665,10281,9225,33,257,21793,16464,66390]

theorem envBound47592 : H12AffineFastState.Bounded env47592 := by
  intro p hp
  have h : env47592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47591_47592 : H12AffineEnvironment.transform 20 12572 env47591 = env47592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env47591 == env47592) = true)

theorem identity47592 : scanCanonicalize (H12AffineFastState.compose env47592 (packedSelected [3,4,8,9,12,14,15,16,18,19,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound47592 : packedSelected [3,4,8,9,12,14,15,16,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env47593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,65536,13389,2420,1025,8460,12572,8573,8525,73816,8192,64,10508,13389,4177,10281,9225,33,257,113,5376,66390]

theorem envBound47593 : H12AffineFastState.Bounded env47593 := by
  intro p hp
  have h : env47593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47592_47593 : H12AffineEnvironment.transform 13 5456 env47592 = env47593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env47592 == env47593) = true)

theorem identity47593 : scanCanonicalize (H12AffineFastState.compose env47593 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound47593 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env47594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8282,13389,2420,1025,8460,12572,8573,8525,2,8192,64,10508,13389,4177,10281,9225,33,257,113,5376,8972]

theorem envBound47594 : H12AffineFastState.Bounded env47594 := by
  intro p hp
  have h : env47594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47593_47594 : H12AffineEnvironment.transform 15 8282 env47593 = env47594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env47593 == env47594) = true)

theorem identity47594 : scanCanonicalize (H12AffineFastState.compose env47594 (packedSelected [0,1,4,7,8,9,10,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47594 : packedSelected [0,1,4,7,8,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env47595 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5237,8232,8282,13389,2129,1025,8233,12345,8280,8296,2,8192,64,10281,13389,4177,10281,9225,33,36,113,5157,8745]

theorem envBound47595 : H12AffineFastState.Bounded env47595 := by
  intro p hp
  have h : env47595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47594_47595 : H12AffineEnvironment.transform 7 37 env47594 = env47595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47594 == env47595) = true)

theorem identity47595 : scanCanonicalize (H12AffineFastState.compose env47595 (packedSelected [2,3,4,5,6,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound47595 : packedSelected [2,3,4,5,6,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47596 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,1053,5237,1077,1095,4176,2129,1025,1076,5156,1093,1141,2,1053,64,3124,4176,4177,3124,20,33,36,113,5157,1588]

theorem envBound47596 : H12AffineFastState.Bounded env47596 := by
  intro p hp
  have h : env47596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47595_47596 : H12AffineEnvironment.transform 12 1053 env47595 = env47596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env47595 == env47596) = true)

theorem identity47596 : scanCanonicalize (H12AffineFastState.compose env47596 (packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47596 : packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS < 2^1333 := by decide +kernel

def env47597 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,1053,5156,1077,1046,4097,2048,1025,1076,5156,1044,1060,2,1053,17,3124,4097,4096,3124,20,33,36,32,5157,1588]

theorem envBound47597 : H12AffineFastState.Bounded env47597 := by
  intro p hp
  have h : env47597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47596_47597 : H12AffineEnvironment.transform 5 17 env47596 = env47597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47596 == env47597) = true)

theorem identity47597 : scanCanonicalize (H12AffineFastState.compose env47597 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound47597 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47598 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2065,1053,3125,1077,1046,2064,2048,1025,1076,3125,1044,1060,2,1053,17,3124,2064,2065,3124,20,33,36,32,3124,1588]

theorem envBound47598 : H12AffineFastState.Bounded env47598 := by
  intro p hp
  have h : env47598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47597_47598 : H12AffineEnvironment.transform 11 2065 env47597 = env47598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env47597 == env47598) = true)

theorem identity47598 : scanCanonicalize (H12AffineFastState.compose env47598 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47598 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env47599 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,2065,41,2049,1,34,2064,2048,53,0,2049,32,16,2,41,17,2048,2064,2065,2048,20,33,36,32,2048,512]

theorem envBound47599 : H12AffineFastState.Bounded env47599 := by
  intro p hp
  have h : env47599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47598_47599 : H12AffineEnvironment.transform 9 52 env47598 = env47599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47598 == env47599) = true)

theorem identity47599 : scanCanonicalize (H12AffineFastState.compose env47599 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47600 : List Nat := [2,4,8,16,0,17,8,5,512,20,2048,2065,9,2049,1,2,2064,2048,21,0,2049,0,16,2,9,17,2048,2064,2065,2048,20,1,4,0,2048,512]

theorem envBound47600 : H12AffineFastState.Bounded env47600 := by
  intro p hp
  have h : env47600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47599_47600 : H12AffineEnvironment.transform 4 0 env47599 = env47600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47599 == env47600) = true)

theorem identity47600 : scanCanonicalize (H12AffineFastState.compose env47600 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound47600 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47601 : List Nat := [2,4,8,16,0,17,8,5,512,20,5,20,9,4,1,2,21,5,21,0,4,0,16,2,9,17,5,21,20,5,20,1,4,0,5,512]

theorem envBound47601 : H12AffineFastState.Bounded env47601 := by
  intro p hp
  have h : env47601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47600_47601 : H12AffineEnvironment.transform 10 5 env47600 = env47601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env47600 == env47601) = true)

def env47602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,262144,1025,29789,2097152,272392,2101329,95496,8193,64,2116929,2098513,17665,2363457,2102548,2373705,257,21793,16464,2175562]

theorem envBound47602 : H12AffineFastState.Bounded env47602 := by
  intro p hp
  have h : env47602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47589_47602 : H12AffineEnvironment.transform 6 9 env47589 = env47602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47589 == env47602) = true)

theorem identity47602 : scanCanonicalize (H12AffineFastState.compose env47602 (packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS)) = affineNative (2^(20+1) ^^^ 347159) := by decide +kernel

theorem selectedBound47602 : packedSelected [1,3,7,8,10,12,14,16,17,24,27,38] rootPS < 2^1333 := by decide +kernel

def env47603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,262144,1025,29789,347159,272392,351302,95496,8193,64,328022,346438,17665,89174,350467,95326,257,21793,16464,294493]

theorem envBound47603 : H12AffineFastState.Bounded env47603 := by
  intro p hp
  have h : env47603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47602_47603 : H12AffineEnvironment.transform 20 347159 env47602 = env47603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 347159 env47602 == env47603) = true)

theorem identity47603 : scanCanonicalize (H12AffineFastState.compose env47603 (packedSelected [0,2,4,5,6,8,9,11,16,17,18,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound47603 : packedSelected [0,2,4,5,6,8,9,11,16,17,18,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47604 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,13388,262144,1025,29789,276764,272392,272717,3,8193,64,291933,277581,17665,10589,273416,341,257,21793,16464,294493]

theorem envBound47604 : H12AffineFastState.Bounded env47604 := by
  intro p hp
  have h : env47604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47603_47604 : H12AffineEnvironment.transform 15 29963 env47603 = env47604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env47603 == env47604) = true)

theorem identity47604 : scanCanonicalize (H12AffineFastState.compose env47604 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound47604 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env47605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8232,8575,13388,262144,1025,8233,276764,272392,272717,3,8193,64,270377,277581,4469,10589,273416,341,257,341,5156,272937]

theorem envBound47605 : H12AffineFastState.Bounded env47605 := by
  intro p hp
  have h : env47605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47604_47605 : H12AffineEnvironment.transform 13 5236 env47604 = env47605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env47604 == env47605) = true)

theorem identity47605 : scanCanonicalize (H12AffineFastState.compose env47605 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 4453) := by decide +kernel

theorem selectedBound47605 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env47606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8232,8575,13388,4453,1025,8233,10361,14701,14376,3,8193,64,12620,11560,4469,10589,15725,341,257,341,5156,15180]

theorem envBound47606 : H12AffineFastState.Bounded env47606 := by
  intro p hp
  have h : env47606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47605_47606 : H12AffineEnvironment.transform 17 4453 env47605 = env47606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4453 env47605 == env47606) = true)

theorem identity47606 : scanCanonicalize (H12AffineFastState.compose env47606 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound47606 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15,17] rootPS < 2^1333 := by decide +kernel

def env47607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,5236,5157,5490,65,4453,1025,5156,7284,3424,3109,3,5132,64,1345,6437,4469,7504,2400,341,257,341,5156,3905]

theorem envBound47607 : H12AffineFastState.Bounded env47607 := by
  intro p hp
  have h : env47607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47606_47607 : H12AffineEnvironment.transform 12 5133 env47606 = env47607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env47606 == env47607) = true)

theorem identity47607 : scanCanonicalize (H12AffineFastState.compose env47607 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound47607 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env47608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,309,1336,1345,1296,1095,65,80,1025,1297,3393,3424,3109,3,1337,64,1345,2064,64,3173,2400,341,257,341,1297,3905]

theorem envBound47608 : H12AffineFastState.Bounded env47608 := by
  intro p hp
  have h : env47608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0