import H12CloudChart0Data106

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound27104 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env27105 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,41,4161,0,34,4176,2129,53,1,4161,112,17,2,41,64,2049,4177,4097,2129,20,113,116,33,4113,513]

theorem envBound27105 : H12AffineFastState.Bounded env27105 := by
  intro p hp
  have h : env27105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27104_27105 : H12AffineEnvironment.transform 9 52 env27104 = env27105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27104 == env27105) = true)

theorem identity27105 : scanCanonicalize (H12AffineFastState.compose env27105 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound27105 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27106 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,96,41,33,0,34,48,2129,53,1,33,112,17,2,41,64,2049,49,97,2129,20,113,116,33,113,513]

theorem envBound27106 : H12AffineFastState.Bounded env27106 := by
  intro p hp
  have h : env27106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27105_27106 : H12AffineEnvironment.transform 11 96 env27105 = env27106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env27105 == env27106) = true)

theorem identity27106 : scanCanonicalize (H12AffineFastState.compose env27106 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound27106 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27107 : List Nat := [2,4,8,16,32,49,8,4,512,52,2048,17,41,33,0,34,48,2080,53,1,33,1,17,2,41,49,2049,49,16,2080,20,0,5,33,0,513]

theorem envBound27107 : H12AffineFastState.Bounded env27107 := by
  intro p hp
  have h : env27107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27106_27107 : H12AffineEnvironment.transform 5 49 env27106 = env27107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env27106 == env27107) = true)

theorem identity27107 : scanCanonicalize (H12AffineFastState.compose env27107 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound27107 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27108 : List Nat := [2,4,8,16,32,49,8,4,33,52,2048,17,41,33,0,34,48,2080,53,1,33,1,17,2,41,49,2049,49,16,2080,20,0,5,33,0,32]

theorem envBound27108 : H12AffineFastState.Bounded env27108 := by
  intro p hp
  have h : env27108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27107_27108 : H12AffineEnvironment.transform 8 33 env27107 = env27108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env27107 == env27108) = true)

theorem identity27108 : scanCanonicalize (H12AffineFastState.compose env27108 (packedSelected [0,1,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound27108 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env27109 : List Nat := [2,4,8,16,32,49,8,4,33,52,16,17,41,33,0,34,48,48,53,1,33,1,17,2,41,49,17,49,16,48,20,0,5,33,0,32]

theorem envBound27109 : H12AffineFastState.Bounded env27109 := by
  intro p hp
  have h : env27109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27108_27109 : H12AffineEnvironment.transform 10 16 env27108 = env27109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env27108 == env27109) = true)

def env27110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77898,272393,119879,95497,8193,64,23809,115014,45404,262145,75103,329730,257,21793,46093,513]

theorem envBound27110 : H12AffineFastState.Bounded env27110 := by
  intro p hp
  have h : env27110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27097_27110 : H12AffineEnvironment.transform 6 9 env27097 = env27110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27097 == env27110) = true)

def env27111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10280,1025,32769,77898,33,119879,95497,8193,64,23809,115014,45404,10281,75103,73770,257,21793,46093,513]

theorem envBound27111 : H12AffineFastState.Bounded env27111 := by
  intro p hp
  have h : env27111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27110_27111 : H12AffineEnvironment.transform 17 10280 env27110 = env27111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env27110 == env27111) = true)

theorem identity27111 : scanCanonicalize (H12AffineFastState.compose env27111 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27111 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env27112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,70726,10280,1025,8541,77898,33,95515,95497,8193,64,23809,90138,4096,10281,75103,73770,257,21793,5457,513]

theorem envBound27112 : H12AffineFastState.Bounded env27112 := by
  intro p hp
  have h : env27112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27111_27112 : H12AffineEnvironment.transform 14 8540 env27111 = env27112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27111 == env27112) = true)

theorem identity27112 : scanCanonicalize (H12AffineFastState.compose env27112 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound27112 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21590,16400,10280,1025,8541,25628,33,8525,8543,8193,64,23809,13388,4096,10281,28937,29820,257,21793,5457,513]

theorem envBound27113 : H12AffineFastState.Bounded env27113 := by
  intro p hp
  have h : env27113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27112_27113 : H12AffineEnvironment.transform 15 21590 env27112 = env27113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env27112 == env27113) = true)

theorem identity27113 : scanCanonicalize (H12AffineFastState.compose env27113 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27113 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27114 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,21590,16400,2420,1025,1,17728,33,17,3,349,64,23809,5392,4096,2421,20565,21792,257,21793,5457,513]

theorem envBound27114 : H12AffineFastState.Bounded env27114 := by
  intro p hp
  have h : env27114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27113_27114 : H12AffineEnvironment.transform 12 348 env27113 = env27114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27113 == env27114) = true)

theorem identity27114 : scanCanonicalize (H12AffineFastState.compose env27114 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27114 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env27115 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5392,2420,1025,1,4160,33,17,3,349,64,2049,5392,4096,2421,1365,32,257,33,5457,513]

theorem envBound27115 : H12AffineFastState.Bounded env27115 := by
  intro p hp
  have h : env27115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27114_27115 : H12AffineEnvironment.transform 13 5376 env27114 = env27115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27114 == env27115) = true)

theorem identity27115 : scanCanonicalize (H12AffineFastState.compose env27115 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound27115 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27116 : List Nat := [2,4,8,16,32,64,9,256,512,564,2048,4096,348,4916,0,342,4900,2420,565,1,4160,33,17,3,349,64,2049,4900,4096,2421,865,32,257,33,4965,513]

theorem envBound27116 : H12AffineFastState.Bounded env27116 := by
  intro p hp
  have h : env27116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27115_27116 : H12AffineEnvironment.transform 9 564 env27115 = env27116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env27115 == env27116) = true)

theorem identity27116 : scanCanonicalize (H12AffineFastState.compose env27116 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27116 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27117 : List Nat := [2,4,8,16,32,16,9,256,512,564,2048,4096,268,4916,0,262,4900,2340,565,1,4112,33,17,3,269,16,2049,4900,4096,2341,817,32,257,33,4917,513]

theorem envBound27117 : H12AffineFastState.Bounded env27117 := by
  intro p hp
  have h : env27117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27116_27117 : H12AffineEnvironment.transform 5 16 env27116 = env27117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27116 == env27117) = true)

theorem identity27117 : scanCanonicalize (H12AffineFastState.compose env27117 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound27117 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27118 : List Nat := [2,4,8,16,32,16,9,256,512,564,2048,513,268,309,0,262,293,2340,565,1,529,33,17,3,269,16,2049,293,513,2341,817,32,257,33,308,513]

theorem envBound27118 : H12AffineFastState.Bounded env27118 := by
  intro p hp
  have h : env27118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27117_27118 : H12AffineEnvironment.transform 11 513 env27117 = env27118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env27117 == env27118) = true)

theorem identity27118 : scanCanonicalize (H12AffineFastState.compose env27118 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound27118 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27119 : List Nat := [2,4,8,16,32,16,9,256,512,564,820,513,268,309,0,262,293,528,565,1,529,33,17,3,269,16,821,293,513,529,817,32,257,33,308,513]

theorem envBound27119 : H12AffineFastState.Bounded env27119 := by
  intro p hp
  have h : env27119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27118_27119 : H12AffineEnvironment.transform 10 820 env27118 = env27119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env27118 == env27119) = true)

theorem identity27119 : scanCanonicalize (H12AffineFastState.compose env27119 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound27119 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27120 : List Nat := [2,4,8,16,32,16,9,256,292,272,16,293,268,309,0,262,293,308,273,1,309,33,17,3,269,16,17,293,293,309,21,32,257,33,308,293]

theorem envBound27120 : H12AffineFastState.Bounded env27120 := by
  intro p hp
  have h : env27120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27119_27120 : H12AffineEnvironment.transform 8 292 env27119 = env27120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env27119 == env27120) = true)

theorem identity27120 : scanCanonicalize (H12AffineFastState.compose env27120 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27120 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27121 : List Nat := [2,4,8,16,16,16,9,256,276,272,16,277,268,261,0,262,277,260,273,1,261,17,17,3,269,16,17,277,277,261,21,16,257,17,260,277]

theorem envBound27121 : H12AffineFastState.Bounded env27121 := by
  intro p hp
  have h : env27121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27120_27121 : H12AffineEnvironment.transform 4 16 env27120 = env27121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27120 == env27121) = true)

theorem identity27121 : scanCanonicalize (H12AffineFastState.compose env27121 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27121 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27122 : List Nat := [2,4,8,16,16,16,9,20,0,4,16,1,24,17,0,18,1,16,5,1,17,17,17,3,25,16,17,1,1,17,21,16,21,17,16,1]

theorem envBound27122 : H12AffineFastState.Bounded env27122 := by
  intro p hp
  have h : env27122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27121_27122 : H12AffineEnvironment.transform 7 20 env27121 = env27122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27121 == env27122) = true)

def env27123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10281,1025,32769,77898,32,119879,95497,8193,64,23809,115014,45404,10280,75103,73771,257,21793,46093,513]

theorem envBound27123 : H12AffineFastState.Bounded env27123 := by
  intro p hp
  have h : env27123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27110_27123 : H12AffineEnvironment.transform 17 10281 env27110 = env27123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env27110 == env27123) = true)

theorem identity27123 : scanCanonicalize (H12AffineFastState.compose env27123 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound27123 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,10281,1025,32769,58397,32,16,41310,8193,64,23809,5393,45404,10280,61704,62588,257,21793,46093,513]

theorem envBound27124 : H12AffineFastState.Bounded env27124 := by
  intro p hp
  have h : env27124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27123_27124 : H12AffineEnvironment.transform 15 54359 env27123 = env27124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env27123 == env27124) = true)

theorem identity27124 : scanCanonicalize (H12AffineFastState.compose env27124 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 15372) := by decide +kernel

theorem selectedBound27124 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,15372,32768,43099,48157,10281,1025,32769,38929,32,16,41310,8193,64,8461,5393,45404,10280,36100,34928,257,10541,46093,513]

theorem envBound27125 : H12AffineFastState.Bounded env27125 := by
  intro p hp
  have h : env27125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27124_27125 : H12AffineEnvironment.transform 13 15372 env27124 = env27125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15372 env27124 == env27125) = true)

theorem identity27125 : scanCanonicalize (H12AffineFastState.compose env27125 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound27125 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,8192,13404,32768,40971,46157,8313,1025,32769,36929,32,16,41310,8193,64,8461,5393,45404,8312,34132,32800,257,8573,46093,513]

theorem envBound27126 : H12AffineFastState.Bounded env27126 := by
  intro p hp
  have h : env27126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27125_27126 : H12AffineEnvironment.transform 10 80 env27125 = env27126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env27125 == env27126) = true)

theorem identity27126 : scanCanonicalize (H12AffineFastState.compose env27126 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 12621) := by decide +kernel

theorem selectedBound27126 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env27127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,8192,13404,12621,4422,1280,8313,1025,12620,8460,32,16,4115,8193,64,8461,5393,17,8312,13337,12653,257,8573,1344,513]

theorem envBound27127 : H12AffineFastState.Bounded env27127 := by
  intro p hp
  have h : env27127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27126_27127 : H12AffineEnvironment.transform 14 12621 env27126 = env27127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12621 env27126 == env27127) = true)

theorem identity27127 : scanCanonicalize (H12AffineFastState.compose env27127 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27127 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env27128 : List Nat := [2,4,8,16,32,64,9,256,512,273,80,4096,8192,12621,12621,4422,17,8313,272,12620,8460,32,16,4115,8193,64,8461,4096,17,8312,12552,12653,257,8573,81,513]

theorem envBound27128 : H12AffineFastState.Bounded env27128 := by
  intro p hp
  have h : env27128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27127_27128 : H12AffineEnvironment.transform 9 273 env27127 = env27128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27127 == env27128) = true)

theorem identity27128 : scanCanonicalize (H12AffineFastState.compose env27128 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27128 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env27129 : List Nat := [2,4,8,16,32,64,9,117,512,100,80,4096,8192,12344,12344,4147,17,8313,101,12345,8313,32,16,4115,8193,64,8312,4096,17,8312,12413,12312,116,8200,81,513]

theorem envBound27129 : H12AffineFastState.Bounded env27129 := by
  intro p hp
  have h : env27129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27128_27129 : H12AffineEnvironment.transform 7 117 env27128 = env27129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27128 == env27129) = true)

def env27130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272513,180360,95497,8328,64,23808,185737,45525,262280,143760,400453,257,21793,46212,202311]

theorem envBound27130 : H12AffineFastState.Bounded env27130 := by
  intro p hp
  have h : env27130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27095_27130 : H12AffineEnvironment.transform 21 272513 env27095 = env27130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27095 == env27130) = true)

theorem identity27130 : scanCanonicalize (H12AffineFastState.compose env27130 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound27130 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,140300,272513,180360,41430,8328,64,23808,185737,45525,262280,143760,400453,257,21793,46212,180888]

theorem envBound27131 : H12AffineFastState.Bounded env27131 := by
  intro p hp
  have h : env27131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27130_27131 : H12AffineEnvironment.transform 15 54495 env27130 = env27131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env27130 == env27131) = true)

def env27132 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,140300,272393,180224,41310,8192,64,23808,185601,45405,262144,143640,400453,257,21793,46092,180752]

theorem envBound27132 : H12AffineFastState.Bounded env27132 := by
  intro p hp
  have h : env27132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27131_27132 : H12AffineEnvironment.transform 6 8 env27131 = env27132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27131 == env27132) = true)

theorem identity27132 : scanCanonicalize (H12AffineFastState.compose env27132 (packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound27132 : packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env27133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13673,262144,1025,32769,4453,272393,62825,41310,8192,64,23808,57448,45405,262144,1137,272684,257,21793,46092,63353]

theorem envBound27133 : H12AffineFastState.Bounded env27133 := by
  intro p hp
  have h : env27133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27132_27133 : H12AffineEnvironment.transform 16 13673 env27132 = env27133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env27132 == env27133) = true)

theorem identity27133 : scanCanonicalize (H12AffineFastState.compose env27133 (packedSelected [0,1,3,4,10,14,18,19,20,22,23,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 43356) := by decide +kernel

theorem selectedBound27133 : packedSelected [0,1,3,4,10,14,18,19,20,22,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13673,43356,1025,32769,4453,33109,62825,41310,8192,64,23808,57448,45405,43356,1137,32880,257,21793,46092,63353]

theorem envBound27134 : H12AffineFastState.Bounded env27134 := by
  intro p hp
  have h : env27134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27133_27134 : H12AffineEnvironment.transform 17 43356 env27133 = env27134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43356 env27133 == env27134) = true)

theorem identity27134 : scanCanonicalize (H12AffineFastState.compose env27134 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18,19,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound27134 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18,19,26] rootPS < 2^1333 := by decide +kernel

def env27135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40970,13673,43356,1025,32769,4453,33109,33076,41310,8192,64,10589,37941,45405,43356,1137,32880,257,8572,46092,33572]

theorem envBound27135 : H12AffineFastState.Bounded env27135 := by
  intro p hp
  have h : env27135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27134_27135 : H12AffineEnvironment.transform 13 13405 env27134 = env27135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env27134 == env27135) = true)

theorem identity27135 : scanCanonicalize (H12AffineFastState.compose env27135 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound27135 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env27136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8312,114,13673,2340,1025,8313,4453,8493,8524,294,8192,64,10589,13389,4389,2340,1137,8200,257,8572,5236,9052]

theorem envBound27136 : H12AffineFastState.Bounded env27136 := by
  intro p hp
  have h : env27136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27135_27136 : H12AffineEnvironment.transform 14 8312 env27135 = env27136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env27135 == env27136) = true)

theorem identity27136 : scanCanonicalize (H12AffineFastState.compose env27136 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27136 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env27137 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,8312,114,13341,2128,1025,8313,4113,8281,8248,82,8192,64,10281,13389,4177,2128,1137,8200,117,8200,5236,8744]

theorem envBound27137 : H12AffineFastState.Bounded env27137 := by
  intro p hp
  have h : env27137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27136_27137 : H12AffineEnvironment.transform 7 116 env27136 = env27137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27136 == env27137) = true)

theorem identity27137 : scanCanonicalize (H12AffineFastState.compose env27137 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound27137 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env27138 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1076,4096,8192,13405,8312,114,13341,1124,1025,8313,4113,8281,8248,82,8192,64,9245,13389,4177,1124,1137,8200,117,8200,5236,8744]

theorem envBound27138 : H12AffineFastState.Bounded env27138 := by
  intro p hp
  have h : env27138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27137_27138 : H12AffineEnvironment.transform 10 1076 env27137 = env27138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env27137 == env27138) = true)

theorem identity27138 : scanCanonicalize (H12AffineFastState.compose env27138 (packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound27138 : packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env27139 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1076,4096,5133,80,5237,114,16,1124,1025,5236,4113,5204,5173,82,5133,64,4112,64,4177,1124,1137,5125,117,5125,5236,5669]

theorem envBound27139 : H12AffineFastState.Bounded env27139 := by
  intro p hp
  have h : env27139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27138_27139 : H12AffineEnvironment.transform 12 5133 env27138 = env27139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env27138 == env27139) = true)

theorem identity27139 : scanCanonicalize (H12AffineFastState.compose env27139 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27139 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env27140 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,4096,5133,1,5156,35,16,1077,1025,5157,4113,5125,5173,3,5133,17,4112,17,4096,1077,1056,5125,36,5125,5157,5669]

theorem envBound27140 : H12AffineFastState.Bounded env27140 := by
  intro p hp
  have h : env27140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27139_27140 : H12AffineEnvironment.transform 5 17 env27139 = env27140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27139 == env27140) = true)

theorem identity27140 : scanCanonicalize (H12AffineFastState.compose env27140 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound27140 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env27141 : List Nat := [2,4,8,16,32,17,8,37,11,1024,1076,4096,5133,1,5156,35,16,1077,1025,5157,4113,5125,5173,3,5133,17,4112,17,4096,1077,1056,5125,36,5125,5157,5166]

theorem envBound27141 : H12AffineFastState.Bounded env27141 := by
  intro p hp
  have h : env27141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27140_27141 : H12AffineEnvironment.transform 8 11 env27140 = env27141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env27140 == env27141) = true)

def env27142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,140300,272392,180225,41311,8193,64,23808,185600,45404,262145,143641,400453,257,21793,46093,180753]

theorem envBound27142 : H12AffineFastState.Bounded env27142 := by
  intro p hp
  have h : env27142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27131_27142 : H12AffineEnvironment.transform 6 9 env27131 = env27142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27131 == env27142) = true)

theorem identity27142 : scanCanonicalize (H12AffineFastState.compose env27142 (packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 171060) := by decide +kernel

theorem selectedBound27142 : packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env27143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,171060,1025,32769,140300,177212,180225,41311,8193,64,23808,185600,45404,171061,143641,32881,257,21793,46093,180753]

theorem envBound27143 : H12AffineFastState.Bounded env27143 := by
  intro p hp
  have h : env27143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27142_27143 : H12AffineEnvironment.transform 17 171060 env27142 = env27143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171060 env27142 == env27143) = true)

theorem identity27143 : scanCanonicalize (H12AffineFastState.compose env27143 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound27143 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env27144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,23588,1025,32769,58396,29740,17,41311,8193,64,23808,5392,45404,23589,61705,32881,257,21793,46093,513]

theorem envBound27144 : H12AffineFastState.Bounded env27144 := by
  intro p hp
  have h : env27144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27143_27144 : H12AffineEnvironment.transform 16 49168 env27143 = env27144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27143 == env27144) = true)

theorem identity27144 : scanCanonicalize (H12AffineFastState.compose env27144 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27144 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,41050,46108,10280,1025,32769,36880,32,17,41311,8193,64,10508,5392,45404,10281,34053,32881,257,8493,46093,513]

theorem envBound27145 : H12AffineFastState.Bounded env27145 := by
  intro p hp
  have h : env27145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27144_27145 : H12AffineEnvironment.transform 13 13324 env27144 = env27145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27144 == env27145) = true)

theorem identity27145 : scanCanonicalize (H12AffineFastState.compose env27145 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound27145 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env27146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8460,342,5392,10280,1025,8461,12572,32,17,83,8193,64,10508,5392,4176,10281,9225,8573,257,8493,5377,513]

theorem envBound27146 : H12AffineFastState.Bounded env27146 := by
  intro p hp
  have h : env27146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27145_27146 : H12AffineEnvironment.transform 14 8460 env27145 = env27146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env27145 == env27146) = true)

theorem identity27146 : scanCanonicalize (H12AffineFastState.compose env27146 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27146 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,342,5392,2340,1025,1,4112,32,17,83,269,64,2048,5392,4176,2341,1285,113,257,33,5377,513]

theorem envBound27147 : H12AffineFastState.Bounded env27147 := by
  intro p hp
  have h : env27147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27146_27147 : H12AffineEnvironment.transform 12 268 env27146 = env27147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27146 == env27147) = true)

theorem identity27147 : scanCanonicalize (H12AffineFastState.compose env27147 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27147 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env27148 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1025,1,4112,32,17,3,269,16,2048,5392,4096,2341,1285,33,257,33,5377,513]

theorem envBound27148 : H12AffineFastState.Bounded env27148 := by
  intro p hp
  have h : env27148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27147_27148 : H12AffineEnvironment.transform 5 16 env27147 = env27148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27147 == env27148) = true)

theorem identity27148 : scanCanonicalize (H12AffineFastState.compose env27148 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound27148 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27149 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1328,268,48,0,262,32,2340,1025,1,1312,32,17,3,269,16,2048,32,1328,2341,1285,33,257,33,49,513]

theorem envBound27149 : H12AffineFastState.Bounded env27149 := by
  intro p hp
  have h : env27149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27148_27149 : H12AffineEnvironment.transform 11 1328 env27148 = env27149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env27148 == env27149) = true)

theorem identity27149 : scanCanonicalize (H12AffineFastState.compose env27149 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound27149 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27150 : List Nat := [2,4,8,16,32,16,9,256,276,1024,2048,1328,268,48,0,262,32,2340,1025,1,1312,32,17,3,269,16,2048,32,1328,2341,1285,33,257,33,49,277]

theorem envBound27150 : H12AffineFastState.Bounded env27150 := by
  intro p hp
  have h : env27150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27149_27150 : H12AffineEnvironment.transform 8 276 env27149 = env27150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env27149 == env27150) = true)

theorem identity27150 : scanCanonicalize (H12AffineFastState.compose env27150 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound27150 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27151 : List Nat := [2,4,8,16,32,16,9,256,276,1024,1076,1328,268,48,0,262,32,1296,1025,1,1312,32,17,3,269,16,1076,32,1328,1297,1285,33,257,33,49,277]

theorem envBound27151 : H12AffineFastState.Bounded env27151 := by
  intro p hp
  have h : env27151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27150_27151 : H12AffineEnvironment.transform 10 1076 env27150 = env27151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env27150 == env27151) = true)

theorem identity27151 : scanCanonicalize (H12AffineFastState.compose env27151 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound27151 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27152 : List Nat := [2,4,8,16,32,16,9,256,276,304,260,0,268,48,0,262,32,32,305,1,16,32,17,3,269,16,260,32,0,33,53,33,257,33,49,277]

theorem envBound27152 : H12AffineFastState.Bounded env27152 := by
  intro p hp
  have h : env27152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27151_27152 : H12AffineEnvironment.transform 9 304 env27151 = env27152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env27151 == env27152) = true)

theorem identity27152 : scanCanonicalize (H12AffineFastState.compose env27152 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27152 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env27153 : List Nat := [2,4,8,16,32,16,9,21,1,37,17,0,25,48,0,19,32,32,36,1,16,32,17,3,24,16,17,32,0,33,53,33,20,33,49,0]

theorem envBound27153 : H12AffineFastState.Bounded env27153 := by
  intro p hp
  have h : env27153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27152_27153 : H12AffineEnvironment.transform 7 21 env27152 = env27153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27152 == env27153) = true)

theorem identity27153 : scanCanonicalize (H12AffineFastState.compose env27153 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27153 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env27154 : List Nat := [2,4,8,0,32,0,9,5,1,37,1,0,9,32,0,3,32,32,36,1,0,32,1,3,8,0,1,32,0,33,37,33,4,33,33,0]

theorem envBound27154 : H12AffineFastState.Bounded env27154 := by
  intro p hp
  have h : env27154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27153_27154 : H12AffineEnvironment.transform 3 0 env27153 = env27154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27153 == env27154) = true)

def env27155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,180361,95496,8328,64,4486529,185736,45524,262281,143760,4338885,257,21793,46212,202311]

theorem envBound27155 : H12AffineFastState.Bounded env27155 := by
  intro p hp
  have h : env27155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27094_27155 : H12AffineEnvironment.transform 22 180361 env27094 = env27155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env27094 == env27155) = true)

def env27156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272512,180361,95496,8328,64,23809,185736,45524,262281,143760,400453,257,21793,46212,202311]

theorem envBound27156 : H12AffineFastState.Bounded env27156 := by
  intro p hp
  have h : env27156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27155_27156 : H12AffineEnvironment.transform 21 272512 env27155 = env27156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27155 == env27156) = true)

theorem identity27156 : scanCanonicalize (H12AffineFastState.compose env27156 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound27156 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,115871,272512,73754,95496,8328,64,23809,79131,45524,262281,119043,392406,257,21793,46212,63188]

theorem envBound27157 : H12AffineFastState.Bounded env27157 := by
  intro p hp
  have h : env27157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27156_27157 : H12AffineEnvironment.transform 16 123027 env27156 = env27157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env27156 == env27157) = true)

def env27158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10400,1025,32769,115871,32,73754,95496,8328,64,23809,79131,45524,10281,119043,119926,257,21793,46212,63188]

theorem envBound27158 : H12AffineFastState.Bounded env27158 := by
  intro p hp
  have h : env27158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27157_27158 : H12AffineEnvironment.transform 17 10400 env27157 = env27158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27157 == env27158) = true)

theorem identity27158 : scanCanonicalize (H12AffineFastState.compose env27158 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound27158 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41090,16401,10400,1025,32769,25629,32,32920,54666,8328,64,23809,38297,45524,10281,29057,29940,257,21793,46212,63188]

theorem envBound27159 : H12AffineFastState.Bounded env27159 := by
  intro p hp
  have h : env27159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27158_27159 : H12AffineEnvironment.transform 15 41090 env27158 = env27159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env27158 == env27159) = true)

theorem identity27159 : scanCanonicalize (H12AffineFastState.compose env27159 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound27159 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env27160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,41090,13389,10400,1025,32769,4161,32,32920,41430,8328,64,10589,38297,45524,10281,1501,168,257,8573,46212,33416]

theorem envBound27160 : H12AffineFastState.Bounded env27160 := by
  intro p hp
  have h : env27160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27159_27160 : H12AffineEnvironment.transform 13 13404 env27159 = env27160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env27159 == env27160) = true)

theorem identity27160 : scanCanonicalize (H12AffineFastState.compose env27160 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27160 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env27161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,32768,33246,5393,2556,1025,32769,4161,32,32920,32906,468,64,2049,38297,37000,2421,1501,168,257,33,38360,33416]

theorem envBound27161 : H12AffineFastState.Bounded env27161 := by
  intro p hp
  have h : env27161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27160_27161 : H12AffineEnvironment.transform 12 348 env27160 = env27161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27160 == env27161) = true)

theorem identity27161 : scanCanonicalize (H12AffineFastState.compose env27161 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound27161 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env27162 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,4096,129,5341,32768,32771,5324,2081,1025,32769,4161,32,32920,32906,9,64,2049,37956,37000,2216,1024,168,220,33,37893,33416]

theorem envBound27162 : H12AffineFastState.Bounded env27162 := by
  intro p hp
  have h : env27162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27161_27162 : H12AffineEnvironment.transform 7 221 env27161 = env27162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env27161 == env27162) = true)

theorem identity27162 : scanCanonicalize (H12AffineFastState.compose env27162 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound27162 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env27163 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,4096,129,5341,136,139,5324,2081,1025,137,4161,32,16,2,9,64,2049,5324,4096,2216,1024,168,220,33,5261,512]

theorem envBound27163 : H12AffineFastState.Bounded env27163 := by
  intro p hp
  have h : env27163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27162_27163 : H12AffineEnvironment.transform 14 136 env27162 = env27163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env27162 == env27163) = true)

theorem identity27163 : scanCanonicalize (H12AffineFastState.compose env27163 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27163 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27164 : List Nat := [2,4,8,16,1,64,128,221,512,1024,2048,4096,129,5341,136,139,5324,2048,1025,137,4161,1,16,2,9,64,2049,5324,4096,2185,1024,137,220,0,5261,512]

theorem envBound27164 : H12AffineFastState.Bounded env27164 := by
  intro p hp
  have h : env27164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27163_27164 : H12AffineEnvironment.transform 4 1 env27163 = env27164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27163 == env27164) = true)

theorem identity27164 : scanCanonicalize (H12AffineFastState.compose env27164 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound27164 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27165 : List Nat := [2,4,8,16,1,64,88,5,512,1024,2048,4096,89,5125,80,83,5140,2048,1025,81,4161,1,16,2,9,64,2049,5140,4096,2129,1024,81,4,0,5205,512]

theorem envBound27165 : H12AffineFastState.Bounded env27165 := by
  intro p hp
  have h : env27165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27164_27165 : H12AffineEnvironment.transform 6 88 env27164 = env27165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env27164 == env27165) = true)

theorem identity27165 : scanCanonicalize (H12AffineFastState.compose env27165 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27165 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27166 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,1,2,5140,2048,1025,0,4112,1,16,2,9,17,2049,5140,4096,2048,1024,0,4,0,5124,512]

theorem envBound27166 : H12AffineFastState.Bounded env27166 := by
  intro p hp
  have h : env27166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27165_27166 : H12AffineEnvironment.transform 5 17 env27165 = env27166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27165 == env27166) = true)

theorem identity27166 : scanCanonicalize (H12AffineFastState.compose env27166 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound27166 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27167 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1045,1,2,1028,2048,1025,0,0,1,16,2,9,17,2049,1028,16,2048,1024,0,4,0,1044,512]

theorem envBound27167 : H12AffineFastState.Bounded env27167 := by
  intro p hp
  have h : env27167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27166_27167 : H12AffineEnvironment.transform 11 16 env27166 = env27167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27166 == env27167) = true)

theorem identity27167 : scanCanonicalize (H12AffineFastState.compose env27167 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound27167 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27168 : List Nat := [2,4,8,16,1,17,9,5,512,1024,1044,16,8,1045,1,2,1028,1044,1025,0,0,1,16,2,9,17,1045,1028,16,1044,1024,0,4,0,1044,512]

theorem envBound27168 : H12AffineFastState.Bounded env27168 := by
  intro p hp
  have h : env27168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27167_27168 : H12AffineEnvironment.transform 10 1044 env27167 = env27168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env27167 == env27168) = true)

theorem identity27168 : scanCanonicalize (H12AffineFastState.compose env27168 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound27168 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27169 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,16,8,0,1,2,17,1,20,0,0,1,16,2,9,17,0,17,16,1,21,0,4,0,1,512]

theorem envBound27169 : H12AffineFastState.Bounded env27169 := by
  intro p hp
  have h : env27169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27168_27169 : H12AffineEnvironment.transform 9 21 env27168 = env27169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env27168 == env27169) = true)

theorem identity27169 : scanCanonicalize (H12AffineFastState.compose env27169 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound27169 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27170 : List Nat := [2,4,8,4,1,5,9,5,512,1,1,4,8,0,1,2,5,1,0,0,0,1,4,2,9,5,0,5,4,1,1,0,4,0,1,512]

theorem envBound27170 : H12AffineFastState.Bounded env27170 := by
  intro p hp
  have h : env27170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27169_27170 : H12AffineEnvironment.transform 3 4 env27169 = env27170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env27169 == env27170) = true)

def env27171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10401,1025,32769,115871,33,73754,95496,8328,64,23809,79131,45524,10280,119043,119927,257,21793,46212,63188]

theorem envBound27171 : H12AffineFastState.Bounded env27171 := by
  intro p hp
  have h : env27171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27157_27171 : H12AffineEnvironment.transform 17 10401 env27157 = env27171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env27157 == env27171) = true)

theorem identity27171 : scanCanonicalize (H12AffineFastState.compose env27171 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound27171 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,57677,10401,1025,32769,50497,33,8644,29910,8328,64,23809,13509,45524,10280,53469,54697,257,21793,46212,63188]

theorem envBound27172 : H12AffineFastState.Bounded env27172 := by
  intro p hp
  have h : env27172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27171_27172 : H12AffineEnvironment.transform 15 478 env27171 = env27172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env27171 == env27172) = true)

theorem identity27172 : scanCanonicalize (H12AffineFastState.compose env27172 (packedSelected [1,3,4,7,9,10,16,17,18,20,23,24,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound27172 : packedSelected [1,3,4,7,9,10,16,17,18,20,23,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,478,49305,2421,1025,32769,50497,33,16,21762,348,64,23809,5393,36864,2556,53469,54697,257,21793,38224,55040]

theorem envBound27173 : H12AffineFastState.Bounded env27173 := by
  intro p hp
  have h : env27173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27172_27173 : H12AffineEnvironment.transform 12 468 env27172 = env27173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env27172 == env27173) = true)

theorem identity27173 : scanCanonicalize (H12AffineFastState.compose env27173 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound27173 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env27174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,137,478,16400,2421,1025,136,17864,33,16,21762,348,64,23809,5393,4233,2556,20564,21792,257,21793,5593,22409]

theorem envBound27174 : H12AffineFastState.Bounded env27174 := by
  intro p hp
  have h : env27174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27173_27174 : H12AffineEnvironment.transform 14 137 env27173 = env27174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env27173 == env27174) = true)

theorem identity27174 : scanCanonicalize (H12AffineFastState.compose env27174 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound27174 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,478,5528,2421,1025,136,4160,33,16,138,348,64,2185,5393,4233,2556,1500,168,257,169,5593,513]

theorem envBound27175 : H12AffineFastState.Bounded env27175 := by
  intro p hp
  have h : env27175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27174_27175 : H12AffineEnvironment.transform 13 5512 env27174 = env27175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env27174 == env27175) = true)

def env27176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272513,180361,95496,8328,64,23808,185736,45524,262281,143760,400452,257,21793,46212,202311]

theorem envBound27176 : H12AffineFastState.Bounded env27176 := by
  intro p hp
  have h : env27176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27155_27176 : H12AffineEnvironment.transform 21 272513 env27155 = env27176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27155 == env27176) = true)

theorem identity27176 : scanCanonicalize (H12AffineFastState.compose env27176 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27176 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140300,272513,180361,21763,8328,64,23808,185736,45524,262281,143760,400452,257,21793,46212,144972]

theorem envBound27177 : H12AffineFastState.Bounded env27177 := by
  intro p hp
  have h : env27177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27176_27177 : H12AffineEnvironment.transform 15 8203 env27176 = env27177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27176 == env27177) = true)

def env27178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140300,272393,180225,21763,8192,64,23808,185600,45404,262145,143640,400452,257,21793,46092,144972]

theorem envBound27178 : H12AffineFastState.Bounded env27178 := by
  intro p hp
  have h : env27178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27177_27178 : H12AffineEnvironment.transform 6 8 env27177 = env27178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27177 == env27178) = true)

def env27179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,58396,272393,17,21763,8192,64,23808,5392,45404,262145,61704,318548,257,21793,46092,63068]

theorem envBound27179 : H12AffineFastState.Bounded env27179 := by
  intro p hp
  have h : env27179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27178_27179 : H12AffineEnvironment.transform 16 49168 env27178 = env27179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27178 == env27179) = true)

theorem identity27179 : scanCanonicalize (H12AffineFastState.compose env27179 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound27179 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,32041,1025,32769,58396,21792,17,21763,8192,64,23808,5392,45404,32040,61704,41341,257,21793,46092,63068]

theorem envBound27180 : H12AffineFastState.Bounded env27180 := by
  intro p hp
  have h : env27180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27179_27180 : H12AffineEnvironment.transform 17 32041 env27179 = env27180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env27179 == env27180) = true)

theorem identity27180 : scanCanonicalize (H12AffineFastState.compose env27180 (packedSelected [2,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound27180 : packedSelected [2,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env27181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,13389,32041,1025,29788,4161,21792,17,21763,8192,64,23808,5392,17665,32040,1365,21792,257,21793,16465,513]

theorem envBound27181 : H12AffineFastState.Bounded env27181 := by
  intro p hp
  have h : env27181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27180_27181 : H12AffineEnvironment.transform 14 29789 env27180 = env27181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env27180 == env27181) = true)

theorem identity27181 : scanCanonicalize (H12AffineFastState.compose env27181 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound27181 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,9293,8203,13389,11577,1025,9292,4161,1328,17,1299,8192,64,3344,5392,5393,11576,1365,1328,257,1329,4161,513]

theorem envBound27182 : H12AffineFastState.Bounded env27182 := by
  intro p hp
  have h : env27182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27181_27182 : H12AffineEnvironment.transform 13 4112 env27181 = env27182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env27181 == env27182) = true)

def env27183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,58397,272393,16,21763,8192,64,23808,5393,45404,262145,61705,318549,257,21793,46092,63069]

theorem envBound27183 : H12AffineFastState.Bounded env27183 := by
  intro p hp
  have h : env27183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27178_27183 : H12AffineEnvironment.transform 16 49169 env27178 = env27183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env27178 == env27183) = true)

theorem identity27183 : scanCanonicalize (H12AffineFastState.compose env27183 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound27183 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,38160,262144,1025,32769,45340,272393,16,2,8192,64,2049,5393,45404,262145,41992,297300,257,32,46092,41820]

theorem envBound27184 : H12AffineFastState.Bounded env27184 := by
  intro p hp
  have h : env27184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27183_27184 : H12AffineEnvironment.transform 13 5377 env27183 = env27184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27183 == env27184) = true)

theorem identity27184 : scanCanonicalize (H12AffineFastState.compose env27184 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound27184 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env27185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,38160,10280,1025,32769,45340,33,16,2,8192,64,2049,5393,45404,10281,41992,41340,257,32,46092,41820]

theorem envBound27185 : H12AffineFastState.Bounded env27185 := by
  intro p hp
  have h : env27185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27184_27185 : H12AffineEnvironment.transform 17 10280 env27184 = env27185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env27184 == env27185) = true)

def env27186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140300,272392,180224,21763,8193,64,23808,185601,45405,262144,143641,400452,257,21793,46093,144972]

theorem envBound27186 : H12AffineFastState.Bounded env27186 := by
  intro p hp
  have h : env27186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27177_27186 : H12AffineEnvironment.transform 6 9 env27177 = env27186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27177 == env27186) = true)

def env27187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,58396,272392,16,21763,8193,64,23808,5393,45405,262144,61705,318548,257,21793,46093,63068]

theorem envBound27187 : H12AffineFastState.Bounded env27187 := by
  intro p hp
  have h : env27187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27186_27187 : H12AffineEnvironment.transform 16 49168 env27186 = env27187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27186 == env27187) = true)

theorem identity27187 : scanCanonicalize (H12AffineFastState.compose env27187 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound27187 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,13389,262144,1025,29788,4161,272392,16,21763,8193,64,23808,5393,17664,262144,1364,272393,257,21793,16464,513]

theorem envBound27188 : H12AffineFastState.Bounded env27188 := by
  intro p hp
  have h : env27188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27187_27188 : H12AffineEnvironment.transform 14 29789 env27187 = env27188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env27187 == env27188) = true)

theorem identity27188 : scanCanonicalize (H12AffineFastState.compose env27188 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound27188 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,13389,10360,1025,29788,4161,112,16,21763,8193,64,23808,5393,17664,10360,1364,113,257,21793,16464,513]

theorem envBound27189 : H12AffineFastState.Bounded env27189 := by
  intro p hp
  have h : env27189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27188_27189 : H12AffineEnvironment.transform 17 10360 env27188 = env27189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env27188 == env27189) = true)

theorem identity27189 : scanCanonicalize (H12AffineFastState.compose env27189 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound27189 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env27190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8203,13389,10360,1025,0,4161,112,16,8543,8193,64,10588,5393,12636,10360,1364,113,257,8573,13324,513]

theorem envBound27190 : H12AffineFastState.Bounded env27190 := by
  intro p hp
  have h : env27190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27189_27190 : H12AffineEnvironment.transform 13 13404 env27189 = env27190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env27189 == env27190) = true)

theorem identity27190 : scanCanonicalize (H12AffineFastState.compose env27190 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27190 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,1,263,5441,2420,1025,0,4161,112,16,83,269,64,2128,5393,4176,2420,1364,113,257,113,5376,513]

theorem envBound27191 : H12AffineFastState.Bounded env27191 := by
  intro p hp
  have h : env27191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27190_27191 : H12AffineEnvironment.transform 12 268 env27190 = env27191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27190 == env27191) = true)

theorem identity27191 : scanCanonicalize (H12AffineFastState.compose env27191 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound27191 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env27192 : List Nat := [2,4,8,16,32,64,9,256,512,549,2048,4096,268,4981,1,263,4964,2420,548,0,4161,112,16,83,269,64,2128,4916,4176,2420,881,113,257,113,4901,513]

theorem envBound27192 : H12AffineFastState.Bounded env27192 := by
  intro p hp
  have h : env27192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27191_27192 : H12AffineEnvironment.transform 9 549 env27191 = env27192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env27191 == env27192) = true)

theorem identity27192 : scanCanonicalize (H12AffineFastState.compose env27192 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound27192 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env27193 : List Nat := [2,4,8,16,32,64,9,256,512,549,2048,17,268,868,1,263,885,2420,548,0,80,112,16,83,269,64,2128,805,65,2420,881,113,257,113,820,513]

theorem envBound27193 : H12AffineFastState.Bounded env27193 := by
  intro p hp
  have h : env27193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27192_27193 : H12AffineEnvironment.transform 11 17 env27192 = env27193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27192 == env27193) = true)

theorem identity27193 : scanCanonicalize (H12AffineFastState.compose env27193 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27193 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27194 : List Nat := [2,4,8,16,32,64,9,37,512,549,2048,17,41,577,1,34,592,2129,548,0,80,112,16,83,40,64,2128,512,65,2129,596,113,36,113,529,513]

theorem envBound27194 : H12AffineFastState.Bounded env27194 := by
  intro p hp
  have h : env27194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27193_27194 : H12AffineEnvironment.transform 7 37 env27193 = env27194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27193 == env27194) = true)

theorem identity27194 : scanCanonicalize (H12AffineFastState.compose env27194 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound27194 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27195 : List Nat := [2,4,8,16,32,1,9,37,512,549,2048,17,41,512,1,34,529,2064,548,0,17,49,16,18,40,1,2065,512,0,2064,533,48,36,48,529,513]

theorem envBound27195 : H12AffineFastState.Bounded env27195 := by
  intro p hp
  have h : env27195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27194_27195 : H12AffineEnvironment.transform 5 1 env27194 = env27195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env27194 == env27195) = true)

theorem identity27195 : scanCanonicalize (H12AffineFastState.compose env27195 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound27195 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env27196 : List Nat := [2,4,8,16,32,1,9,37,512,549,1,17,41,512,1,34,529,17,548,0,17,49,16,18,40,1,16,512,0,17,533,48,36,48,529,513]

theorem envBound27196 : H12AffineFastState.Bounded env27196 := by
  intro p hp
  have h : env27196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27195_27196 : H12AffineEnvironment.transform 10 1 env27195 = env27196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env27195 == env27196) = true)

theorem identity27196 : scanCanonicalize (H12AffineFastState.compose env27196 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27196 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27197 : List Nat := [2,4,8,16,32,1,9,37,1,36,1,17,41,1,1,34,16,17,37,0,17,49,16,18,40,1,16,1,0,17,20,48,36,48,16,0]

theorem envBound27197 : H12AffineFastState.Bounded env27197 := by
  intro p hp
  have h : env27197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27196_27197 : H12AffineEnvironment.transform 8 1 env27196 = env27197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27196 == env27197) = true)

theorem identity27197 : scanCanonicalize (H12AffineFastState.compose env27197 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27198 : List Nat := [2,4,8,16,16,1,9,21,1,20,1,17,25,1,1,18,16,17,21,0,17,1,16,18,24,1,16,1,0,17,20,0,20,0,16,0]

theorem envBound27198 : H12AffineFastState.Bounded env27198 := by
  intro p hp
  have h : env27198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27197_27198 : H12AffineEnvironment.transform 4 16 env27197 = env27198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27197 == env27198) = true)

theorem identity27198 : scanCanonicalize (H12AffineFastState.compose env27198 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27198 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27199 : List Nat := [2,4,8,1,1,1,9,4,1,5,1,0,8,1,1,3,1,0,4,0,0,1,1,3,9,1,1,1,0,0,5,0,5,0,1,0]

theorem envBound27199 : H12AffineFastState.Bounded env27199 := by
  intro p hp
  have h : env27199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27198_27199 : H12AffineEnvironment.transform 3 1 env27198 = env27199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27198 == env27199) = true)

def env27200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,58397,272392,17,21763,8193,64,23808,5392,45405,262144,61704,318549,257,21793,46093,63069]

theorem envBound27200 : H12AffineFastState.Bounded env27200 := by
  intro p hp
  have h : env27200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27186_27200 : H12AffineEnvironment.transform 16 49169 env27186 = env27200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env27186 == env27200) = true)

theorem identity27200 : scanCanonicalize (H12AffineFastState.compose env27200 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound27200 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,56436,1025,32769,58397,62588,17,21763,8193,64,23808,5392,45405,56436,61704,33,257,21793,46093,63069]

theorem envBound27201 : H12AffineFastState.Bounded env27201 := by
  intro p hp
  have h : env27201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27200_27201 : H12AffineEnvironment.transform 17 56436 env27200 = env27201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env27200 == env27201) = true)

theorem identity27201 : scanCanonicalize (H12AffineFastState.compose env27201 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27201 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env27202 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24908,32041,1025,8540,17728,21793,17,21763,8193,64,23808,5392,4096,32041,20565,33,257,21793,5456,22272]

theorem envBound27202 : H12AffineFastState.Bounded env27202 := by
  intro p hp
  have h : env27202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27201_27202 : H12AffineEnvironment.transform 14 8541 env27201 = env27202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27201 == env27202) = true)

theorem identity27202 : scanCanonicalize (H12AffineFastState.compose env27202 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27202 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,8203,5440,2341,1025,8540,12620,8493,17,8463,8193,64,10508,5392,4096,2341,9305,33,257,8493,5456,8972]

theorem envBound27203 : H12AffineFastState.Bounded env27203 := by
  intro p hp
  have h : env27203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27202_27203 : H12AffineEnvironment.transform 13 13324 env27202 = env27203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27202 == env27203) = true)

theorem identity27203 : scanCanonicalize (H12AffineFastState.compose env27203 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27203 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env27204 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8461,8203,5392,2341,1025,8460,12572,8493,17,8463,8193,16,10508,5392,4096,2341,9225,33,257,8493,5376,8972]

theorem envBound27204 : H12AffineFastState.Bounded env27204 := by
  intro p hp
  have h : env27204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27203_27204 : H12AffineEnvironment.transform 5 16 env27203 = env27204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27203 == env27204) = true)

theorem identity27204 : scanCanonicalize (H12AffineFastState.compose env27204 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 5417) := by decide +kernel

theorem selectedBound27204 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env27205 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5417,293,5156,5410,5392,2341,1025,5157,1077,5124,17,5158,5416,16,7205,5392,4096,2341,4384,33,257,5124,5376,5669]

theorem envBound27205 : H12AffineFastState.Bounded env27205 := by
  intro p hp
  have h : env27205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27204_27205 : H12AffineEnvironment.transform 12 5417 env27204 = env27205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5417 env27204 == env27205) = true)

theorem identity27205 : scanCanonicalize (H12AffineFastState.compose env27205 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound27205 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27206 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,5417,293,5156,5410,5392,1297,1025,5157,1077,5124,17,5158,5416,16,4113,5392,4096,1297,4384,33,257,5124,5376,5669]

theorem envBound27206 : H12AffineFastState.Bounded env27206 := by
  intro p hp
  have h : env27206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27205_27206 : H12AffineEnvironment.transform 10 1076 env27205 = env27206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env27205 == env27206) = true)

theorem identity27206 : scanCanonicalize (H12AffineFastState.compose env27206 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27206 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env27207 : List Nat := [2,4,8,16,32,16,9,256,512,52,0,4096,4381,293,4112,4374,4388,293,53,4113,1,4144,17,4114,4380,16,4113,4388,4096,293,4384,33,257,4144,4404,4625]

theorem envBound27207 : H12AffineFastState.Bounded env27207 := by
  intro p hp
  have h : env27207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27206_27207 : H12AffineEnvironment.transform 9 52 env27206 = env27207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27206 == env27207) = true)

theorem identity27207 : scanCanonicalize (H12AffineFastState.compose env27207 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound27207 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env27208 : List Nat := [2,4,8,16,32,16,9,256,512,52,0,16,269,293,0,262,308,293,53,1,1,32,17,2,268,16,1,308,16,293,304,33,257,32,292,513]

theorem envBound27208 : H12AffineFastState.Bounded env27208 := by
  intro p hp
  have h : env27208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27207_27208 : H12AffineEnvironment.transform 11 16 env27207 = env27208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27207 == env27208) = true)

def env27209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254784,25265168,145662400,525568,140903596,27337993,25733063]

theorem envBound27209 : H12AffineFastState.Bounded env27209 := by
  intro p hp
  have h : env27209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26530_27209 : H12AffineEnvironment.transform 25 65 env26530 = env27209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env26530 == env27209) = true)

def env27210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356288,25265168,23160256,525568,27902124,27337993,25733063]

theorem envBound27210 : H12AffineFastState.Bounded env27210 := by
  intro p hp
  have h : env27210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27209_27210 : H12AffineEnvironment.transform 26 30393344 env27209 = env27210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env27209 == env27210) = true)

def env27211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265168,23160256,256,27378860,27337993,25207751]

theorem envBound27211 : H12AffineFastState.Bounded env27211 := by
  intro p hp
  have h : env27211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27210_27211 : H12AffineEnvironment.transform 18 1024 env27210 = env27211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env27210 == env27211) = true)

theorem identity27211 : scanCanonicalize (H12AffineFastState.compose env27211 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 485740) := by decide +kernel

theorem selectedBound27211 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,485740,8328,65,12626284,2551265,10507600,8830976,8842620,6687916,256,10923456,10898533,8899243]

theorem envBound27212 : H12AffineFastState.Bounded env27212 := by
  intro p hp
  have h : env27212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27211_27212 : H12AffineEnvironment.transform 23 485740 env27211 = env27212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 485740 env27211 == env27212) = true)

def env27213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2554080,485740,8328,65,6705548,2551265,437680,2111712,2102684,6687916,256,21792,46213,2175563]

theorem envBound27213 : H12AffineFastState.Bounded env27213 := by
  intro p hp
  have h : env27213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27212_27213 : H12AffineEnvironment.transform 22 2554080 env27212 = env27213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2554080 env27212 == env27213) = true)

def env27214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101328,98780,8328,65,6338876,2098513,17664,2111712,2102684,6349852,256,21792,46213,2175563]

theorem envBound27214 : H12AffineFastState.Bounded env27214 := by
  intro p hp
  have h : env27214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27213_27214 : H12AffineEnvironment.transform 17 190640 env27213 = env27214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env27213 == env27214) = true)

def env27215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,16,98780,8328,65,4237692,5393,17664,10400,1500,4256860,256,21792,46213,74251]

theorem envBound27215 : H12AffineFastState.Bounded env27215 := by
  intro p hp
  have h : env27215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27214_27215 : H12AffineEnvironment.transform 20 4160 env27214 = env27215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27214 == env27215) = true)

theorem identity27215 : scanCanonicalize (H12AffineFastState.compose env27215 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound27215 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,190640,1024,32769,4160,4194304,16,21762,8328,65,4237692,5393,17664,10400,1500,4256860,256,21792,46213,63189]

theorem envBound27216 : H12AffineFastState.Bounded env27216 := by
  intro p hp
  have h : env27216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27215_27216 : H12AffineEnvironment.transform 15 54494 env27215 = env27216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env27215 == env27216) = true)

def env27217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4160,4194304,16,21762,8192,65,4237692,5393,17664,10280,1364,4256860,256,21792,46093,63069]

theorem envBound27217 : H12AffineFastState.Bounded env27217 := by
  intro p hp
  have h : env27217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27216_27217 : H12AffineEnvironment.transform 6 8 env27216 = env27217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27216 == env27217) = true)

theorem identity27217 : scanCanonicalize (H12AffineFastState.compose env27217 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound27217 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,32040,1024,32769,4160,4194304,16,21762,8192,65,4237692,5393,17664,10280,1364,4256860,256,21792,46093,63069]

theorem envBound27218 : H12AffineFastState.Bounded env27218 := by
  intro p hp
  have h : env27218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27217_27218 : H12AffineEnvironment.transform 16 38160 env27217 = env27218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env27217 == env27218) = true)

theorem identity27218 : scanCanonicalize (H12AffineFastState.compose env27218 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound27218 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,32040,1024,32769,4160,8573,16,21762,8192,65,34817,5393,17664,10280,1364,54561,256,21792,46093,63069]

theorem envBound27219 : H12AffineFastState.Bounded env27219 := by
  intro p hp
  have h : env27219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27218_27219 : H12AffineEnvironment.transform 21 8573 env27218 = env27219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env27218 == env27219) = true)

theorem identity27219 : scanCanonicalize (H12AffineFastState.compose env27219 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound27219 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env27220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,343,16401,32040,1024,21760,4160,8573,16,21762,8192,65,23808,5393,17664,10280,1364,32,256,21792,24844,9052]

theorem envBound27220 : H12AffineFastState.Bounded env27220 := by
  intro p hp
  have h : env27220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27219_27220 : H12AffineEnvironment.transform 14 21761 env27219 = env27220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env27219 == env27220) = true)

theorem identity27220 : scanCanonicalize (H12AffineFastState.compose env27220 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27220 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env27221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,343,16401,23669,1024,21760,4160,32,16,21762,349,65,23808,5393,17664,2421,1364,32,256,21792,16465,513]

theorem envBound27221 : H12AffineFastState.Bounded env27221 := by
  intro p hp
  have h : env27221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27220_27221 : H12AffineEnvironment.transform 12 349 env27220 = env27221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27220 == env27221) = true)

theorem identity27221 : scanCanonicalize (H12AffineFastState.compose env27221 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27221 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27222 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21761,262,16401,23588,1024,21760,4113,32,16,21762,268,16,23808,5393,17664,2340,1285,32,256,21792,16384,513]

theorem envBound27222 : H12AffineFastState.Bounded env27222 := by
  intro p hp
  have h : env27222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27221_27222 : H12AffineEnvironment.transform 5 17 env27221 = env27222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27221 == env27222) = true)

theorem identity27222 : scanCanonicalize (H12AffineFastState.compose env27222 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 1793) := by decide +kernel

theorem selectedBound27222 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env27223 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,1793,4608,262,1808,6949,1024,4609,4113,32,16,4611,268,16,6657,5393,513,2340,1285,32,256,4641,1793,513]

theorem envBound27223 : H12AffineFastState.Bounded env27223 := by
  intro p hp
  have h : env27223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27222_27223 : H12AffineEnvironment.transform 13 1793 env27222 = env27223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1793 env27222 == env27223) = true)

def env27224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4160,4194304,16,21762,8193,65,4237692,5393,17664,10281,1365,4256860,256,21792,46092,63068]

theorem envBound27224 : H12AffineFastState.Bounded env27224 := by
  intro p hp
  have h : env27224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27216_27224 : H12AffineEnvironment.transform 6 9 env27216 = env27224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27216 == env27224) = true)

theorem identity27224 : scanCanonicalize (H12AffineFastState.compose env27224 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound27224 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56437,1024,32769,4160,4194304,16,21762,8193,65,4237692,5393,17664,10281,1365,4256860,256,21792,46092,63068]

theorem envBound27225 : H12AffineFastState.Bounded env27225 := by
  intro p hp
  have h : env27225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27224_27225 : H12AffineEnvironment.transform 16 13388 env27224 = env27225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env27224 == env27225) = true)

theorem identity27225 : scanCanonicalize (H12AffineFastState.compose env27225 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 54561) := by decide +kernel

theorem selectedBound27225 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27226 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56437,1024,32769,4160,54561,16,21762,8193,65,31837,5393,17664,10281,1365,8573,256,21792,46092,63068]

theorem envBound27226 : H12AffineFastState.Bounded env27226 := by
  intro p hp
  have h : env27226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27225_27226 : H12AffineEnvironment.transform 21 54561 env27225 = env27226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54561 env27225 == env27226) = true)

theorem identity27226 : scanCanonicalize (H12AffineFastState.compose env27226 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound27226 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env27227 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13388,10280,1024,29788,4160,8572,16,21762,8193,65,31837,5393,17664,10281,1365,8573,256,21792,16465,513]

theorem envBound27227 : H12AffineFastState.Bounded env27227 := by
  intro p hp
  have h : env27227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27226_27227 : H12AffineEnvironment.transform 14 29789 env27226 = env27227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env27226 == env27227) = true)

theorem identity27227 : scanCanonicalize (H12AffineFastState.compose env27227 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27227 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27228 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,81,8202,13388,10280,1024,80,4160,8572,16,8462,8193,65,2129,5393,12556,10281,1365,8573,256,8492,13405,513]

theorem envBound27228 : H12AffineFastState.Bounded env27228 := by
  intro p hp
  have h : env27228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27227_27228 : H12AffineEnvironment.transform 13 13324 env27227 = env27228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27227 == env27228) = true)

def env27229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,17,98780,8328,65,4237693,5392,17664,10401,1501,4256861,256,21792,46213,74250]

theorem envBound27229 : H12AffineFastState.Bounded env27229 := by
  intro p hp
  have h : env27229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27214_27229 : H12AffineEnvironment.transform 20 4161 env27214 = env27229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27214 == env27229) = true)

theorem identity27229 : scanCanonicalize (H12AffineFastState.compose env27229 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201967) := by decide +kernel

theorem selectedBound27229 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,201967,17,98780,8328,65,245138,5392,17664,10401,1501,254130,256,21792,46213,74250]

theorem envBound27230 : H12AffineFastState.Bounded env27230 := by
  intro p hp
  have h : env27230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27229_27230 : H12AffineEnvironment.transform 21 201967 env27229 = env27230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201967 env27229 == env27230) = true)

def env27231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,201831,17,98644,8192,65,245018,5392,17664,10281,1365,254010,256,21792,46093,74250]

theorem envBound27231 : H12AffineFastState.Bounded env27231 := by
  intro p hp
  have h : env27231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27230_27231 : H12AffineEnvironment.transform 6 8 env27230 = env27231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27230 == env27231) = true)

theorem identity27231 : scanCanonicalize (H12AffineFastState.compose env27231 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound27231 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190520,1024,32769,4161,169265,17,2,8192,65,146508,5392,17664,10281,1365,156012,256,21792,46093,41820]

theorem envBound27232 : H12AffineFastState.Bounded env27232 := by
  intro p hp
  have h : env27232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27231_27232 : H12AffineEnvironment.transform 15 33110 env27231 = env27232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env27231 == env27232) = true)

theorem identity27232 : scanCanonicalize (H12AffineFastState.compose env27232 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound27232 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,33110,131072,171061,1024,32769,4161,169265,17,2,8192,65,146508,5392,12557,10281,1365,136545,256,8493,46093,41820]

theorem envBound27233 : H12AffineFastState.Bounded env27233 := by
  intro p hp
  have h : env27233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27232_27233 : H12AffineEnvironment.transform 13 13325 env27232 = env27233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env27232 == env27233) = true)

theorem identity27233 : scanCanonicalize (H12AffineFastState.compose env27233 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound27233 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env27234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,33110,13673,43356,1024,32769,4161,41048,17,2,8192,65,2341,5392,12557,10281,1365,8200,256,8493,46093,41820]

theorem envBound27234 : H12AffineFastState.Bounded env27234 := by
  intro p hp
  have h : env27234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27233_27234 : H12AffineEnvironment.transform 16 13673 env27233 = env27234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env27233 == env27234) = true)

theorem identity27234 : scanCanonicalize (H12AffineFastState.compose env27234 (packedSelected [0,1,2,4,5,6,7,8,9,11,14,16,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27234 : packedSelected [0,1,2,4,5,6,7,8,9,11,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env27235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,8202,13673,2048,1024,8541,4161,260,17,2,8192,65,2341,5392,12557,10281,1365,8200,256,8493,5457,512]

theorem envBound27235 : H12AffineFastState.Bounded env27235 := by
  intro p hp
  have h : env27235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27234_27235 : H12AffineEnvironment.transform 14 8540 env27234 = env27235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27234 == env27235) = true)

theorem identity27235 : scanCanonicalize (H12AffineFastState.compose env27235 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27235 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27236 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13325,8312,8202,13389,2048,1024,8313,4161,32,17,2,8192,65,2049,5172,12329,10281,1137,8200,36,8201,5237,512]

theorem envBound27236 : H12AffineFastState.Bounded env27236 := by
  intro p hp
  have h : env27236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27235_27236 : H12AffineEnvironment.transform 7 36 env27235 = env27236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27235 == env27236) = true)

theorem identity27236 : scanCanonicalize (H12AffineFastState.compose env27236 (packedSelected [2,3,5,6,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound27236 : packedSelected [2,3,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env27237 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,88,5205,32,82,5141,2048,1024,33,4161,32,17,2,88,65,2049,5172,4209,2161,1137,80,36,81,5237,512]

theorem envBound27237 : H12AffineFastState.Bounded env27237 := by
  intro p hp
  have h : env27237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27236_27237 : H12AffineEnvironment.transform 12 88 env27236 = env27237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env27236 == env27237) = true)

theorem identity27237 : scanCanonicalize (H12AffineFastState.compose env27237 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27237 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27238 : List Nat := [2,4,8,16,0,64,8,4,512,1024,2048,4096,88,5205,0,82,5141,2048,1024,1,4161,0,17,2,88,65,2049,5140,4177,2129,1105,80,4,81,5205,512]

theorem envBound27238 : H12AffineFastState.Bounded env27238 := by
  intro p hp
  have h : env27238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27237_27238 : H12AffineEnvironment.transform 4 0 env27237 = env27238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27237 == env27238) = true)

def env27239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,201830,17,98645,8193,65,245019,5392,17664,10280,1364,254011,256,21792,46092,74250]

theorem envBound27239 : H12AffineFastState.Bounded env27239 := by
  intro p hp
  have h : env27239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27230_27239 : H12AffineEnvironment.transform 6 9 env27230 = env27239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27230 == env27239) = true)

theorem identity27239 : scanCanonicalize (H12AffineFastState.compose env27239 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27239 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27240 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4161,144493,17,41310,8193,65,171280,5392,17664,10280,1364,180272,256,21792,46092,513]

theorem envBound27240 : H12AffineFastState.Bounded env27240 := by
  intro p hp
  have h : env27240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27239_27240 : H12AffineEnvironment.transform 15 8203 env27239 = env27240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27239 == env27240) = true)

theorem identity27240 : scanCanonicalize (H12AffineFastState.compose env27240 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27240 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27241 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4113,144445,17,41230,8193,17,171280,5392,17664,10280,1284,180272,256,21792,46092,513]

theorem envBound27241 : H12AffineFastState.Bounded env27241 := by
  intro p hp
  have h : env27241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27240_27241 : H12AffineEnvironment.transform 5 16 env27240 = env27241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27240 == env27241) = true)

theorem identity27241 : scanCanonicalize (H12AffineFastState.compose env27241 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound27241 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env27242 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43049,1024,32769,4113,29741,17,41230,8193,17,56576,5392,17664,10280,1284,32800,256,21792,46092,513]

theorem envBound27242 : H12AffineFastState.Bounded env27242 := by
  intro p hp
  have h : env27242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27241_27242 : H12AffineEnvironment.transform 16 16400 env27241 = env27242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env27241 == env27242) = true)

theorem identity27242 : scanCanonicalize (H12AffineFastState.compose env27242 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound27242 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27243 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,8203,16400,2341,1024,8461,4113,29741,17,2,8193,17,31756,5392,17664,10280,1284,8492,256,21792,5376,513]

theorem envBound27243 : H12AffineFastState.Bounded env27243 := by
  intro p hp
  have h : env27243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27242_27243 : H12AffineEnvironment.transform 14 8460 env27242 = env27243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env27242 == env27243) = true)

theorem identity27243 : scanCanonicalize (H12AffineFastState.compose env27243 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2828) := by decide +kernel

theorem selectedBound27243 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env27244 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,2828,16384,2560,2823,16400,2341,1024,2561,4113,24353,17,2,2829,17,22272,5392,17664,804,1284,2592,256,21792,5376,513]

theorem envBound27244 : H12AffineFastState.Bounded env27244 := by
  intro p hp
  have h : env27244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27243_27244 : H12AffineEnvironment.transform 12 2828 env27243 = env27244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2828 env27243 == env27244) = true)

theorem identity27244 : scanCanonicalize (H12AffineFastState.compose env27244 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound27244 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27245 : List Nat := [2,4,8,16,32,16,9,256,512,1024,513,4096,269,16384,1,262,16400,804,1024,0,4113,21792,17,2,268,17,22272,5392,17664,804,1284,33,256,21792,5376,513]

theorem envBound27245 : H12AffineFastState.Bounded env27245 := by
  intro p hp
  have h : env27245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27244_27245 : H12AffineEnvironment.transform 10 513 env27244 = env27245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env27244 == env27245) = true)

theorem identity27245 : scanCanonicalize (H12AffineFastState.compose env27245 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound27245 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27246 : List Nat := [2,4,8,16,32,16,9,256,512,1024,513,4096,269,5377,1,262,5393,804,1024,0,4113,33,17,2,268,17,513,5392,4097,804,1284,33,256,33,5376,513]

theorem envBound27246 : H12AffineFastState.Bounded env27246 := by
  intro p hp
  have h : env27246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27245_27246 : H12AffineEnvironment.transform 13 5377 env27245 = env27246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27245 == env27246) = true)

theorem identity27246 : scanCanonicalize (H12AffineFastState.compose env27246 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27246 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27247 : List Nat := [2,4,8,16,17,16,9,256,512,1024,513,4096,269,5377,1,262,5393,789,1024,0,4113,16,17,2,268,17,513,5392,4097,789,1284,16,256,16,5376,513]

theorem envBound27247 : H12AffineFastState.Bounded env27247 := by
  intro p hp
  have h : env27247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27246_27247 : H12AffineEnvironment.transform 4 17 env27246 = env27247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27246 == env27247) = true)

theorem identity27247 : scanCanonicalize (H12AffineFastState.compose env27247 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound27247 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27248 : List Nat := [2,4,8,16,17,16,9,256,512,517,513,4096,269,4868,1,262,4884,789,517,0,4113,16,17,2,268,17,513,4885,4097,789,769,16,256,16,4869,513]

theorem envBound27248 : H12AffineFastState.Bounded env27248 := by
  intro p hp
  have h : env27248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27247_27248 : H12AffineEnvironment.transform 9 517 env27247 = env27248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env27247 == env27248) = true)

theorem identity27248 : scanCanonicalize (H12AffineFastState.compose env27248 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound27248 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27249 : List Nat := [2,4,8,16,17,16,9,256,512,517,513,772,269,0,1,262,16,789,517,0,789,16,17,2,268,17,513,17,773,789,769,16,256,16,1,513]

theorem envBound27249 : H12AffineFastState.Bounded env27249 := by
  intro p hp
  have h : env27249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27248_27249 : H12AffineEnvironment.transform 11 772 env27248 = env27249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env27248 == env27249) = true)

theorem identity27249 : scanCanonicalize (H12AffineFastState.compose env27249 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound27249 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27250 : List Nat := [2,4,8,16,17,16,9,256,261,256,260,1,269,0,1,262,16,16,256,0,16,16,17,2,268,17,260,17,0,16,4,16,256,16,1,260]

theorem envBound27250 : H12AffineFastState.Bounded env27250 := by
  intro p hp
  have h : env27250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27249_27250 : H12AffineEnvironment.transform 8 261 env27249 = env27250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env27249 == env27250) = true)

theorem identity27250 : scanCanonicalize (H12AffineFastState.compose env27250 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27250 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27251 : List Nat := [2,4,8,16,17,16,9,20,17,20,16,1,25,0,1,18,16,16,20,0,16,16,17,2,24,17,16,17,0,16,4,16,20,16,1,16]

theorem envBound27251 : H12AffineFastState.Bounded env27251 := by
  intro p hp
  have h : env27251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27250_27251 : H12AffineEnvironment.transform 7 20 env27250 = env27251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27250 == env27251) = true)

theorem identity27251 : scanCanonicalize (H12AffineFastState.compose env27251 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27251 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27252 : List Nat := [2,4,8,1,0,1,9,5,0,5,1,1,8,0,1,3,1,1,5,0,1,1,0,2,9,0,1,0,0,1,4,1,5,1,1,1]

theorem envBound27252 : H12AffineFastState.Bounded env27252 := by
  intro p hp
  have h : env27252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27251_27252 : H12AffineEnvironment.transform 3 1 env27251 = env27252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27251 == env27252) = true)

theorem identity27252 : scanCanonicalize (H12AffineFastState.compose env27252 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27253 : List Nat := [2,4,2,1,0,1,3,5,0,5,1,1,2,0,1,3,1,1,5,0,1,1,0,2,3,0,1,0,0,1,4,1,5,1,1,1]

theorem envBound27253 : H12AffineFastState.Bounded env27253 := by
  intro p hp
  have h : env27253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27252_27253 : H12AffineEnvironment.transform 2 2 env27252 = env27253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27252 == env27253) = true)

def env27254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101329,98781,8328,65,6338877,2098512,17665,2111712,2102684,6349853,256,21792,46213,2175563]

theorem envBound27254 : H12AffineFastState.Bounded env27254 := by
  intro p hp
  have h : env27254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27213_27254 : H12AffineEnvironment.transform 17 190641 env27213 = env27254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env27213 == env27254) = true)

def env27255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,17,98781,8328,65,4237693,5392,17665,10400,1500,4256861,256,21792,46213,74251]

theorem envBound27255 : H12AffineFastState.Bounded env27255 := by
  intro p hp
  have h : env27255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27254_27255 : H12AffineEnvironment.transform 20 4160 env27254 = env27255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27254 == env27255) = true)

theorem identity27255 : scanCanonicalize (H12AffineFastState.compose env27255 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254011) := by decide +kernel

theorem selectedBound27255 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,254011,17,98781,8328,65,215366,5392,17665,10400,1500,201830,256,21792,46213,74251]

theorem envBound27256 : H12AffineFastState.Bounded env27256 := by
  intro p hp
  have h : env27256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27255_27256 : H12AffineEnvironment.transform 21 254011 env27255 = env27256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254011 env27255 == env27256) = true)

def env27257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,254011,17,98645,8192,65,215366,5392,17665,10280,1364,201830,256,21792,46093,74251]

theorem envBound27257 : H12AffineFastState.Bounded env27257 := by
  intro p hp
  have h : env27257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27256_27257 : H12AffineEnvironment.transform 6 8 env27256 = env27257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27256 == env27257) = true)

theorem identity27257 : scanCanonicalize (H12AffineFastState.compose env27257 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound27257 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27258 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190521,1024,32769,4160,156012,17,2,8192,65,182289,5392,17665,10280,1364,169265,256,21792,46093,41820]

theorem envBound27258 : H12AffineFastState.Bounded env27258 := by
  intro p hp
  have h : env27258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27257_27258 : H12AffineEnvironment.transform 15 33111 env27257 = env27258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env27257 == env27258) = true)

theorem identity27258 : scanCanonicalize (H12AffineFastState.compose env27258 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27258 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env27259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,149860,1024,8540,4160,156012,17,2,8192,65,158028,5392,17665,10280,1364,144492,256,21792,5456,513]

theorem envBound27259 : H12AffineFastState.Bounded env27259 := by
  intro p hp
  have h : env27259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27258_27259 : H12AffineEnvironment.transform 14 8541 env27258 = env27259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27258 == env27259) = true)

theorem identity27259 : scanCanonicalize (H12AffineFastState.compose env27259 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound27259 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8541,8202,131072,138561,1024,8540,4160,144713,17,2,8192,65,146793,5392,4388,10280,1364,144492,256,261,5456,513]

theorem envBound27260 : H12AffineFastState.Bounded env27260 := by
  intro p hp
  have h : env27260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27259_27260 : H12AffineEnvironment.transform 13 5157 env27259 = env27260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env27259 == env27260) = true)

theorem identity27260 : scanCanonicalize (H12AffineFastState.compose env27260 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound27260 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env27261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8541,8202,5172,2421,1024,8540,4160,8573,17,2,8192,65,10589,5392,4388,10280,1364,8280,256,261,5456,513]

theorem envBound27261 : H12AffineFastState.Bounded env27261 := by
  intro p hp
  have h : env27261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27260_27261 : H12AffineEnvironment.transform 16 5172 env27260 = env27261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env27260 == env27261) = true)

theorem identity27261 : scanCanonicalize (H12AffineFastState.compose env27261 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound27261 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env27262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5157,372,35,5172,2421,1024,373,4160,340,17,2,41,65,2420,5392,4388,2049,1364,113,256,261,5456,513]

theorem envBound27262 : H12AffineFastState.Bounded env27262 := by
  intro p hp
  have h : env27262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27261_27262 : H12AffineEnvironment.transform 12 41 env27261 = env27262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env27261 == env27262) = true)

theorem identity27262 : scanCanonicalize (H12AffineFastState.compose env27262 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound27262 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env27263 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3408,41,2421,372,35,2404,2421,1024,373,3344,340,17,2,41,65,2420,2112,3188,2049,1364,113,256,261,2048,513]

theorem envBound27263 : H12AffineFastState.Bounded env27263 := by
  intro p hp
  have h : env27263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27262_27263 : H12AffineEnvironment.transform 11 3408 env27262 = env27263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env27262 == env27263) = true)

theorem identity27263 : scanCanonicalize (H12AffineFastState.compose env27263 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound27263 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,1141,41,80,372,35,65,80,1024,373,1077,340,17,2,41,65,81,357,1361,292,1364,113,256,261,293,513]

theorem envBound27264 : H12AffineFastState.Bounded env27264 := by
  intro p hp
  have h : env27264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27263_27264 : H12AffineEnvironment.transform 10 293 env27263 = env27264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env27263 == env27264) = true)

theorem identity27264 : scanCanonicalize (H12AffineFastState.compose env27264 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound27264 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env27265 : List Nat := [2,4,8,16,32,64,8,256,512,53,293,64,41,80,372,35,65,80,53,373,0,340,17,2,41,65,81,357,356,292,353,113,256,261,293,513]

theorem envBound27265 : H12AffineFastState.Bounded env27265 := by
  intro p hp
  have h : env27265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27264_27265 : H12AffineEnvironment.transform 9 53 env27264 = env27265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env27264 == env27265) = true)

theorem identity27265 : scanCanonicalize (H12AffineFastState.compose env27265 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27265 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27266 : List Nat := [2,4,8,16,32,64,8,117,512,53,80,64,41,80,1,35,65,80,53,0,0,33,17,2,41,65,81,16,17,81,20,113,117,112,80,513]

theorem envBound27266 : H12AffineFastState.Bounded env27266 := by
  intro p hp
  have h : env27266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27265_27266 : H12AffineEnvironment.transform 7 117 env27265 = env27266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27265 == env27266) = true)

def env27267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,254011,17,98644,8193,65,215366,5392,17665,10281,1365,201830,256,21792,46092,74251]

theorem envBound27267 : H12AffineFastState.Bounded env27267 := by
  intro p hp
  have h : env27267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27256_27267 : H12AffineEnvironment.transform 6 9 env27256 = env27267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27256 == env27267) = true)

theorem identity27267 : scanCanonicalize (H12AffineFastState.compose env27267 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27267 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,180273,17,41310,8193,65,158028,5392,17665,10281,1365,144492,256,21792,46092,513]

theorem envBound27268 : H12AffineFastState.Bounded env27268 := by
  intro p hp
  have h : env27268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27267_27268 : H12AffineEnvironment.transform 15 8202 env27267 = env27268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27267 == env27268) = true)

theorem identity27268 : scanCanonicalize (H12AffineFastState.compose env27268 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound27268 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4160,32800,17,41310,8193,65,10589,5392,17665,10281,1365,29821,256,21792,46092,513]

theorem envBound27269 : H12AffineFastState.Bounded env27269 := by
  intro p hp
  have h : env27269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27268_27269 : H12AffineEnvironment.transform 16 16401 env27268 = env27269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env27268 == env27269) = true)

theorem identity27269 : scanCanonicalize (H12AffineFastState.compose env27269 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27269 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,2420,1024,8540,4160,8573,17,3,8193,65,10589,5392,17665,10281,1365,29821,256,21792,5457,513]

theorem envBound27270 : H12AffineFastState.Bounded env27270 := by
  intro p hp
  have h : env27270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27269_27270 : H12AffineEnvironment.transform 14 8541 env27269 = env27270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27269 == env27270) = true)

theorem identity27270 : scanCanonicalize (H12AffineFastState.compose env27270 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27270 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,8202,13341,2420,1024,8540,4160,8573,17,3,8193,65,10589,5392,12557,10281,1365,113,256,8492,5457,513]

theorem envBound27271 : H12AffineFastState.Bounded env27271 := by
  intro p hp
  have h : env27271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27270_27271 : H12AffineEnvironment.transform 13 13324 env27270 = env27271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27270 == env27271) = true)

theorem identity27271 : scanCanonicalize (H12AffineFastState.compose env27271 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound27271 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env27272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,4404,1125,1330,4389,2420,1024,1124,4160,1093,17,3,1337,65,3173,5392,5173,3345,1365,113,256,1044,5457,513]

theorem envBound27272 : H12AffineFastState.Bounded env27272 := by
  intro p hp
  have h : env27272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27271_27272 : H12AffineEnvironment.transform 12 1336 env27271 = env27272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env27271 == env27272) = true)

theorem identity27272 : scanCanonicalize (H12AffineFastState.compose env27272 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound27272 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env27273 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,4404,0,343,4389,2420,101,1,4160,32,17,3,348,65,2048,4469,4176,2420,304,113,256,113,4404,513]

theorem envBound27273 : H12AffineFastState.Bounded env27273 := by
  intro p hp
  have h : env27273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27272_27273 : H12AffineEnvironment.transform 9 101 env27272 = env27273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env27272 == env27273) = true)

theorem identity27273 : scanCanonicalize (H12AffineFastState.compose env27273 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27273 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27274 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,269,4404,0,263,4389,2340,53,1,4112,32,17,3,268,17,2048,4389,4096,2340,304,33,256,33,4404,513]

theorem envBound27274 : H12AffineFastState.Bounded env27274 := by
  intro p hp
  have h : env27274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27273_27274 : H12AffineEnvironment.transform 5 16 env27273 = env27274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27273 == env27274) = true)

theorem identity27274 : scanCanonicalize (H12AffineFastState.compose env27274 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27274 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27275 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,0,34,4096,2049,53,1,4112,32,17,3,41,17,2048,4096,4096,2049,21,33,37,33,4113,513]

theorem envBound27275 : H12AffineFastState.Bounded env27275 := by
  intro p hp
  have h : env27275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27274_27275 : H12AffineEnvironment.transform 7 37 env27274 = env27275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27274 == env27275) = true)

theorem identity27275 : scanCanonicalize (H12AffineFastState.compose env27275 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27276 : List Nat := [2,4,8,1,32,1,9,37,512,36,2048,4096,40,4096,0,34,4096,2049,36,1,4097,32,0,3,41,0,2048,4096,4096,2049,4,33,37,33,4096,513]

theorem envBound27276 : H12AffineFastState.Bounded env27276 := by
  intro p hp
  have h : env27276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27275_27276 : H12AffineEnvironment.transform 3 1 env27275 = env27276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27275 == env27276) = true)

theorem identity27276 : scanCanonicalize (H12AffineFastState.compose env27276 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2603) := by decide +kernel

theorem selectedBound27276 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27277 : List Nat := [2,4,8,1,32,1,9,37,512,36,2048,2603,40,2603,0,34,2603,2049,36,1,2602,32,0,3,41,0,2048,2603,2603,2049,4,33,37,33,2603,513]

theorem envBound27277 : H12AffineFastState.Bounded env27277 := by
  intro p hp
  have h : env27277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27276_27277 : H12AffineEnvironment.transform 11 2603 env27276 = env27277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2603 env27276 == env27277) = true)

def env27278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,16,98781,8328,65,4237692,5393,17665,10401,1501,4256860,256,21792,46213,74250]

theorem envBound27278 : H12AffineFastState.Bounded env27278 := by
  intro p hp
  have h : env27278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27254_27278 : H12AffineEnvironment.transform 20 4161 env27254 = env27278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27254 == env27278) = true)

theorem identity27278 : scanCanonicalize (H12AffineFastState.compose env27278 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27278 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4161,4194304,16,41430,8328,65,4237692,5393,17665,10401,1501,4256860,256,21792,46213,513]

theorem envBound27279 : H12AffineFastState.Bounded env27279 := by
  intro p hp
  have h : env27279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27278_27279 : H12AffineEnvironment.transform 15 8203 env27278 = env27279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27278 == env27279) = true)

theorem identity27279 : scanCanonicalize (H12AffineFastState.compose env27279 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound27279 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4161,32801,16,41430,8328,65,10589,5393,17665,10401,1501,29821,256,21792,46213,513]

theorem envBound27280 : H12AffineFastState.Bounded env27280 := by
  intro p hp
  have h : env27280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27279_27280 : H12AffineEnvironment.transform 21 32801 env27279 = env27280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env27279 == env27280) = true)

theorem identity27280 : scanCanonicalize (H12AffineFastState.compose env27280 (packedSelected [0,3,4,7,10,11,17,18,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound27280 : packedSelected [0,3,4,7,10,11,17,18,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env27281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,35188,1024,32769,4161,32801,16,41430,8328,65,10589,5393,17665,10401,1501,29821,256,21792,46213,513]

theorem envBound27281 : H12AffineFastState.Bounded env27281 := by
  intro p hp
  have h : env27281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27280_27281 : H12AffineEnvironment.transform 16 25029 env27280 = env27281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env27280 == env27281) = true)

theorem identity27281 : scanCanonicalize (H12AffineFastState.compose env27281 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27281 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env27282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,35188,1024,32769,4161,32801,16,41311,8193,65,10589,5393,17665,10280,1364,29821,256,21792,46092,513]

theorem envBound27282 : H12AffineFastState.Bounded env27282 := by
  intro p hp
  have h : env27282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27281_27282 : H12AffineEnvironment.transform 6 9 env27281 = env27282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27281 == env27282) = true)

theorem identity27282 : scanCanonicalize (H12AffineFastState.compose env27282 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound27282 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27283 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,24908,23669,1024,21760,4161,21792,16,29790,8193,65,10589,5393,17665,10280,1364,29821,256,21792,24845,513]

theorem envBound27283 : H12AffineFastState.Bounded env27283 := by
  intro p hp
  have h : env27283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27282_27283 : H12AffineEnvironment.transform 14 21761 env27282 = env27283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env27282 == env27283) = true)

theorem identity27283 : scanCanonicalize (H12AffineFastState.compose env27283 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound27283 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27284 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8203,5393,10280,1024,8541,4161,8573,16,3,8193,65,10589,5393,12636,10280,1364,32,256,8573,5456,513]

theorem envBound27284 : H12AffineFastState.Bounded env27284 := by
  intro p hp
  have h : env27284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27283_27284 : H12AffineEnvironment.transform 13 13405 env27283 = env27284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env27283 == env27284) = true)

theorem identity27284 : scanCanonicalize (H12AffineFastState.compose env27284 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27284 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env27285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5393,2420,1024,1,4161,33,16,3,349,65,2049,5393,4096,2420,1364,32,256,33,5456,513]

theorem envBound27285 : H12AffineFastState.Bounded env27285 := by
  intro p hp
  have h : env27285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27284_27285 : H12AffineEnvironment.transform 12 348 env27284 = env27285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27284 == env27285) = true)

theorem identity27285 : scanCanonicalize (H12AffineFastState.compose env27285 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound27285 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,348,292,0,343,308,2420,1024,1,1124,33,16,3,349,65,2049,308,1061,2420,1364,32,256,33,373,513]

theorem envBound27286 : H12AffineFastState.Bounded env27286 := by
  intro p hp
  have h : env27286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27285_27286 : H12AffineEnvironment.transform 11 1061 env27285 = env27286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env27285 == env27286) = true)

theorem identity27286 : scanCanonicalize (H12AffineFastState.compose env27286 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound27286 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,1061,348,292,0,343,308,1124,1024,1,1124,33,16,3,349,65,1297,308,1061,1124,1364,32,256,33,373,513]

theorem envBound27287 : H12AffineFastState.Bounded env27287 := by
  intro p hp
  have h : env27287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27286_27287 : H12AffineEnvironment.transform 10 1296 env27286 = env27287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env27286 == env27287) = true)

theorem identity27287 : scanCanonicalize (H12AffineFastState.compose env27287 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound27287 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env27288 : List Nat := [2,4,8,16,32,33,9,256,512,1024,1296,1061,317,292,0,310,308,1029,1024,1,1029,33,16,3,316,32,1297,308,1061,1029,1333,32,256,33,276,513]

theorem envBound27288 : H12AffineFastState.Bounded env27288 := by
  intro p hp
  have h : env27288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27287_27288 : H12AffineEnvironment.transform 5 33 env27287 = env27288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env27287 == env27288) = true)

theorem identity27288 : scanCanonicalize (H12AffineFastState.compose env27288 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound27288 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env27289 : List Nat := [2,4,8,16,32,33,9,256,293,1024,1296,1061,317,292,0,310,308,1029,1024,1,1029,33,16,3,316,32,1297,308,1061,1029,1333,32,256,33,276,292]

theorem envBound27289 : H12AffineFastState.Bounded env27289 := by
  intro p hp
  have h : env27289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27288_27289 : H12AffineEnvironment.transform 8 293 env27288 = env27289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env27288 == env27289) = true)

theorem identity27289 : scanCanonicalize (H12AffineFastState.compose env27289 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27289 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27290 : List Nat := [2,4,8,16,1,0,9,256,260,1024,1296,1028,284,261,0,279,277,1029,1024,1,1029,0,16,3,285,1,1297,277,1028,1029,1300,1,256,0,276,261]

theorem envBound27290 : H12AffineFastState.Bounded env27290 := by
  intro p hp
  have h : env27290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27289_27290 : H12AffineEnvironment.transform 4 1 env27289 = env27290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27289 == env27290) = true)

theorem identity27290 : scanCanonicalize (H12AffineFastState.compose env27290 (packedSelected [0,4,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27290 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env27291 : List Nat := [2,4,8,0,1,0,9,256,260,1024,1280,1028,268,261,0,263,261,1029,1024,1,1029,0,0,3,269,1,1281,261,1028,1029,1284,1,256,0,260,261]

theorem envBound27291 : H12AffineFastState.Bounded env27291 := by
  intro p hp
  have h : env27291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27290_27291 : H12AffineEnvironment.transform 3 0 env27290 = env27291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27290 == env27291) = true)

theorem identity27291 : scanCanonicalize (H12AffineFastState.compose env27291 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound27291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27292 : List Nat := [2,4,8,0,1,0,9,256,260,257,1,261,268,261,0,263,261,260,257,1,260,0,0,3,269,1,0,261,261,260,5,1,256,0,260,261]

theorem envBound27292 : H12AffineFastState.Bounded env27292 := by
  intro p hp
  have h : env27292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27291_27292 : H12AffineEnvironment.transform 9 257 env27291 = env27292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env27291 == env27292) = true)

theorem identity27292 : scanCanonicalize (H12AffineFastState.compose env27292 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27292 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27293 : List Nat := [2,4,8,0,1,0,9,5,1,4,1,0,9,0,0,2,0,1,4,1,1,0,0,3,8,1,0,0,0,1,5,1,5,0,1,0]

theorem envBound27293 : H12AffineFastState.Bounded env27293 := by
  intro p hp
  have h : env27293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27292_27293 : H12AffineEnvironment.transform 7 5 env27292 = env27293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27292 == env27293) = true)

def env27294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2554081,485740,8328,65,6705549,2551265,437681,2111713,2102685,6687916,256,21793,46212,2175562]

theorem envBound27294 : H12AffineFastState.Bounded env27294 := by
  intro p hp
  have h : env27294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27212_27294 : H12AffineEnvironment.transform 22 2554081 env27212 = env27294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2554081 env27212 == env27294) = true)

def env27295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101329,98780,8328,65,6338877,2098513,17665,2111713,2102685,6349852,256,21793,46212,2175562]

theorem envBound27295 : H12AffineFastState.Bounded env27295 := by
  intro p hp
  have h : env27295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27294_27295 : H12AffineEnvironment.transform 17 190640 env27294 = env27295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env27294 == env27295) = true)

def env27296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,17,98780,8328,65,4237693,5393,17665,10401,1501,4256860,256,21793,46212,74250]

theorem envBound27296 : H12AffineFastState.Bounded env27296 := by
  intro p hp
  have h : env27296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27295_27296 : H12AffineEnvironment.transform 20 4160 env27295 = env27296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27295 == env27296) = true)

theorem identity27296 : scanCanonicalize (H12AffineFastState.compose env27296 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound27296 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,144613,17,98780,8328,65,171416,5393,17665,10401,1501,180409,256,21793,46212,74250]

theorem envBound27297 : H12AffineFastState.Bounded env27297 := by
  intro p hp
  have h : env27297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27296_27297 : H12AffineEnvironment.transform 21 144613 env27296 = env27297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env27296 == env27297) = true)

def env27298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144493,17,98644,8192,65,171280,5393,17665,10281,1365,180273,256,21793,46092,74250]

theorem envBound27298 : H12AffineFastState.Bounded env27298 := by
  intro p hp
  have h : env27298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27297_27298 : H12AffineEnvironment.transform 6 8 env27297 = env27298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27297 == env27298) = true)

theorem identity27298 : scanCanonicalize (H12AffineFastState.compose env27298 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound27298 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190520,1024,32769,4160,144493,17,2,8192,65,171280,5393,17665,10281,1365,180273,256,21793,46092,41820]

theorem envBound27299 : H12AffineFastState.Bounded env27299 := by
  intro p hp
  have h : env27299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27298_27299 : H12AffineEnvironment.transform 15 33110 env27298 = env27299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env27298 == env27299) = true)

theorem identity27299 : scanCanonicalize (H12AffineFastState.compose env27299 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27299 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,33110,131072,171060,1024,32769,4160,144493,17,2,8192,65,171280,5393,12557,10281,1365,177213,256,8493,46092,41820]

theorem envBound27300 : H12AffineFastState.Bounded env27300 := by
  intro p hp
  have h : env27300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27299_27300 : H12AffineEnvironment.transform 13 13324 env27299 = env27300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27299 == env27300) = true)

theorem identity27300 : scanCanonicalize (H12AffineFastState.compose env27300 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound27300 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,263,131072,138341,1024,80,4160,144493,17,2,8192,65,138561,5393,12557,10281,1365,144492,256,8493,13405,8973]

theorem envBound27301 : H12AffineFastState.Bounded env27301 := by
  intro p hp
  have h : env27301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27300_27301 : H12AffineEnvironment.transform 14 81 env27300 = env27301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env27300 == env27301) = true)

theorem identity27301 : scanCanonicalize (H12AffineFastState.compose env27301 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound27301 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,81,263,5173,2128,1024,80,4160,8280,17,2,8192,65,2420,5393,12557,10281,1365,8281,256,8493,13405,8973]

theorem envBound27302 : H12AffineFastState.Bounded env27302 := by
  intro p hp
  have h : env27302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27301_27302 : H12AffineEnvironment.transform 16 5173 env27301 = env27302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env27301 == env27302) = true)

theorem identity27302 : scanCanonicalize (H12AffineFastState.compose env27302 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound27302 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27303 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,13324,81,83,5173,2128,1024,80,4160,8280,17,2,8192,65,2080,5189,12377,10281,1025,8281,84,8313,13405,8793]

theorem envBound27303 : H12AffineFastState.Bounded env27303 := by
  intro p hp
  have h : env27303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27302_27303 : H12AffineEnvironment.transform 7 84 env27302 = env27303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env27302 == env27303) = true)

theorem identity27303 : scanCanonicalize (H12AffineFastState.compose env27303 (packedSelected [1,6,8,11,12,14,15,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound27303 : packedSelected [1,6,8,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env27304 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,8192,13324,33,35,5173,2080,1024,32,4144,8232,17,2,8192,49,2080,5173,12329,10281,1025,8233,36,8201,13357,8745]

theorem envBound27304 : H12AffineFastState.Bounded env27304 := by
  intro p hp
  have h : env27304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27303_27304 : H12AffineEnvironment.transform 5 48 env27303 = env27304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env27303 == env27304) = true)

def env27305 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144492,17,98645,8193,65,171281,5393,17665,10280,1364,180272,256,21793,46093,74250]

theorem envBound27305 : H12AffineFastState.Bounded env27305 := by
  intro p hp
  have h : env27305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27297_27305 : H12AffineEnvironment.transform 6 9 env27297 = env27305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27297 == env27305) = true)

theorem identity27305 : scanCanonicalize (H12AffineFastState.compose env27305 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27305 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4160,144492,17,41310,8193,65,171281,5393,17665,10280,1364,180272,256,21793,46093,513]

theorem envBound27306 : H12AffineFastState.Bounded env27306 := by
  intro p hp
  have h : env27306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27305_27306 : H12AffineEnvironment.transform 15 8203 env27305 = env27306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27305 == env27306) = true)

theorem identity27306 : scanCanonicalize (H12AffineFastState.compose env27306 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27306 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27307 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4112,144444,17,41230,8193,17,171281,5393,17665,10280,1284,180272,256,21793,46093,513]

theorem envBound27307 : H12AffineFastState.Bounded env27307 := by
  intro p hp
  have h : env27307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27306_27307 : H12AffineEnvironment.transform 5 16 env27306 = env27307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27306 == env27307) = true)

theorem identity27307 : scanCanonicalize (H12AffineFastState.compose env27307 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound27307 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env27308 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43049,1024,32769,4112,29740,17,41230,8193,17,56577,5393,17665,10280,1284,32800,256,21793,46093,513]

theorem envBound27308 : H12AffineFastState.Bounded env27308 := by
  intro p hp
  have h : env27308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27307_27308 : H12AffineEnvironment.transform 16 16400 env27307 = env27308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env27307 == env27308) = true)

theorem identity27308 : scanCanonicalize (H12AffineFastState.compose env27308 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound27308 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27309 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,8203,16400,2341,1024,8461,4112,29740,17,2,8193,17,31757,5393,17665,10280,1284,8492,256,21793,5377,513]

theorem envBound27309 : H12AffineFastState.Bounded env27309 := by
  intro p hp
  have h : env27309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27308_27309 : H12AffineEnvironment.transform 14 8460 env27308 = env27309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env27308 == env27309) = true)

theorem identity27309 : scanCanonicalize (H12AffineFastState.compose env27309 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2829) := by decide +kernel

theorem selectedBound27309 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env27310 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,2829,16384,2561,2822,16400,2341,1024,2560,4112,24353,17,2,2828,17,22272,5393,17665,805,1284,2593,256,21793,5377,513]

theorem envBound27310 : H12AffineFastState.Bounded env27310 := by
  intro p hp
  have h : env27310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27309_27310 : H12AffineEnvironment.transform 12 2829 env27309 = env27310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2829 env27309 == env27310) = true)

def env27311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,16,98780,8328,65,4237692,5392,17665,10400,1500,4256861,256,21793,46212,74251]

theorem envBound27311 : H12AffineFastState.Bounded env27311 := by
  intro p hp
  have h : env27311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27295_27311 : H12AffineEnvironment.transform 20 4161 env27295 = env27311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27295 == env27311) = true)

theorem identity27311 : scanCanonicalize (H12AffineFastState.compose env27311 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound27311 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138341,1024,29908,4161,4194304,16,95497,8328,65,4218281,5392,17665,10400,1500,4194440,256,21793,16465,74251]

theorem envBound27312 : H12AffineFastState.Bounded env27312 := by
  intro p hp
  have h : env27312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27311_27312 : H12AffineEnvironment.transform 14 29909 env27311 = env27312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env27311 == env27312) = true)

def env27313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138341,1024,8660,4161,4194304,16,73737,8328,65,4196521,5392,4097,10400,1500,4194440,256,33,5457,74251]

theorem envBound27313 : H12AffineFastState.Bounded env27313 := by
  intro p hp
  have h : env27313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27312_27313 : H12AffineEnvironment.transform 13 5376 env27312 = env27313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27312 == env27313) = true)

theorem identity27313 : scanCanonicalize (H12AffineFastState.compose env27313 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound27313 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70862,67755,1024,8660,4161,4194304,16,73737,8328,65,4196521,5392,4097,10400,1500,4194440,256,33,5457,74251]

theorem envBound27314 : H12AffineFastState.Bounded env27314 := by
  intro p hp
  have h : env27314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27313_27314 : H12AffineEnvironment.transform 16 70862 env27313 = env27314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env27313 == env27314) = true)

def env27315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138341,1024,8661,4161,4194304,16,73736,8328,65,4196520,5392,4096,10400,1500,4194440,256,32,5456,74251]

theorem envBound27315 : H12AffineFastState.Bounded env27315 := by
  intro p hp
  have h : env27315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27312_27315 : H12AffineEnvironment.transform 13 5377 env27312 = env27315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env27312 == env27315) = true)

theorem identity27315 : scanCanonicalize (H12AffineFastState.compose env27315 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound27315 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70727,67618,1024,8661,4161,4194304,16,73736,8328,65,4196520,5392,4096,10400,1500,4194440,256,32,5456,74251]

theorem envBound27316 : H12AffineFastState.Bounded env27316 := by
  intro p hp
  have h : env27316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27315_27316 : H12AffineEnvironment.transform 16 70727 env27315 = env27316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env27315 == env27316) = true)

theorem identity27316 : scanCanonicalize (H12AffineFastState.compose env27316 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27316 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,13389,10280,1024,8661,4161,4194304,16,2,8328,65,4196520,5392,4096,10400,1500,4194440,256,32,5456,513]

theorem envBound27317 : H12AffineFastState.Bounded env27317 := by
  intro p hp
  have h : env27317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27316_27317 : H12AffineEnvironment.transform 15 8202 env27316 = env27317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27316 == env27317) = true)

theorem identity27317 : scanCanonicalize (H12AffineFastState.compose env27317 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 249) := by decide +kernel

theorem selectedBound27317 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,13389,10280,1024,8661,4161,249,16,2,8328,65,2129,5392,4096,10400,1500,113,256,32,5456,513]

theorem envBound27318 : H12AffineFastState.Bounded env27318 := by
  intro p hp
  have h : env27318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27317_27318 : H12AffineEnvironment.transform 21 249 env27317 = env27318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 249 env27317 == env27318) = true)

def env27319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101328,98781,8328,65,6338876,2098512,17664,2111713,2102685,6349853,256,21793,46212,2175562]

theorem envBound27319 : H12AffineFastState.Bounded env27319 := by
  intro p hp
  have h : env27319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27294_27319 : H12AffineEnvironment.transform 17 190641 env27294 = env27319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env27294 == env27319) = true)

def env27320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,16,98781,8328,65,4237692,5392,17664,10401,1501,4256861,256,21793,46212,74250]

theorem envBound27320 : H12AffineFastState.Bounded env27320 := by
  intro p hp
  have h : env27320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27319_27320 : H12AffineEnvironment.transform 20 4160 env27319 = env27320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27319 == env27320) = true)

def env27321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,98645,8192,65,4237692,5392,17664,10281,1365,4256861,256,21793,46092,74250]

theorem envBound27321 : H12AffineFastState.Bounded env27321 := by
  intro p hp
  have h : env27321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27320_27321 : H12AffineEnvironment.transform 6 8 env27320 = env27321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27320 == env27321) = true)

theorem identity27321 : scanCanonicalize (H12AffineFastState.compose env27321 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound27321 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,108927,1024,32769,4160,4194304,16,98645,8192,65,4237692,5392,17664,10281,1365,4256861,256,21793,46092,74250]

theorem envBound27322 : H12AffineFastState.Bounded env27322 := by
  intro p hp
  have h : env27322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27321_27322 : H12AffineEnvironment.transform 16 82246 env27321 = env27322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env27321 == env27322) = true)

theorem identity27322 : scanCanonicalize (H12AffineFastState.compose env27322 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 119847) := by decide +kernel

theorem selectedBound27322 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,108927,1024,32769,4160,119847,16,98645,8192,65,97627,5392,17664,10281,1365,73850,256,21793,46092,74250]

theorem envBound27323 : H12AffineFastState.Bounded env27323 := by
  intro p hp
  have h : env27323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27322_27323 : H12AffineEnvironment.transform 21 119847 env27322 = env27323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119847 env27322 == env27323) = true)

theorem identity27323 : scanCanonicalize (H12AffineFastState.compose env27323 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound27323 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env27324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,114,16692,43277,1024,32769,4160,54357,16,33063,8192,65,32041,5392,17664,10281,1365,8200,256,21793,46092,8824]

theorem envBound27324 : H12AffineFastState.Bounded env27324 := by
  intro p hp
  have h : env27324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27323_27324 : H12AffineEnvironment.transform 15 114 env27323 = env27324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env27323 == env27324) = true)

theorem identity27324 : scanCanonicalize (H12AffineFastState.compose env27324 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound27324 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,32768,114,5220,43277,1024,32769,4160,33029,16,33063,8192,65,10361,5392,4176,10281,1365,8200,256,113,46092,8824]

theorem envBound27325 : H12AffineFastState.Bounded env27325 := by
  intro p hp
  have h : env27325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27324_27325 : H12AffineEnvironment.transform 13 5456 env27324 = env27325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env27324 == env27325) = true)

theorem identity27325 : scanCanonicalize (H12AffineFastState.compose env27325 (packedSelected [0,1,2,3,4,7,8,9,10,12,15,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8572) := by decide +kernel

theorem selectedBound27325 : packedSelected [0,1,2,3,4,7,8,9,10,12,15,18,23,24] rootPS < 2^1333 := by decide +kernel

def env27326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8572,114,5220,2161,1024,8573,4160,8313,16,8283,8192,65,10361,5392,4176,10281,1365,8200,256,113,5488,8824]

theorem envBound27326 : H12AffineFastState.Bounded env27326 := by
  intro p hp
  have h : env27326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27325_27326 : H12AffineEnvironment.transform 14 8572 env27325 = env27326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8572 env27325 == env27326) = true)

theorem identity27326 : scanCanonicalize (H12AffineFastState.compose env27326 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound27326 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27327 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5156,8200,114,5220,2161,1024,8201,4160,8313,16,8283,8192,65,10361,5220,4176,10281,1057,8200,116,113,5124,8824]

theorem envBound27327 : H12AffineFastState.Bounded env27327 := by
  intro p hp
  have h : env27327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27326_27327 : H12AffineEnvironment.transform 7 116 env27326 = env27327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env27326 == env27327) = true)

theorem identity27327 : scanCanonicalize (H12AffineFastState.compose env27327 (packedSelected [0,3,5,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound27327 : packedSelected [0,3,5,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env27328 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8,5156,0,114,5220,2161,1024,1,4160,113,16,83,8,65,2161,5220,4176,2081,1057,0,116,113,5124,624]

theorem envBound27328 : H12AffineFastState.Bounded env27328 := by
  intro p hp
  have h : env27328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27327_27328 : H12AffineEnvironment.transform 12 8 env27327 = env27328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env27327 == env27328) = true)

theorem identity27328 : scanCanonicalize (H12AffineFastState.compose env27328 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound27328 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27329 : List Nat := [2,4,8,16,32,48,8,4,512,1024,2048,4096,8,5156,0,2,5140,2049,1024,1,4144,1,16,35,8,49,2049,5140,4128,2081,1057,0,4,1,5124,512]

theorem envBound27329 : H12AffineFastState.Bounded env27329 := by
  intro p hp
  have h : env27329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27328_27329 : H12AffineEnvironment.transform 5 48 env27328 = env27329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env27328 == env27329) = true)

theorem identity27329 : scanCanonicalize (H12AffineFastState.compose env27329 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27329 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27330 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,8,5125,0,2,5140,2049,1024,1,4113,1,16,2,8,16,2049,5140,4097,2048,1024,0,4,1,5124,512]

theorem envBound27330 : H12AffineFastState.Bounded env27330 := by
  intro p hp
  have h : env27330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27329_27330 : H12AffineEnvironment.transform 4 1 env27329 = env27330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27329 == env27330) = true)

def env27331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,98644,8193,65,4237692,5392,17664,10280,1364,4256861,256,21793,46093,74250]

theorem envBound27331 : H12AffineFastState.Bounded env27331 := by
  intro p hp
  have h : env27331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27320_27331 : H12AffineEnvironment.transform 6 9 env27320 = env27331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27320 == env27331) = true)

theorem identity27331 : scanCanonicalize (H12AffineFastState.compose env27331 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound27331 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67619,1024,32769,4160,4194304,16,98644,8193,65,4237692,5392,17664,10280,1364,4256861,256,21793,46093,74250]

theorem envBound27332 : H12AffineFastState.Bounded env27332 := by
  intro p hp
  have h : env27332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27331_27332 : H12AffineEnvironment.transform 16 122907 env27331 = env27332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env27331 == env27332) = true)

theorem identity27332 : scanCanonicalize (H12AffineFastState.compose env27332 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound27332 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67619,1024,32769,4160,32801,16,98644,8193,65,10589,5392,17664,10280,1364,29820,256,21793,46093,74250]

theorem envBound27333 : H12AffineFastState.Bounded env27333 := by
  intro p hp
  have h : env27333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27332_27333 : H12AffineEnvironment.transform 21 32801 env27332 = env27333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env27332 == env27333) = true)

theorem identity27333 : scanCanonicalize (H12AffineFastState.compose env27333 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound27333 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env27334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56436,1024,32769,4160,32801,16,21763,8193,65,10589,5392,17664,10280,1364,29820,256,21793,46093,63069]

theorem envBound27334 : H12AffineFastState.Bounded env27334 := by
  intro p hp
  have h : env27334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27333_27334 : H12AffineEnvironment.transform 15 54359 env27333 = env27334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env27333 == env27334) = true)

theorem identity27334 : scanCanonicalize (H12AffineFastState.compose env27334 (packedSelected [2,3,5,6,14,15,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27334 : packedSelected [2,3,5,6,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env27335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54359,5392,56436,1024,32769,4160,32801,16,21763,349,65,2049,5392,17664,2420,1364,21792,256,21793,38225,55041]

theorem envBound27335 : H12AffineFastState.Bounded env27335 := by
  intro p hp
  have h : env27335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27334_27335 : H12AffineEnvironment.transform 12 348 env27334 = env27335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27334 == env27335) = true)

theorem identity27335 : scanCanonicalize (H12AffineFastState.compose env27335 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound27335 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env27336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,80,21511,5392,23588,1024,81,4160,113,16,21763,349,65,2049,5392,17664,2420,1364,21792,256,21793,5377,22353]

theorem envBound27336 : H12AffineFastState.Bounded env27336 := by
  intro p hp
  have h : env27336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27335_27336 : H12AffineEnvironment.transform 14 80 env27335 = env27336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env27335 == env27336) = true)

theorem identity27336 : scanCanonicalize (H12AffineFastState.compose env27336 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound27336 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,80,343,5392,2420,1024,81,4160,113,16,83,349,65,2049,5392,4176,2420,1364,112,256,113,5377,513]

theorem envBound27337 : H12AffineFastState.Bounded env27337 := by
  intro p hp
  have h : env27337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27336_27337 : H12AffineEnvironment.transform 13 5456 env27336 = env27337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env27336 == env27337) = true)

theorem identity27337 : scanCanonicalize (H12AffineFastState.compose env27337 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound27337 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env27338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,97,4096,348,5456,80,343,5392,277,1024,81,4160,113,16,83,349,65,96,5392,4176,277,1364,112,256,113,5377,513]

theorem envBound27338 : H12AffineFastState.Bounded env27338 := by
  intro p hp
  have h : env27338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27337_27338 : H12AffineEnvironment.transform 10 97 env27337 = env27338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env27337 == env27338) = true)

theorem identity27338 : scanCanonicalize (H12AffineFastState.compose env27338 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27338 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27339 : List Nat := [2,4,8,16,32,16,9,256,512,1024,49,4096,268,5376,0,263,5392,277,1024,1,4112,33,16,3,269,17,48,5392,4096,277,1284,32,256,33,5377,513]

theorem envBound27339 : H12AffineFastState.Bounded env27339 := by
  intro p hp
  have h : env27339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27338_27339 : H12AffineEnvironment.transform 5 16 env27338 = env27339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27338 == env27339) = true)

theorem identity27339 : scanCanonicalize (H12AffineFastState.compose env27339 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound27339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27340 : List Nat := [2,4,8,16,32,16,9,256,512,1024,49,276,268,1044,0,263,1028,277,1024,1,260,33,16,3,269,17,48,1028,276,277,1284,32,256,33,1045,513]

theorem envBound27340 : H12AffineFastState.Bounded env27340 := by
  intro p hp
  have h : env27340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27339_27340 : H12AffineEnvironment.transform 11 276 env27339 = env27340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env27339 == env27340) = true)

theorem identity27340 : scanCanonicalize (H12AffineFastState.compose env27340 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound27340 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27341 : List Nat := [2,4,8,16,32,16,9,256,512,304,49,276,268,292,0,263,308,277,304,1,260,33,16,3,269,17,48,308,276,277,52,32,256,33,293,513]

theorem envBound27341 : H12AffineFastState.Bounded env27341 := by
  intro p hp
  have h : env27341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27340_27341 : H12AffineEnvironment.transform 9 304 env27340 = env27341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env27340 == env27341) = true)

theorem identity27341 : scanCanonicalize (H12AffineFastState.compose env27341 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound27341 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27342 : List Nat := [2,4,8,16,32,16,9,256,293,304,49,276,268,292,0,263,308,277,304,1,260,33,16,3,269,17,48,308,276,277,52,32,256,33,293,292]

theorem envBound27342 : H12AffineFastState.Bounded env27342 := by
  intro p hp
  have h : env27342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27341_27342 : H12AffineEnvironment.transform 8 293 env27341 = env27342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env27341 == env27342) = true)

theorem identity27342 : scanCanonicalize (H12AffineFastState.compose env27342 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27342 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27343 : List Nat := [2,4,8,16,17,16,9,256,276,257,0,276,268,277,0,263,261,277,257,1,260,16,16,3,269,17,1,261,276,277,5,17,256,16,276,277]

theorem envBound27343 : H12AffineFastState.Bounded env27343 := by
  intro p hp
  have h : env27343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27342_27343 : H12AffineEnvironment.transform 4 17 env27342 = env27343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27342 == env27343) = true)

theorem identity27343 : scanCanonicalize (H12AffineFastState.compose env27343 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27344 : List Nat := [2,4,8,0,1,0,9,256,260,257,0,260,268,261,0,263,261,261,257,1,260,0,0,3,269,1,1,261,260,261,5,1,256,0,260,261]

theorem envBound27344 : H12AffineFastState.Bounded env27344 := by
  intro p hp
  have h : env27344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27343_27344 : H12AffineEnvironment.transform 3 0 env27343 = env27344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27343 == env27344) = true)

theorem identity27344 : scanCanonicalize (H12AffineFastState.compose env27344 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27344 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27345 : List Nat := [2,4,3,0,1,0,2,256,260,257,0,260,263,261,0,263,261,261,257,1,260,0,0,3,262,1,1,261,260,261,5,1,256,0,260,261]

theorem envBound27345 : H12AffineFastState.Bounded env27345 := by
  intro p hp
  have h : env27345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27344_27345 : H12AffineEnvironment.transform 2 3 env27344 = env27345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27344 == env27345) = true)

def env27346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,17,98781,8328,65,4237693,5393,17664,10400,1500,4256860,256,21793,46212,74251]

theorem envBound27346 : H12AffineFastState.Bounded env27346 := by
  intro p hp
  have h : env27346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27319_27346 : H12AffineEnvironment.transform 20 4161 env27319 = env27346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27319 == env27346) = true)

theorem identity27346 : scanCanonicalize (H12AffineFastState.compose env27346 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180273) := by decide +kernel

theorem selectedBound27346 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,180273,17,98781,8328,65,158028,5393,17664,10400,1500,144493,256,21793,46212,74251]

theorem envBound27347 : H12AffineFastState.Bounded env27347 := by
  intro p hp
  have h : env27347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27346_27347 : H12AffineEnvironment.transform 21 180273 env27346 = env27347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env27346 == env27347) = true)

theorem identity27347 : scanCanonicalize (H12AffineFastState.compose env27347 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27347 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env27348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190641,1024,32769,4161,180273,17,41431,8328,65,158028,5393,17664,10400,1500,144493,256,21793,46212,513]

theorem envBound27348 : H12AffineFastState.Bounded env27348 := by
  intro p hp
  have h : env27348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27347_27348 : H12AffineEnvironment.transform 15 8202 env27347 = env27348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27347 == env27348) = true)

theorem identity27348 : scanCanonicalize (H12AffineFastState.compose env27348 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound27348 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43168,1024,32769,4161,32800,17,41431,8328,65,10589,5393,17664,10400,1500,29820,256,21793,46212,513]

theorem envBound27349 : H12AffineFastState.Bounded env27349 := by
  intro p hp
  have h : env27349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27348_27349 : H12AffineEnvironment.transform 16 16401 env27348 = env27349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env27348 == env27349) = true)

theorem identity27349 : scanCanonicalize (H12AffineFastState.compose env27349 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound27349 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env27350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,16401,23725,1024,29708,4161,29741,17,21978,8328,65,10589,5393,17664,10400,1500,29820,256,21793,16521,513]

theorem envBound27350 : H12AffineFastState.Bounded env27350 := by
  intro p hp
  have h : env27350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27349_27350 : H12AffineEnvironment.transform 14 29709 env27349 = env27350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env27349 == env27350) = true)

theorem identity27350 : scanCanonicalize (H12AffineFastState.compose env27350 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27350 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env27351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8202,16401,23589,1024,29708,4161,29741,17,21842,8192,65,10589,5393,17664,10280,1364,29820,256,21793,16385,513]

theorem envBound27351 : H12AffineFastState.Bounded env27351 := by
  intro p hp
  have h : env27351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27350_27351 : H12AffineEnvironment.transform 6 8 env27350 = env27351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27350 == env27351) = true)

theorem identity27351 : scanCanonicalize (H12AffineFastState.compose env27351 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound27351 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env27352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4452,9577,8202,4469,3393,1024,9576,4161,9545,17,1078,8192,65,10589,5393,5220,10280,1364,9496,256,1093,4453,513]

theorem envBound27352 : H12AffineFastState.Bounded env27352 := by
  intro p hp
  have h : env27352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27351_27352 : H12AffineEnvironment.transform 13 4452 env27351 = env27352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env27351 == env27352) = true)

theorem identity27352 : scanCanonicalize (H12AffineFastState.compose env27352 (packedSelected [2,3,4,6,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27352 : packedSelected [2,3,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env27353 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,4405,9528,8202,4388,3344,1024,9529,4112,9496,17,1078,8192,16,10508,5393,5173,10280,1285,9496,256,1044,4404,513]

theorem envBound27353 : H12AffineFastState.Bounded env27353 := by
  intro p hp
  have h : env27353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27352_27353 : H12AffineEnvironment.transform 5 17 env27352 = env27353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27352 == env27353) = true)

theorem identity27353 : scanCanonicalize (H12AffineFastState.compose env27353 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound27353 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env27354 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1052,4405,292,1046,4388,3344,1024,293,4112,260,17,1078,1052,16,3344,5393,5173,3124,1285,260,256,1044,4404,513]

theorem envBound27354 : H12AffineFastState.Bounded env27354 := by
  intro p hp
  have h : env27354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27353_27354 : H12AffineEnvironment.transform 12 1052 env27353 = env27354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env27353 == env27354) = true)

theorem identity27354 : scanCanonicalize (H12AffineFastState.compose env27354 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27354 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27355 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,40,4405,292,34,4388,2340,52,293,4112,260,17,2,40,16,2340,4389,4097,2048,305,260,256,32,4404,513]

theorem envBound27355 : H12AffineFastState.Bounded env27355 := by
  intro p hp
  have h : env27355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27354_27355 : H12AffineEnvironment.transform 9 52 env27354 = env27355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27354 == env27355) = true)

theorem identity27355 : scanCanonicalize (H12AffineFastState.compose env27355 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27355 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27356 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,4096,40,4113,0,34,4096,2048,52,1,4112,32,17,2,40,16,2048,4097,4097,2048,21,32,36,32,4112,513]

theorem envBound27356 : H12AffineFastState.Bounded env27356 := by
  intro p hp
  have h : env27356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27355_27356 : H12AffineEnvironment.transform 7 36 env27355 = env27356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27355 == env27356) = true)

theorem identity27356 : scanCanonicalize (H12AffineFastState.compose env27356 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound27356 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27357 : List Nat := [2,4,8,16,32,17,8,36,512,52,2048,2049,40,2064,0,34,2049,2048,52,1,2065,32,17,2,40,16,2048,2048,2048,2048,21,32,36,32,2065,513]

theorem envBound27357 : H12AffineFastState.Bounded env27357 := by
  intro p hp
  have h : env27357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27356_27357 : H12AffineEnvironment.transform 11 2049 env27356 = env27357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env27356 == env27357) = true)

theorem identity27357 : scanCanonicalize (H12AffineFastState.compose env27357 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27357 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27358 : List Nat := [2,4,8,16,11,17,8,15,512,31,2048,2049,3,2064,0,9,2049,2048,31,1,2065,11,17,2,3,16,2048,2048,2048,2048,21,11,15,11,2065,513]

theorem envBound27358 : H12AffineFastState.Bounded env27358 := by
  intro p hp
  have h : env27358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27357_27358 : H12AffineEnvironment.transform 4 11 env27357 = env27358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27357 == env27358) = true)

theorem identity27358 : scanCanonicalize (H12AffineFastState.compose env27358 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound27358 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27359 : List Nat := [2,4,8,16,11,17,8,15,512,31,17,16,3,1,0,9,16,17,31,1,0,11,17,2,3,16,17,17,17,17,21,11,15,11,0,513]

theorem envBound27359 : H12AffineFastState.Bounded env27359 := by
  intro p hp
  have h : env27359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27358_27359 : H12AffineEnvironment.transform 10 17 env27358 = env27359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env27358 == env27359) = true)

theorem identity27359 : scanCanonicalize (H12AffineFastState.compose env27359 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27359 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27360 : List Nat := [2,4,8,0,11,1,8,15,512,15,1,0,3,1,0,9,0,1,15,1,0,11,1,2,3,0,1,1,1,1,5,11,15,11,0,513]

theorem envBound27360 : H12AffineFastState.Bounded env27360 := by
  intro p hp
  have h : env27360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27359_27360 : H12AffineEnvironment.transform 3 0 env27359 = env27360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27359 == env27360) = true)

def env27361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound27361 : H12AffineFastState.Bounded env27361 := by
  intro p hp
  have h : env27361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27210_27361 : H12AffineEnvironment.transform 18 1025 env27210 = env27361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env27210 == env27361) = true)

theorem identity27361 : scanCanonicalize (H12AffineFastState.compose env27361 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 297453) := by decide +kernel

theorem selectedBound27361 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,297453,16777216,8328,65,21187052,18973836,2415805,149996,17108477,23160256,257,19221824,19246308,17050155]

theorem envBound27362 : H12AffineFastState.Bounded env27362 := by
  intro p hp
  have h : env27362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27361_27362 : H12AffineEnvironment.transform 22 297453 env27361 = env27362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297453 env27361 == env27362) = true)

def env27363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182764,1025,32769,2097152,4194304,147457,16777216,8328,65,21187052,18973836,2233681,149996,17024017,23160256,257,19104940,19096840,16966599]

theorem envBound27363 : H12AffineFastState.Bounded env27363 := by
  intro p hp
  have h : env27363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27362_27363 : H12AffineEnvironment.transform 17 182764 env27362 = env27363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182764 env27362 == env27363) = true)

theorem identity27363 : scanCanonicalize (H12AffineFastState.compose env27363 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound27363 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

end H12CloudChart0