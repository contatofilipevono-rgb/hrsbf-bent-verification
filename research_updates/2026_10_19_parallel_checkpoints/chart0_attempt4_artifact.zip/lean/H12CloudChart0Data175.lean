import H12CloudChart0Data174

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env44332 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,262144,1024,8461,4113,33,16,3,8193,16,398388,5392,4096,406556,1284,32,256,33,5377,513]

theorem envBound44332 : H12AffineFastState.Bounded env44332 := by
  intro p hp
  have h : env44332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44331_44332 : H12AffineEnvironment.transform 5 16 env44331 = env44332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44331 == env44332) = true)

theorem identity44332 : scanCanonicalize (H12AffineFastState.compose env44332 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound44332 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44333 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,138292,1024,8461,4113,33,16,3,8193,16,2048,5392,4096,10280,1284,32,256,33,5377,513]

theorem envBound44333 : H12AffineFastState.Bounded env44333 := by
  intro p hp
  have h : env44333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44332_44333 : H12AffineEnvironment.transform 17 138292 env44332 = env44333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env44332 == env44333) = true)

theorem identity44333 : scanCanonicalize (H12AffineFastState.compose env44333 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound44333 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env44334 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,13340,10280,1024,8461,4113,33,16,3,8193,16,2048,5392,4096,10280,1284,32,256,33,5377,513]

theorem envBound44334 : H12AffineFastState.Bounded env44334 := by
  intro p hp
  have h : env44334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44333_44334 : H12AffineEnvironment.transform 16 13340 env44333 = env44334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env44333 == env44334) = true)

theorem identity44334 : scanCanonicalize (H12AffineFastState.compose env44334 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44334 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env44335 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5392,2340,1024,1,4113,33,16,3,269,16,2048,5392,4096,2340,1284,32,256,33,5377,513]

theorem envBound44335 : H12AffineFastState.Bounded env44335 := by
  intro p hp
  have h : env44335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44334_44335 : H12AffineEnvironment.transform 12 268 env44334 = env44335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44334 == env44335) = true)

theorem identity44335 : scanCanonicalize (H12AffineFastState.compose env44335 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44336 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,35,5173,2049,1024,1,4113,33,16,3,40,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound44336 : H12AffineFastState.Bounded env44336 := by
  intro p hp
  have h : env44336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44335_44336 : H12AffineEnvironment.transform 7 37 env44335 = env44336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44335 == env44336) = true)

def env44337 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,0,35,1029,2049,1024,1,33,33,16,3,40,16,2048,1029,48,2049,1057,32,37,33,1044,513]

theorem envBound44337 : H12AffineFastState.Bounded env44337 := by
  intro p hp
  have h : env44337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44336_44337 : H12AffineEnvironment.transform 11 48 env44336 = env44337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44336 == env44337) = true)

def env44338 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,48,41,32,0,35,49,2049,52,1,33,33,16,3,40,16,2048,49,48,2049,21,32,37,33,32,513]

theorem envBound44338 : H12AffineFastState.Bounded env44338 := by
  intro p hp
  have h : env44338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44337_44338 : H12AffineEnvironment.transform 9 52 env44337 = env44338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44337 == env44338) = true)

theorem identity44338 : scanCanonicalize (H12AffineFastState.compose env44338 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound44338 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44339 : List Nat := [2,4,8,16,32,16,9,37,10,52,2048,48,41,32,0,35,49,2049,52,1,33,33,16,3,40,16,2048,49,48,2049,21,32,37,33,32,11]

theorem envBound44339 : H12AffineFastState.Bounded env44339 := by
  intro p hp
  have h : env44339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44338_44339 : H12AffineEnvironment.transform 8 10 env44338 = env44339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env44338 == env44339) = true)

def leafEnv44339 : List Nat := [2,4,8,16,32,16,9,37,10,52,2048,48,41,32,0,35,49,2049,52,1,33,33,16,3,21,40,1,16,2048,49,48,2049,21,32,37,33,4,34,32,11,1,33,0]

def active44339 : List Nat := [0,1,2,3,4,10]

def tree44339 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44339 : H12WitnessSearch.Good tree44339 := H12GlobalWitnessIndex.good

theorem leafIdentity44339 : H12AffineFastState.composeSystem env44339 rootObs = leafEnv44339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44339 rootObs == leafEnv44339) = true)

theorem terminalChecked44339 : H12PackedTerminal.terminalCheckFast leafEnv44339 active44339 tree44339 = true := by decide +kernel

def env44340 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,48,41,33,0,35,48,2049,53,1,33,33,16,3,40,16,2048,48,48,2049,20,32,37,33,33,513]

theorem envBound44340 : H12AffineFastState.Bounded env44340 := by
  intro p hp
  have h : env44340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44337_44340 : H12AffineEnvironment.transform 9 53 env44337 = env44340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44337 == env44340) = true)

theorem identity44340 : scanCanonicalize (H12AffineFastState.compose env44340 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44340 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44341 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,9,1,0,3,16,2049,21,1,1,1,16,3,8,16,2048,16,16,2049,20,0,5,1,1,513]

theorem envBound44341 : H12AffineFastState.Bounded env44341 := by
  intro p hp
  have h : env44341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44340_44341 : H12AffineEnvironment.transform 4 0 env44340 = env44341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44340 == env44341) = true)

def leafEnv44341 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,9,1,0,3,16,2049,21,1,1,1,16,3,20,8,1,16,2048,16,16,2049,20,0,5,1,4,2,1,513,1,1,0]

def active44341 : List Nat := [0,1,2,3,8,10]

def tree44341 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44341 : H12WitnessSearch.Good tree44341 := H12GlobalWitnessIndex.good

theorem leafIdentity44341 : H12AffineFastState.composeSystem env44341 rootObs = leafEnv44341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44341 rootObs == leafEnv44341) = true)

theorem terminalChecked44341 : H12PackedTerminal.terminalCheckFast leafEnv44341 active44341 tree44341 = true := by decide +kernel

def env44342 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,0,35,1028,2049,1024,1,32,33,16,3,40,16,2048,1028,49,2049,1057,32,37,33,1045,513]

theorem envBound44342 : H12AffineFastState.Bounded env44342 := by
  intro p hp
  have h : env44342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44336_44342 : H12AffineEnvironment.transform 11 49 env44336 = env44342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44336 == env44342) = true)

theorem identity44342 : scanCanonicalize (H12AffineFastState.compose env44342 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44342 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44343 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,49,41,33,0,35,48,2049,52,1,32,33,16,3,40,16,2048,48,49,2049,21,32,37,33,33,513]

theorem envBound44343 : H12AffineFastState.Bounded env44343 := by
  intro p hp
  have h : env44343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44342_44343 : H12AffineEnvironment.transform 9 52 env44342 = env44343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44342 == env44343) = true)

theorem identity44343 : scanCanonicalize (H12AffineFastState.compose env44343 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound44343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44344 : List Nat := [2,4,8,16,32,16,9,37,11,52,2048,49,41,33,0,35,48,2049,52,1,32,33,16,3,40,16,2048,48,49,2049,21,32,37,33,33,10]

theorem envBound44344 : H12AffineFastState.Bounded env44344 := by
  intro p hp
  have h : env44344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44343_44344 : H12AffineEnvironment.transform 8 11 env44343 = env44344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env44343 == env44344) = true)

def leafEnv44344 : List Nat := [2,4,8,16,32,16,9,37,11,52,2048,49,41,33,0,35,48,2049,52,1,32,33,16,3,21,40,1,16,2048,48,49,2049,21,32,37,33,4,34,33,10,1,32,0]

def active44344 : List Nat := [0,1,2,3,4,10]

def tree44344 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44344 : H12WitnessSearch.Good tree44344 := H12GlobalWitnessIndex.good

theorem leafIdentity44344 : H12AffineFastState.composeSystem env44344 rootObs = leafEnv44344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44344 rootObs == leafEnv44344) = true)

theorem terminalChecked44344 : H12PackedTerminal.terminalCheckFast leafEnv44344 active44344 tree44344 = true := by decide +kernel

def env44345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98644,8328,64,6685700,2098649,4097,2524496,2102684,6336797,256,168,46212,2175562]

theorem envBound44345 : H12AffineFastState.Bounded env44345 := by
  intro p hp
  have h : env44345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44286_44345 : H12AffineEnvironment.transform 22 2101465 env44286 = env44345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env44286 == env44345) = true)

def env44346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98644,8328,64,2491428,2098649,4097,2524496,2102684,2142525,256,168,46212,2175562]

theorem envBound44346 : H12AffineFastState.Bounded env44346 := by
  intro p hp
  have h : env44346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44345_44346 : H12AffineEnvironment.transform 21 32 env44345 = env44346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44345 == env44346) = true)

theorem identity44346 : scanCanonicalize (H12AffineFastState.compose env44346 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44346 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,262144,1024,8541,2097152,32,2101465,73736,8328,64,2491428,2098649,4097,2499596,2102684,2101345,256,168,5592,2175562]

theorem envBound44347 : H12AffineFastState.Bounded env44347 := by
  intro p hp
  have h : env44347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44346_44347 : H12AffineEnvironment.transform 14 8540 env44346 = env44347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44346 == env44347) = true)

def env44348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10400,1024,8541,2097152,32,2101465,73736,8328,64,2239620,2098649,4097,2231468,2102684,2101345,256,168,5592,2175562]

theorem envBound44348 : H12AffineFastState.Bounded env44348 := by
  intro p hp
  have h : env44348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44347_44348 : H12AffineEnvironment.transform 17 10400 env44347 = env44348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env44347 == env44348) = true)

theorem identity44348 : scanCanonicalize (H12AffineFastState.compose env44348 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4297) := by decide +kernel

theorem selectedBound44348 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10400,1024,8541,4297,32,16,73736,8328,64,146509,5392,4097,138341,1365,168,256,168,5592,74371]

theorem envBound44349 : H12AffineFastState.Bounded env44349 := by
  intro p hp
  have h : env44349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44348_44349 : H12AffineEnvironment.transform 20 4297 env44348 = env44349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4297 env44348 == env44349) = true)

theorem identity44349 : scanCanonicalize (H12AffineFastState.compose env44349 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound44349 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,5393,10400,1024,8541,4297,32,16,73736,8328,64,10588,5392,4097,2420,1365,168,256,168,5592,74371]

theorem envBound44350 : H12AffineFastState.Bounded env44350 := by
  intro p hp
  have h : env44350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44349_44350 : H12AffineEnvironment.transform 16 5393 env44349 = env44350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env44349 == env44350) = true)

theorem identity44350 : scanCanonicalize (H12AffineFastState.compose env44350 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound44350 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8322,5393,10400,1024,8541,4297,32,16,138,8328,64,10588,5392,4097,2420,1365,168,256,168,5592,513]

theorem envBound44351 : H12AffineFastState.Bounded env44351 := by
  intro p hp
  have h : env44351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44350_44351 : H12AffineEnvironment.transform 15 8322 env44350 = env44351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env44350 == env44351) = true)

theorem identity44351 : scanCanonicalize (H12AffineFastState.compose env44351 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound44351 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env44352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2184,8540,8322,2065,10400,1024,8541,3529,32,16,138,8328,64,10588,2064,3329,2420,1365,168,256,168,2264,513]

theorem envBound44352 : H12AffineFastState.Bounded env44352 := by
  intro p hp
  have h : env44352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44351_44352 : H12AffineEnvironment.transform 11 3328 env44351 = env44352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env44351 == env44352) = true)

theorem identity44352 : scanCanonicalize (H12AffineFastState.compose env44352 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44352 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env44353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1281,8192,137,8540,8322,16,8353,1024,8541,1480,32,16,138,8328,64,8541,17,1280,373,1365,168,256,168,217,513]

theorem envBound44353 : H12AffineFastState.Bounded env44353 := by
  intro p hp
  have h : env44353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44352_44353 : H12AffineEnvironment.transform 10 1 env44352 = env44353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44352 == env44353) = true)

theorem identity44353 : scanCanonicalize (H12AffineFastState.compose env44353 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound44353 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env44354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1281,1337,137,1125,1467,16,1432,1024,1124,1480,32,16,138,1457,64,1124,17,1280,373,1365,168,256,168,217,513]

theorem envBound44354 : H12AffineFastState.Bounded env44354 := by
  intro p hp
  have h : env44354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44353_44354 : H12AffineEnvironment.transform 12 1337 env44353 = env44354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env44353 == env44354) = true)

theorem identity44354 : scanCanonicalize (H12AffineFastState.compose env44354 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound44354 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env44355 : List Nat := [2,4,8,16,32,64,128,256,512,188,1,445,389,137,217,263,16,292,188,216,372,32,16,138,269,64,216,17,444,373,489,168,256,168,217,513]

theorem envBound44355 : H12AffineFastState.Bounded env44355 := by
  intro p hp
  have h : env44355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44354_44355 : H12AffineEnvironment.transform 9 188 env44354 = env44355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env44354 == env44355) = true)

theorem identity44355 : scanCanonicalize (H12AffineFastState.compose env44355 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44355 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env44356 : List Nat := [2,4,8,16,32,64,8,256,512,52,1,309,269,1,81,263,16,292,52,80,372,32,16,2,269,64,80,17,308,373,353,32,256,32,81,513]

theorem envBound44356 : H12AffineFastState.Bounded env44356 := by
  intro p hp
  have h : env44356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44355_44356 : H12AffineEnvironment.transform 6 8 env44355 = env44356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44355 == env44356) = true)

theorem identity44356 : scanCanonicalize (H12AffineFastState.compose env44356 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44356 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44357 : List Nat := [2,4,8,16,32,64,8,36,512,52,1,17,41,1,81,35,16,0,52,80,80,32,16,2,41,64,80,17,16,81,69,32,36,32,81,513]

theorem envBound44357 : H12AffineFastState.Bounded env44357 := by
  intro p hp
  have h : env44357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44356_44357 : H12AffineEnvironment.transform 7 36 env44356 = env44357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44356 == env44357) = true)

def env44358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10401,1024,8541,2097152,32,2101465,73736,8328,64,2239621,2098649,4097,2231469,2102684,2101345,256,168,5592,2175562]

theorem envBound44358 : H12AffineFastState.Bounded env44358 := by
  intro p hp
  have h : env44358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44347_44358 : H12AffineEnvironment.transform 17 10401 env44347 = env44358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env44347 == env44358) = true)

def env44359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10401,1024,8541,132432,32,136585,73736,8328,64,10709,131209,4097,2557,135372,136497,256,168,5592,210714]

theorem envBound44359 : H12AffineFastState.Bounded env44359 := by
  intro p hp
  have h : env44359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44358_44359 : H12AffineEnvironment.transform 20 132432 env44358 = env44359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132432 env44358 == env44359) = true)

theorem identity44359 : scanCanonicalize (H12AffineFastState.compose env44359 (packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound44359 : packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env44360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8323,131072,10401,1024,8541,132432,32,136585,139,8328,64,10709,131209,4097,2557,135372,136497,256,168,5592,137113]

theorem envBound44360 : H12AffineFastState.Bounded env44360 := by
  intro p hp
  have h : env44360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44359_44360 : H12AffineEnvironment.transform 15 8323 env44359 = env44360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env44359 == env44360) = true)

theorem identity44360 : scanCanonicalize (H12AffineFastState.compose env44360 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound44360 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8323,5392,10401,1024,8541,4160,32,153,139,8328,64,10709,5529,4097,2557,1500,33,256,168,5592,649]

theorem envBound44361 : H12AffineFastState.Bounded env44361 := by
  intro p hp
  have h : env44361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44360_44361 : H12AffineEnvironment.transform 16 5392 env44360 = env44361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env44360 == env44361) = true)

theorem identity44361 : scanCanonicalize (H12AffineFastState.compose env44361 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44361 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44362 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5373,8233,8323,5221,10401,1024,8232,4160,32,153,139,8328,64,10400,5356,4097,2184,1193,33,117,168,5293,649]

theorem envBound44362 : H12AffineFastState.Bounded env44362 := by
  intro p hp
  have h : env44362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44361_44362 : H12AffineEnvironment.transform 7 117 env44361 = env44362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44361 == env44362) = true)

theorem identity44362 : scanCanonicalize (H12AffineFastState.compose env44362 (packedSelected [6,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound44362 : packedSelected [6,11,14,18] rootPS < 2^1333 := by decide +kernel

def env44363 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,240,5373,217,115,5221,2129,1024,216,4160,32,153,139,120,64,2128,5356,4097,2184,1193,33,117,168,5293,649]

theorem envBound44363 : H12AffineFastState.Bounded env44363 := by
  intro p hp
  have h : env44363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44362_44363 : H12AffineEnvironment.transform 12 240 env44362 = env44363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env44362 == env44363) = true)

def env44364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10401,1024,8541,132433,32,136584,73736,8328,64,10708,131208,4097,2556,135373,136496,256,168,5592,210715]

theorem envBound44364 : H12AffineFastState.Bounded env44364 := by
  intro p hp
  have h : env44364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44358_44364 : H12AffineEnvironment.transform 20 132433 env44358 = env44364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132433 env44358 == env44364) = true)

theorem identity44364 : scanCanonicalize (H12AffineFastState.compose env44364 (packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound44364 : packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env44365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,70862,10401,1024,8541,70047,32,65862,73736,8328,64,10708,70726,4097,2556,66563,66046,256,168,5592,9173]

theorem envBound44365 : H12AffineFastState.Bounded env44365 := by
  intro p hp
  have h : env44365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44364_44365 : H12AffineEnvironment.transform 16 70862 env44364 = env44365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env44364 == env44365) = true)

def env44366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98644,8328,64,2491429,2098649,4097,2524496,2102684,2142524,256,168,46212,2175562]

theorem envBound44366 : H12AffineFastState.Bounded env44366 := by
  intro p hp
  have h : env44366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44345_44366 : H12AffineEnvironment.transform 21 33 env44345 = env44366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44345 == env44366) = true)

theorem identity44366 : scanCanonicalize (H12AffineFastState.compose env44366 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45461) := by decide +kernel

theorem selectedBound44366 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,45461,33,41292,98644,8328,64,439728,46156,4097,406725,41993,169,256,168,46212,99295]

theorem envBound44367 : H12AffineFastState.Bounded env44367 := by
  intro p hp
  have h : env44367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44366_44367 : H12AffineEnvironment.transform 20 45461 env44366 = env44367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45461 env44366 == env44367) = true)

theorem identity44367 : scanCanonicalize (H12AffineFastState.compose env44367 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound44367 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env44368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,108927,1024,32769,45461,33,41292,98644,8328,64,203983,46156,4097,236986,41993,169,256,168,46212,99295]

theorem envBound44368 : H12AffineFastState.Bounded env44368 := by
  intro p hp
  have h : env44368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44367_44368 : H12AffineEnvironment.transform 17 108927 env44367 = env44368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env44367 == env44368) = true)

theorem identity44368 : scanCanonicalize (H12AffineFastState.compose env44368 (packedSelected [1,3,4,7,9,11,12,15,18,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound44368 : packedSelected [1,3,4,7,9,11,12,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env44369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,131072,10401,1024,32769,45461,33,41292,138,8328,64,171281,46156,4097,138340,41993,169,256,168,46212,513]

theorem envBound44369 : H12AffineFastState.Bounded env44369 := by
  intro p hp
  have h : env44369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44368_44369 : H12AffineEnvironment.transform 15 33246 env44368 = env44369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env44368 == env44369) = true)

theorem identity44369 : scanCanonicalize (H12AffineFastState.compose env44369 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound44369 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env44370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33246,13341,10401,1024,32769,45461,33,41292,138,8328,64,43276,46156,4097,10361,41993,169,256,168,46212,513]

theorem envBound44370 : H12AffineFastState.Bounded env44370 := by
  intro p hp
  have h : env44370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44369_44370 : H12AffineEnvironment.transform 16 13341 env44369 = env44370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env44369 == env44370) = true)

theorem identity44370 : scanCanonicalize (H12AffineFastState.compose env44370 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound44370 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env44371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,216,262,13341,10401,1024,217,12621,33,8596,138,8328,64,10708,13460,4097,10361,9425,169,256,168,13404,513]

theorem envBound44371 : H12AffineFastState.Bounded env44371 := by
  intro p hp
  have h : env44371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44370_44371 : H12AffineEnvironment.transform 14 216 env44370 = env44371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env44370 == env44371) = true)

theorem identity44371 : scanCanonicalize (H12AffineFastState.compose env44371 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound44371 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env44372 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5457,1,262,13341,10360,1024,0,12621,33,8525,83,8273,64,10509,13389,4097,10361,9224,112,256,113,13404,513]

theorem envBound44372 : H12AffineFastState.Bounded env44372 := by
  intro p hp
  have h : env44372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44371_44372 : H12AffineEnvironment.transform 6 89 env44371 = env44372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env44371 == env44372) = true)

theorem identity44372 : scanCanonicalize (H12AffineFastState.compose env44372 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44372 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44373 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,1,262,5393,2420,1024,0,4161,33,65,83,349,64,2049,5441,4097,2421,1284,112,256,113,5456,513]

theorem envBound44373 : H12AffineFastState.Bounded env44373 := by
  intro p hp
  have h : env44373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44372_44373 : H12AffineEnvironment.transform 12 268 env44372 = env44373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44372 == env44373) = true)

theorem identity44373 : scanCanonicalize (H12AffineFastState.compose env44373 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44373 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44374 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1024,0,4112,33,16,2,268,17,2049,5392,4097,2340,1284,33,256,32,5377,513]

theorem envBound44374 : H12AffineFastState.Bounded env44374 := by
  intro p hp
  have h : env44374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44373_44374 : H12AffineEnvironment.transform 5 17 env44373 = env44374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44373 == env44374) = true)

theorem identity44374 : scanCanonicalize (H12AffineFastState.compose env44374 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44374 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44375 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,268,4113,1,262,4096,2341,273,0,4112,33,16,2,268,17,2049,4097,4097,2340,21,33,256,32,4112,513]

theorem envBound44375 : H12AffineFastState.Bounded env44375 := by
  intro p hp
  have h : env44375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44374_44375 : H12AffineEnvironment.transform 9 273 env44374 = env44375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44374 == env44375) = true)

theorem identity44375 : scanCanonicalize (H12AffineFastState.compose env44375 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44375 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44376 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,4113,1,35,4096,2048,52,0,4112,33,16,2,41,17,2049,4097,4097,2049,21,33,37,32,4112,513]

theorem envBound44376 : H12AffineFastState.Bounded env44376 := by
  intro p hp
  have h : env44376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44375_44376 : H12AffineEnvironment.transform 7 37 env44375 = env44376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44375 == env44376) = true)

theorem identity44376 : scanCanonicalize (H12AffineFastState.compose env44376 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound44376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44377 : List Nat := [2,4,8,16,32,17,8,37,48,52,2048,4096,41,4113,1,35,4096,2048,52,0,4112,33,16,2,41,17,2049,4097,4097,2049,21,33,37,32,4112,49]

theorem envBound44377 : H12AffineFastState.Bounded env44377 := by
  intro p hp
  have h : env44377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44376_44377 : H12AffineEnvironment.transform 8 48 env44376 = env44377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env44376 == env44377) = true)

theorem identity44377 : scanCanonicalize (H12AffineFastState.compose env44377 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44377 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44378 : List Nat := [2,4,8,16,32,17,8,37,48,52,1,4096,41,4113,1,35,4096,1,52,0,4112,33,16,2,41,17,0,4097,4097,0,21,33,37,32,4112,49]

theorem envBound44378 : H12AffineFastState.Bounded env44378 := by
  intro p hp
  have h : env44378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44377_44378 : H12AffineEnvironment.transform 10 1 env44377 = env44378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44377 == env44378) = true)

theorem identity44378 : scanCanonicalize (H12AffineFastState.compose env44378 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound44378 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44379 : List Nat := [2,4,8,16,32,17,8,37,48,52,1,17,41,0,1,35,17,1,52,0,1,33,16,2,41,17,0,16,16,0,21,33,37,32,1,49]

theorem envBound44379 : H12AffineFastState.Bounded env44379 := by
  intro p hp
  have h : env44379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44378_44379 : H12AffineEnvironment.transform 11 17 env44378 = env44379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env44378 == env44379) = true)

def env44380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6685700,8393985,10485977,8820104,2102685,12624324,256,168,46213,2175563]

theorem envBound44380 : H12AffineFastState.Bounded env44380 := by
  intro p hp
  have h : env44380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44285_44380 : H12AffineEnvironment.transform 13 5513 env44285 = env44380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env44285 == env44380) = true)

def env44381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98644,8328,64,6685700,2098649,4097,2524496,2102685,6336796,256,168,46213,2175563]

theorem envBound44381 : H12AffineFastState.Bounded env44381 := by
  intro p hp
  have h : env44381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44380_44381 : H12AffineEnvironment.transform 22 2101464 env44380 = env44381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env44380 == env44381) = true)

def env44382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98644,8328,64,2491428,2098649,4097,2524496,2102685,2142524,256,168,46213,2175563]

theorem envBound44382 : H12AffineFastState.Bounded env44382 := by
  intro p hp
  have h : env44382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44381_44382 : H12AffineEnvironment.transform 21 32 env44381 = env44382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44381 == env44382) = true)

theorem identity44382 : scanCanonicalize (H12AffineFastState.compose env44382 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102678) := by decide +kernel

theorem selectedBound44382 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,102678,32,98766,98644,8328,64,496946,103631,4097,463942,99467,73770,256,168,46213,41821]

theorem envBound44383 : H12AffineFastState.Bounded env44383 := by
  intro p hp
  have h : env44383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44382_44383 : H12AffineEnvironment.transform 20 102678 env44382 = env44383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102678 env44382 == env44383) = true)

def env44384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10400,1024,32769,102678,32,98766,98644,8328,64,245138,103631,4097,212198,99467,73770,256,168,46213,41821]

theorem envBound44384 : H12AffineFastState.Bounded env44384 := by
  intro p hp
  have h : env44384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44383_44384 : H12AffineEnvironment.transform 17 10400 env44383 = env44384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env44383 == env44384) = true)

theorem identity44384 : scanCanonicalize (H12AffineFastState.compose env44384 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103630) := by decide +kernel

theorem selectedBound44384 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,103630,10400,1024,32769,102678,32,98766,98644,8328,64,10588,103631,4097,43048,99467,73770,256,168,46213,41821]

theorem envBound44385 : H12AffineFastState.Bounded env44385 := by
  intro p hp
  have h : env44385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44384_44385 : H12AffineEnvironment.transform 16 103630 env44384 = env44385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103630 env44384 == env44385) = true)

theorem identity44385 : scanCanonicalize (H12AffineFastState.compose env44385 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound44385 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env44386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,5392,10400,1024,32769,4296,32,16,138,8328,64,10588,5393,4097,43048,1365,41460,256,168,46213,41821]

theorem envBound44386 : H12AffineFastState.Bounded env44386 := by
  intro p hp
  have h : env44386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44385_44386 : H12AffineEnvironment.transform 15 33246 env44385 = env44386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env44385 == env44386) = true)

theorem identity44386 : scanCanonicalize (H12AffineFastState.compose env44386 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound44386 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env44387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,81,399,5392,10400,1024,80,4296,32,16,138,8328,64,10588,5393,4097,10361,1365,8613,256,168,13524,8972]

theorem envBound44387 : H12AffineFastState.Bounded env44387 := by
  intro p hp
  have h : env44387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44386_44387 : H12AffineEnvironment.transform 14 81 env44386 = env44387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env44386 == env44387) = true)

theorem identity44387 : scanCanonicalize (H12AffineFastState.compose env44387 (packedSelected [0,4,5,8,10,12,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44387 : packedSelected [0,4,5,8,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env44388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,81,399,5392,2476,1024,80,4296,32,16,138,388,64,2128,5393,4097,2421,1365,169,256,168,5592,512]

theorem envBound44388 : H12AffineFastState.Bounded env44388 := by
  intro p hp
  have h : env44388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44387_44388 : H12AffineEnvironment.transform 12 268 env44387 = env44388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44387 == env44388) = true)

theorem identity44388 : scanCanonicalize (H12AffineFastState.compose env44388 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44388 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env44389 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,268,5513,81,399,5392,2445,1024,80,4296,1,16,138,388,64,2128,5393,4097,2388,1365,136,256,137,5592,512]

theorem envBound44389 : H12AffineFastState.Bounded env44389 := by
  intro p hp
  have h : env44389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44388_44389 : H12AffineEnvironment.transform 4 1 env44388 = env44389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44388 == env44389) = true)

def env44390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10401,1024,32769,102678,32,98766,98644,8328,64,245139,103631,4097,212199,99467,73770,256,168,46213,41821]

theorem envBound44390 : H12AffineFastState.Bounded env44390 := by
  intro p hp
  have h : env44390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44383_44390 : H12AffineEnvironment.transform 17 10401 env44383 = env44390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env44383 == env44390) = true)

def env44391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102678,32,98630,98644,8192,64,245019,103495,4097,212079,99331,73770,256,32,46093,41821]

theorem envBound44391 : H12AffineFastState.Bounded env44391 := by
  intro p hp
  have h : env44391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44390_44391 : H12AffineEnvironment.transform 6 8 env44390 = env44391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44390 == env44391) = true)

theorem identity44391 : scanCanonicalize (H12AffineFastState.compose env44391 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44391 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,77898,32,73754,73736,8192,64,203847,79131,4097,212079,75103,73770,256,32,5457,513]

theorem envBound44392 : H12AffineFastState.Bounded env44392 := by
  intro p hp
  have h : env44392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44391_44392 : H12AffineEnvironment.transform 14 8540 env44391 = env44392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44391 == env44392) = true)

theorem identity44392 : scanCanonicalize (H12AffineFastState.compose env44392 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 70963) := by decide +kernel

theorem selectedBound44392 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,70963,10281,1024,8541,77898,32,73754,73736,8192,64,2420,79131,4097,10588,75103,73770,256,32,5457,513]

theorem envBound44393 : H12AffineFastState.Bounded env44393 := by
  intro p hp
  have h : env44393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44392_44393 : H12AffineEnvironment.transform 16 70963 env44392 = env44393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70963 env44392 == env44393) = true)

theorem identity44393 : scanCanonicalize (H12AffineFastState.compose env44393 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound44393 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,1124,65536,70963,3345,1024,1125,71026,32,66850,66864,1336,64,2420,69667,4097,3172,65639,66834,256,32,5457,513]

theorem envBound44394 : H12AffineFastState.Bounded env44394 := by
  intro p hp
  have h : env44394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44393_44394 : H12AffineEnvironment.transform 12 1336 env44393 = env44394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env44393 == env44394) = true)

theorem identity44394 : scanCanonicalize (H12AffineFastState.compose env44394 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound44394 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env44395 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,121,4160,293,65536,69746,2128,321,292,69683,32,65635,65649,121,64,2420,69667,4097,2341,65639,65619,256,32,4112,513]

theorem envBound44395 : H12AffineFastState.Bounded env44395 := by
  intro p hp
  have h : env44395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44394_44395 : H12AffineEnvironment.transform 9 321 env44394 = env44395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44394 == env44395) = true)

theorem identity44395 : scanCanonicalize (H12AffineFastState.compose env44395 (packedSelected [0,4,7,9,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound44395 : packedSelected [0,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env44396 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2113,121,2049,293,65536,67635,2128,321,292,67698,32,65635,65649,121,64,2420,67682,2112,2341,65639,65619,256,32,2129,513]

theorem envBound44396 : H12AffineFastState.Bounded env44396 := by
  intro p hp
  have h : env44396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44395_44396 : H12AffineEnvironment.transform 11 2113 env44395 = env44396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env44395 == env44396) = true)

def env44397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102678,32,98631,98644,8193,64,245018,103494,4097,212078,99330,73770,256,33,46092,41821]

theorem envBound44397 : H12AffineFastState.Bounded env44397 := by
  intro p hp
  have h : env44397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44390_44397 : H12AffineEnvironment.transform 6 9 env44390 = env44397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44390 == env44397) = true)

theorem identity44397 : scanCanonicalize (H12AffineFastState.compose env44397 (packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound44397 : packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env44398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,111898,10280,1024,32769,102678,32,98631,98644,8193,64,2048,103494,4097,35188,99330,73770,256,33,46092,41821]

theorem envBound44398 : H12AffineFastState.Bounded env44398 := by
  intro p hp
  have h : env44398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44397_44398 : H12AffineEnvironment.transform 16 111898 env44397 = env44398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env44397 == env44398) = true)

theorem identity44398 : scanCanonicalize (H12AffineFastState.compose env44398 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44398 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,38161,10280,1024,32769,45341,32,41292,41311,8193,64,2048,46157,4097,35188,41993,33,256,33,46092,41821]

theorem envBound44399 : H12AffineFastState.Bounded env44399 := by
  intro p hp
  have h : env44399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44398_44399 : H12AffineEnvironment.transform 15 8203 env44398 = env44399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44398 == env44399) = true)

theorem identity44399 : scanCanonicalize (H12AffineFastState.compose env44399 (packedSelected [0,1,4,6,7,8,9,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44399 : packedSelected [0,1,4,6,7,8,9,19] rootPS < 2^1333 := by decide +kernel

def env44400 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,32768,8203,37988,10280,1024,32769,45160,32,41017,41002,8193,64,2048,46157,4097,34817,41993,33,117,33,46092,41512]

theorem envBound44400 : H12AffineFastState.Bounded env44400 := by
  intro p hp
  have h : env44400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44399_44400 : H12AffineEnvironment.transform 7 117 env44399 = env44400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44399 == env44400) = true)

theorem identity44400 : scanCanonicalize (H12AffineFastState.compose env44400 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44400 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env44401 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,32768,34,37988,2049,1024,32769,36929,32,32784,32771,40,64,2048,37988,4097,34817,33824,33,117,33,37925,33281]

theorem envBound44401 : H12AffineFastState.Bounded env44401 := by
  intro p hp
  have h : env44401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44400_44401 : H12AffineEnvironment.transform 12 41 env44400 = env44401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44400 == env44401) = true)

theorem identity44401 : scanCanonicalize (H12AffineFastState.compose env44401 (packedSelected [0,1,2,3,5,7,8,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound44401 : packedSelected [0,1,2,3,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env44402 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,4096,41,5237,32768,34,37988,81,1024,32769,36929,32,32784,32771,40,64,80,37988,4097,32849,33824,33,117,33,37925,33281]

theorem envBound44402 : H12AffineFastState.Bounded env44402 := by
  intro p hp
  have h : env44402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44401_44402 : H12AffineEnvironment.transform 10 80 env44401 = env44402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env44401 == env44402) = true)

theorem identity44402 : scanCanonicalize (H12AffineFastState.compose env44402 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44402 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env44403 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,4096,41,5237,1,34,5221,81,1024,0,4160,32,17,2,40,64,80,5221,4097,80,1057,33,117,33,5156,512]

theorem envBound44403 : H12AffineFastState.Bounded env44403 := by
  intro p hp
  have h : env44403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44402_44403 : H12AffineEnvironment.transform 14 1 env44402 = env44403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44402 == env44403) = true)

theorem identity44403 : scanCanonicalize (H12AffineFastState.compose env44403 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 58) := by decide +kernel

theorem selectedBound44403 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44404 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,58,41,1103,1,34,1119,81,1024,0,122,32,17,2,40,64,80,1119,59,80,1057,33,117,33,1054,512]

theorem envBound44404 : H12AffineFastState.Bounded env44404 := by
  intro p hp
  have h : env44404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44403_44404 : H12AffineEnvironment.transform 11 58 env44403 = env44404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 58 env44403 == env44404) = true)

theorem identity44404 : scanCanonicalize (H12AffineFastState.compose env44404 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound44404 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44405 : List Nat := [2,4,8,16,32,64,9,117,512,63,80,58,41,112,1,34,96,81,63,0,122,32,17,2,40,64,80,96,59,80,30,33,117,33,33,512]

theorem envBound44405 : H12AffineFastState.Bounded env44405 := by
  intro p hp
  have h : env44405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44404_44405 : H12AffineEnvironment.transform 9 63 env44404 = env44405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env44404 == env44405) = true)

theorem identity44405 : scanCanonicalize (H12AffineFastState.compose env44405 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound44405 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env44406 : List Nat := [2,4,8,16,20,64,9,65,512,11,80,14,29,68,1,22,84,81,11,0,78,20,17,2,28,64,80,84,15,80,30,21,65,21,21,512]

theorem envBound44406 : H12AffineFastState.Bounded env44406 := by
  intro p hp
  have h : env44406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44405_44406 : H12AffineEnvironment.transform 4 20 env44405 = env44406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env44405 == env44406) = true)

theorem identity44406 : scanCanonicalize (H12AffineFastState.compose env44406 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound44406 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44407 : List Nat := [2,4,8,16,20,5,9,4,512,11,21,14,29,1,1,22,17,20,11,0,11,20,17,2,28,5,21,17,15,21,30,21,4,21,21,512]

theorem envBound44407 : H12AffineFastState.Bounded env44407 := by
  intro p hp
  have h : env44407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44406_44407 : H12AffineEnvironment.transform 5 5 env44406 = env44407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env44406 == env44407) = true)

theorem identity44407 : scanCanonicalize (H12AffineFastState.compose env44407 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound44407 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env44408 : List Nat := [2,4,8,4,0,5,9,4,512,11,1,14,9,1,1,2,5,0,11,0,11,0,5,2,8,5,1,5,15,1,10,1,4,1,1,512]

theorem envBound44408 : H12AffineFastState.Bounded env44408 := by
  intro p hp
  have h : env44408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44407_44408 : H12AffineEnvironment.transform 3 4 env44407 = env44408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env44407 == env44408) = true)

theorem identity44408 : scanCanonicalize (H12AffineFastState.compose env44408 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44409 : List Nat := [2,1,8,1,0,0,9,1,512,11,1,11,9,1,1,2,0,0,11,0,11,0,0,2,8,0,1,0,10,1,10,1,1,1,1,512]

theorem envBound44409 : H12AffineFastState.Bounded env44409 := by
  intro p hp
  have h : env44409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44408_44409 : H12AffineEnvironment.transform 1 1 env44408 = env44409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44408 == env44409) = true)

theorem identity44409 : scanCanonicalize (H12AffineFastState.compose env44409 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44409 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env44410 : List Nat := [2,1,3,1,0,0,2,1,512,0,1,0,2,1,1,2,0,0,0,0,0,0,0,2,3,0,1,0,1,1,1,1,1,1,1,512]

theorem envBound44410 : H12AffineFastState.Bounded env44410 := by
  intro p hp
  have h : env44410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44409_44410 : H12AffineEnvironment.transform 2 3 env44409 = env44410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44409 == env44410) = true)

theorem identity44410 : scanCanonicalize (H12AffineFastState.compose env44410 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44411 : List Nat := [0,1,1,1,0,0,0,1,512,0,1,0,0,1,1,0,0,0,0,0,0,0,0,0,1,0,1,0,1,1,1,1,1,1,1,512]

theorem envBound44411 : H12AffineFastState.Bounded env44411 := by
  intro p hp
  have h : env44411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44410_44411 : H12AffineEnvironment.transform 0 0 env44410 = env44411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44410 == env44411) = true)

def env44412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98644,8328,64,2491429,2098649,4097,2524496,2102685,2142525,256,168,46213,2175563]

theorem envBound44412 : H12AffineFastState.Bounded env44412 := by
  intro p hp
  have h : env44412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44381_44412 : H12AffineEnvironment.transform 21 33 env44381 = env44412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44381 == env44412) = true)

theorem identity44412 : scanCanonicalize (H12AffineFastState.compose env44412 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound44412 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,131072,262144,1024,32769,2097152,33,2101464,138,8328,64,2491429,2098649,4097,2524496,2102685,2142525,256,168,46213,2143125]

theorem envBound44413 : H12AffineFastState.Bounded env44413 := by
  intro p hp
  have h : env44413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44412_44413 : H12AffineEnvironment.transform 15 33246 env44412 = env44413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env44412 == env44413) = true)

theorem identity44413 : scanCanonicalize (H12AffineFastState.compose env44413 (packedSelected [3,4,7,9,10,11,12,14,15,16,18,20,23,24,26,27,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound44413 : packedSelected [3,4,7,9,10,11,12,14,15,16,18,20,23,24,26,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env44414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,131072,10401,1024,32769,2097152,33,2101464,138,8328,64,2239620,2098649,4097,2272753,2102685,2142525,256,168,46213,2143125]

theorem envBound44414 : H12AffineFastState.Bounded env44414 := by
  intro p hp
  have h : env44414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44413_44414 : H12AffineEnvironment.transform 17 10401 env44413 = env44414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env44413 == env44414) = true)

theorem identity44414 : scanCanonicalize (H12AffineFastState.compose env44414 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 45460) := by decide +kernel

theorem selectedBound44414 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env44415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,131072,10401,1024,32769,45460,33,41292,138,8328,64,171280,46157,4097,138341,41993,169,256,168,46213,513]

theorem envBound44415 : H12AffineFastState.Bounded env44415 := by
  intro p hp
  have h : env44415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44414_44415 : H12AffineEnvironment.transform 20 45460 env44414 = env44415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45460 env44414 == env44415) = true)

theorem identity44415 : scanCanonicalize (H12AffineFastState.compose env44415 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound44415 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env44416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33246,13340,10401,1024,32769,45460,33,41292,138,8328,64,43276,46157,4097,10361,41993,169,256,168,46213,513]

theorem envBound44416 : H12AffineFastState.Bounded env44416 := by
  intro p hp
  have h : env44416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44415_44416 : H12AffineEnvironment.transform 16 13340 env44415 = env44416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env44415 == env44416) = true)

theorem identity44416 : scanCanonicalize (H12AffineFastState.compose env44416 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound44416 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env44417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,216,262,13340,10401,1024,217,12620,33,8596,138,8328,64,10708,13461,4097,10361,9425,169,256,168,13405,513]

theorem envBound44417 : H12AffineFastState.Bounded env44417 := by
  intro p hp
  have h : env44417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44416_44417 : H12AffineEnvironment.transform 14 216 env44416 = env44417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env44416 == env44417) = true)

theorem identity44417 : scanCanonicalize (H12AffineFastState.compose env44417 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound44417 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env44418 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,1,262,13340,10360,1024,0,12620,33,8525,83,8273,64,10509,13388,4097,10361,9224,112,256,113,13405,513]

theorem envBound44418 : H12AffineFastState.Bounded env44418 := by
  intro p hp
  have h : env44418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44417_44418 : H12AffineEnvironment.transform 6 89 env44417 = env44418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env44417 == env44418) = true)

theorem identity44418 : scanCanonicalize (H12AffineFastState.compose env44418 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44418 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44419 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,1,262,5392,2420,1024,0,4160,33,65,83,349,64,2049,5440,4097,2421,1284,112,256,113,5457,513]

theorem envBound44419 : H12AffineFastState.Bounded env44419 := by
  intro p hp
  have h : env44419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44418_44419 : H12AffineEnvironment.transform 12 268 env44418 = env44419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44418 == env44419) = true)

theorem identity44419 : scanCanonicalize (H12AffineFastState.compose env44419 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44419 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44420 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1024,0,4112,33,17,3,269,16,2049,5392,4097,2341,1284,32,256,33,5377,513]

theorem envBound44420 : H12AffineFastState.Bounded env44420 := by
  intro p hp
  have h : env44420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44419_44420 : H12AffineEnvironment.transform 5 16 env44419 = env44420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44419 == env44420) = true)

theorem identity44420 : scanCanonicalize (H12AffineFastState.compose env44420 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44421 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,1,34,5172,2048,1024,0,4112,33,17,3,41,16,2049,5172,4097,2049,1056,32,36,33,5157,513]

theorem envBound44421 : H12AffineFastState.Bounded env44421 := by
  intro p hp
  have h : env44421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44420_44421 : H12AffineEnvironment.transform 7 36 env44420 = env44421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44420 == env44421) = true)

theorem identity44421 : scanCanonicalize (H12AffineFastState.compose env44421 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1599) := by decide +kernel

theorem selectedBound44421 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44422 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1599,4096,40,5156,1,34,5172,1599,1024,0,4112,33,17,3,41,16,1598,5172,4097,1598,1056,32,36,33,5157,513]

theorem envBound44422 : H12AffineFastState.Bounded env44422 := by
  intro p hp
  have h : env44422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44421_44422 : H12AffineEnvironment.transform 10 1599 env44421 = env44422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1599 env44421 == env44422) = true)

theorem identity44422 : scanCanonicalize (H12AffineFastState.compose env44422 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound44422 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44423 : List Nat := [2,4,8,16,32,16,9,36,512,542,33,4096,40,4666,1,34,4650,33,542,0,4112,33,17,3,41,16,32,4650,4097,32,574,32,36,33,4667,513]

theorem envBound44423 : H12AffineFastState.Bounded env44423 := by
  intro p hp
  have h : env44423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44422_44423 : H12AffineEnvironment.transform 9 542 env44422 = env44423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env44422 == env44423) = true)

theorem identity44423 : scanCanonicalize (H12AffineFastState.compose env44423 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound44423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44424 : List Nat := [2,4,8,16,32,16,9,36,2,28,33,4096,40,4152,1,34,4136,33,28,0,4112,33,17,3,41,16,32,4136,4097,32,60,32,36,33,4153,3]

theorem envBound44424 : H12AffineFastState.Bounded env44424 := by
  intro p hp
  have h : env44424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44423_44424 : H12AffineEnvironment.transform 8 2 env44423 = env44424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env44423 == env44424) = true)

theorem identity44424 : scanCanonicalize (H12AffineFastState.compose env44424 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 25) := by decide +kernel

theorem selectedBound44424 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env44425 : List Nat := [2,4,8,16,32,16,9,36,2,28,33,25,40,33,1,34,49,33,28,0,9,33,17,3,41,16,32,49,24,32,60,32,36,33,32,3]

theorem envBound44425 : H12AffineFastState.Bounded env44425 := by
  intro p hp
  have h : env44425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44424_44425 : H12AffineEnvironment.transform 11 25 env44424 = env44425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 25 env44424 == env44425) = true)

theorem identity44425 : scanCanonicalize (H12AffineFastState.compose env44425 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound44425 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44426 : List Nat := [2,4,8,16,12,16,9,8,2,28,13,25,4,13,1,14,29,13,28,0,9,13,17,3,5,16,12,29,24,12,16,12,8,13,12,3]

theorem envBound44426 : H12AffineFastState.Bounded env44426 := by
  intro p hp
  have h : env44426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44425_44426 : H12AffineEnvironment.transform 4 12 env44425 = env44426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env44425 == env44426) = true)

theorem identity44426 : scanCanonicalize (H12AffineFastState.compose env44426 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44426 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env44427 : List Nat := [2,1,8,16,9,16,9,8,2,25,8,25,1,8,1,11,24,8,25,0,9,8,17,3,0,16,9,24,24,9,16,9,8,8,9,3]

theorem envBound44427 : H12AffineFastState.Bounded env44427 := by
  intro p hp
  have h : env44427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44426_44427 : H12AffineEnvironment.transform 1 1 env44426 = env44427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44426 == env44427) = true)

def env44428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98645,8328,64,6685700,2098648,4096,2524497,2102685,6336797,256,168,46213,2175563]

theorem envBound44428 : H12AffineFastState.Bounded env44428 := by
  intro p hp
  have h : env44428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44380_44428 : H12AffineEnvironment.transform 22 2101465 env44380 = env44428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env44380 == env44428) = true)

def env44429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98645,8328,64,2491428,2098648,4096,2524497,2102685,2142525,256,168,46213,2175563]

theorem envBound44429 : H12AffineFastState.Bounded env44429 := by
  intro p hp
  have h : env44429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44428_44429 : H12AffineEnvironment.transform 21 32 env44428 = env44429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44428 == env44429) = true)

theorem identity44429 : scanCanonicalize (H12AffineFastState.compose env44429 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound44429 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,77898,32,73875,98645,8328,64,472174,79250,4096,505115,75223,98679,256,168,46213,513]

theorem envBound44430 : H12AffineFastState.Bounded env44430 := by
  intro p hp
  have h : env44430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44429_44430 : H12AffineEnvironment.transform 20 77898 env44429 = env44430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env44429 == env44430) = true)

def env44431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98645,8192,64,472174,79130,4096,505115,75103,98679,256,32,46093,513]

theorem envBound44431 : H12AffineFastState.Bounded env44431 := by
  intro p hp
  have h : env44431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44430_44431 : H12AffineEnvironment.transform 6 8 env44430 = env44431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44430 == env44431) = true)

theorem identity44431 : scanCanonicalize (H12AffineFastState.compose env44431 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound44431 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,262144,1024,32769,77898,32,73755,98645,8192,64,262516,79130,4096,294913,75103,98679,256,32,46093,513]

theorem envBound44432 : H12AffineFastState.Bounded env44432 := by
  intro p hp
  have h : env44432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44431_44432 : H12AffineEnvironment.transform 16 79130 env44431 = env44432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env44431 == env44432) = true)

theorem identity44432 : scanCanonicalize (H12AffineFastState.compose env44432 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33862) := by decide +kernel

theorem selectedBound44432 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33862,45404,262144,1024,32769,46092,32,42077,1299,8192,64,262516,45404,4096,294913,41241,1329,256,32,46093,513]

theorem envBound44433 : H12AffineFastState.Bounded env44433 := by
  intro p hp
  have h : env44433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44432_44433 : H12AffineEnvironment.transform 15 33862 env44432 = env44433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33862 env44432 == env44433) = true)

theorem identity44433 : scanCanonicalize (H12AffineFastState.compose env44433 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(17+1) ^^^ 44109) := by decide +kernel

theorem selectedBound44433 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env44434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33862,45404,44109,1024,32769,46092,32,42077,1299,8192,64,44345,45404,4096,11340,41241,1329,256,32,46093,513]

theorem envBound44434 : H12AffineFastState.Bounded env44434 := by
  intro p hp
  have h : env44434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44433_44434 : H12AffineEnvironment.transform 17 44109 env44433 = env44434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44109 env44433 == env44434) = true)

theorem identity44434 : scanCanonicalize (H12AffineFastState.compose env44434 (packedSelected [3,5,10,11,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 1345) := by decide +kernel

theorem selectedBound44434 : packedSelected [3,5,10,11,21,23] rootPS < 2^1333 := by decide +kernel

def env44435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1345,263,13341,10508,1024,1344,12621,32,8476,1299,8192,64,10360,13341,4096,11340,9304,1329,256,32,12620,513]

theorem envBound44435 : H12AffineFastState.Bounded env44435 := by
  intro p hp
  have h : env44435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44434_44435 : H12AffineEnvironment.transform 14 1345 env44434 = env44435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env44434 == env44435) = true)

theorem identity44435 : scanCanonicalize (H12AffineFastState.compose env44435 (packedSelected [11,12,15,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound44435 : packedSelected [11,12,15,18,21] rootPS < 2^1333 := by decide +kernel

def env44436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,1345,263,4389,3124,1024,1344,5237,32,1060,1299,1336,64,3392,4389,4096,2420,352,1329,256,32,5236,513]

theorem envBound44436 : H12AffineFastState.Bounded env44436 := by
  intro p hp
  have h : env44436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44435_44436 : H12AffineEnvironment.transform 12 1336 env44435 = env44436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env44435 == env44436) = true)

theorem identity44436 : scanCanonicalize (H12AffineFastState.compose env44436 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound44436 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,1336,64,1345,263,1124,3124,1024,1344,308,32,1060,1299,1336,64,3392,1124,1345,2420,352,1329,256,32,309,513]

theorem envBound44437 : H12AffineFastState.Bounded env44437 := by
  intro p hp
  have h : env44437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44436_44437 : H12AffineEnvironment.transform 11 1345 env44436 = env44437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env44436 == env44437) = true)

theorem identity44437 : scanCanonicalize (H12AffineFastState.compose env44437 (packedSelected [4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44437 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env44438 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1076,1101,64,1076,114,1124,3124,1024,1077,65,32,1060,1126,1101,64,3125,1124,1076,2049,21,1092,117,32,64,513]

theorem envBound44438 : H12AffineFastState.Bounded env44438 := by
  intro p hp
  have h : env44438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44437_44438 : H12AffineEnvironment.transform 7 117 env44437 = env44438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44437 == env44438) = true)

theorem identity44438 : scanCanonicalize (H12AffineFastState.compose env44438 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound44438 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env44439 : List Nat := [2,4,8,16,32,64,8,117,81,1024,2048,1076,1101,64,1076,114,1124,3124,1024,1077,65,32,1060,1126,1101,64,3125,1124,1076,2049,21,1092,117,32,64,80]

theorem envBound44439 : H12AffineFastState.Bounded env44439 := by
  intro p hp
  have h : env44439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44438_44439 : H12AffineEnvironment.transform 8 81 env44438 = env44439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env44438 == env44439) = true)

theorem identity44439 : scanCanonicalize (H12AffineFastState.compose env44439 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound44439 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44440 : List Nat := [2,4,8,16,32,64,8,117,81,21,2048,33,88,64,33,114,113,2081,21,32,65,32,49,115,88,64,2080,113,33,2049,21,81,117,32,64,80]

theorem envBound44440 : H12AffineFastState.Bounded env44440 := by
  intro p hp
  have h : env44440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44439_44440 : H12AffineEnvironment.transform 9 21 env44439 = env44440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env44439 == env44440) = true)

theorem identity44440 : scanCanonicalize (H12AffineFastState.compose env44440 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44441 : List Nat := [2,4,8,16,32,17,8,36,0,21,2048,33,9,17,33,35,32,2081,21,32,16,32,49,34,9,17,2080,32,33,2049,21,0,36,32,17,1]

theorem envBound44441 : H12AffineFastState.Bounded env44441 := by
  intro p hp
  have h : env44441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44440_44441 : H12AffineEnvironment.transform 5 17 env44440 = env44441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44440 == env44441) = true)

theorem identity44441 : scanCanonicalize (H12AffineFastState.compose env44441 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44441 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44442 : List Nat := [2,4,8,16,1,17,8,5,0,21,2048,0,9,17,0,2,1,2048,21,1,16,1,16,3,9,17,2049,1,0,2049,21,0,5,1,17,1]

theorem envBound44442 : H12AffineFastState.Bounded env44442 := by
  intro p hp
  have h : env44442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44441_44442 : H12AffineEnvironment.transform 4 1 env44441 = env44442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44441 == env44442) = true)

theorem identity44442 : scanCanonicalize (H12AffineFastState.compose env44442 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound44442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44443 : List Nat := [2,4,3,16,1,17,3,5,0,21,2048,0,2,17,0,2,1,2048,21,1,16,1,16,3,2,17,2049,1,0,2049,21,0,5,1,17,1]

theorem envBound44443 : H12AffineFastState.Bounded env44443 := by
  intro p hp
  have h : env44443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44442_44443 : H12AffineEnvironment.transform 2 3 env44442 = env44443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env44442 == env44443) = true)

theorem identity44443 : scanCanonicalize (H12AffineFastState.compose env44443 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44444 : List Nat := [2,4,3,0,1,1,3,5,0,5,2048,0,2,1,0,2,1,2048,5,1,0,1,0,3,2,1,2049,1,0,2049,5,0,5,1,1,1]

theorem envBound44444 : H12AffineFastState.Bounded env44444 := by
  intro p hp
  have h : env44444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44443_44444 : H12AffineEnvironment.transform 3 0 env44443 = env44444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44443 == env44444) = true)

theorem identity44444 : scanCanonicalize (H12AffineFastState.compose env44444 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44444 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44445 : List Nat := [2,4,3,0,1,1,3,5,0,5,1,0,2,1,0,2,1,1,5,1,0,1,0,3,2,1,0,1,0,0,5,0,5,1,1,1]

theorem envBound44445 : H12AffineFastState.Bounded env44445 := by
  intro p hp
  have h : env44445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44444_44445 : H12AffineEnvironment.transform 10 1 env44444 = env44445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44444 == env44445) = true)

def env44446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77898,32,73754,98645,8193,64,472174,79131,4096,505115,75102,98679,256,33,46092,513]

theorem envBound44446 : H12AffineFastState.Bounded env44446 := by
  intro p hp
  have h : env44446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44430_44446 : H12AffineEnvironment.transform 6 9 env44430 = env44446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44430 == env44446) = true)

theorem identity44446 : scanCanonicalize (H12AffineFastState.compose env44446 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44446 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env44447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,77898,32,73754,73737,8193,64,472174,79131,4096,463943,75102,73771,256,33,5456,513]

theorem envBound44447 : H12AffineFastState.Bounded env44447 := by
  intro p hp
  have h : env44447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44446_44447 : H12AffineEnvironment.transform 14 8540 env44446 = env44447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44446 == env44447) = true)

theorem identity44447 : scanCanonicalize (H12AffineFastState.compose env44447 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44447 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env44448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,131072,262144,1024,8541,4160,32,16,3,8193,64,398436,5393,4096,406605,1364,33,256,33,5456,513]

theorem envBound44448 : H12AffineFastState.Bounded env44448 := by
  intro p hp
  have h : env44448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44447_44448 : H12AffineEnvironment.transform 15 8202 env44447 = env44448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44447 == env44448) = true)

theorem identity44448 : scanCanonicalize (H12AffineFastState.compose env44448 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44448 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44449 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,262144,1024,8461,4112,32,16,3,8193,16,398388,5393,4096,406557,1284,33,256,33,5376,513]

theorem envBound44449 : H12AffineFastState.Bounded env44449 := by
  intro p hp
  have h : env44449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44448_44449 : H12AffineEnvironment.transform 5 16 env44448 = env44449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44448 == env44449) = true)

theorem identity44449 : scanCanonicalize (H12AffineFastState.compose env44449 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound44449 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44450 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,10281,1024,8461,4112,32,16,3,8193,16,146461,5393,4096,138292,1284,33,256,33,5376,513]

theorem envBound44450 : H12AffineFastState.Bounded env44450 := by
  intro p hp
  have h : env44450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44449_44450 : H12AffineEnvironment.transform 17 10281 env44449 = env44450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env44449 == env44450) = true)

theorem identity44450 : scanCanonicalize (H12AffineFastState.compose env44450 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound44450 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44451 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,13341,10281,1024,8461,4112,32,16,3,8193,16,2048,5393,4096,10281,1284,33,256,33,5376,513]

theorem envBound44451 : H12AffineFastState.Bounded env44451 := by
  intro p hp
  have h : env44451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44450_44451 : H12AffineEnvironment.transform 16 13341 env44450 = env44451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env44450 == env44451) = true)

theorem identity44451 : scanCanonicalize (H12AffineFastState.compose env44451 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound44451 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44452 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,5376,1297,1047,4096,3124,1024,1296,4112,32,16,3,1052,16,2048,5393,4096,3124,1284,33,256,33,5376,513]

theorem envBound44452 : H12AffineFastState.Bounded env44452 := by
  intro p hp
  have h : env44452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44451_44452 : H12AffineEnvironment.transform 12 1053 env44451 = env44452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env44451 == env44452) = true)

theorem identity44452 : scanCanonicalize (H12AffineFastState.compose env44452 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44452 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env44453 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,4096,1053,5376,1297,1047,4096,1077,1024,1296,4112,32,16,3,1052,16,1,5393,4096,1077,1284,33,256,33,5376,513]

theorem envBound44453 : H12AffineFastState.Bounded env44453 := by
  intro p hp
  have h : env44453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44452_44453 : H12AffineEnvironment.transform 10 1 env44452 = env44453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44452 == env44453) = true)

theorem identity44453 : scanCanonicalize (H12AffineFastState.compose env44453 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound44453 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env44454 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,1281,1053,1,1297,1047,1281,1077,1024,1296,1297,32,16,3,1052,16,1,16,1281,1077,1284,33,256,33,1,513]

theorem envBound44454 : H12AffineFastState.Bounded env44454 := by
  intro p hp
  have h : env44454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44453_44454 : H12AffineEnvironment.transform 11 1281 env44453 = env44454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env44453 == env44454) = true)

def env44455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98645,8328,64,2491429,2098648,4096,2524497,2102685,2142524,256,168,46213,2175563]

theorem envBound44455 : H12AffineFastState.Bounded env44455 := by
  intro p hp
  have h : env44455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44428_44455 : H12AffineEnvironment.transform 21 33 env44428 = env44455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44428 == env44455) = true)

theorem identity44455 : scanCanonicalize (H12AffineFastState.compose env44455 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound44455 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101465,41430,8328,64,2491429,2098648,4096,2524497,2102685,2142524,256,168,46213,2101960]

theorem envBound44456 : H12AffineFastState.Bounded env44456 := by
  intro p hp
  have h : env44456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44455_44456 : H12AffineEnvironment.transform 15 8323 env44455 = env44456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env44455 == env44456) = true)

def env44457 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101385,41350,8328,16,2491429,2098568,4096,2524417,2102685,2142524,256,168,46213,2101912]

theorem envBound44457 : H12AffineFastState.Bounded env44457 := by
  intro p hp
  have h : env44457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44456_44457 : H12AffineEnvironment.transform 5 16 env44456 = env44457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44456 == env44457) = true)

theorem identity44457 : scanCanonicalize (H12AffineFastState.compose env44457 (packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound44457 : packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env44458 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35108,1024,32769,2097152,33,2101385,41350,8328,16,2264321,2098568,4096,2231333,2102685,2142524,256,168,46213,2101912]

theorem envBound44458 : H12AffineFastState.Bounded env44458 := by
  intro p hp
  have h : env44458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44457_44458 : H12AffineEnvironment.transform 17 35108 env44457 = env44458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env44457 == env44458) = true)

theorem identity44458 : scanCanonicalize (H12AffineFastState.compose env44458 (packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound44458 : packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env44459 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,38161,35108,1024,32769,2097152,33,2101385,41350,8328,16,2103312,2098568,4096,2136372,2102685,2142524,256,168,46213,2101912]

theorem envBound44459 : H12AffineFastState.Bounded env44459 := by
  intro p hp
  have h : env44459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44458_44459 : H12AffineEnvironment.transform 16 38161 env44458 = env44459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env44458 == env44459) = true)

theorem identity44459 : scanCanonicalize (H12AffineFastState.compose env44459 (packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS)) = affineNative (2^(20+1) ^^^ 36880) := by decide +kernel

theorem selectedBound44459 : packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS < 2^1333 := by decide +kernel

def env44460 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,38161,35108,1024,32769,36880,33,32921,41350,8328,16,34816,38296,4096,2340,34189,8492,256,168,46213,33416]

theorem envBound44460 : H12AffineFastState.Bounded env44460 := by
  intro p hp
  have h : env44460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44459_44460 : H12AffineEnvironment.transform 20 36880 env44459 = env44460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36880 env44459 == env44460) = true)

theorem identity44460 : scanCanonicalize (H12AffineFastState.compose env44460 (packedSelected [0,4,7,16,18,20,21,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound44460 : packedSelected [0,4,7,16,18,20,21,22,23] rootPS < 2^1333 := by decide +kernel

def env44461 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8460,8323,13341,10280,1024,8461,12572,33,8597,138,8328,16,10508,13460,4096,2340,9345,8492,256,168,5513,9092]

theorem envBound44461 : H12AffineFastState.Bounded env44461 := by
  intro p hp
  have h : env44461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44460_44461 : H12AffineEnvironment.transform 14 8460 env44460 = env44461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env44460 == env44461) = true)

theorem identity44461 : scanCanonicalize (H12AffineFastState.compose env44461 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44461 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env44462 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,13341,10280,1024,8461,12572,33,8476,3,8193,16,10508,13341,4096,2340,9224,8492,256,33,5376,8973]

theorem envBound44462 : H12AffineFastState.Bounded env44462 := by
  intro p hp
  have h : env44462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44461_44462 : H12AffineEnvironment.transform 6 9 env44461 = env44462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44461 == env44462) = true)

theorem identity44462 : scanCanonicalize (H12AffineFastState.compose env44462 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44462 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env44463 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5376,293,35,5172,2049,1024,292,4405,33,309,3,40,16,2341,5172,4096,2340,1057,261,256,33,5376,804]

theorem envBound44463 : H12AffineFastState.Bounded env44463 := by
  intro p hp
  have h : env44463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44462_44463 : H12AffineEnvironment.transform 12 41 env44462 = env44463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44462 == env44463) = true)

theorem identity44463 : scanCanonicalize (H12AffineFastState.compose env44463 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44463 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44464 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,1,35,5172,2049,1024,0,4113,33,17,3,40,16,2049,5172,4096,2048,1057,33,36,33,5156,512]

theorem envBound44464 : H12AffineFastState.Bounded env44464 := by
  intro p hp
  have h : env44464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44463_44464 : H12AffineEnvironment.transform 7 36 env44463 = env44464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44463 == env44464) = true)

theorem identity44464 : scanCanonicalize (H12AffineFastState.compose env44464 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound44464 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44465 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,33,41,1029,1,35,1045,2049,1024,0,48,33,17,3,40,16,2049,1045,33,2048,1057,33,36,33,1029,512]

theorem envBound44465 : H12AffineFastState.Bounded env44465 := by
  intro p hp
  have h : env44465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44464_44465 : H12AffineEnvironment.transform 11 33 env44464 = env44465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env44464 == env44465) = true)

theorem identity44465 : scanCanonicalize (H12AffineFastState.compose env44465 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound44465 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44466 : List Nat := [2,4,8,16,32,16,9,36,512,532,2048,33,41,529,1,35,513,2049,532,0,48,33,17,3,40,16,2049,513,33,2048,565,33,36,33,529,512]

theorem envBound44466 : H12AffineFastState.Bounded env44466 := by
  intro p hp
  have h : env44466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44465_44466 : H12AffineEnvironment.transform 9 532 env44465 = env44466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env44465 == env44466) = true)

theorem identity44466 : scanCanonicalize (H12AffineFastState.compose env44466 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44466 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44467 : List Nat := [2,4,8,16,0,16,9,4,512,532,2048,1,9,529,1,3,513,2049,532,0,16,1,17,3,8,16,2049,513,1,2048,533,1,4,1,529,512]

theorem envBound44467 : H12AffineFastState.Bounded env44467 := by
  intro p hp
  have h : env44467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44466_44467 : H12AffineEnvironment.transform 4 0 env44466 = env44467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44466 == env44467) = true)

theorem identity44467 : scanCanonicalize (H12AffineFastState.compose env44467 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44467 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44468 : List Nat := [2,4,8,16,0,16,9,4,0,20,2048,1,9,17,1,3,1,2049,20,0,16,1,17,3,8,16,2049,1,1,2048,21,1,4,1,17,0]

theorem envBound44468 : H12AffineFastState.Bounded env44468 := by
  intro p hp
  have h : env44468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44467_44468 : H12AffineEnvironment.transform 8 0 env44467 = env44468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44467 == env44468) = true)

theorem identity44468 : scanCanonicalize (H12AffineFastState.compose env44468 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44469 : List Nat := [2,4,8,16,0,16,9,4,0,20,1,1,9,17,1,3,1,0,20,0,16,1,17,3,8,16,0,1,1,1,21,1,4,1,17,0]

theorem envBound44469 : H12AffineFastState.Bounded env44469 := by
  intro p hp
  have h : env44469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44468_44469 : H12AffineEnvironment.transform 10 1 env44468 = env44469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44468 == env44469) = true)

theorem identity44469 : scanCanonicalize (H12AffineFastState.compose env44469 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound44469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44470 : List Nat := [2,4,8,14,0,14,9,4,0,10,1,1,9,15,1,3,1,0,10,0,14,1,15,3,8,14,0,1,1,1,11,1,4,1,15,0]

theorem envBound44470 : H12AffineFastState.Bounded env44470 := by
  intro p hp
  have h : env44470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44469_44470 : H12AffineEnvironment.transform 3 14 env44469 = env44470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env44469 == env44470) = true)

def env44471 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101384,41351,8328,17,2491429,2098569,4096,2524416,2102685,2142524,256,168,46213,2101913]

theorem envBound44471 : H12AffineFastState.Bounded env44471 := by
  intro p hp
  have h : env44471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44456_44471 : H12AffineEnvironment.transform 5 17 env44456 = env44471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44456 == env44471) = true)

theorem identity44471 : scanCanonicalize (H12AffineFastState.compose env44471 (packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound44471 : packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env44472 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35245,1024,32769,2097152,33,2101384,41351,8328,17,2264456,2098569,4096,2231469,2102685,2142524,256,168,46213,2101913]

theorem envBound44472 : H12AffineFastState.Bounded env44472 := by
  intro p hp
  have h : env44472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44471_44472 : H12AffineEnvironment.transform 17 35245 env44471 = env44472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env44471 == env44472) = true)

theorem identity44472 : scanCanonicalize (H12AffineFastState.compose env44472 (packedSelected [3,4,5,7,8,9,10,16,20,21,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 132489) := by decide +kernel

theorem selectedBound44472 : packedSelected [3,4,5,7,8,9,10,16,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44473 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35245,1024,32769,132489,33,136449,41351,8328,17,34817,131072,4096,2340,135188,177333,256,168,46213,136976]

theorem envBound44473 : H12AffineFastState.Bounded env44473 := by
  intro p hp
  have h : env44473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44472_44473 : H12AffineEnvironment.transform 20 132489 env44472 = env44473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132489 env44472 == env44473) = true)

theorem identity44473 : scanCanonicalize (H12AffineFastState.compose env44473 (packedSelected [1,4,5,7,8,9,16,18,20,21,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound44473 : packedSelected [1,4,5,7,8,9,16,18,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env44474 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,46108,35245,1024,32769,45461,33,41245,41351,8328,17,34817,46108,4096,2340,41992,169,256,168,46213,41740]

theorem envBound44474 : H12AffineFastState.Bounded env44474 := by
  intro p hp
  have h : env44474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44473_44474 : H12AffineEnvironment.transform 16 46108 env44473 = env44474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env44473 == env44474) = true)

theorem identity44474 : scanCanonicalize (H12AffineFastState.compose env44474 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1212) := by decide +kernel

theorem selectedBound44474 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env44475 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,1212,8323,12448,3345,1024,1213,13609,33,9633,9531,8328,17,3261,12448,4096,2340,8372,169,256,168,12345,10160]

theorem envBound44475 : H12AffineFastState.Bounded env44475 := by
  intro p hp
  have h : env44475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44474_44475 : H12AffineEnvironment.transform 14 1212 env44474 = env44475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1212 env44474 == env44475) = true)

theorem identity44475 : scanCanonicalize (H12AffineFastState.compose env44475 (packedSelected [0,3,5,7,10,11,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44475 : packedSelected [0,3,5,7,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env44476 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1077,8202,12329,3345,1024,1076,13609,33,9512,9531,8193,17,3124,12329,4096,2340,8253,32,256,33,12345,10041]

theorem envBound44476 : H12AffineFastState.Bounded env44476 := by
  intro p hp
  have h : env44476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44475_44476 : H12AffineEnvironment.transform 6 9 env44475 = env44476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44475 == env44476) = true)

theorem identity44476 : scanCanonicalize (H12AffineFastState.compose env44476 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 7212) := by decide +kernel

theorem selectedBound44476 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env44477 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,7212,5376,1077,7206,3077,3345,1024,1076,2309,33,6404,6423,7213,17,3124,3077,4096,2340,7185,32,256,33,3093,6933]

theorem envBound44477 : H12AffineFastState.Bounded env44477 := by
  intro p hp
  have h : env44477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44476_44477 : H12AffineEnvironment.transform 12 7212 env44476 = env44477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7212 env44476 == env44477) = true)

theorem identity44477 : scanCanonicalize (H12AffineFastState.compose env44477 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound44477 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env44478 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1281,2349,1,1077,2343,3077,3345,1024,1076,2309,33,3077,3094,2348,17,3124,3077,1281,2340,2320,32,256,33,3093,3604]

theorem envBound44478 : H12AffineFastState.Bounded env44478 := by
  intro p hp
  have h : env44478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44477_44478 : H12AffineEnvironment.transform 11 1281 env44477 = env44478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env44477 == env44478) = true)

theorem identity44478 : scanCanonicalize (H12AffineFastState.compose env44478 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound44478 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env44479 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,1077,2073,1,1077,2067,3077,3109,1024,1076,2097,33,3077,3094,2072,17,3124,3077,1077,2064,2084,32,52,33,3093,3604]

theorem envBound44479 : H12AffineFastState.Bounded env44479 := by
  intro p hp
  have h : env44479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44478_44479 : H12AffineEnvironment.transform 7 52 env44478 = env44479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env44478 == env44479) = true)

theorem identity44479 : scanCanonicalize (H12AffineFastState.compose env44479 (packedSelected [0,3,4,5,6,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44479 : packedSelected [0,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44480 : List Nat := [2,4,8,0,32,1,9,36,512,1024,2048,1061,2057,1,1061,2051,3077,3109,1024,1060,2081,33,3077,3078,2056,1,3108,3077,1061,2048,2084,32,36,33,3077,3588]

theorem envBound44480 : H12AffineFastState.Bounded env44480 := by
  intro p hp
  have h : env44480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44479_44480 : H12AffineEnvironment.transform 3 0 env44479 = env44480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44479 == env44480) = true)

theorem identity44480 : scanCanonicalize (H12AffineFastState.compose env44480 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound44480 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44481 : List Nat := [2,4,8,0,32,1,9,36,512,1024,544,1061,553,1,1061,547,1573,1541,1024,1060,513,33,1573,1574,552,1,1540,1573,1061,544,516,32,36,33,1573,1060]

theorem envBound44481 : H12AffineFastState.Bounded env44481 := by
  intro p hp
  have h : env44481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44480_44481 : H12AffineEnvironment.transform 10 544 env44480 = env44481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env44480 == env44481) = true)

theorem identity44481 : scanCanonicalize (H12AffineFastState.compose env44481 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound44481 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44482 : List Nat := [2,4,8,0,32,1,9,36,512,36,544,1,553,1,1,547,513,545,36,0,513,33,513,514,552,1,544,513,1,544,516,32,36,33,513,0]

theorem envBound44482 : H12AffineFastState.Bounded env44482 := by
  intro p hp
  have h : env44482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44481_44482 : H12AffineEnvironment.transform 9 36 env44481 = env44482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env44481 == env44482) = true)

theorem identity44482 : scanCanonicalize (H12AffineFastState.compose env44482 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound44482 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44483 : List Nat := [2,4,8,0,32,1,9,36,32,36,0,1,9,1,1,3,33,1,36,0,33,33,33,34,8,1,0,33,1,0,36,32,36,33,33,0]

theorem envBound44483 : H12AffineFastState.Bounded env44483 := by
  intro p hp
  have h : env44483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44482_44483 : H12AffineEnvironment.transform 8 32 env44482 = env44483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env44482 == env44483) = true)

def env44484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound44484 : H12AffineFastState.Bounded env44484 := by
  intro p hp
  have h : env44484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44283_44484 : H12AffineEnvironment.transform 18 1025 env44283 = env44484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env44283 == env44484) = true)

theorem identity44484 : scanCanonicalize (H12AffineFastState.compose env44484 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 140420) := by decide +kernel

theorem selectedBound44484 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,8388608,16777216,8328,64,29868032,17014792,8548820,8830976,25265169,21184837,257,25419816,25362829,25207750]

theorem envBound44485 : H12AffineFastState.Bounded env44485 := by
  intro p hp
  have h : env44485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44484_44485 : H12AffineEnvironment.transform 20 140420 env44484 = env44485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140420 env44484 == env44485) = true)

def env44486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,8388608,8631560,8328,64,4486408,8393984,8548820,8830976,143641,12645453,257,21792,46213,202446]

theorem envBound44486 : H12AffineFastState.Bounded env44486 := by
  intro p hp
  have h : env44486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44485_44486 : H12AffineEnvironment.transform 23 8631560 env44485 = env44486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631560 env44485 == env44486) = true)

def env44487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,180224,95496,8328,64,4486408,185600,45524,262144,143641,4338765,257,21792,46213,202446]

theorem envBound44487 : H12AffineFastState.Bounded env44487 := by
  intro p hp
  have h : env44487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44486_44487 : H12AffineEnvironment.transform 22 180224 env44486 = env44487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env44486 == env44487) = true)

def env44488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272512,180224,95496,8328,64,23944,185600,45524,262144,143641,400589,257,21792,46213,202446]

theorem envBound44488 : H12AffineFastState.Bounded env44488 := by
  intro p hp
  have h : env44488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44487_44488 : H12AffineEnvironment.transform 21 272512 env44487 = env44488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44487 == env44488) = true)

theorem identity44488 : scanCanonicalize (H12AffineFastState.compose env44488 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44488 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140420,272512,180224,21762,8328,64,23944,185600,45524,262144,143641,400589,257,21792,46213,145092]

theorem envBound44489 : H12AffineFastState.Bounded env44489 := by
  intro p hp
  have h : env44489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44488_44489 : H12AffineEnvironment.transform 15 8202 env44488 = env44489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44488 == env44489) = true)

def env44490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140300,272392,180224,21762,8192,64,23808,185600,45404,262144,143641,400453,257,21792,46093,144972]

theorem envBound44490 : H12AffineFastState.Bounded env44490 := by
  intro p hp
  have h : env44490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44489_44490 : H12AffineEnvironment.transform 6 8 env44489 = env44490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44489 == env44490) = true)

def env44491 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,58396,272392,16,21762,8192,64,23808,5392,45404,262144,61705,318549,257,21792,46093,63068]

theorem envBound44491 : H12AffineFastState.Bounded env44491 := by
  intro p hp
  have h : env44491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44490_44491 : H12AffineEnvironment.transform 16 49168 env44490 = env44491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env44490 == env44491) = true)

theorem identity44491 : scanCanonicalize (H12AffineFastState.compose env44491 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44491 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env44492 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49168,262144,1025,32769,50496,264532,16,21762,348,64,23808,5392,36864,262144,53333,318549,257,21792,38225,55040]

theorem envBound44492 : H12AffineFastState.Bounded env44492 := by
  intro p hp
  have h : env44492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44491_44492 : H12AffineEnvironment.transform 12 348 env44491 = env44492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44491 == env44492) = true)

def env44493 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,58397,272392,17,21762,8192,64,23808,5393,45404,262144,61704,318548,257,21792,46093,63069]

theorem envBound44493 : H12AffineFastState.Bounded env44493 := by
  intro p hp
  have h : env44493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44490_44493 : H12AffineEnvironment.transform 16 49169 env44490 = env44493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env44490 == env44493) = true)

theorem identity44493 : scanCanonicalize (H12AffineFastState.compose env44493 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44493 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44494 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10280,1025,32769,58397,32,17,21762,8192,64,23808,5393,45404,10280,61704,62588,257,21792,46093,63069]

theorem envBound44494 : H12AffineFastState.Bounded env44494 := by
  intro p hp
  have h : env44494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44493_44494 : H12AffineEnvironment.transform 17 10280 env44493 = env44494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44493 == env44494) = true)

theorem identity44494 : scanCanonicalize (H12AffineFastState.compose env44494 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound44494 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env44495 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,5393,10280,1025,21761,12573,32,17,21762,8192,64,23808,5393,25692,10280,9224,8572,257,21792,24845,9053]

theorem envBound44495 : H12AffineFastState.Bounded env44495 := by
  intro p hp
  have h : env44495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44494_44495 : H12AffineEnvironment.transform 14 21760 env44494 = env44495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env44494 == env44495) = true)

theorem identity44495 : scanCanonicalize (H12AffineFastState.compose env44495 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound44495 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env44496 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,8202,5393,10280,1025,1,12573,32,17,2,8192,64,2048,5393,12636,10280,9224,8572,257,32,13325,9053]

theorem envBound44496 : H12AffineFastState.Bounded env44496 := by
  intro p hp
  have h : env44496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44495_44496 : H12AffineEnvironment.transform 13 5376 env44495 = env44496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44495 == env44496) = true)

theorem identity44496 : scanCanonicalize (H12AffineFastState.compose env44496 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44496 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env44497 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,0,8202,5221,10280,1025,1,12393,32,17,2,8192,64,2048,5221,12328,10280,9224,8200,117,32,13325,8745]

theorem envBound44497 : H12AffineFastState.Bounded env44497 := by
  intro p hp
  have h : env44497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44496_44497 : H12AffineEnvironment.transform 7 116 env44496 = env44497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44496 == env44497) = true)

theorem identity44497 : scanCanonicalize (H12AffineFastState.compose env44497 (packedSelected [1,2,3,5,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound44497 : packedSelected [1,2,3,5,8,14] rootPS < 2^1333 := by decide +kernel

def env44498 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,4096,8192,5236,0,8202,5221,8233,1025,1,12393,32,17,2,8192,64,1,5221,12328,8233,9224,8200,117,32,13325,8745]

theorem envBound44498 : H12AffineFastState.Bounded env44498 := by
  intro p hp
  have h : env44498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44497_44498 : H12AffineEnvironment.transform 10 1 env44497 = env44498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env44497 == env44498) = true)

theorem identity44498 : scanCanonicalize (H12AffineFastState.compose env44498 (packedSelected [0,3,5,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound44498 : packedSelected [0,3,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env44499 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,4096,1101,5236,0,1095,5221,1124,1025,1,5156,32,17,2,1101,64,1,5221,5221,1124,69,1093,117,32,4160,1636]

theorem envBound44499 : H12AffineFastState.Bounded env44499 := by
  intro p hp
  have h : env44499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44498_44499 : H12AffineEnvironment.transform 12 1101 env44498 = env44499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env44498 == env44499) = true)

theorem identity44499 : scanCanonicalize (H12AffineFastState.compose env44499 (packedSelected [3,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound44499 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env44500 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1,1141,1101,1,0,1095,16,1124,1025,1,81,32,17,2,1101,64,1,16,16,1124,69,1093,117,32,1077,1636]

theorem envBound44500 : H12AffineFastState.Bounded env44500 := by
  intro p hp
  have h : env44500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44499_44500 : H12AffineEnvironment.transform 11 1141 env44499 = env44500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env44499 == env44500) = true)

theorem identity44500 : scanCanonicalize (H12AffineFastState.compose env44500 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44500 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44501 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,1061,1053,1,0,1047,16,1076,1025,1,1,32,17,2,1053,16,1,16,16,1076,21,1045,37,32,1077,1588]

theorem envBound44501 : H12AffineFastState.Bounded env44501 := by
  intro p hp
  have h : env44501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44500_44501 : H12AffineEnvironment.transform 5 16 env44500 = env44501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44500 == env44501) = true)

theorem identity44501 : scanCanonicalize (H12AffineFastState.compose env44501 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44501 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env44502 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,41,1,0,35,16,0,53,1,1,32,17,2,41,16,1,16,16,0,21,33,37,32,1,512]

theorem envBound44502 : H12AffineFastState.Bounded env44502 := by
  intro p hp
  have h : env44502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44501_44502 : H12AffineEnvironment.transform 9 52 env44501 = env44502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44501 == env44502) = true)

theorem identity44502 : scanCanonicalize (H12AffineFastState.compose env44502 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound44502 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44503 : List Nat := [2,4,8,16,32,16,8,36,21,52,1,17,41,1,0,35,16,0,53,1,1,32,17,2,41,16,1,16,16,0,21,33,37,32,1,21]

theorem envBound44503 : H12AffineFastState.Bounded env44503 := by
  intro p hp
  have h : env44503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44502_44503 : H12AffineEnvironment.transform 8 21 env44502 = env44503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env44502 == env44503) = true)

theorem identity44503 : scanCanonicalize (H12AffineFastState.compose env44503 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44503 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44504 : List Nat := [2,4,8,16,7,16,8,3,21,19,1,17,14,1,0,4,16,0,18,1,1,7,17,2,14,16,1,16,16,0,21,6,2,7,1,21]

theorem envBound44504 : H12AffineFastState.Bounded env44504 := by
  intro p hp
  have h : env44504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44503_44504 : H12AffineEnvironment.transform 4 7 env44503 = env44504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44503 == env44504) = true)

theorem identity44504 : scanCanonicalize (H12AffineFastState.compose env44504 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound44504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44505 : List Nat := [2,4,8,6,7,6,8,3,3,5,1,7,14,1,0,4,6,0,4,1,1,7,7,2,14,6,1,6,6,0,3,6,2,7,1,3]

theorem envBound44505 : H12AffineFastState.Bounded env44505 := by
  intro p hp
  have h : env44505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44504_44505 : H12AffineEnvironment.transform 3 6 env44504 = env44505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env44504 == env44505) = true)

theorem identity44505 : scanCanonicalize (H12AffineFastState.compose env44505 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44505 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44506 : List Nat := [2,4,4,6,7,6,4,3,3,5,1,7,2,1,0,4,6,0,4,1,1,7,7,2,2,6,1,6,6,0,3,6,2,7,1,3]

theorem envBound44506 : H12AffineFastState.Bounded env44506 := by
  intro p hp
  have h : env44506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44505_44506 : H12AffineEnvironment.transform 2 4 env44505 = env44506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44505 == env44506) = true)

theorem identity44506 : scanCanonicalize (H12AffineFastState.compose env44506 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44506 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env44507 : List Nat := [2,2,2,0,1,0,2,3,3,3,1,1,2,1,0,2,0,0,2,1,1,1,1,2,2,0,1,0,0,0,3,0,2,1,1,3]

theorem envBound44507 : H12AffineFastState.Bounded env44507 := by
  intro p hp
  have h : env44507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44506_44507 : H12AffineEnvironment.transform 1 2 env44506 = env44507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44506 == env44507) = true)

def env44508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,140301,272393,180224,21762,8193,64,23809,185600,45405,262144,143641,400452,257,21792,46092,144973]

theorem envBound44508 : H12AffineFastState.Bounded env44508 := by
  intro p hp
  have h : env44508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44489_44508 : H12AffineEnvironment.transform 6 9 env44489 = env44508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44489 == env44508) = true)

def env44509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,58397,272393,16,21762,8193,64,23809,5392,45405,262144,61705,318548,257,21792,46092,63069]

theorem envBound44509 : H12AffineFastState.Bounded env44509 := by
  intro p hp
  have h : env44509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44508_44509 : H12AffineEnvironment.transform 16 49168 env44508 = env44509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env44508 == env44509) = true)

theorem identity44509 : scanCanonicalize (H12AffineFastState.compose env44509 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44509 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,24909,262144,1025,8540,17728,272393,16,21762,8193,64,23809,5392,4096,262144,20564,294153,257,21792,5457,22272]

theorem envBound44510 : H12AffineFastState.Bounded env44510 := by
  intro p hp
  have h : env44510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44509_44510 : H12AffineEnvironment.transform 14 8541 env44509 = env44510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44509 == env44510) = true)

theorem identity44510 : scanCanonicalize (H12AffineFastState.compose env44510 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound44510 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env44511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,24909,32041,1025,8540,17728,21792,16,21762,8193,64,23809,5392,4096,32041,20564,32,257,21792,5457,22272]

theorem envBound44511 : H12AffineFastState.Bounded env44511 := by
  intro p hp
  have h : env44511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44510_44511 : H12AffineEnvironment.transform 17 32041 env44510 = env44511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env44510 == env44511) = true)

theorem identity44511 : scanCanonicalize (H12AffineFastState.compose env44511 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44511 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44512 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,16384,8541,8202,24909,31005,53,8540,16756,20756,16,20790,8193,64,22837,4388,4096,31005,20564,32,257,20756,4453,21300]

theorem envBound44512 : H12AffineFastState.Bounded env44512 := by
  intro p hp
  have h : env44512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44511_44512 : H12AffineEnvironment.transform 9 52 env44511 = env44512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44511 == env44512) = true)

theorem identity44512 : scanCanonicalize (H12AffineFastState.compose env44512 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound44512 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env44513 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,6429,16384,6208,6423,22608,16384,53,6209,16756,20756,16,20790,6428,64,22837,4388,4096,16384,20564,32,257,20756,4453,21300]

theorem envBound44513 : H12AffineFastState.Bounded env44513 := by
  intro p hp
  have h : env44513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44512_44513 : H12AffineEnvironment.transform 12 6429 env44512 = env44513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env44512 == env44513) = true)

theorem identity44513 : scanCanonicalize (H12AffineFastState.compose env44513 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound44513 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44514 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,357,2168,16384,2341,2162,18741,16384,53,2340,16756,16497,16,16467,2169,64,18512,65,357,16384,16689,32,257,16497,0,16977]

theorem envBound44514 : H12AffineFastState.Bounded env44514 := by
  intro p hp
  have h : env44514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44513_44514 : H12AffineEnvironment.transform 11 357 env44513 = env44514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env44513 == env44514) = true)

theorem identity44514 : scanCanonicalize (H12AffineFastState.compose env44514 (packedSelected [2,3,4,5,9,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound44514 : packedSelected [2,3,4,5,9,10,16] rootPS < 2^1333 := by decide +kernel

def env44515 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,357,2168,2049,2341,2162,308,2049,53,2340,2421,2160,16,2130,2169,64,81,65,357,2049,2352,32,257,2160,0,2640]

theorem envBound44515 : H12AffineFastState.Bounded env44515 := by
  intro p hp
  have h : env44515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44514_44515 : H12AffineEnvironment.transform 13 2049 env44514 = env44515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env44514 == env44515) = true)

def env44516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,58396,272393,17,21762,8193,64,23809,5393,45405,262144,61704,318549,257,21792,46092,63068]

theorem envBound44516 : H12AffineFastState.Bounded env44516 := by
  intro p hp
  have h : env44516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44508_44516 : H12AffineEnvironment.transform 16 49169 env44508 = env44516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env44508 == env44516) = true)

theorem identity44516 : scanCanonicalize (H12AffineFastState.compose env44516 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound44516 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,35188,1025,32769,58396,41341,17,21762,8193,64,23809,5393,45405,35188,61704,21793,257,21792,46092,63068]

theorem envBound44517 : H12AffineFastState.Bounded env44517 := by
  intro p hp
  have h : env44517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44516_44517 : H12AffineEnvironment.transform 17 35188 env44516 = env44517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env44516 == env44517) = true)

theorem identity44517 : scanCanonicalize (H12AffineFastState.compose env44517 (packedSelected [0,2,7,9,11,18,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44517 : packedSelected [0,2,7,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env44518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,24909,10280,1025,8541,17728,33,17,21762,8193,64,23809,5393,4097,10280,20564,21793,257,21792,5456,22272]

theorem envBound44518 : H12AffineFastState.Bounded env44518 := by
  intro p hp
  have h : env44518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44517_44518 : H12AffineEnvironment.transform 14 8540 env44517 = env44518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44517 == env44518) = true)

theorem identity44518 : scanCanonicalize (H12AffineFastState.compose env44518 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound44518 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env44519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8202,5392,10280,1025,8541,12573,33,17,8543,8193,64,10588,5393,4097,10280,9225,8572,257,8573,5456,9053]

theorem envBound44519 : H12AffineFastState.Bounded env44519 := by
  intro p hp
  have h : env44519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44518_44519 : H12AffineEnvironment.transform 13 13405 env44518 = env44519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env44518 == env44519) = true)

theorem identity44519 : scanCanonicalize (H12AffineFastState.compose env44519 (packedSelected [2,5,6,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6477) := by decide +kernel

theorem selectedBound44519 : packedSelected [2,5,6,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env44520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6477,3344,6161,6471,5392,4453,1025,6160,2128,33,17,6162,6476,64,4113,5393,4097,4453,7492,6193,257,6192,5456,6672]

theorem envBound44520 : H12AffineFastState.Bounded env44520 := by
  intro p hp
  have h : env44520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44519_44520 : H12AffineEnvironment.transform 12 6477 env44519 = env44520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6477 env44519 == env44520) = true)

theorem identity44520 : scanCanonicalize (H12AffineFastState.compose env44520 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44520 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env44521 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,6200,3173,6161,6194,5221,4112,1025,6160,2128,33,17,6162,6201,64,4113,5220,4097,4112,7217,6193,116,6192,5157,6672]

theorem envBound44521 : H12AffineFastState.Bounded env44521 := by
  intro p hp
  have h : env44521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44520_44521 : H12AffineEnvironment.transform 7 117 env44520 = env44521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44520 == env44521) = true)

theorem identity44521 : scanCanonicalize (H12AffineFastState.compose env44521 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound44521 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env44522 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,64,2168,3173,2129,2162,1061,80,1025,2128,2128,33,17,2130,2169,64,81,1060,65,80,3185,2161,116,2160,1125,2640]

theorem envBound44522 : H12AffineFastState.Bounded env44522 := by
  intro p hp
  have h : env44522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44521_44522 : H12AffineEnvironment.transform 11 64 env44521 = env44522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env44521 == env44522) = true)

theorem identity44522 : scanCanonicalize (H12AffineFastState.compose env44522 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound44522 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44523 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,64,40,1077,1,34,1061,80,1025,0,0,33,17,2,41,64,81,1060,65,80,1057,33,116,32,1125,512]

theorem envBound44523 : H12AffineFastState.Bounded env44523 := by
  intro p hp
  have h : env44523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44522_44523 : H12AffineEnvironment.transform 10 80 env44522 = env44523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env44522 == env44523) = true)

theorem identity44523 : scanCanonicalize (H12AffineFastState.compose env44523 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound44523 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44524 : List Nat := [2,4,8,16,32,49,9,4,512,1024,33,49,40,1077,1,34,1061,33,1025,0,0,33,17,2,41,49,32,1060,48,33,1057,33,5,32,1044,512]

theorem envBound44524 : H12AffineFastState.Bounded env44524 := by
  intro p hp
  have h : env44524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44523_44524 : H12AffineEnvironment.transform 5 49 env44523 = env44524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env44523 == env44524) = true)

theorem identity44524 : scanCanonicalize (H12AffineFastState.compose env44524 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44524 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env44525 : List Nat := [2,4,8,16,32,49,9,4,512,53,33,49,40,0,1,34,16,33,52,0,0,33,17,2,41,49,32,17,48,33,20,33,5,32,33,512]

theorem envBound44525 : H12AffineFastState.Bounded env44525 := by
  intro p hp
  have h : env44525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44524_44525 : H12AffineEnvironment.transform 9 53 env44524 = env44525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44524 == env44525) = true)

def env44526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272513,180224,95496,8328,64,23945,185600,45524,262144,143641,400588,257,21792,46213,202446]

theorem envBound44526 : H12AffineFastState.Bounded env44526 := by
  intro p hp
  have h : env44526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44487_44526 : H12AffineEnvironment.transform 21 272513 env44487 = env44526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44487 == env44526) = true)

theorem identity44526 : scanCanonicalize (H12AffineFastState.compose env44526 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound44526 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,115871,272513,73755,95496,8328,64,23945,79131,45524,262144,119042,392407,257,21792,46213,63189]

theorem envBound44527 : H12AffineFastState.Bounded env44527 := by
  intro p hp
  have h : env44527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44526_44527 : H12AffineEnvironment.transform 16 122907 env44526 = env44527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env44526 == env44527) = true)

def env44528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10400,1025,32769,115871,33,73755,95496,8328,64,23945,79131,45524,10400,119042,119927,257,21792,46213,63189]

theorem envBound44528 : H12AffineFastState.Bounded env44528 := by
  intro p hp
  have h : env44528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44527_44528 : H12AffineEnvironment.transform 17 10400 env44527 = env44528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env44527 == env44528) = true)

theorem identity44528 : scanCanonicalize (H12AffineFastState.compose env44528 (packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound44528 : packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env44529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,5393,10400,1025,32769,12693,33,54545,32770,8328,64,23945,49169,45524,10400,9224,8573,257,21792,46213,63189]

theorem envBound44529 : H12AffineFastState.Bounded env44529 := by
  intro p hp
  have h : env44529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44528_44529 : H12AffineEnvironment.transform 15 62730 env44528 = env44529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env44528 == env44529) = true)

theorem identity44529 : scanCanonicalize (H12AffineFastState.compose env44529 (packedSelected [2,5,6,9,10,11,12,14,15,16,17,20,22,23,24,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound44529 : packedSelected [2,5,6,9,10,11,12,14,15,16,17,20,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env44530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,8323,5393,10400,1025,21896,12693,33,152,21899,8328,64,23945,5528,25693,10400,9224,8573,257,21792,24844,9052]

theorem envBound44530 : H12AffineFastState.Bounded env44530 := by
  intro p hp
  have h : env44530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44529_44530 : H12AffineEnvironment.transform 14 21897 env44529 = env44530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env44529 == env44530) = true)

theorem identity44530 : scanCanonicalize (H12AffineFastState.compose env44530 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound44530 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env44531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8661,8323,5393,10400,1025,8660,12693,33,152,8663,8328,64,10709,5528,4097,10400,9224,8573,257,8572,5456,9052]

theorem envBound44531 : H12AffineFastState.Bounded env44531 := by
  intro p hp
  have h : env44531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44530_44531 : H12AffineEnvironment.transform 13 13404 env44530 = env44531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env44530 == env44531) = true)

theorem identity44531 : scanCanonicalize (H12AffineFastState.compose env44531 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44531 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8541,8203,5393,10280,1025,8540,12573,33,16,8543,8192,64,10589,5392,4097,10280,9224,8573,257,8572,5456,9052]

theorem envBound44532 : H12AffineFastState.Bounded env44532 := by
  intro p hp
  have h : env44532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44531_44532 : H12AffineEnvironment.transform 6 8 env44531 = env44532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44531 == env44532) = true)

theorem identity44532 : scanCanonicalize (H12AffineFastState.compose env44532 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44532 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,81,263,5393,2340,1025,80,4113,33,16,83,268,64,2129,5392,4097,2340,1284,113,257,112,5456,592]

theorem envBound44533 : H12AffineFastState.Bounded env44533 := by
  intro p hp
  have h : env44533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44532_44533 : H12AffineEnvironment.transform 12 268 env44532 = env44533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44532 == env44533) = true)

theorem identity44533 : scanCanonicalize (H12AffineFastState.compose env44533 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44533 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44534 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1025,1,4113,33,16,2,268,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound44534 : H12AffineFastState.Bounded env44534 := by
  intro p hp
  have h : env44534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44533_44534 : H12AffineEnvironment.transform 5 17 env44533 = env44534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44533 == env44534) = true)

theorem identity44534 : scanCanonicalize (H12AffineFastState.compose env44534 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44534 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44535 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5172,2049,1025,1,4113,33,16,2,41,17,2048,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound44535 : H12AffineFastState.Bounded env44535 := by
  intro p hp
  have h : env44535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44534_44535 : H12AffineEnvironment.transform 7 37 env44534 = env44535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44534 == env44535) = true)

def env44536 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1044,0,34,1028,2049,1025,1,33,33,16,2,41,17,2048,1029,49,2049,1057,32,36,33,1044,513]

theorem envBound44536 : H12AffineFastState.Bounded env44536 := by
  intro p hp
  have h : env44536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44535_44536 : H12AffineEnvironment.transform 11 48 env44535 = env44536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44535 == env44536) = true)

theorem identity44536 : scanCanonicalize (H12AffineFastState.compose env44536 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound44536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44537 : List Nat := [2,4,8,16,32,17,8,37,512,548,2048,48,41,560,0,34,544,2049,549,1,33,33,16,2,41,17,2048,545,49,2049,517,32,36,33,560,513]

theorem envBound44537 : H12AffineFastState.Bounded env44537 := by
  intro p hp
  have h : env44537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44536_44537 : H12AffineEnvironment.transform 9 548 env44536 = env44537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env44536 == env44537) = true)

def env44538 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,48,41,32,0,34,48,2049,53,1,33,33,16,2,41,17,2048,49,49,2049,21,32,36,33,32,17]

theorem envBound44538 : H12AffineFastState.Bounded env44538 := by
  intro p hp
  have h : env44538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44537_44538 : H12AffineEnvironment.transform 8 16 env44537 = env44538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44537 == env44538) = true)

theorem identity44538 : scanCanonicalize (H12AffineFastState.compose env44538 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound44538 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44539 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,48,41,32,0,34,48,27,53,1,33,33,16,2,41,17,26,49,49,27,21,32,36,33,32,17]

theorem envBound44539 : H12AffineFastState.Bounded env44539 := by
  intro p hp
  have h : env44539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44538_44539 : H12AffineEnvironment.transform 10 26 env44538 = env44539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env44538 == env44539) = true)

def leafEnv44539 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,48,41,32,0,34,48,27,53,1,33,33,16,2,20,41,1,17,26,49,49,27,21,32,36,33,5,34,32,17,1,33,0]

def active44539 : List Nat := [0,1,2,3,4]

def tree44539 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44539 : H12WitnessSearch.Good tree44539 := H12GlobalWitnessIndex.good

theorem leafIdentity44539 : H12AffineFastState.composeSystem env44539 rootObs = leafEnv44539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44539 rootObs == leafEnv44539) = true)

theorem terminalChecked44539 : H12PackedTerminal.terminalCheckFast leafEnv44539 active44539 tree44539 = true := by decide +kernel

def env44540 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,48,41,33,0,34,49,2049,52,1,33,33,16,2,41,17,2048,48,49,2049,20,32,36,33,33,16]

theorem envBound44540 : H12AffineFastState.Bounded env44540 := by
  intro p hp
  have h : env44540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44537_44540 : H12AffineEnvironment.transform 8 17 env44537 = env44540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44537 == env44540) = true)

theorem identity44540 : scanCanonicalize (H12AffineFastState.compose env44540 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound44540 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44541 : List Nat := [2,4,8,16,32,17,8,37,17,53,32,48,41,33,0,34,49,33,52,1,33,33,16,2,41,17,32,48,49,33,20,32,36,33,33,16]

theorem envBound44541 : H12AffineFastState.Bounded env44541 := by
  intro p hp
  have h : env44541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44540_44541 : H12AffineEnvironment.transform 10 32 env44540 = env44541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env44540 == env44541) = true)

def leafEnv44541 : List Nat := [2,4,8,16,32,17,8,37,17,53,32,48,41,33,0,34,49,33,52,1,33,33,16,2,21,41,1,17,32,48,49,33,20,32,36,33,5,34,33,16,1,33,0]

def active44541 : List Nat := [0,1,2,3,4]

def tree44541 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44541 : H12WitnessSearch.Good tree44541 := H12GlobalWitnessIndex.good

theorem leafIdentity44541 : H12AffineFastState.composeSystem env44541 rootObs = leafEnv44541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44541 rootObs == leafEnv44541) = true)

theorem terminalChecked44541 : H12PackedTerminal.terminalCheckFast leafEnv44541 active44541 tree44541 = true := by decide +kernel

def env44542 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1045,0,34,1029,2049,1025,1,32,33,16,2,41,17,2048,1028,48,2049,1057,32,36,33,1045,513]

theorem envBound44542 : H12AffineFastState.Bounded env44542 := by
  intro p hp
  have h : env44542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44535_44542 : H12AffineEnvironment.transform 11 49 env44535 = env44542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env44535 == env44542) = true)

theorem identity44542 : scanCanonicalize (H12AffineFastState.compose env44542 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound44542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44543 : List Nat := [2,4,8,16,32,17,8,37,16,1024,2048,49,41,1045,0,34,1029,2049,1025,1,32,33,16,2,41,17,2048,1028,48,2049,1057,32,36,33,1045,17]

theorem envBound44543 : H12AffineFastState.Bounded env44543 := by
  intro p hp
  have h : env44543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44542_44543 : H12AffineEnvironment.transform 8 16 env44542 = env44543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44542 == env44543) = true)

def env44544 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,49,41,33,0,34,49,2049,53,1,32,33,16,2,41,17,2048,48,48,2049,21,32,36,33,33,17]

theorem envBound44544 : H12AffineFastState.Bounded env44544 := by
  intro p hp
  have h : env44544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44543_44544 : H12AffineEnvironment.transform 9 52 env44543 = env44544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44543 == env44544) = true)

theorem identity44544 : scanCanonicalize (H12AffineFastState.compose env44544 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound44544 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44545 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,49,41,33,0,34,49,27,53,1,32,33,16,2,41,17,26,48,48,27,21,32,36,33,33,17]

theorem envBound44545 : H12AffineFastState.Bounded env44545 := by
  intro p hp
  have h : env44545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44544_44545 : H12AffineEnvironment.transform 10 26 env44544 = env44545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env44544 == env44545) = true)

def leafEnv44545 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,49,41,33,0,34,49,27,53,1,32,33,16,2,20,41,1,17,26,48,48,27,21,32,36,33,5,34,33,17,1,32,0]

def active44545 : List Nat := [0,1,2,3,4]

def tree44545 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44545 : H12WitnessSearch.Good tree44545 := H12GlobalWitnessIndex.good

theorem leafIdentity44545 : H12AffineFastState.composeSystem env44545 rootObs = leafEnv44545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44545 rootObs == leafEnv44545) = true)

theorem terminalChecked44545 : H12PackedTerminal.terminalCheckFast leafEnv44545 active44545 tree44545 = true := by decide +kernel

def env44546 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,49,41,32,0,34,48,2049,52,1,32,33,16,2,41,17,2048,49,48,2049,20,32,36,33,32,17]

theorem envBound44546 : H12AffineFastState.Bounded env44546 := by
  intro p hp
  have h : env44546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44543_44546 : H12AffineEnvironment.transform 9 53 env44543 = env44546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44543 == env44546) = true)

theorem identity44546 : scanCanonicalize (H12AffineFastState.compose env44546 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound44546 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44547 : List Nat := [2,4,8,16,32,17,8,37,16,53,33,49,41,32,0,34,48,32,52,1,32,33,16,2,41,17,33,49,48,32,20,32,36,33,32,17]

theorem envBound44547 : H12AffineFastState.Bounded env44547 := by
  intro p hp
  have h : env44547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44546_44547 : H12AffineEnvironment.transform 10 33 env44546 = env44547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env44546 == env44547) = true)

def leafEnv44547 : List Nat := [2,4,8,16,32,17,8,37,16,53,33,49,41,32,0,34,48,32,52,1,32,33,16,2,21,41,1,17,33,49,48,32,20,32,36,33,5,34,32,17,1,32,0]

def active44547 : List Nat := [0,1,2,3,4]

def tree44547 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44547 : H12WitnessSearch.Good tree44547 := H12GlobalWitnessIndex.good

theorem leafIdentity44547 : H12AffineFastState.composeSystem env44547 rootObs = leafEnv44547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44547 rootObs == leafEnv44547) = true)

theorem terminalChecked44547 : H12PackedTerminal.terminalCheckFast leafEnv44547 active44547 tree44547 = true := by decide +kernel

def env44548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10401,1025,32769,115871,32,73755,95496,8328,64,23945,79131,45524,10401,119042,119926,257,21792,46213,63189]

theorem envBound44548 : H12AffineFastState.Bounded env44548 := by
  intro p hp
  have h : env44548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44527_44548 : H12AffineEnvironment.transform 17 10401 env44527 = env44548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env44527 == env44548) = true)

theorem identity44548 : scanCanonicalize (H12AffineFastState.compose env44548 (packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound44548 : packedSelected [0,3,4,5,7,8,10,11,17,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env44549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,70726,10401,1025,29788,78018,32,73755,95496,8328,64,23945,79131,17801,10401,75103,73771,257,21792,16600,648]

theorem envBound44549 : H12AffineFastState.Bounded env44549 := by
  intro p hp
  have h : env44549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44548_44549 : H12AffineEnvironment.transform 14 29789 env44548 = env44549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env44548 == env44549) = true)

theorem identity44549 : scanCanonicalize (H12AffineFastState.compose env44549 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound44549 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env44550 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29789,65536,70726,10361,1025,29788,77850,32,73755,95496,8272,64,23889,79131,17745,10361,75103,73771,257,21792,16384,592]

theorem envBound44550 : H12AffineFastState.Bounded env44550 := by
  intro p hp
  have h : env44550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44549_44550 : H12AffineEnvironment.transform 6 88 env44549 = env44550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env44549 == env44550) = true)

theorem identity44550 : scanCanonicalize (H12AffineFastState.compose env44550 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound44550 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44551 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5237,8232,65536,70726,10361,1025,8233,77850,32,73755,74109,8272,64,2340,79131,4388,10361,75103,73771,257,341,5237,592]

theorem envBound44551 : H12AffineFastState.Bounded env44551 := by
  intro p hp
  have h : env44551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44550_44551 : H12AffineEnvironment.transform 13 5237 env44550 = env44551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env44550 == env44551) = true)

theorem identity44551 : scanCanonicalize (H12AffineFastState.compose env44551 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,17,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound44551 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env44552 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5237,8232,8495,13673,10361,1025,8233,4405,32,308,82,8272,64,2340,5172,4388,10361,1136,260,257,341,5237,592]

theorem envBound44552 : H12AffineFastState.Bounded env44552 := by
  intro p hp
  have h : env44552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44551_44552 : H12AffineEnvironment.transform 15 8495 env44551 = env44552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env44551 == env44552) = true)

theorem identity44552 : scanCanonicalize (H12AffineFastState.compose env44552 (packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound44552 : packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env44553 : List Nat := [2,4,8,16,32,64,88,256,512,53,2048,4096,8192,4160,8232,8495,12636,10361,52,8233,4405,32,308,82,8272,64,2340,4097,4388,10361,69,260,257,341,4160,592]

theorem envBound44553 : H12AffineFastState.Bounded env44553 := by
  intro p hp
  have h : env44553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44552_44553 : H12AffineEnvironment.transform 9 53 env44552 = env44553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44552 == env44553) = true)

theorem identity44553 : scanCanonicalize (H12AffineFastState.compose env44553 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound44553 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env44554 : List Nat := [2,4,8,16,32,64,88,256,512,53,2048,4096,121,4160,81,342,4389,2048,52,80,4405,32,308,82,41,64,2340,4097,4388,2048,69,260,257,341,4160,592]

theorem envBound44554 : H12AffineFastState.Bounded env44554 := by
  intro p hp
  have h : env44554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44553_44554 : H12AffineEnvironment.transform 12 121 env44553 = env44554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env44553 == env44554) = true)

theorem identity44554 : scanCanonicalize (H12AffineFastState.compose env44554 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44554 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44555 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,40,4113,0,263,4389,2048,52,1,4405,32,308,3,41,17,2340,4097,4388,2048,20,260,257,260,4113,513]

theorem envBound44555 : H12AffineFastState.Bounded env44555 := by
  intro p hp
  have h : env44555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44554_44555 : H12AffineEnvironment.transform 5 17 env44554 = env44555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44554 == env44555) = true)

theorem identity44555 : scanCanonicalize (H12AffineFastState.compose env44555 (packedSelected [1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound44555 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env44556 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2608,40,2593,0,263,2837,2048,52,1,2821,32,308,3,41,17,2340,2609,2836,2048,20,260,257,260,2593,513]

theorem envBound44556 : H12AffineFastState.Bounded env44556 := by
  intro p hp
  have h : env44556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44555_44556 : H12AffineEnvironment.transform 11 2608 env44555 = env44556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env44555 == env44556) = true)

theorem identity44556 : scanCanonicalize (H12AffineFastState.compose env44556 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 772) := by decide +kernel

theorem selectedBound44556 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env44557 : List Nat := [2,4,8,16,32,17,9,256,512,53,772,308,40,293,0,263,17,772,52,1,1,32,308,3,41,17,544,309,16,772,20,260,257,260,293,513]

theorem envBound44557 : H12AffineFastState.Bounded env44557 := by
  intro p hp
  have h : env44557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44556_44557 : H12AffineEnvironment.transform 10 772 env44556 = env44557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env44556 == env44557) = true)

theorem identity44557 : scanCanonicalize (H12AffineFastState.compose env44557 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44557 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44558 : List Nat := [2,4,8,16,32,17,9,36,512,53,544,16,40,1,0,35,17,544,52,1,1,32,16,3,41,17,544,17,16,544,20,32,37,32,1,513]

theorem envBound44558 : H12AffineFastState.Bounded env44558 := by
  intro p hp
  have h : env44558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44557_44558 : H12AffineEnvironment.transform 7 36 env44557 = env44558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44557 == env44558) = true)

def env44559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,180225,95497,8328,64,4486408,185601,45525,262145,143641,4338764,257,21792,46213,202446]

theorem envBound44559 : H12AffineFastState.Bounded env44559 := by
  intro p hp
  have h : env44559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44486_44559 : H12AffineEnvironment.transform 22 180225 env44486 = env44559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env44486 == env44559) = true)

def env44560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272512,180225,95497,8328,64,23944,185601,45525,262145,143641,400588,257,21792,46213,202446]

theorem envBound44560 : H12AffineFastState.Bounded env44560 := by
  intro p hp
  have h : env44560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44559_44560 : H12AffineEnvironment.transform 21 272512 env44559 = env44560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env44559 == env44560) = true)

theorem identity44560 : scanCanonicalize (H12AffineFastState.compose env44560 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound44560 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,140420,272512,180225,41430,8328,64,23944,185601,45525,262145,143641,400588,257,21792,46213,180753]

theorem envBound44561 : H12AffineFastState.Bounded env44561 := by
  intro p hp
  have h : env44561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44560_44561 : H12AffineEnvironment.transform 15 54495 env44560 = env44561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env44560 == env44561) = true)

def env44562 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,140420,272512,180225,41350,8328,16,23944,185601,45445,262145,143641,400540,257,21792,46213,180753]

theorem envBound44562 : H12AffineFastState.Bounded env44562 := by
  intro p hp
  have h : env44562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44561_44562 : H12AffineEnvironment.transform 5 16 env44561 = env44562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44561 == env44562) = true)

theorem identity44562 : scanCanonicalize (H12AffineFastState.compose env44562 (packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS)) = affineNative (2^(16+1) ^^^ 46228) := by decide +kernel

theorem selectedBound44562 : packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS < 2^1333 := by decide +kernel

def env44563 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,46228,262144,1025,32769,36880,272512,29845,41350,8328,16,23944,24981,45445,262145,34189,305160,257,21792,46213,30341]

theorem envBound44563 : H12AffineFastState.Bounded env44563 := by
  intro p hp
  have h : env44563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44562_44563 : H12AffineEnvironment.transform 16 46228 env44562 = env44563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46228 env44562 == env44563) = true)

theorem identity44563 : scanCanonicalize (H12AffineFastState.compose env44563 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound44563 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env44564 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,46228,23588,1025,32769,36880,29860,29845,41350,8328,16,23944,24981,45445,23589,34189,62508,257,21792,46213,30341]

theorem envBound44564 : H12AffineFastState.Bounded env44564 := by
  intro p hp
  have h : env44564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44563_44564 : H12AffineEnvironment.transform 17 23588 env44563 = env44564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env44563 == env44564) = true)

theorem identity44564 : scanCanonicalize (H12AffineFastState.compose env44564 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound44564 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env44565 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,33031,46228,2476,1025,32769,36880,8492,8477,41350,8328,16,2048,13341,45445,2477,34189,41380,257,168,46213,8973]

theorem envBound44565 : H12AffineFastState.Bounded env44565 := by
  intro p hp
  have h : env44565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44564_44565 : H12AffineEnvironment.transform 13 5512 env44564 = env44565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env44564 == env44565) = true)

theorem identity44565 : scanCanonicalize (H12AffineFastState.compose env44565 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44565 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env44566 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,32768,33031,46109,2341,1025,32769,36880,8492,8477,41231,8193,16,2048,13341,45324,2340,34052,41261,257,33,46092,8973]

theorem envBound44566 : H12AffineFastState.Bounded env44566 := by
  intro p hp
  have h : env44566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44565_44566 : H12AffineEnvironment.transform 6 9 env44565 = env44566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44565 == env44566) = true)

theorem identity44566 : scanCanonicalize (H12AffineFastState.compose env44566 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound44566 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44567 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,292,35,13625,2341,1025,293,4404,8492,8477,8235,8193,16,2048,13341,12328,2340,1056,8201,257,33,13608,8973]

theorem envBound44567 : H12AffineFastState.Bounded env44567 := by
  intro p hp
  have h : env44567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44566_44567 : H12AffineEnvironment.transform 14 292 env44566 = env44567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env44566 == env44567) = true)

theorem identity44567 : scanCanonicalize (H12AffineFastState.compose env44567 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44567 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44568 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5377,292,35,5392,2341,1025,293,4404,261,308,2,40,16,2048,5172,4097,2340,1056,32,257,33,5377,804]

theorem envBound44568 : H12AffineFastState.Bounded env44568 := by
  intro p hp
  have h : env44568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44567_44568 : H12AffineEnvironment.transform 12 41 env44567 = env44568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44567 == env44568) = true)

theorem identity44568 : scanCanonicalize (H12AffineFastState.compose env44568 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound44568 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44569 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,41,293,292,35,308,2341,1025,293,1296,261,308,2,40,16,2048,16,1061,2340,1056,32,257,33,293,804]

theorem envBound44569 : H12AffineFastState.Bounded env44569 := by
  intro p hp
  have h : env44569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44568_44569 : H12AffineEnvironment.transform 11 1060 env44568 = env44569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env44568 == env44569) = true)

theorem identity44569 : scanCanonicalize (H12AffineFastState.compose env44569 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44569 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44570 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,1060,41,0,1,35,17,2048,1025,0,1077,32,17,2,40,16,2048,16,1061,2049,1056,32,36,33,0,513]

theorem envBound44570 : H12AffineFastState.Bounded env44570 := by
  intro p hp
  have h : env44570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44569_44570 : H12AffineEnvironment.transform 7 37 env44569 = env44570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44569 == env44570) = true)

def env44571 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,140420,272512,180225,41351,8328,17,23944,185601,45444,262145,143641,400541,257,21792,46213,180753]

theorem envBound44571 : H12AffineFastState.Bounded env44571 := by
  intro p hp
  have h : env44571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44561_44571 : H12AffineEnvironment.transform 5 17 env44561 = env44571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44561 == env44571) = true)

theorem identity44571 : scanCanonicalize (H12AffineFastState.compose env44571 (packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound44571 : packedSelected [4,7,9,10,12,19,26,27,31,41] rootPS < 2^1333 := by decide +kernel

def env44572 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,157753,1025,32769,140420,147641,180225,41351,8328,17,23944,185601,45444,157752,143641,29860,257,21792,46213,180753]

theorem envBound44572 : H12AffineFastState.Bounded env44572 := by
  intro p hp
  have h : env44572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44571_44572 : H12AffineEnvironment.transform 17 157753 env44571 = env44572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env44571 == env44572) = true)

theorem identity44572 : scanCanonicalize (H12AffineFastState.compose env44572 (packedSelected [1,4,5,7,8,9,10,11,16,18,20,23,24,27,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound44572 : packedSelected [1,4,5,7,8,9,10,11,16,18,20,23,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env44573 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,49304,43169,1025,32769,58396,32801,153,41351,8328,17,23944,5529,45444,43168,61825,29860,257,21792,46213,649]

theorem envBound44573 : H12AffineFastState.Bounded env44573 := by
  intro p hp
  have h : env44573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44572_44573 : H12AffineEnvironment.transform 16 49304 env44572 = env44573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env44572 == env44573) = true)

theorem identity44573 : scanCanonicalize (H12AffineFastState.compose env44573 (packedSelected [3,5,10,12,15,16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44573 : packedSelected [3,5,10,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env44574 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,32768,54414,49304,35245,1025,32769,50448,32801,153,32907,388,17,23944,5529,37000,35244,53389,21928,257,21792,38281,649]

theorem envBound44574 : H12AffineFastState.Bounded env44574 := by
  intro p hp
  have h : env44574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44573_44574 : H12AffineEnvironment.transform 12 268 env44573 = env44574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44573 == env44574) = true)

theorem identity44574 : scanCanonicalize (H12AffineFastState.compose env44574 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound44574 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44575 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,137,21511,16401,2340,1025,136,17817,168,153,2,388,17,23944,5529,4097,2341,20484,21928,257,21792,5376,649]

theorem envBound44575 : H12AffineFastState.Bounded env44575 := by
  intro p hp
  have h : env44575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44574_44575 : H12AffineEnvironment.transform 14 137 env44574 = env44575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env44574 == env44575) = true)

theorem identity44575 : scanCanonicalize (H12AffineFastState.compose env44575 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound44575 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env44576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,137,262,5392,2340,1025,136,4248,168,153,2,388,17,2185,5529,4097,2341,1285,169,257,33,5376,649]

theorem envBound44576 : H12AffineFastState.Bounded env44576 := by
  intro p hp
  have h : env44576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44575_44576 : H12AffineEnvironment.transform 13 5377 env44575 = env44576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44575 == env44576) = true)

theorem identity44576 : scanCanonicalize (H12AffineFastState.compose env44576 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound44576 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env44577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,308,268,1077,137,262,1060,2340,1025,136,428,168,153,2,388,17,2185,1197,309,2341,1285,169,257,33,1076,649]

theorem envBound44577 : H12AffineFastState.Bounded env44577 := by
  intro p hp
  have h : env44577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44576_44577 : H12AffineEnvironment.transform 11 308 env44576 = env44577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env44576 == env44577) = true)

theorem identity44577 : scanCanonicalize (H12AffineFastState.compose env44577 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound44577 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env44578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1076,308,268,1077,137,262,1060,1296,1025,136,428,168,153,2,388,17,1213,1197,309,1297,1285,169,257,33,1076,649]

theorem envBound44578 : H12AffineFastState.Bounded env44578 := by
  intro p hp
  have h : env44578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44577_44578 : H12AffineEnvironment.transform 10 1076 env44577 = env44578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env44577 == env44578) = true)

theorem identity44578 : scanCanonicalize (H12AffineFastState.compose env44578 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound44578 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44579 : List Nat := [2,4,8,16,32,17,128,256,512,189,137,308,268,136,137,262,153,429,188,136,428,168,153,2,388,17,0,16,309,428,440,169,257,33,137,649]

theorem envBound44579 : H12AffineFastState.Bounded env44579 := by
  intro p hp
  have h : env44579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44578_44579 : H12AffineEnvironment.transform 9 189 env44578 = env44579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env44578 == env44579) = true)

def env44580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272513,180225,95497,8328,64,23945,185601,45525,262145,143641,400589,257,21792,46213,202446]

theorem envBound44580 : H12AffineFastState.Bounded env44580 := by
  intro p hp
  have h : env44580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44559_44580 : H12AffineEnvironment.transform 21 272513 env44559 = env44580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env44559 == env44580) = true)

theorem identity44580 : scanCanonicalize (H12AffineFastState.compose env44580 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound44580 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,77899,272513,120014,95497,8328,64,23945,115150,45525,262145,75222,329730,257,21792,46213,513]

theorem envBound44581 : H12AffineFastState.Bounded env44581 := by
  intro p hp
  have h : env44581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44580_44581 : H12AffineEnvironment.transform 16 70863 env44580 = env44581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env44580 == env44581) = true)

def env44582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,77899,272393,119878,95497,8192,64,23809,115014,45405,262145,75102,329730,257,21792,46093,513]

theorem envBound44582 : H12AffineFastState.Bounded env44582 := by
  intro p hp
  have h : env44582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44581_44582 : H12AffineEnvironment.transform 6 8 env44581 = env44582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44581 == env44582) = true)

def env44583 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77899,272392,119879,95497,8193,64,23808,115015,45404,262145,75103,329730,257,21792,46092,513]

theorem envBound44583 : H12AffineFastState.Bounded env44583 := by
  intro p hp
  have h : env44583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44581_44583 : H12AffineEnvironment.transform 6 9 env44581 = env44583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44581 == env44583) = true)

theorem identity44583 : scanCanonicalize (H12AffineFastState.compose env44583 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound44583 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44584 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,70726,262144,1025,32769,77899,272392,106522,65876,8193,64,10589,111898,45404,262145,75103,329730,257,8573,46092,513]

theorem envBound44584 : H12AffineFastState.Bounded env44584 := by
  intro p hp
  have h : env44584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0