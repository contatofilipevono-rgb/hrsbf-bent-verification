import H12CloudChart0Data016

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans4191_4192 : H12AffineEnvironment.transform 7 4 env4191 = env4192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4191 == env4192) = true)

def env4193 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,4096,8192,16384,13729,25899,4524,262144,1024,13729,4097,4194304,4194336,5514,8329,4194336,279841,16384,16813,22561,16641,17581,256,20480,4195468,4195213]

theorem envBound4193 : H12AffineFastState.Bounded env4193 := by
  intro p hp
  have h : env4193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4189_4193 : H12AffineEnvironment.transform 3 1 env4189 = env4193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4189 == env4193) = true)

def env4194 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1280,8192,16384,8353,25899,1196,262144,1024,8353,1281,4194304,4194336,138,8329,4194336,279841,16384,16813,19745,16641,17581,256,17664,4195468,4195213]

theorem envBound4194 : H12AffineFastState.Bounded env4194 := by
  intro p hp
  have h : env4194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4193_4194 : H12AffineEnvironment.transform 11 1280 env4193 = env4194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env4193 == env4194) = true)

theorem identity4194 : scanCanonicalize (H12AffineFastState.compose env4194 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 282024) := by decide +kernel

theorem selectedBound4194 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4195 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1280,8192,16384,8353,25899,1196,262144,1024,8353,1281,282024,281992,138,8329,281992,279841,16384,16813,19745,16641,17581,256,17664,280868,282149]

theorem envBound4195 : H12AffineFastState.Bounded env4195 := by
  intro p hp
  have h : env4195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4194_4195 : H12AffineEnvironment.transform 21 282024 env4194 = env4195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 282024 env4194 == env4195) = true)

theorem identity4195 : scanCanonicalize (H12AffineFastState.compose env4195 (packedSelected [2,3,4,5,6,9,10,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 2310) := by decide +kernel

theorem selectedBound4195 : packedSelected [2,3,4,5,6,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env4196 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1280,2310,16384,2471,19501,1196,262144,1024,2471,1281,282024,281992,138,2447,281992,279841,16384,16813,19745,16641,17581,256,17664,280868,282149]

theorem envBound4196 : H12AffineFastState.Bounded env4196 := by
  intro p hp
  have h : env4196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4195_4196 : H12AffineEnvironment.transform 12 2310 env4195 = env4196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2310 env4195 == env4196) = true)

theorem identity4196 : scanCanonicalize (H12AffineFastState.compose env4196 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4196 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env4197 : List Nat := [2,4,8,1,32,1,41,256,512,1024,2048,1280,2310,16384,2318,19501,1029,262144,1024,2318,1281,281857,281889,35,2342,281889,279841,16384,16644,19745,16641,17412,256,17664,280868,282149]

theorem envBound4197 : H12AffineFastState.Bounded env4197 := by
  intro p hp
  have h : env4197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4196_4197 : H12AffineEnvironment.transform 6 41 env4196 = env4197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4196 == env4197) = true)

theorem identity4197 : scanCanonicalize (H12AffineFastState.compose env4197 (packedSelected [1,4,6,8,9,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 261) := by decide +kernel

theorem selectedBound4197 : packedSelected [1,4,6,8,9,13,15] rootPS < 2^1333 := by decide +kernel

def env4198 : List Nat := [2,4,8,1,32,1,41,256,512,1024,2048,1280,2310,261,2318,3368,1029,262144,1024,2318,1281,265220,265252,35,2342,265252,263204,261,1,3108,4,1281,256,1029,264225,266016]

theorem envBound4198 : H12AffineFastState.Bounded env4198 := by
  intro p hp
  have h : env4198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4197_4198 : H12AffineEnvironment.transform 13 261 env4197 = env4198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 261 env4197 == env4198) = true)

theorem identity4198 : scanCanonicalize (H12AffineFastState.compose env4198 (packedSelected [0,1,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound4198 : packedSelected [0,1,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env4199 : List Nat := [2,4,8,1,32,1,41,256,512,548,2048,804,2310,261,2318,2828,545,262144,548,2318,805,264736,264704,35,2342,264704,262656,261,1,2560,4,805,256,545,264225,264452]

theorem envBound4199 : H12AffineFastState.Bounded env4199 := by
  intro p hp
  have h : env4199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4198_4199 : H12AffineEnvironment.transform 9 548 env4198 = env4199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env4198 == env4199) = true)

theorem identity4199 : scanCanonicalize (H12AffineFastState.compose env4199 (packedSelected [0,2,3,6,7,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound4199 : packedSelected [0,2,3,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env4200 : List Nat := [2,4,8,1,32,1,41,256,512,548,2048,804,2310,261,2318,2828,545,554,548,2318,805,2058,2090,35,2342,2090,42,261,1,2560,4,805,256,545,2571,2862]

theorem envBound4200 : H12AffineFastState.Bounded env4200 := by
  intro p hp
  have h : env4200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4199_4200 : H12AffineEnvironment.transform 17 554 env4199 = env4200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env4199 == env4200) = true)

theorem identity4200 : scanCanonicalize (H12AffineFastState.compose env4200 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound4200 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env4201 : List Nat := [2,4,8,1,32,1,41,256,512,548,523,804,781,261,773,263,545,554,548,773,805,513,545,35,813,545,42,261,1,11,4,805,256,545,0,293]

theorem envBound4201 : H12AffineFastState.Bounded env4201 := by
  intro p hp
  have h : env4201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4200_4201 : H12AffineEnvironment.transform 10 523 env4200 = env4201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env4200 == env4201) = true)

theorem identity4201 : scanCanonicalize (H12AffineFastState.compose env4201 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4201 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env4202 : List Nat := [2,4,8,1,1,1,8,256,512,517,523,773,781,261,773,263,512,523,517,773,772,513,512,2,780,512,11,261,1,11,4,772,256,512,0,260]

theorem envBound4202 : H12AffineFastState.Bounded env4202 := by
  intro p hp
  have h : env4202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4201_4202 : H12AffineEnvironment.transform 4 1 env4201 = env4202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4201 == env4202) = true)

theorem identity4202 : scanCanonicalize (H12AffineFastState.compose env4202 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4202 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4203 : List Nat := [2,4,8,1,1,1,8,4,512,517,523,513,521,1,513,3,512,523,517,513,512,513,512,2,520,512,11,1,1,11,4,512,4,512,0,0]

theorem envBound4203 : H12AffineFastState.Bounded env4203 := by
  intro p hp
  have h : env4203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4202_4203 : H12AffineEnvironment.transform 7 4 env4202 = env4203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4202 == env4203) = true)

theorem identity4203 : scanCanonicalize (H12AffineFastState.compose env4203 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4203 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4204 : List Nat := [2,4,2,1,1,1,2,4,512,517,513,513,515,1,513,3,512,513,517,513,512,513,512,2,514,512,1,1,1,1,4,512,4,512,0,0]

theorem envBound4204 : H12AffineFastState.Bounded env4204 := by
  intro p hp
  have h : env4204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4203_4204 : H12AffineEnvironment.transform 2 2 env4203 = env4204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4203 == env4204) = true)

def env4205 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1281,8192,16384,8352,25899,1197,262144,1024,8352,1280,4194304,4194336,139,8329,4194336,279841,16384,16813,19744,16641,17581,256,17665,4195468,4195213]

theorem envBound4205 : H12AffineFastState.Bounded env4205 := by
  intro p hp
  have h : env4205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4193_4205 : H12AffineEnvironment.transform 11 1281 env4193 = env4205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env4193 == env4205) = true)

theorem identity4205 : scanCanonicalize (H12AffineFastState.compose env4205 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4205 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4206 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1281,8192,16384,8352,25899,1197,2080,1024,8352,1280,4194304,4194336,139,8329,4194336,19713,16384,16813,19744,16641,17581,256,17665,4195468,4195213]

theorem envBound4206 : H12AffineFastState.Bounded env4206 := by
  intro p hp
  have h : env4206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4205_4206 : H12AffineEnvironment.transform 17 2080 env4205 = env4206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4205 == env4206) = true)

theorem identity4206 : scanCanonicalize (H12AffineFastState.compose env4206 (packedSelected [0,1,7,8,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 11529) := by decide +kernel

theorem selectedBound4206 : packedSelected [0,1,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env4207 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1281,8192,11529,8352,2082,1197,2080,1024,8352,1280,4194304,4194336,139,8329,4194336,8200,11529,11428,8233,11272,10660,256,10248,4195468,4195213]

theorem envBound4207 : H12AffineFastState.Bounded env4207 := by
  intro p hp
  have h : env4207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4206_4207 : H12AffineEnvironment.transform 13 11529 env4206 = env4207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11529 env4206 == env4207) = true)

theorem identity4207 : scanCanonicalize (H12AffineFastState.compose env4207 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4207 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env4208 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1196,8192,11428,8352,2082,1197,2080,1024,8352,1197,4194304,4194336,139,8329,4194336,8200,11428,11428,8233,11272,10249,173,10248,4195468,4194848]

theorem envBound4208 : H12AffineFastState.Bounded env4208 := by
  intro p hp
  have h : env4208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4207_4208 : H12AffineEnvironment.transform 7 173 env4207 = env4208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4207 == env4208) = true)

theorem identity4208 : scanCanonicalize (H12AffineFastState.compose env4208 (packedSelected [1,2,3] rootPS)) = affineNative (2^(21+1) ^^^ 10249) := by decide +kernel

theorem selectedBound4208 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4209 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1196,8192,11428,8352,2082,1197,2080,1024,8352,1197,10249,10281,139,8329,10281,8200,11428,11428,8233,11272,10249,173,10248,11397,10793]

theorem envBound4209 : H12AffineFastState.Bounded env4209 := by
  intro p hp
  have h : env4209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4208_4209 : H12AffineEnvironment.transform 21 10249 env4208 = env4209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env4208 == env4209) = true)

theorem identity4209 : scanCanonicalize (H12AffineFastState.compose env4209 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound4209 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env4210 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1196,2089,1165,2185,2082,1197,2080,1024,2185,1197,32,0,139,2208,0,2081,1165,1165,2048,1057,32,173,33,1196,512]

theorem envBound4210 : H12AffineFastState.Bounded env4210 := by
  intro p hp
  have h : env4210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4209_4210 : H12AffineEnvironment.transform 12 2089 env4209 = env4210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env4209 == env4210) = true)

theorem identity4210 : scanCanonicalize (H12AffineFastState.compose env4210 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4210 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4211 : List Nat := [2,4,8,1,0,1,128,141,512,1024,2048,1164,2057,1165,2185,2050,1165,2048,1024,2185,1165,0,0,139,2176,0,2049,1165,1165,2048,1025,0,141,1,1164,512]

theorem envBound4211 : H12AffineFastState.Bounded env4211 := by
  intro p hp
  have h : env4211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4210_4211 : H12AffineEnvironment.transform 4 0 env4210 = env4211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4210 == env4211) = true)

theorem identity4211 : scanCanonicalize (H12AffineFastState.compose env4211 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound4211 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4212 : List Nat := [2,4,8,1,0,1,128,141,512,1024,1039,1164,1030,1165,1158,1037,1165,1039,1024,1158,1165,0,0,139,1167,0,1038,1165,1165,1039,1025,0,141,1,1164,512]

theorem envBound4212 : H12AffineFastState.Bounded env4212 := by
  intro p hp
  have h : env4212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4211_4212 : H12AffineEnvironment.transform 10 1039 env4211 = env4212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env4211 == env4212) = true)

theorem identity4212 : scanCanonicalize (H12AffineFastState.compose env4212 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4212 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4213 : List Nat := [2,4,8,1,0,1,128,141,1,1024,1039,1164,1030,1165,1158,1037,1165,1039,1024,1158,1165,0,0,139,1167,0,1038,1165,1165,1039,1025,0,141,1,1164,1]

theorem envBound4213 : H12AffineFastState.Bounded env4213 := by
  intro p hp
  have h : env4213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4212_4213 : H12AffineEnvironment.transform 8 1 env4212 = env4213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4212 == env4213) = true)

theorem identity4213 : scanCanonicalize (H12AffineFastState.compose env4213 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound4213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4214 : List Nat := [2,4,8,1,0,1,128,141,1,14,1,130,8,131,136,3,131,1,14,136,131,0,0,139,129,0,0,131,131,1,15,0,141,1,130,1]

theorem envBound4214 : H12AffineFastState.Bounded env4214 := by
  intro p hp
  have h : env4214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4213_4214 : H12AffineEnvironment.transform 9 14 env4213 = env4214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env4213 == env4214) = true)

theorem identity4214 : scanCanonicalize (H12AffineFastState.compose env4214 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4214 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env4215 : List Nat := [2,4,2,1,0,1,128,135,1,4,1,130,2,131,130,3,131,1,4,130,131,0,0,129,129,0,0,131,131,1,5,0,135,1,130,1]

theorem envBound4215 : H12AffineFastState.Bounded env4215 := by
  intro p hp
  have h : env4215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4214_4215 : H12AffineEnvironment.transform 2 2 env4214 = env4215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4214 == env4215) = true)

theorem identity4215 : scanCanonicalize (H12AffineFastState.compose env4215 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound4215 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4216 : List Nat := [2,4,2,1,0,1,3,4,1,4,1,1,2,0,1,3,0,1,4,1,0,0,0,2,2,0,0,0,0,1,5,0,4,1,1,1]

theorem envBound4216 : H12AffineFastState.Bounded env4216 := by
  intro p hp
  have h : env4216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4215_4216 : H12AffineEnvironment.transform 6 3 env4215 = env4216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env4215 == env4216) = true)

def env4217 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4097,4194304,4240785,41003,8329,4240785,323712,16384,16813,22561,16656,17580,256,20480,4239677,4240941]

theorem envBound4217 : H12AffineFastState.Bounded env4217 := by
  intro p hp
  have h : env4217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4187_4217 : H12AffineEnvironment.transform 22 4240785 env4187 = env4217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240785 env4187 == env4217) = true)

theorem identity4217 : scanCanonicalize (H12AffineFastState.compose env4217 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound4217 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4218 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13341,25914,4524,262144,1024,13341,4097,4194304,4194700,5174,8329,4194700,279709,16384,16813,22561,16656,17580,256,20480,4195616,4194864]

theorem envBound4218 : H12AffineFastState.Bounded env4218 := by
  intro p hp
  have h : env4218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4217_4218 : H12AffineEnvironment.transform 14 13341 env4217 = env4218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env4217 == env4218) = true)

def env4219 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1280,8192,16384,8477,25914,1196,262144,1024,8477,1281,4194304,4194700,310,8329,4194700,279709,16384,16813,19745,16656,17580,256,17664,4195616,4194864]

theorem envBound4219 : H12AffineFastState.Bounded env4219 := by
  intro p hp
  have h : env4219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4218_4219 : H12AffineEnvironment.transform 11 1280 env4218 = env4219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env4218 == env4219) = true)

theorem identity4219 : scanCanonicalize (H12AffineFastState.compose env4219 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound4219 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4220 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1045,8192,16384,8200,25647,1196,262144,1024,8200,1044,4194304,4194457,35,8329,4194457,279709,16384,16568,19508,16389,17580,21,17429,4195381,4194864]

theorem envBound4220 : H12AffineFastState.Bounded env4220 := by
  intro p hp
  have h : env4220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4219_4220 : H12AffineEnvironment.transform 7 21 env4219 = env4220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env4219 == env4220) = true)

theorem identity4220 : scanCanonicalize (H12AffineFastState.compose env4220 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound4220 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4221 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1045,8192,16384,8200,25647,1196,262144,1024,8200,1044,32,185,35,8329,185,279709,16384,16568,19508,16389,17580,21,17429,1045,528]

theorem envBound4221 : H12AffineFastState.Bounded env4221 := by
  intro p hp
  have h : env4221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4220_4221 : H12AffineEnvironment.transform 21 32 env4220 = env4221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4220 == env4221) = true)

theorem identity4221 : scanCanonicalize (H12AffineFastState.compose env4221 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4221 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4222 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1045,8192,16384,8200,25647,1196,2080,1024,8200,1044,32,185,35,8329,185,19645,16384,16568,19508,16389,17580,21,17429,1045,528]

theorem envBound4222 : H12AffineFastState.Bounded env4222 := by
  intro p hp
  have h : env4222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4221_4222 : H12AffineEnvironment.transform 17 2080 env4221 = env4222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4221 == env4222) = true)

theorem identity4222 : scanCanonicalize (H12AffineFastState.compose env4222 (packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound4222 : packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS < 2^1333 := by decide +kernel

def env4223 : List Nat := [2,4,8,16,32,16,57,21,512,1024,2048,1045,8192,16384,8200,25647,1045,2080,1024,8200,1044,32,0,35,8240,0,19460,16384,16385,19508,16389,17429,21,17429,1045,528]

theorem envBound4223 : H12AffineFastState.Bounded env4223 := by
  intro p hp
  have h : env4223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4222_4223 : H12AffineEnvironment.transform 6 57 env4222 = env4223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env4222 == env4223) = true)

theorem identity4223 : scanCanonicalize (H12AffineFastState.compose env4223 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4223 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env4224 : List Nat := [2,4,8,1,32,1,40,4,512,1024,2048,1028,8192,16384,8200,25647,1028,2080,1024,8200,1029,32,0,35,8225,0,19460,16384,16385,19493,16389,17412,4,17412,1028,513]

theorem envBound4224 : H12AffineFastState.Bounded env4224 := by
  intro p hp
  have h : env4224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4223_4224 : H12AffineEnvironment.transform 3 1 env4223 = env4224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4223 == env4224) = true)

theorem identity4224 : scanCanonicalize (H12AffineFastState.compose env4224 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 47) := by decide +kernel

theorem selectedBound4224 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env4225 : List Nat := [2,4,8,1,32,1,40,4,512,1024,47,1028,8192,16384,8200,25647,1028,15,1024,8200,1029,32,0,35,8225,0,17451,16384,16385,17418,16389,17412,4,17412,1028,513]

theorem envBound4225 : H12AffineFastState.Bounded env4225 := by
  intro p hp
  have h : env4225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4224_4225 : H12AffineEnvironment.transform 10 47 env4224 = env4225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 47 env4224 == env4225) = true)

theorem identity4225 : scanCanonicalize (H12AffineFastState.compose env4225 (packedSelected [5] rootPS)) = affineNative (2^(13+1) ^^^ 5) := by decide +kernel

theorem selectedBound4225 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4226 : List Nat := [2,4,8,1,32,1,40,4,512,1024,47,1028,8192,5,8200,9258,1028,15,1024,8200,1029,32,0,35,8225,0,1070,5,4,1039,0,1025,4,1025,1028,513]

theorem envBound4226 : H12AffineFastState.Bounded env4226 := by
  intro p hp
  have h : env4226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4225_4226 : H12AffineEnvironment.transform 13 5 env4225 = env4226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5 env4225 == env4226) = true)

theorem identity4226 : scanCanonicalize (H12AffineFastState.compose env4226 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 513) := by decide +kernel

theorem selectedBound4226 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4227 : List Nat := [2,4,8,1,32,1,40,4,512,513,47,517,8192,5,8200,8747,517,15,513,8200,516,32,0,35,8225,0,559,5,4,526,0,512,4,512,517,513]

theorem envBound4227 : H12AffineFastState.Bounded env4227 := by
  intro p hp
  have h : env4227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4226_4227 : H12AffineEnvironment.transform 9 513 env4226 = env4227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 513 env4226 == env4227) = true)

theorem identity4227 : scanCanonicalize (H12AffineFastState.compose env4227 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4227 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4228 : List Nat := [2,4,8,1,32,1,40,4,32,33,47,37,8192,5,8200,8203,37,15,33,8200,36,32,0,35,8225,0,15,5,4,46,0,32,4,32,37,33]

theorem envBound4228 : H12AffineFastState.Bounded env4228 := by
  intro p hp
  have h : env4228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4227_4228 : H12AffineEnvironment.transform 8 32 env4227 = env4228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4227 == env4228) = true)

theorem identity4228 : scanCanonicalize (H12AffineFastState.compose env4228 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound4228 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4229 : List Nat := [2,4,8,1,15,1,7,4,15,14,0,10,8192,5,8200,8203,10,15,14,8200,11,15,0,12,8206,0,15,5,4,1,0,15,4,15,10,14]

theorem envBound4229 : H12AffineFastState.Bounded env4229 := by
  intro p hp
  have h : env4229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4228_4229 : H12AffineEnvironment.transform 4 15 env4228 = env4229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env4228 == env4229) = true)

theorem identity4229 : scanCanonicalize (H12AffineFastState.compose env4229 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 6) := by decide +kernel

theorem selectedBound4229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4230 : List Nat := [2,4,8,1,15,1,7,4,15,14,0,10,6,5,14,13,10,15,14,14,11,15,0,12,8,0,15,5,4,1,0,15,4,15,10,14]

theorem envBound4230 : H12AffineFastState.Bounded env4230 := by
  intro p hp
  have h : env4230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4229_4230 : H12AffineEnvironment.transform 12 6 env4229 = env4230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6 env4229 == env4230) = true)

theorem identity4230 : scanCanonicalize (H12AffineFastState.compose env4230 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4231 : List Nat := [2,4,3,1,4,1,7,4,4,5,0,1,6,5,5,6,1,4,5,5,0,4,0,7,3,0,4,5,4,1,0,4,4,4,1,5]

theorem envBound4231 : H12AffineFastState.Bounded env4231 := by
  intro p hp
  have h : env4231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4230_4231 : H12AffineEnvironment.transform 2 3 env4230 = env4231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4230 == env4231) = true)

def leafEnv4231 : List Nat := [2,4,3,1,4,1,7,4,4,5,0,1,6,5,5,6,1,4,5,5,0,4,0,7,1,3,1,0,4,5,4,1,0,4,4,4,5,2,1,5,1,5,0]

def active4231 : List Nat := [0,1]

def tree4231 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4231 : H12WitnessSearch.Good tree4231 := H12GlobalWitnessIndex.good

theorem leafIdentity4231 : H12AffineFastState.composeSystem env4231 rootObs = leafEnv4231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4231 rootObs == leafEnv4231) = true)

theorem terminalChecked4231 : H12PackedTerminal.terminalCheckFast leafEnv4231 active4231 tree4231 = true := by decide +kernel

def env4232 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1281,8192,16384,8476,25914,1197,262144,1024,8476,1280,4194304,4194700,311,8329,4194700,279709,16384,16813,19744,16656,17580,256,17665,4195616,4194864]

theorem envBound4232 : H12AffineFastState.Bounded env4232 := by
  intro p hp
  have h : env4232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4218_4232 : H12AffineEnvironment.transform 11 1281 env4218 = env4232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env4218 == env4232) = true)

theorem identity4232 : scanCanonicalize (H12AffineFastState.compose env4232 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4232 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4233 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1196,8192,16384,8369,25751,1197,262144,1024,8369,1197,4194304,4194337,154,8329,4194337,279709,16384,16384,19597,16573,17580,173,17580,4195469,4194864]

theorem envBound4233 : H12AffineFastState.Bounded env4233 := by
  intro p hp
  have h : env4233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4232_4233 : H12AffineEnvironment.transform 7 173 env4232 = env4233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4232 == env4233) = true)

theorem identity4233 : scanCanonicalize (H12AffineFastState.compose env4233 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4233 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4234 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,8192,16384,8216,25662,1028,262144,1024,8216,1028,4194304,4194337,51,8224,4194337,279604,16384,16384,19492,16404,17413,4,17413,4195364,4194864]

theorem envBound4234 : H12AffineFastState.Bounded env4234 := by
  intro p hp
  have h : env4234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4233_4234 : H12AffineEnvironment.transform 6 41 env4233 = env4234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4233 == env4234) = true)

theorem identity4234 : scanCanonicalize (H12AffineFastState.compose env4234 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound4234 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4235 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,8192,16384,8216,25662,1028,262144,1024,8216,1028,32,1,51,8224,1,279604,16384,16384,19492,16404,17413,4,17413,1028,528]

theorem envBound4235 : H12AffineFastState.Bounded env4235 := by
  intro p hp
  have h : env4235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4234_4235 : H12AffineEnvironment.transform 21 32 env4234 = env4235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4234 == env4235) = true)

theorem identity4235 : scanCanonicalize (H12AffineFastState.compose env4235 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 19508) := by decide +kernel

theorem selectedBound4235 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4236 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,8192,16384,8216,25662,1028,19508,1024,8216,1028,32,1,51,8224,1,2048,16384,16384,19492,16404,17413,4,17413,1028,528]

theorem envBound4236 : H12AffineFastState.Bounded env4236 := by
  intro p hp
  have h : env4236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4235_4236 : H12AffineEnvironment.transform 17 19508 env4235 = env4236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19508 env4235 == env4236) = true)

theorem identity4236 : scanCanonicalize (H12AffineFastState.compose env4236 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound4236 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4237 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,8192,1573,8216,8731,1028,2577,1024,8216,1028,32,1,51,8224,1,2048,1573,1573,2561,1585,544,4,544,1028,528]

theorem envBound4237 : H12AffineFastState.Bounded env4237 := by
  intro p hp
  have h : env4237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4236_4237 : H12AffineEnvironment.transform 13 1573 env4236 = env4237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env4236 == env4237) = true)

theorem identity4237 : scanCanonicalize (H12AffineFastState.compose env4237 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1548) := by decide +kernel

theorem selectedBound4237 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env4238 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,1548,1573,1556,1047,1028,2577,1024,1556,1028,32,1,51,1580,1,2048,1573,1573,2561,1585,544,4,544,1028,528]

theorem envBound4238 : H12AffineFastState.Bounded env4238 := by
  intro p hp
  have h : env4238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4237_4238 : H12AffineEnvironment.transform 12 1548 env4237 = env4238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1548 env4237 == env4238) = true)

theorem identity4238 : scanCanonicalize (H12AffineFastState.compose env4238 (packedSelected [1,2,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound4238 : packedSelected [1,2,6,8,11] rootPS < 2^1333 := by decide +kernel

def env4239 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1566,1029,1548,1573,1556,1047,1028,1039,1024,1556,1028,32,1,51,1580,1,1566,1573,1573,1055,1585,544,4,544,1028,528]

theorem envBound4239 : H12AffineFastState.Bounded env4239 := by
  intro p hp
  have h : env4239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4238_4239 : H12AffineEnvironment.transform 10 1566 env4238 = env4239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env4238 == env4239) = true)

theorem identity4239 : scanCanonicalize (H12AffineFastState.compose env4239 (packedSelected [0,2,5,6,7,8,13] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound4239 : packedSelected [0,2,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env4240 : List Nat := [2,4,8,16,32,16,41,4,512,564,42,561,56,17,32,547,560,571,564,32,560,32,1,51,24,1,42,17,17,555,5,544,4,544,560,528]

theorem envBound4240 : H12AffineFastState.Bounded env4240 := by
  intro p hp
  have h : env4240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4239_4240 : H12AffineEnvironment.transform 9 564 env4239 = env4240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env4239 == env4240) = true)

theorem identity4240 : scanCanonicalize (H12AffineFastState.compose env4240 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4240 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env4241 : List Nat := [2,4,8,16,32,16,41,4,33,21,42,16,56,17,32,2,17,26,21,32,17,32,1,51,24,1,42,17,17,10,5,1,4,1,17,49]

theorem envBound4241 : H12AffineFastState.Bounded env4241 := by
  intro p hp
  have h : env4241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4240_4241 : H12AffineEnvironment.transform 8 33 env4240 = env4241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4240 == env4241) = true)

theorem identity4241 : scanCanonicalize (H12AffineFastState.compose env4241 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4242 : List Nat := [2,4,2,16,32,16,35,4,33,21,32,16,50,17,32,2,17,16,21,32,17,32,1,51,18,1,32,17,17,0,5,1,4,1,17,49]

theorem envBound4242 : H12AffineFastState.Bounded env4242 := by
  intro p hp
  have h : env4242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4241_4242 : H12AffineEnvironment.transform 2 2 env4241 = env4242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4241 == env4242) = true)

theorem identity4242 : scanCanonicalize (H12AffineFastState.compose env4242 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4242 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4243 : List Nat := [2,4,2,0,32,0,35,4,33,5,32,0,34,1,32,2,1,0,5,32,1,32,1,35,2,1,32,1,1,0,5,1,4,1,1,33]

theorem envBound4243 : H12AffineFastState.Bounded env4243 := by
  intro p hp
  have h : env4243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4242_4243 : H12AffineEnvironment.transform 3 0 env4242 = env4243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4242 == env4243) = true)

theorem identity4243 : scanCanonicalize (H12AffineFastState.compose env4243 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4243 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4244 : List Nat := [2,4,2,0,1,0,2,4,0,5,1,0,3,1,1,2,1,0,5,1,1,1,1,2,2,1,1,1,1,0,5,1,4,1,1,0]

theorem envBound4244 : H12AffineFastState.Bounded env4244 := by
  intro p hp
  have h : env4244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4243_4244 : H12AffineEnvironment.transform 4 1 env4243 = env4244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4243 == env4244) = true)

def env4245 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4097,4194304,8388608,41003,8329,8388609,323713,16384,16812,22560,16656,12644669,256,20481,8389804,8389565]

theorem envBound4245 : H12AffineFastState.Bounded env4245 := by
  intro p hp
  have h : env4245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4186_4245 : H12AffineEnvironment.transform 5 17 env4186 = env4245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4186 == env4245) = true)

theorem identity4245 : scanCanonicalize (H12AffineFastState.compose env4245 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound4245 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4246 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4097,4194304,445,41003,8329,444,323713,16384,16812,22560,16656,4255872,256,20481,1297,512]

theorem envBound4246 : H12AffineFastState.Bounded env4246 := by
  intro p hp
  have h : env4246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4245_4246 : H12AffineEnvironment.transform 22 445 env4245 = env4246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env4245 == env4246) = true)

theorem identity4246 : scanCanonicalize (H12AffineFastState.compose env4246 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound4246 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4247 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4097,41349,445,41003,8329,444,323713,16384,16812,22560,16656,20741,256,20481,1297,512]

theorem envBound4247 : H12AffineFastState.Bounded env4247 := by
  intro p hp
  have h : env4247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4246_4247 : H12AffineEnvironment.transform 21 41349 env4246 = env4247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env4246 == env4247) = true)

theorem identity4247 : scanCanonicalize (H12AffineFastState.compose env4247 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29313) := by decide +kernel

theorem selectedBound4247 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4248 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29313,25914,4525,262144,1024,29313,4097,21252,445,21162,8329,444,262656,16384,16812,22560,16656,20741,256,20481,1297,512]

theorem envBound4248 : H12AffineFastState.Bounded env4248 := by
  intro p hp
  have h : env4248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4247_4248 : H12AffineEnvironment.transform 14 29313 env4247 = env4248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29313 env4247 == env4248) = true)

theorem identity4248 : scanCanonicalize (H12AffineFastState.compose env4248 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound4248 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4249 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26425,25914,1045,262144,1024,26425,1465,18108,445,18194,8329,444,262656,16384,16812,19864,16656,17597,256,17849,1297,512]

theorem envBound4249 : H12AffineFastState.Bounded env4249 := by
  intro p hp
  have h : env4249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4248_4249 : H12AffineEnvironment.transform 11 1464 env4248 = env4249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env4248 == env4249) = true)

theorem identity4249 : scanCanonicalize (H12AffineFastState.compose env4249 (packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 20157) := by decide +kernel

theorem selectedBound4249 : packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS < 2^1333 := by decide +kernel

def env4250 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26425,25914,1045,20157,1024,26425,1465,18108,445,18194,8329,444,19645,16384,16812,19864,16656,17597,256,17849,1297,512]

theorem envBound4250 : H12AffineFastState.Bounded env4250 := by
  intro p hp
  have h : env4250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4249_4250 : H12AffineEnvironment.transform 17 20157 env4249 = env4250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20157 env4249 == env4250) = true)

theorem identity4250 : scanCanonicalize (H12AffineFastState.compose env4250 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4250 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4251 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,1840,8201,8714,1045,2445,1024,8201,1465,396,445,34,8329,444,2957,1840,1692,2728,1568,909,256,649,1297,512]

theorem envBound4251 : H12AffineFastState.Bounded env4251 := by
  intro p hp
  have h : env4251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4250_4251 : H12AffineEnvironment.transform 13 1840 env4250 = env4251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env4250 == env4251) = true)

theorem identity4251 : scanCanonicalize (H12AffineFastState.compose env4251 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4251 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env4252 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1044,8192,1692,8201,8714,1045,2081,1024,8201,1045,32,17,34,8329,16,2593,1692,1692,2728,1568,545,172,649,1213,512]

theorem envBound4252 : H12AffineFastState.Bounded env4252 := by
  intro p hp
  have h : env4252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4251_4252 : H12AffineEnvironment.transform 7 172 env4251 = env4252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4251 == env4252) = true)

theorem identity4252 : scanCanonicalize (H12AffineFastState.compose env4252 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound4252 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4253 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1551,1044,8192,1692,8201,8714,1045,1582,1024,8201,1045,32,17,34,8329,16,1070,1692,1692,1191,1568,545,172,649,1213,512]

theorem envBound4253 : H12AffineFastState.Bounded env4253 := by
  intro p hp
  have h : env4253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4252_4253 : H12AffineEnvironment.transform 10 1551 env4252 = env4253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env4252 == env4253) = true)

theorem identity4253 : scanCanonicalize (H12AffineFastState.compose env4253 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound4253 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env4254 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1551,1044,1031,1692,1038,1549,1045,1582,1024,1038,1045,32,17,34,1166,16,1070,1692,1692,1191,1568,545,172,649,1213,512]

theorem envBound4254 : H12AffineFastState.Bounded env4254 := by
  intro p hp
  have h : env4254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4253_4254 : H12AffineEnvironment.transform 12 1031 env4253 = env4254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env4253 == env4254) = true)

theorem identity4254 : scanCanonicalize (H12AffineFastState.compose env4254 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound4254 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4255 : List Nat := [2,4,8,16,32,17,128,172,169,1024,1190,1044,1031,1077,1038,1188,1045,1159,1024,1038,1045,32,17,34,1166,16,1070,1077,1077,1191,1161,136,172,32,1213,169]

theorem envBound4255 : H12AffineFastState.Bounded env4255 := by
  intro p hp
  have h : env4255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4254_4255 : H12AffineEnvironment.transform 8 169 env4254 = env4255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env4254 == env4255) = true)

theorem identity4255 : scanCanonicalize (H12AffineFastState.compose env4255 (packedSelected [2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4255 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env4256 : List Nat := [2,4,8,16,26,17,128,150,147,1024,1180,1044,1031,1039,1038,1182,1045,1159,1024,1038,1045,26,17,24,1166,16,1044,1039,1039,1181,1161,136,150,26,1159,147]

theorem envBound4256 : H12AffineFastState.Bounded env4256 := by
  intro p hp
  have h : env4256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4255_4256 : H12AffineEnvironment.transform 4 26 env4255 = env4256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4255 == env4256) = true)

theorem identity4256 : scanCanonicalize (H12AffineFastState.compose env4256 (packedSelected [0,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound4256 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env4257 : List Nat := [2,4,8,16,26,17,18,4,1,1024,1038,1044,1031,1039,1038,1036,1045,1045,1024,1038,1045,26,17,24,1052,16,1044,1039,1039,1039,1051,26,4,26,1045,1]

theorem envBound4257 : H12AffineFastState.Bounded env4257 := by
  intro p hp
  have h : env4257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4256_4257 : H12AffineEnvironment.transform 6 18 env4256 = env4257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env4256 == env4257) = true)

def env4258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323793,16384,16893,22640,74795,12644669,257,20561,8479126,8389613]

theorem envBound4258 : H12AffineFastState.Bounded env4258 := by
  intro p hp
  have h : env4258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4184_4258 : H12AffineEnvironment.transform 18 1025 env4184 = env4258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4184 == env4258) = true)

theorem identity4258 : scanCanonicalize (H12AffineFastState.compose env4258 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 73786) := by decide +kernel

theorem selectedBound4258 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,73786,41003,8329,73835,323793,16384,16893,22640,74795,4313351,257,20561,16812,74711]

theorem envBound4259 : H12AffineFastState.Bounded env4259 := by
  intro p hp
  have h : env4259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4258_4259 : H12AffineEnvironment.transform 22 73786 env4258 = env4259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73786 env4258 == env4259) = true)

def env4260 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,73786,41003,8329,73787,323713,16384,16813,22560,74795,4313351,257,20481,16812,74631]

theorem envBound4260 : H12AffineFastState.Bounded env4260 := by
  intro p hp
  have h : env4260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4259_4260 : H12AffineEnvironment.transform 5 16 env4259 = env4260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4259 == env4260) = true)

theorem identity4260 : scanCanonicalize (H12AffineFastState.compose env4260 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound4260 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4261 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4524,262144,1025,32768,4097,4194304,445,41003,8329,444,323713,16384,16813,22560,1452,4255872,257,20481,16812,512]

theorem envBound4261 : H12AffineFastState.Bounded env4261 := by
  intro p hp
  have h : env4261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4260_4261 : H12AffineEnvironment.transform 15 8583 env4260 = env4261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env4260 == env4261) = true)

theorem identity4261 : scanCanonicalize (H12AffineFastState.compose env4261 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound4261 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4262 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4524,262144,1025,32768,4097,41348,445,41003,8329,444,323713,16384,16813,22560,1452,20740,257,20481,16812,512]

theorem envBound4262 : H12AffineFastState.Bounded env4262 := by
  intro p hp
  have h : env4262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4261_4262 : H12AffineEnvironment.transform 21 41348 env4261 = env4262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env4261 == env4262) = true)

theorem identity4262 : scanCanonicalize (H12AffineFastState.compose env4262 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound4262 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4263 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13884,8583,4524,262144,1025,13884,4097,6072,445,5655,8329,444,280253,16384,16813,22560,1452,20740,257,20481,16812,512]

theorem envBound4263 : H12AffineFastState.Bounded env4263 := by
  intro p hp
  have h : env4263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4262_4263 : H12AffineEnvironment.transform 14 13884 env4262 = env4263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env4262 == env4263) = true)

theorem identity4263 : scanCanonicalize (H12AffineFastState.compose env4263 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound4263 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4264 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,13884,8583,4524,262144,1025,13884,4097,6072,445,5655,8329,444,268216,4357,4264,2341,1452,1,257,260,4265,512]

theorem envBound4264 : H12AffineFastState.Bounded env4264 := by
  intro p hp
  have h : env4264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4263_4264 : H12AffineEnvironment.transform 13 4357 env4263 = env4264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env4263 == env4264) = true)

theorem identity4264 : scanCanonicalize (H12AffineFastState.compose env4264 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4264 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env4265 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13884,8323,4264,262144,1025,13884,4097,5820,185,5655,8329,184,267964,4097,4264,2081,1192,1,5,0,4265,512]

theorem envBound4265 : H12AffineFastState.Bounded env4265 := by
  intro p hp
  have h : env4265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4264_4265 : H12AffineEnvironment.transform 7 4 env4264 = env4265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4264 == env4265) = true)

theorem identity4265 : scanCanonicalize (H12AffineFastState.compose env4265 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound4265 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4266 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13884,8323,4264,2184,1025,13884,4097,5820,185,5655,8329,184,7732,4097,4264,2081,1192,1,5,0,4265,512]

theorem envBound4266 : H12AffineFastState.Bounded env4266 := by
  intro p hp
  have h : env4266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4265_4266 : H12AffineEnvironment.transform 17 2184 env4265 = env4266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env4265 == env4266) = true)

theorem identity4266 : scanCanonicalize (H12AffineFastState.compose env4266 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4266 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4267 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1692,8192,1693,8352,8323,1588,2184,1025,8352,1693,32,185,139,8329,184,2216,1693,1588,2081,1192,1,5,0,1589,512]

theorem envBound4267 : H12AffineFastState.Bounded env4267 := by
  intro p hp
  have h : env4267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4266_4267 : H12AffineEnvironment.transform 11 1692 env4266 = env4267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env4266 == env4267) = true)

theorem identity4267 : scanCanonicalize (H12AffineFastState.compose env4267 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 18) := by decide +kernel

theorem selectedBound4267 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4268 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1692,18,1693,178,145,1588,2184,1025,178,1693,32,185,139,155,184,2216,1693,1588,2081,1192,1,5,0,1589,512]

theorem envBound4268 : H12AffineFastState.Bounded env4268 := by
  intro p hp
  have h : env4268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4267_4268 : H12AffineEnvironment.transform 12 18 env4267 = env4268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 18 env4267 == env4268) = true)

theorem identity4268 : scanCanonicalize (H12AffineFastState.compose env4268 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 691) := by decide +kernel

theorem selectedBound4268 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4269 : List Nat := [2,4,8,16,32,16,128,4,512,1024,691,1692,18,1693,178,145,1588,571,1025,178,1693,32,185,139,155,184,539,1693,1588,658,1192,1,5,0,1589,512]

theorem envBound4269 : H12AffineFastState.Bounded env4269 := by
  intro p hp
  have h : env4269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4268_4269 : H12AffineEnvironment.transform 10 691 env4268 = env4269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 691 env4268 == env4269) = true)

theorem identity4269 : scanCanonicalize (H12AffineFastState.compose env4269 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound4269 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4270 : List Nat := [2,4,8,16,32,16,18,4,512,1024,545,1550,18,1551,32,3,1588,571,1025,32,1551,32,43,25,9,42,539,1551,1588,512,1082,1,5,0,1589,512]

theorem envBound4270 : H12AffineFastState.Bounded env4270 := by
  intro p hp
  have h : env4270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4269_4270 : H12AffineEnvironment.transform 6 18 env4269 = env4270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env4269 == env4270) = true)

theorem identity4270 : scanCanonicalize (H12AffineFastState.compose env4270 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4270 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env4271 : List Nat := [2,4,8,16,0,16,18,4,512,1024,513,1550,18,1551,0,3,1556,539,1025,0,1551,0,11,25,9,10,539,1551,1556,512,1050,1,5,0,1557,512]

theorem envBound4271 : H12AffineFastState.Bounded env4271 := by
  intro p hp
  have h : env4271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4270_4271 : H12AffineEnvironment.transform 4 0 env4270 = env4271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4270 == env4271) = true)

theorem identity4271 : scanCanonicalize (H12AffineFastState.compose env4271 (packedSelected [0,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4271 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env4272 : List Nat := [2,4,8,10,0,10,8,4,512,1024,513,1550,8,1551,0,3,1550,513,1025,0,1551,0,11,3,9,10,513,1551,1550,512,1024,1,5,0,1551,512]

theorem envBound4272 : H12AffineFastState.Bounded env4272 := by
  intro p hp
  have h : env4272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4271_4272 : H12AffineEnvironment.transform 3 10 env4271 = env4272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4271 == env4272) = true)

theorem identity4272 : scanCanonicalize (H12AffineFastState.compose env4272 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound4272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4273 : List Nat := [2,4,8,10,0,10,8,4,11,1024,10,1029,8,1028,0,3,1029,10,1025,0,1028,0,11,3,9,10,10,1028,1029,11,1024,1,5,0,1028,11]

theorem envBound4273 : H12AffineFastState.Bounded env4273 := by
  intro p hp
  have h : env4273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4272_4273 : H12AffineEnvironment.transform 8 11 env4272 = env4273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env4272 == env4273) = true)

theorem identity4273 : scanCanonicalize (H12AffineFastState.compose env4273 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4274 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1,1029,3,1028,0,3,1029,1,1025,0,1028,0,0,3,2,1,1,1028,1029,0,1024,1,5,0,1028,0]

theorem envBound4274 : H12AffineFastState.Bounded env4274 := by
  intro p hp
  have h : env4274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4273_4274 : H12AffineEnvironment.transform 2 3 env4273 = env4274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4273 == env4274) = true)

def leafEnv4274 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1,1029,3,1028,0,3,1029,1,1025,0,1028,0,0,3,1025,2,1,1,1,1028,1029,0,1024,1,5,0,5,3,1028,0,1,1029,0]

def active4274 : List Nat := [0,1,9]

def tree4274 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4274 : H12WitnessSearch.Good tree4274 := H12GlobalWitnessIndex.good

theorem leafIdentity4274 : H12AffineFastState.composeSystem env4274 rootObs = leafEnv4274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4274 rootObs == leafEnv4274) = true)

theorem terminalChecked4274 : H12PackedTerminal.terminalCheckFast leafEnv4274 active4274 tree4274 = true := by decide +kernel

def env4275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,73786,41003,8329,73786,323712,16384,16812,22561,74795,4313351,257,20480,16812,74630]

theorem envBound4275 : H12AffineFastState.Bounded env4275 := by
  intro p hp
  have h : env4275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4259_4275 : H12AffineEnvironment.transform 5 17 env4259 = env4275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4259 == env4275) = true)

def env4276 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,41088,73786,41003,8329,73786,323712,16384,16812,22561,74795,94599,257,20480,16812,74630]

theorem envBound4276 : H12AffineFastState.Bounded env4276 := by
  intro p hp
  have h : env4276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4275_4276 : H12AffineEnvironment.transform 21 41088 env4275 = env4276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4275 == env4276) = true)

theorem identity4276 : scanCanonicalize (H12AffineFastState.compose env4276 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound4276 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4277 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8322,4525,262144,1025,32768,4097,41088,184,41003,8329,184,323712,16384,16812,22561,1193,20741,257,20480,16812,772]

theorem envBound4277 : H12AffineFastState.Bounded env4277 := by
  intro p hp
  have h : env4277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4276_4277 : H12AffineEnvironment.transform 15 8322 env4276 = env4277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env4276 == env4277) = true)

theorem identity4277 : scanCanonicalize (H12AffineFastState.compose env4277 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound4277 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4278 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8322,4525,7868,1025,32768,4097,41088,184,41003,8329,184,60988,16384,16812,22561,1193,20741,257,20480,16812,772]

theorem envBound4278 : H12AffineFastState.Bounded env4278 := by
  intro p hp
  have h : env4278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4277_4278 : H12AffineEnvironment.transform 17 7868 env4277 = env4278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env4277 == env4278) = true)

theorem identity4278 : scanCanonicalize (H12AffineFastState.compose env4278 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 1588) := by decide +kernel

theorem selectedBound4278 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4279 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1588,32768,8322,4525,7868,1025,32768,4097,41088,184,41003,8329,184,43016,1588,1944,7701,1193,5937,257,5684,1944,772]

theorem envBound4279 : H12AffineFastState.Bounded env4279 := by
  intro p hp
  have h : env4279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4278_4279 : H12AffineEnvironment.transform 13 1588 env4278 = env4279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1588 env4278 == env4279) = true)

theorem identity4279 : scanCanonicalize (H12AffineFastState.compose env4279 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4279 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env4280 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1693,8192,1588,32768,8322,1840,2081,1025,32768,1692,41088,184,41003,8329,184,43016,1588,1944,2184,1193,428,257,169,1944,772]

theorem envBound4280 : H12AffineFastState.Bounded env4280 := by
  intro p hp
  have h : env4280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4279_4280 : H12AffineEnvironment.transform 11 1693 env4279 = env4280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env4279 == env4280) = true)

theorem identity4280 : scanCanonicalize (H12AffineFastState.compose env4280 (packedSelected [2,3,5,10,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8217) := by decide +kernel

theorem selectedBound4280 : packedSelected [2,3,5,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4281 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1693,8192,1588,8217,8322,1840,2081,1025,8217,1692,153,184,50,8329,184,2065,1588,1944,2184,1193,428,257,169,1944,772]

theorem envBound4281 : H12AffineFastState.Bounded env4281 := by
  intro p hp
  have h : env4281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4280_4281 : H12AffineEnvironment.transform 14 8217 env4280 = env4281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8217 env4280 == env4281) = true)

theorem identity4281 : scanCanonicalize (H12AffineFastState.compose env4281 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4281 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4282 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1677,8192,1572,8201,8322,1824,2081,1025,8201,1676,137,168,34,8329,168,2049,1572,1928,2184,1193,428,257,169,1928,772]

theorem envBound4282 : H12AffineFastState.Bounded env4282 := by
  intro p hp
  have h : env4282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4281_4282 : H12AffineEnvironment.transform 3 0 env4281 = env4282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4281 == env4282) = true)

theorem identity4282 : scanCanonicalize (H12AffineFastState.compose env4282 (packedSelected [1,3,4,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound4282 : packedSelected [1,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env4283 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1677,2948,1572,2957,2822,1824,2081,1025,2957,1676,137,168,34,2829,168,2049,1572,1928,2184,1193,428,257,169,1928,772]

theorem envBound4283 : H12AffineFastState.Bounded env4283 := by
  intro p hp
  have h : env4283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4282_4283 : H12AffineEnvironment.transform 12 2948 env4282 = env4283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env4282 == env4283) = true)

theorem identity4283 : scanCanonicalize (H12AffineFastState.compose env4283 (packedSelected [0,4,6,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4283 : packedSelected [0,4,6,11,15] rootPS < 2^1333 := by decide +kernel

def env4284 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1677,2601,1572,2592,2731,1677,2081,1025,2592,1676,137,168,34,2720,168,2049,1572,1573,2184,1193,1,172,169,1573,681]

theorem envBound4284 : H12AffineFastState.Bounded env4284 := by
  intro p hp
  have h : env4284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4283_4284 : H12AffineEnvironment.transform 7 173 env4283 = env4284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4283 == env4284) = true)

theorem identity4284 : scanCanonicalize (H12AffineFastState.compose env4284 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4284 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env4285 : List Nat := [2,4,3,0,32,1,128,166,512,1024,2048,1670,2594,1572,2592,2720,1670,2081,1025,2592,1671,130,163,34,2720,163,2049,1572,1573,2179,1186,1,167,162,1573,674]

theorem envBound4285 : H12AffineFastState.Bounded env4285 := by
  intro p hp
  have h : env4285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4284_4285 : H12AffineEnvironment.transform 2 3 env4284 = env4285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4284 == env4285) = true)

def env4286 : List Nat := [2,4,3,0,32,1,128,166,512,1024,1540,1670,1062,1572,1060,1188,1670,1573,1025,1060,1671,130,163,34,1188,163,1541,1572,1573,1671,1186,1,167,162,1573,674]

theorem envBound4286 : H12AffineFastState.Bounded env4286 := by
  intro p hp
  have h : env4286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4285_4286 : H12AffineEnvironment.transform 10 1540 env4285 = env4286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env4285 == env4286) = true)

theorem identity4286 : scanCanonicalize (H12AffineFastState.compose env4286 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound4286 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4287 : List Nat := [2,4,3,0,32,1,34,4,512,1024,1540,1572,1062,1572,1060,1030,1572,1573,1025,1060,1573,32,1,34,1030,1,1541,1572,1573,1573,1024,1,5,0,1573,512]

theorem envBound4287 : H12AffineFastState.Bounded env4287 := by
  intro p hp
  have h : env4287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4286_4287 : H12AffineEnvironment.transform 6 34 env4286 = env4287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env4286 == env4287) = true)

theorem identity4287 : scanCanonicalize (H12AffineFastState.compose env4287 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4287 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4288 : List Nat := [2,4,3,0,0,1,2,4,512,1024,1540,1540,1030,1540,1028,1030,1540,1541,1025,1028,1541,0,1,2,1030,1,1541,1540,1541,1541,1024,1,5,0,1541,512]

theorem envBound4288 : H12AffineFastState.Bounded env4288 := by
  intro p hp
  have h : env4288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4287_4288 : H12AffineEnvironment.transform 4 0 env4287 = env4288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4287 == env4288) = true)

theorem identity4288 : scanCanonicalize (H12AffineFastState.compose env4288 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4288 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4289 : List Nat := [2,4,3,0,0,1,2,4,0,1024,1028,1028,1030,1028,1028,1030,1028,1029,1025,1028,1029,0,1,2,1030,1,1029,1028,1029,1029,1024,1,5,0,1029,0]

theorem envBound4289 : H12AffineFastState.Bounded env4289 := by
  intro p hp
  have h : env4289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4288_4289 : H12AffineEnvironment.transform 8 0 env4288 = env4289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4288 == env4289) = true)

theorem identity4289 : scanCanonicalize (H12AffineFastState.compose env4289 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound4289 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4290 : List Nat := [2,4,3,0,0,1,2,4,0,4,0,0,2,0,0,2,0,1,5,0,1,0,1,2,2,1,1,0,1,1,4,1,5,0,1,0]

theorem envBound4290 : H12AffineFastState.Bounded env4290 := by
  intro p hp
  have h : env4290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4289_4290 : H12AffineEnvironment.transform 9 4 env4289 = env4290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env4289 == env4290) = true)

def leafEnv4290 : List Nat := [2,4,3,0,0,1,2,4,0,4,0,0,2,0,0,2,0,1,5,0,1,0,1,2,5,2,1,1,1,0,1,1,4,1,5,0,5,3,1,0,1,1,0]

def active4290 : List Nat := [0,1]

def tree4290 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4290 : H12WitnessSearch.Good tree4290 := H12GlobalWitnessIndex.good

theorem leafIdentity4290 : H12AffineFastState.composeSystem env4290 rootObs = leafEnv4290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4290 rootObs == leafEnv4290) = true)

theorem terminalChecked4290 : H12PackedTerminal.terminalCheckFast leafEnv4290 active4290 tree4290 = true := by decide +kernel

def env4291 : List Nat := [2,4,3,0,32,1,128,166,512,1024,1541,1670,1063,1572,1061,1189,1670,1572,1025,1061,1671,130,163,34,1189,163,1540,1572,1573,1670,1186,1,167,162,1573,674]

theorem envBound4291 : H12AffineFastState.Bounded env4291 := by
  intro p hp
  have h : env4291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4285_4291 : H12AffineEnvironment.transform 10 1541 env4285 = env4291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env4285 == env4291) = true)

def env4292 : List Nat := [2,4,3,0,32,1,128,166,0,1024,1029,1158,1063,1060,1061,1189,1158,1060,1025,1061,1159,130,163,34,1189,163,1028,1060,1061,1158,1186,1,167,162,1061,162]

theorem envBound4292 : H12AffineFastState.Bounded env4292 := by
  intro p hp
  have h : env4292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4291_4292 : H12AffineEnvironment.transform 8 0 env4291 = env4292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4291 == env4292) = true)

theorem identity4292 : scanCanonicalize (H12AffineFastState.compose env4292 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound4292 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4293 : List Nat := [2,4,3,0,32,1,128,166,0,5,0,131,34,33,32,160,131,33,4,32,130,130,163,34,160,163,1,33,32,131,167,1,167,162,32,162]

theorem envBound4293 : H12AffineFastState.Bounded env4293 := by
  intro p hp
  have h : env4293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4292_4293 : H12AffineEnvironment.transform 9 5 env4292 = env4293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env4292 == env4293) = true)

theorem identity4293 : scanCanonicalize (H12AffineFastState.compose env4293 (packedSelected [0,11] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound4293 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env4294 : List Nat := [2,4,3,0,32,1,34,4,0,5,0,33,34,33,32,2,33,33,4,32,32,32,1,34,2,1,1,33,32,33,5,1,5,0,32,0]

theorem envBound4294 : H12AffineFastState.Bounded env4294 := by
  intro p hp
  have h : env4294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4293_4294 : H12AffineEnvironment.transform 6 34 env4293 = env4294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env4293 == env4294) = true)

theorem identity4294 : scanCanonicalize (H12AffineFastState.compose env4294 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4295 : List Nat := [2,4,3,0,0,1,2,4,0,5,0,1,2,1,0,2,1,1,4,0,0,0,1,2,2,1,1,1,0,1,5,1,5,0,0,0]

theorem envBound4295 : H12AffineFastState.Bounded env4295 := by
  intro p hp
  have h : env4295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4294_4295 : H12AffineEnvironment.transform 4 0 env4294 = env4295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4294 == env4295) = true)

def leafEnv4295 : List Nat := [2,4,3,0,0,1,2,4,0,5,0,1,2,1,0,2,1,1,4,0,0,0,1,2,4,2,1,1,1,1,0,1,5,1,5,0,5,3,0,0,1,0,0]

def active4295 : List Nat := [0,1]

def tree4295 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4295 : H12WitnessSearch.Good tree4295 := H12GlobalWitnessIndex.good

theorem leafIdentity4295 : H12AffineFastState.composeSystem env4295 rootObs = leafEnv4295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4295 rootObs == leafEnv4295) = true)

theorem terminalChecked4295 : H12PackedTerminal.terminalCheckFast leafEnv4295 active4295 tree4295 = true := by decide +kernel

def env4296 : List Nat := [2,4,3,0,32,1,128,166,1,1024,1028,1159,1063,1061,1061,1189,1159,1061,1025,1061,1158,130,163,34,1189,163,1029,1061,1060,1159,1186,1,167,162,1060,163]

theorem envBound4296 : H12AffineFastState.Bounded env4296 := by
  intro p hp
  have h : env4296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4291_4296 : H12AffineEnvironment.transform 8 1 env4291 = env4296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4291 == env4296) = true)

theorem identity4296 : scanCanonicalize (H12AffineFastState.compose env4296 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 134) := by decide +kernel

theorem selectedBound4296 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4297 : List Nat := [2,4,3,0,32,1,128,166,1,134,130,1,161,163,163,35,1,163,135,163,0,130,163,34,35,163,131,163,162,1,36,1,167,162,162,163]

theorem envBound4297 : H12AffineFastState.Bounded env4297 := by
  intro p hp
  have h : env4297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4296_4297 : H12AffineEnvironment.transform 9 134 env4296 = env4297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 134 env4296 == env4297) = true)

theorem identity4297 : scanCanonicalize (H12AffineFastState.compose env4297 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound4297 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4298 : List Nat := [2,4,3,0,32,1,35,5,1,37,33,1,2,0,0,35,1,0,36,0,0,33,0,34,35,0,32,0,1,1,36,1,4,1,1,0]

theorem envBound4298 : H12AffineFastState.Bounded env4298 := by
  intro p hp
  have h : env4298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4297_4298 : H12AffineEnvironment.transform 6 35 env4297 = env4298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env4297 == env4298) = true)

theorem identity4298 : scanCanonicalize (H12AffineFastState.compose env4298 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4299 : List Nat := [2,1,3,0,32,1,35,0,1,32,33,1,2,0,0,35,1,0,33,0,0,33,0,34,35,0,32,0,1,1,33,1,1,1,1,0]

theorem envBound4299 : H12AffineFastState.Bounded env4299 := by
  intro p hp
  have h : env4299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4298_4299 : H12AffineEnvironment.transform 1 1 env4298 = env4299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4298 == env4299) = true)

def leafEnv4299 : List Nat := [2,1,3,0,32,1,35,0,1,32,33,1,2,0,0,35,1,0,33,0,0,33,0,34,32,35,1,0,32,0,1,1,33,1,1,1,0,2,1,0,1,1,0]

def active4299 : List Nat := [0,4]

def tree4299 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4299 : H12WitnessSearch.Good tree4299 := H12GlobalWitnessIndex.good

theorem leafIdentity4299 : H12AffineFastState.composeSystem env4299 rootObs = leafEnv4299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4299 rootObs == leafEnv4299) = true)

theorem terminalChecked4299 : H12PackedTerminal.terminalCheckFast leafEnv4299 active4299 tree4299 = true := by decide +kernel

def env4300 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,41089,73786,41003,8329,73786,323712,16384,16812,22561,74795,94598,257,20480,16812,74630]

theorem envBound4300 : H12AffineFastState.Bounded env4300 := by
  intro p hp
  have h : env4300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4275_4300 : H12AffineEnvironment.transform 21 41089 env4275 = env4300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4275 == env4300) = true)

theorem identity4300 : scanCanonicalize (H12AffineFastState.compose env4300 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4300 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4301 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,65536,4264,262144,1025,32768,4097,41089,73786,41003,8329,73786,323712,16384,16553,22561,74795,94339,4,20480,16553,74371]

theorem envBound4301 : H12AffineFastState.Bounded env4301 := by
  intro p hp
  have h : env4301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4300_4301 : H12AffineEnvironment.transform 7 5 env4300 = env4301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4300 == env4301) = true)

theorem identity4301 : scanCanonicalize (H12AffineFastState.compose env4301 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 75938) := by decide +kernel

theorem selectedBound4301 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4302 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,65536,4264,75938,1025,32768,4097,41089,73786,41003,8329,73786,120866,16384,16553,22561,74795,94339,4,20480,16553,74371]

theorem envBound4302 : H12AffineFastState.Bounded env4302 := by
  intro p hp
  have h : env4302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4301_4302 : H12AffineEnvironment.transform 17 75938 env4301 = env4302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75938 env4301 == env4302) = true)

theorem identity4302 : scanCanonicalize (H12AffineFastState.compose env4302 (packedSelected [3,4,5,8,9,20,28] rootPS)) = affineNative (2^(15+1) ^^^ 53386) := by decide +kernel

theorem selectedBound4302 : packedSelected [3,4,5,8,9,20,28] rootPS < 2^1333 := by decide +kernel

def env4303 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,53386,4264,63528,1025,32768,4097,41089,61616,41003,8329,61616,2216,16384,16553,22561,62625,40969,4,20480,16553,61961]

theorem envBound4303 : H12AffineFastState.Bounded env4303 := by
  intro p hp
  have h : env4303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4302_4303 : H12AffineEnvironment.transform 15 53386 env4302 = env4303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53386 env4302 == env4303) = true)

theorem identity4303 : scanCanonicalize (H12AffineFastState.compose env4303 (packedSelected [1,4,8,9,10,12,13,18,21] rootPS)) = affineNative (2^(13+1) ^^^ 1588) := by decide +kernel

theorem selectedBound4303 : packedSelected [1,4,8,9,10,12,13,18,21] rootPS < 2^1333 := by decide +kernel

def env4304 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,1588,32768,38590,4264,48668,1025,32768,4097,41089,46724,41003,8329,46724,2216,1588,1693,7701,45717,40969,4,5684,1693,46141]

theorem envBound4304 : H12AffineFastState.Bounded env4304 := by
  intro p hp
  have h : env4304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4303_4304 : H12AffineEnvironment.transform 13 1588 env4303 = env4304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1588 env4303 == env4304) = true)

theorem identity4304 : scanCanonicalize (H12AffineFastState.compose env4304 (packedSelected [0,5,7,10,12,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound4304 : packedSelected [0,5,7,10,12,18,24] rootPS < 2^1333 := by decide +kernel

def env4305 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,1588,13885,8323,4264,2081,1025,13885,4097,5820,185,5654,8329,185,2216,1588,1693,7701,1192,5684,4,5684,1693,512]

theorem envBound4305 : H12AffineFastState.Bounded env4305 := by
  intro p hp
  have h : env4305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4304_4305 : H12AffineEnvironment.transform 14 13885 env4304 = env4305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env4304 == env4305) = true)

theorem identity4305 : scanCanonicalize (H12AffineFastState.compose env4305 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound4305 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4306 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1588,8192,1588,8201,8323,1692,2081,1025,8201,1589,136,185,34,8329,185,2216,1588,1693,2081,1192,0,4,0,1693,512]

theorem envBound4306 : H12AffineFastState.Bounded env4306 := by
  intro p hp
  have h : env4306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4305_4306 : H12AffineEnvironment.transform 11 1588 env4305 = env4306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env4305 == env4306) = true)

def env4307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849104,16385,16892,547953,598058,12644669,525568,545872,8479126,8914924]

theorem envBound4307 : H12AffineFastState.Bounded env4307 := by
  intro p hp
  have h : env4307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4183_4307 : H12AffineEnvironment.transform 27 16385 env4183 = env4307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env4183 == env4307) = true)

def env4308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323792,16385,16892,22641,74794,12644669,256,20560,8479126,8389612]

theorem envBound4308 : H12AffineFastState.Bounded env4308 := by
  intro p hp
  have h : env4308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4307_4308 : H12AffineEnvironment.transform 18 1024 env4307 = env4308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4307 == env4308) = true)

theorem identity4308 : scanCanonicalize (H12AffineFastState.compose env4308 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4310442) := by decide +kernel

theorem selectedBound4308 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,4310442,41003,8329,4310522,323792,16385,16892,22641,74794,78999,256,20560,4236348,4310598]

theorem envBound4309 : H12AffineFastState.Bounded env4309 := by
  intro p hp
  have h : env4309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4308_4309 : H12AffineEnvironment.transform 22 4310442 env4308 = env4309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4310442 env4308 == env4309) = true)

def env4310 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4310442,41003,8329,4310442,323712,16385,16812,22561,74794,78999,256,20480,4236348,4310550]

theorem envBound4310 : H12AffineFastState.Bounded env4310 := by
  intro p hp
  have h : env4310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4309_4310 : H12AffineEnvironment.transform 5 16 env4309 = env4310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4309 == env4310) = true)

theorem identity4310 : scanCanonicalize (H12AffineFastState.compose env4310 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 115734) := by decide +kernel

theorem selectedBound4310 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4311 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115734,444,41003,8329,444,323712,16385,16812,22561,74794,78999,256,20480,90154,512]

theorem envBound4311 : H12AffineFastState.Bounded env4311 := by
  intro p hp
  have h : env4311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4310_4311 : H12AffineEnvironment.transform 21 115734 env4310 = env4311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115734 env4310 == env4311) = true)

theorem identity4311 : scanCanonicalize (H12AffineFastState.compose env4311 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound4311 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4312 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1024,32768,4097,41348,444,41003,8329,444,323712,16385,16812,22561,16824,20741,256,20480,1464,512]

theorem envBound4312 : H12AffineFastState.Bounded env4312 := by
  intro p hp
  have h : env4312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4311_4312 : H12AffineEnvironment.transform 15 26002 env4311 = env4312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env4311 == env4312) = true)

theorem identity4312 : scanCanonicalize (H12AffineFastState.compose env4312 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound4312 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4313 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29225,26002,4524,262144,1024,29225,4097,21421,444,20994,8329,444,262825,16385,16812,22561,16824,20741,256,20480,1464,512]

theorem envBound4313 : H12AffineFastState.Bounded env4313 := by
  intro p hp
  have h : env4313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4312_4313 : H12AffineEnvironment.transform 14 29225 env4312 = env4313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env4312 == env4313) = true)

theorem identity4313 : scanCanonicalize (H12AffineFastState.compose env4313 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound4313 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4314 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,26424,26002,1213,262144,1024,26424,1296,18108,444,18195,8329,444,262825,16385,16812,19760,16824,17428,256,17681,1464,512]

theorem envBound4314 : H12AffineFastState.Bounded env4314 := by
  intro p hp
  have h : env4314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4313_4314 : H12AffineEnvironment.transform 11 1297 env4313 = env4314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4313 == env4314) = true)

theorem identity4314 : scanCanonicalize (H12AffineFastState.compose env4314 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4314 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4315 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1297,8192,16384,26424,25915,1044,262144,1024,26424,1296,17941,277,18195,8224,277,262656,16385,16645,19760,16657,17428,256,17681,1297,512]

theorem envBound4315 : H12AffineFastState.Bounded env4315 := by
  intro p hp
  have h : env4315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4314_4315 : H12AffineEnvironment.transform 6 41 env4314 = env4315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4314 == env4315) = true)

def env4316 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4310442,41003,8329,4310443,323713,16385,16813,22560,74794,78999,256,20481,4236348,4310551]

theorem envBound4316 : H12AffineFastState.Bounded env4316 := by
  intro p hp
  have h : env4316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4309_4316 : H12AffineEnvironment.transform 5 17 env4309 = env4316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4309 == env4316) = true)

def env4317 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1280,8192,16384,32768,65536,1197,262144,1024,32768,1281,4194304,4310442,41003,8329,4310443,320897,16385,16813,19744,74794,74135,256,17665,4236348,4310551]

theorem envBound4317 : H12AffineFastState.Bounded env4317 := by
  intro p hp
  have h : env4317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4316_4317 : H12AffineEnvironment.transform 11 1280 env4316 = env4317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env4316 == env4317) = true)

theorem identity4317 : scanCanonicalize (H12AffineFastState.compose env4317 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50587) := by decide +kernel

theorem selectedBound4317 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4318 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1280,8192,16384,32768,50587,1197,262144,1024,32768,1281,4194304,4194353,41003,8329,4194352,320897,16385,16813,19744,57777,58380,256,17665,4236348,4195212]

theorem envBound4318 : H12AffineFastState.Bounded env4318 := by
  intro p hp
  have h : env4318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4317_4318 : H12AffineEnvironment.transform 15 50587 env4317 = env4318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50587 env4317 == env4318) = true)

def env4319 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,32768,50571,1197,262144,1024,32768,1281,4194304,4194337,41003,8329,4194336,320897,16385,16813,19744,57761,58380,256,17665,4236332,4195212]

theorem envBound4319 : H12AffineFastState.Bounded env4319 := by
  intro p hp
  have h : env4319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4318_4319 : H12AffineEnvironment.transform 3 0 env4318 = env4319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4318 == env4319) = true)

def env4320 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,32768,50571,1197,262144,1024,32768,1281,41088,41121,41003,8329,41120,320897,16385,16813,19744,57761,58380,256,17665,1196,41740]

theorem envBound4320 : H12AffineFastState.Bounded env4320 := by
  intro p hp
  have h : env4320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4319_4320 : H12AffineEnvironment.transform 21 41088 env4319 = env4320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4319 == env4320) = true)

theorem identity4320 : scanCanonicalize (H12AffineFastState.compose env4320 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4320 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4321 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,8200,25987,1197,262144,1024,8200,1281,136,169,35,8329,168,279945,16385,16813,19744,16809,17412,256,17665,1196,772]

theorem envBound4321 : H12AffineFastState.Bounded env4321 := by
  intro p hp
  have h : env4321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4320_4321 : H12AffineEnvironment.transform 14 8200 env4320 = env4321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4320 == env4321) = true)

theorem identity4321 : scanCanonicalize (H12AffineFastState.compose env4321 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 20393) := by decide +kernel

theorem selectedBound4321 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4322 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,8200,25987,1197,20393,1024,8200,1281,136,169,35,8329,168,2592,16385,16813,19744,16809,17412,256,17665,1196,772]

theorem envBound4322 : H12AffineFastState.Bounded env4322 := by
  intro p hp
  have h : env4322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4321_4322 : H12AffineEnvironment.transform 17 20393 env4321 = env4322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20393 env4321 == env4322) = true)

theorem identity4322 : scanCanonicalize (H12AffineFastState.compose env4322 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4322 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env4323 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,16384,8200,25734,1197,20140,1024,8200,1028,136,169,35,8329,168,2592,16385,16552,19493,16556,17412,5,17412,1196,513]

theorem envBound4323 : H12AffineFastState.Bounded env4323 := by
  intro p hp
  have h : env4323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4322_4323 : H12AffineEnvironment.transform 7 5 env4322 = env4323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4322 == env4323) = true)

theorem identity4323 : scanCanonicalize (H12AffineFastState.compose env4323 (packedSelected [2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2566) := by decide +kernel

theorem selectedBound4323 : packedSelected [2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env4324 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,2566,16384,2574,20096,1197,20140,1024,2574,1028,136,169,35,2703,168,2592,16385,16552,19493,16556,17412,5,17412,1196,513]

theorem envBound4324 : H12AffineFastState.Bounded env4324 := by
  intro p hp
  have h : env4324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4323_4324 : H12AffineEnvironment.transform 12 2566 env4323 = env4324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2566 env4323 == env4324) = true)

theorem identity4324 : scanCanonicalize (H12AffineFastState.compose env4324 (packedSelected [13,17] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4324 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4325 : List Nat := [2,4,8,0,32,1,128,5,32,1024,2048,1029,2086,16384,2094,19616,1197,19596,1024,2094,1028,136,169,35,2223,168,2048,16385,16552,19493,16556,17412,5,17412,1196,33]

theorem envBound4325 : H12AffineFastState.Bounded env4325 := by
  intro p hp
  have h : env4325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4324_4325 : H12AffineEnvironment.transform 8 32 env4324 = env4325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4324 == env4325) = true)

theorem identity4325 : scanCanonicalize (H12AffineFastState.compose env4325 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 2215) := by decide +kernel

theorem selectedBound4325 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4326 : List Nat := [2,4,8,0,32,1,128,5,32,1024,2048,1029,2086,2215,2094,1031,1197,1067,1024,2094,1028,136,169,35,2223,168,2048,2214,2063,1154,2059,3235,5,3235,1196,33]

theorem envBound4326 : H12AffineFastState.Bounded env4326 := by
  intro p hp
  have h : env4326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4325_4326 : H12AffineEnvironment.transform 13 2215 env4325 = env4326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2215 env4325 == env4326) = true)

theorem identity4326 : scanCanonicalize (H12AffineFastState.compose env4326 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4326 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4327 : List Nat := [2,4,8,0,10,1,128,5,10,1024,2048,1029,2060,2189,2052,1031,1159,1025,1024,2052,1028,136,131,9,2181,130,2048,2188,2063,1154,2059,3209,5,3209,1158,11]

theorem envBound4327 : H12AffineFastState.Bounded env4327 := by
  intro p hp
  have h : env4327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4326_4327 : H12AffineEnvironment.transform 4 10 env4326 = env4327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4326 == env4327) = true)

theorem identity4327 : scanCanonicalize (H12AffineFastState.compose env4327 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound4327 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4328 : List Nat := [2,4,8,0,10,1,3,5,10,1024,2048,1029,2060,2062,2052,1031,1028,1025,1024,2052,1028,11,0,9,2054,1,2048,2063,2063,1025,2059,3082,5,3082,1029,11]

theorem envBound4328 : H12AffineFastState.Bounded env4328 := by
  intro p hp
  have h : env4328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4327_4328 : H12AffineEnvironment.transform 6 3 env4327 = env4328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env4327 == env4328) = true)

theorem identity4328 : scanCanonicalize (H12AffineFastState.compose env4328 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1025) := by decide +kernel

theorem selectedBound4328 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4329 : List Nat := [2,4,8,0,10,1,3,5,10,1024,1025,1029,1037,1039,1029,1031,1028,1025,1024,1029,1028,11,0,9,1031,1,1025,1038,1038,1025,1034,11,5,11,1029,11]

theorem envBound4329 : H12AffineFastState.Bounded env4329 := by
  intro p hp
  have h : env4329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4328_4329 : H12AffineEnvironment.transform 10 1025 env4328 = env4329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1025 env4328 == env4329) = true)

theorem identity4329 : scanCanonicalize (H12AffineFastState.compose env4329 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4329 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4330 : List Nat := [2,4,6,0,4,1,3,5,4,1024,1025,1029,1027,1025,1029,1031,1028,1025,1024,1029,1028,5,0,7,1031,1,1025,1024,1024,1025,1028,5,5,5,1029,5]

theorem envBound4330 : H12AffineFastState.Bounded env4330 := by
  intro p hp
  have h : env4330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4329_4330 : H12AffineEnvironment.transform 2 6 env4329 = env4330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4329 == env4330) = true)

theorem identity4330 : scanCanonicalize (H12AffineFastState.compose env4330 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound4330 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4331 : List Nat := [2,4,6,0,4,1,3,5,4,4,5,1,7,5,1,3,0,5,4,1,0,5,0,7,3,1,5,4,4,5,0,5,5,5,1,5]

theorem envBound4331 : H12AffineFastState.Bounded env4331 := by
  intro p hp
  have h : env4331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4330_4331 : H12AffineEnvironment.transform 9 4 env4330 = env4331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env4330 == env4331) = true)

def env4332 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,32768,50571,1197,262144,1024,32768,1281,41089,41120,41003,8329,41121,320897,16385,16813,19744,57761,58380,256,17665,1197,41741]

theorem envBound4332 : H12AffineFastState.Bounded env4332 := by
  intro p hp
  have h : env4332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4319_4332 : H12AffineEnvironment.transform 21 41089 env4319 = env4332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4319 == env4332) = true)

theorem identity4332 : scanCanonicalize (H12AffineFastState.compose env4332 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4332 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4333 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,16384,32768,50318,1197,262144,1024,32768,1028,41089,41120,41003,8329,41121,320644,16385,16552,19493,57508,58380,5,17412,1197,41480]

theorem envBound4333 : H12AffineFastState.Bounded env4333 := by
  intro p hp
  have h : env4333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4332_4333 : H12AffineEnvironment.transform 7 5 env4332 = env4333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4332 == env4333) = true)

theorem identity4333 : scanCanonicalize (H12AffineFastState.compose env4333 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 60460) := by decide +kernel

theorem selectedBound4333 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4334 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,16384,32768,50318,1197,60460,1024,32768,1028,41089,41120,41003,8329,41121,2216,16385,16552,19493,57508,58380,5,17412,1197,41480]

theorem envBound4334 : H12AffineFastState.Bounded env4334 := by
  intro p hp
  have h : env4334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4333_4334 : H12AffineEnvironment.transform 17 60460 env4333 = env4334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60460 env4333 == env4334) = true)

theorem identity4334 : scanCanonicalize (H12AffineFastState.compose env4334 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 26244) := by decide +kernel

theorem selectedBound4334 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4335 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,16384,26244,8714,1197,2728,1024,26244,1028,17925,17956,18095,8329,17957,2216,16385,16552,19493,1568,648,5,17412,1197,17548]

theorem envBound4335 : H12AffineFastState.Bounded env4335 := by
  intro p hp
  have h : env4335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4334_4335 : H12AffineEnvironment.transform 14 26244 env4334 = env4335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26244 env4334 == env4335) = true)

theorem identity4335 : scanCanonicalize (H12AffineFastState.compose env4335 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound4335 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env4336 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1029,8192,1677,8201,8714,1197,2728,1024,8201,1028,136,169,34,8329,168,2216,1676,1573,2728,1568,648,5,649,1197,513]

theorem envBound4336 : H12AffineFastState.Bounded env4336 := by
  intro p hp
  have h : env4336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4335_4336 : H12AffineEnvironment.transform 13 1677 env4335 = env4336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env4335 == env4336) = true)

theorem identity4336 : scanCanonicalize (H12AffineFastState.compose env4336 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4336 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4337 : List Nat := [2,4,8,0,1,1,128,5,512,1024,2048,1029,8192,1677,8201,8714,1164,2697,1024,8201,1028,136,136,3,8329,137,2185,1676,1540,2697,1537,648,5,649,1164,513]

theorem envBound4337 : H12AffineFastState.Bounded env4337 := by
  intro p hp
  have h : env4337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4336_4337 : H12AffineEnvironment.transform 4 1 env4336 = env4337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4336 == env4337) = true)

theorem identity4337 : scanCanonicalize (H12AffineFastState.compose env4337 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1673) := by decide +kernel

theorem selectedBound4337 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env4338 : List Nat := [2,4,8,0,1,1,128,5,512,1024,1673,1029,8192,1677,8201,8714,1164,1024,1024,8201,1028,136,136,3,8329,137,1536,1676,1540,1024,1537,648,5,649,1164,513]

theorem envBound4338 : H12AffineFastState.Bounded env4338 := by
  intro p hp
  have h : env4338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4337_4338 : H12AffineEnvironment.transform 10 1673 env4337 = env4338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1673 env4337 == env4338) = true)

theorem identity4338 : scanCanonicalize (H12AffineFastState.compose env4338 (packedSelected [4,11] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound4338 : packedSelected [4,11] rootPS < 2^1333 := by decide +kernel

def env4339 : List Nat := [2,4,8,0,1,1,128,5,512,1024,1673,1029,9,1677,0,515,1164,1024,1024,0,1028,136,136,3,128,137,1536,1676,1540,1024,1537,648,5,649,1164,513]

theorem envBound4339 : H12AffineFastState.Bounded env4339 := by
  intro p hp
  have h : env4339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4338_4339 : H12AffineEnvironment.transform 12 9 env4338 = env4339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env4338 == env4339) = true)

theorem identity4339 : scanCanonicalize (H12AffineFastState.compose env4339 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound4339 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env4340 : List Nat := [2,4,8,0,1,1,3,5,512,1024,1546,1029,9,1550,0,515,1039,1024,1024,0,1028,11,11,3,3,10,1536,1551,1540,1024,1537,523,5,522,1039,513]

theorem envBound4340 : H12AffineFastState.Bounded env4340 := by
  intro p hp
  have h : env4340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4339_4340 : H12AffineEnvironment.transform 6 3 env4339 = env4340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env4339 == env4340) = true)

theorem identity4340 : scanCanonicalize (H12AffineFastState.compose env4340 (packedSelected [0,2,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 527) := by decide +kernel

theorem selectedBound4340 : packedSelected [0,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env4341 : List Nat := [2,4,8,0,1,1,3,5,512,527,5,522,9,1,0,515,512,527,527,0,523,11,11,3,3,10,15,0,11,527,14,523,5,522,512,513]

theorem envBound4341 : H12AffineFastState.Bounded env4341 := by
  intro p hp
  have h : env4341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4340_4341 : H12AffineEnvironment.transform 9 527 env4340 = env4341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 527 env4340 == env4341) = true)

theorem identity4341 : scanCanonicalize (H12AffineFastState.compose env4341 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound4341 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4342 : List Nat := [2,4,8,0,1,1,3,5,5,10,5,15,9,1,0,6,5,10,10,0,14,11,11,3,3,10,15,0,11,10,14,14,5,15,5,4]

theorem envBound4342 : H12AffineFastState.Bounded env4342 := by
  intro p hp
  have h : env4342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4341_4342 : H12AffineEnvironment.transform 8 5 env4341 = env4342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env4341 == env4342) = true)

def env4343 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1280,8192,16384,32768,50570,1197,262144,1024,32768,1281,4194304,4194336,41003,8329,4194337,320897,16385,16813,19744,57760,58380,256,17665,4236333,4195212]

theorem envBound4343 : H12AffineFastState.Bounded env4343 := by
  intro p hp
  have h : env4343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4318_4343 : H12AffineEnvironment.transform 3 1 env4318 = env4343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4318 == env4343) = true)

theorem identity4343 : scanCanonicalize (H12AffineFastState.compose env4343 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound4343 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4344 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1280,8192,16384,8461,25735,1197,262144,1024,8461,1281,4194304,4194336,294,8329,4194337,279692,16385,16813,19744,16557,17665,256,17665,4195616,4195212]

theorem envBound4344 : H12AffineFastState.Bounded env4344 := by
  intro p hp
  have h : env4344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4343_4344 : H12AffineEnvironment.transform 14 8461 env4343 = env4344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env4343 == env4344) = true)

theorem identity4344 : scanCanonicalize (H12AffineFastState.compose env4344 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4344 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4345 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1029,8192,16384,8200,25735,1197,262144,1024,8200,1028,4194304,4194336,35,8329,4194337,279692,16385,16552,19493,16557,17412,5,17412,4195365,4194953]

theorem envBound4345 : H12AffineFastState.Bounded env4345 := by
  intro p hp
  have h : env4345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4344_4345 : H12AffineEnvironment.transform 7 5 env4344 = env4345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4344 == env4345) = true)

def env4346 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1281,8192,16384,32768,65536,1196,262144,1024,32768,1280,4194304,4310442,41003,8329,4310443,320896,16385,16813,19745,74794,74134,256,17664,4236348,4310551]

theorem envBound4346 : H12AffineFastState.Bounded env4346 := by
  intro p hp
  have h : env4346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4316_4346 : H12AffineEnvironment.transform 11 1281 env4316 = env4346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env4316 == env4346) = true)

theorem identity4346 : scanCanonicalize (H12AffineFastState.compose env4346 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50214) := by decide +kernel

theorem selectedBound4346 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4347 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1281,8192,16384,32768,50214,1196,262144,1024,32768,1280,4194304,4194700,41003,8329,4194701,320896,16385,16813,19745,57356,58800,256,17664,4236348,4194865]

theorem envBound4347 : H12AffineFastState.Bounded env4347 := by
  intro p hp
  have h : env4347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4346_4347 : H12AffineEnvironment.transform 15 50214 env4346 = env4347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50214 env4346 == env4347) = true)

def env4348 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,32768,50214,1196,262144,1024,32768,1280,4194304,4194700,41003,8329,4194701,320896,16385,16813,19745,57356,58784,256,17664,4236332,4194849]

theorem envBound4348 : H12AffineFastState.Bounded env4348 := by
  intro p hp
  have h : env4348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4347_4348 : H12AffineEnvironment.transform 3 0 env4347 = env4348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4347 == env4348) = true)

theorem identity4348 : scanCanonicalize (H12AffineFastState.compose env4348 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8612) := by decide +kernel

theorem selectedBound4348 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4349 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8612,25986,1196,262144,1024,8612,1280,4194304,4194700,399,8329,4194701,279588,16385,16813,19745,16808,17412,256,17664,4195720,4194849]

theorem envBound4349 : H12AffineFastState.Bounded env4349 := by
  intro p hp
  have h : env4349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4348_4349 : H12AffineEnvironment.transform 14 8612 env4348 = env4349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8612 env4348 == env4349) = true)

theorem identity4349 : scanCanonicalize (H12AffineFastState.compose env4349 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 17549) := by decide +kernel

theorem selectedBound4349 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4350 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8612,25986,1196,262144,1024,8612,1280,17549,17665,399,8329,17664,279588,16385,16813,19745,16808,17412,256,17664,16645,18092]

theorem envBound4350 : H12AffineFastState.Bounded env4350 := by
  intro p hp
  have h : env4350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4349_4350 : H12AffineEnvironment.transform 21 17549 env4349 = env4350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17549 env4349 == env4350) = true)

theorem identity4350 : scanCanonicalize (H12AffineFastState.compose env4350 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4350 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4351 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8612,25986,1196,2081,1024,8612,1280,17549,17665,399,8329,17664,19461,16385,16813,19745,16808,17412,256,17664,16645,18092]

theorem envBound4351 : H12AffineFastState.Bounded env4351 := by
  intro p hp
  have h : env4351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4350_4351 : H12AffineEnvironment.transform 17 2081 env4350 = env4351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4350 == env4351) = true)

theorem identity4351 : scanCanonicalize (H12AffineFastState.compose env4351 (packedSelected [0,1,6,7,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 11814) := by decide +kernel

theorem selectedBound4351 : packedSelected [0,1,6,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env4352 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,11814,8612,2980,1196,2081,1024,8612,1280,10923,11047,399,8329,11046,8739,11815,12171,8967,12174,10786,256,11046,12067,10378]

theorem envBound4352 : H12AffineFastState.Bounded env4352 := by
  intro p hp
  have h : env4352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4351_4352 : H12AffineEnvironment.transform 13 11814 env4351 = env4352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11814 env4351 == env4352) = true)

theorem identity4352 : scanCanonicalize (H12AffineFastState.compose env4352 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2311) := by decide +kernel

theorem selectedBound4352 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env4353 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,2311,1825,2211,2980,1196,2081,1024,2211,1280,940,544,399,2446,545,2852,1824,1676,2560,1673,805,256,545,1572,397]

theorem envBound4353 : H12AffineFastState.Bounded env4353 := by
  intro p hp
  have h : env4353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4352_4353 : H12AffineEnvironment.transform 12 2311 env4352 = env4353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2311 env4352 == env4353) = true)

theorem identity4353 : scanCanonicalize (H12AffineFastState.compose env4353 (packedSelected [0,5,6,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4353 : packedSelected [0,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env4354 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,1196,2218,1676,2211,2569,1196,2081,1024,2211,1197,513,544,34,2083,545,2697,1677,1676,2560,1673,648,173,545,1572,32]

theorem envBound4354 : H12AffineFastState.Bounded env4354 := by
  intro p hp
  have h : env4354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4353_4354 : H12AffineEnvironment.transform 7 173 env4353 = env4354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4353 == env4354) = true)

theorem identity4354 : scanCanonicalize (H12AffineFastState.compose env4354 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1158) := by decide +kernel

theorem selectedBound4354 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4355 : List Nat := [2,4,8,0,32,1,128,173,512,1024,1158,1196,1068,1676,1061,1679,1196,1191,1024,1061,1197,513,544,34,1189,545,1551,1677,1676,1670,1673,648,173,545,1572,32]

theorem envBound4355 : H12AffineFastState.Bounded env4355 := by
  intro p hp
  have h : env4355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4354_4355 : H12AffineEnvironment.transform 10 1158 env4354 = env4355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1158 env4354 == env4355) = true)

theorem identity4355 : scanCanonicalize (H12AffineFastState.compose env4355 (packedSelected [7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4355 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env4356 : List Nat := [2,4,8,0,32,1,41,4,512,1024,1071,1029,1068,1573,1061,1574,1029,1038,1024,1061,1028,513,544,34,1036,545,1551,1572,1573,1583,1568,545,4,545,1572,32]

theorem envBound4356 : H12AffineFastState.Bounded env4356 := by
  intro p hp
  have h : env4356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4355_4356 : H12AffineEnvironment.transform 6 41 env4355 = env4356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4355 == env4356) = true)

theorem identity4356 : scanCanonicalize (H12AffineFastState.compose env4356 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4356 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4357 : List Nat := [2,4,2,0,32,1,35,4,512,1024,1061,1029,1062,1573,1061,1574,1029,1028,1024,1061,1028,513,544,34,1030,545,1541,1572,1573,1573,1568,545,4,545,1572,32]

theorem envBound4357 : H12AffineFastState.Bounded env4357 := by
  intro p hp
  have h : env4357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4356_4357 : H12AffineEnvironment.transform 2 2 env4356 = env4357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4356 == env4357) = true)

theorem identity4357 : scanCanonicalize (H12AffineFastState.compose env4357 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound4357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4358 : List Nat := [2,4,2,0,32,1,35,4,512,517,544,512,547,32,544,35,512,513,517,544,513,513,544,34,515,545,0,33,32,32,37,545,4,545,33,32]

theorem envBound4358 : H12AffineFastState.Bounded env4358 := by
  intro p hp
  have h : env4358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4357_4358 : H12AffineEnvironment.transform 9 517 env4357 = env4358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env4357 == env4358) = true)

theorem identity4358 : scanCanonicalize (H12AffineFastState.compose env4358 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4358 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env4359 : List Nat := [2,4,2,0,32,1,35,4,1,4,33,1,34,32,33,35,1,0,4,33,0,0,33,34,2,32,0,33,32,32,37,32,4,32,33,32]

theorem envBound4359 : H12AffineFastState.Bounded env4359 := by
  intro p hp
  have h : env4359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4358_4359 : H12AffineEnvironment.transform 8 1 env4358 = env4359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4358 == env4359) = true)

def env4360 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1281,8192,16384,32768,50214,1196,262144,1024,32768,1280,4194304,4194700,41003,8329,4194701,320896,16385,16813,19745,57356,58785,256,17664,4236333,4194848]

theorem envBound4360 : H12AffineFastState.Bounded env4360 := by
  intro p hp
  have h : env4360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4347_4360 : H12AffineEnvironment.transform 3 1 env4347 = env4360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4347 == env4360) = true)

theorem identity4360 : scanCanonicalize (H12AffineFastState.compose env4360 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4360 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4361 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,16384,32768,50214,1029,262144,1024,32768,1280,4194304,4194597,41003,8224,4194596,320809,16385,16644,19745,57356,58632,256,17664,4236333,4194848]

theorem envBound4361 : H12AffineFastState.Bounded env4361 := by
  intro p hp
  have h : env4361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4360_4361 : H12AffineEnvironment.transform 6 41 env4360 = env4361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4360 == env4361) = true)

theorem identity4361 : scanCanonicalize (H12AffineFastState.compose env4361 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19493) := by decide +kernel

theorem selectedBound4361 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4362 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,16384,32768,50214,1029,19493,1024,32768,1280,4194304,4194597,41003,8224,4194596,43276,16385,16644,19745,57356,58632,256,17664,4236333,4194848]

theorem envBound4362 : H12AffineFastState.Bounded env4362 := by
  intro p hp
  have h : env4362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4361_4362 : H12AffineEnvironment.transform 17 19493 env4361 = env4362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19493 env4361 == env4362) = true)

theorem identity4362 : scanCanonicalize (H12AffineFastState.compose env4362 (packedSelected [0,3,4,5,7,10,13,17,22] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound4362 : packedSelected [0,3,4,5,7,10,13,17,22] rootPS < 2^1333 := by decide +kernel

def env4363 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,16384,32768,50214,1029,19493,1024,32768,1280,41000,41229,41003,8224,41228,43276,16385,16644,19745,57356,58632,256,17664,1029,41480]

theorem envBound4363 : H12AffineFastState.Bounded env4363 := by
  intro p hp
  have h : env4363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4362_4363 : H12AffineEnvironment.transform 21 41000 env4362 = env4363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env4362 == env4363) = true)

theorem identity4363 : scanCanonicalize (H12AffineFastState.compose env4363 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound4363 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env4364 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,1572,32768,33282,1029,2561,1024,32768,1280,41000,41229,41003,8224,41228,43276,1573,1824,2821,42536,41772,256,804,1029,41480]

theorem envBound4364 : H12AffineFastState.Bounded env4364 := by
  intro p hp
  have h : env4364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4363_4364 : H12AffineEnvironment.transform 13 1572 env4363 = env4364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env4363 == env4364) = true)

theorem identity4364 : scanCanonicalize (H12AffineFastState.compose env4364 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4364 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env4365 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,1281,8192,1572,8201,8715,1029,2561,1024,8201,1280,33,260,34,8224,261,2309,1573,1824,2821,1569,805,256,804,1029,513]

theorem envBound4365 : H12AffineFastState.Bounded env4365 := by
  intro p hp
  have h : env4365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4364_4365 : H12AffineEnvironment.transform 14 8201 env4364 = env4365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4364 == env4365) = true)

theorem identity4365 : scanCanonicalize (H12AffineFastState.compose env4365 (packedSelected [4,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound4365 : packedSelected [4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env4366 : List Nat := [2,4,8,1,32,0,41,256,14,1024,2048,1281,8192,1066,8201,8197,1029,2063,1024,8201,1280,33,260,34,8224,261,2309,1067,1326,2315,1071,299,256,298,1029,15]

theorem envBound4366 : H12AffineFastState.Bounded env4366 := by
  intro p hp
  have h : env4366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4365_4366 : H12AffineEnvironment.transform 8 14 env4365 = env4366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env4365 == env4366) = true)

theorem identity4366 : scanCanonicalize (H12AffineFastState.compose env4366 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 43) := by decide +kernel

theorem selectedBound4366 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4367 : List Nat := [2,4,8,1,32,0,41,43,14,1024,2048,1066,8192,1066,8201,8197,1029,2063,1024,8201,1067,33,47,34,8224,46,2094,1067,1029,2080,1071,0,43,1,1029,15]

theorem envBound4367 : H12AffineFastState.Bounded env4367 := by
  intro p hp
  have h : env4367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4366_4367 : H12AffineEnvironment.transform 7 43 env4366 = env4367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 43 env4366 == env4367) = true)

theorem identity4367 : scanCanonicalize (H12AffineFastState.compose env4367 (packedSelected [0,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 1058) := by decide +kernel

theorem selectedBound4367 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env4368 : List Nat := [2,4,8,1,32,0,41,43,14,1024,2048,1066,1058,1066,1067,1063,1029,2063,1024,1067,1067,33,47,34,1026,46,2094,1067,1029,2080,1071,0,43,1,1029,15]

theorem envBound4368 : H12AffineFastState.Bounded env4368 := by
  intro p hp
  have h : env4368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4367_4368 : H12AffineEnvironment.transform 12 1058 env4367 = env4368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1058 env4367 == env4368) = true)

def env4369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323793,16385,16892,22640,74795,12644669,257,20561,8479126,8389613]

theorem envBound4369 : H12AffineFastState.Bounded env4369 := by
  intro p hp
  have h : env4369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4307_4369 : H12AffineEnvironment.transform 18 1025 env4307 = env4369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4307 == env4369) = true)

theorem identity4369 : scanCanonicalize (H12AffineFastState.compose env4369 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 98475) := by decide +kernel

theorem selectedBound4369 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,98475,8388608,41003,8329,8388689,323793,16385,16892,22640,74795,8483222,257,20561,8479126,8389613]

theorem envBound4370 : H12AffineFastState.Bounded env4370 := by
  intro p hp
  have h : env4370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4369_4370 : H12AffineEnvironment.transform 21 98475 env4369 = env4370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98475 env4369 == env4370) = true)

def env4371 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,98475,8388608,41003,8329,8388609,323713,16385,16812,22560,74795,8483222,257,20481,8479126,8389565]

theorem envBound4371 : H12AffineFastState.Bounded env4371 := by
  intro p hp
  have h : env4371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4370_4371 : H12AffineEnvironment.transform 5 16 env4370 = env4371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4370 == env4371) = true)

def env4372 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,98307,8388608,41003,8225,8388609,323625,16385,16644,22560,74795,8483134,257,20481,8479038,8389397]

theorem envBound4372 : H12AffineFastState.Bounded env4372 := by
  intro p hp
  have h : env4372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4371_4372 : H12AffineEnvironment.transform 6 40 env4371 = env4372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4371 == env4372) = true)

theorem identity4372 : scanCanonicalize (H12AffineFastState.compose env4372 (packedSelected [0,7,9,11,20,22,32] rootPS)) = affineNative (2^(22+1) ^^^ 325948) := by decide +kernel

theorem selectedBound4372 : packedSelected [0,7,9,11,20,22,32] rootPS < 2^1333 := by decide +kernel

def env4373 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,98307,325948,41003,8225,325949,323625,16385,16644,22560,74795,362498,257,20481,366594,326185]

theorem envBound4373 : H12AffineFastState.Bounded env4373 := by
  intro p hp
  have h : env4373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4372_4373 : H12AffineEnvironment.transform 22 325948 env4372 = env4373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 325948 env4372 == env4373) = true)

theorem identity4373 : scanCanonicalize (H12AffineFastState.compose env4373 (packedSelected [0,1,3,5,7,8,9,10,13,17,20,22,26] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound4373 : packedSelected [0,1,3,5,7,8,9,10,13,17,20,22,26] rootPS < 2^1333 := by decide +kernel

def env4374 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,43049,1025,32768,4097,98307,20757,41003,8225,20756,22528,16385,16644,22560,74795,73771,257,20481,77867,20992]

theorem envBound4374 : H12AffineFastState.Bounded env4374 := by
  intro p hp
  have h : env4374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4373_4374 : H12AffineEnvironment.transform 17 43049 env4373 = env4374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env4373 == env4374) = true)

theorem identity4374 : scanCanonicalize (H12AffineFastState.compose env4374 (packedSelected [2,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound4374 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4375 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8461,65536,4356,2340,1025,8461,4097,73998,20757,294,8225,20756,22528,16385,16644,22560,74795,73771,257,20481,77867,20992]

theorem envBound4375 : H12AffineFastState.Bounded env4375 := by
  intro p hp
  have h : env4375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4374_4375 : H12AffineEnvironment.transform 14 8461 env4374 = env4375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env4374 == env4375) = true)

theorem identity4375 : scanCanonicalize (H12AffineFastState.compose env4375 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 19478) := by decide +kernel

theorem selectedBound4375 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env4376 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8461,19478,4356,2340,1025,8461,4097,27928,20757,294,8225,20756,22528,16385,16644,22560,26685,27709,257,20481,31805,20992]

theorem envBound4376 : H12AffineFastState.Bounded env4376 := by
  intro p hp
  have h : env4376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4375_4376 : H12AffineEnvironment.transform 15 19478 env4375 = env4376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19478 env4375 == env4376) = true)

theorem identity4376 : scanCanonicalize (H12AffineFastState.compose env4376 (packedSelected [3,5,11] rootPS)) = affineNative (2^(13+1) ^^^ 4609) := by decide +kernel

theorem selectedBound4376 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env4377 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,4609,8461,7703,4356,2340,1025,8461,4097,16153,788,294,8225,789,2561,4608,4869,2593,14908,15932,257,512,11836,1]

theorem envBound4377 : H12AffineFastState.Bounded env4377 := by
  intro p hp
  have h : env4377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4376_4377 : H12AffineEnvironment.transform 13 4609 env4376 = env4377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4609 env4376 == env4377) = true)

theorem identity4377 : scanCanonicalize (H12AffineFastState.compose env4377 (packedSelected [1,2,3,4,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4377 : packedSelected [1,2,3,4,9,10,12] rootPS < 2^1333 := by decide +kernel

def env4378 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1840,8192,1329,8461,2343,1588,2340,1025,8461,1841,10281,788,294,8225,789,2561,1328,1077,2593,11532,10508,257,512,11836,1]

theorem envBound4378 : H12AffineFastState.Bounded env4378 := by
  intro p hp
  have h : env4378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4377_4378 : H12AffineEnvironment.transform 11 1840 env4377 = env4378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env4377 == env4378) = true)

theorem identity4378 : scanCanonicalize (H12AffineFastState.compose env4378 (packedSelected [0,1,3,6,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4378 : packedSelected [0,1,3,6,9,10,13] rootPS < 2^1333 := by decide +kernel

def env4379 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,1588,8192,1077,8201,2083,1588,2080,1025,8201,1589,10281,528,34,8225,529,2561,1076,1077,2593,11272,10248,5,512,11836,1]

theorem envBound4379 : H12AffineFastState.Bounded env4379 := by
  intro p hp
  have h : env4379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4378_4379 : H12AffineEnvironment.transform 7 4 env4378 = env4379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4378 == env4379) = true)

theorem identity4379 : scanCanonicalize (H12AffineFastState.compose env4379 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4380 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1589,1588,8192,1077,8201,1558,1588,1557,1025,8201,1589,9756,528,34,8225,529,1076,1076,1077,1044,8765,9789,5,512,8201,1]

theorem envBound4380 : H12AffineFastState.Bounded env4380 := by
  intro p hp
  have h : env4380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4379_4380 : H12AffineEnvironment.transform 10 1589 env4379 = env4380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env4379 == env4380) = true)

theorem identity4380 : scanCanonicalize (H12AffineFastState.compose env4380 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound4380 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4381 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1589,1588,1085,1077,1076,1558,1588,1557,1025,1076,1589,545,528,34,1052,529,1076,1076,1077,1044,1536,512,5,512,1076,1]

theorem envBound4381 : H12AffineFastState.Bounded env4381 := by
  intro p hp
  have h : env4381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4380_4381 : H12AffineEnvironment.transform 12 1085 env4380 = env4381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env4380 == env4381) = true)

theorem identity4381 : scanCanonicalize (H12AffineFastState.compose env4381 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound4381 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4382 : List Nat := [2,4,8,16,32,16,40,4,512,526,59,58,563,571,570,24,58,27,527,570,59,545,528,34,530,529,570,570,571,538,14,512,5,512,570,1]

theorem envBound4382 : H12AffineFastState.Bounded env4382 := by
  intro p hp
  have h : env4382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4381_4382 : H12AffineEnvironment.transform 9 526 env4381 = env4382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env4381 == env4382) = true)

theorem identity4382 : scanCanonicalize (H12AffineFastState.compose env4382 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound4382 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4383 : List Nat := [2,4,8,16,32,16,40,4,59,53,59,58,8,0,1,24,58,27,52,1,59,26,43,34,41,42,1,1,0,33,14,59,5,59,1,1]

theorem envBound4383 : H12AffineFastState.Bounded env4383 := by
  intro p hp
  have h : env4383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4382_4383 : H12AffineEnvironment.transform 8 59 env4382 = env4383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env4382 == env4383) = true)

def env4384 : List Nat := [2,4,8,4,32,4,40,4,47,33,47,46,8,0,1,12,46,15,32,1,47,14,43,34,41,42,1,1,0,33,14,47,5,47,1,1]

theorem envBound4384 : H12AffineFastState.Bounded env4384 := by
  intro p hp
  have h : env4384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4383_4384 : H12AffineEnvironment.transform 3 4 env4383 = env4384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env4383 == env4384) = true)

def env4385 : List Nat := [2,4,8,5,32,5,40,4,46,32,46,47,8,0,1,13,47,14,33,1,46,15,43,34,41,42,1,1,0,33,14,46,5,46,1,1]

theorem envBound4385 : H12AffineFastState.Bounded env4385 := by
  intro p hp
  have h : env4385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4383_4385 : H12AffineEnvironment.transform 3 5 env4383 = env4385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env4383 == env4385) = true)

theorem identity4385 : scanCanonicalize (H12AffineFastState.compose env4385 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound4385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4386 : List Nat := [2,4,8,5,14,5,6,4,0,14,0,1,8,0,1,13,1,14,15,1,0,15,5,12,7,4,1,1,0,15,14,0,5,0,1,1]

theorem envBound4386 : H12AffineFastState.Bounded env4386 := by
  intro p hp
  have h : env4386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4385_4386 : H12AffineEnvironment.transform 4 14 env4385 = env4386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env4385 == env4386) = true)

theorem identity4386 : scanCanonicalize (H12AffineFastState.compose env4386 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4386 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4387 : List Nat := [2,0,8,1,10,1,2,0,0,10,0,1,8,0,1,9,1,10,11,1,0,11,1,8,3,0,1,1,0,11,10,0,1,0,1,1]

theorem envBound4387 : H12AffineFastState.Bounded env4387 := by
  intro p hp
  have h : env4387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4386_4387 : H12AffineEnvironment.transform 1 0 env4386 = env4387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4386 == env4387) = true)

def leafEnv4387 : List Nat := [2,0,8,1,10,1,2,0,0,10,0,1,8,0,1,9,1,10,11,1,0,11,1,8,11,3,1,0,1,1,0,11,10,0,1,0,1,2,1,1,1,1,0]

def active4387 : List Nat := [0,2]

def tree4387 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4387 : H12WitnessSearch.Good tree4387 := H12GlobalWitnessIndex.good

theorem leafIdentity4387 : H12AffineFastState.composeSystem env4387 rootObs = leafEnv4387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4387 rootObs == leafEnv4387) = true)

theorem terminalChecked4387 : H12PackedTerminal.terminalCheckFast leafEnv4387 active4387 tree4387 = true := by decide +kernel

def env4388 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1025,32768,4097,98306,8388608,41003,8224,8388609,323624,16385,16645,22560,74795,8483135,257,20481,8479039,8389396]

theorem envBound4388 : H12AffineFastState.Bounded env4388 := by
  intro p hp
  have h : env4388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4371_4388 : H12AffineEnvironment.transform 6 41 env4371 = env4388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4371 == env4388) = true)

theorem identity4388 : scanCanonicalize (H12AffineFastState.compose env4388 (packedSelected [0,7,9,11,20,22,32] rootPS)) = affineNative (2^(22+1) ^^^ 74046) := by decide +kernel

theorem selectedBound4388 : packedSelected [0,7,9,11,20,22,32] rootPS < 2^1333 := by decide +kernel

def env4389 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1025,32768,4097,98306,74046,41003,8224,74047,323624,16385,16645,22560,74795,20481,257,20481,16385,74282]

theorem envBound4389 : H12AffineFastState.Bounded env4389 := by
  intro p hp
  have h : env4389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4388_4389 : H12AffineEnvironment.transform 22 74046 env4388 = env4389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 74046 env4388 == env4389) = true)

theorem identity4389 : scanCanonicalize (H12AffineFastState.compose env4389 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4389 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4390 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4097,98306,73786,41003,8224,73787,323624,16385,16385,22560,74795,20481,5,20481,16385,74282]

theorem envBound4390 : H12AffineFastState.Bounded env4390 := by
  intro p hp
  have h : env4390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4389_4390 : H12AffineEnvironment.transform 7 4 env4389 = env4390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4389 == env4390) = true)

theorem identity4390 : scanCanonicalize (H12AffineFastState.compose env4390 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4390 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env4391 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,65536,4097,2080,1025,32768,4097,98306,73786,41003,8224,73787,63496,16385,16385,22560,74795,20481,5,20481,16385,74282]

theorem envBound4391 : H12AffineFastState.Bounded env4391 := by
  intro p hp
  have h : env4391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4390_4391 : H12AffineEnvironment.transform 17 2080 env4390 = env4391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4390 == env4391) = true)

theorem identity4391 : scanCanonicalize (H12AffineFastState.compose env4391 (packedSelected [3,4,5,9,10,12,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 38422) := by decide +kernel

theorem selectedBound4391 : packedSelected [3,4,5,9,10,12,18,20] rootPS < 2^1333 := by decide +kernel

def env4392 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,38422,4097,2080,1025,32768,4097,5652,46636,41003,8224,46637,63496,16385,16385,22560,45629,20481,5,20481,16385,46140]

theorem envBound4392 : H12AffineFastState.Bounded env4392 := by
  intro p hp
  have h : env4392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4391_4392 : H12AffineEnvironment.transform 15 38422 env4391 = env4392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38422 env4391 == env4392) = true)

theorem identity4392 : scanCanonicalize (H12AffineFastState.compose env4392 (packedSelected [3,5,10,12,13,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4392 : packedSelected [3,5,10,12,13,18,21] rootPS < 2^1333 := by decide +kernel

def env4393 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,8200,13854,4097,2080,1025,8200,4097,5652,5668,35,8224,5669,22528,16385,16385,22560,4661,20481,5,20481,16385,5172]

theorem envBound4393 : H12AffineFastState.Bounded env4393 := by
  intro p hp
  have h : env4393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4392_4393 : H12AffineEnvironment.transform 14 8200 env4392 = env4393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4392 == env4393) = true)

theorem identity4393 : scanCanonicalize (H12AffineFastState.compose env4393 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4393 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env4394 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,1583,8200,13854,4097,2080,1025,8200,4097,5652,5668,35,8224,5669,7727,1582,1582,7695,4661,5678,5,5678,1582,5172]

theorem envBound4394 : H12AffineFastState.Bounded env4394 := by
  intro p hp
  have h : env4394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4393_4394 : H12AffineEnvironment.transform 13 1583 env4393 = env4394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1583 env4393 == env4394) = true)

theorem identity4394 : scanCanonicalize (H12AffineFastState.compose env4394 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4394 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4395 : List Nat := [2,4,8,11,32,11,41,4,512,1024,2048,4096,8192,1583,8200,13829,4097,2080,1025,8200,4097,5647,5668,35,8224,5669,7727,1582,1582,7695,4654,5678,5,5678,1582,5167]

theorem envBound4395 : H12AffineFastState.Bounded env4395 := by
  intro p hp
  have h : env4395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4394_4395 : H12AffineEnvironment.transform 3 11 env4394 = env4395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4394 == env4395) = true)

theorem identity4395 : scanCanonicalize (H12AffineFastState.compose env4395 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4395 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4396 : List Nat := [2,4,8,11,32,11,41,4,512,1024,2048,2081,8192,1583,8200,11812,2080,2080,1025,8200,2080,3630,3589,35,8224,3588,1550,1582,1582,1582,2575,3599,5,3599,1582,3086]

theorem envBound4396 : H12AffineFastState.Bounded env4396 := by
  intro p hp
  have h : env4396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4395_4396 : H12AffineEnvironment.transform 11 2081 env4395 = env4396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env4395 == env4396) = true)

theorem identity4396 : scanCanonicalize (H12AffineFastState.compose env4396 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound4396 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4397 : List Nat := [2,4,8,11,32,11,41,4,512,1024,1551,1582,8192,1583,8200,8235,1583,1583,1025,8200,1583,33,10,35,8224,11,1550,1582,1582,1582,1024,0,5,0,1582,513]

theorem envBound4397 : H12AffineFastState.Bounded env4397 := by
  intro p hp
  have h : env4397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4396_4397 : H12AffineEnvironment.transform 10 1551 env4396 = env4397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env4396 == env4397) = true)

theorem identity4397 : scanCanonicalize (H12AffineFastState.compose env4397 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound4397 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4398 : List Nat := [2,4,8,11,32,11,41,4,512,1024,1551,1582,1062,1583,1070,1037,1583,1583,1025,1070,1583,33,10,35,1030,11,1550,1582,1582,1582,1024,0,5,0,1582,513]

theorem envBound4398 : H12AffineFastState.Bounded env4398 := by
  intro p hp
  have h : env4398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4397_4398 : H12AffineEnvironment.transform 12 1062 env4397 = env4398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env4397 == env4398) = true)

theorem identity4398 : scanCanonicalize (H12AffineFastState.compose env4398 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound4398 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4399 : List Nat := [2,4,7,4,32,4,38,4,512,1024,1536,1569,1062,1568,1057,1026,1568,1568,1025,1057,1568,33,5,35,1030,4,1537,1569,1569,1569,1024,0,5,0,1569,513]

theorem envBound4399 : H12AffineFastState.Bounded env4399 := by
  intro p hp
  have h : env4399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4398_4399 : H12AffineEnvironment.transform 2 7 env4398 = env4399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env4398 == env4399) = true)

def env4400 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,98475,8388608,41003,8329,8388608,323712,16385,16813,22561,74795,8483222,257,20480,8479126,8389564]

theorem envBound4400 : H12AffineFastState.Bounded env4400 := by
  intro p hp
  have h : env4400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4370_4400 : H12AffineEnvironment.transform 5 17 env4370 = env4400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4370 == env4400) = true)

theorem identity4400 : scanCanonicalize (H12AffineFastState.compose env4400 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4400 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4401 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,98475,444,41003,8329,444,323712,16385,16813,22561,74795,94250,257,20480,90154,512]

theorem envBound4401 : H12AffineFastState.Bounded env4401 := by
  intro p hp
  have h : env4401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4400_4401 : H12AffineEnvironment.transform 22 444 env4400 = env4401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4400 == env4401) = true)

theorem identity4401 : scanCanonicalize (H12AffineFastState.compose env4401 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound4401 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4402 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1025,32768,4097,41349,444,41003,8329,444,323712,16385,16813,22561,1285,20740,257,20480,16644,512]

theorem envBound4402 : H12AffineFastState.Bounded env4402 := by
  intro p hp
  have h : env4402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4401_4402 : H12AffineEnvironment.transform 15 8494 env4401 = env4402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env4401 == env4402) = true)

theorem identity4402 : scanCanonicalize (H12AffineFastState.compose env4402 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound4402 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4403 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13973,8494,4525,262144,1025,13973,4097,5904,444,5822,8329,444,280085,16385,16813,22561,1285,20740,257,20480,16644,512]

theorem envBound4403 : H12AffineFastState.Bounded env4403 := by
  intro p hp
  have h : env4403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4402_4403 : H12AffineEnvironment.transform 14 13973 env4402 = env4403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env4402 == env4403) = true)

theorem identity4403 : scanCanonicalize (H12AffineFastState.compose env4403 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4525) := by decide +kernel

theorem selectedBound4403 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4404 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,13973,8494,4525,262144,1025,13973,4097,5904,444,5822,8329,444,268216,4524,4096,2444,1285,169,257,429,4265,512]

theorem envBound4404 : H12AffineFastState.Bounded env4404 := by
  intro p hp
  have h : env4404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4403_4404 : H12AffineEnvironment.transform 13 4525 env4403 = env4404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4525 env4403 == env4404) = true)

theorem identity4404 : scanCanonicalize (H12AffineFastState.compose env4404 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7868) := by decide +kernel

theorem selectedBound4404 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4405 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,13973,8494,4525,7868,1025,13973,4097,5904,444,5822,8329,444,2308,4524,4096,2444,1285,169,257,429,4265,512]

theorem envBound4405 : H12AffineFastState.Bounded env4405 := by
  intro p hp
  have h : env4405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4404_4405 : H12AffineEnvironment.transform 17 7868 env4404 = env4405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7868 env4404 == env4405) = true)

theorem identity4405 : scanCanonicalize (H12AffineFastState.compose env4405 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4405 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4406 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1841,8192,1692,8612,8494,1692,2445,1025,8612,1840,33,444,399,8329,444,2308,1693,1841,2444,1285,169,257,429,1944,512]

theorem envBound4406 : H12AffineFastState.Bounded env4406 := by
  intro p hp
  have h : env4406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4405_4406 : H12AffineEnvironment.transform 11 1841 env4405 = env4406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env4405 == env4406) = true)

theorem identity4406 : scanCanonicalize (H12AffineFastState.compose env4406 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4406 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4407 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1589,8192,1692,8352,8234,1692,2185,1025,8352,1588,33,184,139,8329,184,2048,1693,1589,2184,1025,169,5,169,1692,512]

theorem envBound4407 : H12AffineFastState.Bounded env4407 := by
  intro p hp
  have h : env4407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4406_4407 : H12AffineEnvironment.transform 7 4 env4406 = env4407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4406 == env4407) = true)

theorem identity4407 : scanCanonicalize (H12AffineFastState.compose env4407 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 2747) := by decide +kernel

theorem selectedBound4407 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env4408 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1589,2747,1692,2587,2705,1692,2185,1025,2587,1588,33,184,139,2610,184,2048,1693,1589,2184,1025,169,5,169,1692,512]

theorem envBound4408 : H12AffineFastState.Bounded env4408 := by
  intro p hp
  have h : env4408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4407_4408 : H12AffineEnvironment.transform 12 2747 env4407 = env4408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2747 env4407 == env4408) = true)

theorem identity4408 : scanCanonicalize (H12AffineFastState.compose env4408 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound4408 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env4409 : List Nat := [2,4,8,16,32,17,128,4,512,21,2048,544,2747,649,2587,2705,649,2185,20,2587,545,33,184,139,2610,184,2048,648,544,2184,20,169,5,169,649,512]

theorem envBound4409 : H12AffineFastState.Bounded env4409 := by
  intro p hp
  have h : env4409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4408_4409 : H12AffineEnvironment.transform 9 21 env4408 = env4409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env4408 == env4409) = true)

def env4410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41003,8329,11015249,849105,268435456,268435965,547952,2699307,12644668,525568,545873,8479127,8914924]

theorem envBound4410 : H12AffineFastState.Bounded env4410 := by
  intro p hp
  have h : env4410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3920_4410 : H12AffineEnvironment.transform 26 849105 env3920 = env4410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 849105 env3920 == env4410) = true)

def env4411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849105,268435456,268435965,547952,598059,12644668,525568,545873,8479127,8914924]

theorem envBound4411 : H12AffineFastState.Bounded env4411 := by
  intro p hp
  have h : env4411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4410_4411 : H12AffineEnvironment.transform 20 4096 env4410 = env4411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env4410 == env4411) = true)

def env4412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849105,16384,16893,547952,598059,12644668,525568,545873,8479127,8914924]

theorem envBound4412 : H12AffineFastState.Bounded env4412 := by
  intro p hp
  have h : env4412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4411_4412 : H12AffineEnvironment.transform 27 16384 env4411 = env4412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env4411 == env4412) = true)

def env4413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323793,16384,16893,22640,74795,12644668,256,20561,8479127,8389612]

theorem envBound4413 : H12AffineFastState.Bounded env4413 := by
  intro p hp
  have h : env4413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4412_4413 : H12AffineEnvironment.transform 18 1024 env4412 = env4413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4412 == env4413) = true)

theorem identity4413 : scanCanonicalize (H12AffineFastState.compose env4413 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound4413 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8494,4604,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323793,16384,16893,22640,1285,12644668,256,20561,8405177,8389612]

theorem envBound4414 : H12AffineFastState.Bounded env4414 := by
  intro p hp
  have h : env4414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4413_4414 : H12AffineEnvironment.transform 15 8494 env4413 = env4414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env4413 == env4414) = true)

def env4415 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,4194304,8388608,41003,8329,8388609,323713,16384,16813,22560,1285,12644668,256,20481,8405177,8389564]

theorem envBound4415 : H12AffineFastState.Bounded env4415 := by
  intro p hp
  have h : env4415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4414_4415 : H12AffineEnvironment.transform 5 16 env4414 = env4415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4414 == env4415) = true)

def env4416 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,136,8388608,41003,8329,8388609,323713,16384,16813,22560,1285,8450484,256,20481,8405177,8389564]

theorem envBound4416 : H12AffineFastState.Bounded env4416 := by
  intro p hp
  have h : env4416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4415_4416 : H12AffineEnvironment.transform 21 136 env4415 = env4416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env4415 == env4416) = true)

theorem identity4416 : scanCanonicalize (H12AffineFastState.compose env4416 (packedSelected [7,9,13,17,20,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 269996) := by decide +kernel

theorem selectedBound4416 : packedSelected [7,9,13,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env4417 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8494,4524,262144,1024,32768,4096,136,269996,41003,8329,269997,323713,16384,16813,22560,1285,323352,256,20481,286229,269584]

theorem envBound4417 : H12AffineFastState.Bounded env4417 := by
  intro p hp
  have h : env4417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4416_4417 : H12AffineEnvironment.transform 22 269996 env4416 = env4417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 269996 env4416 == env4417) = true)

def env4418 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,262144,1024,32768,4096,32,269828,41003,8225,269829,323625,16384,16645,22560,1285,323352,256,20481,286229,269584]

theorem envBound4418 : H12AffineFastState.Bounded env4418 := by
  intro p hp
  have h : env4418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4417_4418 : H12AffineEnvironment.transform 6 40 env4417 = env4418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4417 == env4418) = true)

theorem identity4418 : scanCanonicalize (H12AffineFastState.compose env4418 (packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 61208) := by decide +kernel

theorem selectedBound4418 : packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4419 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,8494,4356,61208,1024,32768,4096,32,61724,41003,8225,61725,7985,16384,16645,22560,1285,0,256,20481,45325,61960]

theorem envBound4419 : H12AffineFastState.Bounded env4419 := by
  intro p hp
  have h : env4419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4418_4419 : H12AffineEnvironment.transform 17 61208 env4418 = env4419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61208 env4418 == env4419) = true)

theorem identity4419 : scanCanonicalize (H12AffineFastState.compose env4419 (packedSelected [17,21] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4419 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env4420 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1840,8192,16384,32768,8494,1588,61208,1024,32768,1840,32,58924,41003,8225,58925,2049,16384,16645,20240,1285,0,256,18225,42557,58680]

theorem envBound4420 : H12AffineFastState.Bounded env4420 := by
  intro p hp
  have h : env4420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4419_4420 : H12AffineEnvironment.transform 11 1840 env4419 = env4420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env4419 == env4420) = true)

theorem identity4420 : scanCanonicalize (H12AffineFastState.compose env4420 (packedSelected [4,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound4420 : packedSelected [4,20,22] rootPS < 2^1333 := by decide +kernel

def env4421 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1840,8192,16384,8460,8494,1588,19988,1024,8460,1840,32,18208,295,8225,18209,2049,16384,16645,20240,1285,0,256,18225,1841,17460]

theorem envBound4421 : H12AffineFastState.Bounded env4421 := by
  intro p hp
  have h : env4421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4420_4421 : H12AffineEnvironment.transform 14 8460 env4420 = env4421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env4420 == env4421) = true)

theorem identity4421 : scanCanonicalize (H12AffineFastState.compose env4421 (packedSelected [0,2,3,6,7,8,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1834) := by decide +kernel

theorem selectedBound4421 : packedSelected [0,2,3,6,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env4422 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1840,8192,1834,8460,8494,1588,2366,1024,8460,1840,32,10,295,8225,11,2049,1834,1583,2106,1285,0,256,27,1841,798]

theorem envBound4422 : H12AffineFastState.Bounded env4422 := by
  intro p hp
  have h : env4422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4421_4422 : H12AffineEnvironment.transform 13 1834 env4421 = env4422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1834 env4421 == env4422) = true)

theorem identity4422 : scanCanonicalize (H12AffineFastState.compose env4422 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4422 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env4423 : List Nat := [2,4,8,10,32,10,40,256,512,1024,2048,1834,8192,1834,8460,8494,1582,2340,1024,8460,1834,32,10,295,8225,11,2049,1834,1583,2080,1285,0,256,1,1835,772]

theorem envBound4423 : H12AffineFastState.Bounded env4423 := by
  intro p hp
  have h : env4423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4422_4423 : H12AffineEnvironment.transform 3 10 env4422 = env4423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4422 == env4423) = true)

theorem identity4423 : scanCanonicalize (H12AffineFastState.compose env4423 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound4423 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env4424 : List Nat := [2,4,8,10,32,10,40,256,512,1024,2048,1834,300,1834,32,2,1582,2340,1024,32,1834,32,10,295,269,11,2049,1834,1583,2080,1285,0,256,1,1835,772]

theorem envBound4424 : H12AffineFastState.Bounded env4424 := by
  intro p hp
  have h : env4424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4423_4424 : H12AffineEnvironment.transform 12 300 env4423 = env4424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env4423 == env4424) = true)

theorem identity4424 : scanCanonicalize (H12AffineFastState.compose env4424 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4424 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4425 : List Nat := [2,4,8,10,32,10,40,4,512,1024,2048,1582,40,1582,32,2,1582,2080,1024,32,1582,32,10,35,9,11,2049,1582,1583,2080,1025,0,4,1,1583,512]

theorem envBound4425 : H12AffineFastState.Bounded env4425 := by
  intro p hp
  have h : env4425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4424_4425 : H12AffineEnvironment.transform 7 4 env4424 = env4425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4424 == env4425) = true)

theorem identity4425 : scanCanonicalize (H12AffineFastState.compose env4425 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound4425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4426 : List Nat := [2,4,8,10,32,10,40,4,512,1024,523,1582,40,1582,32,2,1582,555,1024,32,1582,32,10,35,9,11,522,1582,1583,555,1025,0,4,1,1583,512]

theorem envBound4426 : H12AffineFastState.Bounded env4426 := by
  intro p hp
  have h : env4426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4425_4426 : H12AffineEnvironment.transform 10 523 env4425 = env4426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env4425 == env4426) = true)

theorem identity4426 : scanCanonicalize (H12AffineFastState.compose env4426 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound4426 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4427 : List Nat := [2,4,8,10,11,10,3,4,512,1024,523,1541,3,1541,11,2,1541,512,1024,11,1541,11,10,8,9,11,522,1541,1540,512,1025,0,4,1,1540,512]

theorem envBound4427 : H12AffineFastState.Bounded env4427 := by
  intro p hp
  have h : env4427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4426_4427 : H12AffineEnvironment.transform 4 11 env4426 = env4427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env4426 == env4427) = true)

theorem identity4427 : scanCanonicalize (H12AffineFastState.compose env4427 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4427 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4428 : List Nat := [2,4,3,1,0,1,3,4,512,1024,512,1541,3,1541,0,2,1541,512,1024,0,1541,0,1,3,2,0,513,1541,1540,512,1025,0,4,1,1540,512]

theorem envBound4428 : H12AffineFastState.Bounded env4428 := by
  intro p hp
  have h : env4428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4427_4428 : H12AffineEnvironment.transform 2 3 env4427 = env4428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4427 == env4428) = true)

theorem identity4428 : scanCanonicalize (H12AffineFastState.compose env4428 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4428 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4429 : List Nat := [2,4,3,1,0,1,3,4,0,1024,0,1029,3,1029,0,2,1029,0,1024,0,1029,0,1,3,2,0,1,1029,1028,0,1025,0,4,1,1028,0]

theorem envBound4429 : H12AffineFastState.Bounded env4429 := by
  intro p hp
  have h : env4429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4428_4429 : H12AffineEnvironment.transform 8 0 env4428 = env4429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4428 == env4429) = true)

def leafEnv4429 : List Nat := [2,4,3,1,0,1,3,4,0,1024,0,1029,3,1029,0,2,1029,0,1024,0,1029,0,1,3,1025,2,1,0,1,1029,1028,0,1025,0,4,1,4,2,1028,0,1,1029,0]

def active4429 : List Nat := [0,1,9]

def tree4429 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4429 : H12WitnessSearch.Good tree4429 := H12GlobalWitnessIndex.good

theorem leafIdentity4429 : H12AffineFastState.composeSystem env4429 rootObs = leafEnv4429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4429 rootObs == leafEnv4429) = true)

theorem terminalChecked4429 : H12PackedTerminal.terminalCheckFast leafEnv4429 active4429 tree4429 = true := by decide +kernel

def env4430 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,8494,4357,262144,1024,32768,4096,33,269829,41003,8224,269828,323624,16384,16644,22560,1285,323352,256,20481,286229,269584]

theorem envBound4430 : H12AffineFastState.Bounded env4430 := by
  intro p hp
  have h : env4430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4417_4430 : H12AffineEnvironment.transform 6 41 env4417 = env4430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4417 == env4430) = true)

theorem identity4430 : scanCanonicalize (H12AffineFastState.compose env4430 (packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 48668) := by decide +kernel

theorem selectedBound4430 : packedSelected [3,9,10,11,13,18,21,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4431 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,8494,4357,48668,1024,32768,4096,33,40985,41003,8224,40984,20020,16384,16644,22560,1285,20740,256,20481,57353,41740]

theorem envBound4431 : H12AffineFastState.Bounded env4431 := by
  intro p hp
  have h : env4431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4430_4431 : H12AffineEnvironment.transform 17 48668 env4430 = env4431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48668 env4430 == env4431) = true)

theorem identity4431 : scanCanonicalize (H12AffineFastState.compose env4431 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4431 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4432 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,1840,32768,8494,4357,48668,1024,32768,4096,33,40985,41003,8224,40984,2308,1840,1588,7952,1285,5684,256,5937,42809,41740]

theorem envBound4432 : H12AffineFastState.Bounded env4432 := by
  intro p hp
  have h : env4432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4431_4432 : H12AffineEnvironment.transform 13 1840 env4431 = env4432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env4431 == env4432) = true)

theorem identity4432 : scanCanonicalize (H12AffineFastState.compose env4432 (packedSelected [0,4,7,9,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4432 : packedSelected [0,4,7,9,13,21] rootPS < 2^1333 := by decide +kernel

def env4433 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1841,8192,1840,32768,8494,1588,43309,1024,32768,1841,33,40985,41003,8224,40984,2308,1840,1588,2081,1285,261,256,0,42809,41740]

theorem envBound4433 : H12AffineFastState.Bounded env4433 := by
  intro p hp
  have h : env4433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4432_4433 : H12AffineEnvironment.transform 11 1841 env4432 = env4433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env4432 == env4433) = true)

theorem identity4433 : scanCanonicalize (H12AffineFastState.compose env4433 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound4433 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env4434 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1841,2601,1840,32768,2823,1588,33540,1024,32768,1841,33,35376,35330,2569,35377,2308,1840,1588,2081,1285,261,256,0,36112,35109]

theorem envBound4434 : H12AffineFastState.Bounded env4434 := by
  intro p hp
  have h : env4434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4433_4434 : H12AffineEnvironment.transform 12 2601 env4433 = env4434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env4433 == env4434) = true)

theorem identity4434 : scanCanonicalize (H12AffineFastState.compose env4434 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1070) := by decide +kernel

theorem selectedBound4434 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env4435 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1841,2601,1840,1070,2823,1588,1834,1024,1070,1841,33,3614,3628,2569,3615,2308,1840,1588,2081,1285,261,256,0,2366,3339]

theorem envBound4435 : H12AffineFastState.Bounded env4435 := by
  intro p hp
  have h : env4435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4434_4435 : H12AffineEnvironment.transform 14 1070 env4434 = env4435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1070 env4434 == env4435) = true)

theorem identity4435 : scanCanonicalize (H12AffineFastState.compose env4435 (packedSelected [3,5,6,10,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4435 : packedSelected [3,5,6,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4436 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1588,2601,1589,1070,2562,1588,1583,1024,1070,1588,33,3614,3628,2569,3615,2049,1589,1588,2081,1024,0,5,0,2107,3086]

theorem envBound4436 : H12AffineFastState.Bounded env4436 := by
  intro p hp
  have h : env4436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4435_4436 : H12AffineEnvironment.transform 7 5 env4435 = env4436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4435 == env4436) = true)

theorem identity4436 : scanCanonicalize (H12AffineFastState.compose env4436 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound4436 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env4437 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1557,1588,1084,1589,1070,1047,1588,1583,1024,1070,1588,33,11,57,1052,10,1556,1589,1588,1588,1024,0,5,0,1582,539]

theorem envBound4437 : H12AffineFastState.Bounded env4437 := by
  intro p hp
  have h : env4437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4436_4437 : H12AffineEnvironment.transform 10 1557 env4436 = env4437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env4436 == env4437) = true)

theorem identity4437 : scanCanonicalize (H12AffineFastState.compose env4437 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4437 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env4438 : List Nat := [2,4,8,16,32,16,41,5,0,1024,1045,1076,1084,1077,1070,1047,1076,1071,1024,1070,1076,33,11,57,1052,10,1044,1077,1076,1076,1024,0,5,0,1070,27]

theorem envBound4438 : H12AffineFastState.Bounded env4438 := by
  intro p hp
  have h : env4438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4437_4438 : H12AffineEnvironment.transform 8 0 env4437 = env4438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4437 == env4438) = true)

theorem identity4438 : scanCanonicalize (H12AffineFastState.compose env4438 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound4438 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4439 : List Nat := [2,4,8,16,32,16,41,5,0,46,59,26,18,27,0,57,26,1,46,0,26,33,11,57,50,10,58,27,26,26,46,0,5,0,0,27]

theorem envBound4439 : H12AffineFastState.Bounded env4439 := by
  intro p hp
  have h : env4439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4438_4439 : H12AffineEnvironment.transform 9 46 env4438 = env4439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env4438 == env4439) = true)

theorem identity4439 : scanCanonicalize (H12AffineFastState.compose env4439 (packedSelected [10,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4439 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env4440 : List Nat := [2,4,8,10,32,10,41,5,0,46,33,0,8,1,0,35,0,1,46,0,0,33,11,35,40,10,32,1,0,0,46,0,5,0,0,1]

theorem envBound4440 : H12AffineFastState.Bounded env4440 := by
  intro p hp
  have h : env4440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4439_4440 : H12AffineEnvironment.transform 3 10 env4439 = env4440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4439 == env4440) = true)

theorem identity4440 : scanCanonicalize (H12AffineFastState.compose env4440 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4440 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4441 : List Nat := [2,4,6,4,32,4,39,5,0,32,33,0,6,1,0,35,0,1,32,0,0,33,5,35,38,4,32,1,0,0,32,0,5,0,0,1]

end H12CloudChart0