import H12CloudChart0Data140

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env35776 : List Nat := [2,4,8,16,0,17,8,4,11,20,0,16,9,1,1,3,17,0,21,0,0,1,17,2,9,17,0,17,17,0,20,1,5,1,0,11]

theorem envBound35776 : H12AffineFastState.Bounded env35776 := by
  intro p hp
  have h : env35776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35775_35776 : H12AffineEnvironment.transform 4 0 env35775 = env35776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35775 == env35776) = true)

theorem identity35776 : scanCanonicalize (H12AffineFastState.compose env35776 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound35776 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35777 : List Nat := [2,4,8,4,0,5,8,4,11,0,0,4,9,1,1,3,5,0,1,0,0,1,5,2,9,5,0,5,5,0,0,1,5,1,0,11]

theorem envBound35777 : H12AffineFastState.Bounded env35777 := by
  intro p hp
  have h : env35777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35776_35777 : H12AffineEnvironment.transform 3 4 env35776 = env35777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env35776 == env35777) = true)

theorem identity35777 : scanCanonicalize (H12AffineFastState.compose env35777 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound35777 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35778 : List Nat := [2,4,0,4,0,5,0,4,3,0,0,4,1,1,1,3,5,0,1,0,0,1,5,2,1,5,0,5,5,0,0,1,5,1,0,3]

theorem envBound35778 : H12AffineFastState.Bounded env35778 := by
  intro p hp
  have h : env35778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35777_35778 : H12AffineEnvironment.transform 2 0 env35777 = env35778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env35777 == env35778) = true)

def env35779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,329731,17,21763,8193,64,97547,115014,17664,335883,119043,272392,257,98679,90202,63069]

theorem envBound35779 : H12AffineFastState.Bounded env35779 := by
  intro p hp
  have h : env35779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35763_35779 : H12AffineEnvironment.transform 6 9 env35763 = env35779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35763 == env35779) = true)

theorem identity35779 : scanCanonicalize (H12AffineFastState.compose env35779 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35779 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1025,32769,4161,73771,17,21763,8193,64,97547,115014,17664,67619,119043,32,257,98679,90202,63069]

theorem envBound35780 : H12AffineFastState.Bounded env35780 := by
  intro p hp
  have h : env35780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35779_35780 : H12AffineEnvironment.transform 17 10280 env35779 = env35780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35779 == env35780) = true)

theorem identity35780 : scanCanonicalize (H12AffineFastState.compose env35780 (packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound35780 : packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env35781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10280,1025,32769,4161,32801,17,21763,8193,64,56577,24908,17664,43049,28937,32,257,8573,49232,63069]

theorem envBound35781 : H12AffineFastState.Bounded env35781 := by
  intro p hp
  have h : env35781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35780_35781 : H12AffineEnvironment.transform 15 40970 env35780 = env35781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env35780 == env35781) = true)

theorem identity35781 : scanCanonicalize (H12AffineFastState.compose env35781 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound35781 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8202,16400,10280,1025,1,4161,33,17,21763,8193,64,23809,24908,17664,10281,28937,32,257,8573,16464,30301]

theorem envBound35782 : H12AffineFastState.Bounded env35782 := by
  intro p hp
  have h : env35782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35781_35782 : H12AffineEnvironment.transform 14 0 env35781 = env35782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env35781 == env35782) = true)

theorem identity35782 : scanCanonicalize (H12AffineFastState.compose env35782 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound35782 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,0,8202,13341,10280,1025,1,4161,33,17,8462,8193,64,10508,5441,12557,10281,1284,32,257,8573,13405,592]

theorem envBound35783 : H12AffineFastState.Bounded env35783 := by
  intro p hp
  have h : env35783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35782_35783 : H12AffineEnvironment.transform 13 13325 env35782 = env35783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env35782 == env35783) = true)

theorem identity35783 : scanCanonicalize (H12AffineFastState.compose env35783 (packedSelected [0,1,6,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound35783 : packedSelected [0,1,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env35784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,8192,11293,0,8202,11277,10280,1025,1,2129,33,17,8462,8193,64,10508,3409,10525,10281,1284,32,257,8573,11341,592]

theorem envBound35784 : H12AffineFastState.Bounded env35784 := by
  intro p hp
  have h : env35784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35783_35784 : H12AffineEnvironment.transform 11 2064 env35783 = env35784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env35783 == env35784) = true)

theorem identity35784 : scanCanonicalize (H12AffineFastState.compose env35784 (packedSelected [0,3,5,6,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound35784 : packedSelected [0,3,5,6,9,14] rootPS < 2^1333 := by decide +kernel

def env35785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,120,3173,0,114,3189,2128,1025,1,2129,33,17,374,121,64,2420,3409,2405,2129,1284,32,257,261,3125,592]

theorem envBound35785 : H12AffineFastState.Bounded env35785 := by
  intro p hp
  have h : env35785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35784_35785 : H12AffineEnvironment.transform 12 120 env35784 = env35785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env35784 == env35785) = true)

theorem identity35785 : scanCanonicalize (H12AffineFastState.compose env35785 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35785 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35786 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2064,120,3173,0,114,3189,2128,1025,1,2129,33,17,2,121,64,2048,3109,2065,2129,1136,32,117,113,3125,592]

theorem envBound35786 : H12AffineFastState.Bounded env35786 := by
  intro p hp
  have h : env35786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35785_35786 : H12AffineEnvironment.transform 7 116 env35785 = env35786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35785 == env35786) = true)

theorem identity35786 : scanCanonicalize (H12AffineFastState.compose env35786 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35786 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env35787 : List Nat := [2,4,8,16,32,64,9,116,512,1024,0,16,120,1125,0,114,1141,80,1025,1,81,33,17,2,121,64,0,1061,17,81,1136,32,117,113,1077,592]

theorem envBound35787 : H12AffineFastState.Bounded env35787 := by
  intro p hp
  have h : env35787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35786_35787 : H12AffineEnvironment.transform 10 0 env35786 = env35787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35786 == env35787) = true)

theorem identity35787 : scanCanonicalize (H12AffineFastState.compose env35787 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35787 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env35788 : List Nat := [2,4,8,16,32,17,9,37,512,1024,0,16,41,1076,0,35,1060,1,1025,1,0,33,17,2,40,17,0,1061,17,0,1057,32,36,32,1077,513]

theorem envBound35788 : H12AffineFastState.Bounded env35788 := by
  intro p hp
  have h : env35788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35787_35788 : H12AffineEnvironment.transform 5 17 env35787 = env35788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35787 == env35788) = true)

theorem identity35788 : scanCanonicalize (H12AffineFastState.compose env35788 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound35788 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35789 : List Nat := [2,4,8,16,32,17,9,37,512,36,0,16,41,16,0,35,0,1,37,1,0,33,17,2,40,17,0,1,17,0,5,32,36,32,17,513]

theorem envBound35789 : H12AffineFastState.Bounded env35789 := by
  intro p hp
  have h : env35789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35788_35789 : H12AffineEnvironment.transform 9 36 env35788 = env35789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env35788 == env35789) = true)

theorem identity35789 : scanCanonicalize (H12AffineFastState.compose env35789 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35789 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35790 : List Nat := [2,4,8,16,32,17,9,37,16,36,0,16,41,16,0,35,0,1,37,1,0,33,17,2,40,17,0,1,17,0,5,32,36,32,17,17]

theorem envBound35790 : H12AffineFastState.Bounded env35790 := by
  intro p hp
  have h : env35790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35789_35790 : H12AffineEnvironment.transform 8 16 env35789 = env35790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35789 == env35790) = true)

def env35791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,254082,243089,8328,64,97546,2240796,2340306,336002,119042,2373704,257,2199998,2191386,63189]

theorem envBound35791 : H12AffineFastState.Bounded env35791 := by
  intro p hp
  have h : env35791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35752_35791 : H12AffineEnvironment.transform 23 243089 env35752 = env35791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env35752 == env35791) = true)

def env35792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,254082,243089,8328,64,97546,139612,238994,336002,119042,272392,257,98814,90202,63189]

theorem envBound35792 : H12AffineFastState.Bounded env35792 := by
  intro p hp
  have h : env35792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35791_35792 : H12AffineEnvironment.transform 20 4160 env35791 = env35792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35791 == env35792) = true)

theorem identity35792 : scanCanonicalize (H12AffineFastState.compose env35792 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound35792 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,4160,392286,62661,41430,8328,64,97546,79131,45525,336002,119042,272392,257,98814,90202,63189]

theorem envBound35793 : H12AffineFastState.Bounded env35793 := by
  intro p hp
  have h : env35793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35792_35793 : H12AffineEnvironment.transform 16 70727 env35792 = env35793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env35792 == env35793) = true)

theorem identity35793 : scanCanonicalize (H12AffineFastState.compose env35793 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound35793 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env35794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,70727,262144,1025,29909,4160,329866,17,21762,8328,64,97546,79131,17665,336002,75222,272392,257,95530,90202,513]

theorem envBound35794 : H12AffineFastState.Bounded env35794 := by
  intro p hp
  have h : env35794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35793_35794 : H12AffineEnvironment.transform 14 29908 env35793 = env35794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env35793 == env35794) = true)

def env35795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70727,262144,1025,8661,4160,329866,17,2,8328,64,75786,79131,4097,336002,75222,272392,257,73770,79194,513]

theorem envBound35795 : H12AffineFastState.Bounded env35795 := by
  intro p hp
  have h : env35795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35794_35795 : H12AffineEnvironment.transform 13 5376 env35794 = env35795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35794 == env35795) = true)

theorem identity35795 : scanCanonicalize (H12AffineFastState.compose env35795 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35795 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70727,10280,1025,8661,4160,73890,17,2,8328,64,75786,79131,4097,67754,75222,32,257,73770,79194,513]

theorem envBound35796 : H12AffineFastState.Bounded env35796 := by
  intro p hp
  have h : env35796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35795_35796 : H12AffineEnvironment.transform 17 10280 env35795 = env35796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35795 == env35796) = true)

theorem identity35796 : scanCanonicalize (H12AffineFastState.compose env35796 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35796 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env35797 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,70727,10280,1025,8540,4160,73771,17,2,8193,64,75786,79131,4097,67619,75103,32,257,73770,79194,513]

theorem envBound35797 : H12AffineFastState.Bounded env35797 := by
  intro p hp
  have h : env35797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35796_35797 : H12AffineEnvironment.transform 6 9 env35796 = env35797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35796 == env35797) = true)

theorem identity35797 : scanCanonicalize (H12AffineFastState.compose env35797 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35797 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35798 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,65536,70727,2421,1025,1,4160,65910,17,2,348,64,67927,70726,4097,67619,66562,32,257,65911,70663,513]

theorem envBound35798 : H12AffineFastState.Bounded env35798 := by
  intro p hp
  have h : env35798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35797_35798 : H12AffineEnvironment.transform 12 349 env35797 = env35798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35797 == env35798) = true)

theorem identity35798 : scanCanonicalize (H12AffineFastState.compose env35798 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35798 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env35799 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,0,65536,70679,2341,1025,1,4112,65830,17,2,268,16,67847,70678,4097,67619,66562,32,257,65831,70663,513]

theorem envBound35799 : H12AffineFastState.Bounded env35799 := by
  intro p hp
  have h : env35799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35798_35799 : H12AffineEnvironment.transform 5 16 env35798 = env35799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35798 == env35799) = true)

def env35800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70727,262144,1025,8660,4160,329866,17,3,8328,64,75787,79131,4096,336002,75222,272392,257,73771,79195,513]

theorem envBound35800 : H12AffineFastState.Bounded env35800 := by
  intro p hp
  have h : env35800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35794_35800 : H12AffineEnvironment.transform 13 5377 env35794 = env35800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35794 == env35800) = true)

theorem identity35800 : scanCanonicalize (H12AffineFastState.compose env35800 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound35800 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70727,10401,1025,8660,4160,73771,17,3,8328,64,75787,79131,4096,67619,75222,169,257,73771,79195,513]

theorem envBound35801 : H12AffineFastState.Bounded env35801 := by
  intro p hp
  have h : env35801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35800_35801 : H12AffineEnvironment.transform 17 10401 env35800 = env35801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35800 == env35801) = true)

theorem identity35801 : scanCanonicalize (H12AffineFastState.compose env35801 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35801 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env35802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5377,216,65536,70727,2476,1025,217,4160,65830,17,3,389,64,67846,70678,4096,67619,66779,169,257,65830,70742,513]

theorem envBound35802 : H12AffineFastState.Bounded env35802 := by
  intro p hp
  have h : env35802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35801_35802 : H12AffineEnvironment.transform 12 269 env35801 = env35802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35801 == env35802) = true)

theorem identity35802 : scanCanonicalize (H12AffineFastState.compose env35802 (packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound35802 : packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS < 2^1333 := by decide +kernel

def env35803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5377,216,342,5393,2476,1025,217,4160,112,17,3,389,64,2128,5440,4096,2421,1421,169,257,112,5376,513]

theorem envBound35803 : H12AffineFastState.Bounded env35803 := by
  intro p hp
  have h : env35803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35802_35803 : H12AffineEnvironment.transform 15 342 env35802 = env35803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env35802 == env35803) = true)

theorem identity35803 : scanCanonicalize (H12AffineFastState.compose env35803 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35803 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35804 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,137,263,5393,2476,1025,136,4113,33,17,3,389,17,2049,5393,4096,2340,1421,169,257,33,5376,513]

theorem envBound35804 : H12AffineFastState.Bounded env35804 := by
  intro p hp
  have h : env35804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35803_35804 : H12AffineEnvironment.transform 5 17 env35803 = env35804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35803 == env35804) = true)

theorem identity35804 : scanCanonicalize (H12AffineFastState.compose env35804 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound35804 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env35805 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3464,269,2185,137,263,2201,2476,1025,136,3481,33,17,3,389,17,2049,2201,3464,2340,1421,169,257,33,2184,513]

theorem envBound35805 : H12AffineFastState.Bounded env35805 := by
  intro p hp
  have h : env35805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35804_35805 : H12AffineEnvironment.transform 11 3464 env35804 = env35805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env35804 == env35805) = true)

theorem identity35805 : scanCanonicalize (H12AffineFastState.compose env35805 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 957) := by decide +kernel

theorem selectedBound35805 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env35806 : List Nat := [2,4,8,16,32,17,128,256,512,1024,957,1589,269,820,137,263,804,529,1025,136,1572,33,17,3,389,17,956,804,1589,665,1421,169,257,33,821,513]

theorem envBound35806 : H12AffineFastState.Bounded env35806 := by
  intro p hp
  have h : env35806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35805_35806 : H12AffineEnvironment.transform 10 957 env35805 = env35806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 957 env35805 == env35806) = true)

theorem identity35806 : scanCanonicalize (H12AffineFastState.compose env35806 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound35806 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env35807 : List Nat := [2,4,8,16,32,17,128,256,137,1024,308,1212,269,445,137,263,429,152,1025,136,1197,33,17,3,389,17,309,429,1212,16,1421,169,257,33,444,136]

theorem envBound35807 : H12AffineFastState.Bounded env35807 := by
  intro p hp
  have h : env35807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35806_35807 : H12AffineEnvironment.transform 8 137 env35806 = env35807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env35806 == env35807) = true)

theorem identity35807 : scanCanonicalize (H12AffineFastState.compose env35807 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35807 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env35808 : List Nat := [2,4,8,16,32,17,128,256,137,272,308,428,269,445,137,263,429,152,273,136,445,33,17,3,389,17,309,429,428,16,157,169,257,33,444,136]

theorem envBound35808 : H12AffineFastState.Bounded env35808 := by
  intro p hp
  have h : env35808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35807_35808 : H12AffineEnvironment.transform 9 272 env35807 = env35808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35807 == env35808) = true)

theorem identity35808 : scanCanonicalize (H12AffineFastState.compose env35808 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35808 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35809 : List Nat := [2,4,8,16,32,17,9,256,0,272,308,293,269,308,0,263,292,17,273,1,308,33,17,3,268,17,309,292,293,16,20,32,257,33,309,1]

theorem envBound35809 : H12AffineFastState.Bounded env35809 := by
  intro p hp
  have h : env35809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35808_35809 : H12AffineEnvironment.transform 6 9 env35808 = env35809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35808 == env35809) = true)

theorem identity35809 : scanCanonicalize (H12AffineFastState.compose env35809 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound35809 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35810 : List Nat := [2,4,8,16,32,17,9,14,0,30,58,43,3,58,0,9,42,17,31,1,58,33,17,3,2,17,59,42,43,16,20,32,15,33,59,1]

theorem envBound35810 : H12AffineFastState.Bounded env35810 := by
  intro p hp
  have h : env35810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35809_35810 : H12AffineEnvironment.transform 7 14 env35809 = env35810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env35809 == env35810) = true)

theorem identity35810 : scanCanonicalize (H12AffineFastState.compose env35810 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35810 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35811 : List Nat := [2,4,8,16,11,17,9,14,0,30,17,0,3,17,0,9,1,17,31,1,17,10,17,3,2,17,16,1,0,16,20,11,15,10,16,1]

theorem envBound35811 : H12AffineFastState.Bounded env35811 := by
  intro p hp
  have h : env35811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35810_35811 : H12AffineEnvironment.transform 4 11 env35810 = env35811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35810 == env35811) = true)

theorem identity35811 : scanCanonicalize (H12AffineFastState.compose env35811 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35812 : List Nat := [2,4,8,1,11,0,9,14,0,15,0,0,3,0,0,9,1,0,14,1,0,10,0,3,2,0,1,1,0,1,5,11,15,10,1,1]

theorem envBound35812 : H12AffineFastState.Bounded env35812 := by
  intro p hp
  have h : env35812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35811_35812 : H12AffineEnvironment.transform 3 1 env35811 = env35812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35811 == env35812) = true)

def env35813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,254082,243089,8328,64,97546,139613,238995,336002,119042,272393,257,98815,90203,63189]

theorem envBound35813 : H12AffineFastState.Bounded env35813 := by
  intro p hp
  have h : env35813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35791_35813 : H12AffineEnvironment.transform 20 4161 env35791 = env35813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env35791 == env35813) = true)

theorem identity35813 : scanCanonicalize (H12AffineFastState.compose env35813 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound35813 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,452633,144477,155982,8328,64,43477,139613,160076,324701,1501,272393,257,21792,46212,63189]

theorem envBound35814 : H12AffineFastState.Bounded env35814 := by
  intro p hp
  have h : env35814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35813_35814 : H12AffineEnvironment.transform 15 54495 env35813 = env35814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env35813 == env35814) = true)

def env35815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146912,1025,32769,4161,54777,144477,155982,8328,64,43477,139613,160076,182717,1501,136681,257,21792,46212,63189]

theorem envBound35815 : H12AffineFastState.Bounded env35815 := by
  intro p hp
  have h : env35815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35814_35815 : H12AffineEnvironment.transform 17 146912 env35814 = env35815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env35814 == env35815) = true)

theorem identity35815 : scanCanonicalize (H12AffineFastState.compose env35815 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound35815 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env35816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,5393,10481,1025,32769,4161,54777,8524,29791,8328,64,43477,13388,25693,56492,1501,248,257,21792,46212,63189]

theorem envBound35816 : H12AffineFastState.Bounded env35816 := by
  intro p hp
  have h : env35816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35815_35816 : H12AffineEnvironment.transform 16 5393 env35815 = env35816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env35815 == env35816) = true)

theorem identity35816 : scanCanonicalize (H12AffineFastState.compose env35816 (packedSelected [3,4,7,9,11,14,16,18,19,20,23,24,27,31,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound35816 : packedSelected [3,4,7,9,11,14,16,18,19,20,23,24,27,31,32,35] rootPS < 2^1333 := by decide +kernel

def env35817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33111,5393,10481,1025,32769,4161,32881,8524,8663,8328,64,43477,13388,12757,35108,1501,248,257,168,46212,41821]

theorem envBound35817 : H12AffineFastState.Bounded env35817 := by
  intro p hp
  have h : env35817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35816_35817 : H12AffineEnvironment.transform 13 5512 env35816 = env35817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env35816 == env35817) = true)

theorem identity35817 : scanCanonicalize (H12AffineFastState.compose env35817 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound35817 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env35818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,81,262,5393,10481,1025,80,4161,32,8524,8663,8328,64,10628,13388,12757,2421,1501,248,257,168,13525,8972]

theorem envBound35818 : H12AffineFastState.Bounded env35818 := by
  intro p hp
  have h : env35818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35817_35818 : H12AffineEnvironment.transform 14 81 env35817 = env35818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env35817 == env35818) = true)

theorem identity35818 : scanCanonicalize (H12AffineFastState.compose env35818 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35818 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,81,262,5393,2556,1025,80,4161,32,65,218,389,64,2185,5441,4312,2421,1501,248,257,168,5592,513]

theorem envBound35819 : H12AffineFastState.Bounded env35819 := by
  intro p hp
  have h : env35819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35818_35819 : H12AffineEnvironment.transform 12 269 env35818 = env35819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35818 == env35819) = true)

theorem identity35819 : scanCanonicalize (H12AffineFastState.compose env35819 (packedSelected [3,4,5,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 201) := by decide +kernel

theorem selectedBound35819 : packedSelected [3,4,5,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,201,269,1345,81,262,1496,2556,1025,80,136,32,65,218,389,64,2185,1416,17,2421,1501,248,257,168,1297,513]

theorem envBound35820 : H12AffineFastState.Bounded env35820 := by
  intro p hp
  have h : env35820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35819_35820 : H12AffineEnvironment.transform 11 201 env35819 = env35820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 201 env35819 == env35820) = true)

def env35821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146913,1025,32769,4161,54776,144477,155982,8328,64,43477,139613,160076,182716,1501,136680,257,21792,46212,63189]

theorem envBound35821 : H12AffineFastState.Bounded env35821 := by
  intro p hp
  have h : env35821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35814_35821 : H12AffineEnvironment.transform 17 146913 env35814 = env35821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env35814 == env35821) = true)

theorem identity35821 : scanCanonicalize (H12AffineFastState.compose env35821 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound35821 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env35822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,5528,10361,1025,32769,4161,54776,8645,29910,8328,64,43477,13509,25812,56356,1501,112,257,21792,46212,63189]

theorem envBound35822 : H12AffineFastState.Bounded env35822 := by
  intro p hp
  have h : env35822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35821_35822 : H12AffineEnvironment.transform 16 5528 env35821 = env35822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env35821 == env35822) = true)

theorem identity35822 : scanCanonicalize (H12AffineFastState.compose env35822 (packedSelected [1,4,5,7,8,9,16,17,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound35822 : packedSelected [1,4,5,7,8,9,16,17,20,24,27] rootPS < 2^1333 := by decide +kernel

def env35823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8403,5528,10361,1025,29709,4161,8692,8645,29910,8328,64,24025,13509,25812,10280,1501,112,257,21792,16520,729]

theorem envBound35823 : H12AffineFastState.Bounded env35823 := by
  intro p hp
  have h : env35823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35822_35823 : H12AffineEnvironment.transform 14 29708 env35822 = env35823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env35822 == env35823) = true)

theorem identity35823 : scanCanonicalize (H12AffineFastState.compose env35823 (packedSelected [0,3,4,5,7,9,11,15,16,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35823 : packedSelected [0,3,4,5,7,9,11,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env35824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,8282,5393,10361,1025,29709,4161,8573,8524,29791,8193,64,23888,13388,25693,10280,1364,112,257,21792,16385,592]

theorem envBound35824 : H12AffineFastState.Bounded env35824 := by
  intro p hp
  have h : env35824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35823_35824 : H12AffineEnvironment.transform 6 9 env35823 = env35824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35823 == env35824) = true)

theorem identity35824 : scanCanonicalize (H12AffineFastState.compose env35824 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35824 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21841,263,5393,2340,1025,21840,4161,32,17,21762,348,64,23888,5393,17664,2421,1364,112,257,21792,16385,592]

theorem envBound35825 : H12AffineFastState.Bounded env35825 := by
  intro p hp
  have h : env35825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35824_35825 : H12AffineEnvironment.transform 12 349 env35824 = env35825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35824 == env35825) = true)

theorem identity35825 : scanCanonicalize (H12AffineFastState.compose env35825 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35825 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35826 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,263,5393,2340,1025,21761,4112,32,17,21762,269,17,23809,5393,17664,2340,1285,33,257,21792,16385,513]

theorem envBound35826 : H12AffineFastState.Bounded env35826 := by
  intro p hp
  have h : env35826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35825_35826 : H12AffineEnvironment.transform 5 17 env35825 = env35826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35825 == env35826) = true)

theorem identity35826 : scanCanonicalize (H12AffineFastState.compose env35826 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35826 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35827 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,5393,2340,1025,1,4112,32,17,2,269,17,2049,5393,4096,2340,1285,33,257,32,5377,513]

theorem envBound35827 : H12AffineFastState.Bounded env35827 := by
  intro p hp
  have h : env35827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35826_35827 : H12AffineEnvironment.transform 13 5376 env35826 = env35827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35826 == env35827) = true)

theorem identity35827 : scanCanonicalize (H12AffineFastState.compose env35827 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound35827 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35828 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,309,268,1077,0,263,1060,2340,1025,1,293,32,17,2,269,17,2049,1060,309,2340,1285,33,257,32,1076,513]

theorem envBound35828 : H12AffineFastState.Bounded env35828 := by
  intro p hp
  have h : env35828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35827_35828 : H12AffineEnvironment.transform 11 309 env35827 = env35828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env35827 == env35828) = true)

theorem identity35828 : scanCanonicalize (H12AffineFastState.compose env35828 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35828 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35829 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,309,268,292,0,263,309,2340,272,1,293,32,17,2,269,17,2049,309,309,2340,20,33,257,32,293,513]

theorem envBound35829 : H12AffineFastState.Bounded env35829 := by
  intro p hp
  have h : env35829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35828_35829 : H12AffineEnvironment.transform 9 273 env35828 = env35829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35828 == env35829) = true)

theorem identity35829 : scanCanonicalize (H12AffineFastState.compose env35829 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35829 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35830 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,16,41,1,0,34,16,2049,53,1,0,32,17,2,40,17,2049,16,16,2049,20,33,36,32,0,513]

theorem envBound35830 : H12AffineFastState.Bounded env35830 := by
  intro p hp
  have h : env35830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35829_35830 : H12AffineEnvironment.transform 7 37 env35829 = env35830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35829 == env35830) = true)

theorem identity35830 : scanCanonicalize (H12AffineFastState.compose env35830 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound35830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35831 : List Nat := [2,4,8,16,32,17,9,37,49,52,2048,16,41,1,0,34,16,2049,53,1,0,32,17,2,40,17,2049,16,16,2049,20,33,36,32,0,48]

theorem envBound35831 : H12AffineFastState.Bounded env35831 := by
  intro p hp
  have h : env35831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35830_35831 : H12AffineEnvironment.transform 8 49 env35830 = env35831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env35830 == env35831) = true)

theorem identity35831 : scanCanonicalize (H12AffineFastState.compose env35831 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound35831 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35832 : List Nat := [2,4,8,16,32,17,9,37,49,52,49,16,41,1,0,34,16,48,53,1,0,32,17,2,40,17,48,16,16,48,20,33,36,32,0,48]

theorem envBound35832 : H12AffineFastState.Bounded env35832 := by
  intro p hp
  have h : env35832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35831_35832 : H12AffineEnvironment.transform 10 49 env35831 = env35832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env35831 == env35832) = true)

def env35833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254784,25265168,145662401,525568,140903597,27337993,25733063]

theorem envBound35833 : H12AffineFastState.Bounded env35833 := by
  intro p hp
  have h : env35833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34952_35833 : H12AffineEnvironment.transform 25 65 env34952 = env35833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env34952 == env35833) = true)

def env35834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356288,25265168,23160257,525568,27902125,27337993,25733063]

theorem envBound35834 : H12AffineFastState.Bounded env35834 := by
  intro p hp
  have h : env35834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35833_35834 : H12AffineEnvironment.transform 26 30393344 env35833 = env35834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env35833 == env35834) = true)

def env35835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265168,23160257,256,27378861,27337993,25207751]

theorem envBound35835 : H12AffineFastState.Bounded env35835 := by
  intro p hp
  have h : env35835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35834_35835 : H12AffineEnvironment.transform 18 1024 env35834 = env35835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env35834 == env35835) = true)

theorem identity35835 : scanCanonicalize (H12AffineFastState.compose env35835 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10923491) := by decide +kernel

theorem selectedBound35835 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10923491,8328,65,6385123,8857967,10507601,8830976,2566643,13092898,256,485710,493802,2493988]

theorem envBound35836 : H12AffineFastState.Bounded env35836 := by
  intro p hp
  have h : env35836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35835_35836 : H12AffineEnvironment.transform 23 10923491 env35835 = env35836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10923491 env35835 == env35836) = true)

def env35837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452768,2114883,8328,65,6385123,115151,2538993,10400,2566643,4268162,256,485710,493802,2493988]

theorem envBound35837 : H12AffineFastState.Bounded env35837 := by
  intro p hp
  have h : env35837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35836_35837 : H12AffineEnvironment.transform 22 452768 env35836 = env35837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env35836 == env35837) = true)

def env35838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452768,441779,8328,65,4691219,115151,17665,10400,119043,4268162,256,485710,493802,63188]

theorem envBound35838 : H12AffineFastState.Bounded env35838 := by
  intro p hp
  have h : env35838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35837_35838 : H12AffineEnvironment.transform 20 456944 env35837 = env35838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env35837 == env35838) = true)

def env35839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452768,441779,8328,65,245139,115151,17665,10400,119043,329730,256,485710,493802,63188]

theorem envBound35839 : H12AffineFastState.Bounded env35839 := by
  intro p hp
  have h : env35839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35838_35839 : H12AffineEnvironment.transform 21 272512 env35838 = env35839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35838 == env35839) = true)

theorem identity35839 : scanCanonicalize (H12AffineFastState.compose env35839 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound35839 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396325,272512,400501,412006,8328,65,215366,79130,17665,10400,75222,329730,256,485710,490559,513]

theorem envBound35840 : H12AffineFastState.Bounded env35840 := by
  intro p hp
  have h : env35840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35839_35840 : H12AffineEnvironment.transform 14 29909 env35839 = env35840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env35839 == env35840) = true)

def env35841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,396325,272392,400501,412006,8192,65,215366,79130,17665,10280,75102,329730,256,485710,490559,513]

theorem envBound35841 : H12AffineFastState.Bounded env35841 := by
  intro p hp
  have h : env35841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35840_35841 : H12AffineEnvironment.transform 6 8 env35840 = env35841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35840 == env35841) = true)

theorem identity35841 : scanCanonicalize (H12AffineFastState.compose env35841 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound35841 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1024,29788,355390,272392,359534,338301,8192,65,10589,79130,17665,10280,75102,329730,256,264533,269348,513]

theorem envBound35842 : H12AffineFastState.Bounded env35842 := by
  intro p hp
  have h : env35842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35841_35842 : H12AffineEnvironment.transform 16 90139 env35841 = env35842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env35841 == env35842) = true)

theorem identity35842 : scanCanonicalize (H12AffineFastState.compose env35842 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound35842 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,97327,1024,29788,4113,87079,65,21842,8192,65,10589,79130,17665,10280,75102,29741,256,95610,90123,513]

theorem envBound35843 : H12AffineFastState.Bounded env35843 := by
  intro p hp
  have h : env35843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35842_35843 : H12AffineEnvironment.transform 17 97327 env35842 = env35843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env35842 == env35843) = true)

theorem identity35843 : scanCanonicalize (H12AffineFastState.compose env35843 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound35843 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env35844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,65536,70726,67698,1024,1,4113,73850,65,8463,8192,65,10589,79130,12636,10280,75102,112,256,65831,70742,513]

theorem envBound35844 : H12AffineFastState.Bounded env35844 := by
  intro p hp
  have h : env35844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35843_35844 : H12AffineEnvironment.transform 13 13405 env35843 = env35844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env35843 == env35844) = true)

theorem identity35844 : scanCanonicalize (H12AffineFastState.compose env35844 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35844 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env35845 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,65536,70678,67618,1024,1,4113,73770,17,8463,8192,17,10509,79130,12556,10280,75022,32,256,65831,70662,513]

theorem envBound35845 : H12AffineFastState.Bounded env35845 := by
  intro p hp
  have h : env35845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35844_35845 : H12AffineEnvironment.transform 5 16 env35844 = env35845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35844 == env35845) = true)

theorem identity35845 : scanCanonicalize (H12AffineFastState.compose env35845 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35845 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35846 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,65536,70678,67618,1024,1,4113,65831,17,2,269,17,2048,70679,4097,2341,66563,32,256,65831,70662,513]

theorem envBound35846 : H12AffineFastState.Bounded env35846 := by
  intro p hp
  have h : env35846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35845_35846 : H12AffineEnvironment.transform 12 269 env35845 = env35846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35845 == env35846) = true)

theorem identity35846 : scanCanonicalize (H12AffineFastState.compose env35846 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 7175) := by decide +kernel

theorem selectedBound35846 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env35847 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,7175,2065,5157,1024,1,4113,7456,17,2,269,17,2048,2064,4097,2341,6148,32,256,7456,2049,513]

theorem envBound35847 : H12AffineFastState.Bounded env35847 := by
  intro p hp
  have h : env35847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35846_35847 : H12AffineEnvironment.transform 15 7175 env35846 = env35847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7175 env35846 == env35847) = true)

theorem identity35847 : scanCanonicalize (H12AffineFastState.compose env35847 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35847 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env35848 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4112,0,6423,2065,4405,272,1,4113,6192,17,2,269,17,2048,2064,4097,2341,6148,32,256,6192,2049,513]

theorem envBound35848 : H12AffineFastState.Bounded env35848 := by
  intro p hp
  have h : env35848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35847_35848 : H12AffineEnvironment.transform 9 272 env35847 = env35848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35847 == env35848) = true)

theorem identity35848 : scanCanonicalize (H12AffineFastState.compose env35848 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound35848 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35849 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2065,269,2049,0,262,2065,2340,272,1,2048,33,17,2,269,17,2048,2064,2064,2341,21,32,256,33,2049,513]

theorem envBound35849 : H12AffineFastState.Bounded env35849 := by
  intro p hp
  have h : env35849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35848_35849 : H12AffineEnvironment.transform 11 2065 env35848 = env35849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env35848 == env35849) = true)

theorem identity35849 : scanCanonicalize (H12AffineFastState.compose env35849 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35850 : List Nat := [2,4,8,16,17,16,8,256,512,272,2048,2065,269,2049,0,262,2065,2325,272,1,2048,16,17,2,269,17,2048,2064,2064,2324,21,17,256,16,2049,513]

theorem envBound35850 : H12AffineFastState.Bounded env35850 := by
  intro p hp
  have h : env35850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35849_35850 : H12AffineEnvironment.transform 4 17 env35849 = env35850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35849 == env35850) = true)

theorem identity35850 : scanCanonicalize (H12AffineFastState.compose env35850 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound35850 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35851 : List Nat := [2,4,8,16,17,16,8,256,512,272,789,772,269,788,0,262,772,512,272,1,789,16,17,2,269,17,789,773,773,513,21,17,256,16,788,513]

theorem envBound35851 : H12AffineFastState.Bounded env35851 := by
  intro p hp
  have h : env35851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35850_35851 : H12AffineEnvironment.transform 10 789 env35850 = env35851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env35850 == env35851) = true)

theorem identity35851 : scanCanonicalize (H12AffineFastState.compose env35851 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound35851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35852 : List Nat := [2,4,8,16,17,16,8,256,276,272,1,16,269,0,0,262,16,276,272,1,1,16,17,2,269,17,1,17,17,277,21,17,256,16,0,277]

theorem envBound35852 : H12AffineFastState.Bounded env35852 := by
  intro p hp
  have h : env35852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35851_35852 : H12AffineEnvironment.transform 8 276 env35851 = env35852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env35851 == env35852) = true)

theorem identity35852 : scanCanonicalize (H12AffineFastState.compose env35852 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound35852 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35853 : List Nat := [2,4,8,16,17,16,8,5,17,21,1,16,8,0,0,3,16,17,21,1,1,16,17,2,8,17,1,17,17,16,21,17,5,16,0,16]

theorem envBound35853 : H12AffineFastState.Bounded env35853 := by
  intro p hp
  have h : env35853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35852_35853 : H12AffineEnvironment.transform 7 5 env35852 = env35853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env35852 == env35853) = true)

theorem identity35853 : scanCanonicalize (H12AffineFastState.compose env35853 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35854 : List Nat := [2,4,8,10,11,10,8,5,11,15,1,10,8,0,0,3,10,11,15,1,1,10,11,2,8,11,1,11,11,10,15,11,5,10,0,10]

theorem envBound35854 : H12AffineFastState.Bounded env35854 := by
  intro p hp
  have h : env35854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35853_35854 : H12AffineEnvironment.transform 3 10 env35853 = env35854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35853 == env35854) = true)

def env35855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,396325,272393,400501,412006,8193,65,215366,79130,17665,10281,75103,329730,256,485710,490559,513]

theorem envBound35855 : H12AffineFastState.Bounded env35855 := by
  intro p hp
  have h : env35855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35840_35855 : H12AffineEnvironment.transform 6 9 env35840 = env35855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35840 == env35855) = true)

theorem identity35855 : scanCanonicalize (H12AffineFastState.compose env35855 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35855 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1024,29789,140301,33,144477,155982,8193,65,215366,79130,17665,10281,75103,73770,256,213350,218135,513]

theorem envBound35856 : H12AffineFastState.Bounded env35856 := by
  intro p hp
  have h : env35856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35855_35856 : H12AffineEnvironment.transform 17 10280 env35855 = env35856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35855 == env35856) = true)

theorem identity35856 : scanCanonicalize (H12AffineFastState.compose env35856 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound35856 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env35857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,5393,10280,1024,29789,12572,33,8524,29791,8193,65,89175,79130,17665,10281,75103,73770,256,87159,82182,513]

theorem envBound35857 : H12AffineFastState.Bounded env35857 := by
  intro p hp
  have h : env35857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35856_35857 : H12AffineEnvironment.transform 16 5393 env35856 = env35857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env35856 == env35857) = true)

theorem identity35857 : scanCanonicalize (H12AffineFastState.compose env35857 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35857 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env35858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,65536,5393,2341,1024,21840,4113,33,65,21842,268,65,89175,70679,17665,2340,66642,65831,256,87159,82182,513]

theorem envBound35858 : H12AffineFastState.Bounded env35858 := by
  intro p hp
  have h : env35858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35857_35858 : H12AffineEnvironment.transform 12 269 env35857 = env35858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35857 == env35858) = true)

theorem identity35858 : scanCanonicalize (H12AffineFastState.compose env35858 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound35858 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env35859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,21591,5393,2341,1024,21840,4113,33,65,21842,268,65,2048,16448,17665,2340,20485,21872,256,32,5457,513]

theorem envBound35859 : H12AffineFastState.Bounded env35859 := by
  intro p hp
  have h : env35859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35858_35859 : H12AffineEnvironment.transform 15 21591 env35858 = env35859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env35858 == env35859) = true)

def env35860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452768,441779,8328,65,245138,115151,17665,10400,119043,329731,256,485710,493802,63188]

theorem envBound35860 : H12AffineFastState.Bounded env35860 := by
  intro p hp
  have h : env35860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35838_35860 : H12AffineEnvironment.transform 21 272513 env35838 = env35860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35838 == env35860) = true)

theorem identity35860 : scanCanonicalize (H12AffineFastState.compose env35860 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound35860 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58517,144612,62661,41430,8328,65,245138,115151,17665,10400,119043,201830,256,95531,103567,63188]

theorem envBound35861 : H12AffineFastState.Bounded env35861 := by
  intro p hp
  have h : env35861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35860_35861 : H12AffineEnvironment.transform 17 138341 env35860 = env35861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env35860 == env35861) = true)

def env35862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58397,144492,62541,41310,8192,65,245018,115015,17665,10280,119043,201830,256,95531,103431,63068]

theorem envBound35862 : H12AffineFastState.Bounded env35862 := by
  intro p hp
  have h : env35862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35861_35862 : H12AffineEnvironment.transform 6 8 env35861 = env35862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35861 == env35862) = true)

theorem identity35862 : scanCanonicalize (H12AffineFastState.compose env35862 (packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound35862 : packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env35863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,114,131072,138341,1024,32769,58397,144492,62541,41310,8192,65,179560,49461,17665,10280,53617,136212,256,30041,38005,63068]

theorem envBound35863 : H12AffineFastState.Bounded env35863 := by
  intro p hp
  have h : env35863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35862_35863 : H12AffineEnvironment.transform 15 114 env35862 = env35863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env35862 == env35863) = true)

theorem identity35863 : scanCanonicalize (H12AffineFastState.compose env35863 (packedSelected [1,3,4,9,10,18,19,20,23,24,26,28,31,35] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35863 : packedSelected [1,3,4,9,10,18,19,20,23,24,26,28,31,35] rootPS < 2^1333 := by decide +kernel

def env35864 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,35,131072,138292,1024,32769,58397,144445,62492,41231,8192,16,179513,49461,17665,10280,53536,136212,256,29960,37924,62989]

theorem envBound35864 : H12AffineFastState.Bounded env35864 := by
  intro p hp
  have h : env35864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35863_35864 : H12AffineEnvironment.transform 5 17 env35863 = env35864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35863 == env35864) = true)

theorem identity35864 : scanCanonicalize (H12AffineFastState.compose env35864 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35864 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env35865 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,35,131072,138292,1024,32769,58397,144445,62492,41002,8192,16,179228,49168,17444,10280,53253,136212,37,29741,37924,62989]

theorem envBound35865 : H12AffineFastState.Bounded env35865 := by
  intro p hp
  have h : env35865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35864_35865 : H12AffineEnvironment.transform 7 37 env35864 = env35865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35864 == env35865) = true)

theorem identity35865 : scanCanonicalize (H12AffineFastState.compose env35865 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound35865 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env35866 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,35,24632,31756,1024,32769,58397,21509,62492,41002,8192,16,56356,49168,17444,10280,53253,29740,37,29741,37924,62989]

theorem envBound35866 : H12AffineFastState.Bounded env35866 := by
  intro p hp
  have h : env35866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35865_35866 : H12AffineEnvironment.transform 16 24632 env35865 = env35866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env35865 == env35866) = true)

theorem identity35866 : scanCanonicalize (H12AffineFastState.compose env35866 (packedSelected [0,4,7,9,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound35866 : packedSelected [0,4,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env35867 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,8233,35,24632,31756,1024,8232,17460,21509,21557,3,8192,16,31757,24633,17444,10280,28716,29740,37,29741,13325,22052]

theorem envBound35867 : H12AffineFastState.Bounded env35867 := by
  intro p hp
  have h : env35867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35866_35867 : H12AffineEnvironment.transform 14 8233 env35866 = env35867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env35866 == env35867) = true)

theorem identity35867 : scanCanonicalize (H12AffineFastState.compose env35867 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound35867 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35868 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,13325,8233,35,5173,2049,1024,8232,12345,8200,8248,3,8192,16,2048,5172,12329,10280,1057,33,37,32,13325,8745]

theorem envBound35868 : H12AffineFastState.Bounded env35868 := by
  intro p hp
  have h : env35868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35867_35868 : H12AffineEnvironment.transform 13 13325 env35867 = env35868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env35867 == env35868) = true)

theorem identity35868 : scanCanonicalize (H12AffineFastState.compose env35868 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound35868 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env35869 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2065,8192,11292,8233,35,3108,2049,1024,8232,10280,8200,8248,3,8192,16,2048,3109,10296,10280,1057,33,37,32,11292,8745]

theorem envBound35869 : H12AffineFastState.Bounded env35869 := by
  intro p hp
  have h : env35869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35868_35869 : H12AffineEnvironment.transform 11 2065 env35868 = env35869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env35868 == env35869) = true)

theorem identity35869 : scanCanonicalize (H12AffineFastState.compose env35869 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35869 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35870 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2065,41,3125,0,35,3108,2049,1024,1,2049,33,17,3,41,16,2048,3109,2065,2049,1057,33,37,32,3125,512]

theorem envBound35870 : H12AffineFastState.Bounded env35870 := by
  intro p hp
  have h : env35870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35869_35870 : H12AffineEnvironment.transform 12 41 env35869 = env35870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35869 == env35870) = true)

theorem identity35870 : scanCanonicalize (H12AffineFastState.compose env35870 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound35870 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35871 : List Nat := [2,4,8,16,32,17,8,37,512,1024,16,1,41,1061,0,35,1076,17,1024,1,17,33,17,3,41,16,16,1077,1,17,1057,33,37,32,1061,512]

theorem envBound35871 : H12AffineFastState.Bounded env35871 := by
  intro p hp
  have h : env35871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35870_35871 : H12AffineEnvironment.transform 10 16 env35870 = env35871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env35870 == env35871) = true)

theorem identity35871 : scanCanonicalize (H12AffineFastState.compose env35871 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound35871 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35872 : List Nat := [2,4,8,16,32,17,8,37,512,14,16,1,41,43,0,35,58,17,14,1,17,33,17,3,41,16,16,59,1,17,47,33,37,32,43,512]

theorem envBound35872 : H12AffineFastState.Bounded env35872 := by
  intro p hp
  have h : env35872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35871_35872 : H12AffineEnvironment.transform 9 14 env35871 = env35872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env35871 == env35872) = true)

theorem identity35872 : scanCanonicalize (H12AffineFastState.compose env35872 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound35872 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35873 : List Nat := [2,4,8,16,32,17,8,37,58,14,16,1,41,43,0,35,58,17,14,1,17,33,17,3,41,16,16,59,1,17,47,33,37,32,43,58]

theorem envBound35873 : H12AffineFastState.Bounded env35873 := by
  intro p hp
  have h : env35873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35872_35873 : H12AffineEnvironment.transform 8 58 env35872 = env35873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env35872 == env35873) = true)

theorem identity35873 : scanCanonicalize (H12AffineFastState.compose env35873 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35873 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35874 : List Nat := [2,4,8,16,0,17,8,5,26,14,16,1,9,11,0,3,26,17,14,1,17,1,17,3,9,16,16,27,1,17,15,1,5,0,11,26]

theorem envBound35874 : H12AffineFastState.Bounded env35874 := by
  intro p hp
  have h : env35874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35873_35874 : H12AffineEnvironment.transform 4 0 env35873 = env35874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35873 == env35874) = true)

theorem identity35874 : scanCanonicalize (H12AffineFastState.compose env35874 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound35874 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35875 : List Nat := [2,4,8,2,0,3,8,5,8,14,2,1,9,11,0,3,8,3,14,1,3,1,3,3,9,2,2,9,1,3,15,1,5,0,11,8]

theorem envBound35875 : H12AffineFastState.Bounded env35875 := by
  intro p hp
  have h : env35875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35874_35875 : H12AffineEnvironment.transform 3 2 env35874 = env35875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env35874 == env35875) = true)

def env35876 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58396,144493,62540,41311,8193,65,245019,115014,17665,10281,119043,201830,256,95531,103430,63069]

theorem envBound35876 : H12AffineFastState.Bounded env35876 := by
  intro p hp
  have h : env35876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35861_35876 : H12AffineEnvironment.transform 6 9 env35861 = env35876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35861 == env35876) = true)

theorem identity35876 : scanCanonicalize (H12AffineFastState.compose env35876 (packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound35876 : packedSelected [0,4,8,10,11,12,14,15,16,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env35877 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,65536,131072,138341,1024,80,25677,144493,29725,8462,8193,65,212298,82199,17665,10281,86354,201830,256,95531,70743,30220]

theorem envBound35877 : H12AffineFastState.Bounded env35877 := by
  intro p hp
  have h : env35877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35876_35877 : H12AffineEnvironment.transform 14 81 env35876 = env35877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env35876 == env35877) = true)

theorem identity35877 : scanCanonicalize (H12AffineFastState.compose env35877 (packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound35877 : packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env35878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,65536,16400,23669,1024,80,25677,29821,29725,8462,8193,65,97626,82199,17665,10281,86354,87158,256,95531,70743,30220]

theorem envBound35878 : H12AffineFastState.Bounded env35878 := by
  intro p hp
  have h : env35878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35877_35878 : H12AffineEnvironment.transform 16 16400 env35877 = env35878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env35877 == env35878) = true)

theorem identity35878 : scanCanonicalize (H12AffineFastState.compose env35878 (packedSelected [0,3,5,7,9,10,12,14,15,16,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35878 : packedSelected [0,3,5,7,9,10,12,14,15,16,17,22] rootPS < 2^1333 := by decide +kernel

def env35879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,65536,16400,23669,1024,80,17728,21872,21776,3,268,65,89175,82199,17665,2340,86354,87158,256,87078,70743,22273]

theorem envBound35879 : H12AffineFastState.Bounded env35879 := by
  intro p hp
  have h : env35879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35878_35879 : H12AffineEnvironment.transform 12 269 env35878 = env35879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35878 == env35879) = true)

theorem identity35879 : scanCanonicalize (H12AffineFastState.compose env35879 (packedSelected [1,3,5,8,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 6471) := by decide +kernel

theorem selectedBound35879 : packedSelected [1,3,5,8,14,16,17] rootPS < 2^1333 := by decide +kernel

def env35880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,81,6471,16400,23669,1024,80,17728,21872,21776,3,268,65,17680,22608,17665,2340,18453,19761,256,19809,3344,22273]

theorem envBound35880 : H12AffineFastState.Bounded env35880 := by
  intro p hp
  have h : env35880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35879_35880 : H12AffineEnvironment.transform 15 6471 env35879 = env35880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6471 env35879 == env35880) = true)

theorem identity35880 : scanCanonicalize (H12AffineFastState.compose env35880 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound35880 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env35881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,3344,81,6471,3328,4453,1024,80,2128,6240,6144,3,268,65,2048,5440,2065,2340,1285,33,256,113,3344,6673]

theorem envBound35881 : H12AffineFastState.Bounded env35881 := by
  intro p hp
  have h : env35881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35880_35881 : H12AffineEnvironment.transform 13 3344 env35880 = env35881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env35880 == env35881) = true)

theorem identity35881 : scanCanonicalize (H12AffineFastState.compose env35881 (packedSelected [1,2,6,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound35881 : packedSelected [1,2,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1360,269,3344,81,3095,3328,1077,1024,80,2128,3376,3408,3,268,65,2048,16,2065,2340,1285,33,256,113,3344,3905]

theorem envBound35882 : H12AffineFastState.Bounded env35882 := by
  intro p hp
  have h : env35882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35881_35882 : H12AffineEnvironment.transform 11 1360 env35881 = env35882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env35881 == env35882) = true)

def env35883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452768,441778,8328,65,4691218,115151,17664,10400,119042,4268162,256,485710,493802,63189]

theorem envBound35883 : H12AffineFastState.Bounded env35883 := by
  intro p hp
  have h : env35883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35837_35883 : H12AffineEnvironment.transform 20 456945 env35837 = env35883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env35837 == env35883) = true)

def env35884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452768,441778,8328,65,245138,115151,17664,10400,119042,329730,256,485710,493802,63189]

theorem envBound35884 : H12AffineFastState.Bounded env35884 := by
  intro p hp
  have h : env35884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35883_35884 : H12AffineEnvironment.transform 21 272512 env35883 = env35884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35883 == env35884) = true)

def env35885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272392,452648,441658,8192,65,245018,115015,17664,10280,119042,329730,256,485710,493666,63069]

theorem envBound35885 : H12AffineFastState.Bounded env35885 := by
  intro p hp
  have h : env35885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35884_35885 : H12AffineEnvironment.transform 6 8 env35884 = env35885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35884 == env35885) = true)

def env35886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276585,272392,272440,294186,8192,65,97546,115015,17664,10280,119042,329730,256,371038,346226,63069]

theorem envBound35886 : H12AffineFastState.Bounded env35886 := by
  intro p hp
  have h : env35886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35885_35886 : H12AffineEnvironment.transform 16 49168 env35885 = env35886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35885 == env35886) = true)

theorem identity35886 : scanCanonicalize (H12AffineFastState.compose env35886 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound35886 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,45341,41340,41292,62558,8192,65,97546,115015,17664,10280,119042,98678,256,73770,114950,63069]

theorem envBound35887 : H12AffineFastState.Bounded env35887 := by
  intro p hp
  have h : env35887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35886_35887 : H12AffineEnvironment.transform 17 35188 env35886 = env35887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env35886 == env35887) = true)

theorem identity35887 : scanCanonicalize (H12AffineFastState.compose env35887 (packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound35887 : packedSelected [0,1,3,4,8,10,12,14,15,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env35888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,65536,16692,2128,1024,293,12345,8280,8296,30074,8192,65,97546,82019,17664,10280,86054,65618,256,73770,81954,30585]

theorem envBound35888 : H12AffineFastState.Bounded env35888 := by
  intro p hp
  have h : env35888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35887_35888 : H12AffineEnvironment.transform 14 292 env35887 = env35888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env35887 == env35888) = true)

theorem identity35888 : scanCanonicalize (H12AffineFastState.compose env35888 (packedSelected [1,2,4,5,6,8,11,16,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound35888 : packedSelected [1,2,4,5,6,8,11,16,22,23,24] rootPS < 2^1333 := by decide +kernel

def env35889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,292,65536,5440,2128,1024,293,12345,8280,8296,8462,8192,65,76158,70679,4468,10280,66642,65618,256,73770,70742,8973]

theorem envBound35889 : H12AffineFastState.Bounded env35889 := by
  intro p hp
  have h : env35889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35888_35889 : H12AffineEnvironment.transform 13 5236 env35888 = env35889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env35888 == env35889) = true)

theorem identity35889 : scanCanonicalize (H12AffineFastState.compose env35889 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35889 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env35890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5236,292,65536,5440,2128,1024,293,4112,113,65,295,41,65,67927,70679,4468,2049,66642,65618,256,65539,70742,804]

theorem envBound35890 : H12AffineFastState.Bounded env35890 := by
  intro p hp
  have h : env35890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35889_35890 : H12AffineEnvironment.transform 12 41 env35889 = env35890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35889 == env35890) = true)

theorem identity35890 : scanCanonicalize (H12AffineFastState.compose env35890 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound35890 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5236,292,35,5440,2128,1024,293,4112,113,65,295,41,65,2420,5172,4468,2049,1137,113,256,32,5237,804]

theorem envBound35891 : H12AffineFastState.Bounded env35891 := by
  intro p hp
  have h : env35891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35890_35891 : H12AffineEnvironment.transform 15 35 env35890 = env35891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env35890 == env35891) = true)

theorem identity35891 : scanCanonicalize (H12AffineFastState.compose env35891 (packedSelected [1,3,5,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35891 : packedSelected [1,3,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env35892 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,4112,292,35,4388,2128,100,293,4112,113,65,295,41,65,2420,4176,4468,2049,21,113,256,32,4113,804]

theorem envBound35892 : H12AffineFastState.Bounded env35892 := by
  intro p hp
  have h : env35892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35891_35892 : H12AffineEnvironment.transform 9 100 env35891 = env35892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35891 == env35892) = true)

theorem identity35892 : scanCanonicalize (H12AffineFastState.compose env35892 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35892 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env35893 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,41,4112,80,35,4176,2128,100,81,4112,113,65,83,41,65,2048,4176,4096,2049,21,113,116,32,4113,592]

theorem envBound35893 : H12AffineFastState.Bounded env35893 := by
  intro p hp
  have h : env35893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35892_35893 : H12AffineEnvironment.transform 7 116 env35892 = env35893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35892 == env35893) = true)

theorem identity35893 : scanCanonicalize (H12AffineFastState.compose env35893 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound35893 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env35894 : List Nat := [2,4,8,16,32,64,8,116,512,100,81,4096,41,4112,80,35,4176,1,100,81,4112,113,65,83,41,65,81,4176,4096,80,21,113,116,32,4113,592]

theorem envBound35894 : H12AffineFastState.Bounded env35894 := by
  intro p hp
  have h : env35894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35893_35894 : H12AffineEnvironment.transform 10 81 env35893 = env35894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env35893 == env35894) = true)

theorem identity35894 : scanCanonicalize (H12AffineFastState.compose env35894 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound35894 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env35895 : List Nat := [2,4,8,16,32,64,8,116,512,100,81,16,41,0,80,35,64,1,100,81,0,113,65,83,41,65,81,64,16,80,21,113,116,32,1,592]

theorem envBound35895 : H12AffineFastState.Bounded env35895 := by
  intro p hp
  have h : env35895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35894_35895 : H12AffineEnvironment.transform 11 16 env35894 = env35895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env35894 == env35895) = true)

theorem identity35895 : scanCanonicalize (H12AffineFastState.compose env35895 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35895 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env35896 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,16,41,0,1,35,17,1,53,0,0,32,16,2,41,16,0,17,16,1,21,32,37,32,1,513]

theorem envBound35896 : H12AffineFastState.Bounded env35896 := by
  intro p hp
  have h : env35896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35895_35896 : H12AffineEnvironment.transform 5 17 env35895 = env35896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35895 == env35896) = true)

theorem identity35896 : scanCanonicalize (H12AffineFastState.compose env35896 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35897 : List Nat := [2,4,8,16,32,17,8,37,16,53,0,16,41,0,1,35,17,1,53,0,0,32,16,2,41,16,0,17,16,1,21,32,37,32,1,17]

theorem envBound35897 : H12AffineFastState.Bounded env35897 := by
  intro p hp
  have h : env35897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35896_35897 : H12AffineEnvironment.transform 8 16 env35896 = env35897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35896 == env35897) = true)

theorem identity35897 : scanCanonicalize (H12AffineFastState.compose env35897 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35897 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35898 : List Nat := [2,4,8,10,32,11,8,37,10,47,0,10,41,0,1,35,11,1,47,0,0,32,10,2,41,10,0,11,10,1,15,32,37,32,1,11]

theorem envBound35898 : H12AffineFastState.Bounded env35898 := by
  intro p hp
  have h : env35898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35897_35898 : H12AffineEnvironment.transform 3 10 env35897 = env35898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35897 == env35898) = true)

theorem identity35898 : scanCanonicalize (H12AffineFastState.compose env35898 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35899 : List Nat := [2,4,3,1,32,0,3,37,1,36,0,1,34,0,1,35,0,1,36,0,0,32,1,2,34,1,0,0,1,1,4,32,37,32,1,0]

theorem envBound35899 : H12AffineFastState.Bounded env35899 := by
  intro p hp
  have h : env35899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35898_35899 : H12AffineEnvironment.transform 2 3 env35898 = env35899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35898 == env35899) = true)

def env35900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276584,272392,272441,294187,8192,65,97547,115015,17664,10280,119042,329730,256,371039,346227,63069]

theorem envBound35900 : H12AffineFastState.Bounded env35900 := by
  intro p hp
  have h : env35900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35885_35900 : H12AffineEnvironment.transform 16 49169 env35885 = env35900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35885 == env35900) = true)

theorem identity35900 : scanCanonicalize (H12AffineFastState.compose env35900 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35900 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,262144,1024,8540,276584,272392,272441,294187,8192,65,97547,90138,17664,10280,94303,329730,256,329730,346227,22272]

theorem envBound35901 : H12AffineFastState.Bounded env35901 := by
  intro p hp
  have h : env35901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35900_35901 : H12AffineEnvironment.transform 14 8541 env35900 = env35901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35900 == env35901) = true)

theorem identity35901 : scanCanonicalize (H12AffineFastState.compose env35901 (packedSelected [3,4,5,7,8,9,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound35901 : packedSelected [3,4,5,7,8,9,27,28] rootPS < 2^1333 := by decide +kernel

def env35902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10360,1024,8540,4112,112,65,21843,8192,65,97547,90138,17664,10280,94303,73850,256,73850,90123,22272]

theorem envBound35902 : H12AffineFastState.Bounded env35902 := by
  intro p hp
  have h : env35902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35901_35902 : H12AffineEnvironment.transform 17 10360 env35901 = env35902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env35901 == env35902) = true)

theorem identity35902 : scanCanonicalize (H12AffineFastState.compose env35902 (packedSelected [0,1,3,5,7,8,10,11,15,16,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 18466) := by decide +kernel

theorem selectedBound35902 : packedSelected [0,1,3,5,7,8,10,11,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env35903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,18466,24908,10360,1024,8540,4112,112,65,21843,8192,65,13609,10296,17664,10280,14461,26712,256,26712,10281,22272]

theorem envBound35903 : H12AffineFastState.Bounded env35903 := by
  intro p hp
  have h : env35903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35902_35903 : H12AffineEnvironment.transform 15 18466 env35902 = env35903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18466 env35902 == env35903) = true)

theorem identity35903 : scanCanonicalize (H12AffineFastState.compose env35903 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound35903 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env35904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,8192,16384,8541,18466,24908,10360,1024,8540,3124,112,65,18807,8192,65,10509,10296,17664,10280,9305,26712,256,26712,10281,19236]

theorem envBound35904 : H12AffineFastState.Bounded env35904 := by
  intro p hp
  have h : env35904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35903_35904 : H12AffineEnvironment.transform 11 3108 env35903 = env35904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env35903 == env35904) = true)

theorem identity35904 : scanCanonicalize (H12AffineFastState.compose env35904 (packedSelected [0,7,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35904 : packedSelected [0,7,11,15,16] rootPS < 2^1333 := by decide +kernel

def env35905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,269,16384,80,18466,16449,2421,1024,81,3124,112,65,18807,269,65,2048,2357,17664,2341,1364,18773,256,18773,2340,19236]

theorem envBound35905 : H12AffineFastState.Bounded env35905 := by
  intro p hp
  have h : env35905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35904_35905 : H12AffineEnvironment.transform 12 269 env35904 = env35905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35904 == env35905) = true)

theorem identity35905 : scanCanonicalize (H12AffineFastState.compose env35905 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound35905 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env35906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,1140,269,16384,80,16498,16449,293,1024,81,1124,112,65,16679,269,65,80,357,17664,373,1364,16645,256,16645,372,17268]

theorem envBound35906 : H12AffineFastState.Bounded env35906 := by
  intro p hp
  have h : env35906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35905_35906 : H12AffineEnvironment.transform 10 80 env35905 = env35906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env35905 == env35906) = true)

theorem identity35906 : scanCanonicalize (H12AffineFastState.compose env35906 (packedSelected [1,3,4,5,6,8,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound35906 : packedSelected [1,3,4,5,6,8,9,14] rootPS < 2^1333 := by decide +kernel

def env35907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,1140,269,293,80,343,356,293,1024,81,1124,112,65,2,269,65,80,357,1061,373,1364,32,256,32,372,593]

theorem envBound35907 : H12AffineFastState.Bounded env35907 := by
  intro p hp
  have h : env35907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35906_35907 : H12AffineEnvironment.transform 13 293 env35906 = env35907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env35906 == env35907) = true)

theorem identity35907 : scanCanonicalize (H12AffineFastState.compose env35907 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35907 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env35908 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,357,269,293,80,343,356,293,273,81,373,112,65,2,269,65,80,357,308,373,69,32,256,32,372,593]

theorem envBound35908 : H12AffineFastState.Bounded env35908 := by
  intro p hp
  have h : env35908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35907_35908 : H12AffineEnvironment.transform 9 273 env35907 = env35908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35907 == env35908) = true)

theorem identity35908 : scanCanonicalize (H12AffineFastState.compose env35908 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35908 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env35909 : List Nat := [2,4,8,16,32,64,8,37,512,52,80,64,40,0,80,114,65,0,52,81,80,112,65,2,40,65,80,64,17,80,69,32,37,32,81,593]

theorem envBound35909 : H12AffineFastState.Bounded env35909 := by
  intro p hp
  have h : env35909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35908_35909 : H12AffineEnvironment.transform 7 37 env35908 = env35909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35908 == env35909) = true)

theorem identity35909 : scanCanonicalize (H12AffineFastState.compose env35909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35910 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,40,0,1,35,16,0,52,0,1,33,16,2,40,16,1,17,17,1,20,32,37,32,0,512]

theorem envBound35910 : H12AffineFastState.Bounded env35910 := by
  intro p hp
  have h : env35910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35909_35910 : H12AffineEnvironment.transform 5 17 env35909 = env35910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35909 == env35910) = true)

theorem identity35910 : scanCanonicalize (H12AffineFastState.compose env35910 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound35910 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35911 : List Nat := [2,4,8,16,32,17,8,37,4,52,1,17,40,0,1,35,16,0,52,0,1,33,16,2,40,16,1,17,17,1,20,32,37,32,0,4]

theorem envBound35911 : H12AffineFastState.Bounded env35911 := by
  intro p hp
  have h : env35911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35910_35911 : H12AffineEnvironment.transform 8 4 env35910 = env35911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env35910 == env35911) = true)

theorem identity35911 : scanCanonicalize (H12AffineFastState.compose env35911 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound35911 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35912 : List Nat := [2,4,8,16,7,17,8,2,4,19,1,17,15,0,1,4,16,0,19,0,1,6,16,2,15,16,1,17,17,1,20,7,2,7,0,4]

theorem envBound35912 : H12AffineFastState.Bounded env35912 := by
  intro p hp
  have h : env35912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35911_35912 : H12AffineEnvironment.transform 4 7 env35911 = env35912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env35911 == env35912) = true)

theorem identity35912 : scanCanonicalize (H12AffineFastState.compose env35912 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35912 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35913 : List Nat := [2,4,8,0,7,1,8,2,4,3,1,1,15,0,1,4,0,0,3,0,1,6,0,2,15,0,1,1,1,1,4,7,2,7,0,4]

theorem envBound35913 : H12AffineFastState.Bounded env35913 := by
  intro p hp
  have h : env35913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35912_35913 : H12AffineEnvironment.transform 3 0 env35912 = env35913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35912 == env35913) = true)

theorem identity35913 : scanCanonicalize (H12AffineFastState.compose env35913 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound35913 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35914 : List Nat := [2,4,5,0,7,1,5,2,4,3,1,1,2,0,1,4,0,0,3,0,1,6,0,2,2,0,1,1,1,1,4,7,2,7,0,4]

theorem envBound35914 : H12AffineFastState.Bounded env35914 := by
  intro p hp
  have h : env35914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35913_35914 : H12AffineEnvironment.transform 2 5 env35913 = env35914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env35913 == env35914) = true)

theorem identity35914 : scanCanonicalize (H12AffineFastState.compose env35914 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35914 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35915 : List Nat := [2,0,1,0,3,1,1,2,0,3,1,1,2,0,1,0,0,0,3,0,1,2,0,2,2,0,1,1,1,1,0,3,2,3,0,0]

theorem envBound35915 : H12AffineFastState.Bounded env35915 := by
  intro p hp
  have h : env35915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35914_35915 : H12AffineEnvironment.transform 1 0 env35914 = env35915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35914 == env35915) = true)

theorem identity35915 : scanCanonicalize (H12AffineFastState.compose env35915 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35915 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35916 : List Nat := [0,0,1,0,1,1,1,0,0,1,1,1,0,0,1,0,0,0,1,0,1,0,0,0,0,0,1,1,1,1,0,1,0,1,0,0]

theorem envBound35916 : H12AffineFastState.Bounded env35916 := by
  intro p hp
  have h : env35916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35915_35916 : H12AffineEnvironment.transform 0 0 env35915 = env35916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35915 == env35916) = true)

def env35917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272393,452649,441659,8193,65,245019,115014,17664,10281,119042,329730,256,485710,493667,63068]

theorem envBound35917 : H12AffineFastState.Bounded env35917 := by
  intro p hp
  have h : env35917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35884_35917 : H12AffineEnvironment.transform 6 9 env35884 = env35917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35884 == env35917) = true)

def env35918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272393,272441,294187,8193,65,97547,115014,17664,10281,119042,329730,256,371038,346227,63068]

theorem envBound35918 : H12AffineFastState.Bounded env35918 := by
  intro p hp
  have h : env35918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35917_35918 : H12AffineEnvironment.transform 16 49168 env35917 = env35918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35917 == env35918) = true)

theorem identity35918 : scanCanonicalize (H12AffineFastState.compose env35918 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35918 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,33,17,21763,8193,65,97547,115014,17664,10281,119042,73770,256,98678,90203,63068]

theorem envBound35919 : H12AffineFastState.Bounded env35919 := by
  intro p hp
  have h : env35919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35918_35919 : H12AffineEnvironment.transform 17 10280 env35918 = env35919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35918 == env35919) = true)

theorem identity35919 : scanCanonicalize (H12AffineFastState.compose env35919 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound35919 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env35920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,262,49168,10280,1024,32769,4160,33,17,21763,8193,65,31757,49216,17664,10281,53252,8492,256,32880,24925,63068]

theorem envBound35920 : H12AffineFastState.Bounded env35920 := by
  intro p hp
  have h : env35920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35919_35920 : H12AffineEnvironment.transform 15 262 env35919 = env35920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env35919 == env35920) = true)

theorem identity35920 : scanCanonicalize (H12AffineFastState.compose env35920 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound35920 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,262,5441,10280,1024,21840,4160,33,17,21763,8193,65,31757,5393,17664,10281,1365,8492,256,21793,24925,8973]

theorem envBound35921 : H12AffineFastState.Bounded env35921 := by
  intro p hp
  have h : env35921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35920_35921 : H12AffineEnvironment.transform 14 21841 env35920 = env35921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env35920 == env35921) = true)

theorem identity35921 : scanCanonicalize (H12AffineFastState.compose env35921 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35921 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21841,262,5441,2421,1024,21840,4160,33,17,21763,348,65,23888,5393,17664,2420,1365,113,256,21793,16384,592]

theorem envBound35922 : H12AffineFastState.Bounded env35922 := by
  intro p hp
  have h : env35922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35921_35922 : H12AffineEnvironment.transform 12 349 env35921 = env35922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35921 == env35922) = true)

def env35923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272393,272440,294186,8193,65,97546,115014,17664,10281,119042,329730,256,371039,346226,63068]

theorem envBound35923 : H12AffineFastState.Bounded env35923 := by
  intro p hp
  have h : env35923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35917_35923 : H12AffineEnvironment.transform 16 49169 env35917 = env35923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35917 == env35923) = true)

theorem identity35923 : scanCanonicalize (H12AffineFastState.compose env35923 (packedSelected [1,5,7,10,14,18,19,20,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound35923 : packedSelected [1,5,7,10,14,18,19,20,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env35924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56357,1024,32769,58444,62508,62493,41231,8193,65,97546,115014,17664,10281,119042,119847,256,95610,103511,63068]

theorem envBound35924 : H12AffineFastState.Bounded env35924 := by
  intro p hp
  have h : env35924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35923_35924 : H12AffineEnvironment.transform 17 56357 env35923 = env35924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env35923 == env35924) = true)

theorem identity35924 : scanCanonicalize (H12AffineFastState.compose env35924 (packedSelected [0,1,5,7,9,12,14,15,16,19,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound35924 : packedSelected [0,1,5,7,9,12,14,15,16,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env35925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,10361,1024,29789,4112,112,65,21843,8193,65,97546,79130,17664,10281,75102,73851,256,95610,90123,512]

theorem envBound35925 : H12AffineFastState.Bounded env35925 := by
  intro p hp
  have h : env35925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35924_35925 : H12AffineEnvironment.transform 14 29788 env35924 = env35925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env35924 == env35925) = true)

theorem identity35925 : scanCanonicalize (H12AffineFastState.compose env35925 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound35925 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env35926 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,30042,13389,10361,1024,29789,4112,112,65,21843,8193,65,2128,16448,17664,10281,20484,21793,256,32,5457,512]

theorem envBound35926 : H12AffineFastState.Bounded env35926 := by
  intro p hp
  have h : env35926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35925_35926 : H12AffineEnvironment.transform 15 30042 env35925 = env35926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env35925 == env35926) = true)

theorem identity35926 : scanCanonicalize (H12AffineFastState.compose env35926 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound35926 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env35927 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4405,9577,9327,13389,10361,1024,9576,4112,112,65,1126,8193,65,2128,4469,5173,10281,305,1044,256,32,5457,512]

theorem envBound35927 : H12AffineFastState.Bounded env35927 := by
  intro p hp
  have h : env35927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35926_35927 : H12AffineEnvironment.transform 13 4405 env35926 = env35927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env35926 == env35927) = true)

theorem identity35927 : scanCanonicalize (H12AffineFastState.compose env35927 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound35927 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env35928 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,1,263,4389,3345,1024,0,4112,112,65,1126,1385,65,2128,4469,5173,3393,305,1044,256,32,5457,512]

theorem envBound35928 : H12AffineFastState.Bounded env35928 := by
  intro p hp
  have h : env35928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35927_35928 : H12AffineEnvironment.transform 12 1384 env35927 = env35928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env35927 == env35928) = true)

theorem identity35928 : scanCanonicalize (H12AffineFastState.compose env35928 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound35928 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35929 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,1305,4405,1,263,4389,3345,1024,0,4112,1,48,1047,1304,48,2081,4356,5173,3376,305,1044,256,32,5408,512]

theorem envBound35929 : H12AffineFastState.Bounded env35929 := by
  intro p hp
  have h : env35929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35928_35929 : H12AffineEnvironment.transform 5 49 env35928 = env35929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env35928 == env35929) = true)

theorem identity35929 : scanCanonicalize (H12AffineFastState.compose env35929 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35929 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35930 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,1085,4113,1,35,4097,3125,1024,0,4112,1,48,1047,1084,48,2081,4128,5173,3092,21,1044,36,32,5124,512]

theorem envBound35930 : H12AffineFastState.Bounded env35930 := by
  intro p hp
  have h : env35930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35929_35930 : H12AffineEnvironment.transform 7 36 env35929 = env35930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35929 == env35930) = true)

theorem identity35930 : scanCanonicalize (H12AffineFastState.compose env35930 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35930 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35931 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,1053,4113,1,3,4097,3093,1024,0,4112,1,16,1047,1052,16,2049,4096,5141,3092,21,1044,4,0,5124,512]

theorem envBound35931 : H12AffineFastState.Bounded env35931 := by
  intro p hp
  have h : env35931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35930_35931 : H12AffineEnvironment.transform 4 0 env35930 = env35931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35930 == env35931) = true)

theorem identity35931 : scanCanonicalize (H12AffineFastState.compose env35931 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound35931 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35932 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,1044,1053,1029,1,3,1045,3093,1024,0,1028,1,16,1047,1052,16,2049,1044,1,3092,21,1044,4,0,16,512]

theorem envBound35932 : H12AffineFastState.Bounded env35932 := by
  intro p hp
  have h : env35932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35931_35932 : H12AffineEnvironment.transform 11 1044 env35931 = env35932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env35931 == env35932) = true)

theorem identity35932 : scanCanonicalize (H12AffineFastState.compose env35932 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound35932 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env35933 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1044,1044,1053,1029,1,3,1045,1,1024,0,1028,1,16,1047,1052,16,1045,1044,1,0,21,1044,4,0,16,512]

theorem envBound35933 : H12AffineFastState.Bounded env35933 := by
  intro p hp
  have h : env35933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35932_35933 : H12AffineEnvironment.transform 10 1044 env35932 = env35933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env35932 == env35933) = true)

theorem identity35933 : scanCanonicalize (H12AffineFastState.compose env35933 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound35933 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35934 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,0,9,17,1,3,1,1,20,0,16,1,16,3,8,16,1,0,1,0,21,0,4,0,16,512]

theorem envBound35934 : H12AffineFastState.Bounded env35934 := by
  intro p hp
  have h : env35934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35933_35934 : H12AffineEnvironment.transform 9 20 env35933 = env35934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35933 == env35934) = true)

theorem identity35934 : scanCanonicalize (H12AffineFastState.compose env35934 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35935 : List Nat := [2,4,8,16,0,17,9,4,16,20,0,0,9,17,1,3,1,1,20,0,16,1,16,3,8,16,1,0,1,0,21,0,4,0,16,16]

theorem envBound35935 : H12AffineFastState.Bounded env35935 := by
  intro p hp
  have h : env35935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35934_35935 : H12AffineEnvironment.transform 8 16 env35934 = env35935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35934 == env35935) = true)

theorem identity35935 : scanCanonicalize (H12AffineFastState.compose env35935 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound35935 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35936 : List Nat := [2,4,8,15,0,14,9,4,15,11,0,0,9,14,1,3,1,1,11,0,15,1,15,3,8,15,1,0,1,0,10,0,4,0,15,15]

theorem envBound35936 : H12AffineFastState.Bounded env35936 := by
  intro p hp
  have h : env35936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35935_35936 : H12AffineEnvironment.transform 3 15 env35935 = env35936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env35935 == env35936) = true)

def env35937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272513,452768,441778,8328,65,245139,115151,17664,10400,119042,329731,256,485710,493802,63189]

theorem envBound35937 : H12AffineFastState.Bounded env35937 := by
  intro p hp
  have h : env35937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35883_35937 : H12AffineEnvironment.transform 21 272513 env35883 = env35937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35883 == env35937) = true)

theorem identity35937 : scanCanonicalize (H12AffineFastState.compose env35937 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound35937 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,180273,16,21762,8328,65,245139,115151,17664,10400,119042,254131,256,98814,90202,63189]

theorem envBound35938 : H12AffineFastState.Bounded env35938 := by
  intro p hp
  have h : env35938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35937_35938 : H12AffineEnvironment.transform 17 190640 env35937 = env35938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env35937 == env35938) = true)

def env35939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180273,16,21762,8192,65,245019,115015,17664,10280,119042,254011,256,98678,90202,63069]

theorem envBound35939 : H12AffineFastState.Bounded env35939 := by
  intro p hp
  have h : env35939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35938_35939 : H12AffineEnvironment.transform 6 8 env35938 = env35939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35938 == env35939) = true)

theorem identity35939 : scanCanonicalize (H12AffineFastState.compose env35939 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound35939 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1024,32769,4161,41341,16,21762,8192,65,121943,115015,17664,10280,119042,98679,256,98678,90202,63069]

theorem envBound35940 : H12AffineFastState.Bounded env35940 := by
  intro p hp
  have h : env35940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35939_35940 : H12AffineEnvironment.transform 16 24908 env35939 = env35940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env35939 == env35940) = true)

theorem identity35940 : scanCanonicalize (H12AffineFastState.compose env35940 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound35940 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env35941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,24908,23669,1024,21760,4161,29820,16,21762,8192,65,67926,70726,17664,10280,66563,87158,256,87159,90202,9052]

theorem envBound35941 : H12AffineFastState.Bounded env35941 := by
  intro p hp
  have h : env35941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35940_35941 : H12AffineEnvironment.transform 14 21761 env35940 = env35941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env35940 == env35941) = true)

theorem identity35941 : scanCanonicalize (H12AffineFastState.compose env35941 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35941 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,16401,23669,1024,21760,4161,21793,16,21762,349,65,67926,70726,17664,2421,66563,87158,256,87159,82183,513]

theorem envBound35942 : H12AffineFastState.Bounded env35942 := by
  intro p hp
  have h : env35942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35941_35942 : H12AffineEnvironment.transform 12 349 env35941 = env35942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35941 == env35942) = true)

theorem identity35942 : scanCanonicalize (H12AffineFastState.compose env35942 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound35942 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,35,16401,23669,1024,21760,4161,21793,16,21762,349,65,2421,5221,17664,2421,1056,21589,256,21588,16676,513]

theorem envBound35943 : H12AffineFastState.Bounded env35943 := by
  intro p hp
  have h : env35943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35942_35943 : H12AffineEnvironment.transform 15 35 env35942 = env35943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env35942 == env35943) = true)

theorem identity35943 : scanCanonicalize (H12AffineFastState.compose env35943 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound35943 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env35944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,373,35,5221,2049,1024,372,4161,341,16,374,349,65,2421,5221,4468,2421,1056,33,256,32,5456,513]

theorem envBound35944 : H12AffineFastState.Bounded env35944 := by
  intro p hp
  have h : env35944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35943_35944 : H12AffineEnvironment.transform 13 5236 env35943 = env35944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env35943 == env35944) = true)

theorem identity35944 : scanCanonicalize (H12AffineFastState.compose env35944 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound35944 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env35945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2420,349,3328,373,35,3345,2049,1024,372,2357,341,16,374,349,65,2421,3345,2048,2421,1056,33,256,32,3108,513]

theorem envBound35945 : H12AffineFastState.Bounded env35945 := by
  intro p hp
  have h : env35945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35944_35945 : H12AffineEnvironment.transform 11 2420 env35944 = env35945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env35944 == env35945) = true)

theorem identity35945 : scanCanonicalize (H12AffineFastState.compose env35945 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound35945 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env35946 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,2420,349,2404,373,35,2421,2049,100,372,2357,341,16,374,349,65,2421,2421,2048,2421,68,33,256,32,2112,513]

theorem envBound35946 : H12AffineFastState.Bounded env35946 := by
  intro p hp
  have h : env35946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35945_35946 : H12AffineEnvironment.transform 9 100 env35945 = env35946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env35945 == env35946) = true)

theorem identity35946 : scanCanonicalize (H12AffineFastState.compose env35946 (packedSelected [4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35946 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env35947 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,2049,40,2065,0,35,2048,2049,100,1,2112,32,16,3,40,65,2048,2048,2048,2048,68,33,117,32,2112,513]

theorem envBound35947 : H12AffineFastState.Bounded env35947 := by
  intro p hp
  have h : env35947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35946_35947 : H12AffineEnvironment.transform 7 117 env35946 = env35947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35946 == env35947) = true)

theorem identity35947 : scanCanonicalize (H12AffineFastState.compose env35947 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound35947 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35948 : List Nat := [2,4,8,16,32,0,8,53,512,36,2048,2049,40,2065,0,35,2048,2049,36,1,2048,32,16,3,40,1,2048,2048,2048,2048,4,33,53,32,2048,513]

theorem envBound35948 : H12AffineFastState.Bounded env35948 := by
  intro p hp
  have h : env35948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35947_35948 : H12AffineEnvironment.transform 5 0 env35947 = env35948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env35947 == env35948) = true)

theorem identity35948 : scanCanonicalize (H12AffineFastState.compose env35948 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound35948 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35949 : List Nat := [2,4,8,7,32,0,8,34,512,36,2048,2049,40,2054,0,35,2048,2049,36,1,2048,32,7,3,40,1,2048,2048,2048,2048,4,33,34,32,2048,513]

theorem envBound35949 : H12AffineFastState.Bounded env35949 := by
  intro p hp
  have h : env35949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35948_35949 : H12AffineEnvironment.transform 3 7 env35948 = env35949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env35948 == env35949) = true)

theorem identity35949 : scanCanonicalize (H12AffineFastState.compose env35949 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35949 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35950 : List Nat := [2,4,4,7,32,0,4,34,512,36,2048,2049,36,2054,0,35,2048,2049,36,1,2048,32,7,3,36,1,2048,2048,2048,2048,4,33,34,32,2048,513]

theorem envBound35950 : H12AffineFastState.Bounded env35950 := by
  intro p hp
  have h : env35950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35949_35950 : H12AffineEnvironment.transform 2 4 env35949 = env35950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35949 == env35950) = true)

theorem identity35950 : scanCanonicalize (H12AffineFastState.compose env35950 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound35950 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35951 : List Nat := [2,4,4,7,32,0,4,34,37,36,2048,2049,36,2054,0,35,2048,2049,36,1,2048,32,7,3,36,1,2048,2048,2048,2048,4,33,34,32,2048,36]

theorem envBound35951 : H12AffineFastState.Bounded env35951 := by
  intro p hp
  have h : env35951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35950_35951 : H12AffineEnvironment.transform 8 37 env35950 = env35951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env35950 == env35951) = true)

def env35952 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180273,16,21762,8193,65,245018,115014,17664,10281,119042,254010,256,98679,90202,63068]

theorem envBound35952 : H12AffineFastState.Bounded env35952 := by
  intro p hp
  have h : env35952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35938_35952 : H12AffineEnvironment.transform 6 9 env35938 = env35952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35938 == env35952) = true)

theorem identity35952 : scanCanonicalize (H12AffineFastState.compose env35952 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound35952 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,32,16,21762,8193,65,97547,115014,17664,10281,119042,73771,256,98679,90202,63068]

theorem envBound35953 : H12AffineFastState.Bounded env35953 := by
  intro p hp
  have h : env35953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35952_35953 : H12AffineEnvironment.transform 16 49169 env35952 = env35953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35952 == env35953) = true)

theorem identity35953 : scanCanonicalize (H12AffineFastState.compose env35953 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35953 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env35954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,65536,49169,2340,1024,32769,4161,32,16,21762,269,65,89095,115014,17664,2341,119042,65831,256,98679,82262,55120]

theorem envBound35954 : H12AffineFastState.Bounded env35954 := by
  intro p hp
  have h : env35954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35953_35954 : H12AffineEnvironment.transform 12 268 env35953 = env35954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35953 == env35954) = true)

theorem identity35954 : scanCanonicalize (H12AffineFastState.compose env35954 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35954 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,65536,38160,2340,1024,32769,4161,32,16,3,269,65,67846,103495,4097,2341,99331,65831,256,98679,70743,33361]

theorem envBound35955 : H12AffineFastState.Bounded env35955 := by
  intro p hp
  have h : env35955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35954_35955 : H12AffineEnvironment.transform 13 5377 env35954 = env35955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35954 == env35955) = true)

theorem identity35955 : scanCanonicalize (H12AffineFastState.compose env35955 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound35955 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,0,65536,5392,2340,1024,1,4161,32,16,3,269,65,67846,70727,4097,2341,66563,65831,256,65911,70743,593]

theorem envBound35956 : H12AffineFastState.Bounded env35956 := by
  intro p hp
  have h : env35956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35955_35956 : H12AffineEnvironment.transform 14 0 env35955 = env35956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env35955 == env35956) = true)

theorem identity35956 : scanCanonicalize (H12AffineFastState.compose env35956 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound35956 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env35957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,268,3392,0,65536,3409,2340,1024,1,2048,32,16,3,269,65,67846,68614,2112,2341,66563,65831,256,65911,68630,593]

theorem envBound35957 : H12AffineFastState.Bounded env35957 := by
  intro p hp
  have h : env35957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35956_35957 : H12AffineEnvironment.transform 11 2113 env35956 = env35957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env35956 == env35957) = true)

theorem identity35957 : scanCanonicalize (H12AffineFastState.compose env35957 (packedSelected [0,4,7,9,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound35957 : packedSelected [0,4,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env35958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,268,3392,0,262,3409,2340,1024,1,2048,32,16,3,269,65,2048,3328,2112,2341,1285,33,256,113,3344,593]

theorem envBound35958 : H12AffineFastState.Bounded env35958 := by
  intro p hp
  have h : env35958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35957_35958 : H12AffineEnvironment.transform 15 262 env35957 = env35958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env35957 == env35958) = true)

theorem identity35958 : scanCanonicalize (H12AffineFastState.compose env35958 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 597) := by decide +kernel

theorem selectedBound35958 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35959 : List Nat := [2,4,8,16,32,64,9,256,512,597,2048,2113,268,2837,0,262,2820,2340,597,1,2048,32,16,3,269,65,2048,2901,2112,2341,848,33,256,113,2885,593]

theorem envBound35959 : H12AffineFastState.Bounded env35959 := by
  intro p hp
  have h : env35959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35958_35959 : H12AffineEnvironment.transform 9 597 env35958 = env35959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 597 env35958 == env35959) = true)

theorem identity35959 : scanCanonicalize (H12AffineFastState.compose env35959 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound35959 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env35960 : List Nat := [2,4,8,16,32,64,9,21,512,597,2048,2113,25,2560,0,19,2577,2097,597,1,2048,32,16,3,24,65,2048,2624,2112,2096,581,33,21,113,2640,593]

theorem envBound35960 : H12AffineFastState.Bounded env35960 := by
  intro p hp
  have h : env35960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35959_35960 : H12AffineEnvironment.transform 7 21 env35959 = env35960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env35959 == env35960) = true)

theorem identity35960 : scanCanonicalize (H12AffineFastState.compose env35960 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound35960 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35961 : List Nat := [2,4,8,16,32,33,9,21,512,564,2048,2080,25,2560,0,19,2577,2097,564,1,2048,32,16,3,24,32,2048,2593,2081,2096,548,33,21,16,2609,560]

theorem envBound35961 : H12AffineFastState.Bounded env35961 := by
  intro p hp
  have h : env35961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35960_35961 : H12AffineEnvironment.transform 5 33 env35960 = env35961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env35960 == env35961) = true)

theorem identity35961 : scanCanonicalize (H12AffineFastState.compose env35961 (packedSelected [3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35961 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env35962 : List Nat := [2,4,8,0,32,33,9,5,512,548,2048,2080,9,2560,0,3,2561,2081,548,1,2048,32,0,3,8,32,2048,2593,2081,2080,548,33,5,0,2593,544]

theorem envBound35962 : H12AffineFastState.Bounded env35962 := by
  intro p hp
  have h : env35962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35961_35962 : H12AffineEnvironment.transform 3 0 env35961 = env35962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35961 == env35962) = true)

theorem identity35962 : scanCanonicalize (H12AffineFastState.compose env35962 (packedSelected [0,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound35962 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env35963 : List Nat := [2,4,8,0,32,33,9,5,512,548,513,545,9,1,0,3,0,544,548,1,513,32,0,3,8,32,513,32,544,545,548,33,5,0,32,544]

theorem envBound35963 : H12AffineFastState.Bounded env35963 := by
  intro p hp
  have h : env35963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35962_35963 : H12AffineEnvironment.transform 10 513 env35962 = env35963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env35962 == env35963) = true)

def env35964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452769,2114882,8328,65,6385123,115150,2538992,10401,2566643,4268163,256,485710,493802,2493988]

theorem envBound35964 : H12AffineFastState.Bounded env35964 := by
  intro p hp
  have h : env35964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35836_35964 : H12AffineEnvironment.transform 22 452769 env35836 = env35964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env35836 == env35964) = true)

def env35965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,4194304,452769,441778,8328,65,4691219,115150,17664,10401,119043,4268163,256,485710,493802,63188]

theorem envBound35965 : H12AffineFastState.Bounded env35965 := by
  intro p hp
  have h : env35965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35964_35965 : H12AffineEnvironment.transform 20 456944 env35964 = env35965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456944 env35964 == env35965) = true)

def env35966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272512,452769,441778,8328,65,245139,115150,17664,10401,119043,329731,256,485710,493802,63188]

theorem envBound35966 : H12AffineFastState.Bounded env35966 := by
  intro p hp
  have h : env35966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35965_35966 : H12AffineEnvironment.transform 21 272512 env35965 = env35966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35965 == env35966) = true)

theorem identity35966 : scanCanonicalize (H12AffineFastState.compose env35966 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound35966 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,115871,201967,120014,98781,8328,65,245139,115150,17664,10401,119043,144492,256,21793,46213,63188]

theorem envBound35967 : H12AffineFastState.Bounded env35967 := by
  intro p hp
  have h : env35967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35966_35967 : H12AffineEnvironment.transform 17 212079 env35966 = env35967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env35966 == env35967) = true)

def env35968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,115871,120063,120014,98781,8328,65,97667,115150,17664,10401,119043,62588,256,21793,46213,63188]

theorem envBound35968 : H12AffineFastState.Bounded env35968 := by
  intro p hp
  have h : env35968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35967_35968 : H12AffineEnvironment.transform 16 49168 env35967 = env35968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35967 == env35968) = true)

theorem identity35968 : scanCanonicalize (H12AffineFastState.compose env35968 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35968 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env35969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,49168,122147,1024,32769,115871,120063,120014,98781,468,65,89311,115150,17664,2557,119043,54560,256,21793,38361,55176]

theorem envBound35969 : H12AffineFastState.Bounded env35969 := by
  intro p hp
  have h : env35969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35968_35969 : H12AffineEnvironment.transform 12 348 env35968 = env35969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35968 == env35969) = true)

theorem identity35969 : scanCanonicalize (H12AffineFastState.compose env35969 (packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35969 : packedSelected [1,4,5,7,8,9,16,20,24,27] rootPS < 2^1333 := by decide +kernel

def env35970 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,49168,122147,1024,32769,115734,119926,119879,98644,349,65,89174,115015,17664,2420,119043,54560,256,21793,38224,55041]

theorem envBound35970 : H12AffineFastState.Bounded env35970 := by
  intro p hp
  have h : env35970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35969_35970 : H12AffineEnvironment.transform 6 9 env35969 = env35970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35969 == env35970) = true)

theorem identity35970 : scanCanonicalize (H12AffineFastState.compose env35970 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound35970 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35971 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,5392,67619,1024,21761,69910,65910,65863,87124,349,65,89174,70727,17664,2420,66563,32,256,21793,16464,513]

theorem envBound35971 : H12AffineFastState.Bounded env35971 := by
  intro p hp
  have h : env35971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35970_35971 : H12AffineEnvironment.transform 14 21760 env35970 = env35971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env35970 == env35971) = true)

def env35972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130174,1024,32769,115871,120062,120014,98781,8328,65,97666,115150,17664,10401,119043,62589,256,21793,46213,63188]

theorem envBound35972 : H12AffineFastState.Bounded env35972 := by
  intro p hp
  have h : env35972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35967_35972 : H12AffineEnvironment.transform 16 49169 env35967 = env35972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35967 == env35972) = true)

theorem identity35972 : scanCanonicalize (H12AffineFastState.compose env35972 (packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound35972 : packedSelected [0,1,4,5,7,8,10,11,15,16,20,22,24,31,32,38] rootPS < 2^1333 := by decide +kernel

def env35973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33031,49169,32121,1024,32769,17816,22009,21961,218,8328,65,64645,16585,17664,10401,20484,62589,256,21793,46213,63188]

theorem envBound35973 : H12AffineFastState.Bounded env35973 := by
  intro p hp
  have h : env35973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35972_35973 : H12AffineEnvironment.transform 15 33031 env35972 = env35973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env35972 == env35973) = true)

theorem identity35973 : scanCanonicalize (H12AffineFastState.compose env35973 (packedSelected [0,1,4,5,7,8,10,11,16,17,19,20,22,24,26,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound35973 : packedSelected [0,1,4,5,7,8,10,11,16,17,19,20,22,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env35974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,217,478,16584,32121,1024,216,17816,22009,21961,218,8328,65,31836,16585,17664,10401,20484,29860,256,21793,13404,30221]

theorem envBound35974 : H12AffineFastState.Bounded env35974 := by
  intro p hp
  have h : env35974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35973_35974 : H12AffineEnvironment.transform 14 217 env35973 = env35974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env35973 == env35974) = true)

theorem identity35974 : scanCanonicalize (H12AffineFastState.compose env35974 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35974 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env35975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,217,478,16584,23588,1024,216,17816,22009,21961,218,469,65,23809,16585,17664,2556,20484,22009,256,21793,5377,22352]

theorem envBound35975 : H12AffineFastState.Bounded env35975 := by
  intro p hp
  have h : env35975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35974_35975 : H12AffineEnvironment.transform 12 349 env35974 = env35975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35974 == env35975) = true)

theorem identity35975 : scanCanonicalize (H12AffineFastState.compose env35975 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound35975 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env35976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5457,217,478,5529,2421,1024,216,4297,168,152,218,469,65,2128,5528,4177,2556,1365,168,256,112,5377,513]

theorem envBound35976 : H12AffineFastState.Bounded env35976 := by
  intro p hp
  have h : env35976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35975_35976 : H12AffineEnvironment.transform 13 5457 env35975 = env35976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env35975 == env35976) = true)

theorem identity35976 : scanCanonicalize (H12AffineFastState.compose env35976 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound35976 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35977 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,0,263,5440,2421,1024,1,4112,113,65,3,268,65,2128,5441,4177,2341,1365,113,256,112,5377,513]

theorem envBound35977 : H12AffineFastState.Bounded env35977 := by
  intro p hp
  have h : env35977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35976_35977 : H12AffineEnvironment.transform 6 89 env35976 = env35977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env35976 == env35977) = true)

theorem identity35977 : scanCanonicalize (H12AffineFastState.compose env35977 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35977 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35978 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5392,2341,1024,1,4112,33,17,3,268,17,2048,5393,4097,2341,1285,33,256,32,5377,513]

theorem envBound35978 : H12AffineFastState.Bounded env35978 := by
  intro p hp
  have h : env35978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35977_35978 : H12AffineEnvironment.transform 5 16 env35977 = env35978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35977 == env35978) = true)

theorem identity35978 : scanCanonicalize (H12AffineFastState.compose env35978 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35978 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35979 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5157,0,35,5172,2049,1024,1,4112,33,17,3,40,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound35979 : H12AffineFastState.Bounded env35979 := by
  intro p hp
  have h : env35979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35978_35979 : H12AffineEnvironment.transform 7 36 env35978 = env35979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35978 == env35979) = true)

def env35980 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1045,0,35,1028,2049,1024,1,32,33,17,3,40,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound35980 : H12AffineFastState.Bounded env35980 := by
  intro p hp
  have h : env35980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35979_35980 : H12AffineEnvironment.transform 11 48 env35979 = env35980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35979 == env35980) = true)

theorem identity35980 : scanCanonicalize (H12AffineFastState.compose env35980 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35980 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35981 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,17,8,1045,0,2,1028,2049,1024,1,1,0,17,3,9,17,2048,1029,16,2049,1024,0,5,1,1045,513]

theorem envBound35981 : H12AffineFastState.Bounded env35981 := by
  intro p hp
  have h : env35981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35980_35981 : H12AffineEnvironment.transform 4 1 env35980 = env35981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35980 == env35981) = true)

def env35982 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,17,8,1,0,2,16,2049,20,1,1,0,17,3,9,17,2048,17,16,2049,20,0,5,1,1,513]

theorem envBound35982 : H12AffineFastState.Bounded env35982 := by
  intro p hp
  have h : env35982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35981_35982 : H12AffineEnvironment.transform 9 20 env35981 = env35982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35981 == env35982) = true)

theorem identity35982 : scanCanonicalize (H12AffineFastState.compose env35982 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35983 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,17,8,1,0,2,16,1,20,1,1,0,17,3,9,17,0,17,16,1,20,0,5,1,1,513]

theorem envBound35983 : H12AffineFastState.Bounded env35983 := by
  intro p hp
  have h : env35983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35982_35983 : H12AffineEnvironment.transform 10 0 env35982 = env35983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35982 == env35983) = true)

def leafEnv35983 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,17,8,1,0,2,16,1,20,1,1,0,17,3,20,9,1,17,0,17,16,1,20,0,5,1,4,3,1,513,1,1,0]

def active35983 : List Nat := [0,1,2,3,8]

def tree35983 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35983 : H12WitnessSearch.Good tree35983 := H12GlobalWitnessIndex.good

theorem leafIdentity35983 : H12AffineFastState.composeSystem env35983 rootObs = leafEnv35983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35983 rootObs == leafEnv35983) = true)

theorem terminalChecked35983 : H12PackedTerminal.terminalCheckFast leafEnv35983 active35983 tree35983 = true := by decide +kernel

def env35984 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,8,0,0,2,17,2049,21,1,1,0,17,3,9,17,2048,16,16,2049,21,0,5,1,0,513]

theorem envBound35984 : H12AffineFastState.Bounded env35984 := by
  intro p hp
  have h : env35984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35981_35984 : H12AffineEnvironment.transform 9 21 env35981 = env35984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env35981 == env35984) = true)

theorem identity35984 : scanCanonicalize (H12AffineFastState.compose env35984 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound35984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35985 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,17,8,0,0,2,17,522,21,1,1,0,17,3,9,17,523,16,16,522,21,0,5,1,0,513]

theorem envBound35985 : H12AffineFastState.Bounded env35985 := by
  intro p hp
  have h : env35985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35984_35985 : H12AffineEnvironment.transform 10 523 env35984 = env35985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env35984 == env35985) = true)

def leafEnv35985 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,17,8,0,0,2,17,522,21,1,1,0,17,3,21,9,1,17,523,16,16,522,21,0,5,1,4,3,0,513,1,1,0]

def active35985 : List Nat := [0,1,2,3,8]

def tree35985 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35985 : H12WitnessSearch.Good tree35985 := H12GlobalWitnessIndex.good

theorem leafIdentity35985 : H12AffineFastState.composeSystem env35985 rootObs = leafEnv35985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35985 rootObs == leafEnv35985) = true)

theorem terminalChecked35985 : H12PackedTerminal.terminalCheckFast leafEnv35985 active35985 tree35985 = true := by decide +kernel

def env35986 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1044,0,35,1029,2049,1024,1,33,33,17,3,40,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound35986 : H12AffineFastState.Bounded env35986 := by
  intro p hp
  have h : env35986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35979_35986 : H12AffineEnvironment.transform 11 49 env35979 = env35986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35979 == env35986) = true)

theorem identity35986 : scanCanonicalize (H12AffineFastState.compose env35986 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound35986 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35987 : List Nat := [2,4,8,16,32,16,9,36,512,20,2048,49,41,0,0,35,17,2049,20,1,33,33,17,3,40,17,2048,16,48,2049,53,33,36,32,0,513]

theorem envBound35987 : H12AffineFastState.Bounded env35987 := by
  intro p hp
  have h : env35987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35986_35987 : H12AffineEnvironment.transform 9 20 env35986 = env35987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35986 == env35987) = true)

def env35988 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,17,9,0,0,3,17,2049,20,1,1,1,17,3,8,17,2048,16,16,2049,21,1,4,0,0,513]

theorem envBound35988 : H12AffineFastState.Bounded env35988 := by
  intro p hp
  have h : env35988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35987_35988 : H12AffineEnvironment.transform 4 0 env35987 = env35988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35987 == env35988) = true)

theorem identity35988 : scanCanonicalize (H12AffineFastState.compose env35988 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound35988 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35989 : List Nat := [2,4,8,16,0,16,9,4,512,20,523,17,9,0,0,3,17,522,20,1,1,1,17,3,8,17,523,16,16,522,21,1,4,0,0,513]

theorem envBound35989 : H12AffineFastState.Bounded env35989 := by
  intro p hp
  have h : env35989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35988_35989 : H12AffineEnvironment.transform 10 523 env35988 = env35989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env35988 == env35989) = true)

def leafEnv35989 : List Nat := [2,4,8,16,0,16,9,4,512,20,523,17,9,0,0,3,17,522,20,1,1,1,17,3,21,8,1,17,523,16,16,522,21,1,4,0,4,2,0,513,1,1,0]

def active35989 : List Nat := [0,1,2,3,8]

def tree35989 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35989 : H12WitnessSearch.Good tree35989 := H12GlobalWitnessIndex.good

theorem leafIdentity35989 : H12AffineFastState.composeSystem env35989 rootObs = leafEnv35989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35989 rootObs == leafEnv35989) = true)

theorem terminalChecked35989 : H12PackedTerminal.terminalCheckFast leafEnv35989 active35989 tree35989 = true := by decide +kernel

def env35990 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,16,8,0,0,2,17,2049,20,1,0,0,17,3,9,17,2048,16,17,2049,20,0,5,1,0,513]

theorem envBound35990 : H12AffineFastState.Bounded env35990 := by
  intro p hp
  have h : env35990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35987_35990 : H12AffineEnvironment.transform 4 1 env35987 = env35990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35987 == env35990) = true)

theorem identity35990 : scanCanonicalize (H12AffineFastState.compose env35990 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35990 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35991 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,16,8,0,0,2,17,0,20,1,0,0,17,3,9,17,1,16,17,0,20,0,5,1,0,513]

theorem envBound35991 : H12AffineFastState.Bounded env35991 := by
  intro p hp
  have h : env35991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35990_35991 : H12AffineEnvironment.transform 10 1 env35990 = env35991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35990 == env35991) = true)

def leafEnv35991 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,16,8,0,0,2,17,0,20,1,0,0,17,3,20,9,1,17,1,16,17,0,20,0,5,1,4,3,0,513,1,0,0]

def active35991 : List Nat := [0,1,2,3,8]

def tree35991 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35991 : H12WitnessSearch.Good tree35991 := H12GlobalWitnessIndex.good

theorem leafIdentity35991 : H12AffineFastState.composeSystem env35991 rootObs = leafEnv35991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35991 rootObs == leafEnv35991) = true)

theorem terminalChecked35991 : H12PackedTerminal.terminalCheckFast leafEnv35991 active35991 tree35991 = true := by decide +kernel

def env35992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456944,272513,452769,441778,8328,65,245138,115150,17664,10401,119043,329730,256,485710,493802,63188]

theorem envBound35992 : H12AffineFastState.Bounded env35992 := by
  intro p hp
  have h : env35992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35965_35992 : H12AffineEnvironment.transform 21 272513 env35965 = env35992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35965 == env35992) = true)

theorem identity35992 : scanCanonicalize (H12AffineFastState.compose env35992 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound35992 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,456944,272513,452769,441778,8328,65,158028,5392,17664,10401,1501,318684,256,441744,416820,63188]

theorem envBound35993 : H12AffineFastState.Bounded env35993 := by
  intro p hp
  have h : env35993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35992_35993 : H12AffineEnvironment.transform 15 54494 env35992 = env35993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env35992 == env35993) = true)

theorem identity35993 : scanCanonicalize (H12AffineFastState.compose env35993 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound35993 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env35994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,131072,262144,1024,29908,396325,272513,400500,412007,8328,65,158028,5392,17664,10401,1501,272393,256,411973,416820,513]

theorem envBound35994 : H12AffineFastState.Bounded env35994 := by
  intro p hp
  have h : env35994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35993_35994 : H12AffineEnvironment.transform 14 29909 env35993 = env35994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env35993 == env35994) = true)

theorem identity35994 : scanCanonicalize (H12AffineFastState.compose env35994 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35994 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env35995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,131072,262144,1024,21897,396325,264668,400500,412007,469,65,149521,5392,17664,2556,1501,264532,256,411973,416820,513]

theorem envBound35995 : H12AffineFastState.Bounded env35995 := by
  intro p hp
  have h : env35995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35994_35995 : H12AffineEnvironment.transform 12 349 env35994 = env35995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35994 == env35995) = true)

theorem identity35995 : scanCanonicalize (H12AffineFastState.compose env35995 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 2556) := by decide +kernel

theorem selectedBound35995 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env35996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,131072,2556,1024,21897,132569,32,136584,147611,469,65,149521,5392,17664,2556,1501,168,256,147641,153032,513]

theorem envBound35996 : H12AffineFastState.Bounded env35996 := by
  intro p hp
  have h : env35996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35995_35996 : H12AffineEnvironment.transform 17 2556 env35995 = env35996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2556 env35995 == env35996) = true)

theorem identity35996 : scanCanonicalize (H12AffineFastState.compose env35996 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound35996 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env35997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,5529,2556,1024,21897,4160,32,17,21762,469,65,23944,5392,17664,2556,1501,168,256,21792,16465,513]

theorem envBound35997 : H12AffineFastState.Bounded env35997 := by
  intro p hp
  have h : env35997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35996_35997 : H12AffineEnvironment.transform 16 5529 env35996 = env35997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env35996 == env35997) = true)

theorem identity35997 : scanCanonicalize (H12AffineFastState.compose env35997 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound35997 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35998 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,21840,342,5441,2340,1024,21841,4160,32,17,21762,269,65,23888,5392,17664,2340,1285,112,256,21792,16465,513]

theorem envBound35998 : H12AffineFastState.Bounded env35998 := by
  intro p hp
  have h : env35998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35997_35998 : H12AffineEnvironment.transform 6 88 env35997 = env35998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env35997 == env35998) = true)

theorem identity35998 : scanCanonicalize (H12AffineFastState.compose env35998 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound35998 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env35999 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5457,1,342,5441,2340,1024,0,4160,32,17,83,269,65,2049,5392,4177,2340,1285,112,256,113,5376,513]

theorem envBound35999 : H12AffineFastState.Bounded env35999 := by
  intro p hp
  have h : env35999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35998_35999 : H12AffineEnvironment.transform 13 5457 env35998 = env35999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env35998 == env35999) = true)

theorem identity35999 : scanCanonicalize (H12AffineFastState.compose env35999 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1637) := by decide +kernel

theorem selectedBound35999 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36000 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1637,349,820,1,342,804,2340,1024,0,1573,32,17,83,269,65,2049,885,1588,2340,1285,112,256,113,869,513]

theorem envBound36000 : H12AffineFastState.Bounded env36000 := by
  intro p hp
  have h : env36000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35999_36000 : H12AffineEnvironment.transform 11 1637 env35999 = env36000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1637 env35999 == env36000) = true)

theorem identity36000 : scanCanonicalize (H12AffineFastState.compose env36000 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 884) := by decide +kernel

theorem selectedBound36000 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36001 : List Nat := [2,4,8,16,32,64,88,256,512,1024,884,1637,349,820,1,342,804,592,1024,0,1573,32,17,83,269,65,885,885,1588,592,1285,112,256,113,869,513]

theorem envBound36001 : H12AffineFastState.Bounded env36001 := by
  intro p hp
  have h : env36001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36000_36001 : H12AffineEnvironment.transform 10 884 env36000 = env36001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 884 env36000 == env36001) = true)

theorem identity36001 : scanCanonicalize (H12AffineFastState.compose env36001 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36001 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env36002 : List Nat := [2,4,8,16,32,0,24,256,512,1024,820,1573,285,820,1,278,804,528,1024,0,1573,32,17,19,269,1,821,821,1588,528,1285,48,256,49,805,513]

theorem envBound36002 : H12AffineFastState.Bounded env36002 := by
  intro p hp
  have h : env36002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36001_36002 : H12AffineEnvironment.transform 5 0 env36001 = env36002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36001 == env36002) = true)

theorem identity36002 : scanCanonicalize (H12AffineFastState.compose env36002 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound36002 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env36003 : List Nat := [2,4,8,16,32,0,24,256,512,256,820,805,285,820,1,278,804,528,256,0,805,32,17,19,269,1,821,821,820,528,5,48,256,49,805,513]

theorem envBound36003 : H12AffineFastState.Bounded env36003 := by
  intro p hp
  have h : env36003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36002_36003 : H12AffineEnvironment.transform 9 256 env36002 = env36003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env36002 == env36003) = true)

theorem identity36003 : scanCanonicalize (H12AffineFastState.compose env36003 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36003 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env36004 : List Nat := [2,4,8,16,32,0,24,21,512,21,545,560,8,545,1,3,561,528,21,0,560,32,17,19,24,1,544,544,545,528,5,48,21,49,560,513]

theorem envBound36004 : H12AffineFastState.Bounded env36004 := by
  intro p hp
  have h : env36004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36003_36004 : H12AffineEnvironment.transform 7 21 env36003 = env36004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36003 == env36004) = true)

theorem identity36004 : scanCanonicalize (H12AffineFastState.compose env36004 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36004 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env36005 : List Nat := [2,4,8,1,32,0,9,4,512,4,545,545,8,545,1,3,544,513,4,0,545,32,0,2,9,1,544,544,545,513,5,33,4,32,545,513]

theorem envBound36005 : H12AffineFastState.Bounded env36005 := by
  intro p hp
  have h : env36005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36004_36005 : H12AffineEnvironment.transform 3 1 env36004 = env36005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36004 == env36005) = true)

theorem identity36005 : scanCanonicalize (H12AffineFastState.compose env36005 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36006 : List Nat := [2,4,8,1,0,0,9,4,512,4,513,513,8,513,1,3,512,513,4,0,513,0,0,2,9,1,512,512,513,513,5,1,4,0,513,513]

theorem envBound36006 : H12AffineFastState.Bounded env36006 := by
  intro p hp
  have h : env36006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36005_36006 : H12AffineEnvironment.transform 4 0 env36005 = env36006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36005 == env36006) = true)

def env36007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,4194304,452769,441779,8328,65,4691218,115150,17665,10401,119042,4268163,256,485710,493802,63189]

theorem envBound36007 : H12AffineFastState.Bounded env36007 := by
  intro p hp
  have h : env36007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35964_36007 : H12AffineEnvironment.transform 20 456945 env35964 = env36007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456945 env35964 == env36007) = true)

def env36008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456945,272512,452769,441779,8328,65,245138,115150,17665,10401,119042,329731,256,485710,493802,63189]

theorem envBound36008 : H12AffineFastState.Bounded env36008 := by
  intro p hp
  have h : env36008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36007_36008 : H12AffineEnvironment.transform 21 272512 env36007 = env36008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env36007 == env36008) = true)

theorem identity36008 : scanCanonicalize (H12AffineFastState.compose env36008 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound36008 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,77899,254010,73755,95497,8328,65,245138,115150,17665,10401,119042,180409,256,41460,16464,63189]

theorem envBound36009 : H12AffineFastState.Bounded env36009 := by
  intro p hp
  have h : env36009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36008_36009 : H12AffineEnvironment.transform 17 247994 env36008 = env36009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env36008 == env36009) = true)

def env36010 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247962,1024,32769,77899,253978,73755,95497,8328,65,245138,115150,17665,10369,119042,180377,256,41428,16464,63189]

theorem envBound36010 : H12AffineFastState.Bounded env36010 := by
  intro p hp
  have h : env36010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36009_36010 : H12AffineEnvironment.transform 4 0 env36009 = env36010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36009 == env36010) = true)

theorem identity36010 : scanCanonicalize (H12AffineFastState.compose env36010 (packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound36010 : packedSelected [0,2,3,4,6,7,11,14,15,22,24,26,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env36011 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,21897,65536,131072,204051,1024,21896,77899,210323,73755,95497,8328,65,223259,70727,17665,10369,66699,136464,256,29789,16464,9052]

theorem envBound36011 : H12AffineFastState.Bounded env36011 := by
  intro p hp
  have h : env36011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36010_36011 : H12AffineEnvironment.transform 14 21897 env36010 = env36011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env36010 == env36011) = true)

theorem identity36011 : scanCanonicalize (H12AffineFastState.compose env36011 (packedSelected [1,2,3,4,5,6,7,8,9,11,12,16,17,19,20,27,31,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound36011 : packedSelected [1,2,3,4,5,6,7,8,9,11,12,16,17,19,20,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env36012 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,21897,478,131072,138445,1024,21896,12693,144461,8645,29911,8328,65,158149,5529,17665,10369,1365,136464,256,29789,16464,9052]

theorem envBound36012 : H12AffineFastState.Bounded env36012 := by
  intro p hp
  have h : env36012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36011_36012 : H12AffineEnvironment.transform 15 478 env36011 = env36012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env36011 == env36012) = true)

theorem identity36012 : scanCanonicalize (H12AffineFastState.compose env36012 (packedSelected [1,5,8,16,17,19,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound36012 : packedSelected [1,5,8,16,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env36013 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,468,16384,21897,478,131072,138445,1024,21896,4161,136601,17,21763,348,65,149521,5529,17665,2389,1365,136464,256,21897,16464,648]

theorem envBound36013 : H12AffineFastState.Bounded env36013 := by
  intro p hp
  have h : env36013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36012_36013 : H12AffineEnvironment.transform 12 468 env36012 = env36013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env36012 == env36013) = true)

theorem identity36013 : scanCanonicalize (H12AffineFastState.compose env36013 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound36013 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env36014 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,468,16384,21897,478,16401,23772,1024,21896,4161,21896,17,21763,348,65,2048,5529,17665,2389,1365,21761,256,21897,16464,648]

theorem envBound36014 : H12AffineFastState.Bounded env36014 := by
  intro p hp
  have h : env36014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36013_36014 : H12AffineEnvironment.transform 16 16401 env36013 = env36014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36013 == env36014) = true)

theorem identity36014 : scanCanonicalize (H12AffineFastState.compose env36014 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36014 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36015 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,468,5376,137,478,5393,2524,1024,136,4161,136,17,3,348,65,2048,5529,4097,2389,1365,1,256,137,5456,648]

theorem envBound36015 : H12AffineFastState.Bounded env36015 := by
  intro p hp
  have h : env36015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36014_36015 : H12AffineEnvironment.transform 13 5376 env36014 = env36015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36014 == env36015) = true)

theorem identity36015 : scanCanonicalize (H12AffineFastState.compose env36015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36016 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,349,5376,0,343,5393,2389,1024,1,4161,1,17,3,348,65,2048,5392,4097,2389,1365,1,256,0,5456,513]

theorem envBound36016 : H12AffineFastState.Bounded env36016 := by
  intro p hp
  have h : env36016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36015_36016 : H12AffineEnvironment.transform 6 9 env36015 = env36016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36015 == env36016) = true)

theorem identity36016 : scanCanonicalize (H12AffineFastState.compose env36016 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound36016 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36017 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5205,0,2,5188,2048,1024,1,4161,1,17,3,9,65,2048,5189,4097,2048,1024,1,85,0,5125,513]

theorem envBound36017 : H12AffineFastState.Bounded env36017 := by
  intro p hp
  have h : env36017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36016_36017 : H12AffineEnvironment.transform 7 85 env36016 = env36017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env36016 == env36017) = true)

theorem identity36017 : scanCanonicalize (H12AffineFastState.compose env36017 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36017 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36018 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,8,5125,0,2,5140,2048,1024,1,4113,1,17,3,9,17,2048,5141,4097,2048,1024,1,5,0,5125,513]

theorem envBound36018 : H12AffineFastState.Bounded env36018 := by
  intro p hp
  have h : env36018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36017_36018 : H12AffineEnvironment.transform 5 16 env36017 = env36018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36017 == env36018) = true)

def env36019 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,16,8,1045,0,2,1028,2048,1024,1,1,1,17,3,9,17,2048,1029,17,2048,1024,1,5,0,1045,513]

theorem envBound36019 : H12AffineFastState.Bounded env36019 := by
  intro p hp
  have h : env36019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36018_36019 : H12AffineEnvironment.transform 11 16 env36018 = env36019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36018 == env36019) = true)

theorem identity36019 : scanCanonicalize (H12AffineFastState.compose env36019 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound36019 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36020 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1540,16,8,1045,0,2,1028,1540,1024,1,1,1,17,3,9,17,1540,1029,17,1540,1024,1,5,0,1045,513]

theorem envBound36020 : H12AffineFastState.Bounded env36020 := by
  intro p hp
  have h : env36020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36019_36020 : H12AffineEnvironment.transform 10 1540 env36019 = env36020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env36019 == env36020) = true)

def env36021 : List Nat := [2,4,8,16,0,16,9,5,512,20,528,16,8,1,0,2,16,528,20,1,1,1,17,3,9,17,528,17,17,528,20,1,5,0,1,513]

theorem envBound36021 : H12AffineFastState.Bounded env36021 := by
  intro p hp
  have h : env36021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36020_36021 : H12AffineEnvironment.transform 9 20 env36020 = env36021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36020 == env36021) = true)

theorem identity36021 : scanCanonicalize (H12AffineFastState.compose env36021 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36021 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36022 : List Nat := [2,4,8,10,0,10,9,5,512,14,522,10,8,1,0,2,10,522,14,1,1,1,11,3,9,11,522,11,11,522,14,1,5,0,1,513]

theorem envBound36022 : H12AffineFastState.Bounded env36022 := by
  intro p hp
  have h : env36022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36021_36022 : H12AffineEnvironment.transform 3 10 env36021 = env36022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36021 == env36022) = true)

def leafEnv36022 : List Nat := [2,4,8,10,0,10,9,5,512,14,522,10,8,1,0,2,10,522,14,1,1,1,11,3,14,9,1,11,522,11,11,522,14,1,5,0,4,3,1,513,1,1,0]

def active36022 : List Nat := [0,1,2,8]

def tree36022 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36022 : H12WitnessSearch.Good tree36022 := H12GlobalWitnessIndex.good

theorem leafIdentity36022 : H12AffineFastState.composeSystem env36022 rootObs = leafEnv36022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36022 rootObs == leafEnv36022) = true)

theorem terminalChecked36022 : H12PackedTerminal.terminalCheckFast leafEnv36022 active36022 tree36022 = true := by decide +kernel

def env36023 : List Nat := [2,4,8,16,0,16,9,5,512,21,529,16,8,0,0,2,17,529,21,1,1,1,17,3,9,17,529,16,17,529,21,1,5,0,0,513]

theorem envBound36023 : H12AffineFastState.Bounded env36023 := by
  intro p hp
  have h : env36023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36020_36023 : H12AffineEnvironment.transform 9 21 env36020 = env36023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36020 == env36023) = true)

theorem identity36023 : scanCanonicalize (H12AffineFastState.compose env36023 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36023 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36024 : List Nat := [2,4,8,16,0,16,9,5,16,21,1,16,8,0,0,2,17,1,21,1,1,1,17,3,9,17,1,16,17,1,21,1,5,0,0,17]

theorem envBound36024 : H12AffineFastState.Bounded env36024 := by
  intro p hp
  have h : env36024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36023_36024 : H12AffineEnvironment.transform 8 16 env36023 = env36024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36023 == env36024) = true)

def leafEnv36024 : List Nat := [2,4,8,16,0,16,9,5,16,21,1,16,8,0,0,2,17,1,21,1,1,1,17,3,21,9,1,17,1,16,17,1,21,1,5,0,4,3,0,17,1,1,0]

def active36024 : List Nat := [0,1,2,3]

def tree36024 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36024 : H12WitnessSearch.Good tree36024 := H12GlobalWitnessIndex.good

theorem leafIdentity36024 : H12AffineFastState.composeSystem env36024 rootObs = leafEnv36024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36024 rootObs == leafEnv36024) = true)

theorem terminalChecked36024 : H12PackedTerminal.terminalCheckFast leafEnv36024 active36024 tree36024 = true := by decide +kernel

def env36025 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,17,8,1044,0,2,1029,2048,1024,1,0,1,17,3,9,17,2048,1028,16,2048,1024,1,5,0,1044,513]

theorem envBound36025 : H12AffineFastState.Bounded env36025 := by
  intro p hp
  have h : env36025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36018_36025 : H12AffineEnvironment.transform 11 17 env36018 = env36025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env36018 == env36025) = true)

theorem identity36025 : scanCanonicalize (H12AffineFastState.compose env36025 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound36025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36026 : List Nat := [2,4,8,16,0,16,9,5,512,1024,529,17,8,1044,0,2,1029,529,1024,1,0,1,17,3,9,17,529,1028,16,529,1024,1,5,0,1044,513]

theorem envBound36026 : H12AffineFastState.Bounded env36026 := by
  intro p hp
  have h : env36026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36025_36026 : H12AffineEnvironment.transform 10 529 env36025 = env36026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env36025 == env36026) = true)

def env36027 : List Nat := [2,4,8,16,0,16,9,5,512,20,529,17,8,0,0,2,17,529,20,1,0,1,17,3,9,17,529,16,16,529,20,1,5,0,0,513]

theorem envBound36027 : H12AffineFastState.Bounded env36027 := by
  intro p hp
  have h : env36027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36026_36027 : H12AffineEnvironment.transform 9 20 env36026 = env36027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36026 == env36027) = true)

theorem identity36027 : scanCanonicalize (H12AffineFastState.compose env36027 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36027 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36028 : List Nat := [2,4,8,11,0,11,9,5,512,15,522,10,8,0,0,2,10,522,15,1,0,1,10,3,9,10,522,11,11,522,15,1,5,0,0,513]

theorem envBound36028 : H12AffineFastState.Bounded env36028 := by
  intro p hp
  have h : env36028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36027_36028 : H12AffineEnvironment.transform 3 11 env36027 = env36028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36027 == env36028) = true)

def leafEnv36028 : List Nat := [2,4,8,11,0,11,9,5,512,15,522,10,8,0,0,2,10,522,15,1,0,1,10,3,15,9,1,10,522,11,11,522,15,1,5,0,4,3,0,513,1,0,0]

end H12CloudChart0