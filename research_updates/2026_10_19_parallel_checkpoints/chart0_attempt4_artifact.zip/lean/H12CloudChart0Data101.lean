import H12CloudChart0Data100

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound25567 : H12AffineFastState.Bounded env25567 := by
  intro p hp
  have h : env25567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25566_25567 : H12AffineEnvironment.transform 6 9 env25566 = env25567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25566 == env25567) = true)

def env25568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1024,8661,2097152,33,8388608,10563673,8328,64,2239501,8393984,10485841,8526964,2102684,8388793,256,32,5457,2175562]

theorem envBound25568 : H12AffineFastState.Bounded env25568 := by
  intro p hp
  have h : env25568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25541_25568 : H12AffineEnvironment.transform 17 10401 env25541 = env25568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env25541 == env25568) = true)

theorem identity25568 : scanCanonicalize (H12AffineFastState.compose env25568 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 2175067) := by decide +kernel

theorem selectedBound25568 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1024,8661,2097152,33,2175067,2,8328,64,2239501,2172251,77834,2305071,2102684,2175202,256,32,5457,2175562]

theorem envBound25569 : H12AffineFastState.Bounded env25569 := by
  intro p hp
  have h : env25569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25568_25569 : H12AffineEnvironment.transform 22 2175067 env25568 = env25569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2175067 env25568 == env25569) = true)

theorem identity25569 : scanCanonicalize (H12AffineFastState.compose env25569 (packedSelected [1,11,18,19,23,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound25569 : packedSelected [1,11,18,19,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env25570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1024,8661,4161,33,73754,2,8328,64,146508,79130,77834,212078,1501,73891,256,32,5457,74251]

theorem envBound25570 : H12AffineFastState.Bounded env25570 := by
  intro p hp
  have h : env25570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25569_25570 : H12AffineEnvironment.transform 20 4161 env25569 = env25570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25569 == env25570) = true)

theorem identity25570 : scanCanonicalize (H12AffineFastState.compose env25570 (packedSelected [0,2,3,4,9,10,14,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 295) := by decide +kernel

theorem selectedBound25570 : packedSelected [0,2,3,4,9,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env25571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,295,131072,10401,1024,8661,4161,33,8509,2,8328,64,146508,13373,12589,146761,1501,8580,256,32,5457,9004]

theorem envBound25571 : H12AffineFastState.Bounded env25571 := by
  intro p hp
  have h : env25571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25570_25571 : H12AffineEnvironment.transform 15 295 env25570 = env25571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 295 env25570 == env25571) = true)

theorem identity25571 : scanCanonicalize (H12AffineFastState.compose env25571 (packedSelected [1,4,5,6,8,14,16,19,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 13373) := by decide +kernel

theorem selectedBound25571 : packedSelected [1,4,5,6,8,14,16,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env25572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,295,13373,10401,1024,8661,4161,33,8509,2,8328,64,2161,13373,12589,2420,1501,8580,256,32,5457,9004]

theorem envBound25572 : H12AffineFastState.Bounded env25572 := by
  intro p hp
  have h : env25572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25571_25572 : H12AffineEnvironment.transform 16 13373 env25571 = env25572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13373 env25571 == env25572) = true)

theorem identity25572 : scanCanonicalize (H12AffineFastState.compose env25572 (packedSelected [1,3,4,5,6,8,10,14,16,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound25572 : packedSelected [1,3,4,5,6,8,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env25573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,301,5377,249,295,5392,2444,1024,248,4161,33,16,2,421,64,2161,5392,4096,2420,1501,169,256,32,5457,513]

theorem envBound25573 : H12AffineFastState.Bounded env25573 := by
  intro p hp
  have h : env25573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25572_25573 : H12AffineEnvironment.transform 12 301 env25572 = env25573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env25572 == env25573) = true)

theorem identity25573 : scanCanonicalize (H12AffineFastState.compose env25573 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound25573 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25574 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,301,5377,33,295,5392,2388,1024,32,4161,33,16,2,381,64,2161,5392,4096,2420,1285,113,256,32,5457,513]

theorem envBound25574 : H12AffineFastState.Bounded env25574 := by
  intro p hp
  have h : env25574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25573_25574 : H12AffineEnvironment.transform 6 88 env25573 = env25574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env25573 == env25574) = true)

theorem identity25574 : scanCanonicalize (H12AffineFastState.compose env25574 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound25574 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25575 : List Nat := [2,4,8,16,32,64,88,256,512,101,2048,4096,301,4452,33,295,4469,2388,101,32,4161,33,16,2,381,64,2161,4469,4096,2420,352,113,256,32,4404,513]

theorem envBound25575 : H12AffineFastState.Bounded env25575 := by
  intro p hp
  have h : env25575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25574_25575 : H12AffineEnvironment.transform 9 101 env25574 = env25575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env25574 == env25575) = true)

theorem identity25575 : scanCanonicalize (H12AffineFastState.compose env25575 (packedSelected [3,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound25575 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env25576 : List Nat := [2,4,8,16,32,64,88,116,512,101,2048,4096,89,4112,33,83,4097,2080,101,32,4161,33,16,2,9,64,2161,4097,4096,2048,20,113,116,32,4160,513]

theorem envBound25576 : H12AffineFastState.Bounded env25576 := by
  intro p hp
  have h : env25576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25575_25576 : H12AffineEnvironment.transform 7 116 env25575 = env25576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env25575 == env25576) = true)

theorem identity25576 : scanCanonicalize (H12AffineFastState.compose env25576 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound25576 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env25577 : List Nat := [2,4,8,16,32,64,88,116,512,101,2048,2576,89,2560,33,83,2577,2080,101,32,2641,33,16,2,9,64,2161,2577,2576,2048,20,113,116,32,2640,513]

theorem envBound25577 : H12AffineFastState.Bounded env25577 := by
  intro p hp
  have h : env25577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25576_25577 : H12AffineEnvironment.transform 11 2576 env25576 = env25577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env25576 == env25577) = true)

theorem identity25577 : scanCanonicalize (H12AffineFastState.compose env25577 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound25577 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25578 : List Nat := [2,4,8,16,32,64,88,116,91,101,2048,2123,89,2139,33,83,2122,2080,101,32,2058,33,16,2,9,64,2161,2122,2123,2048,20,113,116,32,2059,90]

theorem envBound25578 : H12AffineFastState.Bounded env25578 := by
  intro p hp
  have h : env25578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25577_25578 : H12AffineEnvironment.transform 8 91 env25577 = env25578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env25577 == env25578) = true)

theorem identity25578 : scanCanonicalize (H12AffineFastState.compose env25578 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25578 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env25579 : List Nat := [2,4,8,16,32,16,8,36,11,53,2048,2075,9,2059,33,3,2074,2080,53,32,2058,33,16,2,9,16,2081,2074,2075,2048,20,33,36,32,2059,10]

theorem envBound25579 : H12AffineFastState.Bounded env25579 := by
  intro p hp
  have h : env25579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25578_25579 : H12AffineEnvironment.transform 5 16 env25578 = env25579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25578 == env25579) = true)

theorem identity25579 : scanCanonicalize (H12AffineFastState.compose env25579 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound25579 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25580 : List Nat := [2,4,8,16,32,16,8,36,11,53,43,48,9,32,33,3,49,11,53,32,33,33,16,2,9,16,10,49,48,43,20,33,36,32,32,10]

theorem envBound25580 : H12AffineFastState.Bounded env25580 := by
  intro p hp
  have h : env25580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25579_25580 : H12AffineEnvironment.transform 10 43 env25579 = env25580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env25579 == env25580) = true)

theorem identity25580 : scanCanonicalize (H12AffineFastState.compose env25580 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25580 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25581 : List Nat := [2,4,8,0,32,0,8,36,11,37,43,32,9,32,33,3,33,11,37,32,33,33,0,2,9,0,10,33,32,43,4,33,36,32,32,10]

theorem envBound25581 : H12AffineFastState.Bounded env25581 := by
  intro p hp
  have h : env25581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25580_25581 : H12AffineEnvironment.transform 3 0 env25580 = env25581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25580 == env25581) = true)

theorem identity25581 : scanCanonicalize (H12AffineFastState.compose env25581 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound25581 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25582 : List Nat := [2,4,8,0,11,0,8,15,11,14,0,11,9,11,10,3,10,11,14,11,10,10,0,2,9,0,10,10,11,0,4,10,15,11,11,10]

theorem envBound25582 : H12AffineFastState.Bounded env25582 := by
  intro p hp
  have h : env25582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25581_25582 : H12AffineEnvironment.transform 4 11 env25581 = env25582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env25581 == env25582) = true)

def env25583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,8388608,10577240,8328,64,2259213,8393984,10507600,8795349,2102684,8661017,256,21793,16464,2175562]

theorem envBound25583 : H12AffineFastState.Bounded env25583 := by
  intro p hp
  have h : env25583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25507_25583 : H12AffineEnvironment.transform 21 272513 env25507 = env25583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env25507 == env25583) = true)

theorem identity25583 : scanCanonicalize (H12AffineFastState.compose env25583 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound25583 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,272513,16,2188616,8328,64,2259213,5392,2118976,406725,2102684,272393,256,21793,16464,2175562]

theorem envBound25584 : H12AffineFastState.Bounded env25584 := by
  intro p hp
  have h : env25584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25583_25584 : H12AffineEnvironment.transform 22 16 env25583 = env25584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env25583 == env25584) = true)

def env25585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,2097152,272513,16,2175048,8328,64,2239501,5392,2097216,406725,2102684,272393,256,33,5456,2175562]

theorem envBound25585 : H12AffineFastState.Bounded env25585 := by
  intro p hp
  have h : env25585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25584_25585 : H12AffineEnvironment.transform 13 5376 env25584 = env25585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25584 == env25585) = true)

theorem identity25585 : scanCanonicalize (H12AffineFastState.compose env25585 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound25585 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,78018,272513,16,138,8328,64,203983,5392,77954,406725,75102,272393,256,33,5456,648]

theorem envBound25586 : H12AffineFastState.Bounded env25586 := by
  intro p hp
  have h : env25586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25585_25586 : H12AffineEnvironment.transform 20 78018 env25585 = env25586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env25585 == env25586) = true)

theorem identity25586 : scanCanonicalize (H12AffineFastState.compose env25586 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 212031) := by decide +kernel

theorem selectedBound25586 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env25587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212031,1024,8660,78018,201918,16,138,8328,64,203983,5392,77954,67834,75102,201782,256,33,5456,648]

theorem envBound25587 : H12AffineFastState.Bounded env25587 := by
  intro p hp
  have h : env25587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25586_25587 : H12AffineEnvironment.transform 17 212031 env25586 = env25587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212031 env25586 == env25587) = true)

theorem identity25587 : scanCanonicalize (H12AffineFastState.compose env25587 (packedSelected [1,3,4,8,9,10,11,16,19,20,23,24,31] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25587 : packedSelected [1,3,4,8,9,10,11,16,19,20,23,24,31] rootPS < 2^1333 := by decide +kernel

def env25588 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,65536,131072,212031,1024,8580,77970,201918,16,138,8328,16,203935,5392,77954,67754,75022,201782,256,33,5376,648]

theorem envBound25588 : H12AffineFastState.Bounded env25588 := by
  intro p hp
  have h : env25588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25587_25588 : H12AffineEnvironment.transform 5 16 env25587 = env25588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25587 == env25588) = true)

theorem identity25588 : scanCanonicalize (H12AffineFastState.compose env25588 (packedSelected [2,6,9,10,11,12,15,16,18,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound25588 : packedSelected [2,6,9,10,11,12,15,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env25589 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,8322,131072,138429,1024,8580,4112,144444,16,138,8328,16,146461,5392,4096,10280,1420,144564,256,33,5376,648]

theorem envBound25589 : H12AffineFastState.Bounded env25589 := by
  intro p hp
  have h : env25589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25588_25589 : H12AffineEnvironment.transform 15 8322 env25588 = env25589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env25588 == env25589) = true)

theorem identity25589 : scanCanonicalize (H12AffineFastState.compose env25589 (packedSelected [4,6,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 13372) := by decide +kernel

theorem selectedBound25589 : packedSelected [4,6,9,16] rootPS < 2^1333 := by decide +kernel

def env25590 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,8322,13372,10369,1024,8580,4112,0,16,138,8328,16,2081,5392,4096,10280,1420,136,256,33,5376,648]

theorem envBound25590 : H12AffineFastState.Bounded env25590 := by
  intro p hp
  have h : env25590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25589_25590 : H12AffineEnvironment.transform 16 13372 env25589 = env25590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13372 env25589 == env25590) = true)

theorem identity25590 : scanCanonicalize (H12AffineFastState.compose env25590 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25590 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env25591 : List Nat := [2,4,8,16,1,16,128,256,512,1024,2048,4096,8192,5376,8581,8322,13341,10369,1024,8580,4112,0,16,138,8328,16,2048,5392,4096,10249,1420,136,256,0,5376,648]

theorem envBound25591 : H12AffineFastState.Bounded env25591 := by
  intro p hp
  have h : env25591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25590_25591 : H12AffineEnvironment.transform 4 1 env25590 = env25591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25590 == env25591) = true)

theorem identity25591 : scanCanonicalize (H12AffineFastState.compose env25591 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25591 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25592 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,13341,10249,1024,8460,4112,0,16,2,8192,16,2048,5392,4096,10249,1284,0,256,0,5376,512]

theorem envBound25592 : H12AffineFastState.Bounded env25592 := by
  intro p hp
  have h : env25592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25591_25592 : H12AffineEnvironment.transform 6 8 env25591 = env25592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25591 == env25592) = true)

theorem identity25592 : scanCanonicalize (H12AffineFastState.compose env25592 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound25592 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25593 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,9,5376,260,3,5140,2048,1024,261,4112,0,16,2,9,16,2048,5392,4096,2048,1284,0,256,0,5376,512]

theorem envBound25593 : H12AffineFastState.Bounded env25593 := by
  intro p hp
  have h : env25593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25592_25593 : H12AffineEnvironment.transform 12 9 env25592 = env25593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env25592 == env25593) = true)

theorem identity25593 : scanCanonicalize (H12AffineFastState.compose env25593 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25593 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env25594 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,9,4112,260,3,4356,2048,272,261,4112,0,16,2,9,16,2048,4096,4096,2048,20,0,256,0,4112,512]

theorem envBound25594 : H12AffineFastState.Bounded env25594 := by
  intro p hp
  have h : env25594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25593_25594 : H12AffineEnvironment.transform 9 272 env25593 = env25594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25593 == env25594) = true)

theorem identity25594 : scanCanonicalize (H12AffineFastState.compose env25594 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound25594 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25595 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,4096,9,4112,0,3,4096,2048,20,1,4112,0,16,2,9,16,2048,4096,4096,2048,20,0,4,0,4112,512]

theorem envBound25595 : H12AffineFastState.Bounded env25595 := by
  intro p hp
  have h : env25595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25594_25595 : H12AffineEnvironment.transform 7 4 env25594 = env25595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env25594 == env25595) = true)

theorem identity25595 : scanCanonicalize (H12AffineFastState.compose env25595 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25596 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,2064,9,2048,0,3,2064,2048,20,1,2048,0,16,2,9,16,2048,2064,2064,2048,20,0,4,0,2048,512]

theorem envBound25596 : H12AffineFastState.Bounded env25596 := by
  intro p hp
  have h : env25596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25595_25596 : H12AffineEnvironment.transform 11 2064 env25595 = env25596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env25595 == env25596) = true)

theorem identity25596 : scanCanonicalize (H12AffineFastState.compose env25596 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound25596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25597 : List Nat := [2,4,8,16,1,16,8,4,512,20,20,4,9,20,0,3,4,20,20,1,20,0,16,2,9,16,20,4,4,20,20,0,4,0,20,512]

theorem envBound25597 : H12AffineFastState.Bounded env25597 := by
  intro p hp
  have h : env25597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25596_25597 : H12AffineEnvironment.transform 10 20 env25596 = env25597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env25596 == env25597) = true)

theorem identity25597 : scanCanonicalize (H12AffineFastState.compose env25597 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound25597 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25598 : List Nat := [2,4,8,5,1,5,8,4,512,1,1,4,9,1,0,3,4,1,1,1,1,0,5,2,9,5,1,4,4,1,1,0,4,0,1,512]

theorem envBound25598 : H12AffineFastState.Bounded env25598 := by
  intro p hp
  have h : env25598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25597_25598 : H12AffineEnvironment.transform 3 5 env25597 = env25598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25597 == env25598) = true)

def env25599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,2097152,272513,16,2175049,8328,64,2239500,5392,2097217,406725,2102684,272393,256,32,5457,2175562]

theorem envBound25599 : H12AffineFastState.Bounded env25599 := by
  intro p hp
  have h : env25599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25584_25599 : H12AffineEnvironment.transform 13 5377 env25584 = env25599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25584 == env25599) = true)

theorem identity25599 : scanCanonicalize (H12AffineFastState.compose env25599 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound25599 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,77899,272513,16,2,8328,64,203847,5392,77834,406725,75223,272393,256,32,5457,513]

theorem envBound25600 : H12AffineFastState.Bounded env25600 := by
  intro p hp
  have h : env25600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25599_25600 : H12AffineEnvironment.transform 20 77899 env25599 = env25600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env25599 == env25600) = true)

def env25601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,77899,272393,16,2,8192,64,203847,5392,77834,406605,75103,272393,256,32,5457,513]

theorem envBound25601 : H12AffineFastState.Bounded env25601 := by
  intro p hp
  have h : env25601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25600_25601 : H12AffineEnvironment.transform 6 8 env25600 = env25601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25600 == env25601) = true)

theorem identity25601 : scanCanonicalize (H12AffineFastState.compose env25601 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound25601 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9498,131072,262144,1024,8541,5457,272393,16,2,8192,64,145757,5392,5392,406605,69,272393,256,32,5457,513]

theorem envBound25602 : H12AffineFastState.Bounded env25602 := by
  intro p hp
  have h : env25602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25601_25602 : H12AffineEnvironment.transform 15 9498 env25601 = env25602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env25601 == env25602) = true)

theorem identity25602 : scanCanonicalize (H12AffineFastState.compose env25602 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound25602 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env25603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9498,4096,262144,1024,8541,5457,272393,16,2,8192,64,10589,5392,5392,271437,69,272393,256,32,5457,513]

theorem envBound25603 : H12AffineFastState.Bounded env25603 := by
  intro p hp
  have h : env25603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25602_25603 : H12AffineEnvironment.transform 16 4096 env25602 = env25603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env25602 == env25603) = true)

theorem identity25603 : scanCanonicalize (H12AffineFastState.compose env25603 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 11577) := by decide +kernel

theorem selectedBound25603 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env25604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,9498,4096,11577,1024,8541,5457,1328,16,2,8192,64,10589,5392,5392,2420,69,1328,256,32,5457,513]

theorem envBound25604 : H12AffineFastState.Bounded env25604 := by
  intro p hp
  have h : env25604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25603_25604 : H12AffineEnvironment.transform 17 11577 env25603 = env25604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11577 env25603 == env25604) = true)

theorem identity25604 : scanCanonicalize (H12AffineFastState.compose env25604 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound25604 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env25605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,5377,1125,35,4096,2048,1024,1124,5457,1328,16,2,1337,64,3172,5392,5392,2420,69,1328,256,32,5457,513]

theorem envBound25605 : H12AffineFastState.Bounded env25605 := by
  intro p hp
  have h : env25605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25604_25605 : H12AffineEnvironment.transform 12 1337 env25604 = env25605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env25604 == env25605) = true)

theorem identity25605 : scanCanonicalize (H12AffineFastState.compose env25605 (packedSelected [1,3,5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound25605 : packedSelected [1,3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env25606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,1337,2341,1125,35,3108,2048,1024,1124,2421,1328,16,2,1337,64,3172,2356,2356,2420,69,1328,256,32,2421,513]

theorem envBound25606 : H12AffineFastState.Bounded env25606 := by
  intro p hp
  have h : env25606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25605_25606 : H12AffineEnvironment.transform 11 3108 env25605 = env25606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env25605 == env25606) = true)

theorem identity25606 : scanCanonicalize (H12AffineFastState.compose env25606 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25606 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env25607 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3108,1052,2048,1125,35,3108,2048,1024,1124,2128,1045,16,2,1052,64,3172,2065,2065,2129,69,1045,37,32,2128,513]

theorem envBound25607 : H12AffineFastState.Bounded env25607 := by
  intro p hp
  have h : env25607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25606_25607 : H12AffineEnvironment.transform 7 37 env25606 = env25607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25606 == env25607) = true)

theorem identity25607 : scanCanonicalize (H12AffineFastState.compose env25607 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25607 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env25608 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3108,1052,2048,1076,35,3108,2048,1024,1077,2049,1045,16,2,1052,17,3125,2065,2065,2048,20,1045,37,32,2049,513]

theorem envBound25608 : H12AffineFastState.Bounded env25608 := by
  intro p hp
  have h : env25608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25607_25608 : H12AffineEnvironment.transform 5 17 env25607 = env25608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25607 == env25608) = true)

theorem identity25608 : scanCanonicalize (H12AffineFastState.compose env25608 (packedSelected [3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound25608 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env25609 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1061,1,1052,1061,1076,35,1,1061,1024,1077,1060,1045,16,2,1052,17,16,1076,1076,1061,20,1045,37,32,1060,513]

theorem envBound25609 : H12AffineFastState.Bounded env25609 := by
  intro p hp
  have h : env25609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25608_25609 : H12AffineEnvironment.transform 10 1061 env25608 = env25609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env25608 == env25609) = true)

theorem identity25609 : scanCanonicalize (H12AffineFastState.compose env25609 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound25609 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env25610 : List Nat := [2,4,8,16,32,17,8,37,512,21,48,1,9,48,33,35,1,48,21,32,49,0,16,2,9,17,16,33,33,48,20,0,37,32,49,513]

theorem envBound25610 : H12AffineFastState.Bounded env25610 := by
  intro p hp
  have h : env25610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25609_25610 : H12AffineEnvironment.transform 9 21 env25609 = env25610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env25609 == env25610) = true)

theorem identity25610 : scanCanonicalize (H12AffineFastState.compose env25610 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25610 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env25611 : List Nat := [2,4,8,1,32,0,8,37,512,4,33,1,9,33,33,35,1,33,4,32,32,0,1,2,9,0,1,33,33,33,5,0,37,32,32,513]

theorem envBound25611 : H12AffineFastState.Bounded env25611 := by
  intro p hp
  have h : env25611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25610_25611 : H12AffineEnvironment.transform 3 1 env25610 = env25611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25610 == env25611) = true)

theorem identity25611 : scanCanonicalize (H12AffineFastState.compose env25611 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25611 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25612 : List Nat := [2,4,8,1,1,0,8,4,512,4,0,1,9,0,0,2,1,0,4,1,1,0,1,2,9,0,1,0,0,0,5,0,4,1,1,513]

theorem envBound25612 : H12AffineFastState.Bounded env25612 := by
  intro p hp
  have h : env25612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25611_25612 : H12AffineEnvironment.transform 4 1 env25611 = env25612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25611 == env25612) = true)

theorem identity25612 : scanCanonicalize (H12AffineFastState.compose env25612 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25612 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25613 : List Nat := [2,4,8,1,1,0,8,4,0,4,0,1,9,0,0,2,1,0,4,1,1,0,1,2,9,0,1,0,0,0,5,0,4,1,1,1]

theorem envBound25613 : H12AffineFastState.Bounded env25613 := by
  intro p hp
  have h : env25613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25612_25613 : H12AffineEnvironment.transform 8 0 env25612 = env25613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25612 == env25613) = true)

def env25614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77899,272392,16,2,8193,64,203847,5392,77834,406604,75102,272393,256,32,5457,513]

theorem envBound25614 : H12AffineFastState.Bounded env25614 := by
  intro p hp
  have h : env25614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25600_25614 : H12AffineEnvironment.transform 6 9 env25600 = env25614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25600 == env25614) = true)

theorem identity25614 : scanCanonicalize (H12AffineFastState.compose env25614 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound25614 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env25615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,70726,262144,1024,8540,77899,272392,16,2,8193,64,2049,5392,77834,335882,75102,272393,256,32,5457,513]

theorem envBound25615 : H12AffineFastState.Bounded env25615 := by
  intro p hp
  have h : env25615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25614_25615 : H12AffineEnvironment.transform 16 70726 env25614 = env25615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env25614 == env25615) = true)

theorem identity25615 : scanCanonicalize (H12AffineFastState.compose env25615 (packedSelected [0,1,4,5,7,8,9,14,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound25615 : packedSelected [0,1,4,5,7,8,9,14,18,23,24] rootPS < 2^1333 := by decide +kernel

def env25616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,70726,67699,1024,8540,77899,73851,16,2,8193,64,2049,5392,77834,10361,75102,73850,256,32,5457,513]

theorem envBound25616 : H12AffineFastState.Bounded env25616 := by
  intro p hp
  have h : env25616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25615_25616 : H12AffineEnvironment.transform 17 67699 env25615 = env25616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env25615 == env25616) = true)

theorem identity25616 : scanCanonicalize (H12AffineFastState.compose env25616 (packedSelected [18,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25616 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env25617 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,65536,70679,67618,1024,8461,77850,73770,16,2,8193,17,2049,5392,77834,10280,75023,73771,256,32,5376,513]

theorem envBound25617 : H12AffineFastState.Bounded env25617 := by
  intro p hp
  have h : env25617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25616_25617 : H12AffineEnvironment.transform 5 17 env25616 = env25617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25616 == env25617) = true)

theorem identity25617 : scanCanonicalize (H12AffineFastState.compose env25617 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound25617 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env25618 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,6428,5377,6160,65536,70679,67618,1024,6161,67846,71990,16,2,6429,17,2049,5392,67862,4404,72723,71991,256,32,5376,513]

theorem envBound25618 : H12AffineFastState.Bounded env25618 := by
  intro p hp
  have h : env25618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25617_25618 : H12AffineEnvironment.transform 12 6428 env25617 = env25618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env25617 == env25618) = true)

theorem identity25618 : scanCanonicalize (H12AffineFastState.compose env25618 (packedSelected [1,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 4146) := by decide +kernel

theorem selectedBound25618 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env25619 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,6428,5377,6160,4146,1061,6160,1024,6161,6452,2308,16,2,6429,17,2049,5392,6436,4404,3105,2309,256,32,5376,513]

theorem envBound25619 : H12AffineFastState.Bounded env25619 := by
  intro p hp
  have h : env25619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25618_25619 : H12AffineEnvironment.transform 15 4146 env25618 = env25619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4146 env25618 == env25619) = true)

def env25620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound25620 : H12AffineFastState.Bounded env25620 := by
  intro p hp
  have h : env25620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25438_25620 : H12AffineEnvironment.transform 18 1025 env25438 = env25620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25438 == env25620) = true)

theorem identity25620 : scanCanonicalize (H12AffineFastState.compose env25620 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 165337) := by decide +kernel

theorem selectedBound25620 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,8388608,16777216,8328,64,29868032,16974165,8573065,8830977,25265169,21225497,257,25379188,25403601,25207750]

theorem envBound25621 : H12AffineFastState.Bounded env25621 := by
  intro p hp
  have h : env25621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25620_25621 : H12AffineEnvironment.transform 20 165337 env25620 = env25621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env25620 == env25621) = true)

def env25622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,8388608,8590420,8328,64,4510804,8393985,8573065,8830977,168005,12645453,257,21792,46213,243602]

theorem envBound25622 : H12AffineFastState.Bounded env25622 := by
  intro p hp
  have h : env25622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25621_25622 : H12AffineEnvironment.transform 23 8590420 env25621 = env25622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590420 env25621 == env25622) = true)

def env25623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,169352,98780,8328,64,4510804,163977,17665,284041,168005,4350405,257,21792,46213,243602]

theorem envBound25623 : H12AffineFastState.Bounded env25623 := by
  intro p hp
  have h : env25623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25622_25623 : H12AffineEnvironment.transform 22 169352 env25622 = env25623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env25622 == env25623) = true)

def env25624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272512,169352,98780,8328,64,64724,163977,17665,284041,168005,411973,257,21792,46213,243602]

theorem envBound25624 : H12AffineFastState.Bounded env25624 := by
  intro p hp
  have h : env25624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25623_25624 : H12AffineEnvironment.transform 21 272512 env25623 = env25624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env25623 == env25624) = true)

def env25625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272392,169216,98644,8192,64,64604,163841,17665,283905,168005,411973,257,21792,46093,243482]

theorem envBound25625 : H12AffineFastState.Bounded env25625 := by
  intro p hp
  have h : env25625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25624_25625 : H12AffineEnvironment.transform 6 8 env25624 = env25625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25624 == env25625) = true)

theorem identity25625 : scanCanonicalize (H12AffineFastState.compose env25625 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound25625 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env25626 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,77898,272392,73755,98644,8192,64,64604,79130,17665,283905,75102,392286,257,21792,46093,513]

theorem envBound25626 : H12AffineFastState.Bounded env25626 := by
  intro p hp
  have h : env25626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25625_25626 : H12AffineEnvironment.transform 16 111899 env25625 = env25626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env25625 == env25626) = true)

theorem identity25626 : scanCanonicalize (H12AffineFastState.compose env25626 (packedSelected [0,2,3,4,6,9,10,11,17,20,24,26,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound25626 : packedSelected [0,2,3,4,6,9,10,11,17,20,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env25627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,67618,1025,32769,77898,73770,73755,98644,8192,64,64604,79130,17665,89379,75102,62588,257,21792,46093,513]

theorem envBound25627 : H12AffineFastState.Bounded env25627 := by
  intro p hp
  have h : env25627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25626_25627 : H12AffineEnvironment.transform 17 67618 env25626 = env25627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env25626 == env25627) = true)

theorem identity25627 : scanCanonicalize (H12AffineFastState.compose env25627 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25627 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1025,32769,4161,33,16,41311,8192,64,64604,5393,17665,32040,1365,62588,257,21792,46093,513]

theorem envBound25628 : H12AffineFastState.Bounded env25628 := by
  intro p hp
  have h : env25628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25627_25628 : H12AffineEnvironment.transform 15 8203 env25627 = env25628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25627 == env25628) = true)

theorem identity25628 : scanCanonicalize (H12AffineFastState.compose env25628 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound25628 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env25629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8203,5440,10281,1025,81,4161,33,16,8463,8192,64,31756,5393,17665,32040,1365,29740,257,21792,13405,513]

theorem envBound25629 : H12AffineFastState.Bounded env25629 := by
  intro p hp
  have h : env25629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25628_25629 : H12AffineEnvironment.transform 14 80 env25628 = env25629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env25628 == env25629) = true)

def env25630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272393,169217,98645,8193,64,64605,163840,17665,283904,168005,411973,257,21792,46092,243483]

theorem envBound25630 : H12AffineFastState.Bounded env25630 := by
  intro p hp
  have h : env25630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25624_25630 : H12AffineEnvironment.transform 6 9 env25624 = env25630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25624 == env25630) = true)

theorem identity25630 : scanCanonicalize (H12AffineFastState.compose env25630 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound25630 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env25631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,50496,272393,54545,98645,8193,64,64605,49168,17665,283904,53333,264533,257,21792,46092,128779]

theorem envBound25631 : H12AffineFastState.Bounded env25631 := by
  intro p hp
  have h : env25631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25630_25631 : H12AffineEnvironment.transform 16 16400 env25630 = env25631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env25630 == env25631) = true)

def env25632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,262144,1025,21761,4160,272393,17,87125,8193,64,10589,5392,17665,283904,1365,264533,257,21792,24844,74251]

theorem envBound25632 : H12AffineFastState.Bounded env25632 := by
  intro p hp
  have h : env25632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25631_25632 : H12AffineEnvironment.transform 14 21760 env25631 = env25632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env25631 == env25632) = true)

theorem identity25632 : scanCanonicalize (H12AffineFastState.compose env25632 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97407) := by decide +kernel

theorem selectedBound25632 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,16400,97407,1025,21761,4160,87158,17,87125,8193,64,10589,5392,17665,76159,1365,95530,257,21792,24844,74251]

theorem envBound25633 : H12AffineFastState.Bounded env25633 := by
  intro p hp
  have h : env25633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25632_25633 : H12AffineEnvironment.transform 17 97407 env25632 = env25633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97407 env25632 == env25633) = true)

theorem identity25633 : scanCanonicalize (H12AffineFastState.compose env25633 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25633 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,16400,23668,1025,21761,4160,29821,17,29790,8193,64,10589,5392,17665,2420,1365,21793,257,21792,24844,512]

theorem envBound25634 : H12AffineFastState.Bounded env25634 := by
  intro p hp
  have h : env25634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25633_25634 : H12AffineEnvironment.transform 15 8203 env25633 = env25634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25633 == env25634) = true)

theorem identity25634 : scanCanonicalize (H12AffineFastState.compose env25634 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound25634 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,293,8203,5173,2129,1025,292,4160,8280,17,8315,8193,64,10589,5392,4388,2420,1365,260,257,261,13609,512]

theorem envBound25635 : H12AffineFastState.Bounded env25635 := by
  intro p hp
  have h : env25635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25634_25635 : H12AffineEnvironment.transform 13 5157 env25634 = env25635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env25634 == env25635) = true)

theorem identity25635 : scanCanonicalize (H12AffineFastState.compose env25635 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound25635 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env25636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,782,4096,8192,5157,293,8203,5173,863,1025,292,4160,8280,17,8315,8193,64,8787,5392,4388,634,1365,260,257,261,13609,512]

theorem envBound25636 : H12AffineFastState.Bounded env25636 := by
  intro p hp
  have h : env25636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25635_25636 : H12AffineEnvironment.transform 10 782 env25635 = env25636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env25635 == env25636) = true)

theorem identity25636 : scanCanonicalize (H12AffineFastState.compose env25636 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25636 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env25637 : List Nat := [2,4,8,16,32,17,9,256,512,1024,782,4096,8192,5157,293,8203,5173,782,1025,292,4113,8201,17,8234,8193,17,8706,5392,4388,555,1284,260,257,261,13609,512]

theorem envBound25637 : H12AffineFastState.Bounded env25637 := by
  intro p hp
  have h : env25637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25636_25637 : H12AffineEnvironment.transform 5 17 env25636 = env25637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25636 == env25637) = true)

theorem identity25637 : scanCanonicalize (H12AffineFastState.compose env25637 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25637 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env25638 : List Nat := [2,4,8,16,32,17,9,256,512,1024,782,4096,269,5157,293,262,5173,782,1025,292,4113,260,17,295,268,17,783,5392,4388,555,1284,260,257,261,5156,512]

theorem envBound25638 : H12AffineFastState.Bounded env25638 := by
  intro p hp
  have h : env25638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25637_25638 : H12AffineEnvironment.transform 12 269 env25637 = env25638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25637 == env25638) = true)

theorem identity25638 : scanCanonicalize (H12AffineFastState.compose env25638 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound25638 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25639 : List Nat := [2,4,8,16,32,17,9,5,512,1024,523,4096,8,5157,32,3,5173,523,1025,33,4113,1,17,34,9,17,522,5141,4129,555,1025,1,4,0,5156,512]

theorem envBound25639 : H12AffineFastState.Bounded env25639 := by
  intro p hp
  have h : env25639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25638_25639 : H12AffineEnvironment.transform 7 5 env25638 = env25639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env25638 == env25639) = true)

theorem identity25639 : scanCanonicalize (H12AffineFastState.compose env25639 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25639 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env25640 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,4096,8,5124,1,3,5140,523,1025,0,4113,1,17,3,9,17,522,5141,4096,522,1025,1,4,0,5125,512]

theorem envBound25640 : H12AffineFastState.Bounded env25640 := by
  intro p hp
  have h : env25640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25639_25640 : H12AffineEnvironment.transform 4 1 env25639 = env25640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25639 == env25640) = true)

def env25641 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,16,8,1044,1,3,1028,523,1025,0,1,1,17,3,9,17,522,1029,16,522,1025,1,4,0,1045,512]

theorem envBound25641 : H12AffineFastState.Bounded env25641 := by
  intro p hp
  have h : env25641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25640_25641 : H12AffineEnvironment.transform 11 16 env25640 = env25641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25640 == env25641) = true)

theorem identity25641 : scanCanonicalize (H12AffineFastState.compose env25641 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound25641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25642 : List Nat := [2,4,8,16,1,17,9,5,512,1,523,16,8,21,1,3,5,523,0,0,1,1,17,3,9,17,522,4,16,522,0,1,4,0,20,512]

theorem envBound25642 : H12AffineFastState.Bounded env25642 := by
  intro p hp
  have h : env25642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25641_25642 : H12AffineEnvironment.transform 9 1 env25641 = env25642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env25641 == env25642) = true)

def env25643 : List Nat := [2,4,8,4,1,5,9,5,512,1,523,4,8,1,1,3,5,523,0,0,1,1,5,3,9,5,522,4,4,522,0,1,4,0,0,512]

theorem envBound25643 : H12AffineFastState.Bounded env25643 := by
  intro p hp
  have h : env25643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25642_25643 : H12AffineEnvironment.transform 3 4 env25642 = env25643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25642 == env25643) = true)

theorem identity25643 : scanCanonicalize (H12AffineFastState.compose env25643 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound25643 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25644 : List Nat := [2,4,8,4,1,5,9,5,8,1,3,4,8,1,1,3,5,3,0,0,1,1,5,3,9,5,2,4,4,2,0,1,4,0,0,8]

theorem envBound25644 : H12AffineFastState.Bounded env25644 := by
  intro p hp
  have h : env25644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25643_25644 : H12AffineEnvironment.transform 8 8 env25643 = env25644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env25643 == env25644) = true)

def leafEnv25644 : List Nat := [2,4,8,4,1,5,9,5,8,1,3,4,8,1,1,3,5,3,0,0,1,1,5,3,0,9,1,5,2,4,4,2,0,1,4,0,4,2,0,8,1,0,0]

def active25644 : List Nat := [0,1,2]

def tree25644 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25644 : H12WitnessSearch.Good tree25644 := H12GlobalWitnessIndex.good

theorem leafIdentity25644 : H12AffineFastState.composeSystem env25644 rootObs = leafEnv25644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25644 rootObs == leafEnv25644) = true)

theorem terminalChecked25644 : H12PackedTerminal.terminalCheckFast leafEnv25644 active25644 tree25644 = true := by decide +kernel

def env25645 : List Nat := [2,4,8,5,1,4,9,5,512,1,523,5,8,0,1,3,5,523,0,0,1,1,4,3,9,4,522,4,5,522,0,1,4,0,1,512]

theorem envBound25645 : H12AffineFastState.Bounded env25645 := by
  intro p hp
  have h : env25645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25642_25645 : H12AffineEnvironment.transform 3 5 env25642 = env25645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25642 == env25645) = true)

theorem identity25645 : scanCanonicalize (H12AffineFastState.compose env25645 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound25645 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25646 : List Nat := [0,4,8,5,1,4,9,5,512,1,521,5,8,0,1,1,5,521,0,0,1,1,4,1,9,4,520,4,5,520,0,1,4,0,1,512]

theorem envBound25646 : H12AffineFastState.Bounded env25646 := by
  intro p hp
  have h : env25646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25645_25646 : H12AffineEnvironment.transform 0 0 env25645 = env25646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env25645 == env25646) = true)

def leafEnv25646 : List Nat := [0,4,8,5,1,4,9,5,512,1,521,5,8,0,1,1,5,521,0,0,1,1,4,1,0,9,1,4,520,4,5,520,0,1,4,0,4,0,1,512,1,0,0]

def active25646 : List Nat := [1,2,8]

def tree25646 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25646 : H12WitnessSearch.Good tree25646 := H12GlobalWitnessIndex.good

theorem leafIdentity25646 : H12AffineFastState.composeSystem env25646 rootObs = leafEnv25646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25646 rootObs == leafEnv25646) = true)

theorem terminalChecked25646 : H12PackedTerminal.terminalCheckFast leafEnv25646 active25646 tree25646 = true := by decide +kernel

def env25647 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,17,8,1045,1,3,1029,523,1025,0,0,1,17,3,9,17,522,1028,17,522,1025,1,4,0,1044,512]

theorem envBound25647 : H12AffineFastState.Bounded env25647 := by
  intro p hp
  have h : env25647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25640_25647 : H12AffineEnvironment.transform 11 17 env25640 = env25647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25640 == env25647) = true)

theorem identity25647 : scanCanonicalize (H12AffineFastState.compose env25647 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound25647 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25648 : List Nat := [2,4,8,4,1,5,9,5,512,1024,523,5,8,1025,1,3,1029,523,1025,0,0,1,5,3,9,5,522,1028,5,522,1025,1,4,0,1024,512]

theorem envBound25648 : H12AffineFastState.Bounded env25648 := by
  intro p hp
  have h : env25648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25647_25648 : H12AffineEnvironment.transform 3 4 env25647 = env25648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25647 == env25648) = true)

def env25649 : List Nat := [2,4,8,4,1,5,9,5,512,0,523,5,8,1,1,3,5,523,1,0,0,1,5,3,9,5,522,4,5,522,1,1,4,0,0,512]

theorem envBound25649 : H12AffineFastState.Bounded env25649 := by
  intro p hp
  have h : env25649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25648_25649 : H12AffineEnvironment.transform 9 0 env25648 = env25649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env25648 == env25649) = true)

theorem identity25649 : scanCanonicalize (H12AffineFastState.compose env25649 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound25649 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25650 : List Nat := [0,4,8,4,1,5,9,5,512,0,521,5,8,1,1,1,5,521,1,0,0,1,5,1,9,5,520,4,5,520,1,1,4,0,0,512]

theorem envBound25650 : H12AffineFastState.Bounded env25650 := by
  intro p hp
  have h : env25650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25649_25650 : H12AffineEnvironment.transform 0 0 env25649 = env25650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env25649 == env25650) = true)

def leafEnv25650 : List Nat := [0,4,8,4,1,5,9,5,512,0,521,5,8,1,1,1,5,521,1,0,0,1,5,1,1,9,1,5,520,4,5,520,1,1,4,0,4,0,0,512,1,1,0]

def active25650 : List Nat := [1,2,8]

def tree25650 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25650 : H12WitnessSearch.Good tree25650 := H12GlobalWitnessIndex.good

theorem leafIdentity25650 : H12AffineFastState.composeSystem env25650 rootObs = leafEnv25650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25650 rootObs == leafEnv25650) = true)

theorem terminalChecked25650 : H12PackedTerminal.terminalCheckFast leafEnv25650 active25650 tree25650 = true := by decide +kernel

def env25651 : List Nat := [2,4,8,4,1,5,9,5,512,1,523,5,8,0,1,3,4,523,0,0,0,1,5,3,9,5,522,5,5,522,0,1,4,0,1,512]

theorem envBound25651 : H12AffineFastState.Bounded env25651 := by
  intro p hp
  have h : env25651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25648_25651 : H12AffineEnvironment.transform 9 1 env25648 = env25651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env25648 == env25651) = true)

theorem identity25651 : scanCanonicalize (H12AffineFastState.compose env25651 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound25651 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25652 : List Nat := [2,4,8,4,1,5,9,5,9,1,2,5,8,0,1,3,4,2,0,0,0,1,5,3,9,5,3,5,5,3,0,1,4,0,1,9]

theorem envBound25652 : H12AffineFastState.Bounded env25652 := by
  intro p hp
  have h : env25652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25651_25652 : H12AffineEnvironment.transform 8 9 env25651 = env25652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env25651 == env25652) = true)

def leafEnv25652 : List Nat := [2,4,8,4,1,5,9,5,9,1,2,5,8,0,1,3,4,2,0,0,0,1,5,3,0,9,1,5,3,5,5,3,0,1,4,0,4,2,1,9,1,1,0]

def active25652 : List Nat := [0,1,2]

def tree25652 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25652 : H12WitnessSearch.Good tree25652 := H12GlobalWitnessIndex.good

theorem leafIdentity25652 : H12AffineFastState.composeSystem env25652 rootObs = leafEnv25652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25652 rootObs == leafEnv25652) = true)

theorem terminalChecked25652 : H12PackedTerminal.terminalCheckFast leafEnv25652 active25652 tree25652 = true := by decide +kernel

def env25653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1025,21760,4161,272393,16,87124,8193,64,10588,5393,17665,283904,1364,264533,257,21792,24845,74250]

theorem envBound25653 : H12AffineFastState.Bounded env25653 := by
  intro p hp
  have h : env25653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25631_25653 : H12AffineEnvironment.transform 14 21761 env25631 = env25653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env25631 == env25653) = true)

theorem identity25653 : scanCanonicalize (H12AffineFastState.compose env25653 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound25653 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25654 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21591,16400,262144,1025,21760,4161,272393,16,3,8193,64,10588,5393,17665,283904,1364,264533,257,21792,24845,30301]

theorem envBound25654 : H12AffineFastState.Bounded env25654 := by
  intro p hp
  have h : env25654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25653_25654 : H12AffineEnvironment.transform 15 21591 env25653 = env25654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env25653 == env25654) = true)

theorem identity25654 : scanCanonicalize (H12AffineFastState.compose env25654 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound25654 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env25655 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21591,16400,32041,1025,21760,4161,21792,16,3,8193,64,10588,5393,17665,10281,1364,29820,257,21792,24845,30301]

theorem envBound25655 : H12AffineFastState.Bounded env25655 := by
  intro p hp
  have h : env25655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25654_25655 : H12AffineEnvironment.transform 17 32041 env25654 = env25655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env25654 == env25655) = true)

theorem identity25655 : scanCanonicalize (H12AffineFastState.compose env25655 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25655 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env25656 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,21540,21591,16400,31756,1025,21541,4161,21509,16,3,8193,64,10361,5172,17444,10281,1137,29820,36,21509,24616,30301]

theorem envBound25656 : H12AffineFastState.Bounded env25656 := by
  intro p hp
  have h : env25656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25655_25656 : H12AffineEnvironment.transform 7 37 env25655 = env25656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25655 == env25656) = true)

theorem identity25656 : scanCanonicalize (H12AffineFastState.compose env25656 (packedSelected [3,4,5,6,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound25656 : packedSelected [3,4,5,6,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env25657 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,0,115,5172,10280,1025,1,4161,33,16,3,8193,64,10361,5172,4096,10281,1137,8280,36,33,13324,8825]

theorem envBound25657 : H12AffineFastState.Bounded env25657 := by
  intro p hp
  have h : env25657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25656_25657 : H12AffineEnvironment.transform 13 5156 env25656 = env25657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env25656 == env25657) = true)

theorem identity25657 : scanCanonicalize (H12AffineFastState.compose env25657 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25657 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25658 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,8192,4112,0,115,4096,10280,53,1,4161,33,16,3,8193,64,10361,4096,4096,10281,69,8280,36,33,12344,8825]

theorem envBound25658 : H12AffineFastState.Bounded env25658 := by
  intro p hp
  have h : env25658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25657_25658 : H12AffineEnvironment.transform 9 52 env25657 = env25658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25657 == env25658) = true)

theorem identity25658 : scanCanonicalize (H12AffineFastState.compose env25658 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound25658 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25659 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,120,4112,0,115,4096,2128,53,1,4161,33,16,3,121,64,2049,4096,4096,2129,69,32,36,33,4160,513]

theorem envBound25659 : H12AffineFastState.Bounded env25659 := by
  intro p hp
  have h : env25659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25658_25659 : H12AffineEnvironment.transform 12 120 env25658 = env25659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env25658 == env25659) = true)

theorem identity25659 : scanCanonicalize (H12AffineFastState.compose env25659 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25659 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25660 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4112,0,34,4096,2049,53,1,4112,33,16,3,40,17,2049,4096,4096,2048,20,32,36,33,4113,513]

theorem envBound25660 : H12AffineFastState.Bounded env25660 := by
  intro p hp
  have h : env25660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25659_25660 : H12AffineEnvironment.transform 5 17 env25659 = env25660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25659 == env25660) = true)

theorem identity25660 : scanCanonicalize (H12AffineFastState.compose env25660 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound25660 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25661 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,4096,41,4112,0,34,4096,528,53,1,4112,33,16,3,40,17,528,4096,4096,529,20,32,36,33,4113,513]

theorem envBound25661 : H12AffineFastState.Bounded env25661 := by
  intro p hp
  have h : env25661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25660_25661 : H12AffineEnvironment.transform 10 529 env25660 = env25661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env25660 == env25661) = true)

theorem identity25661 : scanCanonicalize (H12AffineFastState.compose env25661 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound25661 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25662 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,27,41,11,0,34,27,528,53,1,11,33,16,3,40,17,528,27,27,529,20,32,36,33,10,513]

theorem envBound25662 : H12AffineFastState.Bounded env25662 := by
  intro p hp
  have h : env25662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25661_25662 : H12AffineEnvironment.transform 11 27 env25661 = env25662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env25661 == env25662) = true)

theorem identity25662 : scanCanonicalize (H12AffineFastState.compose env25662 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound25662 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25663 : List Nat := [2,4,8,16,32,17,9,37,27,52,10,27,41,11,0,34,27,11,53,1,11,33,16,3,40,17,11,27,27,10,20,32,36,33,10,26]

theorem envBound25663 : H12AffineFastState.Bounded env25663 := by
  intro p hp
  have h : env25663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25662_25663 : H12AffineEnvironment.transform 8 27 env25662 = env25663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env25662 == env25663) = true)

def env25664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272513,169352,98780,8328,64,64725,163977,17665,284041,168005,411972,257,21792,46213,243602]

theorem envBound25664 : H12AffineFastState.Bounded env25664 := by
  intro p hp
  have h : env25664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25623_25664 : H12AffineEnvironment.transform 21 272513 env25623 = env25664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env25623 == env25664) = true)

theorem identity25664 : scanCanonicalize (H12AffineFastState.compose env25664 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound25664 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4160,272513,17,98780,8328,64,64725,5392,17665,284041,1500,318685,257,21792,46213,74251]

theorem envBound25665 : H12AffineFastState.Bounded env25665 := by
  intro p hp
  have h : env25665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25664_25665 : H12AffineEnvironment.transform 16 38297 env25664 = env25665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env25664 == env25665) = true)

theorem identity25665 : scanCanonicalize (H12AffineFastState.compose env25665 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25665 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env25666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38297,262144,1025,32769,4160,272513,17,41430,8328,64,64725,5392,17665,284041,1500,318685,257,21792,46213,513]

theorem envBound25666 : H12AffineFastState.Bounded env25666 := by
  intro p hp
  have h : env25666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25665_25666 : H12AffineEnvironment.transform 15 8202 env25665 = env25666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25665 == env25666) = true)

def env25667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,169353,98781,8328,64,4510804,163976,17664,284040,168005,4350404,257,21792,46213,243602]

theorem envBound25667 : H12AffineFastState.Bounded env25667 := by
  intro p hp
  have h : env25667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25622_25667 : H12AffineEnvironment.transform 22 169353 env25622 = env25667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env25622 == env25667) = true)

def env25668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272512,169353,98781,8328,64,64724,163976,17664,284040,168005,411972,257,21792,46213,243602]

theorem envBound25668 : H12AffineFastState.Bounded env25668 := by
  intro p hp
  have h : env25668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25667_25668 : H12AffineEnvironment.transform 21 272512 env25667 = env25668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env25667 == env25668) = true)

theorem identity25668 : scanCanonicalize (H12AffineFastState.compose env25668 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound25668 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,160013,272512,155997,95497,8328,64,2048,160860,17664,284040,156817,411972,257,21792,16465,213830]

theorem envBound25669 : H12AffineFastState.Bounded env25669 := by
  intro p hp
  have h : env25669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25668_25669 : H12AffineEnvironment.transform 14 29908 env25668 = env25669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env25668 == env25669) = true)

def env25670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272513,169353,98781,8328,64,64725,163976,17664,284040,168005,411973,257,21792,46213,243602]

theorem envBound25670 : H12AffineFastState.Bounded env25670 := by
  intro p hp
  have h : env25670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25667_25670 : H12AffineEnvironment.transform 21 272513 env25667 = env25670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env25667 == env25670) = true)

theorem identity25670 : scanCanonicalize (H12AffineFastState.compose env25670 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound25670 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,58517,272513,62661,98781,8328,64,64725,57796,17664,284040,61705,272393,257,21792,46213,120542]

theorem envBound25671 : H12AffineFastState.Bounded env25671 := by
  intro p hp
  have h : env25671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25670_25671 : H12AffineEnvironment.transform 16 24908 env25670 = env25671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env25670 == env25671) = true)

def env25672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10280,1025,32769,58517,169,62661,98781,8328,64,64725,57796,17664,32160,61705,33,257,21792,46213,120542]

theorem envBound25672 : H12AffineFastState.Bounded env25672 := by
  intro p hp
  have h : env25672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25671_25672 : H12AffineEnvironment.transform 17 10280 env25671 = env25672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25671 == env25672) = true)

theorem identity25672 : scanCanonicalize (H12AffineFastState.compose env25672 (packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound25672 : packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env25673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1125,65536,24908,10280,1025,1124,24816,169,28832,67000,8328,64,30896,26017,17664,32160,30060,33,257,21792,12512,86715]

theorem envBound25673 : H12AffineFastState.Bounded env25673 := by
  intro p hp
  have h : env25673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25672_25673 : H12AffineEnvironment.transform 14 1125 env25672 = env25673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env25672 == env25673) = true)

theorem identity25673 : scanCanonicalize (H12AffineFastState.compose env25673 (packedSelected [3,5,8,11,15,18,19,23,26,28,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound25673 : packedSelected [3,5,8,11,15,18,19,23,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env25674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1125,21511,24908,10280,1025,1124,24816,169,28832,20927,8328,64,30896,26017,17664,32160,30060,33,257,21792,12512,1724]

theorem envBound25674 : H12AffineFastState.Bounded env25674 := by
  intro p hp
  have h : env25674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25673_25674 : H12AffineEnvironment.transform 15 21511 env25673 = env25674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env25673 == env25674) = true)

theorem identity25674 : scanCanonicalize (H12AffineFastState.compose env25674 (packedSelected [0,1,2,6,7,8,11,16,17,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound25674 : packedSelected [0,1,2,6,7,8,11,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env25675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,1125,8283,5392,10280,1025,1124,5292,169,1276,9699,8328,64,3308,4605,12636,2556,304,33,257,8572,12512,1724]

theorem envBound25675 : H12AffineFastState.Bounded env25675 := by
  intro p hp
  have h : env25675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25674_25675 : H12AffineEnvironment.transform 13 13404 env25674 = env25675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env25674 == env25675) = true)

theorem identity25675 : scanCanonicalize (H12AffineFastState.compose env25675 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1457) := by decide +kernel

theorem selectedBound25675 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,4589,1125,1514,5392,3481,1025,1124,5292,169,1276,82,1337,64,3308,4605,5357,2556,304,33,257,1229,5457,1724]

theorem envBound25676 : H12AffineFastState.Bounded env25676 := by
  intro p hp
  have h : env25676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25675_25676 : H12AffineEnvironment.transform 12 1457 env25675 = env25676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env25675 == env25676) = true)

theorem identity25676 : scanCanonicalize (H12AffineFastState.compose env25676 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound25676 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env25677 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,241,4589,293,170,4176,2265,321,292,4588,169,444,82,121,64,2476,4605,4525,2556,304,33,257,397,4113,1020]

theorem envBound25677 : H12AffineFastState.Bounded env25677 := by
  intro p hp
  have h : env25677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25676_25677 : H12AffineEnvironment.transform 9 320 env25676 = env25677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env25676 == env25677) = true)

theorem identity25677 : scanCanonicalize (H12AffineFastState.compose env25677 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound25677 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env25678 : List Nat := [2,4,8,16,32,64,128,252,512,188,2048,4096,241,4113,217,170,4176,2265,189,216,4112,169,64,82,121,64,2128,4097,4177,2048,204,33,253,113,4113,512]

theorem envBound25678 : H12AffineFastState.Bounded env25678 := by
  intro p hp
  have h : env25678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25677_25678 : H12AffineEnvironment.transform 7 252 env25677 = env25678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env25677 == env25678) = true)

theorem identity25678 : scanCanonicalize (H12AffineFastState.compose env25678 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2744) := by decide +kernel

theorem selectedBound25678 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env25679 : List Nat := [2,4,8,16,32,64,128,252,512,188,2048,2744,241,2729,217,170,2792,2265,189,216,2728,169,64,82,121,64,2128,2745,2793,2048,204,33,253,113,2729,512]

theorem envBound25679 : H12AffineFastState.Bounded env25679 := by
  intro p hp
  have h : env25679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25678_25679 : H12AffineEnvironment.transform 11 2744 env25678 = env25679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2744 env25678 == env25679) = true)

theorem identity25679 : scanCanonicalize (H12AffineFastState.compose env25679 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25679 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25680 : List Nat := [2,4,8,16,0,64,128,220,512,156,2048,2712,209,2697,217,138,2760,2265,157,216,2696,137,64,82,89,64,2128,2713,2761,2048,204,1,221,81,2697,512]

theorem envBound25680 : H12AffineFastState.Bounded env25680 := by
  intro p hp
  have h : env25680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25679_25680 : H12AffineEnvironment.transform 4 0 env25679 = env25680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25679 == env25680) = true)

theorem identity25680 : scanCanonicalize (H12AffineFastState.compose env25680 (packedSelected [4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 199) := by decide +kernel

theorem selectedBound25680 : packedSelected [4,7,8] rootPS < 2^1333 := by decide +kernel

def env25681 : List Nat := [2,4,8,16,0,64,128,220,199,156,2048,2143,209,2126,217,138,2063,2265,157,216,2127,137,64,82,89,64,2128,2142,2062,2048,204,1,221,81,2126,199]

theorem envBound25681 : H12AffineFastState.Bounded env25681 := by
  intro p hp
  have h : env25681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25680_25681 : H12AffineEnvironment.transform 8 199 env25680 = env25681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 199 env25680 == env25681) = true)

theorem identity25681 : scanCanonicalize (H12AffineFastState.compose env25681 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25681 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25682 : List Nat := [2,4,8,16,0,17,128,141,150,156,2048,2062,128,2079,136,138,2063,2184,157,137,2078,137,17,3,8,17,2049,2063,2062,2048,157,1,140,0,2079,150]

theorem envBound25682 : H12AffineFastState.Bounded env25682 := by
  intro p hp
  have h : env25682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25681_25682 : H12AffineEnvironment.transform 5 17 env25681 = env25682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25681 == env25682) = true)

theorem identity25682 : scanCanonicalize (H12AffineFastState.compose env25682 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25682 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25683 : List Nat := [2,4,8,16,0,17,8,5,30,20,2048,2062,8,2079,0,2,2063,2048,21,1,2078,1,17,3,8,17,2049,2063,2062,2048,21,1,4,0,2079,30]

theorem envBound25683 : H12AffineFastState.Bounded env25683 := by
  intro p hp
  have h : env25683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25682_25683 : H12AffineEnvironment.transform 6 8 env25682 = env25683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25682 == env25683) = true)

theorem identity25683 : scanCanonicalize (H12AffineFastState.compose env25683 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound25683 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25684 : List Nat := [2,4,8,16,0,17,8,5,30,20,30,16,8,1,0,2,17,30,21,1,0,1,17,3,8,17,31,17,16,30,21,1,4,0,1,30]

theorem envBound25684 : H12AffineFastState.Bounded env25684 := by
  intro p hp
  have h : env25684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25683_25684 : H12AffineEnvironment.transform 10 30 env25683 = env25684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env25683 == env25684) = true)

theorem identity25684 : scanCanonicalize (H12AffineFastState.compose env25684 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound25684 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25685 : List Nat := [2,4,8,15,0,14,8,5,1,11,1,15,8,1,0,2,14,1,10,1,0,1,14,3,8,14,0,14,15,1,10,1,4,0,1,1]

theorem envBound25685 : H12AffineFastState.Bounded env25685 := by
  intro p hp
  have h : env25685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25684_25685 : H12AffineEnvironment.transform 3 15 env25684 = env25685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env25684 == env25685) = true)

def env25686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,10281,1025,32769,58517,168,62661,98781,8328,64,64725,57796,17664,32161,61705,32,257,21792,46213,120542]

theorem envBound25686 : H12AffineFastState.Bounded env25686 := by
  intro p hp
  have h : env25686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25671_25686 : H12AffineEnvironment.transform 17 10281 env25671 = env25686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25671 == env25686) = true)

theorem identity25686 : scanCanonicalize (H12AffineFastState.compose env25686 (packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound25686 : packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env25687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10281,1025,8541,17865,168,21913,73857,8328,64,23945,16536,17664,32161,20565,32,257,21792,5593,96130]

theorem envBound25687 : H12AffineFastState.Bounded env25687 := by
  intro p hp
  have h : env25687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25686_25687 : H12AffineEnvironment.transform 14 8540 env25686 = env25687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env25686 == env25687) = true)

theorem identity25687 : scanCanonicalize (H12AffineFastState.compose env25687 (packedSelected [0,1,2,6,7,8,11,18,20,26] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound25687 : packedSelected [0,1,2,6,7,8,11,18,20,26] rootPS < 2^1333 := by decide +kernel

def env25688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,21510,24908,10281,1025,8541,17865,168,21913,29831,8328,64,23945,16536,17664,32161,20565,32,257,21792,5593,9092]

theorem envBound25688 : H12AffineFastState.Bounded env25688 := by
  intro p hp
  have h : env25688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25687_25688 : H12AffineEnvironment.transform 15 21510 env25687 = env25688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env25687 == env25688) = true)

theorem identity25688 : scanCanonicalize (H12AffineFastState.compose env25688 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound25688 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env25689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,398,13508,10281,1025,8541,4161,168,17,8463,8328,64,2049,5392,4232,10281,1501,32,257,168,5593,9092]

theorem envBound25689 : H12AffineFastState.Bounded env25689 := by
  intro p hp
  have h : env25689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25688_25689 : H12AffineEnvironment.transform 13 5512 env25688 = env25689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env25688 == env25689) = true)

theorem identity25689 : scanCanonicalize (H12AffineFastState.compose env25689 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound25689 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5512,217,398,5441,2476,1025,216,4161,168,17,138,269,64,2049,5392,4232,2476,1501,32,257,168,5593,513]

theorem envBound25690 : H12AffineFastState.Bounded env25690 := by
  intro p hp
  have h : env25690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25689_25690 : H12AffineEnvironment.transform 12 389 env25689 = env25690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env25689 == env25690) = true)

theorem identity25690 : scanCanonicalize (H12AffineFastState.compose env25690 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25690 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25691 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5512,136,398,5392,2476,1025,137,4112,168,17,138,269,17,2049,5392,4232,2476,1420,32,257,168,5512,513]

theorem envBound25691 : H12AffineFastState.Bounded env25691 := by
  intro p hp
  have h : env25691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25690_25691 : H12AffineEnvironment.transform 5 17 env25690 = env25691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25690 == env25691) = true)

theorem identity25691 : scanCanonicalize (H12AffineFastState.compose env25691 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25691 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25692 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1025,1,4112,32,17,2,269,17,2049,5392,4096,2340,1284,32,257,32,5376,513]

theorem envBound25692 : H12AffineFastState.Bounded env25692 := by
  intro p hp
  have h : env25692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25691_25692 : H12AffineEnvironment.transform 6 8 env25691 = env25692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25691 == env25692) = true)

theorem identity25692 : scanCanonicalize (H12AffineFastState.compose env25692 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound25692 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25693 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,33,269,1313,0,262,1329,2340,1025,1,49,32,17,2,269,17,2049,1329,33,2340,1284,32,257,32,1313,513]

theorem envBound25693 : H12AffineFastState.Bounded env25693 := by
  intro p hp
  have h : env25693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25692_25693 : H12AffineEnvironment.transform 11 33 env25692 = env25693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env25692 == env25693) = true)

theorem identity25693 : scanCanonicalize (H12AffineFastState.compose env25693 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound25693 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25694 : List Nat := [2,4,8,16,32,17,8,256,277,1024,2048,33,269,1313,0,262,1329,2340,1025,1,49,32,17,2,269,17,2049,1329,33,2340,1284,32,257,32,1313,276]

theorem envBound25694 : H12AffineFastState.Bounded env25694 := by
  intro p hp
  have h : env25694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25693_25694 : H12AffineEnvironment.transform 8 277 env25693 = env25694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env25693 == env25694) = true)

theorem identity25694 : scanCanonicalize (H12AffineFastState.compose env25694 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound25694 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25695 : List Nat := [2,4,8,16,32,17,8,256,277,5,2048,33,269,292,0,262,308,2340,4,1,49,32,17,2,269,17,2049,308,33,2340,257,32,257,32,292,276]

theorem envBound25695 : H12AffineFastState.Bounded env25695 := by
  intro p hp
  have h : env25695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25694_25695 : H12AffineEnvironment.transform 9 5 env25694 = env25695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env25694 == env25695) = true)

theorem identity25695 : scanCanonicalize (H12AffineFastState.compose env25695 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound25695 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25696 : List Nat := [2,4,8,16,32,17,8,52,33,5,2048,33,57,16,0,50,0,2064,4,1,49,32,17,2,57,17,2049,0,33,2064,53,32,53,32,16,32]

theorem envBound25696 : H12AffineFastState.Bounded env25696 := by
  intro p hp
  have h : env25696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25695_25696 : H12AffineEnvironment.transform 7 52 env25695 = env25696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env25695 == env25696) = true)

theorem identity25696 : scanCanonicalize (H12AffineFastState.compose env25696 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25696 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25697 : List Nat := [2,4,8,16,32,17,8,52,33,5,0,33,57,16,0,50,0,16,4,1,49,32,17,2,57,17,1,0,33,16,53,32,53,32,16,32]

theorem envBound25697 : H12AffineFastState.Bounded env25697 := by
  intro p hp
  have h : env25697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25696_25697 : H12AffineEnvironment.transform 10 0 env25696 = env25697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25696 == env25697) = true)

theorem identity25697 : scanCanonicalize (H12AffineFastState.compose env25697 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25697 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25698 : List Nat := [2,4,8,16,17,17,8,5,16,5,0,16,8,16,0,3,0,16,4,1,0,17,17,2,8,17,1,0,16,16,4,17,4,17,16,17]

theorem envBound25698 : H12AffineFastState.Bounded env25698 := by
  intro p hp
  have h : env25698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25697_25698 : H12AffineEnvironment.transform 4 17 env25697 = env25698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25697 == env25698) = true)

def env25699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,8388608,8590421,8328,64,4510805,8393984,8573065,8830977,168004,12645452,257,21793,46212,243603]

theorem envBound25699 : H12AffineFastState.Bounded env25699 := by
  intro p hp
  have h : env25699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25621_25699 : H12AffineEnvironment.transform 23 8590421 env25621 = env25699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590421 env25621 == env25699) = true)

def env25700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,169352,98781,8328,64,4510805,163976,17665,284041,168004,4350404,257,21793,46212,243603]

theorem envBound25700 : H12AffineFastState.Bounded env25700 := by
  intro p hp
  have h : env25700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25699_25700 : H12AffineEnvironment.transform 22 169352 env25699 = env25700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env25699 == env25700) = true)

def env25701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272512,169352,98781,8328,64,64725,163976,17665,284041,168004,411972,257,21793,46212,243603]

theorem envBound25701 : H12AffineFastState.Bounded env25701 := by
  intro p hp
  have h : env25701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25700_25701 : H12AffineEnvironment.transform 21 272512 env25700 = env25701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env25700 == env25701) = true)

theorem identity25701 : scanCanonicalize (H12AffineFastState.compose env25701 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound25701 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115870,272512,120015,98781,8328,64,64725,115151,17665,284041,119043,329731,257,21793,46212,63188]

theorem envBound25702 : H12AffineFastState.Bounded env25702 := by
  intro p hp
  have h : env25702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25701_25702 : H12AffineEnvironment.transform 16 82247 env25701 = env25702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env25701 == env25702) = true)

def env25703 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115870,272512,119967,98701,8328,16,64645,115103,17665,284041,119043,329731,257,21793,46212,63108]

theorem envBound25703 : H12AffineFastState.Bounded env25703 := by
  intro p hp
  have h : env25703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25702_25703 : H12AffineEnvironment.transform 5 16 env25702 = env25703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25702 == env25703) = true)

theorem identity25703 : scanCanonicalize (H12AffineFastState.compose env25703 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound25703 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env25704 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,23589,1025,32769,115870,29861,119967,98701,8328,16,64645,115103,17665,2476,119043,87078,257,21793,46212,63108]

theorem envBound25704 : H12AffineFastState.Bounded env25704 := by
  intro p hp
  have h : env25704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25703_25704 : H12AffineEnvironment.transform 17 23589 env25703 = env25704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env25703 == env25704) = true)

theorem identity25704 : scanCanonicalize (H12AffineFastState.compose env25704 (packedSelected [0,1,4,5,7,8,10,11,16,20,22,24,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound25704 : packedSelected [0,1,4,5,7,8,10,11,16,20,22,24,31,32] rootPS < 2^1333 := by decide +kernel

def env25705 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,65536,82199,23589,1025,21761,70046,29861,65951,87181,8328,16,10629,70815,17665,2476,66563,87078,257,21793,24964,9092]

theorem envBound25705 : H12AffineFastState.Bounded env25705 := by
  intro p hp
  have h : env25705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25704_25705 : H12AffineEnvironment.transform 14 21760 env25704 = env25705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env25704 == env25705) = true)

theorem identity25705 : scanCanonicalize (H12AffineFastState.compose env25705 (packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25705 : packedSelected [0,1,4,5,7,8,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env25706 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21760,65536,82199,23589,1025,21761,70046,21928,65951,87181,389,16,2184,70815,17665,2476,66563,87078,257,21793,16521,649]

theorem envBound25706 : H12AffineFastState.Bounded env25706 := by
  intro p hp
  have h : env25706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25705_25706 : H12AffineEnvironment.transform 12 269 env25705 = env25706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25705 == env25706) = true)

theorem identity25706 : scanCanonicalize (H12AffineFastState.compose env25706 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound25706 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25707 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21760,21511,5392,23589,1025,21761,17817,21928,21912,138,389,16,2184,16536,17665,2476,20484,33,257,21793,16521,649]

theorem envBound25707 : H12AffineFastState.Bounded env25707 := by
  intro p hp
  have h : env25707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25706_25707 : H12AffineEnvironment.transform 15 21511 env25706 = env25707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env25706 == env25707) = true)

theorem identity25707 : scanCanonicalize (H12AffineFastState.compose env25707 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25707 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env25708 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,1,262,5392,2340,1025,0,4248,169,153,138,389,16,2184,5529,4096,2476,1285,33,257,32,5512,649]

theorem envBound25708 : H12AffineFastState.Bounded env25708 := by
  intro p hp
  have h : env25708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25707_25708 : H12AffineEnvironment.transform 13 5377 env25707 = env25708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25707 == env25708) = true)

theorem identity25708 : scanCanonicalize (H12AffineFastState.compose env25708 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound25708 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env25709 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,161,5293,1,170,5308,2184,1025,0,4248,169,153,138,41,16,2184,5173,4096,2048,1193,33,173,32,5156,649]

theorem envBound25709 : H12AffineFastState.Bounded env25709 := by
  intro p hp
  have h : env25709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25708_25709 : H12AffineEnvironment.transform 7 172 env25708 = env25709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25708 == env25709) = true)

theorem identity25709 : scanCanonicalize (H12AffineFastState.compose env25709 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25709 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env25710 : List Nat := [2,4,8,16,1,16,128,141,512,1024,2048,4096,128,5260,1,139,5277,2184,1025,0,4248,136,153,138,8,16,2184,5140,4096,2048,1160,0,140,1,5125,649]

theorem envBound25710 : H12AffineFastState.Bounded env25710 := by
  intro p hp
  have h : env25710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25709_25710 : H12AffineEnvironment.transform 4 1 env25709 = env25710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25709 == env25710) = true)

def env25711 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,115870,272512,119966,98700,8328,17,64644,115102,17665,284041,119043,329731,257,21793,46212,63109]

theorem envBound25711 : H12AffineFastState.Bounded env25711 := by
  intro p hp
  have h : env25711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25702_25711 : H12AffineEnvironment.transform 5 17 env25702 = env25711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25702 == env25711) = true)

theorem identity25711 : scanCanonicalize (H12AffineFastState.compose env25711 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound25711 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env25712 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,97326,1025,32769,115870,87214,119966,98700,8328,17,64644,115102,17665,76199,119043,29741,257,21793,46212,63109]

theorem envBound25712 : H12AffineFastState.Bounded env25712 := by
  intro p hp
  have h : env25712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25711_25712 : H12AffineEnvironment.transform 17 97326 env25711 = env25712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env25711 == env25712) = true)

theorem identity25712 : scanCanonicalize (H12AffineFastState.compose env25712 (packedSelected [5,8,19,24,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound25712 : packedSelected [5,8,19,24,28,31] rootPS < 2^1333 := by decide +kernel

def env25713 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,30083,13461,2477,1025,32769,45341,8493,41245,62479,8328,17,64644,46109,17665,23588,42112,29741,257,21793,46212,63109]

theorem envBound25713 : H12AffineFastState.Bounded env25713 := by
  intro p hp
  have h : env25713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25712_25713 : H12AffineEnvironment.transform 15 30083 env25712 = env25713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env25712 == env25713) = true)

def env25714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272513,169352,98781,8328,64,64724,163976,17665,284041,168004,411973,257,21793,46212,243603]

theorem envBound25714 : H12AffineFastState.Bounded env25714 := by
  intro p hp
  have h : env25714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25700_25714 : H12AffineEnvironment.transform 21 272513 env25700 = env25714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env25700 == env25714) = true)

theorem identity25714 : scanCanonicalize (H12AffineFastState.compose env25714 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound25714 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,165337,272513,169352,21763,8328,64,64724,163976,17665,284041,168004,411973,257,21793,46212,156493]

theorem envBound25715 : H12AffineFastState.Bounded env25715 := by
  intro p hp
  have h : env25715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25714_25715 : H12AffineEnvironment.transform 15 54494 env25714 = env25715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env25714 == env25715) = true)

def env25716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,165201,272393,169216,21763,8192,64,64604,163840,17665,283905,168004,411973,257,21793,46092,156493]

theorem envBound25716 : H12AffineFastState.Bounded env25716 := by
  intro p hp
  have h : env25716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25715_25716 : H12AffineEnvironment.transform 6 8 env25715 = env25716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25715 == env25716) = true)

theorem identity25716 : scanCanonicalize (H12AffineFastState.compose env25716 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound25716 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env25717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,149861,1025,32769,165201,156012,169216,21763,8192,64,64604,163840,17665,138340,168004,32,257,21793,46092,156493]

theorem envBound25717 : H12AffineFastState.Bounded env25717 := by
  intro p hp
  have h : env25717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25716_25717 : H12AffineEnvironment.transform 17 149861 env25716 = env25717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env25716 == env25717) = true)

theorem identity25717 : scanCanonicalize (H12AffineFastState.compose env25717 (packedSelected [0,1,3,5,7,8,11,12,14,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 49217) := by decide +kernel

theorem selectedBound25717 : packedSelected [0,1,3,5,7,8,11,12,14,19,26] rootPS < 2^1333 := by decide +kernel

def env25718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49217,35108,1025,32769,17680,41261,21825,21763,8192,64,64604,16449,17665,56357,20485,32,257,21793,46092,41740]

theorem envBound25718 : H12AffineFastState.Bounded env25718 := by
  intro p hp
  have h : env25718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25717_25718 : H12AffineEnvironment.transform 16 49217 env25717 = env25718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49217 env25717 == env25718) = true)

theorem identity25718 : scanCanonicalize (H12AffineFastState.compose env25718 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound25718 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env25719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,13340,32121,1025,29788,17680,21872,21825,21763,8192,64,2049,16449,17665,10360,20485,32,257,21793,16465,22353]

theorem envBound25719 : H12AffineFastState.Bounded env25719 := by
  intro p hp
  have h : env25719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25718_25719 : H12AffineEnvironment.transform 14 29789 env25718 = env25719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env25718 == env25719) = true)

theorem identity25719 : scanCanonicalize (H12AffineFastState.compose env25719 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound25719 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8203,13340,10281,1025,8460,4160,32,17,83,8192,64,2049,5393,4177,10360,1365,32,257,113,5377,513]

theorem envBound25720 : H12AffineFastState.Bounded env25720 := by
  intro p hp
  have h : env25720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25719_25720 : H12AffineEnvironment.transform 13 5456 env25719 = env25720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env25719 == env25720) = true)

theorem identity25720 : scanCanonicalize (H12AffineFastState.compose env25720 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25720 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env25721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,1,263,5392,2341,1025,0,4160,32,17,83,268,64,2049,5393,4177,2420,1365,32,257,113,5377,513]

theorem envBound25721 : H12AffineFastState.Bounded env25721 := by
  intro p hp
  have h : env25721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25720_25721 : H12AffineEnvironment.transform 12 268 env25720 = env25721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25720 == env25721) = true)

theorem identity25721 : scanCanonicalize (H12AffineFastState.compose env25721 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25721 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25722 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,263,5392,2341,1025,0,4113,32,17,2,268,17,2049,5393,4096,2341,1284,32,257,32,5377,513]

theorem envBound25722 : H12AffineFastState.Bounded env25722 := by
  intro p hp
  have h : env25722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25721_25722 : H12AffineEnvironment.transform 5 17 env25721 = env25722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25721 == env25722) = true)

theorem identity25722 : scanCanonicalize (H12AffineFastState.compose env25722 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25722 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25723 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5377,1,263,5392,2309,1025,0,4113,0,17,2,268,17,2049,5393,4096,2309,1284,0,257,0,5377,513]

theorem envBound25723 : H12AffineFastState.Bounded env25723 := by
  intro p hp
  have h : env25723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25722_25723 : H12AffineEnvironment.transform 4 0 env25722 = env25723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25722 == env25723) = true)

theorem identity25723 : scanCanonicalize (H12AffineFastState.compose env25723 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2847) := by decide +kernel

theorem selectedBound25723 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25724 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,2847,268,3614,1,263,3599,2309,1025,0,2830,0,17,2,268,17,2049,3598,2847,2309,1284,0,257,0,3614,513]

theorem envBound25724 : H12AffineFastState.Bounded env25724 := by
  intro p hp
  have h : env25724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25723_25724 : H12AffineEnvironment.transform 11 2847 env25723 = env25724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2847 env25723 == env25724) = true)

theorem identity25724 : scanCanonicalize (H12AffineFastState.compose env25724 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound25724 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25725 : List Nat := [2,4,8,16,0,17,8,256,512,1024,11,788,268,1557,1,263,1540,270,1025,0,773,0,17,2,268,17,10,1541,788,270,1284,0,257,0,1557,513]

theorem envBound25725 : H12AffineFastState.Bounded env25725 := by
  intro p hp
  have h : env25725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25724_25725 : H12AffineEnvironment.transform 10 11 env25724 = env25725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env25724 == env25725) = true)

theorem identity25725 : scanCanonicalize (H12AffineFastState.compose env25725 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25725 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25726 : List Nat := [2,4,8,10,0,11,8,256,512,1024,11,782,268,1551,1,263,1540,270,1025,0,773,0,11,2,268,11,10,1541,782,270,1284,0,257,0,1551,513]

theorem envBound25726 : H12AffineFastState.Bounded env25726 := by
  intro p hp
  have h : env25726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25725_25726 : H12AffineEnvironment.transform 3 10 env25725 = env25726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25725 == env25726) = true)

theorem identity25726 : scanCanonicalize (H12AffineFastState.compose env25726 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound25726 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25727 : List Nat := [2,4,8,10,0,11,8,256,512,256,11,782,268,783,1,263,772,270,257,0,773,0,11,2,268,11,10,773,782,270,4,0,257,0,783,513]

theorem envBound25727 : H12AffineFastState.Bounded env25727 := by
  intro p hp
  have h : env25727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25726_25727 : H12AffineEnvironment.transform 9 256 env25726 = env25727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env25726 == env25727) = true)

theorem identity25727 : scanCanonicalize (H12AffineFastState.compose env25727 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound25727 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25728 : List Nat := [2,4,8,10,0,11,8,256,261,256,11,11,268,10,1,263,1,270,257,0,0,0,11,2,268,11,10,0,11,270,4,0,257,0,10,260]

theorem envBound25728 : H12AffineFastState.Bounded env25728 := by
  intro p hp
  have h : env25728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25727_25728 : H12AffineEnvironment.transform 8 261 env25727 = env25728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env25727 == env25728) = true)

theorem identity25728 : scanCanonicalize (H12AffineFastState.compose env25728 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25728 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25729 : List Nat := [2,4,7,5,0,4,7,256,261,256,4,4,259,5,1,263,1,257,257,0,0,0,4,2,259,4,5,0,4,257,4,0,257,0,5,260]

theorem envBound25729 : H12AffineFastState.Bounded env25729 := by
  intro p hp
  have h : env25729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25728_25729 : H12AffineEnvironment.transform 2 7 env25728 = env25729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25728 == env25729) = true)

theorem identity25729 : scanCanonicalize (H12AffineFastState.compose env25729 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound25729 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25730 : List Nat := [1,4,4,5,0,4,4,256,261,256,4,4,256,5,1,260,1,257,257,0,0,0,4,1,256,4,5,0,4,257,4,0,257,0,5,260]

theorem envBound25730 : H12AffineFastState.Bounded env25730 := by
  intro p hp
  have h : env25730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25729_25730 : H12AffineEnvironment.transform 0 1 env25729 = env25730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env25729 == env25730) = true)

theorem identity25730 : scanCanonicalize (H12AffineFastState.compose env25730 (packedSelected [9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound25730 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env25731 : List Nat := [1,4,4,5,0,4,4,4,1,4,4,4,4,5,1,0,1,5,5,0,0,0,4,1,4,4,5,0,4,5,4,0,5,0,5,0]

theorem envBound25731 : H12AffineFastState.Bounded env25731 := by
  intro p hp
  have h : env25731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25730_25731 : H12AffineEnvironment.transform 7 4 env25730 = env25731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env25730 == env25731) = true)

def env25732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,165200,272392,169217,21763,8193,64,64605,163841,17665,283904,168004,411973,257,21793,46093,156493]

theorem envBound25732 : H12AffineFastState.Bounded env25732 := by
  intro p hp
  have h : env25732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25715_25732 : H12AffineEnvironment.transform 6 9 env25715 = env25732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25715 == env25732) = true)

theorem identity25732 : scanCanonicalize (H12AffineFastState.compose env25732 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound25732 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env25733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,157752,1025,32769,165200,147504,169217,21763,8193,64,64605,163841,17665,146744,168004,8573,257,21793,46093,156493]

theorem envBound25733 : H12AffineFastState.Bounded env25733 := by
  intro p hp
  have h : env25733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25732_25733 : H12AffineEnvironment.transform 17 157752 env25732 = env25733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env25732 == env25733) = true)

theorem identity25733 : scanCanonicalize (H12AffineFastState.compose env25733 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound25733 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env25734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,43049,1025,32769,17729,32801,21776,21763,8193,64,64605,16400,17665,64809,20565,8573,257,21793,46093,41820]

theorem envBound25734 : H12AffineFastState.Bounded env25734 := by
  intro p hp
  have h : env25734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25733_25734 : H12AffineEnvironment.transform 16 49169 env25733 = env25734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env25733 == env25734) = true)

theorem identity25734 : scanCanonicalize (H12AffineFastState.compose env25734 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound25734 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env25735 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40970,46156,43049,1025,32769,12572,32801,8525,8542,8193,64,34816,13389,12636,35188,9224,8573,257,8572,46093,41820]

theorem envBound25735 : H12AffineFastState.Bounded env25735 := by
  intro p hp
  have h : env25735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25734_25735 : H12AffineEnvironment.transform 13 13405 env25734 = env25735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env25734 == env25735) = true)

def env25736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,169353,98780,8328,64,4510805,163977,17664,284040,168004,4350405,257,21793,46212,243603]

theorem envBound25736 : H12AffineFastState.Bounded env25736 := by
  intro p hp
  have h : env25736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25699_25736 : H12AffineEnvironment.transform 22 169353 env25699 = env25736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env25699 == env25736) = true)

def env25737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272512,169353,98780,8328,64,64725,163977,17664,284040,168004,411973,257,21793,46212,243603]

theorem envBound25737 : H12AffineFastState.Bounded env25737 := by
  intro p hp
  have h : env25737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25736_25737 : H12AffineEnvironment.transform 21 272512 env25736 = env25737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env25736 == env25737) = true)

theorem identity25737 : scanCanonicalize (H12AffineFastState.compose env25737 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112018) := by decide +kernel

theorem selectedBound25737 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112018,262144,1025,32769,77899,272512,73755,98780,8328,64,64725,79131,17664,284040,75222,392407,257,21793,46212,513]

theorem envBound25738 : H12AffineFastState.Bounded env25738 := by
  intro p hp
  have h : env25738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25737_25738 : H12AffineEnvironment.transform 16 112018 env25737 = env25738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112018 env25737 == env25738) = true)

def env25739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90258,262144,1025,21761,77899,272512,73755,87260,8328,64,10709,79131,17664,284040,75222,338391,257,21793,24964,513]

theorem envBound25739 : H12AffineFastState.Bounded env25739 := by
  intro p hp
  have h : env25739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25738_25739 : H12AffineEnvironment.transform 14 21760 env25738 = env25739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env25738 == env25739) = true)

theorem identity25739 : scanCanonicalize (H12AffineFastState.compose env25739 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound25739 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env25740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8322,16400,262144,1025,21761,4297,272512,153,29790,8328,64,10709,5529,17664,284040,1364,264533,257,21793,24964,513]

theorem envBound25740 : H12AffineFastState.Bounded env25740 := by
  intro p hp
  have h : env25740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25739_25740 : H12AffineEnvironment.transform 15 8322 env25739 = env25740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env25739 == env25740) = true)

theorem identity25740 : scanCanonicalize (H12AffineFastState.compose env25740 (packedSelected [1,2,4,5,6,8,9,11,14,17,19,20,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound25740 : packedSelected [1,2,4,5,6,8,9,11,14,17,19,20,24,26,32] rootPS < 2^1333 := by decide +kernel

def env25741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,137,8322,5529,262144,1025,136,4297,272512,153,8663,8328,64,10709,5529,4233,262145,1364,264533,257,168,13325,513]

theorem envBound25741 : H12AffineFastState.Bounded env25741 := by
  intro p hp
  have h : env25741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25740_25741 : H12AffineEnvironment.transform 13 5513 env25740 = env25741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env25740 == env25741) = true)

theorem identity25741 : scanCanonicalize (H12AffineFastState.compose env25741 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25741 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env25742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,137,479,5529,262144,1025,136,4297,264669,153,138,469,64,2184,5529,4233,262145,1364,264533,257,168,5456,513]

theorem envBound25742 : H12AffineFastState.Bounded env25742 := by
  intro p hp
  have h : env25742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25741_25742 : H12AffineEnvironment.transform 12 349 env25741 = env25742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25741 == env25742) = true)

theorem identity25742 : scanCanonicalize (H12AffineFastState.compose env25742 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound25742 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env25743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,137,479,5529,2421,1025,136,4297,168,153,138,469,64,2184,5529,4233,2420,1364,32,257,168,5456,513]

theorem envBound25743 : H12AffineFastState.Bounded env25743 := by
  intro p hp
  have h : env25743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25742_25743 : H12AffineEnvironment.transform 17 2421 env25742 = env25743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env25742 == env25743) = true)

theorem identity25743 : scanCanonicalize (H12AffineFastState.compose env25743 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25743 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5392,2421,1025,1,4160,33,16,3,348,64,2049,5392,4096,2420,1364,32,257,33,5456,513]

theorem envBound25744 : H12AffineFastState.Bounded env25744 := by
  intro p hp
  have h : env25744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25743_25744 : H12AffineEnvironment.transform 6 9 env25743 = env25744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25743 == env25744) = true)

theorem identity25744 : scanCanonicalize (H12AffineFastState.compose env25744 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25744 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25745 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,5392,2340,1025,1,4113,33,16,3,269,17,2049,5392,4096,2341,1285,32,257,33,5377,513]

theorem envBound25745 : H12AffineFastState.Bounded env25745 := by
  intro p hp
  have h : env25745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25744_25745 : H12AffineEnvironment.transform 5 17 env25744 = env25745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25744 == env25745) = true)

theorem identity25745 : scanCanonicalize (H12AffineFastState.compose env25745 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound25745 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25746 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3329,268,2049,0,263,2065,2340,1025,1,3344,33,16,3,269,17,2049,2065,3329,2341,1285,32,257,33,2048,513]

theorem envBound25746 : H12AffineFastState.Bounded env25746 := by
  intro p hp
  have h : env25746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25745_25746 : H12AffineEnvironment.transform 11 3329 env25745 = env25746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env25745 == env25746) = true)

theorem identity25746 : scanCanonicalize (H12AffineFastState.compose env25746 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25746 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25747 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,40,2049,0,35,2065,2048,1025,1,3124,33,16,3,41,17,2049,2065,3109,2049,1057,32,37,33,2048,513]

theorem envBound25747 : H12AffineFastState.Bounded env25747 := by
  intro p hp
  have h : env25747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25746_25747 : H12AffineEnvironment.transform 7 36 env25746 = env25747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25746 == env25747) = true)

theorem identity25747 : scanCanonicalize (H12AffineFastState.compose env25747 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25747 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25748 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2065,40,2049,0,35,2065,2048,53,1,2048,33,16,3,41,17,2049,2065,2065,2049,21,32,37,33,2048,513]

theorem envBound25748 : H12AffineFastState.Bounded env25748 := by
  intro p hp
  have h : env25748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25747_25748 : H12AffineEnvironment.transform 9 52 env25747 = env25748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25747 == env25748) = true)

def env25749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90259,262144,1025,21760,77899,272512,73755,87261,8328,64,10708,79131,17664,284040,75222,338390,257,21793,24965,513]

theorem envBound25749 : H12AffineFastState.Bounded env25749 := by
  intro p hp
  have h : env25749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25738_25749 : H12AffineEnvironment.transform 14 21761 env25738 = env25749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env25738 == env25749) = true)

theorem identity25749 : scanCanonicalize (H12AffineFastState.compose env25749 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25749 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,90139,262144,1025,21760,77899,272392,73755,87125,8192,64,10588,79131,17664,283904,75102,338270,257,21793,24845,513]

theorem envBound25750 : H12AffineFastState.Bounded env25750 := by
  intro p hp
  have h : env25750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25749_25750 : H12AffineEnvironment.transform 6 8 env25749 = env25750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25749 == env25750) = true)

theorem identity25750 : scanCanonicalize (H12AffineFastState.compose env25750 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound25750 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env25751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,90139,67618,1025,21760,77899,73770,73755,87125,8192,64,10588,79131,17664,89378,75102,8572,257,21793,24845,513]

theorem envBound25751 : H12AffineFastState.Bounded env25751 := by
  intro p hp
  have h : env25751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25750_25751 : H12AffineEnvironment.transform 17 67618 env25750 = env25751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env25750 == env25751) = true)

theorem identity25751 : scanCanonicalize (H12AffineFastState.compose env25751 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25751 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8203,16400,10281,1025,21760,4160,33,16,29790,8192,64,10588,5392,17664,32041,1365,8572,257,21793,24845,513]

theorem envBound25752 : H12AffineFastState.Bounded env25752 := by
  intro p hp
  have h : env25752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25751_25752 : H12AffineEnvironment.transform 15 8203 env25751 = env25752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25751 == env25752) = true)

theorem identity25752 : scanCanonicalize (H12AffineFastState.compose env25752 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound25752 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,8203,13389,10281,1025,8541,4160,33,16,3,8192,64,10588,5392,12637,2420,1365,8572,257,8572,5456,513]

theorem envBound25753 : H12AffineFastState.Bounded env25753 := by
  intro p hp
  have h : env25753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25752_25753 : H12AffineEnvironment.transform 13 13405 env25752 = env25753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env25752 == env25753) = true)

theorem identity25753 : scanCanonicalize (H12AffineFastState.compose env25753 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25753 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25754 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13405,8312,8203,13389,10281,1025,8313,4160,33,16,3,8192,64,10360,5172,12409,2128,1137,8280,37,8280,5236,513]

theorem envBound25754 : H12AffineFastState.Bounded env25754 := by
  intro p hp
  have h : env25754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25753_25754 : H12AffineEnvironment.transform 7 36 env25753 = env25754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25753 == env25754) = true)

theorem identity25754 : scanCanonicalize (H12AffineFastState.compose env25754 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound25754 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25755 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,4096,8192,12344,8312,8203,12328,10281,100,8313,4160,33,16,3,8192,64,10360,4177,12409,2128,20,8280,37,8280,4113,513]

theorem envBound25755 : H12AffineFastState.Bounded env25755 := by
  intro p hp
  have h : env25755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25754_25755 : H12AffineEnvironment.transform 9 101 env25754 = env25755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env25754 == env25755) = true)

theorem identity25755 : scanCanonicalize (H12AffineFastState.compose env25755 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 4201) := by decide +kernel

theorem selectedBound25755 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25756 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,4096,4201,81,4113,4194,65,6208,100,4112,4160,33,16,3,4201,64,6161,4177,16,2128,20,4145,37,4145,4113,513]

theorem envBound25756 : H12AffineFastState.Bounded env25756 := by
  intro p hp
  have h : env25756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25755_25756 : H12AffineEnvironment.transform 12 4201 env25755 = env25756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4201 env25755 == env25756) = true)

theorem identity25756 : scanCanonicalize (H12AffineFastState.compose env25756 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25756 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25757 : List Nat := [2,4,8,16,32,64,8,36,512,101,1,4096,4201,81,4113,4194,65,4161,100,4112,4160,33,16,3,4201,64,4112,4177,16,81,20,4145,37,4145,4113,513]

theorem envBound25757 : H12AffineFastState.Bounded env25757 := by
  intro p hp
  have h : env25757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25756_25757 : H12AffineEnvironment.transform 10 1 env25756 = env25757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25756 == env25757) = true)

theorem identity25757 : scanCanonicalize (H12AffineFastState.compose env25757 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound25757 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25758 : List Nat := [2,4,8,16,32,64,8,36,512,101,1,16,121,81,1,114,65,81,100,0,80,33,16,3,121,64,0,65,16,81,20,33,37,33,1,513]

theorem envBound25758 : H12AffineFastState.Bounded env25758 := by
  intro p hp
  have h : env25758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25757_25758 : H12AffineEnvironment.transform 11 16 env25757 = env25758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25757 == env25758) = true)

theorem identity25758 : scanCanonicalize (H12AffineFastState.compose env25758 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25758 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25759 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,16,41,1,1,34,17,1,52,0,0,33,16,3,41,16,0,17,16,1,20,33,37,33,1,513]

theorem envBound25759 : H12AffineFastState.Bounded env25759 := by
  intro p hp
  have h : env25759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25758_25759 : H12AffineEnvironment.transform 5 16 env25758 = env25759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25758 == env25759) = true)

theorem identity25759 : scanCanonicalize (H12AffineFastState.compose env25759 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound25759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25760 : List Nat := [2,4,8,16,32,16,8,36,32,53,1,16,41,1,1,34,17,1,52,0,0,33,16,3,41,16,0,17,16,1,20,33,37,33,1,33]

theorem envBound25760 : H12AffineFastState.Bounded env25760 := by
  intro p hp
  have h : env25760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25759_25760 : H12AffineEnvironment.transform 8 32 env25759 = env25760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env25759 == env25760) = true)

def env25761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272513,169353,98780,8328,64,64724,163977,17664,284040,168004,411972,257,21793,46212,243603]

theorem envBound25761 : H12AffineFastState.Bounded env25761 := by
  intro p hp
  have h : env25761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25736_25761 : H12AffineEnvironment.transform 21 272513 env25736 = env25761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env25736 == env25761) = true)

theorem identity25761 : scanCanonicalize (H12AffineFastState.compose env25761 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound25761 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165337,272513,169353,41430,8328,64,64724,163977,17664,284040,168004,411972,257,21793,46212,169881]

theorem envBound25762 : H12AffineFastState.Bounded env25762 := by
  intro p hp
  have h : env25762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25761_25762 : H12AffineEnvironment.transform 15 8202 env25761 = env25762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env25761 == env25762) = true)

def env25763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165201,272393,169217,41310,8192,64,64604,163841,17664,283904,168004,411972,257,21793,46092,169745]

theorem envBound25763 : H12AffineFastState.Bounded env25763 := by
  intro p hp
  have h : env25763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25762_25763 : H12AffineEnvironment.transform 6 8 env25762 = env25763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25762 == env25763) = true)

theorem identity25763 : scanCanonicalize (H12AffineFastState.compose env25763 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound25763 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env25764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1025,32769,165201,169265,169217,41310,8192,64,64604,163841,17664,190520,168004,62588,257,21793,46092,169745]

theorem envBound25764 : H12AffineFastState.Bounded env25764 := by
  intro p hp
  have h : env25764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25763_25764 : H12AffineEnvironment.transform 17 179512 env25763 = env25764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env25763 == env25764) = true)

def env25765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165200,272392,169216,41311,8193,64,64605,163840,17664,283905,168004,411972,257,21793,46093,169744]

theorem envBound25765 : H12AffineFastState.Bounded env25765 := by
  intro p hp
  have h : env25765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25762_25765 : H12AffineEnvironment.transform 6 9 env25762 = env25765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25762 == env25765) = true)

theorem identity25765 : scanCanonicalize (H12AffineFastState.compose env25765 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound25765 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env25766 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,138341,1025,32769,165200,144493,169216,41311,8193,64,64605,163840,17664,149860,168004,21793,257,21793,46093,169744]

theorem envBound25766 : H12AffineFastState.Bounded env25766 := by
  intro p hp
  have h : env25766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25765_25766 : H12AffineEnvironment.transform 17 138341 env25765 = env25766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env25765 == env25766) = true)

theorem identity25766 : scanCanonicalize (H12AffineFastState.compose env25766 (packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound25766 : packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env25767 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,8202,131072,138341,1025,29992,159865,144493,155689,21622,8193,64,2420,161065,17664,149860,157037,21793,257,21793,16676,156217]

theorem envBound25767 : H12AffineFastState.Bounded env25767 := by
  intro p hp
  have h : env25767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25766_25767 : H12AffineEnvironment.transform 14 29993 env25766 = env25767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env25766 == env25767) = true)

theorem identity25767 : scanCanonicalize (H12AffineFastState.compose env25767 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 24633) := by decide +kernel

theorem selectedBound25767 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env25768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,8202,24633,31836,1025,29992,4160,21588,16,21622,8193,64,2420,5392,17664,10589,1364,21793,257,21793,16676,512]

theorem envBound25768 : H12AffineFastState.Bounded env25768 := by
  intro p hp
  have h : env25768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25767_25768 : H12AffineEnvironment.transform 16 24633 env25767 = env25768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24633 env25767 == env25768) = true)

theorem identity25768 : scanCanonicalize (H12AffineFastState.compose env25768 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25768 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25769 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,29708,8202,24633,31836,1025,29709,4160,21588,16,21622,8193,64,2129,5173,17445,10360,1137,21508,36,21508,16385,512]

theorem envBound25769 : H12AffineFastState.Bounded env25769 := by
  intro p hp
  have h : env25769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25768_25769 : H12AffineEnvironment.transform 7 37 env25768 = env25769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25768 == env25769) = true)

theorem identity25769 : scanCanonicalize (H12AffineFastState.compose env25769 (packedSelected [2,3,5,6,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound25769 : packedSelected [2,3,5,6,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env25770 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,1076,12344,8202,9229,14440,1025,12345,4160,4192,16,4162,8193,64,2129,5173,17,10360,1137,4144,36,4144,1077,512]

theorem envBound25770 : H12AffineFastState.Bounded env25770 := by
  intro p hp
  have h : env25770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25769_25770 : H12AffineEnvironment.transform 13 1076 env25769 = env25770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env25769 == env25770) = true)

theorem identity25770 : scanCanonicalize (H12AffineFastState.compose env25770 (packedSelected [0,1,3,4,5,6,7,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound25770 : packedSelected [0,1,3,4,5,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env25771 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,97,8192,1076,8281,8202,9229,10249,1025,8280,33,1,16,35,8193,64,2129,1108,17,10360,1137,81,36,81,1077,512]

theorem envBound25771 : H12AffineFastState.Bounded env25771 := by
  intro p hp
  have h : env25771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25770_25771 : H12AffineEnvironment.transform 11 97 env25770 = env25771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env25770 == env25771) = true)

theorem identity25771 : scanCanonicalize (H12AffineFastState.compose env25771 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25771 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env25772 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,65,8192,1044,8281,8202,9229,10249,1025,8280,1,1,16,3,8193,64,2129,1108,17,10328,1105,81,4,81,1045,512]

theorem envBound25772 : H12AffineFastState.Bounded env25772 := by
  intro p hp
  have h : env25772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25771_25772 : H12AffineEnvironment.transform 4 0 env25771 = env25772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25771 == env25772) = true)

theorem identity25772 : scanCanonicalize (H12AffineFastState.compose env25772 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound25772 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25773 : List Nat := [2,4,8,16,0,64,9,5,512,1024,2048,65,89,1044,0,83,1108,2128,1025,1,1,1,16,3,88,64,2129,1108,17,2049,1105,81,4,81,1045,512]

theorem envBound25773 : H12AffineFastState.Bounded env25773 := by
  intro p hp
  have h : env25773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25772_25773 : H12AffineEnvironment.transform 12 89 env25772 = env25773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env25772 == env25773) = true)

theorem identity25773 : scanCanonicalize (H12AffineFastState.compose env25773 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound25773 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env25774 : List Nat := [2,4,8,16,0,64,9,5,512,69,2048,65,89,81,0,83,17,2128,68,1,1,1,16,3,88,64,2129,17,17,2049,20,81,4,81,80,512]

theorem envBound25774 : H12AffineFastState.Bounded env25774 := by
  intro p hp
  have h : env25774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25773_25774 : H12AffineEnvironment.transform 9 69 env25773 = env25774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env25773 == env25774) = true)

theorem identity25774 : scanCanonicalize (H12AffineFastState.compose env25774 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25774 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25775 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,16,8,0,0,2,17,2049,21,1,1,1,16,3,9,17,2048,17,17,2049,20,0,4,0,1,512]

theorem envBound25775 : H12AffineFastState.Bounded env25775 := by
  intro p hp
  have h : env25775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25774_25775 : H12AffineEnvironment.transform 5 17 env25774 = env25775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25774 == env25775) = true)

theorem identity25775 : scanCanonicalize (H12AffineFastState.compose env25775 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25775 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25776 : List Nat := [2,1,8,16,0,17,9,0,512,17,2048,16,8,0,0,2,17,2049,16,1,1,1,16,3,9,17,2048,17,17,2049,17,0,1,0,1,512]

theorem envBound25776 : H12AffineFastState.Bounded env25776 := by
  intro p hp
  have h : env25776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25775_25776 : H12AffineEnvironment.transform 1 1 env25775 = env25776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25775 == env25776) = true)

theorem identity25776 : scanCanonicalize (H12AffineFastState.compose env25776 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound25776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25777 : List Nat := [2,1,1,16,0,17,0,0,512,17,2048,16,1,0,0,2,17,2049,16,1,1,1,16,3,0,17,2048,17,17,2049,17,0,1,0,1,512]

theorem envBound25777 : H12AffineFastState.Bounded env25777 := by
  intro p hp
  have h : env25777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25776_25777 : H12AffineEnvironment.transform 2 1 env25776 = env25777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env25776 == env25777) = true)

def env25778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254785,25265168,145662401,525568,140903597,27337992,25733063]

theorem envBound25778 : H12AffineFastState.Bounded env25778 := by
  intro p hp
  have h : env25778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25089_25778 : H12AffineEnvironment.transform 25 65 env25089 = env25778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env25089 == env25778) = true)

def env25779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356289,25265168,23160257,525568,27902125,27337992,25733063]

theorem envBound25779 : H12AffineFastState.Bounded env25779 := by
  intro p hp
  have h : env25779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25778_25779 : H12AffineEnvironment.transform 26 30393344 env25778 = env25779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env25778 == env25779) = true)

def env25780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265168,23160257,256,27378861,27337992,25207751]

theorem envBound25780 : H12AffineFastState.Bounded env25780 := by
  intro p hp
  have h : env25780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25779_25780 : H12AffineEnvironment.transform 18 1024 env25779 = env25780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25779 == env25780) = true)

theorem identity25780 : scanCanonicalize (H12AffineFastState.compose env25780 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 510137) := by decide +kernel

theorem selectedBound25780 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,510137,8328,65,12585145,2509876,10507601,8830977,8801449,6729080,256,10882068,10939825,8874878]

theorem envBound25781 : H12AffineFastState.Bounded env25781 := by
  intro p hp
  have h : env25781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25780_25781 : H12AffineEnvironment.transform 23 510137 env25780 = env25781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510137 env25780 == env25781) = true)

def env25782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513204,510137,8328,65,6705549,2509876,396389,2136373,2102685,6729080,256,21792,46213,2175562]

theorem envBound25782 : H12AffineFastState.Bounded env25782 := by
  intro p hp
  have h : env25782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25781_25782 : H12AffineEnvironment.transform 22 2513204 env25781 = env25782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513204 env25781 == env25782) = true)

def env25783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169264,2513204,510137,8328,65,2409661,2509876,396389,2136373,2102685,2373704,256,21792,46213,2175562]

theorem envBound25783 : H12AffineFastState.Bounded env25783 := by
  intro p hp
  have h : env25783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25782_25783 : H12AffineEnvironment.transform 21 169264 env25782 = env25783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env25782 == env25783) = true)

def env25784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412020,510137,8328,65,316669,416884,396389,35189,1501,272392,256,21792,46213,74250]

theorem envBound25784 : H12AffineFastState.Bounded env25784 := by
  intro p hp
  have h : env25784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25783_25784 : H12AffineEnvironment.transform 20 4160 env25783 = env25784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25783 == env25784) = true)

theorem identity25784 : scanCanonicalize (H12AffineFastState.compose env25784 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236987) := by decide +kernel

theorem selectedBound25784 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236987,1024,32769,4160,169264,120015,21762,8328,65,215366,115151,102878,35189,1501,243123,256,21792,46213,74250]

theorem envBound25785 : H12AffineFastState.Bounded env25785 := by
  intro p hp
  have h : env25785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25784_25785 : H12AffineEnvironment.transform 17 236987 env25784 = env25785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236987 env25784 == env25785) = true)

def env25786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,130175,1024,32769,4160,62708,120015,21762,8328,65,75906,115151,102878,35189,1501,119927,256,21792,46213,74250]

theorem envBound25786 : H12AffineFastState.Bounded env25786 := by
  intro p hp
  have h : env25786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25785_25786 : H12AffineEnvironment.transform 16 25028 env25785 = env25786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env25785 == env25786) = true)

theorem identity25786 : scanCanonicalize (H12AffineFastState.compose env25786 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound25786 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env25787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,25028,76158,1024,21760,4160,8693,65998,21762,8328,65,75906,70862,83167,23668,1501,65910,256,21792,24964,74250]

theorem envBound25787 : H12AffineFastState.Bounded env25787 := by
  intro p hp
  have h : env25787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25786_25787 : H12AffineEnvironment.transform 14 21761 env25786 = env25787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env25786 == env25787) = true)

theorem identity25787 : scanCanonicalize (H12AffineFastState.compose env25787 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25787 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env25788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,25028,2421,1024,21760,4160,8693,8645,21762,8328,65,2185,13509,25812,23668,1501,8573,256,21792,24964,513]

theorem envBound25788 : H12AffineFastState.Bounded env25788 := by
  intro p hp
  have h : env25788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25787_25788 : H12AffineEnvironment.transform 15 8203 env25787 = env25788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25787 == env25788) = true)

theorem identity25788 : scanCanonicalize (H12AffineFastState.compose env25788 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound25788 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,478,16401,2421,1024,21760,4160,32,16,21762,349,65,2185,5392,17665,23668,1501,168,256,21792,16465,513]

theorem envBound25789 : H12AffineFastState.Bounded env25789 := by
  intro p hp
  have h : env25789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25788_25789 : H12AffineEnvironment.transform 12 469 env25788 = env25789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env25788 == env25789) = true)

theorem identity25789 : scanCanonicalize (H12AffineFastState.compose env25789 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound25789 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25790 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,16384,21761,263,16401,2421,1024,21760,4160,32,16,21762,349,65,2128,5392,17665,23668,1284,113,256,21792,16465,513]

theorem envBound25790 : H12AffineFastState.Bounded env25790 := by
  intro p hp
  have h : env25790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25789_25790 : H12AffineEnvironment.transform 6 89 env25789 = env25790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env25789 == env25790) = true)

theorem identity25790 : scanCanonicalize (H12AffineFastState.compose env25790 (packedSelected [0,3,4,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 4916) := by decide +kernel

theorem selectedBound25790 : packedSelected [0,3,4,8,10,11] rootPS < 2^1333 := by decide +kernel

def env25791 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,4916,1589,263,4901,2421,1024,1588,4160,32,16,1590,349,65,2128,5392,5685,3904,1284,113,256,1556,4965,513]

theorem envBound25791 : H12AffineFastState.Bounded env25791 := by
  intro p hp
  have h : env25791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25790_25791 : H12AffineEnvironment.transform 13 4916 env25790 = env25791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4916 env25790 == env25791) = true)

theorem identity25791 : scanCanonicalize (H12AffineFastState.compose env25791 (packedSelected [0,1,2,3,5,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound25791 : packedSelected [0,1,2,3,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env25792 : List Nat := [2,4,8,16,32,64,89,256,512,1024,64,4096,268,4916,1589,263,4901,309,1024,1588,4160,32,16,1590,349,65,16,5392,5685,1792,1284,113,256,1556,4965,513]

theorem envBound25792 : H12AffineFastState.Bounded env25792 := by
  intro p hp
  have h : env25792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25791_25792 : H12AffineEnvironment.transform 10 64 env25791 = env25792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env25791 == env25792) = true)

theorem identity25792 : scanCanonicalize (H12AffineFastState.compose env25792 (packedSelected [0,3,5,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25792 : packedSelected [0,3,5,9,14] rootPS < 2^1333 := by decide +kernel

def env25793 : List Nat := [2,4,8,16,32,16,9,256,512,1024,16,4096,268,4916,1589,263,4901,309,1024,1588,4112,32,16,1590,269,17,16,5392,5685,1792,1284,33,256,1556,4917,513]

theorem envBound25793 : H12AffineFastState.Bounded env25793 := by
  intro p hp
  have h : env25793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25792_25793 : H12AffineEnvironment.transform 5 16 env25792 = env25793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25792 == env25793) = true)

theorem identity25793 : scanCanonicalize (H12AffineFastState.compose env25793 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound25793 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env25794 : List Nat := [2,4,8,16,32,16,9,256,293,1024,16,4096,268,4113,1296,263,4096,309,1024,1297,4112,32,16,1299,269,17,16,5392,5392,1061,1284,33,256,1329,4112,292]

theorem envBound25794 : H12AffineFastState.Bounded env25794 := by
  intro p hp
  have h : env25794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25793_25794 : H12AffineEnvironment.transform 8 293 env25793 = env25794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env25793 == env25794) = true)

theorem identity25794 : scanCanonicalize (H12AffineFastState.compose env25794 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound25794 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env25795 : List Nat := [2,4,8,16,32,16,9,256,293,1024,16,16,268,1,1296,263,16,309,1024,1297,0,32,16,1299,269,17,16,1280,1280,1061,1284,33,256,1329,0,292]

theorem envBound25795 : H12AffineFastState.Bounded env25795 := by
  intro p hp
  have h : env25795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25794_25795 : H12AffineEnvironment.transform 11 16 env25794 = env25795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25794 == env25795) = true)

theorem identity25795 : scanCanonicalize (H12AffineFastState.compose env25795 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25795 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25796 : List Nat := [2,4,8,1,32,1,9,256,293,1024,1,1,268,1,1281,263,1,292,1024,1280,0,32,1,1282,269,0,1,1280,1280,1061,1284,33,256,1312,0,292]

theorem envBound25796 : H12AffineFastState.Bounded env25796 := by
  intro p hp
  have h : env25796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25795_25796 : H12AffineEnvironment.transform 3 1 env25795 = env25796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25795 == env25796) = true)

theorem identity25796 : scanCanonicalize (H12AffineFastState.compose env25796 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25796 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env25797 : List Nat := [2,4,8,1,1,1,9,256,260,1024,1,1,268,1,1281,263,1,261,1024,1280,0,1,1,1282,269,0,1,1280,1280,1028,1284,0,256,1281,0,261]

theorem envBound25797 : H12AffineFastState.Bounded env25797 := by
  intro p hp
  have h : env25797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25796_25797 : H12AffineEnvironment.transform 4 1 env25796 = env25797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25796 == env25797) = true)

theorem identity25797 : scanCanonicalize (H12AffineFastState.compose env25797 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound25797 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25798 : List Nat := [2,4,8,1,1,1,9,5,1,1024,1,1,9,1,1028,2,1,0,1024,1029,0,1,1,1031,8,0,1,1029,1029,1028,1025,0,5,1028,0,0]

theorem envBound25798 : H12AffineFastState.Bounded env25798 := by
  intro p hp
  have h : env25798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25797_25798 : H12AffineEnvironment.transform 7 5 env25797 = env25798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env25797 == env25798) = true)

theorem identity25798 : scanCanonicalize (H12AffineFastState.compose env25798 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound25798 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25799 : List Nat := [2,4,8,1,1,1,9,5,1,5,1,1,9,1,1,2,1,0,5,0,0,1,1,2,8,0,1,0,0,1,4,0,5,1,0,0]

theorem envBound25799 : H12AffineFastState.Bounded env25799 := by
  intro p hp
  have h : env25799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25798_25799 : H12AffineEnvironment.transform 9 5 env25798 = env25799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env25798 == env25799) = true)

def env25800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,130174,1024,32769,4160,62709,120015,21762,8328,65,75907,115151,102878,35189,1501,119926,256,21792,46213,74250]

theorem envBound25800 : H12AffineFastState.Bounded env25800 := by
  intro p hp
  have h : env25800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25785_25800 : H12AffineEnvironment.transform 16 25029 env25785 = env25800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env25785 == env25800) = true)

theorem identity25800 : scanCanonicalize (H12AffineFastState.compose env25800 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound25800 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env25801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,25029,2421,1024,32769,4160,62709,8644,21762,8328,65,56712,13508,25813,35189,1501,8573,256,21792,46213,55041]

theorem envBound25801 : H12AffineFastState.Bounded env25801 := by
  intro p hp
  have h : env25801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25800_25801 : H12AffineEnvironment.transform 15 62731 env25800 = env25801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env25800 == env25801) = true)

def env25802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,24909,2421,1024,32769,4160,62589,8524,21762,8192,65,56576,13388,25693,35189,1365,8573,256,21792,46093,55041]

theorem envBound25802 : H12AffineFastState.Bounded env25802 := by
  intro p hp
  have h : env25802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25801_25802 : H12AffineEnvironment.transform 6 8 env25801 = env25802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25801 == env25802) = true)

theorem identity25802 : scanCanonicalize (H12AffineFastState.compose env25802 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound25802 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,24909,2421,1024,21761,4160,8573,8524,21762,8192,65,2048,13388,25693,23669,1365,8573,256,21792,24845,513]

theorem envBound25803 : H12AffineFastState.Bounded env25803 := by
  intro p hp
  have h : env25803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25802_25803 : H12AffineEnvironment.transform 14 21760 env25802 = env25803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env25802 == env25803) = true)

theorem identity25803 : scanCanonicalize (H12AffineFastState.compose env25803 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25803 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,343,16401,2421,1024,21761,4160,33,16,21762,348,65,2048,5392,17665,23669,1365,33,256,21792,16465,513]

theorem envBound25804 : H12AffineFastState.Bounded env25804 := by
  intro p hp
  have h : env25804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25803_25804 : H12AffineEnvironment.transform 12 348 env25803 = env25804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25803 == env25804) = true)

theorem identity25804 : scanCanonicalize (H12AffineFastState.compose env25804 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound25804 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,80,343,5441,2421,1024,81,4160,33,16,82,348,65,2048,5392,4177,2341,1365,33,256,112,5377,513]

theorem envBound25805 : H12AffineFastState.Bounded env25805 := by
  intro p hp
  have h : env25805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25804_25805 : H12AffineEnvironment.transform 13 5456 env25804 = env25805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env25804 == env25805) = true)

theorem identity25805 : scanCanonicalize (H12AffineFastState.compose env25805 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound25805 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env25806 : List Nat := [2,4,8,16,32,64,8,256,512,768,2048,4096,348,4688,80,343,4673,2421,768,81,4160,33,16,82,348,65,2048,4624,4177,2341,597,33,256,112,4609,513]

theorem envBound25806 : H12AffineFastState.Bounded env25806 := by
  intro p hp
  have h : env25806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25805_25806 : H12AffineEnvironment.transform 9 768 env25805 = env25806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env25805 == env25806) = true)

theorem identity25806 : scanCanonicalize (H12AffineFastState.compose env25806 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 885) := by decide +kernel

theorem selectedBound25806 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env25807 : List Nat := [2,4,8,16,32,64,8,256,512,768,885,4096,348,4688,80,343,4673,512,768,81,4160,33,16,82,348,65,885,4624,4177,592,597,33,256,112,4609,513]

theorem envBound25807 : H12AffineFastState.Bounded env25807 := by
  intro p hp
  have h : env25807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25806_25807 : H12AffineEnvironment.transform 10 885 env25806 = env25807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 885 env25806 == env25807) = true)

theorem identity25807 : scanCanonicalize (H12AffineFastState.compose env25807 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound25807 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env25808 : List Nat := [2,4,8,16,32,64,8,256,512,768,885,821,348,357,80,343,372,512,768,81,885,33,16,82,348,65,885,293,868,592,597,33,256,112,308,513]

theorem envBound25808 : H12AffineFastState.Bounded env25808 := by
  intro p hp
  have h : env25808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25807_25808 : H12AffineEnvironment.transform 11 821 env25807 = env25808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env25807 == env25808) = true)

theorem identity25808 : scanCanonicalize (H12AffineFastState.compose env25808 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound25808 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env25809 : List Nat := [2,4,8,16,32,64,8,256,80,336,293,357,348,357,80,343,372,80,336,81,293,33,16,82,348,65,293,293,308,0,5,33,256,112,308,81]

theorem envBound25809 : H12AffineFastState.Bounded env25809 := by
  intro p hp
  have h : env25809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25808_25809 : H12AffineEnvironment.transform 8 80 env25808 = env25809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env25808 == env25809) = true)

theorem identity25809 : scanCanonicalize (H12AffineFastState.compose env25809 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25809 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25810 : List Nat := [2,4,8,16,32,64,8,36,80,116,1,65,120,65,80,115,80,80,116,81,1,33,16,82,120,65,1,1,16,0,5,33,36,112,16,81]

theorem envBound25810 : H12AffineFastState.Bounded env25810 := by
  intro p hp
  have h : env25810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25809_25810 : H12AffineEnvironment.transform 7 36 env25809 = env25810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25809 == env25810) = true)

theorem identity25810 : scanCanonicalize (H12AffineFastState.compose env25810 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25811 : List Nat := [2,4,8,16,32,16,8,36,0,36,1,17,40,17,0,35,0,0,36,1,1,33,16,2,40,17,1,1,16,0,5,33,36,32,16,1]

theorem envBound25811 : H12AffineFastState.Bounded env25811 := by
  intro p hp
  have h : env25811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25810_25811 : H12AffineEnvironment.transform 5 16 env25810 = env25811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25810 == env25811) = true)

def env25812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24908,2421,1024,32769,4160,62588,8525,21762,8193,65,56577,13389,25692,35189,1364,8573,256,21792,46092,55041]

theorem envBound25812 : H12AffineFastState.Bounded env25812 := by
  intro p hp
  have h : env25812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25801_25812 : H12AffineEnvironment.transform 6 9 env25801 = env25812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25801 == env25812) = true)

theorem identity25812 : scanCanonicalize (H12AffineFastState.compose env25812 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound25812 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,33110,5393,2421,1024,32769,4160,32801,8525,8543,8193,65,43356,13389,4097,35189,1364,8573,256,8573,46092,41820]

theorem envBound25813 : H12AffineFastState.Bounded env25813 := by
  intro p hp
  have h : env25813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25812_25813 : H12AffineEnvironment.transform 13 13405 env25812 = env25813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env25812 == env25813) = true)

theorem identity25813 : scanCanonicalize (H12AffineFastState.compose env25813 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound25813 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env25814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,373,35,5393,2421,1024,372,4160,340,8525,8543,8193,65,10281,13389,4097,2048,1364,8573,256,8573,13689,8745]

theorem envBound25814 : H12AffineFastState.Bounded env25814 := by
  intro p hp
  have h : env25814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25813_25814 : H12AffineEnvironment.transform 14 373 env25813 = env25814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env25813 == env25814) = true)

theorem identity25814 : scanCanonicalize (H12AffineFastState.compose env25814 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound25814 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env25815 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13405,0,35,5220,2048,1024,1,4160,33,8248,8234,8193,65,10281,13389,4097,2048,1057,8200,117,8200,13324,8745]

theorem envBound25815 : H12AffineFastState.Bounded env25815 := by
  intro p hp
  have h : env25815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25814_25815 : H12AffineEnvironment.transform 7 117 env25814 = env25815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env25814 == env25815) = true)

theorem identity25815 : scanCanonicalize (H12AffineFastState.compose env25815 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound25815 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env25816 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1077,4096,8192,13405,0,35,5220,1077,1024,1,4160,33,8248,8234,8193,65,9244,13389,4097,1077,1057,8200,117,8200,13324,8745]

theorem envBound25816 : H12AffineFastState.Bounded env25816 := by
  intro p hp
  have h : env25816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25815_25816 : H12AffineEnvironment.transform 10 1077 env25815 = env25816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env25815 == env25816) = true)

theorem identity25816 : scanCanonicalize (H12AffineFastState.compose env25816 (packedSelected [0,1,2,3,5,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound25816 : packedSelected [0,1,2,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env25817 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,4096,8192,12345,0,35,4096,81,100,1,4160,33,8248,8234,8193,65,8312,12329,4097,81,69,8200,117,8200,12392,8745]

theorem envBound25817 : H12AffineFastState.Bounded env25817 := by
  intro p hp
  have h : env25817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25816_25817 : H12AffineEnvironment.transform 9 100 env25816 = env25817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env25816 == env25817) = true)

theorem identity25817 : scanCanonicalize (H12AffineFastState.compose env25817 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound25817 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env25818 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,16,8192,8233,0,35,16,81,100,1,80,33,8248,8234,8193,65,8312,8249,17,81,69,8200,117,8200,8312,8745]

theorem envBound25818 : H12AffineFastState.Bounded env25818 := by
  intro p hp
  have h : env25818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25817_25818 : H12AffineEnvironment.transform 11 16 env25817 = env25818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env25817 == env25818) = true)

theorem identity25818 : scanCanonicalize (H12AffineFastState.compose env25818 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound25818 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25819 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,16,41,0,0,35,16,81,100,1,80,33,17,3,40,65,81,16,17,81,69,33,117,33,81,512]

theorem envBound25819 : H12AffineFastState.Bounded env25819 := by
  intro p hp
  have h : env25819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25818_25819 : H12AffineEnvironment.transform 12 41 env25818 = env25819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env25818 == env25819) = true)

theorem identity25819 : scanCanonicalize (H12AffineFastState.compose env25819 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 68) := by decide +kernel

theorem selectedBound25819 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25820 : List Nat := [2,4,8,16,32,64,9,117,68,100,81,16,41,0,0,35,16,81,100,1,80,33,17,3,40,65,81,16,17,81,69,33,117,33,81,68]

theorem envBound25820 : H12AffineFastState.Bounded env25820 := by
  intro p hp
  have h : env25820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25819_25820 : H12AffineEnvironment.transform 8 68 env25819 = env25820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 68 env25819 == env25820) = true)

theorem identity25820 : scanCanonicalize (H12AffineFastState.compose env25820 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound25820 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25821 : List Nat := [2,4,8,7,32,64,9,98,68,100,70,7,41,0,0,35,7,70,100,1,71,33,6,3,40,65,70,7,6,70,69,33,98,33,70,68]

theorem envBound25821 : H12AffineFastState.Bounded env25821 := by
  intro p hp
  have h : env25821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25820_25821 : H12AffineEnvironment.transform 3 7 env25820 = env25821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env25820 == env25821) = true)

theorem identity25821 : scanCanonicalize (H12AffineFastState.compose env25821 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25821 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25822 : List Nat := [2,4,8,7,1,64,9,67,68,69,70,7,8,0,0,2,7,70,69,1,71,0,6,3,9,65,70,7,6,70,69,0,67,0,70,68]

theorem envBound25822 : H12AffineFastState.Bounded env25822 := by
  intro p hp
  have h : env25822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25821_25822 : H12AffineEnvironment.transform 4 1 env25821 = env25822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25821 == env25822) = true)

theorem identity25822 : scanCanonicalize (H12AffineFastState.compose env25822 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

end H12CloudChart0