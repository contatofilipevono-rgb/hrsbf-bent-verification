import H12CloudChart0Data167

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound42567 : H12AffineFastState.Bounded env42567 := by
  intro p hp
  have h : env42567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42566_42567 : H12AffineEnvironment.transform 12 1052 env42566 = env42567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env42566 == env42567) = true)

theorem identity42567 : scanCanonicalize (H12AffineFastState.compose env42567 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 1046) := by decide +kernel

theorem selectedBound42567 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42568 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,16384,20497,1046,17664,3124,1025,20496,4113,32,16,20498,1053,16,3344,4096,17664,22837,20,1329,257,20529,17681,1808]

theorem envBound42568 : H12AffineFastState.Bounded env42568 := by
  intro p hp
  have h : env42568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42567_42568 : H12AffineEnvironment.transform 15 1046 env42567 = env42568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1046 env42567 == env42568) = true)

theorem identity42568 : scanCanonicalize (H12AffineFastState.compose env42568 (packedSelected [2,5,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound42568 : packedSelected [2,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env42569 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,16384,20497,262,16400,2340,273,20496,4113,32,16,20498,269,16,2048,4096,16400,22837,20,33,257,20529,16385,512]

theorem envBound42569 : H12AffineFastState.Bounded env42569 := by
  intro p hp
  have h : env42569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42568_42569 : H12AffineEnvironment.transform 9 272 env42568 = env42569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env42568 == env42569) = true)

theorem identity42569 : scanCanonicalize (H12AffineFastState.compose env42569 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound42569 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env42570 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2325,268,16384,18692,262,16400,2340,273,18693,2308,32,16,18695,269,16,2048,2325,16400,16416,20,33,257,18724,16385,512]

theorem envBound42570 : H12AffineFastState.Bounded env42570 := by
  intro p hp
  have h : env42570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42569_42570 : H12AffineEnvironment.transform 11 2325 env42569 = env42570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env42569 == env42570) = true)

theorem identity42570 : scanCanonicalize (H12AffineFastState.compose env42570 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42570 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42571 : List Nat := [2,4,8,16,1,16,9,256,512,272,2048,2325,268,16384,18692,262,16400,2309,273,18693,2308,1,16,18695,269,16,2048,2325,16400,16385,20,0,257,18693,16385,512]

theorem envBound42571 : H12AffineFastState.Bounded env42571 := by
  intro p hp
  have h : env42571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42570_42571 : H12AffineEnvironment.transform 4 1 env42570 = env42571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42570 == env42571) = true)

theorem identity42571 : scanCanonicalize (H12AffineFastState.compose env42571 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound42571 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env42572 : List Nat := [2,4,8,16,1,16,9,256,512,272,2048,2325,268,2308,0,262,2324,2309,273,1,2308,1,16,3,269,16,2048,2325,2324,2309,20,0,257,1,2309,512]

theorem envBound42572 : H12AffineFastState.Bounded env42572 := by
  intro p hp
  have h : env42572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42571_42572 : H12AffineEnvironment.transform 13 2308 env42571 = env42572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env42571 == env42572) = true)

theorem identity42572 : scanCanonicalize (H12AffineFastState.compose env42572 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42572 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42573 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,2064,9,2049,0,3,2065,2048,20,1,2049,1,16,3,8,16,2048,2064,2065,2048,20,0,4,1,2048,512]

theorem envBound42573 : H12AffineFastState.Bounded env42573 := by
  intro p hp
  have h : env42573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42572_42573 : H12AffineEnvironment.transform 7 5 env42572 = env42573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42572 == env42573) = true)

theorem identity42573 : scanCanonicalize (H12AffineFastState.compose env42573 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound42573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42574 : List Nat := [2,4,8,16,1,16,9,5,0,21,2048,2064,9,2049,0,3,2065,2048,20,1,2049,1,16,3,8,16,2048,2064,2065,2048,20,0,4,1,2048,0]

theorem envBound42574 : H12AffineFastState.Bounded env42574 := by
  intro p hp
  have h : env42574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42573_42574 : H12AffineEnvironment.transform 8 0 env42573 = env42574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env42573 == env42574) = true)

theorem identity42574 : scanCanonicalize (H12AffineFastState.compose env42574 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound42574 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42575 : List Nat := [2,4,8,4,1,4,9,5,0,1,2048,2052,9,2049,0,3,2053,2048,0,1,2049,1,4,3,8,4,2048,2052,2053,2048,0,0,4,1,2048,0]

theorem envBound42575 : H12AffineFastState.Bounded env42575 := by
  intro p hp
  have h : env42575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42574_42575 : H12AffineEnvironment.transform 3 4 env42574 = env42575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env42574 == env42575) = true)

def env42576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,262144,1025,29828,4112,272513,73754,29830,8328,17,10509,70814,91402,357643,9224,338311,257,29861,24964,66446]

theorem envBound42576 : H12AffineFastState.Bounded env42576 := by
  intro p hp
  have h : env42576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42563_42576 : H12AffineEnvironment.transform 5 17 env42563 = env42576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42563 == env42576) = true)

theorem identity42576 : scanCanonicalize (H12AffineFastState.compose env42576 (packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound42576 : packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env42577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,399,24980,262144,1025,29828,4112,272513,8597,29830,8328,17,10509,5393,25733,291972,9224,272392,257,29861,24964,513]

theorem envBound42577 : H12AffineFastState.Bounded env42577 := by
  intro p hp
  have h : env42577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42576_42577 : H12AffineEnvironment.transform 15 399 env42576 = env42577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env42576 == env42577) = true)

def env42578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411972,213471,16777216,8328,64,16959642,16974300,102879,360927,16958926,17148372,257,16777250,16834950,17031705]

theorem envBound42578 : H12AffineFastState.Bounded env42578 := by
  intro p hp
  have h : env42578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42534_42578 : H12AffineEnvironment.transform 20 165201 env42534 = env42578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env42534 == env42578) = true)

def env42579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318548,120015,16777216,8328,64,16801162,16880844,102879,360927,16797918,17148372,257,16777250,16834950,16873225]

theorem envBound42579 : H12AffineFastState.Bounded env42579 := by
  intro p hp
  have h : env42579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42578_42579 : H12AffineEnvironment.transform 16 38160 env42578 = env42579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env42578 == env42579) = true)

theorem identity42579 : scanCanonicalize (H12AffineFastState.compose env42579 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95496) := by decide +kernel

theorem selectedBound42579 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318548,120015,95496,8328,64,75906,57796,102879,360927,75222,318684,257,95530,103566,513]

theorem envBound42580 : H12AffineFastState.Bounded env42580 := by
  intro p hp
  have h : env42580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42579_42580 : H12AffineEnvironment.transform 23 95496 env42579 = env42580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env42579 == env42580) = true)

def env42581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318548,119879,95496,8192,64,75786,57676,102743,360791,75102,318548,257,95530,103430,513]

theorem envBound42581 : H12AffineFastState.Bounded env42581 := by
  intro p hp
  have h : env42581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42580_42581 : H12AffineEnvironment.transform 6 8 env42580 = env42581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42580 == env42581) = true)

theorem identity42581 : scanCanonicalize (H12AffineFastState.compose env42581 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound42581 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env42582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38160,262144,1025,32769,4161,318548,8524,32771,8192,64,56577,57676,25692,291932,53333,318548,257,32801,24845,513]

theorem envBound42582 : H12AffineFastState.Bounded env42582 := by
  intro p hp
  have h : env42582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42581_42582 : H12AffineEnvironment.transform 15 62731 env42581 = env42582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env42581 == env42582) = true)

theorem identity42582 : scanCanonicalize (H12AffineFastState.compose env42582 (packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound42582 : packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env42583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38160,22884,1025,32769,4161,34096,8524,32771,8192,64,56577,57676,25692,11576,53333,34096,257,32801,24845,513]

theorem envBound42583 : H12AffineFastState.Bounded env42583 := by
  intro p hp
  have h : env42583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42582_42583 : H12AffineEnvironment.transform 17 22884 env42582 = env42583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env42582 == env42583) = true)

theorem identity42583 : scanCanonicalize (H12AffineFastState.compose env42583 (packedSelected [0,4,8,9,10,17,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound42583 : packedSelected [0,4,8,9,10,17,20,27,28] rootPS < 2^1333 := by decide +kernel

def env42584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12572,32768,33815,38160,10360,1025,32769,4161,34096,8524,32771,8192,64,44061,36944,5440,11576,41289,34096,257,32801,4113,513]

theorem envBound42584 : H12AffineFastState.Bounded env42584 := by
  intro p hp
  have h : env42584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42583_42584 : H12AffineEnvironment.transform 13 12572 env42583 = env42584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env42583 == env42584) = true)

theorem identity42584 : scanCanonicalize (H12AffineFastState.compose env42584 (packedSelected [0,2,3,5,6,7,10,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound42584 : packedSelected [0,2,3,5,6,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env42585 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,8192,12572,32768,33110,36945,10360,320,32769,4161,32881,8524,32771,8192,64,43356,36944,4097,10361,41289,32881,257,32801,4113,513]

theorem envBound42585 : H12AffineFastState.Bounded env42585 := by
  intro p hp
  have h : env42585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42584_42585 : H12AffineEnvironment.transform 9 321 env42584 = env42585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42584 == env42585) = true)

theorem identity42585 : scanCanonicalize (H12AffineFastState.compose env42585 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42585 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42586 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,8192,12393,32768,32803,36945,10360,53,32769,4161,32881,8249,32771,8192,64,43049,36944,4097,10361,41020,32881,116,32801,4113,513]

theorem envBound42586 : H12AffineFastState.Bounded env42586 := by
  intro p hp
  have h : env42586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42585_42586 : H12AffineEnvironment.transform 7 117 env42585 = env42586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42585 == env42586) = true)

theorem identity42586 : scanCanonicalize (H12AffineFastState.compose env42586 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(14+1) ^^^ 6161) := by decide +kernel

theorem selectedBound42586 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env42587 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,8192,12393,6161,6194,2112,10360,53,6160,4161,6240,8249,6162,8192,64,12344,2113,4097,10361,14381,6240,116,6192,4113,513]

theorem envBound42587 : H12AffineFastState.Bounded env42587 := by
  intro p hp
  have h : env42587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42586_42587 : H12AffineEnvironment.transform 14 6161 env42586 = env42587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6161 env42586 == env42587) = true)

theorem identity42587 : scanCanonicalize (H12AffineFastState.compose env42587 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4200) := by decide +kernel

theorem selectedBound42587 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env42588 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,4200,1,6161,6194,2112,6160,53,6160,4161,6240,4177,6162,4200,64,80,2113,4097,6161,2117,6240,116,6192,4113,513]

theorem envBound42588 : H12AffineFastState.Bounded env42588 := by
  intro p hp
  have h : env42588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42587_42588 : H12AffineEnvironment.transform 12 4200 env42587 = env42588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4200 env42587 == env42588) = true)

theorem identity42588 : scanCanonicalize (H12AffineFastState.compose env42588 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound42588 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42589 : List Nat := [2,4,8,16,32,64,8,117,512,52,80,4096,4200,1,4161,4194,16,4160,53,4160,4161,4144,4177,4162,4200,64,80,17,4097,4161,21,4144,116,4192,4113,513]

theorem envBound42589 : H12AffineFastState.Bounded env42589 := by
  intro p hp
  have h : env42589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42588_42589 : H12AffineEnvironment.transform 10 80 env42588 = env42589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env42588 == env42589) = true)

theorem identity42589 : scanCanonicalize (H12AffineFastState.compose env42589 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound42589 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env42590 : List Nat := [2,4,8,16,32,64,8,117,512,52,80,16,120,1,81,114,16,80,53,80,81,32,65,82,120,64,80,17,17,81,21,32,116,112,1,513]

theorem envBound42590 : H12AffineFastState.Bounded env42590 := by
  intro p hp
  have h : env42590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42589_42590 : H12AffineEnvironment.transform 11 16 env42589 = env42590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env42589 == env42590) = true)

theorem identity42590 : scanCanonicalize (H12AffineFastState.compose env42590 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42590 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env42591 : List Nat := [2,4,8,16,32,1,8,52,512,52,17,16,57,1,16,51,16,17,53,17,16,32,0,19,57,1,17,17,17,16,21,32,53,49,1,513]

theorem envBound42591 : H12AffineFastState.Bounded env42591 := by
  intro p hp
  have h : env42591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42590_42591 : H12AffineEnvironment.transform 5 1 env42590 = env42591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42590 == env42591) = true)

def env42592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318548,119878,95496,8193,64,75787,57677,102742,360790,75103,318549,257,95530,103431,513]

theorem envBound42592 : H12AffineFastState.Bounded env42592 := by
  intro p hp
  have h : env42592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42580_42592 : H12AffineEnvironment.transform 6 9 env42580 = env42592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42580 == env42592) = true)

theorem identity42592 : scanCanonicalize (H12AffineFastState.compose env42592 (packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound42592 : packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env42593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35188,1025,32769,4161,21792,119878,95496,8193,64,75787,57677,102742,67618,75103,21793,257,95530,103431,513]

theorem envBound42593 : H12AffineFastState.Bounded env42593 := by
  intro p hp
  have h : env42593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42592_42593 : H12AffineEnvironment.transform 17 35188 env42592 = env42593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env42592 == env42593) = true)

theorem identity42593 : scanCanonicalize (H12AffineFastState.compose env42593 (packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound42593 : packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env42594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38160,35188,1025,32769,4161,21792,8525,32771,8193,64,56576,57677,25693,64809,53332,21793,257,32801,24844,513]

theorem envBound42594 : H12AffineFastState.Bounded env42594 := by
  intro p hp
  have h : env42594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42593_42594 : H12AffineEnvironment.transform 15 62731 env42593 = env42594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env42593 == env42594) = true)

theorem identity42594 : scanCanonicalize (H12AffineFastState.compose env42594 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42594 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env42595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,40971,38160,35188,1025,32769,4161,32,8525,32771,8193,64,34816,46157,12637,43049,34132,33,257,32801,13324,513]

theorem envBound42595 : H12AffineFastState.Bounded env42595 := by
  intro p hp
  have h : env42595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42594_42595 : H12AffineEnvironment.transform 13 5376 env42594 = env42595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42594 == env42595) = true)

theorem identity42595 : scanCanonicalize (H12AffineFastState.compose env42595 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42595 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,342,13389,10281,1025,8540,4161,32,8525,8542,8193,64,10589,5392,12637,2420,9225,33,257,8572,13324,513]

theorem envBound42596 : H12AffineFastState.Bounded env42596 := by
  intro p hp
  have h : env42596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42595_42596 : H12AffineEnvironment.transform 14 8541 env42595 = env42596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42595 == env42596) = true)

theorem identity42596 : scanCanonicalize (H12AffineFastState.compose env42596 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42596 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42597 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,262,13341,10281,1025,8460,4113,32,8477,8462,8193,16,10509,5392,12557,2340,9225,33,257,8492,13324,513]

theorem envBound42597 : H12AffineFastState.Bounded env42597 := by
  intro p hp
  have h : env42597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42596_42597 : H12AffineEnvironment.transform 5 16 env42596 = env42597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42596 == env42597) = true)

theorem identity42597 : scanCanonicalize (H12AffineFastState.compose env42597 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound42597 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42598 : List Nat := [2,4,8,16,32,16,9,256,512,784,2048,4096,8192,4624,8461,262,13069,10281,785,8460,4113,32,8477,8462,8193,16,10509,4608,12557,2340,8985,33,257,8492,13084,513]

theorem envBound42598 : H12AffineFastState.Bounded env42598 := by
  intro p hp
  have h : env42598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42597_42598 : H12AffineEnvironment.transform 9 784 env42597 = env42598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env42597 == env42598) = true)

theorem identity42598 : scanCanonicalize (H12AffineFastState.compose env42598 (packedSelected [1,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42598 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env42599 : List Nat := [2,4,8,16,32,16,9,256,512,784,2048,4096,268,4624,1,262,4609,2341,785,0,4113,32,17,2,269,16,2049,4608,4097,2340,533,33,257,32,4624,513]

theorem envBound42599 : H12AffineFastState.Bounded env42599 := by
  intro p hp
  have h : env42599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42598_42599 : H12AffineEnvironment.transform 12 268 env42598 = env42599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42598 == env42599) = true)

theorem identity42599 : scanCanonicalize (H12AffineFastState.compose env42599 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound42599 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42600 : List Nat := [2,4,8,16,32,16,9,256,512,784,2048,261,268,789,1,262,772,2341,785,0,276,32,17,2,269,16,2049,773,260,2340,533,33,257,32,789,513]

theorem envBound42600 : H12AffineFastState.Bounded env42600 := by
  intro p hp
  have h : env42600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42599_42600 : H12AffineEnvironment.transform 11 261 env42599 = env42600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env42599 == env42600) = true)

theorem identity42600 : scanCanonicalize (H12AffineFastState.compose env42600 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound42600 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42601 : List Nat := [2,4,8,16,32,16,9,256,512,784,293,261,268,789,1,262,772,0,785,0,276,32,17,2,269,16,292,773,260,1,533,33,257,32,789,513]

theorem envBound42601 : H12AffineFastState.Bounded env42601 := by
  intro p hp
  have h : env42601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42600_42601 : H12AffineEnvironment.transform 10 293 env42600 = env42601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env42600 == env42601) = true)

theorem identity42601 : scanCanonicalize (H12AffineFastState.compose env42601 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42601 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42602 : List Nat := [2,4,8,0,32,0,9,256,512,768,293,261,268,773,1,262,772,0,769,0,260,32,1,2,269,0,292,773,260,1,517,33,257,32,773,513]

theorem envBound42602 : H12AffineFastState.Bounded env42602 := by
  intro p hp
  have h : env42602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42601_42602 : H12AffineEnvironment.transform 3 0 env42601 = env42602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42601 == env42602) = true)

theorem identity42602 : scanCanonicalize (H12AffineFastState.compose env42602 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound42602 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42603 : List Nat := [2,4,8,0,32,0,9,256,260,4,293,261,268,1,1,262,0,0,5,0,260,32,1,2,269,0,292,1,260,1,257,33,257,32,1,261]

theorem envBound42603 : H12AffineFastState.Bounded env42603 := by
  intro p hp
  have h : env42603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42602_42603 : H12AffineEnvironment.transform 8 260 env42602 = env42603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env42602 == env42603) = true)

def env42604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318549,120014,16777216,8328,64,16801163,16880845,102879,360927,16797919,17148372,257,16777250,16834950,16873224]

theorem envBound42604 : H12AffineFastState.Bounded env42604 := by
  intro p hp
  have h : env42604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42578_42604 : H12AffineEnvironment.transform 16 38161 env42578 = env42604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env42578 == env42604) = true)

def env42605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318549,120014,338048,8328,64,357643,310349,102879,360927,358495,33108,257,338082,379142,286600]

theorem envBound42605 : H12AffineFastState.Bounded env42605 := by
  intro p hp
  have h : env42605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42604_42605 : H12AffineEnvironment.transform 23 338048 env42604 = env42605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338048 env42604 == env42605) = true)

theorem identity42605 : scanCanonicalize (H12AffineFastState.compose env42605 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound42605 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env42606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35325,1025,32769,4160,21928,120014,106877,8328,64,130294,13744,102879,67618,127394,33108,257,106847,82171,54901]

theorem envBound42606 : H12AffineFastState.Bounded env42606 := by
  intro p hp
  have h : env42606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42605_42606 : H12AffineEnvironment.transform 17 35325 env42605 = env42606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env42605 == env42606) = true)

def env42607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,13389,10401,1025,8541,4160,21928,95634,65569,8328,64,89514,13744,77955,67618,86270,8200,257,65539,82171,30505]

theorem envBound42607 : H12AffineFastState.Bounded env42607 := by
  intro p hp
  have h : env42607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42606_42607 : H12AffineEnvironment.transform 14 8540 env42606 = env42607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42606 == env42607) = true)

theorem identity42607 : scanCanonicalize (H12AffineFastState.compose env42607 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound42607 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29963,13389,10401,1025,8541,4160,21928,153,29994,8328,64,10401,13744,17800,32041,9717,8200,257,29960,13808,30505]

theorem envBound42608 : H12AffineFastState.Bounded env42608 := by
  intro p hp
  have h : env42608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42607_42608 : H12AffineEnvironment.transform 15 29963 env42607 = env42608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env42607 == env42608) = true)

theorem identity42608 : scanCanonicalize (H12AffineFastState.compose env42608 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound42608 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env42609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13608,8540,35,13389,10401,1025,8541,4160,8320,153,2,8328,64,10401,13744,12448,2049,9717,8200,257,32,13808,513]

theorem envBound42609 : H12AffineFastState.Bounded env42609 := by
  intro p hp
  have h : env42609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42608_42609 : H12AffineEnvironment.transform 13 13608 env42608 = env42609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env42608 == env42609) = true)

theorem identity42609 : scanCanonicalize (H12AffineFastState.compose env42609 (packedSelected [1,4,8,9,10,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound42609 : packedSelected [1,4,8,9,10,15,18] rootPS < 2^1333 := by decide +kernel

def env42610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6476,3172,6160,35,3329,4589,1025,6161,4160,6604,153,2,6596,64,4589,3324,2540,2049,7353,6468,257,32,3260,513]

theorem envBound42610 : H12AffineFastState.Bounded env42610 := by
  intro p hp
  have h : env42610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42609_42610 : H12AffineEnvironment.transform 12 6476 env42609 = env42610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env42609 == env42610) = true)

theorem identity42610 : scanCanonicalize (H12AffineFastState.compose env42610 (packedSelected [0,1,2,6,7,8,10,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound42610 : packedSelected [0,1,2,6,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env42611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1196,3552,3172,3260,35,3329,1345,1025,3261,1260,3424,153,2,3432,64,1345,3324,2540,2049,2069,3560,257,32,3260,513]

theorem envBound42611 : H12AffineFastState.Bounded env42611 := by
  intro p hp
  have h : env42611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42610_42611 : H12AffineEnvironment.transform 11 1196 env42610 = env42611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env42610 == env42611) = true)

theorem identity42611 : scanCanonicalize (H12AffineFastState.compose env42611 (packedSelected [0,1,2,6,7,8,10,11,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound42611 : packedSelected [0,1,2,6,7,8,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,293,1196,1221,1345,1433,35,1060,1345,1025,1432,1260,1093,153,2,1101,64,1345,1497,201,292,304,1229,257,32,1433,513]

theorem envBound42612 : H12AffineFastState.Bounded env42612 := by
  intro p hp
  have h : env42612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42611_42612 : H12AffineEnvironment.transform 10 293 env42611 = env42612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env42611 == env42612) = true)

theorem identity42612 : scanCanonicalize (H12AffineFastState.compose env42612 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42612 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,1060,1101,1345,1297,35,1060,1345,1025,1296,1124,1093,17,2,1101,64,1345,1361,65,292,304,1093,257,32,1297,513]

theorem envBound42613 : H12AffineFastState.Bounded env42613 := by
  intro p hp
  have h : env42613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42612_42613 : H12AffineEnvironment.transform 6 8 env42612 = env42613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42612 == env42613) = true)

theorem identity42613 : scanCanonicalize (H12AffineFastState.compose env42613 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound42613 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env42614 : List Nat := [2,4,8,16,32,64,8,256,512,273,293,309,348,80,0,35,309,80,272,1,373,340,17,2,348,64,80,64,65,292,304,340,257,32,0,513]

theorem envBound42614 : H12AffineFastState.Bounded env42614 := by
  intro p hp
  have h : env42614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42613_42614 : H12AffineEnvironment.transform 9 273 env42613 = env42614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env42613 == env42614) = true)

theorem identity42614 : scanCanonicalize (H12AffineFastState.compose env42614 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 52) := by decide +kernel

theorem selectedBound42614 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42615 : List Nat := [2,4,8,16,32,52,8,256,512,273,293,309,296,36,0,35,309,36,272,1,257,288,17,2,296,52,36,52,53,292,304,288,257,32,0,513]

theorem envBound42615 : H12AffineFastState.Bounded env42615 := by
  intro p hp
  have h : env42615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42614_42615 : H12AffineEnvironment.transform 5 52 env42614 = env42615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 52 env42614 == env42615) = true)

theorem identity42615 : scanCanonicalize (H12AffineFastState.compose env42615 (packedSelected [1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound42615 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env42616 : List Nat := [2,4,8,16,32,52,8,9,512,24,44,60,33,36,0,35,60,36,25,1,8,41,17,2,33,52,36,52,53,45,57,41,8,32,0,513]

theorem envBound42616 : H12AffineFastState.Bounded env42616 := by
  intro p hp
  have h : env42616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42615_42616 : H12AffineEnvironment.transform 7 9 env42615 = env42616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env42615 == env42616) = true)

theorem identity42616 : scanCanonicalize (H12AffineFastState.compose env42616 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound42616 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env42617 : List Nat := [2,4,8,16,16,4,8,9,512,24,28,12,17,20,0,19,12,20,25,1,8,25,17,2,17,4,20,4,5,29,9,25,8,16,0,513]

theorem envBound42617 : H12AffineFastState.Bounded env42617 := by
  intro p hp
  have h : env42617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42616_42617 : H12AffineEnvironment.transform 4 16 env42616 = env42617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env42616 == env42617) = true)

theorem identity42617 : scanCanonicalize (H12AffineFastState.compose env42617 (packedSelected [1,6] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42617 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env42618 : List Nat := [2,4,8,16,16,4,8,9,17,24,28,12,17,20,0,19,12,20,25,1,8,25,17,2,17,4,20,4,5,29,9,25,8,16,0,16]

theorem envBound42618 : H12AffineFastState.Bounded env42618 := by
  intro p hp
  have h : env42618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42617_42618 : H12AffineEnvironment.transform 8 17 env42617 = env42618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42617 == env42618) = true)

theorem identity42618 : scanCanonicalize (H12AffineFastState.compose env42618 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound42618 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42619 : List Nat := [2,4,8,6,6,4,8,9,7,14,10,12,7,2,0,5,12,2,15,1,8,15,7,2,7,4,2,4,5,11,9,15,8,6,0,6]

theorem envBound42619 : H12AffineFastState.Bounded env42619 := by
  intro p hp
  have h : env42619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42618_42619 : H12AffineEnvironment.transform 3 6 env42618 = env42619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env42618 == env42619) = true)

theorem identity42619 : scanCanonicalize (H12AffineFastState.compose env42619 (packedSelected [2,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42619 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env42620 : List Nat := [2,2,8,0,0,2,8,9,1,8,10,10,1,2,0,3,10,2,9,1,8,9,1,2,1,2,2,2,3,11,9,9,8,0,0,0]

theorem envBound42620 : H12AffineFastState.Bounded env42620 := by
  intro p hp
  have h : env42620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42619_42620 : H12AffineEnvironment.transform 1 2 env42619 = env42620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42619 == env42620) = true)

def env42621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,13388,10400,1025,8540,4160,21928,95635,65568,8328,64,89515,13744,77954,67618,86271,8201,257,65538,82171,30504]

theorem envBound42621 : H12AffineFastState.Bounded env42621 := by
  intro p hp
  have h : env42621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42606_42621 : H12AffineEnvironment.transform 14 8541 env42606 = env42621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42606 == env42621) = true)

theorem identity42621 : scanCanonicalize (H12AffineFastState.compose env42621 (packedSelected [0,2,4,6,7,9,16,20,23,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 29943) := by decide +kernel

theorem selectedBound42621 : packedSelected [0,2,4,6,7,9,16,20,23,32,35] rootPS < 2^1333 := by decide +kernel

def env42622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29943,13388,10400,1025,8540,4160,21928,356,29911,8328,64,10588,13744,17525,31957,9224,8201,257,29941,13324,30504]

theorem envBound42622 : H12AffineFastState.Bounded env42622 := by
  intro p hp
  have h : env42622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42621_42622 : H12AffineEnvironment.transform 15 29943 env42621 = env42622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29943 env42621 == env42622) = true)

theorem identity42622 : scanCanonicalize (H12AffineFastState.compose env42622 (packedSelected [0,3,7,9,10,14,16,18,19,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound42622 : packedSelected [0,3,7,9,10,14,16,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env42623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5373,8541,8202,13388,10400,1025,8540,4160,341,356,8234,8328,64,10588,13744,4232,10280,9224,8201,257,8200,13324,9173]

theorem envBound42623 : H12AffineFastState.Bounded env42623 := by
  intro p hp
  have h : env42623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42622_42623 : H12AffineEnvironment.transform 13 5373 env42622 = env42623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env42622 == env42623) = true)

theorem identity42623 : scanCanonicalize (H12AffineFastState.compose env42623 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42623 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env42624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5373,81,262,5440,2476,1025,80,4160,341,356,294,388,64,2128,5308,4232,2340,1284,261,257,260,5376,729]

theorem envBound42624 : H12AffineFastState.Bounded env42624 := by
  intro p hp
  have h : env42624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42623_42624 : H12AffineEnvironment.transform 12 268 env42623 = env42624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42623 == env42624) = true)

theorem identity42624 : scanCanonicalize (H12AffineFastState.compose env42624 (packedSelected [1,3,5,8,10,11,14,15,19] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound42624 : packedSelected [1,3,5,8,10,11,14,15,19] rootPS < 2^1333 := by decide +kernel

def env42625 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,4096,268,4161,81,262,4604,2476,189,80,4160,341,356,294,388,64,2128,4096,4232,2340,440,261,257,260,4540,729]

theorem envBound42625 : H12AffineFastState.Bounded env42625 := by
  intro p hp
  have h : env42625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42624_42625 : H12AffineEnvironment.transform 9 188 env42624 = env42625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env42624 == env42625) = true)

theorem identity42625 : scanCanonicalize (H12AffineFastState.compose env42625 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42625 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42626 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,268,4112,0,262,4525,2476,189,1,4113,260,309,294,388,17,2049,4096,4232,2340,440,261,257,260,4540,648]

theorem envBound42626 : H12AffineFastState.Bounded env42626 := by
  intro p hp
  have h : env42626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42625_42626 : H12AffineEnvironment.transform 5 17 env42625 = env42626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42625 == env42626) = true)

theorem identity42626 : scanCanonicalize (H12AffineFastState.compose env42626 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound42626 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42627 : List Nat := [2,4,8,16,32,17,128,173,512,188,2048,4096,161,4112,0,171,4096,2049,189,1,4113,169,152,139,41,17,2049,4096,4232,2185,21,168,172,169,4113,648]

theorem envBound42627 : H12AffineFastState.Bounded env42627 := by
  intro p hp
  have h : env42627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42626_42627 : H12AffineEnvironment.transform 7 173 env42626 = env42627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env42626 == env42627) = true)

theorem identity42627 : scanCanonicalize (H12AffineFastState.compose env42627 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound42627 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42628 : List Nat := [2,4,8,16,32,17,41,4,512,21,2048,4096,8,4112,0,2,4096,2049,20,1,4113,0,49,34,41,17,2049,4096,4129,2080,21,1,5,0,4113,545]

theorem envBound42628 : H12AffineFastState.Bounded env42628 := by
  intro p hp
  have h : env42628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42627_42628 : H12AffineEnvironment.transform 6 41 env42627 = env42628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env42627 == env42628) = true)

def env42629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318549,120014,338049,8328,64,357642,310348,102879,360927,358494,33109,257,338083,379143,286601]

theorem envBound42629 : H12AffineFastState.Bounded env42629 := by
  intro p hp
  have h : env42629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42604_42629 : H12AffineEnvironment.transform 23 338049 env42604 = env42629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338049 env42604 == env42629) = true)

theorem identity42629 : scanCanonicalize (H12AffineFastState.compose env42629 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound42629 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env42630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35188,1025,32769,4160,21793,120014,106997,8328,64,130174,13624,102879,67755,127274,33109,257,106967,82035,55037]

theorem envBound42630 : H12AffineFastState.Bounded env42630 := by
  intro p hp
  have h : env42630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42629_42630 : H12AffineEnvironment.transform 17 35188 env42629 = env42630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env42629 == env42630) = true)

def env42631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,13509,10400,1025,8661,4160,21793,95514,65569,8328,64,89514,13624,77835,67755,86270,8321,257,65539,82035,30505]

theorem envBound42631 : H12AffineFastState.Bounded env42631 := by
  intro p hp
  have h : env42631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42630_42631 : H12AffineEnvironment.transform 14 8660 env42630 = env42631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env42630 == env42631) = true)

theorem identity42631 : scanCanonicalize (H12AffineFastState.compose env42631 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42631 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42632 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,13388,10281,1025,8540,4160,21793,95514,65569,8193,64,89379,13624,77835,67618,86135,8200,257,65539,82035,30505]

theorem envBound42632 : H12AffineFastState.Bounded env42632 := by
  intro p hp
  have h : env42632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42631_42632 : H12AffineEnvironment.transform 6 9 env42631 = env42632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42631 == env42632) = true)

theorem identity42632 : scanCanonicalize (H12AffineFastState.compose env42632 (packedSelected [0,2,6,7,11,12,15,16,23] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound42632 : packedSelected [0,2,6,7,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env42633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21795,13388,10281,1025,8540,4160,21793,8249,21762,8193,64,2048,13624,25896,23809,1364,8200,257,21792,5456,30505]

theorem envBound42633 : H12AffineFastState.Bounded env42633 := by
  intro p hp
  have h : env42633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42632_42633 : H12AffineEnvironment.transform 15 21795 env42632 = env42633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env42632 == env42633) = true)

theorem identity42633 : scanCanonicalize (H12AffineFastState.compose env42633 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42633 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env42634 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,21590,13388,10281,1025,8233,4160,21588,8249,21623,8193,64,2048,13389,25693,23668,1057,8200,116,21589,5157,30300]

theorem envBound42634 : H12AffineFastState.Bounded env42634 := by
  intro p hp
  have h : env42634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42633_42634 : H12AffineEnvironment.transform 7 117 env42633 = env42634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42633 == env42634) = true)

theorem identity42634 : scanCanonicalize (H12AffineFastState.compose env42634 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound42634 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env42635 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,8232,35,13388,10281,1025,8233,4160,33,8249,2,8193,64,2048,13389,12328,2049,1057,8200,116,32,5157,8745]

theorem envBound42635 : H12AffineFastState.Bounded env42635 := by
  intro p hp
  have h : env42635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42634_42635 : H12AffineEnvironment.transform 13 5237 env42634 = env42635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env42634 == env42635) = true)

theorem identity42635 : scanCanonicalize (H12AffineFastState.compose env42635 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound42635 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42636 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,0,35,5220,2049,1025,1,4160,33,17,2,41,64,2048,5221,4096,2049,1057,32,116,32,5157,513]

theorem envBound42636 : H12AffineFastState.Bounded env42636 := by
  intro p hp
  have h : env42636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42635_42636 : H12AffineEnvironment.transform 12 40 env42635 = env42636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env42635 == env42636) = true)

theorem identity42636 : scanCanonicalize (H12AffineFastState.compose env42636 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound42636 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42637 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1134,4096,40,5237,0,35,5220,1135,1025,1,4160,33,17,2,41,64,1134,5221,4096,1135,1057,32,116,32,5157,513]

theorem envBound42637 : H12AffineFastState.Bounded env42637 := by
  intro p hp
  have h : env42637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42636_42637 : H12AffineEnvironment.transform 10 1134 env42636 = env42637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env42636 == env42637) = true)

theorem identity42637 : scanCanonicalize (H12AffineFastState.compose env42637 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound42637 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42638 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1134,1125,40,16,0,35,1,1135,1025,1,1061,33,17,2,41,64,1134,0,1125,1135,1057,32,116,32,64,513]

theorem envBound42638 : H12AffineFastState.Bounded env42638 := by
  intro p hp
  have h : env42638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42637_42638 : H12AffineEnvironment.transform 11 1125 env42637 = env42638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env42637 == env42638) = true)

theorem identity42638 : scanCanonicalize (H12AffineFastState.compose env42638 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound42638 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42639 : List Nat := [2,4,8,16,32,26,9,47,512,1024,1076,1087,40,16,0,35,1,1077,1025,1,1061,33,17,2,41,26,1076,0,1087,1077,1057,32,46,32,26,513]

theorem envBound42639 : H12AffineFastState.Bounded env42639 := by
  intro p hp
  have h : env42639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42638_42639 : H12AffineEnvironment.transform 5 26 env42638 = env42639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env42638 == env42639) = true)

theorem identity42639 : scanCanonicalize (H12AffineFastState.compose env42639 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42639 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env42640 : List Nat := [2,4,8,1,32,11,9,47,512,1024,1061,1070,40,1,0,35,1,1060,1025,1,1061,33,0,2,41,11,1061,0,1070,1060,1057,32,46,32,11,513]

theorem envBound42640 : H12AffineFastState.Bounded env42640 := by
  intro p hp
  have h : env42640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42639_42640 : H12AffineEnvironment.transform 3 1 env42639 = env42640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42639 == env42640) = true)

theorem identity42640 : scanCanonicalize (H12AffineFastState.compose env42640 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound42640 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42641 : List Nat := [2,4,8,1,32,11,9,47,32,1024,1061,1070,40,1,0,35,1,1060,1025,1,1061,33,0,2,41,11,1061,0,1070,1060,1057,32,46,32,11,33]

theorem envBound42641 : H12AffineFastState.Bounded env42641 := by
  intro p hp
  have h : env42641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42640_42641 : H12AffineEnvironment.transform 8 32 env42640 = env42641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env42640 == env42641) = true)

theorem identity42641 : scanCanonicalize (H12AffineFastState.compose env42641 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 44) := by decide +kernel

theorem selectedBound42641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42642 : List Nat := [2,4,8,1,32,11,9,47,32,44,9,2,40,1,0,35,1,8,45,1,9,33,0,2,41,11,9,0,2,8,13,32,46,32,11,33]

theorem envBound42642 : H12AffineFastState.Bounded env42642 := by
  intro p hp
  have h : env42642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42641_42642 : H12AffineEnvironment.transform 9 44 env42641 = env42642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 44 env42641 == env42642) = true)

theorem identity42642 : scanCanonicalize (H12AffineFastState.compose env42642 (packedSelected [0,2,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42642 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env42643 : List Nat := [2,4,8,1,1,11,9,14,1,13,9,2,9,1,0,2,1,8,12,1,9,0,0,2,8,11,9,0,2,8,13,1,15,1,11,0]

theorem envBound42643 : H12AffineFastState.Bounded env42643 := by
  intro p hp
  have h : env42643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42642_42643 : H12AffineEnvironment.transform 4 1 env42642 = env42643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42642 == env42643) = true)

theorem identity42643 : scanCanonicalize (H12AffineFastState.compose env42643 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound42643 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42644 : List Nat := [2,4,7,1,1,4,6,1,1,2,6,2,6,1,0,2,1,7,3,1,6,0,0,2,7,4,6,0,2,7,2,1,0,1,4,0]

theorem envBound42644 : H12AffineFastState.Bounded env42644 := by
  intro p hp
  have h : env42644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42643_42644 : H12AffineEnvironment.transform 2 7 env42643 = env42644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env42643 == env42644) = true)

def env42645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,13508,10401,1025,8660,4160,21793,95515,65568,8328,64,89515,13624,77834,67755,86271,8320,257,65538,82035,30504]

theorem envBound42645 : H12AffineFastState.Bounded env42645 := by
  intro p hp
  have h : env42645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42630_42645 : H12AffineEnvironment.transform 14 8661 env42630 = env42645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env42630 == env42645) = true)

theorem identity42645 : scanCanonicalize (H12AffineFastState.compose env42645 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound42645 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29963,13508,10401,1025,8660,4160,21793,16,29995,8328,64,10400,13624,17665,32160,9716,8320,257,29961,13688,30504]

theorem envBound42646 : H12AffineFastState.Bounded env42646 := by
  intro p hp
  have h : env42646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42645_42646 : H12AffineEnvironment.transform 15 29963 env42645 = env42646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env42645 == env42646) = true)

theorem identity42646 : scanCanonicalize (H12AffineFastState.compose env42646 (packedSelected [2,4,5,7,9,11,12,14,15,18,19,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound42646 : packedSelected [2,4,5,7,9,11,12,14,15,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env42647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,16384,429,21875,5308,2265,1025,428,4160,21793,16,21843,240,64,2264,5440,17665,24024,1420,248,257,21873,5376,22352]

theorem envBound42647 : H12AffineFastState.Bounded env42647 := by
  intro p hp
  have h : env42647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42646_42647 : H12AffineEnvironment.transform 12 120 env42646 = env42647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env42646 == env42647) = true)

theorem identity42647 : scanCanonicalize (H12AffineFastState.compose env42647 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound42647 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5512,429,251,5308,2265,1025,428,4160,169,16,219,240,64,2264,5440,4233,2128,1420,248,257,249,5376,728]

theorem envBound42648 : H12AffineFastState.Bounded env42648 := by
  intro p hp
  have h : env42648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42647_42648 : H12AffineEnvironment.transform 13 5512 env42647 = env42648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env42647 == env42648) = true)

theorem identity42648 : scanCanonicalize (H12AffineFastState.compose env42648 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42648 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42649 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,5512,429,170,5308,2184,1025,428,4113,169,16,138,161,17,2185,5393,4233,2049,1420,169,257,168,5376,649]

theorem envBound42649 : H12AffineFastState.Bounded env42649 := by
  intro p hp
  have h : env42649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42648_42649 : H12AffineEnvironment.transform 5 17 env42648 = env42649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42648 == env42649) = true)

theorem identity42649 : scanCanonicalize (H12AffineFastState.compose env42649 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42649 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env42650 : List Nat := [2,4,8,16,32,17,128,256,512,53,2048,4096,41,4541,429,170,4233,2184,52,428,4113,169,16,138,161,17,2185,4388,4233,2049,441,169,257,168,4405,649]

theorem envBound42650 : H12AffineFastState.Bounded env42650 := by
  intro p hp
  have h : env42650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42649_42650 : H12AffineEnvironment.transform 9 53 env42649 = env42650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42649 == env42650) = true)

theorem identity42650 : scanCanonicalize (H12AffineFastState.compose env42650 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound42650 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42651 : List Nat := [2,4,8,16,32,17,128,173,512,53,2048,4096,41,4112,0,170,4233,2184,52,1,4113,169,16,138,161,17,2185,4233,4233,2049,20,169,172,168,4248,649]

theorem envBound42651 : H12AffineFastState.Bounded env42651 := by
  intro p hp
  have h : env42651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42650_42651 : H12AffineEnvironment.transform 7 173 env42650 = env42651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env42650 == env42651) = true)

theorem identity42651 : scanCanonicalize (H12AffineFastState.compose env42651 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2232) := by decide +kernel

theorem selectedBound42651 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42652 : List Nat := [2,4,8,16,32,17,128,173,512,53,2048,2232,41,2216,0,170,2097,2184,52,1,2217,169,16,138,161,17,2185,2097,2097,2049,20,169,172,168,2080,649]

theorem envBound42652 : H12AffineFastState.Bounded env42652 := by
  intro p hp
  have h : env42652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42651_42652 : H12AffineEnvironment.transform 11 2232 env42651 = env42652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2232 env42651 == env42652) = true)

theorem identity42652 : scanCanonicalize (H12AffineFastState.compose env42652 (packedSelected [3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound42652 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env42653 : List Nat := [2,4,8,16,32,17,40,5,512,53,2048,2064,41,2048,0,2,2097,2080,52,1,2049,1,16,34,9,17,2081,2097,2097,2049,20,1,4,0,2080,545]

theorem envBound42653 : H12AffineFastState.Bounded env42653 := by
  intro p hp
  have h : env42653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42652_42653 : H12AffineEnvironment.transform 6 40 env42652 = env42653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env42652 == env42653) = true)

theorem identity42653 : scanCanonicalize (H12AffineFastState.compose env42653 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42653 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42654 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2064,8,2048,0,2,2064,2049,21,1,2049,1,16,3,9,17,2048,2064,2064,2049,20,1,4,0,2049,512]

theorem envBound42654 : H12AffineFastState.Bounded env42654 := by
  intro p hp
  have h : env42654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42653_42654 : H12AffineEnvironment.transform 4 1 env42653 = env42654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42653 == env42654) = true)

def env42655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,411973,213471,16777216,8328,64,16959643,18973837,2299022,360927,16958926,19344516,257,19039603,19031255,17031705]

theorem envBound42655 : H12AffineFastState.Bounded env42655 := by
  intro p hp
  have h : env42655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42533_42655 : H12AffineEnvironment.transform 21 411973 env42533 = env42655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 411973 env42533 == env42655) = true)

def env42656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411973,213471,16777216,8328,64,16959643,16974301,102878,360927,16958926,17148372,257,16777251,16834951,17031705]

theorem envBound42656 : H12AffineFastState.Bounded env42656 := by
  intro p hp
  have h : env42656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42655_42656 : H12AffineEnvironment.transform 20 165200 env42655 = env42656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env42655 == env42656) = true)

theorem identity42656 : scanCanonicalize (H12AffineFastState.compose env42656 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 106504) := by decide +kernel

theorem selectedBound42656 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env42657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411973,213471,106504,8328,64,223379,172501,102878,360927,222662,264668,257,106539,82319,147985]

theorem envBound42657 : H12AffineFastState.Bounded env42657 := by
  intro p hp
  have h : env42657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42656_42657 : H12AffineEnvironment.transform 23 106504 env42656 = env42657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 106504 env42656 == env42657) = true)

def env42658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,131072,262144,1025,21761,151632,411973,213471,95496,8328,64,223379,160981,83166,349407,222662,264668,257,95531,82319,147985]

theorem envBound42658 : H12AffineFastState.Bounded env42658 := by
  intro p hp
  have h : env42658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42657_42658 : H12AffineEnvironment.transform 14 21760 env42657 = env42658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env42657 == env42658) = true)

theorem identity42658 : scanCanonicalize (H12AffineFastState.compose env42658 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42658 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,131072,262144,1025,21761,151632,411973,156116,21763,8328,64,149656,160981,25813,292052,148941,264668,257,21792,24964,147985]

theorem envBound42659 : H12AffineFastState.Bounded env42659 := by
  intro p hp
  have h : env42659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42658_42659 : H12AffineEnvironment.transform 15 8203 env42658 = env42659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42658 == env42659) = true)

def env42660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,131072,10280,1025,21761,151632,156013,156116,21763,8328,64,149656,160981,25813,23804,148941,8692,257,21792,24964,147985]

theorem envBound42660 : H12AffineFastState.Bounded env42660 := by
  intro p hp
  have h : env42660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42659_42660 : H12AffineEnvironment.transform 17 10280 env42659 = env42660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42659 == env42660) = true)

theorem identity42660 : scanCanonicalize (H12AffineFastState.compose env42660 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound42660 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42661 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,16384,20632,8203,131072,10280,409,20633,151632,156013,156116,20635,8328,64,149656,160077,24909,22884,147541,8692,257,20664,24964,147985]

theorem envBound42661 : H12AffineFastState.Bounded env42661 := by
  intro p hp
  have h : env42661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42660_42661 : H12AffineEnvironment.transform 9 408 env42660 = env42661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env42660 == env42661) = true)

theorem identity42661 : scanCanonicalize (H12AffineFastState.compose env42661 (packedSelected [1,2,4,6,8,11,17,18,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound42661 : packedSelected [1,2,4,6,8,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env42662 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,16384,20632,8203,24632,10280,409,20633,12392,341,492,20635,8328,64,10400,4469,24909,22884,8301,8692,257,20664,24964,8745]

theorem envBound42662 : H12AffineFastState.Bounded env42662 := by
  intro p hp
  have h : env42662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42661_42662 : H12AffineEnvironment.transform 16 24632 env42661 = env42662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env42661 == env42662) = true)

theorem identity42662 : scanCanonicalize (H12AffineFastState.compose env42662 (packedSelected [4,5,9,14,16,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound42662 : packedSelected [4,5,9,14,16,24,26] rootPS < 2^1333 := by decide +kernel

def env42663 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,40,16384,20632,35,16400,2048,409,20633,4160,341,492,20635,160,64,2184,4469,16741,22884,69,476,257,20664,16812,513]

theorem envBound42663 : H12AffineFastState.Bounded env42663 := by
  intro p hp
  have h : env42663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42662_42663 : H12AffineEnvironment.transform 12 40 env42662 = env42663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env42662 == env42663) = true)

theorem identity42663 : scanCanonicalize (H12AffineFastState.compose env42663 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42663 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42664 : List Nat := [2,4,8,16,32,64,128,117,512,237,2048,4096,40,16384,20632,35,16400,2048,236,20633,4160,32,153,20635,160,64,2184,4096,16400,22545,69,169,116,20664,16601,513]

theorem envBound42664 : H12AffineFastState.Bounded env42664 := by
  intro p hp
  have h : env42664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42663_42664 : H12AffineEnvironment.transform 7 117 env42663 = env42664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42663 == env42664) = true)

theorem identity42664 : scanCanonicalize (H12AffineFastState.compose env42664 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound42664 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42665 : List Nat := [2,4,8,16,32,64,128,117,512,237,2048,4096,40,4113,137,35,4097,2048,236,136,4160,32,153,138,160,64,2184,4096,4097,2048,69,169,116,169,4296,513]

theorem envBound42665 : H12AffineFastState.Bounded env42665 := by
  intro p hp
  have h : env42665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42664_42665 : H12AffineEnvironment.transform 13 4113 env42664 = env42665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env42664 == env42665) = true)

theorem identity42665 : scanCanonicalize (H12AffineFastState.compose env42665 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound42665 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env42666 : List Nat := [2,4,8,16,32,64,128,117,512,237,136,4096,40,4113,137,35,4097,136,236,136,4160,32,153,138,160,64,0,4096,4097,136,69,169,116,169,4296,513]

theorem envBound42666 : H12AffineFastState.Bounded env42666 := by
  intro p hp
  have h : env42666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42665_42666 : H12AffineEnvironment.transform 10 136 env42665 = env42666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env42665 == env42666) = true)

theorem identity42666 : scanCanonicalize (H12AffineFastState.compose env42666 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42666 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env42667 : List Nat := [2,4,8,16,32,64,8,117,512,101,0,4096,40,4113,1,35,4097,0,100,0,4160,32,17,2,40,64,0,4096,4097,0,69,33,116,33,4160,513]

theorem envBound42667 : H12AffineFastState.Bounded env42667 := by
  intro p hp
  have h : env42667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42666_42667 : H12AffineEnvironment.transform 6 8 env42666 = env42667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42666 == env42667) = true)

theorem identity42667 : scanCanonicalize (H12AffineFastState.compose env42667 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42668 : List Nat := [2,4,3,16,32,64,3,117,512,101,0,4096,35,4113,1,35,4097,0,100,0,4160,32,17,2,35,64,0,4096,4097,0,69,33,116,33,4160,513]

theorem envBound42668 : H12AffineFastState.Bounded env42668 := by
  intro p hp
  have h : env42668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42667_42668 : H12AffineEnvironment.transform 2 3 env42667 = env42668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42667 == env42668) = true)

theorem identity42668 : scanCanonicalize (H12AffineFastState.compose env42668 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound42668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42669 : List Nat := [2,4,3,16,32,64,3,117,512,101,0,64,35,81,1,35,65,0,100,0,0,32,17,2,35,64,0,64,65,0,69,33,116,33,0,513]

theorem envBound42669 : H12AffineFastState.Bounded env42669 := by
  intro p hp
  have h : env42669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42668_42669 : H12AffineEnvironment.transform 11 64 env42668 = env42669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env42668 == env42669) = true)

def env42670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,131072,10281,1025,21761,151632,156012,156116,21763,8328,64,149656,160981,25813,23805,148941,8693,257,21792,24964,147985]

theorem envBound42670 : H12AffineFastState.Bounded env42670 := by
  intro p hp
  have h : env42670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42659_42670 : H12AffineEnvironment.transform 17 10281 env42659 = env42670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42659 == env42670) = true)

theorem identity42670 : scanCanonicalize (H12AffineFastState.compose env42670 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound42670 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,8203,131072,10281,1025,8540,140301,136497,136585,8542,8328,64,146629,131208,4232,10400,143760,8693,257,8573,5593,144972]

theorem envBound42671 : H12AffineFastState.Bounded env42671 := by
  intro p hp
  have h : env42671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42670_42671 : H12AffineEnvironment.transform 13 13405 env42670 = env42671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env42670 == env42671) = true)

theorem identity42671 : scanCanonicalize (H12AffineFastState.compose env42671 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound42671 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8541,8203,13509,10281,1025,8540,4296,8692,8524,8542,8328,64,2048,13389,4232,10400,1365,8693,257,8573,5593,649]

theorem envBound42672 : H12AffineFastState.Bounded env42672 := by
  intro p hp
  have h : env42672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42671_42672 : H12AffineEnvironment.transform 16 13509 env42671 = env42672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env42671 == env42672) = true)

theorem identity42672 : scanCanonicalize (H12AffineFastState.compose env42672 (packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 3552) := by decide +kernel

theorem selectedBound42672 : packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env42673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3552,6589,3261,3563,6437,1481,1025,3260,4296,3092,3244,3262,3432,64,2048,6573,4232,1344,1365,3093,257,3229,5593,649]

theorem envBound42673 : H12AffineFastState.Bounded env42673 := by
  intro p hp
  have h : env42673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42672_42673 : H12AffineEnvironment.transform 12 3552 env42672 = env42673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3552 env42672 == env42673) = true)

theorem identity42673 : scanCanonicalize (H12AffineFastState.compose env42673 (packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound42673 : packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env42674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,65,3552,2556,3261,3563,2404,1481,1025,3260,137,3092,3244,3262,3432,64,2048,2540,201,1344,1365,3093,257,3229,1432,649]

theorem envBound42674 : H12AffineFastState.Bounded env42674 := by
  intro p hp
  have h : env42674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42673_42674 : H12AffineEnvironment.transform 11 65 env42673 = env42674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env42673 == env42674) = true)

theorem identity42674 : scanCanonicalize (H12AffineFastState.compose env42674 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42674 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env42675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,65,3432,2420,3125,3427,2404,1345,1025,3124,1,3092,3108,3126,3432,64,2048,2404,65,1344,1365,3093,257,3093,1296,513]

theorem envBound42675 : H12AffineFastState.Bounded env42675 := by
  intro p hp
  have h : env42675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42674_42675 : H12AffineEnvironment.transform 6 8 env42674 = env42675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42674 == env42675) = true)

theorem identity42675 : scanCanonicalize (H12AffineFastState.compose env42675 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound42675 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env42676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,65,1337,293,1124,1330,309,1345,1025,1125,1,1093,1141,1127,1337,64,81,309,65,1344,1365,1092,257,1092,1296,513]

theorem envBound42676 : H12AffineFastState.Bounded env42676 := by
  intro p hp
  have h : env42676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42675_42676 : H12AffineEnvironment.transform 10 81 env42675 = env42676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env42675 == env42676) = true)

theorem identity42676 : scanCanonicalize (H12AffineFastState.compose env42676 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42676 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42677 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,17,1337,293,1076,1330,309,1297,1025,1077,1,1045,1061,1079,1337,16,1,309,17,1296,1285,1044,257,1044,1296,513]

theorem envBound42677 : H12AffineFastState.Bounded env42677 := by
  intro p hp
  have h : env42677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42676_42677 : H12AffineEnvironment.transform 5 16 env42676 = env42677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42676 == env42677) = true)

theorem identity42677 : scanCanonicalize (H12AffineFastState.compose env42677 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42677 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42678 : List Nat := [2,4,8,16,32,16,8,256,512,52,1,17,269,293,0,262,309,293,53,1,1,33,17,3,269,16,1,309,17,292,305,32,257,32,292,513]

theorem envBound42678 : H12AffineFastState.Bounded env42678 := by
  intro p hp
  have h : env42678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42677_42678 : H12AffineEnvironment.transform 9 52 env42677 = env42678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42677 == env42678) = true)

def env42679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,131072,262144,1025,21760,151633,411973,213471,95497,8328,64,223379,160980,83167,349406,222662,264668,257,95530,82319,147985]

theorem envBound42679 : H12AffineFastState.Bounded env42679 := by
  intro p hp
  have h : env42679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42657_42679 : H12AffineEnvironment.transform 14 21761 env42657 = env42679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env42657 == env42679) = true)

theorem identity42679 : scanCanonicalize (H12AffineFastState.compose env42679 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42679 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90139,262144,1025,21760,77898,338270,8644,95497,8328,64,2184,70863,83167,349406,1501,264668,257,95530,82319,74250]

theorem envBound42680 : H12AffineFastState.Bounded env42680 := by
  intro p hp
  have h : env42680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42679_42680 : H12AffineEnvironment.transform 16 90139 env42679 = env42680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42679 == env42680) = true)

theorem identity42680 : scanCanonicalize (H12AffineFastState.compose env42680 (packedSelected [0,1,9,10,11,12,15,17,19,22,27,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89595) := by decide +kernel

theorem selectedBound42680 : packedSelected [0,1,9,10,11,12,15,17,19,22,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env42681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90139,89595,1025,21760,77898,29861,8644,95497,8328,64,2184,70863,83167,2341,1501,87079,257,95530,82319,74250]

theorem envBound42681 : H12AffineFastState.Bounded env42681 := by
  intro p hp
  have h : env42681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42680_42681 : H12AffineEnvironment.transform 17 89595 env42680 = env42681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89595 env42680 == env42681) = true)

theorem identity42681 : scanCanonicalize (H12AffineFastState.compose env42681 (packedSelected [1,3,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound42681 : packedSelected [1,3,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env42682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,263,24860,23804,1025,21760,12621,29861,8644,29710,8328,64,2184,5576,17880,2341,1501,21792,257,29741,16520,8973]

theorem envBound42682 : H12AffineFastState.Bounded env42682 := by
  intro p hp
  have h : env42682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42681_42682 : H12AffineEnvironment.transform 15 263 env42681 = env42682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env42681 == env42682) = true)

theorem identity42682 : scanCanonicalize (H12AffineFastState.compose env42682 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound42682 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env42683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,21761,263,16401,23804,1025,21760,4160,21928,201,21763,389,64,2184,5576,17880,2341,1501,21792,257,21792,16520,512]

theorem envBound42683 : H12AffineFastState.Bounded env42683 := by
  intro p hp
  have h : env42683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42682_42683 : H12AffineEnvironment.transform 12 269 env42682 = env42683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env42682 == env42683) = true)

theorem identity42683 : scanCanonicalize (H12AffineFastState.compose env42683 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 6683) := by decide +kernel

theorem selectedBound42683 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env42684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,6683,3866,263,6666,1767,1025,3867,4160,4019,201,3864,389,64,2184,5576,8131,2341,1501,3899,257,3899,6803,512]

theorem envBound42684 : H12AffineFastState.Bounded env42684 := by
  intro p hp
  have h : env42684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42683_42684 : H12AffineEnvironment.transform 13 6683 env42683 = env42684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6683 env42683 == env42684) = true)

theorem identity42684 : scanCanonicalize (H12AffineFastState.compose env42684 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(10+1) ^^^ 1766) := by decide +kernel

theorem selectedBound42684 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1766,4096,269,5373,508,263,5356,1767,1025,509,4160,341,201,510,389,64,1646,5576,4389,1987,1501,477,257,477,5237,512]

theorem envBound42685 : H12AffineFastState.Bounded env42685 := by
  intro p hp
  have h : env42685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42684_42685 : H12AffineEnvironment.transform 10 1766 env42684 = env42685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1766 env42684 == env42685) = true)

theorem identity42685 : scanCanonicalize (H12AffineFastState.compose env42685 (packedSelected [3,5,12,14] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound42685 : packedSelected [3,5,12,14] rootPS < 2^1333 := by decide +kernel

def env42686 : List Nat := [2,4,8,16,32,64,128,256,90,1024,1212,4096,269,5373,508,263,5356,1213,1025,509,4160,341,201,510,389,64,1076,5576,4389,1433,1501,477,257,477,5237,90]

theorem envBound42686 : H12AffineFastState.Bounded env42686 := by
  intro p hp
  have h : env42686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42685_42686 : H12AffineEnvironment.transform 8 90 env42685 = env42686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env42685 == env42686) = true)

theorem identity42686 : scanCanonicalize (H12AffineFastState.compose env42686 (packedSelected [2,6,17] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound42686 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env42687 : List Nat := [2,4,8,16,32,64,128,220,90,1024,1212,4096,209,5373,32,219,5356,1213,1025,33,4160,137,201,34,89,64,1076,5140,4345,1093,1025,1,221,1,5237,90]

theorem envBound42687 : H12AffineFastState.Bounded env42687 := by
  intro p hp
  have h : env42687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42686_42687 : H12AffineEnvironment.transform 7 220 env42686 = env42687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env42686 == env42687) = true)

theorem identity42687 : scanCanonicalize (H12AffineFastState.compose env42687 (packedSelected [3,5,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1277) := by decide +kernel

theorem selectedBound42687 : packedSelected [3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env42688 : List Nat := [2,4,8,16,32,64,128,220,90,1024,1212,1277,209,0,32,219,17,1213,1025,33,1213,137,201,34,89,64,1076,233,1028,1093,1025,1,221,1,136,90]

theorem envBound42688 : H12AffineFastState.Bounded env42688 := by
  intro p hp
  have h : env42688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42687_42688 : H12AffineEnvironment.transform 11 1277 env42687 = env42688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1277 env42687 == env42688) = true)

theorem identity42688 : scanCanonicalize (H12AffineFastState.compose env42688 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound42688 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env42689 : List Nat := [2,4,8,16,32,64,26,70,90,1024,1062,1127,75,0,32,65,17,1063,1025,33,1063,19,83,34,89,64,1076,115,1028,1093,1025,1,71,1,18,90]

theorem envBound42689 : H12AffineFastState.Bounded env42689 := by
  intro p hp
  have h : env42689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42688_42689 : H12AffineEnvironment.transform 6 26 env42688 = env42689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env42688 == env42689) = true)

theorem identity42689 : scanCanonicalize (H12AffineFastState.compose env42689 (packedSelected [0,5,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42689 : packedSelected [0,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42690 : List Nat := [2,4,8,16,32,16,26,22,10,1024,1062,1079,27,0,32,17,17,1063,1025,33,1063,19,3,34,9,16,1076,35,1028,1045,1025,1,23,1,18,10]

theorem envBound42690 : H12AffineFastState.Bounded env42690 := by
  intro p hp
  have h : env42690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42689_42690 : H12AffineEnvironment.transform 5 16 env42689 = env42690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42689 == env42690) = true)

theorem identity42690 : scanCanonicalize (H12AffineFastState.compose env42690 (packedSelected [0,4,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound42690 : packedSelected [0,4,5,7,10] rootPS < 2^1333 := by decide +kernel

def env42691 : List Nat := [2,4,8,16,19,16,26,22,10,1024,1045,1028,27,0,19,17,17,1044,1025,18,1044,19,3,17,9,16,1031,16,1028,1045,1025,1,23,1,18,10]

theorem envBound42691 : H12AffineFastState.Bounded env42691 := by
  intro p hp
  have h : env42691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42690_42691 : H12AffineEnvironment.transform 4 19 env42690 = env42691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env42690 == env42691) = true)

theorem identity42691 : scanCanonicalize (H12AffineFastState.compose env42691 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound42691 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42692 : List Nat := [2,4,8,16,19,16,26,22,10,9,28,13,27,0,19,17,17,29,8,18,29,19,3,17,9,16,14,16,13,28,8,1,23,1,18,10]

theorem envBound42692 : H12AffineFastState.Bounded env42692 := by
  intro p hp
  have h : env42692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42691_42692 : H12AffineEnvironment.transform 9 9 env42691 = env42692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env42691 == env42692) = true)

def env42693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411973,213471,16777216,8328,64,16959643,16974300,102879,360927,16958926,17148373,257,16777250,16834950,17031705]

theorem envBound42693 : H12AffineFastState.Bounded env42693 := by
  intro p hp
  have h : env42693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42655_42693 : H12AffineEnvironment.transform 20 165201 env42655 = env42693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env42655 == env42693) = true)

theorem identity42693 : scanCanonicalize (H12AffineFastState.compose env42693 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound42693 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env42694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115871,329867,17,16777216,8328,64,16877909,16793618,102879,360927,16876544,17148373,257,16777250,16834950,16819159]

theorem envBound42694 : H12AffineFastState.Bounded env42694 := by
  intro p hp
  have h : env42694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42693_42694 : H12AffineEnvironment.transform 16 82382 env42693 = env42694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env42693 == env42694) = true)

def env42695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115871,329867,17,95496,8328,64,64605,79130,102879,360927,61704,318685,257,95530,103566,120543]

theorem envBound42695 : H12AffineFastState.Bounded env42695 := by
  intro p hp
  have h : env42695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42694_42695 : H12AffineEnvironment.transform 23 95496 env42694 = env42695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env42694 == env42695) = true)

def env42696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115735,329731,17,95496,8192,64,64605,79130,102743,360791,61704,318549,257,95530,103430,120407]

theorem envBound42696 : H12AffineFastState.Bounded env42696 := by
  intro p hp
  have h : env42696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42695_42696 : H12AffineEnvironment.transform 6 8 env42695 = env42696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42695 == env42696) = true)

theorem identity42696 : scanCanonicalize (H12AffineFastState.compose env42696 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound42696 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,35189,1025,32769,115735,98678,17,95496,8192,64,64605,79130,102743,67618,61704,21792,257,95530,103430,120407]

theorem envBound42697 : H12AffineFastState.Bounded env42697 := by
  intro p hp
  have h : env42697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42696_42697 : H12AffineEnvironment.transform 17 35189 env42696 = env42697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env42696 == env42697) = true)

theorem identity42697 : scanCanonicalize (H12AffineFastState.compose env42697 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound42697 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,46157,35189,1025,32769,12572,29821,17,32771,8192,64,64605,49169,25692,64809,61704,21792,257,32801,24845,9052]

theorem envBound42698 : H12AffineFastState.Bounded env42698 := by
  intro p hp
  have h : env42698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42697_42698 : H12AffineEnvironment.transform 15 62731 env42697 = env42698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env42697 == env42698) = true)

theorem identity42698 : scanCanonicalize (H12AffineFastState.compose env42698 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound42698 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,24908,23668,1025,21760,12572,29821,17,21762,8192,64,10588,5392,25692,10280,9225,21792,257,21792,24845,9052]

theorem envBound42699 : H12AffineFastState.Bounded env42699 := by
  intro p hp
  have h : env42699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42698_42699 : H12AffineEnvironment.transform 14 21761 env42698 = env42699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env42698 == env42699) = true)

theorem identity42699 : scanCanonicalize (H12AffineFastState.compose env42699 (packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 2845) := by decide +kernel

theorem selectedBound42699 : packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env42700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2845,16384,21761,2839,19025,23668,1025,21760,6657,24416,17,21762,2845,64,577,5392,20289,821,3860,21792,257,21792,18960,2113]

theorem envBound42700 : H12AffineFastState.Bounded env42700 := by
  intro p hp
  have h : env42700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42699_42700 : H12AffineEnvironment.transform 12 2845 env42699 = env42700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2845 env42699 == env42700) = true)

theorem identity42700 : scanCanonicalize (H12AffineFastState.compose env42700 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42700 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42701 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,2664,16384,21620,2658,19025,23668,1025,21621,6657,24085,17,21623,2664,64,577,5221,20020,576,3681,21589,116,21589,18960,2113]

theorem envBound42701 : H12AffineFastState.Bounded env42701 := by
  intro p hp
  have h : env42701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42700_42701 : H12AffineEnvironment.transform 7 117 env42700 = env42701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42700 == env42701) = true)

theorem identity42701 : scanCanonicalize (H12AffineFastState.compose env42701 (packedSelected [2,5,6,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4673) := by decide +kernel

theorem selectedBound42701 : packedSelected [2,5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env42702 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,2664,4673,1589,2658,6160,3637,1025,1588,6657,3156,17,1590,2664,64,577,5221,7285,576,3681,1556,116,1556,6225,2113]

theorem envBound42702 : H12AffineFastState.Bounded env42702 := by
  intro p hp
  have h : env42702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42701_42702 : H12AffineEnvironment.transform 13 4673 env42701 = env42702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4673 env42701 == env42702) = true)

theorem identity42702 : scanCanonicalize (H12AffineFastState.compose env42702 (packedSelected [2,4,5,6,8,9,11,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound42702 : packedSelected [2,4,5,6,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env42703 : List Nat := [2,4,8,16,32,64,8,117,512,1024,529,4096,121,4673,1589,115,4609,1060,1025,1588,4112,1605,17,1590,121,64,577,5221,5732,576,1136,1556,116,1556,4672,592]

theorem envBound42703 : H12AffineFastState.Bounded env42703 := by
  intro p hp
  have h : env42703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42702_42703 : H12AffineEnvironment.transform 10 529 env42702 = env42703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env42702 == env42703) = true)

theorem identity42703 : scanCanonicalize (H12AffineFastState.compose env42703 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1636) := by decide +kernel

theorem selectedBound42703 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env42704 : List Nat := [2,4,8,16,32,64,8,117,512,1024,529,1636,121,1061,1589,115,1125,1060,1025,1588,1652,1605,17,1590,121,64,577,513,0,576,1136,1556,116,1556,1060,592]

theorem envBound42704 : H12AffineFastState.Bounded env42704 := by
  intro p hp
  have h : env42704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42703_42704 : H12AffineEnvironment.transform 11 1636 env42703 = env42704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1636 env42703 == env42704) = true)

theorem identity42704 : scanCanonicalize (H12AffineFastState.compose env42704 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42704 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42705 : List Nat := [2,4,8,16,32,16,8,37,512,1024,529,1588,41,1061,1589,35,1077,1060,1025,1588,1572,1557,17,1590,41,16,529,513,0,528,1056,1556,36,1556,1060,512]

theorem envBound42705 : H12AffineFastState.Bounded env42705 := by
  intro p hp
  have h : env42705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42704_42705 : H12AffineEnvironment.transform 5 16 env42704 = env42705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42704 == env42705) = true)

theorem identity42705 : scanCanonicalize (H12AffineFastState.compose env42705 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42705 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env42706 : List Nat := [2,4,8,16,1,16,8,4,512,1024,529,1557,8,1028,1556,2,1044,1029,1025,1557,1541,1557,17,1559,8,16,529,513,0,528,1025,1556,5,1556,1029,512]

theorem envBound42706 : H12AffineFastState.Bounded env42706 := by
  intro p hp
  have h : env42706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42705_42706 : H12AffineEnvironment.transform 4 1 env42705 = env42706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42705 == env42706) = true)

theorem identity42706 : scanCanonicalize (H12AffineFastState.compose env42706 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound42706 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env42707 : List Nat := [2,4,8,16,1,16,8,4,512,532,529,1,8,528,0,2,512,529,533,1,17,1,17,3,8,16,529,513,0,528,533,0,5,0,529,512]

theorem envBound42707 : H12AffineFastState.Bounded env42707 := by
  intro p hp
  have h : env42707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42706_42707 : H12AffineEnvironment.transform 9 532 env42706 = env42707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env42706 == env42707) = true)

def env42708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115734,329730,17,95496,8193,64,64605,79130,102742,360790,61704,318548,257,95530,103431,120406]

theorem envBound42708 : H12AffineFastState.Bounded env42708 := by
  intro p hp
  have h : env42708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42695_42708 : H12AffineEnvironment.transform 6 9 env42695 = env42708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42695 == env42708) = true)

theorem identity42708 : scanCanonicalize (H12AffineFastState.compose env42708 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound42708 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,115734,73771,17,95496,8193,64,64605,79130,102742,108927,61704,62589,257,95530,103431,120406]

theorem envBound42709 : H12AffineFastState.Bounded env42709 := by
  intro p hp
  have h : env42709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42708_42709 : H12AffineEnvironment.transform 17 10281 env42708 = env42709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42708 == env42709) = true)

theorem identity42709 : scanCanonicalize (H12AffineFastState.compose env42709 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42709 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env42710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,82247,2420,1025,32769,115734,65910,17,87125,348,64,56576,70727,102742,100386,53333,54560,257,87159,103431,120406]

theorem envBound42710 : H12AffineFastState.Bounded env42710 := by
  intro p hp
  have h : env42710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42709_42710 : H12AffineEnvironment.transform 12 349 env42709 = env42710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42709 == env42710) = true)

theorem identity42710 : scanCanonicalize (H12AffineFastState.compose env42710 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound42710 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env42711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,65536,82247,2420,1025,21761,69910,65910,17,87125,348,64,2048,70727,83030,89378,1365,32,257,87159,82183,66390]

theorem envBound42711 : H12AffineFastState.Bounded env42711 := by
  intro p hp
  have h : env42711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42710_42711 : H12AffineEnvironment.transform 14 21760 env42710 = env42711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env42710 == env42711) = true)

theorem identity42711 : scanCanonicalize (H12AffineFastState.compose env42711 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound42711 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env42712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,80,65536,70679,2420,1025,81,69910,65910,17,65797,348,64,2048,70727,69894,67698,1365,32,257,65831,70743,66390]

theorem envBound42712 : H12AffineFastState.Bounded env42712 := by
  intro p hp
  have h : env42712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42711_42712 : H12AffineEnvironment.transform 13 5456 env42711 = env42712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env42711 == env42712) = true)

theorem identity42712 : scanCanonicalize (H12AffineFastState.compose env42712 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound42712 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env42713 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5156,80,65536,70679,2048,1025,81,69730,65538,17,65649,40,64,2048,70727,69746,67698,1057,32,117,65619,70743,66082]

theorem envBound42713 : H12AffineFastState.Bounded env42713 := by
  intro p hp
  have h : env42713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42712_42713 : H12AffineEnvironment.transform 7 116 env42712 = env42713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env42712 == env42713) = true)

theorem identity42713 : scanCanonicalize (H12AffineFastState.compose env42713 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound42713 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env42714 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5156,80,114,5221,2048,1025,81,4112,112,17,3,40,64,2048,5173,4096,2048,1057,32,117,33,5157,592]

theorem envBound42714 : H12AffineFastState.Bounded env42714 := by
  intro p hp
  have h : env42714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42713_42714 : H12AffineEnvironment.transform 15 114 env42713 = env42714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env42713 == env42714) = true)

theorem identity42714 : scanCanonicalize (H12AffineFastState.compose env42714 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound42714 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env42715 : List Nat := [2,4,8,16,32,49,9,5,512,1024,2048,4096,41,5156,33,3,5140,2048,1025,32,4112,1,17,3,40,49,2048,5173,4096,2048,1057,32,4,33,5157,545]

theorem envBound42715 : H12AffineFastState.Bounded env42715 := by
  intro p hp
  have h : env42715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42714_42715 : H12AffineEnvironment.transform 5 49 env42714 = env42715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env42714 == env42715) = true)

def env42716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115871,329867,17,95497,8328,64,64604,79131,102879,360927,61705,318684,257,95531,103567,120542]

theorem envBound42716 : H12AffineFastState.Bounded env42716 := by
  intro p hp
  have h : env42716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42694_42716 : H12AffineEnvironment.transform 23 95497 env42694 = env42716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env42694 == env42716) = true)

theorem identity42716 : scanCanonicalize (H12AffineFastState.compose env42716 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound42716 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38161,262144,1025,32769,4160,318548,17,41430,8328,64,64604,57796,17664,283904,61705,318684,257,41460,16464,513]

theorem envBound42717 : H12AffineFastState.Bounded env42717 := by
  intro p hp
  have h : env42717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42716_42717 : H12AffineEnvironment.transform 15 54495 env42716 = env42717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env42716 == env42717) = true)

def env42718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,4160,318548,17,41310,8192,64,64604,57676,17664,283904,61705,318548,257,41340,16464,513]

theorem envBound42718 : H12AffineFastState.Bounded env42718 := by
  intro p hp
  have h : env42718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42717_42718 : H12AffineEnvironment.transform 6 8 env42717 = env42718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42717 == env42718) = true)

theorem identity42718 : scanCanonicalize (H12AffineFastState.compose env42718 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound42718 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,35189,1025,32769,4160,21793,17,41310,8192,64,64604,57676,17664,56437,61705,21793,257,41340,16464,513]

theorem envBound42719 : H12AffineFastState.Bounded env42719 := by
  intro p hp
  have h : env42719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42718_42719 : H12AffineEnvironment.transform 17 35189 env42718 = env42719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env42718 == env42719) = true)

theorem identity42719 : scanCanonicalize (H12AffineFastState.compose env42719 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound42719 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env42720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9292,28699,12637,11577,1025,9293,4160,21793,17,1298,8192,64,22544,17664,17664,30777,21829,21793,257,1328,16464,513]

theorem envBound42720 : H12AffineFastState.Bounded env42720 := by
  intro p hp
  have h : env42720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42719_42720 : H12AffineEnvironment.transform 14 9292 env42719 = env42720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env42719 == env42720) = true)

theorem identity42720 : scanCanonicalize (H12AffineFastState.compose env42720 (packedSelected [1,8,9,14,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42720 : packedSelected [1,8,9,14,19,22] rootPS < 2^1333 := by decide +kernel

def env42721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1297,20806,4096,3172,1025,1296,4160,21793,17,1298,349,64,22544,17664,17664,22884,21829,21793,257,1328,16464,513]

theorem envBound42721 : H12AffineFastState.Bounded env42721 := by
  intro p hp
  have h : env42721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42720_42721 : H12AffineEnvironment.transform 12 349 env42720 = env42721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42720 == env42721) = true)

theorem identity42721 : scanCanonicalize (H12AffineFastState.compose env42721 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound42721 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42722 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1297,343,4096,3172,1025,1296,4160,1328,17,1298,349,64,2049,5393,5393,2421,1364,1328,257,1328,4161,513]

theorem envBound42722 : H12AffineFastState.Bounded env42722 := by
  intro p hp
  have h : env42722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42721_42722 : H12AffineEnvironment.transform 13 4113 env42721 = env42722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env42721 == env42722) = true)

theorem identity42722 : scanCanonicalize (H12AffineFastState.compose env42722 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42722 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42723 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4113,1297,262,4096,3125,1025,1296,4113,1328,17,1298,268,17,2049,5393,5393,2340,1285,1328,257,1328,4112,513]

theorem envBound42723 : H12AffineFastState.Bounded env42723 := by
  intro p hp
  have h : env42723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42722_42723 : H12AffineEnvironment.transform 5 17 env42722 = env42723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42722 == env42723) = true)

theorem identity42723 : scanCanonicalize (H12AffineFastState.compose env42723 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound42723 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env42724 : List Nat := [2,4,8,16,32,17,8,256,512,1024,308,4096,268,4113,1297,262,4096,1281,1025,1296,4113,1328,17,1298,268,17,309,5393,5393,16,1285,1328,257,1328,4112,513]

theorem envBound42724 : H12AffineFastState.Bounded env42724 := by
  intro p hp
  have h : env42724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42723_42724 : H12AffineEnvironment.transform 10 308 env42723 = env42724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env42723 == env42724) = true)

theorem identity42724 : scanCanonicalize (H12AffineFastState.compose env42724 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound42724 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env42725 : List Nat := [2,4,8,16,32,17,8,256,512,272,308,4096,268,4113,1,262,4096,17,273,0,4113,32,17,2,268,17,309,4097,4097,16,21,32,257,32,4112,513]

theorem envBound42725 : H12AffineFastState.Bounded env42725 := by
  intro p hp
  have h : env42725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42724_42725 : H12AffineEnvironment.transform 9 272 env42724 = env42725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env42724 == env42725) = true)

theorem identity42725 : scanCanonicalize (H12AffineFastState.compose env42725 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound42725 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42726 : List Nat := [2,4,8,16,32,17,8,256,512,272,308,0,268,17,1,262,0,17,273,0,17,32,17,2,268,17,309,1,1,16,21,32,257,32,16,513]

theorem envBound42726 : H12AffineFastState.Bounded env42726 := by
  intro p hp
  have h : env42726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42725_42726 : H12AffineEnvironment.transform 11 0 env42725 = env42726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env42725 == env42726) = true)

theorem identity42726 : scanCanonicalize (H12AffineFastState.compose env42726 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound42726 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42727 : List Nat := [2,4,8,16,32,17,8,256,0,272,308,0,268,17,1,262,0,17,273,0,17,32,17,2,268,17,309,1,1,16,21,32,257,32,16,1]

theorem envBound42727 : H12AffineFastState.Bounded env42727 := by
  intro p hp
  have h : env42727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42726_42727 : H12AffineEnvironment.transform 8 0 env42726 = env42727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env42726 == env42727) = true)

theorem identity42727 : scanCanonicalize (H12AffineFastState.compose env42727 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42727 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42728 : List Nat := [2,4,8,16,32,17,8,5,0,21,49,0,9,17,1,3,0,17,20,0,17,32,17,2,9,17,48,1,1,16,21,32,4,32,16,1]

theorem envBound42728 : H12AffineFastState.Bounded env42728 := by
  intro p hp
  have h : env42728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42727_42728 : H12AffineEnvironment.transform 7 5 env42727 = env42728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42727 == env42728) = true)

theorem identity42728 : scanCanonicalize (H12AffineFastState.compose env42728 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42728 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env42729 : List Nat := [2,4,8,16,0,17,8,5,0,21,17,0,9,17,1,3,0,17,20,0,17,0,17,2,9,17,16,1,1,16,21,0,4,0,16,1]

theorem envBound42729 : H12AffineFastState.Bounded env42729 := by
  intro p hp
  have h : env42729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42728_42729 : H12AffineEnvironment.transform 4 0 env42728 = env42729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42728 == env42729) = true)

def env42730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,4160,318548,17,41311,8193,64,64604,57677,17664,283904,61705,318549,257,41341,16464,513]

theorem envBound42730 : H12AffineFastState.Bounded env42730 := by
  intro p hp
  have h : env42730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42717_42730 : H12AffineEnvironment.transform 6 9 env42717 = env42730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42717 == env42730) = true)

theorem identity42730 : scanCanonicalize (H12AffineFastState.compose env42730 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound42730 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10281,1025,32769,4160,62589,17,41311,8193,64,64604,57677,17664,32041,61705,62588,257,41341,16464,513]

theorem envBound42731 : H12AffineFastState.Bounded env42731 := by
  intro p hp
  have h : env42731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42730_42731 : H12AffineEnvironment.transform 17 10281 env42730 = env42731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42730 == env42731) = true)

theorem identity42731 : scanCanonicalize (H12AffineFastState.compose env42731 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42731 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env42732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,38161,10281,1025,32769,4160,41340,17,41311,8193,64,43357,46156,4097,10280,41992,41341,257,41341,5457,513]

theorem envBound42732 : H12AffineFastState.Bounded env42732 := by
  intro p hp
  have h : env42732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42731_42732 : H12AffineEnvironment.transform 13 5377 env42731 = env42732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42731 == env42732) = true)

theorem identity42732 : scanCanonicalize (H12AffineFastState.compose env42732 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound42732 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8233,8574,13624,10281,1025,8232,4160,341,17,374,8193,64,2420,5221,4097,10280,1057,340,257,340,5457,513]

theorem envBound42733 : H12AffineFastState.Bounded env42733 := by
  intro p hp
  have h : env42733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42732_42733 : H12AffineEnvironment.transform 14 8233 env42732 = env42733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env42732 == env42733) = true)

theorem identity42733 : scanCanonicalize (H12AffineFastState.compose env42733 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound42733 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env42734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5377,80,263,5441,2128,1025,81,4160,341,17,374,120,64,2420,5221,4097,2129,1057,340,257,340,5457,513]

theorem envBound42734 : H12AffineFastState.Bounded env42734 := by
  intro p hp
  have h : env42734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42733_42734 : H12AffineEnvironment.transform 12 121 env42733 = env42734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env42733 == env42734) = true)

theorem identity42734 : scanCanonicalize (H12AffineFastState.compose env42734 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42734 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42735 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,80,114,5172,2128,1025,81,4160,32,17,3,120,64,2049,5221,4097,2129,1057,33,116,33,5156,513]

theorem envBound42735 : H12AffineFastState.Bounded env42735 := by
  intro p hp
  have h : env42735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42734_42735 : H12AffineEnvironment.transform 7 117 env42734 = env42735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42734 == env42735) = true)

theorem identity42735 : scanCanonicalize (H12AffineFastState.compose env42735 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound42735 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42736 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1060,121,80,80,114,16,2128,1025,81,1124,32,17,3,120,64,2049,65,1061,2129,1057,33,116,33,0,513]

theorem envBound42736 : H12AffineFastState.Bounded env42736 := by
  intro p hp
  have h : env42736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42735_42736 : H12AffineEnvironment.transform 11 1060 env42735 = env42736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env42735 == env42736) = true)

theorem identity42736 : scanCanonicalize (H12AffineFastState.compose env42736 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42736 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42737 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,1060,40,1,1,35,16,2049,1025,0,1077,32,17,3,41,17,2049,16,1061,2048,1057,33,37,33,0,513]

theorem envBound42737 : H12AffineFastState.Bounded env42737 := by
  intro p hp
  have h : env42737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42736_42737 : H12AffineEnvironment.transform 5 17 env42736 = env42737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42736 == env42737) = true)

theorem identity42737 : scanCanonicalize (H12AffineFastState.compose env42737 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound42737 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42738 : List Nat := [2,4,8,16,32,17,9,36,512,37,2048,1,40,1,1,35,16,2049,36,0,16,32,17,3,41,17,2049,16,0,2048,4,33,37,33,0,513]

theorem envBound42738 : H12AffineFastState.Bounded env42738 := by
  intro p hp
  have h : env42738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42737_42738 : H12AffineEnvironment.transform 9 37 env42737 = env42738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env42737 == env42738) = true)

theorem identity42738 : scanCanonicalize (H12AffineFastState.compose env42738 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound42738 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42739 : List Nat := [2,4,8,16,32,17,9,36,512,37,10,1,40,1,1,35,16,11,36,0,16,32,17,3,41,17,11,16,0,10,4,33,37,33,0,513]

theorem envBound42739 : H12AffineFastState.Bounded env42739 := by
  intro p hp
  have h : env42739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42738_42739 : H12AffineEnvironment.transform 10 10 env42738 = env42739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env42738 == env42739) = true)

theorem identity42739 : scanCanonicalize (H12AffineFastState.compose env42739 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound42739 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42740 : List Nat := [2,4,8,16,27,17,9,31,512,30,10,1,19,1,1,24,16,11,31,0,16,27,17,3,18,17,11,16,0,10,4,26,30,26,0,513]

theorem envBound42740 : H12AffineFastState.Bounded env42740 := by
  intro p hp
  have h : env42740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42739_42740 : H12AffineEnvironment.transform 4 27 env42739 = env42740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env42739 == env42740) = true)

def env42741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356288,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound42741 : H12AffineFastState.Bounded env42741 := by
  intro p hp
  have h : env42741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42397_42741 : H12AffineEnvironment.transform 26 30393345 env42397 = env42741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env42397 == env42741) = true)

def env42742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound42742 : H12AffineFastState.Bounded env42742 := by
  intro p hp
  have h : env42742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42741_42742 : H12AffineEnvironment.transform 18 1024 env42741 = env42742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env42741 == env42742) = true)

theorem identity42742 : scanCanonicalize (H12AffineFastState.compose env42742 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound42742 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env42743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,4194304,8388608,16777216,8328,64,29868033,16793618,8491471,8830976,25265169,21012830,256,25165874,25223574,25207751]

theorem envBound42743 : H12AffineFastState.Bounded env42743 := by
  intro p hp
  have h : env42743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42742_42743 : H12AffineEnvironment.transform 20 115870 env42742 = env42743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env42742 == env42743) = true)

def env42744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,4194304,8388608,95496,8328,64,13022473,79130,8491471,8830976,8450329,4314198,256,8484154,8492190,8509135]

theorem envBound42744 : H12AffineFastState.Bounded env42744 := by
  intro p hp
  have h : env42744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42743_42744 : H12AffineEnvironment.transform 23 95496 env42743 = env42744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env42743 == env42744) = true)

def env42745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272512,8388608,95496,8328,64,8560009,79130,8491471,8830976,8450329,392406,256,8484154,8492190,8509135]

theorem envBound42745 : H12AffineFastState.Bounded env42745 := by
  intro p hp
  have h : env42745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42744_42745 : H12AffineEnvironment.transform 21 272512 env42744 = env42745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42744 == env42745) = true)

def env42746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,8388608,95496,8192,64,8559873,79130,8491335,8830976,8450329,392286,256,8484154,8492054,8508999]

theorem envBound42746 : H12AffineFastState.Bounded env42746 := by
  intro p hp
  have h : env42746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42745_42746 : H12AffineEnvironment.transform 6 8 env42745 = env42746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42745 == env42746) = true)

def env42747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,16,95496,8192,64,171281,79130,102743,442384,61705,392286,256,95530,103430,120407]

theorem envBound42747 : H12AffineFastState.Bounded env42747 := by
  intro p hp
  have h : env42747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42746_42747 : H12AffineEnvironment.transform 22 16 env42746 = env42747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42746 == env42747) = true)

theorem identity42747 : scanCanonicalize (H12AffineFastState.compose env42747 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42747 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,91466,272392,16,95496,8192,64,146509,79130,77835,418124,20565,351490,256,95530,79194,96011]

theorem envBound42748 : H12AffineFastState.Bounded env42748 := by
  intro p hp
  have h : env42748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42747_42748 : H12AffineEnvironment.transform 14 8540 env42747 = env42748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42747 == env42748) = true)

theorem identity42748 : scanCanonicalize (H12AffineFastState.compose env42748 (packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound42748 : packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env42749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,146745,1024,8541,91466,136497,16,95496,8192,64,146509,79130,77835,23669,20565,221243,256,95530,79194,96011]

theorem envBound42749 : H12AffineFastState.Bounded env42749 := by
  intro p hp
  have h : env42749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42748_42749 : H12AffineEnvironment.transform 17 146745 env42748 = env42749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env42748 == env42749) = true)

theorem identity42749 : scanCanonicalize (H12AffineFastState.compose env42749 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42749 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env42750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,89378,1024,8541,91466,95530,16,95496,8192,64,89174,79130,77835,23669,20565,32,256,95530,79194,96011]

theorem envBound42750 : H12AffineFastState.Bounded env42750 := by
  intro p hp
  have h : env42750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42749_42750 : H12AffineEnvironment.transform 16 90139 env42749 = env42750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42749 == env42750) = true)

theorem identity42750 : scanCanonicalize (H12AffineFastState.compose env42750 (packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound42750 : packedSelected [0,2,4,6,7,9,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env42751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,114,24681,23888,1024,8541,25912,30040,16,30074,8192,64,23588,13672,12409,23669,20565,32,256,30040,13608,30585]

theorem envBound42751 : H12AffineFastState.Bounded env42751 := by
  intro p hp
  have h : env42751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42750_42751 : H12AffineEnvironment.transform 15 114 env42750 = env42751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env42750 == env42751) = true)

theorem identity42751 : scanCanonicalize (H12AffineFastState.compose env42751 (packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound42751 : packedSelected [0,2,3,4,5,6,7,9,10,14,18,23] rootPS < 2^1333 := by decide +kernel

def env42752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,114,5220,10589,1024,8541,4405,341,16,375,8192,64,10281,13672,12409,10360,9304,32,256,341,13608,884]

theorem envBound42752 : H12AffineFastState.Bounded env42752 := by
  intro p hp
  have h : env42752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42751_42752 : H12AffineEnvironment.transform 13 13325 env42751 = env42752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env42751 == env42752) = true)

theorem identity42752 : scanCanonicalize (H12AffineFastState.compose env42752 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42752 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env42753 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13325,8233,114,5220,10280,1024,8232,4160,32,16,2,8192,64,10281,13341,12409,10360,9304,32,117,32,13405,513]

theorem envBound42753 : H12AffineFastState.Bounded env42753 := by
  intro p hp
  have h : env42753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42752_42753 : H12AffineEnvironment.transform 7 117 env42752 = env42753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42752 == env42753) = true)

theorem identity42753 : scanCanonicalize (H12AffineFastState.compose env42753 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42753 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42754 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,8192,12393,8233,114,4096,10280,100,8232,4160,32,16,2,8192,64,10281,12409,12409,10360,8252,32,117,32,12345,513]

theorem envBound42754 : H12AffineFastState.Bounded env42754 := by
  intro p hp
  have h : env42754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42753_42754 : H12AffineEnvironment.transform 9 100 env42753 = env42754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42753 == env42754) = true)

theorem identity42754 : scanCanonicalize (H12AffineFastState.compose env42754 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 6776) := by decide +kernel

theorem selectedBound42754 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42755 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,6776,2577,6737,114,4096,4688,100,6736,4160,32,16,2,6776,64,4689,2561,2561,4608,6724,32,117,32,2625,513]

theorem envBound42755 : H12AffineFastState.Bounded env42755 := by
  intro p hp
  have h : env42755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42754_42755 : H12AffineEnvironment.transform 12 6776 env42754 = env42755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6776 env42754 == env42755) = true)

theorem identity42755 : scanCanonicalize (H12AffineFastState.compose env42755 (packedSelected [1,2,3,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2624) := by decide +kernel

theorem selectedBound42755 : packedSelected [1,2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env42756 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,2624,56,2577,17,114,2624,2064,100,16,2560,32,16,2,56,64,2065,2561,2561,2112,4,32,117,32,2625,513]

theorem envBound42756 : H12AffineFastState.Bounded env42756 := by
  intro p hp
  have h : env42756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42755_42756 : H12AffineEnvironment.transform 11 2624 env42755 = env42756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2624 env42755 == env42756) = true)

theorem identity42756 : scanCanonicalize (H12AffineFastState.compose env42756 (packedSelected [0,1,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound42756 : packedSelected [0,1,2,4,6] rootPS < 2^1333 := by decide +kernel

def env42757 : List Nat := [2,4,8,16,32,64,8,117,64,100,2048,2048,56,2129,17,114,2048,2064,100,16,2112,32,16,2,56,64,2065,2113,2113,2112,4,32,117,32,2049,65]

theorem envBound42757 : H12AffineFastState.Bounded env42757 := by
  intro p hp
  have h : env42757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42756_42757 : H12AffineEnvironment.transform 8 64 env42756 = env42757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env42756 == env42757) = true)

theorem identity42757 : scanCanonicalize (H12AffineFastState.compose env42757 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound42757 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42758 : List Nat := [2,4,8,16,32,64,8,117,64,100,65,65,56,16,17,114,65,81,100,16,1,32,16,2,56,64,80,0,0,1,4,32,117,32,64,65]

theorem envBound42758 : H12AffineFastState.Bounded env42758 := by
  intro p hp
  have h : env42758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42757_42758 : H12AffineEnvironment.transform 10 65 env42757 = env42758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env42757 == env42758) = true)

theorem identity42758 : scanCanonicalize (H12AffineFastState.compose env42758 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound42758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42759 : List Nat := [2,4,8,16,16,64,8,69,64,84,65,65,8,16,17,66,65,81,84,16,1,16,16,2,8,64,80,0,0,1,4,16,69,16,64,65]

theorem envBound42759 : H12AffineFastState.Bounded env42759 := by
  intro p hp
  have h : env42759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42758_42759 : H12AffineEnvironment.transform 4 16 env42758 = env42759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env42758 == env42759) = true)

theorem identity42759 : scanCanonicalize (H12AffineFastState.compose env42759 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42759 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42760 : List Nat := [2,4,8,16,16,0,8,5,0,20,1,1,8,16,17,2,1,17,20,16,1,16,16,2,8,0,16,0,0,1,4,16,5,16,0,1]

theorem envBound42760 : H12AffineFastState.Bounded env42760 := by
  intro p hp
  have h : env42760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42759_42760 : H12AffineEnvironment.transform 5 0 env42759 = env42760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42759 == env42760) = true)

theorem identity42760 : scanCanonicalize (H12AffineFastState.compose env42760 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42761 : List Nat := [2,4,8,0,0,0,8,5,0,4,1,1,8,0,1,2,1,1,4,0,1,0,0,2,8,0,0,0,0,1,4,0,5,0,0,1]

theorem envBound42761 : H12AffineFastState.Bounded env42761 := by
  intro p hp
  have h : env42761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42760_42761 : H12AffineEnvironment.transform 3 0 env42760 = env42761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42760 == env42761) = true)

def env42762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272392,17,95496,8192,64,171280,79130,102742,442385,61704,392286,256,95531,103431,120406]

theorem envBound42762 : H12AffineFastState.Bounded env42762 := by
  intro p hp
  have h : env42762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42746_42762 : H12AffineEnvironment.transform 22 17 env42746 = env42762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42746 == env42762) = true)

theorem identity42762 : scanCanonicalize (H12AffineFastState.compose env42762 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound42762 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1024,32769,115734,41340,17,95496,8192,64,171280,79130,102742,149861,61704,95530,256,95531,103431,120406]

theorem envBound42763 : H12AffineFastState.Bounded env42763 := by
  intro p hp
  have h : env42763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42762_42763 : H12AffineEnvironment.transform 17 35188 env42762 = env42763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env42762 == env42763) = true)

theorem identity42763 : scanCanonicalize (H12AffineFastState.compose env42763 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound42763 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env42764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,46156,35188,1024,32769,115734,41340,17,95496,8192,64,10588,79130,102742,64809,61704,95530,256,95531,103431,120406]

theorem envBound42764 : H12AffineFastState.Bounded env42764 := by
  intro p hp
  have h : env42764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42763_42764 : H12AffineEnvironment.transform 16 46156 env42763 = env42764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env42763 == env42764) = true)

theorem identity42764 : scanCanonicalize (H12AffineFastState.compose env42764 (packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound42764 : packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env42765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21511,46156,35188,1024,32769,36881,41340,17,8463,8192,64,10588,24861,50513,64809,61704,8493,256,8492,49152,33361]

theorem envBound42765 : H12AffineFastState.Bounded env42765 := by
  intro p hp
  have h : env42765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42764_42765 : H12AffineEnvironment.transform 15 21511 env42764 = env42765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env42764 == env42765) = true)

theorem identity42765 : scanCanonicalize (H12AffineFastState.compose env42765 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42765 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env42766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,21511,38208,35188,1024,32769,36881,32880,17,3,268,64,2128,16401,50513,56357,53252,33,256,32,49152,33361]

theorem envBound42766 : H12AffineFastState.Bounded env42766 := by
  intro p hp
  have h : env42766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42765_42766 : H12AffineEnvironment.transform 12 268 env42765 = env42766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42765 == env42766) = true)

theorem identity42766 : scanCanonicalize (H12AffineFastState.compose env42766 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42766 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env42767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,263,38208,35188,1024,32769,36881,32880,17,3,268,64,2128,5393,36945,35109,34052,33,256,32,38144,33361]

theorem envBound42767 : H12AffineFastState.Bounded env42767 := by
  intro p hp
  have h : env42767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42766_42767 : H12AffineEnvironment.transform 13 5376 env42766 = env42767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42766 == env42767) = true)

theorem identity42767 : scanCanonicalize (H12AffineFastState.compose env42767 (packedSelected [1,2,3] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound42767 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,263,5393,2341,1024,80,4160,33,17,3,268,64,2128,5393,4096,2420,1365,33,256,32,5457,512]

theorem envBound42768 : H12AffineFastState.Bounded env42768 := by
  intro p hp
  have h : env42768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42767_42768 : H12AffineEnvironment.transform 14 81 env42767 = env42768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env42767 == env42768) = true)

theorem identity42768 : scanCanonicalize (H12AffineFastState.compose env42768 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42768 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env42769 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,268,5376,81,263,5393,2309,1024,80,4160,1,17,3,268,64,2128,5393,4096,2388,1365,1,256,0,5457,512]

theorem envBound42769 : H12AffineFastState.Bounded env42769 := by
  intro p hp
  have h : env42769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42768_42769 : H12AffineEnvironment.transform 4 0 env42768 = env42769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42768 == env42769) = true)

theorem identity42769 : scanCanonicalize (H12AffineFastState.compose env42769 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound42769 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env42770 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,88,5204,81,83,5189,2129,1024,80,4160,1,17,3,88,64,2128,5189,4096,2048,1025,1,84,0,5125,512]

theorem envBound42770 : H12AffineFastState.Bounded env42770 := by
  intro p hp
  have h : env42770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42769_42770 : H12AffineEnvironment.transform 7 84 env42769 = env42770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env42769 == env42770) = true)

theorem identity42770 : scanCanonicalize (H12AffineFastState.compose env42770 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound42770 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42771 : List Nat := [2,4,8,16,0,64,8,84,512,1024,80,4096,88,5204,81,83,5189,1,1024,80,4160,1,17,3,88,64,0,5189,4096,80,1025,1,84,0,5125,512]

theorem envBound42771 : H12AffineFastState.Bounded env42771 := by
  intro p hp
  have h : env42771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42770_42771 : H12AffineEnvironment.transform 10 80 env42770 = env42771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env42770 == env42771) = true)

def env42772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,8388608,95496,8193,64,8559872,79130,8491334,8830976,8450329,392287,256,8484154,8492055,8508998]

theorem envBound42772 : H12AffineFastState.Bounded env42772 := by
  intro p hp
  have h : env42772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42745_42772 : H12AffineEnvironment.transform 6 9 env42745 = env42772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42745 == env42772) = true)

def env42773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,16,95496,8193,64,171280,79130,102742,442384,61705,392287,256,95530,103431,120406]

theorem envBound42773 : H12AffineFastState.Bounded env42773 := by
  intro p hp
  have h : env42773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42772_42773 : H12AffineEnvironment.transform 22 16 env42772 = env42773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42772 == env42773) = true)

def env42774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,272393,16,95496,8193,64,56576,79130,102742,294912,61705,392287,256,95530,103431,120406]

theorem envBound42774 : H12AffineFastState.Bounded env42774 := by
  intro p hp
  have h : env42774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42773_42774 : H12AffineEnvironment.transform 16 16400 env42773 = env42774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env42773 == env42774) = true)

def env42775 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,272393,16,95496,8193,16,56576,79130,102662,294912,61705,392207,256,95530,103431,120326]

theorem envBound42775 : H12AffineFastState.Bounded env42775 := by
  intro p hp
  have h : env42775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42774_42775 : H12AffineEnvironment.transform 5 16 env42774 = env42775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42774 == env42775) = true)

theorem identity42775 : scanCanonicalize (H12AffineFastState.compose env42775 (packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound42775 : packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS < 2^1333 := by decide +kernel

def env42776 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,262144,1024,32769,25629,272393,16,54530,8193,16,56576,38160,12556,294912,61705,285701,256,54560,13325,30220]

theorem envBound42776 : H12AffineFastState.Bounded env42776 := by
  intro p hp
  have h : env42776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42775_42776 : H12AffineEnvironment.transform 15 40970 env42775 = env42776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env42775 == env42776) = true)

theorem identity42776 : scanCanonicalize (H12AffineFastState.compose env42776 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42776 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42777 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10280,1024,32769,25629,33,16,54530,8193,16,56576,38160,12556,43048,61705,29741,256,54560,13325,30220]

theorem envBound42777 : H12AffineFastState.Bounded env42777 := by
  intro p hp
  have h : env42777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42776_42777 : H12AffineEnvironment.transform 17 10280 env42776 = env42777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42776 == env42777) = true)

theorem identity42777 : scanCanonicalize (H12AffineFastState.compose env42777 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 28729) := by decide +kernel

theorem selectedBound42777 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env42778 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,28729,20531,16400,10280,1024,28728,25629,33,16,9531,8193,16,11577,25897,12556,22545,304,29741,256,9497,13325,30220]

theorem envBound42778 : H12AffineFastState.Bounded env42778 := by
  intro p hp
  have h : env42778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42777_42778 : H12AffineEnvironment.transform 14 28729 env42777 = env42778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28729 env42777 == env42778) = true)

theorem identity42778 : scanCanonicalize (H12AffineFastState.compose env42778 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound42778 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env42779 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,20496,20531,16400,2049,1024,20497,17460,33,16,1298,40,16,3344,17664,4389,22545,304,21508,256,1328,5156,22053]

theorem envBound42779 : H12AffineFastState.Bounded env42779 := by
  intro p hp
  have h : env42779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42778_42779 : H12AffineEnvironment.transform 12 41 env42778 = env42779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env42778 == env42779) = true)

def env42780 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,272393,16,95496,8193,17,56576,79130,102663,294912,61705,392206,256,95530,103431,120327]

theorem envBound42780 : H12AffineFastState.Bounded env42780 := by
  intro p hp
  have h : env42780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42774_42780 : H12AffineEnvironment.transform 5 17 env42774 = env42780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42774 == env42780) = true)

theorem identity42780 : scanCanonicalize (H12AffineFastState.compose env42780 (packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound42780 : packedSelected [3,4,8,9,12,15,16,19,24,28,35] rootPS < 2^1333 := by decide +kernel

def env42781 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,43048,1024,32769,115735,32801,16,95496,8193,17,56576,79130,102663,10280,61705,87078,256,95530,103431,120327]

theorem envBound42781 : H12AffineFastState.Bounded env42781 := by
  intro p hp
  have h : env42781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42780_42781 : H12AffineEnvironment.transform 17 43048 env42780 = env42781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env42780 == env42781) = true)

theorem identity42781 : scanCanonicalize (H12AffineFastState.compose env42781 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42781 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42782 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,65536,16400,10281,1024,0,82966,32,16,95496,8193,17,23809,79130,69894,10280,28936,87078,256,95530,70662,87558]

theorem envBound42782 : H12AffineFastState.Bounded env42782 := by
  intro p hp
  have h : env42782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42781_42782 : H12AffineEnvironment.transform 14 1 env42781 = env42782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42781 == env42782) = true)

theorem identity42782 : scanCanonicalize (H12AffineFastState.compose env42782 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42782 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env42783 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,8203,16400,10281,1024,0,25629,32,16,21763,8193,17,23809,5393,12557,10280,28936,29741,256,21793,13325,30221]

theorem envBound42783 : H12AffineFastState.Bounded env42783 := by
  intro p hp
  have h : env42783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42782_42783 : H12AffineEnvironment.transform 15 8203 env42782 = env42783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42782 == env42783) = true)

theorem identity42783 : scanCanonicalize (H12AffineFastState.compose env42783 (packedSelected [0,1,3,5,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound42783 : packedSelected [0,1,3,5,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env42784 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,7181,16384,1,7174,16400,5156,1024,0,22544,32,16,21763,7180,17,23809,5393,3328,5157,19717,18464,256,21793,2048,18944]

theorem envBound42784 : H12AffineFastState.Bounded env42784 := by
  intro p hp
  have h : env42784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42783_42784 : H12AffineEnvironment.transform 12 7181 env42783 = env42784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env42783 == env42784) = true)

theorem identity42784 : scanCanonicalize (H12AffineFastState.compose env42784 (packedSelected [10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound42784 : packedSelected [10,11] rootPS < 2^1333 := by decide +kernel

def env42785 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,40,16384,1,35,16400,2049,1024,0,17461,32,16,18726,41,17,16676,2356,3328,2048,19717,18464,256,18692,2048,18944]

theorem envBound42785 : H12AffineFastState.Bounded env42785 := by
  intro p hp
  have h : env42785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42784_42785 : H12AffineEnvironment.transform 11 3109 env42784 = env42785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env42784 == env42785) = true)

theorem identity42785 : scanCanonicalize (H12AffineFastState.compose env42785 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42785 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env42786 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3109,40,16384,1,35,16400,2049,1024,0,17461,32,16,18435,41,17,16385,2065,3109,2048,19488,18464,37,18465,2048,18944]

theorem envBound42786 : H12AffineFastState.Bounded env42786 := by
  intro p hp
  have h : env42786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42785_42786 : H12AffineEnvironment.transform 7 37 env42785 = env42786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42785 == env42786) = true)

theorem identity42786 : scanCanonicalize (H12AffineFastState.compose env42786 (packedSelected [4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound42786 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env42787 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2064,40,16384,1,35,16400,2049,53,0,16384,32,16,18435,41,17,16385,2065,2064,2048,18453,18464,37,18465,2048,18944]

theorem envBound42787 : H12AffineFastState.Bounded env42787 := by
  intro p hp
  have h : env42787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42786_42787 : H12AffineEnvironment.transform 9 53 env42786 = env42787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42786 == env42787) = true)

def env42788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115735,272393,16,95496,8193,64,56577,79130,102742,294913,61705,392287,256,95530,103431,120406]

theorem envBound42788 : H12AffineFastState.Bounded env42788 := by
  intro p hp
  have h : env42788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42773_42788 : H12AffineEnvironment.transform 16 16401 env42773 = env42788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env42773 == env42788) = true)

theorem identity42788 : scanCanonicalize (H12AffineFastState.compose env42788 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound42788 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env42789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16401,262144,1024,32769,4160,272393,16,41311,8193,64,56577,57677,17665,294913,61705,272392,256,41341,16464,513]

theorem envBound42789 : H12AffineFastState.Bounded env42789 := by
  intro p hp
  have h : env42789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42788_42789 : H12AffineEnvironment.transform 15 54359 env42788 = env42789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env42788 == env42789) = true)

theorem identity42789 : scanCanonicalize (H12AffineFastState.compose env42789 (packedSelected [0,1,7,8,12,19,20,38] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound42789 : packedSelected [0,1,7,8,12,19,20,38] rootPS < 2^1333 := by decide +kernel

def env42790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16401,35188,1024,32769,4160,41341,16,41311,8193,64,56577,57677,17665,2421,61705,41340,256,41341,16464,513]

theorem envBound42790 : H12AffineFastState.Bounded env42790 := by
  intro p hp
  have h : env42790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42789_42790 : H12AffineEnvironment.transform 17 35188 env42789 = env42790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env42789 == env42790) = true)

theorem identity42790 : scanCanonicalize (H12AffineFastState.compose env42790 (packedSelected [0,1,2,4,6,7,8,9,12,14,15,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42790 : packedSelected [0,1,2,4,6,7,8,9,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env42791 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,16401,35109,1024,32769,4113,41260,16,41230,8193,17,56577,57628,17665,2340,61705,41261,256,41260,16385,513]

theorem envBound42791 : H12AffineFastState.Bounded env42791 := by
  intro p hp
  have h : env42791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42790_42791 : H12AffineEnvironment.transform 5 17 env42790 = env42791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42790 == env42791) = true)

theorem identity42791 : scanCanonicalize (H12AffineFastState.compose env42791 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound42791 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env42792 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,54278,16401,35109,1024,32769,4113,32800,16,32770,269,17,56577,49168,17665,2340,53253,32801,256,32800,16385,513]

theorem envBound42792 : H12AffineFastState.Bounded env42792 := by
  intro p hp
  have h : env42792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42791_42792 : H12AffineEnvironment.transform 12 268 env42791 = env42792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env42791 == env42792) = true)

theorem identity42792 : scanCanonicalize (H12AffineFastState.compose env42792 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound42792 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env42793 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,21510,16401,2341,1024,1,4113,32,16,2,269,17,23809,16400,17665,2340,20485,33,256,32,16385,513]

theorem envBound42793 : H12AffineFastState.Bounded env42793 := by
  intro p hp
  have h : env42793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42792_42793 : H12AffineEnvironment.transform 14 0 env42792 = env42793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env42792 == env42793) = true)

theorem identity42793 : scanCanonicalize (H12AffineFastState.compose env42793 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound42793 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42794 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1024,1,4113,32,16,2,269,17,2049,5392,4097,2340,1285,33,256,32,5377,513]

theorem envBound42794 : H12AffineFastState.Bounded env42794 := by
  intro p hp
  have h : env42794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42793_42794 : H12AffineEnvironment.transform 13 5376 env42793 = env42794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env42793 == env42794) = true)

theorem identity42794 : scanCanonicalize (H12AffineFastState.compose env42794 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42794 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42795 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,9,5125,0,3,5140,2080,1024,1,4113,32,16,2,8,17,2049,5141,4097,2081,1024,33,5,32,5124,513]

theorem envBound42795 : H12AffineFastState.Bounded env42795 := by
  intro p hp
  have h : env42795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42794_42795 : H12AffineEnvironment.transform 7 5 env42794 = env42795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42794 == env42795) = true)

theorem identity42795 : scanCanonicalize (H12AffineFastState.compose env42795 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42795 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42796 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,4096,9,4145,0,3,4128,2080,52,1,4113,32,16,2,8,17,2049,4129,4097,2081,52,33,5,32,4144,513]

theorem envBound42796 : H12AffineFastState.Bounded env42796 := by
  intro p hp
  have h : env42796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42795_42796 : H12AffineEnvironment.transform 9 52 env42795 = env42796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42795 == env42796) = true)

theorem identity42796 : scanCanonicalize (H12AffineFastState.compose env42796 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound42796 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42797 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,2609,9,2560,0,3,2577,2080,52,1,2592,32,16,2,8,17,2049,2576,2608,2081,52,33,5,32,2561,513]

theorem envBound42797 : H12AffineFastState.Bounded env42797 := by
  intro p hp
  have h : env42797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42796_42797 : H12AffineEnvironment.transform 11 2609 env42796 = env42797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env42796 == env42797) = true)

theorem identity42797 : scanCanonicalize (H12AffineFastState.compose env42797 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound42797 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42798 : List Nat := [2,4,8,16,32,17,9,5,512,52,512,49,9,0,0,3,17,544,52,1,32,32,16,2,8,17,513,16,48,545,52,33,5,32,1,513]

theorem envBound42798 : H12AffineFastState.Bounded env42798 := by
  intro p hp
  have h : env42798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42797_42798 : H12AffineEnvironment.transform 10 512 env42797 = env42798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env42797 == env42798) = true)

theorem identity42798 : scanCanonicalize (H12AffineFastState.compose env42798 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound42798 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42799 : List Nat := [2,4,8,16,32,17,9,5,48,52,48,49,9,0,0,3,17,16,52,1,32,32,16,2,8,17,49,16,48,17,52,33,5,32,1,49]

theorem envBound42799 : H12AffineFastState.Bounded env42799 := by
  intro p hp
  have h : env42799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42798_42799 : H12AffineEnvironment.transform 8 48 env42798 = env42799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env42798 == env42799) = true)

theorem identity42799 : scanCanonicalize (H12AffineFastState.compose env42799 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42799 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env42800 : List Nat := [2,4,8,16,1,17,9,5,17,21,17,16,9,0,0,3,17,16,21,1,1,1,16,2,8,17,16,16,17,17,21,0,5,1,1,16]

theorem envBound42800 : H12AffineFastState.Bounded env42800 := by
  intro p hp
  have h : env42800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42799_42800 : H12AffineEnvironment.transform 4 1 env42799 = env42800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42799 == env42800) = true)

theorem identity42800 : scanCanonicalize (H12AffineFastState.compose env42800 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42800 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42801 : List Nat := [2,4,8,10,1,11,9,5,11,15,11,10,9,0,0,3,11,10,15,1,1,1,10,2,8,11,10,10,11,11,15,0,5,1,1,10]

theorem envBound42801 : H12AffineFastState.Bounded env42801 := by
  intro p hp
  have h : env42801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42800_42801 : H12AffineEnvironment.transform 3 10 env42800 = env42801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42800 == env42801) = true)

def env42802 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272393,17,95496,8193,64,171281,79130,102743,442385,61704,392287,256,95531,103430,120407]

theorem envBound42802 : H12AffineFastState.Bounded env42802 := by
  intro p hp
  have h : env42802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42772_42802 : H12AffineEnvironment.transform 22 17 env42772 = env42802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env42772 == env42802) = true)

theorem identity42802 : scanCanonicalize (H12AffineFastState.compose env42802 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound42802 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115735,32,17,95496,8193,64,171281,79130,102743,190520,61704,119926,256,95531,103430,120407]

theorem envBound42803 : H12AffineFastState.Bounded env42803 := by
  intro p hp
  have h : env42803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42802_42803 : H12AffineEnvironment.transform 17 10281 env42802 = env42803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42802 == env42803) = true)

theorem identity42803 : scanCanonicalize (H12AffineFastState.compose env42803 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound42803 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env42804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46157,10281,1024,32769,115735,32,17,95496,8193,64,10588,79130,102743,23669,61704,119926,256,95531,103430,120407]

theorem envBound42804 : H12AffineFastState.Bounded env42804 := by
  intro p hp
  have h : env42804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42803_42804 : H12AffineEnvironment.transform 16 46157 env42803 = env42804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env42803 == env42804) = true)

theorem identity42804 : scanCanonicalize (H12AffineFastState.compose env42804 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound42804 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,46157,10281,1024,32769,102678,32,17,73737,8193,64,10588,79130,102743,2420,41993,98679,256,73770,103430,99158]

theorem envBound42805 : H12AffineFastState.Bounded env42805 := by
  intro p hp
  have h : env42805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42804_42805 : H12AffineEnvironment.transform 13 5377 env42804 = env42805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env42804 == env42805) = true)

theorem identity42805 : scanCanonicalize (H12AffineFastState.compose env42805 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound42805 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env42806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,46157,10281,1024,32769,4160,32,17,41311,8193,64,10588,46156,4097,2420,41993,33,256,41340,5456,512]

theorem envBound42806 : H12AffineFastState.Bounded env42806 := by
  intro p hp
  have h : env42806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42805_42806 : H12AffineEnvironment.transform 15 33110 env42805 = env42806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env42805 == env42806) = true)

theorem identity42806 : scanCanonicalize (H12AffineFastState.compose env42806 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5164) := by decide +kernel

theorem selectedBound42806 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5164,5377,32768,33110,32865,7173,1024,32769,4160,32,17,38259,5165,64,7536,32864,4097,2420,36901,33,256,38224,5456,512]

theorem envBound42807 : H12AffineFastState.Bounded env42807 := by
  intro p hp
  have h : env42807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42806_42807 : H12AffineEnvironment.transform 12 5164 env42806 = env42807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5164 env42806 == env42807) = true)

theorem identity42807 : scanCanonicalize (H12AffineFastState.compose env42807 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 4405) := by decide +kernel

theorem selectedBound42807 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env42808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5164,5377,4405,4195,4436,7173,1024,4404,4160,32,17,1094,5165,64,7536,4437,4097,2420,272,33,256,1125,5456,512]

theorem envBound42808 : H12AffineFastState.Bounded env42808 := by
  intro p hp
  have h : env42808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42807_42808 : H12AffineEnvironment.transform 14 4405 env42807 = env42808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4405 env42807 == env42808) = true)

theorem identity42808 : scanCanonicalize (H12AffineFastState.compose env42808 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42808 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env42809 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,5164,5157,4113,4195,4208,7173,1024,4112,4160,32,17,1094,5165,64,7252,4209,4097,2128,52,33,36,1125,5236,512]

theorem envBound42809 : H12AffineFastState.Bounded env42809 := by
  intro p hp
  have h : env42809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42808_42809 : H12AffineEnvironment.transform 7 36 env42808 = env42809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42808 == env42809) = true)

theorem identity42809 : scanCanonicalize (H12AffineFastState.compose env42809 (packedSelected [0,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound42809 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env42810 : List Nat := [2,4,8,16,32,64,9,36,512,21,2048,4096,4153,4144,4113,4195,4208,6160,21,4112,4160,32,17,83,4152,64,6209,4209,4097,2128,52,33,36,112,4193,512]

theorem envBound42810 : H12AffineFastState.Bounded env42810 := by
  intro p hp
  have h : env42810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42809_42810 : H12AffineEnvironment.transform 9 21 env42809 = env42810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env42809 == env42810) = true)

theorem identity42810 : scanCanonicalize (H12AffineFastState.compose env42810 (packedSelected [3,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound42810 : packedSelected [3,6,7,8] rootPS < 2^1333 := by decide +kernel

def env42811 : List Nat := [2,4,8,16,32,64,9,36,512,21,609,4096,4153,4144,4113,4195,4208,4721,21,4112,4160,32,17,83,4152,64,4640,4209,4097,561,52,33,36,112,4193,512]

theorem envBound42811 : H12AffineFastState.Bounded env42811 := by
  intro p hp
  have h : env42811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42810_42811 : H12AffineEnvironment.transform 10 609 env42810 = env42811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env42810 == env42811) = true)

theorem identity42811 : scanCanonicalize (H12AffineFastState.compose env42811 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound42811 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env42812 : List Nat := [2,4,8,16,32,64,9,36,512,21,609,48,9,0,33,83,64,577,21,32,112,32,17,83,8,64,528,65,49,561,52,33,36,112,81,512]

theorem envBound42812 : H12AffineFastState.Bounded env42812 := by
  intro p hp
  have h : env42812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42811_42812 : H12AffineEnvironment.transform 11 48 env42811 = env42812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42811 == env42812) = true)

theorem identity42812 : scanCanonicalize (H12AffineFastState.compose env42812 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound42812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42813 : List Nat := [2,4,8,16,32,64,9,36,96,21,1,48,9,0,33,83,64,33,21,32,112,32,17,83,8,64,112,65,49,81,52,33,36,112,81,96]

theorem envBound42813 : H12AffineFastState.Bounded env42813 := by
  intro p hp
  have h : env42813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42812_42813 : H12AffineEnvironment.transform 8 96 env42812 = env42813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env42812 == env42813) = true)

theorem identity42813 : scanCanonicalize (H12AffineFastState.compose env42813 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound42813 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env42814 : List Nat := [2,4,8,16,32,49,9,36,17,21,1,48,9,0,33,34,49,33,21,32,1,32,17,34,8,49,1,48,49,32,52,33,36,1,32,17]

theorem envBound42814 : H12AffineFastState.Bounded env42814 := by
  intro p hp
  have h : env42814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42813_42814 : H12AffineEnvironment.transform 5 49 env42813 = env42814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env42813 == env42814) = true)

theorem identity42814 : scanCanonicalize (H12AffineFastState.compose env42814 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound42814 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42815 : List Nat := [2,4,8,5,32,36,9,36,4,0,1,37,9,0,33,34,36,33,0,32,1,32,4,34,8,36,1,37,36,32,33,33,36,1,32,4]

theorem envBound42815 : H12AffineFastState.Bounded env42815 := by
  intro p hp
  have h : env42815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42814_42815 : H12AffineEnvironment.transform 3 5 env42814 = env42815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env42814 == env42815) = true)

def env42816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272513,8388608,95496,8328,64,8560008,79130,8491471,8830976,8450329,392407,256,8484154,8492190,8509135]

theorem envBound42816 : H12AffineFastState.Bounded env42816 := by
  intro p hp
  have h : env42816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42744_42816 : H12AffineEnvironment.transform 21 272513 env42744 = env42816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42744 == env42816) = true)

theorem identity42816 : scanCanonicalize (H12AffineFastState.compose env42816 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound42816 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115870,272513,16,95496,8328,64,171416,79130,102879,442384,61705,392407,256,95530,103566,120543]

theorem envBound42817 : H12AffineFastState.Bounded env42817 := by
  intro p hp
  have h : env42817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42816_42817 : H12AffineEnvironment.transform 22 16 env42816 = env42817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env42816 == env42817) = true)

def env42818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,16,95496,8192,64,171280,79130,102743,442384,61705,392287,256,95530,103430,120407]

theorem envBound42818 : H12AffineFastState.Bounded env42818 := by
  intro p hp
  have h : env42818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42817_42818 : H12AffineEnvironment.transform 6 8 env42817 = env42818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42817 == env42818) = true)

theorem identity42818 : scanCanonicalize (H12AffineFastState.compose env42818 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound42818 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,91466,272393,16,95496,8192,64,146508,79130,77835,418124,20565,351491,256,95530,79194,96011]

theorem envBound42819 : H12AffineFastState.Bounded env42819 := by
  intro p hp
  have h : env42819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42818_42819 : H12AffineEnvironment.transform 14 8540 env42818 = env42819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env42818 == env42819) = true)

theorem identity42819 : scanCanonicalize (H12AffineFastState.compose env42819 (packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound42819 : packedSelected [0,9,11,12,14,15,18,22,23,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env42820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,90139,262144,1024,8541,91466,272393,16,95496,8192,64,89175,79130,77835,328023,20565,351491,256,95530,79194,96011]

theorem envBound42820 : H12AffineFastState.Bounded env42820 := by
  intro p hp
  have h : env42820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42819_42820 : H12AffineEnvironment.transform 16 90139 env42819 = env42820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env42819 == env42820) = true)

theorem identity42820 : scanCanonicalize (H12AffineFastState.compose env42820 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound42820 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env42821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,5393,262144,1024,8541,4160,272393,16,2,8192,64,10589,16400,17665,291933,20565,272393,256,32,16464,513]

theorem envBound42821 : H12AffineFastState.Bounded env42821 := by
  intro p hp
  have h : env42821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42820_42821 : H12AffineEnvironment.transform 15 29962 env42820 = env42821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env42820 == env42821) = true)

theorem identity42821 : scanCanonicalize (H12AffineFastState.compose env42821 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound42821 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42822 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8540,28699,4096,262144,273,8541,4160,272393,16,2,8192,64,10589,16400,16400,291148,20565,272393,256,32,16464,513]

theorem envBound42822 : H12AffineFastState.Bounded env42822 := by
  intro p hp
  have h : env42822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42821_42822 : H12AffineEnvironment.transform 9 273 env42821 = env42822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env42821 == env42822) = true)

theorem identity42822 : scanCanonicalize (H12AffineFastState.compose env42822 (packedSelected [0,2,6,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42822 : packedSelected [0,2,6,14,27] rootPS < 2^1333 := by decide +kernel

def env42823 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8540,28699,4096,10280,273,8541,4160,33,16,2,8192,64,10589,16400,16400,22884,20565,33,256,32,16464,513]

theorem envBound42823 : H12AffineFastState.Bounded env42823 := by
  intro p hp
  have h : env42823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42822_42823 : H12AffineEnvironment.transform 17 10280 env42822 = env42823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42822 == env42823) = true)

end H12CloudChart0