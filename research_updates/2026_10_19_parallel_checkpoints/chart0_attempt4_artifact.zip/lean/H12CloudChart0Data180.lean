import H12CloudChart0Data179

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity45585 : scanCanonicalize (H12AffineFastState.compose env45585 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound45585 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45586 : List Nat := [2,4,8,4,1,5,9,5,512,1024,522,5,9,1025,1,3,1029,523,1025,0,0,0,5,3,8,5,522,1028,5,523,1025,1,4,0,1024,513]

theorem envBound45586 : H12AffineFastState.Bounded env45586 := by
  intro p hp
  have h : env45586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45585_45586 : H12AffineEnvironment.transform 3 4 env45585 = env45586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env45585 == env45586) = true)

def env45587 : List Nat := [2,4,8,4,1,5,9,5,512,0,522,5,9,1,1,3,5,523,1,0,0,0,5,3,8,5,522,4,5,523,1,1,4,0,0,513]

theorem envBound45587 : H12AffineFastState.Bounded env45587 := by
  intro p hp
  have h : env45587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45586_45587 : H12AffineEnvironment.transform 9 0 env45586 = env45587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env45586 == env45587) = true)

theorem identity45587 : scanCanonicalize (H12AffineFastState.compose env45587 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45587 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45588 : List Nat := [1,4,8,4,1,5,9,5,512,0,521,5,9,1,1,0,5,520,1,0,0,0,5,0,8,5,521,4,5,520,1,1,4,0,0,513]

theorem envBound45588 : H12AffineFastState.Bounded env45588 := by
  intro p hp
  have h : env45588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45587_45588 : H12AffineEnvironment.transform 0 1 env45587 = env45588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45587 == env45588) = true)

def leafEnv45588 : List Nat := [1,4,8,4,1,5,9,5,512,0,521,5,9,1,1,0,5,520,1,0,0,0,5,0,1,8,1,5,521,4,5,520,1,1,4,0,4,1,0,513,1,1,0]

def active45588 : List Nat := [1,2,8]

def tree45588 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45588 : H12WitnessSearch.Good tree45588 := H12GlobalWitnessIndex.good

theorem leafIdentity45588 : H12AffineFastState.composeSystem env45588 rootObs = leafEnv45588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45588 rootObs == leafEnv45588) = true)

theorem terminalChecked45588 : H12PackedTerminal.terminalCheckFast leafEnv45588 active45588 tree45588 = true := by decide +kernel

def env45589 : List Nat := [2,4,8,4,1,5,9,5,512,1,522,5,9,0,1,3,4,523,0,0,0,0,5,3,8,5,522,5,5,523,0,1,4,0,1,513]

theorem envBound45589 : H12AffineFastState.Bounded env45589 := by
  intro p hp
  have h : env45589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45586_45589 : H12AffineEnvironment.transform 9 1 env45586 = env45589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env45586 == env45589) = true)

theorem identity45589 : scanCanonicalize (H12AffineFastState.compose env45589 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound45589 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45590 : List Nat := [2,4,8,4,1,5,9,5,8,1,2,5,9,0,1,3,4,3,0,0,0,0,5,3,8,5,2,5,5,3,0,1,4,0,1,9]

theorem envBound45590 : H12AffineFastState.Bounded env45590 := by
  intro p hp
  have h : env45590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45589_45590 : H12AffineEnvironment.transform 8 8 env45589 = env45590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env45589 == env45590) = true)

def leafEnv45590 : List Nat := [2,4,8,4,1,5,9,5,8,1,2,5,9,0,1,3,4,3,0,0,0,0,5,3,0,8,1,5,2,5,5,3,0,1,4,0,4,2,1,9,1,1,0]

def active45590 : List Nat := [0,1,2]

def tree45590 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45590 : H12WitnessSearch.Good tree45590 := H12GlobalWitnessIndex.good

theorem leafIdentity45590 : H12AffineFastState.composeSystem env45590 rootObs = leafEnv45590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45590 rootObs == leafEnv45590) = true)

theorem terminalChecked45590 : H12PackedTerminal.terminalCheckFast leafEnv45590 active45590 tree45590 = true := by decide +kernel

def env45591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10401,1025,32769,115870,32,120015,98780,8328,64,43477,115150,17665,10280,119042,73890,257,21792,46212,63189]

theorem envBound45591 : H12AffineFastState.Bounded env45591 := by
  intro p hp
  have h : env45591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45568_45591 : H12AffineEnvironment.transform 17 10401 env45568 = env45591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env45568 == env45591) = true)

theorem identity45591 : scanCanonicalize (H12AffineFastState.compose env45591 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound45591 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env45592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41091,46277,10401,1025,32769,25629,32,29772,8543,8328,64,43477,24909,17665,10280,29057,32801,257,21792,46212,63189]

theorem envBound45592 : H12AffineFastState.Bounded env45592 := by
  intro p hp
  have h : env45592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45591_45592 : H12AffineEnvironment.transform 15 41091 env45591 = env45592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env45591 == env45592) = true)

theorem identity45592 : scanCanonicalize (H12AffineFastState.compose env45592 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound45592 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env45593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,21727,16537,10401,1025,29789,25629,32,29772,8543,8328,64,23945,24909,17665,10280,29057,29821,257,21792,16600,649]

theorem envBound45593 : H12AffineFastState.Bounded env45593 := by
  intro p hp
  have h : env45593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45592_45593 : H12AffineEnvironment.transform 14 29788 env45592 = env45593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env45592 == env45593) = true)

theorem identity45593 : scanCanonicalize (H12AffineFastState.compose env45593 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound45593 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env45594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,81,8402,13460,10401,1025,80,4112,32,65,8543,8328,64,10628,5440,12556,10280,1420,112,257,8493,13525,649]

theorem envBound45594 : H12AffineFastState.Bounded env45594 := by
  intro p hp
  have h : env45594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45593_45594 : H12AffineEnvironment.transform 13 13325 env45593 = env45594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env45593 == env45594) = true)

theorem identity45594 : scanCanonicalize (H12AffineFastState.compose env45594 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound45594 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env45595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5513,81,342,5392,2341,1025,80,4112,32,65,219,268,64,2048,5440,4232,2476,1420,112,257,169,5457,649]

theorem envBound45595 : H12AffineFastState.Bounded env45595 := by
  intro p hp
  have h : env45595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45594_45595 : H12AffineEnvironment.transform 12 388 env45594 = env45595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env45594 == env45595) = true)

theorem identity45595 : scanCanonicalize (H12AffineFastState.compose env45595 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound45595 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45596 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,120,5237,81,170,5356,2265,1025,80,4112,32,65,219,240,64,2048,5308,4232,2128,1136,112,253,169,5293,649]

theorem envBound45596 : H12AffineFastState.Bounded env45596 := by
  intro p hp
  have h : env45596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45595_45596 : H12AffineEnvironment.transform 7 252 env45595 = env45596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env45595 == env45596) = true)

theorem identity45596 : scanCanonicalize (H12AffineFastState.compose env45596 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45596 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env45597 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,40,5157,1,170,5308,2185,1025,0,4112,32,17,139,160,16,2048,5308,4232,2048,1056,32,173,169,5293,649]

theorem envBound45597 : H12AffineFastState.Bounded env45597 := by
  intro p hp
  have h : env45597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45596_45597 : H12AffineEnvironment.transform 5 16 env45596 = env45597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45596 == env45597) = true)

theorem identity45597 : scanCanonicalize (H12AffineFastState.compose env45597 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound45597 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45598 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3245,40,2184,1,170,2065,2185,1025,0,3261,32,17,139,160,16,2048,2065,3109,2048,1056,32,173,169,2048,649]

theorem envBound45598 : H12AffineFastState.Bounded env45598 := by
  intro p hp
  have h : env45598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45597_45598 : H12AffineEnvironment.transform 11 3245 env45597 = env45598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env45597 == env45598) = true)

theorem identity45598 : scanCanonicalize (H12AffineFastState.compose env45598 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound45598 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env45599 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,153,40,1212,1,170,1061,1213,1025,0,137,32,17,139,160,16,1076,1061,17,1076,1056,32,173,169,1076,649]

theorem envBound45599 : H12AffineFastState.Bounded env45599 := by
  intro p hp
  have h : env45599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45598_45599 : H12AffineEnvironment.transform 10 1076 env45598 = env45599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env45598 == env45599) = true)

theorem identity45599 : scanCanonicalize (H12AffineFastState.compose env45599 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45599 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45600 : List Nat := [2,4,8,0,32,0,128,172,512,1024,1060,137,40,1196,1,170,1061,1197,1025,0,137,32,1,139,160,0,1060,1061,1,1060,1056,32,173,169,1060,649]

theorem envBound45600 : H12AffineFastState.Bounded env45600 := by
  intro p hp
  have h : env45600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45599_45600 : H12AffineEnvironment.transform 3 0 env45599 = env45600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45599 == env45600) = true)

theorem identity45600 : scanCanonicalize (H12AffineFastState.compose env45600 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound45600 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env45601 : List Nat := [2,4,8,0,32,0,128,172,512,37,1,137,40,137,1,170,0,136,36,0,137,32,1,139,160,0,1,0,1,1,5,32,173,169,1,649]

theorem envBound45601 : H12AffineFastState.Bounded env45601 := by
  intro p hp
  have h : env45601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45600_45601 : H12AffineEnvironment.transform 9 37 env45600 = env45601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env45600 == env45601) = true)

theorem identity45601 : scanCanonicalize (H12AffineFastState.compose env45601 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45601 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45602 : List Nat := [2,4,8,0,32,0,8,36,512,37,1,1,40,1,1,34,0,0,36,0,1,32,1,3,40,0,1,0,1,1,5,32,37,33,1,513]

theorem envBound45602 : H12AffineFastState.Bounded env45602 := by
  intro p hp
  have h : env45602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45601_45602 : H12AffineEnvironment.transform 6 8 env45601 = env45602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45601 == env45602) = true)

theorem identity45602 : scanCanonicalize (H12AffineFastState.compose env45602 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45602 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45603 : List Nat := [2,4,8,0,32,0,8,36,1,37,1,1,40,1,1,34,0,0,36,0,1,32,1,3,40,0,1,0,1,1,5,32,37,33,1,0]

theorem envBound45603 : H12AffineFastState.Bounded env45603 := by
  intro p hp
  have h : env45603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45602_45603 : H12AffineEnvironment.transform 8 1 env45602 = env45603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45602 == env45603) = true)

theorem identity45603 : scanCanonicalize (H12AffineFastState.compose env45603 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45604 : List Nat := [2,4,3,0,32,0,3,36,1,37,1,1,35,1,1,34,0,0,36,0,1,32,1,3,35,0,1,0,1,1,5,32,37,33,1,0]

theorem envBound45604 : H12AffineFastState.Bounded env45604 := by
  intro p hp
  have h : env45604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45603_45604 : H12AffineEnvironment.transform 2 3 env45603 = env45604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45603 == env45604) = true)

def env45605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,8388608,8601941,8328,64,4489556,8393984,8553865,8830976,181572,12645452,257,21793,46213,254611]

theorem envBound45605 : H12AffineFastState.Bounded env45605 := by
  intro p hp
  have h : env45605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45515_45605 : H12AffineEnvironment.transform 20 184537 env45515 = env45605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env45515 == env45605) = true)

def env45606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180360,98781,8328,64,4489556,185736,17665,262280,181572,4338884,257,21793,46213,254611]

theorem envBound45606 : H12AffineFastState.Bounded env45606 := by
  intro p hp
  have h : env45606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45605_45606 : H12AffineEnvironment.transform 22 180360 env45605 = env45606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env45605 == env45606) = true)

def env45607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180360,98781,8328,64,43476,185736,17665,262280,181572,400452,257,21793,46213,254611]

theorem envBound45607 : H12AffineFastState.Bounded env45607 := by
  intro p hp
  have h : env45607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45606_45607 : H12AffineEnvironment.transform 21 272512 env45606 = env45607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45606 == env45607) = true)

theorem identity45607 : scanCanonicalize (H12AffineFastState.compose env45607 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound45607 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4160,272512,17,98781,8328,64,43476,5393,17665,262280,1501,318685,257,21793,46213,74250]

theorem envBound45608 : H12AffineFastState.Bounded env45608 := by
  intro p hp
  have h : env45608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45607_45608 : H12AffineEnvironment.transform 16 49305 env45607 = env45608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env45607 == env45608) = true)

theorem identity45608 : scanCanonicalize (H12AffineFastState.compose env45608 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45608 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env45609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,4160,272512,17,41430,8328,64,43476,5393,17665,262280,1501,318685,257,21793,46213,513]

theorem envBound45609 : H12AffineFastState.Bounded env45609 := by
  intro p hp
  have h : env45609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45608_45609 : H12AffineEnvironment.transform 15 8203 env45608 = env45609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45608 == env45609) = true)

def env45610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180360,98781,8328,64,43477,185736,17665,262280,181572,400453,257,21793,46213,254611]

theorem envBound45610 : H12AffineFastState.Bounded env45610 := by
  intro p hp
  have h : env45610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45606_45610 : H12AffineEnvironment.transform 21 272513 env45606 = env45610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45606 == env45610) = true)

def env45611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272393,180224,98645,8192,64,43357,185600,17665,262144,181572,400453,257,21793,46093,254491]

theorem envBound45611 : H12AffineFastState.Bounded env45611 := by
  intro p hp
  have h : env45611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45610_45611 : H12AffineEnvironment.transform 6 8 env45610 = env45611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45610 == env45611) = true)

theorem identity45611 : scanCanonicalize (H12AffineFastState.compose env45611 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound45611 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env45612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,262144,1025,32769,184401,272393,180224,8542,8192,64,43357,185600,17665,262144,181572,400453,257,21793,46093,147984]

theorem envBound45612 : H12AffineFastState.Bounded env45612 := by
  intro p hp
  have h : env45612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45611_45612 : H12AffineEnvironment.transform 15 40971 env45611 = env45612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env45611 == env45612) = true)

theorem identity45612 : scanCanonicalize (H12AffineFastState.compose env45612 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound45612 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env45613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,43048,1025,32769,184401,32801,180224,8542,8192,64,43357,185600,17665,43048,181572,177261,257,21793,46093,147984]

theorem envBound45613 : H12AffineFastState.Bounded env45613 := by
  intro p hp
  have h : env45613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45612_45613 : H12AffineEnvironment.transform 17 43048 env45612 = env45613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env45612 == env45613) = true)

theorem identity45613 : scanCanonicalize (H12AffineFastState.compose env45613 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound45613 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,57676,43048,1025,32769,12573,32801,8524,8542,8192,64,43357,13388,17665,43048,9224,21793,257,21793,46093,41820]

theorem envBound45614 : H12AffineFastState.Bounded env45614 := by
  intro p hp
  have h : env45614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45613_45614 : H12AffineEnvironment.transform 16 57676 env45613 = env45614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env45613 == env45614) = true)

theorem identity45614 : scanCanonicalize (H12AffineFastState.compose env45614 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45614 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env45615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33111,49168,35188,1025,32769,4161,32801,16,2,348,64,34817,5392,17665,35188,1364,21793,257,21793,38225,33280]

theorem envBound45615 : H12AffineFastState.Bounded env45615 := by
  intro p hp
  have h : env45615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45614_45615 : H12AffineEnvironment.transform 12 348 env45614 = env45615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45614 == env45615) = true)

theorem identity45615 : scanCanonicalize (H12AffineFastState.compose env45615 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound45615 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env45616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5156,32768,33111,37940,35188,1025,32769,4161,32801,16,2,348,64,34817,5392,4389,35188,1364,261,257,261,38225,33280]

theorem envBound45616 : H12AffineFastState.Bounded env45616 := by
  intro p hp
  have h : env45616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45615_45616 : H12AffineEnvironment.transform 13 5156 env45615 = env45616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env45615 == env45616) = true)

theorem identity45616 : scanCanonicalize (H12AffineFastState.compose env45616 (packedSelected [0,1,7,8,10,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound45616 : packedSelected [0,1,7,8,10,11,14] rootPS < 2^1333 := by decide +kernel

def env45617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,348,1344,32768,33111,34128,35188,1025,32769,293,32801,16,2,348,64,34817,1140,65,35188,1364,261,257,261,33845,33280]

theorem envBound45617 : H12AffineFastState.Bounded env45617 := by
  intro p hp
  have h : env45617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45616_45617 : H12AffineEnvironment.transform 11 356 env45616 = env45617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env45616 == env45617) = true)

theorem identity45617 : scanCanonicalize (H12AffineFastState.compose env45617 (packedSelected [0,2,4,6,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45617 : packedSelected [0,2,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env45618 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,356,348,81,32768,33111,32833,35188,272,32769,293,32801,16,2,348,64,34817,357,65,35188,69,261,257,261,33060,33280]

theorem envBound45618 : H12AffineFastState.Bounded env45618 := by
  intro p hp
  have h : env45618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45617_45618 : H12AffineEnvironment.transform 9 273 env45617 = env45618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45617 == env45618) = true)

theorem identity45618 : scanCanonicalize (H12AffineFastState.compose env45618 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound45618 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45619 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,356,348,81,373,34,308,2049,272,372,293,340,16,2,348,64,2420,357,65,2049,69,261,257,261,81,885]

theorem envBound45619 : H12AffineFastState.Bounded env45619 := by
  intro p hp
  have h : env45619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45618_45619 : H12AffineEnvironment.transform 14 373 env45618 = env45619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env45618 == env45619) = true)

def env45620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272392,180225,98644,8193,64,43356,185601,17665,262145,181572,400453,257,21793,46092,254490]

theorem envBound45620 : H12AffineFastState.Bounded env45620 := by
  intro p hp
  have h : env45620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45610_45620 : H12AffineEnvironment.transform 6 9 env45610 = env45620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45610 == env45620) = true)

def env45621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,17,98644,8193,64,43356,5393,17665,262145,1364,318549,257,21793,46092,74250]

theorem envBound45621 : H12AffineFastState.Bounded env45621 := by
  intro p hp
  have h : env45621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45620_45621 : H12AffineEnvironment.transform 16 49168 env45620 = env45621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45620 == env45621) = true)

theorem identity45621 : scanCanonicalize (H12AffineFastState.compose env45621 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound45621 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,33,17,98644,8193,64,43356,5393,17665,10280,1364,62588,257,21793,46092,74250]

theorem envBound45622 : H12AffineFastState.Bounded env45622 := by
  intro p hp
  have h : env45622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45621_45622 : H12AffineEnvironment.transform 17 10281 env45621 = env45622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env45621 == env45622) = true)

theorem identity45622 : scanCanonicalize (H12AffineFastState.compose env45622 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound45622 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,49168,10281,1025,32769,4160,33,17,8543,8193,64,43356,5393,17665,10280,1364,62588,257,21793,46092,33281]

theorem envBound45623 : H12AffineFastState.Bounded env45623 := by
  intro p hp
  have h : env45623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45622_45623 : H12AffineEnvironment.transform 15 40971 env45622 = env45623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env45622 == env45623) = true)

theorem identity45623 : scanCanonicalize (H12AffineFastState.compose env45623 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound45623 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env45624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40971,46157,10281,1025,32769,4160,33,17,8543,8193,64,43356,5393,12636,10280,1364,32801,257,8572,46092,33281]

theorem envBound45624 : H12AffineFastState.Bounded env45624 := by
  intro p hp
  have h : env45624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45623_45624 : H12AffineEnvironment.transform 13 13405 env45623 = env45624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env45623 == env45624) = true)

theorem identity45624 : scanCanonicalize (H12AffineFastState.compose env45624 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45624 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env45625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,342,5392,10281,1025,8540,4160,33,17,8543,8193,64,2049,5393,12636,10280,1364,8572,257,8572,5457,9052]

theorem envBound45625 : H12AffineFastState.Bounded env45625 := by
  intro p hp
  have h : env45625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45624_45625 : H12AffineEnvironment.transform 14 8541 env45624 = env45625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45624 == env45625) = true)

theorem identity45625 : scanCanonicalize (H12AffineFastState.compose env45625 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45625 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45626 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12620,8541,342,4097,10281,272,8540,4160,33,17,8543,8193,64,2049,4096,12636,10280,69,8572,257,8572,4160,9052]

theorem envBound45626 : H12AffineFastState.Bounded env45626 := by
  intro p hp
  have h : env45626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45625_45626 : H12AffineEnvironment.transform 9 273 env45625 = env45626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45625 == env45626) = true)

theorem identity45626 : scanCanonicalize (H12AffineFastState.compose env45626 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound45626 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env45627 : List Nat := [2,4,8,16,32,64,9,85,512,68,2048,4096,8192,12313,8200,3,4097,10281,69,8201,4160,33,17,8202,8193,64,2049,4096,12297,10280,69,8233,84,8233,4160,8713]

theorem envBound45627 : H12AffineFastState.Bounded env45627 := by
  intro p hp
  have h : env45627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45626_45627 : H12AffineEnvironment.transform 7 85 env45626 = env45627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env45626 == env45627) = true)

theorem identity45627 : scanCanonicalize (H12AffineFastState.compose env45627 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound45627 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env45628 : List Nat := [2,4,8,16,32,64,9,85,512,68,2048,4096,4153,32,4145,3,4097,6160,69,4144,4160,33,17,4147,4152,64,2049,4096,48,6161,69,4112,84,4112,4160,4656]

theorem envBound45628 : H12AffineFastState.Bounded env45628 := by
  intro p hp
  have h : env45628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45627_45628 : H12AffineEnvironment.transform 12 4153 env45627 = env45628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env45627 == env45628) = true)

theorem identity45628 : scanCanonicalize (H12AffineFastState.compose env45628 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45628 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45629 : List Nat := [2,4,8,16,32,17,9,4,512,21,2048,4096,4153,32,4145,3,4097,6160,20,4144,4113,33,17,4147,4152,17,2049,4096,48,6161,20,4112,5,4112,4113,4656]

theorem envBound45629 : H12AffineFastState.Bounded env45629 := by
  intro p hp
  have h : env45629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45628_45629 : H12AffineEnvironment.transform 5 17 env45628 = env45629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45628 == env45629) = true)

theorem identity45629 : scanCanonicalize (H12AffineFastState.compose env45629 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound45629 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env45630 : List Nat := [2,4,8,16,32,17,9,4,512,21,2048,2096,2057,32,2049,3,2097,32,20,2048,2081,33,17,2051,2056,17,2049,2096,48,33,20,2080,5,2080,2081,2560]

theorem envBound45630 : H12AffineFastState.Bounded env45630 := by
  intro p hp
  have h : env45630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45629_45630 : H12AffineEnvironment.transform 11 2096 env45629 = env45630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env45629 == env45630) = true)

theorem identity45630 : scanCanonicalize (H12AffineFastState.compose env45630 (packedSelected [14] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45630 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env45631 : List Nat := [2,4,8,16,32,17,9,4,512,21,0,48,9,32,1,3,49,32,20,0,33,33,17,3,8,17,1,48,48,33,20,32,5,32,33,512]

theorem envBound45631 : H12AffineFastState.Bounded env45631 := by
  intro p hp
  have h : env45631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45630_45631 : H12AffineEnvironment.transform 10 0 env45630 = env45631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45630 == env45631) = true)

theorem identity45631 : scanCanonicalize (H12AffineFastState.compose env45631 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound45631 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45632 : List Nat := [2,4,8,16,32,17,9,4,42,21,0,48,9,32,1,3,49,32,20,0,33,33,17,3,8,17,1,48,48,33,20,32,5,32,33,42]

theorem envBound45632 : H12AffineFastState.Bounded env45632 := by
  intro p hp
  have h : env45632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45631_45632 : H12AffineEnvironment.transform 8 42 env45631 = env45632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env45631 == env45632) = true)

def env45633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,16,98644,8193,64,43356,5392,17665,262145,1365,318548,257,21793,46092,74251]

theorem envBound45633 : H12AffineFastState.Bounded env45633 := by
  intro p hp
  have h : env45633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45620_45633 : H12AffineEnvironment.transform 16 49169 env45620 = env45633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45620 == env45633) = true)

theorem identity45633 : scanCanonicalize (H12AffineFastState.compose env45633 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 130094) := by decide +kernel

theorem selectedBound45633 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130094,1025,32769,4161,119846,16,98644,8193,64,43356,5392,17665,130095,1365,73850,257,21793,46092,74251]

theorem envBound45634 : H12AffineFastState.Bounded env45634 := by
  intro p hp
  have h : env45634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45633_45634 : H12AffineEnvironment.transform 17 130094 env45633 = env45634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130094 env45633 == env45634) = true)

theorem identity45634 : scanCanonicalize (H12AffineFastState.compose env45634 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound45634 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,65536,46109,100386,1025,32769,4161,106538,16,98644,8193,64,43356,5392,12557,100387,1365,73850,257,8493,46092,74251]

theorem envBound45635 : H12AffineFastState.Bounded env45635 := by
  intro p hp
  have h : env45635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45634_45635 : H12AffineEnvironment.transform 13 13324 env45634 = env45635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env45634 == env45635) = true)

theorem identity45635 : scanCanonicalize (H12AffineFastState.compose env45635 (packedSelected [1,5,8,10,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45635 : packedSelected [1,5,8,10,24,31] rootPS < 2^1333 := by decide +kernel

def env45636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,8202,46109,43048,1025,32769,4161,32800,16,41310,8193,64,43356,5392,12557,43049,1365,112,257,8493,46092,513]

theorem envBound45636 : H12AffineFastState.Bounded env45636 := by
  intro p hp
  have h : env45636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45635_45636 : H12AffineEnvironment.transform 15 8202 env45635 = env45636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45635 == env45636) = true)

theorem identity45636 : scanCanonicalize (H12AffineFastState.compose env45636 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45636 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,8202,5441,2420,1025,8541,4161,8572,16,2,8193,64,2048,5392,12557,2421,1365,112,257,8493,5456,513]

theorem envBound45637 : H12AffineFastState.Bounded env45637 := by
  intro p hp
  have h : env45637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45636_45637 : H12AffineEnvironment.transform 14 8540 env45636 = env45637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45636 == env45637) = true)

def env45638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180361,98780,8328,64,4489556,185737,17664,262281,181572,4338885,257,21793,46213,254611]

theorem envBound45638 : H12AffineFastState.Bounded env45638 := by
  intro p hp
  have h : env45638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45605_45638 : H12AffineEnvironment.transform 22 180361 env45605 = env45638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env45605 == env45638) = true)

def env45639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180361,98780,8328,64,43476,185737,17664,262281,181572,400453,257,21793,46213,254611]

theorem envBound45639 : H12AffineFastState.Bounded env45639 := by
  intro p hp
  have h : env45639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45638_45639 : H12AffineEnvironment.transform 21 272512 env45638 = env45639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45638 == env45639) = true)

theorem identity45639 : scanCanonicalize (H12AffineFastState.compose env45639 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound45639 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,58516,272512,62660,98780,8328,64,43476,57796,17664,262281,61705,272392,257,21793,46213,120542]

theorem envBound45640 : H12AffineFastState.Bounded env45640 := by
  intro p hp
  have h : env45640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45639_45640 : H12AffineEnvironment.transform 16 13389 env45639 = env45640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env45639 == env45640) = true)

def env45641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10280,1025,32769,58516,168,62660,98780,8328,64,43476,57796,17664,10401,61705,32,257,21793,46213,120542]

theorem envBound45641 : H12AffineFastState.Bounded env45641 := by
  intro p hp
  have h : env45641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45640_45641 : H12AffineEnvironment.transform 17 10280 env45640 = env45641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45640 == env45641) = true)

theorem identity45641 : scanCanonicalize (H12AffineFastState.compose env45641 (packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 20496) := by decide +kernel

theorem selectedBound45641 : packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env45642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20496,65536,13389,10280,1025,20497,13444,168,9428,86476,8328,64,31172,12756,17664,10401,8473,32,257,21793,25749,67278]

theorem envBound45642 : H12AffineFastState.Bounded env45642 := by
  intro p hp
  have h : env45642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45641_45642 : H12AffineEnvironment.transform 14 20496 env45641 = env45642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20496 env45641 == env45642) = true)

theorem identity45642 : scanCanonicalize (H12AffineFastState.compose env45642 (packedSelected [1,3,4,7,8,9,15,16,17,18,19,20,23,24,26,27,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound45642 : packedSelected [1,3,4,7,8,9,15,16,17,18,19,20,23,24,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env45643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12572,8460,65536,13389,10280,1025,8461,13444,168,9428,73936,8328,64,2264,12756,13340,10401,8473,32,257,9277,5513,67278]

theorem envBound45643 : H12AffineFastState.Bounded env45643 := by
  intro p hp
  have h : env45643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45642_45643 : H12AffineEnvironment.transform 13 12572 env45642 = env45643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env45642 == env45643) = true)

theorem identity45643 : scanCanonicalize (H12AffineFastState.compose env45643 (packedSelected [0,3,4,5,7,10,11,16,18,19,20,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound45643 : packedSelected [0,3,4,5,7,10,11,16,18,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env45644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12572,8460,251,13389,10280,1025,8461,13444,168,9428,8235,8328,64,2264,12756,13340,10401,8473,32,257,9277,5513,1589]

theorem envBound45644 : H12AffineFastState.Bounded env45644 := by
  intro p hp
  have h : env45644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45643_45644 : H12AffineEnvironment.transform 15 251 env45643 = env45644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env45643 == env45644) = true)

theorem identity45644 : scanCanonicalize (H12AffineFastState.compose env45644 (packedSelected [0,1,4,7,8,11,12,15,16,17,18,19,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound45644 : packedSelected [0,1,4,7,8,11,12,15,16,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env45645 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,8192,12572,8460,251,12677,10280,457,8461,12620,168,8476,8235,8328,64,2264,12756,12756,10401,8473,32,257,8693,4161,1021]

theorem envBound45645 : H12AffineFastState.Bounded env45645 := by
  intro p hp
  have h : env45645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45644_45645 : H12AffineEnvironment.transform 9 456 env45644 = env45645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env45644 == env45645) = true)

theorem identity45645 : scanCanonicalize (H12AffineFastState.compose env45645 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound45645 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env45646 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,240,4588,508,251,4469,2264,457,509,4540,168,492,219,120,64,2264,4388,4388,2129,489,32,257,261,4161,1021]

theorem envBound45646 : H12AffineFastState.Bounded env45646 := by
  intro p hp
  have h : env45646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45645_45646 : H12AffineEnvironment.transform 12 240 env45645 = env45646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env45645 == env45646) = true)

theorem identity45646 : scanCanonicalize (H12AffineFastState.compose env45646 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45646 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45647 : List Nat := [2,4,8,16,32,64,128,116,512,188,2048,4096,240,4248,136,251,4097,2264,189,137,4296,168,152,219,120,64,2264,4176,4176,2129,157,32,117,113,4161,649]

theorem envBound45647 : H12AffineFastState.Bounded env45647 := by
  intro p hp
  have h : env45647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45646_45647 : H12AffineEnvironment.transform 7 116 env45646 = env45647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45646 == env45647) = true)

theorem identity45647 : scanCanonicalize (H12AffineFastState.compose env45647 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound45647 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env45648 : List Nat := [2,4,8,16,32,64,128,116,512,188,2048,2113,240,2265,136,251,2112,2264,189,137,2185,168,152,219,120,64,2264,2065,2065,2129,157,32,117,113,2048,649]

theorem envBound45648 : H12AffineFastState.Bounded env45648 := by
  intro p hp
  have h : env45648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45647_45648 : H12AffineEnvironment.transform 11 2113 env45647 = env45648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env45647 == env45648) = true)

def env45649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10281,1025,32769,58516,169,62660,98780,8328,64,43476,57796,17664,10400,61705,33,257,21793,46213,120542]

theorem envBound45649 : H12AffineFastState.Bounded env45649 := by
  intro p hp
  have h : env45649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45640_45649 : H12AffineEnvironment.transform 17 10281 env45640 = env45649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env45640 == env45649) = true)

theorem identity45649 : scanCanonicalize (H12AffineFastState.compose env45649 (packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound45649 : packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env45650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,13389,10281,1025,32769,58516,169,62660,29790,8328,64,43476,57796,17664,10400,61705,33,257,21793,46213,9052]

theorem envBound45650 : H12AffineFastState.Bounded env45650 := by
  intro p hp
  have h : env45650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45649_45650 : H12AffineEnvironment.transform 15 62850 env45649 = env45650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env45649 == env45650) = true)

theorem identity45650 : scanCanonicalize (H12AffineFastState.compose env45650 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45650 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,54495,5392,2420,1025,32769,50633,169,54681,21763,469,64,34953,49305,17664,2557,53332,33,257,21793,38360,513]

theorem envBound45651 : H12AffineFastState.Bounded env45651 := by
  intro p hp
  have h : env45651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45650_45651 : H12AffineEnvironment.transform 12 349 env45650 = env45651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45650 == env45651) = true)

theorem identity45651 : scanCanonicalize (H12AffineFastState.compose env45651 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound45651 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env45652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5592,32768,33031,5392,2420,1025,32769,36881,169,32833,219,469,64,34953,38209,4312,2557,34188,33,257,249,38360,513]

theorem envBound45652 : H12AffineFastState.Bounded env45652 := by
  intro p hp
  have h : env45652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45651_45652 : H12AffineEnvironment.transform 13 5592 env45651 = env45652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env45651 == env45652) = true)

theorem identity45652 : scanCanonicalize (H12AffineFastState.compose env45652 (packedSelected [0,3,5,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound45652 : packedSelected [0,3,5,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5592,136,399,5392,2420,1025,137,4249,169,201,219,469,64,2049,5577,4312,2557,1284,33,257,249,5456,513]

theorem envBound45653 : H12AffineFastState.Bounded env45653 := by
  intro p hp
  have h : env45653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45652_45653 : H12AffineEnvironment.transform 14 136 env45652 = env45653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env45652 == env45653) = true)

theorem identity45653 : scanCanonicalize (H12AffineFastState.compose env45653 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45653 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45654 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,136,399,5392,2341,1025,137,4249,169,152,138,388,17,2049,5528,4233,2476,1284,33,257,168,5377,513]

theorem envBound45654 : H12AffineFastState.Bounded env45654 := by
  intro p hp
  have h : env45654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45653_45654 : H12AffineEnvironment.transform 5 17 env45653 = env45654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45653 == env45654) = true)

theorem identity45654 : scanCanonicalize (H12AffineFastState.compose env45654 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2707) := by decide +kernel

theorem selectedBound45654 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45655 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2707,268,3866,136,399,3971,2341,1025,137,2570,169,152,138,388,17,2049,3851,2586,2476,1284,33,257,168,3986,513]

theorem envBound45655 : H12AffineFastState.Bounded env45655 := by
  intro p hp
  have h : env45655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45654_45655 : H12AffineEnvironment.transform 11 2707 env45654 = env45655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2707 env45654 == env45655) = true)

theorem identity45655 : scanCanonicalize (H12AffineFastState.compose env45655 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45655 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env45656 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,2707,40,3646,136,171,3751,2049,1025,137,2570,169,152,138,160,17,2049,3631,2586,2184,1056,33,37,168,3766,513]

theorem envBound45656 : H12AffineFastState.Bounded env45656 := by
  intro p hp
  have h : env45656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45655_45656 : H12AffineEnvironment.transform 7 36 env45655 = env45656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45655 == env45656) = true)

theorem identity45656 : scanCanonicalize (H12AffineFastState.compose env45656 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound45656 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45657 : List Nat := [2,4,8,16,32,17,128,36,11,1024,2048,2200,40,3125,136,171,3244,2049,1025,137,2049,169,152,138,160,17,2049,3108,2065,2184,1056,33,37,168,3261,10]

theorem envBound45657 : H12AffineFastState.Bounded env45657 := by
  intro p hp
  have h : env45657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45656_45657 : H12AffineEnvironment.transform 8 11 env45656 = env45657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env45656 == env45657) = true)

theorem identity45657 : scanCanonicalize (H12AffineFastState.compose env45657 (packedSelected [1,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound45657 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env45658 : List Nat := [2,4,8,16,32,17,128,36,11,1024,136,16,40,1213,136,171,1060,137,1025,137,137,169,152,138,160,17,137,1196,153,0,1056,33,37,168,1077,10]

theorem envBound45658 : H12AffineFastState.Bounded env45658 := by
  intro p hp
  have h : env45658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45657_45658 : H12AffineEnvironment.transform 10 136 env45657 = env45658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env45657 == env45658) = true)

theorem identity45658 : scanCanonicalize (H12AffineFastState.compose env45658 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound45658 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env45659 : List Nat := [2,4,8,16,32,17,14,36,11,1024,6,16,40,1075,6,37,1060,7,1025,7,7,39,22,4,46,17,7,1058,23,0,1056,33,37,38,1077,10]

theorem envBound45659 : H12AffineFastState.Bounded env45659 := by
  intro p hp
  have h : env45659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45658_45659 : H12AffineEnvironment.transform 6 14 env45658 = env45659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env45658 == env45659) = true)

def env45660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180361,98780,8328,64,43477,185737,17664,262281,181572,400452,257,21793,46213,254611]

theorem envBound45660 : H12AffineFastState.Bounded env45660 := by
  intro p hp
  have h : env45660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45638_45660 : H12AffineEnvironment.transform 21 272513 env45638 = env45660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45638 == env45660) = true)

theorem identity45660 : scanCanonicalize (H12AffineFastState.compose env45660 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound45660 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140300,272513,144476,95497,8328,64,23808,139612,17664,262281,143761,400452,257,21793,16464,202310]

theorem envBound45661 : H12AffineFastState.Bounded env45661 := by
  intro p hp
  have h : env45661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45660_45661 : H12AffineEnvironment.transform 14 29909 env45660 = env45661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env45660 == env45661) = true)

def env45662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140300,272393,144476,95497,8192,64,23808,139612,17664,262145,143641,400452,257,21793,16464,202310]

theorem envBound45662 : H12AffineFastState.Bounded env45662 := by
  intro p hp
  have h : env45662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45661_45662 : H12AffineEnvironment.transform 6 8 env45661 = env45662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45661 == env45662) = true)

theorem identity45662 : scanCanonicalize (H12AffineFastState.compose env45662 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound45662 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env45663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,89378,1025,29788,140300,95531,144476,95497,8192,64,23808,139612,17664,89379,143641,213350,257,21793,16464,202310]

theorem envBound45663 : H12AffineFastState.Bounded env45663 := by
  intro p hp
  have h : env45663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45662_45663 : H12AffineEnvironment.transform 17 89378 env45662 = env45663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env45662 == env45663) = true)

theorem identity45663 : scanCanonicalize (H12AffineFastState.compose env45663 (packedSelected [0,3,4,5,10,12,14,15,17,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound45663 : packedSelected [0,3,4,5,10,12,14,15,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env45664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21874,131072,2128,1025,29788,140300,8281,144476,8315,8192,64,23808,139612,17664,2129,143641,136212,257,21793,16464,148276]

theorem envBound45664 : H12AffineFastState.Bounded env45664 := by
  intro p hp
  have h : env45664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45663_45664 : H12AffineEnvironment.transform 15 21874 env45663 = env45664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env45663 == env45664) = true)

theorem identity45664 : scanCanonicalize (H12AffineFastState.compose env45664 (packedSelected [0,4,5,7,12,15,16,17,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound45664 : packedSelected [0,4,5,7,12,15,16,17,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,372,8283,131072,2128,1025,373,140300,8281,144476,8315,8192,64,10281,139612,12329,2129,143641,136212,257,8200,13689,144925]

theorem envBound45665 : H12AffineFastState.Bounded env45665 := by
  intro p hp
  have h : env45665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45664_45665 : H12AffineEnvironment.transform 13 13609 env45664 = env45665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env45664 == env45665) = true)

theorem identity45665 : scanCanonicalize (H12AffineFastState.compose env45665 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45665 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45666 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,0,8283,131072,2128,1025,1,140300,8281,144476,8315,8192,64,10281,139304,12329,2129,143469,136212,117,8200,13325,144925]

theorem envBound45666 : H12AffineFastState.Bounded env45666 := by
  intro p hp
  have h : env45666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45665_45666 : H12AffineEnvironment.transform 7 116 env45665 = env45666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45665 == env45666) = true)

theorem identity45666 : scanCanonicalize (H12AffineFastState.compose env45666 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound45666 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env45667 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5156,0,34,131072,2128,1025,1,132213,32,136229,2,121,64,2128,131153,4176,2129,135188,136212,117,113,5236,136804]

theorem envBound45667 : H12AffineFastState.Bounded env45667 := by
  intro p hp
  have h : env45667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45666_45667 : H12AffineEnvironment.transform 12 121 env45666 = env45667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env45666 == env45667) = true)

theorem identity45667 : scanCanonicalize (H12AffineFastState.compose env45667 (packedSelected [12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound45667 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env45668 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5156,0,34,5173,2128,1025,1,4160,32,16,2,121,64,2128,5220,4176,2129,1057,33,117,113,5236,593]

theorem envBound45668 : H12AffineFastState.Bounded env45668 := by
  intro p hp
  have h : env45668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45667_45668 : H12AffineEnvironment.transform 16 5173 env45667 = env45668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env45667 == env45668) = true)

theorem identity45668 : scanCanonicalize (H12AffineFastState.compose env45668 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound45668 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env45669 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3103,121,2107,0,34,2090,2128,1025,1,3167,32,16,2,121,64,2128,2171,3151,2129,1057,33,117,113,2155,593]

theorem envBound45669 : H12AffineFastState.Bounded env45669 := by
  intro p hp
  have h : env45669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45668_45669 : H12AffineEnvironment.transform 11 3103 env45668 = env45669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env45668 == env45669) = true)

theorem identity45669 : scanCanonicalize (H12AffineFastState.compose env45669 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound45669 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45670 : List Nat := [2,4,8,16,32,49,8,5,512,1024,2048,3103,8,2107,0,34,2090,2081,1025,1,3118,32,16,2,8,49,2081,2058,3134,2080,1057,33,4,0,2074,544]

theorem envBound45670 : H12AffineFastState.Bounded env45670 := by
  intro p hp
  have h : env45670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45669_45670 : H12AffineEnvironment.transform 5 49 env45669 = env45670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env45669 == env45670) = true)

theorem identity45670 : scanCanonicalize (H12AffineFastState.compose env45670 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45670 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45671 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,3103,8,2075,0,2,2058,2049,1025,1,3086,0,16,2,8,17,2049,2058,3102,2048,1025,1,4,0,2074,512]

theorem envBound45671 : H12AffineFastState.Bounded env45671 := by
  intro p hp
  have h : env45671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45670_45671 : H12AffineEnvironment.transform 4 0 env45670 = env45671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45670 == env45671) = true)

theorem identity45671 : scanCanonicalize (H12AffineFastState.compose env45671 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound45671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45672 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1054,1,8,1029,0,2,1044,1055,1025,1,16,0,16,2,8,17,1055,1044,0,1054,1025,1,4,0,1028,512]

theorem envBound45672 : H12AffineFastState.Bounded env45672 := by
  intro p hp
  have h : env45672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45671_45672 : H12AffineEnvironment.transform 10 1054 env45671 = env45672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env45671 == env45672) = true)

theorem identity45672 : scanCanonicalize (H12AffineFastState.compose env45672 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound45672 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45673 : List Nat := [2,4,8,16,0,17,8,5,512,21,11,1,8,16,0,2,1,10,20,1,16,0,16,2,8,17,10,1,0,11,20,1,4,0,17,512]

theorem envBound45673 : H12AffineFastState.Bounded env45673 := by
  intro p hp
  have h : env45673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45672_45673 : H12AffineEnvironment.transform 9 21 env45672 = env45673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45672 == env45673) = true)

theorem identity45673 : scanCanonicalize (H12AffineFastState.compose env45673 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound45673 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45674 : List Nat := [2,4,7,16,0,17,7,5,512,21,4,1,7,16,0,2,1,5,20,1,16,0,16,2,7,17,5,1,0,4,20,1,4,0,17,512]

theorem envBound45674 : H12AffineFastState.Bounded env45674 := by
  intro p hp
  have h : env45674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45673_45674 : H12AffineEnvironment.transform 2 7 env45673 = env45674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env45673 == env45674) = true)

theorem identity45674 : scanCanonicalize (H12AffineFastState.compose env45674 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45674 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45675 : List Nat := [2,4,7,6,0,7,7,5,512,3,4,1,7,6,0,2,1,5,2,1,6,0,6,2,7,7,5,1,0,4,2,1,4,0,7,512]

theorem envBound45675 : H12AffineFastState.Bounded env45675 := by
  intro p hp
  have h : env45675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45674_45675 : H12AffineEnvironment.transform 3 6 env45674 = env45675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45674 == env45675) = true)

def env45676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140300,272392,144476,95497,8193,64,23808,139612,17664,262144,143640,400452,257,21793,16464,202310]

theorem envBound45676 : H12AffineFastState.Bounded env45676 := by
  intro p hp
  have h : env45676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45661_45676 : H12AffineEnvironment.transform 6 9 env45661 = env45676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45661 == env45676) = true)

theorem identity45676 : scanCanonicalize (H12AffineFastState.compose env45676 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound45676 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env45677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,23668,1025,29789,140300,29820,144476,95497,8193,64,23808,139612,17664,23668,143640,147504,257,21793,16464,202310]

theorem envBound45677 : H12AffineFastState.Bounded env45677 := by
  intro p hp
  have h : env45677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45676_45677 : H12AffineEnvironment.transform 17 23668 env45676 = env45677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env45676 == env45677) = true)

theorem identity45677 : scanCanonicalize (H12AffineFastState.compose env45677 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound45677 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env45678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,16400,23668,1025,29789,25628,29820,29772,95497,8193,64,23808,24908,17664,23668,28936,32,257,21793,16464,87638]

theorem envBound45678 : H12AffineFastState.Bounded env45678 := by
  intro p hp
  have h : env45678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45677_45678 : H12AffineEnvironment.transform 16 16400 env45677 = env45678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env45677 == env45678) = true)

theorem identity45678 : scanCanonicalize (H12AffineFastState.compose env45678 (packedSelected [0,1,5,7,9,10,12,14,15,16,18,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound45678 : packedSelected [0,1,5,7,9,10,12,14,15,16,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env45679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,30043,16400,23668,1025,29789,25628,29820,29772,82,8193,64,23808,24908,17664,23668,28936,32,257,21793,16464,8973]

theorem envBound45679 : H12AffineFastState.Bounded env45679 := by
  intro p hp
  have h : env45679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45678_45679 : H12AffineEnvironment.transform 15 30043 env45678 = env45679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env45678 == env45679) = true)

theorem identity45679 : scanCanonicalize (H12AffineFastState.compose env45679 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45679 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45680 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,29962,16400,23589,1025,29708,25628,29741,29725,3,8193,17,23808,24861,17664,23589,28936,32,257,21793,16385,8973]

theorem envBound45680 : H12AffineFastState.Bounded env45680 := by
  intro p hp
  have h : env45680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45679_45680 : H12AffineEnvironment.transform 5 17 env45679 = env45680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45679 == env45680) = true)

theorem identity45680 : scanCanonicalize (H12AffineFastState.compose env45680 (packedSelected [0,1,3,4,5,7,8,9,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45680 : packedSelected [0,1,3,4,5,7,8,9,12,14,18] rootPS < 2^1333 := by decide +kernel

def env45681 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21760,21511,16400,23589,1025,21761,17681,21792,21776,3,268,17,23808,16400,17664,23589,20485,32,257,21793,16385,512]

theorem envBound45681 : H12AffineFastState.Bounded env45681 := by
  intro p hp
  have h : env45681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45680_45681 : H12AffineEnvironment.transform 12 269 env45680 = env45681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45680 == env45681) = true)

theorem identity45681 : scanCanonicalize (H12AffineFastState.compose env45681 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 2080) := by decide +kernel

theorem selectedBound45681 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env45682 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,2080,7456,7207,2096,5125,1025,7457,3377,7424,7472,3,268,17,5408,2096,3360,5125,6181,32,257,7425,2081,512]

theorem envBound45682 : H12AffineFastState.Bounded env45682 := by
  intro p hp
  have h : env45682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45681_45682 : H12AffineEnvironment.transform 13 2080 env45681 = env45682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2080 env45681 == env45682) = true)

theorem identity45682 : scanCanonicalize (H12AffineFastState.compose env45682 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45682 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45683 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,2049,7425,7174,2065,5125,1025,7424,3344,7424,7441,3,268,17,5377,2065,3329,5125,6148,1,257,7425,2048,512]

theorem envBound45683 : H12AffineFastState.Bounded env45683 := by
  intro p hp
  have h : env45683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45682_45683 : H12AffineEnvironment.transform 4 1 env45682 = env45683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45682 == env45683) = true)

theorem identity45683 : scanCanonicalize (H12AffineFastState.compose env45683 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound45683 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45684 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,3076,269,2049,261,2,2065,2049,1025,260,3344,260,277,3,268,17,2309,2065,3329,2049,1024,1,257,261,2048,512]

theorem envBound45684 : H12AffineFastState.Bounded env45684 := by
  intro p hp
  have h : env45684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45683_45684 : H12AffineEnvironment.transform 11 3076 env45683 = env45684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env45683 == env45684) = true)

theorem identity45684 : scanCanonicalize (H12AffineFastState.compose env45684 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45684 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env45685 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,3076,8,2049,0,2,2065,2049,1025,1,3093,1,16,3,9,17,2048,2065,3076,2049,1024,1,4,0,2048,512]

theorem envBound45685 : H12AffineFastState.Bounded env45685 := by
  intro p hp
  have h : env45685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45684_45685 : H12AffineEnvironment.transform 7 5 env45684 = env45685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45684 == env45685) = true)

theorem identity45685 : scanCanonicalize (H12AffineFastState.compose env45685 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound45685 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45686 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2065,8,2049,0,2,2065,2049,20,1,2048,1,16,3,9,17,2048,2065,2065,2049,21,1,4,0,2048,512]

theorem envBound45686 : H12AffineFastState.Bounded env45686 := by
  intro p hp
  have h : env45686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45685_45686 : H12AffineEnvironment.transform 9 21 env45685 = env45686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45685 == env45686) = true)

def env45687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356288,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound45687 : H12AffineFastState.Bounded env45687 := by
  intro p hp
  have h : env45687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45408_45687 : H12AffineEnvironment.transform 26 30393345 env45408 = env45687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env45408 == env45687) = true)

def env45688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound45688 : H12AffineFastState.Bounded env45688 := by
  intro p hp
  have h : env45688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45687_45688 : H12AffineEnvironment.transform 18 1024 env45687 = env45688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env45687 == env45688) = true)

theorem identity45688 : scanCanonicalize (H12AffineFastState.compose env45688 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2212885) := by decide +kernel

theorem selectedBound45688 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2212885,8328,64,15074324,16536,10507600,8830976,10502148,4235732,256,8388792,8446236,10577874]

theorem envBound45689 : H12AffineFastState.Bounded env45689 := by
  intro p hp
  have h : env45689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45688_45689 : H12AffineEnvironment.transform 23 2212885 env45688 = env45689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212885 env45688 == env45689) = true)

def env45690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21912,2212885,8328,64,6705548,16536,2097352,431512,2102684,4235732,256,21792,46212,2175562]

theorem envBound45690 : H12AffineFastState.Bounded env45690 := by
  intro p hp
  have h : env45690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45689_45690 : H12AffineEnvironment.transform 22 21912 env45689 = env45690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21912 env45689 == env45690) = true)

def env45691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,4194304,21912,98645,8328,64,4592844,16536,17800,431512,20700,4235732,256,21792,46212,96010]

theorem envBound45691 : H12AffineFastState.Bounded env45691 := by
  intro p hp
  have h : env45691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45690_45691 : H12AffineEnvironment.transform 20 17728 env45690 = env45691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env45690 == env45691) = true)

def env45692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21912,98645,8328,64,410092,16536,17800,431512,20700,62708,256,21792,46212,96010]

theorem envBound45692 : H12AffineFastState.Bounded env45692 := by
  intro p hp
  have h : env45692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45691_45692 : H12AffineEnvironment.transform 21 21792 env45691 = env45692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env45691 == env45692) = true)

def env45693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21776,98645,8192,64,409956,16400,17664,431376,20564,62588,256,21792,46092,96010]

theorem envBound45693 : H12AffineFastState.Bounded env45693 := by
  intro p hp
  have h : env45693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45692_45693 : H12AffineEnvironment.transform 6 8 env45692 = env45693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45692 == env45693) = true)

def env45694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98645,8192,64,398436,5392,4096,431376,1364,41340,256,32,46092,74250]

theorem envBound45694 : H12AffineFastState.Bounded env45694 := by
  intro p hp
  have h : env45694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45693_45694 : H12AffineEnvironment.transform 13 5376 env45693 = env45694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45693 == env45694) = true)

theorem identity45694 : scanCanonicalize (H12AffineFastState.compose env45694 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45694 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45695 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,32,16,73737,8192,64,398436,5392,4096,406604,1364,32,256,32,5456,74250]

theorem envBound45695 : H12AffineFastState.Bounded env45695 := by
  intro p hp
  have h : env45695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45694_45695 : H12AffineEnvironment.transform 14 8540 env45694 = env45695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45694 == env45695) = true)

theorem identity45695 : scanCanonicalize (H12AffineFastState.compose env45695 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound45695 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45696 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67699,1024,8541,4160,32,16,73737,8192,64,203799,5392,4096,212031,1364,32,256,32,5456,74250]

theorem envBound45696 : H12AffineFastState.Bounded env45696 := by
  intro p hp
  have h : env45696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45695_45696 : H12AffineEnvironment.transform 17 67699 env45695 = env45696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env45695 == env45696) = true)

theorem identity45696 : scanCanonicalize (H12AffineFastState.compose env45696 (packedSelected [4,5,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound45696 : packedSelected [4,5,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env45697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8575,131072,10508,1024,8541,4160,32,16,374,8192,64,146792,5392,4096,138560,1364,32,256,32,5456,885]

theorem envBound45697 : H12AffineFastState.Bounded env45697 := by
  intro p hp
  have h : env45697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45696_45697 : H12AffineEnvironment.transform 15 8575 env45696 = env45697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env45696 == env45697) = true)

theorem identity45697 : scanCanonicalize (H12AffineFastState.compose env45697 (packedSelected [1,8,9,11,14,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 15720) := by decide +kernel

theorem selectedBound45697 : packedSelected [1,8,9,11,14,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env45698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8575,15720,10508,1024,8541,4160,32,16,374,8192,64,0,5392,4096,8232,1364,32,256,32,5456,885]

theorem envBound45698 : H12AffineFastState.Bounded env45698 := by
  intro p hp
  have h : env45698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45697_45698 : H12AffineEnvironment.transform 16 15720 env45697 = env45698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 15720 env45697 == env45698) = true)

theorem identity45698 : scanCanonicalize (H12AffineFastState.compose env45698 (packedSelected [0,1,8,11,14,16,19,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45698 : packedSelected [0,1,8,11,14,16,19,20,27] rootPS < 2^1333 := by decide +kernel

def env45699 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8495,15672,10508,1024,8461,4112,32,16,294,8192,16,0,5392,4096,8232,1284,32,256,32,5376,805]

theorem envBound45699 : H12AffineFastState.Bounded env45699 := by
  intro p hp
  have h : env45699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45698_45699 : H12AffineEnvironment.transform 5 16 env45698 = env45699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45698 == env45699) = true)

theorem identity45699 : scanCanonicalize (H12AffineFastState.compose env45699 (packedSelected [1,2,3,4,5,8,9,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45699 : packedSelected [1,2,3,4,5,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env45700 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5156,8232,8203,15388,10280,1024,8233,4112,32,16,2,8192,16,0,5172,4096,8232,1056,32,36,32,5156,513]

theorem envBound45700 : H12AffineFastState.Bounded env45700 := by
  intro p hp
  have h : env45700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45699_45700 : H12AffineEnvironment.transform 7 36 env45699 = env45700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45699 == env45700) = true)

def env45701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,17,98645,8192,64,398437,5393,4097,431376,1365,41341,256,33,46092,74251]

theorem envBound45701 : H12AffineFastState.Bounded env45701 := by
  intro p hp
  have h : env45701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45693_45701 : H12AffineEnvironment.transform 13 5377 env45693 = env45701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45693 == env45701) = true)

theorem identity45701 : scanCanonicalize (H12AffineFastState.compose env45701 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound45701 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1024,32769,4161,33,17,98645,8192,64,171281,5393,4097,138340,1365,41341,256,33,46092,74251]

theorem envBound45702 : H12AffineFastState.Bounded env45702 := by
  intro p hp
  have h : env45702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45701_45702 : H12AffineEnvironment.transform 17 35188 env45701 = env45702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env45701 == env45702) = true)

theorem identity45702 : scanCanonicalize (H12AffineFastState.compose env45702 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound45702 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,35188,1024,32769,4161,33,17,98645,8192,64,34816,5393,4097,2421,1365,41341,256,33,46092,74251]

theorem envBound45703 : H12AffineFastState.Bounded env45703 := by
  intro p hp
  have h : env45703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45702_45703 : H12AffineEnvironment.transform 16 5393 env45702 = env45703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env45702 == env45703) = true)

theorem identity45703 : scanCanonicalize (H12AffineFastState.compose env45703 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound45703 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,5393,35188,1024,32769,4161,33,17,41310,8192,64,34816,5393,4097,2421,1365,41341,256,33,46092,512]

theorem envBound45704 : H12AffineFastState.Bounded env45704 := by
  intro p hp
  have h : env45704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45703_45704 : H12AffineEnvironment.transform 15 8203 env45703 = env45704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env45703 == env45704) = true)

theorem identity45704 : scanCanonicalize (H12AffineFastState.compose env45704 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound45704 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45705 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8200,8203,5393,10620,1024,8201,4161,33,17,342,8192,64,10248,5393,4097,2421,1365,373,256,33,5124,512]

theorem envBound45705 : H12AffineFastState.Bounded env45705 := by
  intro p hp
  have h : env45705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45704_45705 : H12AffineEnvironment.transform 14 8200 env45704 = env45705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env45704 == env45705) = true)

theorem identity45705 : scanCanonicalize (H12AffineFastState.compose env45705 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45705 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env45706 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8200,8203,5220,10249,1024,8201,4161,33,17,35,8192,64,10248,5220,4097,2048,1056,0,117,33,5124,512]

theorem envBound45706 : H12AffineFastState.Bounded env45706 := by
  intro p hp
  have h : env45706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45705_45706 : H12AffineEnvironment.transform 7 117 env45705 = env45706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45705 == env45706) = true)

theorem identity45706 : scanCanonicalize (H12AffineFastState.compose env45706 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2171) := by decide +kernel

theorem selectedBound45706 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45707 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2171,8192,3087,8200,8203,3103,10249,1024,8201,2106,33,17,35,8192,64,10248,3103,2170,2048,1056,0,117,33,3199,512]

theorem envBound45707 : H12AffineFastState.Bounded env45707 := by
  intro p hp
  have h : env45707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45706_45707 : H12AffineEnvironment.transform 11 2171 env45706 = env45707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2171 env45706 == env45707) = true)

theorem identity45707 : scanCanonicalize (H12AffineFastState.compose env45707 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound45707 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45708 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2171,121,3087,113,114,3103,2160,1024,112,2106,33,17,35,121,64,2161,3103,2170,2048,1056,0,117,33,3199,512]

theorem envBound45708 : H12AffineFastState.Bounded env45708 := by
  intro p hp
  have h : env45708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45707_45708 : H12AffineEnvironment.transform 12 121 env45707 = env45708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env45707 == env45708) = true)

theorem identity45708 : scanCanonicalize (H12AffineFastState.compose env45708 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound45708 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env45709 : List Nat := [2,4,8,16,32,26,8,47,512,1024,2048,2081,35,3087,43,40,3103,2090,1024,42,2106,33,17,35,35,26,2091,3103,2080,2048,1056,0,47,33,3109,512]

theorem envBound45709 : H12AffineFastState.Bounded env45709 := by
  intro p hp
  have h : env45709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45708_45709 : H12AffineEnvironment.transform 5 26 env45708 = env45709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env45708 == env45709) = true)

theorem identity45709 : scanCanonicalize (H12AffineFastState.compose env45709 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45709 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env45710 : List Nat := [2,4,8,16,1,26,8,14,512,1024,2048,2048,2,3087,10,9,3103,2059,1024,11,2075,0,17,2,2,26,2058,3103,2049,2048,1025,0,14,0,3076,512]

theorem envBound45710 : H12AffineFastState.Bounded env45710 := by
  intro p hp
  have h : env45710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45709_45710 : H12AffineEnvironment.transform 4 1 env45709 = env45710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45709 == env45710) = true)

theorem identity45710 : scanCanonicalize (H12AffineFastState.compose env45710 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound45710 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45711 : List Nat := [2,4,8,16,1,26,8,14,512,21,2048,2048,2,2074,10,9,2058,2059,21,11,2075,0,17,2,2,26,2058,2058,2049,2048,20,0,14,0,2065,512]

theorem envBound45711 : H12AffineFastState.Bounded env45711 := by
  intro p hp
  have h : env45711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45710_45711 : H12AffineEnvironment.transform 9 21 env45710 = env45711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45710 == env45711) = true)

theorem identity45711 : scanCanonicalize (H12AffineFastState.compose env45711 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound45711 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45712 : List Nat := [2,4,8,16,1,26,8,14,14,21,2048,2048,2,2074,10,9,2058,2059,21,11,2075,0,17,2,2,26,2058,2058,2049,2048,20,0,14,0,2065,14]

theorem envBound45712 : H12AffineFastState.Bounded env45712 := by
  intro p hp
  have h : env45712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45711_45712 : H12AffineEnvironment.transform 8 14 env45711 = env45712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env45711 == env45712) = true)

theorem identity45712 : scanCanonicalize (H12AffineFastState.compose env45712 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45712 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45713 : List Nat := [2,4,8,11,1,1,8,14,14,14,2048,2048,2,2049,10,9,2058,2059,14,11,2048,0,10,2,2,1,2058,2058,2049,2048,15,0,14,0,2058,14]

theorem envBound45713 : H12AffineFastState.Bounded env45713 := by
  intro p hp
  have h : env45713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45712_45713 : H12AffineEnvironment.transform 3 11 env45712 = env45713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45712 == env45713) = true)

theorem identity45713 : scanCanonicalize (H12AffineFastState.compose env45713 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound45713 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45714 : List Nat := [2,0,8,11,1,1,8,10,10,10,2048,2048,2,2049,10,9,2058,2059,10,11,2048,0,10,2,2,1,2058,2058,2049,2048,11,0,10,0,2058,10]

theorem envBound45714 : H12AffineFastState.Bounded env45714 := by
  intro p hp
  have h : env45714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45713_45714 : H12AffineEnvironment.transform 1 0 env45713 = env45714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45713 == env45714) = true)

theorem identity45714 : scanCanonicalize (H12AffineFastState.compose env45714 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound45714 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45715 : List Nat := [2,0,1,2,1,1,1,3,3,3,2048,2048,2,2049,3,0,2051,2050,3,2,2048,0,3,2,2,1,2051,2051,2049,2048,2,0,3,0,2051,3]

theorem envBound45715 : H12AffineFastState.Bounded env45715 := by
  intro p hp
  have h : env45715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45714_45715 : H12AffineEnvironment.transform 2 1 env45714 = env45715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env45714 == env45715) = true)

theorem identity45715 : scanCanonicalize (H12AffineFastState.compose env45715 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45715 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45716 : List Nat := [2,0,1,2,1,1,1,3,3,3,1,1,2,0,3,0,2,3,3,2,1,0,3,2,2,1,2,2,0,1,2,0,3,0,2,3]

theorem envBound45716 : H12AffineFastState.Bounded env45716 := by
  intro p hp
  have h : env45716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45715_45716 : H12AffineEnvironment.transform 10 1 env45715 = env45716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45715 == env45716) = true)

theorem identity45716 : scanCanonicalize (H12AffineFastState.compose env45716 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45716 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45717 : List Nat := [0,0,1,0,1,1,1,1,1,1,1,1,0,0,1,0,0,1,1,0,1,0,1,0,0,1,0,0,0,1,0,0,1,0,0,1]

theorem envBound45717 : H12AffineFastState.Bounded env45717 := by
  intro p hp
  have h : env45717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45716_45717 : H12AffineEnvironment.transform 0 0 env45716 = env45717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45716 == env45717) = true)

def env45718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21777,98645,8193,64,409957,16401,17665,431377,20565,62589,256,21792,46093,96010]

theorem envBound45718 : H12AffineFastState.Bounded env45718 := by
  intro p hp
  have h : env45718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45692_45718 : H12AffineEnvironment.transform 6 9 env45692 = env45718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45692 == env45718) = true)

def env45719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,17,98645,8193,64,398437,5393,4097,431377,1365,41341,256,32,46093,74250]

theorem envBound45719 : H12AffineFastState.Bounded env45719 := by
  intro p hp
  have h : env45719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45718_45719 : H12AffineEnvironment.transform 13 5376 env45718 = env45719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45718 == env45719) = true)

theorem identity45719 : scanCanonicalize (H12AffineFastState.compose env45719 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound45719 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4160,32,17,98645,8193,64,146508,5393,4097,179512,1365,41341,256,32,46093,74250]

theorem envBound45720 : H12AffineFastState.Bounded env45720 := by
  intro p hp
  have h : env45720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45719_45720 : H12AffineEnvironment.transform 17 10281 env45719 = env45720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env45719 == env45720) = true)

def env45721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,16,98645,8193,64,398436,5392,4096,431377,1364,41340,256,33,46093,74251]

theorem envBound45721 : H12AffineFastState.Bounded env45721 := by
  intro p hp
  have h : env45721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45718_45721 : H12AffineEnvironment.transform 13 5377 env45718 = env45721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45718 == env45721) = true)

theorem identity45721 : scanCanonicalize (H12AffineFastState.compose env45721 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45721 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env45722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41311,8193,64,398436,5392,4096,431377,1364,41340,256,33,46093,513]

theorem envBound45722 : H12AffineFastState.Bounded env45722 := by
  intro p hp
  have h : env45722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45721_45722 : H12AffineEnvironment.transform 15 8202 env45721 = env45722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45721 == env45722) = true)

theorem identity45722 : scanCanonicalize (H12AffineFastState.compose env45722 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45722 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env45723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,33,16,3,8193,64,398436,5392,4096,406605,1364,32,256,33,5457,513]

theorem envBound45723 : H12AffineFastState.Bounded env45723 := by
  intro p hp
  have h : env45723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45722_45723 : H12AffineEnvironment.transform 14 8540 env45722 = env45723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45722 == env45723) = true)

theorem identity45723 : scanCanonicalize (H12AffineFastState.compose env45723 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45723 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45724 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,262144,1024,8461,4113,33,16,3,8193,16,398388,5392,4096,406557,1284,32,256,33,5377,513]

theorem envBound45724 : H12AffineFastState.Bounded env45724 := by
  intro p hp
  have h : env45724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45723_45724 : H12AffineEnvironment.transform 5 16 env45723 = env45724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45723 == env45724) = true)

theorem identity45724 : scanCanonicalize (H12AffineFastState.compose env45724 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound45724 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45725 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,138292,1024,8461,4113,33,16,3,8193,16,2048,5392,4096,10281,1284,32,256,33,5377,513]

theorem envBound45725 : H12AffineFastState.Bounded env45725 := by
  intro p hp
  have h : env45725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45724_45725 : H12AffineEnvironment.transform 17 138292 env45724 = env45725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env45724 == env45725) = true)

theorem identity45725 : scanCanonicalize (H12AffineFastState.compose env45725 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound45725 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env45726 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,13341,10281,1024,8461,4113,33,16,3,8193,16,2048,5392,4096,10281,1284,32,256,33,5377,513]

theorem envBound45726 : H12AffineFastState.Bounded env45726 := by
  intro p hp
  have h : env45726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45725_45726 : H12AffineEnvironment.transform 16 13341 env45725 = env45726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env45725 == env45726) = true)

theorem identity45726 : scanCanonicalize (H12AffineFastState.compose env45726 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45726 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env45727 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5392,2340,1024,0,4113,33,16,3,268,16,2048,5392,4096,2340,1284,32,256,33,5377,513]

theorem envBound45727 : H12AffineFastState.Bounded env45727 := by
  intro p hp
  have h : env45727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45726_45727 : H12AffineEnvironment.transform 12 269 env45726 = env45727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45726 == env45727) = true)

theorem identity45727 : scanCanonicalize (H12AffineFastState.compose env45727 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45727 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45728 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5173,2049,1024,0,4113,33,16,3,41,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound45728 : H12AffineFastState.Bounded env45728 := by
  intro p hp
  have h : env45728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45727_45728 : H12AffineEnvironment.transform 7 37 env45727 = env45728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45727 == env45728) = true)

def env45729 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1044,1,34,1029,2049,1024,0,33,33,16,3,41,16,2048,1029,48,2049,1057,32,37,33,1044,513]

theorem envBound45729 : H12AffineFastState.Bounded env45729 := by
  intro p hp
  have h : env45729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45728_45729 : H12AffineEnvironment.transform 11 48 env45728 = env45729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45728 == env45729) = true)

def env45730 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1045,1,34,1028,2049,1024,0,32,33,16,3,41,16,2048,1028,49,2049,1057,32,37,33,1045,513]

theorem envBound45730 : H12AffineFastState.Bounded env45730 := by
  intro p hp
  have h : env45730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45728_45730 : H12AffineEnvironment.transform 11 49 env45728 = env45730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45728 == env45730) = true)

theorem identity45730 : scanCanonicalize (H12AffineFastState.compose env45730 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45731 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,49,40,32,1,34,49,2049,53,0,32,33,16,3,41,16,2048,49,49,2049,20,32,37,33,32,513]

theorem envBound45731 : H12AffineFastState.Bounded env45731 := by
  intro p hp
  have h : env45731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45730_45731 : H12AffineEnvironment.transform 9 53 env45730 = env45731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45730 == env45731) = true)

theorem identity45731 : scanCanonicalize (H12AffineFastState.compose env45731 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45731 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45732 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,9,1,1,3,16,2049,20,0,1,0,16,3,8,16,2048,16,16,2049,20,1,4,0,1,513]

theorem envBound45732 : H12AffineFastState.Bounded env45732 := by
  intro p hp
  have h : env45732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45731_45732 : H12AffineEnvironment.transform 4 1 env45731 = env45732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45731 == env45732) = true)

def leafEnv45732 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,9,1,1,3,16,2049,20,0,1,0,16,3,20,8,1,16,2048,16,16,2049,20,1,4,0,4,2,1,513,1,1,0]

def active45732 : List Nat := [0,1,2,3,8,10]

def tree45732 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45732 : H12WitnessSearch.Good tree45732 := H12GlobalWitnessIndex.good

theorem leafIdentity45732 : H12AffineFastState.composeSystem env45732 rootObs = leafEnv45732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45732 rootObs == leafEnv45732) = true)

theorem terminalChecked45732 : H12PackedTerminal.terminalCheckFast leafEnv45732 active45732 tree45732 = true := by decide +kernel

def env45733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,21912,98645,8328,64,410093,16536,17800,431512,20700,62709,256,21792,46212,96010]

theorem envBound45733 : H12AffineFastState.Bounded env45733 := by
  intro p hp
  have h : env45733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45691_45733 : H12AffineEnvironment.transform 21 21793 env45691 = env45733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env45691 == env45733) = true)

theorem identity45733 : scanCanonicalize (H12AffineFastState.compose env45733 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound45733 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,4296,169,16,98645,8328,64,398437,5392,4096,431512,1364,41341,256,168,46212,74370]

theorem envBound45734 : H12AffineFastState.Bounded env45734 := by
  intro p hp
  have h : env45734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45733_45734 : H12AffineEnvironment.transform 13 5512 env45733 = env45734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env45733 == env45734) = true)

def env45735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98645,8192,64,398437,5392,4096,431376,1364,41341,256,32,46092,74250]

theorem envBound45735 : H12AffineFastState.Bounded env45735 := by
  intro p hp
  have h : env45735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45734_45735 : H12AffineEnvironment.transform 6 8 env45734 = env45735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45734 == env45735) = true)

theorem identity45735 : scanCanonicalize (H12AffineFastState.compose env45735 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45735 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,33,16,73737,8192,64,398437,5392,4096,406604,1364,33,256,32,5456,74250]

theorem envBound45736 : H12AffineFastState.Bounded env45736 := by
  intro p hp
  have h : env45736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45735_45736 : H12AffineEnvironment.transform 14 8540 env45735 = env45736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45735 == env45736) = true)

theorem identity45736 : scanCanonicalize (H12AffineFastState.compose env45736 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 212030) := by decide +kernel

theorem selectedBound45736 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,131072,212030,1024,8541,4160,33,16,73737,8192,64,75867,5392,4096,67698,1364,33,256,32,5456,74250]

theorem envBound45737 : H12AffineFastState.Bounded env45737 := by
  intro p hp
  have h : env45737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45736_45737 : H12AffineEnvironment.transform 17 212030 env45736 = env45737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212030 env45736 == env45737) = true)

theorem identity45737 : scanCanonicalize (H12AffineFastState.compose env45737 (packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound45737 : packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env45738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,372,65536,131072,203798,1024,373,4160,33,16,65569,40,64,67699,5392,4096,67698,1364,33,256,32,5456,66082]

theorem envBound45738 : H12AffineFastState.Bounded env45738 := by
  intro p hp
  have h : env45738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45737_45738 : H12AffineEnvironment.transform 12 40 env45737 = env45738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env45737 == env45738) = true)

theorem identity45738 : scanCanonicalize (H12AffineFastState.compose env45738 (packedSelected [9,11,14,15,22] rootPS)) = affineNative (2^(16+1) ^^^ 69975) := by decide +kernel

theorem selectedBound45738 : packedSelected [9,11,14,15,22] rootPS < 2^1333 := by decide +kernel

def env45739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,372,65536,69975,3393,1024,373,4160,33,16,65569,40,64,67699,5392,4096,67698,1364,33,256,32,5456,66082]

theorem envBound45739 : H12AffineFastState.Bounded env45739 := by
  intro p hp
  have h : env45739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45738_45739 : H12AffineEnvironment.transform 16 69975 env45738 = env45739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69975 env45738 == env45739) = true)

theorem identity45739 : scanCanonicalize (H12AffineFastState.compose env45739 (packedSelected [0,4,7,9,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45739 : packedSelected [0,4,7,9,11,14] rootPS < 2^1333 := by decide +kernel

def env45740 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4112,372,65536,69975,2129,272,373,4160,33,16,65569,40,64,67699,4096,4096,67698,68,33,256,32,4160,66082]

theorem envBound45740 : H12AffineFastState.Bounded env45740 := by
  intro p hp
  have h : env45740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45739_45740 : H12AffineEnvironment.transform 9 272 env45739 = env45740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45739 == env45740) = true)

theorem identity45740 : scanCanonicalize (H12AffineFastState.compose env45740 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound45740 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45741 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4112,372,114,4389,2129,272,373,4160,33,16,83,40,64,2049,4096,4096,2048,68,33,256,32,4160,592]

theorem envBound45741 : H12AffineFastState.Bounded env45741 := by
  intro p hp
  have h : env45741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45740_45741 : H12AffineEnvironment.transform 15 114 env45740 = env45741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env45740 == env45741) = true)

theorem identity45741 : scanCanonicalize (H12AffineFastState.compose env45741 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound45741 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45742 : List Nat := [2,4,8,16,32,48,8,256,512,272,2048,4096,40,4112,260,2,4389,2081,272,261,4144,33,16,35,40,48,2049,4096,4096,2048,52,33,256,32,4144,544]

theorem envBound45742 : H12AffineFastState.Bounded env45742 := by
  intro p hp
  have h : env45742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45741_45742 : H12AffineEnvironment.transform 5 48 env45741 = env45742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env45741 == env45742) = true)

theorem identity45742 : scanCanonicalize (H12AffineFastState.compose env45742 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45742 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45743 : List Nat := [2,4,8,16,0,16,8,256,512,272,2048,4096,8,4112,260,2,4357,2049,272,261,4112,1,16,3,8,16,2049,4096,4096,2048,20,1,256,0,4112,512]

theorem envBound45743 : H12AffineFastState.Bounded env45743 := by
  intro p hp
  have h : env45743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45742_45743 : H12AffineEnvironment.transform 4 0 env45742 = env45743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45742 == env45743) = true)

theorem identity45743 : scanCanonicalize (H12AffineFastState.compose env45743 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45743 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45744 : List Nat := [2,4,8,16,0,16,8,5,512,21,2048,4096,8,4112,1,2,4096,2049,21,0,4112,1,16,3,8,16,2049,4096,4096,2048,20,1,5,0,4112,512]

theorem envBound45744 : H12AffineFastState.Bounded env45744 := by
  intro p hp
  have h : env45744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45743_45744 : H12AffineEnvironment.transform 7 5 env45743 = env45744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45743 == env45744) = true)

theorem identity45744 : scanCanonicalize (H12AffineFastState.compose env45744 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound45744 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45745 : List Nat := [2,4,8,16,0,16,8,5,512,21,2048,2064,8,2048,1,2,2064,2049,21,0,2048,1,16,3,8,16,2049,2064,2064,2048,20,1,5,0,2048,512]

theorem envBound45745 : H12AffineFastState.Bounded env45745 := by
  intro p hp
  have h : env45745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45744_45745 : H12AffineEnvironment.transform 11 2064 env45744 = env45745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env45744 == env45745) = true)

theorem identity45745 : scanCanonicalize (H12AffineFastState.compose env45745 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound45745 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45746 : List Nat := [2,4,8,5,0,5,8,5,512,0,2048,2053,8,2048,1,2,2053,2049,0,0,2048,1,5,3,8,5,2049,2053,2053,2048,1,1,5,0,2048,512]

theorem envBound45746 : H12AffineFastState.Bounded env45746 := by
  intro p hp
  have h : env45746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45745_45746 : H12AffineEnvironment.transform 3 5 env45745 = env45746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env45745 == env45746) = true)

def env45747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,16,98645,8193,64,398437,5392,4096,431377,1364,41341,256,33,46093,74251]

theorem envBound45747 : H12AffineFastState.Bounded env45747 := by
  intro p hp
  have h : env45747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45734_45747 : H12AffineEnvironment.transform 6 9 env45734 = env45747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45734 == env45747) = true)

theorem identity45747 : scanCanonicalize (H12AffineFastState.compose env45747 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45747 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env45748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41311,8193,64,398437,5392,4096,431377,1364,41341,256,33,46093,513]

theorem envBound45748 : H12AffineFastState.Bounded env45748 := by
  intro p hp
  have h : env45748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45747_45748 : H12AffineEnvironment.transform 15 8202 env45747 = env45748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45747 == env45748) = true)

theorem identity45748 : scanCanonicalize (H12AffineFastState.compose env45748 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45748 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env45749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,131072,262144,1024,8541,4161,32,16,3,8193,64,398437,5392,4096,406605,1364,33,256,33,5457,513]

theorem envBound45749 : H12AffineFastState.Bounded env45749 := by
  intro p hp
  have h : env45749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45748_45749 : H12AffineEnvironment.transform 14 8540 env45748 = env45749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45748 == env45749) = true)

theorem identity45749 : scanCanonicalize (H12AffineFastState.compose env45749 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45749 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45750 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,262144,1024,8461,4113,32,16,3,8193,16,398389,5392,4096,406557,1284,33,256,33,5377,513]

theorem envBound45750 : H12AffineFastState.Bounded env45750 := by
  intro p hp
  have h : env45750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45749_45750 : H12AffineEnvironment.transform 5 16 env45749 = env45750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45749 == env45750) = true)

theorem identity45750 : scanCanonicalize (H12AffineFastState.compose env45750 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45750 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45751 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10280,1024,8461,4113,32,16,3,8193,16,146461,5392,4096,138293,1284,33,256,33,5377,513]

theorem envBound45751 : H12AffineFastState.Bounded env45751 := by
  intro p hp
  have h : env45751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45750_45751 : H12AffineEnvironment.transform 17 10280 env45750 = env45751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45750 == env45751) = true)

theorem identity45751 : scanCanonicalize (H12AffineFastState.compose env45751 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45751 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45752 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,131072,2341,1024,0,4113,32,16,3,268,16,138512,5392,4096,138293,1284,33,256,33,5377,513]

theorem envBound45752 : H12AffineFastState.Bounded env45752 := by
  intro p hp
  have h : env45752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45751_45752 : H12AffineEnvironment.transform 12 269 env45751 = env45752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45751 == env45752) = true)

theorem identity45752 : scanCanonicalize (H12AffineFastState.compose env45752 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45752 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45753 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,4113,1,263,131072,2341,272,0,4113,32,16,3,268,16,137216,4096,4096,137509,20,33,256,33,4113,513]

theorem envBound45753 : H12AffineFastState.Bounded env45753 := by
  intro p hp
  have h : env45753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45752_45753 : H12AffineEnvironment.transform 9 272 env45752 = env45753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45752 == env45753) = true)

theorem identity45753 : scanCanonicalize (H12AffineFastState.compose env45753 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound45753 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env45754 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,4113,1,263,4096,2341,272,0,4113,32,16,3,268,16,2048,4096,4096,2341,20,33,256,33,4113,513]

theorem envBound45754 : H12AffineFastState.Bounded env45754 := by
  intro p hp
  have h : env45754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45753_45754 : H12AffineEnvironment.transform 16 4096 env45753 = env45754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env45753 == env45754) = true)

theorem identity45754 : scanCanonicalize (H12AffineFastState.compose env45754 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45754 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45755 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,1,34,4096,2048,53,0,4113,32,16,3,41,16,2048,4096,4096,2048,20,33,37,33,4113,513]

theorem envBound45755 : H12AffineFastState.Bounded env45755 := by
  intro p hp
  have h : env45755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45754_45755 : H12AffineEnvironment.transform 7 37 env45754 = env45755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45754 == env45755) = true)

theorem identity45755 : scanCanonicalize (H12AffineFastState.compose env45755 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound45755 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45756 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2608,40,2593,1,34,2608,2048,53,0,2593,32,16,3,41,16,2048,2608,2608,2048,20,33,37,33,2593,513]

theorem envBound45756 : H12AffineFastState.Bounded env45756 := by
  intro p hp
  have h : env45756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45755_45756 : H12AffineEnvironment.transform 11 2608 env45755 = env45756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env45755 == env45756) = true)

theorem identity45756 : scanCanonicalize (H12AffineFastState.compose env45756 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound45756 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45757 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,1,40,16,1,34,1,561,53,0,16,32,16,3,41,16,561,1,1,561,20,33,37,33,16,513]

theorem envBound45757 : H12AffineFastState.Bounded env45757 := by
  intro p hp
  have h : env45757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45756_45757 : H12AffineEnvironment.transform 10 561 env45756 = env45757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env45756 == env45757) = true)

theorem identity45757 : scanCanonicalize (H12AffineFastState.compose env45757 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound45757 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env45758 : List Nat := [2,4,8,16,32,16,9,37,48,53,1,1,40,16,1,34,1,1,53,0,16,32,16,3,41,16,1,1,1,1,20,33,37,33,16,49]

theorem envBound45758 : H12AffineFastState.Bounded env45758 := by
  intro p hp
  have h : env45758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45757_45758 : H12AffineEnvironment.transform 8 48 env45757 = env45758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env45757 == env45758) = true)

theorem identity45758 : scanCanonicalize (H12AffineFastState.compose env45758 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45758 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env45759 : List Nat := [2,4,8,0,32,0,9,37,32,37,1,1,40,0,1,34,1,1,37,0,0,32,0,3,41,0,1,1,1,1,4,33,37,33,0,33]

theorem envBound45759 : H12AffineFastState.Bounded env45759 := by
  intro p hp
  have h : env45759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45758_45759 : H12AffineEnvironment.transform 3 0 env45758 = env45759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45758 == env45759) = true)

def env45760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,4194304,21912,98644,8328,64,4592845,16536,17801,431512,20701,4235732,256,21792,46212,96011]

theorem envBound45760 : H12AffineFastState.Bounded env45760 := by
  intro p hp
  have h : env45760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45690_45760 : H12AffineEnvironment.transform 20 17729 env45690 = env45760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env45690 == env45760) = true)

def env45761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,21912,98644,8328,64,410093,16536,17801,431512,20701,62708,256,21792,46212,96011]

theorem envBound45761 : H12AffineFastState.Bounded env45761 := by
  intro p hp
  have h : env45761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45760_45761 : H12AffineEnvironment.transform 21 21792 env45760 = env45761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env45760 == env45761) = true)

theorem identity45761 : scanCanonicalize (H12AffineFastState.compose env45761 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound45761 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,17729,21792,21912,95616,8328,64,410093,16536,17801,418124,20701,32,256,21792,16464,96011]

theorem envBound45762 : H12AffineFastState.Bounded env45762 := by
  intro p hp
  have h : env45762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45761_45762 : H12AffineEnvironment.transform 14 29908 env45761 = env45762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env45761 == env45762) = true)

def env45763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32160,1024,29909,17729,21792,21912,95616,8328,64,146509,16536,17801,138476,20701,32,256,21792,16464,96011]

theorem envBound45763 : H12AffineFastState.Bounded env45763 := by
  intro p hp
  have h : env45763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45762_45763 : H12AffineEnvironment.transform 17 32160 env45762 = env45763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env45762 == env45763) = true)

theorem identity45763 : scanCanonicalize (H12AffineFastState.compose env45763 (packedSelected [4,5,7,8,9,11,14,16,18,20,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound45763 : packedSelected [4,5,7,8,9,11,14,16,18,20,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env45764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,5528,32160,1024,29909,17729,21792,21912,95616,8328,64,10709,16536,17801,2420,20701,32,256,21792,16464,96011]

theorem envBound45764 : H12AffineFastState.Bounded env45764 := by
  intro p hp
  have h : env45764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45763_45764 : H12AffineEnvironment.transform 16 5528 env45763 = env45764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env45763 == env45764) = true)

theorem identity45764 : scanCanonicalize (H12AffineFastState.compose env45764 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45764 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env45765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,5528,10400,1024,8661,4161,32,152,73856,8328,64,10709,5528,4233,2420,1501,32,256,32,5456,74251]

theorem envBound45765 : H12AffineFastState.Bounded env45765 := by
  intro p hp
  have h : env45765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45764_45765 : H12AffineEnvironment.transform 13 5376 env45764 = env45765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45764 == env45765) = true)

def env45766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32161,1024,29909,17729,21792,21912,95616,8328,64,146508,16536,17801,138477,20701,32,256,21792,16464,96011]

theorem envBound45766 : H12AffineFastState.Bounded env45766 := by
  intro p hp
  have h : env45766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45762_45766 : H12AffineEnvironment.transform 17 32161 env45762 = env45766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env45762 == env45766) = true)

theorem identity45766 : scanCanonicalize (H12AffineFastState.compose env45766 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound45766 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10281,1024,8541,4297,168,16,73736,8328,64,146508,5392,4097,138477,1365,32,256,168,5592,74371]

theorem envBound45767 : H12AffineFastState.Bounded env45767 := by
  intro p hp
  have h : env45767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45766_45767 : H12AffineEnvironment.transform 13 5512 env45766 = env45767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env45766 == env45767) = true)

theorem identity45767 : scanCanonicalize (H12AffineFastState.compose env45767 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound45767 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env45768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,79131,10281,1024,8541,4297,168,16,73736,8328,64,67927,5392,4097,76278,1365,32,256,168,5592,74371]

theorem envBound45768 : H12AffineFastState.Bounded env45768 := by
  intro p hp
  have h : env45768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45767_45768 : H12AffineEnvironment.transform 16 79131 env45767 = env45768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env45767 == env45768) = true)

theorem identity45768 : scanCanonicalize (H12AffineFastState.compose env45768 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound45768 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env45769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8322,5529,10281,1024,8541,4297,168,16,138,8328,64,10709,5392,4097,2420,1365,32,256,168,5592,513]

theorem envBound45769 : H12AffineFastState.Bounded env45769 := by
  intro p hp
  have h : env45769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45768_45769 : H12AffineEnvironment.transform 15 8322 env45768 = env45769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env45768 == env45769) = true)

theorem identity45769 : scanCanonicalize (H12AffineFastState.compose env45769 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound45769 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env45770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,137,343,5529,2556,1024,136,4297,168,16,138,349,64,2048,5392,4097,2420,1365,32,256,168,5592,513]

theorem envBound45770 : H12AffineFastState.Bounded env45770 := by
  intro p hp
  have h : env45770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45769_45770 : H12AffineEnvironment.transform 12 469 env45769 = env45770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env45769 == env45770) = true)

theorem identity45770 : scanCanonicalize (H12AffineFastState.compose env45770 (packedSelected [0,1,3,5,7,8,15] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound45770 : packedSelected [0,1,3,5,7,8,15] rootPS < 2^1333 := by decide +kernel

def env45771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,429,4096,469,5512,137,343,5529,81,1024,136,4297,168,16,138,349,64,429,5392,4097,217,1365,32,256,168,5592,513]

theorem envBound45771 : H12AffineFastState.Bounded env45771 := by
  intro p hp
  have h : env45771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45770_45771 : H12AffineEnvironment.transform 10 429 env45770 = env45771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env45770 == env45771) = true)

theorem identity45771 : scanCanonicalize (H12AffineFastState.compose env45771 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45771 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env45772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,349,5376,1,343,5393,81,1024,0,4161,32,16,2,349,64,293,5392,4097,81,1365,32,256,32,5456,513]

theorem envBound45772 : H12AffineFastState.Bounded env45772 := by
  intro p hp
  have h : env45772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45771_45772 : H12AffineEnvironment.transform 6 8 env45771 = env45772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45771 == env45772) = true)

theorem identity45772 : scanCanonicalize (H12AffineFastState.compose env45772 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45772 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45773 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,4096,349,4452,1,343,4469,81,100,0,4161,32,16,2,349,64,293,4468,4097,81,305,32,256,32,4404,513]

theorem envBound45773 : H12AffineFastState.Bounded env45773 := by
  intro p hp
  have h : env45773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45772_45773 : H12AffineEnvironment.transform 9 100 env45772 = env45773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45772 == env45773) = true)

theorem identity45773 : scanCanonicalize (H12AffineFastState.compose env45773 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45773 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45774 : List Nat := [2,4,8,16,32,64,8,37,512,100,0,4096,120,4161,1,114,4176,81,100,0,4161,32,16,2,120,64,0,4177,4097,81,20,32,37,32,4113,513]

theorem envBound45774 : H12AffineFastState.Bounded env45774 := by
  intro p hp
  have h : env45774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45773_45774 : H12AffineEnvironment.transform 7 37 env45773 = env45774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45773 == env45774) = true)

def env45775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,21912,98644,8328,64,410092,16536,17801,431512,20701,62709,256,21792,46212,96011]

theorem envBound45775 : H12AffineFastState.Bounded env45775 := by
  intro p hp
  have h : env45775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45760_45775 : H12AffineEnvironment.transform 21 21793 env45760 = env45775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env45760 == env45775) = true)

theorem identity45775 : scanCanonicalize (H12AffineFastState.compose env45775 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45775 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,17729,21793,21912,73736,8328,64,410092,16536,17801,406724,20701,21929,256,21792,5592,96011]

theorem envBound45776 : H12AffineFastState.Bounded env45776 := by
  intro p hp
  have h : env45776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45775_45776 : H12AffineEnvironment.transform 14 8540 env45775 = env45776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45775 == env45776) = true)

def env45777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,17729,21793,21912,73736,8328,64,158028,16536,17801,138340,20701,21929,256,21792,5592,96011]

theorem envBound45777 : H12AffineFastState.Bounded env45777 := by
  intro p hp
  have h : env45777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45776_45777 : H12AffineEnvironment.transform 17 10400 env45776 = env45777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env45776 == env45777) = true)

theorem identity45777 : scanCanonicalize (H12AffineFastState.compose env45777 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound45777 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env45778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10400,1024,8541,17729,21793,21912,21762,8328,64,158028,16536,17801,138340,20701,21929,256,21792,5592,513]

theorem envBound45778 : H12AffineFastState.Bounded env45778 := by
  intro p hp
  have h : env45778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45777_45778 : H12AffineEnvironment.transform 15 29962 env45777 = env45778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env45777 == env45778) = true)

theorem identity45778 : scanCanonicalize (H12AffineFastState.compose env45778 (packedSelected [2,3,5,11,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound45778 : packedSelected [2,3,5,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env45779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,13673,10400,1024,8541,17729,21793,21912,21762,8328,64,23589,16536,17801,10509,20701,21929,256,21792,5592,513]

theorem envBound45779 : H12AffineFastState.Bounded env45779 := by
  intro p hp
  have h : env45779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45778_45779 : H12AffineEnvironment.transform 16 13673 env45778 = env45779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env45778 == env45779) = true)

theorem identity45779 : scanCanonicalize (H12AffineFastState.compose env45779 (packedSelected [0,1,2,4,6,7,8,9,10,12,16,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound45779 : packedSelected [0,1,2,4,6,7,8,9,10,12,16,23] rootPS < 2^1333 := by decide +kernel

def env45780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,217,21647,5356,2341,1024,216,17729,21793,21912,21762,269,64,23589,16536,17801,2184,20701,21929,256,21792,5592,513]

theorem envBound45780 : H12AffineFastState.Bounded env45780 := by
  intro p hp
  have h : env45780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45779_45780 : H12AffineEnvironment.transform 12 389 env45779 = env45780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env45779 == env45780) = true)

theorem identity45780 : scanCanonicalize (H12AffineFastState.compose env45780 (packedSelected [0,2,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound45780 : packedSelected [0,2,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env45781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5512,217,263,5356,2341,1024,216,4297,169,16,138,269,64,2477,5392,4097,2184,1365,33,256,168,5592,513]

theorem envBound45781 : H12AffineFastState.Bounded env45781 := by
  intro p hp
  have h : env45781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45780_45781 : H12AffineEnvironment.transform 13 5512 env45780 = env45781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env45780 == env45781) = true)

theorem identity45781 : scanCanonicalize (H12AffineFastState.compose env45781 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound45781 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45782 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5457,0,263,5173,2341,1024,1,4112,112,16,83,269,64,2420,5392,4097,2129,1365,33,256,113,5377,513]

theorem envBound45782 : H12AffineFastState.Bounded env45782 := by
  intro p hp
  have h : env45782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45781_45782 : H12AffineEnvironment.transform 6 89 env45781 = env45782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env45781 == env45782) = true)

theorem identity45782 : scanCanonicalize (H12AffineFastState.compose env45782 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45782 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45783 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,41,5156,0,114,5173,2128,1024,1,4112,112,16,83,120,64,2049,5221,4097,2129,1056,33,117,113,5236,513]

theorem envBound45783 : H12AffineFastState.Bounded env45783 := by
  intro p hp
  have h : env45783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45782_45783 : H12AffineEnvironment.transform 7 117 env45782 = env45783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45782 == env45783) = true)

theorem identity45783 : scanCanonicalize (H12AffineFastState.compose env45783 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45783 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45784 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5156,0,35,5173,2049,1024,1,4112,33,16,2,41,17,2049,5172,4097,2048,1056,33,36,32,5157,513]

theorem envBound45784 : H12AffineFastState.Bounded env45784 := by
  intro p hp
  have h : env45784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45783_45784 : H12AffineEnvironment.transform 5 17 env45783 = env45784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45783 == env45784) = true)

theorem identity45784 : scanCanonicalize (H12AffineFastState.compose env45784 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45785 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4113,0,35,4096,2049,53,1,4112,33,16,2,41,17,2049,4097,4097,2048,21,33,36,32,4112,513]

theorem envBound45785 : H12AffineFastState.Bounded env45785 := by
  intro p hp
  have h : env45785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45784_45785 : H12AffineEnvironment.transform 9 53 env45784 = env45785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45784 == env45785) = true)

theorem identity45785 : scanCanonicalize (H12AffineFastState.compose env45785 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound45785 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45786 : List Nat := [2,4,8,16,32,17,8,36,512,53,49,4096,41,4113,0,35,4096,48,53,1,4112,33,16,2,41,17,48,4097,4097,49,21,33,36,32,4112,513]

theorem envBound45786 : H12AffineFastState.Bounded env45786 := by
  intro p hp
  have h : env45786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45785_45786 : H12AffineEnvironment.transform 10 49 env45785 = env45786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env45785 == env45786) = true)

theorem identity45786 : scanCanonicalize (H12AffineFastState.compose env45786 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45786 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45787 : List Nat := [2,4,8,16,1,17,8,5,512,20,16,4096,8,4113,0,2,4096,17,20,1,4112,0,16,2,8,17,17,4097,4097,16,21,0,5,1,4112,513]

theorem envBound45787 : H12AffineFastState.Bounded env45787 := by
  intro p hp
  have h : env45787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45786_45787 : H12AffineEnvironment.transform 4 1 env45786 = env45787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45786 == env45787) = true)

def env45788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,17729,21793,21912,73736,8328,64,158029,16536,17801,138341,20701,21929,256,21792,5592,96011]

theorem envBound45788 : H12AffineFastState.Bounded env45788 := by
  intro p hp
  have h : env45788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45776_45788 : H12AffineEnvironment.transform 17 10401 env45776 = env45788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env45776 == env45788) = true)

theorem identity45788 : scanCanonicalize (H12AffineFastState.compose env45788 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound45788 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,131072,10401,1024,8541,4297,169,16,73736,8328,64,146629,5392,4097,138341,1365,33,256,168,5592,74371]

theorem envBound45789 : H12AffineFastState.Bounded env45789 := by
  intro p hp
  have h : env45789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45788_45789 : H12AffineEnvironment.transform 13 5512 env45788 = env45789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env45788 == env45789) = true)

theorem identity45789 : scanCanonicalize (H12AffineFastState.compose env45789 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound45789 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env45790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,5393,10401,1024,8541,4297,169,16,73736,8328,64,10708,5392,4097,2420,1365,33,256,168,5592,74371]

theorem envBound45790 : H12AffineFastState.Bounded env45790 := by
  intro p hp
  have h : env45790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45789_45790 : H12AffineEnvironment.transform 16 5393 env45789 = env45790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env45789 == env45790) = true)

theorem identity45790 : scanCanonicalize (H12AffineFastState.compose env45790 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound45790 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8322,5393,10401,1024,8541,4297,169,16,138,8328,64,10708,5392,4097,2420,1365,33,256,168,5592,513]

theorem envBound45791 : H12AffineFastState.Bounded env45791 := by
  intro p hp
  have h : env45791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45790_45791 : H12AffineEnvironment.transform 15 8322 env45790 = env45791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env45790 == env45791) = true)

theorem identity45791 : scanCanonicalize (H12AffineFastState.compose env45791 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound45791 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,380,5512,32,510,5393,2525,1024,33,4297,169,16,138,500,64,2216,5392,4097,2420,1365,33,256,168,5592,513]

theorem envBound45792 : H12AffineFastState.Bounded env45792 := by
  intro p hp
  have h : env45792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45791_45792 : H12AffineEnvironment.transform 12 380 env45791 = env45792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env45791 == env45792) = true)

theorem identity45792 : scanCanonicalize (H12AffineFastState.compose env45792 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45792 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env45793 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,380,4249,32,510,4096,2525,273,33,4297,169,16,138,500,64,2216,4097,4097,2420,68,33,256,168,4297,513]

theorem envBound45793 : H12AffineFastState.Bounded env45793 := by
  intro p hp
  have h : env45793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45792_45793 : H12AffineEnvironment.transform 9 273 env45792 = env45793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45792 == env45793) = true)

theorem identity45793 : scanCanonicalize (H12AffineFastState.compose env45793 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound45793 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env45794 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2144,380,2297,32,510,2144,2525,273,33,2217,169,16,138,500,64,2216,2145,2145,2420,68,33,256,168,2217,513]

theorem envBound45794 : H12AffineFastState.Bounded env45794 := by
  intro p hp
  have h : env45794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45793_45794 : H12AffineEnvironment.transform 11 2144 env45793 = env45794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env45793 == env45794) = true)

theorem identity45794 : scanCanonicalize (H12AffineFastState.compose env45794 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound45794 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env45795 : List Nat := [2,4,8,16,32,64,128,256,512,273,508,412,380,261,32,510,412,33,273,33,341,169,16,138,500,64,340,413,413,136,68,33,256,168,341,513]

theorem envBound45795 : H12AffineFastState.Bounded env45795 := by
  intro p hp
  have h : env45795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45794_45795 : H12AffineEnvironment.transform 10 508 env45794 = env45795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env45794 == env45795) = true)

theorem identity45795 : scanCanonicalize (H12AffineFastState.compose env45795 (packedSelected [0,2,4,6,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 249) := by decide +kernel

theorem selectedBound45795 : packedSelected [0,2,4,6,11,12] rootPS < 2^1333 := by decide +kernel

def env45796 : List Nat := [2,4,8,16,32,64,128,256,249,273,508,412,380,261,32,510,412,33,273,33,341,169,16,138,500,64,340,413,413,136,68,33,256,168,341,248]

theorem envBound45796 : H12AffineFastState.Bounded env45796 := by
  intro p hp
  have h : env45796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45795_45796 : H12AffineEnvironment.transform 8 249 env45795 = env45796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 249 env45795 == env45796) = true)

theorem identity45796 : scanCanonicalize (H12AffineFastState.compose env45796 (packedSelected [0,4,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound45796 : packedSelected [0,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env45797 : List Nat := [2,4,8,16,32,64,128,20,249,5,232,136,104,17,32,234,136,33,5,33,65,169,16,138,224,64,64,137,137,136,68,33,20,168,65,248]

theorem envBound45797 : H12AffineFastState.Bounded env45797 := by
  intro p hp
  have h : env45797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45796_45797 : H12AffineEnvironment.transform 7 20 env45796 = env45797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env45796 == env45797) = true)

theorem identity45797 : scanCanonicalize (H12AffineFastState.compose env45797 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound45797 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env45798 : List Nat := [2,4,8,16,32,64,40,20,81,5,64,32,104,17,32,66,32,33,5,33,65,1,16,34,72,64,64,33,33,32,68,33,20,0,65,80]

theorem envBound45798 : H12AffineFastState.Bounded env45798 := by
  intro p hp
  have h : env45798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45797_45798 : H12AffineEnvironment.transform 6 40 env45797 = env45798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env45797 == env45798) = true)

theorem identity45798 : scanCanonicalize (H12AffineFastState.compose env45798 (packedSelected [2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45798 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env45799 : List Nat := [2,4,8,16,17,64,25,20,81,5,64,17,89,17,17,66,17,16,5,16,65,1,16,19,72,64,64,16,16,17,68,16,20,0,65,80]

theorem envBound45799 : H12AffineFastState.Bounded env45799 := by
  intro p hp
  have h : env45799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45798_45799 : H12AffineEnvironment.transform 4 17 env45798 = env45799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45798 == env45799) = true)

theorem identity45799 : scanCanonicalize (H12AffineFastState.compose env45799 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound45799 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45800 : List Nat := [2,4,8,16,17,1,25,20,16,5,1,17,24,17,17,3,17,16,5,16,0,1,16,19,9,1,1,16,16,17,5,16,20,0,0,17]

theorem envBound45800 : H12AffineFastState.Bounded env45800 := by
  intro p hp
  have h : env45800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45799_45800 : H12AffineEnvironment.transform 5 1 env45799 = env45800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45799 == env45800) = true)

def env45801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21913,2212885,8328,64,6705549,16536,2097353,431513,2102685,4235732,256,21793,46213,2175563]

theorem envBound45801 : H12AffineFastState.Bounded env45801 := by
  intro p hp
  have h : env45801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45689_45801 : H12AffineEnvironment.transform 22 21913 env45689 = env45801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21913 env45689 == env45801) = true)

def env45802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,4194304,21913,98645,8328,64,4592845,16536,17801,431513,20701,4235732,256,21793,46213,96011]

theorem envBound45802 : H12AffineFastState.Bounded env45802 := by
  intro p hp
  have h : env45802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45801_45802 : H12AffineEnvironment.transform 20 17728 env45801 = env45802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env45801 == env45802) = true)

def env45803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21913,98645,8328,64,410093,16536,17801,431513,20701,62708,256,21793,46213,96011]

theorem envBound45803 : H12AffineFastState.Bounded env45803 := by
  intro p hp
  have h : env45803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45802_45803 : H12AffineEnvironment.transform 21 21792 env45802 = env45803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env45802 == env45803) = true)

theorem identity45803 : scanCanonicalize (H12AffineFastState.compose env45803 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound45803 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,131072,262144,1024,32769,17728,21792,21913,41430,8328,64,410093,16536,17801,431513,20701,62708,256,21793,46213,22408]

theorem envBound45804 : H12AffineFastState.Bounded env45804 := by
  intro p hp
  have h : env45804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45803_45804 : H12AffineEnvironment.transform 15 8323 env45803 = env45804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env45803 == env45804) = true)

def env45805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5440,262144,1024,32769,17728,21792,21913,41430,8328,64,283821,16536,17801,295129,20701,62708,256,21793,46213,22408]

theorem envBound45805 : H12AffineFastState.Bounded env45805 := by
  intro p hp
  have h : env45805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45804_45805 : H12AffineEnvironment.transform 16 5440 env45804 = env45805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env45804 == env45805) = true)

theorem identity45805 : scanCanonicalize (H12AffineFastState.compose env45805 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound45805 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5440,35108,1024,32769,17728,21792,21913,41430,8328,64,56713,16536,17801,2557,20701,62708,256,21793,46213,22408]

theorem envBound45806 : H12AffineFastState.Bounded env45806 := by
  intro p hp
  have h : env45806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45805_45806 : H12AffineEnvironment.transform 17 35108 env45805 = env45806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env45805 == env45806) = true)

theorem identity45806 : scanCanonicalize (H12AffineFastState.compose env45806 (packedSelected [0,9,11,18,22,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound45806 : packedSelected [0,9,11,18,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env45807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8323,5440,10481,1024,8660,17728,21792,21913,3,8328,64,31836,16536,17801,2557,20701,21793,256,21793,5456,22408]

theorem envBound45807 : H12AffineFastState.Bounded env45807 := by
  intro p hp
  have h : env45807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45806_45807 : H12AffineEnvironment.transform 14 8661 env45806 = env45807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env45806 == env45807) = true)

theorem identity45807 : scanCanonicalize (H12AffineFastState.compose env45807 (packedSelected [1,3,5,8,10,19,21] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45807 : packedSelected [1,3,5,8,10,19,21] rootPS < 2^1333 := by decide +kernel

def env45808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8661,8323,5440,10481,1024,8660,4113,113,200,3,8328,64,10509,5577,4312,2557,1420,112,256,112,5456,729]

theorem envBound45808 : H12AffineFastState.Bounded env45808 := by
  intro p hp
  have h : env45808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45807_45808 : H12AffineEnvironment.transform 13 5457 env45807 = env45808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45807 == env45808) = true)

theorem identity45808 : scanCanonicalize (H12AffineFastState.compose env45808 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45808 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env45809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8540,8202,5440,10360,1024,8541,4113,113,65,3,8193,64,10509,5440,4177,2420,1285,112,256,112,5456,592]

theorem envBound45809 : H12AffineFastState.Bounded env45809 := by
  intro p hp
  have h : env45809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45808_45809 : H12AffineEnvironment.transform 6 9 env45808 = env45809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45808 == env45809) = true)

theorem identity45809 : scanCanonicalize (H12AffineFastState.compose env45809 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound45809 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1085,5457,1377,1079,5440,3141,1024,1376,4113,113,65,3,1084,64,3376,5440,4177,2420,1285,112,256,112,5456,592]

theorem envBound45810 : H12AffineFastState.Bounded env45810 := by
  intro p hp
  have h : env45810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45809_45810 : H12AffineEnvironment.transform 12 1085 env45809 = env45810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env45809 == env45810) = true)

def env45811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5441,262144,1024,32769,17728,21792,21913,41430,8328,64,283820,16536,17801,295128,20701,62708,256,21793,46213,22408]

theorem envBound45811 : H12AffineFastState.Bounded env45811 := by
  intro p hp
  have h : env45811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45804_45811 : H12AffineEnvironment.transform 16 5441 env45804 = env45811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env45804 == env45811) = true)

theorem identity45811 : scanCanonicalize (H12AffineFastState.compose env45811 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound45811 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5441,35245,1024,32769,17728,21792,21913,41430,8328,64,56577,16536,17801,2421,20701,62708,256,21793,46213,22408]

theorem envBound45812 : H12AffineFastState.Bounded env45812 := by
  intro p hp
  have h : env45812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45811_45812 : H12AffineEnvironment.transform 17 35245 env45811 = env45812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env45811 == env45812) = true)

theorem identity45812 : scanCanonicalize (H12AffineFastState.compose env45812 (packedSelected [0,3,4,5,7,8,16,18,20,22,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound45812 : packedSelected [0,3,4,5,7,8,16,18,20,22,23,28] rootPS < 2^1333 := by decide +kernel

def env45813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8581,8323,5441,10280,1024,8580,17728,21792,21913,83,8328,64,31876,16536,17801,2421,20701,21873,256,21793,5376,22408]

theorem envBound45813 : H12AffineFastState.Bounded env45813 := by
  intro p hp
  have h : env45813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45812_45813 : H12AffineEnvironment.transform 14 8581 env45812 = env45813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env45812 == env45813) = true)

theorem identity45813 : scanCanonicalize (H12AffineFastState.compose env45813 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45813 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env45814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,137,399,5441,2340,1024,136,17728,21792,21913,83,388,64,23944,16536,17801,2421,20701,21873,256,21793,5376,22408]

theorem envBound45814 : H12AffineFastState.Bounded env45814 := by
  intro p hp
  have h : env45814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45813_45814 : H12AffineEnvironment.transform 12 268 env45813 = env45814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45813 == env45814) = true)

theorem identity45814 : scanCanonicalize (H12AffineFastState.compose env45814 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound45814 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env45815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,4113,137,399,5441,2340,1024,136,5457,1329,1416,83,388,64,3481,4233,5528,2421,204,1376,256,1328,5376,1945]

theorem envBound45815 : H12AffineFastState.Bounded env45815 := by
  intro p hp
  have h : env45815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45814_45815 : H12AffineEnvironment.transform 13 4113 env45814 = env45815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env45814 == env45815) = true)

theorem identity45815 : scanCanonicalize (H12AffineFastState.compose env45815 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45815 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env45816 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,4113,137,399,5393,2340,1024,136,5377,1329,1416,3,388,16,3481,4233,5528,2341,156,1328,256,1328,5376,1945]

theorem envBound45816 : H12AffineFastState.Bounded env45816 := by
  intro p hp
  have h : env45816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45815_45816 : H12AffineEnvironment.transform 5 16 env45815 = env45816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45815 == env45816) = true)

theorem identity45816 : scanCanonicalize (H12AffineFastState.compose env45816 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1417) := by decide +kernel

theorem selectedBound45816 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env45817 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1417,268,1432,137,399,152,2340,1024,136,136,1329,1416,3,388,16,3481,1280,17,2341,156,1328,256,1328,137,1945]

theorem envBound45817 : H12AffineFastState.Bounded env45817 := by
  intro p hp
  have h : env45817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45816_45817 : H12AffineEnvironment.transform 11 1417 env45816 = env45817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1417 env45816 == env45817) = true)

theorem identity45817 : scanCanonicalize (H12AffineFastState.compose env45817 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound45817 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env45818 : List Nat := [2,4,8,16,32,16,128,256,512,1024,293,1417,268,1432,137,399,152,1,1024,136,136,1329,1416,3,388,16,1212,1280,17,0,156,1328,256,1328,137,1945]

theorem envBound45818 : H12AffineFastState.Bounded env45818 := by
  intro p hp
  have h : env45818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45817_45818 : H12AffineEnvironment.transform 10 293 env45817 = env45818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env45817 == env45818) = true)

theorem identity45818 : scanCanonicalize (H12AffineFastState.compose env45818 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45818 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env45819 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1197,40,1212,137,171,152,1,1024,136,136,1045,1196,3,160,16,1212,1060,17,0,156,1044,36,1044,137,1725]

theorem envBound45819 : H12AffineFastState.Bounded env45819 := by
  intro p hp
  have h : env45819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45818_45819 : H12AffineEnvironment.transform 7 36 env45818 = env45819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45818 == env45819) = true)

def env45820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,21913,98645,8328,64,410092,16536,17801,431513,20701,62709,256,21793,46213,96011]

theorem envBound45820 : H12AffineFastState.Bounded env45820 := by
  intro p hp
  have h : env45820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45802_45820 : H12AffineEnvironment.transform 21 21793 env45802 = env45820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env45802 == env45820) = true)

theorem identity45820 : scanCanonicalize (H12AffineFastState.compose env45820 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound45820 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17728,21793,21913,62559,8328,64,410092,16536,17801,431513,20701,62709,256,21793,46213,513]

theorem envBound45821 : H12AffineFastState.Bounded env45821 := by
  intro p hp
  have h : env45821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45820_45821 : H12AffineEnvironment.transform 15 29962 env45820 = env45821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env45820 == env45821) = true)

theorem identity45821 : scanCanonicalize (H12AffineFastState.compose env45821 (packedSelected [12,15,21,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45821 : packedSelected [12,15,21,38,41] rootPS < 2^1333 := by decide +kernel

def env45822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17728,21793,21776,62559,8193,64,409957,16401,17664,431376,20564,62588,256,21793,46092,513]

theorem envBound45822 : H12AffineFastState.Bounded env45822 := by
  intro p hp
  have h : env45822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45821_45822 : H12AffineEnvironment.transform 6 9 env45821 = env45822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45821 == env45822) = true)

theorem identity45822 : scanCanonicalize (H12AffineFastState.compose env45822 (packedSelected [0,3,4,7,9,10,14,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45822 : packedSelected [0,3,4,7,9,10,14,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env45823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,131072,262144,1024,8541,17728,21793,21776,21763,8193,64,409957,16401,17664,406604,20564,21792,256,21793,5456,513]

theorem envBound45823 : H12AffineFastState.Bounded env45823 := by
  intro p hp
  have h : env45823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45822_45823 : H12AffineEnvironment.transform 14 8540 env45822 = env45823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45822 == env45823) = true)

theorem identity45823 : scanCanonicalize (H12AffineFastState.compose env45823 (packedSelected [0,2,6,14,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound45823 : packedSelected [0,2,6,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env45824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,13340,262144,1024,8541,17728,21793,21776,21763,8193,64,292217,16401,17664,262224,20564,21792,256,21793,5456,513]

theorem envBound45824 : H12AffineFastState.Bounded env45824 := by
  intro p hp
  have h : env45824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45823_45824 : H12AffineEnvironment.transform 16 13340 env45823 = env45824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env45823 == env45824) = true)

theorem identity45824 : scanCanonicalize (H12AffineFastState.compose env45824 (packedSelected [4,9,12,14,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound45824 : packedSelected [4,9,12,14,16,18] rootPS < 2^1333 := by decide +kernel

def env45825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,13340,23668,1024,8541,17728,21793,21776,21763,8193,64,10509,16401,17664,23588,20564,21792,256,21793,5456,513]

theorem envBound45825 : H12AffineFastState.Bounded env45825 := by
  intro p hp
  have h : env45825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45824_45825 : H12AffineEnvironment.transform 17 23668 env45824 = env45825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env45824 == env45825) = true)

theorem identity45825 : scanCanonicalize (H12AffineFastState.compose env45825 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound45825 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env45826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,8282,13340,2340,1024,8541,4112,113,64,83,8193,64,10509,5441,4176,2420,1284,112,256,113,5456,513]

theorem envBound45826 : H12AffineFastState.Bounded env45826 := by
  intro p hp
  have h : env45826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45825_45826 : H12AffineEnvironment.transform 13 5456 env45825 = env45826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env45825 == env45826) = true)

theorem identity45826 : scanCanonicalize (H12AffineFastState.compose env45826 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45826 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,1,263,5441,2340,1024,0,4112,113,64,83,348,64,2128,5441,4176,2420,1284,112,256,113,5456,513]

theorem envBound45827 : H12AffineFastState.Bounded env45827 := by
  intro p hp
  have h : env45827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45826_45827 : H12AffineEnvironment.transform 12 349 env45826 = env45827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45826 == env45827) = true)

theorem identity45827 : scanCanonicalize (H12AffineFastState.compose env45827 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45827 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env45828 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,1,263,5393,2340,1024,0,4112,33,16,3,268,16,2048,5393,4096,2340,1284,32,256,33,5376,513]

theorem envBound45828 : H12AffineFastState.Bounded env45828 := by
  intro p hp
  have h : env45828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45827_45828 : H12AffineEnvironment.transform 5 16 env45827 = env45828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45827 == env45828) = true)

theorem identity45828 : scanCanonicalize (H12AffineFastState.compose env45828 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45828 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45829 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,34,5172,2049,1024,0,4112,33,16,3,41,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound45829 : H12AffineFastState.Bounded env45829 := by
  intro p hp
  have h : env45829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45828_45829 : H12AffineEnvironment.transform 7 37 env45828 = env45829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45828 == env45829) = true)

def env45830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,4194304,21913,98644,8328,64,4592844,16536,17800,431513,20700,4235732,256,21793,46213,96010]

theorem envBound45830 : H12AffineFastState.Bounded env45830 := by
  intro p hp
  have h : env45830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45801_45830 : H12AffineEnvironment.transform 20 17729 env45801 = env45830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env45801 == env45830) = true)

def env45831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,21913,98644,8328,64,410092,16536,17800,431513,20700,62708,256,21793,46213,96010]

theorem envBound45831 : H12AffineFastState.Bounded env45831 := by
  intro p hp
  have h : env45831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45830_45831 : H12AffineEnvironment.transform 21 21792 env45830 = env45831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env45830 == env45831) = true)

theorem identity45831 : scanCanonicalize (H12AffineFastState.compose env45831 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound45831 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,17729,21792,21913,21763,8328,64,410092,16536,17800,431513,20700,62708,256,21793,46213,41821]

theorem envBound45832 : H12AffineFastState.Bounded env45832 := by
  intro p hp
  have h : env45832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45831_45832 : H12AffineEnvironment.transform 15 54359 env45831 = env45832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env45831 == env45832) = true)

theorem identity45832 : scanCanonicalize (H12AffineFastState.compose env45832 (packedSelected [3,10,12,15,21,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound45832 : packedSelected [3,10,12,15,21,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env45833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35324,1024,32769,17729,21792,21913,21763,8328,64,182288,16536,17800,138341,20700,62708,256,21793,46213,41821]

theorem envBound45833 : H12AffineFastState.Bounded env45833 := by
  intro p hp
  have h : env45833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45832_45833 : H12AffineEnvironment.transform 17 35324 env45832 = env45833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env45832 == env45833) = true)

theorem identity45833 : scanCanonicalize (H12AffineFastState.compose env45833 (packedSelected [0,1,3,4,5,6,7,8,9,10,11,12,15,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 30112) := by decide +kernel

theorem selectedBound45833 : packedSelected [0,1,3,4,5,6,7,8,9,10,11,12,15,19,21,23] rootPS < 2^1333 := by decide +kernel

def env45834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,8695,131072,31836,1024,30113,17729,21792,21913,21763,8328,64,146864,16536,17800,138341,20700,340,256,21793,16677,22269]

theorem envBound45834 : H12AffineFastState.Bounded env45834 := by
  intro p hp
  have h : env45834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45833_45834 : H12AffineEnvironment.transform 14 30112 env45833 = env45834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30112 env45833 == env45834) = true)

theorem identity45834 : scanCanonicalize (H12AffineFastState.compose env45834 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound45834 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8232,8695,131072,10708,1024,8233,4297,168,17,139,8328,64,146864,5392,4096,138341,1364,340,256,169,5293,885]

theorem envBound45835 : H12AffineFastState.Bounded env45835 := by
  intro p hp
  have h : env45835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45834_45835 : H12AffineEnvironment.transform 13 5512 env45834 = env45835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env45834 == env45835) = true)

theorem identity45835 : scanCanonicalize (H12AffineFastState.compose env45835 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound45835 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env45836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8232,8695,5357,10708,1024,8233,4297,168,17,139,8328,64,10589,5392,4096,2184,1364,340,256,169,5293,885]

theorem envBound45836 : H12AffineFastState.Bounded env45836 := by
  intro p hp
  have h : env45836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45835_45836 : H12AffineEnvironment.transform 16 5357 env45835 = env45836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env45835 == env45836) = true)

theorem identity45836 : scanCanonicalize (H12AffineFastState.compose env45836 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45836 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5512,1,478,5357,2557,1024,0,4297,168,17,139,161,64,2420,5392,4096,2184,1364,340,256,169,5293,885]

theorem envBound45837 : H12AffineFastState.Bounded env45837 := by
  intro p hp
  have h : env45837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45836_45837 : H12AffineEnvironment.transform 12 41 env45836 = env45837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45836 == env45837) = true)

theorem identity45837 : scanCanonicalize (H12AffineFastState.compose env45837 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound45837 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env45838 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,41,5157,1,115,5357,2128,1024,0,4297,168,17,139,161,64,2265,5309,4096,2184,1273,249,173,169,5293,728]

theorem envBound45838 : H12AffineFastState.Bounded env45838 := by
  intro p hp
  have h : env45838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45837_45838 : H12AffineEnvironment.transform 7 173 env45837 = env45838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env45837 == env45838) = true)

theorem identity45838 : scanCanonicalize (H12AffineFastState.compose env45838 (packedSelected [6,12] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound45838 : packedSelected [6,12] rootPS < 2^1333 := by decide +kernel

def env45839 : List Nat := [2,4,8,16,32,64,128,173,512,172,2048,4096,41,4233,1,115,4161,2128,172,0,4297,168,17,139,161,64,2265,4113,4096,2184,85,249,173,169,4097,728]

theorem envBound45839 : H12AffineFastState.Bounded env45839 := by
  intro p hp
  have h : env45839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45838_45839 : H12AffineEnvironment.transform 9 172 env45838 = env45839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env45838 == env45839) = true)

theorem identity45839 : scanCanonicalize (H12AffineFastState.compose env45839 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45839 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env45840 : List Nat := [2,4,8,16,32,64,9,36,512,37,2048,4096,41,4096,1,115,4161,2128,37,0,4160,33,17,2,40,64,2128,4113,4096,2049,85,112,36,32,4097,593]

theorem envBound45840 : H12AffineFastState.Bounded env45840 := by
  intro p hp
  have h : env45840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45839_45840 : H12AffineEnvironment.transform 6 9 env45839 = env45840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45839 == env45840) = true)

theorem identity45840 : scanCanonicalize (H12AffineFastState.compose env45840 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound45840 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env45841 : List Nat := [2,4,8,16,32,64,9,36,512,37,80,4096,41,4096,1,115,4161,0,37,0,4160,33,17,2,40,64,0,4113,4096,81,85,112,36,32,4097,593]

theorem envBound45841 : H12AffineFastState.Bounded env45841 := by
  intro p hp
  have h : env45841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45840_45841 : H12AffineEnvironment.transform 10 80 env45840 = env45841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env45840 == env45841) = true)

end H12CloudChart0