import H12CloudChart0Data231

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound58848 : packedSelected [0,3,5,7,12,13] rootPS < 2^1333 := by decide +kernel

def env58849 : List Nat := [2,4,8,16,32,64,128,256,372,1024,373,1108,365,1029,80,479,1077,277,1025,80,1393,32,260,511,484,341,325,1028,1124,81,1136,341,256,33,1077,372]

theorem envBound58849 : H12AffineFastState.Bounded env58849 := by
  intro p hp
  have h : env58849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58848_58849 : H12AffineEnvironment.transform 8 372 env58848 = env58849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58848 == env58849) = true)

theorem identity58849 : scanCanonicalize (H12AffineFastState.compose env58849 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound58849 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58850 : List Nat := [2,4,8,16,32,64,128,117,1,1024,0,1108,24,1029,80,170,1077,96,1025,80,1028,32,113,138,145,32,48,1028,1124,81,1136,32,117,33,1077,1]

theorem envBound58850 : H12AffineFastState.Bounded env58850 := by
  intro p hp
  have h : env58850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58849_58850 : H12AffineEnvironment.transform 7 117 env58849 = env58850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env58849 == env58850) = true)

def env58851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131153,4315354,8463814,4294967296,256,4307611964,131073,33563273]

theorem envBound58851 : H12AffineFastState.Bounded env58851 := by
  intro p hp
  have h : env58851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58711_58851 : H12AffineEnvironment.transform 34 131073 env58711 = env58851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env58711 == env58851) = true)

theorem identity58851 : scanCanonicalize (H12AffineFastState.compose env58851 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 138883282) := by decide +kernel

theorem selectedBound58851 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,134217728,16385,131153,4315354,8463814,138883282,256,143114734,131073,33563273]

theorem envBound58852 : H12AffineFastState.Bounded env58852 := by
  intro p hp
  have h : env58852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58851_58852 : H12AffineEnvironment.transform 31 138883282 env58851 = env58852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 138883282 env58851 == env58852) = true)

theorem identity58852 : scanCanonicalize (H12AffineFastState.compose env58852 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12992837) := by decide +kernel

theorem selectedBound58852 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409088,12992837,16385,131153,4315354,8463814,8483223,256,4292779,131073,33563273]

theorem envBound58853 : H12AffineFastState.Bounded env58853 := by
  intro p hp
  have h : env58853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58852_58853 : H12AffineEnvironment.transform 26 12992837 env58852 = env58853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12992837 env58852 == env58853) = true)

def env58854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8388688,12980501,4177,131153,4294794,8463814,8462791,256,4292779,131073,33563273]

theorem envBound58854 : H12AffineFastState.Bounded env58854 := by
  intro p hp
  have h : env58854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58853_58854 : H12AffineEnvironment.transform 13 4176 env58853 = env58854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58853 == env58854) = true)

theorem identity58854 : scanCanonicalize (H12AffineFastState.compose env58854 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58854 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,8328,8388688,12980501,4177,131153,4294794,8463814,8462791,256,4292779,131073,513]

theorem envBound58855 : H12AffineFastState.Bounded env58855 := by
  intro p hp
  have h : env58855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58854_58855 : H12AffineEnvironment.transform 24 8328 env58854 = env58855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58854 == env58855) = true)

theorem identity58855 : scanCanonicalize (H12AffineFastState.compose env58855 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 209246) := by decide +kernel

theorem selectedBound58855 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,2097152,209246,8388608,8430022,8328,8388688,8724555,4177,131153,178644,8463814,8462791,256,176629,131073,513]

theorem envBound58856 : H12AffineFastState.Bounded env58856 := by
  intro p hp
  have h : env58856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58855_58856 : H12AffineEnvironment.transform 21 209246 env58855 = env58856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 209246 env58855 == env58856) = true)

theorem identity58856 : scanCanonicalize (H12AffineFastState.compose env58856 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58856 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,209246,8388608,8430022,8328,8388688,8724555,4177,131153,178644,8463814,8462791,256,176629,131073,513]

theorem envBound58857 : H12AffineFastState.Bounded env58857 := by
  intro p hp
  have h : env58857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58856_58857 : H12AffineEnvironment.transform 20 4096 env58856 = env58857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env58856 == env58857) = true)

theorem identity58857 : scanCanonicalize (H12AffineFastState.compose env58857 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 98767) := by decide +kernel

theorem selectedBound58857 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4096,209246,98767,73737,8328,98719,303492,4177,131153,178644,41993,40968,256,176629,131073,513]

theorem envBound58858 : H12AffineFastState.Bounded env58858 := by
  intro p hp
  have h : env58858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58857_58858 : H12AffineEnvironment.transform 22 98767 env58857 = env58858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98767 env58857 == env58858) = true)

theorem identity58858 : scanCanonicalize (H12AffineFastState.compose env58858 (packedSelected [6,25] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound58858 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,4096,396,98767,73737,8328,98719,303492,4177,77955,100614,41993,40968,256,98599,78035,513]

theorem envBound58859 : H12AffineFastState.Bounded env58859 := by
  intro p hp
  have h : env58859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58858_58859 : H12AffineEnvironment.transform 16 78034 env58858 = env58859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env58858 == env58859) = true)

theorem identity58859 : scanCanonicalize (H12AffineFastState.compose env58859 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound58859 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58860 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,4176,32768,65536,77835,262144,1025,32768,4096,341,98582,73737,8273,98630,303453,4177,77914,100614,41993,40968,256,98599,77834,513]

theorem envBound58860 : H12AffineFastState.Bounded env58860 := by
  intro p hp
  have h : env58860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58859_58860 : H12AffineEnvironment.transform 6 89 env58859 = env58860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env58859 == env58860) = true)

theorem identity58860 : scanCanonicalize (H12AffineFastState.compose env58860 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound58860 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58861 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,4176,32768,8283,4176,262144,1025,32768,4096,341,41293,82,8273,41245,303453,4177,4097,43357,41993,40968,256,41340,4177,513]

theorem envBound58861 : H12AffineFastState.Bounded env58861 := by
  intro p hp
  have h : env58861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58860_58861 : H12AffineEnvironment.transform 15 8283 env58860 = env58861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env58860 == env58861) = true)

theorem identity58861 : scanCanonicalize (H12AffineFastState.compose env58861 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound58861 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58862 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,4176,112,8283,4176,262144,1025,112,4096,341,8509,82,8273,8557,270637,4177,4097,10541,9337,8312,256,8460,4177,513]

theorem envBound58862 : H12AffineFastState.Bounded env58862 := by
  intro p hp
  have h : env58862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58861_58862 : H12AffineEnvironment.transform 14 112 env58861 = env58862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env58861 == env58862) = true)

theorem identity58862 : scanCanonicalize (H12AffineFastState.compose env58862 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound58862 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58863 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,4176,112,8283,4176,2048,1025,112,4096,341,8509,82,8273,8557,10541,4177,4097,10541,9337,8312,256,8460,4177,513]

theorem envBound58863 : H12AffineFastState.Bounded env58863 := by
  intro p hp
  have h : env58863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58862_58863 : H12AffineEnvironment.transform 17 2048 env58862 = env58863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env58862 == env58863) = true)

theorem identity58863 : scanCanonicalize (H12AffineFastState.compose env58863 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound58863 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58864 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,381,4176,112,294,4176,2048,1025,112,4096,341,64,82,300,16,2128,4177,4097,2128,1284,261,256,113,4177,513]

theorem envBound58864 : H12AffineFastState.Bounded env58864 := by
  intro p hp
  have h : env58864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58863_58864 : H12AffineEnvironment.transform 12 381 env58863 = env58864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env58863 == env58864) = true)

theorem identity58864 : scanCanonicalize (H12AffineFastState.compose env58864 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound58864 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env58865 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,577,381,529,112,294,529,2048,1025,112,577,341,64,82,300,16,2128,528,576,2128,1284,261,256,113,528,513]

theorem envBound58865 : H12AffineFastState.Bounded env58865 := by
  intro p hp
  have h : env58865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58864_58865 : H12AffineEnvironment.transform 11 577 env58864 = env58865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env58864 == env58865) = true)

theorem identity58865 : scanCanonicalize (H12AffineFastState.compose env58865 (packedSelected [2,13] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound58865 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env58866 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1803,577,381,529,112,294,529,1803,1025,112,577,341,64,82,300,16,1883,528,576,1883,1284,261,256,113,528,513]

theorem envBound58866 : H12AffineFastState.Bounded env58866 := by
  intro p hp
  have h : env58866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58865_58866 : H12AffineEnvironment.transform 10 1803 env58865 = env58866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env58865 == env58866) = true)

theorem identity58866 : scanCanonicalize (H12AffineFastState.compose env58866 (packedSelected [2,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58866 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env58867 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1803,529,301,529,32,294,529,1803,1025,32,529,261,16,2,300,16,1803,528,528,1803,1284,261,256,33,528,513]

theorem envBound58867 : H12AffineFastState.Bounded env58867 := by
  intro p hp
  have h : env58867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58866_58867 : H12AffineEnvironment.transform 5 16 env58866 = env58867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58866 == env58867) = true)

theorem identity58867 : scanCanonicalize (H12AffineFastState.compose env58867 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 281) := by decide +kernel

theorem selectedBound58867 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58868 : List Nat := [2,4,8,16,32,16,9,256,512,281,530,529,301,529,32,294,529,530,280,32,529,261,16,2,300,16,530,528,528,530,29,261,256,33,528,513]

theorem envBound58868 : H12AffineFastState.Bounded env58868 := by
  intro p hp
  have h : env58868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58867_58868 : H12AffineEnvironment.transform 9 281 env58867 = env58868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 281 env58867 == env58868) = true)

theorem identity58868 : scanCanonicalize (H12AffineFastState.compose env58868 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound58868 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58869 : List Nat := [2,4,8,16,32,16,9,256,26,281,8,11,301,11,32,294,11,8,280,32,11,261,16,2,300,16,8,10,10,8,29,261,256,33,10,27]

theorem envBound58869 : H12AffineFastState.Bounded env58869 := by
  intro p hp
  have h : env58869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58868_58869 : H12AffineEnvironment.transform 8 26 env58868 = env58869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env58868 == env58869) = true)

theorem identity58869 : scanCanonicalize (H12AffineFastState.compose env58869 (packedSelected [1,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58869 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env58870 : List Nat := [2,4,8,16,32,16,9,21,26,12,8,11,56,11,32,51,11,8,13,32,11,16,16,2,57,16,8,10,10,8,29,16,21,33,10,27]

theorem envBound58870 : H12AffineFastState.Bounded env58870 := by
  intro p hp
  have h : env58870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58869_58870 : H12AffineEnvironment.transform 7 21 env58869 = env58870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58869 == env58870) = true)

theorem identity58870 : scanCanonicalize (H12AffineFastState.compose env58870 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58870 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env58871 : List Nat := [2,4,8,16,16,16,9,21,26,12,8,11,8,11,16,3,11,8,13,16,11,16,16,2,9,16,8,10,10,8,29,16,21,17,10,27]

theorem envBound58871 : H12AffineFastState.Bounded env58871 := by
  intro p hp
  have h : env58871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58870_58871 : H12AffineEnvironment.transform 4 16 env58870 = env58871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58870 == env58871) = true)

def leafEnv58871 : List Nat := [2,4,8,16,16,16,9,21,26,12,8,11,8,11,16,3,11,8,13,16,11,16,16,2,28,9,1,16,8,10,10,8,29,16,21,17,4,3,10,27,1,10,0]

def active58871 : List Nat := [0,1,2,3]

def tree58871 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58871 : H12WitnessSearch.Good tree58871 := H12GlobalWitnessIndex.good

theorem leafIdentity58871 : H12AffineFastState.composeSystem env58871 rootObs = leafEnv58871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58871 rootObs == leafEnv58871) = true)

theorem terminalChecked58871 : H12PackedTerminal.terminalCheckFast leafEnv58871 active58871 tree58871 = true := by decide +kernel

def env58872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8388689,12980500,4176,131153,4294795,8463814,8462790,256,4292779,131073,33563273]

theorem envBound58872 : H12AffineFastState.Bounded env58872 := by
  intro p hp
  have h : env58872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58853_58872 : H12AffineEnvironment.transform 13 4177 env58853 = env58872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58853 == env58872) = true)

def env58873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304862,33554432,6329801,2524300,4176,131153,4294795,6402142,6403166,256,4292779,131073,33563273]

theorem envBound58873 : H12AffineFastState.Bounded env58873 := by
  intro p hp
  have h : env58873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58872_58873 : H12AffineEnvironment.transform 22 6329752 env58872 = env58873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329752 env58872 == env58873) = true)

def env58874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304862,4227080,6329801,2524300,4176,131153,4294795,6402142,6403166,256,4292779,131073,4235905]

theorem envBound58874 : H12AffineFastState.Bounded env58874 := by
  intro p hp
  have h : env58874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58873_58874 : H12AffineEnvironment.transform 24 4227080 env58873 = env58874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env58873 == env58874) = true)

def env58875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304862,4227081,6329801,2524300,4176,131153,4294795,6402142,6403166,256,4292779,131073,4235904]

theorem envBound58875 : H12AffineFastState.Bounded env58875 := by
  intro p hp
  have h : env58875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58873_58875 : H12AffineEnvironment.transform 24 4227081 env58873 = env58875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env58873 == env58875) = true)

theorem identity58875 : scanCanonicalize (H12AffineFastState.compose env58875 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41089) := by decide +kernel

theorem selectedBound58875 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,41089,2110745,2135263,8328,2110792,2524300,4176,131153,75786,2167007,2168031,256,73770,131073,513]

theorem envBound58876 : H12AffineFastState.Bounded env58876 := by
  intro p hp
  have h : env58876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58875_58876 : H12AffineEnvironment.transform 21 41089 env58875 = env58876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env58875 == env58876) = true)

theorem identity58876 : scanCanonicalize (H12AffineFastState.compose env58876 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 111830) := by decide +kernel

theorem selectedBound58876 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,111830,41089,98767,73737,8328,98718,471130,4176,131153,75786,41993,40969,256,73770,131073,513]

theorem envBound58877 : H12AffineFastState.Bounded env58877 := by
  intro p hp
  have h : env58877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58876_58877 : H12AffineEnvironment.transform 20 111830 env58876 = env58877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111830 env58876 == env58877) = true)

theorem identity58877 : scanCanonicalize (H12AffineFastState.compose env58877 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13576) := by decide +kernel

theorem selectedBound58877 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,13576,262144,1025,32768,111830,41089,98767,73737,8328,98718,329042,4176,13657,75786,41993,40969,256,73770,13577,513]

theorem envBound58878 : H12AffineFastState.Bounded env58878 := by
  intro p hp
  have h : env58878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58877_58878 : H12AffineEnvironment.transform 16 13576 env58877 = env58878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13576 env58877 == env58878) = true)

theorem identity58878 : scanCanonicalize (H12AffineFastState.compose env58878 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound58878 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,32802,13576,262144,1025,32768,13556,41089,493,41003,8328,444,296304,4176,13657,43048,41993,40969,256,40968,13577,513]

theorem envBound58879 : H12AffineFastState.Bounded env58879 := by
  intro p hp
  have h : env58879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58878_58879 : H12AffineEnvironment.transform 15 32802 env58878 = env58879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env58878 == env58879) = true)

theorem identity58879 : scanCanonicalize (H12AffineFastState.compose env58879 (packedSelected [0,1,4,5,6,7,8,9,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound58879 : packedSelected [0,1,4,5,6,7,8,9,24] rootPS < 2^1333 := by decide +kernel

def env58880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,8495,13576,262144,1025,8461,13556,396,493,294,8328,444,271485,4176,13657,2341,1284,260,256,261,13577,513]

theorem envBound58880 : H12AffineFastState.Bounded env58880 := by
  intro p hp
  have h : env58880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58879_58880 : H12AffineEnvironment.transform 14 8461 env58879 = env58880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env58879 == env58880) = true)

theorem identity58880 : scanCanonicalize (H12AffineFastState.compose env58880 (packedSelected [3,5,6,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 8000) := by decide +kernel

theorem selectedBound58880 : packedSelected [3,5,6,10,13,17] rootPS < 2^1333 := by decide +kernel

def env58881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8461,8495,13576,8000,1025,8461,13556,396,493,294,8328,444,15165,4176,13657,2341,1284,260,256,261,13577,513]

theorem envBound58881 : H12AffineFastState.Bounded env58881 := by
  intro p hp
  have h : env58881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58880_58881 : H12AffineEnvironment.transform 17 8000 env58880 = env58881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8000 env58880 == env58881) = true)

theorem identity58881 : scanCanonicalize (H12AffineFastState.compose env58881 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound58881 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env58882 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,4096,8192,4177,8461,8495,12928,6344,905,8461,13180,396,493,294,8328,444,15165,4176,13009,2341,652,260,256,261,12929,513]

theorem envBound58882 : H12AffineFastState.Bounded env58882 := by
  intro p hp
  have h : env58882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58881_58882 : H12AffineEnvironment.transform 9 904 env58881 = env58882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env58881 == env58882) = true)

theorem identity58882 : scanCanonicalize (H12AffineFastState.compose env58882 (packedSelected [6,25] rootPS)) = affineNative (2^(12+1) ^^^ 893) := by decide +kernel

theorem selectedBound58882 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58883 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,4096,893,4177,624,594,4605,6344,905,624,4097,396,493,294,1013,444,6208,4176,4524,2341,652,260,256,261,4604,513]

theorem envBound58883 : H12AffineFastState.Bounded env58883 := by
  intro p hp
  have h : env58883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58882_58883 : H12AffineEnvironment.transform 12 893 env58882 = env58883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 893 env58882 == env58883) = true)

theorem identity58883 : scanCanonicalize (H12AffineFastState.compose env58883 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound58883 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58884 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,492,893,445,624,594,17,2340,905,624,493,396,493,294,1013,444,2476,444,64,2341,652,260,256,261,16,513]

theorem envBound58884 : H12AffineFastState.Bounded env58884 := by
  intro p hp
  have h : env58884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58883_58884 : H12AffineEnvironment.transform 11 492 env58883 = env58884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env58883 == env58884) = true)

theorem identity58884 : scanCanonicalize (H12AffineFastState.compose env58884 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound58884 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58885 : List Nat := [2,4,8,16,32,64,128,256,217,337,2048,492,420,445,169,139,17,2340,336,169,493,396,493,294,300,444,2476,444,64,2341,85,260,256,261,16,216]

theorem envBound58885 : H12AffineFastState.Bounded env58885 := by
  intro p hp
  have h : env58885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58884_58885 : H12AffineEnvironment.transform 8 217 env58884 = env58885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env58884 == env58885) = true)

theorem identity58885 : scanCanonicalize (H12AffineFastState.compose env58885 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound58885 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env58886 : List Nat := [2,4,8,16,32,27,128,256,130,266,2048,439,420,445,169,139,17,2340,267,169,438,396,438,294,300,444,2476,444,27,2341,14,260,256,261,16,131]

theorem envBound58886 : H12AffineFastState.Bounded env58886 := by
  intro p hp
  have h : env58886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58885_58886 : H12AffineEnvironment.transform 5 27 env58885 = env58886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env58885 == env58886) = true)

def env58887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304863,33554432,6329800,2524301,4176,131153,4294795,6402143,6403167,256,4292779,131073,33563273]

theorem envBound58887 : H12AffineFastState.Bounded env58887 := by
  intro p hp
  have h : env58887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58872_58887 : H12AffineEnvironment.transform 22 6329753 env58872 = env58887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329753 env58872 == env58887) = true)

def env58888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304863,4227080,6329800,2524301,4176,131153,4294795,6402143,6403167,256,4292779,131073,4235905]

theorem envBound58888 : H12AffineFastState.Bounded env58888 := by
  intro p hp
  have h : env58888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58887_58888 : H12AffineEnvironment.transform 24 4227080 env58887 = env58888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227080 env58887 == env58888) = true)

def env58889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,4194304,6329753,6304863,4227081,6329800,2524301,4176,131153,4294795,6402143,6403167,256,4292779,131073,4235904]

theorem envBound58889 : H12AffineFastState.Bounded env58889 := by
  intro p hp
  have h : env58889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58887_58889 : H12AffineEnvironment.transform 24 4227081 env58887 = env58889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4227081 env58887 == env58889) = true)

theorem identity58889 : scanCanonicalize (H12AffineFastState.compose env58889 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41089) := by decide +kernel

theorem selectedBound58889 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,2097152,41089,2110744,2135262,8328,2110793,2524301,4176,131153,75786,2167006,2168030,256,73770,131073,513]

theorem envBound58890 : H12AffineFastState.Bounded env58890 := by
  intro p hp
  have h : env58890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58889_58890 : H12AffineEnvironment.transform 21 41089 env58889 = env58890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env58889 == env58890) = true)

theorem identity58890 : scanCanonicalize (H12AffineFastState.compose env58890 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 111831) := by decide +kernel

theorem selectedBound58890 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,111831,41089,98767,73737,8328,98718,471130,4176,131153,75786,41993,40969,256,73770,131073,513]

theorem envBound58891 : H12AffineFastState.Bounded env58891 := by
  intro p hp
  have h : env58891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58890_58891 : H12AffineEnvironment.transform 20 111831 env58890 = env58891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 111831 env58890 == env58891) = true)

theorem identity58891 : scanCanonicalize (H12AffineFastState.compose env58891 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 13577) := by decide +kernel

theorem selectedBound58891 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,13577,262144,1025,32768,111831,41089,98767,73737,8328,98718,329043,4176,13656,75786,41993,40969,256,73770,13576,513]

theorem envBound58892 : H12AffineFastState.Bounded env58892 := by
  intro p hp
  have h : env58892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58891_58892 : H12AffineEnvironment.transform 16 13577 env58891 = env58892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13577 env58891 == env58892) = true)

theorem identity58892 : scanCanonicalize (H12AffineFastState.compose env58892 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 1529) := by decide +kernel

theorem selectedBound58892 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,1529,65536,13577,262144,1025,1529,78126,9592,66614,73737,8328,66663,329043,4176,13656,75786,8688,9712,256,73770,13576,513]

theorem envBound58893 : H12AffineFastState.Bounded env58893 := by
  intro p hp
  have h : env58893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58892_58893 : H12AffineEnvironment.transform 14 1529 env58892 = env58893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1529 env58892 == env58893) = true)

theorem identity58893 : scanCanonicalize (H12AffineFastState.compose env58893 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(9+1) ^^^ 904) := by decide +kernel

theorem selectedBound58893 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env58894 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,4096,8192,4177,625,65536,12929,262144,905,625,78126,8944,66494,73737,8328,66543,328411,4176,13008,75786,8688,8824,256,73770,12928,513]

theorem envBound58894 : H12AffineFastState.Bounded env58894 := by
  intro p hp
  have h : env58894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58893_58894 : H12AffineEnvironment.transform 9 904 env58893 = env58894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 904 env58893 == env58894) = true)

theorem identity58894 : scanCanonicalize (H12AffineFastState.compose env58894 (packedSelected [0,3,4,5,6,7,9,10,13,17,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound58894 : packedSelected [0,3,4,5,6,7,9,10,13,17,18,23] rootPS < 2^1333 := by decide +kernel

def env58895 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,4096,8192,4177,625,65536,12929,2340,905,625,78126,8944,66494,73737,8328,66543,68607,4176,13008,75786,8688,8824,256,73770,12928,513]

theorem envBound58895 : H12AffineFastState.Bounded env58895 := by
  intro p hp
  have h : env58895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58894_58895 : H12AffineEnvironment.transform 17 2340 env58894 = env58895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env58894 == env58895) = true)

theorem identity58895 : scanCanonicalize (H12AffineFastState.compose env58895 (packedSelected [0,3,4,5,7,9,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound58895 : packedSelected [0,3,4,5,7,9,10,13,17] rootPS < 2^1333 := by decide +kernel

def env58896 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,492,8192,445,625,65536,9069,2340,905,625,73922,8944,66494,73737,8328,66543,68607,444,9020,75786,8688,8824,256,73770,9068,513]

theorem envBound58896 : H12AffineFastState.Bounded env58896 := by
  intro p hp
  have h : env58896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58895_58896 : H12AffineEnvironment.transform 11 492 env58895 = env58896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env58895 == env58896) = true)

theorem identity58896 : scanCanonicalize (H12AffineFastState.compose env58896 (packedSelected [1,5,6,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 892) := by decide +kernel

theorem selectedBound58896 : packedSelected [1,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env58897 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,492,892,445,625,65536,17,2340,905,625,66494,396,66494,66421,1012,66543,68607,444,64,68470,652,260,256,66390,16,513]

theorem envBound58897 : H12AffineFastState.Bounded env58897 := by
  intro p hp
  have h : env58897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58896_58897 : H12AffineEnvironment.transform 12 892 env58896 = env58897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 892 env58896 == env58897) = true)

theorem identity58897 : scanCanonicalize (H12AffineFastState.compose env58897 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 594) := by decide +kernel

theorem selectedBound58897 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58898 : List Nat := [2,4,8,16,32,64,128,256,512,904,2048,492,892,445,625,594,17,2340,905,625,492,396,492,295,1012,445,2477,444,64,2340,652,260,256,260,16,513]

theorem envBound58898 : H12AffineFastState.Bounded env58898 := by
  intro p hp
  have h : env58898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58897_58898 : H12AffineEnvironment.transform 15 594 env58897 = env58898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 594 env58897 == env58898) = true)

theorem identity58898 : scanCanonicalize (H12AffineFastState.compose env58898 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58898 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58899 : List Nat := [2,4,8,16,32,64,128,172,512,548,2048,64,720,17,625,594,17,2184,549,625,64,32,64,139,600,17,2049,16,64,2184,652,168,172,168,16,513]

theorem envBound58899 : H12AffineFastState.Bounded env58899 := by
  intro p hp
  have h : env58899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58898_58899 : H12AffineEnvironment.transform 7 172 env58898 = env58899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58898 == env58899) = true)

theorem identity58899 : scanCanonicalize (H12AffineFastState.compose env58899 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound58899 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58900 : List Nat := [2,4,8,16,32,64,128,172,49,21,2048,64,225,17,64,99,17,2184,20,64,64,32,64,139,105,17,2049,16,64,2184,189,168,172,168,16,48]

theorem envBound58900 : H12AffineFastState.Bounded env58900 := by
  intro p hp
  have h : env58900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58899_58900 : H12AffineEnvironment.transform 8 49 env58899 = env58900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58899 == env58900) = true)

theorem identity58900 : scanCanonicalize (H12AffineFastState.compose env58900 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound58900 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58901 : List Nat := [2,4,8,16,32,64,128,172,49,21,64,64,225,17,64,99,17,200,20,64,64,32,64,139,105,17,65,16,64,200,189,168,172,168,16,48]

theorem envBound58901 : H12AffineFastState.Bounded env58901 := by
  intro p hp
  have h : env58901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58900_58901 : H12AffineEnvironment.transform 10 64 env58900 = env58901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env58900 == env58901) = true)

theorem identity58901 : scanCanonicalize (H12AffineFastState.compose env58901 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound58901 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58902 : List Nat := [2,4,8,16,32,27,128,172,49,21,27,27,186,17,27,56,17,147,20,27,27,32,27,139,50,17,26,16,27,147,189,168,172,168,16,48]

theorem envBound58902 : H12AffineFastState.Bounded env58902 := by
  intro p hp
  have h : env58902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58901_58902 : H12AffineEnvironment.transform 5 27 env58901 = env58902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env58901 == env58902) = true)

theorem identity58902 : scanCanonicalize (H12AffineFastState.compose env58902 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound58902 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58903 : List Nat := [2,4,8,16,32,27,3,47,49,21,27,27,57,17,27,56,17,16,20,27,27,32,27,8,50,17,26,16,27,16,62,43,47,43,16,48]

theorem envBound58903 : H12AffineFastState.Bounded env58903 := by
  intro p hp
  have h : env58903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58902_58903 : H12AffineEnvironment.transform 6 3 env58902 = env58903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env58902 == env58903) = true)

theorem identity58903 : scanCanonicalize (H12AffineFastState.compose env58903 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58903 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58904 : List Nat := [2,4,8,16,16,27,3,31,1,21,27,27,9,17,27,8,17,16,20,27,27,16,27,8,2,17,26,16,27,16,14,27,31,27,16,0]

theorem envBound58904 : H12AffineFastState.Bounded env58904 := by
  intro p hp
  have h : env58904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58903_58904 : H12AffineEnvironment.transform 4 16 env58903 = env58904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58903 == env58904) = true)

theorem identity58904 : scanCanonicalize (H12AffineFastState.compose env58904 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58904 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58905 : List Nat := [2,4,0,16,16,19,3,23,1,21,19,19,1,17,19,0,17,16,20,19,19,16,19,0,2,17,18,16,19,16,6,19,23,19,16,0]

theorem envBound58905 : H12AffineFastState.Bounded env58905 := by
  intro p hp
  have h : env58905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58904_58905 : H12AffineEnvironment.transform 2 0 env58904 = env58905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58904 == env58905) = true)

theorem identity58905 : scanCanonicalize (H12AffineFastState.compose env58905 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58905 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58906 : List Nat := [0,4,0,16,16,17,1,21,1,21,17,17,1,17,17,0,17,16,20,17,17,16,17,0,0,17,16,16,17,16,4,17,21,17,16,0]

theorem envBound58906 : H12AffineFastState.Bounded env58906 := by
  intro p hp
  have h : env58906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58905_58906 : H12AffineEnvironment.transform 0 0 env58905 = env58906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58905 == env58906) = true)

theorem identity58906 : scanCanonicalize (H12AffineFastState.compose env58906 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound58906 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env58907 : List Nat := [0,4,0,1,1,0,1,4,1,4,0,0,1,0,0,0,0,1,5,0,0,1,0,0,0,0,1,1,0,1,4,0,4,0,1,0]

theorem envBound58907 : H12AffineFastState.Bounded env58907 := by
  intro p hp
  have h : env58907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58906_58907 : H12AffineEnvironment.transform 3 1 env58906 = env58907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58906 == env58907) = true)

def env58908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8955335,33554432,8409089,134217728,16385,656465,4840666,8463814,4294967296,525569,4307611965,34359738368,33563273]

theorem envBound58908 : H12AffineFastState.Bounded env58908 := by
  intro p hp
  have h : env58908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58636_58908 : H12AffineEnvironment.transform 25 8409089 env58636 = env58908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8409089 env58636 == env58908) = true)

def env58909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131153,4315354,8463814,4294967296,257,4307611965,34359738368,33563273]

theorem envBound58909 : H12AffineFastState.Bounded env58909 := by
  intro p hp
  have h : env58909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58908_58909 : H12AffineEnvironment.transform 18 1024 env58908 = env58909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env58908 == env58909) = true)

def env58910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131153,4315354,8463814,4294967296,257,4307611965,131072,33563273]

theorem envBound58910 : H12AffineFastState.Bounded env58910 := by
  intro p hp
  have h : env58910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58909_58910 : H12AffineEnvironment.transform 34 131072 env58909 = env58910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env58909 == env58910) = true)

theorem identity58910 : scanCanonicalize (H12AffineFastState.compose env58910 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 140846483) := by decide +kernel

theorem selectedBound58910 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131153,4315354,8463814,140846483,257,145085614,131072,33563273]

theorem envBound58911 : H12AffineFastState.Bounded env58911 := by
  intro p hp
  have h : env58911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58910_58911 : H12AffineEnvironment.transform 31 140846483 env58910 = env58911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 140846483 env58910 == env58911) = true)

theorem identity58911 : scanCanonicalize (H12AffineFastState.compose env58911 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound58911 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8388689,134217728,4177,131153,4294794,8463814,140846483,257,145065214,131072,33563273]

theorem envBound58912 : H12AffineFastState.Bounded env58912 := by
  intro p hp
  have h : env58912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58911_58912 : H12AffineEnvironment.transform 13 4176 env58911 = env58912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58911 == env58912) = true)

theorem identity58912 : scanCanonicalize (H12AffineFastState.compose env58912 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound58912 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env58913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388689,134217728,4177,131153,4294794,8463814,140846483,257,145065214,131072,513]

theorem envBound58913 : H12AffineFastState.Bounded env58913 := by
  intro p hp
  have h : env58913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58912_58913 : H12AffineEnvironment.transform 24 8328 env58912 = env58913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env58912 == env58913) = true)

theorem identity58913 : scanCanonicalize (H12AffineFastState.compose env58913 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724554) := by decide +kernel

theorem selectedBound58913 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388689,8724554,4177,131153,4294794,8463814,14681561,257,2139316,131072,513]

theorem envBound58914 : H12AffineFastState.Bounded env58914 := by
  intro p hp
  have h : env58914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58913_58914 : H12AffineEnvironment.transform 26 8724554 env58913 = env58914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724554 env58913 == env58914) = true)

theorem identity58914 : scanCanonicalize (H12AffineFastState.compose env58914 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58914 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,4194304,8388608,8430023,8328,8388689,8724554,4177,131153,4294794,8463814,12588505,257,46260,131072,513]

theorem envBound58915 : H12AffineFastState.Bounded env58915 := by
  intro p hp
  have h : env58915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58914_58915 : H12AffineEnvironment.transform 20 4096 env58914 = env58915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env58914 == env58915) = true)

theorem identity58915 : scanCanonicalize (H12AffineFastState.compose env58915 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4370576) := by decide +kernel

theorem selectedBound58915 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env58916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,4194304,4370576,4329815,8328,4370625,4690138,4177,131153,4294794,4429142,173385,257,46260,131072,513]

theorem envBound58916 : H12AffineFastState.Bounded env58916 := by
  intro p hp
  have h : env58916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58915_58916 : H12AffineEnvironment.transform 22 4370576 env58915 = env58916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4370576 env58915 == env58916) = true)

theorem identity58916 : scanCanonicalize (H12AffineFastState.compose env58916 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound58916 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env58917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,396,176412,135387,8328,176461,495958,4177,131153,100614,234714,173385,257,46260,131072,513]

theorem envBound58917 : H12AffineFastState.Bounded env58917 := by
  intro p hp
  have h : env58917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58916_58917 : H12AffineEnvironment.transform 21 396 env58916 = env58917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env58916 == env58917) = true)

theorem identity58917 : scanCanonicalize (H12AffineFastState.compose env58917 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound58917 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,65536,131072,262144,1024,8460,4096,396,135184,135387,8328,135233,471130,4177,131153,75786,210390,132165,257,5560,131072,513]

theorem envBound58918 : H12AffineFastState.Bounded env58918 := by
  intro p hp
  have h : env58918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58917_58918 : H12AffineEnvironment.transform 14 8460 env58917 = env58918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env58917 == env58918) = true)

theorem identity58918 : scanCanonicalize (H12AffineFastState.compose env58918 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13423) := by decide +kernel

theorem selectedBound58918 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,13423,131072,262144,1024,8460,4096,396,135184,135387,8328,135233,394293,4177,131153,7269,131513,132165,257,5560,131072,513]

theorem envBound58919 : H12AffineFastState.Bounded env58919 := by
  intro p hp
  have h : env58919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58918_58919 : H12AffineEnvironment.transform 15 13423 env58918 = env58919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13423 env58918 == env58919) = true)

theorem identity58919 : scanCanonicalize (H12AffineFastState.compose env58919 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 7268) := by decide +kernel

theorem selectedBound58919 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8460,13423,131072,7268,1024,8460,4096,396,135184,135387,8328,135233,137297,4177,131153,7269,131513,132165,257,5560,131072,513]

theorem envBound58920 : H12AffineFastState.Bounded env58920 := by
  intro p hp
  have h : env58920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58919_58920 : H12AffineEnvironment.transform 17 7268 env58919 = env58920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7268 env58919 == env58920) = true)

theorem identity58920 : scanCanonicalize (H12AffineFastState.compose env58920 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound58920 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58921 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4176,8353,13423,131072,7268,1024,8353,4096,33,135184,135387,8328,135233,137297,4177,131153,7269,131092,132165,172,5141,131072,513]

theorem envBound58921 : H12AffineFastState.Bounded env58921 := by
  intro p hp
  have h : env58921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58920_58921 : H12AffineEnvironment.transform 7 173 env58920 = env58921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58920 == env58921) = true)

theorem identity58921 : scanCanonicalize (H12AffineFastState.compose env58921 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 4177) := by decide +kernel

theorem selectedBound58921 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58922 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4176,8353,13423,4177,7268,1024,8353,4096,33,65,138,8328,16,2048,4177,4096,7269,4165,5140,172,5141,4177,513]

theorem envBound58922 : H12AffineFastState.Bounded env58922 := by
  intro p hp
  have h : env58922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58921_58922 : H12AffineEnvironment.transform 16 4177 env58921 = env58922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4177 env58921 == env58922) = true)

theorem identity58922 : scanCanonicalize (H12AffineFastState.compose env58922 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58922 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58923 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,8353,13374,4096,7221,1024,8353,4096,33,16,138,8328,16,2048,4096,4096,7220,4116,5140,172,5141,4096,513]

theorem envBound58923 : H12AffineFastState.Bounded env58923 := by
  intro p hp
  have h : env58923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58922_58923 : H12AffineEnvironment.transform 5 17 env58922 = env58923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58922 == env58923) = true)

theorem identity58923 : scanCanonicalize (H12AffineFastState.compose env58923 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound58923 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env58924 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8,4097,169,5174,4096,7221,1024,169,4096,33,16,138,128,16,2048,4096,4096,7220,4116,5140,172,5141,4096,513]

theorem envBound58924 : H12AffineFastState.Bounded env58924 := by
  intro p hp
  have h : env58924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58923_58924 : H12AffineEnvironment.transform 12 8 env58923 = env58924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env58923 == env58924) = true)

theorem identity58924 : scanCanonicalize (H12AffineFastState.compose env58924 (packedSelected [0,1,4] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound58924 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58925 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2074,8,2075,169,3116,2074,1071,1024,169,2074,33,16,138,128,16,2048,2074,2074,1070,2062,3086,172,3087,2074,513]

theorem envBound58925 : H12AffineFastState.Bounded env58925 := by
  intro p hp
  have h : env58925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58924_58925 : H12AffineEnvironment.transform 11 2074 env58924 = env58925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env58924 == env58925) = true)

theorem identity58925 : scanCanonicalize (H12AffineFastState.compose env58925 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58925 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env58926 : List Nat := [2,4,8,11,32,10,128,173,512,1024,2048,2049,8,2048,169,3116,2049,1071,1024,169,2049,33,11,138,128,11,2048,2049,2049,1070,2062,3086,172,3087,2049,513]

theorem envBound58926 : H12AffineFastState.Bounded env58926 := by
  intro p hp
  have h : env58926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58925_58926 : H12AffineEnvironment.transform 3 11 env58925 = env58926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58925 == env58926) = true)

theorem identity58926 : scanCanonicalize (H12AffineFastState.compose env58926 (packedSelected [1,2,10] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound58926 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env58927 : List Nat := [2,4,8,11,32,10,128,173,512,548,2048,2049,8,2048,169,2568,2049,523,548,169,2049,33,11,138,128,11,2048,2049,2049,522,2062,2602,172,2603,2049,513]

theorem envBound58927 : H12AffineFastState.Bounded env58927 := by
  intro p hp
  have h : env58927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58926_58927 : H12AffineEnvironment.transform 9 548 env58926 = env58927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env58926 == env58927) = true)

theorem identity58927 : scanCanonicalize (H12AffineFastState.compose env58927 (packedSelected [2,13] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound58927 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env58928 : List Nat := [2,4,8,11,32,10,128,173,512,548,130,131,8,130,169,650,131,523,548,169,131,33,11,138,128,11,130,131,131,522,140,680,172,681,131,513]

theorem envBound58928 : H12AffineFastState.Bounded env58928 := by
  intro p hp
  have h : env58928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58927_58928 : H12AffineEnvironment.transform 10 130 env58927 = env58928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env58927 == env58928) = true)

def env58929 : List Nat := [2,4,8,11,32,10,128,173,0,36,130,131,8,130,169,138,131,11,36,169,131,33,11,138,128,11,130,131,131,10,140,168,172,169,131,1]

theorem envBound58929 : H12AffineFastState.Bounded env58929 := by
  intro p hp
  have h : env58929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58928_58929 : H12AffineEnvironment.transform 8 0 env58928 = env58929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58928 == env58929) = true)

theorem identity58929 : scanCanonicalize (H12AffineFastState.compose env58929 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58929 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58930 : List Nat := [2,4,8,11,10,10,128,135,0,14,130,131,8,130,131,138,131,11,14,131,131,11,11,138,128,11,130,131,131,10,140,130,134,131,131,1]

theorem envBound58930 : H12AffineFastState.Bounded env58930 := by
  intro p hp
  have h : env58930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58929_58930 : H12AffineEnvironment.transform 4 10 env58929 = env58930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58929 == env58930) = true)

theorem identity58930 : scanCanonicalize (H12AffineFastState.compose env58930 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58931 : List Nat := [2,4,1,2,3,3,128,135,0,7,130,131,1,130,131,131,131,2,7,131,131,2,2,131,128,2,130,131,131,3,133,130,134,131,131,1]

theorem envBound58931 : H12AffineFastState.Bounded env58931 := by
  intro p hp
  have h : env58931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58930_58931 : H12AffineEnvironment.transform 2 1 env58930 = env58931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58930 == env58931) = true)

def env58932 : List Nat := [2,4,8,11,32,10,128,173,1,37,130,131,8,130,169,139,131,10,37,169,131,33,11,138,128,11,130,131,131,11,140,169,172,168,131,0]

theorem envBound58932 : H12AffineFastState.Bounded env58932 := by
  intro p hp
  have h : env58932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58928_58932 : H12AffineEnvironment.transform 8 1 env58928 = env58932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58928 == env58932) = true)

theorem identity58932 : scanCanonicalize (H12AffineFastState.compose env58932 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound58932 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58933 : List Nat := [2,4,8,11,32,10,35,14,1,37,33,32,8,33,10,40,32,10,37,10,32,33,11,41,35,11,33,32,32,11,47,10,15,11,32,0]

theorem envBound58933 : H12AffineFastState.Bounded env58933 := by
  intro p hp
  have h : env58933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58932_58933 : H12AffineEnvironment.transform 6 35 env58932 = env58933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env58932 == env58933) = true)

theorem identity58933 : scanCanonicalize (H12AffineFastState.compose env58933 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound58933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58934 : List Nat := [2,4,8,11,9,10,10,14,1,12,8,9,8,8,10,1,9,10,12,10,9,8,11,0,10,11,8,9,9,11,6,10,15,11,9,0]

theorem envBound58934 : H12AffineFastState.Bounded env58934 := by
  intro p hp
  have h : env58934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58933_58934 : H12AffineEnvironment.transform 4 9 env58933 = env58934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env58933 == env58934) = true)

def leafEnv58934 : List Nat := [2,4,8,11,9,10,10,14,1,12,8,9,8,8,10,1,9,10,12,10,9,8,11,0,7,10,1,11,8,9,9,11,6,10,15,11,4,3,9,0,1,9,0]

def active58934 : List Nat := [0,1,2]

def tree58934 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58934 : H12WitnessSearch.Good tree58934 := H12GlobalWitnessIndex.good

theorem leafIdentity58934 : H12AffineFastState.composeSystem env58934 rootObs = leafEnv58934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58934 rootObs == leafEnv58934) = true)

theorem terminalChecked58934 : H12PackedTerminal.terminalCheckFast leafEnv58934 active58934 tree58934 = true := by decide +kernel

def env58935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131153,4315354,8463814,4294967296,257,4307611965,131073,33563273]

theorem envBound58935 : H12AffineFastState.Bounded env58935 := by
  intro p hp
  have h : env58935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58909_58935 : H12AffineEnvironment.transform 34 131073 env58909 = env58935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env58909 == env58935) = true)

theorem identity58935 : scanCanonicalize (H12AffineFastState.compose env58935 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 138753426) := by decide +kernel

theorem selectedBound58935 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131153,4315354,8463814,138753426,257,142984367,131073,33563273]

theorem envBound58936 : H12AffineFastState.Bounded env58936 := by
  intro p hp
  have h : env58936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58935_58936 : H12AffineEnvironment.transform 31 138753426 env58935 = env58936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 138753426 env58935 == env58936) = true)

theorem identity58936 : scanCanonicalize (H12AffineFastState.compose env58936 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12919238) := by decide +kernel

theorem selectedBound58936 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,33554432,8409089,12919238,16385,131153,4315354,8463814,8393812,257,4253033,131073,33563273]

theorem envBound58937 : H12AffineFastState.Bounded env58937 := by
  intro p hp
  have h : env58937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58936_58937 : H12AffineEnvironment.transform 26 12919238 env58936 = env58937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12919238 env58936 == env58937) = true)

theorem identity58937 : scanCanonicalize (H12AffineFastState.compose env58937 (packedSelected [6,13,17,21,25,33] rootPS)) = affineNative (2^(24+1) ^^^ 28888) := by decide +kernel

theorem selectedBound58937 : packedSelected [6,13,17,21,25,33] rootPS < 2^1333 := by decide +kernel

def env58938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,28888,8409089,12919238,16385,131153,4315354,8463814,8393812,257,4253033,131073,21073]

theorem envBound58938 : H12AffineFastState.Bounded env58938 := by
  intro p hp
  have h : env58938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58937_58938 : H12AffineEnvironment.transform 24 28888 env58937 = env58938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 28888 env58937 == env58938) = true)

def env58939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8328,8388689,12919238,4177,131153,4294794,8463814,8393812,257,4240697,131073,513]

theorem envBound58939 : H12AffineFastState.Bounded env58939 := by
  intro p hp
  have h : env58939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58938_58939 : H12AffineEnvironment.transform 13 4176 env58938 = env58939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58938 == env58939) = true)

theorem identity58939 : scanCanonicalize (H12AffineFastState.compose env58939 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound58939 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,2097152,396,8388608,8430023,8328,8388689,8724554,4177,131153,100614,8463814,8393812,257,46261,131073,513]

theorem envBound58940 : H12AffineFastState.Bounded env58940 := by
  intro p hp
  have h : env58940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58939_58940 : H12AffineEnvironment.transform 21 396 env58939 = env58940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env58939 == env58940) = true)

theorem identity58940 : scanCanonicalize (H12AffineFastState.compose env58940 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58940 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,396,8388608,8430023,8328,8388689,8724554,4177,131153,100614,8463814,8393812,257,46261,131073,513]

theorem envBound58941 : H12AffineFastState.Bounded env58941 := by
  intro p hp
  have h : env58941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58940_58941 : H12AffineEnvironment.transform 20 4096 env58940 = env58941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env58940 == env58941) = true)

theorem identity58941 : scanCanonicalize (H12AffineFastState.compose env58941 (packedSelected [13,21] rootPS)) = affineNative (2^(22+1) ^^^ 176412) := by decide +kernel

theorem selectedBound58941 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4096,396,176412,135387,8328,176461,495958,4177,131153,100614,234714,173384,257,46261,131073,513]

theorem envBound58942 : H12AffineFastState.Bounded env58942 := by
  intro p hp
  have h : env58942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58941_58942 : H12AffineEnvironment.transform 22 176412 env58941 = env58942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 176412 env58941 == env58942) = true)

theorem identity58942 : scanCanonicalize (H12AffineFastState.compose env58942 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound58942 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,65536,131072,262144,1024,8461,4096,396,135185,135387,8328,135232,471131,4177,131153,75787,210391,132165,257,5560,131073,513]

theorem envBound58943 : H12AffineFastState.Bounded env58943 := by
  intro p hp
  have h : env58943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58942_58943 : H12AffineEnvironment.transform 14 8461 env58942 = env58943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env58942 == env58943) = true)

theorem identity58943 : scanCanonicalize (H12AffineFastState.compose env58943 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 13422) := by decide +kernel

theorem selectedBound58943 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env58944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,13422,131072,262144,1024,8461,4096,396,135185,135387,8328,135232,394293,4177,131153,7269,131513,132165,257,5560,131073,513]

theorem envBound58944 : H12AffineFastState.Bounded env58944 := by
  intro p hp
  have h : env58944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58943_58944 : H12AffineEnvironment.transform 15 13422 env58943 = env58944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13422 env58943 == env58944) = true)

theorem identity58944 : scanCanonicalize (H12AffineFastState.compose env58944 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 134196) := by decide +kernel

theorem selectedBound58944 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env58945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,8461,13422,131072,134196,1024,8461,4096,396,135185,135387,8328,135232,2049,4177,131153,7269,131513,132165,257,5560,131073,513]

theorem envBound58945 : H12AffineFastState.Bounded env58945 := by
  intro p hp
  have h : env58945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58944_58945 : H12AffineEnvironment.transform 17 134196 env58944 = env58945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 134196 env58944 == env58945) = true)

theorem identity58945 : scanCanonicalize (H12AffineFastState.compose env58945 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound58945 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58946 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,4176,8352,13422,131072,134196,1024,8352,4096,33,135185,135387,8328,135232,2049,4177,131153,7269,131092,132165,172,5141,131073,513]

theorem envBound58946 : H12AffineFastState.Bounded env58946 := by
  intro p hp
  have h : env58946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58945_58946 : H12AffineEnvironment.transform 7 173 env58945 = env58946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58945 == env58946) = true)

theorem identity58946 : scanCanonicalize (H12AffineFastState.compose env58946 (packedSelected [0,2,3,6,7,8,10,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2267) := by decide +kernel

theorem selectedBound58946 : packedSelected [0,2,3,6,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env58947 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,2267,4176,2171,7349,131072,134196,1024,2171,4096,33,135185,135387,2131,135232,2049,4177,131153,7269,131092,132165,172,5141,131073,513]

theorem envBound58947 : H12AffineFastState.Bounded env58947 := by
  intro p hp
  have h : env58947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58946_58947 : H12AffineEnvironment.transform 12 2267 env58946 = env58947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2267 env58946 == env58947) = true)

theorem identity58947 : scanCanonicalize (H12AffineFastState.compose env58947 (packedSelected [0,2,3,7,8,10,11,15] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound58947 : packedSelected [0,2,3,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env58948 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,2267,4176,2171,7349,4096,7220,1024,2171,4096,33,17,219,2131,64,2049,4177,4177,7269,4116,5189,172,5141,4097,513]

theorem envBound58948 : H12AffineFastState.Bounded env58948 := by
  intro p hp
  have h : env58948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58947_58948 : H12AffineEnvironment.transform 16 4096 env58947 = env58948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env58947 == env58948) = true)

theorem identity58948 : scanCanonicalize (H12AffineFastState.compose env58948 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound58948 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58949 : List Nat := [2,4,8,16,32,64,128,173,512,1024,130,4096,89,4176,249,5175,4096,5302,1024,249,4096,33,17,219,209,64,131,4177,4177,5351,4116,5189,172,5141,4097,513]

theorem envBound58949 : H12AffineFastState.Bounded env58949 := by
  intro p hp
  have h : env58949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58948_58949 : H12AffineEnvironment.transform 10 130 env58948 = env58949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env58948 == env58949) = true)

theorem identity58949 : scanCanonicalize (H12AffineFastState.compose env58949 (packedSelected [0,1,2,3,4,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 182) := by decide +kernel

theorem selectedBound58949 : packedSelected [0,1,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env58950 : List Nat := [2,4,8,16,32,64,128,173,512,182,130,4096,89,4176,249,4225,4096,4096,182,249,4096,33,17,219,209,64,131,4177,4177,4177,4116,4339,172,4259,4097,513]

theorem envBound58950 : H12AffineFastState.Bounded env58950 := by
  intro p hp
  have h : env58950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58949_58950 : H12AffineEnvironment.transform 9 182 env58949 = env58950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 182 env58949 == env58950) = true)

theorem identity58950 : scanCanonicalize (H12AffineFastState.compose env58950 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 194) := by decide +kernel

theorem selectedBound58950 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env58951 : List Nat := [2,4,8,16,32,64,128,173,194,182,130,4096,89,4176,249,4225,4096,4096,182,249,4096,33,17,219,209,64,131,4177,4177,4177,4116,4339,172,4259,4097,195]

theorem envBound58951 : H12AffineFastState.Bounded env58951 := by
  intro p hp
  have h : env58951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58950_58951 : H12AffineEnvironment.transform 8 194 env58950 = env58951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 194 env58950 == env58951) = true)

theorem identity58951 : scanCanonicalize (H12AffineFastState.compose env58951 (packedSelected [5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58951 : packedSelected [5,8,11] rootPS < 2^1333 := by decide +kernel

def env58952 : List Nat := [2,4,8,16,32,17,128,173,147,182,130,4096,8,4097,168,4225,4096,4096,182,168,4096,33,17,138,128,17,131,4096,4096,4096,4116,4258,172,4259,4097,146]

theorem envBound58952 : H12AffineFastState.Bounded env58952 := by
  intro p hp
  have h : env58952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58951_58952 : H12AffineEnvironment.transform 5 17 env58951 = env58952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58951 == env58952) = true)

theorem identity58952 : scanCanonicalize (H12AffineFastState.compose env58952 (packedSelected [0,1,4] rootPS)) = affineNative (2^(11+1) ^^^ 10) := by decide +kernel

theorem selectedBound58952 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58953 : List Nat := [2,4,8,16,32,17,128,173,147,182,130,10,8,11,168,139,10,10,182,168,10,33,17,138,128,17,131,10,10,10,30,168,172,169,11,146]

theorem envBound58953 : H12AffineFastState.Bounded env58953 := by
  intro p hp
  have h : env58953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58952_58953 : H12AffineEnvironment.transform 11 10 env58952 = env58953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 10 env58952 == env58953) = true)

theorem identity58953 : scanCanonicalize (H12AffineFastState.compose env58953 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound58953 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58954 : List Nat := [2,4,8,16,32,17,18,63,1,36,16,10,8,11,58,25,10,10,36,58,10,33,17,24,18,17,17,10,10,10,30,58,62,59,11,0]

theorem envBound58954 : H12AffineFastState.Bounded env58954 := by
  intro p hp
  have h : env58954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58953_58954 : H12AffineEnvironment.transform 6 18 env58953 = env58954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env58953 == env58954) = true)

theorem identity58954 : scanCanonicalize (H12AffineFastState.compose env58954 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58954 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58955 : List Nat := [2,4,8,16,10,17,18,21,1,14,16,10,8,11,16,25,10,10,14,16,10,11,17,24,18,17,17,10,10,10,30,16,20,17,11,0]

theorem envBound58955 : H12AffineFastState.Bounded env58955 := by
  intro p hp
  have h : env58955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58954_58955 : H12AffineEnvironment.transform 4 10 env58954 = env58955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58954 == env58955) = true)

theorem identity58955 : scanCanonicalize (H12AffineFastState.compose env58955 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound58955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58956 : List Nat := [2,4,8,8,10,9,10,13,1,14,8,10,8,11,8,1,10,10,14,8,10,11,9,0,10,9,9,10,10,10,6,8,12,9,11,0]

theorem envBound58956 : H12AffineFastState.Bounded env58956 := by
  intro p hp
  have h : env58956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58955_58956 : H12AffineEnvironment.transform 3 8 env58955 = env58956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env58955 == env58956) = true)

def leafEnv58956 : List Nat := [2,4,8,8,10,9,10,13,1,14,8,10,8,11,8,1,10,10,14,8,10,11,9,0,7,10,1,9,9,10,10,10,6,8,12,9,4,3,11,0,1,11,0]

def active58956 : List Nat := [0,1,2]

def tree58956 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood58956 : H12WitnessSearch.Good tree58956 := H12GlobalWitnessIndex.good

theorem leafIdentity58956 : H12AffineFastState.composeSystem env58956 rootObs = leafEnv58956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env58956 rootObs == leafEnv58956) = true)

theorem terminalChecked58956 : H12PackedTerminal.terminalCheckFast leafEnv58956 active58956 tree58956 = true := by decide +kernel

def env58957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,2097152,4194304,8388608,8430023,8329,8388688,12919238,4176,131153,4294795,8463814,8393812,257,4240696,131073,512]

theorem envBound58957 : H12AffineFastState.Bounded env58957 := by
  intro p hp
  have h : env58957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58938_58957 : H12AffineEnvironment.transform 13 4177 env58938 = env58957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env58938 == env58957) = true)

theorem identity58957 : scanCanonicalize (H12AffineFastState.compose env58957 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound58957 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1024,32768,2097152,4194304,8388608,8430023,8329,8388688,12919238,4176,77955,4294795,8463814,8393812,257,4240696,78035,512]

theorem envBound58958 : H12AffineFastState.Bounded env58958 := by
  intro p hp
  have h : env58958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58957_58958 : H12AffineEnvironment.transform 16 78034 env58957 = env58958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env58957 == env58958) = true)

theorem identity58958 : scanCanonicalize (H12AffineFastState.compose env58958 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 103747) := by decide +kernel

theorem selectedBound58958 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1024,32768,2097152,103747,8388608,8430023,8329,8388688,8696965,4176,77955,7624,8463814,8393812,257,73851,78035,512]

theorem envBound58959 : H12AffineFastState.Bounded env58959 := by
  intro p hp
  have h : env58959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58958_58959 : H12AffineEnvironment.transform 21 103747 env58958 = env58959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 103747 env58958 == env58959) = true)

theorem identity58959 : scanCanonicalize (H12AffineFastState.compose env58959 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 38242) := by decide +kernel

theorem selectedBound58959 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env58960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42416,262144,1024,32768,2097152,33,8388608,8430023,8329,8388688,8696965,4176,42465,7624,8433828,8393812,257,46361,42417,512]

theorem envBound58960 : H12AffineFastState.Bounded env58960 := by
  intro p hp
  have h : env58960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58959_58960 : H12AffineEnvironment.transform 15 38242 env58959 = env58960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38242 env58959 == env58960) = true)

def env58961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42416,262144,1024,32768,2097152,33,64,41351,8329,16,308421,4176,42465,7624,45284,5140,257,46361,42417,512]

theorem envBound58961 : H12AffineFastState.Bounded env58961 := by
  intro p hp
  have h : env58961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58960_58961 : H12AffineEnvironment.transform 22 64 env58960 = env58961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 64 env58960 == env58961) = true)

theorem identity58961 : scanCanonicalize (H12AffineFastState.compose env58961 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 48325) := by decide +kernel

theorem selectedBound58961 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42416,48325,1024,32768,2097152,33,64,41351,8329,16,2048,4176,42465,7624,45284,5140,257,46361,42417,512]

theorem envBound58962 : H12AffineFastState.Bounded env58962 := by
  intro p hp
  have h : env58962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58961_58962 : H12AffineEnvironment.transform 17 48325 env58961 = env58962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48325 env58961 == env58962) = true)

theorem identity58962 : scanCanonicalize (H12AffineFastState.compose env58962 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 1945) := by decide +kernel

theorem selectedBound58962 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42416,48325,1024,32768,1945,33,64,41351,8329,16,2048,4176,42465,7624,45284,5140,257,46361,42417,512]

theorem envBound58963 : H12AffineFastState.Bounded env58963 := by
  intro p hp
  have h : env58963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58962_58963 : H12AffineEnvironment.transform 20 1945 env58962 = env58963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1945 env58962 == env58963) = true)

theorem identity58963 : scanCanonicalize (H12AffineFastState.compose env58963 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound58963 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8460,13422,1212,7625,1024,8460,1945,33,64,139,8329,16,2048,4176,1261,7624,4584,5140,257,5141,1213,512]

theorem envBound58964 : H12AffineFastState.Bounded env58964 := by
  intro p hp
  have h : env58964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58963_58964 : H12AffineEnvironment.transform 14 8460 env58963 = env58964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env58963 == env58964) = true)

theorem identity58964 : scanCanonicalize (H12AffineFastState.compose env58964 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound58964 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env58965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,8192,2586,8460,11813,1212,1922,1024,8460,1945,33,64,139,8329,16,2048,2587,1261,1923,2979,3679,257,3678,1213,512]

theorem envBound58965 : H12AffineFastState.Bounded env58965 := by
  intro p hp
  have h : env58965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58964_58965 : H12AffineEnvironment.transform 11 2635 env58964 = env58965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env58964 == env58965) = true)

theorem identity58965 : scanCanonicalize (H12AffineFastState.compose env58965 (packedSelected [0,1,3,6,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 1110) := by decide +kernel

theorem selectedBound58965 : packedSelected [0,1,3,6,7,13] rootPS < 2^1333 := by decide +kernel

def env58966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,1110,2586,1370,2675,1212,1922,1024,1370,1945,33,64,139,1247,16,2048,2587,1261,1923,2979,3679,257,3678,1213,512]

theorem envBound58966 : H12AffineFastState.Bounded env58966 := by
  intro p hp
  have h : env58966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58965_58966 : H12AffineEnvironment.transform 12 1110 env58965 = env58966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1110 env58965 == env58966) = true)

theorem identity58966 : scanCanonicalize (H12AffineFastState.compose env58966 (packedSelected [0,1,2,5,7,15] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound58966 : packedSelected [0,1,2,5,7,15] rootPS < 2^1333 := by decide +kernel

def env58967 : List Nat := [2,4,8,16,32,64,128,256,293,1024,2048,2414,1110,2367,1370,2390,1212,1191,1024,1370,1212,33,64,139,1247,16,2048,2366,1261,1190,2182,3450,257,3451,1213,293]

theorem envBound58967 : H12AffineFastState.Bounded env58967 := by
  intro p hp
  have h : env58967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58966_58967 : H12AffineEnvironment.transform 8 293 env58966 = env58967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env58966 == env58967) = true)

theorem identity58967 : scanCanonicalize (H12AffineFastState.compose env58967 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1410) := by decide +kernel

theorem selectedBound58967 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58968 : List Nat := [2,4,8,16,32,64,128,256,293,1024,1410,1260,1110,1213,1370,1236,1212,1191,1024,1370,1212,33,64,139,1247,16,1410,1212,1261,1190,1284,248,257,249,1213,293]

theorem envBound58968 : H12AffineFastState.Bounded env58968 := by
  intro p hp
  have h : env58968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58967_58968 : H12AffineEnvironment.transform 10 1410 env58967 = env58968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1410 env58967 == env58968) = true)

def env58969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42416,262144,1024,32768,2097152,33,65,41350,8329,17,308420,4176,42465,7624,45285,5141,257,46361,42417,512]

theorem envBound58969 : H12AffineFastState.Bounded env58969 := by
  intro p hp
  have h : env58969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58960_58969 : H12AffineEnvironment.transform 22 65 env58960 = env58969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65 env58960 == env58969) = true)

theorem identity58969 : scanCanonicalize (H12AffineFastState.compose env58969 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound58969 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42416,43049,1024,32768,2097152,33,65,41350,8329,17,7405,4176,42465,7624,45285,5141,257,46361,42417,512]

theorem envBound58970 : H12AffineFastState.Bounded env58970 := by
  intro p hp
  have h : env58970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58969_58970 : H12AffineEnvironment.transform 17 43049 env58969 = env58970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env58969 == env58970) = true)

theorem identity58970 : scanCanonicalize (H12AffineFastState.compose env58970 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 4980) := by decide +kernel

theorem selectedBound58970 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,38242,42416,43049,1024,32768,4980,33,65,41350,8329,17,7405,4176,42465,7624,45285,5141,257,46361,42417,512]

theorem envBound58971 : H12AffineFastState.Bounded env58971 := by
  intro p hp
  have h : env58971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58970_58971 : H12AffineEnvironment.transform 20 4980 env58970 = env58971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4980 env58970 == env58971) = true)

theorem identity58971 : scanCanonicalize (H12AffineFastState.compose env58971 (packedSelected [1,3,6,13] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound58971 : packedSelected [1,3,6,13] rootPS < 2^1333 := by decide +kernel

def env58972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,8192,1213,32768,33166,42416,43049,1024,32768,1944,33,65,41350,8329,17,2049,1212,42465,2340,41993,249,257,41461,42417,512]

theorem envBound58972 : H12AffineFastState.Bounded env58972 := by
  intro p hp
  have h : env58972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58971_58972 : H12AffineEnvironment.transform 11 1260 env58971 = env58972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env58971 == env58972) = true)

theorem identity58972 : scanCanonicalize (H12AffineFastState.compose env58972 (packedSelected [1,5,12] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound58972 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env58973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,1260,8192,1213,32768,33166,42416,42786,1024,32768,1944,33,65,41350,8329,17,1802,1212,42465,1583,41993,249,257,41461,42417,512]

theorem envBound58973 : H12AffineFastState.Bounded env58973 := by
  intro p hp
  have h : env58973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58972_58973 : H12AffineEnvironment.transform 10 1803 env58972 = env58973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env58972 == env58973) = true)

theorem identity58973 : scanCanonicalize (H12AffineFastState.compose env58973 (packedSelected [3,5,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 9052) := by decide +kernel

theorem selectedBound58973 : packedSelected [3,5,11,15] rootPS < 2^1333 := by decide +kernel

def env58974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,1260,8192,1213,9052,8914,1772,1150,1024,9052,1944,33,65,730,8329,17,1802,1212,1725,1583,1877,249,257,681,1773,512]

theorem envBound58974 : H12AffineFastState.Bounded env58974 := by
  intro p hp
  have h : env58974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58973_58974 : H12AffineEnvironment.transform 14 9052 env58973 = env58974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9052 env58973 == env58974) = true)

theorem identity58974 : scanCanonicalize (H12AffineFastState.compose env58974 (packedSelected [0,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 1758) := by decide +kernel

theorem selectedBound58974 : packedSelected [0,5,11] rootPS < 2^1333 := by decide +kernel

def env58975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,1260,1758,1213,1410,1036,1772,1150,1024,1410,1944,33,65,730,1623,17,1802,1212,1725,1583,1877,249,257,681,1773,512]

theorem envBound58975 : H12AffineFastState.Bounded env58975 := by
  intro p hp
  have h : env58975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58974_58975 : H12AffineEnvironment.transform 12 1758 env58974 = env58975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1758 env58974 == env58975) = true)

theorem identity58975 : scanCanonicalize (H12AffineFastState.compose env58975 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound58975 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env58976 : List Nat := [2,4,8,16,32,64,128,256,81,1024,1370,1260,1167,1213,1410,1036,1213,1150,1024,1410,1481,33,65,139,1030,17,1371,1212,1260,1150,1284,249,257,248,1212,81]

theorem envBound58976 : H12AffineFastState.Bounded env58976 := by
  intro p hp
  have h : env58976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58975_58976 : H12AffineEnvironment.transform 8 81 env58975 = env58976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env58975 == env58976) = true)

theorem identity58976 : scanCanonicalize (H12AffineFastState.compose env58976 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound58976 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58977 : List Nat := [2,4,8,16,32,64,128,256,81,62,356,210,177,131,444,50,131,64,62,444,503,33,65,139,56,17,357,130,210,64,314,249,257,248,130,81]

theorem envBound58977 : H12AffineFastState.Bounded env58977 := by
  intro p hp
  have h : env58977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58976_58977 : H12AffineEnvironment.transform 9 62 env58976 = env58977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env58976 == env58977) = true)

def env58978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131152,4315355,8463814,4294967296,256,4307611965,34359738368,33563273]

theorem envBound58978 : H12AffineFastState.Bounded env58978 := by
  intro p hp
  have h : env58978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58908_58978 : H12AffineEnvironment.transform 18 1025 env58908 = env58978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env58908 == env58978) = true)

def env58979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131152,4315355,8463814,4294967296,256,4307611965,131072,33563273]

theorem envBound58979 : H12AffineFastState.Bounded env58979 := by
  intro p hp
  have h : env58979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58978_58979 : H12AffineEnvironment.transform 34 131072 env58978 = env58979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env58978 == env58979) = true)

theorem identity58979 : scanCanonicalize (H12AffineFastState.compose env58979 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 149250195) := by decide +kernel

theorem selectedBound58979 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,131152,4315355,8463814,149250195,256,136679854,131072,33563273]

theorem envBound58980 : H12AffineFastState.Bounded env58980 := by
  intro p hp
  have h : env58980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58979_58980 : H12AffineEnvironment.transform 31 149250195 env58979 = env58980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 149250195 env58979 == env58980) = true)

theorem identity58980 : scanCanonicalize (H12AffineFastState.compose env58980 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 78034) := by decide +kernel

theorem selectedBound58980 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env58981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8409089,134217728,16385,77954,4315355,8463814,149250195,256,136679854,78034,33563273]

theorem envBound58981 : H12AffineFastState.Bounded env58981 := by
  intro p hp
  have h : env58981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58980_58981 : H12AffineEnvironment.transform 16 78034 env58980 = env58981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78034 env58980 == env58981) = true)

def env58982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430022,33554432,8388689,134217728,4177,77954,4294795,8463814,149237955,256,136679854,78034,33563273]

theorem envBound58982 : H12AffineFastState.Bounded env58982 := by
  intro p hp
  have h : env58982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58981_58982 : H12AffineEnvironment.transform 13 4176 env58981 = env58982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env58981 == env58982) = true)

def env58983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399766,33554432,8388689,134217728,4177,77954,4260571,8463814,149237955,256,136649726,78034,33563273]

theorem envBound58983 : H12AffineFastState.Bounded env58983 := by
  intro p hp
  have h : env58983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58982_58983 : H12AffineEnvironment.transform 14 2640 env58982 = env58983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2640 env58982 == env58983) = true)

def env58984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399766,8397000,8388689,134217728,4177,77954,4260571,8463814,149237955,256,136649726,78034,8389185]

theorem envBound58984 : H12AffineFastState.Bounded env58984 := by
  intro p hp
  have h : env58984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58983_58984 : H12AffineEnvironment.transform 24 8397000 env58983 = env58984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8397000 env58983 == env58984) = true)

def env58985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399766,8397000,8388689,6561532,4177,77954,4260571,8463814,8465983,256,4261122,78034,8389185]

theorem envBound58985 : H12AffineFastState.Bounded env58985 := by
  intro p hp
  have h : env58985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58984_58985 : H12AffineEnvironment.transform 26 6561532 env58984 = env58985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561532 env58984 == env58985) = true)

def env58986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,8388608,8399766,8397000,8388689,2366324,4177,77954,67411,8463814,8465983,256,65674,78034,8389185]

theorem envBound58986 : H12AffineFastState.Bounded env58986 := by
  intro p hp
  have h : env58986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58985_58986 : H12AffineEnvironment.transform 21 1416 env58985 = env58986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env58985 == env58986) = true)

def env58987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9664,3670,1288,9617,2366324,4177,77954,67411,65542,68607,256,65674,78034,10113]

theorem envBound58987 : H12AffineFastState.Bounded env58987 := by
  intro p hp
  have h : env58987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58986_58987 : H12AffineEnvironment.transform 22 9664 env58986 = env58987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env58986 == env58987) = true)

def env58988 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3158,1288,9617,2365812,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound58988 : H12AffineFastState.Bounded env58988 := by
  intro p hp
  have h : env58988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58987_58988 : H12AffineEnvironment.transform 8 0 env58987 = env58988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58987 == env58988) = true)

theorem identity58988 : scanCanonicalize (H12AffineFastState.compose env58988 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound58988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58989 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,1028,1416,9664,3158,1288,9617,269680,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound58989 : H12AffineFastState.Bounded env58989 := by
  intro p hp
  have h : env58989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58988_58989 : H12AffineEnvironment.transform 20 1028 env58988 = env58989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env58988 == env58989) = true)

def env58990 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,1028,1416,64,3158,1288,17,269680,4177,70914,66899,65542,68095,256,65674,70994,1]

theorem envBound58990 : H12AffineFastState.Bounded env58990 := by
  intro p hp
  have h : env58990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58989_58990 : H12AffineEnvironment.transform 12 1408 env58989 = env58990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env58989 == env58990) = true)

theorem identity58990 : scanCanonicalize (H12AffineFastState.compose env58990 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3577) := by decide +kernel

theorem selectedBound58990 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58991 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3577,1408,3497,2128,65536,67755,262144,1025,2128,1028,1416,64,3158,1288,17,262281,3496,67835,66899,65542,68095,256,65674,67755,1]

theorem envBound58991 : H12AffineFastState.Bounded env58991 := by
  intro p hp
  have h : env58991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58990_58991 : H12AffineEnvironment.transform 11 3577 env58990 = env58991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3577 env58990 == env58991) = true)

theorem identity58991 : scanCanonicalize (H12AffineFastState.compose env58991 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound58991 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58992 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,0,1408,80,1449,65536,66898,262144,1025,1449,1028,1416,64,431,1288,17,262281,81,66818,66899,65542,66566,256,65674,66898,1]

theorem envBound58992 : H12AffineFastState.Bounded env58992 := by
  intro p hp
  have h : env58992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58991_58992 : H12AffineEnvironment.transform 10 1529 env58991 = env58992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env58991 == env58992) = true)

theorem identity58992 : scanCanonicalize (H12AffineFastState.compose env58992 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1513) := by decide +kernel

theorem selectedBound58992 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env58993 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,0,1408,80,1449,65536,66898,1513,1025,1449,1028,1416,64,431,1288,17,1376,81,66818,66899,65542,66566,256,65674,66898,1]

theorem envBound58993 : H12AffineFastState.Bounded env58993 := by
  intro p hp
  have h : env58993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58992_58993 : H12AffineEnvironment.transform 17 1513 env58992 = env58993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1513 env58992 == env58993) = true)

theorem identity58993 : scanCanonicalize (H12AffineFastState.compose env58993 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound58993 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env58994 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,0,1408,80,1449,1062,372,1513,1025,1449,1028,1416,64,431,1288,17,1376,81,292,373,1056,32,256,1196,372,1]

theorem envBound58994 : H12AffineFastState.Bounded env58994 := by
  intro p hp
  have h : env58994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58993_58994 : H12AffineEnvironment.transform 15 1062 env58993 = env58994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env58993 == env58994) = true)

theorem identity58994 : scanCanonicalize (H12AffineFastState.compose env58994 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound58994 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env58995 : List Nat := [2,4,8,16,32,64,128,256,0,220,293,0,348,80,373,250,372,309,221,373,216,340,64,431,468,17,444,81,292,373,252,32,256,112,372,1]

theorem envBound58995 : H12AffineFastState.Bounded env58995 := by
  intro p hp
  have h : env58995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58994_58995 : H12AffineEnvironment.transform 9 220 env58994 = env58995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env58994 == env58995) = true)

theorem identity58995 : scanCanonicalize (H12AffineFastState.compose env58995 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound58995 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env58996 : List Nat := [2,4,8,16,32,64,128,173,0,220,136,0,241,80,216,250,217,152,221,216,216,249,64,2,121,17,17,81,137,216,252,32,173,112,217,1]

theorem envBound58996 : H12AffineFastState.Bounded env58996 := by
  intro p hp
  have h : env58996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58995_58996 : H12AffineEnvironment.transform 7 173 env58995 = env58996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58995 == env58996) = true)

theorem identity58996 : scanCanonicalize (H12AffineFastState.compose env58996 (packedSelected [1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 51) := by decide +kernel

theorem selectedBound58996 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env58997 : List Nat := [2,4,8,16,32,51,128,173,0,175,136,0,130,35,171,137,170,152,174,171,171,138,51,2,10,17,17,34,137,171,143,32,173,3,170,1]

theorem envBound58997 : H12AffineFastState.Bounded env58997 := by
  intro p hp
  have h : env58997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58996_58997 : H12AffineEnvironment.transform 5 51 env58996 = env58997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 51 env58996 == env58997) = true)

theorem identity58997 : scanCanonicalize (H12AffineFastState.compose env58997 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58997 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env58998 : List Nat := [1,4,8,16,32,48,128,173,0,172,136,0,129,32,168,137,169,152,173,168,168,137,48,1,9,17,17,33,137,168,140,32,173,0,169,1]

theorem envBound58998 : H12AffineFastState.Bounded env58998 := by
  intro p hp
  have h : env58998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58997_58998 : H12AffineEnvironment.transform 0 1 env58997 = env58998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58997 == env58998) = true)

theorem identity58998 : scanCanonicalize (H12AffineFastState.compose env58998 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound58998 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env58999 : List Nat := [1,4,8,16,24,8,128,149,0,148,136,0,129,24,144,137,145,152,149,144,144,137,8,1,9,17,17,25,137,144,140,24,149,0,145,1]

theorem envBound58999 : H12AffineFastState.Bounded env58999 := by
  intro p hp
  have h : env58999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58998_58999 : H12AffineEnvironment.transform 4 24 env58998 = env58999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env58998 == env58999) = true)

theorem identity58999 : scanCanonicalize (H12AffineFastState.compose env58999 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound58999 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env59000 : List Nat := [1,4,8,16,24,8,1,20,0,21,9,0,0,24,17,8,16,25,20,17,17,8,8,1,9,17,17,25,8,17,13,24,20,0,16,1]

theorem envBound59000 : H12AffineFastState.Bounded env59000 := by
  intro p hp
  have h : env59000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58999_59000 : H12AffineEnvironment.transform 6 1 env58999 = env59000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env58999 == env59000) = true)

def env59001 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,1028,1416,65,3158,1288,16,269680,4177,70915,66899,65542,68095,256,65674,70995,0]

theorem envBound59001 : H12AffineFastState.Bounded env59001 := by
  intro p hp
  have h : env59001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58989_59001 : H12AffineEnvironment.transform 12 1409 env58989 = env59001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env58989 == env59001) = true)

theorem identity59001 : scanCanonicalize (H12AffineFastState.compose env59001 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59001 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59002 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,7422,2477,262144,1025,2128,1028,1416,65,3158,1288,16,269680,4177,2557,6573,7416,5377,256,7284,2477,0]

theorem envBound59002 : H12AffineFastState.Bounded env59002 := by
  intro p hp
  have h : env59002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59001_59002 : H12AffineEnvironment.transform 15 7422 env59001 = env59002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59001 == env59002) = true)

theorem identity59002 : scanCanonicalize (H12AffineFastState.compose env59002 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3528) := by decide +kernel

theorem selectedBound59002 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59003 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,7422,2477,3528,1025,2128,1028,1416,65,3158,1288,16,4280,4177,2557,6573,7416,5377,256,7284,2477,0]

theorem envBound59003 : H12AffineFastState.Bounded env59003 := by
  intro p hp
  have h : env59003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59002_59003 : H12AffineEnvironment.transform 17 3528 env59002 = env59003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3528 env59002 == env59003) = true)

theorem identity59003 : scanCanonicalize (H12AffineFastState.compose env59003 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59003 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59004 : List Nat := [2,4,8,16,32,64,128,256,0,1024,49,4096,1409,4176,97,5327,412,1529,1025,97,1028,1416,65,1127,1288,16,4280,4177,460,4508,5321,5377,256,5189,412,0]

theorem envBound59004 : H12AffineFastState.Bounded env59004 := by
  intro p hp
  have h : env59004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59003_59004 : H12AffineEnvironment.transform 10 49 env59003 = env59004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59003 == env59004) = true)

theorem identity59004 : scanCanonicalize (H12AffineFastState.compose env59004 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59004 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59005 : List Nat := [2,4,8,16,32,64,128,69,0,1024,49,4096,1220,4176,97,5327,217,1212,1025,97,1028,1229,65,1127,1101,16,4280,4177,137,4313,5321,5188,69,5189,217,0]

theorem envBound59005 : H12AffineFastState.Bounded env59005 := by
  intro p hp
  have h : env59005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59004_59005 : H12AffineEnvironment.transform 7 69 env59004 = env59005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59004 == env59005) = true)

theorem identity59005 : scanCanonicalize (H12AffineFastState.compose env59005 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound59005 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59006 : List Nat := [2,4,8,16,32,64,128,69,0,1024,49,137,1220,217,97,1094,217,1212,1025,97,1028,1229,65,1127,1101,16,49,216,137,80,1088,1229,69,1228,217,0]

theorem envBound59006 : H12AffineFastState.Bounded env59006 := by
  intro p hp
  have h : env59006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59005_59006 : H12AffineEnvironment.transform 11 137 env59005 = env59006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env59005 == env59006) = true)

def env59007 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3159,1288,9617,2365813,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59007 : H12AffineFastState.Bounded env59007 := by
  intro p hp
  have h : env59007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58987_59007 : H12AffineEnvironment.transform 8 1 env58987 = env59007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58987 == env59007) = true)

theorem identity59007 : scanCanonicalize (H12AffineFastState.compose env59007 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 8580) := by decide +kernel

theorem selectedBound59007 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59008 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,8580,1416,9664,3159,1288,9617,276721,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59008 : H12AffineFastState.Bounded env59008 := by
  intro p hp
  have h : env59008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59007_59008 : H12AffineEnvironment.transform 20 8580 env59007 = env59008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 8580 env59007 == env59008) = true)

def env59009 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,1028,1416,64,3159,1288,17,269681,4177,70914,66898,65542,68094,256,65674,70994,0]

theorem envBound59009 : H12AffineFastState.Bounded env59009 := by
  intro p hp
  have h : env59009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59008_59009 : H12AffineEnvironment.transform 12 1408 env59008 = env59009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59008 == env59009) = true)

theorem identity59009 : scanCanonicalize (H12AffineFastState.compose env59009 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3576) := by decide +kernel

theorem selectedBound59009 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59010 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3576,1408,3496,2129,65536,67754,262144,1025,2129,1028,1416,64,3159,1288,17,262281,3497,67834,66898,65542,68094,256,65674,67754,0]

theorem envBound59010 : H12AffineFastState.Bounded env59010 := by
  intro p hp
  have h : env59010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59009_59010 : H12AffineEnvironment.transform 11 3576 env59009 = env59010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3576 env59009 == env59010) = true)

theorem identity59010 : scanCanonicalize (H12AffineFastState.compose env59010 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59010 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59011 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,0,1408,80,1449,65536,66898,262144,1025,1449,1028,1416,64,431,1288,17,262281,81,66818,66898,65542,66566,256,65674,66898,0]

theorem envBound59011 : H12AffineFastState.Bounded env59011 := by
  intro p hp
  have h : env59011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59010_59011 : H12AffineEnvironment.transform 10 1528 env59010 = env59011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59010 == env59011) = true)

theorem identity59011 : scanCanonicalize (H12AffineFastState.compose env59011 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1513) := by decide +kernel

theorem selectedBound59011 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59012 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,0,1408,80,1449,65536,66898,1513,1025,1449,1028,1416,64,431,1288,17,1376,81,66818,66898,65542,66566,256,65674,66898,0]

theorem envBound59012 : H12AffineFastState.Bounded env59012 := by
  intro p hp
  have h : env59012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59011_59012 : H12AffineEnvironment.transform 17 1513 env59011 = env59012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1513 env59011 == env59012) = true)

theorem identity59012 : scanCanonicalize (H12AffineFastState.compose env59012 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59012 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59013 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,0,1408,80,1449,1062,372,1513,1025,1449,1028,1416,64,431,1288,17,1376,81,292,372,1056,32,256,1196,372,0]

theorem envBound59013 : H12AffineFastState.Bounded env59013 := by
  intro p hp
  have h : env59013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59012_59013 : H12AffineEnvironment.transform 15 1062 env59012 = env59013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59012 == env59013) = true)

theorem identity59013 : scanCanonicalize (H12AffineFastState.compose env59013 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59013 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59014 : List Nat := [2,4,8,16,32,64,128,256,1,221,293,0,349,80,372,251,372,308,220,372,217,341,64,431,469,17,445,81,292,372,253,32,256,113,372,0]

theorem envBound59014 : H12AffineFastState.Bounded env59014 := by
  intro p hp
  have h : env59014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59013_59014 : H12AffineEnvironment.transform 9 221 env59013 = env59014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59013 == env59014) = true)

theorem identity59014 : scanCanonicalize (H12AffineFastState.compose env59014 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59014 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59015 : List Nat := [2,4,8,16,32,17,128,256,1,140,293,0,268,1,293,170,293,308,141,293,136,260,17,431,388,17,445,0,292,293,172,32,256,32,293,0]

theorem envBound59015 : H12AffineFastState.Bounded env59015 := by
  intro p hp
  have h : env59015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59014_59015 : H12AffineEnvironment.transform 5 17 env59014 = env59015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59014 == env59015) = true)

theorem identity59015 : scanCanonicalize (H12AffineFastState.compose env59015 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound59015 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59016 : List Nat := [2,4,8,16,32,17,128,157,1,140,184,0,145,1,184,170,184,169,141,184,136,153,17,50,25,17,32,0,185,184,172,32,157,32,184,0]

theorem envBound59016 : H12AffineFastState.Bounded env59016 := by
  intro p hp
  have h : env59016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59015_59016 : H12AffineEnvironment.transform 7 157 env59015 = env59016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env59015 == env59016) = true)

theorem identity59016 : scanCanonicalize (H12AffineFastState.compose env59016 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 59) := by decide +kernel

theorem selectedBound59016 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59017 : List Nat := [2,4,8,16,32,17,59,38,1,55,3,0,42,1,3,17,3,18,54,3,51,34,17,50,25,17,32,0,2,3,23,32,38,32,3,0]

theorem envBound59017 : H12AffineFastState.Bounded env59017 := by
  intro p hp
  have h : env59017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59016_59017 : H12AffineEnvironment.transform 6 59 env59016 = env59017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 59 env59016 == env59017) = true)

theorem identity59017 : scanCanonicalize (H12AffineFastState.compose env59017 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59017 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59018 : List Nat := [2,4,8,16,1,17,26,7,1,22,3,0,11,1,3,17,3,18,23,3,18,3,17,19,25,17,1,0,2,3,23,1,7,1,3,0]

theorem envBound59018 : H12AffineFastState.Bounded env59018 := by
  intro p hp
  have h : env59018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59017_59018 : H12AffineEnvironment.transform 4 1 env59017 = env59018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59017 == env59018) = true)

theorem identity59018 : scanCanonicalize (H12AffineFastState.compose env59018 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59018 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59019 : List Nat := [2,4,8,2,1,3,8,7,1,4,3,0,11,1,3,3,3,0,5,3,0,3,3,1,11,3,1,0,2,3,5,1,7,1,3,0]

theorem envBound59019 : H12AffineFastState.Bounded env59019 := by
  intro p hp
  have h : env59019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59018_59019 : H12AffineEnvironment.transform 3 2 env59018 = env59019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59018 == env59019) = true)

def env59020 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,1029,1416,65,3159,1288,16,269680,4177,70915,66898,65542,68094,256,65674,70995,1]

theorem envBound59020 : H12AffineFastState.Bounded env59020 := by
  intro p hp
  have h : env59020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59008_59020 : H12AffineEnvironment.transform 12 1409 env59008 = env59020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59008 == env59020) = true)

theorem identity59020 : scanCanonicalize (H12AffineFastState.compose env59020 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59020 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59021 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,7422,2477,262144,1025,2129,1029,1416,65,3159,1288,16,269680,4177,2557,6572,7416,5376,256,7284,2477,1]

theorem envBound59021 : H12AffineFastState.Bounded env59021 := by
  intro p hp
  have h : env59021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59020_59021 : H12AffineEnvironment.transform 15 7422 env59020 = env59021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59020 == env59021) = true)

theorem identity59021 : scanCanonicalize (H12AffineFastState.compose env59021 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3528) := by decide +kernel

theorem selectedBound59021 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59022 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,7422,2477,3528,1025,2129,1029,1416,65,3159,1288,16,4280,4177,2557,6572,7416,5376,256,7284,2477,1]

theorem envBound59022 : H12AffineFastState.Bounded env59022 := by
  intro p hp
  have h : env59022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59021_59022 : H12AffineEnvironment.transform 17 3528 env59021 = env59022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3528 env59021 == env59022) = true)

theorem identity59022 : scanCanonicalize (H12AffineFastState.compose env59022 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59022 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59023 : List Nat := [2,4,8,16,32,64,128,256,1,1024,48,4096,1409,4176,97,5326,413,1528,1025,97,1029,1416,65,1127,1288,16,4280,4177,461,4508,5320,5376,256,5188,413,1]

theorem envBound59023 : H12AffineFastState.Bounded env59023 := by
  intro p hp
  have h : env59023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59022_59023 : H12AffineEnvironment.transform 10 48 env59022 = env59023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59022 == env59023) = true)

theorem identity59023 : scanCanonicalize (H12AffineFastState.compose env59023 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59023 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59024 : List Nat := [2,4,8,16,32,64,128,256,1,424,48,4096,41,4176,97,4454,413,80,425,97,429,32,65,463,160,16,4280,4177,461,4508,4448,4264,256,4588,413,1]

theorem envBound59024 : H12AffineFastState.Bounded env59024 := by
  intro p hp
  have h : env59024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59023_59024 : H12AffineEnvironment.transform 9 424 env59023 = env59024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59023 == env59024) = true)

theorem identity59024 : scanCanonicalize (H12AffineFastState.compose env59024 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59024 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59025 : List Nat := [2,4,8,16,32,64,128,256,1,424,48,136,41,216,97,494,413,80,425,97,429,32,65,463,160,16,48,217,461,276,488,32,256,356,413,1]

theorem envBound59025 : H12AffineFastState.Bounded env59025 := by
  intro p hp
  have h : env59025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59024_59025 : H12AffineEnvironment.transform 11 136 env59024 = env59025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59024 == env59025) = true)

theorem identity59025 : scanCanonicalize (H12AffineFastState.compose env59025 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound59025 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59026 : List Nat := [2,4,8,16,32,64,128,183,1,31,48,136,41,216,97,89,42,80,30,97,26,32,65,120,160,16,48,217,122,163,95,32,183,211,42,1]

theorem envBound59026 : H12AffineFastState.Bounded env59026 := by
  intro p hp
  have h : env59026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59025_59026 : H12AffineEnvironment.transform 7 183 env59025 = env59026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env59025 == env59026) = true)

theorem identity59026 : scanCanonicalize (H12AffineFastState.compose env59026 (packedSelected [1,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59026 : packedSelected [1,6,9] rootPS < 2^1333 := by decide +kernel

def env59027 : List Nat := [2,4,8,16,32,64,114,69,1,31,48,122,41,42,97,89,42,80,30,97,26,32,65,120,82,16,48,43,122,81,95,32,69,33,42,1]

theorem envBound59027 : H12AffineFastState.Bounded env59027 := by
  intro p hp
  have h : env59027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59026_59027 : H12AffineEnvironment.transform 6 114 env59026 = env59027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59026 == env59027) = true)

def env59028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9665,3671,1289,9616,2366324,4177,77954,67411,65543,68606,256,65674,78034,10112]

theorem envBound59028 : H12AffineFastState.Bounded env59028 := by
  intro p hp
  have h : env59028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58986_59028 : H12AffineEnvironment.transform 22 9665 env58986 = env59028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env58986 == env59028) = true)

def env59029 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3159,1289,9616,2365812,4177,77954,66899,65543,68094,256,65674,78034,9600]

theorem envBound59029 : H12AffineFastState.Bounded env59029 := by
  intro p hp
  have h : env59029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59028_59029 : H12AffineEnvironment.transform 8 0 env59028 = env59029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59028 == env59029) = true)

theorem identity59029 : scanCanonicalize (H12AffineFastState.compose env59029 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 6612) := by decide +kernel

theorem selectedBound59029 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59030 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,6612,4176,2128,65536,67846,262144,1025,2128,2097152,1416,7189,3159,1289,7236,2365812,4177,67926,66899,65543,68094,256,65674,67846,7252]

theorem envBound59030 : H12AffineFastState.Bounded env59030 := by
  intro p hp
  have h : env59030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59029_59030 : H12AffineEnvironment.transform 12 6612 env59029 = env59030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6612 env59029 == env59030) = true)

def env59031 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2128,65536,67846,262144,1025,2128,2097152,1416,65,3159,1289,16,2360608,3077,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59031 : H12AffineFastState.Bounded env59031 := by
  intro p hp
  have h : env59031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59030_59031 : H12AffineEnvironment.transform 11 3156 env59030 = env59031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59030 == env59031) = true)

theorem identity59031 : scanCanonicalize (H12AffineFastState.compose env59031 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 66735) := by decide +kernel

theorem selectedBound59031 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59032 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2128,65536,67846,262144,1025,2128,66735,1416,65,3159,1289,16,328079,3077,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59032 : H12AffineFastState.Bounded env59032 := by
  intro p hp
  have h : env59032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59031_59032 : H12AffineEnvironment.transform 20 66735 env59031 = env59032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66735 env59031 == env59032) = true)

theorem identity59032 : scanCanonicalize (H12AffineFastState.compose env59032 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68962) := by decide +kernel

theorem selectedBound59032 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59033 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2128,65536,67846,68962,1025,2128,66735,1416,65,3159,1289,16,3309,3077,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59033 : H12AffineFastState.Bounded env59033 := by
  intro p hp
  have h : env59033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59032_59033 : H12AffineEnvironment.transform 17 68962 env59032 = env59033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68962 env59032 == env59033) = true)

theorem identity59033 : scanCanonicalize (H12AffineFastState.compose env59033 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound59033 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59034 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2128,2202,412,1528,1025,2128,3125,1416,65,3159,1289,16,3309,3077,460,3529,2205,356,256,2064,412,0]

theorem envBound59034 : H12AffineFastState.Bounded env59034 := by
  intro p hp
  have h : env59034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59033_59034 : H12AffineEnvironment.transform 15 2202 env59033 = env59034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env59033 == env59034) = true)

theorem identity59034 : scanCanonicalize (H12AffineFastState.compose env59034 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59034 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59035 : List Nat := [2,4,8,16,32,64,128,256,0,424,2048,2556,40,2476,2128,2202,412,80,425,2128,2461,32,65,2559,161,16,2373,2477,460,2145,2205,356,256,2064,412,0]

theorem envBound59035 : H12AffineFastState.Bounded env59035 := by
  intro p hp
  have h : env59035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59034_59035 : H12AffineEnvironment.transform 9 424 env59034 = env59035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59034 == env59035) = true)

theorem identity59035 : scanCanonicalize (H12AffineFastState.compose env59035 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59035 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59036 : List Nat := [2,4,8,16,32,64,128,69,0,237,2048,2233,40,2281,2128,2202,217,80,236,2128,2264,32,65,2234,161,16,2048,2280,137,2145,2205,33,69,2064,217,0]

theorem envBound59036 : H12AffineFastState.Bounded env59036 := by
  intro p hp
  have h : env59036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59035_59036 : H12AffineEnvironment.transform 7 69 env59035 = env59036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59035 == env59036) = true)

theorem identity59036 : scanCanonicalize (H12AffineFastState.compose env59036 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound59036 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59037 : List Nat := [2,4,8,16,32,64,115,69,0,30,2048,2122,40,2074,2128,2153,42,80,31,2128,2091,32,65,2121,82,16,2048,2075,122,2145,2158,33,69,2064,42,0]

theorem envBound59037 : H12AffineFastState.Bounded env59037 := by
  intro p hp
  have h : env59037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59036_59037 : H12AffineEnvironment.transform 6 115 env59036 = env59037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env59036 == env59037) = true)

def env59038 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3157,1409,3077,2128,65536,67846,262144,1025,2128,2097152,1416,64,3159,1289,17,2360609,3076,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59038 : H12AffineFastState.Bounded env59038 := by
  intro p hp
  have h : env59038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59030_59038 : H12AffineEnvironment.transform 11 3157 env59030 = env59038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env59030 == env59038) = true)

theorem identity59038 : scanCanonicalize (H12AffineFastState.compose env59038 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1448) := by decide +kernel

theorem selectedBound59038 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59039 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3157,1409,3077,2128,65536,67846,262144,1025,2128,1448,1416,64,3159,1289,17,262281,3076,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59039 : H12AffineFastState.Bounded env59039 := by
  intro p hp
  have h : env59039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59038_59039 : H12AffineEnvironment.transform 20 1448 env59038 = env59039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1448 env59038 == env59039) = true)

theorem identity59039 : scanCanonicalize (H12AffineFastState.compose env59039 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59039 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59040 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,428,1409,508,1449,65536,66815,262144,1025,1449,1448,1416,64,430,1289,17,262281,509,66735,66899,65543,66567,256,65674,66815,1]

theorem envBound59040 : H12AffineFastState.Bounded env59040 := by
  intro p hp
  have h : env59040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59039_59040 : H12AffineEnvironment.transform 10 1529 env59039 = env59040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59039 == env59040) = true)

theorem identity59040 : scanCanonicalize (H12AffineFastState.compose env59040 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1093) := by decide +kernel

theorem selectedBound59040 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59041 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,428,1409,508,1449,65536,66815,1093,1025,1449,1448,1416,64,430,1289,17,1228,509,66735,66899,65543,66567,256,65674,66815,1]

theorem envBound59041 : H12AffineFastState.Bounded env59041 := by
  intro p hp
  have h : env59041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59040_59041 : H12AffineEnvironment.transform 17 1093 env59040 = env59041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1093 env59040 == env59041) = true)

theorem identity59041 : scanCanonicalize (H12AffineFastState.compose env59041 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59041 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59042 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,428,1409,508,1449,1062,217,1093,1025,1449,1448,1416,64,430,1289,17,1228,509,137,373,1057,33,256,1196,217,1]

theorem envBound59042 : H12AffineFastState.Bounded env59042 := by
  intro p hp
  have h : env59042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59041_59042 : H12AffineEnvironment.transform 15 1062 env59041 = env59042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59041 == env59042) = true)

theorem identity59042 : scanCanonicalize (H12AffineFastState.compose env59042 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59042 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59043 : List Nat := [2,4,8,16,32,64,128,256,0,220,293,428,349,508,373,250,217,153,221,373,372,340,64,430,469,17,16,509,137,373,253,33,256,112,217,1]

theorem envBound59043 : H12AffineFastState.Bounded env59043 := by
  intro p hp
  have h : env59043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59042_59043 : H12AffineEnvironment.transform 9 220 env59042 = env59043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59042 == env59043) = true)

theorem identity59043 : scanCanonicalize (H12AffineFastState.compose env59043 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59043 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59044 : List Nat := [2,4,8,16,1,64,128,256,0,220,260,397,349,477,340,219,217,153,221,340,341,340,64,399,469,17,16,476,137,340,220,0,256,81,217,1]

theorem envBound59044 : H12AffineFastState.Bounded env59044 := by
  intro p hp
  have h : env59044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59043_59044 : H12AffineEnvironment.transform 4 1 env59043 = env59044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59043 == env59044) = true)

theorem identity59044 : scanCanonicalize (H12AffineFastState.compose env59044 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59044 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59045 : List Nat := [2,4,8,16,1,17,128,256,0,141,260,397,268,396,261,138,136,153,140,261,260,261,17,399,388,17,16,397,137,261,141,0,256,0,136,1]

theorem envBound59045 : H12AffineFastState.Bounded env59045 := by
  intro p hp
  have h : env59045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59044_59045 : H12AffineEnvironment.transform 5 17 env59044 = env59045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59044 == env59045) = true)

theorem identity59045 : scanCanonicalize (H12AffineFastState.compose env59045 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 142) := by decide +kernel

theorem selectedBound59045 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59046 : List Nat := [2,4,8,16,1,17,128,142,0,141,138,3,130,2,139,138,136,153,140,139,138,139,17,1,10,17,16,3,137,139,141,0,142,0,136,1]

theorem envBound59046 : H12AffineFastState.Bounded env59046 := by
  intro p hp
  have h : env59046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59045_59046 : H12AffineEnvironment.transform 7 142 env59045 = env59046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 142 env59045 == env59046) = true)

theorem identity59046 : scanCanonicalize (H12AffineFastState.compose env59046 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound59046 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59047 : List Nat := [2,4,8,9,1,8,128,142,0,141,138,3,130,2,139,138,136,128,140,139,138,139,8,1,10,8,9,3,137,139,141,0,142,0,136,1]

theorem envBound59047 : H12AffineFastState.Bounded env59047 := by
  intro p hp
  have h : env59047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59046_59047 : H12AffineEnvironment.transform 3 9 env59046 = env59047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env59046 == env59047) = true)

theorem identity59047 : scanCanonicalize (H12AffineFastState.compose env59047 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound59047 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env59048 : List Nat := [2,4,8,9,1,8,0,14,0,13,10,3,2,2,11,10,8,0,12,11,10,11,8,1,10,8,9,3,9,11,13,0,14,0,8,1]

theorem envBound59048 : H12AffineFastState.Bounded env59048 := by
  intro p hp
  have h : env59048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59047_59048 : H12AffineEnvironment.transform 6 0 env59047 = env59048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env59047 == env59048) = true)

theorem identity59048 : scanCanonicalize (H12AffineFastState.compose env59048 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59048 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59049 : List Nat := [1,4,8,9,1,8,0,13,0,13,9,0,1,1,8,9,8,0,12,8,9,8,8,1,9,8,9,0,9,8,13,0,13,0,8,1]

theorem envBound59049 : H12AffineFastState.Bounded env59049 := by
  intro p hp
  have h : env59049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59048_59049 : H12AffineEnvironment.transform 0 1 env59048 = env59049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59048 == env59049) = true)

def env59050 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3158,1289,9616,2365813,4177,77954,66898,65543,68095,256,65674,78034,9601]

theorem envBound59050 : H12AffineFastState.Bounded env59050 := by
  intro p hp
  have h : env59050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59028_59050 : H12AffineEnvironment.transform 8 1 env59028 = env59050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59028 == env59050) = true)

theorem identity59050 : scanCanonicalize (H12AffineFastState.compose env59050 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59050 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59051 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,8192,3076,2129,65536,76934,262144,1025,2129,2097152,1416,9665,3158,1289,9616,2360609,3077,77014,66898,65543,68095,256,65674,76934,9601]

theorem envBound59051 : H12AffineFastState.Bounded env59051 := by
  intro p hp
  have h : env59051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59050_59051 : H12AffineEnvironment.transform 11 3156 env59050 = env59051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59050 == env59051) = true)

def env59052 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2129,65536,67846,262144,1025,2129,2097152,1416,65,3158,1289,16,2360609,3077,67926,66898,65543,68095,256,65674,67846,1]

theorem envBound59052 : H12AffineFastState.Bounded env59052 := by
  intro p hp
  have h : env59052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59051_59052 : H12AffineEnvironment.transform 12 1408 env59051 = env59052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59051 == env59052) = true)

theorem identity59052 : scanCanonicalize (H12AffineFastState.compose env59052 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 66734) := by decide +kernel

theorem selectedBound59052 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59053 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2129,65536,67846,262144,1025,2129,66734,1416,65,3158,1289,16,328079,3077,67926,66898,65543,68095,256,65674,67846,1]

theorem envBound59053 : H12AffineFastState.Bounded env59053 := by
  intro p hp
  have h : env59053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59052_59053 : H12AffineEnvironment.transform 20 66734 env59052 = env59053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66734 env59052 == env59053) = true)

theorem identity59053 : scanCanonicalize (H12AffineFastState.compose env59053 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68962) := by decide +kernel

theorem selectedBound59053 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59054 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2129,65536,67846,68962,1025,2129,66734,1416,65,3158,1289,16,3309,3077,67926,66898,65543,68095,256,65674,67846,1]

theorem envBound59054 : H12AffineFastState.Bounded env59054 := by
  intro p hp
  have h : env59054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59053_59054 : H12AffineEnvironment.transform 17 68962 env59053 = env59054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68962 env59053 == env59054) = true)

theorem identity59054 : scanCanonicalize (H12AffineFastState.compose env59054 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound59054 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59055 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2129,2203,413,1529,1025,2129,3125,1416,65,3158,1289,16,3309,3077,461,3529,2204,356,256,2065,413,1]

theorem envBound59055 : H12AffineFastState.Bounded env59055 := by
  intro p hp
  have h : env59055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59054_59055 : H12AffineEnvironment.transform 15 2203 env59054 = env59055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env59054 == env59055) = true)

theorem identity59055 : scanCanonicalize (H12AffineFastState.compose env59055 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound59055 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59056 : List Nat := [2,4,8,16,32,64,128,256,1,1024,372,1312,1408,1392,293,495,413,1529,1025,293,1345,1416,65,1314,1289,16,1433,1393,461,1213,488,356,256,357,413,1]

theorem envBound59056 : H12AffineFastState.Bounded env59056 := by
  intro p hp
  have h : env59056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59055_59056 : H12AffineEnvironment.transform 10 372 env59055 = env59056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env59055 == env59056) = true)

theorem identity59056 : scanCanonicalize (H12AffineFastState.compose env59056 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59056 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59057 : List Nat := [2,4,8,16,32,64,128,256,1,237,372,461,365,413,293,495,413,276,236,293,428,357,65,463,484,16,372,412,461,80,488,356,256,357,413,1]

theorem envBound59057 : H12AffineFastState.Bounded env59057 := by
  intro p hp
  have h : env59057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59056_59057 : H12AffineEnvironment.transform 9 237 env59056 = env59057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59056 == env59057) = true)

def env59058 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2129,65536,67847,262144,1025,2129,2097152,1416,64,3158,1289,17,2360609,3077,67927,66898,65543,68095,256,65674,67847,0]

theorem envBound59058 : H12AffineFastState.Bounded env59058 := by
  intro p hp
  have h : env59058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59051_59058 : H12AffineEnvironment.transform 12 1409 env59051 = env59058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59051 == env59058) = true)

theorem identity59058 : scanCanonicalize (H12AffineFastState.compose env59058 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1448) := by decide +kernel

theorem selectedBound59058 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59059 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2129,65536,67847,262144,1025,2129,1448,1416,64,3158,1289,17,262281,3077,67927,66898,65543,68095,256,65674,67847,0]

theorem envBound59059 : H12AffineFastState.Bounded env59059 := by
  intro p hp
  have h : env59059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59058_59059 : H12AffineEnvironment.transform 20 1448 env59058 = env59059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1448 env59058 == env59059) = true)

theorem identity59059 : scanCanonicalize (H12AffineFastState.compose env59059 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59059 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59060 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,428,1409,508,1449,65536,66815,262144,1025,1449,1448,1416,64,430,1289,17,262281,509,66735,66898,65543,66567,256,65674,66815,0]

theorem envBound59060 : H12AffineFastState.Bounded env59060 := by
  intro p hp
  have h : env59060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59059_59060 : H12AffineEnvironment.transform 10 1528 env59059 = env59060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59059 == env59060) = true)

theorem identity59060 : scanCanonicalize (H12AffineFastState.compose env59060 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1093) := by decide +kernel

theorem selectedBound59060 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59061 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,428,1409,508,1449,65536,66815,1093,1025,1449,1448,1416,64,430,1289,17,1228,509,66735,66898,65543,66567,256,65674,66815,0]

theorem envBound59061 : H12AffineFastState.Bounded env59061 := by
  intro p hp
  have h : env59061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59060_59061 : H12AffineEnvironment.transform 17 1093 env59060 = env59061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1093 env59060 == env59061) = true)

theorem identity59061 : scanCanonicalize (H12AffineFastState.compose env59061 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59061 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59062 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,428,1409,508,1449,1062,217,1093,1025,1449,1448,1416,64,430,1289,17,1228,509,137,372,1057,33,256,1196,217,0]

theorem envBound59062 : H12AffineFastState.Bounded env59062 := by
  intro p hp
  have h : env59062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59061_59062 : H12AffineEnvironment.transform 15 1062 env59061 = env59062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59061 == env59062) = true)

theorem identity59062 : scanCanonicalize (H12AffineFastState.compose env59062 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59062 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59063 : List Nat := [2,4,8,16,32,64,128,256,1,221,293,428,348,508,372,251,217,152,220,372,373,341,64,430,468,17,17,509,137,372,252,33,256,113,217,0]

theorem envBound59063 : H12AffineFastState.Bounded env59063 := by
  intro p hp
  have h : env59063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59062_59063 : H12AffineEnvironment.transform 9 221 env59062 = env59063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59062 == env59063) = true)

theorem identity59063 : scanCanonicalize (H12AffineFastState.compose env59063 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59063 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59064 : List Nat := [2,4,8,16,32,32,128,256,1,189,293,428,316,412,276,155,185,152,188,276,277,309,32,430,436,17,17,413,137,276,156,33,256,17,185,0]

theorem envBound59064 : H12AffineFastState.Bounded env59064 := by
  intro p hp
  have h : env59064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59063_59064 : H12AffineEnvironment.transform 5 32 env59063 = env59064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59063 == env59064) = true)

theorem identity59064 : scanCanonicalize (H12AffineFastState.compose env59064 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59064 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59065 : List Nat := [2,4,8,3,32,32,128,256,1,174,293,428,303,399,263,136,170,139,175,263,262,294,32,430,423,2,2,398,137,263,143,33,256,2,170,0]

theorem envBound59065 : H12AffineFastState.Bounded env59065 := by
  intro p hp
  have h : env59065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59064_59065 : H12AffineEnvironment.transform 3 3 env59064 = env59065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59064 == env59065) = true)

theorem identity59065 : scanCanonicalize (H12AffineFastState.compose env59065 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59065 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59066 : List Nat := [2,4,8,3,32,32,128,173,1,174,136,1,130,34,170,136,170,139,175,170,171,139,32,3,10,2,2,35,137,170,143,33,173,2,170,0]

theorem envBound59066 : H12AffineFastState.Bounded env59066 := by
  intro p hp
  have h : env59066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59065_59066 : H12AffineEnvironment.transform 7 173 env59065 = env59066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59065 == env59066) = true)

theorem identity59066 : scanCanonicalize (H12AffineFastState.compose env59066 (packedSelected [1,3,4,6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59066 : packedSelected [1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env59067 : List Nat := [2,4,0,3,32,32,128,165,1,166,128,1,130,34,162,128,162,131,167,162,163,131,32,3,2,2,2,35,129,162,135,33,165,2,162,0]

theorem envBound59067 : H12AffineFastState.Bounded env59067 := by
  intro p hp
  have h : env59067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59066_59067 : H12AffineEnvironment.transform 2 0 env59066 = env59067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59066 == env59067) = true)

def env59068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,8388608,8399766,8397000,8388689,2366325,4177,77954,67410,8463814,8465983,256,65675,78034,8389185]

theorem envBound59068 : H12AffineFastState.Bounded env59068 := by
  intro p hp
  have h : env59068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58985_59068 : H12AffineEnvironment.transform 21 1417 env58985 = env59068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env58985 == env59068) = true)

def env59069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9664,3670,1288,9617,2366325,4177,77954,67410,65542,68607,256,65675,78034,10113]

theorem envBound59069 : H12AffineFastState.Bounded env59069 := by
  intro p hp
  have h : env59069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59068_59069 : H12AffineEnvironment.transform 22 9664 env59068 = env59069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59068 == env59069) = true)

def env59070 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3158,1288,9617,2365813,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59070 : H12AffineFastState.Bounded env59070 := by
  intro p hp
  have h : env59070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59069_59070 : H12AffineEnvironment.transform 8 0 env59069 = env59070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59069 == env59070) = true)

theorem identity59070 : scanCanonicalize (H12AffineFastState.compose env59070 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 11609) := by decide +kernel

theorem selectedBound59070 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59071 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,11609,1417,9664,3158,1288,9617,275500,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59071 : H12AffineFastState.Bounded env59071 := by
  intro p hp
  have h : env59071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59070_59071 : H12AffineEnvironment.transform 20 11609 env59070 = env59071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11609 env59070 == env59071) = true)

def env59072 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,2265,1417,64,3158,1288,17,266668,4177,70914,66898,65542,68095,256,65675,70994,1]

theorem envBound59072 : H12AffineFastState.Bounded env59072 := by
  intro p hp
  have h : env59072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59071_59072 : H12AffineEnvironment.transform 12 1408 env59071 = env59072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59071 == env59072) = true)

theorem identity59072 : scanCanonicalize (H12AffineFastState.compose env59072 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound59072 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59073 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,293,1408,373,2128,65536,66679,262144,1025,2128,2265,1417,64,3158,1288,17,262281,372,66599,66898,65542,68095,256,65675,66679,1]

theorem envBound59073 : H12AffineFastState.Bounded env59073 := by
  intro p hp
  have h : env59073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59072_59073 : H12AffineEnvironment.transform 11 293 env59072 = env59073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env59072 == env59073) = true)

theorem identity59073 : scanCanonicalize (H12AffineFastState.compose env59073 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59073 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59074 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,293,1408,373,1449,65536,66679,262144,1025,1449,1312,1417,64,431,1288,17,262281,372,66599,66898,65542,66566,256,65675,66679,1]

theorem envBound59074 : H12AffineFastState.Bounded env59074 := by
  intro p hp
  have h : env59074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59073_59074 : H12AffineEnvironment.transform 10 1529 env59073 = env59074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59073 == env59074) = true)

theorem identity59074 : scanCanonicalize (H12AffineFastState.compose env59074 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1228) := by decide +kernel

theorem selectedBound59074 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59075 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,293,1408,373,1449,65536,66679,1228,1025,1449,1312,1417,64,431,1288,17,1093,372,66599,66898,65542,66566,256,65675,66679,1]

theorem envBound59075 : H12AffineFastState.Bounded env59075 := by
  intro p hp
  have h : env59075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59074_59075 : H12AffineEnvironment.transform 17 1228 env59074 = env59075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1228 env59074 == env59075) = true)

theorem identity59075 : scanCanonicalize (H12AffineFastState.compose env59075 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59075 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59076 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,293,1408,373,1449,1062,81,1228,1025,1449,1312,1417,64,431,1288,17,1093,372,1,372,1056,32,256,1197,81,1]

theorem envBound59076 : H12AffineFastState.Bounded env59076 := by
  intro p hp
  have h : env59076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59075_59076 : H12AffineEnvironment.transform 15 1062 env59075 = env59076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59075 == env59076) = true)

theorem identity59076 : scanCanonicalize (H12AffineFastState.compose env59076 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound59076 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59077 : List Nat := [2,4,8,16,32,64,128,256,0,221,292,293,349,373,372,251,81,17,220,372,509,340,64,431,469,17,152,372,1,372,253,32,256,112,81,1]

theorem envBound59077 : H12AffineFastState.Bounded env59077 := by
  intro p hp
  have h : env59077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59076_59077 : H12AffineEnvironment.transform 9 221 env59076 = env59077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env59076 == env59077) = true)

theorem identity59077 : scanCanonicalize (H12AffineFastState.compose env59077 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59077 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59078 : List Nat := [2,4,8,16,32,64,128,173,0,221,137,136,240,216,217,251,81,17,220,217,80,249,64,2,120,17,152,217,1,217,253,32,173,112,81,1]

theorem envBound59078 : H12AffineFastState.Bounded env59078 := by
  intro p hp
  have h : env59078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59077_59078 : H12AffineEnvironment.transform 7 173 env59077 = env59078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59077 == env59078) = true)

theorem identity59078 : scanCanonicalize (H12AffineFastState.compose env59078 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 58) := by decide +kernel

theorem selectedBound59078 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59079 : List Nat := [2,4,8,16,32,64,58,23,0,103,51,50,74,98,99,65,81,17,102,99,80,67,64,2,120,17,34,99,1,99,71,32,23,112,81,1]

theorem envBound59079 : H12AffineFastState.Bounded env59079 := by
  intro p hp
  have h : env59079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59078_59079 : H12AffineEnvironment.transform 6 58 env59078 = env59079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 58 env59078 == env59079) = true)

theorem identity59079 : scanCanonicalize (H12AffineFastState.compose env59079 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound59079 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env59080 : List Nat := [2,4,8,16,32,2,58,23,0,37,51,50,8,32,33,3,19,17,36,33,18,1,2,2,58,17,34,33,1,33,5,32,23,50,19,1]

theorem envBound59080 : H12AffineFastState.Bounded env59080 := by
  intro p hp
  have h : env59080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59079_59080 : H12AffineEnvironment.transform 5 2 env59079 = env59080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env59079 == env59080) = true)

theorem identity59080 : scanCanonicalize (H12AffineFastState.compose env59080 (packedSelected [0,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound59080 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env59081 : List Nat := [2,4,8,16,24,2,2,23,0,29,11,10,8,24,25,3,19,17,28,25,18,1,2,2,2,17,26,25,1,25,5,24,23,10,19,1]

theorem envBound59081 : H12AffineFastState.Bounded env59081 := by
  intro p hp
  have h : env59081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59080_59081 : H12AffineEnvironment.transform 4 24 env59080 = env59081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env59080 == env59081) = true)

theorem identity59081 : scanCanonicalize (H12AffineFastState.compose env59081 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59081 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59082 : List Nat := [2,4,8,11,3,2,2,12,0,6,11,10,8,3,2,3,8,10,7,2,9,1,2,2,2,10,1,2,1,2,5,3,12,10,8,1]

theorem envBound59082 : H12AffineFastState.Bounded env59082 := by
  intro p hp
  have h : env59082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59081_59082 : H12AffineEnvironment.transform 3 11 env59081 = env59082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59081 == env59082) = true)

def env59083 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,2264,1417,65,3158,1288,16,266669,4177,70915,66898,65542,68095,256,65675,70995,0]

theorem envBound59083 : H12AffineFastState.Bounded env59083 := by
  intro p hp
  have h : env59083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59071_59083 : H12AffineEnvironment.transform 12 1409 env59071 = env59083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59071 == env59083) = true)

theorem identity59083 : scanCanonicalize (H12AffineFastState.compose env59083 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound59083 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59084 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,2264,1417,65,3158,1288,16,266669,4177,1313,5488,4132,6621,256,4265,1393,0]

theorem envBound59084 : H12AffineFastState.Bounded env59084 := by
  intro p hp
  have h : env59084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59083_59084 : H12AffineEnvironment.transform 15 4130 env59083 = env59084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env59083 == env59084) = true)

theorem identity59084 : scanCanonicalize (H12AffineFastState.compose env59084 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 277) := by decide +kernel

theorem selectedBound59084 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59085 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,4130,1393,277,1025,2128,2264,1417,65,3158,1288,16,4280,4177,1313,5488,4132,6621,256,4265,1393,0]

theorem envBound59085 : H12AffineFastState.Bounded env59085 := by
  intro p hp
  have h : env59085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59084_59085 : H12AffineEnvironment.transform 17 277 env59084 = env59085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 277 env59084 == env59085) = true)

theorem identity59085 : scanCanonicalize (H12AffineFastState.compose env59085 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59085 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59086 : List Nat := [2,4,8,16,32,64,128,256,0,236,2048,4096,365,4176,2128,4130,413,277,237,2128,2264,357,65,2234,484,16,4280,4177,461,4508,4132,6621,256,4265,413,0]

theorem envBound59086 : H12AffineFastState.Bounded env59086 := by
  intro p hp
  have h : env59086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59085_59086 : H12AffineEnvironment.transform 9 236 env59085 = env59086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59085 == env59086) = true)

theorem identity59086 : scanCanonicalize (H12AffineFastState.compose env59086 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound59086 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59087 : List Nat := [2,4,8,16,32,64,128,256,0,236,373,4096,365,4176,293,4130,413,277,237,293,429,357,65,463,484,16,4280,4177,461,4508,4132,4264,256,4265,413,0]

theorem envBound59087 : H12AffineFastState.Bounded env59087 := by
  intro p hp
  have h : env59087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59086_59087 : H12AffineEnvironment.transform 10 373 env59086 = env59087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env59086 == env59087) = true)

theorem identity59087 : scanCanonicalize (H12AffineFastState.compose env59087 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59087 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59088 : List Nat := [2,4,8,16,32,64,128,256,0,236,373,461,365,413,293,495,413,277,237,293,429,357,65,463,484,16,373,412,461,81,489,357,256,356,413,0]

theorem envBound59088 : H12AffineFastState.Bounded env59088 := by
  intro p hp
  have h : env59088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59087_59088 : H12AffineEnvironment.transform 11 461 env59087 = env59088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59087 == env59088) = true)

def env59089 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3159,1288,9617,2365812,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59089 : H12AffineFastState.Bounded env59089 := by
  intro p hp
  have h : env59089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59069_59089 : H12AffineEnvironment.transform 8 1 env59069 = env59089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59069 == env59089) = true)

theorem identity59089 : scanCanonicalize (H12AffineFastState.compose env59089 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 2264) := by decide +kernel

theorem selectedBound59089 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59090 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2264,1417,9664,3159,1288,9617,266668,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59090 : H12AffineFastState.Bounded env59090 := by
  intro p hp
  have h : env59090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59089_59090 : H12AffineEnvironment.transform 20 2264 env59089 = env59090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2264 env59089 == env59090) = true)

def env59091 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,2264,1417,64,3159,1288,17,266668,4177,70914,66899,65542,68094,256,65675,70994,0]

theorem envBound59091 : H12AffineFastState.Bounded env59091 := by
  intro p hp
  have h : env59091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59090_59091 : H12AffineEnvironment.transform 12 1408 env59090 = env59091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59090 == env59091) = true)

theorem identity59091 : scanCanonicalize (H12AffineFastState.compose env59091 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound59091 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59092 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,293,1408,373,2129,65536,66679,262144,1025,2129,2264,1417,64,3159,1288,17,262281,372,66599,66899,65542,68094,256,65675,66679,0]

theorem envBound59092 : H12AffineFastState.Bounded env59092 := by
  intro p hp
  have h : env59092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59091_59092 : H12AffineEnvironment.transform 11 293 env59091 = env59092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env59091 == env59092) = true)

theorem identity59092 : scanCanonicalize (H12AffineFastState.compose env59092 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59092 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59093 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,293,1408,373,1449,65536,66679,262144,1025,1449,1312,1417,64,431,1288,17,262281,372,66599,66899,65542,66566,256,65675,66679,0]

theorem envBound59093 : H12AffineFastState.Bounded env59093 := by
  intro p hp
  have h : env59093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59092_59093 : H12AffineEnvironment.transform 10 1528 env59092 = env59093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59092 == env59093) = true)

theorem identity59093 : scanCanonicalize (H12AffineFastState.compose env59093 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1228) := by decide +kernel

theorem selectedBound59093 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59094 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,293,1408,373,1449,65536,66679,1228,1025,1449,1312,1417,64,431,1288,17,1093,372,66599,66899,65542,66566,256,65675,66679,0]

theorem envBound59094 : H12AffineFastState.Bounded env59094 := by
  intro p hp
  have h : env59094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59093_59094 : H12AffineEnvironment.transform 17 1228 env59093 = env59094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1228 env59093 == env59094) = true)

theorem identity59094 : scanCanonicalize (H12AffineFastState.compose env59094 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59094 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59095 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,293,1408,373,1449,1062,81,1228,1025,1449,1312,1417,64,431,1288,17,1093,372,1,373,1056,32,256,1197,81,0]

theorem envBound59095 : H12AffineFastState.Bounded env59095 := by
  intro p hp
  have h : env59095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59094_59095 : H12AffineEnvironment.transform 15 1062 env59094 = env59095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59094 == env59095) = true)

theorem identity59095 : scanCanonicalize (H12AffineFastState.compose env59095 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound59095 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59096 : List Nat := [2,4,8,16,32,64,128,256,1,220,292,293,348,373,373,250,81,16,221,373,508,341,64,431,468,17,153,372,1,373,252,32,256,113,81,0]

theorem envBound59096 : H12AffineFastState.Bounded env59096 := by
  intro p hp
  have h : env59096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59095_59096 : H12AffineEnvironment.transform 9 220 env59095 = env59096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env59095 == env59096) = true)

theorem identity59096 : scanCanonicalize (H12AffineFastState.compose env59096 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59096 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59097 : List Nat := [2,4,8,16,32,17,128,256,1,141,292,293,269,292,292,171,0,16,140,292,429,260,17,431,389,17,153,293,1,292,173,32,256,32,0,0]

theorem envBound59097 : H12AffineFastState.Bounded env59097 := by
  intro p hp
  have h : env59097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59096_59097 : H12AffineEnvironment.transform 5 17 env59096 = env59097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59096 == env59097) = true)

theorem identity59097 : scanCanonicalize (H12AffineFastState.compose env59097 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 159) := by decide +kernel

theorem selectedBound59097 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59098 : List Nat := [2,4,8,16,32,17,128,159,1,141,187,186,146,187,187,171,0,16,140,187,50,155,17,48,26,17,153,186,1,187,173,32,159,32,0,0]

theorem envBound59098 : H12AffineFastState.Bounded env59098 := by
  intro p hp
  have h : env59098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59097_59098 : H12AffineEnvironment.transform 7 159 env59097 = env59098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 159 env59097 == env59098) = true)

theorem identity59098 : scanCanonicalize (H12AffineFastState.compose env59098 (packedSelected [1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound59098 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env59099 : List Nat := [2,4,8,16,32,17,27,4,1,22,32,33,9,32,32,48,0,16,23,32,50,0,17,48,26,17,2,33,1,32,54,32,4,32,0,0]

theorem envBound59099 : H12AffineFastState.Bounded env59099 := by
  intro p hp
  have h : env59099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59098_59099 : H12AffineEnvironment.transform 6 27 env59098 = env59099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env59098 == env59099) = true)

theorem identity59099 : scanCanonicalize (H12AffineFastState.compose env59099 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound59099 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59100 : List Nat := [2,4,8,16,8,17,27,4,1,22,8,9,9,8,8,24,0,16,23,8,26,0,17,24,26,17,2,9,1,8,30,8,4,8,0,0]

theorem envBound59100 : H12AffineFastState.Bounded env59100 := by
  intro p hp
  have h : env59100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59099_59100 : H12AffineEnvironment.transform 4 8 env59099 = env59100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env59099 == env59100) = true)

theorem identity59100 : scanCanonicalize (H12AffineFastState.compose env59100 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59100 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env59101 : List Nat := [2,4,8,11,8,10,0,4,1,13,8,9,9,8,8,3,0,11,12,8,1,0,10,3,1,10,2,9,1,8,5,8,4,8,0,0]

theorem envBound59101 : H12AffineFastState.Bounded env59101 := by
  intro p hp
  have h : env59101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59100_59101 : H12AffineEnvironment.transform 3 11 env59100 = env59101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59100 == env59101) = true)

theorem identity59101 : scanCanonicalize (H12AffineFastState.compose env59101 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59101 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59102 : List Nat := [2,4,3,0,3,1,0,4,1,6,3,2,2,3,3,3,0,0,7,3,1,0,1,3,1,1,2,2,1,3,5,3,4,3,0,0]

theorem envBound59102 : H12AffineFastState.Bounded env59102 := by
  intro p hp
  have h : env59102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59101_59102 : H12AffineEnvironment.transform 2 3 env59101 = env59102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59101 == env59102) = true)

theorem identity59102 : scanCanonicalize (H12AffineFastState.compose env59102 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59102 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59103 : List Nat := [0,4,1,0,1,1,0,4,1,4,1,0,0,1,1,1,0,0,5,1,1,0,1,1,1,1,0,0,1,1,5,1,4,1,0,0]

theorem envBound59103 : H12AffineFastState.Bounded env59103 := by
  intro p hp
  have h : env59103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59102_59103 : H12AffineEnvironment.transform 0 0 env59102 = env59103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59102 == env59103) = true)

def env59104 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,2264,1417,65,3159,1288,16,266668,4177,70915,66899,65542,68094,256,65675,70995,1]

theorem envBound59104 : H12AffineFastState.Bounded env59104 := by
  intro p hp
  have h : env59104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0