import H12CloudChart0Data156

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound39803 : H12AffineFastState.Bounded env39803 := by
  intro p hp
  have h : env39803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39802_39803 : H12AffineEnvironment.transform 11 2318 env39802 = env39803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2318 env39802 == env39803) = true)

theorem identity39803 : scanCanonicalize (H12AffineFastState.compose env39803 (packedSelected [0,2,3,7,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound39803 : packedSelected [0,2,3,7,8,14] rootPS < 2^1333 := by decide +kernel

def env39804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,1386,348,1402,1297,343,1387,1297,1025,1296,1322,33,17,1299,348,64,1124,122,122,0,1365,33,257,1329,1323,513]

theorem envBound39804 : H12AffineFastState.Bounded env39804 := by
  intro p hp
  have h : env39804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39803_39804 : H12AffineEnvironment.transform 10 1124 env39803 = env39804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env39803 == env39804) = true)

theorem identity39804 : scanCanonicalize (H12AffineFastState.compose env39804 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound39804 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env39805 : List Nat := [2,4,8,16,32,43,8,256,512,1024,1039,1281,311,1297,1297,316,1280,1297,1025,1296,1322,33,17,1299,311,43,1039,17,17,0,1342,33,257,1329,1323,513]

theorem envBound39805 : H12AffineFastState.Bounded env39805 := by
  intro p hp
  have h : env39805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39804_39805 : H12AffineEnvironment.transform 5 43 env39804 = env39805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env39804 == env39805) = true)

theorem identity39805 : scanCanonicalize (H12AffineFastState.compose env39805 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39805 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39806 : List Nat := [2,4,8,11,32,43,8,256,512,1024,1039,1281,300,1290,1290,295,1280,1290,1025,1291,1322,33,10,1288,300,43,1039,10,10,0,1317,33,257,1322,1323,513]

theorem envBound39806 : H12AffineFastState.Bounded env39806 := by
  intro p hp
  have h : env39806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39805_39806 : H12AffineEnvironment.transform 3 11 env39805 = env39806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39805 == env39806) = true)

theorem identity39806 : scanCanonicalize (H12AffineFastState.compose env39806 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound39806 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env39807 : List Nat := [2,4,8,11,32,43,8,14,512,1024,1039,1039,34,1028,1028,41,1038,1028,1025,1029,1060,33,10,1030,34,43,1039,10,10,0,1067,33,15,1060,1061,513]

theorem envBound39807 : H12AffineFastState.Bounded env39807 := by
  intro p hp
  have h : env39807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39806_39807 : H12AffineEnvironment.transform 7 14 env39806 = env39807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env39806 == env39807) = true)

theorem identity39807 : scanCanonicalize (H12AffineFastState.compose env39807 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound39807 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env39808 : List Nat := [2,4,8,11,32,43,8,14,34,1024,1039,1039,34,1028,1028,41,1038,1028,1025,1029,1060,33,10,1030,34,43,1039,10,10,0,1067,33,15,1060,1061,35]

theorem envBound39808 : H12AffineFastState.Bounded env39808 := by
  intro p hp
  have h : env39808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39807_39808 : H12AffineEnvironment.transform 8 34 env39807 = env39808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env39807 == env39808) = true)

def env39809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156116,21762,8328,64,215366,115150,140484,303572,241863,498962,257,254010,197023,169744]

theorem envBound39809 : H12AffineFastState.Bounded env39809 := by
  intro p hp
  have h : env39809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39794_39809 : H12AffineEnvironment.transform 20 4161 env39794 = env39809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39794 == env39809) = true)

theorem identity39809 : scanCanonicalize (H12AffineFastState.compose env39809 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound39809 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,4161,329867,120014,21762,8328,64,64604,115150,102878,303572,1501,272392,257,21792,46213,74250]

theorem envBound39810 : H12AffineFastState.Bounded env39810 := by
  intro p hp
  have h : env39810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39809_39810 : H12AffineEnvironment.transform 16 111898 env39809 = env39810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env39809 == env39810) = true)

def env39811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10400,1025,32769,4161,73771,120014,21762,8328,64,64604,115150,102878,35188,1501,168,257,21792,46213,74250]

theorem envBound39811 : H12AffineFastState.Bounded env39811 := by
  intro p hp
  have h : env39811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39810_39811 : H12AffineEnvironment.transform 17 10400 env39810 = env39811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env39810 == env39811) = true)

def env39812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4161,73771,119878,21762,8192,64,64604,115014,102742,35188,1365,32,257,21792,46093,74250]

theorem envBound39812 : H12AffineFastState.Bounded env39812 := by
  intro p hp
  have h : env39812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39811_39812 : H12AffineEnvironment.transform 6 8 env39811 = env39812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39811 == env39812) = true)

theorem identity39812 : scanCanonicalize (H12AffineFastState.compose env39812 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39812 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,70727,10280,1025,8540,4161,73771,95515,21762,8192,64,23809,90139,77835,10281,1365,32,257,21792,5456,74250]

theorem envBound39813 : H12AffineFastState.Bounded env39813 := by
  intro p hp
  have h : env39813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39812_39813 : H12AffineEnvironment.transform 14 8541 env39812 = env39813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39812 == env39813) = true)

theorem identity39813 : scanCanonicalize (H12AffineFastState.compose env39813 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound39813 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env39814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,24908,10280,1025,8540,4161,21792,16,21762,8192,64,23809,5392,17664,10281,1365,32,257,21792,5456,22273]

theorem envBound39814 : H12AffineFastState.Bounded env39814 := by
  intro p hp
  have h : env39814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39813_39814 : H12AffineEnvironment.transform 15 29963 env39813 = env39814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env39813 == env39814) = true)

theorem identity39814 : scanCanonicalize (H12AffineFastState.compose env39814 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound39814 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1297,20807,17664,3172,1025,1296,4161,21792,16,21762,1100,64,23809,5392,17664,3173,1365,32,257,21792,5456,22273]

theorem envBound39815 : H12AffineFastState.Bounded env39815 := by
  intro p hp
  have h : env39815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39814_39815 : H12AffineEnvironment.transform 12 1100 env39814 = env39815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env39814 == env39815) = true)

theorem identity39815 : scanCanonicalize (H12AffineFastState.compose env39815 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound39815 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env39816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4405,1297,114,5173,3172,1025,1296,4161,1045,16,1079,1100,64,3124,5392,5173,3173,1365,32,257,1045,5456,1588]

theorem envBound39816 : H12AffineFastState.Bounded env39816 := by
  intro p hp
  have h : env39816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39815_39816 : H12AffineEnvironment.transform 13 4405 env39815 = env39816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env39815 == env39816) = true)

theorem identity39816 : scanCanonicalize (H12AffineFastState.compose env39816 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39816 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39817 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1100,4113,1077,114,5173,3172,1025,1076,4161,1045,16,1079,1100,64,3124,5172,5173,3173,1137,32,37,1045,5236,1588]

theorem envBound39817 : H12AffineFastState.Bounded env39817 := by
  intro p hp
  have h : env39817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39816_39817 : H12AffineEnvironment.transform 7 36 env39816 = env39817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39816 == env39817) = true)

theorem identity39817 : scanCanonicalize (H12AffineFastState.compose env39817 (packedSelected [1,2,3,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound39817 : packedSelected [1,2,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env39818 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,1100,1124,1077,114,64,3172,1025,1076,1076,1045,16,1079,1100,64,3124,65,64,3173,1137,32,37,1045,1,1588]

theorem envBound39818 : H12AffineFastState.Bounded env39818 := by
  intro p hp
  have h : env39818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39817_39818 : H12AffineEnvironment.transform 11 1141 env39817 = env39818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env39817 == env39818) = true)

theorem identity39818 : scanCanonicalize (H12AffineFastState.compose env39818 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound39818 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env39819 : List Nat := [2,4,8,16,32,64,8,36,512,1024,33,1141,1100,1124,1077,114,64,1093,1025,1076,1076,1045,16,1079,1100,64,1045,65,64,1092,1137,32,37,1045,1,1588]

theorem envBound39819 : H12AffineFastState.Bounded env39819 := by
  intro p hp
  have h : env39819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39818_39819 : H12AffineEnvironment.transform 10 33 env39818 = env39819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env39818 == env39819) = true)

theorem identity39819 : scanCanonicalize (H12AffineFastState.compose env39819 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39819 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env39820 : List Nat := [2,4,8,16,32,64,8,36,512,53,33,64,121,81,0,114,64,112,52,1,1,32,16,2,121,64,32,65,64,113,68,32,37,32,1,513]

theorem envBound39820 : H12AffineFastState.Bounded env39820 := by
  intro p hp
  have h : env39820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39819_39820 : H12AffineEnvironment.transform 9 53 env39819 = env39820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39819 == env39820) = true)

theorem identity39820 : scanCanonicalize (H12AffineFastState.compose env39820 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39820 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39821 : List Nat := [2,4,8,16,32,16,8,36,512,53,33,16,41,1,0,34,16,32,52,1,1,32,16,2,41,16,32,17,16,33,20,32,37,32,1,513]

theorem envBound39821 : H12AffineFastState.Bounded env39821 := by
  intro p hp
  have h : env39821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39820_39821 : H12AffineEnvironment.transform 5 16 env39820 = env39821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39820 == env39821) = true)

theorem identity39821 : scanCanonicalize (H12AffineFastState.compose env39821 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound39821 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39822 : List Nat := [2,4,8,16,5,16,8,1,512,16,4,16,12,1,0,7,16,5,17,1,1,5,16,2,12,16,5,17,16,4,20,5,0,5,1,513]

theorem envBound39822 : H12AffineFastState.Bounded env39822 := by
  intro p hp
  have h : env39822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39821_39822 : H12AffineEnvironment.transform 4 5 env39821 = env39822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env39821 == env39822) = true)

theorem identity39822 : scanCanonicalize (H12AffineFastState.compose env39822 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39822 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39823 : List Nat := [2,2,8,16,3,16,8,1,512,16,2,16,10,1,0,1,16,3,17,1,1,3,16,2,10,16,3,17,16,2,18,3,0,3,1,513]

theorem envBound39823 : H12AffineFastState.Bounded env39823 := by
  intro p hp
  have h : env39823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39822_39823 : H12AffineEnvironment.transform 1 2 env39822 = env39823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39822 == env39823) = true)

theorem identity39823 : scanCanonicalize (H12AffineFastState.compose env39823 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound39823 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39824 : List Nat := [2,2,8,16,3,16,8,1,9,16,2,16,10,1,0,1,16,3,17,1,1,3,16,2,10,16,3,17,16,2,18,3,0,3,1,8]

theorem envBound39824 : H12AffineFastState.Bounded env39824 := by
  intro p hp
  have h : env39824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39823_39824 : H12AffineEnvironment.transform 8 9 env39823 = env39824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env39823 == env39824) = true)

theorem identity39824 : scanCanonicalize (H12AffineFastState.compose env39824 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39824 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39825 : List Nat := [1,1,8,16,0,16,8,1,9,16,1,16,9,1,0,1,16,0,17,1,1,0,16,1,9,16,0,17,16,1,17,0,0,0,1,8]

theorem envBound39825 : H12AffineFastState.Bounded env39825 := by
  intro p hp
  have h : env39825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39824_39825 : H12AffineEnvironment.transform 0 1 env39824 = env39825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39824 == env39825) = true)

def env39826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10281,1025,32769,4161,73771,119879,21762,8193,64,64604,115015,102743,35188,1364,33,257,21792,46092,74250]

theorem envBound39826 : H12AffineFastState.Bounded env39826 := by
  intro p hp
  have h : env39826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39811_39826 : H12AffineEnvironment.transform 6 9 env39811 = env39826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39811 == env39826) = true)

theorem identity39826 : scanCanonicalize (H12AffineFastState.compose env39826 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound39826 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,90138,10281,1025,21761,4161,73771,65863,21762,8193,64,10588,70727,83031,23668,1364,33,257,21792,24844,74250]

theorem envBound39827 : H12AffineFastState.Bounded env39827 := by
  intro p hp
  have h : env39827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39826_39827 : H12AffineEnvironment.transform 14 21760 env39826 = env39827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env39826 == env39827) = true)

theorem identity39827 : scanCanonicalize (H12AffineFastState.compose env39827 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39827 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env39828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,16401,10281,1025,21761,4161,32,8524,21762,8193,64,10588,13388,25692,23668,1364,33,257,21792,24844,513]

theorem envBound39828 : H12AffineFastState.Bounded env39828 := by
  intro p hp
  have h : env39828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39827_39828 : H12AffineEnvironment.transform 15 8203 env39827 = env39828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39827 == env39828) = true)

theorem identity39828 : scanCanonicalize (H12AffineFastState.compose env39828 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39828 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env39829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21760,263,16401,2341,1025,21761,4161,32,64,21762,269,64,2128,5440,17744,23668,1364,33,257,21792,16384,513]

theorem envBound39829 : H12AffineFastState.Bounded env39829 := by
  intro p hp
  have h : env39829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39828_39829 : H12AffineEnvironment.transform 12 268 env39828 = env39829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39828 == env39829) = true)

theorem identity39829 : scanCanonicalize (H12AffineFastState.compose env39829 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39829 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39830 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,263,16401,2341,1025,21761,4113,32,16,21762,269,16,2048,5392,17664,23588,1284,33,257,21792,16384,513]

theorem envBound39830 : H12AffineFastState.Bounded env39830 := by
  intro p hp
  have h : env39830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39829_39830 : H12AffineEnvironment.transform 5 16 env39829 = env39830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39829 == env39830) = true)

theorem identity39830 : scanCanonicalize (H12AffineFastState.compose env39830 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound39830 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39831 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,1,5377,263,16,2341,1025,5376,4113,32,16,5379,269,16,2048,5392,1281,7205,1284,33,257,5409,1,513]

theorem envBound39831 : H12AffineFastState.Bounded env39831 := by
  intro p hp
  have h : env39831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39830_39831 : H12AffineEnvironment.transform 13 1 env39830 = env39831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env39830 == env39831) = true)

theorem identity39831 : scanCanonicalize (H12AffineFastState.compose env39831 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 3882) := by decide +kernel

theorem selectedBound39831 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39832 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3882,268,1,2603,263,16,2341,1025,2602,3899,32,16,2601,269,16,2048,2618,1281,783,1284,33,257,2571,1,513]

theorem envBound39832 : H12AffineFastState.Bounded env39832 := by
  intro p hp
  have h : env39832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39831_39832 : H12AffineEnvironment.transform 11 3882 env39831 = env39832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3882 env39831 == env39832) = true)

theorem identity39832 : scanCanonicalize (H12AffineFastState.compose env39832 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound39832 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env39833 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1044,830,268,1,1599,263,16,1329,1025,1598,815,32,16,1597,269,16,1044,1582,1281,783,1284,33,257,1567,1,513]

theorem envBound39833 : H12AffineFastState.Bounded env39833 := by
  intro p hp
  have h : env39833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39832_39833 : H12AffineEnvironment.transform 10 1044 env39832 = env39833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env39832 == env39833) = true)

theorem identity39833 : scanCanonicalize (H12AffineFastState.compose env39833 (packedSelected [0,2,9] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound39833 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env39834 : List Nat := [2,4,8,16,32,16,9,256,270,1024,1044,48,268,1,1329,263,16,1329,1025,1328,33,32,16,1331,269,16,1044,1312,1281,1,1284,33,257,1297,1,271]

theorem envBound39834 : H12AffineFastState.Bounded env39834 := by
  intro p hp
  have h : env39834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39833_39834 : H12AffineEnvironment.transform 8 270 env39833 = env39834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env39833 == env39834) = true)

theorem identity39834 : scanCanonicalize (H12AffineFastState.compose env39834 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound39834 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env39835 : List Nat := [2,4,8,16,32,16,9,256,270,21,1,48,268,1,292,263,16,292,20,293,33,32,16,294,269,16,1,309,276,1,273,33,257,260,1,271]

theorem envBound39835 : H12AffineFastState.Bounded env39835 := by
  intro p hp
  have h : env39835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39834_39835 : H12AffineEnvironment.transform 9 21 env39834 = env39835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39834 == env39835) = true)

theorem identity39835 : scanCanonicalize (H12AffineFastState.compose env39835 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39835 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39836 : List Nat := [1,4,8,16,32,16,9,256,269,21,1,48,268,1,292,260,16,292,20,293,33,32,16,293,269,16,1,309,276,1,273,33,257,260,1,268]

theorem envBound39836 : H12AffineFastState.Bounded env39836 := by
  intro p hp
  have h : env39836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39835_39836 : H12AffineEnvironment.transform 0 1 env39835 = env39836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39835 == env39836) = true)

def env39837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10401,1025,32769,4161,73770,120014,21762,8328,64,64604,115150,102878,35189,1501,169,257,21792,46213,74250]

theorem envBound39837 : H12AffineFastState.Bounded env39837 := by
  intro p hp
  have h : env39837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39810_39837 : H12AffineEnvironment.transform 17 10401 env39810 = env39837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env39810 == env39837) = true)

def env39838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10281,1025,32769,4161,73770,119878,21762,8192,64,64604,115014,102742,35189,1365,33,257,21792,46093,74250]

theorem envBound39838 : H12AffineFastState.Bounded env39838 := by
  intro p hp
  have h : env39838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39837_39838 : H12AffineEnvironment.transform 6 8 env39837 = env39838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39837 == env39838) = true)

theorem identity39838 : scanCanonicalize (H12AffineFastState.compose env39838 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound39838 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,49169,10281,1025,32769,4161,21793,41293,21762,8192,64,64604,46157,58461,35189,1365,33,257,21792,46093,22273]

theorem envBound39839 : H12AffineFastState.Bounded env39839 := by
  intro p hp
  have h : env39839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39838_39839 : H12AffineEnvironment.transform 15 29963 env39838 = env39839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env39838 == env39839) = true)

theorem identity39839 : scanCanonicalize (H12AffineFastState.compose env39839 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound39839 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env39840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,343,46157,10281,1025,32769,4161,8573,41293,8542,8192,64,34816,46157,36865,35189,1365,33,257,8572,46093,9053]

theorem envBound39840 : H12AffineFastState.Bounded env39840 := by
  intro p hp
  have h : env39840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39839_39840 : H12AffineEnvironment.transform 13 13404 env39839 = env39840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env39839 == env39840) = true)

theorem identity39840 : scanCanonicalize (H12AffineFastState.compose env39840 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39840 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39841 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13404,32768,35,46157,10281,1025,32769,4161,8201,41017,8234,8192,64,34816,46157,36865,34817,1057,33,117,8200,46093,8745]

theorem envBound39841 : H12AffineFastState.Bounded env39841 := by
  intro p hp
  have h : env39841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39840_39841 : H12AffineEnvironment.transform 7 116 env39840 = env39841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39840 == env39841) = true)

theorem identity39841 : scanCanonicalize (H12AffineFastState.compose env39841 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound39841 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39842 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,32768,35,37989,2049,1025,32769,4161,33,32785,2,40,64,34816,37989,36865,34817,1057,33,117,32,37925,513]

theorem envBound39842 : H12AffineFastState.Bounded env39842 := by
  intro p hp
  have h : env39842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39841_39842 : H12AffineEnvironment.transform 12 40 env39841 = env39842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env39841 == env39842) = true)

theorem identity39842 : scanCanonicalize (H12AffineFastState.compose env39842 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound39842 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env39843 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,0,40,1140,32768,35,33893,2049,1025,32769,65,33,32785,2,40,64,34816,33893,32769,34817,1057,33,117,32,33829,513]

theorem envBound39843 : H12AffineFastState.Bounded env39843 := by
  intro p hp
  have h : env39843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39842_39843 : H12AffineEnvironment.transform 11 0 env39842 = env39843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39842 == env39843) = true)

def env39844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10280,1025,32769,4161,73770,119879,21762,8193,64,64604,115015,102743,35189,1364,32,257,21792,46092,74250]

theorem envBound39844 : H12AffineFastState.Bounded env39844 := by
  intro p hp
  have h : env39844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39837_39844 : H12AffineEnvironment.transform 6 9 env39837 = env39844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39837 == env39844) = true)

theorem identity39844 : scanCanonicalize (H12AffineFastState.compose env39844 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound39844 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,10280,1025,32769,4161,62589,16,21762,8193,64,64604,5392,17664,35189,1364,32,257,21792,46092,63069]

theorem envBound39845 : H12AffineFastState.Bounded env39845 := by
  intro p hp
  have h : env39845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39844_39845 : H12AffineEnvironment.transform 15 54359 env39844 = env39845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env39844 == env39845) = true)

theorem identity39845 : scanCanonicalize (H12AffineFastState.compose env39845 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound39845 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1297,20806,24909,10280,1025,1296,4161,29036,16,21762,8193,64,31053,5392,17664,3172,1364,32,257,21792,12573,29516]

theorem envBound39846 : H12AffineFastState.Bounded env39846 := by
  intro p hp
  have h : env39846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39845_39846 : H12AffineEnvironment.transform 14 1297 env39845 = env39846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env39845 == env39846) = true)

theorem identity39846 : scanCanonicalize (H12AffineFastState.compose env39846 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound39846 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,1297,342,12637,10280,1025,1296,4161,8572,16,1298,8193,64,10589,5392,5392,3172,1364,32,257,1328,12573,9052]

theorem envBound39847 : H12AffineFastState.Bounded env39847 := by
  intro p hp
  have h : env39847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39846_39847 : H12AffineEnvironment.transform 13 4112 env39846 = env39847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env39846 == env39847) = true)

theorem identity39847 : scanCanonicalize (H12AffineFastState.compose env39847 (packedSelected [11,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound39847 : packedSelected [11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env39848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1141,4096,8192,4112,1297,342,12637,9309,1025,1296,4161,8572,16,1298,8193,64,9512,5392,5392,17,1364,32,257,1328,12573,9052]

theorem envBound39848 : H12AffineFastState.Bounded env39848 := by
  intro p hp
  have h : env39848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39847_39848 : H12AffineEnvironment.transform 10 1141 env39847 = env39848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env39847 == env39848) = true)

theorem identity39848 : scanCanonicalize (H12AffineFastState.compose env39848 (packedSelected [1,8,11,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39848 : packedSelected [1,8,11,18,19] rootPS < 2^1333 := by decide +kernel

def env39849 : List Nat := [2,4,8,16,32,64,9,256,512,53,64,4096,8192,4112,292,342,12637,8296,52,293,4161,8572,16,295,8193,64,8477,4389,4389,17,353,32,257,261,12573,9052]

theorem envBound39849 : H12AffineFastState.Bounded env39849 := by
  intro p hp
  have h : env39849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39848_39849 : H12AffineEnvironment.transform 9 53 env39848 = env39849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39848 == env39849) = true)

theorem identity39849 : scanCanonicalize (H12AffineFastState.compose env39849 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39849 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39850 : List Nat := [2,4,8,16,32,64,9,256,512,53,64,4096,269,4112,292,342,4176,357,52,293,4161,113,16,295,268,64,16,4389,4389,17,353,32,257,261,4112,593]

theorem envBound39850 : H12AffineFastState.Bounded env39850 := by
  intro p hp
  have h : env39850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39849_39850 : H12AffineEnvironment.transform 12 269 env39849 = env39850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39849 == env39850) = true)

theorem identity39850 : scanCanonicalize (H12AffineFastState.compose env39850 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39850 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env39851 : List Nat := [2,4,8,1,32,64,9,256,512,36,64,4096,269,4097,292,327,4161,357,37,293,4161,96,1,295,268,64,1,4389,4389,0,353,32,257,261,4097,576]

theorem envBound39851 : H12AffineFastState.Bounded env39851 := by
  intro p hp
  have h : env39851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39850_39851 : H12AffineEnvironment.transform 3 1 env39850 = env39851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39850 == env39851) = true)

theorem identity39851 : scanCanonicalize (H12AffineFastState.compose env39851 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound39851 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39852 : List Nat := [2,4,8,1,32,64,9,101,512,36,64,4096,104,4097,65,34,4161,0,37,64,4161,96,1,66,105,64,1,4160,4160,0,4,32,100,96,4097,576]

theorem envBound39852 : H12AffineFastState.Bounded env39852 := by
  intro p hp
  have h : env39852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39851_39852 : H12AffineEnvironment.transform 7 101 env39851 = env39852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env39851 == env39852) = true)

theorem identity39852 : scanCanonicalize (H12AffineFastState.compose env39852 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound39852 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39853 : List Nat := [2,4,8,1,32,64,9,101,512,36,64,64,104,65,65,34,1,0,37,64,1,96,1,66,105,64,1,0,0,0,4,32,100,96,65,576]

theorem envBound39853 : H12AffineFastState.Bounded env39853 := by
  intro p hp
  have h : env39853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39852_39853 : H12AffineEnvironment.transform 11 64 env39852 = env39853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env39852 == env39853) = true)

theorem identity39853 : scanCanonicalize (H12AffineFastState.compose env39853 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39853 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env39854 : List Nat := [2,4,8,1,32,0,9,37,512,36,0,0,40,1,1,34,1,0,37,0,1,32,1,2,41,0,1,0,0,0,4,32,36,32,1,512]

theorem envBound39854 : H12AffineFastState.Bounded env39854 := by
  intro p hp
  have h : env39854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39853_39854 : H12AffineEnvironment.transform 5 0 env39853 = env39854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39853 == env39854) = true)

theorem identity39854 : scanCanonicalize (H12AffineFastState.compose env39854 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound39854 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39855 : List Nat := [2,4,8,1,5,0,9,0,512,1,0,0,13,1,1,7,1,0,0,0,1,5,1,2,12,0,1,0,0,0,4,5,1,5,1,512]

theorem envBound39855 : H12AffineFastState.Bounded env39855 := by
  intro p hp
  have h : env39855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39854_39855 : H12AffineEnvironment.transform 4 5 env39854 = env39855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env39854 == env39855) = true)

theorem identity39855 : scanCanonicalize (H12AffineFastState.compose env39855 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound39855 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39856 : List Nat := [2,4,8,1,5,0,9,0,12,1,0,0,13,1,1,7,1,0,0,0,1,5,1,2,12,0,1,0,0,0,4,5,1,5,1,12]

theorem envBound39856 : H12AffineFastState.Bounded env39856 := by
  intro p hp
  have h : env39856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39855_39856 : H12AffineEnvironment.transform 8 12 env39855 = env39856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env39855 == env39856) = true)

theorem identity39856 : scanCanonicalize (H12AffineFastState.compose env39856 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39856 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39857 : List Nat := [2,1,8,1,0,0,9,0,9,1,0,0,8,1,1,2,1,0,0,0,1,0,1,2,9,0,1,0,0,0,1,0,1,0,1,9]

theorem envBound39857 : H12AffineFastState.Bounded env39857 := by
  intro p hp
  have h : env39857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39856_39857 : H12AffineEnvironment.transform 1 1 env39856 = env39857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39856 == env39857) = true)

theorem identity39857 : scanCanonicalize (H12AffineFastState.compose env39857 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39857 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39858 : List Nat := [2,1,2,1,0,0,3,0,3,1,0,0,2,1,1,2,1,0,0,0,1,0,1,2,3,0,1,0,0,0,1,0,1,0,1,3]

theorem envBound39858 : H12AffineFastState.Bounded env39858 := by
  intro p hp
  have h : env39858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39857_39858 : H12AffineEnvironment.transform 2 2 env39857 = env39858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39857 == env39858) = true)

def env39859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534865,156116,2114883,8328,64,215367,115150,2241669,303572,2334854,2592082,257,254010,197023,2262865]

theorem envBound39859 : H12AffineFastState.Bounded env39859 := by
  intro p hp
  have h : env39859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39793_39859 : H12AffineEnvironment.transform 21 2534865 env39793 = env39859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534865 env39793 == env39859) = true)

def env39860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156116,21763,8328,64,215367,115150,140485,303572,241862,498962,257,254010,197023,169745]

theorem envBound39860 : H12AffineFastState.Bounded env39860 := by
  intro p hp
  have h : env39860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39859_39860 : H12AffineEnvironment.transform 20 4160 env39859 = env39860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39859 == env39860) = true)

theorem identity39860 : scanCanonicalize (H12AffineFastState.compose env39860 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound39860 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,4160,392287,73754,21763,8328,64,2185,115150,91403,303572,61704,318684,257,41460,16465,120543]

theorem envBound39861 : H12AffineFastState.Bounded env39861 := by
  intro p hp
  have h : env39861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39860_39861 : H12AffineEnvironment.transform 16 82382 env39860 = env39861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env39860 == env39861) = true)

def env39862 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,4112,392207,73754,21763,8328,16,2185,115102,91403,303492,61704,318604,257,41380,16385,120463]

theorem envBound39862 : H12AffineFastState.Bounded env39862 := by
  intro p hp
  have h : env39862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39861_39862 : H12AffineEnvironment.transform 5 16 env39861 = env39862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39861 == env39862) = true)

theorem identity39862 : scanCanonicalize (H12AffineFastState.compose env39862 (packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound39862 : packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS < 2^1333 := by decide +kernel

def env39863 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,76079,1025,32769,4112,54560,73754,21763,8328,16,2185,115102,91403,100523,61704,128419,257,41380,16385,120463]

theorem envBound39863 : H12AffineFastState.Bounded env39863 := by
  intro p hp
  have h : env39863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39862_39863 : H12AffineEnvironment.transform 17 76079 env39862 = env39863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env39862 == env39863) = true)

theorem identity39863 : scanCanonicalize (H12AffineFastState.compose env39863 (packedSelected [0,4,7,11,17,19,22,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound39863 : packedSelected [0,4,7,11,17,19,22,26,32] rootPS < 2^1333 := by decide +kernel

def env39864 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33167,49169,43168,1025,32769,4112,54560,41365,21763,8328,16,2185,16401,58500,2340,61704,29740,257,41380,16385,22272]

theorem envBound39864 : H12AffineFastState.Bounded env39864 := by
  intro p hp
  have h : env39864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39863_39864 : H12AffineEnvironment.transform 15 33167 env39863 = env39864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env39863 == env39864) = true)

theorem identity39864 : scanCanonicalize (H12AffineFastState.compose env39864 (packedSelected [16,18,19,20,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound39864 : packedSelected [16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env39865 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21761,21646,5392,32161,1025,21760,4112,33,29844,21763,8328,16,2185,16401,12677,2340,9225,29740,257,29861,16385,22272]

theorem envBound39865 : H12AffineFastState.Bounded env39865 := by
  intro p hp
  have h : env39865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39864_39865 : H12AffineEnvironment.transform 14 21761 env39864 = env39865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env39864 == env39865) = true)

theorem identity39865 : scanCanonicalize (H12AffineFastState.compose env39865 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39865 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env39866 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,0,399,5392,10400,1025,1,4112,33,8597,2,8328,16,2185,5392,12677,2340,9225,8493,257,8612,5376,513]

theorem envBound39866 : H12AffineFastState.Bounded env39866 := by
  intro p hp
  have h : env39866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39865_39866 : H12AffineEnvironment.transform 13 5377 env39865 = env39866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39865 == env39866) = true)

theorem identity39866 : scanCanonicalize (H12AffineFastState.compose env39866 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39866 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env39867 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,0,399,5392,2477,1025,1,4112,33,152,2,389,16,2185,5392,4232,2340,1284,32,257,169,5376,513]

theorem envBound39867 : H12AffineFastState.Bounded env39867 := by
  intro p hp
  have h : env39867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39866_39867 : H12AffineEnvironment.transform 12 269 env39866 = env39867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39866 == env39867) = true)

theorem identity39867 : scanCanonicalize (H12AffineFastState.compose env39867 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39867 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39868 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,263,5392,2341,1025,1,4112,33,16,2,269,16,2049,5392,4096,2340,1284,32,257,33,5376,513]

theorem envBound39868 : H12AffineFastState.Bounded env39868 := by
  intro p hp
  have h : env39868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39867_39868 : H12AffineEnvironment.transform 6 8 env39867 = env39868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39867 == env39868) = true)

theorem identity39868 : scanCanonicalize (H12AffineFastState.compose env39868 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39868 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39869 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,269,4112,0,263,4097,2341,272,1,4112,33,16,2,269,16,2049,4097,4096,2340,21,32,257,33,4113,513]

theorem envBound39869 : H12AffineFastState.Bounded env39869 := by
  intro p hp
  have h : env39869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39868_39869 : H12AffineEnvironment.transform 9 273 env39868 = env39869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39868 == env39869) = true)

theorem identity39869 : scanCanonicalize (H12AffineFastState.compose env39869 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound39869 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39870 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2065,269,2049,0,263,2064,2341,272,1,2049,33,16,2,269,16,2049,2064,2065,2340,21,32,257,33,2048,513]

theorem envBound39870 : H12AffineFastState.Bounded env39870 := by
  intro p hp
  have h : env39870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39869_39870 : H12AffineEnvironment.transform 11 2065 env39869 = env39870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env39869 == env39870) = true)

theorem identity39870 : scanCanonicalize (H12AffineFastState.compose env39870 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39870 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39871 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,41,2049,0,35,2064,2049,52,1,2049,33,16,2,41,16,2049,2064,2065,2048,21,32,37,33,2048,513]

theorem envBound39871 : H12AffineFastState.Bounded env39871 := by
  intro p hp
  have h : env39871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39870_39871 : H12AffineEnvironment.transform 7 36 env39870 = env39871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39870 == env39871) = true)

theorem identity39871 : scanCanonicalize (H12AffineFastState.compose env39871 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound39871 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39872 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,33,41,49,0,35,32,49,52,1,49,33,16,2,41,16,49,32,33,48,21,32,37,33,48,513]

theorem envBound39872 : H12AffineFastState.Bounded env39872 := by
  intro p hp
  have h : env39872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39871_39872 : H12AffineEnvironment.transform 10 48 env39871 = env39872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env39871 == env39872) = true)

def leafEnv39872 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,33,41,49,0,35,32,49,52,1,49,33,16,2,20,41,1,16,49,32,33,48,21,32,37,33,5,35,48,513,1,48,0]

def active39872 : List Nat := [0,1,2,3,4,8]

def tree39872 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39872 : H12WitnessSearch.Good tree39872 := H12GlobalWitnessIndex.good

theorem leafIdentity39872 : H12AffineFastState.composeSystem env39872 rootObs = leafEnv39872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39872 rootObs == leafEnv39872) = true)

theorem terminalChecked39872 : H12PackedTerminal.terminalCheckFast leafEnv39872 active39872 tree39872 = true := by decide +kernel

def env39873 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,4113,392206,73754,21763,8328,17,2185,115103,91403,303493,61704,318605,257,41381,16384,120462]

theorem envBound39873 : H12AffineFastState.Bounded env39873 := by
  intro p hp
  have h : env39873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39861_39873 : H12AffineEnvironment.transform 5 17 env39861 = env39873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39861 == env39873) = true)

theorem identity39873 : scanCanonicalize (H12AffineFastState.compose env39873 (packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound39873 : packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS < 2^1333 := by decide +kernel

def env39874 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40971,57748,262144,1025,32769,4113,285701,32785,21763,8328,17,2185,24980,50432,303493,61704,318605,257,41381,16384,30341]

theorem envBound39874 : H12AffineFastState.Bounded env39874 := by
  intro p hp
  have h : env39874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39873_39874 : H12AffineEnvironment.transform 15 40971 env39873 = env39874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env39873 == env39874) = true)

theorem identity39874 : scanCanonicalize (H12AffineFastState.compose env39874 (packedSelected [0,3,9,19,22,24,27,31] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound39874 : packedSelected [0,3,9,19,22,24,27,31] rootPS < 2^1333 := by decide +kernel

def env39875 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,40971,46109,262144,1025,32769,4113,264588,32785,138,8328,17,2185,13341,37001,303493,42113,297220,257,41381,5513,8972]

theorem envBound39875 : H12AffineFastState.Bounded env39875 := by
  intro p hp
  have h : env39875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39874_39875 : H12AffineEnvironment.transform 13 5513 env39874 = env39875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env39874 == env39875) = true)

theorem identity39875 : scanCanonicalize (H12AffineFastState.compose env39875 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound39875 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env39876 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,40971,46109,10281,1025,32769,4113,8613,32785,138,8328,17,2185,13341,37001,35244,42113,41261,257,41381,5513,8972]

theorem envBound39876 : H12AffineFastState.Bounded env39876 := by
  intro p hp
  have h : env39876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39875_39876 : H12AffineEnvironment.transform 17 10281 env39875 = env39876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39875 == env39876) = true)

theorem identity39876 : scanCanonicalize (H12AffineFastState.compose env39876 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound39876 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env39877 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,136,8323,13461,10281,1025,137,4113,8613,153,138,8328,17,2185,13341,4097,2340,9225,8613,257,8493,5513,8972]

theorem envBound39877 : H12AffineFastState.Bounded env39877 := by
  intro p hp
  have h : env39877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39876_39877 : H12AffineEnvironment.transform 14 136 env39876 = env39877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env39876 == env39877) = true)

theorem identity39877 : scanCanonicalize (H12AffineFastState.compose env39877 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39877 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env39878 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5513,136,398,5528,2340,1025,137,4113,168,153,138,389,17,2185,5392,4097,2340,1284,168,257,32,5513,513]

theorem envBound39878 : H12AffineFastState.Bounded env39878 := by
  intro p hp
  have h : env39878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39877_39878 : H12AffineEnvironment.transform 12 269 env39877 = env39878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39877 == env39878) = true)

theorem identity39878 : scanCanonicalize (H12AffineFastState.compose env39878 (packedSelected [0,2,3,5,7,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39878 : packedSelected [0,2,3,5,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env39879 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,263,5393,2340,1025,0,4113,33,16,3,268,17,2048,5392,4097,2340,1284,33,257,32,5376,513]

theorem envBound39879 : H12AffineFastState.Bounded env39879 := by
  intro p hp
  have h : env39879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39878_39879 : H12AffineEnvironment.transform 6 9 env39878 = env39879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39878 == env39879) = true)

theorem identity39879 : scanCanonicalize (H12AffineFastState.compose env39879 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39880 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,1,34,5172,2049,1025,0,4113,33,16,3,41,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound39880 : H12AffineFastState.Bounded env39880 := by
  intro p hp
  have h : env39880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39879_39880 : H12AffineEnvironment.transform 7 37 env39879 = env39880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39879 == env39880) = true)

def env39881 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1045,1,34,1028,2049,1025,0,33,33,16,3,41,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound39881 : H12AffineFastState.Bounded env39881 := by
  intro p hp
  have h : env39881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39880_39881 : H12AffineEnvironment.transform 11 48 env39880 = env39881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39880 == env39881) = true)

def env39882 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,48,40,33,1,34,48,2049,53,0,33,33,16,3,41,17,2048,49,49,2049,21,33,36,32,33,513]

theorem envBound39882 : H12AffineFastState.Bounded env39882 := by
  intro p hp
  have h : env39882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39881_39882 : H12AffineEnvironment.transform 9 52 env39881 = env39882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39881 == env39882) = true)

theorem identity39882 : scanCanonicalize (H12AffineFastState.compose env39882 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound39882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39883 : List Nat := [2,4,8,16,32,17,9,37,43,52,2048,48,40,33,1,34,48,2049,53,0,33,33,16,3,41,17,2048,49,49,2049,21,33,36,32,33,42]

theorem envBound39883 : H12AffineFastState.Bounded env39883 := by
  intro p hp
  have h : env39883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39882_39883 : H12AffineEnvironment.transform 8 43 env39882 = env39883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env39882 == env39883) = true)

def leafEnv39883 : List Nat := [2,4,8,16,32,17,9,37,43,52,2048,48,40,33,1,34,48,2049,53,0,33,33,16,3,20,41,1,17,2048,49,49,2049,21,33,36,32,5,35,33,42,1,33,0]

def active39883 : List Nat := [0,1,2,3,4,10]

def tree39883 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39883 : H12WitnessSearch.Good tree39883 := H12GlobalWitnessIndex.good

theorem leafIdentity39883 : H12AffineFastState.composeSystem env39883 rootObs = leafEnv39883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39883 rootObs == leafEnv39883) = true)

theorem terminalChecked39883 : H12PackedTerminal.terminalCheckFast leafEnv39883 active39883 tree39883 = true := by decide +kernel

def env39884 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,48,40,32,1,34,49,2049,52,0,33,33,16,3,41,17,2048,48,49,2049,20,33,36,32,32,513]

theorem envBound39884 : H12AffineFastState.Bounded env39884 := by
  intro p hp
  have h : env39884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39881_39884 : H12AffineEnvironment.transform 9 53 env39881 = env39884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39881 == env39884) = true)

def env39885 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1044,1,34,1029,2049,1025,0,32,33,16,3,41,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound39885 : H12AffineFastState.Bounded env39885 := by
  intro p hp
  have h : env39885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39880_39885 : H12AffineEnvironment.transform 11 49 env39880 = env39885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env39880 == env39885) = true)

theorem identity39885 : scanCanonicalize (H12AffineFastState.compose env39885 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound39885 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39886 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,40,32,1,34,49,2049,53,0,32,33,16,3,41,17,2048,48,48,2049,21,33,36,32,32,513]

theorem envBound39886 : H12AffineFastState.Bounded env39886 := by
  intro p hp
  have h : env39886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39885_39886 : H12AffineEnvironment.transform 9 52 env39885 = env39886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39885 == env39886) = true)

theorem identity39886 : scanCanonicalize (H12AffineFastState.compose env39886 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound39886 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39887 : List Nat := [2,4,8,16,32,17,9,37,42,52,2048,49,40,32,1,34,49,2049,53,0,32,33,16,3,41,17,2048,48,48,2049,21,33,36,32,32,43]

theorem envBound39887 : H12AffineFastState.Bounded env39887 := by
  intro p hp
  have h : env39887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39886_39887 : H12AffineEnvironment.transform 8 42 env39886 = env39887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env39886 == env39887) = true)

def leafEnv39887 : List Nat := [2,4,8,16,32,17,9,37,42,52,2048,49,40,32,1,34,49,2049,53,0,32,33,16,3,20,41,1,17,2048,48,48,2049,21,33,36,32,5,35,32,43,1,32,0]

def active39887 : List Nat := [0,1,2,3,4,10]

def tree39887 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39887 : H12WitnessSearch.Good tree39887 := H12GlobalWitnessIndex.good

theorem leafIdentity39887 : H12AffineFastState.composeSystem env39887 rootObs = leafEnv39887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39887 rootObs == leafEnv39887) = true)

theorem terminalChecked39887 : H12PackedTerminal.terminalCheckFast leafEnv39887 active39887 tree39887 = true := by decide +kernel

def env39888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156116,21762,8328,64,215367,115150,140484,303572,241863,498963,257,254010,197023,169744]

theorem envBound39888 : H12AffineFastState.Bounded env39888 := by
  intro p hp
  have h : env39888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39859_39888 : H12AffineEnvironment.transform 20 4161 env39859 = env39888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39859 == env39888) = true)

theorem identity39888 : scanCanonicalize (H12AffineFastState.compose env39888 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound39888 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,441744,156116,21762,8328,64,171416,5393,140484,303572,156696,412108,257,144613,185664,169744]

theorem envBound39889 : H12AffineFastState.Bounded env39889 := by
  intro p hp
  have h : env39889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39888_39889 : H12AffineEnvironment.transform 15 54495 env39888 = env39889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env39888 == env39889) = true)

def env39890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10280,1025,32769,4161,169400,156116,21762,8328,64,171416,5393,140484,35324,156696,156132,257,144613,185664,169744]

theorem envBound39890 : H12AffineFastState.Bounded env39890 := by
  intro p hp
  have h : env39890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39889_39890 : H12AffineEnvironment.transform 17 10280 env39889 = env39890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39889 == env39890) = true)

theorem identity39890 : scanCanonicalize (H12AffineFastState.compose env39890 (packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound39890 : packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS < 2^1333 := by decide +kernel

def env39891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,45217,10280,1025,32769,4161,9497,53621,21762,8328,64,11577,5393,37989,35324,54457,53573,257,33860,26081,10161]

theorem envBound39891 : H12AffineFastState.Bounded env39891 := by
  intro p hp
  have h : env39891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39890_39891 : H12AffineEnvironment.transform 16 45217 env39890 = env39891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env39890 == env39891) = true)

theorem identity39891 : scanCanonicalize (H12AffineFastState.compose env39891 (packedSelected [3,5,8,15,16,17,19,20,26,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound39891 : packedSelected [3,5,8,15,16,17,19,20,26,28,38] rootPS < 2^1333 := by decide +kernel

def env39892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,30162,4524,10280,1025,8460,4161,9497,28792,21762,8328,64,11577,5393,13672,10481,30132,28744,257,9545,26081,10161]

theorem envBound39892 : H12AffineFastState.Bounded env39892 := by
  intro p hp
  have h : env39892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39891_39892 : H12AffineEnvironment.transform 14 8461 env39891 = env39892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env39891 == env39892) = true)

theorem identity39892 : scanCanonicalize (H12AffineFastState.compose env39892 (packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound39892 : packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env39893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,293,22010,4524,2048,1025,292,4161,1329,20560,21762,160,64,3345,5393,5440,2265,21916,20576,257,1377,17865,1945]

theorem envBound39893 : H12AffineFastState.Bounded env39893 := by
  intro p hp
  have h : env39893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39892_39893 : H12AffineEnvironment.transform 12 40 env39892 = env39893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env39892 == env39893) = true)

theorem identity39893 : scanCanonicalize (H12AffineFastState.compose env39893 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound39893 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env39894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,4541,293,1095,4524,2048,1025,292,4161,1329,493,1215,160,64,3345,5393,5440,2265,1057,477,257,1377,5236,1945]

theorem envBound39894 : H12AffineFastState.Bounded env39894 := by
  intro p hp
  have h : env39894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39893_39894 : H12AffineEnvironment.transform 13 4541 env39893 = env39894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env39893 == env39894) = true)

theorem identity39894 : scanCanonicalize (H12AffineFastState.compose env39894 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound39894 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39895 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,40,4541,293,479,4524,2048,409,292,4161,169,493,295,160,64,2185,4233,4312,2265,441,477,257,249,4588,513]

theorem envBound39895 : H12AffineFastState.Bounded env39895 := by
  intro p hp
  have h : env39895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39894_39895 : H12AffineEnvironment.transform 9 408 env39894 = env39895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env39894 == env39895) = true)

theorem identity39895 : scanCanonicalize (H12AffineFastState.compose env39895 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound39895 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39896 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,40,4453,293,263,4468,2048,321,292,4161,113,309,295,120,64,2129,4177,4096,2049,353,261,257,33,4404,513]

theorem envBound39896 : H12AffineFastState.Bounded env39896 := by
  intro p hp
  have h : env39896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39895_39896 : H12AffineEnvironment.transform 6 88 env39895 = env39896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env39895 == env39896) = true)

theorem identity39896 : scanCanonicalize (H12AffineFastState.compose env39896 (packedSelected [2,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39896 : packedSelected [2,10,11] rootPS < 2^1333 := by decide +kernel

def env39897 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,40,4404,293,263,4389,2048,272,292,4112,32,309,295,41,17,2048,4096,4096,2049,304,261,257,33,4404,513]

theorem envBound39897 : H12AffineFastState.Bounded env39897 := by
  intro p hp
  have h : env39897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39896_39897 : H12AffineEnvironment.transform 5 17 env39896 = env39897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39896 == env39897) = true)

theorem identity39897 : scanCanonicalize (H12AffineFastState.compose env39897 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound39897 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env39898 : List Nat := [2,4,8,16,32,17,9,256,512,273,292,4096,40,4404,293,263,4389,292,272,292,4112,32,309,295,41,17,292,4096,4096,293,304,261,257,33,4404,513]

theorem envBound39898 : H12AffineFastState.Bounded env39898 := by
  intro p hp
  have h : env39898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39897_39898 : H12AffineEnvironment.transform 10 292 env39897 = env39898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env39897 == env39898) = true)

theorem identity39898 : scanCanonicalize (H12AffineFastState.compose env39898 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound39898 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39899 : List Nat := [2,4,8,16,32,17,9,256,512,273,292,308,40,0,293,263,17,292,272,292,292,32,309,295,41,17,292,308,308,293,304,261,257,33,0,513]

theorem envBound39899 : H12AffineFastState.Bounded env39899 := by
  intro p hp
  have h : env39899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39898_39899 : H12AffineEnvironment.transform 11 308 env39898 = env39899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env39898 == env39899) = true)

def env39900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10281,1025,32769,4161,169401,156116,21762,8328,64,171416,5393,140484,35325,156696,156133,257,144613,185664,169744]

theorem envBound39900 : H12AffineFastState.Bounded env39900 := by
  intro p hp
  have h : env39900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39889_39900 : H12AffineEnvironment.transform 17 10281 env39889 = env39900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39889 == env39900) = true)

theorem identity39900 : scanCanonicalize (H12AffineFastState.compose env39900 (packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound39900 : packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS < 2^1333 := by decide +kernel

def env39901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,10281,1025,29908,4161,156012,156116,21762,8328,64,158029,5393,140484,32040,156696,156133,257,144613,139669,156613]

theorem envBound39901 : H12AffineFastState.Bounded env39901 := by
  intro p hp
  have h : env39901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39900_39901 : H12AffineEnvironment.transform 14 29909 env39900 = env39901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env39900 == env39901) = true)

theorem identity39901 : scanCanonicalize (H12AffineFastState.compose env39901 (packedSelected [0,2,3,5,6,7,10,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound39901 : packedSelected [0,2,3,5,6,7,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env39902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,217,8202,131072,10281,1025,216,4161,136544,136664,8462,8328,64,138561,5393,140484,2340,135188,136681,257,144613,139669,137161]

theorem envBound39902 : H12AffineFastState.Bounded env39902 := by
  intro p hp
  have h : env39902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39901_39902 : H12AffineEnvironment.transform 13 13324 env39901 = env39902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env39901 == env39902) = true)

theorem identity39902 : scanCanonicalize (H12AffineFastState.compose env39902 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39902 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env39903 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,136,8202,131072,10281,1025,137,4112,136497,136585,8462,8328,17,138512,5393,140437,2340,135188,136632,257,144564,139669,137112]

theorem envBound39903 : H12AffineFastState.Bounded env39903 := by
  intro p hp
  have h : env39903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39902_39903 : H12AffineEnvironment.transform 5 17 env39902 = env39903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39902 == env39903) = true)

theorem identity39903 : scanCanonicalize (H12AffineFastState.compose env39903 (packedSelected [0,1,2,6,7,8,11,16,17,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound39903 : packedSelected [0,1,2,6,7,8,11,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env39904 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,136,8202,13460,10281,1025,137,4112,8613,8477,8462,8328,17,10628,5393,4097,2340,9344,8492,257,32,5377,8972]

theorem envBound39904 : H12AffineFastState.Bounded env39904 := by
  intro p hp
  have h : env39904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39903_39904 : H12AffineEnvironment.transform 16 13460 env39903 = env39904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env39903 == env39904) = true)

theorem identity39904 : scanCanonicalize (H12AffineFastState.compose env39904 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39904 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env39905 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,136,263,5529,2340,1025,137,4112,168,16,3,389,17,2185,5393,4097,2340,1421,33,257,32,5377,513]

theorem envBound39905 : H12AffineFastState.Bounded env39905 := by
  intro p hp
  have h : env39905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39904_39905 : H12AffineEnvironment.transform 12 269 env39904 = env39905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39904 == env39905) = true)

theorem identity39905 : scanCanonicalize (H12AffineFastState.compose env39905 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39905 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39906 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5392,2340,1025,0,4112,33,16,3,268,17,2048,5393,4097,2340,1284,33,257,32,5377,513]

theorem envBound39906 : H12AffineFastState.Bounded env39906 := by
  intro p hp
  have h : env39906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39905_39906 : H12AffineEnvironment.transform 6 9 env39905 = env39906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39905 == env39906) = true)

theorem identity39906 : scanCanonicalize (H12AffineFastState.compose env39906 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39906 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39907 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,35,5172,2048,1025,0,4112,33,16,3,40,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound39907 : H12AffineFastState.Bounded env39907 := by
  intro p hp
  have h : env39907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39906_39907 : H12AffineEnvironment.transform 7 36 env39906 = env39907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39906 == env39907) = true)

def env39908 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1045,1,35,1028,2048,1025,0,32,33,16,3,40,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound39908 : H12AffineFastState.Bounded env39908 := by
  intro p hp
  have h : env39908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39907_39908 : H12AffineEnvironment.transform 11 48 env39907 = env39908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39907 == env39908) = true)

theorem identity39908 : scanCanonicalize (H12AffineFastState.compose env39908 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound39908 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39909 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,48,41,1045,1,35,1028,1573,1025,0,32,33,16,3,40,17,1573,1029,49,1573,1056,33,37,32,1045,513]

theorem envBound39909 : H12AffineFastState.Bounded env39909 := by
  intro p hp
  have h : env39909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39908_39909 : H12AffineEnvironment.transform 10 1573 env39908 = env39909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env39908 == env39909) = true)

def env39910 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,41,33,1,35,48,529,53,0,32,33,16,3,40,17,529,49,49,529,20,33,37,32,33,513]

theorem envBound39910 : H12AffineFastState.Bounded env39910 := by
  intro p hp
  have h : env39910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39909_39910 : H12AffineEnvironment.transform 9 52 env39909 = env39910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39909 == env39910) = true)

theorem identity39910 : scanCanonicalize (H12AffineFastState.compose env39910 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound39910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39911 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,48,41,33,1,35,48,59,53,0,32,33,16,3,40,17,59,49,49,59,20,33,37,32,33,43]

theorem envBound39911 : H12AffineFastState.Bounded env39911 := by
  intro p hp
  have h : env39911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39910_39911 : H12AffineEnvironment.transform 8 42 env39910 = env39911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env39910 == env39911) = true)

def leafEnv39911 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,48,41,33,1,35,48,59,53,0,32,33,16,3,21,40,1,17,59,49,49,59,20,33,37,32,5,34,33,43,1,32,0]

def active39911 : List Nat := [0,1,2,3,4]

def tree39911 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39911 : H12WitnessSearch.Good tree39911 := H12GlobalWitnessIndex.good

theorem leafIdentity39911 : H12AffineFastState.composeSystem env39911 rootObs = leafEnv39911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39911 rootObs == leafEnv39911) = true)

theorem terminalChecked39911 : H12PackedTerminal.terminalCheckFast leafEnv39911 active39911 tree39911 = true := by decide +kernel

def env39912 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,41,32,1,35,49,528,52,0,32,33,16,3,40,17,528,48,49,528,21,33,37,32,32,513]

theorem envBound39912 : H12AffineFastState.Bounded env39912 := by
  intro p hp
  have h : env39912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39909_39912 : H12AffineEnvironment.transform 9 53 env39909 = env39912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39909 == env39912) = true)

def env39913 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1044,1,35,1029,2048,1025,0,33,33,16,3,40,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound39913 : H12AffineFastState.Bounded env39913 := by
  intro p hp
  have h : env39913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39907_39913 : H12AffineEnvironment.transform 11 49 env39907 = env39913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env39907 == env39913) = true)

theorem identity39913 : scanCanonicalize (H12AffineFastState.compose env39913 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound39913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39914 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,49,41,1044,1,35,1029,529,1025,0,33,33,16,3,40,17,529,1028,48,529,1056,33,37,32,1044,513]

theorem envBound39914 : H12AffineFastState.Bounded env39914 := by
  intro p hp
  have h : env39914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39913_39914 : H12AffineEnvironment.transform 10 529 env39913 = env39914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env39913 == env39914) = true)

def env39915 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,41,32,1,35,49,529,53,0,33,33,16,3,40,17,529,48,48,529,20,33,37,32,32,513]

theorem envBound39915 : H12AffineFastState.Bounded env39915 := by
  intro p hp
  have h : env39915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39914_39915 : H12AffineEnvironment.transform 9 52 env39914 = env39915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39914 == env39915) = true)

theorem identity39915 : scanCanonicalize (H12AffineFastState.compose env39915 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound39915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39916 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,49,41,32,1,35,49,58,53,0,33,33,16,3,40,17,58,48,48,58,20,33,37,32,32,42]

theorem envBound39916 : H12AffineFastState.Bounded env39916 := by
  intro p hp
  have h : env39916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39915_39916 : H12AffineEnvironment.transform 8 43 env39915 = env39916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env39915 == env39916) = true)

def leafEnv39916 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,49,41,32,1,35,49,58,53,0,33,33,16,3,21,40,1,17,58,48,48,58,20,33,37,32,5,34,32,42,1,33,0]

def active39916 : List Nat := [0,1,2,3,4]

def tree39916 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39916 : H12WitnessSearch.Good tree39916 := H12GlobalWitnessIndex.good

theorem leafIdentity39916 : H12AffineFastState.composeSystem env39916 rootObs = leafEnv39916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39916 rootObs == leafEnv39916) = true)

theorem terminalChecked39916 : H12PackedTerminal.terminalCheckFast leafEnv39916 active39916 tree39916 = true := by decide +kernel

def env39917 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,41,33,1,35,48,529,52,0,33,33,16,3,40,17,529,49,48,529,21,33,37,32,33,513]

theorem envBound39917 : H12AffineFastState.Bounded env39917 := by
  intro p hp
  have h : env39917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39914_39917 : H12AffineEnvironment.transform 9 53 env39914 = env39917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39914 == env39917) = true)

def env39918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,156117,2114882,8328,64,6677654,115151,2241668,303573,2334854,4268162,257,254010,197023,2262865]

theorem envBound39918 : H12AffineFastState.Bounded env39918 := by
  intro p hp
  have h : env39918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39792_39918 : H12AffineEnvironment.transform 22 156117 env39792 = env39918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 156117 env39792 == env39918) = true)

def env39919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534864,156117,2114882,8328,64,215366,115151,2241668,303573,2334854,2592082,257,254010,197023,2262865]

theorem envBound39919 : H12AffineFastState.Bounded env39919 := by
  intro p hp
  have h : env39919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39918_39919 : H12AffineEnvironment.transform 21 2534864 env39918 = env39919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534864 env39918 == env39919) = true)

def env39920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156117,21762,8328,64,215366,115151,140484,303573,241862,498962,257,254010,197023,169745]

theorem envBound39920 : H12AffineFastState.Bounded env39920 := by
  intro p hp
  have h : env39920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39919_39920 : H12AffineEnvironment.transform 20 4160 env39919 = env39920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39919 == env39920) = true)

theorem identity39920 : scanCanonicalize (H12AffineFastState.compose env39920 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound39920 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,411972,156117,21762,8328,64,215366,79131,140484,283905,214034,485830,257,201966,197023,156613]

theorem envBound39921 : H12AffineFastState.Bounded env39921 := by
  intro p hp
  have h : env39921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39920_39921 : H12AffineEnvironment.transform 14 29908 env39920 = env39921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env39920 == env39921) = true)

def env39922 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4112,411924,156037,21762,8328,16,215318,79131,140436,283905,214034,485782,257,201918,197023,156565]

theorem envBound39922 : H12AffineFastState.Bounded env39922 := by
  intro p hp
  have h : env39922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39921_39922 : H12AffineEnvironment.transform 5 16 env39921 = env39922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39921 == env39922) = true)

theorem identity39922 : scanCanonicalize (H12AffineFastState.compose env39922 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound39922 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env39923 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24861,262144,1025,29829,4112,272393,152,21762,8328,16,75787,79131,17801,283905,75023,329867,257,95651,90242,648]

theorem envBound39923 : H12AffineFastState.Bounded env39923 := by
  intro p hp
  have h : env39923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39922_39923 : H12AffineEnvironment.transform 16 24861 env39922 = env39923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env39922 == env39923) = true)

theorem identity39923 : scanCanonicalize (H12AffineFastState.compose env39923 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39923 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env39924 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,65536,13340,262144,1025,8580,4112,272393,152,3,8328,16,75787,79131,4232,262144,75023,329867,257,73890,79235,648]

theorem envBound39924 : H12AffineFastState.Bounded env39924 := by
  intro p hp
  have h : env39924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39923_39924 : H12AffineEnvironment.transform 13 5377 env39923 = env39924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39923 == env39924) = true)

theorem identity39924 : scanCanonicalize (H12AffineFastState.compose env39924 (packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6558) := by decide +kernel

theorem selectedBound39924 : packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS < 2^1333 := by decide +kernel

def env39925 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,6558,13340,262144,1025,8580,4112,272393,152,3,8328,16,12693,11397,4232,262144,15505,266517,257,14652,11293,648]

theorem envBound39925 : H12AffineFastState.Bounded env39925 := by
  intro p hp
  have h : env39925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39924_39925 : H12AffineEnvironment.transform 15 6558 env39924 = env39925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6558 env39924 == env39925) = true)

theorem identity39925 : scanCanonicalize (H12AffineFastState.compose env39925 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound39925 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env39926 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,6558,13340,10400,1025,8580,4112,169,152,3,8328,16,12693,11397,4232,10400,15505,14773,257,14652,11293,648]

theorem envBound39926 : H12AffineFastState.Bounded env39926 := by
  intro p hp
  have h : env39926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39925_39926 : H12AffineEnvironment.transform 17 10400 env39925 = env39926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env39925 == env39926) = true)

theorem identity39926 : scanCanonicalize (H12AffineFastState.compose env39926 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39926 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env39927 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,6422,13340,10280,1025,8460,4112,33,16,3,8192,16,12573,11277,4096,10280,15385,14653,257,14652,11293,512]

theorem envBound39927 : H12AffineFastState.Bounded env39927 := by
  intro p hp
  have h : env39927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39926_39927 : H12AffineEnvironment.transform 6 8 env39926 = env39927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39926 == env39927) = true)

theorem identity39927 : scanCanonicalize (H12AffineFastState.compose env39927 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 6460) := by decide +kernel

theorem selectedBound39927 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39928 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,6460,5377,6193,6422,3360,4372,1025,6192,4112,33,16,3,6460,16,2081,5425,4096,4372,1317,1,257,0,5409,512]

theorem envBound39928 : H12AffineFastState.Bounded env39928 := by
  intro p hp
  have h : env39928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39927_39928 : H12AffineEnvironment.transform 12 6460 env39927 = env39928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6460 env39927 == env39928) = true)

theorem identity39928 : scanCanonicalize (H12AffineFastState.compose env39928 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39928 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39929 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,4096,6200,5125,6193,6162,3108,4112,1025,6192,4112,33,16,3,6200,16,2081,5173,4096,4112,1057,1,5,0,5157,512]

theorem envBound39929 : H12AffineFastState.Bounded env39929 := by
  intro p hp
  have h : env39929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39928_39929 : H12AffineEnvironment.transform 7 4 env39928 = env39929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39928 == env39929) = true)

theorem identity39929 : scanCanonicalize (H12AffineFastState.compose env39929 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound39929 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env39930 : List Nat := [2,4,8,16,32,16,8,4,512,1024,33,4096,4121,5125,4112,4147,1029,4112,1025,4113,4112,33,16,3,4121,16,0,5173,4096,4112,1057,1,5,0,5157,512]

theorem envBound39930 : H12AffineFastState.Bounded env39930 := by
  intro p hp
  have h : env39930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39929_39930 : H12AffineEnvironment.transform 10 33 env39929 = env39930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env39929 == env39930) = true)

theorem identity39930 : scanCanonicalize (H12AffineFastState.compose env39930 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound39930 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env39931 : List Nat := [2,4,8,16,32,16,8,4,512,1024,33,48,41,1077,32,3,1029,32,1025,33,32,33,16,3,41,16,0,1029,48,32,1057,1,5,0,1045,512]

theorem envBound39931 : H12AffineFastState.Bounded env39931 := by
  intro p hp
  have h : env39931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39930_39931 : H12AffineEnvironment.transform 11 48 env39930 = env39931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39930 == env39931) = true)

theorem identity39931 : scanCanonicalize (H12AffineFastState.compose env39931 (packedSelected [2,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound39931 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env39932 : List Nat := [2,4,8,16,32,16,8,4,512,52,33,48,41,1,32,3,49,32,53,33,32,33,16,3,41,16,0,49,48,32,21,1,5,0,33,512]

theorem envBound39932 : H12AffineFastState.Bounded env39932 := by
  intro p hp
  have h : env39932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39931_39932 : H12AffineEnvironment.transform 9 52 env39931 = env39932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39931 == env39932) = true)

theorem identity39932 : scanCanonicalize (H12AffineFastState.compose env39932 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39932 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39933 : List Nat := [2,0,8,16,32,16,8,0,512,48,33,48,41,1,32,3,49,32,49,33,32,33,16,3,41,16,0,49,48,32,17,1,1,0,33,512]

theorem envBound39933 : H12AffineFastState.Bounded env39933 := by
  intro p hp
  have h : env39933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39932_39933 : H12AffineEnvironment.transform 1 0 env39932 = env39933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39932 == env39933) = true)

theorem identity39933 : scanCanonicalize (H12AffineFastState.compose env39933 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39933 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env39934 : List Nat := [2,0,8,16,0,16,8,0,512,16,1,16,9,1,0,3,17,0,17,1,0,1,16,3,9,16,0,17,16,0,17,1,1,0,1,512]

theorem envBound39934 : H12AffineFastState.Bounded env39934 := by
  intro p hp
  have h : env39934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39933_39934 : H12AffineEnvironment.transform 4 0 env39933 = env39934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39933 == env39934) = true)

def env39935 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4113,411925,156036,21762,8328,17,215319,79131,140437,283905,214034,485783,257,201919,197023,156564]

theorem envBound39935 : H12AffineFastState.Bounded env39935 := by
  intro p hp
  have h : env39935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39921_39935 : H12AffineEnvironment.transform 5 17 env39921 = env39935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39921 == env39935) = true)

theorem identity39935 : scanCanonicalize (H12AffineFastState.compose env39935 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 149813) := by decide +kernel

theorem selectedBound39935 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env39936 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,149813,1025,29828,4113,32,156036,21762,8328,17,215319,79131,140437,138292,214034,73890,257,201919,197023,156564]

theorem envBound39936 : H12AffineFastState.Bounded env39936 := by
  intro p hp
  have h : env39936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39935_39936 : H12AffineEnvironment.transform 17 149813 env39935 = env39936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149813 env39935 == env39936) = true)

theorem identity39936 : scanCanonicalize (H12AffineFastState.compose env39936 (packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound39936 : packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env39937 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8323,131072,149813,1025,29828,4113,32,156036,21762,8328,17,158100,5528,140437,138292,156817,33,257,144444,139548,156564]

theorem envBound39937 : H12AffineFastState.Bounded env39937 := by
  intro p hp
  have h : env39937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39936_39937 : H12AffineEnvironment.transform 15 8323 env39936 = env39937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env39936 == env39937) = true)

def env39938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156117,21763,8328,64,215366,115151,140485,303573,241863,498963,257,254010,197023,169744]

theorem envBound39938 : H12AffineFastState.Bounded env39938 := by
  intro p hp
  have h : env39938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39919_39938 : H12AffineEnvironment.transform 20 4161 env39919 = env39938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39919 == env39938) = true)

theorem identity39938 : scanCanonicalize (H12AffineFastState.compose env39938 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound39938 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,4161,318549,17,21763,8328,64,75906,115151,17665,303573,119043,392407,257,98814,90203,63188]

theorem envBound39939 : H12AffineFastState.Bounded env39939 := by
  intro p hp
  have h : env39939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39938_39939 : H12AffineEnvironment.transform 16 25028 env39938 = env39939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env39938 == env39939) = true)

def env39940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,318549,17,21763,8192,64,75786,115015,17665,303453,119043,392287,257,98678,90203,63068]

theorem envBound39940 : H12AffineFastState.Bounded env39940 := by
  intro p hp
  have h : env39940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39939_39940 : H12AffineEnvironment.transform 6 8 env39939 = env39940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39939 == env39940) = true)

theorem identity39940 : scanCanonicalize (H12AffineFastState.compose env39940 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound39940 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1025,32769,4161,21792,17,21763,8192,64,75786,115015,17665,10280,119043,95530,257,98678,90203,63068]

theorem envBound39941 : H12AffineFastState.Bounded env39941 := by
  intro p hp
  have h : env39941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39940_39941 : H12AffineEnvironment.transform 17 35189 env39940 = env39941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env39940 == env39941) = true)

theorem identity39941 : scanCanonicalize (H12AffineFastState.compose env39941 (packedSelected [1,3,18,19,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound39941 : packedSelected [1,3,18,19,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,24908,35189,1025,32769,4161,21792,17,21763,8192,64,31836,38161,17665,10280,34133,8572,257,54560,13325,63068]

theorem envBound39942 : H12AffineFastState.Bounded env39942 := by
  intro p hp
  have h : env39942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39941_39942 : H12AffineEnvironment.transform 15 21590 env39941 = env39942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env39941 == env39942) = true)

theorem identity39942 : scanCanonicalize (H12AffineFastState.compose env39942 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39942 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21590,24908,10281,1025,8541,4161,21792,17,21763,8192,64,31836,13389,17665,10280,9225,8572,257,29820,13325,22272]

theorem envBound39943 : H12AffineFastState.Bounded env39943 := by
  intro p hp
  have h : env39943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39942_39943 : H12AffineEnvironment.transform 14 8540 env39942 = env39943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39942 == env39943) = true)

theorem identity39943 : scanCanonicalize (H12AffineFastState.compose env39943 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39943 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env39944 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,21590,24633,10281,1025,8232,4161,21589,17,21622,8192,64,31836,13389,17524,10280,9225,8201,116,29820,13325,22133]

theorem envBound39944 : H12AffineFastState.Bounded env39944 := by
  intro p hp
  have h : env39944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39943_39944 : H12AffineEnvironment.transform 7 117 env39943 = env39944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39943 == env39944) = true)

theorem identity39944 : scanCanonicalize (H12AffineFastState.compose env39944 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound39944 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39945 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8233,34,13389,10281,1025,8232,4161,33,17,2,8192,64,10280,13389,4096,10280,9225,8201,116,8200,13325,513]

theorem envBound39945 : H12AffineFastState.Bounded env39945 := by
  intro p hp
  have h : env39945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39944_39945 : H12AffineEnvironment.transform 13 5236 env39944 = env39945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env39944 == env39945) = true)

theorem identity39945 : scanCanonicalize (H12AffineFastState.compose env39945 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound39945 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env39946 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1141,8192,1,8233,34,8248,10281,1025,8232,1076,33,17,2,8192,64,10280,8248,1141,10280,9225,8201,116,8200,8312,513]

theorem envBound39946 : H12AffineFastState.Bounded env39946 := by
  intro p hp
  have h : env39946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39945_39946 : H12AffineEnvironment.transform 11 1141 env39945 = env39946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env39945 == env39946) = true)

theorem identity39946 : scanCanonicalize (H12AffineFastState.compose env39946 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound39946 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env39947 : List Nat := [2,4,8,16,32,64,8,117,512,1024,80,1141,8192,1,8233,34,8248,8313,1025,8232,1076,33,17,2,8192,64,8312,8248,1141,8312,9225,8201,116,8200,8312,513]

theorem envBound39947 : H12AffineFastState.Bounded env39947 := by
  intro p hp
  have h : env39947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39946_39947 : H12AffineEnvironment.transform 10 80 env39946 = env39947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env39946 == env39947) = true)

theorem identity39947 : scanCanonicalize (H12AffineFastState.compose env39947 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound39947 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env39948 : List Nat := [2,4,8,16,32,64,8,117,512,1024,80,1141,120,1,81,34,64,1,1025,80,1076,33,17,2,120,64,0,64,1141,0,1137,113,116,112,0,513]

theorem envBound39948 : H12AffineFastState.Bounded env39948 := by
  intro p hp
  have h : env39948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39947_39948 : H12AffineEnvironment.transform 12 120 env39947 = env39948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env39947 == env39948) = true)

theorem identity39948 : scanCanonicalize (H12AffineFastState.compose env39948 (packedSelected [3,5,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound39948 : packedSelected [3,5,14] rootPS < 2^1333 := by decide +kernel

def env39949 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,16,120,1,81,34,64,1,100,80,81,33,17,2,120,64,0,64,16,0,20,113,116,112,0,513]

theorem envBound39949 : H12AffineFastState.Bounded env39949 := by
  intro p hp
  have h : env39949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39948_39949 : H12AffineEnvironment.transform 9 101 env39948 = env39949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env39948 == env39949) = true)

theorem identity39949 : scanCanonicalize (H12AffineFastState.compose env39949 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound39949 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39950 : List Nat := [2,4,8,16,32,64,8,117,81,101,80,16,120,1,81,34,64,1,100,80,81,33,17,2,120,64,0,64,16,0,20,113,116,112,0,80]

theorem envBound39950 : H12AffineFastState.Bounded env39950 := by
  intro p hp
  have h : env39950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39949_39950 : H12AffineEnvironment.transform 8 81 env39949 = env39950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env39949 == env39950) = true)

theorem identity39950 : scanCanonicalize (H12AffineFastState.compose env39950 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39950 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39951 : List Nat := [2,4,8,16,32,16,8,37,1,53,0,16,40,1,1,34,16,1,52,0,1,33,17,2,40,16,0,16,16,0,20,33,36,32,0,0]

theorem envBound39951 : H12AffineFastState.Bounded env39951 := by
  intro p hp
  have h : env39951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39950_39951 : H12AffineEnvironment.transform 5 16 env39950 = env39951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39950 == env39951) = true)

theorem identity39951 : scanCanonicalize (H12AffineFastState.compose env39951 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39952 : List Nat := [2,4,8,16,17,16,8,20,1,4,0,16,25,1,1,19,16,1,5,0,1,16,17,2,25,16,0,16,16,0,20,16,21,17,0,0]

theorem envBound39952 : H12AffineFastState.Bounded env39952 := by
  intro p hp
  have h : env39952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39951_39952 : H12AffineEnvironment.transform 4 17 env39951 = env39952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39951 == env39952) = true)

def env39953 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318549,17,21763,8193,64,75787,115014,17665,303452,119043,392286,257,98679,90203,63069]

theorem envBound39953 : H12AffineFastState.Bounded env39953 := by
  intro p hp
  have h : env39953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39939_39953 : H12AffineEnvironment.transform 6 9 env39939 = env39953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39939 == env39953) = true)

theorem identity39953 : scanCanonicalize (H12AffineFastState.compose env39953 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound39953 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1025,32769,4161,62588,17,21763,8193,64,75787,115014,17665,35189,119043,119927,257,98679,90203,63069]

theorem envBound39954 : H12AffineFastState.Bounded env39954 := by
  intro p hp
  have h : env39954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39953_39954 : H12AffineEnvironment.transform 17 10281 env39953 = env39954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39953 == env39954) = true)

theorem identity39954 : scanCanonicalize (H12AffineFastState.compose env39954 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound39954 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,13389,10281,1025,32769,4161,41340,17,3,8193,64,75787,103494,4097,35189,99331,98679,257,98679,79195,41821]

theorem envBound39955 : H12AffineFastState.Bounded env39955 := by
  intro p hp
  have h : env39955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39954_39955 : H12AffineEnvironment.transform 13 5376 env39954 = env39955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39954 == env39955) = true)

theorem identity39955 : scanCanonicalize (H12AffineFastState.compose env39955 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39955 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env39956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,65536,5393,2421,1025,32769,4161,32800,17,3,349,64,67927,103494,4097,35189,99331,98679,257,98679,70663,33281]

theorem envBound39956 : H12AffineFastState.Bounded env39956 := by
  intro p hp
  have h : env39956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39955_39956 : H12AffineEnvironment.transform 12 348 env39955 = env39956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39955 == env39956) = true)

theorem identity39956 : scanCanonicalize (H12AffineFastState.compose env39956 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound39956 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,342,5393,2421,1025,32769,4161,32800,17,3,349,64,2049,38160,4097,35189,34133,32801,257,32801,5457,33281]

theorem envBound39957 : H12AffineFastState.Bounded env39957 := by
  intro p hp
  have h : env39957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39956_39957 : H12AffineEnvironment.transform 15 342 env39956 = env39957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env39956 == env39957) = true)

theorem identity39957 : scanCanonicalize (H12AffineFastState.compose env39957 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound39957 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39958 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,32768,2,5189,2081,1025,32769,4161,32800,17,3,9,64,2049,37956,4097,34849,33793,32801,85,32801,5125,33281]

theorem envBound39958 : H12AffineFastState.Bounded env39958 := by
  intro p hp
  have h : env39958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39957_39958 : H12AffineEnvironment.transform 7 84 env39957 = env39958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env39957 == env39958) = true)

theorem identity39958 : scanCanonicalize (H12AffineFastState.compose env39958 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound39958 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env39959 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,80,2,5189,2081,1025,81,4161,112,17,3,9,64,2049,5140,4097,2161,1105,113,85,113,5125,593]

theorem envBound39959 : H12AffineFastState.Bounded env39959 := by
  intro p hp
  have h : env39959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39958_39959 : H12AffineEnvironment.transform 14 80 env39958 = env39959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env39958 == env39959) = true)

theorem identity39959 : scanCanonicalize (H12AffineFastState.compose env39959 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound39959 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env39960 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,2096,8,3172,80,2,3189,2081,1025,81,2161,112,17,3,9,64,2049,3108,2097,2161,1105,113,85,113,3125,593]

theorem envBound39960 : H12AffineFastState.Bounded env39960 := by
  intro p hp
  have h : env39960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39959_39960 : H12AffineEnvironment.transform 11 2096 env39959 = env39960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env39959 == env39960) = true)

theorem identity39960 : scanCanonicalize (H12AffineFastState.compose env39960 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound39960 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env39961 : List Nat := [2,4,8,16,32,64,9,84,512,1024,113,65,8,1045,80,2,1028,80,1025,81,0,112,17,3,9,64,112,1109,64,0,1105,113,85,113,1092,593]

theorem envBound39961 : H12AffineFastState.Bounded env39961 := by
  intro p hp
  have h : env39961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39960_39961 : H12AffineEnvironment.transform 10 113 env39960 = env39961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env39960 == env39961) = true)

theorem identity39961 : scanCanonicalize (H12AffineFastState.compose env39961 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound39961 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env39962 : List Nat := [2,4,8,16,32,48,9,36,512,1024,1,49,8,1045,32,2,1028,32,1025,33,0,0,17,3,9,48,0,1061,48,0,1057,1,37,1,1076,545]

theorem envBound39962 : H12AffineFastState.Bounded env39962 := by
  intro p hp
  have h : env39962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39961_39962 : H12AffineEnvironment.transform 5 48 env39961 = env39962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env39961 == env39962) = true)

theorem identity39962 : scanCanonicalize (H12AffineFastState.compose env39962 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39962 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39963 : List Nat := [2,4,8,16,0,16,9,4,512,1024,1,17,8,1045,0,2,1028,0,1025,1,0,0,17,3,9,16,0,1029,16,0,1025,1,5,1,1044,513]

theorem envBound39963 : H12AffineFastState.Bounded env39963 := by
  intro p hp
  have h : env39963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39962_39963 : H12AffineEnvironment.transform 4 0 env39962 = env39963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39962 == env39963) = true)

theorem identity39963 : scanCanonicalize (H12AffineFastState.compose env39963 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound39963 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39964 : List Nat := [2,4,8,16,0,16,9,4,1,1024,1,17,8,1045,0,2,1028,0,1025,1,0,0,17,3,9,16,0,1029,16,0,1025,1,5,1,1044,0]

theorem envBound39964 : H12AffineFastState.Bounded env39964 := by
  intro p hp
  have h : env39964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39963_39964 : H12AffineEnvironment.transform 8 1 env39963 = env39964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env39963 == env39964) = true)

theorem identity39964 : scanCanonicalize (H12AffineFastState.compose env39964 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39965 : List Nat := [2,4,8,0,0,0,9,4,1,1024,1,1,8,1029,0,2,1028,0,1025,1,0,0,1,3,9,0,0,1029,0,0,1025,1,5,1,1028,0]

theorem envBound39965 : H12AffineFastState.Bounded env39965 := by
  intro p hp
  have h : env39965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39964_39965 : H12AffineEnvironment.transform 3 0 env39964 = env39965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39964 == env39965) = true)

theorem identity39965 : scanCanonicalize (H12AffineFastState.compose env39965 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39965 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39966 : List Nat := [2,4,8,0,0,0,9,4,1,5,1,1,8,0,0,2,1,0,4,1,0,0,1,3,9,0,0,0,0,0,4,1,5,1,1,0]

theorem envBound39966 : H12AffineFastState.Bounded env39966 := by
  intro p hp
  have h : env39966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39965_39966 : H12AffineEnvironment.transform 9 5 env39965 = env39966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39965 == env39966) = true)

def env39967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534865,156117,2114882,8328,64,215367,115151,2241668,303573,2334854,2592083,257,254010,197023,2262865]

theorem envBound39967 : H12AffineFastState.Bounded env39967 := by
  intro p hp
  have h : env39967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39918_39967 : H12AffineEnvironment.transform 21 2534865 env39918 = env39967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534865 env39918 == env39967) = true)

def env39968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156117,21762,8328,64,215367,115151,140484,303573,241862,498963,257,254010,197023,169745]

theorem envBound39968 : H12AffineFastState.Bounded env39968 := by
  intro p hp
  have h : env39968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39967_39968 : H12AffineEnvironment.transform 20 4160 env39967 = env39968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39967 == env39968) = true)

theorem identity39968 : scanCanonicalize (H12AffineFastState.compose env39968 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound39968 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272513,62661,21762,8328,64,121943,115151,45524,303573,75222,329731,257,95530,103567,513]

theorem envBound39969 : H12AffineFastState.Bounded env39969 := by
  intro p hp
  have h : env39969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39968_39969 : H12AffineEnvironment.transform 16 38160 env39968 = env39969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env39968 == env39969) = true)

def env39970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4160,169,62661,21762,8328,64,121943,115151,45524,35325,75222,73771,257,95530,103567,513]

theorem envBound39970 : H12AffineFastState.Bounded env39970 := by
  intro p hp
  have h : env39970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39969_39970 : H12AffineEnvironment.transform 17 10280 env39969 = env39970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39969 == env39970) = true)

theorem identity39970 : scanCanonicalize (H12AffineFastState.compose env39970 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound39970 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env39971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,38160,10280,1025,32769,4160,169,62661,21762,8328,64,10588,13508,45524,35325,53469,54560,257,32801,24964,513]

theorem envBound39971 : H12AffineFastState.Bounded env39971 := by
  intro p hp
  have h : env39971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39970_39971 : H12AffineEnvironment.transform 15 62731 env39970 = env39971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env39970 == env39971) = true)

theorem identity39971 : scanCanonicalize (H12AffineFastState.compose env39971 (packedSelected [2,4,6,7,8,9,10,11,17,27,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound39971 : packedSelected [2,4,6,7,8,9,10,11,17,27,28,32] rootPS < 2^1333 := by decide +kernel

def env39972 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,16384,32768,61515,36944,10280,321,32769,4160,169,61829,20546,8328,64,10588,12676,45524,35325,53469,53344,257,32801,24964,513]

theorem envBound39972 : H12AffineFastState.Bounded env39972 := by
  intro p hp
  have h : env39972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39971_39972 : H12AffineEnvironment.transform 9 320 env39971 = env39972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39971 == env39972) = true)

theorem identity39972 : scanCanonicalize (H12AffineFastState.compose env39972 (packedSelected [7,8,10,11,14,18,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 12513) := by decide +kernel

theorem selectedBound39972 : packedSelected [7,8,10,11,14,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env39973 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,12513,32768,32938,36944,10280,321,32769,4160,169,33124,8355,8328,64,10588,12676,45524,35325,41020,41089,257,32801,4453,513]

theorem envBound39973 : H12AffineFastState.Bounded env39973 := by
  intro p hp
  have h : env39973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39972_39973 : H12AffineEnvironment.transform 13 12513 env39972 = env39973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12513 env39972 == env39973) = true)

theorem identity39973 : scanCanonicalize (H12AffineFastState.compose env39973 (packedSelected [0,3,5,10,12,14,17,18,23,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound39973 : packedSelected [0,3,5,10,12,14,17,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env39974 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,12513,8660,8574,12676,10280,321,8661,4160,169,8368,8355,8328,64,10588,12676,4096,10281,488,341,257,8693,4453,513]

theorem envBound39974 : H12AffineFastState.Bounded env39974 := by
  intro p hp
  have h : env39974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39973_39974 : H12AffineEnvironment.transform 14 8660 env39973 = env39974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env39973 == env39974) = true)

theorem identity39974 : scanCanonicalize (H12AffineFastState.compose env39974 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound39974 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39975 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,41,4296,509,343,4525,2049,321,508,4160,169,153,138,161,64,2421,4525,4096,2048,488,341,257,476,4453,513]

theorem envBound39975 : H12AffineFastState.Bounded env39975 := by
  intro p hp
  have h : env39975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39974_39975 : H12AffineEnvironment.transform 12 41 env39974 = env39975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env39974 == env39975) = true)

theorem identity39975 : scanCanonicalize (H12AffineFastState.compose env39975 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound39975 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39976 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,4096,41,4113,292,343,4468,2049,321,293,4160,112,64,83,120,64,2421,4468,4096,2048,305,341,257,261,4453,513]

theorem envBound39976 : H12AffineFastState.Bounded env39976 := by
  intro p hp
  have h : env39976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39975_39976 : H12AffineEnvironment.transform 6 89 env39975 = env39976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env39975 == env39976) = true)

theorem identity39976 : scanCanonicalize (H12AffineFastState.compose env39976 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39976 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39977 : List Nat := [2,4,8,16,32,64,89,116,512,52,2048,4096,41,4113,80,35,4096,2049,53,81,4160,112,64,83,120,64,2049,4096,4096,2048,69,33,117,113,4113,513]

theorem envBound39977 : H12AffineFastState.Bounded env39977 := by
  intro p hp
  have h : env39977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39976_39977 : H12AffineEnvironment.transform 7 116 env39976 = env39977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39976 == env39977) = true)

theorem identity39977 : scanCanonicalize (H12AffineFastState.compose env39977 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39977 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39978 : List Nat := [2,4,8,16,32,64,89,116,512,52,0,4096,41,4113,80,35,4096,1,53,81,4160,112,64,83,120,64,1,4096,4096,0,69,33,117,113,4113,513]

theorem envBound39978 : H12AffineFastState.Bounded env39978 := by
  intro p hp
  have h : env39978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39977_39978 : H12AffineEnvironment.transform 10 0 env39977 = env39978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39977 == env39978) = true)

theorem identity39978 : scanCanonicalize (H12AffineFastState.compose env39978 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound39978 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env39979 : List Nat := [2,4,8,16,32,64,89,116,512,52,0,17,41,0,80,35,17,1,53,81,81,112,64,83,120,64,1,17,17,0,69,33,117,113,0,513]

theorem envBound39979 : H12AffineFastState.Bounded env39979 := by
  intro p hp
  have h : env39979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39978_39979 : H12AffineEnvironment.transform 11 17 env39978 = env39979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env39978 == env39979) = true)

theorem identity39979 : scanCanonicalize (H12AffineFastState.compose env39979 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39979 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39980 : List Nat := [2,4,8,16,32,16,9,36,512,52,0,17,41,0,0,35,17,1,53,1,1,32,16,3,40,16,1,17,17,0,21,33,37,33,0,513]

theorem envBound39980 : H12AffineFastState.Bounded env39980 := by
  intro p hp
  have h : env39980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39979_39980 : H12AffineEnvironment.transform 5 16 env39979 = env39980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39979 == env39980) = true)

theorem identity39980 : scanCanonicalize (H12AffineFastState.compose env39980 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound39980 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39981 : List Nat := [2,4,8,16,32,16,9,36,16,52,0,17,41,0,0,35,17,1,53,1,1,32,16,3,40,16,1,17,17,0,21,33,37,33,0,17]

theorem envBound39981 : H12AffineFastState.Bounded env39981 := by
  intro p hp
  have h : env39981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39980_39981 : H12AffineEnvironment.transform 8 16 env39980 = env39981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env39980 == env39981) = true)

theorem identity39981 : scanCanonicalize (H12AffineFastState.compose env39981 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound39981 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39982 : List Nat := [2,4,8,16,27,16,9,31,16,15,0,17,18,0,0,24,17,1,14,1,1,27,16,3,19,16,1,17,17,0,21,26,30,26,0,17]

theorem envBound39982 : H12AffineFastState.Bounded env39982 := by
  intro p hp
  have h : env39982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39981_39982 : H12AffineEnvironment.transform 4 27 env39981 = env39982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env39981 == env39982) = true)

def env39983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4160,168,62661,21762,8328,64,121943,115151,45524,35324,75222,73770,257,95530,103567,513]

theorem envBound39983 : H12AffineFastState.Bounded env39983 := by
  intro p hp
  have h : env39983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39969_39983 : H12AffineEnvironment.transform 17 10281 env39969 = env39983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39969 == env39983) = true)

theorem identity39983 : scanCanonicalize (H12AffineFastState.compose env39983 (packedSelected [0,1,2,3,4,5,6,11,14,17,19,20,22,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound39983 : packedSelected [0,1,2,3,4,5,6,11,14,17,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env39984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,32768,65536,38160,10281,1025,32769,4160,168,41244,219,8328,64,100750,103446,45524,35324,75222,73770,257,73971,103567,513]

theorem envBound39984 : H12AffineFastState.Bounded env39984 := by
  intro p hp
  have h : env39984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39983_39984 : H12AffineEnvironment.transform 13 5593 env39983 = env39984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env39983 == env39984) = true)

theorem identity39984 : scanCanonicalize (H12AffineFastState.compose env39984 (packedSelected [0,2,4,5,6,9,11,17,19,20,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound39984 : packedSelected [0,2,4,5,6,9,11,17,19,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env39985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5593,32768,65536,38160,2477,1025,32769,4160,168,32920,219,268,64,100750,103446,36944,35324,66642,65966,257,65911,103567,513]

theorem envBound39985 : H12AffineFastState.Bounded env39985 := by
  intro p hp
  have h : env39985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39984_39985 : H12AffineEnvironment.transform 12 388 env39984 = env39985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env39984 == env39985) = true)

theorem identity39985 : scanCanonicalize (H12AffineFastState.compose env39985 (packedSelected [3,4,5,9,10,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39985 : packedSelected [3,4,5,9,10,14,17,20] rootPS < 2^1333 := by decide +kernel

def env39986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5593,32768,263,38160,2477,1025,32769,4160,168,32920,219,268,64,34953,38161,36944,35324,1365,169,257,112,38280,513]

theorem envBound39986 : H12AffineFastState.Bounded env39986 := by
  intro p hp
  have h : env39986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39985_39986 : H12AffineEnvironment.transform 15 263 env39985 = env39986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39985 == env39986) = true)

def env39987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156117,21763,8328,64,215367,115151,140485,303573,241863,498962,257,254010,197023,169744]

theorem envBound39987 : H12AffineFastState.Bounded env39987 := by
  intro p hp
  have h : env39987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39967_39987 : H12AffineEnvironment.transform 20 4161 env39967 = env39987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39967 == env39987) = true)

def env39988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,169400,156117,21763,8328,64,215367,115151,140485,35325,241863,243002,257,254010,197023,169744]

theorem envBound39988 : H12AffineFastState.Bounded env39988 := by
  intro p hp
  have h : env39988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39987_39988 : H12AffineEnvironment.transform 17 10280 env39987 = env39988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39987 == env39988) = true)

def env39989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,21928,41413,21763,8328,64,100695,115151,58581,35325,94423,95530,257,73770,115087,22272]

theorem envBound39989 : H12AffineFastState.Bounded env39989 := by
  intro p hp
  have h : env39989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39988_39989 : H12AffineEnvironment.transform 16 49168 env39988 = env39989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env39988 == env39989) = true)

theorem identity39989 : scanCanonicalize (H12AffineFastState.compose env39989 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound39989 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10280,1025,8660,4161,21928,16,21763,8328,64,75906,90138,17664,10280,94423,95530,257,73770,90202,22272]

theorem envBound39990 : H12AffineFastState.Bounded env39990 := by
  intro p hp
  have h : env39990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39989_39990 : H12AffineEnvironment.transform 14 8661 env39989 = env39990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env39989 == env39990) = true)

theorem identity39990 : scanCanonicalize (H12AffineFastState.compose env39990 (packedSelected [2,3,5,6,7,8,9,11,16,22,23,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 29943) := by decide +kernel

theorem selectedBound39990 : packedSelected [2,3,5,6,7,8,9,11,16,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env39991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29943,25029,10280,1025,8660,4161,21928,16,21763,8328,64,23669,5357,17664,10280,1056,477,257,21725,5293,22272]

theorem envBound39991 : H12AffineFastState.Bounded env39991 := by
  intro p hp
  have h : env39991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39990_39991 : H12AffineEnvironment.transform 15 29943 env39990 = env39991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29943 env39990 == env39991) = true)

theorem identity39991 : scanCanonicalize (H12AffineFastState.compose env39991 (packedSelected [0,1,2,3,6,8,10,11,12,14,15,16,20,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound39991 : packedSelected [0,1,2,3,6,8,10,11,12,14,15,16,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env39992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5293,8661,8282,13672,10280,1025,8660,4161,261,16,430,8328,64,2264,5357,4525,10280,1056,477,257,112,5293,941]

theorem envBound39992 : H12AffineFastState.Bounded env39992 := by
  intro p hp
  have h : env39992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39991_39992 : H12AffineEnvironment.transform 13 5293 env39991 = env39992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env39991 == env39992) = true)

theorem identity39992 : scanCanonicalize (H12AffineFastState.compose env39992 (packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound39992 : packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env39993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,5293,1076,1467,4233,3529,1025,1077,4161,261,16,430,1385,64,2264,5357,4525,3529,1056,477,257,112,5293,941]

theorem envBound39993 : H12AffineFastState.Bounded env39993 := by
  intro p hp
  have h : env39993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39992_39993 : H12AffineEnvironment.transform 12 1505 env39992 = env39993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env39992 == env39993) = true)

theorem identity39993 : scanCanonicalize (H12AffineFastState.compose env39993 (packedSelected [0,4,7,11,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39993 : packedSelected [0,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env39994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5157,1076,1331,4097,3393,1025,1077,4161,261,16,294,1385,64,2128,5221,4389,3393,1056,341,257,112,5157,805]

theorem envBound39994 : H12AffineFastState.Bounded env39994 := by
  intro p hp
  have h : env39994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39993_39994 : H12AffineEnvironment.transform 6 8 env39993 = env39994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39993 == env39994) = true)

theorem identity39994 : scanCanonicalize (H12AffineFastState.compose env39994 (packedSelected [0,1,2,6,7,8,10,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39994 : packedSelected [0,1,2,6,7,8,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39995 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1052,5157,1076,1094,4097,3124,1025,1077,4161,112,16,83,1052,64,2128,5221,4176,3124,1056,32,116,112,5157,592]

theorem envBound39995 : H12AffineFastState.Bounded env39995 := by
  intro p hp
  have h : env39995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39994_39995 : H12AffineEnvironment.transform 7 117 env39994 = env39995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39994 == env39995) = true)

theorem identity39995 : scanCanonicalize (H12AffineFastState.compose env39995 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound39995 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env39996 : List Nat := [2,4,8,16,32,64,8,117,512,68,2048,4096,88,4193,112,2,4097,2160,69,113,4161,112,16,83,88,64,2128,4129,4176,2160,100,32,116,112,4193,592]

theorem envBound39996 : H12AffineFastState.Bounded env39996 := by
  intro p hp
  have h : env39996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39995_39996 : H12AffineEnvironment.transform 9 68 env39995 = env39996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env39995 == env39996) = true)

theorem identity39996 : scanCanonicalize (H12AffineFastState.compose env39996 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound39996 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39997 : List Nat := [2,4,8,16,32,49,8,4,512,53,2048,4096,41,4112,1,2,4097,2049,52,0,4144,1,16,34,41,49,2081,4129,4129,2049,21,32,5,1,4112,545]

theorem envBound39997 : H12AffineFastState.Bounded env39997 := by
  intro p hp
  have h : env39997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39996_39997 : H12AffineEnvironment.transform 5 49 env39996 = env39997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env39996 == env39997) = true)

theorem identity39997 : scanCanonicalize (H12AffineFastState.compose env39997 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound39997 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39998 : List Nat := [2,4,8,16,32,49,8,4,512,53,2048,512,41,528,1,2,513,2049,52,0,560,1,16,34,41,49,2081,545,545,2049,21,32,5,1,528,545]

theorem envBound39998 : H12AffineFastState.Bounded env39998 := by
  intro p hp
  have h : env39998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39997_39998 : H12AffineEnvironment.transform 11 512 env39997 = env39998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env39997 == env39998) = true)

theorem identity39998 : scanCanonicalize (H12AffineFastState.compose env39998 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound39998 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39999 : List Nat := [2,4,8,16,32,49,8,4,512,53,523,512,41,528,1,2,513,522,52,0,560,1,16,34,41,49,554,545,545,522,21,32,5,1,528,545]

theorem envBound39999 : H12AffineFastState.Bounded env39999 := by
  intro p hp
  have h : env39999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39998_39999 : H12AffineEnvironment.transform 10 523 env39998 = env39999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env39998 == env39999) = true)

theorem identity39999 : scanCanonicalize (H12AffineFastState.compose env39999 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound39999 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env40000 : List Nat := [2,4,8,16,32,49,8,4,15,53,4,15,41,31,1,2,14,5,52,0,63,1,16,34,41,49,37,46,46,5,21,32,5,1,31,46]

theorem envBound40000 : H12AffineFastState.Bounded env40000 := by
  intro p hp
  have h : env40000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39999_40000 : H12AffineEnvironment.transform 8 15 env39999 = env40000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env39999 == env40000) = true)

theorem identity40000 : scanCanonicalize (H12AffineFastState.compose env40000 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound40000 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env40001 : List Nat := [2,4,8,16,8,25,8,4,15,29,4,15,1,31,1,2,14,5,28,0,23,1,16,10,1,25,13,6,6,5,21,8,5,1,31,6]

theorem envBound40001 : H12AffineFastState.Bounded env40001 := by
  intro p hp
  have h : env40001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40000_40001 : H12AffineEnvironment.transform 4 8 env40000 = env40001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env40000 == env40001) = true)

theorem identity40001 : scanCanonicalize (H12AffineFastState.compose env40001 (packedSelected [0,4,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40001 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env40002 : List Nat := [2,4,8,1,8,8,8,4,15,12,4,15,1,14,1,2,14,5,13,0,6,1,1,10,1,8,13,6,6,5,4,8,5,1,14,6]

theorem envBound40002 : H12AffineFastState.Bounded env40002 := by
  intro p hp
  have h : env40002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40001_40002 : H12AffineEnvironment.transform 3 1 env40001 = env40002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40001 == env40002) = true)

theorem identity40002 : scanCanonicalize (H12AffineFastState.compose env40002 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound40002 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40003 : List Nat := [2,4,6,1,6,6,6,4,1,2,4,1,1,0,1,2,0,5,3,0,6,1,1,4,1,6,3,6,6,5,4,6,5,1,0,6]

theorem envBound40003 : H12AffineFastState.Bounded env40003 := by
  intro p hp
  have h : env40003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40002_40003 : H12AffineEnvironment.transform 2 6 env40002 = env40003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env40002 == env40003) = true)

theorem identity40003 : scanCanonicalize (H12AffineFastState.compose env40003 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound40003 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40004 : List Nat := [2,1,3,1,3,3,3,1,1,2,1,1,1,0,1,2,0,0,3,0,3,1,1,1,1,3,3,3,3,0,1,3,0,1,0,3]

theorem envBound40004 : H12AffineFastState.Bounded env40004 := by
  intro p hp
  have h : env40004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40003_40004 : H12AffineEnvironment.transform 1 1 env40003 = env40004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env40003 == env40004) = true)

def env40005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,21929,41412,21763,8328,64,100694,115151,58580,35325,94422,95531,257,73771,115086,22273]

theorem envBound40005 : H12AffineFastState.Bounded env40005 := by
  intro p hp
  have h : env40005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39988_40005 : H12AffineEnvironment.transform 16 49169 env39988 = env40005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env39988 == env40005) = true)

theorem identity40005 : scanCanonicalize (H12AffineFastState.compose env40005 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40005 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10280,1025,8540,4161,21929,153,21763,8328,64,75787,90258,17801,10400,94422,95531,257,73771,90323,22273]

theorem envBound40006 : H12AffineFastState.Bounded env40006 := by
  intro p hp
  have h : env40006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40005_40006 : H12AffineEnvironment.transform 14 8541 env40005 = env40006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40005 == env40006) = true)

theorem identity40006 : scanCanonicalize (H12AffineFastState.compose env40006 (packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21875) := by decide +kernel

theorem selectedBound40006 : packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,21875,24908,10280,1025,8540,4161,21929,153,21763,8328,64,32120,13793,17801,10400,9637,8280,257,30040,13728,22273]

theorem envBound40007 : H12AffineFastState.Bounded env40007 := by
  intro p hp
  have h : env40007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40006_40007 : H12AffineEnvironment.transform 15 21875 env40006 = env40007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21875 env40006 == env40007) = true)

theorem identity40007 : scanCanonicalize (H12AffineFastState.compose env40007 (packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,16,20,22,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound40007 : packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,16,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env40008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,16384,1296,21875,17665,3173,1025,1297,4161,21929,153,21763,1221,64,22837,4524,17801,3309,488,1045,257,20757,4589,22273]

theorem envBound40008 : H12AffineFastState.Bounded env40008 := by
  intro p hp
  have h : env40008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40007_40008 : H12AffineEnvironment.transform 12 1101 env40007 = env40008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env40007 == env40008) = true)

theorem identity40008 : scanCanonicalize (H12AffineFastState.compose env40008 (packedSelected [1,2,6,8,9,14,18,19,22,23] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound40008 : packedSelected [1,2,6,8,9,14,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env40009 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,389,16384,216,20667,16585,2477,457,217,4161,20577,153,20683,269,64,22837,4524,16449,2341,488,477,257,20757,4589,21193]

theorem envBound40009 : H12AffineFastState.Bounded env40009 := by
  intro p hp
  have h : env40009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40008_40009 : H12AffineEnvironment.transform 9 456 env40008 = env40009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env40008 == env40009) = true)

theorem identity40009 : scanCanonicalize (H12AffineFastState.compose env40009 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40009 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env40010 : List Nat := [2,4,8,16,32,64,128,37,512,237,2048,4096,160,16384,216,20667,16585,2184,236,217,4161,20577,153,20683,40,64,22544,4233,16449,2048,205,248,36,20528,4296,21193]

theorem envBound40010 : H12AffineFastState.Bounded env40010 := by
  intro p hp
  have h : env40010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40009_40010 : H12AffineEnvironment.transform 7 37 env40009 = env40010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40009 == env40010) = true)

theorem identity40010 : scanCanonicalize (H12AffineFastState.compose env40010 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound40010 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40011 : List Nat := [2,4,8,16,32,64,128,37,512,237,2048,4096,160,4161,216,250,4232,2184,236,217,4161,32,153,138,40,64,2129,4233,4096,2048,205,248,36,113,4296,648]

theorem envBound40011 : H12AffineFastState.Bounded env40011 := by
  intro p hp
  have h : env40011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40010_40011 : H12AffineEnvironment.transform 13 4161 env40010 = env40011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env40010 == env40011) = true)

theorem identity40011 : scanCanonicalize (H12AffineFastState.compose env40011 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40011 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40012 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,4096,160,4112,137,171,4232,2184,189,136,4112,32,153,138,40,17,2048,4233,4096,2048,156,169,36,32,4249,648]

theorem envBound40012 : H12AffineFastState.Bounded env40012 := by
  intro p hp
  have h : env40012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40011_40012 : H12AffineEnvironment.transform 5 17 env40011 = env40012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40011 == env40012) = true)

theorem identity40012 : scanCanonicalize (H12AffineFastState.compose env40012 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40012 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env40013 : List Nat := [2,4,8,16,11,17,128,14,512,151,2048,4096,139,4112,137,128,4232,2184,150,136,4112,11,153,138,3,17,2048,4233,4096,2048,156,130,15,11,4249,648]

theorem envBound40013 : H12AffineFastState.Bounded env40013 := by
  intro p hp
  have h : env40013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40012_40013 : H12AffineEnvironment.transform 4 11 env40012 = env40013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40012 == env40013) = true)

theorem identity40013 : scanCanonicalize (H12AffineFastState.compose env40013 (packedSelected [3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound40013 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env40014 : List Nat := [2,4,8,4,11,5,128,14,512,131,2048,4096,139,4100,137,128,4232,2184,130,136,4100,11,141,138,3,5,2048,4233,4096,2048,136,130,15,11,4237,648]

theorem envBound40014 : H12AffineFastState.Bounded env40014 := by
  intro p hp
  have h : env40014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40013_40014 : H12AffineEnvironment.transform 3 4 env40013 = env40014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env40013 == env40014) = true)

theorem identity40014 : scanCanonicalize (H12AffineFastState.compose env40014 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 515) := by decide +kernel

theorem selectedBound40014 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env40015 : List Nat := [2,4,8,4,11,5,128,14,512,131,2048,515,139,519,137,128,651,2184,130,136,519,11,141,138,3,5,2048,650,515,2048,136,130,15,11,654,648]

theorem envBound40015 : H12AffineFastState.Bounded env40015 := by
  intro p hp
  have h : env40015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40014_40015 : H12AffineEnvironment.transform 11 515 env40014 = env40015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 515 env40014 == env40015) = true)

theorem identity40015 : scanCanonicalize (H12AffineFastState.compose env40015 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 6) := by decide +kernel

theorem selectedBound40015 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env40016 : List Nat := [2,4,8,4,11,5,6,14,512,5,2048,515,13,519,15,6,525,2062,4,14,519,11,11,12,3,5,2048,524,515,2048,14,4,15,11,520,526]

theorem envBound40016 : H12AffineFastState.Bounded env40016 := by
  intro p hp
  have h : env40016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40015_40016 : H12AffineEnvironment.transform 6 6 env40015 = env40016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 6 env40015 == env40016) = true)

theorem identity40016 : scanCanonicalize (H12AffineFastState.compose env40016 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound40016 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env40017 : List Nat := [2,4,8,4,11,5,6,14,512,5,4,515,13,519,15,6,525,10,4,14,519,11,11,12,3,5,4,524,515,4,14,4,15,11,520,526]

theorem envBound40017 : H12AffineFastState.Bounded env40017 := by
  intro p hp
  have h : env40017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40016_40017 : H12AffineEnvironment.transform 10 4 env40016 = env40017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env40016 == env40017) = true)

theorem identity40017 : scanCanonicalize (H12AffineFastState.compose env40017 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound40017 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40018 : List Nat := [2,4,8,4,11,5,6,14,9,5,4,10,13,14,15,6,4,10,4,14,14,11,11,12,3,5,4,5,10,4,14,4,15,11,1,7]

theorem envBound40018 : H12AffineFastState.Bounded env40018 := by
  intro p hp
  have h : env40018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40017_40018 : H12AffineEnvironment.transform 8 9 env40017 = env40018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env40017 == env40018) = true)

theorem identity40018 : scanCanonicalize (H12AffineFastState.compose env40018 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40019 : List Nat := [2,0,8,0,11,1,2,10,9,1,0,10,9,10,11,2,0,10,0,10,10,11,11,8,3,1,0,1,10,0,10,0,11,11,1,3]

theorem envBound40019 : H12AffineFastState.Bounded env40019 := by
  intro p hp
  have h : env40019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40018_40019 : H12AffineEnvironment.transform 1 0 env40018 = env40019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40018 == env40019) = true)

theorem identity40019 : scanCanonicalize (H12AffineFastState.compose env40019 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40019 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40020 : List Nat := [2,0,3,0,0,1,2,1,2,1,0,1,2,1,0,2,0,1,0,1,1,0,0,3,3,1,0,1,1,0,1,0,0,0,1,3]

theorem envBound40020 : H12AffineFastState.Bounded env40020 := by
  intro p hp
  have h : env40020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40019_40020 : H12AffineEnvironment.transform 2 3 env40019 = env40020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40019 == env40020) = true)

theorem identity40020 : scanCanonicalize (H12AffineFastState.compose env40020 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40020 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40021 : List Nat := [1,0,0,0,0,1,1,1,1,1,0,1,1,1,0,1,0,1,0,1,1,0,0,0,0,1,0,1,1,0,1,0,0,0,1,0]

theorem envBound40021 : H12AffineFastState.Bounded env40021 := by
  intro p hp
  have h : env40021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40020_40021 : H12AffineEnvironment.transform 0 1 env40020 = env40021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40020 == env40021) = true)

def env40022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,169401,156117,21763,8328,64,215367,115151,140485,35324,241863,243003,257,254010,197023,169744]

theorem envBound40022 : H12AffineFastState.Bounded env40022 := by
  intro p hp
  have h : env40022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39987_40022 : H12AffineEnvironment.transform 17 10281 env39987 = env40022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39987 == env40022) = true)

def env40023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21929,41413,21763,8328,64,100695,115151,58581,35324,94423,95531,257,73770,115087,22272]

theorem envBound40023 : H12AffineFastState.Bounded env40023 := by
  intro p hp
  have h : env40023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40022_40023 : H12AffineEnvironment.transform 16 49168 env40022 = env40023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env40022 == env40023) = true)

theorem identity40023 : scanCanonicalize (H12AffineFastState.compose env40023 (packedSelected [0,1,2,3,5,6,7,11,14,15,18,20,26,28,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21727) := by decide +kernel

theorem selectedBound40023 : packedSelected [0,1,2,3,5,6,7,11,14,15,18,20,26,28,35,38] rootPS < 2^1333 := by decide +kernel

def env40024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21727,49168,10281,1025,32769,4161,21929,41413,21763,8328,64,56712,38160,58581,35324,9224,8692,257,29941,38224,22272]

theorem envBound40024 : H12AffineFastState.Bounded env40024 := by
  intro p hp
  have h : env40024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40023_40024 : H12AffineEnvironment.transform 15 21727 env40023 = env40024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21727 env40023 == env40024) = true)

theorem identity40024 : scanCanonicalize (H12AffineFastState.compose env40024 (packedSelected [2,5,6,7,9,20,22,23,24,26,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40024 : packedSelected [2,5,6,7,9,20,22,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env40025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,478,38161,10281,1025,32769,4161,168,41413,2,8328,64,34953,38160,45524,35324,9224,8692,257,8692,38224,513]

theorem envBound40025 : H12AffineFastState.Bounded env40025 := by
  intro p hp
  have h : env40025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40024_40025 : H12AffineEnvironment.transform 13 5377 env40024 = env40025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40024 == env40025) = true)

theorem identity40025 : scanCanonicalize (H12AffineFastState.compose env40025 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound40025 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env40026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,137,478,5528,10281,1025,136,4161,168,8524,2,8328,64,2048,5529,12637,2421,9224,8692,257,8692,5593,513]

theorem envBound40026 : H12AffineFastState.Bounded env40026 := by
  intro p hp
  have h : env40026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40025_40026 : H12AffineEnvironment.transform 14 137 env40025 = env40026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env40025 == env40026) = true)

theorem identity40026 : scanCanonicalize (H12AffineFastState.compose env40026 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40026 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,343,5393,10281,1025,1,4161,33,8524,2,8193,64,2048,5392,12637,2421,9224,8573,257,8573,5456,513]

theorem envBound40027 : H12AffineFastState.Bounded env40027 := by
  intro p hp
  have h : env40027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40026_40027 : H12AffineEnvironment.transform 6 9 env40026 = env40027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40026 == env40027) = true)

theorem identity40027 : scanCanonicalize (H12AffineFastState.compose env40027 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40027 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,0,343,5393,2341,1025,1,4161,33,64,2,269,64,2048,5392,4177,2421,1284,113,257,113,5456,513]

theorem envBound40028 : H12AffineFastState.Bounded env40028 := by
  intro p hp
  have h : env40028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40027_40028 : H12AffineEnvironment.transform 12 268 env40027 = env40028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40027 == env40028) = true)

theorem identity40028 : scanCanonicalize (H12AffineFastState.compose env40028 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound40028 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env40029 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,268,4192,0,343,4208,2341,352,1,4161,33,64,2,269,64,2048,4209,4177,2421,101,113,257,113,4145,513]

theorem envBound40029 : H12AffineFastState.Bounded env40029 := by
  intro p hp
  have h : env40029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40028_40029 : H12AffineEnvironment.transform 9 353 env40028 = env40029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env40028 == env40029) = true)

theorem identity40029 : scanCanonicalize (H12AffineFastState.compose env40029 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40029 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env40030 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,268,4145,0,262,4129,2341,305,1,4112,33,17,2,269,17,2048,4128,4096,2340,52,32,257,32,4145,513]

theorem envBound40030 : H12AffineFastState.Bounded env40030 := by
  intro p hp
  have h : env40030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40029_40030 : H12AffineEnvironment.transform 5 17 env40029 = env40030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40029 == env40030) = true)

theorem identity40030 : scanCanonicalize (H12AffineFastState.compose env40030 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2847) := by decide +kernel

theorem selectedBound40030 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40031 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,2847,268,2862,0,262,2878,2341,305,1,2831,33,17,2,269,17,2048,2879,2847,2340,52,32,257,32,2862,513]

theorem envBound40031 : H12AffineFastState.Bounded env40031 := by
  intro p hp
  have h : env40031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40030_40031 : H12AffineEnvironment.transform 11 2847 env40030 = env40031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2847 env40030 == env40031) = true)

theorem identity40031 : scanCanonicalize (H12AffineFastState.compose env40031 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound40031 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40032 : List Nat := [2,4,8,16,32,17,9,256,10,304,2048,2325,268,2340,0,262,2356,2341,305,1,2309,33,17,2,269,17,2048,2357,2325,2340,52,32,257,32,2340,11]

theorem envBound40032 : H12AffineFastState.Bounded env40032 := by
  intro p hp
  have h : env40032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40031_40032 : H12AffineEnvironment.transform 8 10 env40031 = env40032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env40031 == env40032) = true)

theorem identity40032 : scanCanonicalize (H12AffineFastState.compose env40032 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound40032 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40033 : List Nat := [2,4,8,16,32,17,9,256,10,304,33,308,268,261,0,262,277,260,305,1,292,33,17,2,269,17,33,276,308,261,52,32,257,32,261,11]

theorem envBound40033 : H12AffineFastState.Bounded env40033 := by
  intro p hp
  have h : env40033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40032_40033 : H12AffineEnvironment.transform 10 33 env40032 = env40033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env40032 == env40033) = true)

theorem identity40033 : scanCanonicalize (H12AffineFastState.compose env40033 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40033 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40034 : List Nat := [2,4,8,16,32,17,9,37,10,21,33,17,41,32,0,35,48,33,20,1,1,33,17,2,40,17,33,49,17,32,52,32,36,32,32,11]

theorem envBound40034 : H12AffineFastState.Bounded env40034 := by
  intro p hp
  have h : env40034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40033_40034 : H12AffineEnvironment.transform 7 37 env40033 = env40034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40033 == env40034) = true)

theorem identity40034 : scanCanonicalize (H12AffineFastState.compose env40034 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound40034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40035 : List Nat := [2,4,7,16,32,17,6,37,5,21,33,17,38,32,0,35,48,33,20,1,1,33,17,2,39,17,33,49,17,32,52,32,36,32,32,4]

theorem envBound40035 : H12AffineFastState.Bounded env40035 := by
  intro p hp
  have h : env40035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40034_40035 : H12AffineEnvironment.transform 2 7 env40034 = env40035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env40034 == env40035) = true)

theorem identity40035 : scanCanonicalize (H12AffineFastState.compose env40035 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound40035 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40036 : List Nat := [2,4,7,16,2,17,6,7,5,21,3,17,4,2,0,1,18,3,20,1,1,3,17,2,5,17,3,19,17,2,22,2,6,2,2,4]

theorem envBound40036 : H12AffineFastState.Bounded env40036 := by
  intro p hp
  have h : env40036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40035_40036 : H12AffineEnvironment.transform 4 2 env40035 = env40036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env40035 == env40036) = true)

def env40037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21928,41412,21763,8328,64,100694,115151,58580,35324,94422,95530,257,73771,115086,22273]

theorem envBound40037 : H12AffineFastState.Bounded env40037 := by
  intro p hp
  have h : env40037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40022_40037 : H12AffineEnvironment.transform 16 49169 env40022 = env40037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env40022 == env40037) = true)

theorem identity40037 : scanCanonicalize (H12AffineFastState.compose env40037 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40037 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21793,41293,21763,8193,64,100694,115014,58461,35189,94303,95530,257,73771,114951,22273]

theorem envBound40038 : H12AffineFastState.Bounded env40038 := by
  intro p hp
  have h : env40038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40037_40038 : H12AffineEnvironment.transform 6 9 env40037 = env40038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40037 == env40038) = true)

theorem identity40038 : scanCanonicalize (H12AffineFastState.compose env40038 (packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound40038 : packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40039 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,65536,5440,10281,1025,21840,4161,21793,29724,21763,8193,64,89095,70679,12556,23588,94303,95530,257,73771,70742,22273]

theorem envBound40039 : H12AffineFastState.Bounded env40039 := by
  intro p hp
  have h : env40039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40038_40039 : H12AffineEnvironment.transform 14 21841 env40038 = env40039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env40038 == env40039) = true)

theorem identity40039 : scanCanonicalize (H12AffineFastState.compose env40039 (packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound40039 : packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS < 2^1333 := by decide +kernel

def env40040 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,263,5440,10281,1025,21840,4161,21793,29724,21763,8193,64,23808,5392,12556,23588,29016,29741,257,8492,5457,22273]

theorem envBound40040 : H12AffineFastState.Bounded env40040 := by
  intro p hp
  have h : env40040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40039_40040 : H12AffineEnvironment.transform 15 263 env40039 = env40040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env40039 == env40040) = true)

theorem identity40040 : scanCanonicalize (H12AffineFastState.compose env40040 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40040 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40041 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8460,263,5440,10281,1025,8461,4161,8572,65,8542,8193,64,10589,5392,12556,10361,1285,112,257,8492,5457,9052]

theorem envBound40041 : H12AffineFastState.Bounded env40041 := by
  intro p hp
  have h : env40041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40040_40041 : H12AffineEnvironment.transform 13 13405 env40040 = env40041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40040 == env40041) = true)

theorem identity40041 : scanCanonicalize (H12AffineFastState.compose env40041 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40041 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40042 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,1,263,5440,2340,1025,0,4161,113,65,83,268,64,2128,5392,4097,2420,1285,112,257,33,5457,593]

theorem envBound40042 : H12AffineFastState.Bounded env40042 := by
  intro p hp
  have h : env40042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40041_40042 : H12AffineEnvironment.transform 12 269 env40041 = env40042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40041 == env40042) = true)

theorem identity40042 : scanCanonicalize (H12AffineFastState.compose env40042 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40042 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env40043 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5157,1,114,5173,2129,1025,0,4161,113,65,83,121,64,2128,5221,4097,2049,1136,112,116,33,5156,593]

theorem envBound40043 : H12AffineFastState.Bounded env40043 := by
  intro p hp
  have h : env40043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40042_40043 : H12AffineEnvironment.transform 7 117 env40042 = env40043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40042 == env40043) = true)

def env40044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356288,25265169,23160257,525568,27902125,27337992,25733063]

theorem envBound40044 : H12AffineFastState.Bounded env40044 := by
  intro p hp
  have h : env40044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39565_40044 : H12AffineEnvironment.transform 26 30393345 env39565 = env40044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env39565 == env40044) = true)

def env40045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265169,23160257,256,27378861,27337992,25207751]

theorem envBound40045 : H12AffineFastState.Bounded env40045 := by
  intro p hp
  have h : env40045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40044_40045 : H12AffineEnvironment.transform 18 1024 env40044 = env40045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env40044 == env40045) = true)

theorem identity40045 : scanCanonicalize (H12AffineFastState.compose env40045 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 41430) := by decide +kernel

theorem selectedBound40045 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41430,8328,64,13066711,2172250,10507601,8830976,8463815,6407191,256,10577275,10585310,8389137]

theorem envBound40046 : H12AffineFastState.Bounded env40046 := by
  intro p hp
  have h : env40046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40045_40046 : H12AffineEnvironment.transform 23 41430 env40045 = env40046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41430 env40045 == env40046) = true)

def env40047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,8388608,41430,8328,64,13066711,115150,8434117,8830976,8463815,4268163,256,8487407,8478794,8389137]

theorem envBound40047 : H12AffineFastState.Bounded env40047 := by
  intro p hp
  have h : env40047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40046_40047 : H12AffineEnvironment.transform 20 58516 env40046 = env40047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env40046 == env40047) = true)

def env40048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,16,41430,8328,64,4678087,115150,45525,442384,75223,4268163,256,98815,90202,513]

theorem envBound40048 : H12AffineFastState.Bounded env40048 := by
  intro p hp
  have h : env40048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40047_40048 : H12AffineEnvironment.transform 22 16 env40047 = env40048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40047 == env40048) = true)

def env40049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41310,8192,64,4677967,115014,45405,442384,75103,4268043,256,98679,90202,513]

theorem envBound40049 : H12AffineFastState.Bounded env40049 := by
  intro p hp
  have h : env40049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40048_40049 : H12AffineEnvironment.transform 6 8 env40048 = env40049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40048 == env40049) = true)

theorem identity40049 : scanCanonicalize (H12AffineFastState.compose env40049 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40049 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,17728,4194304,16,2,8192,64,4677967,90138,4097,418124,75103,4268043,256,73771,90202,513]

theorem envBound40050 : H12AffineFastState.Bounded env40050 := by
  intro p hp
  have h : env40050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40049_40050 : H12AffineEnvironment.transform 14 8540 env40049 = env40050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40049 == env40050) = true)

theorem identity40050 : scanCanonicalize (H12AffineFastState.compose env40050 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound40050 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,131072,262144,1024,8541,5456,4194304,16,2,8192,64,4665695,77834,4097,405852,75103,4268043,256,73771,77898,513]

theorem envBound40051 : H12AffineFastState.Bounded env40051 := by
  intro p hp
  have h : env40051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40050_40051 : H12AffineEnvironment.transform 13 4112 env40050 = env40051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env40050 == env40051) = true)

theorem identity40051 : scanCanonicalize (H12AffineFastState.compose env40051 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 77835) := by decide +kernel

theorem selectedBound40051 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env40052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77835,262144,1024,8541,5456,4194304,16,2,8192,64,4456788,77834,4097,328023,75103,4268043,256,73771,77898,513]

theorem envBound40052 : H12AffineFastState.Bounded env40052 := by
  intro p hp
  have h : env40052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40051_40052 : H12AffineEnvironment.transform 16 77835 env40051 = env40052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 77835 env40051 == env40052) = true)

theorem identity40052 : scanCanonicalize (H12AffineFastState.compose env40052 (packedSelected [0,2,3,5,6,10,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound40052 : packedSelected [0,2,3,5,6,10,14,27] rootPS < 2^1333 := by decide +kernel

def env40053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77835,262144,1024,8541,5456,33,16,2,8192,64,262517,77834,4097,328023,75103,73770,256,73771,77898,513]

theorem envBound40053 : H12AffineFastState.Bounded env40053 := by
  intro p hp
  have h : env40053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40052_40053 : H12AffineEnvironment.transform 21 33 env40052 = env40053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env40052 == env40053) = true)

theorem identity40053 : scanCanonicalize (H12AffineFastState.compose env40053 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound40053 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env40054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,65536,77835,67619,1024,8541,5456,33,16,2,8192,64,67926,77834,4097,2420,75103,73770,256,73771,77898,513]

theorem envBound40054 : H12AffineFastState.Bounded env40054 := by
  intro p hp
  have h : env40054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40053_40054 : H12AffineEnvironment.transform 17 67619 env40053 = env40054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env40053 == env40054) = true)

theorem identity40054 : scanCanonicalize (H12AffineFastState.compose env40054 (packedSelected [0,4,6,7,9,11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 1298) := by decide +kernel

theorem selectedBound40054 : packedSelected [0,4,6,7,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env40055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,1298,13593,3377,1024,8541,5456,33,16,2,8192,64,3140,13592,4097,2420,8269,9528,256,9529,13656,513]

theorem envBound40055 : H12AffineFastState.Bounded env40055 := by
  intro p hp
  have h : env40055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40054_40055 : H12AffineEnvironment.transform 15 1298 env40054 = env40055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1298 env40054 == env40055) = true)

theorem identity40055 : scanCanonicalize (H12AffineFastState.compose env40055 (packedSelected [0,1,2,3,4,7,9,11,12,15,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound40055 : packedSelected [0,1,2,3,4,7,9,11,12,15,23,24,28] rootPS < 2^1333 := by decide +kernel

def env40056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1305,4112,1093,1298,4096,3377,1024,1092,5456,33,16,2,1305,64,3140,4097,4097,2420,1364,33,256,32,4161,513]

theorem envBound40056 : H12AffineFastState.Bounded env40056 := by
  intro p hp
  have h : env40056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart0