import H12CloudChart0Data006

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound1695 : H12AffineFastState.Bounded env1695 := by
  intro p hp
  have h : env1695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1660_1695 : H12AffineEnvironment.transform 18 1025 env1660 = env1695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1660 == env1695) = true)

def env1696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16385,151552,2081,16852469,4341977,257,1,131072,16925298]

theorem envBound1696 : H12AffineFastState.Bounded env1696 := by
  intro p hp
  have h : env1696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1695_1696 : H12AffineEnvironment.transform 34 131072 env1695 = env1696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1695 == env1696) = true)

theorem identity1696 : scanCanonicalize (H12AffineFastState.compose env1696 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6365500) := by decide +kernel

theorem selectedBound1696 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,6365500,8328,147472,409817,16385,151552,2081,6292681,4341977,257,1,131072,6513486]

theorem envBound1697 : H12AffineFastState.Bounded env1697 := by
  intro p hp
  have h : env1697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1696_1697 : H12AffineEnvironment.transform 23 6365500 env1696 = env1697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6365500 env1696 == env1697) = true)

theorem identity1697 : scanCanonicalize (H12AffineFastState.compose env1697 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound1697 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,2097152,4194304,147520,6291782,8328,147472,409817,16385,151552,2081,6292681,4341977,257,1,131072,6439732]

theorem envBound1698 : H12AffineFastState.Bounded env1698 := by
  intro p hp
  have h : env1698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1697_1698 : H12AffineEnvironment.transform 15 8314 env1697 = env1698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env1697 == env1698) = true)

def env1699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,2097152,147672,147520,2245022,8328,147472,409817,16385,151552,2081,2245649,1,257,1,131072,2098156]

theorem envBound1699 : H12AffineFastState.Bounded env1699 := by
  intro p hp
  have h : env1699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1698_1699 : H12AffineEnvironment.transform 21 147672 env1698 = env1699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env1698 == env1699) = true)

theorem identity1699 : scanCanonicalize (H12AffineFastState.compose env1699 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 233) := by decide +kernel

theorem selectedBound1699 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,233,147672,147520,147831,8328,147472,409817,16385,151552,2081,148728,1,257,1,131072,773]

theorem envBound1700 : H12AffineFastState.Bounded env1700 := by
  intro p hp
  have h : env1700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1699_1700 : H12AffineEnvironment.transform 20 233 env1699 = env1700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 233 env1699 == env1700) = true)

theorem identity1700 : scanCanonicalize (H12AffineFastState.compose env1700 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound1700 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,16632,262144,1025,8693,233,32,184,399,8328,232,262177,16385,4344,2081,1024,1,257,1,16632,773]

theorem envBound1701 : H12AffineFastState.Bounded env1701 := by
  intro p hp
  have h : env1701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1700_1701 : H12AffineEnvironment.transform 16 16632 env1700 = env1701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1700 == env1701) = true)

theorem identity1701 : scanCanonicalize (H12AffineFastState.compose env1701 (packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound1701 : packedSelected [1,3,4,5,8,9,10,13,17,19,20] rootPS < 2^1333 := by decide +kernel

def env1702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,16632,2264,1025,8693,233,32,184,399,8328,232,2297,16385,4344,2081,1024,1,257,1,16632,773]

theorem envBound1702 : H12AffineFastState.Bounded env1702 := by
  intro p hp
  have h : env1702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1701_1702 : H12AffineEnvironment.transform 17 2264 env1701 = env1702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env1701 == env1702) = true)

theorem identity1702 : scanCanonicalize (H12AffineFastState.compose env1702 (packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound1702 : packedSelected [1,2,3,5,6,8,10,11,13,15,19] rootPS < 2^1333 := by decide +kernel

def env1703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1084,16384,1481,1094,16632,2264,1025,1481,233,32,184,399,1204,232,2297,16385,4344,2081,1024,1,257,1,16632,773]

theorem envBound1703 : H12AffineFastState.Bounded env1703 := by
  intro p hp
  have h : env1703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1702_1703 : H12AffineEnvironment.transform 12 1084 env1702 = env1703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env1702 == env1703) = true)

theorem identity1703 : scanCanonicalize (H12AffineFastState.compose env1703 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound1703 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env1704 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1084,16384,1125,1094,16632,2264,1025,1125,233,32,184,35,1204,232,2297,16385,4344,2081,1024,1,173,1,16632,681]

theorem envBound1704 : H12AffineFastState.Bounded env1704 := by
  intro p hp
  have h : env1704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1703_1704 : H12AffineEnvironment.transform 7 172 env1703 = env1704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env1703 == env1704) = true)

theorem identity1704 : scanCanonicalize (H12AffineFastState.compose env1704 (packedSelected [0,1,4,5,6,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2097) := by decide +kernel

theorem selectedBound1704 : packedSelected [0,1,4,5,6,11,15] rootPS < 2^1333 := by decide +kernel

def env1705 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,1084,2097,1125,1094,2249,2264,1025,1125,233,32,184,35,1204,232,2297,2096,4344,2081,1024,1,173,1,2249,681]

theorem envBound1705 : H12AffineFastState.Bounded env1705 := by
  intro p hp
  have h : env1705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1704_1705 : H12AffineEnvironment.transform 13 2097 env1704 = env1705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2097 env1704 == env1705) = true)

theorem identity1705 : scanCanonicalize (H12AffineFastState.compose env1705 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound1705 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env1706 : List Nat := [2,4,8,16,32,64,128,172,512,117,2048,4096,73,2097,16,51,2249,2264,116,16,233,32,184,35,193,232,2297,2096,4344,2081,117,1,173,1,2249,681]

theorem envBound1706 : H12AffineFastState.Bounded env1706 := by
  intro p hp
  have h : env1706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1705_1706 : H12AffineEnvironment.transform 9 117 env1705 = env1706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env1705 == env1706) = true)

theorem identity1706 : scanCanonicalize (H12AffineFastState.compose env1706 (packedSelected [0,1,3,5,7,8,10,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 2128) := by decide +kernel

theorem selectedBound1706 : packedSelected [0,1,3,5,7,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env1707 : List Nat := [2,4,8,16,32,64,128,172,512,117,2048,2128,73,2097,16,51,2249,2264,116,16,233,32,184,35,193,232,2297,2096,2216,2081,117,1,173,1,2249,681]

theorem envBound1707 : H12AffineFastState.Bounded env1707 := by
  intro p hp
  have h : env1707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1706_1707 : H12AffineEnvironment.transform 11 2128 env1706 = env1707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2128 env1706 == env1707) = true)

theorem identity1707 : scanCanonicalize (H12AffineFastState.compose env1707 (packedSelected [0,1,2,4,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound1707 : packedSelected [0,1,2,4,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env1708 : List Nat := [2,4,8,16,32,64,128,172,512,117,185,233,73,136,16,51,112,97,116,16,233,32,184,35,193,232,64,137,17,152,117,1,173,1,112,681]

theorem envBound1708 : H12AffineFastState.Bounded env1708 := by
  intro p hp
  have h : env1708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1707_1708 : H12AffineEnvironment.transform 10 185 env1707 = env1708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env1707 == env1708) = true)

theorem identity1708 : scanCanonicalize (H12AffineFastState.compose env1708 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound1708 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env1709 : List Nat := [2,4,8,16,32,17,128,172,512,36,185,184,24,136,16,51,33,48,37,16,184,32,184,35,144,185,17,137,17,152,36,1,173,1,33,681]

theorem envBound1709 : H12AffineFastState.Bounded env1709 := by
  intro p hp
  have h : env1709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1708_1709 : H12AffineEnvironment.transform 5 17 env1708 = env1709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env1708 == env1709) = true)

theorem identity1709 : scanCanonicalize (H12AffineFastState.compose env1709 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound1709 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env1710 : List Nat := [2,4,8,16,32,17,4,40,512,36,61,60,24,12,16,51,33,48,37,16,60,32,60,35,20,61,17,13,17,28,36,1,41,1,33,557]

theorem envBound1710 : H12AffineFastState.Bounded env1710 := by
  intro p hp
  have h : env1710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1709_1710 : H12AffineEnvironment.transform 6 4 env1709 = env1710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env1709 == env1710) = true)

theorem identity1710 : scanCanonicalize (H12AffineFastState.compose env1710 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound1710 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env1711 : List Nat := [2,4,8,16,29,17,4,21,512,25,0,1,24,12,16,14,28,13,24,16,1,29,1,30,20,0,17,13,17,28,25,1,20,1,28,528]

theorem envBound1711 : H12AffineFastState.Bounded env1711 := by
  intro p hp
  have h : env1711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1710_1711 : H12AffineEnvironment.transform 4 29 env1710 = env1711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env1710 == env1711) = true)

theorem identity1711 : scanCanonicalize (H12AffineFastState.compose env1711 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound1711 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env1712 : List Nat := [2,4,8,0,13,1,4,5,512,9,0,1,8,12,0,14,12,13,8,0,1,13,1,14,4,0,1,13,1,12,9,1,4,1,12,512]

theorem envBound1712 : H12AffineFastState.Bounded env1712 := by
  intro p hp
  have h : env1712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1711_1712 : H12AffineEnvironment.transform 3 0 env1711 = env1712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env1711 == env1712) = true)

theorem identity1712 : scanCanonicalize (H12AffineFastState.compose env1712 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound1712 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1713 : List Nat := [2,4,3,0,6,1,4,5,512,2,0,1,3,7,0,5,7,6,3,0,1,6,1,5,4,0,1,6,1,7,2,1,4,1,7,512]

theorem envBound1713 : H12AffineFastState.Bounded env1713 := by
  intro p hp
  have h : env1713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1712_1713 : H12AffineEnvironment.transform 2 3 env1712 = env1713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env1712 == env1713) = true)

def env1714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,2097152,147673,147520,2245023,8328,147472,409817,16385,151552,2081,2245648,0,257,1,131072,2098157]

theorem envBound1714 : H12AffineFastState.Bounded env1714 := by
  intro p hp
  have h : env1714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1698_1714 : H12AffineEnvironment.transform 21 147673 env1698 = env1714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env1698 == env1714) = true)

theorem identity1714 : scanCanonicalize (H12AffineFastState.compose env1714 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1714 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1715 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,131072,262144,1025,8432,2097152,147673,147520,2244762,8328,147472,409817,16385,151552,2081,2245648,0,4,1,131072,2097896]

theorem envBound1715 : H12AffineFastState.Bounded env1715 := by
  intro p hp
  have h : env1715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1714_1715 : H12AffineEnvironment.transform 7 5 env1714 = env1715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1714 == env1715) = true)

def env1716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147472,409817,16385,151552,2081,16852469,4341977,257,1,131073,16925298]

theorem envBound1716 : H12AffineFastState.Bounded env1716 := by
  intro p hp
  have h : env1716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1695_1716 : H12AffineEnvironment.transform 34 131073 env1695 = env1716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1695 == env1716) = true)

theorem identity1716 : scanCanonicalize (H12AffineFastState.compose env1716 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4272445) := by decide +kernel

theorem selectedBound1716 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,4272445,8328,147472,409817,16385,151552,2081,4199624,4341977,257,1,131073,4420431]

theorem envBound1717 : H12AffineFastState.Bounded env1717 := by
  intro p hp
  have h : env1717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1716_1717 : H12AffineEnvironment.transform 23 4272445 env1716 = env1717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4272445 env1716 == env1717) = true)

theorem identity1717 : scanCanonicalize (H12AffineFastState.compose env1717 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound1717 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,293,147520,77848,8328,147472,409817,16385,151552,2081,5613,147964,257,1,131073,225898]

theorem envBound1718 : H12AffineFastState.Bounded env1718 := by
  intro p hp
  have h : env1718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1717_1718 : H12AffineEnvironment.transform 21 293 env1717 = env1718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env1717 == env1718) = true)

def env1719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16892,262144,1025,8693,2097152,293,444,77848,8328,492,262437,16385,4604,2081,5613,0,257,1,16893,78742]

theorem envBound1719 : H12AffineFastState.Bounded env1719 := by
  intro p hp
  have h : env1719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1718_1719 : H12AffineEnvironment.transform 16 16892 env1718 = env1719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env1718 == env1719) = true)

theorem identity1719 : scanCanonicalize (H12AffineFastState.compose env1719 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound1719 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8575,16892,262144,1025,8693,2097152,293,444,4455,8328,492,262437,16385,4604,2081,5613,0,257,1,16893,4841]

theorem envBound1720 : H12AffineFastState.Bounded env1720 := by
  intro p hp
  have h : env1720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1719_1720 : H12AffineEnvironment.transform 15 8575 env1719 = env1720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env1719 == env1720) = true)

def env1721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16893,262144,1025,8693,2097152,293,445,77848,8328,493,262436,16385,4605,2081,5613,1,257,1,16892,78743]

theorem envBound1721 : H12AffineFastState.Bounded env1721 := by
  intro p hp
  have h : env1721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1718_1721 : H12AffineEnvironment.transform 16 16893 env1718 = env1721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env1718 == env1721) = true)

theorem identity1721 : scanCanonicalize (H12AffineFastState.compose env1721 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound1721 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,16384,8693,65536,16893,262144,1025,8693,2097152,293,445,73968,8328,493,262436,16385,277,2081,1285,1,257,1,16892,74623]

theorem envBound1722 : H12AffineFastState.Bounded env1722 := by
  intro p hp
  have h : env1722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1721_1722 : H12AffineEnvironment.transform 11 232 env1721 = env1722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env1721 == env1722) = true)

theorem identity1722 : scanCanonicalize (H12AffineFastState.compose env1722 (packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound1722 : packedSelected [3,5,8,10,17,18,19,21,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env1723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,16384,8693,65536,16893,2525,1025,8693,2097152,293,445,73968,8328,493,2297,16385,277,2081,1285,1,257,1,16892,74623]

theorem envBound1723 : H12AffineFastState.Bounded env1723 := by
  intro p hp
  have h : env1723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1722_1723 : H12AffineEnvironment.transform 17 2525 env1722 = env1723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env1722 == env1723) = true)

theorem identity1723 : scanCanonicalize (H12AffineFastState.compose env1723 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1723 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env1724 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,16384,8432,65536,16632,2264,1025,8432,2097152,32,184,73968,8328,232,2297,16385,16,2081,1024,1,4,1,16633,74362]

theorem envBound1724 : H12AffineFastState.Bounded env1724 := by
  intro p hp
  have h : env1724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1723_1724 : H12AffineEnvironment.transform 7 5 env1723 = env1724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1723 == env1724) = true)

theorem identity1724 : scanCanonicalize (H12AffineFastState.compose env1724 (packedSelected [2,6,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1724 : packedSelected [2,6,11,15,17] rootPS < 2^1333 := by decide +kernel

def env1725 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,16384,8432,8315,16632,2264,1025,8432,2097152,32,184,139,8328,232,2297,16385,16,2081,1024,1,4,1,16633,513]

theorem envBound1725 : H12AffineFastState.Bounded env1725 := by
  intro p hp
  have h : env1725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1724_1725 : H12AffineEnvironment.transform 15 8315 env1724 = env1725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1724 == env1725) = true)

theorem identity1725 : scanCanonicalize (H12AffineFastState.compose env1725 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(20+1) ^^^ 3766) := by decide +kernel

theorem selectedBound1725 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1726 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,16384,8432,8315,16632,2264,1025,8432,3766,32,184,139,8328,232,2297,16385,16,2081,1024,1,4,1,16633,513]

theorem envBound1726 : H12AffineFastState.Bounded env1726 := by
  intro p hp
  have h : env1726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1725_1726 : H12AffineEnvironment.transform 20 3766 env1725 = env1726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3766 env1725 == env1726) = true)

theorem identity1726 : scanCanonicalize (H12AffineFastState.compose env1726 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(13+1) ^^^ 2297) := by decide +kernel

theorem selectedBound1726 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1727 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,232,8192,2297,8432,8315,2049,2264,1025,8432,3766,32,184,139,8328,232,2297,2296,16,2081,1024,1,4,1,2048,513]

theorem envBound1727 : H12AffineFastState.Bounded env1727 := by
  intro p hp
  have h : env1727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1726_1727 : H12AffineEnvironment.transform 13 2297 env1726 = env1727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2297 env1726 == env1727) = true)

theorem identity1727 : scanCanonicalize (H12AffineFastState.compose env1727 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 1671) := by decide +kernel

theorem selectedBound1727 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env1728 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1671,232,8192,1662,8432,8315,1670,1631,1025,8432,49,32,184,139,8328,232,1662,1663,16,1702,1024,1,4,1,1671,513]

theorem envBound1728 : H12AffineFastState.Bounded env1728 := by
  intro p hp
  have h : env1728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1727_1728 : H12AffineEnvironment.transform 10 1671 env1727 = env1728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1671 env1727 == env1728) = true)

theorem identity1728 : scanCanonicalize (H12AffineFastState.compose env1728 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1236) := by decide +kernel

theorem selectedBound1728 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1729 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1671,232,1236,1662,1060,1199,1670,1631,1025,1060,49,32,184,139,1116,232,1662,1663,16,1702,1024,1,4,1,1671,513]

theorem envBound1729 : H12AffineFastState.Bounded env1729 := by
  intro p hp
  have h : env1729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1728_1729 : H12AffineEnvironment.transform 12 1236 env1728 = env1729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1236 env1728 == env1729) = true)

theorem identity1729 : scanCanonicalize (H12AffineFastState.compose env1729 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 678) := by decide +kernel

theorem selectedBound1729 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1730 : List Nat := [2,4,8,16,32,64,128,5,512,678,33,232,626,216,642,521,32,249,679,642,49,32,184,139,762,232,216,217,16,0,678,1,4,1,33,513]

theorem envBound1730 : H12AffineFastState.Bounded env1730 := by
  intro p hp
  have h : env1730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1729_1730 : H12AffineEnvironment.transform 9 678 env1729 = env1730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 678 env1729 == env1730) = true)

theorem identity1730 : scanCanonicalize (H12AffineFastState.compose env1730 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound1730 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1731 : List Nat := [2,4,8,16,32,49,128,5,512,678,33,153,515,169,642,521,32,136,679,642,49,32,184,139,651,153,169,168,16,0,678,1,4,1,33,513]

theorem envBound1731 : H12AffineFastState.Bounded env1731 := by
  intro p hp
  have h : env1731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1730_1731 : H12AffineEnvironment.transform 5 49 env1730 = env1731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env1730 == env1731) = true)

theorem identity1731 : scanCanonicalize (H12AffineFastState.compose env1731 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound1731 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1732 : List Nat := [2,4,8,16,32,49,128,5,163,5,33,153,160,169,33,170,32,136,4,33,49,32,184,139,40,153,169,168,16,0,5,1,4,1,33,162]

theorem envBound1732 : H12AffineFastState.Bounded env1732 := by
  intro p hp
  have h : env1732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1731_1732 : H12AffineEnvironment.transform 8 163 env1731 = env1732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env1731 == env1732) = true)

theorem identity1732 : scanCanonicalize (H12AffineFastState.compose env1732 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound1732 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1733 : List Nat := [2,4,8,9,32,40,128,5,163,5,33,128,160,169,33,170,32,136,4,33,40,32,161,139,40,128,169,168,9,0,5,1,4,1,33,162]

theorem envBound1733 : H12AffineFastState.Bounded env1733 := by
  intro p hp
  have h : env1733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1732_1733 : H12AffineEnvironment.transform 3 9 env1732 = env1733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env1732 == env1733) = true)

theorem identity1733 : scanCanonicalize (H12AffineFastState.compose env1733 (packedSelected [6,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound1733 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env1734 : List Nat := [2,4,8,9,32,40,8,5,43,5,33,8,40,33,33,34,32,0,4,33,40,32,41,3,40,8,33,32,9,0,5,1,4,1,33,42]

theorem envBound1734 : H12AffineFastState.Bounded env1734 := by
  intro p hp
  have h : env1734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1733_1734 : H12AffineEnvironment.transform 6 8 env1733 = env1734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env1733 == env1734) = true)

theorem identity1734 : scanCanonicalize (H12AffineFastState.compose env1734 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound1734 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1735 : List Nat := [2,4,8,9,1,9,8,5,10,5,0,8,9,0,0,3,1,0,4,0,9,1,8,3,9,8,0,1,9,0,5,1,4,1,0,11]

theorem envBound1735 : H12AffineFastState.Bounded env1735 := by
  intro p hp
  have h : env1735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1734_1735 : H12AffineEnvironment.transform 4 1 env1734 = env1735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env1734 == env1735) = true)

theorem identity1735 : scanCanonicalize (H12AffineFastState.compose env1735 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound1735 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1736 : List Nat := [2,3,8,9,1,9,8,2,10,2,0,8,9,0,0,3,1,0,3,0,9,1,8,3,9,8,0,1,9,0,2,1,3,1,0,11]

theorem envBound1736 : H12AffineFastState.Bounded env1736 := by
  intro p hp
  have h : env1736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1735_1736 : H12AffineEnvironment.transform 1 3 env1735 = env1736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env1735 == env1736) = true)

theorem identity1736 : scanCanonicalize (H12AffineFastState.compose env1736 (packedSelected [13] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound1736 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env1737 : List Nat := [2,3,1,0,1,0,1,2,3,2,0,1,0,0,0,3,1,0,3,0,0,1,1,3,0,1,0,1,0,0,2,1,3,1,0,2]

theorem envBound1737 : H12AffineFastState.Bounded env1737 := by
  intro p hp
  have h : env1737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1736_1737 : H12AffineEnvironment.transform 2 1 env1736 = env1737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env1736 == env1737) = true)

def env1738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147521,16777216,8328,672784,935129,16385,151552,2081,17375732,4867289,525568,1,34359738368,17450610]

theorem envBound1738 : H12AffineFastState.Bounded env1738 := by
  intro p hp
  have h : env1738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1659_1738 : H12AffineEnvironment.transform 22 147521 env1659 = env1738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env1659 == env1738) = true)

def env1739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16385,151552,2081,16852468,4341977,256,1,34359738368,16925298]

theorem envBound1739 : H12AffineFastState.Bounded env1739 := by
  intro p hp
  have h : env1739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1738_1739 : H12AffineEnvironment.transform 18 1024 env1738 = env1739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1738 == env1739) = true)

def env1740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16385,151552,2081,16852468,4341977,256,1,131072,16925298]

theorem envBound1740 : H12AffineFastState.Bounded env1740 := by
  intro p hp
  have h : env1740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1739_1740 : H12AffineEnvironment.transform 34 131072 env1739 = env1740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1739 == env1740) = true)

theorem identity1740 : scanCanonicalize (H12AffineFastState.compose env1740 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6517804) := by decide +kernel

theorem selectedBound1740 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,6517804,8328,147472,409817,16385,151552,2081,6443480,4341977,256,1,131072,6370910]

theorem envBound1741 : H12AffineFastState.Bounded env1741 := by
  intro p hp
  have h : env1741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1740_1741 : H12AffineEnvironment.transform 23 6517804 env1740 = env1741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6517804 env1740 == env1741) = true)

theorem identity1741 : scanCanonicalize (H12AffineFastState.compose env1741 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 2323623) := by decide +kernel

theorem selectedBound1741 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,2323623,147521,139,8328,147472,409817,16385,151552,2081,75135,2176126,256,1,131072,148217]

theorem envBound1742 : H12AffineFastState.Bounded env1742 := by
  intro p hp
  have h : env1742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1741_1742 : H12AffineEnvironment.transform 21 2323623 env1741 = env1742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2323623 env1741 == env1742) = true)

def env1743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16632,262144,1024,8693,2097152,2176095,185,139,8328,232,262177,16385,4344,2081,75135,2176126,256,1,16632,513]

theorem envBound1743 : H12AffineFastState.Bounded env1743 := by
  intro p hp
  have h : env1743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1742_1743 : H12AffineEnvironment.transform 16 16632 env1742 = env1743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env1742 == env1743) = true)

theorem identity1743 : scanCanonicalize (H12AffineFastState.compose env1743 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 9263) := by decide +kernel

theorem selectedBound1743 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9263,16632,262144,1024,8693,2097152,2101360,185,139,8328,232,262177,16385,4344,2081,336,2101329,256,1,16632,513]

theorem envBound1744 : H12AffineFastState.Bounded env1744 := by
  intro p hp
  have h : env1744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1743_1744 : H12AffineEnvironment.transform 15 9263 env1743 = env1744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9263 env1743 == env1744) = true)

theorem identity1744 : scanCanonicalize (H12AffineFastState.compose env1744 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 4264) := by decide +kernel

theorem selectedBound1744 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env1745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9263,16632,262144,1024,8693,4264,216,185,139,8328,232,262177,16385,4344,2081,336,249,256,1,16632,513]

theorem envBound1745 : H12AffineFastState.Bounded env1745 := by
  intro p hp
  have h : env1745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1744_1745 : H12AffineEnvironment.transform 20 4264 env1744 = env1745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4264 env1744 == env1745) = true)

theorem identity1745 : scanCanonicalize (H12AffineFastState.compose env1745 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound1745 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1746 : List Nat := [2,4,8,16,32,64,128,256,512,424,2048,4096,8192,16384,8693,8583,16632,262144,424,8693,4264,216,185,139,8328,232,262177,16385,4344,2081,336,249,256,1,16632,513]

theorem envBound1746 : H12AffineFastState.Bounded env1746 := by
  intro p hp
  have h : env1746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1745_1746 : H12AffineEnvironment.transform 9 424 env1745 = env1746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env1745 == env1746) = true)

theorem identity1746 : scanCanonicalize (H12AffineFastState.compose env1746 (packedSelected [13,17] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound1746 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1747 : List Nat := [2,4,8,16,32,64,41,256,512,257,2048,4096,8192,16384,8540,8494,16465,262144,257,8540,4097,113,16,34,8225,65,262177,16385,4177,2081,336,80,256,1,16465,513]

theorem envBound1747 : H12AffineFastState.Bounded env1747 := by
  intro p hp
  have h : env1747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1746_1747 : H12AffineEnvironment.transform 6 41 env1746 = env1747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env1746 == env1747) = true)

theorem identity1747 : scanCanonicalize (H12AffineFastState.compose env1747 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 22820) := by decide +kernel

theorem selectedBound1747 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env1748 : List Nat := [2,4,8,16,32,64,41,256,512,257,2048,4096,8192,16384,8540,8494,16465,22820,257,8540,4097,113,16,34,8225,65,22789,16385,4177,2081,336,80,256,1,16465,513]

theorem envBound1748 : H12AffineFastState.Bounded env1748 := by
  intro p hp
  have h : env1748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1747_1748 : H12AffineEnvironment.transform 17 22820 env1747 = env1748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22820 env1747 == env1748) = true)

theorem identity1748 : scanCanonicalize (H12AffineFastState.compose env1748 (packedSelected [1,2,3,5,8,13] rootPS)) = affineNative (2^(13+1) ^^^ 14424) := by decide +kernel

theorem selectedBound1748 : packedSelected [1,2,3,5,8,13] rootPS < 2^1333 := by decide +kernel

def env1749 : List Nat := [2,4,8,16,32,64,41,256,512,257,2048,4096,8192,14424,8540,8494,14345,8572,257,8540,4097,113,16,34,8225,65,8541,14425,4177,2081,336,80,256,1,14345,513]

theorem envBound1749 : H12AffineFastState.Bounded env1749 := by
  intro p hp
  have h : env1749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1748_1749 : H12AffineEnvironment.transform 13 14424 env1748 = env1749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14424 env1748 == env1749) = true)

theorem identity1749 : scanCanonicalize (H12AffineFastState.compose env1749 (packedSelected [1,2,6,8,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2121) := by decide +kernel

theorem selectedBound1749 : packedSelected [1,2,6,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env1750 : List Nat := [2,4,8,16,32,64,41,256,512,257,2048,4096,2121,4113,2325,2407,4160,2357,257,2325,4097,113,16,34,2152,65,2324,4112,4177,2081,336,80,256,1,4160,513]

theorem envBound1750 : H12AffineFastState.Bounded env1750 := by
  intro p hp
  have h : env1750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1749_1750 : H12AffineEnvironment.transform 12 2121 env1749 = env1750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2121 env1749 == env1750) = true)

theorem identity1750 : scanCanonicalize (H12AffineFastState.compose env1750 (packedSelected [2,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound1750 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env1751 : List Nat := [2,4,8,16,32,0,41,256,512,257,2048,4096,2057,4113,2325,2343,4096,2357,257,2325,4097,49,16,34,2088,1,2324,4112,4113,2081,272,16,256,1,4096,513]

theorem envBound1751 : H12AffineFastState.Bounded env1751 := by
  intro p hp
  have h : env1751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1750_1751 : H12AffineEnvironment.transform 5 0 env1750 = env1751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1750 == env1751) = true)

theorem identity1751 : scanCanonicalize (H12AffineFastState.compose env1751 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound1751 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1752 : List Nat := [2,4,8,16,32,0,41,256,512,257,277,4096,284,4113,0,50,4096,32,257,0,4097,49,16,34,317,1,1,4112,4113,308,272,16,256,1,4096,513]

theorem envBound1752 : H12AffineFastState.Bounded env1752 := by
  intro p hp
  have h : env1752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1751_1752 : H12AffineEnvironment.transform 10 277 env1751 = env1752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env1751 == env1752) = true)

theorem identity1752 : scanCanonicalize (H12AffineFastState.compose env1752 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound1752 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env1753 : List Nat := [2,4,8,16,32,0,41,256,512,257,277,293,284,308,0,50,293,32,257,0,292,49,16,34,317,1,1,309,308,308,272,16,256,1,293,513]

theorem envBound1753 : H12AffineFastState.Bounded env1753 := by
  intro p hp
  have h : env1753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1752_1753 : H12AffineEnvironment.transform 11 293 env1752 = env1753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env1752 == env1753) = true)

theorem identity1753 : scanCanonicalize (H12AffineFastState.compose env1753 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 17) := by decide +kernel

theorem selectedBound1753 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1754 : List Nat := [2,4,8,16,32,0,41,17,512,16,4,52,13,37,0,50,52,32,16,0,53,49,16,34,44,1,1,36,37,37,1,16,17,1,52,513]

theorem envBound1754 : H12AffineFastState.Bounded env1754 := by
  intro p hp
  have h : env1754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1753_1754 : H12AffineEnvironment.transform 7 17 env1753 = env1754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 17 env1753 == env1754) = true)

theorem identity1754 : scanCanonicalize (H12AffineFastState.compose env1754 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound1754 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env1755 : List Nat := [2,4,8,16,32,0,41,17,52,16,4,52,13,37,0,50,52,32,16,0,53,49,16,34,44,1,1,36,37,37,1,16,17,1,52,53]

theorem envBound1755 : H12AffineFastState.Bounded env1755 := by
  intro p hp
  have h : env1755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1754_1755 : H12AffineEnvironment.transform 8 52 env1754 = env1755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env1754 == env1755) = true)

theorem identity1755 : scanCanonicalize (H12AffineFastState.compose env1755 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound1755 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env1756 : List Nat := [2,4,8,16,30,0,23,17,10,16,4,10,13,27,0,12,10,30,16,0,11,15,16,28,18,1,1,26,27,27,1,16,17,1,10,11]

theorem envBound1756 : H12AffineFastState.Bounded env1756 := by
  intro p hp
  have h : env1756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1755_1756 : H12AffineEnvironment.transform 4 30 env1755 = env1756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env1755 == env1756) = true)

theorem identity1756 : scanCanonicalize (H12AffineFastState.compose env1756 (packedSelected [0,1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound1756 : packedSelected [0,1,2,8] rootPS < 2^1333 := by decide +kernel

def env1757 : List Nat := [2,4,8,7,9,0,0,6,10,7,4,10,13,12,0,12,10,9,7,0,11,15,7,11,5,1,1,13,12,12,1,7,6,1,10,11]

theorem envBound1757 : H12AffineFastState.Bounded env1757 := by
  intro p hp
  have h : env1757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1756_1757 : H12AffineEnvironment.transform 3 7 env1756 = env1757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env1756 == env1757) = true)

theorem identity1757 : scanCanonicalize (H12AffineFastState.compose env1757 (packedSelected [0,1,2,10] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound1757 : packedSelected [0,1,2,10] rootPS < 2^1333 := by decide +kernel

def env1758 : List Nat := [2,3,8,0,9,0,0,1,10,0,3,10,10,11,0,11,10,9,0,0,11,8,0,11,2,1,1,10,11,11,1,0,1,1,10,11]

theorem envBound1758 : H12AffineFastState.Bounded env1758 := by
  intro p hp
  have h : env1758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1757_1758 : H12AffineEnvironment.transform 1 3 env1757 = env1758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env1757 == env1758) = true)

theorem identity1758 : scanCanonicalize (H12AffineFastState.compose env1758 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound1758 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1759 : List Nat := [0,1,8,0,9,0,0,1,8,0,1,8,8,9,0,9,8,9,0,0,9,8,0,9,0,1,1,8,9,9,1,0,1,1,8,9]

theorem envBound1759 : H12AffineFastState.Bounded env1759 := by
  intro p hp
  have h : env1759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1758_1759 : H12AffineEnvironment.transform 0 0 env1758 = env1759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env1758 == env1759) = true)

theorem identity1759 : scanCanonicalize (H12AffineFastState.compose env1759 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound1759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1760 : List Nat := [0,1,0,0,1,0,0,1,0,0,1,0,0,1,0,1,0,1,0,0,1,0,0,1,0,1,1,0,1,1,1,0,1,1,0,1]

theorem envBound1760 : H12AffineFastState.Bounded env1760 := by
  intro p hp
  have h : env1760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1759_1760 : H12AffineEnvironment.transform 2 0 env1759 = env1760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env1759 == env1760) = true)

def env1761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16633,262144,1024,8693,2097152,2176094,184,139,8328,233,262176,16385,4345,2081,75135,2176126,256,1,16633,512]

theorem envBound1761 : H12AffineFastState.Bounded env1761 := by
  intro p hp
  have h : env1761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1742_1761 : H12AffineEnvironment.transform 16 16633 env1742 = env1761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1742 == env1761) = true)

theorem identity1761 : scanCanonicalize (H12AffineFastState.compose env1761 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 78975) := by decide +kernel

theorem selectedBound1761 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16633,262144,1024,8693,78975,33,184,139,8328,233,262176,16385,4345,2081,75135,1,256,1,16633,512]

theorem envBound1762 : H12AffineFastState.Bounded env1762 := by
  intro p hp
  have h : env1762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1761_1762 : H12AffineEnvironment.transform 20 78975 env1761 = env1762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78975 env1761 == env1762) = true)

theorem identity1762 : scanCanonicalize (H12AffineFastState.compose env1762 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound1762 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env1763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8574,16633,262144,1024,8693,5377,33,184,139,8328,233,262176,16385,4345,2081,1025,1,256,1,16633,512]

theorem envBound1763 : H12AffineFastState.Bounded env1763 := by
  intro p hp
  have h : env1763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1762_1763 : H12AffineEnvironment.transform 15 8574 env1762 = env1763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env1762 == env1763) = true)

def env1764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,16777216,8328,147472,409817,16385,151552,2081,16852468,4341977,256,1,131073,16925298]

theorem envBound1764 : H12AffineFastState.Bounded env1764 := by
  intro p hp
  have h : env1764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1739_1764 : H12AffineEnvironment.transform 34 131073 env1739 = env1764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1739 == env1764) = true)

theorem identity1764 : scanCanonicalize (H12AffineFastState.compose env1764 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4416557) := by decide +kernel

theorem selectedBound1764 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147521,4416557,8328,147472,409817,16385,151552,2081,4342233,4341977,256,1,131073,4269663]

theorem envBound1765 : H12AffineFastState.Bounded env1765 := by
  intro p hp
  have h : env1765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1764_1765 : H12AffineEnvironment.transform 23 4416557 env1764 = env1765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4416557 env1764 == env1765) = true)

theorem identity1765 : scanCanonicalize (H12AffineFastState.compose env1765 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 17912) := by decide +kernel

theorem selectedBound1765 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,17912,262144,1024,8693,2097152,4194304,1465,4268501,8328,1512,263457,16385,5624,2081,4195361,4195617,256,1,17913,4269663]

theorem envBound1766 : H12AffineFastState.Bounded env1766 := by
  intro p hp
  have h : env1766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1765_1766 : H12AffineEnvironment.transform 16 17912 env1765 = env1766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17912 env1765 == env1766) = true)

theorem identity1766 : scanCanonicalize (H12AffineFastState.compose env1766 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 74847) := by decide +kernel

theorem selectedBound1766 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env1767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,17912,262144,1024,8693,2097152,74847,1465,1418,8328,1512,263457,16385,5624,2081,73854,74110,256,1,17913,512]

theorem envBound1767 : H12AffineFastState.Bounded env1767 := by
  intro p hp
  have h : env1767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1766_1767 : H12AffineEnvironment.transform 21 74847 env1766 = env1767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74847 env1766 == env1767) = true)

theorem identity1767 : scanCanonicalize (H12AffineFastState.compose env1767 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound1767 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,9342,17912,262144,1024,8693,2097152,33,1465,1418,8328,1512,263457,16385,5624,2081,1024,1280,256,1,17913,512]

theorem envBound1768 : H12AffineFastState.Bounded env1768 := by
  intro p hp
  have h : env1768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1767_1768 : H12AffineEnvironment.transform 15 9342 env1767 = env1768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env1767 == env1768) = true)

theorem identity1768 : scanCanonicalize (H12AffineFastState.compose env1768 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound1768 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1769 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,8574,16632,262144,256,8693,2097152,33,185,138,8328,232,262177,16385,4344,2081,256,0,256,1,16633,512]

theorem envBound1769 : H12AffineFastState.Bounded env1769 := by
  intro p hp
  have h : env1769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1768_1769 : H12AffineEnvironment.transform 9 256 env1768 = env1769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env1768 == env1769) = true)

theorem identity1769 : scanCanonicalize (H12AffineFastState.compose env1769 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound1769 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env1770 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8693,8574,16632,2081,256,8693,2097152,33,185,138,8328,232,2048,16385,4344,2081,256,0,256,1,16633,512]

theorem envBound1770 : H12AffineFastState.Bounded env1770 := by
  intro p hp
  have h : env1770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1769_1770 : H12AffineEnvironment.transform 17 2081 env1769 = env1770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env1769 == env1770) = true)

theorem identity1770 : scanCanonicalize (H12AffineFastState.compose env1770 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound1770 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1771 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,16384,8201,8322,16632,2081,252,8201,2097152,33,185,138,8328,232,2048,16385,4344,2081,252,0,252,1,16633,512]

theorem envBound1771 : H12AffineFastState.Bounded env1771 := by
  intro p hp
  have h : env1771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1770_1771 : H12AffineEnvironment.transform 7 252 env1770 = env1771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1770 == env1771) = true)

theorem identity1771 : scanCanonicalize (H12AffineFastState.compose env1771 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26674) := by decide +kernel

theorem selectedBound1771 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env1772 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,16384,8201,8322,16632,2081,252,8201,26674,33,185,138,8328,232,2048,16385,4344,2081,252,0,252,1,16633,512]

theorem envBound1772 : H12AffineFastState.Bounded env1772 := by
  intro p hp
  have h : env1772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1771_1772 : H12AffineEnvironment.transform 20 26674 env1771 = env1772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26674 env1771 == env1772) = true)

theorem identity1772 : scanCanonicalize (H12AffineFastState.compose env1772 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12496) := by decide +kernel

theorem selectedBound1772 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env1773 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,8192,12496,8201,8322,12328,2081,252,8201,6370,33,185,138,8328,232,2048,12497,4344,2081,252,0,252,1,12329,512]

theorem envBound1773 : H12AffineFastState.Bounded env1773 := by
  intro p hp
  have h : env1773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1772_1773 : H12AffineEnvironment.transform 13 12496 env1772 = env1773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12496 env1772 == env1773) = true)

theorem identity1773 : scanCanonicalize (H12AffineFastState.compose env1773 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound1773 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env1774 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,4096,2283,6203,2274,2153,6339,2081,252,2274,6370,33,185,138,2147,232,2048,6202,4344,2081,252,0,252,1,6338,512]

theorem envBound1774 : H12AffineFastState.Bounded env1774 := by
  intro p hp
  have h : env1774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1773_1774 : H12AffineEnvironment.transform 12 2283 env1773 = env1774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env1773 == env1774) = true)

theorem identity1774 : scanCanonicalize (H12AffineFastState.compose env1774 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2216) := by decide +kernel

theorem selectedBound1774 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env1775 : List Nat := [2,4,8,16,32,64,128,252,512,252,2048,2216,2283,147,2274,2153,107,2081,252,2274,74,33,185,138,2147,232,2048,146,2128,2081,252,0,252,1,106,512]

theorem envBound1775 : H12AffineFastState.Bounded env1775 := by
  intro p hp
  have h : env1775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1774_1775 : H12AffineEnvironment.transform 11 2216 env1774 = env1775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2216 env1774 == env1775) = true)

theorem identity1775 : scanCanonicalize (H12AffineFastState.compose env1775 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound1775 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1776 : List Nat := [2,4,8,16,32,64,128,252,512,252,194,106,41,147,32,171,107,227,252,32,74,33,185,138,161,232,194,146,146,227,252,0,252,1,106,512]

theorem envBound1776 : H12AffineFastState.Bounded env1776 := by
  intro p hp
  have h : env1776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1775_1776 : H12AffineEnvironment.transform 10 194 env1775 = env1776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env1775 == env1776) = true)

theorem identity1776 : scanCanonicalize (H12AffineFastState.compose env1776 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound1776 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env1777 : List Nat := [2,4,8,16,32,64,18,110,512,110,80,106,41,1,32,57,107,113,110,32,74,33,43,24,51,122,80,0,0,113,110,0,110,1,106,512]

theorem envBound1777 : H12AffineFastState.Bounded env1777 := by
  intro p hp
  have h : env1777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1776_1777 : H12AffineEnvironment.transform 6 18 env1776 = env1777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env1776 == env1777) = true)

def env1778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16385,151552,2081,16852469,4341976,257,1,34359738368,16925299]

theorem envBound1778 : H12AffineFastState.Bounded env1778 := by
  intro p hp
  have h : env1778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1738_1778 : H12AffineEnvironment.transform 18 1025 env1738 = env1778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1738 == env1778) = true)

def env1779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16385,151552,2081,16852469,4341976,257,1,131072,16925299]

theorem envBound1779 : H12AffineFastState.Bounded env1779 := by
  intro p hp
  have h : env1779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1778_1779 : H12AffineEnvironment.transform 34 131072 env1778 = env1779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1778 == env1779) = true)

theorem identity1779 : scanCanonicalize (H12AffineFastState.compose env1779 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6386029) := by decide +kernel

theorem selectedBound1779 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,6386029,8328,147473,409816,16385,151552,2081,6313112,4341976,257,1,131072,6501150]

theorem envBound1780 : H12AffineFastState.Bounded env1780 := by
  intro p hp
  have h : env1780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1779_1780 : H12AffineEnvironment.transform 23 6386029 env1779 = env1780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6386029 env1779 == env1780) = true)

theorem identity1780 : scanCanonicalize (H12AffineFastState.compose env1780 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound1780 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,2097152,4194304,147521,6312215,8328,147473,409816,16385,151552,2081,6313112,4341976,257,1,131072,6427492]

theorem envBound1781 : H12AffineFastState.Bounded env1781 := by
  intro p hp
  have h : env1781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1780_1781 : H12AffineEnvironment.transform 15 8314 env1780 = env1781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env1780 == env1781) = true)

def env1782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,2097152,147672,147521,2232783,8328,147473,409816,16385,151552,2081,2233408,0,257,1,131072,2118588]

theorem envBound1782 : H12AffineFastState.Bounded env1782 := by
  intro p hp
  have h : env1782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1781_1782 : H12AffineEnvironment.transform 21 147672 env1781 = env1782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env1781 == env1782) = true)

theorem identity1782 : scanCanonicalize (H12AffineFastState.compose env1782 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1782 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1783 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,131072,262144,1025,8432,2097152,147672,147521,2232522,8328,147473,409816,16385,151552,2081,2233408,0,4,1,131072,2118329]

theorem envBound1783 : H12AffineFastState.Bounded env1783 := by
  intro p hp
  have h : env1783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1782_1783 : H12AffineEnvironment.transform 7 5 env1782 = env1783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1782 == env1783) = true)

def env1784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,2097152,147673,147521,2232782,8328,147473,409816,16385,151552,2081,2233409,1,257,1,131072,2118589]

theorem envBound1784 : H12AffineFastState.Bounded env1784 := by
  intro p hp
  have h : env1784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1781_1784 : H12AffineEnvironment.transform 21 147673 env1781 = env1784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env1781 == env1784) = true)

theorem identity1784 : scanCanonicalize (H12AffineFastState.compose env1784 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 20664) := by decide +kernel

theorem selectedBound1784 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1025,8693,20664,147673,147521,147830,8328,147473,409816,16385,151552,2081,148729,1,257,1,131072,773]

theorem envBound1785 : H12AffineFastState.Bounded env1785 := by
  intro p hp
  have h : env1785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1784_1785 : H12AffineEnvironment.transform 20 20664 env1784 = env1785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 20664 env1784 == env1785) = true)

theorem identity1785 : scanCanonicalize (H12AffineFastState.compose env1785 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound1785 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,2525,1025,8693,20664,147673,147521,147830,8328,147473,149765,16385,151552,2081,148729,1,257,1,131072,773]

theorem envBound1786 : H12AffineFastState.Bounded env1786 := by
  intro p hp
  have h : env1786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1785_1786 : H12AffineEnvironment.transform 17 2525 env1785 = env1786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env1785 == env1786) = true)

theorem identity1786 : scanCanonicalize (H12AffineFastState.compose env1786 (packedSelected [1,5,8,17,18,21,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound1786 : packedSelected [1,5,8,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env1787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,16633,2525,1025,8693,20664,32,184,399,8328,232,2556,16385,4345,2081,1024,1,257,1,16633,773]

theorem envBound1787 : H12AffineFastState.Bounded env1787 := by
  intro p hp
  have h : env1787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1786_1787 : H12AffineEnvironment.transform 16 16633 env1786 = env1787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1786 == env1787) = true)

theorem identity1787 : scanCanonicalize (H12AffineFastState.compose env1787 (packedSelected [2,6,12,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1787 : packedSelected [2,6,12,13,18] rootPS < 2^1333 := by decide +kernel

def env1788 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8314,16633,2265,1025,8433,20664,32,184,139,8328,232,2296,16385,4345,2081,1024,1,5,1,16633,513]

theorem envBound1788 : H12AffineFastState.Bounded env1788 := by
  intro p hp
  have h : env1788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1787_1788 : H12AffineEnvironment.transform 7 4 env1787 = env1788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1787 == env1788) = true)

theorem identity1788 : scanCanonicalize (H12AffineFastState.compose env1788 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 3766) := by decide +kernel

theorem selectedBound1788 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1789 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,3766,8433,8314,3663,2265,1025,8433,7694,32,184,139,8328,232,2296,3767,4345,2081,1024,1,5,1,3663,513]

theorem envBound1789 : H12AffineFastState.Bounded env1789 := by
  intro p hp
  have h : env1789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1788_1789 : H12AffineEnvironment.transform 13 3766 env1788 = env1789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3766 env1788 == env1789) = true)

theorem identity1789 : scanCanonicalize (H12AffineFastState.compose env1789 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1750) := by decide +kernel

theorem selectedBound1789 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1790 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1750,4096,8192,96,8433,8314,153,1551,1025,8433,4312,32,184,139,8328,232,1582,97,4345,1783,1024,1,5,1,153,513]

theorem envBound1790 : H12AffineFastState.Bounded env1790 := by
  intro p hp
  have h : env1790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1789_1790 : H12AffineEnvironment.transform 10 1750 env1789 = env1790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1750 env1789 == env1790) = true)

theorem identity1790 : scanCanonicalize (H12AffineFastState.compose env1790 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound1790 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1791 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1750,4096,1156,96,1141,1278,153,1551,1025,1141,4312,32,184,139,1036,232,1582,97,4345,1783,1024,1,5,1,153,513]

theorem envBound1791 : H12AffineFastState.Bounded env1791 := by
  intro p hp
  have h : env1791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1790_1791 : H12AffineEnvironment.transform 12 1156 env1790 = env1791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env1790 == env1791) = true)

theorem identity1791 : scanCanonicalize (H12AffineFastState.compose env1791 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1750) := by decide +kernel

theorem selectedBound1791 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env1792 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1750,1750,1156,96,1141,1278,153,1551,1025,1141,1550,32,184,139,1036,232,1582,97,1583,1783,1024,1,5,1,153,513]

theorem envBound1792 : H12AffineFastState.Bounded env1792 := by
  intro p hp
  have h : env1792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1791_1792 : H12AffineEnvironment.transform 11 1750 env1791 = env1792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1750 env1791 == env1792) = true)

theorem identity1792 : scanCanonicalize (H12AffineFastState.compose env1792 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 647) := by decide +kernel

theorem selectedBound1792 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1793 : List Nat := [2,4,8,16,32,64,128,4,512,647,81,81,515,96,754,633,153,136,646,754,137,32,184,139,651,232,169,97,168,112,647,1,5,1,153,513]

theorem envBound1793 : H12AffineFastState.Bounded env1793 := by
  intro p hp
  have h : env1793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1792_1793 : H12AffineEnvironment.transform 9 647 env1792 = env1793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 647 env1792 == env1793) = true)

theorem identity1793 : scanCanonicalize (H12AffineFastState.compose env1793 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1793 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1794 : List Nat := [2,4,8,16,32,64,120,4,512,639,81,81,515,96,522,633,97,112,638,522,113,32,64,115,627,16,81,97,80,112,639,1,5,1,97,513]

theorem envBound1794 : H12AffineFastState.Bounded env1794 := by
  intro p hp
  have h : env1794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1793_1794 : H12AffineEnvironment.transform 6 120 env1793 = env1794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1793 == env1794) = true)

theorem identity1794 : scanCanonicalize (H12AffineFastState.compose env1794 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound1794 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1795 : List Nat := [2,4,8,16,32,64,120,4,122,5,81,81,121,96,112,3,97,112,4,112,113,32,64,115,9,16,81,97,80,112,5,1,5,1,97,123]

theorem envBound1795 : H12AffineFastState.Bounded env1795 := by
  intro p hp
  have h : env1795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1794_1795 : H12AffineEnvironment.transform 8 122 env1794 = env1795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env1794 == env1795) = true)

theorem identity1795 : scanCanonicalize (H12AffineFastState.compose env1795 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound1795 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1796 : List Nat := [2,4,8,16,32,49,9,4,11,5,32,32,8,17,1,3,16,1,4,1,0,32,49,2,9,16,32,16,33,1,5,1,5,1,16,10]

theorem envBound1796 : H12AffineFastState.Bounded env1796 := by
  intro p hp
  have h : env1796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1795_1796 : H12AffineEnvironment.transform 5 49 env1795 = env1796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env1795 == env1796) = true)

theorem identity1796 : scanCanonicalize (H12AffineFastState.compose env1796 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound1796 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1797 : List Nat := [2,4,8,16,0,17,9,4,11,5,0,0,8,17,1,3,16,1,4,1,0,0,17,2,9,16,0,16,1,1,5,1,5,1,16,10]

theorem envBound1797 : H12AffineFastState.Bounded env1797 := by
  intro p hp
  have h : env1797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1796_1797 : H12AffineEnvironment.transform 4 0 env1796 = env1797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env1796 == env1797) = true)

theorem identity1797 : scanCanonicalize (H12AffineFastState.compose env1797 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound1797 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1798 : List Nat := [2,4,8,6,0,7,9,4,11,5,0,0,8,7,1,3,6,1,4,1,0,0,7,2,9,6,0,6,1,1,5,1,5,1,6,10]

theorem envBound1798 : H12AffineFastState.Bounded env1798 := by
  intro p hp
  have h : env1798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1797_1798 : H12AffineEnvironment.transform 3 6 env1797 = env1798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env1797 == env1798) = true)

theorem identity1798 : scanCanonicalize (H12AffineFastState.compose env1798 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound1798 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1799 : List Nat := [2,4,1,6,0,7,0,4,2,5,0,0,1,7,1,3,6,1,4,1,0,0,7,2,0,6,0,6,1,1,5,1,5,1,6,3]

theorem envBound1799 : H12AffineFastState.Bounded env1799 := by
  intro p hp
  have h : env1799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1798_1799 : H12AffineEnvironment.transform 2 1 env1798 = env1799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env1798 == env1799) = true)

theorem identity1799 : scanCanonicalize (H12AffineFastState.compose env1799 (packedSelected [12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound1799 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env1800 : List Nat := [2,3,1,1,0,0,0,3,2,2,0,0,1,0,1,3,1,1,3,1,0,0,0,2,0,1,0,1,1,1,2,1,2,1,1,3]

theorem envBound1800 : H12AffineFastState.Bounded env1800 := by
  intro p hp
  have h : env1800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1799_1800 : H12AffineEnvironment.transform 1 3 env1799 = env1800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env1799 == env1800) = true)

def env1801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,16777216,8328,147473,409816,16385,151552,2081,16852469,4341976,257,1,131073,16925299]

theorem envBound1801 : H12AffineFastState.Bounded env1801 := by
  intro p hp
  have h : env1801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1778_1801 : H12AffineEnvironment.transform 34 131073 env1778 = env1801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1778 == env1801) = true)

theorem identity1801 : scanCanonicalize (H12AffineFastState.compose env1801 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4284780) := by decide +kernel

theorem selectedBound1801 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147521,4284780,8328,147473,409816,16385,151552,2081,4211865,4341976,257,1,131073,4399903]

theorem envBound1802 : H12AffineFastState.Bounded env1802 := by
  intro p hp
  have h : env1802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1801_1802 : H12AffineEnvironment.transform 23 4284780 env1801 = env1802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4284780 env1801 == env1802) = true)

theorem identity1802 : scanCanonicalize (H12AffineFastState.compose env1802 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound1802 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,293,147521,90185,8328,147473,409816,16385,151552,2081,17852,147965,257,1,131073,205370]

theorem envBound1803 : H12AffineFastState.Bounded env1803 := by
  intro p hp
  have h : env1803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1802_1803 : H12AffineEnvironment.transform 21 293 env1802 = env1803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env1802 == env1803) = true)

def env1804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16892,262144,1025,8693,2097152,293,445,90185,8328,493,262436,16385,4604,2081,17852,1,257,1,16893,91078]

theorem envBound1804 : H12AffineFastState.Bounded env1804 := by
  intro p hp
  have h : env1804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1803_1804 : H12AffineEnvironment.transform 16 16892 env1803 = env1804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env1803 == env1804) = true)

theorem identity1804 : scanCanonicalize (H12AffineFastState.compose env1804 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound1804 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8693,65536,325,262144,1025,8693,2097152,293,445,73968,8328,493,262436,184,4604,2081,1285,1,257,1,324,74623]

theorem envBound1805 : H12AffineFastState.Bounded env1805 := by
  intro p hp
  have h : env1805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1804_1805 : H12AffineEnvironment.transform 13 185 env1804 = env1805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env1804 == env1805) = true)

theorem identity1805 : scanCanonicalize (H12AffineFastState.compose env1805 (packedSelected [15,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 2265) := by decide +kernel

theorem selectedBound1805 : packedSelected [15,18,23,38] rootPS < 2^1333 := by decide +kernel

def env1806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8693,65536,325,2265,1025,8693,2097152,293,445,73968,8328,493,2557,184,4604,2081,1285,1,257,1,324,74623]

theorem envBound1806 : H12AffineFastState.Bounded env1806 := by
  intro p hp
  have h : env1806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1805_1806 : H12AffineEnvironment.transform 17 2265 env1805 = env1806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2265 env1805 == env1806) = true)

theorem identity1806 : scanCanonicalize (H12AffineFastState.compose env1806 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound1806 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env1807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8693,8314,325,2265,1025,8693,2097152,293,445,138,8328,493,2557,184,4604,2081,1285,1,257,1,324,773]

theorem envBound1807 : H12AffineFastState.Bounded env1807 := by
  intro p hp
  have h : env1807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1806_1807 : H12AffineEnvironment.transform 15 8314 env1806 = env1807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env1806 == env1807) = true)

theorem identity1807 : scanCanonicalize (H12AffineFastState.compose env1807 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(20+1) ^^^ 11690) := by decide +kernel

theorem selectedBound1807 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,185,8693,8314,325,2265,1025,8693,11690,293,445,138,8328,493,2557,184,4604,2081,1285,1,257,1,324,773]

theorem envBound1808 : H12AffineFastState.Bounded env1808 := by
  intro p hp
  have h : env1808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1807_1808 : H12AffineEnvironment.transform 20 11690 env1807 = env1808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11690 env1807 == env1808) = true)

theorem identity1808 : scanCanonicalize (H12AffineFastState.compose env1808 (packedSelected [0,4,7,9,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3369) := by decide +kernel

theorem selectedBound1808 : packedSelected [0,4,7,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env1809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3369,185,3292,3411,325,2265,1025,3292,131,293,445,138,3489,493,2557,184,4604,2081,1285,1,257,1,324,773]

theorem envBound1809 : H12AffineFastState.Bounded env1809 := by
  intro p hp
  have h : env1809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1808_1809 : H12AffineEnvironment.transform 12 3369 env1808 = env1809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3369 env1808 == env1809) = true)

theorem identity1809 : scanCanonicalize (H12AffineFastState.compose env1809 (packedSelected [0,1,2,5,6,7,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1809 : packedSelected [0,1,2,5,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env1810 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,3117,185,3292,3159,65,2265,1025,3292,131,33,185,138,3237,233,2297,184,4344,2081,1025,1,5,1,64,513]

theorem envBound1810 : H12AffineFastState.Bounded env1810 := by
  intro p hp
  have h : env1810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1809_1810 : H12AffineEnvironment.transform 7 4 env1809 = env1810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1809 == env1810) = true)

theorem identity1810 : scanCanonicalize (H12AffineFastState.compose env1810 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1708) := by decide +kernel

theorem selectedBound1810 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env1811 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1708,4096,641,185,624,763,65,1653,1025,624,131,33,185,138,521,233,1621,184,4344,1677,1025,1,5,1,64,513]

theorem envBound1811 : H12AffineFastState.Bounded env1811 := by
  intro p hp
  have h : env1811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1810_1811 : H12AffineEnvironment.transform 10 1708 env1810 = env1811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1708 env1810 == env1811) = true)

theorem identity1811 : scanCanonicalize (H12AffineFastState.compose env1811 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound1811 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1812 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1708,1676,641,185,624,763,65,1653,1025,624,131,33,185,138,521,233,1621,184,1652,1677,1025,1,5,1,64,513]

theorem envBound1812 : H12AffineFastState.Bounded env1812 := by
  intro p hp
  have h : env1812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1811_1812 : H12AffineEnvironment.transform 11 1676 env1811 = env1812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env1811 == env1812) = true)

theorem identity1812 : scanCanonicalize (H12AffineFastState.compose env1812 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound1812 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1813 : List Nat := [2,4,8,16,32,64,24,4,512,1024,1588,1556,537,33,624,611,65,1653,1025,624,27,33,33,18,521,113,1621,32,1652,1557,1025,1,5,1,64,513]

theorem envBound1813 : H12AffineFastState.Bounded env1813 := by
  intro p hp
  have h : env1813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1812_1813 : H12AffineEnvironment.transform 6 24 env1812 = env1813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env1812 == env1813) = true)

theorem identity1813 : scanCanonicalize (H12AffineFastState.compose env1813 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 623) := by decide +kernel

theorem selectedBound1813 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env1814 : List Nat := [2,4,8,16,32,64,24,4,512,623,91,123,537,33,624,611,65,26,622,624,27,33,33,18,521,113,58,32,27,122,622,1,5,1,64,513]

theorem envBound1814 : H12AffineFastState.Bounded env1814 := by
  intro p hp
  have h : env1814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1813_1814 : H12AffineEnvironment.transform 9 623 env1813 = env1814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 623 env1813 == env1814) = true)

theorem identity1814 : scanCanonicalize (H12AffineFastState.compose env1814 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound1814 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env1815 : List Nat := [2,4,8,16,32,59,24,4,512,532,32,0,537,33,523,536,58,26,533,523,27,33,33,18,521,10,58,32,27,1,533,1,5,1,59,513]

theorem envBound1815 : H12AffineFastState.Bounded env1815 := by
  intro p hp
  have h : env1815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1814_1815 : H12AffineEnvironment.transform 5 59 env1814 = env1815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env1814 == env1815) = true)

theorem identity1815 : scanCanonicalize (H12AffineFastState.compose env1815 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound1815 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1816 : List Nat := [2,4,8,16,32,59,24,4,32,52,32,0,57,33,43,56,58,26,53,43,27,33,33,18,41,10,58,32,27,1,53,1,5,1,59,33]

theorem envBound1816 : H12AffineFastState.Bounded env1816 := by
  intro p hp
  have h : env1816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1815_1816 : H12AffineEnvironment.transform 8 32 env1815 = env1816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env1815 == env1816) = true)

theorem identity1816 : scanCanonicalize (H12AffineFastState.compose env1816 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound1816 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1817 : List Nat := [2,4,8,16,21,14,24,4,21,1,21,0,12,20,30,13,15,26,0,30,27,20,20,18,28,10,15,21,27,1,0,1,5,1,14,20]

theorem envBound1817 : H12AffineFastState.Bounded env1817 := by
  intro p hp
  have h : env1817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1816_1817 : H12AffineEnvironment.transform 4 21 env1816 = env1817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env1816 == env1817) = true)

def env1818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16893,262144,1025,8693,2097152,293,444,90185,8328,492,262437,16385,4605,2081,17852,0,257,1,16892,91079]

theorem envBound1818 : H12AffineFastState.Bounded env1818 := by
  intro p hp
  have h : env1818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1803_1818 : H12AffineEnvironment.transform 16 16893 env1803 = env1818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env1803 == env1818) = true)

theorem identity1818 : scanCanonicalize (H12AffineFastState.compose env1818 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound1818 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8575,16893,262144,1025,8693,2097152,293,444,16694,8328,492,262437,16385,4605,2081,17852,0,257,1,16892,17080]

theorem envBound1819 : H12AffineFastState.Bounded env1819 := by
  intro p hp
  have h : env1819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1818_1819 : H12AffineEnvironment.transform 15 8575 env1818 = env1819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env1818 == env1819) = true)

def env1820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,268453921,92374096,281601389,525568,268451841,34359738368,25733062]

theorem envBound1820 : H12AffineFastState.Bounded env1820 := by
  intro p hp
  have h : env1820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans780_1820 : H12AffineEnvironment.transform 29 268453921 env780 = env1820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 268453921 env780 == env1820) = true)

def env1821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,268435456,268570625,268453921,17399808,281601389,525568,268451841,34359738368,25733062]

theorem envBound1821 : H12AffineFastState.Bounded env1821 := by
  intro p hp
  have h : env1821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1820_1821 : H12AffineEnvironment.transform 25 8914000 env1820 = env1821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env1820 == env1821) = true)

def env1822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2081,17399808,13149549,525568,1,34359738368,25733062]

theorem envBound1822 : H12AffineFastState.Bounded env1822 := by
  intro p hp
  have h : env1822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1821_1822 : H12AffineEnvironment.transform 27 16384 env1821 = env1822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env1821 == env1822) = true)

def env1823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2081,17375732,13108377,525568,1,34359738368,25691698]

theorem envBound1823 : H12AffineFastState.Bounded env1823 := by
  intro p hp
  have h : env1823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1822_1823 : H12AffineEnvironment.transform 14 8692 env1822 = env1823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env1822 == env1823) = true)

theorem identity1823 : scanCanonicalize (H12AffineFastState.compose env1823 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913970) := by decide +kernel

theorem selectedBound1823 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env1824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913970,8328,8914000,9176216,16384,151553,2081,8463814,13108377,525568,1,34359738368,512]

theorem envBound1824 : H12AffineFastState.Bounded env1824 := by
  intro p hp
  have h : env1824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1823_1824 : H12AffineEnvironment.transform 23 8913970 env1823 = env1824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913970 env1823 == env1824) = true)

theorem identity1824 : scanCanonicalize (H12AffineFastState.compose env1824 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525344) := by decide +kernel

theorem selectedBound1824 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env1825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,525344,8388608,8913970,8328,8914000,9176216,16384,151553,2081,8463814,8388793,525568,1,34359738368,512]

theorem envBound1825 : H12AffineFastState.Bounded env1825 := by
  intro p hp
  have h : env1825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1824_1825 : H12AffineEnvironment.transform 21 525344 env1824 = env1825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525344 env1824 == env1825) = true)

theorem identity1825 : scanCanonicalize (H12AffineFastState.compose env1825 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75134) := by decide +kernel

theorem selectedBound1825 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env1826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,8388608,8462668,8328,8462638,8724966,16384,151553,2081,8463814,8388793,73854,1,34359738368,512]

theorem envBound1826 : H12AffineFastState.Bounded env1826 := by
  intro p hp
  have h : env1826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1825_1826 : H12AffineEnvironment.transform 18 75134 env1825 = env1826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75134 env1825 == env1826) = true)

theorem identity1826 : scanCanonicalize (H12AffineFastState.compose env1826 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131332) := by decide +kernel

theorem selectedBound1826 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env1827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,8388608,8462668,8328,8462638,8724966,16384,151553,2081,8463814,8388793,73854,1,131332,512]

theorem envBound1827 : H12AffineFastState.Bounded env1827 := by
  intro p hp
  have h : env1827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1826_1827 : H12AffineEnvironment.transform 34 131332 env1826 = env1827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131332 env1826 == env1827) = true)

def env1828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,184,74228,8328,74134,336222,16384,151553,2081,75134,1,73854,1,131332,512]

theorem envBound1828 : H12AffineFastState.Bounded env1828 := by
  intro p hp
  have h : env1828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1827_1828 : H12AffineEnvironment.transform 22 184 env1827 = env1828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env1827 == env1828) = true)

theorem identity1828 : scanCanonicalize (H12AffineFastState.compose env1828 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223322) := by decide +kernel

theorem selectedBound1828 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env1829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,223322,75134,8692,2097152,74078,184,74228,8328,74134,149764,16384,151553,2081,75134,1,73854,1,131332,512]

theorem envBound1829 : H12AffineFastState.Bounded env1829 := by
  intro p hp
  have h : env1829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1828_1829 : H12AffineEnvironment.transform 17 223322 env1828 = env1829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223322 env1828 == env1829) = true)

def env1830 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74882,8200,2097152,73890,184,73736,8328,73834,149752,16384,151553,2081,74882,1,73854,1,131320,512]

theorem envBound1830 : H12AffineFastState.Bounded env1830 := by
  intro p hp
  have h : env1830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1829_1830 : H12AffineEnvironment.transform 7 252 env1829 = env1830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env1829 == env1830) = true)

theorem identity1830 : scanCanonicalize (H12AffineFastState.compose env1830 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151553) := by decide +kernel

theorem selectedBound1830 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1831 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74882,8200,151553,73890,184,73736,8328,73834,149752,16384,151553,2081,74882,1,73854,1,131320,512]

theorem envBound1831 : H12AffineFastState.Bounded env1831 := by
  intro p hp
  have h : env1831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1830_1831 : H12AffineEnvironment.transform 20 151553 env1830 = env1831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151553 env1830 == env1831) = true)

theorem identity1831 : scanCanonicalize (H12AffineFastState.compose env1831 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90235) := by decide +kernel

theorem selectedBound1831 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env1832 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,90235,2081,74882,8200,77946,73890,184,73736,8328,73834,75907,16384,77946,2081,74882,1,73854,1,90243,512]

theorem envBound1832 : H12AffineFastState.Bounded env1832 := by
  intro p hp
  have h : env1832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1831_1832 : H12AffineEnvironment.transform 16 90235 env1831 = env1832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90235 env1831 == env1832) = true)

theorem identity1832 : scanCanonicalize (H12AffineFastState.compose env1832 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound1832 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env1833 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,8323,16632,2081,1025,8200,4345,33,184,139,8328,233,2048,16384,4345,2081,1025,1,253,1,16384,512]

theorem envBound1833 : H12AffineFastState.Bounded env1833 := by
  intro p hp
  have h : env1833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1832_1833 : H12AffineEnvironment.transform 15 8323 env1832 = env1833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env1832 == env1833) = true)

theorem identity1833 : scanCanonicalize (H12AffineFastState.compose env1833 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound1833 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1834 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5237,8200,8323,5261,2081,1025,8200,4345,33,184,139,8328,233,2048,5237,4345,2081,1025,1,253,1,5237,512]

theorem envBound1834 : H12AffineFastState.Bounded env1834 := by
  intro p hp
  have h : env1834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1833_1834 : H12AffineEnvironment.transform 13 5237 env1833 = env1834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env1833 == env1834) = true)

theorem identity1834 : scanCanonicalize (H12AffineFastState.compose env1834 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound1834 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1835 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,8192,603,8200,8323,675,2081,1025,8200,1751,33,184,139,8328,233,2048,603,1751,2081,1025,1,253,1,603,512]

theorem envBound1835 : H12AffineFastState.Bounded env1835 := by
  intro p hp
  have h : env1835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1834_1835 : H12AffineEnvironment.transform 11 1582 env1834 = env1835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env1834 == env1835) = true)

theorem identity1835 : scanCanonicalize (H12AffineFastState.compose env1835 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound1835 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env1836 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1582,3822,603,3814,3693,675,2081,1025,3814,1751,33,184,139,3686,233,2048,603,1751,2081,1025,1,253,1,603,512]

theorem envBound1836 : H12AffineFastState.Bounded env1836 := by
  intro p hp
  have h : env1836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1835_1836 : H12AffineEnvironment.transform 12 3822 env1835 = env1836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env1835 == env1836) = true)

theorem identity1836 : scanCanonicalize (H12AffineFastState.compose env1836 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound1836 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1837 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,555,2795,603,2787,2664,675,2081,4,2787,722,33,184,139,2659,233,2048,603,722,2081,4,1,253,1,603,512]

theorem envBound1837 : H12AffineFastState.Bounded env1837 := by
  intro p hp
  have h : env1837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1836_1837 : H12AffineEnvironment.transform 9 5 env1836 = env1837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env1836 == env1837) = true)

theorem identity1837 : scanCanonicalize (H12AffineFastState.compose env1837 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound1837 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env1838 : List Nat := [2,4,8,16,32,64,121,5,512,5,2048,555,2578,603,2586,2664,602,2081,4,2586,555,33,65,114,2659,16,2048,603,555,2081,4,1,4,1,603,512]

theorem envBound1838 : H12AffineFastState.Bounded env1838 := by
  intro p hp
  have h : env1838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1837_1838 : H12AffineEnvironment.transform 6 121 env1837 = env1838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env1837 == env1838) = true)

theorem identity1838 : scanCanonicalize (H12AffineFastState.compose env1838 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound1838 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env1839 : List Nat := [2,4,8,16,32,64,121,5,512,5,609,555,115,603,123,9,602,576,4,123,555,33,65,114,2,16,609,603,555,576,4,1,4,1,603,512]

theorem envBound1839 : H12AffineFastState.Bounded env1839 := by
  intro p hp
  have h : env1839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1838_1839 : H12AffineEnvironment.transform 10 609 env1838 = env1839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env1838 == env1839) = true)

theorem identity1839 : scanCanonicalize (H12AffineFastState.compose env1839 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound1839 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env1840 : List Nat := [2,4,8,16,26,64,67,5,512,5,603,529,73,603,65,9,602,576,4,65,529,27,65,72,2,16,603,603,529,576,4,1,4,1,603,512]

theorem envBound1840 : H12AffineFastState.Bounded env1840 := by
  intro p hp
  have h : env1840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1839_1840 : H12AffineEnvironment.transform 4 26 env1839 = env1840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env1839 == env1840) = true)

def env1841 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74883,8201,2097152,73891,184,73737,8328,73835,149753,16384,151553,2081,74883,1,73854,1,131321,512]

theorem envBound1841 : H12AffineFastState.Bounded env1841 := by
  intro p hp
  have h : env1841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1829_1841 : H12AffineEnvironment.transform 7 253 env1829 = env1841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1829 == env1841) = true)

theorem identity1841 : scanCanonicalize (H12AffineFastState.compose env1841 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78035) := by decide +kernel

theorem selectedBound1841 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env1842 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74883,8201,78035,73891,184,73737,8328,73835,149753,16384,151553,2081,74883,1,73854,1,131321,512]

theorem envBound1842 : H12AffineFastState.Bounded env1842 := by
  intro p hp
  have h : env1842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1841_1842 : H12AffineEnvironment.transform 20 78035 env1841 = env1842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78035 env1841 == env1842) = true)

theorem identity1842 : scanCanonicalize (H12AffineFastState.compose env1842 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound1842 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env1843 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7695,8201,65536,131072,210517,74883,8201,78035,73891,184,73737,8328,73835,136950,7695,134670,2081,74883,1,73854,1,131321,512]

theorem envBound1843 : H12AffineFastState.Bounded env1843 := by
  intro p hp
  have h : env1843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1842_1843 : H12AffineEnvironment.transform 13 7695 env1842 = env1843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env1842 == env1843) = true)

def env1844 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,131072,205377,74883,8201,74951,73891,184,73737,8328,73835,131810,2587,134670,2081,74883,1,73854,1,131321,512]

theorem envBound1844 : H12AffineFastState.Bounded env1844 := by
  intro p hp
  have h : env1844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1843_1844 : H12AffineEnvironment.transform 11 1044 env1843 = env1844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env1843 == env1844) = true)

def env1845 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76384,2081,74883,8201,74951,73891,184,73737,8328,73835,75906,2587,74862,2081,74883,1,73854,1,76441,512]

theorem envBound1845 : H12AffineFastState.Bounded env1845 := by
  intro p hp
  have h : env1845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1844_1845 : H12AffineEnvironment.transform 16 76384 env1844 = env1845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1844 == env1845) = true)

theorem identity1845 : scanCanonicalize (H12AffineFastState.compose env1845 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound1845 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1846 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,225,2587,232,65536,68225,2081,66658,232,66598,65602,184,65768,105,65674,67683,2587,66703,2081,66658,1,65695,1,68216,512]

theorem envBound1846 : H12AffineFastState.Bounded env1846 := by
  intro p hp
  have h : env1846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1845_1846 : H12AffineEnvironment.transform 12 225 env1845 = env1846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env1845 == env1846) = true)

def env1847 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76385,2080,74883,8201,74951,73891,184,73737,8328,73835,75907,2587,74863,2081,74883,1,73854,1,76440,512]

theorem envBound1847 : H12AffineFastState.Bounded env1847 := by
  intro p hp
  have h : env1847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1844_1847 : H12AffineEnvironment.transform 16 76385 env1844 = env1847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1844 == env1847) = true)

theorem identity1847 : scanCanonicalize (H12AffineFastState.compose env1847 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound1847 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1848 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,3732,9461,2080,10775,8201,10835,11831,184,11933,8328,12031,9751,2587,11003,2081,10775,1,12010,1,9228,512]

theorem envBound1848 : H12AffineFastState.Bounded env1848 := by
  intro p hp
  have h : env1848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1847_1848 : H12AffineEnvironment.transform 15 3732 env1847 = env1848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env1847 == env1848) = true)

theorem identity1848 : scanCanonicalize (H12AffineFastState.compose env1848 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound1848 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1849 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2587,3615,3732,2787,2080,1025,3615,1093,33,184,139,3742,233,2049,2587,1261,2081,1025,1,252,1,2586,512]

theorem envBound1849 : H12AffineFastState.Bounded env1849 := by
  intro p hp
  have h : env1849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1848_1849 : H12AffineEnvironment.transform 12 3606 env1848 = env1849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env1848 == env1849) = true)

theorem identity1849 : scanCanonicalize (H12AffineFastState.compose env1849 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1849 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1850 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,64,2626,2587,2635,2752,2787,2080,85,2635,17,33,184,139,2762,233,2049,2587,185,2081,85,1,252,1,2586,512]

theorem envBound1850 : H12AffineFastState.Bounded env1850 := by
  intro p hp
  have h : env1850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1849_1850 : H12AffineEnvironment.transform 9 84 env1849 = env1850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1849 == env1850) = true)

theorem identity1850 : scanCanonicalize (H12AffineFastState.compose env1850 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1850 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1851 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,64,2626,2587,2635,2664,2635,2080,85,2635,17,33,16,35,2658,65,2049,2587,17,2081,85,1,84,1,2586,512]

theorem envBound1851 : H12AffineFastState.Bounded env1851 := by
  intro p hp
  have h : env1851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1850_1851 : H12AffineEnvironment.transform 6 40 env1850 = env1851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1850 == env1851) = true)

def env1852 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,64,2626,2587,2635,2648,2635,2064,85,2635,17,17,16,19,2642,65,2049,2587,17,2065,85,1,84,1,2586,512]

theorem envBound1852 : H12AffineFastState.Bounded env1852 := by
  intro p hp
  have h : env1852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1851_1852 : H12AffineEnvironment.transform 4 16 env1851 = env1852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1851 == env1852) = true)

def env1853 : List Nat := [2,4,8,16,16,64,24,85,512,84,0,64,578,539,587,600,587,16,85,587,17,17,16,19,594,65,1,539,17,17,85,1,84,1,538,512]

theorem envBound1853 : H12AffineFastState.Bounded env1853 := by
  intro p hp
  have h : env1853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1852_1853 : H12AffineEnvironment.transform 10 0 env1852 = env1853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1852 == env1853) = true)

theorem identity1853 : scanCanonicalize (H12AffineFastState.compose env1853 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1854 : List Nat := [2,4,4,16,16,64,20,85,512,84,0,64,578,535,583,596,583,16,85,583,17,17,16,19,594,65,1,535,17,17,85,1,84,1,534,512]

theorem envBound1854 : H12AffineFastState.Bounded env1854 := by
  intro p hp
  have h : env1854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1853_1854 : H12AffineEnvironment.transform 2 4 env1853 = env1854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1853 == env1854) = true)

def env1855 : List Nat := [2,4,4,16,16,0,20,21,512,20,0,0,514,535,519,532,519,16,21,519,17,17,16,19,530,1,1,535,17,17,21,1,20,1,534,512]

theorem envBound1855 : H12AffineFastState.Bounded env1855 := by
  intro p hp
  have h : env1855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1854_1855 : H12AffineEnvironment.transform 5 0 env1854 = env1855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1854 == env1855) = true)

theorem identity1855 : scanCanonicalize (H12AffineFastState.compose env1855 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound1855 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1856 : List Nat := [2,4,4,16,16,0,20,21,22,20,0,0,20,1,17,2,17,16,21,17,17,17,16,19,4,1,1,1,17,17,21,1,20,1,0,22]

theorem envBound1856 : H12AffineFastState.Bounded env1856 := by
  intro p hp
  have h : env1856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1855_1856 : H12AffineEnvironment.transform 8 22 env1855 = env1856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env1855 == env1856) = true)

def leafEnv1856 : List Nat := [2,4,4,16,16,0,20,21,22,20,0,0,20,1,17,2,17,16,21,17,17,17,16,19,21,4,1,1,1,1,17,17,21,1,20,1,4,19,0,22,1,16,0]

def active1856 : List Nat := [0,1,3]

def tree1856 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1856 : H12WitnessSearch.Good tree1856 := H12GlobalWitnessIndex.good

theorem leafIdentity1856 : H12AffineFastState.composeSystem env1856 rootObs = leafEnv1856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1856 rootObs == leafEnv1856) = true)

theorem terminalChecked1856 : H12PackedTerminal.terminalCheckFast leafEnv1856 active1856 tree1856 = true := by decide +kernel

def env1857 : List Nat := [2,4,4,16,16,1,20,20,512,21,0,1,515,535,518,533,518,16,20,518,17,17,16,19,531,0,1,535,17,17,20,1,21,1,534,512]

theorem envBound1857 : H12AffineFastState.Bounded env1857 := by
  intro p hp
  have h : env1857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1854_1857 : H12AffineEnvironment.transform 5 1 env1854 = env1857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1854 == env1857) = true)

def leafEnv1857 : List Nat := [2,4,4,16,16,1,20,20,512,21,0,1,515,535,518,533,518,16,20,518,17,17,16,19,20,531,1,0,1,535,17,17,20,1,21,1,4,516,534,512,1,16,0]

def active1857 : List Nat := [0,1,3,8]

def tree1857 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1857 : H12WitnessSearch.Good tree1857 := H12GlobalWitnessIndex.good

theorem leafIdentity1857 : H12AffineFastState.composeSystem env1857 rootObs = leafEnv1857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1857 rootObs == leafEnv1857) = true)

theorem terminalChecked1857 : H12PackedTerminal.terminalCheckFast leafEnv1857 active1857 tree1857 = true := by decide +kernel

def env1858 : List Nat := [2,4,8,16,16,64,24,85,512,84,1,64,579,538,586,601,586,17,85,586,17,17,16,19,595,65,0,538,17,16,85,1,84,1,539,512]

theorem envBound1858 : H12AffineFastState.Bounded env1858 := by
  intro p hp
  have h : env1858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1852_1858 : H12AffineEnvironment.transform 10 1 env1852 = env1858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1852 == env1858) = true)

theorem identity1858 : scanCanonicalize (H12AffineFastState.compose env1858 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1859 : List Nat := [2,4,8,13,13,64,5,72,512,73,1,64,579,519,586,580,586,12,72,586,12,12,13,14,590,65,0,519,12,13,72,1,73,1,518,512]

theorem envBound1859 : H12AffineFastState.Bounded env1859 := by
  intro p hp
  have h : env1859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1858_1859 : H12AffineEnvironment.transform 3 13 env1858 = env1859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1858 == env1859) = true)

def env1860 : List Nat := [2,4,8,13,13,0,5,8,512,9,1,0,515,519,522,516,522,12,8,522,12,12,13,14,526,1,0,519,12,13,8,1,9,1,518,512]

theorem envBound1860 : H12AffineFastState.Bounded env1860 := by
  intro p hp
  have h : env1860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1859_1860 : H12AffineEnvironment.transform 5 0 env1859 = env1860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1859 == env1860) = true)

def leafEnv1860 : List Nat := [2,4,8,13,13,0,5,8,512,9,1,0,515,519,522,516,522,12,8,522,12,12,13,14,8,526,1,1,0,519,12,13,8,1,9,1,4,520,518,512,1,13,0]

def active1860 : List Nat := [0,1,2,8]

def tree1860 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1860 : H12WitnessSearch.Good tree1860 := H12GlobalWitnessIndex.good

theorem leafIdentity1860 : H12AffineFastState.composeSystem env1860 rootObs = leafEnv1860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1860 rootObs == leafEnv1860) = true)

theorem terminalChecked1860 : H12PackedTerminal.terminalCheckFast leafEnv1860 active1860 tree1860 = true := by decide +kernel

def env1861 : List Nat := [2,4,8,13,13,1,5,9,512,8,1,1,514,519,523,517,523,12,9,523,12,12,13,14,527,0,0,519,12,13,9,1,8,1,518,512]

theorem envBound1861 : H12AffineFastState.Bounded env1861 := by
  intro p hp
  have h : env1861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1859_1861 : H12AffineEnvironment.transform 5 1 env1859 = env1861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1859 == env1861) = true)

theorem identity1861 : scanCanonicalize (H12AffineFastState.compose env1861 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound1861 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1862 : List Nat := [2,4,8,13,13,1,5,9,6,8,1,1,4,1,13,3,13,12,9,13,12,12,13,14,9,0,0,1,12,13,9,1,8,1,0,6]

theorem envBound1862 : H12AffineFastState.Bounded env1862 := by
  intro p hp
  have h : env1862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1861_1862 : H12AffineEnvironment.transform 8 6 env1861 = env1862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env1861 == env1862) = true)

def leafEnv1862 : List Nat := [2,4,8,13,13,1,5,9,6,8,1,1,4,1,13,3,13,12,9,13,12,12,13,14,9,9,1,0,0,1,12,13,9,1,8,1,4,15,0,6,1,13,0]

def active1862 : List Nat := [0,1,2]

def tree1862 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1862 : H12WitnessSearch.Good tree1862 := H12GlobalWitnessIndex.good

theorem leafIdentity1862 : H12AffineFastState.composeSystem env1862 rootObs = leafEnv1862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1862 rootObs == leafEnv1862) = true)

theorem terminalChecked1862 : H12PackedTerminal.terminalCheckFast leafEnv1862 active1862 tree1862 = true := by decide +kernel

def env1863 : List Nat := [2,4,8,16,17,64,25,85,512,84,2048,64,2626,2587,2635,2649,2635,2065,85,2635,17,16,16,18,2643,65,2049,2587,17,2064,85,1,84,1,2586,512]

theorem envBound1863 : H12AffineFastState.Bounded env1863 := by
  intro p hp
  have h : env1863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1851_1863 : H12AffineEnvironment.transform 4 17 env1851 = env1863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1851 == env1863) = true)

def env1864 : List Nat := [2,4,8,16,17,64,25,85,512,84,0,64,578,539,587,601,587,17,85,587,17,16,16,18,595,65,1,539,17,16,85,1,84,1,538,512]

theorem envBound1864 : H12AffineFastState.Bounded env1864 := by
  intro p hp
  have h : env1864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1863_1864 : H12AffineEnvironment.transform 10 0 env1863 = env1864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1863 == env1864) = true)

theorem identity1864 : scanCanonicalize (H12AffineFastState.compose env1864 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 70) := by decide +kernel

theorem selectedBound1864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1865 : List Nat := [2,4,8,16,17,64,25,85,70,84,0,64,4,93,13,31,13,17,85,13,17,16,16,18,21,65,1,93,17,16,85,1,84,1,92,70]

theorem envBound1865 : H12AffineFastState.Bounded env1865 := by
  intro p hp
  have h : env1865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1864_1865 : H12AffineEnvironment.transform 8 70 env1864 = env1865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 70 env1864 == env1865) = true)

def env1866 : List Nat := [2,4,8,16,17,0,25,21,6,20,0,0,4,29,13,31,13,17,21,13,17,16,16,18,21,1,1,29,17,16,21,1,20,1,28,6]

theorem envBound1866 : H12AffineFastState.Bounded env1866 := by
  intro p hp
  have h : env1866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1865_1866 : H12AffineEnvironment.transform 5 0 env1865 = env1866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1865 == env1866) = true)

theorem identity1866 : scanCanonicalize (H12AffineFastState.compose env1866 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1866 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1867 : List Nat := [2,4,8,13,12,0,4,8,6,9,0,0,4,0,13,2,13,12,8,13,12,13,13,15,8,1,1,0,12,13,8,1,9,1,1,6]

theorem envBound1867 : H12AffineFastState.Bounded env1867 := by
  intro p hp
  have h : env1867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1866_1867 : H12AffineEnvironment.transform 3 13 env1866 = env1867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1866 == env1867) = true)

def leafEnv1867 : List Nat := [2,4,8,13,12,0,4,8,6,9,0,0,4,0,13,2,13,12,8,13,12,13,13,15,8,8,1,1,1,0,12,13,8,1,9,1,4,15,1,6,1,13,0]

def active1867 : List Nat := [0,1,2]

def tree1867 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1867 : H12WitnessSearch.Good tree1867 := H12GlobalWitnessIndex.good

theorem leafIdentity1867 : H12AffineFastState.composeSystem env1867 rootObs = leafEnv1867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1867 rootObs == leafEnv1867) = true)

theorem terminalChecked1867 : H12PackedTerminal.terminalCheckFast leafEnv1867 active1867 tree1867 = true := by decide +kernel

def env1868 : List Nat := [2,4,8,16,17,1,25,20,7,21,0,1,4,28,13,31,13,17,20,13,17,16,16,18,21,0,1,28,17,16,20,1,21,1,29,7]

theorem envBound1868 : H12AffineFastState.Bounded env1868 := by
  intro p hp
  have h : env1868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1865_1868 : H12AffineEnvironment.transform 5 1 env1865 = env1868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1865 == env1868) = true)

def leafEnv1868 : List Nat := [2,4,8,16,17,1,25,20,7,21,0,1,4,28,13,31,13,17,20,13,17,16,16,18,20,21,1,0,1,28,17,16,20,1,21,1,4,15,29,7,1,16,0]

def active1868 : List Nat := [0,1,2,3]

def tree1868 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1868 : H12WitnessSearch.Good tree1868 := H12GlobalWitnessIndex.good

theorem leafIdentity1868 : H12AffineFastState.composeSystem env1868 rootObs = leafEnv1868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1868 rootObs == leafEnv1868) = true)

theorem terminalChecked1868 : H12PackedTerminal.terminalCheckFast leafEnv1868 active1868 tree1868 = true := by decide +kernel

def env1869 : List Nat := [2,4,8,16,17,64,25,85,512,84,1,64,579,538,586,600,586,16,85,586,17,16,16,18,594,65,0,538,17,17,85,1,84,1,539,512]

theorem envBound1869 : H12AffineFastState.Bounded env1869 := by
  intro p hp
  have h : env1869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1863_1869 : H12AffineEnvironment.transform 10 1 env1863 = env1869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1863 == env1869) = true)

theorem identity1869 : scanCanonicalize (H12AffineFastState.compose env1869 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 87) := by decide +kernel

theorem selectedBound1869 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1870 : List Nat := [2,4,8,16,17,64,25,85,87,84,1,64,20,77,29,15,29,16,85,29,17,16,16,18,5,65,0,77,17,17,85,1,84,1,76,87]

theorem envBound1870 : H12AffineFastState.Bounded env1870 := by
  intro p hp
  have h : env1870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1869_1870 : H12AffineEnvironment.transform 8 87 env1869 = env1870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 87 env1869 == env1870) = true)

def env1871 : List Nat := [2,4,8,16,17,0,25,21,23,20,1,0,20,13,29,15,29,16,21,29,17,16,16,18,5,1,0,13,17,17,21,1,20,1,12,23]

theorem envBound1871 : H12AffineFastState.Bounded env1871 := by
  intro p hp
  have h : env1871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1870_1871 : H12AffineEnvironment.transform 5 0 env1870 = env1871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1870 == env1871) = true)

def leafEnv1871 : List Nat := [2,4,8,16,17,0,25,21,23,20,1,0,20,13,29,15,29,16,21,29,17,16,16,18,21,5,1,1,0,13,17,17,21,1,20,1,4,31,12,23,1,16,0]

def active1871 : List Nat := [0,1,2,3]

def tree1871 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1871 : H12WitnessSearch.Good tree1871 := H12GlobalWitnessIndex.good

theorem leafIdentity1871 : H12AffineFastState.composeSystem env1871 rootObs = leafEnv1871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1871 rootObs == leafEnv1871) = true)

theorem terminalChecked1871 : H12PackedTerminal.terminalCheckFast leafEnv1871 active1871 tree1871 = true := by decide +kernel

def env1872 : List Nat := [2,4,8,16,17,1,25,20,22,21,1,1,20,12,29,15,29,16,20,29,17,16,16,18,5,0,0,12,17,17,20,1,21,1,13,22]

theorem envBound1872 : H12AffineFastState.Bounded env1872 := by
  intro p hp
  have h : env1872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1870_1872 : H12AffineEnvironment.transform 5 1 env1870 = env1872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1870 == env1872) = true)

theorem identity1872 : scanCanonicalize (H12AffineFastState.compose env1872 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1872 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1873 : List Nat := [2,4,4,16,17,1,21,20,22,21,1,1,20,0,17,3,17,16,20,17,17,16,16,18,5,0,0,0,17,17,20,1,21,1,1,22]

theorem envBound1873 : H12AffineFastState.Bounded env1873 := by
  intro p hp
  have h : env1873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1872_1873 : H12AffineEnvironment.transform 2 4 env1872 = env1873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1872 == env1873) = true)

def leafEnv1873 : List Nat := [2,4,4,16,17,1,21,20,22,21,1,1,20,0,17,3,17,16,20,17,17,16,16,18,20,5,1,0,0,0,17,17,20,1,21,1,4,19,1,22,1,16,0]

def active1873 : List Nat := [0,1,3]

def tree1873 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1873 : H12WitnessSearch.Good tree1873 := H12GlobalWitnessIndex.good

theorem leafIdentity1873 : H12AffineFastState.composeSystem env1873 rootObs = leafEnv1873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1873 rootObs == leafEnv1873) = true)

theorem terminalChecked1873 : H12PackedTerminal.terminalCheckFast leafEnv1873 active1873 tree1873 = true := by decide +kernel

def env1874 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,131072,205376,74883,8201,74950,73891,184,73737,8328,73835,131811,2586,134670,2081,74883,1,73854,1,131321,512]

theorem envBound1874 : H12AffineFastState.Bounded env1874 := by
  intro p hp
  have h : env1874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1843_1874 : H12AffineEnvironment.transform 11 1045 env1843 = env1874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env1843 == env1874) = true)

def env1875 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76384,2080,74883,8201,74950,73891,184,73737,8328,73835,75907,2586,74862,2081,74883,1,73854,1,76441,512]

theorem envBound1875 : H12AffineFastState.Bounded env1875 := by
  intro p hp
  have h : env1875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1874_1875 : H12AffineEnvironment.transform 16 76384 env1874 = env1875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env1874 == env1875) = true)

theorem identity1875 : scanCanonicalize (H12AffineFastState.compose env1875 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound1875 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1876 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3606,2586,3615,65536,66678,2080,68245,3615,68304,69301,184,69151,3742,69245,67221,2586,68216,2081,68245,1,69224,1,66703,512]

theorem envBound1876 : H12AffineFastState.Bounded env1876 := by
  intro p hp
  have h : env1876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1875_1876 : H12AffineEnvironment.transform 12 3606 env1875 = env1876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env1875 == env1876) = true)

theorem identity1876 : scanCanonicalize (H12AffineFastState.compose env1876 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound1876 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env1877 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3606,2586,3615,3732,2786,2080,1025,3615,1092,33,184,139,3742,233,2049,2586,1260,2081,1025,1,252,1,2587,512]

theorem envBound1877 : H12AffineFastState.Bounded env1877 := by
  intro p hp
  have h : env1877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1876_1877 : H12AffineEnvironment.transform 15 3732 env1876 = env1877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env1876 == env1877) = true)

theorem identity1877 : scanCanonicalize (H12AffineFastState.compose env1877 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound1877 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env1878 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,65,2626,2586,2635,2752,2786,2080,85,2635,16,33,184,139,2762,233,2049,2586,184,2081,85,1,252,1,2587,512]

theorem envBound1878 : H12AffineFastState.Bounded env1878 := by
  intro p hp
  have h : env1878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1877_1878 : H12AffineEnvironment.transform 9 84 env1877 = env1878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env1877 == env1878) = true)

theorem identity1878 : scanCanonicalize (H12AffineFastState.compose env1878 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound1878 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env1879 : List Nat := [2,4,8,16,32,64,40,85,512,84,2048,65,2626,2586,2635,2664,2634,2080,85,2635,16,33,16,35,2658,65,2049,2586,16,2081,85,1,84,1,2587,512]

theorem envBound1879 : H12AffineFastState.Bounded env1879 := by
  intro p hp
  have h : env1879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1878_1879 : H12AffineEnvironment.transform 6 40 env1878 = env1879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env1878 == env1879) = true)

def env1880 : List Nat := [2,4,8,16,16,64,24,85,512,84,2048,65,2626,2586,2635,2648,2634,2064,85,2635,16,17,16,19,2642,65,2049,2586,16,2065,85,1,84,1,2587,512]

theorem envBound1880 : H12AffineFastState.Bounded env1880 := by
  intro p hp
  have h : env1880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1879_1880 : H12AffineEnvironment.transform 4 16 env1879 = env1880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env1879 == env1880) = true)

def env1881 : List Nat := [2,4,8,16,16,64,24,85,512,84,0,65,578,538,587,600,586,16,85,587,16,17,16,19,594,65,1,538,16,17,85,1,84,1,539,512]

theorem envBound1881 : H12AffineFastState.Bounded env1881 := by
  intro p hp
  have h : env1881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1880_1881 : H12AffineEnvironment.transform 10 0 env1880 = env1881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1880 == env1881) = true)

theorem identity1881 : scanCanonicalize (H12AffineFastState.compose env1881 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1881 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1882 : List Nat := [2,4,8,16,16,64,24,85,7,84,0,65,69,29,76,95,77,16,85,76,16,17,16,19,85,65,1,29,16,17,85,1,84,1,28,7]

theorem envBound1882 : H12AffineFastState.Bounded env1882 := by
  intro p hp
  have h : env1882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1881_1882 : H12AffineEnvironment.transform 8 7 env1881 = env1882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1881 == env1882) = true)

def env1883 : List Nat := [2,4,8,16,16,0,24,21,7,20,0,1,5,29,12,31,13,16,21,12,16,17,16,19,21,1,1,29,16,17,21,1,20,1,28,7]

theorem envBound1883 : H12AffineFastState.Bounded env1883 := by
  intro p hp
  have h : env1883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1882_1883 : H12AffineEnvironment.transform 5 0 env1882 = env1883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1882 == env1883) = true)

def leafEnv1883 : List Nat := [2,4,8,16,16,0,24,21,7,20,0,1,5,29,12,31,13,16,21,12,16,17,16,19,21,21,1,1,1,29,16,17,21,1,20,1,4,14,28,7,1,17,0]

def active1883 : List Nat := [0,1,2,3]

def tree1883 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1883 : H12WitnessSearch.Good tree1883 := H12GlobalWitnessIndex.good

theorem leafIdentity1883 : H12AffineFastState.composeSystem env1883 rootObs = leafEnv1883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1883 rootObs == leafEnv1883) = true)

theorem terminalChecked1883 : H12PackedTerminal.terminalCheckFast leafEnv1883 active1883 tree1883 = true := by decide +kernel

def env1884 : List Nat := [2,4,8,16,16,1,24,20,7,21,0,0,4,29,13,30,12,16,20,13,16,17,16,19,20,0,1,29,16,17,20,1,21,1,28,7]

theorem envBound1884 : H12AffineFastState.Bounded env1884 := by
  intro p hp
  have h : env1884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1882_1884 : H12AffineEnvironment.transform 5 1 env1882 = env1884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1882 == env1884) = true)

theorem identity1884 : scanCanonicalize (H12AffineFastState.compose env1884 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound1884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1885 : List Nat := [2,4,8,13,13,1,5,9,7,8,0,0,4,0,13,3,12,13,9,13,13,12,13,14,9,0,1,0,13,12,9,1,8,1,1,7]

theorem envBound1885 : H12AffineFastState.Bounded env1885 := by
  intro p hp
  have h : env1885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1884_1885 : H12AffineEnvironment.transform 3 13 env1884 = env1885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1884 == env1885) = true)

def leafEnv1885 : List Nat := [2,4,8,13,13,1,5,9,7,8,0,0,4,0,13,3,12,13,9,13,13,12,13,14,9,9,1,0,1,0,13,12,9,1,8,1,4,15,1,7,1,12,0]

def active1885 : List Nat := [0,1,2]

def tree1885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1885 : H12WitnessSearch.Good tree1885 := H12GlobalWitnessIndex.good

theorem leafIdentity1885 : H12AffineFastState.composeSystem env1885 rootObs = leafEnv1885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1885 rootObs == leafEnv1885) = true)

theorem terminalChecked1885 : H12PackedTerminal.terminalCheckFast leafEnv1885 active1885 tree1885 = true := by decide +kernel

def env1886 : List Nat := [2,4,8,16,16,64,24,85,512,84,1,65,579,539,586,601,587,17,85,586,16,17,16,19,595,65,0,539,16,16,85,1,84,1,538,512]

theorem envBound1886 : H12AffineFastState.Bounded env1886 := by
  intro p hp
  have h : env1886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1880_1886 : H12AffineEnvironment.transform 10 1 env1880 = env1886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1880 == env1886) = true)

theorem identity1886 : scanCanonicalize (H12AffineFastState.compose env1886 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1887 : List Nat := [2,4,8,16,16,64,24,85,23,84,1,65,84,12,93,78,92,17,85,93,16,17,16,19,68,65,0,12,16,16,85,1,84,1,13,23]

theorem envBound1887 : H12AffineFastState.Bounded env1887 := by
  intro p hp
  have h : env1887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1886_1887 : H12AffineEnvironment.transform 8 23 env1886 = env1887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1886 == env1887) = true)

def env1888 : List Nat := [2,4,8,16,16,0,24,21,23,20,1,1,20,12,29,14,28,17,21,29,16,17,16,19,4,1,0,12,16,16,21,1,20,1,13,23]

theorem envBound1888 : H12AffineFastState.Bounded env1888 := by
  intro p hp
  have h : env1888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1887_1888 : H12AffineEnvironment.transform 5 0 env1887 = env1888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env1887 == env1888) = true)

theorem identity1888 : scanCanonicalize (H12AffineFastState.compose env1888 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound1888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1889 : List Nat := [2,4,4,16,16,0,20,21,23,20,1,1,20,0,17,2,16,17,21,17,16,17,16,19,4,1,0,0,16,16,21,1,20,1,1,23]

theorem envBound1889 : H12AffineFastState.Bounded env1889 := by
  intro p hp
  have h : env1889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1888_1889 : H12AffineEnvironment.transform 2 4 env1888 = env1889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1888 == env1889) = true)

def leafEnv1889 : List Nat := [2,4,4,16,16,0,20,21,23,20,1,1,20,0,17,2,16,17,21,17,16,17,16,19,21,4,1,1,0,0,16,16,21,1,20,1,4,19,1,23,1,17,0]

def active1889 : List Nat := [0,1,3]

def tree1889 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1889 : H12WitnessSearch.Good tree1889 := H12GlobalWitnessIndex.good

theorem leafIdentity1889 : H12AffineFastState.composeSystem env1889 rootObs = leafEnv1889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1889 rootObs == leafEnv1889) = true)

theorem terminalChecked1889 : H12PackedTerminal.terminalCheckFast leafEnv1889 active1889 tree1889 = true := by decide +kernel

def env1890 : List Nat := [2,4,8,16,16,1,24,20,23,21,1,0,21,12,28,15,29,17,20,28,16,17,16,19,5,0,0,12,16,16,20,1,21,1,13,23]

theorem envBound1890 : H12AffineFastState.Bounded env1890 := by
  intro p hp
  have h : env1890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1887_1890 : H12AffineEnvironment.transform 5 1 env1887 = env1890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env1887 == env1890) = true)

def leafEnv1890 : List Nat := [2,4,8,16,16,1,24,20,23,21,1,0,21,12,28,15,29,17,20,28,16,17,16,19,20,5,1,0,0,12,16,16,20,1,21,1,4,30,13,23,1,17,0]

def active1890 : List Nat := [0,1,2,3]

def tree1890 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1890 : H12WitnessSearch.Good tree1890 := H12GlobalWitnessIndex.good

theorem leafIdentity1890 : H12AffineFastState.composeSystem env1890 rootObs = leafEnv1890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1890 rootObs == leafEnv1890) = true)

theorem terminalChecked1890 : H12PackedTerminal.terminalCheckFast leafEnv1890 active1890 tree1890 = true := by decide +kernel

def env1891 : List Nat := [2,4,8,16,17,64,25,85,512,84,2048,65,2626,2586,2635,2649,2634,2065,85,2635,16,16,16,18,2643,65,2049,2586,16,2064,85,1,84,1,2587,512]

theorem envBound1891 : H12AffineFastState.Bounded env1891 := by
  intro p hp
  have h : env1891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1879_1891 : H12AffineEnvironment.transform 4 17 env1879 = env1891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env1879 == env1891) = true)

def env1892 : List Nat := [2,4,8,16,17,64,25,85,512,84,0,65,578,538,587,601,586,17,85,587,16,16,16,18,595,65,1,538,16,16,85,1,84,1,539,512]

theorem envBound1892 : H12AffineFastState.Bounded env1892 := by
  intro p hp
  have h : env1892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1891_1892 : H12AffineEnvironment.transform 10 0 env1891 = env1892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env1891 == env1892) = true)

theorem identity1892 : scanCanonicalize (H12AffineFastState.compose env1892 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound1892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1893 : List Nat := [2,4,8,16,17,13,25,24,512,25,0,12,527,538,518,532,519,17,24,518,16,16,16,18,542,12,1,538,16,16,24,1,25,1,539,512]

theorem envBound1893 : H12AffineFastState.Bounded env1893 := by
  intro p hp
  have h : env1893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1892_1893 : H12AffineEnvironment.transform 5 13 env1892 = env1893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env1892 == env1893) = true)

def env1894 : List Nat := [2,4,4,16,17,1,21,20,512,21,0,0,515,534,518,532,519,17,20,518,16,16,16,18,530,0,1,534,16,16,20,1,21,1,535,512]

theorem envBound1894 : H12AffineFastState.Bounded env1894 := by
  intro p hp
  have h : env1894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1893_1894 : H12AffineEnvironment.transform 2 4 env1893 = env1894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env1893 == env1894) = true)

theorem identity1894 : scanCanonicalize (H12AffineFastState.compose env1894 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound1894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1895 : List Nat := [2,4,4,16,17,1,21,20,23,21,0,0,20,1,17,3,16,17,20,17,16,16,16,18,5,0,1,1,16,16,20,1,21,1,0,23]

theorem envBound1895 : H12AffineFastState.Bounded env1895 := by
  intro p hp
  have h : env1895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1894_1895 : H12AffineEnvironment.transform 8 23 env1894 = env1895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env1894 == env1895) = true)

def leafEnv1895 : List Nat := [2,4,4,16,17,1,21,20,23,21,0,0,20,1,17,3,16,17,20,17,16,16,16,18,20,5,1,0,1,1,16,16,20,1,21,1,4,19,0,23,1,17,0]

def active1895 : List Nat := [0,1,3]

def tree1895 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1895 : H12WitnessSearch.Good tree1895 := H12GlobalWitnessIndex.good

theorem leafIdentity1895 : H12AffineFastState.composeSystem env1895 rootObs = leafEnv1895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1895 rootObs == leafEnv1895) = true)

theorem terminalChecked1895 : H12PackedTerminal.terminalCheckFast leafEnv1895 active1895 tree1895 = true := by decide +kernel

def env1896 : List Nat := [2,4,5,16,17,0,20,21,512,20,0,1,514,535,518,532,519,17,21,518,16,16,16,18,531,1,1,535,16,16,21,1,20,1,534,512]

theorem envBound1896 : H12AffineFastState.Bounded env1896 := by
  intro p hp
  have h : env1896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1893_1896 : H12AffineEnvironment.transform 2 5 env1893 = env1896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env1893 == env1896) = true)

def leafEnv1896 : List Nat := [2,4,5,16,17,0,20,21,512,20,0,1,514,535,518,532,519,17,21,518,16,16,16,18,21,531,1,1,1,535,16,16,21,1,20,1,4,516,534,512,1,17,0]

def active1896 : List Nat := [0,1,3,8]

def tree1896 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1896 : H12WitnessSearch.Good tree1896 := H12GlobalWitnessIndex.good

theorem leafIdentity1896 : H12AffineFastState.composeSystem env1896 rootObs = leafEnv1896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1896 rootObs == leafEnv1896) = true)

theorem terminalChecked1896 : H12PackedTerminal.terminalCheckFast leafEnv1896 active1896 tree1896 = true := by decide +kernel

def env1897 : List Nat := [2,4,8,16,17,64,25,85,512,84,1,65,579,539,586,600,587,16,85,586,16,16,16,18,594,65,0,539,16,17,85,1,84,1,538,512]

theorem envBound1897 : H12AffineFastState.Bounded env1897 := by
  intro p hp
  have h : env1897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1891_1897 : H12AffineEnvironment.transform 10 1 env1891 = env1897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env1891 == env1897) = true)

theorem identity1897 : scanCanonicalize (H12AffineFastState.compose env1897 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound1897 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1898 : List Nat := [2,4,8,16,17,29,25,8,512,9,1,28,542,539,535,517,534,16,8,535,16,16,16,18,527,28,0,539,16,17,8,1,9,1,538,512]

theorem envBound1898 : H12AffineFastState.Bounded env1898 := by
  intro p hp
  have h : env1898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1897_1898 : H12AffineEnvironment.transform 5 29 env1897 = env1898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env1897 == env1898) = true)

def env1899 : List Nat := [2,4,8,12,13,1,5,8,512,9,1,0,514,519,523,517,522,12,8,523,12,12,12,14,527,0,0,519,12,13,8,1,9,1,518,512]

theorem envBound1899 : H12AffineFastState.Bounded env1899 := by
  intro p hp
  have h : env1899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1898_1899 : H12AffineEnvironment.transform 3 12 env1898 = env1899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env1898 == env1899) = true)

def leafEnv1899 : List Nat := [2,4,8,12,13,1,5,8,512,9,1,0,514,519,523,517,522,12,8,523,12,12,12,14,8,527,1,0,0,519,12,13,8,1,9,1,4,521,518,512,1,13,0]

def active1899 : List Nat := [0,1,2,8]

def tree1899 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1899 : H12WitnessSearch.Good tree1899 := H12GlobalWitnessIndex.good

theorem leafIdentity1899 : H12AffineFastState.composeSystem env1899 rootObs = leafEnv1899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1899 rootObs == leafEnv1899) = true)

theorem terminalChecked1899 : H12PackedTerminal.terminalCheckFast leafEnv1899 active1899 tree1899 = true := by decide +kernel

def env1900 : List Nat := [2,4,8,13,12,0,4,8,512,9,1,1,515,518,522,517,523,13,8,522,13,13,13,15,527,1,0,518,13,12,8,1,9,1,519,512]

theorem envBound1900 : H12AffineFastState.Bounded env1900 := by
  intro p hp
  have h : env1900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1898_1900 : H12AffineEnvironment.transform 3 13 env1898 = env1900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env1898 == env1900) = true)

theorem identity1900 : scanCanonicalize (H12AffineFastState.compose env1900 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound1900 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1901 : List Nat := [2,4,8,13,12,0,4,8,7,9,1,1,4,1,13,2,12,13,8,13,13,13,13,15,8,1,0,1,13,12,8,1,9,1,0,7]

theorem envBound1901 : H12AffineFastState.Bounded env1901 := by
  intro p hp
  have h : env1901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1900_1901 : H12AffineEnvironment.transform 8 7 env1900 = env1901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env1900 == env1901) = true)

def leafEnv1901 : List Nat := [2,4,8,13,12,0,4,8,7,9,1,1,4,1,13,2,12,13,8,13,13,13,13,15,8,8,1,1,0,1,13,12,8,1,9,1,4,15,0,7,1,12,0]

def active1901 : List Nat := [0,1,2]

def tree1901 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood1901 : H12WitnessSearch.Good tree1901 := H12GlobalWitnessIndex.good

theorem leafIdentity1901 : H12AffineFastState.composeSystem env1901 rootObs = leafEnv1901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env1901 rootObs == leafEnv1901) = true)

theorem terminalChecked1901 : H12PackedTerminal.terminalCheckFast leafEnv1901 active1901 tree1901 = true := by decide +kernel

def env1902 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76385,2081,74883,8201,74950,73891,184,73737,8328,73835,75906,2586,74863,2081,74883,1,73854,1,76440,512]

theorem envBound1902 : H12AffineFastState.Bounded env1902 := by
  intro p hp
  have h : env1902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1874_1902 : H12AffineEnvironment.transform 16 76385 env1874 = env1902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env1874 == env1902) = true)

theorem identity1902 : scanCanonicalize (H12AffineFastState.compose env1902 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound1902 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env1903 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,99,10754,2081,9440,8201,9381,8384,184,8298,8328,8200,10465,2586,9228,2081,9440,1,8221,1,11003,512]

theorem envBound1903 : H12AffineFastState.Bounded env1903 := by
  intro p hp
  have h : env1903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1902_1903 : H12AffineEnvironment.transform 15 99 env1902 = env1903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env1902 == env1903) = true)

def env1904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,185,74229,8328,74135,336223,16384,151553,2081,75135,0,73854,1,131332,512]

theorem envBound1904 : H12AffineFastState.Bounded env1904 := by
  intro p hp
  have h : env1904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1827_1904 : H12AffineEnvironment.transform 22 185 env1827 = env1904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env1827 == env1904) = true)

theorem identity1904 : scanCanonicalize (H12AffineFastState.compose env1904 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound1904 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env1905 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,74883,8201,2097152,73891,185,73736,8328,73834,336034,16384,151553,2081,74882,0,73854,1,131321,512]

theorem envBound1905 : H12AffineFastState.Bounded env1905 := by
  intro p hp
  have h : env1905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1904_1905 : H12AffineEnvironment.transform 7 253 env1904 = env1905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env1904 == env1905) = true)

def env1906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2081,17375733,13108376,525568,1,34359738368,25691699]

theorem envBound1906 : H12AffineFastState.Bounded env1906 := by
  intro p hp
  have h : env1906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1822_1906 : H12AffineEnvironment.transform 14 8693 env1822 = env1906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env1822 == env1906) = true)

def env1907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147520,16777216,8328,672784,935128,16384,151553,2081,17375733,4867288,525568,1,34359738368,17450611]

theorem envBound1907 : H12AffineFastState.Bounded env1907 := by
  intro p hp
  have h : env1907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1906_1907 : H12AffineEnvironment.transform 22 147520 env1906 = env1907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env1906 == env1907) = true)

def env1908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16852469,4341976,256,1,34359738368,16925299]

theorem envBound1908 : H12AffineFastState.Bounded env1908 := by
  intro p hp
  have h : env1908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1907_1908 : H12AffineEnvironment.transform 18 1024 env1907 = env1908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env1907 == env1908) = true)

def env1909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16852469,4341976,256,1,131072,16925299]

theorem envBound1909 : H12AffineFastState.Bounded env1909 := by
  intro p hp
  have h : env1909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1908_1909 : H12AffineEnvironment.transform 34 131072 env1908 = env1909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1908 == env1909) = true)

theorem identity1909 : scanCanonicalize (H12AffineFastState.compose env1909 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound1909 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16794934,4341976,256,1,131072,16925299]

theorem envBound1910 : H12AffineFastState.Bounded env1910 := by
  intro p hp
  have h : env1910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1909_1910 : H12AffineEnvironment.transform 15 24771 env1909 = env1910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env1909 == env1910) = true)

theorem identity1910 : scanCanonicalize (H12AffineFastState.compose env1910 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 292) := by decide +kernel

theorem selectedBound1910 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,131072,262144,1024,8693,2097152,292,147520,16777216,8328,147472,409816,16384,151553,2081,16794934,147964,256,1,131072,16925299]

theorem envBound1911 : H12AffineFastState.Bounded env1911 := by
  intro p hp
  have h : env1911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1910_1911 : H12AffineEnvironment.transform 21 292 env1910 = env1911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292 env1910 == env1911) = true)

def env1912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,16892,262144,1024,8693,2097152,292,444,16777216,8328,492,262436,16384,4605,2081,16794934,0,256,1,16892,16778127]

theorem envBound1912 : H12AffineFastState.Bounded env1912 := by
  intro p hp
  have h : env1912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1911_1912 : H12AffineEnvironment.transform 16 16892 env1911 = env1912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env1911 == env1912) = true)

theorem identity1912 : scanCanonicalize (H12AffineFastState.compose env1912 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound1912 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,444,8693,8575,64,262144,1024,8693,2097152,292,444,16777216,8328,492,262436,444,4605,2081,16778378,0,256,1,64,16778127]

theorem envBound1913 : H12AffineFastState.Bounded env1913 := by
  intro p hp
  have h : env1913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1912_1913 : H12AffineEnvironment.transform 13 444 env1912 = env1913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env1912 == env1913) = true)

def env1914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,16893,262144,1024,8693,2097152,292,445,16777216,8328,493,262437,16384,4604,2081,16794934,1,256,1,16893,16778126]

theorem envBound1914 : H12AffineFastState.Bounded env1914 := by
  intro p hp
  have h : env1914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1911_1914 : H12AffineEnvironment.transform 16 16893 env1911 = env1914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env1911 == env1914) = true)

theorem identity1914 : scanCanonicalize (H12AffineFastState.compose env1914 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 16434) := by decide +kernel

theorem selectedBound1914 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,16893,262144,1024,8693,2097152,292,445,16434,8328,493,262437,16384,4604,2081,1284,1,256,1,16893,17340]

theorem envBound1915 : H12AffineFastState.Bounded env1915 := by
  intro p hp
  have h : env1915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1914_1915 : H12AffineEnvironment.transform 23 16434 env1914 = env1915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 16434 env1914 == env1915) = true)

theorem identity1915 : scanCanonicalize (H12AffineFastState.compose env1915 (packedSelected [15,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound1915 : packedSelected [15,18,23,38] rootPS < 2^1333 := by decide +kernel

def env1916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,24771,16893,2264,1024,8693,2097152,292,445,16434,8328,493,2557,16384,4604,2081,1284,1,256,1,16893,17340]

theorem envBound1916 : H12AffineFastState.Bounded env1916 := by
  intro p hp
  have h : env1916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1915_1916 : H12AffineEnvironment.transform 17 2264 env1915 = env1916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env1915 == env1916) = true)

theorem identity1916 : scanCanonicalize (H12AffineFastState.compose env1916 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound1916 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env1917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,8315,325,2264,1024,8693,2097152,292,445,138,8328,493,2557,184,4604,2081,1284,1,256,1,325,772]

theorem envBound1917 : H12AffineFastState.Bounded env1917 := by
  intro p hp
  have h : env1917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1916_1917 : H12AffineEnvironment.transform 13 184 env1916 = env1917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env1916 == env1917) = true)

theorem identity1917 : scanCanonicalize (H12AffineFastState.compose env1917 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(20+1) ^^^ 11690) := by decide +kernel

theorem selectedBound1917 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env1918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,184,8693,8315,325,2264,1024,8693,11690,292,445,138,8328,493,2557,184,4604,2081,1284,1,256,1,325,772]

theorem envBound1918 : H12AffineFastState.Bounded env1918 := by
  intro p hp
  have h : env1918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1917_1918 : H12AffineEnvironment.transform 20 11690 env1917 = env1918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11690 env1917 == env1918) = true)

theorem identity1918 : scanCanonicalize (H12AffineFastState.compose env1918 (packedSelected [0,4,7,9,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3117) := by decide +kernel

theorem selectedBound1918 : packedSelected [0,4,7,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env1919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3117,184,3544,3158,325,2264,1024,3544,391,292,445,138,3237,493,2557,184,4604,2081,1284,1,256,1,325,772]

theorem envBound1919 : H12AffineFastState.Bounded env1919 := by
  intro p hp
  have h : env1919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1918_1919 : H12AffineEnvironment.transform 12 3117 env1918 = env1919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3117 env1918 == env1919) = true)

def env1920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16852469,4341976,256,1,131073,16925299]

theorem envBound1920 : H12AffineFastState.Bounded env1920 := by
  intro p hp
  have h : env1920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1908_1920 : H12AffineEnvironment.transform 34 131073 env1908 = env1920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env1908 == env1920) = true)

theorem identity1920 : scanCanonicalize (H12AffineFastState.compose env1920 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 94403) := by decide +kernel

theorem selectedBound1920 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,94403,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16852469,4341976,256,1,131073,16925299]

theorem envBound1921 : H12AffineFastState.Bounded env1921 := by
  intro p hp
  have h : env1921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1920_1921 : H12AffineEnvironment.transform 20 94403 env1920 = env1921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 94403 env1920 == env1921) = true)

theorem identity1921 : scanCanonicalize (H12AffineFastState.compose env1921 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound1921 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env1922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,20664,4194304,147520,16777216,8328,147472,409816,16384,151553,2081,16778638,4341976,256,1,131073,16925299]

theorem envBound1922 : H12AffineFastState.Bounded env1922 := by
  intro p hp
  have h : env1922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1921_1922 : H12AffineEnvironment.transform 15 8315 env1921 = env1922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env1921 == env1922) = true)

def env1923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,20664,147672,147520,16777216,8328,147472,409816,16384,151553,2081,16778638,0,256,1,131073,16925299]

theorem envBound1923 : H12AffineFastState.Bounded env1923 := by
  intro p hp
  have h : env1923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1922_1923 : H12AffineEnvironment.transform 21 147672 env1922 = env1923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147672 env1922 == env1923) = true)

theorem identity1923 : scanCanonicalize (H12AffineFastState.compose env1923 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound1923 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1924 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,16384,8433,8315,131072,262144,1024,8433,20664,147672,147520,16777216,8328,147472,409816,16384,151553,2081,16778378,0,4,1,131073,16925299]

theorem envBound1924 : H12AffineFastState.Bounded env1924 := by
  intro p hp
  have h : env1924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1923_1924 : H12AffineEnvironment.transform 7 4 env1923 = env1924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env1923 == env1924) = true)

def env1925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,20664,147673,147520,16777216,8328,147472,409816,16384,151553,2081,16778638,1,256,1,131073,16925299]

theorem envBound1925 : H12AffineFastState.Bounded env1925 := by
  intro p hp
  have h : env1925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1922_1925 : H12AffineEnvironment.transform 21 147673 env1922 = env1925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147673 env1922 == env1925) = true)

theorem identity1925 : scanCanonicalize (H12AffineFastState.compose env1925 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147831) := by decide +kernel

theorem selectedBound1925 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env1926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,262144,1024,8693,20664,147673,147520,147831,8328,147472,409816,16384,151553,2081,148729,1,256,1,131073,772]

theorem envBound1926 : H12AffineFastState.Bounded env1926 := by
  intro p hp
  have h : env1926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1925_1926 : H12AffineEnvironment.transform 23 147831 env1925 = env1926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147831 env1925 == env1926) = true)

theorem identity1926 : scanCanonicalize (H12AffineFastState.compose env1926 (packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 2525) := by decide +kernel

theorem selectedBound1926 : packedSelected [1,3,17,18,19,21,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env1927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,131072,2525,1024,8693,20664,147673,147520,147831,8328,147472,149765,16384,151553,2081,148729,1,256,1,131073,772]

theorem envBound1927 : H12AffineFastState.Bounded env1927 := by
  intro p hp
  have h : env1927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1926_1927 : H12AffineEnvironment.transform 17 2525 env1926 = env1927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2525 env1926 == env1927) = true)

theorem identity1927 : scanCanonicalize (H12AffineFastState.compose env1927 (packedSelected [1,5,8,17,18,21,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 16633) := by decide +kernel

theorem selectedBound1927 : packedSelected [1,5,8,17,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env1928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8315,16633,2525,1024,8693,20664,32,185,398,8328,233,2556,16384,4344,2081,1024,1,256,1,16632,772]

theorem envBound1928 : H12AffineFastState.Bounded env1928 := by
  intro p hp
  have h : env1928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1927_1928 : H12AffineEnvironment.transform 16 16633 env1927 = env1928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16633 env1927 == env1928) = true)

theorem identity1928 : scanCanonicalize (H12AffineFastState.compose env1928 (packedSelected [2,6,12,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound1928 : packedSelected [2,6,12,13,18] rootPS < 2^1333 := by decide +kernel

def env1929 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8315,16633,2264,1024,8432,20664,32,185,139,8328,233,2297,16384,4344,2081,1024,1,5,1,16632,513]

theorem envBound1929 : H12AffineFastState.Bounded env1929 := by
  intro p hp
  have h : env1929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1928_1929 : H12AffineEnvironment.transform 7 5 env1928 = env1929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env1928 == env1929) = true)

theorem identity1929 : scanCanonicalize (H12AffineFastState.compose env1929 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 3767) := by decide +kernel

theorem selectedBound1929 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env1930 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,3767,8432,8315,3662,2264,1024,8432,7695,32,185,139,8328,233,2297,3767,4344,2081,1024,1,5,1,3663,513]

theorem envBound1930 : H12AffineFastState.Bounded env1930 := by
  intro p hp
  have h : env1930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1929_1930 : H12AffineEnvironment.transform 13 3767 env1929 = env1930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3767 env1929 == env1930) = true)

theorem identity1930 : scanCanonicalize (H12AffineFastState.compose env1930 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1751) := by decide +kernel

theorem selectedBound1930 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env1931 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,4096,8192,96,8432,8315,153,1551,1024,8432,4312,32,185,139,8328,233,1582,96,4344,1782,1024,1,5,1,152,513]

theorem envBound1931 : H12AffineFastState.Bounded env1931 := by
  intro p hp
  have h : env1931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1930_1931 : H12AffineEnvironment.transform 10 1751 env1930 = env1931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1751 env1930 == env1931) = true)

theorem identity1931 : scanCanonicalize (H12AffineFastState.compose env1931 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound1931 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env1932 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,4096,1156,96,1140,1279,153,1551,1024,1140,4312,32,185,139,1036,233,1582,96,4344,1782,1024,1,5,1,152,513]

theorem envBound1932 : H12AffineFastState.Bounded env1932 := by
  intro p hp
  have h : env1932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1931_1932 : H12AffineEnvironment.transform 12 1156 env1931 = env1932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env1931 == env1932) = true)

theorem identity1932 : scanCanonicalize (H12AffineFastState.compose env1932 (packedSelected [0,1,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1750) := by decide +kernel

theorem selectedBound1932 : packedSelected [0,1,5,9] rootPS < 2^1333 := by decide +kernel

def env1933 : List Nat := [2,4,8,16,32,64,128,5,512,1024,1751,1750,1156,96,1140,1279,153,1551,1024,1140,1550,32,185,139,1036,233,1582,96,1582,1782,1024,1,5,1,152,513]

theorem envBound1933 : H12AffineFastState.Bounded env1933 := by
  intro p hp
  have h : env1933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1932_1933 : H12AffineEnvironment.transform 11 1750 env1932 = env1933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1750 env1932 == env1933) = true)

theorem identity1933 : scanCanonicalize (H12AffineFastState.compose env1933 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 647) := by decide +kernel

theorem selectedBound1933 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env1934 : List Nat := [2,4,8,16,32,64,128,5,512,647,80,81,515,96,755,632,153,136,647,755,137,32,185,139,651,233,169,96,169,113,647,1,5,1,152,513]

theorem envBound1934 : H12AffineFastState.Bounded env1934 := by
  intro p hp
  have h : env1934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1933_1934 : H12AffineEnvironment.transform 9 647 env1933 = env1934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 647 env1933 == env1934) = true)

theorem identity1934 : scanCanonicalize (H12AffineFastState.compose env1934 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound1934 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env1935 : List Nat := [2,4,8,16,32,64,120,5,512,639,80,81,515,96,523,632,97,112,639,523,113,32,65,115,627,17,81,96,81,113,639,1,5,1,96,513]

theorem envBound1935 : H12AffineFastState.Bounded env1935 := by
  intro p hp
  have h : env1935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1934_1935 : H12AffineEnvironment.transform 6 120 env1934 = env1935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env1934 == env1935) = true)

theorem identity1935 : scanCanonicalize (H12AffineFastState.compose env1935 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 106) := by decide +kernel

theorem selectedBound1935 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env1936 : List Nat := [2,4,8,16,32,64,120,5,106,21,80,81,105,96,97,18,97,112,21,97,113,32,65,115,25,17,81,96,81,113,21,1,5,1,96,107]

theorem envBound1936 : H12AffineFastState.Bounded env1936 := by
  intro p hp
  have h : env1936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1935_1936 : H12AffineEnvironment.transform 8 106 env1935 = env1936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 106 env1935 == env1936) = true)

theorem identity1936 : scanCanonicalize (H12AffineFastState.compose env1936 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound1936 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env1937 : List Nat := [2,4,8,0,32,64,104,5,106,5,64,65,105,96,97,2,97,96,5,97,97,32,65,99,9,1,65,96,65,97,5,1,5,1,96,107]

theorem envBound1937 : H12AffineFastState.Bounded env1937 := by
  intro p hp
  have h : env1937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1936_1937 : H12AffineEnvironment.transform 3 0 env1936 = env1937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env1936 == env1937) = true)

theorem identity1937 : scanCanonicalize (H12AffineFastState.compose env1937 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound1937 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env1938 : List Nat := [2,4,8,0,32,32,8,5,10,5,32,33,9,0,1,2,1,0,5,1,1,32,33,3,9,1,33,0,33,1,5,1,5,1,0,11]

theorem envBound1938 : H12AffineFastState.Bounded env1938 := by
  intro p hp
  have h : env1938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1937_1938 : H12AffineEnvironment.transform 5 32 env1937 = env1938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env1937 == env1938) = true)

theorem identity1938 : scanCanonicalize (H12AffineFastState.compose env1938 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound1938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env1939 : List Nat := [2,4,8,0,3,3,8,5,10,5,3,2,9,0,1,2,1,0,5,1,1,3,2,3,9,1,2,0,2,1,5,1,5,1,0,11]

theorem envBound1939 : H12AffineFastState.Bounded env1939 := by
  intro p hp
  have h : env1939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1938_1939 : H12AffineEnvironment.transform 4 3 env1938 = env1939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env1938 == env1939) = true)

theorem identity1939 : scanCanonicalize (H12AffineFastState.compose env1939 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound1939 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env1940 : List Nat := [0,4,8,0,1,1,8,5,8,5,1,0,9,0,1,0,1,0,5,1,1,1,0,1,9,1,0,0,0,1,5,1,5,1,0,9]

theorem envBound1940 : H12AffineFastState.Bounded env1940 := by
  intro p hp
  have h : env1940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1939_1940 : H12AffineEnvironment.transform 0 0 env1939 = env1940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env1939 == env1940) = true)

theorem identity1940 : scanCanonicalize (H12AffineFastState.compose env1940 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound1940 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env1941 : List Nat := [0,0,8,0,1,1,8,1,8,1,1,0,9,0,1,0,1,0,1,1,1,1,0,1,9,1,0,0,0,1,1,1,1,1,0,9]

theorem envBound1941 : H12AffineFastState.Bounded env1941 := by
  intro p hp
  have h : env1941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1940_1941 : H12AffineEnvironment.transform 1 0 env1940 = env1941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env1940 == env1941) = true)

def env1942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2081,16852468,4341977,257,1,34359738368,16925298]

theorem envBound1942 : H12AffineFastState.Bounded env1942 := by
  intro p hp
  have h : env1942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1907_1942 : H12AffineEnvironment.transform 18 1025 env1907 = env1942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env1907 == env1942) = true)

def env1943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2081,16852468,4341977,257,1,131072,16925298]

theorem envBound1943 : H12AffineFastState.Bounded env1943 := by
  intro p hp
  have h : env1943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1942_1943 : H12AffineEnvironment.transform 34 131072 env1942 = env1943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env1942 == env1943) = true)

theorem identity1943 : scanCanonicalize (H12AffineFastState.compose env1943 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 91522) := by decide +kernel

theorem selectedBound1943 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env1944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,91522,262144,1025,8693,2097152,4194304,75202,16777216,8328,75155,337243,16384,79235,2081,16852468,4269403,257,1,91522,16852976]

theorem envBound1944 : H12AffineFastState.Bounded env1944 := by
  intro p hp
  have h : env1944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1943_1944 : H12AffineEnvironment.transform 16 91522 env1943 = env1944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91522 env1943 == env1944) = true)

theorem identity1944 : scanCanonicalize (H12AffineFastState.compose env1944 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 4268501) := by decide +kernel

end H12CloudChart0