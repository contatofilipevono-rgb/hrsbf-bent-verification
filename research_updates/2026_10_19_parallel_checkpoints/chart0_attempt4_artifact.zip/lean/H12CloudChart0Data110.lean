import H12CloudChart0Data109

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound27878 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env27879 : List Nat := [2,4,8,16,17,64,9,4,0,69,65,16,88,81,0,3,16,0,69,1,80,65,64,3,89,64,64,17,65,0,20,16,4,16,0,81]

theorem envBound27879 : H12AffineFastState.Bounded env27879 := by
  intro p hp
  have h : env27879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27878_27879 : H12AffineEnvironment.transform 7 4 env27878 = env27879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27878 == env27879) = true)

theorem identity27879 : scanCanonicalize (H12AffineFastState.compose env27879 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound27879 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27880 : List Nat := [2,4,8,16,17,1,9,4,0,4,0,16,25,16,0,3,16,0,4,1,17,0,1,3,24,1,1,17,0,0,20,16,4,16,0,16]

theorem envBound27880 : H12AffineFastState.Bounded env27880 := by
  intro p hp
  have h : env27880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27879_27880 : H12AffineEnvironment.transform 5 1 env27879 = env27880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env27879 == env27880) = true)

theorem identity27880 : scanCanonicalize (H12AffineFastState.compose env27880 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27880 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27881 : List Nat := [2,4,8,0,1,1,9,4,0,4,0,0,9,0,0,3,0,0,4,1,1,0,1,3,8,1,1,1,0,0,4,0,4,0,0,0]

theorem envBound27881 : H12AffineFastState.Bounded env27881 := by
  intro p hp
  have h : env27881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27880_27881 : H12AffineEnvironment.transform 3 0 env27880 = env27881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27880 == env27881) = true)

theorem identity27881 : scanCanonicalize (H12AffineFastState.compose env27881 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27881 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27882 : List Nat := [2,0,8,0,1,1,9,0,0,0,0,0,9,0,0,3,0,0,0,1,1,0,1,3,8,1,1,1,0,0,0,0,0,0,0,0]

theorem envBound27882 : H12AffineFastState.Bounded env27882 := by
  intro p hp
  have h : env27882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27881_27882 : H12AffineEnvironment.transform 1 0 env27881 = env27882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27881 == env27882) = true)

theorem identity27882 : scanCanonicalize (H12AffineFastState.compose env27882 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27883 : List Nat := [1,0,8,0,1,1,9,0,0,0,0,0,9,0,0,0,0,0,0,1,1,0,1,0,8,1,1,1,0,0,0,0,0,0,0,0]

theorem envBound27883 : H12AffineFastState.Bounded env27883 := by
  intro p hp
  have h : env27883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27882_27883 : H12AffineEnvironment.transform 0 1 env27882 = env27883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27882 == env27883) = true)

theorem identity27883 : scanCanonicalize (H12AffineFastState.compose env27883 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound27883 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27884 : List Nat := [1,0,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,0,1,1,1,1,0,0,0,0,0,0,0,0]

theorem envBound27884 : H12AffineFastState.Bounded env27884 := by
  intro p hp
  have h : env27884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27883_27884 : H12AffineEnvironment.transform 2 1 env27883 = env27884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env27883 == env27884) = true)

def env27885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265169,23160256,257,27378861,27337993,25207750]

theorem envBound27885 : H12AffineFastState.Bounded env27885 := by
  intro p hp
  have h : env27885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27810_27885 : H12AffineEnvironment.transform 18 1025 env27810 = env27885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env27810 == env27885) = true)

theorem identity27885 : scanCanonicalize (H12AffineFastState.compose env27885 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8602077) := by decide +kernel

theorem selectedBound27885 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env27886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8602077,8328,64,4489692,10667345,10507601,8830976,181708,14820381,257,2262384,2254036,254491]

theorem envBound27886 : H12AffineFastState.Bounded env27886 := by
  intro p hp
  have h : env27886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27885_27886 : H12AffineEnvironment.transform 23 8602077 env27885 = env27886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8602077 env27885 == env27886) = true)

def env27887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,8388608,8602077,8328,64,4489692,8393985,8553729,8830976,181708,12645453,257,21792,46212,254491]

theorem envBound27887 : H12AffineFastState.Bounded env27887 := by
  intro p hp
  have h : env27887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27886_27887 : H12AffineEnvironment.transform 20 184400 env27886 = env27887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env27886 == env27887) = true)

def env27888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180224,98781,8328,64,4489692,185601,17665,262144,181708,4338765,257,21792,46212,254491]

theorem envBound27888 : H12AffineFastState.Bounded env27888 := by
  intro p hp
  have h : env27888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27887_27888 : H12AffineEnvironment.transform 22 180224 env27887 = env27888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env27887 == env27888) = true)

def env27889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180224,98781,8328,64,43356,185601,17665,262144,181708,400589,257,21792,46212,254491]

theorem envBound27889 : H12AffineFastState.Bounded env27889 := by
  intro p hp
  have h : env27889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27888_27889 : H12AffineEnvironment.transform 21 272512 env27888 = env27889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27888 == env27889) = true)

theorem identity27889 : scanCanonicalize (H12AffineFastState.compose env27889 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound27889 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140420,272512,144596,95497,8328,64,23944,139733,17665,262144,143640,400589,257,21792,16464,202447]

theorem envBound27890 : H12AffineFastState.Bounded env27890 := by
  intro p hp
  have h : env27890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27889_27890 : H12AffineEnvironment.transform 14 29908 env27889 = env27890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env27889 == env27890) = true)

theorem identity27890 : scanCanonicalize (H12AffineFastState.compose env27890 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound27890 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env27891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,262144,1025,29909,83102,272512,87246,95497,8328,64,23944,82383,17665,262144,86274,359639,257,21792,16464,30421]

theorem envBound27891 : H12AffineFastState.Bounded env27891 := by
  intro p hp
  have h : env27891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27890_27891 : H12AffineEnvironment.transform 16 90138 env27890 = env27891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env27890 == env27891) = true)

theorem identity27891 : scanCanonicalize (H12AffineFastState.compose env27891 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound27891 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,0,65536,70862,262144,1025,1,77898,272512,73754,66013,8328,64,10588,79131,12757,262144,75222,329731,257,8692,13444,513]

theorem envBound27892 : H12AffineFastState.Bounded env27892 := by
  intro p hp
  have h : env27892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27891_27892 : H12AffineEnvironment.transform 13 13524 env27891 = env27892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env27891 == env27892) = true)

def env27893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,65536,70726,262144,1025,1,77898,272392,73754,65877,8192,64,10588,79131,12637,262144,75102,329731,257,8572,13324,513]

theorem envBound27893 : H12AffineFastState.Bounded env27893 := by
  intro p hp
  have h : env27893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27892_27893 : H12AffineEnvironment.transform 6 8 env27892 = env27893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27892 == env27893) = true)

theorem identity27893 : scanCanonicalize (H12AffineFastState.compose env27893 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27893 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env27894 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,65536,70678,262144,1025,1,77850,272392,73754,65797,8192,16,10508,79131,12557,262144,75022,329731,257,8492,13324,513]

theorem envBound27894 : H12AffineFastState.Bounded env27894 := by
  intro p hp
  have h : env27894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27893_27894 : H12AffineEnvironment.transform 5 16 env27893 = env27894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27893 == env27894) = true)

theorem identity27894 : scanCanonicalize (H12AffineFastState.compose env27894 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound27894 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27895 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,65536,70678,76078,1025,1,77850,65830,73754,65797,8192,16,10508,79131,12557,76078,75022,8493,257,8492,13324,513]

theorem envBound27895 : H12AffineFastState.Bounded env27895 := by
  intro p hp
  have h : env27895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27894_27895 : H12AffineEnvironment.transform 17 76078 env27894 = env27895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env27894 == env27895) = true)

theorem identity27895 : scanCanonicalize (H12AffineFastState.compose env27895 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound27895 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27896 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,8203,13341,2341,1025,1,4113,8493,17,8462,8192,16,10508,5392,12557,2341,1285,8493,257,8492,13324,513]

theorem envBound27896 : H12AffineFastState.Bounded env27896 := by
  intro p hp
  have h : env27896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27895_27896 : H12AffineEnvironment.transform 15 8203 env27895 = env27896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env27895 == env27896) = true)

theorem identity27896 : scanCanonicalize (H12AffineFastState.compose env27896 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 781) := by decide +kernel

theorem selectedBound27896 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27897 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,781,5889,0,774,5904,2341,1025,1,4113,544,17,515,781,16,2561,5392,4608,2341,1285,544,257,545,5889,513]

theorem envBound27897 : H12AffineFastState.Bounded env27897 := by
  intro p hp
  have h : env27897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27896_27897 : H12AffineEnvironment.transform 12 781 env27896 = env27897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 781 env27896 == env27897) = true)

theorem identity27897 : scanCanonicalize (H12AffineFastState.compose env27897 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27897 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27898 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,4096,268,5376,0,263,5393,2341,1025,1,4113,33,17,2,268,16,2048,5392,4097,2341,1285,33,257,32,5376,0]

theorem envBound27898 : H12AffineFastState.Bounded env27898 := by
  intro p hp
  have h : env27898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27897_27898 : H12AffineEnvironment.transform 8 1 env27897 = env27898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27897 == env27898) = true)

theorem identity27898 : scanCanonicalize (H12AffineFastState.compose env27898 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound27898 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27899 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,292,268,1060,0,263,1077,2341,1025,1,309,33,17,2,268,16,2048,1076,293,2341,1285,33,257,32,1060,0]

theorem envBound27899 : H12AffineFastState.Bounded env27899 := by
  intro p hp
  have h : env27899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27898_27899 : H12AffineEnvironment.transform 11 292 env27898 = env27899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env27898 == env27899) = true)

def env27900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,65536,70727,262144,1025,1,77898,272393,73754,65876,8193,64,10588,79131,12636,262144,75103,329731,257,8573,13325,513]

theorem envBound27900 : H12AffineFastState.Bounded env27900 := by
  intro p hp
  have h : env27900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27892_27900 : H12AffineEnvironment.transform 6 9 env27892 = env27900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27892 == env27900) = true)

theorem identity27900 : scanCanonicalize (H12AffineFastState.compose env27900 (packedSelected [2,6,17] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound27900 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env27901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,65536,70727,67699,1025,1,77898,73850,73754,65876,8193,64,10588,79131,12636,67699,75103,112,257,8573,13325,513]

theorem envBound27901 : H12AffineFastState.Bounded env27901 := by
  intro p hp
  have h : env27901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27900_27901 : H12AffineEnvironment.transform 17 67699 env27900 = env27901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env27900 == env27901) = true)

theorem identity27901 : scanCanonicalize (H12AffineFastState.compose env27901 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27901 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env27902 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,65536,70678,67618,1025,1,77851,73771,73754,65797,8193,17,10509,79131,12557,67618,75022,33,257,8492,13325,513]

theorem envBound27902 : H12AffineFastState.Bounded env27902 := by
  intro p hp
  have h : env27902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27901_27902 : H12AffineEnvironment.transform 5 17 env27901 = env27902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27901 == env27902) = true)

theorem identity27902 : scanCanonicalize (H12AffineFastState.compose env27902 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound27902 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27903 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,262,5392,2340,1025,1,12573,8493,8476,3,8193,17,10509,13341,12557,2340,9224,33,257,8492,13325,513]

theorem envBound27903 : H12AffineFastState.Bounded env27903 := by
  intro p hp
  have h : env27903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27902_27903 : H12AffineEnvironment.transform 15 262 env27902 = env27903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env27902 == env27903) = true)

theorem identity27903 : scanCanonicalize (H12AffineFastState.compose env27903 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 4876) := by decide +kernel

theorem selectedBound27903 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27904 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,4876,1792,0,262,5392,2340,1025,1,529,4641,4624,3,4877,17,6657,1809,513,2340,5892,33,257,4640,1793,513]

theorem envBound27904 : H12AffineFastState.Bounded env27904 := by
  intro p hp
  have h : env27904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27903_27904 : H12AffineEnvironment.transform 12 4876 env27903 = env27904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4876 env27903 == env27904) = true)

theorem identity27904 : scanCanonicalize (H12AffineFastState.compose env27904 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound27904 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env27905 : List Nat := [2,4,8,16,32,17,9,256,512,1024,820,4096,4876,1792,0,262,5392,528,1025,1,529,4641,4624,3,4877,17,4405,1809,513,528,5892,33,257,4640,1793,513]

theorem envBound27905 : H12AffineFastState.Bounded env27905 := by
  intro p hp
  have h : env27905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27904_27905 : H12AffineEnvironment.transform 10 820 env27904 = env27905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env27904 == env27905) = true)

theorem identity27905 : scanCanonicalize (H12AffineFastState.compose env27905 (packedSelected [0,3,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound27905 : packedSelected [0,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env27906 : List Nat := [2,4,8,16,32,17,9,256,512,1024,820,529,285,1792,0,262,1793,528,1025,1,529,48,1,3,284,17,804,1809,513,528,1301,33,257,49,1793,513]

theorem envBound27906 : H12AffineFastState.Bounded env27906 := by
  intro p hp
  have h : env27906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27905_27906 : H12AffineEnvironment.transform 11 529 env27905 = env27906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env27905 == env27906) = true)

theorem identity27906 : scanCanonicalize (H12AffineFastState.compose env27906 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27906 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env27907 : List Nat := [2,4,8,1,32,0,9,256,512,1024,805,512,268,1792,0,262,1793,513,1025,1,512,33,1,3,269,0,804,1792,513,513,1284,33,257,32,1793,513]

theorem envBound27907 : H12AffineFastState.Bounded env27907 := by
  intro p hp
  have h : env27907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27906_27907 : H12AffineEnvironment.transform 3 1 env27906 = env27907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27906 == env27907) = true)

theorem identity27907 : scanCanonicalize (H12AffineFastState.compose env27907 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound27907 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27908 : List Nat := [2,4,8,1,32,0,9,256,512,288,805,512,268,544,0,262,545,513,289,1,512,33,1,3,269,0,804,544,513,513,36,33,257,32,545,513]

theorem envBound27908 : H12AffineFastState.Bounded env27908 := by
  intro p hp
  have h : env27908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27907_27908 : H12AffineEnvironment.transform 9 288 env27907 = env27908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env27907 == env27908) = true)

theorem identity27908 : scanCanonicalize (H12AffineFastState.compose env27908 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27908 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27909 : List Nat := [2,4,8,1,32,0,9,36,512,4,513,512,40,544,0,34,545,513,5,1,512,33,1,3,41,0,512,544,513,513,36,33,37,32,545,513]

theorem envBound27909 : H12AffineFastState.Bounded env27909 := by
  intro p hp
  have h : env27909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27908_27909 : H12AffineEnvironment.transform 7 36 env27908 = env27909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27908 == env27909) = true)

theorem identity27909 : scanCanonicalize (H12AffineFastState.compose env27909 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27909 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27910 : List Nat := [2,4,8,1,1,0,9,5,512,4,513,512,9,513,0,3,512,513,5,1,512,0,1,3,8,0,512,513,513,513,5,0,4,1,512,513]

theorem envBound27910 : H12AffineFastState.Bounded env27910 := by
  intro p hp
  have h : env27910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27909_27910 : H12AffineEnvironment.transform 4 1 env27909 = env27910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27909 == env27910) = true)

theorem identity27910 : scanCanonicalize (H12AffineFastState.compose env27910 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27910 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27911 : List Nat := [2,4,8,1,1,0,9,5,0,4,1,0,9,1,0,3,0,1,5,1,0,0,1,3,8,0,0,1,1,1,5,0,4,1,0,1]

theorem envBound27911 : H12AffineFastState.Bounded env27911 := by
  intro p hp
  have h : env27911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27910_27911 : H12AffineEnvironment.transform 8 0 env27910 = env27911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27910 == env27911) = true)

theorem identity27911 : scanCanonicalize (H12AffineFastState.compose env27911 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27911 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27912 : List Nat := [2,4,3,1,1,0,2,5,0,4,1,0,2,1,0,3,0,1,5,1,0,0,1,3,3,0,0,1,1,1,5,0,4,1,0,1]

theorem envBound27912 : H12AffineFastState.Bounded env27912 := by
  intro p hp
  have h : env27912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27911_27912 : H12AffineEnvironment.transform 2 3 env27911 = env27912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27911 == env27912) = true)

def env27913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180224,98781,8328,64,43357,185601,17665,262144,181708,400588,257,21792,46212,254491]

theorem envBound27913 : H12AffineFastState.Bounded env27913 := by
  intro p hp
  have h : env27913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27888_27913 : H12AffineEnvironment.transform 21 272513 env27888 = env27913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27888 == env27913) = true)

theorem identity27913 : scanCanonicalize (H12AffineFastState.compose env27913 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound27913 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,262144,1025,32769,58517,272513,62661,98781,8328,64,43357,57796,17665,262144,61705,272393,257,21792,46212,120542]

theorem envBound27914 : H12AffineFastState.Bounded env27914 := by
  intro p hp
  have h : env27914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27913_27914 : H12AffineEnvironment.transform 16 13509 env27913 = env27914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env27913 == env27914) = true)

def env27915 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,262144,1025,32769,58517,272513,62613,98701,8328,16,43277,57748,17665,262144,61705,272393,257,21792,46212,120462]

theorem envBound27915 : H12AffineFastState.Bounded env27915 := by
  intro p hp
  have h : env27915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27914_27915 : H12AffineEnvironment.transform 5 16 env27914 = env27915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27914 == env27915) = true)

theorem identity27915 : scanCanonicalize (H12AffineFastState.compose env27915 (packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound27915 : packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env27916 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8581,65536,13461,262144,1025,8580,17680,272513,21776,73736,8328,16,2184,16401,17665,262144,20620,272393,257,21792,5377,96011]

theorem envBound27916 : H12AffineFastState.Bounded env27916 := by
  intro p hp
  have h : env27916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27915_27916 : H12AffineEnvironment.transform 14 8581 env27915 = env27916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env27915 == env27916) = true)

theorem identity27916 : scanCanonicalize (H12AffineFastState.compose env27916 (packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27916 : packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env27917 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,65536,13341,262144,1025,8460,17680,272393,21776,73736,8192,16,2048,16401,17665,262144,20484,272393,257,21792,5377,96011]

theorem envBound27917 : H12AffineFastState.Bounded env27917 := by
  intro p hp
  have h : env27917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27916_27917 : H12AffineEnvironment.transform 6 8 env27916 = env27917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27916 == env27917) = true)

theorem identity27917 : scanCanonicalize (H12AffineFastState.compose env27917 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound27917 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env27918 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,65536,13341,89379,1025,8460,17680,95530,21776,73736,8192,16,2048,16401,17665,89379,20484,95530,257,21792,5377,96011]

theorem envBound27918 : H12AffineFastState.Bounded env27918 := by
  intro p hp
  have h : env27918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27917_27918 : H12AffineEnvironment.transform 17 89379 env27917 = env27918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env27917 == env27918) = true)

theorem identity27918 : scanCanonicalize (H12AffineFastState.compose env27918 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27918 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env27919 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,65536,13341,67619,1025,8460,4112,73770,16,73736,8192,16,2048,5393,4097,67619,1284,73770,257,32,5377,74251]

theorem envBound27919 : H12AffineFastState.Bounded env27919 := by
  intro p hp
  have h : env27919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27918_27919 : H12AffineEnvironment.transform 13 5376 env27918 = env27919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27918 == env27919) = true)

theorem identity27919 : scanCanonicalize (H12AffineFastState.compose env27919 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound27919 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27920 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8495,13341,10508,1025,8460,4112,261,16,295,8192,16,2048,5393,4097,10508,1284,261,257,32,5377,804]

theorem envBound27920 : H12AffineFastState.Bounded env27920 := by
  intro p hp
  have h : env27920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27919_27920 : H12AffineEnvironment.transform 15 8495 env27919 = env27920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env27919 == env27920) = true)

theorem identity27920 : scanCanonicalize (H12AffineFastState.compose env27920 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound27920 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env27921 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2357,8192,3125,8461,8495,11560,10508,1025,8460,2341,261,16,295,8192,16,2048,3108,2356,10508,1284,261,257,32,3124,804]

theorem envBound27921 : H12AffineFastState.Bounded env27921 := by
  intro p hp
  have h : env27921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27920_27921 : H12AffineEnvironment.transform 11 2357 env27920 = env27921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env27920 == env27921) = true)

theorem identity27921 : scanCanonicalize (H12AffineFastState.compose env27921 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27921 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env27922 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2357,269,3125,0,34,3109,2049,1025,1,2341,261,16,295,269,16,2048,3108,2356,2049,1284,261,257,32,3124,804]

theorem envBound27922 : H12AffineFastState.Bounded env27922 := by
  intro p hp
  have h : env27922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27921_27922 : H12AffineEnvironment.transform 12 269 env27921 = env27922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27921 == env27922) = true)

theorem identity27922 : scanCanonicalize (H12AffineFastState.compose env27922 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27922 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27923 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,2357,269,3125,0,34,3109,2049,1025,1,2341,261,16,295,269,16,2048,3108,2356,2049,1284,261,257,32,3124,293]

theorem envBound27923 : H12AffineFastState.Bounded env27923 := by
  intro p hp
  have h : env27923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27922_27923 : H12AffineEnvironment.transform 8 1 env27922 = env27923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27922 == env27923) = true)

theorem identity27923 : scanCanonicalize (H12AffineFastState.compose env27923 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound27923 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env27924 : List Nat := [2,4,8,16,32,16,8,256,1,1024,1061,1296,269,16,0,34,0,1060,1025,1,1280,261,16,295,269,16,1061,1,1297,1060,1284,261,257,32,17,293]

theorem envBound27924 : H12AffineFastState.Bounded env27924 := by
  intro p hp
  have h : env27924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27923_27924 : H12AffineEnvironment.transform 10 1061 env27923 = env27924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env27923 == env27924) = true)

theorem identity27924 : scanCanonicalize (H12AffineFastState.compose env27924 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27924 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27925 : List Nat := [2,4,8,16,32,16,8,256,1,272,309,0,269,16,0,34,0,308,273,1,16,261,16,295,269,16,309,1,1,308,20,261,257,32,17,293]

theorem envBound27925 : H12AffineFastState.Bounded env27925 := by
  intro p hp
  have h : env27925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27924_27925 : H12AffineEnvironment.transform 9 272 env27924 = env27925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27924 == env27925) = true)

theorem identity27925 : scanCanonicalize (H12AffineFastState.compose env27925 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27926 : List Nat := [2,4,8,0,32,0,8,256,1,256,293,0,269,0,0,34,0,292,257,1,0,261,0,295,269,0,293,1,1,292,4,261,257,32,1,293]

theorem envBound27926 : H12AffineFastState.Bounded env27926 := by
  intro p hp
  have h : env27926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27925_27926 : H12AffineEnvironment.transform 3 0 env27925 = env27926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27925 == env27926) = true)

theorem identity27926 : scanCanonicalize (H12AffineFastState.compose env27926 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound27926 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27927 : List Nat := [2,4,8,0,32,0,8,36,1,36,1,0,41,0,0,34,0,0,37,1,0,33,0,3,41,0,1,1,1,0,4,33,37,32,1,1]

theorem envBound27927 : H12AffineFastState.Bounded env27927 := by
  intro p hp
  have h : env27927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27926_27927 : H12AffineEnvironment.transform 7 36 env27926 = env27927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env27926 == env27927) = true)

theorem identity27927 : scanCanonicalize (H12AffineFastState.compose env27927 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound27927 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27928 : List Nat := [2,4,6,0,32,0,6,36,1,36,1,0,39,0,0,34,0,0,37,1,0,33,0,3,39,0,1,1,1,0,4,33,37,32,1,1]

theorem envBound27928 : H12AffineFastState.Bounded env27928 := by
  intro p hp
  have h : env27928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27927_27928 : H12AffineEnvironment.transform 2 6 env27927 = env27928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env27927 == env27928) = true)

theorem identity27928 : scanCanonicalize (H12AffineFastState.compose env27928 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27928 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27929 : List Nat := [2,4,6,0,0,0,6,4,1,4,1,0,7,0,0,2,0,0,5,1,0,1,0,3,7,0,1,1,1,0,4,1,5,0,1,1]

theorem envBound27929 : H12AffineFastState.Bounded env27929 := by
  intro p hp
  have h : env27929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27928_27929 : H12AffineEnvironment.transform 4 0 env27928 = env27929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27928 == env27929) = true)

def env27930 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,262144,1025,32769,58517,272513,62612,98700,8328,17,43276,57749,17665,262144,61705,272393,257,21792,46212,120463]

theorem envBound27930 : H12AffineFastState.Bounded env27930 := by
  intro p hp
  have h : env27930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27914_27930 : H12AffineEnvironment.transform 5 17 env27914 = env27930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27914 == env27930) = true)

theorem identity27930 : scanCanonicalize (H12AffineFastState.compose env27930 (packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound27930 : packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env27931 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,65536,13460,262144,1025,32769,45341,272513,41244,98700,8328,17,43276,46109,4233,262144,42113,272393,257,168,46212,99079]

theorem envBound27931 : H12AffineFastState.Bounded env27931 := by
  intro p hp
  have h : env27931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27930_27931 : H12AffineEnvironment.transform 13 5512 env27930 = env27931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env27930 == env27931) = true)

theorem identity27931 : scanCanonicalize (H12AffineFastState.compose env27931 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound27931 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env27932 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,65536,13460,10281,1025,32769,45341,168,41244,98700,8328,17,43276,46109,4233,10281,42113,32,257,168,46212,99079]

theorem envBound27932 : H12AffineFastState.Bounded env27932 := by
  intro p hp
  have h : env27932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27931_27932 : H12AffineEnvironment.transform 17 10281 env27931 = env27932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env27931 == env27932) = true)

theorem identity27932 : scanCanonicalize (H12AffineFastState.compose env27932 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound27932 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27933 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,33030,13460,10281,1025,32769,45341,168,41244,138,8328,17,43276,46109,4233,10281,42113,32,257,168,46212,513]

theorem envBound27933 : H12AffineFastState.Bounded env27933 := by
  intro p hp
  have h : env27933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27932_27933 : H12AffineEnvironment.transform 15 33030 env27932 = env27933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env27932 == env27933) = true)

theorem identity27933 : scanCanonicalize (H12AffineFastState.compose env27933 (packedSelected [2,3,4,5,6,9,10,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound27933 : packedSelected [2,3,4,5,6,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env27934 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,1,263,13460,10281,1025,0,12572,168,8477,138,8328,17,10509,13340,4233,10281,9344,32,257,168,13445,513]

theorem envBound27934 : H12AffineFastState.Bounded env27934 := by
  intro p hp
  have h : env27934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27933_27934 : H12AffineEnvironment.transform 14 1 env27933 = env27934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env27933 == env27934) = true)

theorem identity27934 : scanCanonicalize (H12AffineFastState.compose env27934 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound27934 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27935 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5512,1,263,5392,2477,1025,0,4248,168,153,138,268,17,2185,5528,4233,2477,1284,32,257,168,5377,513]

theorem envBound27935 : H12AffineFastState.Bounded env27935 := by
  intro p hp
  have h : env27935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27934_27935 : H12AffineEnvironment.transform 12 388 env27934 = env27935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env27934 == env27935) = true)

theorem identity27935 : scanCanonicalize (H12AffineFastState.compose env27935 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 694) := by decide +kernel

theorem selectedBound27935 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env27936 : List Nat := [2,4,8,16,32,17,128,256,512,694,2048,4096,388,4926,1,263,5030,2477,695,0,4248,168,153,138,268,17,2185,4910,4233,2477,946,32,257,168,5047,513]

theorem envBound27936 : H12AffineFastState.Bounded env27936 := by
  intro p hp
  have h : env27936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27935_27936 : H12AffineEnvironment.transform 9 694 env27935 = env27936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 694 env27935 == env27936) = true)

theorem identity27936 : scanCanonicalize (H12AffineFastState.compose env27936 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27936 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27937 : List Nat := [2,4,8,16,32,17,8,256,512,574,2048,4096,268,4926,1,263,4910,2341,575,0,4112,32,17,2,268,17,2049,4910,4097,2341,826,32,257,32,4927,513]

theorem envBound27937 : H12AffineFastState.Bounded env27937 := by
  intro p hp
  have h : env27937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27936_27937 : H12AffineEnvironment.transform 6 8 env27936 = env27937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27936 == env27937) = true)

theorem identity27937 : scanCanonicalize (H12AffineFastState.compose env27937 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound27937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27938 : List Nat := [2,4,8,16,32,17,8,256,271,305,2048,4096,268,4145,1,263,4129,2341,304,0,4112,32,17,2,268,17,2049,4129,4097,2341,53,32,257,32,4144,270]

theorem envBound27938 : H12AffineFastState.Bounded env27938 := by
  intro p hp
  have h : env27938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27937_27938 : H12AffineEnvironment.transform 8 271 env27937 = env27938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env27937 == env27938) = true)

theorem identity27938 : scanCanonicalize (H12AffineFastState.compose env27938 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound27938 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27939 : List Nat := [2,4,8,16,32,17,8,256,271,305,2048,2325,268,2340,1,263,2356,2341,304,0,2309,32,17,2,268,17,2049,2356,2324,2341,53,32,257,32,2341,270]

theorem envBound27939 : H12AffineFastState.Bounded env27939 := by
  intro p hp
  have h : env27939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27938_27939 : H12AffineEnvironment.transform 11 2325 env27938 = env27939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env27938 == env27939) = true)

theorem identity27939 : scanCanonicalize (H12AffineFastState.compose env27939 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27939 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27940 : List Nat := [2,4,8,16,11,17,8,256,271,282,2048,2325,268,2319,1,263,2335,2318,283,0,2309,11,17,2,268,17,2049,2335,2324,2318,30,11,257,11,2318,270]

theorem envBound27940 : H12AffineFastState.Bounded env27940 := by
  intro p hp
  have h : env27940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27939_27940 : H12AffineEnvironment.transform 4 11 env27939 = env27940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27939 == env27940) = true)

theorem identity27940 : scanCanonicalize (H12AffineFastState.compose env27940 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27940 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27941 : List Nat := [2,4,8,16,11,17,8,21,26,15,2048,2048,25,2074,1,18,2058,2075,14,0,2064,11,17,2,25,17,2049,2058,2049,2075,30,11,20,11,2075,27]

theorem envBound27941 : H12AffineFastState.Bounded env27941 := by
  intro p hp
  have h : env27941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27940_27941 : H12AffineEnvironment.transform 7 21 env27940 = env27941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27940 == env27941) = true)

theorem identity27941 : scanCanonicalize (H12AffineFastState.compose env27941 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound27941 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27942 : List Nat := [2,4,8,8,11,9,8,13,2,15,2048,2048,1,2050,1,10,2058,2051,14,0,2056,11,9,2,1,9,2049,2058,2049,2051,6,11,12,11,2051,3]

theorem envBound27942 : H12AffineFastState.Bounded env27942 := by
  intro p hp
  have h : env27942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27941_27942 : H12AffineEnvironment.transform 3 8 env27941 = env27942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env27941 == env27942) = true)

theorem identity27942 : scanCanonicalize (H12AffineFastState.compose env27942 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound27942 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27943 : List Nat := [2,4,8,8,11,9,8,13,2,15,10,10,1,8,1,10,0,9,14,0,2,11,9,2,1,9,11,0,11,9,6,11,12,11,9,3]

theorem envBound27943 : H12AffineFastState.Bounded env27943 := by
  intro p hp
  have h : env27943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27942_27943 : H12AffineEnvironment.transform 10 10 env27942 = env27943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env27942 == env27943) = true)

theorem identity27943 : scanCanonicalize (H12AffineFastState.compose env27943 (packedSelected [0,9] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound27943 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env27944 : List Nat := [2,4,1,1,2,0,1,4,2,6,3,3,1,1,1,3,0,0,7,0,2,2,0,2,1,0,2,0,2,0,6,2,5,2,0,3]

theorem envBound27944 : H12AffineFastState.Bounded env27944 := by
  intro p hp
  have h : env27944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27943_27944 : H12AffineEnvironment.transform 2 1 env27943 = env27944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env27943 == env27944) = true)

theorem identity27944 : scanCanonicalize (H12AffineFastState.compose env27944 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound27944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27945 : List Nat := [2,1,1,1,2,0,1,1,2,3,3,3,1,1,1,3,0,0,2,0,2,2,0,2,1,0,2,0,2,0,3,2,0,2,0,3]

theorem envBound27945 : H12AffineFastState.Bounded env27945 := by
  intro p hp
  have h : env27945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27944_27945 : H12AffineEnvironment.transform 1 1 env27944 = env27945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env27944 == env27945) = true)

def env27946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180225,98780,8328,64,4489692,185600,17664,262145,181708,4338764,257,21792,46212,254491]

theorem envBound27946 : H12AffineFastState.Bounded env27946 := by
  intro p hp
  have h : env27946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27887_27946 : H12AffineEnvironment.transform 22 180225 env27887 = env27946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env27887 == env27946) = true)

def env27947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180225,98780,8328,64,43356,185600,17664,262145,181708,400588,257,21792,46212,254491]

theorem envBound27947 : H12AffineFastState.Bounded env27947 := by
  intro p hp
  have h : env27947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27946_27947 : H12AffineEnvironment.transform 21 272512 env27946 = env27947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27946 == env27947) = true)

def env27948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272392,180225,98644,8192,64,43356,185600,17664,262145,181572,400452,257,21792,46092,254491]

theorem envBound27948 : H12AffineFastState.Bounded env27948 := by
  intro p hp
  have h : env27948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27947_27948 : H12AffineEnvironment.transform 6 8 env27947 = env27948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27947 == env27948) = true)

theorem identity27948 : scanCanonicalize (H12AffineFastState.compose env27948 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound27948 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env27949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77898,272392,73755,98644,8192,64,43356,79130,17664,262145,75102,392286,257,21792,46092,513]

theorem envBound27949 : H12AffineFastState.Bounded env27949 := by
  intro p hp
  have h : env27949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27948_27949 : H12AffineEnvironment.transform 16 122906 env27948 = env27949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env27948 == env27949) = true)

theorem identity27949 : scanCanonicalize (H12AffineFastState.compose env27949 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound27949 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env27950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67619,1025,32769,77898,73771,73755,98644,8192,64,43356,79130,17664,67618,75102,62589,257,21792,46092,513]

theorem envBound27950 : H12AffineFastState.Bounded env27950 := by
  intro p hp
  have h : env27950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27949_27950 : H12AffineEnvironment.transform 17 67619 env27949 = env27950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env27949 == env27950) = true)

theorem identity27950 : scanCanonicalize (H12AffineFastState.compose env27950 (packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound27950 : packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env27951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,65536,70678,67619,1025,29709,77898,73771,73755,95576,8192,64,23888,79130,17664,67618,75102,113,257,21792,16384,513]

theorem envBound27951 : H12AffineFastState.Bounded env27951 := by
  intro p hp
  have h : env27951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27950_27951 : H12AffineEnvironment.transform 14 29708 env27950 = env27951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env27950 == env27951) = true)

theorem identity27951 : scanCanonicalize (H12AffineFastState.compose env27951 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound27951 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env27952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,0,65536,70678,67619,1025,1,77898,73771,73755,65876,8192,64,10588,79130,12556,67618,75102,113,257,8492,13324,513]

theorem envBound27952 : H12AffineFastState.Bounded env27952 := by
  intro p hp
  have h : env27952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27951_27952 : H12AffineEnvironment.transform 13 13324 env27951 = env27952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env27951 == env27952) = true)

theorem identity27952 : scanCanonicalize (H12AffineFastState.compose env27952 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound27952 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env27953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,0,262,5392,2341,1025,1,12620,8493,8477,82,8192,64,10588,13340,12556,2340,9304,113,257,8492,13324,513]

theorem envBound27953 : H12AffineFastState.Bounded env27953 := by
  intro p hp
  have h : env27953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27952_27953 : H12AffineEnvironment.transform 15 262 env27952 = env27953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env27952 == env27953) = true)

theorem identity27953 : scanCanonicalize (H12AffineFastState.compose env27953 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27953 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27954 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,262,5392,2341,1025,1,12572,8493,8477,2,8192,16,10508,13340,12556,2340,9224,33,257,8492,13324,513]

theorem envBound27954 : H12AffineFastState.Bounded env27954 := by
  intro p hp
  have h : env27954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27953_27954 : H12AffineEnvironment.transform 5 16 env27953 = env27954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27953 == env27954) = true)

theorem identity27954 : scanCanonicalize (H12AffineFastState.compose env27954 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27954 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27955 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,8192,12572,0,262,4096,2341,273,1,12572,8493,8477,2,8192,16,10508,12556,12556,2340,8472,33,257,8492,12572,513]

theorem envBound27955 : H12AffineFastState.Bounded env27955 := by
  intro p hp
  have h : env27955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27954_27955 : H12AffineEnvironment.transform 9 272 env27954 = env27955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27954 == env27955) = true)

theorem identity27955 : scanCanonicalize (H12AffineFastState.compose env27955 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27955 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27956 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,268,4112,0,262,4096,2341,273,1,4112,33,17,2,268,16,2048,4096,4096,2340,20,33,257,32,4112,513]

theorem envBound27956 : H12AffineFastState.Bounded env27956 := by
  intro p hp
  have h : env27956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27955_27956 : H12AffineEnvironment.transform 12 268 env27955 = env27956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27955 == env27956) = true)

theorem identity27956 : scanCanonicalize (H12AffineFastState.compose env27956 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound27956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27957 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,276,268,260,0,262,276,2341,273,1,260,33,17,2,268,16,2048,276,276,2340,20,33,257,32,260,513]

theorem envBound27957 : H12AffineFastState.Bounded env27957 := by
  intro p hp
  have h : env27957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27956_27957 : H12AffineEnvironment.transform 11 276 env27956 = env27957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env27956 == env27957) = true)

theorem identity27957 : scanCanonicalize (H12AffineFastState.compose env27957 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27957 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27958 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,276,268,260,0,262,276,2308,273,1,260,0,17,2,268,16,2048,276,276,2309,20,0,257,1,260,513]

theorem envBound27958 : H12AffineFastState.Bounded env27958 := by
  intro p hp
  have h : env27958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27957_27958 : H12AffineEnvironment.transform 4 1 env27957 = env27958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27957 == env27958) = true)

theorem identity27958 : scanCanonicalize (H12AffineFastState.compose env27958 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound27958 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27959 : List Nat := [2,4,8,16,1,16,8,256,512,272,513,276,268,260,0,262,276,773,273,1,260,0,17,2,268,16,513,276,276,772,20,0,257,1,260,513]

theorem envBound27959 : H12AffineFastState.Bounded env27959 := by
  intro p hp
  have h : env27959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27958_27959 : H12AffineEnvironment.transform 10 513 env27958 = env27959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env27958 == env27959) = true)

theorem identity27959 : scanCanonicalize (H12AffineFastState.compose env27959 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27960 : List Nat := [2,4,8,0,1,0,8,256,512,256,513,260,268,260,0,262,260,773,257,1,260,0,1,2,268,0,513,260,260,772,4,0,257,1,260,513]

theorem envBound27960 : H12AffineFastState.Bounded env27960 := by
  intro p hp
  have h : env27960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27959_27960 : H12AffineEnvironment.transform 3 0 env27959 = env27960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27959 == env27960) = true)

theorem identity27960 : scanCanonicalize (H12AffineFastState.compose env27960 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound27960 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27961 : List Nat := [2,4,8,0,1,0,8,256,260,256,261,260,268,260,0,262,260,1,257,1,260,0,1,2,268,0,261,260,260,0,4,0,257,1,260,261]

theorem envBound27961 : H12AffineFastState.Bounded env27961 := by
  intro p hp
  have h : env27961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27960_27961 : H12AffineEnvironment.transform 8 260 env27960 = env27961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env27960 == env27961) = true)

def env27962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272393,180225,98645,8193,64,43356,185600,17664,262145,181573,400453,257,21792,46093,254491]

theorem envBound27962 : H12AffineFastState.Bounded env27962 := by
  intro p hp
  have h : env27962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27947_27962 : H12AffineEnvironment.transform 6 9 env27947 = env27962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27947 == env27962) = true)

theorem identity27962 : scanCanonicalize (H12AffineFastState.compose env27962 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound27962 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env27963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,36929,272393,32784,98645,8193,64,43356,38161,17664,262145,34132,285780,257,21792,46093,107018]

theorem envBound27963 : H12AffineFastState.Bounded env27963 := by
  intro p hp
  have h : env27963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27962_27963 : H12AffineEnvironment.transform 16 16401 env27962 = env27963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env27962 == env27963) = true)

theorem identity27963 : scanCanonicalize (H12AffineFastState.compose env27963 (packedSelected [0,1,4,7,19,22,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound27963 : packedSelected [0,1,4,7,19,22,28,31] rootPS < 2^1333 := by decide +kernel

def env27964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,43048,1025,32769,36929,32801,32784,98645,8193,64,43356,38161,17664,43049,34132,62588,257,21792,46093,107018]

theorem envBound27964 : H12AffineFastState.Bounded env27964 := by
  intro p hp
  have h : env27964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27963_27964 : H12AffineEnvironment.transform 17 43048 env27963 = env27964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env27963 == env27964) = true)

theorem identity27964 : scanCanonicalize (H12AffineFastState.compose env27964 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound27964 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,43048,1025,32769,36929,32801,32784,3,8193,64,43356,38161,17664,43049,34132,62588,257,21792,46093,9052]

theorem envBound27965 : H12AffineFastState.Bounded env27965 := by
  intro p hp
  have h : env27965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27964_27965 : H12AffineEnvironment.transform 15 33110 env27964 = env27965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env27964 == env27965) = true)

theorem identity27965 : scanCanonicalize (H12AffineFastState.compose env27965 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27965 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env27966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,2421,1025,8540,12572,8572,8525,3,8193,64,2049,13388,17664,2420,9225,21793,257,21792,5456,9052]

theorem envBound27966 : H12AffineFastState.Bounded env27966 := by
  intro p hp
  have h : env27966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27965_27966 : H12AffineEnvironment.transform 14 8541 env27965 = env27966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27965 == env27966) = true)

theorem identity27966 : scanCanonicalize (H12AffineFastState.compose env27966 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound27966 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env27967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,8203,5221,2421,1025,8540,12572,8572,8525,3,8193,64,2049,13388,4468,2420,9225,341,257,340,5456,9052]

theorem envBound27967 : H12AffineFastState.Bounded env27967 := by
  intro p hp
  have h : env27967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27966_27967 : H12AffineEnvironment.transform 13 5236 env27966 = env27967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env27966 == env27967) = true)

theorem identity27967 : scanCanonicalize (H12AffineFastState.compose env27967 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27967 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5236,81,263,5221,2421,1025,80,4112,112,65,3,269,64,2049,5440,4468,2420,1285,341,257,340,5456,592]

theorem envBound27968 : H12AffineFastState.Bounded env27968 := by
  intro p hp
  have h : env27968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27967_27968 : H12AffineEnvironment.transform 12 268 env27967 = env27968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27967 == env27968) = true)

theorem identity27968 : scanCanonicalize (H12AffineFastState.compose env27968 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound27968 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env27969 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,81,114,5221,2048,1025,80,4112,112,65,3,120,64,2049,5173,4097,2049,1136,32,116,33,5157,592]

theorem envBound27969 : H12AffineFastState.Bounded env27969 := by
  intro p hp
  have h : env27969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27968_27969 : H12AffineEnvironment.transform 7 117 env27968 = env27969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env27968 == env27969) = true)

theorem identity27969 : scanCanonicalize (H12AffineFastState.compose env27969 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27969 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env27970 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,34,5173,2048,1025,0,4112,32,17,3,40,16,2049,5173,4097,2049,1056,32,36,33,5157,512]

theorem envBound27970 : H12AffineFastState.Bounded env27970 := by
  intro p hp
  have h : env27970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27969_27970 : H12AffineEnvironment.transform 5 16 env27969 = env27970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27969 == env27970) = true)

theorem identity27970 : scanCanonicalize (H12AffineFastState.compose env27970 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27970 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27971 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5124,1,2,5141,2048,1025,0,4112,0,17,3,8,16,2049,5141,4097,2049,1024,0,4,1,5125,512]

theorem envBound27971 : H12AffineFastState.Bounded env27971 := by
  intro p hp
  have h : env27971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27970_27971 : H12AffineEnvironment.transform 4 0 env27970 = env27971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27970 == env27971) = true)

theorem identity27971 : scanCanonicalize (H12AffineFastState.compose env27971 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound27971 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27972 : List Nat := [2,4,8,16,0,16,9,5,512,1024,522,4096,9,5124,1,2,5141,522,1025,0,4112,0,17,3,8,16,523,5141,4097,523,1024,0,4,1,5125,512]

theorem envBound27972 : H12AffineFastState.Bounded env27972 := by
  intro p hp
  have h : env27972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27971_27972 : H12AffineEnvironment.transform 10 522 env27971 = env27972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env27971 == env27972) = true)

def env27973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180225,98780,8328,64,43357,185600,17664,262145,181708,400589,257,21792,46212,254491]

theorem envBound27973 : H12AffineFastState.Bounded env27973 := by
  intro p hp
  have h : env27973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27946_27973 : H12AffineEnvironment.transform 21 272513 env27946 = env27973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27946 == env27973) = true)

theorem identity27973 : scanCanonicalize (H12AffineFastState.compose env27973 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound27973 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272513,17,98780,8328,64,43357,5392,17664,262145,1500,318685,257,21792,46212,74251]

theorem envBound27974 : H12AffineFastState.Bounded env27974 := by
  intro p hp
  have h : env27974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27973_27974 : H12AffineEnvironment.transform 16 49168 env27973 = env27974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env27973 == env27974) = true)

theorem identity27974 : scanCanonicalize (H12AffineFastState.compose env27974 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27974 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env27975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4160,272513,17,41430,8328,64,43357,5392,17664,262145,1500,318685,257,21792,46212,513]

theorem envBound27975 : H12AffineFastState.Bounded env27975 := by
  intro p hp
  have h : env27975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27974_27975 : H12AffineEnvironment.transform 15 8202 env27974 = env27975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27974 == env27975) = true)

theorem identity27975 : scanCanonicalize (H12AffineFastState.compose env27975 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound27975 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env27976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10400,1025,32769,4160,33,17,41430,8328,64,43357,5392,17664,10401,1500,62589,257,21792,46212,513]

theorem envBound27976 : H12AffineFastState.Bounded env27976 := by
  intro p hp
  have h : env27976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27975_27976 : H12AffineEnvironment.transform 17 10400 env27975 = env27976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27975 == env27976) = true)

theorem identity27976 : scanCanonicalize (H12AffineFastState.compose env27976 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound27976 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env27977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16400,10400,1025,1,4160,33,17,8662,8328,64,10589,5392,17664,10401,1500,29821,257,21792,13444,513]

theorem envBound27977 : H12AffineFastState.Bounded env27977 := by
  intro p hp
  have h : env27977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27976_27977 : H12AffineEnvironment.transform 14 0 env27976 = env27977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env27976 == env27977) = true)

theorem identity27977 : scanCanonicalize (H12AffineFastState.compose env27977 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound27977 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env27978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,0,8202,4097,10400,1025,1,4160,33,17,8662,8328,64,10589,5392,5393,10401,1500,9324,257,1329,13444,513]

theorem envBound27978 : H12AffineFastState.Bounded env27978 := by
  intro p hp
  have h : env27978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27977_27978 : H12AffineEnvironment.transform 13 4113 env27977 = env27978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env27977 == env27978) = true)

theorem identity27978 : scanCanonicalize (H12AffineFastState.compose env27978 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound27978 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,4113,0,1095,4097,3309,1025,1,4160,33,17,1435,1221,64,3344,5392,5393,3308,1500,33,257,1329,4297,513]

theorem envBound27979 : H12AffineFastState.Bounded env27979 := by
  intro p hp
  have h : env27979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27978_27979 : H12AffineEnvironment.transform 12 1101 env27978 = env27979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env27978 == env27979) = true)

theorem identity27979 : scanCanonicalize (H12AffineFastState.compose env27979 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound27979 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env27980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1076,4096,1101,4113,0,1095,4097,217,1025,1,4160,33,17,1435,1221,64,292,5392,5393,216,1500,33,257,1329,4297,513]

theorem envBound27980 : H12AffineFastState.Bounded env27980 := by
  intro p hp
  have h : env27980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27979_27980 : H12AffineEnvironment.transform 10 1076 env27979 = env27980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env27979 == env27980) = true)

theorem identity27980 : scanCanonicalize (H12AffineFastState.compose env27980 (packedSelected [1,2,3,5,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27980 : packedSelected [1,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env27981 : List Nat := [2,4,8,16,32,64,128,256,512,273,293,4096,348,4113,0,342,4097,217,272,1,4160,33,17,138,468,64,292,4097,4096,216,205,33,257,32,4297,513]

theorem envBound27981 : H12AffineFastState.Bounded env27981 := by
  intro p hp
  have h : env27981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27980_27981 : H12AffineEnvironment.transform 9 273 env27980 = env27981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27980 == env27981) = true)

theorem identity27981 : scanCanonicalize (H12AffineFastState.compose env27981 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound27981 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27982 : List Nat := [2,4,8,16,32,64,128,173,512,188,136,4096,241,4113,0,251,4097,217,189,1,4160,33,17,138,121,64,137,4097,4096,216,205,33,172,32,4297,513]

theorem envBound27982 : H12AffineFastState.Bounded env27982 := by
  intro p hp
  have h : env27982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27981_27982 : H12AffineEnvironment.transform 7 173 env27981 = env27982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27981 == env27982) = true)

theorem identity27982 : scanCanonicalize (H12AffineFastState.compose env27982 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound27982 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27983 : List Nat := [2,4,8,16,32,64,128,173,512,188,136,153,241,136,0,251,152,217,189,1,217,33,17,138,121,64,137,152,153,216,205,33,172,32,80,513]

theorem envBound27983 : H12AffineFastState.Bounded env27983 := by
  intro p hp
  have h : env27983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27982_27983 : H12AffineEnvironment.transform 11 153 env27982 = env27983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env27982 == env27983) = true)

theorem identity27983 : scanCanonicalize (H12AffineFastState.compose env27983 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27983 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27984 : List Nat := [2,4,8,16,32,16,128,173,512,188,136,153,161,136,0,171,152,137,189,1,137,33,17,138,41,16,137,152,153,136,157,33,172,32,0,513]

theorem envBound27984 : H12AffineFastState.Bounded env27984 := by
  intro p hp
  have h : env27984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27983_27984 : H12AffineEnvironment.transform 5 16 env27983 = env27984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27983 == env27984) = true)

theorem identity27984 : scanCanonicalize (H12AffineFastState.compose env27984 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27984 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27985 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,16,40,1,0,34,17,0,52,1,0,33,17,3,41,16,0,17,16,1,20,33,37,32,0,513]

theorem envBound27985 : H12AffineFastState.Bounded env27985 := by
  intro p hp
  have h : env27985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27984_27985 : H12AffineEnvironment.transform 6 9 env27984 = env27985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27984 == env27985) = true)

theorem identity27985 : scanCanonicalize (H12AffineFastState.compose env27985 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound27985 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27986 : List Nat := [2,4,8,16,32,16,9,36,16,53,1,16,40,1,0,34,17,0,52,1,0,33,17,3,41,16,0,17,16,1,20,33,37,32,0,17]

theorem envBound27986 : H12AffineFastState.Bounded env27986 := by
  intro p hp
  have h : env27986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27985_27986 : H12AffineEnvironment.transform 8 16 env27985 = env27986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env27985 == env27986) = true)

theorem identity27986 : scanCanonicalize (H12AffineFastState.compose env27986 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound27986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27987 : List Nat := [2,4,8,16,26,16,9,30,16,15,1,16,18,1,0,24,17,0,14,1,0,27,17,3,19,16,0,17,16,1,20,27,31,26,0,17]

theorem envBound27987 : H12AffineFastState.Bounded env27987 := by
  intro p hp
  have h : env27987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27986_27987 : H12AffineEnvironment.transform 4 26 env27986 = env27987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env27986 == env27987) = true)

def env27988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,8388608,8602077,8328,64,4489692,8393984,8553728,8830976,181708,12645452,257,21793,46213,254491]

theorem envBound27988 : H12AffineFastState.Bounded env27988 := by
  intro p hp
  have h : env27988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27886_27988 : H12AffineEnvironment.transform 20 184401 env27886 = env27988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env27886 == env27988) = true)

def env27989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180224,98781,8328,64,4489692,185600,17664,262144,181708,4338764,257,21793,46213,254491]

theorem envBound27989 : H12AffineFastState.Bounded env27989 := by
  intro p hp
  have h : env27989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27988_27989 : H12AffineEnvironment.transform 22 180224 env27988 = env27989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env27988 == env27989) = true)

def env27990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180224,98781,8328,64,43356,185600,17664,262144,181708,400588,257,21793,46213,254491]

theorem envBound27990 : H12AffineFastState.Bounded env27990 := by
  intro p hp
  have h : env27990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27989_27990 : H12AffineEnvironment.transform 21 272512 env27989 = env27990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27989 == env27990) = true)

theorem identity27990 : scanCanonicalize (H12AffineFastState.compose env27990 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound27990 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,115870,272512,120015,98781,8328,64,43356,115151,17664,262144,119043,329731,257,21793,46213,63188]

theorem envBound27991 : H12AffineFastState.Bounded env27991 := by
  intro p hp
  have h : env27991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27990_27991 : H12AffineEnvironment.transform 16 70863 env27990 = env27991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env27990 == env27991) = true)

theorem identity27991 : scanCanonicalize (H12AffineFastState.compose env27991 (packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound27991 : packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env27992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,70863,262144,1025,32769,110667,272512,106522,98781,8328,64,43356,111898,12757,262144,107990,329731,257,8692,46213,33281]

theorem envBound27992 : H12AffineFastState.Bounded env27992 := by
  intro p hp
  have h : env27992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27991_27992 : H12AffineEnvironment.transform 13 13525 env27991 = env27992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env27991 == env27992) = true)

theorem identity27992 : scanCanonicalize (H12AffineFastState.compose env27992 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound27992 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,0,65536,70863,262144,1025,1,77899,272512,73754,66013,8328,64,10588,79130,12757,262144,75222,329731,257,8692,13445,513]

theorem envBound27993 : H12AffineFastState.Bounded env27993 := by
  intro p hp
  have h : env27993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27992_27993 : H12AffineEnvironment.transform 14 0 env27992 = env27993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env27992 == env27993) = true)

def env27994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,65536,70727,262144,1025,1,77899,272392,73754,65877,8192,64,10588,79130,12637,262144,75102,329731,257,8572,13325,513]

theorem envBound27994 : H12AffineFastState.Bounded env27994 := by
  intro p hp
  have h : env27994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27993_27994 : H12AffineEnvironment.transform 6 8 env27993 = env27994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27993 == env27994) = true)

theorem identity27994 : scanCanonicalize (H12AffineFastState.compose env27994 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27994 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env27995 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,65536,70679,262144,1025,1,77851,272392,73754,65797,8192,16,10508,79130,12557,262144,75022,329731,257,8492,13325,513]

theorem envBound27995 : H12AffineFastState.Bounded env27995 := by
  intro p hp
  have h : env27995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27994_27995 : H12AffineEnvironment.transform 5 16 env27994 = env27995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27994 == env27995) = true)

theorem identity27995 : scanCanonicalize (H12AffineFastState.compose env27995 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound27995 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27996 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,263,5392,262144,1025,1,12572,272392,8477,2,8192,16,10508,13341,12557,262144,9225,264452,257,8492,13325,513]

theorem envBound27996 : H12AffineFastState.Bounded env27996 := by
  intro p hp
  have h : env27996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27995_27996 : H12AffineEnvironment.transform 15 263 env27995 = env27996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env27995 == env27996) = true)

theorem identity27996 : scanCanonicalize (H12AffineFastState.compose env27996 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound27996 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27997 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,263,5392,2341,1025,1,12572,8493,8477,2,8192,16,10508,13341,12557,2341,9225,33,257,8492,13325,513]

theorem envBound27997 : H12AffineFastState.Bounded env27997 := by
  intro p hp
  have h : env27997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27996_27997 : H12AffineEnvironment.transform 17 2341 env27996 = env27997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env27996 == env27997) = true)

theorem identity27997 : scanCanonicalize (H12AffineFastState.compose env27997 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 804) := by decide +kernel

theorem selectedBound27997 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27998 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,804,8192,10025,0,263,1588,2341,1025,1,8760,8493,8477,2,8192,16,10508,10041,8745,2341,9225,33,257,8492,10025,513]

theorem envBound27998 : H12AffineFastState.Bounded env27998 := by
  intro p hp
  have h : env27998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27997_27998 : H12AffineEnvironment.transform 11 804 env27997 = env27998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 804 env27997 == env27998) = true)

theorem identity27998 : scanCanonicalize (H12AffineFastState.compose env27998 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound27998 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27999 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,804,8192,8989,0,263,512,2341,53,1,8760,8493,8477,2,8192,16,10508,8973,8745,2341,8253,33,257,8492,8989,513]

theorem envBound27999 : H12AffineFastState.Bounded env27999 := by
  intro p hp
  have h : env27999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27998_27999 : H12AffineEnvironment.transform 9 52 env27998 = env27999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env27998 == env27999) = true)

theorem identity27999 : scanCanonicalize (H12AffineFastState.compose env27999 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27999 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env28000 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,513,8192,8760,0,34,512,2048,53,1,8760,8200,8248,2,8192,16,10281,8744,8745,2048,8253,33,36,8201,8760,513]

theorem envBound28000 : H12AffineFastState.Bounded env28000 := by
  intro p hp
  have h : env28000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27999_28000 : H12AffineEnvironment.transform 7 37 env27999 = env28000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27999 == env28000) = true)

theorem identity28000 : scanCanonicalize (H12AffineFastState.compose env28000 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 2104) := by decide +kernel

theorem selectedBound28000 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28001 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,513,2104,2560,0,34,512,2048,53,1,2560,2096,2048,2,2104,16,17,2576,2577,2048,2053,33,36,2097,2560,513]

theorem envBound28001 : H12AffineFastState.Bounded env28001 := by
  intro p hp
  have h : env28001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28000_28001 : H12AffineEnvironment.transform 12 2104 env28000 = env28001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2104 env28000 == env28001) = true)

theorem identity28001 : scanCanonicalize (H12AffineFastState.compose env28001 (packedSelected [2,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound28001 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env28002 : List Nat := [2,4,8,16,32,16,8,37,512,52,17,513,41,529,0,34,512,17,53,1,529,33,17,2,41,16,17,513,512,17,20,33,36,32,529,513]

theorem envBound28002 : H12AffineFastState.Bounded env28002 := by
  intro p hp
  have h : env28002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28001_28002 : H12AffineEnvironment.transform 10 17 env28001 = env28002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env28001 == env28002) = true)

theorem identity28002 : scanCanonicalize (H12AffineFastState.compose env28002 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound28002 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28003 : List Nat := [2,4,8,16,32,16,8,37,27,52,17,26,41,10,0,34,27,17,53,1,10,33,17,2,41,16,17,26,27,17,20,33,36,32,10,26]

theorem envBound28003 : H12AffineFastState.Bounded env28003 := by
  intro p hp
  have h : env28003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28002_28003 : H12AffineEnvironment.transform 8 27 env28002 = env28003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env28002 == env28003) = true)

theorem identity28003 : scanCanonicalize (H12AffineFastState.compose env28003 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28003 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28004 : List Nat := [2,4,8,11,32,11,8,37,0,47,10,1,41,10,0,34,0,10,46,1,10,33,10,2,41,11,10,1,0,10,15,33,36,32,10,1]

theorem envBound28004 : H12AffineFastState.Bounded env28004 := by
  intro p hp
  have h : env28004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28003_28004 : H12AffineEnvironment.transform 3 11 env28003 = env28004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28003 == env28004) = true)

def env28005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,65536,70726,262144,1025,1,77899,272393,73754,65876,8193,64,10588,79130,12636,262144,75103,329731,257,8573,13324,513]

theorem envBound28005 : H12AffineFastState.Bounded env28005 := by
  intro p hp
  have h : env28005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27993_28005 : H12AffineEnvironment.transform 6 9 env27993 = env28005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27993 == env28005) = true)

theorem identity28005 : scanCanonicalize (H12AffineFastState.compose env28005 (packedSelected [2,6,17] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound28005 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env28006 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,65536,70726,67699,1025,1,77899,73850,73754,65876,8193,64,10588,79130,12636,67699,75103,112,257,8573,13324,513]

theorem envBound28006 : H12AffineFastState.Bounded env28006 := by
  intro p hp
  have h : env28006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28005_28006 : H12AffineEnvironment.transform 17 67699 env28005 = env28006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env28005 == env28006) = true)

theorem identity28006 : scanCanonicalize (H12AffineFastState.compose env28006 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28006 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env28007 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,0,65536,70679,67618,1025,1,77850,73771,73754,65797,8193,17,10509,79130,12557,67618,75022,33,257,8492,13324,513]

theorem envBound28007 : H12AffineFastState.Bounded env28007 := by
  intro p hp
  have h : env28007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28006_28007 : H12AffineEnvironment.transform 5 17 env28006 = env28007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28006 == env28007) = true)

theorem identity28007 : scanCanonicalize (H12AffineFastState.compose env28007 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound28007 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28008 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,0,262,5393,2340,1025,1,12572,8493,8476,3,8193,17,10509,13340,12557,2340,9224,33,257,8492,13324,513]

theorem envBound28008 : H12AffineFastState.Bounded env28008 := by
  intro p hp
  have h : env28008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28007_28008 : H12AffineEnvironment.transform 15 262 env28007 = env28008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env28007 == env28008) = true)

theorem identity28008 : scanCanonicalize (H12AffineFastState.compose env28008 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound28008 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28009 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,512,8192,9741,0,262,1809,2340,1025,1,8988,8493,8476,3,8193,17,10509,9756,8973,2340,9224,33,257,8492,9740,513]

theorem envBound28009 : H12AffineFastState.Bounded env28009 := by
  intro p hp
  have h : env28009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28008_28009 : H12AffineEnvironment.transform 11 512 env28008 = env28009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env28008 == env28009) = true)

theorem identity28009 : scanCanonicalize (H12AffineFastState.compose env28009 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2617) := by decide +kernel

theorem selectedBound28009 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env28010 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,512,2617,3124,0,262,1809,2340,1025,1,2341,2836,2853,3,2616,17,820,3109,2356,2340,3633,33,257,2837,3125,513]

theorem envBound28010 : H12AffineFastState.Bounded env28010 := by
  intro p hp
  have h : env28010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28009_28010 : H12AffineEnvironment.transform 12 2617 env28009 = env28010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2617 env28009 == env28010) = true)

theorem identity28010 : scanCanonicalize (H12AffineFastState.compose env28010 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound28010 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28011 : List Nat := [2,4,8,16,32,17,9,256,512,1024,821,512,268,1793,0,262,1809,529,1025,1,528,33,16,3,269,17,820,1808,513,529,1284,33,257,32,1792,513]

theorem envBound28011 : H12AffineFastState.Bounded env28011 := by
  intro p hp
  have h : env28011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28010_28011 : H12AffineEnvironment.transform 10 821 env28010 = env28011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env28010 == env28011) = true)

theorem identity28011 : scanCanonicalize (H12AffineFastState.compose env28011 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound28011 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28012 : List Nat := [2,4,8,16,32,17,9,256,512,289,821,512,268,544,0,262,560,529,288,1,528,33,16,3,269,17,820,561,513,529,37,33,257,32,545,513]

theorem envBound28012 : H12AffineFastState.Bounded env28012 := by
  intro p hp
  have h : env28012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28011_28012 : H12AffineEnvironment.transform 9 289 env28011 = env28012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env28011 == env28012) = true)

theorem identity28012 : scanCanonicalize (H12AffineFastState.compose env28012 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound28012 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28013 : List Nat := [2,4,8,16,32,17,9,53,512,20,512,512,57,544,0,51,560,529,21,1,528,33,16,3,56,17,513,561,513,529,37,33,52,32,545,513]

theorem envBound28013 : H12AffineFastState.Bounded env28013 := by
  intro p hp
  have h : env28013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28012_28013 : H12AffineEnvironment.transform 7 53 env28012 = env28013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env28012 == env28013) = true)

theorem identity28013 : scanCanonicalize (H12AffineFastState.compose env28013 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28013 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28014 : List Nat := [2,4,8,16,16,17,9,5,512,20,512,512,9,528,0,3,512,529,21,1,528,17,16,3,8,17,513,513,513,529,21,17,4,16,529,513]

theorem envBound28014 : H12AffineFastState.Bounded env28014 := by
  intro p hp
  have h : env28014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28013_28014 : H12AffineEnvironment.transform 4 16 env28013 = env28014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28013 == env28014) = true)

theorem identity28014 : scanCanonicalize (H12AffineFastState.compose env28014 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28014 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28015 : List Nat := [2,4,8,16,16,17,9,5,1,20,1,1,9,17,0,3,1,16,21,1,17,17,16,3,8,17,0,0,0,16,21,17,4,16,16,0]

theorem envBound28015 : H12AffineFastState.Bounded env28015 := by
  intro p hp
  have h : env28015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28014_28015 : H12AffineEnvironment.transform 8 1 env28014 = env28015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28014 == env28015) = true)

theorem identity28015 : scanCanonicalize (H12AffineFastState.compose env28015 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28015 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28016 : List Nat := [2,4,2,16,16,17,3,5,1,20,1,1,3,17,0,3,1,16,21,1,17,17,16,3,2,17,0,0,0,16,21,17,4,16,16,0]

theorem envBound28016 : H12AffineFastState.Bounded env28016 := by
  intro p hp
  have h : env28016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28015_28016 : H12AffineEnvironment.transform 2 2 env28015 = env28016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28015 == env28016) = true)

theorem identity28016 : scanCanonicalize (H12AffineFastState.compose env28016 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28016 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env28017 : List Nat := [2,4,2,0,0,1,3,5,1,4,1,1,3,1,0,3,1,0,5,1,1,1,0,3,2,1,0,0,0,0,5,1,4,0,0,0]

theorem envBound28017 : H12AffineFastState.Bounded env28017 := by
  intro p hp
  have h : env28017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28016_28017 : H12AffineEnvironment.transform 3 0 env28016 = env28017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28016 == env28017) = true)

def env28018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180224,98781,8328,64,43357,185600,17664,262144,181708,400589,257,21793,46213,254491]

theorem envBound28018 : H12AffineFastState.Bounded env28018 := by
  intro p hp
  have h : env28018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27989_28018 : H12AffineEnvironment.transform 21 272513 env27989 = env28018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27989 == env28018) = true)

theorem identity28018 : scanCanonicalize (H12AffineFastState.compose env28018 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound28018 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,184401,272513,180224,21763,8328,64,43357,185600,17664,262144,181708,400589,257,21793,46213,145093]

theorem envBound28019 : H12AffineFastState.Bounded env28019 := by
  intro p hp
  have h : env28019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28018_28019 : H12AffineEnvironment.transform 15 54494 env28018 = env28019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env28018 == env28019) = true)

def env28020 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,184321,272513,180224,21763,8328,16,43277,185600,17664,262144,181660,400541,257,21793,46213,145045]

theorem envBound28020 : H12AffineFastState.Bounded env28020 := by
  intro p hp
  have h : env28020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28019_28020 : H12AffineEnvironment.transform 5 16 env28019 = env28020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28019 == env28020) = true)

theorem identity28020 : scanCanonicalize (H12AffineFastState.compose env28020 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound28020 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env28021 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,35108,1025,32769,184321,41381,180224,21763,8328,16,43277,185600,17664,35108,181660,169401,257,21793,46213,145045]

theorem envBound28021 : H12AffineFastState.Bounded env28021 := by
  intro p hp
  have h : env28021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28020_28021 : H12AffineEnvironment.transform 17 35108 env28020 = env28021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env28020 == env28021) = true)

theorem identity28021 : scanCanonicalize (H12AffineFastState.compose env28021 (packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound28021 : packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28022 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,33030,131072,35108,1025,32769,165257,41381,169352,139,8328,16,43277,163976,4232,35108,167956,169401,257,169,46213,145045]

theorem envBound28022 : H12AffineFastState.Bounded env28022 := by
  intro p hp
  have h : env28022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28021_28022 : H12AffineEnvironment.transform 13 5512 env28021 = env28022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env28021 == env28022) = true)

theorem identity28022 : scanCanonicalize (H12AffineFastState.compose env28022 (packedSelected [1,3,8,14,17,18,19,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 46228) := by decide +kernel

theorem selectedBound28022 : packedSelected [1,3,8,14,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28023 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,33030,46228,35108,1025,32769,12573,41381,8476,139,8328,16,43277,13340,4232,35108,9344,8493,257,169,46213,33281]

theorem envBound28023 : H12AffineFastState.Bounded env28023 := by
  intro p hp
  have h : env28023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28022_28023 : H12AffineEnvironment.transform 16 46228 env28022 = env28023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46228 env28022 == env28023) = true)

theorem identity28023 : scanCanonicalize (H12AffineFastState.compose env28023 (packedSelected [3,5,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound28023 : packedSelected [3,5,14,16,19] rootPS < 2^1333 := by decide +kernel

def env28024 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8461,8203,5529,10281,1025,8460,12573,168,8476,139,8328,16,2048,13340,4232,10281,9344,8493,257,169,5512,8972]

theorem envBound28024 : H12AffineFastState.Bounded env28024 := by
  intro p hp
  have h : env28024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28023_28024 : H12AffineEnvironment.transform 14 8461 env28023 = env28024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env28023 == env28024) = true)

theorem identity28024 : scanCanonicalize (H12AffineFastState.compose env28024 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 701) := by decide +kernel

theorem selectedBound28024 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env28025 : List Nat := [2,4,8,16,32,16,128,256,512,701,2048,4096,8192,4917,8461,8203,4900,10281,700,8460,12573,168,8476,139,8328,16,2048,12961,4232,10281,8765,8493,257,169,4917,8972]

theorem envBound28025 : H12AffineFastState.Bounded env28025 := by
  intro p hp
  have h : env28025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28024_28025 : H12AffineEnvironment.transform 9 701 env28024 = env28025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 701 env28024 == env28025) = true)

theorem identity28025 : scanCanonicalize (H12AffineFastState.compose env28025 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 4997) := by decide +kernel

theorem selectedBound28025 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env28026 : List Nat := [2,4,8,16,32,16,128,256,512,701,2048,4096,4997,4917,4744,5006,4900,7084,700,4745,664,168,4761,139,4877,16,2048,292,4232,7084,4536,4776,257,169,4917,4233]

theorem envBound28026 : H12AffineFastState.Bounded env28026 := by
  intro p hp
  have h : env28026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28025_28026 : H12AffineEnvironment.transform 12 4997 env28025 = env28026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4997 env28025 == env28026) = true)

theorem identity28026 : scanCanonicalize (H12AffineFastState.compose env28026 (packedSelected [1,3,4,5,6,8,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound28026 : packedSelected [1,3,4,5,6,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env28027 : List Nat := [2,4,8,16,32,16,128,256,512,701,2048,544,421,277,168,430,260,2444,700,169,664,168,185,139,301,16,2048,292,680,2444,920,136,257,169,277,681]

theorem envBound28027 : H12AffineFastState.Bounded env28027 := by
  intro p hp
  have h : env28027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28026_28027 : H12AffineEnvironment.transform 11 544 env28026 = env28027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env28026 == env28027) = true)

theorem identity28027 : scanCanonicalize (H12AffineFastState.compose env28027 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28027 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env28028 : List Nat := [2,4,8,16,32,16,9,256,512,564,2048,544,300,277,33,295,260,2309,565,32,529,33,48,2,301,16,2048,292,545,2309,785,1,257,32,277,544]

theorem envBound28028 : H12AffineFastState.Bounded env28028 := by
  intro p hp
  have h : env28028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28027_28028 : H12AffineEnvironment.transform 6 9 env28027 = env28028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28027 == env28028) = true)

theorem identity28028 : scanCanonicalize (H12AffineFastState.compose env28028 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28028 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28029 : List Nat := [2,4,8,16,32,16,9,5,512,564,2048,544,41,16,33,34,1,2048,565,32,529,33,48,2,40,16,2048,33,545,2048,532,1,4,32,16,544]

theorem envBound28029 : H12AffineFastState.Bounded env28029 := by
  intro p hp
  have h : env28029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28028_28029 : H12AffineEnvironment.transform 7 5 env28028 = env28029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28028 == env28029) = true)

theorem identity28029 : scanCanonicalize (H12AffineFastState.compose env28029 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28029 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28030 : List Nat := [2,4,8,16,1,16,9,5,512,533,2048,513,8,16,0,3,1,2048,532,1,529,0,17,2,9,16,2048,0,512,2048,532,1,4,1,16,513]

theorem envBound28030 : H12AffineFastState.Bounded env28030 := by
  intro p hp
  have h : env28030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28029_28030 : H12AffineEnvironment.transform 4 1 env28029 = env28030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28029 == env28030) = true)

def env28031 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,184320,272513,180224,21763,8328,17,43276,185600,17664,262144,181661,400540,257,21793,46213,145044]

theorem envBound28031 : H12AffineFastState.Bounded env28031 := by
  intro p hp
  have h : env28031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28019_28031 : H12AffineEnvironment.transform 5 17 env28019 = env28031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28019 == env28031) = true)

theorem identity28031 : scanCanonicalize (H12AffineFastState.compose env28031 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound28031 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env28032 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33030,131072,262144,1025,32769,165257,272513,169353,138,8328,17,43276,163977,4233,262144,167956,400540,257,168,46213,145044]

theorem envBound28032 : H12AffineFastState.Bounded env28032 := by
  intro p hp
  have h : env28032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28031_28032 : H12AffineEnvironment.transform 13 5513 env28031 = env28032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env28031 == env28032) = true)

theorem identity28032 : scanCanonicalize (H12AffineFastState.compose env28032 (packedSelected [3,19,24,31] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound28032 : packedSelected [3,19,24,31] rootPS < 2^1333 := by decide +kernel

def env28033 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33030,38297,262144,1025,32769,4112,272513,16,138,8328,17,43276,5392,4233,262144,1421,297221,257,168,46213,41741]

theorem envBound28033 : H12AffineFastState.Bounded env28033 := by
  intro p hp
  have h : env28033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28032_28033 : H12AffineEnvironment.transform 16 38297 env28032 = env28033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env28032 == env28033) = true)

theorem identity28033 : scanCanonicalize (H12AffineFastState.compose env28033 (packedSelected [17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound28033 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env28034 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8581,8323,13340,262144,1025,8580,4112,272513,16,138,8328,17,2185,5392,4233,262144,1421,272512,257,168,5376,648]

theorem envBound28034 : H12AffineFastState.Bounded env28034 := by
  intro p hp
  have h : env28034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28033_28034 : H12AffineEnvironment.transform 14 8581 env28033 = env28034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env28033 == env28034) = true)

theorem identity28034 : scanCanonicalize (H12AffineFastState.compose env28034 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound28034 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env28035 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5156,8232,8323,13340,262144,1025,8233,4112,272513,16,138,8328,17,2185,5309,4233,262144,1056,272512,172,168,5293,648]

theorem envBound28035 : H12AffineFastState.Bounded env28035 := by
  intro p hp
  have h : env28035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28034_28035 : H12AffineEnvironment.transform 7 173 env28034 = env28035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env28034 == env28035) = true)

theorem identity28035 : scanCanonicalize (H12AffineFastState.compose env28035 (packedSelected [6,14] rootPS)) = affineNative (2^(17+1) ^^^ 3125) := by decide +kernel

theorem selectedBound28035 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env28036 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5156,8232,8323,13340,3125,1025,8233,4112,9396,16,138,8328,17,2185,5309,4233,3125,1056,9397,172,168,5293,648]

theorem envBound28036 : H12AffineFastState.Bounded env28036 := by
  intro p hp
  have h : env28036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28035_28036 : H12AffineEnvironment.transform 17 3125 env28035 = env28036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3125 env28035 == env28036) = true)

theorem identity28036 : scanCanonicalize (H12AffineFastState.compose env28036 (packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound28036 : packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS < 2^1333 := by decide +kernel

def env28037 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2064,8192,3124,8232,8323,11276,3125,1025,8233,2048,9396,16,138,8328,17,2185,3245,2201,3125,1056,9397,172,168,3261,648]

theorem envBound28037 : H12AffineFastState.Bounded env28037 := by
  intro p hp
  have h : env28037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28036_28037 : H12AffineEnvironment.transform 11 2064 env28036 = env28037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env28036 == env28037) = true)

theorem identity28037 : scanCanonicalize (H12AffineFastState.compose env28037 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 3221) := by decide +kernel

theorem selectedBound28037 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28038 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2064,3221,3124,3261,3094,153,3125,1025,3260,2048,2081,16,138,3101,17,2185,3245,2201,3125,1056,2080,172,168,3261,648]

theorem envBound28038 : H12AffineFastState.Bounded env28038 := by
  intro p hp
  have h : env28038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28037_28038 : H12AffineEnvironment.transform 12 3221 env28037 = env28038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3221 env28037 == env28038) = true)

theorem identity28038 : scanCanonicalize (H12AffineFastState.compose env28038 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound28038 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env28039 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1076,1060,161,0,137,34,153,1,1025,136,1076,1045,16,138,41,17,1213,153,1197,1,1056,1044,172,168,137,648]

theorem envBound28039 : H12AffineFastState.Bounded env28039 := by
  intro p hp
  have h : env28039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28038_28039 : H12AffineEnvironment.transform 10 1076 env28038 = env28039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env28038 == env28039) = true)

theorem identity28039 : scanCanonicalize (H12AffineFastState.compose env28039 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28039 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28040 : List Nat := [2,4,8,1,32,0,128,173,512,1024,1061,1060,161,0,137,34,136,1,1025,136,1061,1028,1,138,41,0,1196,136,1197,1,1056,1029,172,168,137,648]

theorem envBound28040 : H12AffineFastState.Bounded env28040 := by
  intro p hp
  have h : env28040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28039_28040 : H12AffineEnvironment.transform 3 1 env28039 = env28040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28039 == env28040) = true)

theorem identity28040 : scanCanonicalize (H12AffineFastState.compose env28040 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound28040 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env28041 : List Nat := [2,4,8,1,32,0,128,173,512,173,136,137,161,0,137,34,136,1,172,136,136,169,1,138,41,0,1,136,0,1,141,168,172,168,137,648]

theorem envBound28041 : H12AffineFastState.Bounded env28041 := by
  intro p hp
  have h : env28041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28040_28041 : H12AffineEnvironment.transform 9 173 env28040 = env28041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env28040 == env28041) = true)

theorem identity28041 : scanCanonicalize (H12AffineFastState.compose env28041 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28041 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28042 : List Nat := [2,4,8,1,32,0,8,37,512,37,0,1,41,0,1,34,0,1,36,0,0,33,1,2,41,0,1,0,0,1,5,32,36,32,1,512]

theorem envBound28042 : H12AffineFastState.Bounded env28042 := by
  intro p hp
  have h : env28042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28041_28042 : H12AffineEnvironment.transform 6 8 env28041 = env28042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28041 == env28042) = true)

theorem identity28042 : scanCanonicalize (H12AffineFastState.compose env28042 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound28042 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28043 : List Nat := [2,4,8,1,4,0,8,1,512,1,0,1,13,0,1,6,0,1,0,0,0,5,1,2,13,0,1,0,0,1,5,4,0,4,1,512]

theorem envBound28043 : H12AffineFastState.Bounded env28043 := by
  intro p hp
  have h : env28043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28042_28043 : H12AffineEnvironment.transform 4 4 env28042 = env28043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env28042 == env28043) = true)

theorem identity28043 : scanCanonicalize (H12AffineFastState.compose env28043 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound28043 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28044 : List Nat := [2,4,1,1,4,0,1,1,512,1,0,1,4,0,1,6,0,1,0,0,0,5,1,2,4,0,1,0,0,1,5,4,0,4,1,512]

theorem envBound28044 : H12AffineFastState.Bounded env28044 := by
  intro p hp
  have h : env28044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28043_28044 : H12AffineEnvironment.transform 2 1 env28043 = env28044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env28043 == env28044) = true)

theorem identity28044 : scanCanonicalize (H12AffineFastState.compose env28044 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28044 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28045 : List Nat := [2,2,1,1,2,0,1,1,512,1,0,1,2,0,1,0,0,1,0,0,0,3,1,2,2,0,1,0,0,1,3,2,0,2,1,512]

theorem envBound28045 : H12AffineFastState.Bounded env28045 := by
  intro p hp
  have h : env28045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28044_28045 : H12AffineEnvironment.transform 1 2 env28044 = env28045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28044 == env28045) = true)

theorem identity28045 : scanCanonicalize (H12AffineFastState.compose env28045 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28045 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28046 : List Nat := [2,2,1,1,2,0,1,1,1,1,0,1,2,0,1,0,0,1,0,0,0,3,1,2,2,0,1,0,0,1,3,2,0,2,1,1]

theorem envBound28046 : H12AffineFastState.Bounded env28046 := by
  intro p hp
  have h : env28046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28045_28046 : H12AffineEnvironment.transform 8 1 env28045 = env28046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28045 == env28046) = true)

theorem identity28046 : scanCanonicalize (H12AffineFastState.compose env28046 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28046 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28047 : List Nat := [1,1,1,1,1,0,1,1,1,1,0,1,1,0,1,0,0,1,0,0,0,0,1,1,1,0,1,0,0,1,0,1,0,1,1,1]

theorem envBound28047 : H12AffineFastState.Bounded env28047 := by
  intro p hp
  have h : env28047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28046_28047 : H12AffineEnvironment.transform 0 1 env28046 = env28047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28046 == env28047) = true)

def env28048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180225,98780,8328,64,4489692,185601,17665,262145,181708,4338765,257,21793,46213,254491]

theorem envBound28048 : H12AffineFastState.Bounded env28048 := by
  intro p hp
  have h : env28048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27988_28048 : H12AffineEnvironment.transform 22 180225 env27988 = env28048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env27988 == env28048) = true)

def env28049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180225,98780,8328,64,43356,185601,17665,262145,181708,400589,257,21793,46213,254491]

theorem envBound28049 : H12AffineFastState.Bounded env28049 := by
  intro p hp
  have h : env28049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28048_28049 : H12AffineEnvironment.transform 21 272512 env28048 = env28049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28048 == env28049) = true)

theorem identity28049 : scanCanonicalize (H12AffineFastState.compose env28049 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound28049 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77899,272512,73755,98780,8328,64,43356,79131,17665,262145,75222,392407,257,21793,46213,513]

theorem envBound28050 : H12AffineFastState.Bounded env28050 := by
  intro p hp
  have h : env28050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28049_28050 : H12AffineEnvironment.transform 16 122906 env28049 = env28050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env28049 == env28050) = true)

theorem identity28050 : scanCanonicalize (H12AffineFastState.compose env28050 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound28050 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env28051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67619,1025,32769,77899,73891,73755,98780,8328,64,43356,79131,17665,67618,75222,62708,257,21793,46213,513]

theorem envBound28051 : H12AffineFastState.Bounded env28051 := by
  intro p hp
  have h : env28051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28050_28051 : H12AffineEnvironment.transform 17 67619 env28050 = env28051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env28050 == env28051) = true)

theorem identity28051 : scanCanonicalize (H12AffineFastState.compose env28051 (packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28051 : packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env28052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90138,67619,1025,1,77899,73891,73755,66012,8328,64,10588,79131,17665,67618,75222,29940,257,21793,13445,513]

theorem envBound28052 : H12AffineFastState.Bounded env28052 := by
  intro p hp
  have h : env28052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28051_28052 : H12AffineEnvironment.transform 14 0 env28051 = env28052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28051 == env28052) = true)

def env28053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,90138,67619,1025,1,77899,73771,73755,65876,8192,64,10588,79131,17665,67618,75102,29820,257,21793,13325,513]

theorem envBound28053 : H12AffineFastState.Bounded env28053 := by
  intro p hp
  have h : env28053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28052_28053 : H12AffineEnvironment.transform 6 8 env28052 = env28053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28052 == env28053) = true)

theorem identity28053 : scanCanonicalize (H12AffineFastState.compose env28053 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound28053 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env28054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21591,13389,23668,1025,1,25628,29820,29772,21763,8192,64,10588,24908,17665,23669,28937,29820,257,21793,13325,513]

theorem envBound28054 : H12AffineFastState.Bounded env28054 := by
  intro p hp
  have h : env28054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28053_28054 : H12AffineEnvironment.transform 15 21591 env28053 = env28054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env28053 == env28054) = true)

theorem identity28054 : scanCanonicalize (H12AffineFastState.compose env28054 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28054 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28055 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,21591,5393,23668,1025,1,17728,21792,21776,21763,348,64,2048,16400,17665,23669,20565,21792,257,21793,5457,513]

theorem envBound28055 : H12AffineFastState.Bounded env28055 := by
  intro p hp
  have h : env28055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28054_28055 : H12AffineEnvironment.transform 12 348 env28054 = env28055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28054 == env28055) = true)

theorem identity28055 : scanCanonicalize (H12AffineFastState.compose env28055 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28055 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28056 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5393,2421,1025,1,4161,33,17,2,348,64,2048,5393,4096,2420,1364,33,257,32,5457,513]

theorem envBound28056 : H12AffineFastState.Bounded env28056 := by
  intro p hp
  have h : env28056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28055_28056 : H12AffineEnvironment.transform 13 5377 env28055 = env28056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28055 == env28056) = true)

theorem identity28056 : scanCanonicalize (H12AffineFastState.compose env28056 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound28056 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28057 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,348,1125,0,342,1141,2421,1025,1,293,33,17,2,348,64,2048,1141,356,2420,1364,33,257,32,1077,513]

theorem envBound28057 : H12AffineFastState.Bounded env28057 := by
  intro p hp
  have h : env28057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28056_28057 : H12AffineEnvironment.transform 11 356 env28056 = env28057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env28056 == env28057) = true)

theorem identity28057 : scanCanonicalize (H12AffineFastState.compose env28057 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound28057 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28058 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,356,348,1125,0,342,1141,1296,1025,1,293,33,17,2,348,64,1125,1141,356,1297,1364,33,257,32,1077,513]

theorem envBound28058 : H12AffineFastState.Bounded env28058 := by
  intro p hp
  have h : env28058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28057_28058 : H12AffineEnvironment.transform 10 1125 env28057 = env28058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env28057 == env28058) = true)

theorem identity28058 : scanCanonicalize (H12AffineFastState.compose env28058 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound28058 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env28059 : List Nat := [2,4,8,16,32,64,8,256,308,1024,1125,356,348,1125,0,342,1141,1296,1025,1,293,33,17,2,348,64,1125,1141,356,1297,1364,33,257,32,1077,309]

theorem envBound28059 : H12AffineFastState.Bounded env28059 := by
  intro p hp
  have h : env28059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28058_28059 : H12AffineEnvironment.transform 8 308 env28058 = env28059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env28058 == env28059) = true)

theorem identity28059 : scanCanonicalize (H12AffineFastState.compose env28059 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound28059 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env28060 : List Nat := [2,4,8,16,32,32,8,256,308,1024,1029,260,316,1029,0,310,1045,1296,1025,1,293,33,17,2,316,32,1029,1045,260,1297,1332,33,257,32,1077,309]

theorem envBound28060 : H12AffineFastState.Bounded env28060 := by
  intro p hp
  have h : env28060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28059_28060 : H12AffineEnvironment.transform 5 32 env28059 = env28060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env28059 == env28060) = true)

theorem identity28060 : scanCanonicalize (H12AffineFastState.compose env28060 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28060 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env28061 : List Nat := [2,4,8,16,0,0,8,256,276,1024,1029,260,284,1029,0,278,1045,1296,1025,1,261,1,17,2,284,0,1029,1045,260,1297,1300,1,257,0,1045,277]

theorem envBound28061 : H12AffineFastState.Bounded env28061 := by
  intro p hp
  have h : env28061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28060_28061 : H12AffineEnvironment.transform 4 0 env28060 = env28061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28060 == env28061) = true)

theorem identity28061 : scanCanonicalize (H12AffineFastState.compose env28061 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28061 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env28062 : List Nat := [2,4,8,0,0,0,8,256,260,1024,1029,260,268,1029,0,262,1029,1280,1025,1,261,1,1,2,268,0,1029,1029,260,1281,1284,1,257,0,1029,261]

theorem envBound28062 : H12AffineFastState.Bounded env28062 := by
  intro p hp
  have h : env28062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28061_28062 : H12AffineEnvironment.transform 3 0 env28061 = env28062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28061 == env28062) = true)

theorem identity28062 : scanCanonicalize (H12AffineFastState.compose env28062 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound28062 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28063 : List Nat := [2,4,8,0,0,0,8,256,260,257,260,260,268,260,0,262,260,1,256,1,261,1,1,2,268,0,260,260,260,0,5,1,257,0,260,261]

theorem envBound28063 : H12AffineFastState.Bounded env28063 := by
  intro p hp
  have h : env28063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28062_28063 : H12AffineEnvironment.transform 9 257 env28062 = env28063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env28062 == env28063) = true)

theorem identity28063 : scanCanonicalize (H12AffineFastState.compose env28063 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28063 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28064 : List Nat := [2,4,8,0,0,0,8,5,1,4,1,1,9,1,0,3,1,1,5,1,0,1,1,2,9,0,1,1,1,0,5,1,4,0,1,0]

theorem envBound28064 : H12AffineFastState.Bounded env28064 := by
  intro p hp
  have h : env28064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28063_28064 : H12AffineEnvironment.transform 7 5 env28063 = env28064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28063 == env28064) = true)

def env28065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,90138,67619,1025,1,77899,73770,73755,65877,8193,64,10588,79131,17665,67618,75103,29821,257,21793,13324,513]

theorem envBound28065 : H12AffineFastState.Bounded env28065 := by
  intro p hp
  have h : env28065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28052_28065 : H12AffineEnvironment.transform 6 9 env28052 = env28065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28052 == env28065) = true)

theorem identity28065 : scanCanonicalize (H12AffineFastState.compose env28065 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound28065 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,342,24908,2421,1025,1,12573,8572,8525,3,8193,64,10588,13389,17665,2420,9225,29821,257,21793,13324,513]

theorem envBound28066 : H12AffineFastState.Bounded env28066 := by
  intro p hp
  have h : env28066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28065_28066 : H12AffineEnvironment.transform 15 342 env28065 = env28066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env28065 == env28066) = true)

def env28067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180225,98780,8328,64,43357,185601,17665,262145,181708,400588,257,21793,46213,254491]

theorem envBound28067 : H12AffineFastState.Bounded env28067 := by
  intro p hp
  have h : env28067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28048_28067 : H12AffineEnvironment.transform 21 272513 env28048 = env28067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28048 == env28067) = true)

theorem identity28067 : scanCanonicalize (H12AffineFastState.compose env28067 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28067 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184401,272513,180225,41430,8328,64,43357,185601,17665,262145,181708,400588,257,21793,46213,180753]

theorem envBound28068 : H12AffineFastState.Bounded env28068 := by
  intro p hp
  have h : env28068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28067_28068 : H12AffineEnvironment.transform 15 8202 env28067 = env28068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28067 == env28068) = true)

theorem identity28068 : scanCanonicalize (H12AffineFastState.compose env28068 (packedSelected [1,12,15,16,17,19,20,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound28068 : packedSelected [1,12,15,16,17,19,20,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env28069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190640,1025,32769,184401,180273,180225,41430,8328,64,43357,185601,17665,190641,181708,62588,257,21793,46213,180753]

theorem envBound28069 : H12AffineFastState.Bounded env28069 := by
  intro p hp
  have h : env28069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28068_28069 : H12AffineEnvironment.transform 17 190640 env28068 = env28069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env28068 == env28069) = true)

theorem identity28069 : scanCanonicalize (H12AffineFastState.compose env28069 (packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound28069 : packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env28070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43169,1025,32769,36928,32800,32784,41430,8328,64,43357,38160,17665,43168,34269,62588,257,21793,46213,33280]

theorem envBound28070 : H12AffineFastState.Bounded env28070 := by
  intro p hp
  have h : env28070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28069_28070 : H12AffineEnvironment.transform 16 16401 env28069 = env28070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28069 == env28070) = true)

theorem identity28070 : scanCanonicalize (H12AffineFastState.compose env28070 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28070 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1025,32769,36928,32800,32784,41311,8193,64,43357,38160,17665,43049,34132,62588,257,21793,46092,33280]

theorem envBound28071 : H12AffineFastState.Bounded env28071 := by
  intro p hp
  have h : env28071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28070_28071 : H12AffineEnvironment.transform 6 9 env28070 = env28071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28070 == env28071) = true)

theorem identity28071 : scanCanonicalize (H12AffineFastState.compose env28071 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28071 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,2420,1025,8541,12572,8572,8524,3,8193,64,2049,13388,17665,2421,9224,21792,257,21793,5456,9052]

theorem envBound28072 : H12AffineFastState.Bounded env28072 := by
  intro p hp
  have h : env28072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28071_28072 : H12AffineEnvironment.transform 14 8540 env28071 = env28072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28071 == env28072) = true)

theorem identity28072 : scanCanonicalize (H12AffineFastState.compose env28072 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(13+1) ^^^ 1280) := by decide +kernel

theorem selectedBound28072 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env28073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1280,8540,8202,1297,2420,1025,8541,12572,8572,8524,3,8193,64,2049,13388,1,2421,9224,4128,257,4129,5456,9052]

theorem envBound28073 : H12AffineFastState.Bounded env28073 := by
  intro p hp
  have h : env28073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28072_28073 : H12AffineEnvironment.transform 13 1280 env28072 = env28073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1280 env28072 == env28073) = true)

theorem identity28073 : scanCanonicalize (H12AffineFastState.compose env28073 (packedSelected [4,6,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound28073 : packedSelected [4,6,9,12,15] rootPS < 2^1333 := by decide +kernel

def env28074 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5432,1280,5220,5426,1297,2420,1025,5221,1060,5188,5236,3,5433,64,2049,372,1,2421,4400,4128,257,4129,5456,5732]

theorem envBound28074 : H12AffineFastState.Bounded env28074 := by
  intro p hp
  have h : env28074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28073_28074 : H12AffineEnvironment.transform 12 5432 env28073 = env28074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env28073 == env28074) = true)

theorem identity28074 : scanCanonicalize (H12AffineFastState.compose env28074 (packedSelected [0,2,6,7,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound28074 : packedSelected [0,2,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env28075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,373,1101,1280,1297,1095,1297,2420,1025,1296,1060,1329,1281,3,1100,64,2049,372,1,2421,69,341,257,340,1061,1809]

theorem envBound28075 : H12AffineFastState.Bounded env28075 := by
  intro p hp
  have h : env28075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28074_28075 : H12AffineEnvironment.transform 11 373 env28074 = env28075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env28074 == env28075) = true)

theorem identity28075 : scanCanonicalize (H12AffineFastState.compose env28075 (packedSelected [0,6,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28075 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env28076 : List Nat := [2,4,8,1,32,64,9,256,512,1024,2048,356,1101,1280,1280,1095,1280,2405,1025,1281,1060,1312,1281,3,1100,64,2049,357,1,2404,69,324,257,325,1061,1792]

theorem envBound28076 : H12AffineFastState.Bounded env28076 := by
  intro p hp
  have h : env28076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28075_28076 : H12AffineEnvironment.transform 3 1 env28075 = env28076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28075 == env28076) = true)

theorem identity28076 : scanCanonicalize (H12AffineFastState.compose env28076 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound28076 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28077 : List Nat := [2,4,8,1,32,64,9,256,512,256,2048,356,333,0,0,327,0,2405,257,1,292,32,1,3,332,64,2049,357,1,2404,69,324,257,325,293,512]

theorem envBound28077 : H12AffineFastState.Bounded env28077 := by
  intro p hp
  have h : env28077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28076_28077 : H12AffineEnvironment.transform 9 256 env28076 = env28077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env28076 == env28077) = true)

theorem identity28077 : scanCanonicalize (H12AffineFastState.compose env28077 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound28077 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28078 : List Nat := [2,4,8,1,32,64,9,69,512,69,2048,33,8,0,0,2,0,2080,68,1,97,32,1,3,9,64,2049,32,1,2081,69,1,68,0,96,512]

theorem envBound28078 : H12AffineFastState.Bounded env28078 := by
  intro p hp
  have h : env28078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28077_28078 : H12AffineEnvironment.transform 7 69 env28077 = env28078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env28077 == env28078) = true)

theorem identity28078 : scanCanonicalize (H12AffineFastState.compose env28078 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound28078 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28079 : List Nat := [2,4,8,1,32,64,9,69,32,69,2048,33,8,0,0,2,0,2080,68,1,97,32,1,3,9,64,2049,32,1,2081,69,1,68,0,96,32]

theorem envBound28079 : H12AffineFastState.Bounded env28079 := by
  intro p hp
  have h : env28079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28078_28079 : H12AffineEnvironment.transform 8 32 env28078 = env28079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env28078 == env28079) = true)

theorem identity28079 : scanCanonicalize (H12AffineFastState.compose env28079 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound28079 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28080 : List Nat := [2,4,8,1,32,33,9,36,32,36,2048,33,8,0,0,2,0,2080,37,1,0,32,1,3,9,33,2049,32,1,2081,36,1,37,0,1,32]

theorem envBound28080 : H12AffineFastState.Bounded env28080 := by
  intro p hp
  have h : env28080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28079_28080 : H12AffineEnvironment.transform 5 33 env28079 = env28080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env28079 == env28080) = true)

theorem identity28080 : scanCanonicalize (H12AffineFastState.compose env28080 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28080 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28081 : List Nat := [2,4,8,1,0,1,9,4,0,4,2048,1,8,0,0,2,0,2048,5,1,0,0,1,3,9,1,2049,0,1,2049,4,1,5,0,1,0]

theorem envBound28081 : H12AffineFastState.Bounded env28081 := by
  intro p hp
  have h : env28081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28080_28081 : H12AffineEnvironment.transform 4 0 env28080 = env28081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28080 == env28081) = true)

def env28082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356288,25265169,23160257,525568,27902125,27337993,25733063]

theorem envBound28082 : H12AffineFastState.Bounded env28082 := by
  intro p hp
  have h : env28082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27809_28082 : H12AffineEnvironment.transform 26 30393345 env27809 = env28082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env27809 == env28082) = true)

def env28083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound28083 : H12AffineFastState.Bounded env28083 := by
  intro p hp
  have h : env28083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28082_28083 : H12AffineEnvironment.transform 18 1024 env28082 = env28083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env28082 == env28083) = true)

theorem identity28083 : scanCanonicalize (H12AffineFastState.compose env28083 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2213021) := by decide +kernel

theorem selectedBound28083 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2213021,8328,64,15074460,16400,10507601,8830976,10502284,4235612,256,8388656,8446356,10577754]

theorem envBound28084 : H12AffineFastState.Bounded env28084 := by
  intro p hp
  have h : env28084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28083_28084 : H12AffineEnvironment.transform 23 2213021 env28083 = env28084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2213021 env28083 == env28084) = true)

def env28085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21776,2213021,8328,64,6705548,16400,2097217,431376,2102684,4235612,256,21792,46212,2175562]

theorem envBound28085 : H12AffineFastState.Bounded env28085 := by
  intro p hp
  have h : env28085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28084_28085 : H12AffineEnvironment.transform 22 21776 env28084 = env28085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21776 env28084 == env28085) = true)

def env28086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17864,4194304,21776,98645,8328,64,4592708,16400,17801,431376,20564,4235612,256,21792,46212,96130]

theorem envBound28086 : H12AffineFastState.Bounded env28086 := by
  intro p hp
  have h : env28086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28085_28086 : H12AffineEnvironment.transform 20 17864 env28085 = env28086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env28085 == env28086) = true)

def env28087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,4194304,16,98645,8328,64,4592708,5392,4233,431376,1364,4235612,256,32,46212,74370]

theorem envBound28087 : H12AffineFastState.Bounded env28087 := by
  intro p hp
  have h : env28087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28086_28087 : H12AffineEnvironment.transform 13 5376 env28086 = env28087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28086 == env28087) = true)

theorem identity28087 : scanCanonicalize (H12AffineFastState.compose env28087 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28087 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28088 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,4194304,16,98645,8192,64,4592708,5392,4097,431376,1364,4235612,256,32,46092,74250]

theorem envBound28088 : H12AffineFastState.Bounded env28088 := by
  intro p hp
  have h : env28088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28087_28088 : H12AffineEnvironment.transform 6 8 env28087 = env28088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28087 == env28088) = true)

theorem identity28088 : scanCanonicalize (H12AffineFastState.compose env28088 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28088 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28089 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,4194304,16,41310,8192,64,4592708,5392,4097,431376,1364,4235612,256,32,46092,513]

theorem envBound28089 : H12AffineFastState.Bounded env28089 := by
  intro p hp
  have h : env28089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28088_28089 : H12AffineEnvironment.transform 15 8203 env28088 = env28089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28088 == env28089) = true)

theorem identity28089 : scanCanonicalize (H12AffineFastState.compose env28089 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28089 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env28090 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,4194304,16,2,8192,64,4592708,5392,4097,406604,1364,4194304,256,32,5456,513]

theorem envBound28090 : H12AffineFastState.Bounded env28090 := by
  intro p hp
  have h : env28090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28089_28090 : H12AffineEnvironment.transform 14 8540 env28089 = env28090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28089 == env28090) = true)

theorem identity28090 : scanCanonicalize (H12AffineFastState.compose env28090 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146793) := by decide +kernel

theorem selectedBound28090 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28091 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146793,1024,8541,4160,4194304,16,2,8192,64,4204845,5392,4097,2341,1364,4194304,256,32,5456,513]

theorem envBound28091 : H12AffineFastState.Bounded env28091 := by
  intro p hp
  have h : env28091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28090_28091 : H12AffineEnvironment.transform 17 146793 env28090 = env28091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146793 env28090 == env28091) = true)

theorem identity28091 : scanCanonicalize (H12AffineFastState.compose env28091 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound28091 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env28092 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,146793,1024,8541,4160,136497,16,2,8192,64,146460,5392,4097,2341,1364,136497,256,32,5456,513]

theorem envBound28092 : H12AffineFastState.Bounded env28092 := by
  intro p hp
  have h : env28092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28091_28092 : H12AffineEnvironment.transform 21 136497 env28091 = env28092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env28091 == env28092) = true)

theorem identity28092 : scanCanonicalize (H12AffineFastState.compose env28092 (packedSelected [1,8,12,15,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28092 : packedSelected [1,8,12,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env28093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5392,10361,1024,8541,4160,33,16,2,8192,64,10508,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound28093 : H12AffineFastState.Bounded env28093 := by
  intro p hp
  have h : env28093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28092_28093 : H12AffineEnvironment.transform 16 5392 env28092 = env28093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28092 == env28093) = true)

theorem identity28093 : scanCanonicalize (H12AffineFastState.compose env28093 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 5481) := by decide +kernel

theorem selectedBound28093 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env28094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5481,5376,5173,5474,5392,7440,1024,5172,4160,33,16,2,5481,64,7269,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound28094 : H12AffineFastState.Bounded env28094 := by
  intro p hp
  have h : env28094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28093_28094 : H12AffineEnvironment.transform 12 5481 env28093 = env28094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5481 env28093 == env28094) = true)

theorem identity28094 : scanCanonicalize (H12AffineFastState.compose env28094 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound28094 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env28095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1125,268,357,80,263,373,2421,1024,81,1061,33,16,2,268,64,2048,373,1124,2341,1364,33,256,32,309,513]

theorem envBound28095 : H12AffineFastState.Bounded env28095 := by
  intro p hp
  have h : env28095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28094_28095 : H12AffineEnvironment.transform 11 1125 env28094 = env28095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env28094 == env28095) = true)

theorem identity28095 : scanCanonicalize (H12AffineFastState.compose env28095 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound28095 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env28096 : List Nat := [2,4,8,16,32,64,8,95,512,1024,2048,1125,83,58,80,88,42,2090,1024,81,1061,33,16,2,83,64,2048,42,1124,2170,1035,33,95,32,106,513]

theorem envBound28096 : H12AffineFastState.Bounded env28096 := by
  intro p hp
  have h : env28096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28095_28096 : H12AffineEnvironment.transform 7 95 env28095 = env28096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env28095 == env28096) = true)

theorem identity28096 : scanCanonicalize (H12AffineFastState.compose env28096 (packedSelected [0,5,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28096 : packedSelected [0,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env28097 : List Nat := [2,4,8,16,32,16,8,15,512,1024,2048,1077,3,58,0,8,42,2090,1024,1,1061,33,16,2,3,16,2048,42,1076,2090,1035,33,15,32,58,513]

theorem envBound28097 : H12AffineFastState.Bounded env28097 := by
  intro p hp
  have h : env28097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28096_28097 : H12AffineEnvironment.transform 5 16 env28096 = env28097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28096 == env28097) = true)

theorem identity28097 : scanCanonicalize (H12AffineFastState.compose env28097 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound28097 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28098 : List Nat := [2,4,8,16,32,16,8,15,512,1024,33,1077,3,58,0,8,42,11,1024,1,1061,33,16,2,3,16,33,42,1076,11,1035,33,15,32,58,513]

theorem envBound28098 : H12AffineFastState.Bounded env28098 := by
  intro p hp
  have h : env28098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28097_28098 : H12AffineEnvironment.transform 10 33 env28097 = env28098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env28097 == env28098) = true)

theorem identity28098 : scanCanonicalize (H12AffineFastState.compose env28098 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28098 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28099 : List Nat := [2,4,8,16,32,16,8,15,512,4,33,49,3,58,0,8,42,11,4,1,33,33,16,2,3,16,33,42,48,11,15,33,15,32,58,513]

theorem envBound28099 : H12AffineFastState.Bounded env28099 := by
  intro p hp
  have h : env28099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28098_28099 : H12AffineEnvironment.transform 9 4 env28098 = env28099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28098 == env28099) = true)

def env28100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,4194304,17,98645,8328,64,4592708,5393,4232,431376,1365,4235612,256,33,46212,74371]

theorem envBound28100 : H12AffineFastState.Bounded env28100 := by
  intro p hp
  have h : env28100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28086_28100 : H12AffineEnvironment.transform 13 5377 env28086 = env28100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28086 == env28100) = true)

theorem identity28100 : scanCanonicalize (H12AffineFastState.compose env28100 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound28100 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,32,17,98645,8328,64,398436,5393,4232,431376,1365,41340,256,33,46212,74371]

theorem envBound28101 : H12AffineFastState.Bounded env28101 := by
  intro p hp
  have h : env28101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28100_28101 : H12AffineEnvironment.transform 21 32 env28100 = env28101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env28100 == env28101) = true)

def env28102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,17,98645,8192,64,398436,5393,4096,431376,1365,41340,256,33,46092,74251]

theorem envBound28102 : H12AffineFastState.Bounded env28102 := by
  intro p hp
  have h : env28102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28101_28102 : H12AffineEnvironment.transform 6 8 env28101 = env28102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28101 == env28102) = true)

theorem identity28102 : scanCanonicalize (H12AffineFastState.compose env28102 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound28102 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1024,32769,4161,32,17,98645,8192,64,203847,5393,4096,236851,1365,41340,256,33,46092,74251]

theorem envBound28103 : H12AffineFastState.Bounded env28103 := by
  intro p hp
  have h : env28103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28102_28103 : H12AffineEnvironment.transform 17 67619 env28102 = env28103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env28102 == env28103) = true)

theorem identity28103 : scanCanonicalize (H12AffineFastState.compose env28103 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound28103 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env28104 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,65536,131072,67619,1024,0,4161,32,17,65876,8192,64,203847,5393,4096,204082,1365,8573,256,33,13325,74251]

theorem envBound28104 : H12AffineFastState.Bounded env28104 := by
  intro p hp
  have h : env28104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28103_28104 : H12AffineEnvironment.transform 14 1 env28103 = env28104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env28103 == env28104) = true)

theorem identity28104 : scanCanonicalize (H12AffineFastState.compose env28104 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound28104 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28105 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,65536,70727,67619,1024,0,4161,32,17,65876,8192,64,2048,5393,4096,2421,1365,8573,256,33,13325,74251]

theorem envBound28105 : H12AffineFastState.Bounded env28105 := by
  intro p hp
  have h : env28105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28104_28105 : H12AffineEnvironment.transform 16 70727 env28104 = env28105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env28104 == env28105) = true)

theorem identity28105 : scanCanonicalize (H12AffineFastState.compose env28105 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound28105 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env28106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,262,5441,2341,1024,0,4161,32,17,82,8192,64,2048,5393,4096,2421,1365,8573,256,33,13325,8973]

theorem envBound28106 : H12AffineFastState.Bounded env28106 := by
  intro p hp
  have h : env28106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28105_28106 : H12AffineEnvironment.transform 15 262 env28105 = env28106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env28105 == env28106) = true)

theorem identity28106 : scanCanonicalize (H12AffineFastState.compose env28106 (packedSelected [1,2,3,5,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28106 : packedSelected [1,2,3,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env28107 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,1,262,4177,2341,272,0,4161,32,17,82,8192,64,2048,4097,4096,2421,69,8573,256,33,12573,8973]

theorem envBound28107 : H12AffineFastState.Bounded env28107 := by
  intro p hp
  have h : env28107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28106_28107 : H12AffineEnvironment.transform 9 272 env28106 = env28107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28106 == env28107) = true)

def env28108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,32,17,98645,8193,64,398436,5393,4097,431376,1365,41340,256,33,46093,74250]

theorem envBound28108 : H12AffineFastState.Bounded env28108 := by
  intro p hp
  have h : env28108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28101_28108 : H12AffineEnvironment.transform 6 9 env28101 = env28108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28101 == env28108) = true)

theorem identity28108 : scanCanonicalize (H12AffineFastState.compose env28108 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound28108 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108927,1024,32769,4160,32,17,98645,8193,64,245019,5393,4097,212079,1365,41340,256,33,46093,74250]

theorem envBound28109 : H12AffineFastState.Bounded env28109 := by
  intro p hp
  have h : env28109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28108_28109 : H12AffineEnvironment.transform 17 108927 env28108 = env28109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env28108 == env28109) = true)

theorem identity28109 : scanCanonicalize (H12AffineFastState.compose env28109 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28109 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35188,1024,32769,4160,32,17,41310,8193,64,171280,5393,4097,138340,1365,41340,256,33,46093,513]

theorem envBound28110 : H12AffineFastState.Bounded env28110 := by
  intro p hp
  have h : env28110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28109_28110 : H12AffineEnvironment.transform 15 8203 env28109 = env28110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28109 == env28110) = true)

theorem identity28110 : scanCanonicalize (H12AffineFastState.compose env28110 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 12636) := by decide +kernel

theorem selectedBound28110 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,12636,35188,1024,32769,4160,32,17,41310,8193,64,44108,5393,4097,11576,1365,41340,256,33,46093,513]

theorem envBound28111 : H12AffineFastState.Bounded env28111 := by
  intro p hp
  have h : env28111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28110_28111 : H12AffineEnvironment.transform 16 12636 env28110 = env28111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12636 env28110 == env28111) = true)

theorem identity28111 : scanCanonicalize (H12AffineFastState.compose env28111 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound28111 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env28112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,32768,1095,5392,35188,1024,32769,4160,32,17,34066,1101,64,34816,5393,4097,2420,1365,34096,256,33,36929,513]

theorem envBound28112 : H12AffineFastState.Bounded env28112 := by
  intro p hp
  have h : env28112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28111_28112 : H12AffineEnvironment.transform 12 1100 env28111 = env28112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env28111 == env28112) = true)

theorem identity28112 : scanCanonicalize (H12AffineFastState.compose env28112 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 5685) := by decide +kernel

theorem selectedBound28112 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28113 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,5685,1095,5392,8001,1024,5684,4160,32,17,4903,1101,64,7733,5393,4097,2420,1365,4869,256,33,1652,513]

theorem envBound28113 : H12AffineFastState.Bounded env28113 := by
  intro p hp
  have h : env28113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28112_28113 : H12AffineEnvironment.transform 14 5685 env28112 = env28113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5685 env28112 == env28113) = true)

def env28114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17865,4194304,21776,98644,8328,64,4592709,16400,17800,431376,20565,4235612,256,21792,46212,96131]

theorem envBound28114 : H12AffineFastState.Bounded env28114 := by
  intro p hp
  have h : env28114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28085_28114 : H12AffineEnvironment.transform 20 17865 env28085 = env28114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env28085 == env28114) = true)

def env28115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,4194304,16,98644,8328,64,4592709,5392,4232,431376,1365,4235612,256,32,46212,74371]

theorem envBound28115 : H12AffineFastState.Bounded env28115 := by
  intro p hp
  have h : env28115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28114_28115 : H12AffineEnvironment.transform 13 5376 env28114 = env28115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28114 == env28115) = true)

theorem identity28115 : scanCanonicalize (H12AffineFastState.compose env28115 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28115 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4297,4194304,16,73736,8328,64,4592709,5392,4232,406604,1365,4194304,256,32,5592,74371]

theorem envBound28116 : H12AffineFastState.Bounded env28116 := by
  intro p hp
  have h : env28116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28115_28116 : H12AffineEnvironment.transform 14 8540 env28115 = env28116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28115 == env28116) = true)

theorem identity28116 : scanCanonicalize (H12AffineFastState.compose env28116 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound28116 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,131072,262144,1024,8541,4297,4194304,16,138,8328,64,4592709,5392,4232,406604,1365,4194304,256,32,5592,513]

theorem envBound28117 : H12AffineFastState.Bounded env28117 := by
  intro p hp
  have h : env28117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28116_28117 : H12AffineEnvironment.transform 15 8322 env28116 = env28117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env28116 == env28117) = true)

def env28118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,131072,262144,1024,8541,4297,409024,16,138,8328,64,10629,5392,4232,406604,1365,409024,256,32,5592,513]

theorem envBound28118 : H12AffineFastState.Bounded env28118 := by
  intro p hp
  have h : env28118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28117_28118 : H12AffineEnvironment.transform 21 409024 env28117 = env28118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 409024 env28117 == env28118) = true)

theorem identity28118 : scanCanonicalize (H12AffineFastState.compose env28118 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound28118 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,131072,146792,1024,8541,4297,168,16,138,8328,64,10629,5392,4232,2340,1365,168,256,32,5592,513]

theorem envBound28119 : H12AffineFastState.Bounded env28119 := by
  intro p hp
  have h : env28119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28118_28119 : H12AffineEnvironment.transform 17 146792 env28118 = env28119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env28118 == env28119) = true)

theorem identity28119 : scanCanonicalize (H12AffineFastState.compose env28119 (packedSelected [0,3,4,10,14,18,19,20,22,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound28119 : packedSelected [0,3,4,10,14,18,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env28120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,216,262,131072,138476,1024,217,4297,168,16,138,268,64,2049,5392,4232,2340,1365,168,256,32,5592,513]

theorem envBound28120 : H12AffineFastState.Bounded env28120 := by
  intro p hp
  have h : env28120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28119_28120 : H12AffineEnvironment.transform 12 388 env28119 = env28120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env28119 == env28120) = true)

theorem identity28120 : scanCanonicalize (H12AffineFastState.compose env28120 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound28120 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env28121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,216,262,5393,2557,1024,217,4297,168,16,138,268,64,2049,5392,4232,2340,1365,168,256,32,5592,513]

theorem envBound28121 : H12AffineFastState.Bounded env28121 := by
  intro p hp
  have h : env28121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28120_28121 : H12AffineEnvironment.transform 16 5393 env28120 = env28121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env28120 == env28121) = true)

theorem identity28121 : scanCanonicalize (H12AffineFastState.compose env28121 (packedSelected [0,4,7,9,11,12,18] rootPS)) = affineNative (2^(11+1) ^^^ 3325) := by decide +kernel

theorem selectedBound28121 : packedSelected [0,4,7,9,11,12,18] rootPS < 2^1333 := by decide +kernel

def env28122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3325,388,2557,216,262,2540,2557,1024,217,3124,168,16,138,268,64,2049,2541,3189,2340,1365,168,256,32,2341,513]

theorem envBound28122 : H12AffineFastState.Bounded env28122 := by
  intro p hp
  have h : env28122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28121_28122 : H12AffineEnvironment.transform 11 3325 env28121 = env28122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3325 env28121 == env28122) = true)

theorem identity28122 : scanCanonicalize (H12AffineFastState.compose env28122 (packedSelected [0,3,4,5,7,9,10,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28122 : packedSelected [0,3,4,5,7,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env28123 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2541,388,2557,216,262,2540,2557,272,217,2340,168,16,138,268,64,2049,2541,2405,2340,69,168,256,32,2341,513]

theorem envBound28123 : H12AffineFastState.Bounded env28123 := by
  intro p hp
  have h : env28123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28122_28123 : H12AffineEnvironment.transform 9 272 env28122 = env28123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28122 == env28123) = true)

theorem identity28123 : scanCanonicalize (H12AffineFastState.compose env28123 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28123 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28124 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,2493,388,2477,136,262,2492,2477,272,137,2340,168,16,138,268,16,2049,2493,2357,2340,21,168,256,32,2341,513]

theorem envBound28124 : H12AffineFastState.Bounded env28124 := by
  intro p hp
  have h : env28124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28123_28124 : H12AffineEnvironment.transform 5 16 env28123 = env28124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28123 == env28124) = true)

theorem identity28124 : scanCanonicalize (H12AffineFastState.compose env28124 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound28124 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28125 : List Nat := [2,4,8,16,32,16,128,256,512,272,0,445,388,429,136,262,444,429,272,137,292,168,16,138,268,16,1,445,309,292,21,168,256,32,293,513]

theorem envBound28125 : H12AffineFastState.Bounded env28125 := by
  intro p hp
  have h : env28125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28124_28125 : H12AffineEnvironment.transform 10 0 env28124 = env28125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env28124 == env28125) = true)

def env28126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,131072,262144,1024,8541,4297,409025,16,138,8328,64,10628,5392,4232,406604,1365,409025,256,32,5592,513]

theorem envBound28126 : H12AffineFastState.Bounded env28126 := by
  intro p hp
  have h : env28126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28117_28126 : H12AffineEnvironment.transform 21 409025 env28117 = env28126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 409025 env28117 == env28126) = true)

theorem identity28126 : scanCanonicalize (H12AffineFastState.compose env28126 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146913) := by decide +kernel

theorem selectedBound28126 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8322,131072,146913,1024,8541,4297,32,16,138,8328,64,10628,5392,4232,2477,1365,32,256,32,5592,513]

theorem envBound28127 : H12AffineFastState.Bounded env28127 := by
  intro p hp
  have h : env28127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28126_28127 : H12AffineEnvironment.transform 17 146913 env28126 = env28127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env28126 == env28127) = true)

theorem identity28127 : scanCanonicalize (H12AffineFastState.compose env28127 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28127 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env28128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,81,399,131072,138476,1024,80,4297,32,16,138,389,64,2185,5392,4232,2477,1365,32,256,32,5592,513]

theorem envBound28128 : H12AffineFastState.Bounded env28128 := by
  intro p hp
  have h : env28128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28127_28128 : H12AffineEnvironment.transform 12 269 env28127 = env28128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28127 == env28128) = true)

theorem identity28128 : scanCanonicalize (H12AffineFastState.compose env28128 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound28128 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env28129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,81,399,5528,2420,1024,80,4297,32,16,138,389,64,2185,5392,4232,2477,1365,32,256,32,5592,513]

theorem envBound28129 : H12AffineFastState.Bounded env28129 := by
  intro p hp
  have h : env28129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28128_28129 : H12AffineEnvironment.transform 16 5528 env28128 = env28129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env28128 == env28129) = true)

theorem identity28129 : scanCanonicalize (H12AffineFastState.compose env28129 (packedSelected [3,5,10,11,12,18] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound28129 : packedSelected [3,5,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env28130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,269,5376,81,399,5528,1077,1024,80,4297,32,16,138,389,64,1480,5392,4232,1260,1365,32,256,32,5592,513]

theorem envBound28130 : H12AffineFastState.Bounded env28130 := by
  intro p hp
  have h : env28130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28129_28130 : H12AffineEnvironment.transform 10 1345 env28129 = env28130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env28129 == env28130) = true)

theorem identity28130 : scanCanonicalize (H12AffineFastState.compose env28130 (packedSelected [0,7,11,12,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound28130 : packedSelected [0,7,11,12,15,20] rootPS < 2^1333 := by decide +kernel

def env28131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1141,269,373,81,399,493,1077,1024,80,1212,32,16,138,389,64,1480,357,1277,1260,1365,32,256,32,429,513]

theorem envBound28131 : H12AffineFastState.Bounded env28131 := by
  intro p hp
  have h : env28131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28130_28131 : H12AffineEnvironment.transform 11 1141 env28130 = env28131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env28130 == env28131) = true)

theorem identity28131 : scanCanonicalize (H12AffineFastState.compose env28131 (packedSelected [1,4,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28131 : packedSelected [1,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28132 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1345,1141,269,373,81,343,309,1077,1024,80,1124,32,16,82,349,64,1296,357,1061,1076,1365,32,256,32,373,513]

theorem envBound28132 : H12AffineFastState.Bounded env28132 := by
  intro p hp
  have h : env28132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28131_28132 : H12AffineEnvironment.transform 6 88 env28131 = env28132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28131 == env28132) = true)

theorem identity28132 : scanCanonicalize (H12AffineFastState.compose env28132 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound28132 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env28133 : List Nat := [2,4,8,16,32,64,88,101,512,1024,1060,1141,104,16,81,50,80,1077,1024,80,1124,32,16,82,56,64,1141,0,1061,1076,1072,32,101,32,16,513]

theorem envBound28133 : H12AffineFastState.Bounded env28133 := by
  intro p hp
  have h : env28133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28132_28133 : H12AffineEnvironment.transform 7 101 env28132 = env28133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env28132 == env28133) = true)

def env28134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,4194304,17,98644,8328,64,4592709,5393,4233,431376,1364,4235612,256,33,46212,74370]

theorem envBound28134 : H12AffineFastState.Bounded env28134 := by
  intro p hp
  have h : env28134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28114_28134 : H12AffineEnvironment.transform 13 5377 env28114 = env28134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28114 == env28134) = true)

theorem identity28134 : scanCanonicalize (H12AffineFastState.compose env28134 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41461) := by decide +kernel

end H12CloudChart0