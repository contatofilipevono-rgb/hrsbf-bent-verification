import H12CloudChart0Data103

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity26335 : scanCanonicalize (H12AffineFastState.compose env26335 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26335 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26336 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,4096,40,4112,0,35,4097,0,52,1,4112,33,17,3,41,17,1,4096,4097,1,20,33,37,32,4112,513]

theorem envBound26336 : H12AffineFastState.Bounded env26336 := by
  intro p hp
  have h : env26336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26335_26336 : H12AffineEnvironment.transform 10 1 env26335 = env26336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26335 == env26336) = true)

theorem identity26336 : scanCanonicalize (H12AffineFastState.compose env26336 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound26336 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26337 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,570,40,554,0,35,571,0,52,1,554,33,17,3,41,17,1,570,571,1,20,33,37,32,554,513]

theorem envBound26337 : H12AffineFastState.Bounded env26337 := by
  intro p hp
  have h : env26337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26336_26337 : H12AffineEnvironment.transform 11 570 env26336 = env26337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env26336 == env26337) = true)

theorem identity26337 : scanCanonicalize (H12AffineFastState.compose env26337 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26337 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26338 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,539,9,523,0,2,538,0,21,1,523,0,17,3,8,17,1,539,538,1,20,0,4,1,523,513]

theorem envBound26338 : H12AffineFastState.Bounded env26338 := by
  intro p hp
  have h : env26338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26337_26338 : H12AffineEnvironment.transform 4 1 env26337 = env26338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26337 == env26338) = true)

theorem identity26338 : scanCanonicalize (H12AffineFastState.compose env26338 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound26338 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26339 : List Nat := [2,4,8,16,1,16,9,5,11,20,1,16,9,0,0,2,17,0,21,1,0,0,17,3,8,17,1,16,17,1,20,0,4,1,0,10]

theorem envBound26339 : H12AffineFastState.Bounded env26339 := by
  intro p hp
  have h : env26339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26338_26339 : H12AffineEnvironment.transform 8 11 env26338 = env26339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env26338 == env26339) = true)

theorem identity26339 : scanCanonicalize (H12AffineFastState.compose env26339 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26339 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26340 : List Nat := [2,4,2,16,1,16,3,5,1,20,1,16,3,0,0,2,17,0,21,1,0,0,17,3,2,17,1,16,17,1,20,0,4,1,0,0]

theorem envBound26340 : H12AffineFastState.Bounded env26340 := by
  intro p hp
  have h : env26340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26339_26340 : H12AffineEnvironment.transform 2 2 env26339 = env26340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26339 == env26340) = true)

theorem identity26340 : scanCanonicalize (H12AffineFastState.compose env26340 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26340 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26341 : List Nat := [2,4,2,0,1,0,3,5,1,4,1,0,3,0,0,2,1,0,5,1,0,0,1,3,2,1,1,0,1,1,4,0,4,1,0,0]

theorem envBound26341 : H12AffineFastState.Bounded env26341 := by
  intro p hp
  have h : env26341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26340_26341 : H12AffineEnvironment.transform 3 0 env26340 = env26341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26340 == env26341) = true)

def env26342 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4160,33,73754,41123,8328,65,171244,78959,91262,212079,1193,119927,116,21588,46212,74250]

theorem envBound26342 : H12AffineFastState.Bounded env26342 := by
  intro p hp
  have h : env26342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26326_26342 : H12AffineEnvironment.transform 7 117 env26326 = env26342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26326 == env26342) = true)

def env26343 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,65536,131072,56324,1025,32769,4144,33,73754,41123,8328,49,171164,78879,91150,211999,1193,119815,4,21540,46212,74250]

theorem envBound26343 : H12AffineFastState.Bounded env26343 := by
  intro p hp
  have h : env26343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26342_26343 : H12AffineEnvironment.transform 5 48 env26342 = env26343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env26342 == env26343) = true)

theorem identity26343 : scanCanonicalize (H12AffineFastState.compose env26343 (packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 38045) := by decide +kernel

theorem selectedBound26343 : packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS < 2^1333 := by decide +kernel

def env26344 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,65536,38045,56324,1025,32769,4144,33,73754,41123,8328,49,2049,78879,91150,108674,1193,119815,4,21540,46212,74250]

theorem envBound26344 : H12AffineFastState.Bounded env26344 := by
  intro p hp
  have h : env26344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26343_26344 : H12AffineEnvironment.transform 16 38045 env26343 = env26344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38045 env26343 == env26344) = true)

theorem identity26344 : scanCanonicalize (H12AffineFastState.compose env26344 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26344 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26345 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,8192,16384,32768,65536,37908,56324,1025,32769,4144,33,73754,41002,8193,49,2049,78879,91150,108555,1056,119815,4,21540,46093,74250]

theorem envBound26345 : H12AffineFastState.Bounded env26345 := by
  intro p hp
  have h : env26345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26344_26345 : H12AffineEnvironment.transform 6 9 env26344 = env26345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26344 == env26345) = true)

def env26346 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,65536,131072,56325,1025,32769,4145,33,73754,41123,8328,48,171165,78878,91151,211998,1193,119814,5,21541,46212,74250]

theorem envBound26346 : H12AffineFastState.Bounded env26346 := by
  intro p hp
  have h : env26346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26342_26346 : H12AffineEnvironment.transform 5 49 env26342 = env26346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env26342 == env26346) = true)

theorem identity26346 : scanCanonicalize (H12AffineFastState.compose env26346 (packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound26346 : packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS < 2^1333 := by decide +kernel

def env26347 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,65536,24632,56325,1025,32769,4145,33,73754,41123,8328,48,64677,78878,91151,89126,1193,119814,5,21541,46212,74250]

theorem envBound26347 : H12AffineFastState.Bounded env26347 := by
  intro p hp
  have h : env26347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26346_26347 : H12AffineEnvironment.transform 16 24632 env26346 = env26347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env26346 == env26347) = true)

theorem identity26347 : scanCanonicalize (H12AffineFastState.compose env26347 (packedSelected [0,2,5,7,8,9,10,11,18,20,22,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound26347 : packedSelected [0,2,5,7,8,9,10,11,18,20,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26348 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,13444,32768,65536,5308,43137,1025,32769,4145,33,73754,41123,8328,48,34849,78878,69771,75938,1193,106626,5,8353,46212,74250]

theorem envBound26348 : H12AffineFastState.Bounded env26348 := by
  intro p hp
  have h : env26348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26347_26348 : H12AffineEnvironment.transform 13 13444 env26347 = env26348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env26347 == env26348) = true)

theorem identity26348 : scanCanonicalize (H12AffineFastState.compose env26348 (packedSelected [1,2,4,5,6,8,11,17,19,20,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 41122) := by decide +kernel

theorem selectedBound26348 : packedSelected [1,2,4,5,6,8,11,17,19,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26349 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,13444,32768,41122,5308,43137,1025,32769,4145,33,32952,41123,8328,48,34849,38076,45097,34816,1193,32,5,8353,46212,33448]

theorem envBound26349 : H12AffineFastState.Bounded env26349 := by
  intro p hp
  have h : env26349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26348_26349 : H12AffineEnvironment.transform 15 41122 env26348 = env26349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41122 env26348 == env26349) = true)

theorem identity26349 : scanCanonicalize (H12AffineFastState.compose env26349 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound26349 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env26350 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,13444,8233,139,5308,2216,1025,8232,4145,33,8337,138,8328,48,10248,13461,4096,10281,1193,32,5,8353,5293,8833]

theorem envBound26350 : H12AffineFastState.Bounded env26350 := by
  intro p hp
  have h : env26350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26349_26350 : H12AffineEnvironment.transform 14 8233 env26349 = env26350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env26349 == env26350) = true)

theorem identity26350 : scanCanonicalize (H12AffineFastState.compose env26350 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound26350 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env26351 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8,5260,33,139,5308,2216,1025,32,4145,33,153,138,128,48,2048,5277,4096,2081,1193,32,5,169,5293,649]

theorem envBound26351 : H12AffineFastState.Bounded env26351 := by
  intro p hp
  have h : env26351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26350_26351 : H12AffineEnvironment.transform 12 8 env26350 = env26351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env26350 == env26351) = true)

theorem identity26351 : scanCanonicalize (H12AffineFastState.compose env26351 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound26351 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env26352 : List Nat := [2,4,8,16,32,49,128,4,512,1024,1212,4096,8,5260,33,139,5308,1044,1025,32,4145,33,153,138,128,48,1212,5277,4096,1181,1193,32,5,169,5293,649]

theorem envBound26352 : H12AffineFastState.Bounded env26352 := by
  intro p hp
  have h : env26352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26351_26352 : H12AffineEnvironment.transform 10 1212 env26351 = env26352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env26351 == env26352) = true)

def env26353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,4194304,8388608,8487373,8328,65,4365753,8393984,8406288,8526965,1501,12645452,257,21793,46212,74251]

theorem envBound26353 : H12AffineFastState.Bounded env26353 := by
  intro p hp
  have h : env26353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26295_26353 : H12AffineEnvironment.transform 20 4161 env26295 = env26353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26295 == env26353) = true)

def env26354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,32,8388608,8487373,8328,65,171417,8393984,8406288,8526965,1501,8451180,257,21793,46212,74251]

theorem envBound26354 : H12AffineFastState.Bounded env26354 := by
  intro p hp
  have h : env26354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26353_26354 : H12AffineEnvironment.transform 21 32 env26353 = env26354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26353 == env26354) = true)

theorem identity26354 : scanCanonicalize (H12AffineFastState.compose env26354 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound26354 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,56436,1025,32769,4161,32,8388608,8410386,8328,65,171417,8393984,8406288,8526965,1501,8451180,257,21793,46212,63188]

theorem envBound26355 : H12AffineFastState.Bounded env26355 := by
  intro p hp
  have h : env26355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26354_26355 : H12AffineEnvironment.transform 15 54495 env26354 = env26355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env26354 == env26355) = true)

def env26356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56436,1025,32769,4161,32,8388608,8410386,8192,65,171281,8393984,8406288,8526965,1365,8451180,257,21793,46092,63068]

theorem envBound26356 : H12AffineFastState.Bounded env26356 := by
  intro p hp
  have h : env26356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26355_26356 : H12AffineEnvironment.transform 6 8 env26355 = env26356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26355 == env26356) = true)

theorem identity26356 : scanCanonicalize (H12AffineFastState.compose env26356 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound26356 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26357 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,10281,1025,29788,4161,32,8388608,8410386,8192,65,158028,8393984,8406288,8526965,1365,8388657,257,21793,16465,513]

theorem envBound26357 : H12AffineFastState.Bounded env26357 := by
  intro p hp
  have h : env26357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26356_26357 : H12AffineEnvironment.transform 14 29789 env26356 = env26357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env26356 == env26357) = true)

theorem identity26357 : scanCanonicalize (H12AffineFastState.compose env26357 (packedSelected [1,8,10,11,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound26357 : packedSelected [1,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env26358 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16400,10281,1025,29788,4161,32,8388608,8410386,8192,65,10588,8393984,8406288,8412261,1365,8388657,257,21793,16465,513]

theorem envBound26358 : H12AffineFastState.Bounded env26358 := by
  intro p hp
  have h : env26358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26357_26358 : H12AffineEnvironment.transform 16 16400 env26357 = env26358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env26357 == env26358) = true)

theorem identity26358 : scanCanonicalize (H12AffineFastState.compose env26358 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(22+1) ^^^ 21777) := by decide +kernel

theorem selectedBound26358 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env26359 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16400,10281,1025,29788,4161,32,21777,3,8192,65,10588,16401,4097,2420,1365,21792,257,21793,16465,513]

theorem envBound26359 : H12AffineFastState.Bounded env26359 := by
  intro p hp
  have h : env26359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26358_26359 : H12AffineEnvironment.transform 22 21777 env26358 = env26359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21777 env26358 == env26359) = true)

theorem identity26359 : scanCanonicalize (H12AffineFastState.compose env26359 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound26359 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5392,10281,1025,8540,4161,32,17,3,8192,65,10588,5393,4097,2420,1365,32,257,33,5457,513]

theorem envBound26360 : H12AffineFastState.Bounded env26360 := by
  intro p hp
  have h : env26360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26359_26360 : H12AffineEnvironment.transform 13 5376 env26359 = env26360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26359 == env26360) = true)

theorem identity26360 : scanCanonicalize (H12AffineFastState.compose env26360 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26360 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5392,2420,1025,1,4161,32,17,3,349,65,2049,5393,4097,2420,1365,32,257,33,5457,513]

theorem envBound26361 : H12AffineFastState.Bounded env26361 := by
  intro p hp
  have h : env26361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26360_26361 : H12AffineEnvironment.transform 12 349 env26360 = env26361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26360 == env26361) = true)

theorem identity26361 : scanCanonicalize (H12AffineFastState.compose env26361 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound26361 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1573,349,805,0,343,821,2420,1025,1,1636,32,17,3,349,65,2049,820,1572,2420,1365,32,257,33,884,513]

theorem envBound26362 : H12AffineFastState.Bounded env26362 := by
  intro p hp
  have h : env26362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26361_26362 : H12AffineEnvironment.transform 11 1573 env26361 = env26362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env26361 == env26362) = true)

theorem identity26362 : scanCanonicalize (H12AffineFastState.compose env26362 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound26362 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1572,1573,349,805,0,343,821,1872,1025,1,1636,32,17,3,349,65,1573,820,1572,1872,1365,32,257,33,884,513]

theorem envBound26363 : H12AffineFastState.Bounded env26363 := by
  intro p hp
  have h : env26363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26362_26363 : H12AffineEnvironment.transform 10 1572 env26362 = env26363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env26362 == env26363) = true)

theorem identity26363 : scanCanonicalize (H12AffineFastState.compose env26363 (packedSelected [5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26363 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env26364 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1572,1573,269,805,0,263,821,1792,1025,1,1588,32,17,3,269,17,1573,820,1572,1792,1285,32,257,33,804,513]

theorem envBound26364 : H12AffineFastState.Bounded env26364 := by
  intro p hp
  have h : env26364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26363_26364 : H12AffineEnvironment.transform 5 16 env26363 = env26364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26363 == env26364) = true)

theorem identity26364 : scanCanonicalize (H12AffineFastState.compose env26364 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound26364 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26365 : List Nat := [2,4,8,16,32,16,8,52,512,1024,1572,1573,57,529,0,51,513,1588,1025,1,1588,32,17,3,57,17,1573,512,1572,1588,1073,32,53,33,528,513]

theorem envBound26365 : H12AffineFastState.Bounded env26365 := by
  intro p hp
  have h : env26365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26364_26365 : H12AffineEnvironment.transform 7 52 env26364 = env26365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env26364 == env26365) = true)

theorem identity26365 : scanCanonicalize (H12AffineFastState.compose env26365 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound26365 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26366 : List Nat := [2,4,8,16,32,16,8,52,512,564,16,17,57,529,0,51,513,0,565,1,0,32,17,3,57,17,17,512,16,0,517,32,53,33,528,513]

theorem envBound26366 : H12AffineFastState.Bounded env26366 := by
  intro p hp
  have h : env26366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26365_26366 : H12AffineEnvironment.transform 9 564 env26365 = env26366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env26365 == env26366) = true)

def env26367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56436,1025,32769,4161,32,8388608,8410386,8193,65,171280,8393984,8406288,8526965,1364,8451180,257,21793,46093,63069]

theorem envBound26367 : H12AffineFastState.Bounded env26367 := by
  intro p hp
  have h : env26367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26355_26367 : H12AffineEnvironment.transform 6 9 env26355 = env26367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26355 == env26367) = true)

theorem identity26367 : scanCanonicalize (H12AffineFastState.compose env26367 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound26367 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,29822,131072,31836,1025,8233,4161,32,8388608,8410386,8193,65,146744,8393984,8406288,8526965,1364,8410180,257,21793,5157,22133]

theorem envBound26368 : H12AffineFastState.Bounded env26368 := by
  intro p hp
  have h : env26368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26367_26368 : H12AffineEnvironment.transform 14 8232 env26367 = env26368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env26367 == env26368) = true)

theorem identity26368 : scanCanonicalize (H12AffineFastState.compose env26368 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound26368 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env26369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,29822,5392,31836,1025,8233,4161,32,8388608,8410386,8193,65,10280,8393984,8406288,8391013,1364,8410180,257,21793,5157,22133]

theorem envBound26369 : H12AffineFastState.Bounded env26369 := by
  intro p hp
  have h : env26369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26368_26369 : H12AffineEnvironment.transform 16 5392 env26368 = env26369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env26368 == env26369) = true)

theorem identity26369 : scanCanonicalize (H12AffineFastState.compose env26369 (packedSelected [2,4,9,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound26369 : packedSelected [2,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env26370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8232,8203,5392,10281,1025,8233,4161,32,8388608,8388967,8193,65,10280,8393984,8393061,8391013,1364,8388657,257,340,5157,512]

theorem envBound26370 : H12AffineFastState.Bounded env26370 := by
  intro p hp
  have h : env26370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26369_26370 : H12AffineEnvironment.transform 13 5237 env26369 = env26370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env26369 == env26370) = true)

theorem identity26370 : scanCanonicalize (H12AffineFastState.compose env26370 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26370 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env26371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5237,292,263,5392,2341,1025,293,4161,32,8388608,8388967,269,65,2340,8393984,8393061,8391013,1364,8388657,257,340,5157,512]

theorem envBound26371 : H12AffineFastState.Bounded env26371 := by
  intro p hp
  have h : env26371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26370_26371 : H12AffineEnvironment.transform 12 268 env26370 = env26371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26370 == env26371) = true)

theorem identity26371 : scanCanonicalize (H12AffineFastState.compose env26371 (packedSelected [0,3,5,6,7,10,11] rootPS)) = affineNative (2^(22+1) ^^^ 277) := by decide +kernel

theorem selectedBound26371 : packedSelected [0,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env26372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5237,292,263,5392,2341,1025,293,4161,32,277,114,269,65,2340,5141,4208,2160,1364,292,257,340,5157,512]

theorem envBound26372 : H12AffineFastState.Bounded env26372 := by
  intro p hp
  have h : env26372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26371_26372 : H12AffineEnvironment.transform 22 277 env26371 = env26372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 277 env26371 == env26372) = true)

theorem identity26372 : scanCanonicalize (H12AffineFastState.compose env26372 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound26372 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env26373 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,268,5124,292,263,5392,2341,1025,293,4144,32,277,3,269,48,2340,5141,4097,2049,1317,292,257,293,5157,512]

theorem envBound26373 : H12AffineFastState.Bounded env26373 := by
  intro p hp
  have h : env26373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26372_26373 : H12AffineEnvironment.transform 5 49 env26372 = env26373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env26372 == env26373) = true)

theorem identity26373 : scanCanonicalize (H12AffineFastState.compose env26373 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26373 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env26374 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,8,5124,32,3,5140,2081,1025,33,4144,32,17,3,9,48,2080,5141,4097,2049,1057,32,5,33,5157,512]

theorem envBound26374 : H12AffineFastState.Bounded env26374 := by
  intro p hp
  have h : env26374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26373_26374 : H12AffineEnvironment.transform 7 4 env26373 = env26374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26373 == env26374) = true)

theorem identity26374 : scanCanonicalize (H12AffineFastState.compose env26374 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26374 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env26375 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5124,1,3,5140,2048,1025,0,4113,1,17,3,9,17,2049,5141,4097,2049,1024,1,5,0,5124,512]

theorem envBound26375 : H12AffineFastState.Bounded env26375 := by
  intro p hp
  have h : env26375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26374_26375 : H12AffineEnvironment.transform 4 1 env26374 = env26375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26374 == env26375) = true)

def env26376 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,8,1044,1,3,1028,2048,1025,0,1,1,17,3,9,17,2049,1029,17,2049,1024,1,5,0,1044,512]

theorem envBound26376 : H12AffineFastState.Bounded env26376 := by
  intro p hp
  have h : env26376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26375_26376 : H12AffineEnvironment.transform 11 16 env26375 = env26376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env26375 == env26376) = true)

theorem identity26376 : scanCanonicalize (H12AffineFastState.compose env26376 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound26376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26377 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,0,1,3,16,2048,21,0,1,1,17,3,9,17,2049,17,17,2049,20,1,5,0,0,512]

theorem envBound26377 : H12AffineFastState.Bounded env26377 := by
  intro p hp
  have h : env26377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26376_26377 : H12AffineEnvironment.transform 9 20 env26376 = env26377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26376 == env26377) = true)

theorem identity26377 : scanCanonicalize (H12AffineFastState.compose env26377 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound26377 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26378 : List Nat := [2,4,8,16,1,16,9,4,512,20,20,16,8,0,1,3,16,20,21,0,1,1,17,3,9,17,21,17,17,21,20,1,5,0,0,512]

theorem envBound26378 : H12AffineFastState.Bounded env26378 := by
  intro p hp
  have h : env26378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26377_26378 : H12AffineEnvironment.transform 10 20 env26377 = env26378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env26377 == env26378) = true)

def leafEnv26378 : List Nat := [2,4,8,16,1,16,9,4,512,20,20,16,8,0,1,3,16,20,21,0,1,1,17,3,21,9,1,17,21,17,17,21,20,1,5,0,5,2,0,512,1,1,0]

def active26378 : List Nat := [0,1,2,3,8]

def tree26378 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26378 : H12WitnessSearch.Good tree26378 := H12GlobalWitnessIndex.good

theorem leafIdentity26378 : H12AffineFastState.composeSystem env26378 rootObs = leafEnv26378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26378 rootObs == leafEnv26378) = true)

theorem terminalChecked26378 : H12PackedTerminal.terminalCheckFast leafEnv26378 active26378 tree26378 = true := by decide +kernel

def env26379 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1045,1,3,1029,2048,1025,0,0,1,17,3,9,17,2049,1028,16,2049,1024,1,5,0,1045,512]

theorem envBound26379 : H12AffineFastState.Bounded env26379 := by
  intro p hp
  have h : env26379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26375_26379 : H12AffineEnvironment.transform 11 17 env26375 = env26379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env26375 == env26379) = true)

def env26380 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,8,1,1,3,17,2048,21,0,0,1,17,3,9,17,2049,16,16,2049,20,1,5,0,1,512]

theorem envBound26380 : H12AffineFastState.Bounded env26380 := by
  intro p hp
  have h : env26380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26379_26380 : H12AffineEnvironment.transform 9 20 env26379 = env26380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26379 == env26380) = true)

theorem identity26380 : scanCanonicalize (H12AffineFastState.compose env26380 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound26380 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26381 : List Nat := [2,4,8,16,1,16,9,4,512,20,21,17,8,1,1,3,17,21,21,0,0,1,17,3,9,17,20,16,16,20,20,1,5,0,1,512]

theorem envBound26381 : H12AffineFastState.Bounded env26381 := by
  intro p hp
  have h : env26381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26380_26381 : H12AffineEnvironment.transform 10 21 env26380 = env26381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env26380 == env26381) = true)

def leafEnv26381 : List Nat := [2,4,8,16,1,16,9,4,512,20,21,17,8,1,1,3,17,21,21,0,0,1,17,3,21,9,1,17,20,16,16,20,20,1,5,0,5,2,1,512,1,0,0]

def active26381 : List Nat := [0,1,2,3,8]

def tree26381 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26381 : H12WitnessSearch.Good tree26381 := H12GlobalWitnessIndex.good

theorem leafIdentity26381 : H12AffineFastState.composeSystem env26381 rootObs = leafEnv26381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26381 rootObs == leafEnv26381) = true)

theorem terminalChecked26381 : H12PackedTerminal.terminalCheckFast leafEnv26381 active26381 tree26381 = true := by decide +kernel

def env26382 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,0,1,3,16,2048,20,0,0,1,17,3,9,17,2049,17,16,2049,21,1,5,0,0,512]

theorem envBound26382 : H12AffineFastState.Bounded env26382 := by
  intro p hp
  have h : env26382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26379_26382 : H12AffineEnvironment.transform 9 21 env26379 = env26382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26379 == env26382) = true)

theorem identity26382 : scanCanonicalize (H12AffineFastState.compose env26382 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound26382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26383 : List Nat := [2,4,8,16,1,16,9,4,512,21,542,17,8,0,1,3,16,542,20,0,0,1,17,3,9,17,543,17,16,543,21,1,5,0,0,512]

theorem envBound26383 : H12AffineFastState.Bounded env26383 := by
  intro p hp
  have h : env26383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26382_26383 : H12AffineEnvironment.transform 10 542 env26382 = env26383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env26382 == env26383) = true)

def leafEnv26383 : List Nat := [2,4,8,16,1,16,9,4,512,21,542,17,8,0,1,3,16,542,20,0,0,1,17,3,20,9,1,17,543,17,16,543,21,1,5,0,5,2,0,512,1,0,0]

def active26383 : List Nat := [0,1,2,3,8]

def tree26383 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26383 : H12WitnessSearch.Good tree26383 := H12GlobalWitnessIndex.good

theorem leafIdentity26383 : H12AffineFastState.composeSystem env26383 rootObs = leafEnv26383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26383 rootObs == leafEnv26383) = true)

theorem terminalChecked26383 : H12PackedTerminal.terminalCheckFast leafEnv26383 active26383 tree26383 = true := by decide +kernel

def env26384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,8388608,8487373,8328,65,171416,8393984,8406288,8526965,1501,8451181,257,21793,46212,74251]

theorem envBound26384 : H12AffineFastState.Bounded env26384 := by
  intro p hp
  have h : env26384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26353_26384 : H12AffineEnvironment.transform 21 33 env26353 = env26384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26353 == env26384) = true)

theorem identity26384 : scanCanonicalize (H12AffineFastState.compose env26384 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120014) := by decide +kernel

theorem selectedBound26384 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,120014,21763,8328,65,171416,115150,102878,247995,1501,73891,257,21793,46212,74251]

theorem envBound26385 : H12AffineFastState.Bounded env26385 := by
  intro p hp
  have h : env26385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26384_26385 : H12AffineEnvironment.transform 22 120014 env26384 = env26385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120014 env26384 == env26385) = true)

def env26386 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56356,1025,32769,4113,33,119966,21763,8328,17,171416,115102,102798,247995,1421,73891,257,21793,46212,74251]

theorem envBound26386 : H12AffineFastState.Bounded env26386 := by
  intro p hp
  have h : env26386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26385_26386 : H12AffineEnvironment.transform 5 16 env26385 = env26386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26385 == env26386) = true)

theorem identity26386 : scanCanonicalize (H12AffineFastState.compose env26386 (packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound26386 : packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env26387 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,5529,56356,1025,32769,4113,33,119966,21763,8328,17,34817,115102,102798,122146,1421,73891,257,21793,46212,74251]

theorem envBound26387 : H12AffineFastState.Bounded env26387 := by
  intro p hp
  have h : env26387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26386_26387 : H12AffineEnvironment.transform 16 5529 env26386 = env26387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env26386 == env26387) = true)

theorem identity26387 : scanCanonicalize (H12AffineFastState.compose env26387 (packedSelected [3,4,5,7,8,9,14,27,28,35] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound26387 : packedSelected [3,4,5,7,8,9,14,27,28,35] rootPS < 2^1333 := by decide +kernel

def env26388 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,5529,56356,1025,32769,4113,33,17,21763,8328,17,34817,5393,17665,2477,1421,62508,257,21793,46212,63108]

theorem envBound26388 : H12AffineFastState.Bounded env26388 := by
  intro p hp
  have h : env26388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26387_26388 : H12AffineEnvironment.transform 15 54415 env26387 = env26388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env26387 == env26388) = true)

theorem identity26388 : scanCanonicalize (H12AffineFastState.compose env26388 (packedSelected [0,1,2,3,5,6,7,8,9,12,17,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound26388 : packedSelected [0,1,2,3,5,6,7,8,9,12,17,18,22] rootPS < 2^1333 := by decide +kernel

def env26389 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,32768,40971,5529,43168,1025,32769,4113,33,17,8583,8328,17,34817,5393,12677,2477,1421,32936,257,8613,46212,33280]

theorem envBound26389 : H12AffineFastState.Bounded env26389 := by
  intro p hp
  have h : env26389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26388_26389 : H12AffineEnvironment.transform 13 13444 env26388 = env26389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env26388 == env26389) = true)

theorem identity26389 : scanCanonicalize (H12AffineFastState.compose env26389 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound26389 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env26390 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,8460,263,5529,2476,1025,8461,4113,33,17,8583,8328,17,10509,5393,12677,2477,1421,8612,257,8613,5512,8972]

theorem envBound26390 : H12AffineFastState.Bounded env26390 := by
  intro p hp
  have h : env26390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26389_26390 : H12AffineEnvironment.transform 14 8460 env26389 = env26390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env26389 == env26390) = true)

theorem identity26390 : scanCanonicalize (H12AffineFastState.compose env26390 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1676) := by decide +kernel

theorem selectedBound26390 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26391 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1676,4096,8192,13444,8460,263,5529,1824,1025,8461,4113,33,17,8583,8328,17,10113,5393,12677,1825,1421,8612,257,8613,5512,8972]

theorem envBound26391 : H12AffineFastState.Bounded env26391 := by
  intro p hp
  have h : env26391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26390_26391 : H12AffineEnvironment.transform 10 1676 env26390 = env26391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1676 env26390 == env26391) = true)

theorem identity26391 : scanCanonicalize (H12AffineFastState.compose env26391 (packedSelected [0,1,6,8,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound26391 : packedSelected [0,1,6,8,9,14] rootPS < 2^1333 := by decide +kernel

def env26392 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1676,4096,1336,4540,1076,263,5529,1824,1025,1077,4113,33,17,1215,1456,17,697,5393,5309,1825,1421,1180,257,1181,5512,1588]

theorem envBound26392 : H12AffineFastState.Bounded env26392 := by
  intro p hp
  have h : env26392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26391_26392 : H12AffineEnvironment.transform 12 1336 env26391 = env26392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env26391 == env26392) = true)

theorem identity26392 : scanCanonicalize (H12AffineFastState.compose env26392 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound26392 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env26393 : List Nat := [2,4,8,16,32,16,128,256,512,768,396,4096,568,4540,820,263,4761,32,769,821,4113,33,17,959,688,17,697,4625,5053,33,653,924,257,925,4744,308]

theorem envBound26393 : H12AffineFastState.Bounded env26393 := by
  intro p hp
  have h : env26393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26392_26393 : H12AffineEnvironment.transform 9 768 env26392 = env26393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env26392 == env26393) = true)

theorem identity26393 : scanCanonicalize (H12AffineFastState.compose env26393 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound26393 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env26394 : List Nat := [2,4,8,16,32,16,128,256,512,768,396,561,568,909,820,263,168,32,769,821,544,33,17,959,688,17,697,32,396,33,653,924,257,925,185,308]

theorem envBound26394 : H12AffineFastState.Bounded env26394 := by
  intro p hp
  have h : env26394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26393_26394 : H12AffineEnvironment.transform 11 561 env26393 = env26394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env26393 == env26394) = true)

theorem identity26394 : scanCanonicalize (H12AffineFastState.compose env26394 (packedSelected [0,1,3,5,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound26394 : packedSelected [0,1,3,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env26395 : List Nat := [2,4,8,16,32,16,128,256,308,52,396,261,268,185,0,263,168,32,53,1,276,33,17,139,388,17,397,32,396,33,441,168,257,169,185,308]

theorem envBound26395 : H12AffineFastState.Bounded env26395 := by
  intro p hp
  have h : env26395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26394_26395 : H12AffineEnvironment.transform 8 308 env26394 = env26395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env26394 == env26395) = true)

theorem identity26395 : scanCanonicalize (H12AffineFastState.compose env26395 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound26395 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26396 : List Nat := [2,4,8,16,32,16,3,256,308,52,271,261,268,58,0,263,43,32,53,1,276,33,17,8,263,17,270,32,271,33,314,43,257,42,58,308]

theorem envBound26396 : H12AffineFastState.Bounded env26396 := by
  intro p hp
  have h : env26396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26395_26396 : H12AffineEnvironment.transform 6 3 env26395 = env26396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env26395 == env26396) = true)

theorem identity26396 : scanCanonicalize (H12AffineFastState.compose env26396 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 7) := by decide +kernel

theorem selectedBound26396 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26397 : List Nat := [2,4,8,16,32,16,3,7,51,52,8,2,11,58,0,0,43,32,53,1,19,33,17,8,0,17,9,32,8,33,61,43,6,42,58,51]

theorem envBound26397 : H12AffineFastState.Bounded env26397 := by
  intro p hp
  have h : env26397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26396_26397 : H12AffineEnvironment.transform 7 7 env26396 = env26397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 7 env26396 == env26397) = true)

theorem identity26397 : scanCanonicalize (H12AffineFastState.compose env26397 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26397 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26398 : List Nat := [2,4,8,16,1,16,3,7,18,21,8,2,11,27,0,0,10,1,20,1,19,0,17,8,0,17,9,1,8,0,28,10,6,11,27,18]

theorem envBound26398 : H12AffineFastState.Bounded env26398 := by
  intro p hp
  have h : env26398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26397_26398 : H12AffineEnvironment.transform 4 1 env26397 = env26398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26397 == env26398) = true)

theorem identity26398 : scanCanonicalize (H12AffineFastState.compose env26398 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound26398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26399 : List Nat := [2,1,8,16,1,16,3,2,18,16,8,2,11,27,0,0,10,1,17,1,19,0,17,8,0,17,9,1,8,0,25,10,3,11,27,18]

theorem envBound26399 : H12AffineFastState.Bounded env26399 := by
  intro p hp
  have h : env26399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26398_26399 : H12AffineEnvironment.transform 1 1 env26398 = env26399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env26398 == env26399) = true)

theorem identity26399 : scanCanonicalize (H12AffineFastState.compose env26399 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26399 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26400 : List Nat := [2,1,2,16,1,16,3,2,18,16,2,2,1,17,0,0,0,1,17,1,19,0,17,2,0,17,3,1,2,0,19,0,3,1,17,18]

theorem envBound26400 : H12AffineFastState.Bounded env26400 := by
  intro p hp
  have h : env26400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26399_26400 : H12AffineEnvironment.transform 2 2 env26399 = env26400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26399 == env26400) = true)

theorem identity26400 : scanCanonicalize (H12AffineFastState.compose env26400 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26400 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env26401 : List Nat := [1,1,1,16,1,16,0,1,17,16,1,1,1,17,0,0,0,1,17,1,16,0,17,1,0,17,0,1,1,0,16,0,0,1,17,17]

theorem envBound26401 : H12AffineFastState.Bounded env26401 := by
  intro p hp
  have h : env26401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26400_26401 : H12AffineEnvironment.transform 0 1 env26400 = env26401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26400 == env26401) = true)

def env26402 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56357,1025,32769,4112,33,119967,21763,8328,16,171416,115103,102799,247995,1420,73891,257,21793,46212,74251]

theorem envBound26402 : H12AffineFastState.Bounded env26402 := by
  intro p hp
  have h : env26402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26385_26402 : H12AffineEnvironment.transform 5 17 env26385 = env26402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26385 == env26402) = true)

theorem identity26402 : scanCanonicalize (H12AffineFastState.compose env26402 (packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound26402 : packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env26403 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,79251,56357,1025,32769,4112,33,119967,21763,8328,16,108555,115103,102799,64808,1420,73891,257,21793,46212,74251]

theorem envBound26403 : H12AffineFastState.Bounded env26403 := by
  intro p hp
  have h : env26403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26402_26403 : H12AffineEnvironment.transform 16 79251 env26402 = env26403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env26402 == env26403) = true)

theorem identity26403 : scanCanonicalize (H12AffineFastState.compose env26403 (packedSelected [0,4,7,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound26403 : packedSelected [0,4,7,19,22,26] rootPS < 2^1333 := by decide +kernel

def env26404 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33031,46228,56357,1025,32769,4112,33,21912,21763,8328,16,10508,16536,4232,64808,1420,41380,257,21793,46212,41740]

theorem envBound26404 : H12AffineFastState.Bounded env26404 := by
  intro p hp
  have h : env26404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26403_26404 : H12AffineEnvironment.transform 15 33031 env26403 = env26404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env26403 == env26404) = true)

theorem identity26404 : scanCanonicalize (H12AffineFastState.compose env26404 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound26404 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env26405 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,8202,5529,32040,1025,8460,4112,33,21912,21763,8328,16,10508,16536,4232,23589,1420,169,257,21793,5513,513]

theorem envBound26405 : H12AffineFastState.Bounded env26405 := by
  intro p hp
  have h : env26405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26404_26405 : H12AffineEnvironment.transform 14 8461 env26404 = env26405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env26404 == env26405) = true)

theorem identity26405 : scanCanonicalize (H12AffineFastState.compose env26405 (packedSelected [2,3,5,6,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound26405 : packedSelected [2,3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env26406 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,8368,8202,5156,31893,1025,8369,4112,33,21541,21694,8328,16,10417,16536,4232,23589,1073,169,188,21660,5172,513]

theorem envBound26406 : H12AffineFastState.Bounded env26406 := by
  intro p hp
  have h : env26406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26405_26406 : H12AffineEnvironment.transform 7 189 env26405 = env26406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env26405 == env26406) = true)

theorem identity26406 : scanCanonicalize (H12AffineFastState.compose env26406 (packedSelected [2,3,4,5,6,9,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5172) := by decide +kernel

theorem selectedBound26406 : packedSelected [2,3,4,5,6,9,10,16] rootPS < 2^1333 := by decide +kernel

def env26407 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,5172,8368,8202,5156,10401,1025,8369,4112,33,17,138,8328,16,10417,5292,4232,2065,1073,169,188,168,5172,513]

theorem envBound26407 : H12AffineFastState.Bounded env26407 := by
  intro p hp
  have h : env26407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26406_26407 : H12AffineEnvironment.transform 13 5172 env26406 = env26407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5172 env26406 == env26407) = true)

theorem identity26407 : scanCanonicalize (H12AffineFastState.compose env26407 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26407 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26408 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,4096,8192,5172,8249,8202,5156,10280,1025,8248,4112,33,17,3,8193,16,10296,5157,4097,2065,1073,32,53,33,5172,513]

theorem envBound26408 : H12AffineFastState.Bounded env26408 := by
  intro p hp
  have h : env26408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26407_26408 : H12AffineEnvironment.transform 6 9 env26407 = env26408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26407 == env26408) = true)

theorem identity26408 : scanCanonicalize (H12AffineFastState.compose env26408 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound26408 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26409 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,4096,9,5172,48,3,5156,2081,1025,49,4112,33,17,3,8,16,2097,5157,4097,2065,1073,32,53,33,5172,513]

theorem envBound26409 : H12AffineFastState.Bounded env26409 := by
  intro p hp
  have h : env26409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26408_26409 : H12AffineEnvironment.transform 12 9 env26408 = env26409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env26408 == env26409) = true)

theorem identity26409 : scanCanonicalize (H12AffineFastState.compose env26409 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound26409 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26410 : List Nat := [2,4,8,16,32,17,9,52,512,1024,545,4096,9,5172,48,3,5156,512,1025,49,4112,33,17,3,8,16,528,5157,4097,560,1073,32,53,33,5172,513]

theorem envBound26410 : H12AffineFastState.Bounded env26410 := by
  intro p hp
  have h : env26410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26409_26410 : H12AffineEnvironment.transform 10 545 env26409 = env26410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env26409 == env26410) = true)

theorem identity26410 : scanCanonicalize (H12AffineFastState.compose env26410 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound26410 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26411 : List Nat := [2,4,8,16,32,17,9,52,512,36,545,4096,9,4112,48,3,4096,512,37,49,4112,33,17,3,8,16,528,4097,4097,560,21,32,53,33,4112,513]

theorem envBound26411 : H12AffineFastState.Bounded env26411 := by
  intro p hp
  have h : env26411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26410_26411 : H12AffineEnvironment.transform 9 36 env26410 = env26411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env26410 == env26411) = true)

theorem identity26411 : scanCanonicalize (H12AffineFastState.compose env26411 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound26411 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26412 : List Nat := [2,4,8,16,32,17,9,52,512,36,545,529,9,513,48,3,529,512,37,49,513,33,17,3,8,16,528,528,528,560,21,32,53,33,513,513]

theorem envBound26412 : H12AffineFastState.Bounded env26412 := by
  intro p hp
  have h : env26412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26411_26412 : H12AffineEnvironment.transform 11 529 env26411 = env26412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env26411 == env26412) = true)

theorem identity26412 : scanCanonicalize (H12AffineFastState.compose env26412 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26412 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26413 : List Nat := [2,4,8,16,1,17,9,21,512,5,512,529,9,513,17,3,529,512,4,16,513,0,17,3,8,16,528,528,528,529,21,1,20,0,513,513]

theorem envBound26413 : H12AffineFastState.Bounded env26413 := by
  intro p hp
  have h : env26413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26412_26413 : H12AffineEnvironment.transform 4 1 env26412 = env26413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26412 == env26413) = true)

def env26414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,2097152,4194304,8388608,10588557,8328,65,6458872,8393985,10507601,8526964,2102685,12645453,257,21792,46213,2175563]

theorem envBound26414 : H12AffineFastState.Bounded env26414 := by
  intro p hp
  have h : env26414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26294_26414 : H12AffineEnvironment.transform 17 56437 env26294 = env26414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env26294 == env26414) = true)

def env26415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,4194304,8388608,8487373,8328,65,4365752,8393985,8406289,8526964,1501,12645453,257,21792,46213,74251]

theorem envBound26415 : H12AffineFastState.Bounded env26415 := by
  intro p hp
  have h : env26415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26414_26415 : H12AffineEnvironment.transform 20 4160 env26414 = env26415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env26414 == env26415) = true)

def env26416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,32,8388608,8487373,8328,65,171416,8393985,8406289,8526964,1501,8451181,257,21792,46213,74251]

theorem envBound26416 : H12AffineFastState.Bounded env26416 := by
  intro p hp
  have h : env26416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26415_26416 : H12AffineEnvironment.transform 21 32 env26415 = env26416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26415 == env26416) = true)

theorem identity26416 : scanCanonicalize (H12AffineFastState.compose env26416 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound26416 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1025,29909,4160,32,8388608,8484121,8328,65,158028,8393985,8406289,8526964,1501,8388793,257,21792,16465,74251]

theorem envBound26417 : H12AffineFastState.Bounded env26417 := by
  intro p hp
  have h : env26417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26416_26417 : H12AffineEnvironment.transform 14 29908 env26416 = env26417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env26416 == env26417) = true)

theorem identity26417 : scanCanonicalize (H12AffineFastState.compose env26417 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26417 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env26418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,10401,1025,29909,4160,32,8388608,8410387,8328,65,158028,8393985,8406289,8526964,1501,8388793,257,21792,16465,513]

theorem envBound26418 : H12AffineFastState.Bounded env26418 := by
  intro p hp
  have h : env26418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26417_26418 : H12AffineEnvironment.transform 15 8202 env26417 = env26418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26417 == env26418) = true)

def env26419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8202,131072,10401,1025,8661,4160,32,8388608,8388627,8328,65,146508,8393985,8392721,8526964,1501,8388793,257,32,5457,513]

theorem envBound26419 : H12AffineFastState.Bounded env26419 := by
  intro p hp
  have h : env26419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26418_26419 : H12AffineEnvironment.transform 13 5376 env26418 = env26419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26418 == env26419) = true)

theorem identity26419 : scanCanonicalize (H12AffineFastState.compose env26419 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26419 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10281,1025,8541,4160,32,8388608,8388627,8192,65,146508,8393985,8392721,8526964,1365,8388657,257,32,5457,513]

theorem envBound26420 : H12AffineFastState.Bounded env26420 := by
  intro p hp
  have h : env26420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26419_26420 : H12AffineEnvironment.transform 6 8 env26419 = env26420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26419 == env26420) = true)

theorem identity26420 : scanCanonicalize (H12AffineFastState.compose env26420 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 136448) := by decide +kernel

theorem selectedBound26420 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10281,1025,8541,4160,32,136448,136467,8192,65,146508,131073,132369,2420,1365,136497,257,32,5457,513]

theorem envBound26421 : H12AffineFastState.Bounded env26421 := by
  intro p hp
  have h : env26421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26420_26421 : H12AffineEnvironment.transform 22 136448 env26420 = env26421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env26420 == env26421) = true)

theorem identity26421 : scanCanonicalize (H12AffineFastState.compose env26421 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound26421 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5440,10281,1025,8541,4160,32,64,83,8192,65,10508,5441,4177,2420,1365,113,257,32,5457,513]

theorem envBound26422 : H12AffineFastState.Bounded env26422 := by
  intro p hp
  have h : env26422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26421_26422 : H12AffineEnvironment.transform 16 5440 env26421 = env26422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env26421 == env26422) = true)

theorem identity26422 : scanCanonicalize (H12AffineFastState.compose env26422 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26422 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env26423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,81,263,5440,2340,1025,80,4160,32,64,83,269,65,2049,5441,4177,2420,1365,113,257,32,5457,513]

theorem envBound26423 : H12AffineFastState.Bounded env26423 := by
  intro p hp
  have h : env26423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26422_26423 : H12AffineEnvironment.transform 12 269 env26422 = env26423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26422 == env26423) = true)

theorem identity26423 : scanCanonicalize (H12AffineFastState.compose env26423 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26423 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26424 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,263,5393,2340,1025,1,4113,32,17,2,269,16,2049,5392,4096,2341,1284,32,257,32,5376,513]

theorem envBound26424 : H12AffineFastState.Bounded env26424 := by
  intro p hp
  have h : env26424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26423_26424 : H12AffineEnvironment.transform 5 17 env26423 = env26424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26423 == env26424) = true)

theorem identity26424 : scanCanonicalize (H12AffineFastState.compose env26424 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound26424 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26425 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,16,269,1296,0,263,1281,2340,1025,1,1,32,17,2,269,16,2049,1280,16,2341,1284,32,257,32,1296,513]

theorem envBound26425 : H12AffineFastState.Bounded env26425 := by
  intro p hp
  have h : env26425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26424_26425 : H12AffineEnvironment.transform 11 16 env26424 = env26425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env26424 == env26425) = true)

theorem identity26425 : scanCanonicalize (H12AffineFastState.compose env26425 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound26425 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26426 : List Nat := [2,4,8,16,32,17,8,256,512,1024,522,16,269,1296,0,263,1281,814,1025,1,1,32,17,2,269,16,523,1280,16,815,1284,32,257,32,1296,513]

theorem envBound26426 : H12AffineFastState.Bounded env26426 := by
  intro p hp
  have h : env26426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26425_26426 : H12AffineEnvironment.transform 10 522 env26425 = env26426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env26425 == env26426) = true)

theorem identity26426 : scanCanonicalize (H12AffineFastState.compose env26426 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 826) := by decide +kernel

theorem selectedBound26426 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26427 : List Nat := [2,4,8,16,32,17,8,256,512,826,522,16,269,554,0,263,571,814,827,1,1,32,17,2,269,16,523,570,16,815,574,32,257,32,554,513]

theorem envBound26427 : H12AffineFastState.Bounded env26427 := by
  intro p hp
  have h : env26427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26426_26427 : H12AffineEnvironment.transform 9 826 env26426 = env26427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 826 env26426 == env26427) = true)

theorem identity26427 : scanCanonicalize (H12AffineFastState.compose env26427 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26427 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26428 : List Nat := [2,4,8,16,0,17,8,256,512,794,522,16,269,522,0,263,539,782,795,1,1,0,17,2,269,16,523,538,16,783,542,0,257,0,522,513]

theorem envBound26428 : H12AffineFastState.Bounded env26428 := by
  intro p hp
  have h : env26428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26427_26428 : H12AffineEnvironment.transform 4 0 env26427 = env26428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26427 == env26428) = true)

theorem identity26428 : scanCanonicalize (H12AffineFastState.compose env26428 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound26428 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26429 : List Nat := [2,4,8,16,0,17,8,256,10,272,0,16,269,0,0,263,17,260,273,1,1,0,17,2,269,16,1,16,16,261,20,0,257,0,0,11]

theorem envBound26429 : H12AffineFastState.Bounded env26429 := by
  intro p hp
  have h : env26429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26428_26429 : H12AffineEnvironment.transform 8 10 env26428 = env26429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env26428 == env26429) = true)

theorem identity26429 : scanCanonicalize (H12AffineFastState.compose env26429 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26429 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env26430 : List Nat := [2,4,8,16,0,17,8,5,10,21,0,16,8,0,0,2,17,1,20,1,1,0,17,2,8,16,1,16,16,0,20,0,4,0,0,11]

theorem envBound26430 : H12AffineFastState.Bounded env26430 := by
  intro p hp
  have h : env26430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26429_26430 : H12AffineEnvironment.transform 7 5 env26429 = env26430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26429 == env26430) = true)

theorem identity26430 : scanCanonicalize (H12AffineFastState.compose env26430 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26430 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26431 : List Nat := [2,4,8,5,0,4,8,5,10,0,0,5,8,0,0,2,4,1,1,1,1,0,4,2,8,5,1,5,5,0,1,0,4,0,0,11]

theorem envBound26431 : H12AffineFastState.Bounded env26431 := by
  intro p hp
  have h : env26431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26430_26431 : H12AffineEnvironment.transform 3 5 env26430 = env26431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26430 == env26431) = true)

theorem identity26431 : scanCanonicalize (H12AffineFastState.compose env26431 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26431 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26432 : List Nat := [2,4,4,5,0,4,4,5,6,0,0,5,4,0,0,2,4,1,1,1,1,0,4,2,4,5,1,5,5,0,1,0,4,0,0,7]

theorem envBound26432 : H12AffineFastState.Bounded env26432 := by
  intro p hp
  have h : env26432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26431_26432 : H12AffineEnvironment.transform 2 4 env26431 = env26432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26431 == env26432) = true)

def env26433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,131072,10401,1025,8660,4160,32,8388608,8388626,8328,65,146509,8393985,8392720,8526964,1501,8388793,257,33,5456,513]

theorem envBound26433 : H12AffineFastState.Bounded env26433 := by
  intro p hp
  have h : env26433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26418_26433 : H12AffineEnvironment.transform 13 5377 env26418 = env26433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26418 == env26433) = true)

theorem identity26433 : scanCanonicalize (H12AffineFastState.compose env26433 (packedSelected [1,3,4,5,7,8,9,10,11,12,15,16,18,19,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound26433 : packedSelected [1,3,4,5,7,8,9,10,11,12,15,16,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env26434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,13340,10401,1025,8660,4160,32,8388608,8388626,8328,65,2129,8393985,8392720,8398952,1501,8388793,257,33,5456,513]

theorem envBound26434 : H12AffineFastState.Bounded env26434 := by
  intro p hp
  have h : env26434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26433_26434 : H12AffineEnvironment.transform 16 13340 env26433 = env26434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env26433 == env26434) = true)

theorem identity26434 : scanCanonicalize (H12AffineFastState.compose env26434 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(22+1) ^^^ 65) := by decide +kernel

theorem selectedBound26434 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env26435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,13340,10401,1025,8660,4160,32,65,83,8328,65,2129,5440,4177,10281,1501,248,257,33,5456,513]

theorem envBound26435 : H12AffineFastState.Bounded env26435 := by
  intro p hp
  have h : env26435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26434_26435 : H12AffineEnvironment.transform 22 65 env26434 = env26435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 65 env26434 == env26435) = true)

theorem identity26435 : scanCanonicalize (H12AffineFastState.compose env26435 (packedSelected [0,1,7,8,10,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26435 : packedSelected [0,1,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env26436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,13340,10281,1025,8540,4160,32,65,83,8192,65,2129,5440,4177,10281,1365,112,257,33,5456,513]

theorem envBound26436 : H12AffineFastState.Bounded env26436 := by
  intro p hp
  have h : env26436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26435_26436 : H12AffineEnvironment.transform 6 8 env26435 = env26436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26435 == env26436) = true)

theorem identity26436 : scanCanonicalize (H12AffineFastState.compose env26436 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26436 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env26437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,263,5393,2340,1025,81,4160,32,65,83,269,65,2129,5440,4177,2340,1365,112,257,33,5456,513]

theorem envBound26437 : H12AffineFastState.Bounded env26437 := by
  intro p hp
  have h : env26437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26436_26437 : H12AffineEnvironment.transform 12 269 env26436 = env26437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26436 == env26437) = true)

theorem identity26437 : scanCanonicalize (H12AffineFastState.compose env26437 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound26437 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env26438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1281,269,0,80,263,16,2340,1025,81,1345,32,65,83,269,65,2129,65,1360,2340,1365,112,257,33,81,513]

theorem envBound26438 : H12AffineFastState.Bounded env26438 := by
  intro p hp
  have h : env26438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26437_26438 : H12AffineEnvironment.transform 11 1281 env26437 = env26438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env26437 == env26438) = true)

theorem identity26438 : scanCanonicalize (H12AffineFastState.compose env26438 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound26438 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env26439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,1281,269,0,80,263,16,80,1025,81,1345,32,65,83,269,65,293,65,1360,80,1365,112,257,33,81,513]

theorem envBound26439 : H12AffineFastState.Bounded env26439 := by
  intro p hp
  have h : env26439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26438_26439 : H12AffineEnvironment.transform 10 372 env26438 = env26439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env26438 == env26439) = true)

theorem identity26439 : scanCanonicalize (H12AffineFastState.compose env26439 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound26439 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26440 : List Nat := [2,4,8,16,32,64,8,256,512,321,372,64,269,0,80,263,16,80,320,81,0,32,65,83,269,65,293,65,17,80,20,112,257,33,81,513]

theorem envBound26440 : H12AffineFastState.Bounded env26440 := by
  intro p hp
  have h : env26440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26439_26440 : H12AffineEnvironment.transform 9 321 env26439 = env26440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env26439 == env26440) = true)

theorem identity26440 : scanCanonicalize (H12AffineFastState.compose env26440 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26440 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26441 : List Nat := [2,4,8,16,32,17,8,256,512,272,293,17,269,0,1,263,16,1,273,0,0,32,16,2,269,16,293,16,17,1,20,33,257,33,0,513]

theorem envBound26441 : H12AffineFastState.Bounded env26441 := by
  intro p hp
  have h : env26441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26440_26441 : H12AffineEnvironment.transform 5 17 env26440 = env26441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26440 == env26441) = true)

theorem identity26441 : scanCanonicalize (H12AffineFastState.compose env26441 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26441 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26442 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,17,41,0,1,35,16,1,53,0,0,32,16,2,41,16,1,16,17,1,20,33,37,33,0,513]

theorem envBound26442 : H12AffineFastState.Bounded env26442 := by
  intro p hp
  have h : env26442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26441_26442 : H12AffineEnvironment.transform 7 36 env26441 = env26442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26441 == env26442) = true)

theorem identity26442 : scanCanonicalize (H12AffineFastState.compose env26442 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26442 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26443 : List Nat := [2,4,8,16,16,17,8,20,512,4,1,17,25,0,1,19,16,1,5,0,0,16,16,2,25,16,1,16,17,1,20,17,21,17,0,513]

theorem envBound26443 : H12AffineFastState.Bounded env26443 := by
  intro p hp
  have h : env26443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26442_26443 : H12AffineEnvironment.transform 4 16 env26442 = env26443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26442 == env26443) = true)

def env26444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,8388608,8487373,8328,65,171417,8393985,8406289,8526964,1501,8451180,257,21792,46213,74251]

theorem envBound26444 : H12AffineFastState.Bounded env26444 := by
  intro p hp
  have h : env26444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26415_26444 : H12AffineEnvironment.transform 21 33 env26415 = env26444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26415 == env26444) = true)

theorem identity26444 : scanCanonicalize (H12AffineFastState.compose env26444 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62661) := by decide +kernel

theorem selectedBound26444 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,62661,95496,8328,65,171417,57796,45524,190641,1501,169,257,21792,46213,74251]

theorem envBound26445 : H12AffineFastState.Bounded env26445 := by
  intro p hp
  have h : env26445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26444_26445 : H12AffineEnvironment.transform 22 62661 env26444 = env26445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env26444 == env26445) = true)

def env26446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,62541,95496,8192,65,171281,57676,45404,190521,1365,33,257,21792,46093,74251]

theorem envBound26446 : H12AffineFastState.Bounded env26446 := by
  intro p hp
  have h : env26446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26445_26446 : H12AffineEnvironment.transform 6 8 env26445 = env26446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26445 == env26446) = true)

theorem identity26446 : scanCanonicalize (H12AffineFastState.compose env26446 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound26446 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56437,1025,32769,4160,33,62541,41310,8192,65,171281,57676,45404,190521,1365,33,257,21792,46093,63069]

theorem envBound26447 : H12AffineFastState.Bounded env26447 := by
  intro p hp
  have h : env26447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26446_26447 : H12AffineEnvironment.transform 15 54358 env26446 = env26447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env26446 == env26447) = true)

theorem identity26447 : scanCanonicalize (H12AffineFastState.compose env26447 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound26447 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env26448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,10281,1025,29789,4160,33,17,21762,8192,65,158029,5392,17664,138341,1365,33,257,21792,16465,513]

theorem envBound26448 : H12AffineFastState.Bounded env26448 := by
  intro p hp
  have h : env26448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26447_26448 : H12AffineEnvironment.transform 14 29788 env26447 = env26448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env26447 == env26448) = true)

theorem identity26448 : scanCanonicalize (H12AffineFastState.compose env26448 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound26448 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env26449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,24909,10281,1025,29789,4160,33,17,21762,8192,65,2048,5392,17664,32040,1365,33,257,21792,16465,513]

theorem envBound26449 : H12AffineFastState.Bounded env26449 := by
  intro p hp
  have h : env26449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26448_26449 : H12AffineEnvironment.transform 16 24909 env26448 = env26449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env26448 == env26449) = true)

theorem identity26449 : scanCanonicalize (H12AffineFastState.compose env26449 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26449 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,13388,10281,1025,8540,4160,33,17,3,8192,65,2048,5392,4097,10281,1365,33,257,33,5456,513]

theorem envBound26450 : H12AffineFastState.Bounded env26450 := by
  intro p hp
  have h : env26450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26449_26450 : H12AffineEnvironment.transform 13 5377 env26449 = env26450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26449 == env26450) = true)

theorem identity26450 : scanCanonicalize (H12AffineFastState.compose env26450 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26450 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5393,2420,1025,1,4160,33,17,3,349,65,2048,5392,4097,2420,1365,33,257,33,5456,513]

theorem envBound26451 : H12AffineFastState.Bounded env26451 := by
  intro p hp
  have h : env26451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26450_26451 : H12AffineEnvironment.transform 12 349 env26450 = env26451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26450 == env26451) = true)

theorem identity26451 : scanCanonicalize (H12AffineFastState.compose env26451 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound26451 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26452 : List Nat := [2,4,8,16,32,64,8,256,512,613,2048,4096,349,4964,0,343,4980,2420,612,1,4160,33,17,3,349,65,2048,4981,4097,2420,816,33,257,33,4917,513]

theorem envBound26452 : H12AffineFastState.Bounded env26452 := by
  intro p hp
  have h : env26452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26451_26452 : H12AffineEnvironment.transform 9 613 env26451 = env26452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env26451 == env26452) = true)

theorem identity26452 : scanCanonicalize (H12AffineFastState.compose env26452 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound26452 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26453 : List Nat := [2,4,8,16,32,64,8,256,512,613,2048,373,349,529,0,343,513,2420,612,1,309,33,17,3,349,65,2048,512,372,2420,816,33,257,33,576,513]

theorem envBound26453 : H12AffineFastState.Bounded env26453 := by
  intro p hp
  have h : env26453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26452_26453 : H12AffineEnvironment.transform 11 373 env26452 = env26453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env26452 == env26453) = true)

theorem identity26453 : scanCanonicalize (H12AffineFastState.compose env26453 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound26453 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env26454 : List Nat := [2,4,8,16,32,64,8,85,512,613,2048,32,8,529,0,2,513,2081,612,1,96,33,17,3,8,65,2048,512,33,2081,613,33,84,33,576,513]

theorem envBound26454 : H12AffineFastState.Bounded env26454 := by
  intro p hp
  have h : env26454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26453_26454 : H12AffineEnvironment.transform 7 85 env26453 = env26454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env26453 == env26454) = true)

def env26455 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,62540,95496,8193,65,171280,57677,45405,190520,1364,32,257,21792,46092,74251]

theorem envBound26455 : H12AffineFastState.Bounded env26455 := by
  intro p hp
  have h : env26455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26445_26455 : H12AffineEnvironment.transform 6 9 env26445 = env26455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26445 == env26455) = true)

theorem identity26455 : scanCanonicalize (H12AffineFastState.compose env26455 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound26455 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26456 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,56437,1025,32769,4160,33,62540,3,8193,65,171280,57677,45405,190520,1364,32,257,21792,46092,22272]

theorem envBound26456 : H12AffineFastState.Bounded env26456 := by
  intro p hp
  have h : env26456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26455_26456 : H12AffineEnvironment.transform 15 29963 env26455 = env26456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env26455 == env26456) = true)

theorem identity26456 : scanCanonicalize (H12AffineFastState.compose env26456 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound26456 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env26457 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,5393,56437,1025,32769,4160,33,62540,3,8193,65,34817,57677,45405,64809,1364,32,257,21792,46092,22272]

theorem envBound26457 : H12AffineFastState.Bounded env26457 := by
  intro p hp
  have h : env26457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26456_26457 : H12AffineEnvironment.transform 16 5393 env26456 = env26457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env26456 == env26457) = true)

theorem identity26457 : scanCanonicalize (H12AffineFastState.compose env26457 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26457 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,5393,35188,1025,32769,4160,33,41293,3,8193,65,34817,46156,45405,43048,1364,32,257,33,46092,513]

theorem envBound26458 : H12AffineFastState.Bounded env26458 := by
  intro p hp
  have h : env26458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26457_26458 : H12AffineEnvironment.transform 13 5377 env26457 = env26458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26457 == env26458) = true)

theorem identity26458 : scanCanonicalize (H12AffineFastState.compose env26458 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound26458 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1124,8202,5393,3344,1025,1125,4160,33,9513,3,8193,65,3173,12328,13625,11340,1364,32,257,33,12392,513]

theorem envBound26459 : H12AffineFastState.Bounded env26459 := by
  intro p hp
  have h : env26459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26458_26459 : H12AffineEnvironment.transform 14 1124 env26458 = env26459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env26458 == env26459) = true)

theorem identity26459 : scanCanonicalize (H12AffineFastState.compose env26459 (packedSelected [0,2,4,6,7,9,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26459 : packedSelected [0,2,4,6,7,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env26460 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5236,1124,8202,5220,3173,1025,1125,4160,33,9308,3,8193,65,3173,12328,13388,11340,1057,32,116,33,12392,513]

theorem envBound26460 : H12AffineFastState.Bounded env26460 := by
  intro p hp
  have h : env26460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26459_26460 : H12AffineEnvironment.transform 7 117 env26459 = env26460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26459 == env26460) = true)

theorem identity26460 : scanCanonicalize (H12AffineFastState.compose env26460 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound26460 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env26461 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,8192,4113,1,8202,4097,2048,100,0,4160,33,8249,3,8193,65,2048,12328,12329,10281,68,32,116,33,12392,513]

theorem envBound26461 : H12AffineFastState.Bounded env26461 := by
  intro p hp
  have h : env26461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26460_26461 : H12AffineEnvironment.transform 9 101 env26460 = env26461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env26460 == env26461) = true)

theorem identity26461 : scanCanonicalize (H12AffineFastState.compose env26461 (packedSelected [0,2,5,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 536) := by decide +kernel

theorem selectedBound26461 : packedSelected [0,2,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26462 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,536,4113,1,530,4097,2048,100,0,4160,33,545,3,537,65,2048,4656,4657,2609,68,32,116,33,4720,513]

theorem envBound26462 : H12AffineFastState.Bounded env26462 := by
  intro p hp
  have h : env26462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26461_26462 : H12AffineEnvironment.transform 12 536 env26461 = env26462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env26461 == env26462) = true)

theorem identity26462 : scanCanonicalize (H12AffineFastState.compose env26462 (packedSelected [1,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound26462 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env26463 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,64,536,81,1,530,65,2048,100,0,0,33,545,3,537,65,2048,624,625,2609,68,32,116,33,560,513]

theorem envBound26463 : H12AffineFastState.Bounded env26463 := by
  intro p hp
  have h : env26463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26462_26463 : H12AffineEnvironment.transform 11 64 env26462 = env26463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env26462 == env26463) = true)

theorem identity26463 : scanCanonicalize (H12AffineFastState.compose env26463 (packedSelected [2,7] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound26463 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env26464 : List Nat := [2,4,8,16,32,64,9,117,512,101,608,64,536,81,1,530,65,608,100,0,0,33,545,3,537,65,608,624,625,81,68,32,116,33,560,513]

theorem envBound26464 : H12AffineFastState.Bounded env26464 := by
  intro p hp
  have h : env26464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26463_26464 : H12AffineEnvironment.transform 10 608 env26463 = env26464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env26463 == env26464) = true)

theorem identity26464 : scanCanonicalize (H12AffineFastState.compose env26464 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound26464 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26465 : List Nat := [2,4,8,16,32,64,9,117,48,101,80,64,40,81,1,34,65,80,100,0,0,33,17,3,41,65,80,64,65,81,68,32,116,33,0,49]

theorem envBound26465 : H12AffineFastState.Bounded env26465 := by
  intro p hp
  have h : env26465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26464_26465 : H12AffineEnvironment.transform 8 48 env26464 = env26465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env26464 == env26465) = true)

theorem identity26465 : scanCanonicalize (H12AffineFastState.compose env26465 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound26465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26466 : List Nat := [2,4,8,16,32,48,9,5,48,21,32,48,40,33,1,34,49,32,20,0,0,33,17,3,41,49,32,48,49,33,52,32,4,33,0,49]

theorem envBound26466 : H12AffineFastState.Bounded env26466 := by
  intro p hp
  have h : env26466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26465_26466 : H12AffineEnvironment.transform 5 48 env26465 = env26466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env26465 == env26466) = true)

theorem identity26466 : scanCanonicalize (H12AffineFastState.compose env26466 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26466 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26467 : List Nat := [2,4,3,16,32,48,2,5,48,21,32,48,35,33,1,34,49,32,20,0,0,33,17,3,34,49,32,48,49,33,52,32,4,33,0,49]

theorem envBound26467 : H12AffineFastState.Bounded env26467 := by
  intro p hp
  have h : env26467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26466_26467 : H12AffineEnvironment.transform 2 3 env26466 = env26467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26466 == env26467) = true)

theorem identity26467 : scanCanonicalize (H12AffineFastState.compose env26467 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26467 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26468 : List Nat := [2,4,3,1,32,33,2,5,33,4,32,33,35,33,1,34,32,32,5,0,0,33,0,3,34,32,32,33,32,33,37,32,4,33,0,32]

theorem envBound26468 : H12AffineFastState.Bounded env26468 := by
  intro p hp
  have h : env26468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26467_26468 : H12AffineEnvironment.transform 3 1 env26467 = env26468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26467 == env26468) = true)

theorem identity26468 : scanCanonicalize (H12AffineFastState.compose env26468 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26468 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26469 : List Nat := [2,4,3,1,0,1,2,5,1,4,0,1,3,1,1,2,0,0,5,0,0,1,0,3,2,0,0,1,0,1,5,0,4,1,0,0]

theorem envBound26469 : H12AffineFastState.Bounded env26469 := by
  intro p hp
  have h : env26469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26468_26469 : H12AffineEnvironment.transform 4 0 env26468 = env26469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26468 == env26469) = true)

def env26470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,4194304,8388608,8487372,8328,65,4365753,8393985,8406288,8526964,1500,12645453,257,21792,46213,74250]

theorem envBound26470 : H12AffineFastState.Bounded env26470 := by
  intro p hp
  have h : env26470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26414_26470 : H12AffineEnvironment.transform 20 4161 env26414 = env26470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env26414 == env26470) = true)

def env26471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,32,8388608,8487372,8328,65,171417,8393985,8406288,8526964,1500,8451181,257,21792,46213,74250]

theorem envBound26471 : H12AffineFastState.Bounded env26471 := by
  intro p hp
  have h : env26471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26470_26471 : H12AffineEnvironment.transform 21 32 env26470 = env26471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26470 == env26471) = true)

def env26472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,32,152,98644,8328,65,171417,5529,17800,138476,1500,62709,257,21792,46213,74250]

theorem envBound26472 : H12AffineFastState.Bounded env26472 := by
  intro p hp
  have h : env26472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26471_26472 : H12AffineEnvironment.transform 22 152 env26471 = env26472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env26471 == env26472) = true)

theorem identity26472 : scanCanonicalize (H12AffineFastState.compose env26472 (packedSelected [1,3,4,5,7,8,9,10,12,14,15,16,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound26472 : packedSelected [1,3,4,5,7,8,9,10,12,14,15,16,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,46157,56437,1025,32769,4161,32,152,98644,8328,65,10708,5529,17800,43169,1500,62709,257,21792,46213,74250]

theorem envBound26473 : H12AffineFastState.Bounded env26473 := by
  intro p hp
  have h : env26473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26472_26473 : H12AffineEnvironment.transform 16 46157 env26472 = env26473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env26472 == env26473) = true)

def env26474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46157,35189,1025,32769,4161,32,152,98644,8328,65,10708,5529,4232,43169,1500,41461,257,32,46213,74250]

theorem envBound26474 : H12AffineFastState.Bounded env26474 := by
  intro p hp
  have h : env26474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26473_26474 : H12AffineEnvironment.transform 13 5376 env26473 = env26474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26473 == env26474) = true)

theorem identity26474 : scanCanonicalize (H12AffineFastState.compose env26474 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound26474 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33111,46157,35189,1025,32769,4161,32,152,3,8328,65,10708,5529,4232,43169,1500,41461,257,32,46213,41821]

theorem envBound26475 : H12AffineFastState.Bounded env26475 := by
  intro p hp
  have h : env26475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26474_26475 : H12AffineEnvironment.transform 15 33111 env26474 = env26475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env26474 == env26475) = true)

theorem identity26475 : scanCanonicalize (H12AffineFastState.compose env26475 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26475 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10281,1025,8541,4161,32,152,3,8328,65,10708,5529,4232,2557,1500,169,257,32,5593,513]

theorem envBound26476 : H12AffineFastState.Bounded env26476 := by
  intro p hp
  have h : env26476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26475_26476 : H12AffineEnvironment.transform 14 8540 env26475 = env26476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26475 == env26476) = true)

theorem identity26476 : scanCanonicalize (H12AffineFastState.compose env26476 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound26476 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env26477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,136,479,5393,2557,1025,137,4161,32,152,3,348,65,2048,5529,4232,2557,1500,169,257,32,5593,513]

theorem envBound26477 : H12AffineFastState.Bounded env26477 := by
  intro p hp
  have h : env26477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26476_26477 : H12AffineEnvironment.transform 12 468 env26476 = env26477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env26476 == env26477) = true)

theorem identity26477 : scanCanonicalize (H12AffineFastState.compose env26477 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound26477 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env26478 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5376,80,263,5393,2341,1025,81,4161,32,64,3,348,65,2048,5441,4176,2341,1284,113,257,32,5377,513]

theorem envBound26478 : H12AffineFastState.Bounded env26478 := by
  intro p hp
  have h : env26478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26477_26478 : H12AffineEnvironment.transform 6 88 env26477 = env26478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env26477 == env26478) = true)

def env26479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,46157,35188,1025,32769,4161,32,152,98644,8328,65,10708,5529,4233,43169,1500,41460,257,33,46213,74250]

theorem envBound26479 : H12AffineFastState.Bounded env26479 := by
  intro p hp
  have h : env26479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26473_26479 : H12AffineEnvironment.transform 13 5377 env26473 = env26479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26473 == env26479) = true)

theorem identity26479 : scanCanonicalize (H12AffineFastState.compose env26479 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound26479 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,46157,35188,1025,32769,4161,32,152,138,8328,65,10708,5529,4233,43169,1500,41460,257,33,46213,41940]

theorem envBound26480 : H12AffineFastState.Bounded env26480 := by
  intro p hp
  have h : env26480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26479_26480 : H12AffineEnvironment.transform 15 33246 env26479 = env26480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env26479 == env26480) = true)

theorem identity26480 : scanCanonicalize (H12AffineFastState.compose env26480 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound26480 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env26481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8200,8662,5189,10620,1025,8201,4161,32,152,138,8328,65,10708,5529,4233,2217,1500,508,257,33,5261,988]

theorem envBound26481 : H12AffineFastState.Bounded env26481 := by
  intro p hp
  have h : env26481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26480_26481 : H12AffineEnvironment.transform 14 8200 env26480 = env26481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env26480 == env26481) = true)

theorem identity26481 : scanCanonicalize (H12AffineFastState.compose env26481 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26481 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env26482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8200,8542,5189,10620,1025,8201,4161,32,16,2,8192,65,10588,5393,4097,2081,1364,372,257,33,5125,852]

theorem envBound26482 : H12AffineFastState.Bounded env26482 := by
  intro p hp
  have h : env26482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26481_26482 : H12AffineEnvironment.transform 6 8 env26481 = env26482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26481 == env26482) = true)

theorem identity26482 : scanCanonicalize (H12AffineFastState.compose env26482 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26482 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env26483 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,4096,8192,5125,8200,8282,5189,10360,1025,8201,4161,32,16,2,8192,65,10328,5141,4097,2081,1104,112,5,33,5125,592]

theorem envBound26483 : H12AffineFastState.Bounded env26483 := by
  intro p hp
  have h : env26483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26482_26483 : H12AffineEnvironment.transform 7 4 env26482 = env26483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26482 == env26483) = true)

theorem identity26483 : scanCanonicalize (H12AffineFastState.compose env26483 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound26483 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26484 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,4096,8,5125,0,82,5189,2160,1025,1,4161,32,16,2,8,65,2128,5141,4097,2081,1104,112,5,33,5125,592]

theorem envBound26484 : H12AffineFastState.Bounded env26484 := by
  intro p hp
  have h : env26484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26483_26484 : H12AffineEnvironment.transform 12 8 env26483 = env26484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env26483 == env26484) = true)

theorem identity26484 : scanCanonicalize (H12AffineFastState.compose env26484 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound26484 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env26485 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,1588,8,561,0,82,625,2160,1025,1,1653,32,16,2,8,65,2128,545,1589,2081,1104,112,5,33,561,592]

theorem envBound26485 : H12AffineFastState.Bounded env26485 := by
  intro p hp
  have h : env26485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26484_26485 : H12AffineEnvironment.transform 11 1588 env26484 = env26485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env26484 == env26485) = true)

theorem identity26485 : scanCanonicalize (H12AffineFastState.compose env26485 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound26485 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env26486 : List Nat := [2,4,8,16,32,64,8,4,512,1024,560,1588,8,561,0,82,625,576,1025,1,1653,32,16,2,8,65,608,545,1589,529,1104,112,5,33,561,592]

theorem envBound26486 : H12AffineFastState.Bounded env26486 := by
  intro p hp
  have h : env26486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26485_26486 : H12AffineEnvironment.transform 10 560 env26485 = env26486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env26485 == env26486) = true)

theorem identity26486 : scanCanonicalize (H12AffineFastState.compose env26486 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26486 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env26487 : List Nat := [2,4,8,16,0,64,8,4,512,1024,528,1556,8,529,0,82,593,576,1025,1,1621,0,16,2,8,65,576,513,1557,529,1104,80,5,1,529,592]

theorem envBound26487 : H12AffineFastState.Bounded env26487 := by
  intro p hp
  have h : env26487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26486_26487 : H12AffineEnvironment.transform 4 0 env26486 = env26487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26486 == env26487) = true)

def env26488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,32,153,98645,8328,65,171417,5528,17801,138477,1500,62708,257,21792,46213,74250]

theorem envBound26488 : H12AffineFastState.Bounded env26488 := by
  intro p hp
  have h : env26488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26471_26488 : H12AffineEnvironment.transform 22 153 env26471 = env26488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 153 env26471 == env26488) = true)

def env26489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1025,32769,4161,32,153,98645,8328,65,171417,5528,4233,138477,1500,41460,257,32,46213,74250]

theorem envBound26489 : H12AffineFastState.Bounded env26489 := by
  intro p hp
  have h : env26489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26488_26489 : H12AffineEnvironment.transform 13 5376 env26488 = env26489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26488 == env26489) = true)

theorem identity26489 : scanCanonicalize (H12AffineFastState.compose env26489 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound26489 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,35189,1025,32769,4161,32,153,41430,8328,65,171417,5528,4233,138477,1500,41460,257,32,46213,649]

theorem envBound26490 : H12AffineFastState.Bounded env26490 := by
  intro p hp
  have h : env26490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26489_26490 : H12AffineEnvironment.transform 15 8323 env26489 = env26490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env26489 == env26490) = true)

theorem identity26490 : scanCanonicalize (H12AffineFastState.compose env26490 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26490 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26491 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,35189,1025,32769,4161,32,17,41310,8192,65,171281,5392,4097,138341,1364,41340,257,32,46093,513]

theorem envBound26491 : H12AffineFastState.Bounded env26491 := by
  intro p hp
  have h : env26491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26490_26491 : H12AffineEnvironment.transform 6 8 env26490 = env26491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26490 == env26491) = true)

theorem identity26491 : scanCanonicalize (H12AffineFastState.compose env26491 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound26491 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26492 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,46157,35189,1025,32769,4161,32,17,41310,8192,65,10588,5392,4097,43048,1364,41340,257,32,46093,513]

theorem envBound26492 : H12AffineFastState.Bounded env26492 := by
  intro p hp
  have h : env26492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26491_26492 : H12AffineEnvironment.transform 16 46157 env26491 = env26492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env26491 == env26492) = true)

theorem identity26492 : scanCanonicalize (H12AffineFastState.compose env26492 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26492 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26493 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10281,1025,8541,4161,32,17,2,8192,65,10588,5392,4097,2420,1364,32,257,32,5457,513]

theorem envBound26493 : H12AffineFastState.Bounded env26493 := by
  intro p hp
  have h : env26493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26492_26493 : H12AffineEnvironment.transform 14 8540 env26492 = env26493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26492 == env26493) = true)

theorem identity26493 : scanCanonicalize (H12AffineFastState.compose env26493 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26493 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26494 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8203,5393,10281,1025,8461,4113,32,17,2,8192,17,10508,5392,4097,2340,1284,32,257,32,5377,513]

theorem envBound26494 : H12AffineFastState.Bounded env26494 := by
  intro p hp
  have h : env26494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26493_26494 : H12AffineEnvironment.transform 5 16 env26493 = env26494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26493 == env26494) = true)

theorem identity26494 : scanCanonicalize (H12AffineFastState.compose env26494 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound26494 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26495 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,300,5376,32,295,5393,2309,1025,33,4113,32,17,2,300,17,2080,5392,4097,2340,1284,32,257,32,5377,513]

theorem envBound26495 : H12AffineFastState.Bounded env26495 := by
  intro p hp
  have h : env26495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26494_26495 : H12AffineEnvironment.transform 12 300 env26494 = env26495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env26494 == env26495) = true)

theorem identity26495 : scanCanonicalize (H12AffineFastState.compose env26495 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26495 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26496 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8,5156,32,3,5173,2081,1025,33,4113,32,17,2,8,17,2080,5172,4097,2048,1056,32,37,32,5157,513]

theorem envBound26496 : H12AffineFastState.Bounded env26496 := by
  intro p hp
  have h : env26496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26495_26496 : H12AffineEnvironment.transform 7 36 env26495 = env26496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26495 == env26496) = true)

theorem identity26496 : scanCanonicalize (H12AffineFastState.compose env26496 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound26496 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26497 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,4096,8,5156,32,3,5173,1045,1025,33,4113,32,17,2,8,17,1044,5172,4097,1076,1056,32,37,32,5157,513]

theorem envBound26497 : H12AffineFastState.Bounded env26497 := by
  intro p hp
  have h : env26497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26496_26497 : H12AffineEnvironment.transform 10 1076 env26496 = env26497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env26496 == env26497) = true)

theorem identity26497 : scanCanonicalize (H12AffineFastState.compose env26497 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26497 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26498 : List Nat := [2,4,8,16,32,16,8,36,0,1024,1076,4096,8,5156,32,3,5173,1045,1025,33,4113,32,17,2,8,17,1044,5172,4097,1076,1056,32,37,32,5157,1]

theorem envBound26498 : H12AffineFastState.Bounded env26498 := by
  intro p hp
  have h : env26498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26497_26498 : H12AffineEnvironment.transform 8 0 env26497 = env26498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26497 == env26498) = true)

def env26499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1025,32769,4161,32,153,98645,8328,65,171417,5528,4232,138477,1500,41461,257,33,46213,74250]

theorem envBound26499 : H12AffineFastState.Bounded env26499 := by
  intro p hp
  have h : env26499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26488_26499 : H12AffineEnvironment.transform 13 5377 env26488 = env26499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26488 == env26499) = true)

theorem identity26499 : scanCanonicalize (H12AffineFastState.compose env26499 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26499 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35188,1025,32769,4161,32,153,41310,8328,65,171417,5528,4232,138477,1500,41461,257,33,46213,513]

theorem envBound26500 : H12AffineFastState.Bounded env26500 := by
  intro p hp
  have h : env26500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26499_26500 : H12AffineEnvironment.transform 15 8203 env26499 = env26500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26499 == env26500) = true)

theorem identity26500 : scanCanonicalize (H12AffineFastState.compose env26500 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound26500 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,38296,35188,1025,32769,4161,32,153,41310,8328,65,2049,5528,4232,35189,1500,41461,257,33,46213,513]

theorem envBound26501 : H12AffineFastState.Bounded env26501 := by
  intro p hp
  have h : env26501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26500_26501 : H12AffineEnvironment.transform 16 38296 env26500 = env26501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env26500 == env26501) = true)

theorem identity26501 : scanCanonicalize (H12AffineFastState.compose env26501 (packedSelected [1,4,5,8,9,14,16,24] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound26501 : packedSelected [1,4,5,8,9,14,16,24] rootPS < 2^1333 := by decide +kernel

def env26502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8460,8203,13460,10360,1025,8461,4161,32,153,82,8328,65,2049,5528,4232,10361,1500,249,257,33,5513,513]

theorem envBound26502 : H12AffineFastState.Bounded env26502 := by
  intro p hp
  have h : env26502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26501_26502 : H12AffineEnvironment.transform 14 8460 env26501 = env26502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env26501 == env26502) = true)

theorem identity26502 : scanCanonicalize (H12AffineFastState.compose env26502 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound26502 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env26503 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5372,8433,8203,13460,10360,1025,8432,4161,32,153,82,8328,65,2049,5221,4232,10361,1057,249,252,33,5236,513]

theorem envBound26503 : H12AffineFastState.Bounded env26503 := by
  intro p hp
  have h : env26503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26502_26503 : H12AffineEnvironment.transform 7 253 env26502 = env26503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env26502 == env26503) = true)

theorem identity26503 : scanCanonicalize (H12AffineFastState.compose env26503 (packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound26503 : packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26504 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,240,5372,1,251,5220,2184,1025,0,4161,32,153,82,120,65,2049,5221,4232,2185,1057,249,252,33,5236,513]

theorem envBound26504 : H12AffineFastState.Bounded env26504 := by
  intro p hp
  have h : env26504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26503_26504 : H12AffineEnvironment.transform 12 240 env26503 = env26504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env26503 == env26504) = true)

theorem identity26504 : scanCanonicalize (H12AffineFastState.compose env26504 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound26504 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26505 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1,240,1277,1,251,1125,2184,1025,0,64,32,153,82,120,65,2049,1124,137,2185,1057,249,252,33,1141,513]

theorem envBound26505 : H12AffineFastState.Bounded env26505 := by
  intro p hp
  have h : env26505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26504_26505 : H12AffineEnvironment.transform 11 1 env26504 = env26505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env26504 == env26505) = true)

theorem identity26505 : scanCanonicalize (H12AffineFastState.compose env26505 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26505 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env26506 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1,160,1197,1,171,1077,2184,1025,0,16,32,153,2,40,17,2049,1076,137,2185,1057,169,172,33,1061,513]

theorem envBound26506 : H12AffineFastState.Bounded env26506 := by
  intro p hp
  have h : env26506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26505_26506 : H12AffineEnvironment.transform 5 16 env26505 = env26506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26505 == env26506) = true)

theorem identity26506 : scanCanonicalize (H12AffineFastState.compose env26506 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26506 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26507 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1,40,1061,1,35,1077,2048,1025,0,16,32,17,2,40,17,2049,1076,1,2049,1057,33,36,33,1061,513]

theorem envBound26507 : H12AffineFastState.Bounded env26507 := by
  intro p hp
  have h : env26507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26506_26507 : H12AffineEnvironment.transform 6 8 env26506 = env26507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26506 == env26507) = true)

theorem identity26507 : scanCanonicalize (H12AffineFastState.compose env26507 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26508 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,1,40,17,1,35,1,2048,53,0,16,32,17,2,40,17,2049,0,1,2049,21,33,36,33,17,513]

theorem envBound26508 : H12AffineFastState.Bounded env26508 := by
  intro p hp
  have h : env26508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26507_26508 : H12AffineEnvironment.transform 9 52 env26507 = env26508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26507 == env26508) = true)

theorem identity26508 : scanCanonicalize (H12AffineFastState.compose env26508 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound26508 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26509 : List Nat := [2,4,8,16,32,16,8,37,36,52,2048,1,40,17,1,35,1,2048,53,0,16,32,17,2,40,17,2049,0,1,2049,21,33,36,33,17,37]

theorem envBound26509 : H12AffineFastState.Bounded env26509 := by
  intro p hp
  have h : env26509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26508_26509 : H12AffineEnvironment.transform 8 36 env26508 = env26509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env26508 == env26509) = true)

theorem identity26509 : scanCanonicalize (H12AffineFastState.compose env26509 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound26509 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26510 : List Nat := [2,4,8,16,32,16,8,37,36,52,9,1,40,17,1,35,1,9,53,0,16,32,17,2,40,17,8,0,1,8,21,33,36,33,17,37]

theorem envBound26510 : H12AffineFastState.Bounded env26510 := by
  intro p hp
  have h : env26510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26509_26510 : H12AffineEnvironment.transform 10 9 env26509 = env26510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env26509 == env26510) = true)

theorem identity26510 : scanCanonicalize (H12AffineFastState.compose env26510 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26510 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26511 : List Nat := [1,4,8,16,32,16,8,37,36,52,9,1,40,17,1,32,1,9,53,0,16,32,17,1,40,17,8,0,1,8,21,33,36,33,17,37]

theorem envBound26511 : H12AffineFastState.Bounded env26511 := by
  intro p hp
  have h : env26511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26510_26511 : H12AffineEnvironment.transform 0 1 env26510 = env26511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26510 == env26511) = true)

theorem identity26511 : scanCanonicalize (H12AffineFastState.compose env26511 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound26511 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26512 : List Nat := [1,4,8,16,24,16,8,29,28,12,9,1,16,17,1,24,1,9,13,0,16,24,17,1,16,17,8,0,1,8,21,25,28,25,17,29]

theorem envBound26512 : H12AffineFastState.Bounded env26512 := by
  intro p hp
  have h : env26512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26511_26512 : H12AffineEnvironment.transform 4 24 env26511 = env26512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env26511 == env26512) = true)

def env26513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,8388608,8487372,8328,65,171416,8393985,8406288,8526964,1500,8451180,257,21792,46213,74250]

theorem envBound26513 : H12AffineFastState.Bounded env26513 := by
  intro p hp
  have h : env26513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26470_26513 : H12AffineEnvironment.transform 21 33 env26470 = env26513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26470 == env26513) = true)

theorem identity26513 : scanCanonicalize (H12AffineFastState.compose env26513 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound26513 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,17,98781,8328,65,171416,5392,17665,138341,1500,62589,257,21792,46213,74250]

theorem envBound26514 : H12AffineFastState.Bounded env26514 := by
  intro p hp
  have h : env26514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26513_26514 : H12AffineEnvironment.transform 22 17 env26513 = env26514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env26513 == env26514) = true)

def env26515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,17,98645,8192,65,171280,5392,17665,138341,1364,62589,257,21792,46093,74250]

theorem envBound26515 : H12AffineFastState.Bounded env26515 := by
  intro p hp
  have h : env26515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26514_26515 : H12AffineEnvironment.transform 6 8 env26514 = env26515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26514 == env26515) = true)

theorem identity26515 : scanCanonicalize (H12AffineFastState.compose env26515 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26515 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56437,1025,32769,4161,33,17,41310,8192,65,171280,5392,17665,138341,1364,62589,257,21792,46093,513]

theorem envBound26516 : H12AffineFastState.Bounded env26516 := by
  intro p hp
  have h : env26516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26515_26516 : H12AffineEnvironment.transform 15 8203 env26515 = env26516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26515 == env26516) = true)

theorem identity26516 : scanCanonicalize (H12AffineFastState.compose env26516 (packedSelected [0,2,3,6,7,10,18,20,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound26516 : packedSelected [0,2,3,6,7,10,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26517 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,56437,1025,32769,4161,33,17,41310,8192,65,23809,5392,17665,56436,1364,62589,257,21792,46093,513]

theorem envBound26517 : H12AffineFastState.Bounded env26517 := by
  intro p hp
  have h : env26517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26516_26517 : H12AffineEnvironment.transform 16 49169 env26516 = env26517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env26516 == env26517) = true)

theorem identity26517 : scanCanonicalize (H12AffineFastState.compose env26517 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26517 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26518 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,56356,1025,32769,4112,33,17,41231,8192,16,23809,5392,17665,56357,1285,62508,257,21792,46093,513]

theorem envBound26518 : H12AffineFastState.Bounded env26518 := by
  intro p hp
  have h : env26518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26517_26518 : H12AffineEnvironment.transform 5 17 env26517 = env26518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26517 == env26518) = true)

def env26519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,17,98644,8193,65,171281,5392,17665,138341,1365,62589,257,21792,46092,74250]

theorem envBound26519 : H12AffineFastState.Bounded env26519 := by
  intro p hp
  have h : env26519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26514_26519 : H12AffineEnvironment.transform 6 9 env26514 = env26519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26514 == env26519) = true)

theorem identity26519 : scanCanonicalize (H12AffineFastState.compose env26519 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound26519 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,56437,1025,32769,4161,33,17,3,8193,65,171281,5392,17665,138341,1365,62589,257,21792,46092,41821]

theorem envBound26520 : H12AffineFastState.Bounded env26520 := by
  intro p hp
  have h : env26520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26519_26520 : H12AffineEnvironment.transform 15 33111 env26519 = env26520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env26519 == env26520) = true)

theorem identity26520 : scanCanonicalize (H12AffineFastState.compose env26520 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound26520 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,56437,1025,32769,4161,33,17,3,8193,65,56576,5392,17665,23668,1365,62589,257,21792,46092,41821]

theorem envBound26521 : H12AffineFastState.Bounded env26521 := by
  intro p hp
  have h : env26521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26520_26521 : H12AffineEnvironment.transform 16 16401 env26520 = env26521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env26520 == env26521) = true)

theorem identity26521 : scanCanonicalize (H12AffineFastState.compose env26521 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26521 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,32041,1025,8541,4161,33,17,3,8193,65,31836,5392,17665,23668,1365,21793,257,21792,5456,513]

theorem envBound26522 : H12AffineFastState.Bounded env26522 := by
  intro p hp
  have h : env26522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26521_26522 : H12AffineEnvironment.transform 14 8540 env26521 = env26522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26521 == env26522) = true)

theorem identity26522 : scanCanonicalize (H12AffineFastState.compose env26522 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound26522 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,8203,5441,10361,1025,8541,4161,33,17,3,8193,65,10508,5392,4177,2340,1365,113,257,112,5456,513]

theorem envBound26523 : H12AffineFastState.Bounded env26523 := by
  intro p hp
  have h : env26523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26522_26523 : H12AffineEnvironment.transform 13 5456 env26522 = env26523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env26522 == env26523) = true)

theorem identity26523 : scanCanonicalize (H12AffineFastState.compose env26523 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26523 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26524 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5237,8313,8203,5220,10361,1025,8312,4161,33,17,3,8193,65,10281,5173,4177,2049,1136,113,36,112,5237,513]

theorem envBound26524 : H12AffineFastState.Bounded env26524 := by
  intro p hp
  have h : env26524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26523_26524 : H12AffineEnvironment.transform 7 37 env26523 = env26524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26523 == env26524) = true)

theorem identity26524 : scanCanonicalize (H12AffineFastState.compose env26524 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26524 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26525 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,8192,4160,8313,8203,4177,10361,52,8312,4161,33,17,3,8193,65,10281,4096,4177,2049,69,113,36,112,4160,513]

theorem envBound26525 : H12AffineFastState.Bounded env26525 := by
  intro p hp
  have h : env26525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26524_26525 : H12AffineEnvironment.transform 9 53 env26524 = env26525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26524 == env26525) = true)

theorem identity26525 : scanCanonicalize (H12AffineFastState.compose env26525 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound26525 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env26526 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2113,8192,2049,8313,8203,2064,10361,52,8312,2048,33,17,3,8193,65,10281,2113,2064,2049,69,113,36,112,2049,513]

theorem envBound26526 : H12AffineFastState.Bounded env26526 := by
  intro p hp
  have h : env26526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26525_26526 : H12AffineEnvironment.transform 11 2113 env26525 = env26526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env26525 == env26526) = true)

theorem identity26526 : scanCanonicalize (H12AffineFastState.compose env26526 (packedSelected [0,2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound26526 : packedSelected [0,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26527 : List Nat := [2,4,8,16,32,64,9,37,512,53,113,48,8192,112,8313,8203,97,8200,52,8312,113,33,17,3,8193,65,8280,48,97,112,69,113,36,112,112,513]

theorem envBound26527 : H12AffineFastState.Bounded env26527 := by
  intro p hp
  have h : env26527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26526_26527 : H12AffineEnvironment.transform 10 113 env26526 = env26527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env26526 == env26527) = true)

def env26528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374097,4294967296,525568,4308116844,27337993,25733063]

theorem envBound26528 : H12AffineFastState.Bounded env26528 := by
  intro p hp
  have h : env26528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20771_26528 : H12AffineEnvironment.transform 28 77616401 env20771 = env26528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616401 env20771 == env26528) = true)

def env26529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound26529 : H12AffineFastState.Bounded env26529 := by
  intro p hp
  have h : env26529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26528_26529 : H12AffineEnvironment.transform 31 145662400 env26528 = env26529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env26528 == env26529) = true)

def env26530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254784,92374097,145662400,525568,140903596,27337993,25733063]

theorem envBound26530 : H12AffineFastState.Bounded env26530 := by
  intro p hp
  have h : env26530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26529_26530 : H12AffineEnvironment.transform 29 155254784 env26529 = env26530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env26529 == env26530) = true)

def env26531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254784,25265169,145662400,525568,140903596,27337993,25733063]

theorem envBound26531 : H12AffineFastState.Bounded env26531 := by
  intro p hp
  have h : env26531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26530_26531 : H12AffineEnvironment.transform 25 64 env26530 = env26531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env26530 == env26531) = true)

def env26532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356288,25265169,23160256,525568,27902124,27337993,25733063]

theorem envBound26532 : H12AffineFastState.Bounded env26532 := by
  intro p hp
  have h : env26532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26531_26532 : H12AffineEnvironment.transform 26 30393344 env26531 = env26532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env26531 == env26532) = true)

def env26533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265169,23160256,256,27378860,27337993,25207751]

theorem envBound26533 : H12AffineFastState.Bounded env26533 := by
  intro p hp
  have h : env26533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26532_26533 : H12AffineEnvironment.transform 18 1024 env26532 = env26533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env26532 == env26533) = true)

theorem identity26533 : scanCanonicalize (H12AffineFastState.compose env26533 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound26533 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,41292,16777216,8328,64,21455180,18973837,2159645,418124,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound26534 : H12AffineFastState.Bounded env26534 := by
  intro p hp
  have h : env26534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26533_26534 : H12AffineEnvironment.transform 22 41292 env26533 = env26534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env26533 == env26534) = true)

def env26535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,262144,1024,32769,2097152,4194304,41292,16777216,8328,64,21331968,18973837,2159645,294912,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound26535 : H12AffineFastState.Bounded env26535 := by
  intro p hp
  have h : env26535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26534_26535 : H12AffineEnvironment.transform 16 57676 env26534 = env26535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env26534 == env26535) = true)

theorem identity26535 : scanCanonicalize (H12AffineFastState.compose env26535 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound26535 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env26536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,262144,1024,32769,2097152,4194304,41292,138,8328,64,4554890,2196487,2159645,294912,75223,6382922,256,2188650,2196687,513]

theorem envBound26536 : H12AffineFastState.Bounded env26536 := by
  intro p hp
  have h : env26536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26535_26536 : H12AffineEnvironment.transform 23 138 env26535 = env26536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env26535 == env26536) = true)

def env26537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,138,8328,64,4303010,2196487,2159645,43048,75223,6382922,256,2188650,2196687,513]

theorem envBound26537 : H12AffineFastState.Bounded env26537 := by
  intro p hp
  have h : env26537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26536_26537 : H12AffineEnvironment.transform 17 10280 env26536 = env26537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26536 == env26537) = true)

def env26538 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,2,8192,64,4302890,2196487,2159645,43048,75103,6382922,256,2188650,2196551,513]

theorem envBound26538 : H12AffineFastState.Bounded env26538 := by
  intro p hp
  have h : env26538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26537_26538 : H12AffineEnvironment.transform 6 8 env26537 = env26538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26537 == env26538) = true)

theorem identity26538 : scanCanonicalize (H12AffineFastState.compose env26538 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound26538 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26539 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,10280,1024,32769,2097152,4194304,41292,2,8192,64,4204924,2098513,2159645,43048,41993,6349852,256,2155580,2098449,513]

theorem envBound26539 : H12AffineFastState.Bounded env26539 := by
  intro p hp
  have h : env26539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26538_26539 : H12AffineEnvironment.transform 15 33110 env26538 = env26539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env26538 == env26539) = true)

theorem identity26539 : scanCanonicalize (H12AffineFastState.compose env26539 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound26539 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env26540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,33110,45404,10280,1024,32769,2097152,4194304,41292,2,8192,64,4204924,2098513,2139149,43048,41993,6337548,256,2143276,2098449,513]

theorem envBound26540 : H12AffineFastState.Bounded env26540 := by
  intro p hp
  have h : env26540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26539_26540 : H12AffineEnvironment.transform 13 4112 env26539 = env26540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env26539 == env26540) = true)

theorem identity26540 : scanCanonicalize (H12AffineFastState.compose env26540 (packedSelected [11,17,23] rootPS)) = affineNative (2^(21+1) ^^^ 9325) := by decide +kernel

theorem selectedBound26540 : packedSelected [11,17,23] rootPS < 2^1333 := by decide +kernel

def env26541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,33110,45404,10280,1024,32769,2097152,9325,41292,2,8192,64,3345,2098513,2139149,43048,41993,2134113,256,2143276,2098449,513]

theorem envBound26541 : H12AffineFastState.Bounded env26541 := by
  intro p hp
  have h : env26541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26540_26541 : H12AffineEnvironment.transform 21 9325 env26540 = env26541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9325 env26540 == env26541) = true)

theorem identity26541 : scanCanonicalize (H12AffineFastState.compose env26541 (packedSelected [4,7,9,11,17,18,27] rootPS)) = affineNative (2^(20+1) ^^^ 46172) := by decide +kernel

theorem selectedBound26541 : packedSelected [4,7,9,11,17,18,27] rootPS < 2^1333 := by decide +kernel

def env26542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,32768,33110,45404,10280,1024,32769,46172,9325,41292,2,8192,64,3345,45325,4177,43048,41993,9277,256,112,45389,513]

theorem envBound26542 : H12AffineFastState.Bounded env26542 := by
  intro p hp
  have h : env26542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26541_26542 : H12AffineEnvironment.transform 20 46172 env26541 = env26542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46172 env26541 == env26542) = true)

theorem identity26542 : scanCanonicalize (H12AffineFastState.compose env26542 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound26542 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env26543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3100,4112,32768,33110,40256,1076,1024,32769,38976,2161,36176,2,3100,64,3345,40209,4177,33844,34837,2081,256,112,40273,513]

theorem envBound26543 : H12AffineFastState.Bounded env26543 := by
  intro p hp
  have h : env26543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26542_26543 : H12AffineEnvironment.transform 12 3100 env26542 = env26543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env26542 == env26543) = true)

theorem identity26543 : scanCanonicalize (H12AffineFastState.compose env26543 (packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound26543 : packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env26544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,3100,3173,32768,33110,33077,1076,1024,32769,33845,2161,36176,2,3100,64,3345,33124,3108,33844,34837,2081,256,112,33060,513]

theorem envBound26544 : H12AffineFastState.Bounded env26544 := by
  intro p hp
  have h : env26544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26543_26544 : H12AffineEnvironment.transform 11 3189 env26543 = env26544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env26543 == env26544) = true)

theorem identity26544 : scanCanonicalize (H12AffineFastState.compose env26544 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound26544 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env26545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,1060,1101,1076,32768,33110,33077,1076,1024,32769,33845,32,34049,2,1101,64,1344,33124,1141,33844,32836,112,256,112,33060,513]

theorem envBound26545 : H12AffineFastState.Bounded env26545 := by
  intro p hp
  have h : env26545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26544_26545 : H12AffineEnvironment.transform 10 81 env26544 = env26545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env26544 == env26545) = true)

theorem identity26545 : scanCanonicalize (H12AffineFastState.compose env26545 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26545 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26546 : List Nat := [2,4,8,16,32,64,8,116,512,1024,81,1060,1101,1076,32768,32802,32833,1076,1024,32769,33845,32,33909,2,1101,64,1076,32784,1141,33844,32836,112,116,112,32848,513]

theorem envBound26546 : H12AffineFastState.Bounded env26546 := by
  intro p hp
  have h : env26546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26545_26546 : H12AffineEnvironment.transform 7 116 env26545 = env26546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26545 == env26546) = true)

theorem identity26546 : scanCanonicalize (H12AffineFastState.compose env26546 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26546 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env26547 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,1060,1053,1076,32768,32802,32785,1076,1024,32769,33845,32,33829,2,1053,16,1076,32784,1061,33844,32788,32,36,32,32768,513]

theorem envBound26547 : H12AffineFastState.Bounded env26547 := by
  intro p hp
  have h : env26547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26546_26547 : H12AffineEnvironment.transform 5 16 env26546 = env26547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26546 == env26547) = true)

theorem identity26547 : scanCanonicalize (H12AffineFastState.compose env26547 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound26547 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26548 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,1060,1053,1076,0,34,17,1076,1024,1,1077,32,1061,2,1053,16,1076,16,1061,1076,20,32,36,32,0,513]

theorem envBound26548 : H12AffineFastState.Bounded env26548 := by
  intro p hp
  have h : env26548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26547_26548 : H12AffineEnvironment.transform 14 0 env26547 = env26548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env26547 == env26548) = true)

theorem identity26548 : scanCanonicalize (H12AffineFastState.compose env26548 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26548 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26549 : List Nat := [2,4,8,16,1,16,8,5,512,1024,1,1029,1053,1045,0,3,17,1045,1024,1,1044,1,1028,2,1053,16,1045,16,1028,1045,20,1,5,1,0,513]

theorem envBound26549 : H12AffineFastState.Bounded env26549 := by
  intro p hp
  have h : env26549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26548_26549 : H12AffineEnvironment.transform 4 1 env26548 = env26549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26548 == env26549) = true)

theorem identity26549 : scanCanonicalize (H12AffineFastState.compose env26549 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound26549 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26550 : List Nat := [2,4,8,16,1,16,8,5,512,4,1,1,25,17,0,3,17,17,4,1,16,1,0,2,25,16,17,16,0,17,20,1,5,1,0,513]

theorem envBound26550 : H12AffineFastState.Bounded env26550 := by
  intro p hp
  have h : env26550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26549_26550 : H12AffineEnvironment.transform 9 4 env26549 = env26550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26549 == env26550) = true)

def env26551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41292,3,8193,64,4302891,2196487,2159645,43048,75102,6382922,256,2188650,2196550,513]

theorem envBound26551 : H12AffineFastState.Bounded env26551 := by
  intro p hp
  have h : env26551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26537_26551 : H12AffineEnvironment.transform 6 9 env26537 = env26551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26537 == env26551) = true)

theorem identity26551 : scanCanonicalize (H12AffineFastState.compose env26551 (packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound26551 : packedSelected [3,4,8,9,12,14,15,16,17,19,24,28] rootPS < 2^1333 := by decide +kernel

def env26552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,115735,4194304,41292,3,8193,64,4302891,16400,77834,43048,75102,4235613,256,41341,16465,513]

theorem envBound26552 : H12AffineFastState.Bounded env26552 := by
  intro p hp
  have h : env26552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26551_26552 : H12AffineEnvironment.transform 20 115735 env26551 = env26552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env26551 == env26552) = true)

theorem identity26552 : scanCanonicalize (H12AffineFastState.compose env26552 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26552 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env26553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,91466,4194304,17,3,8193,64,4262262,16400,77834,2421,75102,4194304,256,32,16465,513]

theorem envBound26553 : H12AffineFastState.Bounded env26553 := by
  intro p hp
  have h : env26553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26552_26553 : H12AffineEnvironment.transform 14 8541 env26552 = env26553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26552 == env26553) = true)

theorem identity26553 : scanCanonicalize (H12AffineFastState.compose env26553 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26553 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1024,8540,17729,4194304,17,3,8193,64,4204925,16400,4097,2421,1365,4194304,256,32,16465,513]

theorem envBound26554 : H12AffineFastState.Bounded env26554 := by
  intro p hp
  have h : env26554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26553_26554 : H12AffineEnvironment.transform 15 8203 env26553 = env26554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26553 == env26554) = true)

theorem identity26554 : scanCanonicalize (H12AffineFastState.compose env26554 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26554 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26555 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8203,16401,10280,1024,8461,17680,4194304,17,3,8193,17,4204844,16400,4097,2340,1284,4194304,256,32,16384,513]

theorem envBound26555 : H12AffineFastState.Bounded env26555 := by
  intro p hp
  have h : env26555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26554_26555 : H12AffineEnvironment.transform 5 17 env26554 = env26555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26554 == env26555) = true)

theorem identity26555 : scanCanonicalize (H12AffineFastState.compose env26555 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound26555 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26556 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,3101,16384,3345,3094,16401,1077,1024,3344,17680,4194304,17,3,3100,17,4195633,16400,4097,2340,1284,4194304,256,32,16384,513]

theorem envBound26556 : H12AffineFastState.Bounded env26556 := by
  intro p hp
  have h : env26556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26555_26556 : H12AffineEnvironment.transform 12 3101 env26555 = env26556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env26555 == env26556) = true)

theorem identity26556 : scanCanonicalize (H12AffineFastState.compose env26556 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound26556 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26557 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,3101,16384,3345,3094,16401,1077,1024,3344,17680,33,17,3,3100,17,1296,16400,4097,2340,1284,33,256,32,16384,513]

theorem envBound26557 : H12AffineFastState.Bounded env26557 := by
  intro p hp
  have h : env26557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26556_26557 : H12AffineEnvironment.transform 21 33 env26556 = env26557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26556 == env26557) = true)

theorem identity26557 : scanCanonicalize (H12AffineFastState.compose env26557 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound26557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26558 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2324,3101,16384,3345,3094,16401,1077,1024,3344,17680,33,17,3,3100,17,1296,16400,2325,2340,1284,33,256,32,16384,513]

theorem envBound26558 : H12AffineFastState.Bounded env26558 := by
  intro p hp
  have h : env26558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26557_26558 : H12AffineEnvironment.transform 11 2324 env26557 = env26558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env26557 == env26558) = true)

theorem identity26558 : scanCanonicalize (H12AffineFastState.compose env26558 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound26558 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26559 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1556,1792,521,16384,773,514,16401,1077,1024,772,17680,33,17,3,520,17,1296,16400,1793,1840,1284,33,256,32,16384,513]

theorem envBound26559 : H12AffineFastState.Bounded env26559 := by
  intro p hp
  have h : env26559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26558_26559 : H12AffineEnvironment.transform 10 1556 env26558 = env26559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env26558 == env26559) = true)

theorem identity26559 : scanCanonicalize (H12AffineFastState.compose env26559 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound26559 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env26560 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1556,1792,521,293,773,514,308,1077,1024,772,1077,33,17,3,520,17,1296,309,1793,1840,1284,33,256,32,293,513]

theorem envBound26560 : H12AffineFastState.Bounded env26560 := by
  intro p hp
  have h : env26560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26559_26560 : H12AffineEnvironment.transform 13 293 env26559 = env26560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env26559 == env26560) = true)

theorem identity26560 : scanCanonicalize (H12AffineFastState.compose env26560 (packedSelected [1,3,12] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound26560 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env26561 : List Nat := [2,4,8,16,32,17,9,256,260,1024,1296,1028,269,293,1,262,308,1077,1024,0,1077,33,17,3,268,17,1296,309,1029,1076,1284,33,256,32,293,261]

theorem envBound26561 : H12AffineFastState.Bounded env26561 := by
  intro p hp
  have h : env26561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26560_26561 : H12AffineEnvironment.transform 8 260 env26560 = env26561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env26560 == env26561) = true)

theorem identity26561 : scanCanonicalize (H12AffineFastState.compose env26561 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26561 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26562 : List Nat := [2,4,8,16,32,17,9,256,260,53,293,49,269,293,1,262,308,0,53,0,0,33,17,3,268,17,293,309,48,1,305,33,256,32,293,261]

theorem envBound26562 : H12AffineFastState.Bounded env26562 := by
  intro p hp
  have h : env26562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26561_26562 : H12AffineEnvironment.transform 9 53 env26561 = env26562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26561 == env26562) = true)

theorem identity26562 : scanCanonicalize (H12AffineFastState.compose env26562 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26562 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26563 : List Nat := [2,4,8,16,17,17,9,256,260,4,276,0,269,276,1,262,261,0,4,0,0,16,17,3,268,17,276,260,1,1,256,16,256,17,276,261]

theorem envBound26563 : H12AffineFastState.Bounded env26563 := by
  intro p hp
  have h : env26563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26562_26563 : H12AffineEnvironment.transform 4 17 env26562 = env26563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26562 == env26563) = true)

theorem identity26563 : scanCanonicalize (H12AffineFastState.compose env26563 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26564 : List Nat := [2,4,8,16,17,17,9,20,16,4,0,0,25,0,1,18,17,0,4,0,0,16,17,3,24,17,0,16,1,1,20,16,20,17,0,17]

theorem envBound26564 : H12AffineFastState.Bounded env26564 := by
  intro p hp
  have h : env26564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26563_26564 : H12AffineEnvironment.transform 7 20 env26563 = env26564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26563 == env26564) = true)

theorem identity26564 : scanCanonicalize (H12AffineFastState.compose env26564 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26564 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env26565 : List Nat := [2,4,8,1,0,0,9,5,1,4,0,0,8,0,1,3,0,0,4,0,0,1,0,3,9,0,0,1,1,1,5,1,5,0,0,0]

theorem envBound26565 : H12AffineFastState.Bounded env26565 := by
  intro p hp
  have h : env26565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26564_26565 : H12AffineEnvironment.transform 3 1 env26564 = env26565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26564 == env26565) = true)

theorem identity26565 : scanCanonicalize (H12AffineFastState.compose env26565 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26565 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26566 : List Nat := [2,4,3,1,0,0,2,5,1,4,0,0,3,0,1,3,0,0,4,0,0,1,0,3,2,0,0,1,1,1,5,1,5,0,0,0]

theorem envBound26566 : H12AffineFastState.Bounded env26566 := by
  intro p hp
  have h : env26566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26565_26566 : H12AffineEnvironment.transform 2 3 env26565 = env26566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26565 == env26566) = true)

def env26567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10281,1024,32769,2097152,4194304,41292,138,8328,64,4303011,2196487,2159645,43049,75223,6382922,256,2188650,2196687,513]

theorem envBound26567 : H12AffineFastState.Bounded env26567 := by
  intro p hp
  have h : env26567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26536_26567 : H12AffineEnvironment.transform 17 10281 env26536 = env26567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env26536 == env26567) = true)

theorem identity26567 : scanCanonicalize (H12AffineFastState.compose env26567 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26567 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env26568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1024,8541,2097152,4194304,16,138,8328,64,4262399,2172251,2118977,2421,75223,6382922,256,2188650,2172307,513]

theorem envBound26568 : H12AffineFastState.Bounded env26568 := by
  intro p hp
  have h : env26568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26567_26568 : H12AffineEnvironment.transform 14 8540 env26567 = env26568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26567 == env26568) = true)

theorem identity26568 : scanCanonicalize (H12AffineFastState.compose env26568 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound26568 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env26569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1024,8541,2097152,4194304,16,138,8328,64,4205045,2098513,2118977,2421,1501,6309184,256,2114912,2098585,513]

theorem envBound26569 : H12AffineFastState.Bounded env26569 := by
  intro p hp
  have h : env26569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26568_26569 : H12AffineEnvironment.transform 15 8202 env26568 = env26569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env26568 == env26569) = true)

theorem identity26569 : scanCanonicalize (H12AffineFastState.compose env26569 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 5592) := by decide +kernel

theorem selectedBound26569 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1024,8541,5592,4194304,16,138,8328,64,4205045,4233,16537,2421,1501,4214936,256,20664,4161,513]

theorem envBound26570 : H12AffineFastState.Bounded env26570 := by
  intro p hp
  have h : env26570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26569_26570 : H12AffineEnvironment.transform 20 5592 env26569 = env26570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5592 env26569 == env26570) = true)

theorem identity26570 : scanCanonicalize (H12AffineFastState.compose env26570 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 20577) := by decide +kernel

theorem selectedBound26570 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env26571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10281,1024,8541,5592,20577,16,138,8328,64,31124,4233,16537,2421,1501,249,256,20664,4161,513]

theorem envBound26571 : H12AffineFastState.Bounded env26571 := by
  intro p hp
  have h : env26571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26570_26571 : H12AffineEnvironment.transform 21 20577 env26570 = env26571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20577 env26570 == env26571) = true)

theorem identity26571 : scanCanonicalize (H12AffineFastState.compose env26571 (packedSelected [1,3,4,9,14,18,20,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 12693) := by decide +kernel

theorem selectedBound26571 : packedSelected [1,3,4,9,14,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env26572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12693,8540,8202,12677,10281,1024,8541,5592,8692,16,138,8328,64,2049,4233,12556,2421,1501,249,256,8493,4161,513]

theorem envBound26572 : H12AffineFastState.Bounded env26572 := by
  intro p hp
  have h : env26572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26571_26572 : H12AffineEnvironment.transform 13 12693 env26571 = env26572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12693 env26571 == env26572) = true)

theorem identity26572 : scanCanonicalize (H12AffineFastState.compose env26572 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26572 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env26573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,4296,1,343,4312,2420,1024,0,5592,169,16,138,469,64,2049,4233,4177,2421,1501,249,256,112,4161,513]

theorem envBound26573 : H12AffineFastState.Bounded env26573 := by
  intro p hp
  have h : env26573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26572_26573 : H12AffineEnvironment.transform 12 349 env26572 = env26573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26572 == env26573) = true)

theorem identity26573 : scanCanonicalize (H12AffineFastState.compose env26573 (packedSelected [0,1,3,4,5,6,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26573 : packedSelected [0,1,3,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4160,1,343,4176,2420,1024,0,5456,33,16,2,349,64,2049,4097,4177,2421,1365,113,256,112,4161,513]

theorem envBound26574 : H12AffineFastState.Bounded env26574 := by
  intro p hp
  have h : env26574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26573_26574 : H12AffineEnvironment.transform 6 8 env26573 = env26574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26573 == env26574) = true)

theorem identity26574 : scanCanonicalize (H12AffineFastState.compose env26574 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound26574 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env26575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,349,2129,1,343,2113,2420,1024,0,3393,33,16,2,349,64,2049,2064,2112,2421,1365,113,256,112,2128,513]

theorem envBound26575 : H12AffineFastState.Bounded env26575 := by
  intro p hp
  have h : env26575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26574_26575 : H12AffineEnvironment.transform 11 2065 env26574 = env26575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env26574 == env26575) = true)

theorem identity26575 : scanCanonicalize (H12AffineFastState.compose env26575 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26575 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26576 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2065,349,2129,1,343,2113,2420,53,0,2420,33,16,2,349,64,2049,2064,2112,2421,352,113,256,112,2128,513]

theorem envBound26576 : H12AffineFastState.Bounded env26576 := by
  intro p hp
  have h : env26576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26575_26576 : H12AffineEnvironment.transform 9 53 env26575 = env26576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26575 == env26576) = true)

theorem identity26576 : scanCanonicalize (H12AffineFastState.compose env26576 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26576 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26577 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2065,268,2048,1,262,2064,2341,53,0,2341,33,16,2,268,17,2049,2064,2065,2340,305,32,256,33,2049,513]

theorem envBound26577 : H12AffineFastState.Bounded env26577 := by
  intro p hp
  have h : env26577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26576_26577 : H12AffineEnvironment.transform 5 17 env26576 = env26577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26576 == env26577) = true)

theorem identity26577 : scanCanonicalize (H12AffineFastState.compose env26577 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound26577 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26578 : List Nat := [2,4,8,16,32,17,8,256,512,53,302,319,268,302,1,262,318,11,53,0,11,33,16,2,268,17,303,318,319,10,305,32,256,33,303,513]

theorem envBound26578 : H12AffineFastState.Bounded env26578 := by
  intro p hp
  have h : env26578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26577_26578 : H12AffineEnvironment.transform 10 302 env26577 = env26578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env26577 == env26578) = true)

def env26579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,262144,1024,32769,2097152,4194304,41292,16777216,8328,64,21331969,18973837,2159645,294913,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound26579 : H12AffineFastState.Bounded env26579 := by
  intro p hp
  have h : env26579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26534_26579 : H12AffineEnvironment.transform 16 57677 env26534 = env26579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env26534 == env26579) = true)

def env26580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,16777216,8328,64,21080105,18973837,2159645,43049,16852317,23160256,256,18965984,18973765,16777867]

theorem envBound26580 : H12AffineFastState.Bounded env26580 := by
  intro p hp
  have h : env26580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26579_26580 : H12AffineEnvironment.transform 17 10280 env26579 = env26580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26579 == env26580) = true)

theorem identity26580 : scanCanonicalize (H12AffineFastState.compose env26580 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound26580 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env26581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,138,8328,64,4303011,2196487,2159645,43049,75223,6382922,256,2188650,2196687,513]

theorem envBound26581 : H12AffineFastState.Bounded env26581 := by
  intro p hp
  have h : env26581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26580_26581 : H12AffineEnvironment.transform 23 138 env26580 = env26581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env26580 == env26581) = true)

def env26582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,10280,1024,32769,2097152,4194304,41292,2,8192,64,4302891,2196487,2159645,43049,75103,6382922,256,2188650,2196551,513]

theorem envBound26582 : H12AffineFastState.Bounded env26582 := by
  intro p hp
  have h : env26582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26581_26582 : H12AffineEnvironment.transform 6 8 env26581 = env26582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26581 == env26582) = true)

theorem identity26582 : scanCanonicalize (H12AffineFastState.compose env26582 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound26582 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,2097152,4194304,41292,2,8192,64,4204924,2098512,2159645,43049,41992,6349853,256,2155581,2098448,513]

theorem envBound26583 : H12AffineFastState.Bounded env26583 := by
  intro p hp
  have h : env26583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26582_26583 : H12AffineEnvironment.transform 15 33111 env26582 = env26583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env26582 == env26583) = true)

theorem identity26583 : scanCanonicalize (H12AffineFastState.compose env26583 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound26583 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env26584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10280,1024,32769,5456,4194304,41292,2,8192,64,4204924,4096,57677,43049,41992,4256077,256,61805,4160,513]

theorem envBound26584 : H12AffineFastState.Bounded env26584 := by
  intro p hp
  have h : env26584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26583_26584 : H12AffineEnvironment.transform 20 5456 env26583 = env26584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env26583 == env26584) = true)

theorem identity26584 : scanCanonicalize (H12AffineFastState.compose env26584 (packedSelected [11,17,23] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound26584 : packedSelected [11,17,23] rootPS < 2^1333 := by decide +kernel

def env26585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,32768,33111,50513,3124,1024,32769,5456,4194304,34128,2,1052,64,4197728,4096,50513,35893,32788,4248913,256,54641,4160,513]

theorem envBound26585 : H12AffineFastState.Bounded env26585 := by
  intro p hp
  have h : env26585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26584_26585 : H12AffineEnvironment.transform 12 1052 env26584 = env26585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env26584 == env26585) = true)

theorem identity26585 : scanCanonicalize (H12AffineFastState.compose env26585 (packedSelected [4,7,9,11,17,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound26585 : packedSelected [4,7,9,11,17,18,27] rootPS < 2^1333 := by decide +kernel

def env26586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,21760,21591,4177,3124,1024,21761,5456,4194304,20560,2,1052,64,4197728,4096,4177,22837,21780,4194385,256,113,4160,513]

theorem envBound26586 : H12AffineFastState.Bounded env26586 := by
  intro p hp
  have h : env26586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26585_26586 : H12AffineEnvironment.transform 14 21760 env26585 = env26586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env26585 == env26586) = true)

theorem identity26586 : scanCanonicalize (H12AffineFastState.compose env26586 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound26586 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env26587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,6161,3345,3142,4177,3124,1024,3344,5456,4194304,2113,2,1052,64,4197728,4096,4177,292,3333,4194385,256,113,4160,513]

theorem envBound26587 : H12AffineFastState.Bounded env26587 := by
  intro p hp
  have h : env26587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26586_26587 : H12AffineEnvironment.transform 13 6161 env26586 = env26587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env26586 == env26587) = true)

theorem identity26587 : scanCanonicalize (H12AffineFastState.compose env26587 (packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS)) = affineNative (2^(21+1) ^^^ 4420) := by decide +kernel

theorem selectedBound26587 : packedSelected [1,2,3,4,5,6,8,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env26588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,6161,3345,3142,4177,3124,1024,3344,5456,4420,2113,2,1052,64,7204,4096,4177,292,3333,4373,256,113,4160,513]

theorem envBound26588 : H12AffineFastState.Bounded env26588 := by
  intro p hp
  have h : env26588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26587_26588 : H12AffineEnvironment.transform 21 4420 env26587 = env26588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4420 env26587 == env26588) = true)

theorem identity26588 : scanCanonicalize (H12AffineFastState.compose env26588 (packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound26588 : packedSelected [0,3,4,5,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env26589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2405,1052,372,3345,3142,2356,3124,1024,3344,3125,2081,2113,2,1052,64,1345,2405,2356,292,3333,2160,256,113,2341,513]

theorem envBound26589 : H12AffineFastState.Bounded env26589 := by
  intro p hp
  have h : env26589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26588_26589 : H12AffineEnvironment.transform 11 2405 env26588 = env26589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env26588 == env26589) = true)

theorem identity26589 : scanCanonicalize (H12AffineFastState.compose env26589 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26589 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,357,1052,372,1297,1094,308,1076,1024,1296,1077,33,65,2,1052,64,1345,357,308,292,1285,112,256,113,293,513]

theorem envBound26590 : H12AffineFastState.Bounded env26590 := by
  intro p hp
  have h : env26590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26589_26590 : H12AffineEnvironment.transform 10 0 env26589 = env26590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26589 == env26590) = true)

theorem identity26590 : scanCanonicalize (H12AffineFastState.compose env26590 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

end H12CloudChart0