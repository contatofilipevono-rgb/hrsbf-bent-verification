import H12CloudChart0Data155

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound39548 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env39549 : List Nat := [2,4,8,16,1,17,9,20,512,4,529,529,9,513,16,3,529,528,5,17,512,0,17,3,8,16,513,528,528,513,21,1,21,0,512,513]

theorem envBound39549 : H12AffineFastState.Bounded env39549 := by
  intro p hp
  have h : env39549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39548_39549 : H12AffineEnvironment.transform 9 4 env39548 = env39549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39548 == env39549) = true)

theorem identity39549 : scanCanonicalize (H12AffineFastState.compose env39549 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39549 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39550 : List Nat := [2,4,8,1,1,0,9,5,512,4,512,512,9,513,1,3,512,513,5,0,512,0,0,3,8,1,513,513,513,513,4,1,4,0,512,513]

theorem envBound39550 : H12AffineFastState.Bounded env39550 := by
  intro p hp
  have h : env39550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39549_39550 : H12AffineEnvironment.transform 3 1 env39549 = env39550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39549 == env39550) = true)

def env39551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,4268091,4565340,8193,65,4262262,6565208,6387051,4562986,331127,2411540,257,2444610,2468975,272936]

theorem envBound39551 : H12AffineFastState.Bounded env39551 := by
  intro p hp
  have h : env39551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39535_39551 : H12AffineEnvironment.transform 16 16401 env39535 = env39551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env39535 == env39551) = true)

theorem identity39551 : scanCanonicalize (H12AffineFastState.compose env39551 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound39551 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,4268091,4268073,8193,65,4262262,6333485,6387051,4270431,99330,2114913,257,2212919,2172186,41821]

theorem envBound39552 : H12AffineFastState.Bounded env39552 := by
  intro p hp
  have h : env39552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39551_39552 : H12AffineEnvironment.transform 17 35189 env39551 = env39552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env39551 == env39552) = true)

theorem identity39552 : scanCanonicalize (H12AffineFastState.compose env39552 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound39552 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35189,1025,32769,2097152,4194304,4235628,4235646,8193,65,4229153,6333485,6353980,4237320,1365,2114913,257,2114912,2139213,41821]

theorem envBound39553 : H12AffineFastState.Bounded env39553 := by
  intro p hp
  have h : env39553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39552_39553 : H12AffineEnvironment.transform 15 33111 env39552 = env39553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env39552 == env39553) = true)

theorem identity39553 : scanCanonicalize (H12AffineFastState.compose env39553 (packedSelected [0,2,3,4,5,6,9,10,11,12,15,16,17,18,21,27] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound39553 : packedSelected [0,2,3,4,5,6,9,10,11,12,15,16,17,18,21,27] rootPS < 2^1333 := by decide +kernel

def env39554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35189,1025,32769,50449,4194304,4235628,4235646,8193,65,4229153,4219196,4206893,4237320,1365,32880,257,32881,24924,41821]

theorem envBound39554 : H12AffineFastState.Bounded env39554 := by
  intro p hp
  have h : env39554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39553_39554 : H12AffineEnvironment.transform 20 50449 env39553 = env39554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env39553 == env39554) = true)

theorem identity39554 : scanCanonicalize (H12AffineFastState.compose env39554 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound39554 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env39555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35189,1025,32769,50449,33,41293,41311,8193,65,34816,24861,12556,43049,1365,32880,257,32881,24924,41821]

theorem envBound39555 : H12AffineFastState.Bounded env39555 := by
  intro p hp
  have h : env39555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39554_39555 : H12AffineEnvironment.transform 21 33 env39554 = env39555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39554 == env39555) = true)

theorem identity39555 : scanCanonicalize (H12AffineFastState.compose env39555 (packedSelected [0,2,5,8,9,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound39555 : packedSelected [0,2,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,16401,32040,1025,29788,12620,33,21776,21762,8193,65,31837,24861,12556,23668,1365,29741,257,29740,24924,22272]

theorem envBound39556 : H12AffineFastState.Bounded env39556 := by
  intro p hp
  have h : env39556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39555_39556 : H12AffineEnvironment.transform 14 29789 env39555 = env39556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env39555 == env39556) = true)

theorem identity39556 : scanCanonicalize (H12AffineFastState.compose env39556 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound39556 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env39557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21541,21874,16401,23888,1025,21540,4404,33,21776,21762,121,65,23589,16741,4468,23668,1365,21589,257,21588,16676,22272]

theorem envBound39557 : H12AffineFastState.Bounded env39557 := by
  intro p hp
  have h : env39557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39556_39557 : H12AffineEnvironment.transform 12 120 env39556 = env39557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env39556 == env39557) = true)

theorem identity39557 : scanCanonicalize (H12AffineFastState.compose env39557 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39557 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env39558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,292,115,5392,2129,1025,293,4404,33,17,3,121,65,2340,5220,4468,2421,1365,340,257,341,5157,513]

theorem envBound39558 : H12AffineFastState.Bounded env39558 := by
  intro p hp
  have h : env39558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39557_39558 : H12AffineEnvironment.transform 13 5377 env39557 = env39558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39557 == env39558) = true)

theorem identity39558 : scanCanonicalize (H12AffineFastState.compose env39558 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39558 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39559 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,120,4113,292,115,4096,2129,273,293,4404,33,17,3,121,65,2340,4468,4468,2421,69,340,257,341,4405,513]

theorem envBound39559 : H12AffineFastState.Bounded env39559 := by
  intro p hp
  have h : env39559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39558_39559 : H12AffineEnvironment.transform 9 272 env39558 = env39559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39558 == env39559) = true)

theorem identity39559 : scanCanonicalize (H12AffineFastState.compose env39559 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39559 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39560 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,41,4113,292,34,4096,2048,273,293,4404,33,17,3,40,16,2340,4389,4389,2340,20,261,257,260,4405,513]

theorem envBound39560 : H12AffineFastState.Bounded env39560 := by
  intro p hp
  have h : env39560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39559_39560 : H12AffineEnvironment.transform 5 17 env39559 = env39560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39559 == env39560) = true)

theorem identity39560 : scanCanonicalize (H12AffineFastState.compose env39560 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39560 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env39561 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,41,4113,1,34,4096,2048,52,0,4113,33,17,3,40,16,2049,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound39561 : H12AffineFastState.Bounded env39561 := by
  intro p hp
  have h : env39561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39560_39561 : H12AffineEnvironment.transform 7 37 env39560 = env39561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39560 == env39561) = true)

theorem identity39561 : scanCanonicalize (H12AffineFastState.compose env39561 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound39561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39562 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,32,41,49,1,34,32,2048,52,0,49,33,17,3,40,16,2049,32,32,2049,20,32,36,33,48,513]

theorem envBound39562 : H12AffineFastState.Bounded env39562 := by
  intro p hp
  have h : env39562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39561_39562 : H12AffineEnvironment.transform 11 32 env39561 = env39562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env39561 == env39562) = true)

theorem identity39562 : scanCanonicalize (H12AffineFastState.compose env39562 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound39562 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39563 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,41,49,1,34,32,48,52,0,49,33,17,3,40,16,49,32,32,49,20,32,36,33,48,513]

theorem envBound39563 : H12AffineFastState.Bounded env39563 := by
  intro p hp
  have h : env39563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39562_39563 : H12AffineEnvironment.transform 10 48 env39562 = env39563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env39562 == env39563) = true)

def leafEnv39563 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,41,49,1,34,32,48,52,0,49,33,17,3,21,40,1,16,49,32,32,49,20,32,36,33,5,35,48,513,1,48,0]

def active39563 : List Nat := [0,1,2,3,4,8]

def tree39563 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39563 : H12WitnessSearch.Good tree39563 := H12GlobalWitnessIndex.good

theorem leafIdentity39563 : H12AffineFastState.composeSystem env39563 rootObs = leafEnv39563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39563 rootObs == leafEnv39563) = true)

theorem terminalChecked39563 : H12PackedTerminal.terminalCheckFast leafEnv39563 active39563 tree39563 = true := by decide +kernel

def env39564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254785,92374097,145662400,525568,140903596,27337992,25733063]

theorem envBound39564 : H12AffineFastState.Bounded env39564 := by
  intro p hp
  have h : env39564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38093_39564 : H12AffineEnvironment.transform 29 155254785 env38093 = env39564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env38093 == env39564) = true)

def env39565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254785,25265169,145662400,525568,140903596,27337992,25733063]

theorem envBound39565 : H12AffineFastState.Bounded env39565 := by
  intro p hp
  have h : env39565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39564_39565 : H12AffineEnvironment.transform 25 64 env39564 = env39565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env39564 == env39565) = true)

def env39566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356289,25265169,23160256,525568,27902124,27337992,25733063]

theorem envBound39566 : H12AffineFastState.Bounded env39566 := by
  intro p hp
  have h : env39566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39565_39566 : H12AffineEnvironment.transform 26 30393344 env39565 = env39566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env39565 == env39566) = true)

def env39567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265169,23160256,256,27378860,27337992,25207751]

theorem envBound39567 : H12AffineFastState.Bounded env39567 := by
  intro p hp
  have h : env39567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39566_39567 : H12AffineEnvironment.transform 18 1024 env39566 = env39567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env39566 == env39567) = true)

theorem identity39567 : scanCanonicalize (H12AffineFastState.compose env39567 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound39567 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,4194304,8388608,16777216,8328,64,29868032,16793754,8491335,8830977,25265169,21012950,256,25166010,25223454,25207751]

theorem envBound39568 : H12AffineFastState.Bounded env39568 := by
  intro p hp
  have h : env39568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39567_39568 : H12AffineEnvironment.transform 20 115734 env39567 = env39568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env39567 == env39568) = true)

def env39569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,4194304,8388608,95616,8328,64,13022592,79130,8491335,8830977,8450449,4314198,256,8484154,8492190,8508999]

theorem envBound39569 : H12AffineFastState.Bounded env39569 := by
  intro p hp
  have h : env39569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39568_39569 : H12AffineEnvironment.transform 23 95616 env39568 = env39569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95616 env39568 == env39569) = true)

def env39570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,4194304,8388608,73856,8328,64,13022592,79130,8491335,8819969,8430737,4292950,256,8462394,8492190,8487751]

theorem envBound39570 : H12AffineFastState.Bounded env39570 := by
  intro p hp
  have h : env39570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39569_39570 : H12AffineEnvironment.transform 13 5376 env39569 = env39570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39569 == env39570) = true)

def env39571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,8388608,73856,8328,64,8828320,79130,8491335,8819969,8430737,98678,256,8462394,8492190,8487751]

theorem envBound39571 : H12AffineFastState.Bounded env39571 := by
  intro p hp
  have h : env39571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39570_39571 : H12AffineEnvironment.transform 21 32 env39570 = env39571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39570 == env39571) = true)

theorem identity39571 : scanCanonicalize (H12AffineFastState.compose env39571 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98766) := by decide +kernel

theorem selectedBound39571 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,98766,73856,8328,64,472174,79130,4233,464079,75103,98678,256,41460,5456,649]

theorem envBound39572 : H12AffineFastState.Bounded env39572 := by
  intro p hp
  have h : env39572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39571_39572 : H12AffineEnvironment.transform 22 98766 env39571 = env39572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98766 env39571 == env39572) = true)

theorem identity39572 : scanCanonicalize (H12AffineFastState.compose env39572 (packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound39572 : packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env39573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10401,1024,32769,102678,32,98766,73856,8328,64,203983,79130,4233,212078,75103,98678,256,41460,5456,649]

theorem envBound39573 : H12AffineFastState.Bounded env39573 := by
  intro p hp
  have h : env39573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39572_39573 : H12AffineEnvironment.transform 17 10401 env39572 = env39573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env39572 == env39573) = true)

theorem identity39573 : scanCanonicalize (H12AffineFastState.compose env39573 (packedSelected [0,1,4,5,7,8,16,19,20,21,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39573 : packedSelected [0,1,4,5,7,8,16,19,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102678,32,98630,73736,8192,64,203847,79130,4097,212078,75103,98678,256,41340,5456,513]

theorem envBound39574 : H12AffineFastState.Bounded env39574 := by
  intro p hp
  have h : env39574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39573_39574 : H12AffineEnvironment.transform 6 8 env39573 = env39574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39573 == env39574) = true)

theorem identity39574 : scanCanonicalize (H12AffineFastState.compose env39574 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39574 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env39575 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102678,32,98583,73736,8192,17,203798,79130,4097,212031,75022,98599,256,41261,5377,513]

theorem envBound39575 : H12AffineFastState.Bounded env39575 := by
  intro p hp
  have h : env39575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39574_39575 : H12AffineEnvironment.transform 5 17 env39574 = env39575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39574 == env39575) = true)

theorem identity39575 : scanCanonicalize (H12AffineFastState.compose env39575 (packedSelected [0,7,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound39575 : packedSelected [0,7,11,14] rootPS < 2^1333 := by decide +kernel

def env39576 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,65536,131072,10281,1024,8461,77850,32,73755,73736,8192,17,203798,79130,4097,212031,75022,73771,256,33,5377,513]

theorem envBound39576 : H12AffineFastState.Bounded env39576 := by
  intro p hp
  have h : env39576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39575_39576 : H12AffineEnvironment.transform 14 8460 env39575 = env39576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env39575 == env39576) = true)

theorem identity39576 : scanCanonicalize (H12AffineFastState.compose env39576 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound39576 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39577 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,65536,70679,10281,1024,8461,77850,32,73755,73736,8192,17,2049,79130,4097,10280,75022,73771,256,33,5377,513]

theorem envBound39577 : H12AffineFastState.Bounded env39577 := by
  intro p hp
  have h : env39577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39576_39577 : H12AffineEnvironment.transform 16 70679 env39576 = env39577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env39576 == env39577) = true)

theorem identity39577 : scanCanonicalize (H12AffineFastState.compose env39577 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39577 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39578 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,65536,70679,2341,1024,1,69910,32,65815,65796,268,17,2049,70678,4097,2340,66562,65831,256,33,5377,513]

theorem envBound39578 : H12AffineFastState.Bounded env39578 := by
  intro p hp
  have h : env39578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39577_39578 : H12AffineEnvironment.transform 12 268 env39577 = env39578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39577 == env39578) = true)

theorem identity39578 : scanCanonicalize (H12AffineFastState.compose env39578 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39578 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39579 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1024,1,4113,32,16,3,268,17,2049,5393,4097,2340,1285,32,256,33,5377,513]

theorem envBound39579 : H12AffineFastState.Bounded env39579 := by
  intro p hp
  have h : env39579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39578_39579 : H12AffineEnvironment.transform 15 263 env39578 = env39579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39578 == env39579) = true)

theorem identity39579 : scanCanonicalize (H12AffineFastState.compose env39579 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39579 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39580 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8,5124,0,3,5140,2081,1024,1,4113,32,16,3,8,17,2049,5141,4097,2080,1025,32,4,33,5125,513]

theorem envBound39580 : H12AffineFastState.Bounded env39580 := by
  intro p hp
  have h : env39580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39579_39580 : H12AffineEnvironment.transform 7 4 env39579 = env39580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39579 == env39580) = true)

theorem identity39580 : scanCanonicalize (H12AffineFastState.compose env39580 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound39580 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39581 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,4096,8,4144,0,3,4128,2081,52,1,4113,32,16,3,8,17,2049,4129,4097,2080,53,32,4,33,4145,513]

theorem envBound39581 : H12AffineFastState.Bounded env39581 := by
  intro p hp
  have h : env39581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39580_39581 : H12AffineEnvironment.transform 9 52 env39580 = env39581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39580 == env39581) = true)

theorem identity39581 : scanCanonicalize (H12AffineFastState.compose env39581 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound39581 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39582 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,2609,8,2561,0,3,2577,2081,52,1,2592,32,16,3,8,17,2049,2576,2608,2080,53,32,4,33,2560,513]

theorem envBound39582 : H12AffineFastState.Bounded env39582 := by
  intro p hp
  have h : env39582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39581_39582 : H12AffineEnvironment.transform 11 2609 env39581 = env39582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env39581 == env39582) = true)

theorem identity39582 : scanCanonicalize (H12AffineFastState.compose env39582 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound39582 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39583 : List Nat := [2,4,8,16,32,17,8,4,17,52,2048,2080,8,2064,0,3,2048,2081,52,1,2097,32,16,3,8,17,2049,2049,2081,2080,53,32,4,33,2065,16]

theorem envBound39583 : H12AffineFastState.Bounded env39583 := by
  intro p hp
  have h : env39583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39582_39583 : H12AffineEnvironment.transform 8 17 env39582 = env39583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env39582 == env39583) = true)

theorem identity39583 : scanCanonicalize (H12AffineFastState.compose env39583 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound39583 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39584 : List Nat := [2,4,8,16,32,17,8,4,17,52,49,17,8,33,0,3,49,16,52,1,0,32,16,3,8,17,48,48,16,17,53,32,4,33,32,16]

theorem envBound39584 : H12AffineFastState.Bounded env39584 := by
  intro p hp
  have h : env39584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39583_39584 : H12AffineEnvironment.transform 10 49 env39583 = env39584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env39583 == env39584) = true)

theorem identity39584 : scanCanonicalize (H12AffineFastState.compose env39584 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39584 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39585 : List Nat := [2,4,8,16,1,17,8,4,17,21,16,17,8,0,0,3,16,16,21,1,0,1,16,3,8,17,17,17,16,17,20,1,4,0,1,16]

theorem envBound39585 : H12AffineFastState.Bounded env39585 := by
  intro p hp
  have h : env39585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39584_39585 : H12AffineEnvironment.transform 4 1 env39584 = env39585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39584 == env39585) = true)

theorem identity39585 : scanCanonicalize (H12AffineFastState.compose env39585 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39586 : List Nat := [2,4,8,11,1,10,8,4,10,14,11,10,8,0,0,3,11,11,14,1,0,1,11,3,8,10,10,10,11,10,15,1,4,0,1,11]

theorem envBound39586 : H12AffineFastState.Bounded env39586 := by
  intro p hp
  have h : env39586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39585_39586 : H12AffineEnvironment.transform 3 11 env39585 = env39586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39585 == env39586) = true)

def env39587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,8388608,73856,8328,64,8828321,79130,8491335,8819969,8430737,98679,256,8462394,8492190,8487751]

theorem envBound39587 : H12AffineFastState.Bounded env39587 := by
  intro p hp
  have h : env39587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39570_39587 : H12AffineEnvironment.transform 21 33 env39570 = env39587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39570 == env39587) = true)

theorem identity39587 : scanCanonicalize (H12AffineFastState.compose env39587 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound39587 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33246,131072,262144,1024,32769,4296,33,8388608,41310,8328,64,8828321,46276,8392857,8819969,8430737,169,256,8430052,8394048,8389273]

theorem envBound39588 : H12AffineFastState.Bounded env39588 := by
  intro p hp
  have h : env39588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39587_39588 : H12AffineEnvironment.transform 15 33246 env39587 = env39588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env39587 == env39588) = true)

theorem identity39588 : scanCanonicalize (H12AffineFastState.compose env39588 (packedSelected [4,7,9,11,14,16,18,20,21,23,27,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39588 : packedSelected [4,7,9,11,14,16,18,20,21,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env39589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4160,33,8388608,41310,8192,64,8828201,46156,8392721,8819969,8430617,33,256,8429932,8394048,8389137]

theorem envBound39589 : H12AffineFastState.Bounded env39589 := by
  intro p hp
  have h : env39589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39588_39589 : H12AffineEnvironment.transform 6 8 env39588 = env39589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39588 == env39589) = true)

theorem identity39589 : scanCanonicalize (H12AffineFastState.compose env39589 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound39589 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4160,33,16,41310,8192,64,439609,46156,4097,431377,41993,33,256,41340,5456,513]

theorem envBound39590 : H12AffineFastState.Bounded env39590 := by
  intro p hp
  have h : env39590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39589_39590 : H12AffineEnvironment.transform 22 16 env39589 = env39590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env39589 == env39590) = true)

def env39591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,4194304,8388608,73857,8328,64,13022592,79130,8491335,8819968,8430736,4292951,256,8462395,8492190,8487750]

theorem envBound39591 : H12AffineFastState.Bounded env39591 := by
  intro p hp
  have h : env39591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39569_39591 : H12AffineEnvironment.transform 13 5377 env39569 = env39591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39569 == env39591) = true)

def env39592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,8388608,73857,8328,64,8828320,79130,8491335,8819968,8430736,98679,256,8462395,8492190,8487750]

theorem envBound39592 : H12AffineFastState.Bounded env39592 := by
  intro p hp
  have h : env39592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39591_39592 : H12AffineEnvironment.transform 21 32 env39591 = env39592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39591 == env39592) = true)

theorem identity39592 : scanCanonicalize (H12AffineFastState.compose env39592 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98631) := by decide +kernel

theorem selectedBound39592 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,98631,73857,8328,64,472295,79130,4096,463943,75223,98679,256,41340,5593,513]

theorem envBound39593 : H12AffineFastState.Bounded env39593 := by
  intro p hp
  have h : env39593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39592_39593 : H12AffineEnvironment.transform 22 98631 env39592 = env39593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98631 env39592 == env39593) = true)

def env39594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,98631,73737,8192,64,472175,79130,4096,463943,75103,98679,256,41340,5457,513]

theorem envBound39594 : H12AffineFastState.Bounded env39594 := by
  intro p hp
  have h : env39594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39593_39594 : H12AffineEnvironment.transform 6 8 env39593 = env39594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39593 == env39594) = true)

def env39595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102679,32,98631,73737,8192,64,203847,79130,4096,212079,75103,98679,256,41340,5457,513]

theorem envBound39595 : H12AffineFastState.Bounded env39595 := by
  intro p hp
  have h : env39595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39594_39595 : H12AffineEnvironment.transform 17 10280 env39594 = env39595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env39594 == env39595) = true)

theorem identity39595 : scanCanonicalize (H12AffineFastState.compose env39595 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 40037) := by decide +kernel

theorem selectedBound39595 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env39596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,40037,10280,1024,32769,102679,32,98631,73737,8192,64,98338,79130,4096,106506,75103,98679,256,41340,5457,513]

theorem envBound39596 : H12AffineFastState.Bounded env39596 := by
  intro p hp
  have h : env39596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39595_39596 : H12AffineEnvironment.transform 16 40037 env39595 = env39596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40037 env39595 == env39596) = true)

theorem identity39596 : scanCanonicalize (H12AffineFastState.compose env39596 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 43391) := by decide +kernel

theorem selectedBound39596 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env39597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,43391,40037,10280,1024,32769,14440,32,10296,35190,8192,64,10589,40037,4096,2421,35872,10248,256,41340,5457,513]

theorem envBound39597 : H12AffineFastState.Bounded env39597 := by
  intro p hp
  have h : env39597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39596_39597 : H12AffineEnvironment.transform 15 43391 env39596 = env39597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43391 env39596 == env39597) = true)

theorem identity39597 : scanCanonicalize (H12AffineFastState.compose env39597 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 3173) := by decide +kernel

theorem selectedBound39597 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,3173,9498,4096,10280,1024,3172,14440,32,10296,1299,8192,64,10589,4096,4096,2421,69,10248,256,11545,5457,513]

theorem envBound39598 : H12AffineFastState.Bounded env39598 := by
  intro p hp
  have h : env39598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39597_39598 : H12AffineEnvironment.transform 14 3173 env39597 = env39598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3173 env39597 == env39598) = true)

theorem identity39598 : scanCanonicalize (H12AffineFastState.compose env39598 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound39598 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2088,5377,3173,3378,4096,0,1024,3172,4160,32,16,1299,2088,64,373,4096,4096,2421,69,32,256,1329,5457,513]

theorem envBound39599 : H12AffineFastState.Bounded env39599 := by
  intro p hp
  have h : env39599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39598_39599 : H12AffineEnvironment.transform 12 2088 env39598 = env39599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env39598 == env39599) = true)

theorem identity39599 : scanCanonicalize (H12AffineFastState.compose env39599 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound39599 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,1336,5377,373,34,4096,0,1024,372,4160,32,16,1299,1336,64,373,4096,4096,1125,69,32,256,1329,5457,513]

theorem envBound39600 : H12AffineFastState.Bounded env39600 := by
  intro p hp
  have h : env39600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39599_39600 : H12AffineEnvironment.transform 10 1296 env39599 = env39600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env39599 == env39600) = true)

def env39601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102679,32,98631,73737,8192,64,203846,79130,4096,212078,75103,98679,256,41340,5457,513]

theorem envBound39601 : H12AffineFastState.Bounded env39601 := by
  intro p hp
  have h : env39601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39594_39601 : H12AffineEnvironment.transform 17 10281 env39594 = env39601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39594 == env39601) = true)

theorem identity39601 : scanCanonicalize (H12AffineFastState.compose env39601 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound39601 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env39602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,40971,131072,10281,1024,32769,12572,32,8524,32770,8192,64,179277,38161,4096,171109,34132,8572,256,41340,5457,513]

theorem envBound39602 : H12AffineFastState.Bounded env39602 := by
  intro p hp
  have h : env39602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39601_39602 : H12AffineEnvironment.transform 15 40971 env39601 = env39602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env39601 == env39602) = true)

theorem identity39602 : scanCanonicalize (H12AffineFastState.compose env39602 (packedSelected [0,1,3,5,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39602 : packedSelected [0,1,3,5,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env39603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,33110,131072,2420,1024,32769,4161,32,17,32770,349,64,171280,38161,4096,171109,34132,33,256,32801,5457,513]

theorem envBound39603 : H12AffineFastState.Bounded env39603 := by
  intro p hp
  have h : env39603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39602_39603 : H12AffineEnvironment.transform 12 349 env39602 = env39603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39602 == env39603) = true)

theorem identity39603 : scanCanonicalize (H12AffineFastState.compose env39603 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound39603 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,33110,38161,2420,1024,32769,4161,32,17,32770,349,64,2049,38161,4096,2420,34132,33,256,32801,5457,513]

theorem envBound39604 : H12AffineFastState.Bounded env39604 := by
  intro p hp
  have h : env39604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39603_39604 : H12AffineEnvironment.transform 16 38161 env39603 = env39604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env39603 == env39604) = true)

theorem identity39604 : scanCanonicalize (H12AffineFastState.compose env39604 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39604 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39605 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,32768,33031,38161,2341,1024,32769,4112,32,17,32770,268,17,2049,38161,4096,2341,34053,33,256,32801,5376,513]

theorem envBound39605 : H12AffineFastState.Bounded env39605 := by
  intro p hp
  have h : env39605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39604_39605 : H12AffineEnvironment.transform 5 17 env39604 = env39605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39604 == env39605) = true)

theorem identity39605 : scanCanonicalize (H12AffineFastState.compose env39605 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39605 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39606 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,262,5392,2341,1024,0,4112,32,17,3,268,17,2049,5392,4096,2341,1284,33,256,32,5376,513]

theorem envBound39606 : H12AffineFastState.Bounded env39606 := by
  intro p hp
  have h : env39606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39605_39606 : H12AffineEnvironment.transform 14 1 env39605 = env39606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39605 == env39606) = true)

theorem identity39606 : scanCanonicalize (H12AffineFastState.compose env39606 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound39606 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39607 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,309,268,1076,1,262,1061,2341,1024,0,293,32,17,3,268,17,2049,1061,309,2341,1284,33,256,32,1077,513]

theorem envBound39607 : H12AffineFastState.Bounded env39607 := by
  intro p hp
  have h : env39607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39606_39607 : H12AffineEnvironment.transform 11 309 env39606 = env39607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env39606 == env39607) = true)

theorem identity39607 : scanCanonicalize (H12AffineFastState.compose env39607 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39607 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39608 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,309,268,293,1,262,308,2341,273,0,293,32,17,3,268,17,2049,308,309,2341,21,33,256,32,292,513]

theorem envBound39608 : H12AffineFastState.Bounded env39608 := by
  intro p hp
  have h : env39608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39607_39608 : H12AffineEnvironment.transform 9 273 env39607 = env39608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39607 == env39608) = true)

theorem identity39608 : scanCanonicalize (H12AffineFastState.compose env39608 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39608 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39609 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,17,40,1,1,34,16,2049,53,0,1,32,17,3,40,17,2049,16,17,2049,21,33,36,32,0,513]

theorem envBound39609 : H12AffineFastState.Bounded env39609 := by
  intro p hp
  have h : env39609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39608_39609 : H12AffineEnvironment.transform 7 36 env39608 = env39609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39608 == env39609) = true)

theorem identity39609 : scanCanonicalize (H12AffineFastState.compose env39609 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39609 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39610 : List Nat := [2,4,8,16,16,17,8,20,512,5,2048,17,24,1,1,18,16,2049,5,0,1,16,17,3,24,17,2049,16,17,2049,21,17,20,16,0,513]

theorem envBound39610 : H12AffineFastState.Bounded env39610 := by
  intro p hp
  have h : env39610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39609_39610 : H12AffineEnvironment.transform 4 16 env39609 = env39610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39609 == env39610) = true)

theorem identity39610 : scanCanonicalize (H12AffineFastState.compose env39610 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound39610 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39611 : List Nat := [2,4,8,16,16,17,8,20,512,5,16,17,24,1,1,18,16,17,5,0,1,16,17,3,24,17,17,16,17,17,21,17,20,16,0,513]

theorem envBound39611 : H12AffineFastState.Bounded env39611 := by
  intro p hp
  have h : env39611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39610_39611 : H12AffineEnvironment.transform 10 16 env39610 = env39611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env39610 == env39611) = true)

theorem identity39611 : scanCanonicalize (H12AffineFastState.compose env39611 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39611 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39612 : List Nat := [2,4,8,0,0,1,8,4,512,5,0,1,8,1,1,2,0,1,5,0,1,0,1,3,8,1,1,0,1,1,5,1,4,0,0,513]

theorem envBound39612 : H12AffineFastState.Bounded env39612 := by
  intro p hp
  have h : env39612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39611_39612 : H12AffineEnvironment.transform 3 0 env39611 = env39612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39611 == env39612) = true)

def env39613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,98631,73736,8193,64,472174,79130,4096,463943,75102,98679,256,41340,5456,513]

theorem envBound39613 : H12AffineFastState.Bounded env39613 := by
  intro p hp
  have h : env39613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39593_39613 : H12AffineEnvironment.transform 6 9 env39593 = env39613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39593 == env39613) = true)

theorem identity39613 : scanCanonicalize (H12AffineFastState.compose env39613 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound39613 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79130,262144,1024,32769,102679,32,98631,73736,8193,64,262516,79130,4096,270685,75102,98679,256,41340,5456,513]

theorem envBound39614 : H12AffineFastState.Bounded env39614 := by
  intro p hp
  have h : env39614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39613_39614 : H12AffineEnvironment.transform 16 79130 env39613 = env39614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env39613 == env39614) = true)

theorem identity39614 : scanCanonicalize (H12AffineFastState.compose env39614 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound39614 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,9499,4097,262144,1024,32769,46092,32,42076,1299,8193,64,262516,4097,4096,270685,69,42092,256,41340,5456,513]

theorem envBound39615 : H12AffineFastState.Bounded env39615 := by
  intro p hp
  have h : env39615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39614_39615 : H12AffineEnvironment.transform 15 9499 env39614 = env39615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env39614 == env39615) = true)

theorem identity39615 : scanCanonicalize (H12AffineFastState.compose env39615 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound39615 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,9499,4097,11576,1024,32769,46092,32,42076,1299,8193,64,11340,4097,4096,3173,69,42092,256,41340,5456,513]

theorem envBound39616 : H12AffineFastState.Bounded env39616 := by
  intro p hp
  have h : env39616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39615_39616 : H12AffineEnvironment.transform 17 11576 env39615 = env39616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env39615 == env39616) = true)

theorem identity39616 : scanCanonicalize (H12AffineFastState.compose env39616 (packedSelected [6,14,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8492) := by decide +kernel

theorem selectedBound39616 : packedSelected [6,14,18,23] rootPS < 2^1333 := by decide +kernel

def env39617 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8492,9499,4097,11576,1024,8493,5408,32,1392,1299,8193,64,11340,4097,4096,3173,69,1344,256,80,5456,513]

theorem envBound39617 : H12AffineFastState.Bounded env39617 := by
  intro p hp
  have h : env39617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39616_39617 : H12AffineEnvironment.transform 14 8492 env39616 = env39617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8492 env39616 == env39617) = true)

theorem identity39617 : scanCanonicalize (H12AffineFastState.compose env39617 (packedSelected [0,6,21,27] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound39617 : packedSelected [0,6,21,27] rootPS < 2^1333 := by decide +kernel

def env39618 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,381,5377,81,1126,4097,3141,1024,80,5408,32,1392,1299,380,64,3377,4097,4096,3173,69,1344,256,80,5456,513]

theorem envBound39618 : H12AffineFastState.Bounded env39618 := by
  intro p hp
  have h : env39618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39617_39618 : H12AffineEnvironment.transform 12 381 env39617 = env39618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env39617 == env39618) = true)

theorem identity39618 : scanCanonicalize (H12AffineFastState.compose env39618 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound39618 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39619 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,4096,381,4145,81,342,4097,2421,304,80,4112,32,64,35,380,64,2049,4097,4096,2389,69,112,256,80,4192,513]

theorem envBound39619 : H12AffineFastState.Bounded env39619 := by
  intro p hp
  have h : env39619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39618_39619 : H12AffineEnvironment.transform 9 304 env39618 = env39619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env39618 == env39619) = true)

theorem identity39619 : scanCanonicalize (H12AffineFastState.compose env39619 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound39619 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env39620 : List Nat := [2,4,8,16,32,64,9,256,512,304,32,4096,381,4145,81,342,4097,341,304,80,4112,32,64,35,380,64,33,4097,4096,373,69,112,256,80,4192,513]

theorem envBound39620 : H12AffineFastState.Bounded env39620 := by
  intro p hp
  have h : env39620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39619_39620 : H12AffineEnvironment.transform 10 32 env39619 = env39620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env39619 == env39620) = true)

theorem identity39620 : scanCanonicalize (H12AffineFastState.compose env39620 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound39620 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env39621 : List Nat := [2,4,8,16,32,64,9,256,512,304,32,97,381,80,81,342,96,341,304,80,113,32,64,35,380,64,33,96,97,373,69,112,256,80,1,513]

theorem envBound39621 : H12AffineFastState.Bounded env39621 := by
  intro p hp
  have h : env39621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39620_39621 : H12AffineEnvironment.transform 11 97 env39620 = env39621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env39620 == env39621) = true)

theorem identity39621 : scanCanonicalize (H12AffineFastState.compose env39621 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound39621 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39622 : List Nat := [2,4,8,16,32,64,9,256,341,304,32,97,381,80,81,342,96,341,304,80,113,32,64,35,380,64,33,96,97,373,69,112,256,80,1,340]

theorem envBound39622 : H12AffineFastState.Bounded env39622 := by
  intro p hp
  have h : env39622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39621_39622 : H12AffineEnvironment.transform 8 341 env39621 = env39622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env39621 == env39622) = true)

theorem identity39622 : scanCanonicalize (H12AffineFastState.compose env39622 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39622 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env39623 : List Nat := [2,4,8,16,32,64,9,4,81,52,32,97,121,80,81,82,96,81,52,80,113,32,64,35,120,64,33,96,97,113,69,112,4,80,1,80]

theorem envBound39623 : H12AffineFastState.Bounded env39623 := by
  intro p hp
  have h : env39623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39622_39623 : H12AffineEnvironment.transform 7 4 env39622 = env39623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39622 == env39623) = true)

theorem identity39623 : scanCanonicalize (H12AffineFastState.compose env39623 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39623 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39624 : List Nat := [2,4,8,16,0,64,9,4,81,20,0,65,89,80,81,82,64,81,20,80,81,0,64,3,88,64,1,64,65,81,69,80,4,80,1,80]

theorem envBound39624 : H12AffineFastState.Bounded env39624 := by
  intro p hp
  have h : env39624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39623_39624 : H12AffineEnvironment.transform 4 0 env39623 = env39624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39623 == env39624) = true)

def env39625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,8388608,73857,8328,64,8828321,79130,8491335,8819968,8430736,98678,256,8462395,8492190,8487750]

theorem envBound39625 : H12AffineFastState.Bounded env39625 := by
  intro p hp
  have h : env39625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39591_39625 : H12AffineEnvironment.transform 21 33 env39591 = env39625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39591 == env39625) = true)

theorem identity39625 : scanCanonicalize (H12AffineFastState.compose env39625 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound39625 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4160,33,8388608,41430,8328,64,8828321,46157,8392720,8819968,8430736,33,256,8429932,8394185,8389137]

theorem envBound39626 : H12AffineFastState.Bounded env39626 := by
  intro p hp
  have h : env39626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39625_39626 : H12AffineEnvironment.transform 15 33111 env39625 = env39626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env39625 == env39626) = true)

def env39627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,146864,1024,32769,4160,33,8388608,41430,8328,64,8423441,46157,8392720,8431792,8430736,33,256,8429932,8394185,8389137]

theorem envBound39627 : H12AffineFastState.Bounded env39627 := by
  intro p hp
  have h : env39627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39626_39627 : H12AffineEnvironment.transform 17 146864 env39626 = env39627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146864 env39626 == env39627) = true)

theorem identity39627 : scanCanonicalize (H12AffineFastState.compose env39627 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound39627 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env39628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,5393,10401,1024,32769,4160,33,8388608,41430,8328,64,8423441,46157,8392720,8431792,8430736,33,256,8429932,8394185,8389137]

theorem envBound39628 : H12AffineFastState.Bounded env39628 := by
  intro p hp
  have h : env39628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39627_39628 : H12AffineEnvironment.transform 16 5393 env39627 = env39628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39627 == env39628) = true)

theorem identity39628 : scanCanonicalize (H12AffineFastState.compose env39628 (packedSelected [3,10,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound39628 : packedSelected [3,10,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env39629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,137,478,5393,10401,1024,136,4160,33,8388608,8543,8328,64,8390808,13508,8392720,8398905,8397849,33,256,8397285,8394185,8389137]

theorem envBound39629 : H12AffineFastState.Bounded env39629 := by
  intro p hp
  have h : env39629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39628_39629 : H12AffineEnvironment.transform 14 137 env39628 = env39629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env39628 == env39629) = true)

theorem identity39629 : scanCanonicalize (H12AffineFastState.compose env39629 (packedSelected [1,3,16,20,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound39629 : packedSelected [1,3,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env39630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,137,478,5393,2420,1024,136,4160,33,8388608,138,349,64,8390808,5393,8392720,8391148,8390092,33,256,8388656,8394185,8389137]

theorem envBound39630 : H12AffineFastState.Bounded env39630 := by
  intro p hp
  have h : env39630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39629_39630 : H12AffineEnvironment.transform 12 469 env39629 = env39630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env39629 == env39630) = true)

theorem identity39630 : scanCanonicalize (H12AffineFastState.compose env39630 (packedSelected [0,2,3,4,5,7,9,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39630 : packedSelected [0,2,3,4,5,7,9,10,16] rootPS < 2^1333 := by decide +kernel

def env39631 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,161,5237,137,170,5221,2048,1024,136,4160,33,8388608,138,41,64,8390808,5221,8392720,8390808,8389816,33,116,8388656,8393917,8389137]

theorem envBound39631 : H12AffineFastState.Bounded env39631 := by
  intro p hp
  have h : env39631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39630_39631 : H12AffineEnvironment.transform 7 116 env39630 = env39631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39630 == env39631) = true)

theorem identity39631 : scanCanonicalize (H12AffineFastState.compose env39631 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(22+1) ^^^ 200) := by decide +kernel

theorem selectedBound39631 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39632 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,161,5237,137,170,5221,2048,1024,136,4160,33,200,138,41,64,2128,5221,4312,2128,1136,33,116,248,5237,729]

theorem envBound39632 : H12AffineFastState.Bounded env39632 := by
  intro p hp
  have h : env39632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39631_39632 : H12AffineEnvironment.transform 22 200 env39631 = env39632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 200 env39631 == env39632) = true)

theorem identity39632 : scanCanonicalize (H12AffineFastState.compose env39632 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39632 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39633 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,1,34,5221,2048,1024,0,4160,33,64,2,41,64,2128,5221,4176,2128,1136,33,116,112,5237,593]

theorem envBound39633 : H12AffineFastState.Bounded env39633 := by
  intro p hp
  have h : env39633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39632_39633 : H12AffineEnvironment.transform 6 8 env39632 = env39633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39632 == env39633) = true)

theorem identity39633 : scanCanonicalize (H12AffineFastState.compose env39633 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39633 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env39634 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,34,5173,2048,1024,0,4112,33,16,2,41,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound39634 : H12AffineFastState.Bounded env39634 := by
  intro p hp
  have h : env39634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39633_39634 : H12AffineEnvironment.transform 5 16 env39633 = env39634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39633 == env39634) = true)

def env39635 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,1,34,1029,2048,1024,0,32,33,16,2,41,16,2048,1029,48,2048,1056,33,36,32,1045,513]

theorem envBound39635 : H12AffineFastState.Bounded env39635 := by
  intro p hp
  have h : env39635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39634_39635 : H12AffineEnvironment.transform 11 48 env39634 = env39635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39634 == env39635) = true)

theorem identity39635 : scanCanonicalize (H12AffineFastState.compose env39635 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39636 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,48,41,1045,1,34,1029,0,1024,0,32,33,16,2,41,16,0,1029,48,0,1056,33,36,32,1045,513]

theorem envBound39636 : H12AffineFastState.Bounded env39636 := by
  intro p hp
  have h : env39636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39635_39636 : H12AffineEnvironment.transform 10 0 env39635 = env39636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39635 == env39636) = true)

def env39637 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,48,41,33,1,34,49,0,52,0,32,33,16,2,41,16,0,49,48,0,20,33,36,32,33,513]

theorem envBound39637 : H12AffineFastState.Bounded env39637 := by
  intro p hp
  have h : env39637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39636_39637 : H12AffineEnvironment.transform 9 52 env39636 = env39637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39636 == env39637) = true)

theorem identity39637 : scanCanonicalize (H12AffineFastState.compose env39637 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound39637 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39638 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,48,41,33,1,34,49,0,52,0,32,33,16,2,41,16,0,49,48,0,20,33,36,32,33,42]

theorem envBound39638 : H12AffineFastState.Bounded env39638 := by
  intro p hp
  have h : env39638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39637_39638 : H12AffineEnvironment.transform 8 43 env39637 = env39638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env39637 == env39638) = true)

def leafEnv39638 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,48,41,33,1,34,49,0,52,0,32,33,16,2,20,41,1,16,0,49,48,0,20,33,36,32,4,34,33,42,1,32,0]

def active39638 : List Nat := [0,1,2,3,4]

def tree39638 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39638 : H12WitnessSearch.Good tree39638 := H12GlobalWitnessIndex.good

theorem leafIdentity39638 : H12AffineFastState.composeSystem env39638 rootObs = leafEnv39638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39638 rootObs == leafEnv39638) = true)

theorem terminalChecked39638 : H12PackedTerminal.terminalCheckFast leafEnv39638 active39638 tree39638 = true := by decide +kernel

def env39639 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,41,32,1,34,48,0,53,0,32,33,16,2,41,16,0,48,48,0,21,33,36,32,32,513]

theorem envBound39639 : H12AffineFastState.Bounded env39639 := by
  intro p hp
  have h : env39639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39636_39639 : H12AffineEnvironment.transform 9 53 env39636 = env39639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39636 == env39639) = true)

def leafEnv39639 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,41,32,1,34,48,0,53,0,32,33,16,2,21,41,1,16,0,48,48,0,21,33,36,32,4,34,32,513,1,32,0]

def active39639 : List Nat := [0,1,2,3,4,8]

def tree39639 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39639 : H12WitnessSearch.Good tree39639 := H12GlobalWitnessIndex.good

theorem leafIdentity39639 : H12AffineFastState.composeSystem env39639 rootObs = leafEnv39639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39639 rootObs == leafEnv39639) = true)

theorem terminalChecked39639 : H12PackedTerminal.terminalCheckFast leafEnv39639 active39639 tree39639 = true := by decide +kernel

def env39640 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,1,34,1028,2048,1024,0,33,33,16,2,41,16,2048,1028,49,2048,1056,33,36,32,1044,513]

theorem envBound39640 : H12AffineFastState.Bounded env39640 := by
  intro p hp
  have h : env39640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39634_39640 : H12AffineEnvironment.transform 11 49 env39634 = env39640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env39634 == env39640) = true)

theorem identity39640 : scanCanonicalize (H12AffineFastState.compose env39640 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound39640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39641 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,49,41,1044,1,34,1028,1076,1024,0,33,33,16,2,41,16,1076,1028,49,1076,1056,33,36,32,1044,513]

theorem envBound39641 : H12AffineFastState.Bounded env39641 := by
  intro p hp
  have h : env39641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39640_39641 : H12AffineEnvironment.transform 10 1076 env39640 = env39641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env39640 == env39641) = true)

def env39642 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,41,32,1,34,48,0,52,0,33,33,16,2,41,16,0,48,49,0,20,33,36,32,32,513]

theorem envBound39642 : H12AffineFastState.Bounded env39642 := by
  intro p hp
  have h : env39642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39641_39642 : H12AffineEnvironment.transform 9 52 env39641 = env39642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39641 == env39642) = true)

theorem identity39642 : scanCanonicalize (H12AffineFastState.compose env39642 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound39642 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39643 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,49,41,32,1,34,48,0,52,0,33,33,16,2,41,16,0,48,49,0,20,33,36,32,32,42]

theorem envBound39643 : H12AffineFastState.Bounded env39643 := by
  intro p hp
  have h : env39643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39642_39643 : H12AffineEnvironment.transform 8 43 env39642 = env39643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env39642 == env39643) = true)

def leafEnv39643 : List Nat := [2,4,8,16,32,16,8,36,43,52,0,49,41,32,1,34,48,0,52,0,33,33,16,2,20,41,1,16,0,48,49,0,20,33,36,32,4,34,32,42,1,33,0]

def active39643 : List Nat := [0,1,2,3,4]

def tree39643 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39643 : H12WitnessSearch.Good tree39643 := H12GlobalWitnessIndex.good

theorem leafIdentity39643 : H12AffineFastState.composeSystem env39643 rootObs = leafEnv39643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39643 rootObs == leafEnv39643) = true)

theorem terminalChecked39643 : H12PackedTerminal.terminalCheckFast leafEnv39643 active39643 tree39643 = true := by decide +kernel

def env39644 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,41,33,1,34,49,1,53,0,33,33,16,2,41,16,1,49,49,1,21,33,36,32,33,513]

theorem envBound39644 : H12AffineFastState.Bounded env39644 := by
  intro p hp
  have h : env39644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39641_39644 : H12AffineEnvironment.transform 9 53 env39641 = env39644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39641 == env39644) = true)

def leafEnv39644 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,41,33,1,34,49,1,53,0,33,33,16,2,21,41,1,16,1,49,49,1,21,33,36,32,4,34,33,513,1,33,0]

def active39644 : List Nat := [0,1,2,3,4,8]

def tree39644 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39644 : H12WitnessSearch.Good tree39644 := H12GlobalWitnessIndex.good

theorem leafIdentity39644 : H12AffineFastState.composeSystem env39644 rootObs = leafEnv39644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39644 rootObs == leafEnv39644) = true)

theorem terminalChecked39644 : H12PackedTerminal.terminalCheckFast leafEnv39644 active39644 tree39644 = true := by decide +kernel

def env39645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,131072,146865,1024,32769,4160,33,8388608,41430,8328,64,8423440,46157,8392720,8431793,8430736,33,256,8429932,8394185,8389137]

theorem envBound39645 : H12AffineFastState.Bounded env39645 := by
  intro p hp
  have h : env39645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39626_39645 : H12AffineEnvironment.transform 17 146865 env39626 = env39645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env39626 == env39645) = true)

theorem identity39645 : scanCanonicalize (H12AffineFastState.compose env39645 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound39645 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env39646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,5528,10281,1024,32769,4160,33,8388608,41430,8328,64,8423440,46157,8392720,8431793,8430736,33,256,8429932,8394185,8389137]

theorem envBound39646 : H12AffineFastState.Bounded env39646 := by
  intro p hp
  have h : env39646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39645_39646 : H12AffineEnvironment.transform 16 5528 env39645 = env39646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env39645 == env39646) = true)

theorem identity39646 : scanCanonicalize (H12AffineFastState.compose env39646 (packedSelected [0,1,2,4,5,6,9,10,11,15,18,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39646 : packedSelected [0,1,2,4,5,6,9,10,11,15,18,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env39647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8202,5528,10281,1024,8540,4160,33,8388608,139,8328,64,8399181,5392,8392720,8391148,8390093,33,256,8388657,8394185,8389137]

theorem envBound39647 : H12AffineFastState.Bounded env39647 := by
  intro p hp
  have h : env39647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39646_39647 : H12AffineEnvironment.transform 14 8541 env39646 = env39647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39646 == env39647) = true)

theorem identity39647 : scanCanonicalize (H12AffineFastState.compose env39647 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound39647 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8202,5528,10281,1024,8540,4160,33,152,139,8328,64,10709,5392,4232,2420,1365,33,256,169,5457,649]

theorem envBound39648 : H12AffineFastState.Bounded env39648 := by
  intro p hp
  have h : env39648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39647_39648 : H12AffineEnvironment.transform 22 152 env39647 = env39648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env39647 == env39648) = true)

theorem identity39648 : scanCanonicalize (H12AffineFastState.compose env39648 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39648 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,5392,10281,1024,8540,4160,33,16,3,8192,64,10589,5392,4096,2420,1365,33,256,33,5457,513]

theorem envBound39649 : H12AffineFastState.Bounded env39649 := by
  intro p hp
  have h : env39649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39648_39649 : H12AffineEnvironment.transform 6 8 env39648 = env39649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39648 == env39649) = true)

theorem identity39649 : scanCanonicalize (H12AffineFastState.compose env39649 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39649 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5392,2421,1024,0,4160,33,16,3,348,64,2049,5392,4096,2420,1365,33,256,33,5457,513]

theorem envBound39650 : H12AffineFastState.Bounded env39650 := by
  intro p hp
  have h : env39650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39649_39650 : H12AffineEnvironment.transform 12 348 env39649 = env39650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39649 == env39650) = true)

theorem identity39650 : scanCanonicalize (H12AffineFastState.compose env39650 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound39650 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39651 : List Nat := [2,4,8,16,32,64,8,256,81,1024,2048,4096,348,5377,1,342,5392,2421,1024,0,4160,33,16,3,348,64,2049,5392,4096,2420,1365,33,256,33,5457,80]

theorem envBound39651 : H12AffineFastState.Bounded env39651 := by
  intro p hp
  have h : env39651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39650_39651 : H12AffineEnvironment.transform 8 81 env39650 = env39651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env39650 == env39651) = true)

theorem identity39651 : scanCanonicalize (H12AffineFastState.compose env39651 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound39651 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39652 : List Nat := [2,4,8,16,32,64,8,256,81,1024,2048,1297,348,16,1,342,1,2421,1024,0,1361,33,16,3,348,64,2049,1,1297,2420,1365,33,256,33,64,80]

theorem envBound39652 : H12AffineFastState.Bounded env39652 := by
  intro p hp
  have h : env39652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39651_39652 : H12AffineEnvironment.transform 11 1297 env39651 = env39652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env39651 == env39652) = true)

theorem identity39652 : scanCanonicalize (H12AffineFastState.compose env39652 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound39652 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env39653 : List Nat := [2,4,8,16,32,64,8,85,81,1024,2048,1092,9,16,1,3,1,2080,1024,0,1028,33,16,3,9,64,2049,1,1092,2081,1024,33,85,33,64,80]

theorem envBound39653 : H12AffineFastState.Bounded env39653 := by
  intro p hp
  have h : env39653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39652_39653 : H12AffineEnvironment.transform 7 85 env39652 = env39653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env39652 == env39653) = true)

def env39654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,4194304,8388608,95617,8328,64,13022593,79131,8491335,8830977,8450448,4314199,256,8484155,8492191,8508998]

theorem envBound39654 : H12AffineFastState.Bounded env39654 := by
  intro p hp
  have h : env39654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39568_39654 : H12AffineEnvironment.transform 23 95617 env39568 = env39654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95617 env39568 == env39654) = true)

def env39655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,4194304,8388608,73857,8328,64,13022593,79131,8491335,8819969,8430736,4292951,256,8462395,8492191,8487750]

theorem envBound39655 : H12AffineFastState.Bounded env39655 := by
  intro p hp
  have h : env39655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39654_39655 : H12AffineEnvironment.transform 13 5376 env39654 = env39655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39654 == env39655) = true)

def env39656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,8388608,73857,8328,64,8828321,79131,8491335,8819969,8430736,98679,256,8462395,8492191,8487750]

theorem envBound39656 : H12AffineFastState.Bounded env39656 := by
  intro p hp
  have h : env39656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39655_39656 : H12AffineEnvironment.transform 21 32 env39655 = env39656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39655 == env39656) = true)

def env39657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,8388608,73737,8192,64,8828201,79131,8491335,8819969,8430616,98679,256,8462395,8492055,8487750]

theorem envBound39657 : H12AffineFastState.Bounded env39657 := by
  intro p hp
  have h : env39657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39656_39657 : H12AffineEnvironment.transform 6 8 env39656 = env39657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39656 == env39657) = true)

def env39658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,16,73737,8192,64,439609,79131,102743,431377,41992,98679,256,73771,103431,99158]

theorem envBound39658 : H12AffineFastState.Bounded env39658 := by
  intro p hp
  have h : env39658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39657_39658 : H12AffineEnvironment.transform 22 16 env39657 = env39658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env39657 == env39658) = true)

def env39659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5392,262144,1024,32769,102678,32,16,73737,8192,64,303145,79131,102743,294913,41992,98679,256,73771,103431,99158]

theorem envBound39659 : H12AffineFastState.Bounded env39659 := by
  intro p hp
  have h : env39659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39658_39659 : H12AffineEnvironment.transform 16 5392 env39658 = env39659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env39658 == env39659) = true)

theorem identity39659 : scanCanonicalize (H12AffineFastState.compose env39659 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound39659 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5392,262144,1024,32769,4161,32,16,41310,8192,64,303145,46156,4096,294913,41992,32,256,41340,5456,513]

theorem envBound39660 : H12AffineFastState.Bounded env39660 := by
  intro p hp
  have h : env39660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39659_39660 : H12AffineEnvironment.transform 15 33111 env39659 = env39660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env39659 == env39660) = true)

theorem identity39660 : scanCanonicalize (H12AffineFastState.compose env39660 (packedSelected [1,2,6,8,12,15,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound39660 : packedSelected [1,2,6,8,12,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,8283,5392,262144,1024,8461,4161,32,16,82,8192,64,262437,5440,4096,270605,1284,32,256,112,5456,513]

theorem envBound39661 : H12AffineFastState.Bounded env39661 := by
  intro p hp
  have h : env39661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39660_39661 : H12AffineEnvironment.transform 14 8460 env39660 = env39661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env39660 == env39661) = true)

theorem identity39661 : scanCanonicalize (H12AffineFastState.compose env39661 (packedSelected [1,2,6,8,12,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound39661 : packedSelected [1,2,6,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env39662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,8283,5392,10360,1024,8461,4161,32,16,82,8192,64,10589,5440,4096,2421,1284,32,256,112,5456,513]

theorem envBound39662 : H12AffineFastState.Bounded env39662 := by
  intro p hp
  have h : env39662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39661_39662 : H12AffineEnvironment.transform 17 10360 env39661 = env39662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env39661 == env39662) = true)

theorem identity39662 : scanCanonicalize (H12AffineFastState.compose env39662 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39662 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,80,263,5392,2340,1024,81,4161,32,16,82,348,64,2049,5440,4096,2421,1284,32,256,112,5456,513]

theorem envBound39663 : H12AffineFastState.Bounded env39663 := by
  intro p hp
  have h : env39663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39662_39663 : H12AffineEnvironment.transform 12 348 env39662 = env39663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39662 == env39663) = true)

def env39664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5393,262144,1024,32769,102678,32,16,73737,8192,64,303144,79131,102743,294912,41992,98679,256,73771,103431,99158]

theorem envBound39664 : H12AffineFastState.Bounded env39664 := by
  intro p hp
  have h : env39664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39658_39664 : H12AffineEnvironment.transform 16 5393 env39658 = env39664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39658 == env39664) = true)

theorem identity39664 : scanCanonicalize (H12AffineFastState.compose env39664 (packedSelected [1,3,5,8,10,11,12,15,18,19,23,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound39664 : packedSelected [1,3,5,8,10,11,12,15,18,19,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env39665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5393,108926,1024,32769,102678,32,16,73737,8192,64,67926,79131,102743,76158,41992,98679,256,73771,103431,99158]

theorem envBound39665 : H12AffineFastState.Bounded env39665 := by
  intro p hp
  have h : env39665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39664_39665 : H12AffineEnvironment.transform 17 108926 env39664 = env39665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env39664 == env39665) = true)

theorem identity39665 : scanCanonicalize (H12AffineFastState.compose env39665 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound39665 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env39666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,262,5393,43128,1024,32769,36880,32,16,8463,8192,64,2128,13341,36945,10360,41992,32881,256,8493,38145,33360]

theorem envBound39666 : H12AffineFastState.Bounded env39666 := by
  intro p hp
  have h : env39666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39665_39666 : H12AffineEnvironment.transform 15 262 env39665 = env39666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env39665 == env39666) = true)

theorem identity39666 : scanCanonicalize (H12AffineFastState.compose env39666 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39666 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env39667 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,262,5393,43048,1024,32769,36880,32,16,8463,8192,16,2048,13341,36865,10280,41992,32801,256,8493,38145,33280]

theorem envBound39667 : H12AffineFastState.Bounded env39667 := by
  intro p hp
  have h : env39667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39666_39667 : H12AffineEnvironment.transform 5 16 env39666 = env39667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39666 == env39667) = true)

theorem identity39667 : scanCanonicalize (H12AffineFastState.compose env39667 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39667 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env39668 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,32768,262,5393,35109,1024,32769,36880,32,16,2,269,16,2048,5392,36865,2341,34053,32801,256,32,38145,33280]

theorem envBound39668 : H12AffineFastState.Bounded env39668 := by
  intro p hp
  have h : env39668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39667_39668 : H12AffineEnvironment.transform 12 269 env39667 = env39668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39667 == env39668) = true)

theorem identity39668 : scanCanonicalize (H12AffineFastState.compose env39668 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39668 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39669 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,4096,9,5124,32768,2,5141,34849,1024,32769,36880,32,16,2,9,16,2048,5140,36865,2081,33793,32801,4,32,37893,33280]

theorem envBound39669 : H12AffineFastState.Bounded env39669 := by
  intro p hp
  have h : env39669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39668_39669 : H12AffineEnvironment.transform 7 4 env39668 = env39669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39668 == env39669) = true)

theorem identity39669 : scanCanonicalize (H12AffineFastState.compose env39669 (packedSelected [1,2,8] rootPS)) = affineNative (2^(14+1) ^^^ 6193) := by decide +kernel

theorem selectedBound39669 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env39670 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,4096,9,5124,6193,2,5141,4112,1024,6192,2081,32,16,2,9,16,2048,5140,2096,2081,7216,6160,4,32,3124,6705]

theorem envBound39670 : H12AffineFastState.Bounded env39670 := by
  intro p hp
  have h : env39670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39669_39670 : H12AffineEnvironment.transform 14 6193 env39669 = env39670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6193 env39669 == env39670) = true)

theorem identity39670 : scanCanonicalize (H12AffineFastState.compose env39670 (packedSelected [0,2,6,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound39670 : packedSelected [0,2,6,7,10] rootPS < 2^1333 := by decide +kernel

def env39671 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,3077,9,2049,1076,2,2064,3093,1024,1077,2081,32,16,2,9,16,2048,2065,2096,2081,53,1045,4,32,3124,1588]

theorem envBound39671 : H12AffineFastState.Bounded env39671 := by
  intro p hp
  have h : env39671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39670_39671 : H12AffineEnvironment.transform 11 3077 env39670 = env39671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env39670 == env39671) = true)

theorem identity39671 : scanCanonicalize (H12AffineFastState.compose env39671 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound39671 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env39672 : List Nat := [2,4,8,16,32,16,8,4,512,52,2048,2097,9,2049,0,2,2064,2081,52,1,2081,32,16,2,9,16,2048,2065,2096,2081,53,33,4,32,2048,512]

theorem envBound39672 : H12AffineFastState.Bounded env39672 := by
  intro p hp
  have h : env39672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39671_39672 : H12AffineEnvironment.transform 9 52 env39671 = env39672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39671 == env39672) = true)

theorem identity39672 : scanCanonicalize (H12AffineFastState.compose env39672 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39672 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39673 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2065,9,2049,0,2,2064,2049,20,1,2049,0,16,2,9,16,2048,2065,2064,2049,21,1,4,0,2048,512]

theorem envBound39673 : H12AffineFastState.Bounded env39673 := by
  intro p hp
  have h : env39673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39672_39673 : H12AffineEnvironment.transform 4 0 env39672 = env39673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39672 == env39673) = true)

theorem identity39673 : scanCanonicalize (H12AffineFastState.compose env39673 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39673 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39674 : List Nat := [2,4,8,16,0,16,8,4,0,20,2048,2065,9,2049,0,2,2064,2049,20,1,2049,0,16,2,9,16,2048,2065,2064,2049,21,1,4,0,2048,0]

theorem envBound39674 : H12AffineFastState.Bounded env39674 := by
  intro p hp
  have h : env39674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39673_39674 : H12AffineEnvironment.transform 8 0 env39673 = env39674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39673 == env39674) = true)

theorem identity39674 : scanCanonicalize (H12AffineFastState.compose env39674 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound39674 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39675 : List Nat := [2,4,8,16,0,16,8,4,0,20,31,14,9,30,0,2,15,30,20,1,30,0,16,2,9,16,31,14,15,30,21,1,4,0,31,0]

theorem envBound39675 : H12AffineFastState.Bounded env39675 := by
  intro p hp
  have h : env39675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39674_39675 : H12AffineEnvironment.transform 10 31 env39674 = env39675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env39674 == env39675) = true)

def env39676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,17,73737,8192,64,439608,79131,102742,431376,41993,98679,256,73770,103430,99159]

theorem envBound39676 : H12AffineFastState.Bounded env39676 := by
  intro p hp
  have h : env39676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39657_39676 : H12AffineEnvironment.transform 22 17 env39657 = env39676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env39657 == env39676) = true)

theorem identity39676 : scanCanonicalize (H12AffineFastState.compose env39676 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound39676 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102678,32,17,73737,8192,64,171281,79131,102742,179513,41993,98679,256,73770,103430,99159]

theorem envBound39677 : H12AffineFastState.Bounded env39677 := by
  intro p hp
  have h : env39677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39676_39677 : H12AffineEnvironment.transform 17 10281 env39676 = env39677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39676 == env39677) = true)

theorem identity39677 : scanCanonicalize (H12AffineFastState.compose env39677 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound39677 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79131,10281,1024,32769,102678,32,17,73737,8192,64,108554,79131,102742,100386,41993,98679,256,73770,103430,99159]

theorem envBound39678 : H12AffineFastState.Bounded env39678 := by
  intro p hp
  have h : env39678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39677_39678 : H12AffineEnvironment.transform 16 79131 env39677 = env39678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env39677 == env39678) = true)

theorem identity39678 : scanCanonicalize (H12AffineFastState.compose env39678 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39678 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env39679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,263,13340,10281,1024,32769,36881,32,17,8462,8192,64,43277,13340,36945,35109,41993,32880,256,8493,38145,33360]

theorem envBound39679 : H12AffineFastState.Bounded env39679 := by
  intro p hp
  have h : env39679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39678_39679 : H12AffineEnvironment.transform 15 263 env39678 = env39679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39678 == env39679) = true)

theorem identity39679 : scanCanonicalize (H12AffineFastState.compose env39679 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound39679 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env39680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,81,263,13340,10281,1024,80,4160,32,17,8462,8192,64,10588,13340,4096,2420,9304,33,256,8493,5456,513]

theorem envBound39680 : H12AffineFastState.Bounded env39680 := by
  intro p hp
  have h : env39680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39679_39680 : H12AffineEnvironment.transform 14 81 env39679 = env39680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env39679 == env39680) = true)

theorem identity39680 : scanCanonicalize (H12AffineFastState.compose env39680 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39680 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,263,5392,2341,1024,80,4160,32,17,2,268,64,2128,5392,4096,2420,1364,33,256,33,5456,513]

theorem envBound39681 : H12AffineFastState.Bounded env39681 := by
  intro p hp
  have h : env39681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39680_39681 : H12AffineEnvironment.transform 12 268 env39680 = env39681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39680 == env39681) = true)

theorem identity39681 : scanCanonicalize (H12AffineFastState.compose env39681 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound39681 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39682 : List Nat := [2,4,8,16,32,64,8,256,277,1024,2048,4096,268,5376,81,263,5392,2341,1024,80,4160,32,17,2,268,64,2128,5392,4096,2420,1364,33,256,33,5456,276]

theorem envBound39682 : H12AffineFastState.Bounded env39682 := by
  intro p hp
  have h : env39682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39681_39682 : H12AffineEnvironment.transform 8 277 env39681 = env39682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env39681 == env39682) = true)

theorem identity39682 : scanCanonicalize (H12AffineFastState.compose env39682 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3360) := by decide +kernel

theorem selectedBound39682 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env39683 : List Nat := [2,4,8,16,32,64,8,256,277,1024,2048,3360,268,2080,81,263,2096,2341,1024,80,3424,32,17,2,268,64,2128,2096,3360,2420,1364,33,256,33,2160,276]

theorem envBound39683 : H12AffineFastState.Bounded env39683 := by
  intro p hp
  have h : env39683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39682_39683 : H12AffineEnvironment.transform 11 3360 env39682 = env39683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3360 env39682 == env39683) = true)

theorem identity39683 : scanCanonicalize (H12AffineFastState.compose env39683 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound39683 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env39684 : List Nat := [2,4,8,16,32,64,8,256,277,101,2048,2373,268,2080,81,263,2096,2341,101,80,2309,32,17,2,268,64,2128,2096,2373,2420,305,33,256,33,2160,276]

theorem envBound39684 : H12AffineFastState.Bounded env39684 := by
  intro p hp
  have h : env39684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39683_39684 : H12AffineEnvironment.transform 9 101 env39683 = env39684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env39683 == env39684) = true)

theorem identity39684 : scanCanonicalize (H12AffineFastState.compose env39684 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound39684 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env39685 : List Nat := [2,4,8,16,32,64,8,256,277,101,32,357,268,0,81,263,16,261,101,80,293,32,17,2,268,64,112,16,357,340,305,33,256,33,80,276]

theorem envBound39685 : H12AffineFastState.Bounded env39685 := by
  intro p hp
  have h : env39685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39684_39685 : H12AffineEnvironment.transform 10 32 env39684 = env39685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env39684 == env39685) = true)

theorem identity39685 : scanCanonicalize (H12AffineFastState.compose env39685 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound39685 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env39686 : List Nat := [2,4,8,16,32,64,8,85,64,101,32,48,89,0,81,82,16,80,101,80,112,32,17,2,89,64,112,16,48,1,100,33,85,33,80,65]

theorem envBound39686 : H12AffineFastState.Bounded env39686 := by
  intro p hp
  have h : env39686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39685_39686 : H12AffineEnvironment.transform 7 85 env39685 = env39686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env39685 == env39686) = true)

theorem identity39686 : scanCanonicalize (H12AffineFastState.compose env39686 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39686 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env39687 : List Nat := [2,4,8,16,32,17,8,4,17,52,32,48,8,0,0,3,16,1,52,1,33,32,17,2,8,17,33,16,48,1,53,33,4,33,1,16]

theorem envBound39687 : H12AffineFastState.Bounded env39687 := by
  intro p hp
  have h : env39687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39686_39687 : H12AffineEnvironment.transform 5 17 env39686 = env39687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39686 == env39687) = true)

theorem identity39687 : scanCanonicalize (H12AffineFastState.compose env39687 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39687 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39688 : List Nat := [2,4,8,0,32,1,8,4,1,36,32,32,8,0,0,3,0,1,36,1,33,32,1,2,8,1,33,0,32,1,37,33,4,33,1,0]

theorem envBound39688 : H12AffineFastState.Bounded env39688 := by
  intro p hp
  have h : env39688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39687_39688 : H12AffineEnvironment.transform 3 0 env39687 = env39688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39687 == env39688) = true)

def env39689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,8388608,73736,8193,64,8828200,79131,8491335,8819969,8430617,98679,256,8462395,8492054,8487750]

theorem envBound39689 : H12AffineFastState.Bounded env39689 := by
  intro p hp
  have h : env39689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39656_39689 : H12AffineEnvironment.transform 6 9 env39656 = env39689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39656 == env39689) = true)

def env39690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,16,73736,8193,64,439608,79131,102743,431377,41993,98679,256,73771,103430,99158]

theorem envBound39690 : H12AffineFastState.Bounded env39690 := by
  intro p hp
  have h : env39690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39689_39690 : H12AffineEnvironment.transform 22 16 env39689 = env39690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env39689 == env39690) = true)

theorem identity39690 : scanCanonicalize (H12AffineFastState.compose env39690 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39690 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,77898,32,16,73736,8193,64,398436,79131,77835,406605,1365,73771,256,73771,79194,74250]

theorem envBound39691 : H12AffineFastState.Bounded env39691 := by
  intro p hp
  have h : env39691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39690_39691 : H12AffineEnvironment.transform 14 8540 env39690 = env39691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39690 == env39691) = true)

theorem identity39691 : scanCanonicalize (H12AffineFastState.compose env39691 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound39691 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,212079,1024,8541,77898,32,16,73736,8193,64,75787,79131,77835,67618,1365,73771,256,73771,79194,74250]

theorem envBound39692 : H12AffineFastState.Bounded env39692 := by
  intro p hp
  have h : env39692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39691_39692 : H12AffineEnvironment.transform 17 212079 env39691 = env39692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env39691 == env39692) = true)

theorem identity39692 : scanCanonicalize (H12AffineFastState.compose env39692 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound39692 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env39693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,372,65536,131072,203847,1024,373,69730,32,16,65568,41,64,67619,70963,69667,67618,1365,65539,256,65539,71026,66082]

theorem envBound39693 : H12AffineFastState.Bounded env39693 := by
  intro p hp
  have h : env39693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39692_39693 : H12AffineEnvironment.transform 12 40 env39692 = env39693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env39692 == env39693) = true)

theorem identity39693 : scanCanonicalize (H12AffineFastState.compose env39693 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound39693 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,372,35,131072,138340,1024,373,4161,32,16,3,41,64,2048,5392,4096,2049,1365,32,256,32,5457,513]

theorem envBound39694 : H12AffineFastState.Bounded env39694 := by
  intro p hp
  have h : env39694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39693_39694 : H12AffineEnvironment.transform 15 35 env39693 = env39694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env39693 == env39694) = true)

theorem identity39694 : scanCanonicalize (H12AffineFastState.compose env39694 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound39694 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39695 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,372,35,5172,2128,1024,373,4161,32,16,3,41,64,2048,5392,4096,2049,1365,32,256,32,5457,513]

theorem envBound39695 : H12AffineFastState.Bounded env39695 := by
  intro p hp
  have h : env39695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39694_39695 : H12AffineEnvironment.transform 16 5172 env39694 = env39695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env39694 == env39695) = true)

theorem identity39695 : scanCanonicalize (H12AffineFastState.compose env39695 (packedSelected [11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound39695 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env39696 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3109,40,2341,372,35,2065,2128,1024,373,3172,32,16,3,41,64,2048,2357,3109,2049,1365,32,256,32,2420,513]

theorem envBound39696 : H12AffineFastState.Bounded env39696 := by
  intro p hp
  have h : env39696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39695_39696 : H12AffineEnvironment.transform 11 3109 env39695 = env39696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env39695 == env39696) = true)

theorem identity39696 : scanCanonicalize (H12AffineFastState.compose env39696 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound39696 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39697 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2113,40,2341,372,35,2065,2128,100,373,2048,32,16,3,41,64,2048,2357,2113,2049,305,32,256,32,2420,513]

theorem envBound39697 : H12AffineFastState.Bounded env39697 := by
  intro p hp
  have h : env39697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39696_39697 : H12AffineEnvironment.transform 9 100 env39696 = env39697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env39696 == env39697) = true)

theorem identity39697 : scanCanonicalize (H12AffineFastState.compose env39697 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39697 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39698 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,2113,40,2048,81,35,2065,2128,100,80,2048,32,16,3,41,64,2048,2064,2113,2049,20,32,37,32,2129,513]

theorem envBound39698 : H12AffineFastState.Bounded env39698 := by
  intro p hp
  have h : env39698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39697_39698 : H12AffineEnvironment.transform 7 37 env39697 = env39698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39697 == env39698) = true)

theorem identity39698 : scanCanonicalize (H12AffineFastState.compose env39698 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 36) := by decide +kernel

theorem selectedBound39698 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env39699 : List Nat := [2,4,8,16,32,36,9,37,512,0,2048,2085,40,2048,53,35,2065,2100,0,52,2048,32,16,3,41,36,2048,2064,2085,2049,20,32,37,32,2101,513]

theorem envBound39699 : H12AffineFastState.Bounded env39699 := by
  intro p hp
  have h : env39699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39698_39699 : H12AffineEnvironment.transform 5 36 env39698 = env39699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env39698 == env39699) = true)

theorem identity39699 : scanCanonicalize (H12AffineFastState.compose env39699 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39699 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env39700 : List Nat := [2,4,8,10,32,36,9,37,512,0,2048,2085,40,2048,47,35,2059,2094,0,46,2048,32,10,3,41,36,2048,2058,2085,2049,14,32,37,32,2095,513]

theorem envBound39700 : H12AffineFastState.Bounded env39700 := by
  intro p hp
  have h : env39700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39699_39700 : H12AffineEnvironment.transform 3 10 env39699 = env39700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39699 == env39700) = true)

theorem identity39700 : scanCanonicalize (H12AffineFastState.compose env39700 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound39700 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env39701 : List Nat := [2,4,8,10,13,9,9,8,512,0,2048,2056,5,2048,2,14,2059,2051,0,3,2048,13,10,3,4,9,2048,2058,2056,2049,14,13,8,13,2050,513]

theorem envBound39701 : H12AffineFastState.Bounded env39701 := by
  intro p hp
  have h : env39701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39700_39701 : H12AffineEnvironment.transform 4 13 env39700 = env39701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env39700 == env39701) = true)

theorem identity39701 : scanCanonicalize (H12AffineFastState.compose env39701 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound39701 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env39702 : List Nat := [2,4,8,10,13,9,9,8,512,0,11,3,5,11,2,14,0,8,0,3,11,13,10,3,4,9,11,1,3,10,14,13,8,13,9,513]

theorem envBound39702 : H12AffineFastState.Bounded env39702 := by
  intro p hp
  have h : env39702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39701_39702 : H12AffineEnvironment.transform 10 11 env39701 = env39702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env39701 == env39702) = true)

theorem identity39702 : scanCanonicalize (H12AffineFastState.compose env39702 (packedSelected [0,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39702 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env39703 : List Nat := [2,3,8,10,10,9,9,8,512,0,11,3,2,11,2,9,0,8,0,3,11,10,10,3,3,9,11,1,3,10,9,10,8,10,9,513]

theorem envBound39703 : H12AffineFastState.Bounded env39703 := by
  intro p hp
  have h : env39703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39702_39703 : H12AffineEnvironment.transform 1 3 env39702 = env39703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39702 == env39703) = true)

theorem identity39703 : scanCanonicalize (H12AffineFastState.compose env39703 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39703 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env39704 : List Nat := [2,3,2,0,0,3,3,2,512,0,1,3,2,1,2,3,0,2,0,3,1,0,0,3,3,3,1,1,3,0,3,0,2,0,3,513]

theorem envBound39704 : H12AffineFastState.Bounded env39704 := by
  intro p hp
  have h : env39704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39703_39704 : H12AffineEnvironment.transform 2 2 env39703 = env39704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39703 == env39704) = true)

def env39705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,32,17,73736,8193,64,439609,79131,102742,431376,41992,98679,256,73770,103431,99159]

theorem envBound39705 : H12AffineFastState.Bounded env39705 := by
  intro p hp
  have h : env39705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39689_39705 : H12AffineEnvironment.transform 22 17 env39689 = env39705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env39689 == env39705) = true)

theorem identity39705 : scanCanonicalize (H12AffineFastState.compose env39705 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound39705 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35188,1024,32769,102678,32,17,73736,8193,64,146509,79131,102742,138340,41992,98679,256,73770,103431,99159]

theorem envBound39706 : H12AffineFastState.Bounded env39706 := by
  intro p hp
  have h : env39706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39705_39706 : H12AffineEnvironment.transform 17 35188 env39705 = env39706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env39705 == env39706) = true)

theorem identity39706 : scanCanonicalize (H12AffineFastState.compose env39706 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 37941) := by decide +kernel

theorem selectedBound39706 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,37941,35188,1024,32769,102678,32,17,73736,8193,64,43128,79131,102742,34897,41992,98679,256,73770,103431,99159]

theorem envBound39707 : H12AffineFastState.Bounded env39707 := by
  intro p hp
  have h : env39707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39706_39707 : H12AffineEnvironment.transform 16 37941 env39706 = env39707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37941 env39706 == env39707) = true)

theorem identity39707 : scanCanonicalize (H12AffineFastState.compose env39707 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound39707 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,32768,65536,37941,35188,1024,32769,102678,32,17,65648,121,64,34816,71011,102742,34897,33904,98679,256,65618,103431,99159]

theorem envBound39708 : H12AffineFastState.Bounded env39708 := by
  intro p hp
  have h : env39708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39707_39708 : H12AffineEnvironment.transform 12 120 env39707 = env39708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env39707 == env39708) = true)

theorem identity39708 : scanCanonicalize (H12AffineFastState.compose env39708 (packedSelected [1,3,5,6,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39708 : packedSelected [1,3,5,6,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env39709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,32768,263,37941,35188,1024,32769,36881,32,17,375,121,64,34816,5220,36945,34897,33904,32880,256,341,38144,33360]

theorem envBound39709 : H12AffineFastState.Bounded env39709 := by
  intro p hp
  have h : env39709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39708_39709 : H12AffineEnvironment.transform 15 263 env39708 = env39709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39708 == env39709) = true)

theorem identity39709 : scanCanonicalize (H12AffineFastState.compose env39709 (packedSelected [6,11,14,16,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound39709 : packedSelected [6,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env39710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,293,263,5392,2129,1024,292,4404,32,17,375,121,64,2341,5220,4468,2420,1365,341,256,341,5157,885]

theorem envBound39710 : H12AffineFastState.Bounded env39710 := by
  intro p hp
  have h : env39710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39709_39710 : H12AffineEnvironment.transform 14 293 env39709 = env39710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env39709 == env39710) = true)

theorem identity39710 : scanCanonicalize (H12AffineFastState.compose env39710 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 884) := by decide +kernel

theorem selectedBound39710 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env39711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,884,120,1652,293,263,1636,2129,1024,292,576,32,17,375,121,64,2341,1808,512,2420,1365,341,256,341,1873,885]

theorem envBound39711 : H12AffineFastState.Bounded env39711 := by
  intro p hp
  have h : env39711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39710_39711 : H12AffineEnvironment.transform 11 884 env39710 = env39711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 884 env39710 == env39711) = true)

def env39712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,8388608,73857,8328,64,8828320,79131,8491335,8819969,8430736,98678,256,8462395,8492191,8487750]

theorem envBound39712 : H12AffineFastState.Bounded env39712 := by
  intro p hp
  have h : env39712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39655_39712 : H12AffineEnvironment.transform 21 33 env39655 = env39712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39655 == env39712) = true)

theorem identity39712 : scanCanonicalize (H12AffineFastState.compose env39712 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound39712 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,16,73857,8328,64,439728,79131,102743,431377,42112,98678,256,73771,103567,99158]

theorem envBound39713 : H12AffineFastState.Bounded env39713 := by
  intro p hp
  have h : env39713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39712_39713 : H12AffineEnvironment.transform 22 16 env39712 = env39713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env39712 == env39713) = true)

def env39714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,16,73737,8192,64,439608,79131,102743,431377,41992,98678,256,73771,103431,99158]

theorem envBound39714 : H12AffineFastState.Bounded env39714 := by
  intro p hp
  have h : env39714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39713_39714 : H12AffineEnvironment.transform 6 8 env39713 = env39714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39713 == env39714) = true)

theorem identity39714 : scanCanonicalize (H12AffineFastState.compose env39714 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound39714 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4161,33,16,41310,8192,64,439608,46156,4096,431377,41992,33,256,41340,5456,513]

theorem envBound39715 : H12AffineFastState.Bounded env39715 := by
  intro p hp
  have h : env39715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39714_39715 : H12AffineEnvironment.transform 15 33111 env39714 = env39715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env39714 == env39715) = true)

theorem identity39715 : scanCanonicalize (H12AffineFastState.compose env39715 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39715 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env39716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,342,131072,262144,1024,0,4161,33,16,8543,8192,64,406841,13389,4096,398608,9225,33,256,8573,5456,513]

theorem envBound39716 : H12AffineFastState.Bounded env39716 := by
  intro p hp
  have h : env39716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39715_39716 : H12AffineEnvironment.transform 14 1 env39715 = env39716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39715 == env39716) = true)

theorem identity39716 : scanCanonicalize (H12AffineFastState.compose env39716 (packedSelected [0,1,4,7,8,9,12,14,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound39716 : packedSelected [0,1,4,7,8,9,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env39717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,342,131072,138340,1024,0,4161,33,16,8543,8192,64,10589,13389,4096,2420,9225,33,256,8573,5456,513]

theorem envBound39717 : H12AffineFastState.Bounded env39717 := by
  intro p hp
  have h : env39717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39716_39717 : H12AffineEnvironment.transform 17 138340 env39716 = env39717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env39716 == env39717) = true)

theorem identity39717 : scanCanonicalize (H12AffineFastState.compose env39717 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound39717 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,342,13389,10281,1024,0,4161,33,16,8543,8192,64,10589,13389,4096,2420,9225,33,256,8573,5456,513]

theorem envBound39718 : H12AffineFastState.Bounded env39718 := by
  intro p hp
  have h : env39718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39717_39718 : H12AffineEnvironment.transform 16 13389 env39717 = env39718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env39717 == env39718) = true)

theorem identity39718 : scanCanonicalize (H12AffineFastState.compose env39718 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39718 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1024,0,4161,33,16,2,349,64,2048,5392,4096,2420,1364,33,256,32,5456,513]

theorem envBound39719 : H12AffineFastState.Bounded env39719 := by
  intro p hp
  have h : env39719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39718_39719 : H12AffineEnvironment.transform 12 349 env39718 = env39719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39718 == env39719) = true)

def env39720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102678,33,16,73736,8193,64,439609,79131,102743,431377,41993,98678,256,73771,103430,99158]

theorem envBound39720 : H12AffineFastState.Bounded env39720 := by
  intro p hp
  have h : env39720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39713_39720 : H12AffineEnvironment.transform 6 9 env39713 = env39720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39713 == env39720) = true)

theorem identity39720 : scanCanonicalize (H12AffineFastState.compose env39720 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39720 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,77898,33,16,73736,8193,64,398437,79131,77835,406605,1365,73770,256,73771,79194,74250]

theorem envBound39721 : H12AffineFastState.Bounded env39721 := by
  intro p hp
  have h : env39721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39720_39721 : H12AffineEnvironment.transform 14 8540 env39720 = env39721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39720 == env39721) = true)

theorem identity39721 : scanCanonicalize (H12AffineFastState.compose env39721 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound39721 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67619,1024,8541,77898,33,16,73736,8193,64,203846,79131,77835,212078,1365,73770,256,73771,79194,74250]

theorem envBound39722 : H12AffineFastState.Bounded env39722 := by
  intro p hp
  have h : env39722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39721_39722 : H12AffineEnvironment.transform 17 67619 env39721 = env39722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env39721 == env39722) = true)

theorem identity39722 : scanCanonicalize (H12AffineFastState.compose env39722 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39722 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env39723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,65536,131072,67619,1024,81,69958,33,16,65796,269,64,203846,70679,69895,204130,1365,65830,256,65831,70742,66310]

theorem envBound39723 : H12AffineFastState.Bounded env39723 := by
  intro p hp
  have h : env39723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39722_39723 : H12AffineEnvironment.transform 12 268 env39722 = env39723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39722 == env39723) = true)

theorem identity39723 : scanCanonicalize (H12AffineFastState.compose env39723 (packedSelected [0,2,9,10,11,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 67635) := by decide +kernel

theorem selectedBound39723 : packedSelected [0,2,9,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,65536,67635,67619,1024,81,69958,33,16,65796,269,64,5237,70679,69895,5457,1365,65830,256,65831,70742,66310]

theorem envBound39724 : H12AffineFastState.Bounded env39724 := by
  intro p hp
  have h : env39724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39723_39724 : H12AffineEnvironment.transform 16 67635 env39723 = env39724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 67635 env39723 == env39724) = true)

theorem identity39724 : scanCanonicalize (H12AffineFastState.compose env39724 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 7255) := by decide +kernel

theorem selectedBound39724 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env39725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,80,7255,5220,5236,1024,81,3345,33,16,7507,269,64,5237,2112,3408,5457,1365,7537,256,7536,2049,8017]

theorem envBound39725 : H12AffineFastState.Bounded env39725 := by
  intro p hp
  have h : env39725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39724_39725 : H12AffineEnvironment.transform 15 7255 env39724 = env39725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7255 env39724 == env39725) = true)

theorem identity39725 : scanCanonicalize (H12AffineFastState.compose env39725 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound39725 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3109,268,2341,80,114,2113,2129,1024,81,3345,33,16,374,269,64,2128,2112,3408,2420,1365,340,256,341,2049,884]

theorem envBound39726 : H12AffineFastState.Bounded env39726 := by
  intro p hp
  have h : env39726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39725_39726 : H12AffineEnvironment.transform 11 3109 env39725 = env39726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env39725 == env39726) = true)

theorem identity39726 : scanCanonicalize (H12AffineFastState.compose env39726 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39726 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env39727 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,2341,1,35,2064,2048,1024,0,3345,33,16,295,269,17,2049,2065,3329,2341,1284,261,256,260,2049,805]

theorem envBound39727 : H12AffineFastState.Bounded env39727 := by
  intro p hp
  have h : env39727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39726_39727 : H12AffineEnvironment.transform 5 17 env39726 = env39727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39726 == env39727) = true)

theorem identity39727 : scanCanonicalize (H12AffineFastState.compose env39727 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound39727 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39728 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,2324,268,2341,1,35,2064,2048,305,0,2080,33,16,295,269,17,2049,2065,2096,2341,53,261,256,260,2049,805]

theorem envBound39728 : H12AffineFastState.Bounded env39728 := by
  intro p hp
  have h : env39728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39727_39728 : H12AffineEnvironment.transform 9 305 env39727 = env39728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env39727 == env39728) = true)

theorem identity39728 : scanCanonicalize (H12AffineFastState.compose env39728 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39728 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env39729 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,2065,9,2080,1,35,2064,2048,52,0,2080,33,16,34,8,17,2049,2065,2096,2080,53,0,5,1,2049,544]

theorem envBound39729 : H12AffineFastState.Bounded env39729 := by
  intro p hp
  have h : env39729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39728_39729 : H12AffineEnvironment.transform 7 5 env39728 = env39729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39728 == env39729) = true)

theorem identity39729 : scanCanonicalize (H12AffineFastState.compose env39729 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39729 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39730 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,2065,9,2048,1,3,2064,2048,20,0,2048,1,16,2,8,17,2049,2065,2064,2048,21,0,5,1,2049,512]

theorem envBound39730 : H12AffineFastState.Bounded env39730 := by
  intro p hp
  have h : env39730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39729_39730 : H12AffineEnvironment.transform 4 0 env39729 = env39730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39729 == env39730) = true)

theorem identity39730 : scanCanonicalize (H12AffineFastState.compose env39730 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39731 : List Nat := [2,4,8,1,0,0,9,5,512,5,2048,2048,9,2048,1,3,2049,2048,5,0,2048,1,1,2,8,0,2049,2048,2049,2048,4,0,5,1,2049,512]

theorem envBound39731 : H12AffineFastState.Bounded env39731 := by
  intro p hp
  have h : env39731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39730_39731 : H12AffineEnvironment.transform 3 1 env39730 = env39731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39730 == env39731) = true)

theorem identity39731 : scanCanonicalize (H12AffineFastState.compose env39731 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound39731 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39732 : List Nat := [2,4,7,1,0,0,6,5,512,5,2048,2048,6,2048,1,3,2049,2048,5,0,2048,1,1,2,7,0,2049,2048,2049,2048,4,0,5,1,2049,512]

theorem envBound39732 : H12AffineFastState.Bounded env39732 := by
  intro p hp
  have h : env39732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39731_39732 : H12AffineEnvironment.transform 2 7 env39731 = env39732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env39731 == env39732) = true)

theorem identity39732 : scanCanonicalize (H12AffineFastState.compose env39732 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound39732 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39733 : List Nat := [2,4,7,1,0,0,6,5,512,5,513,513,6,513,1,3,512,513,5,0,513,1,1,2,7,0,512,513,512,513,4,0,5,1,512,512]

theorem envBound39733 : H12AffineFastState.Bounded env39733 := by
  intro p hp
  have h : env39733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39732_39733 : H12AffineEnvironment.transform 10 513 env39732 = env39733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env39732 == env39733) = true)

def env39734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,4194304,8388608,73856,8328,64,13022593,79131,8491335,8819968,8430737,4292950,256,8462394,8492191,8487751]

theorem envBound39734 : H12AffineFastState.Bounded env39734 := by
  intro p hp
  have h : env39734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39654_39734 : H12AffineEnvironment.transform 13 5377 env39654 = env39734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39654 == env39734) = true)

def env39735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,8388608,73856,8328,64,8828321,79131,8491335,8819968,8430737,98678,256,8462394,8492191,8487751]

theorem envBound39735 : H12AffineFastState.Bounded env39735 := by
  intro p hp
  have h : env39735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39734_39735 : H12AffineEnvironment.transform 21 32 env39734 = env39735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39734 == env39735) = true)

theorem identity39735 : scanCanonicalize (H12AffineFastState.compose env39735 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39735 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,8388608,73736,8192,64,8828201,79131,8491335,8819968,8430617,98678,256,8462394,8492055,8487751]

theorem envBound39736 : H12AffineFastState.Bounded env39736 := by
  intro p hp
  have h : env39736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39735_39736 : H12AffineEnvironment.transform 6 8 env39735 = env39736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39735 == env39736) = true)

def env39737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,16,73736,8192,64,439609,79131,102743,431376,41993,98678,256,73770,103431,99159]

theorem envBound39737 : H12AffineFastState.Bounded env39737 := by
  intro p hp
  have h : env39737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39736_39737 : H12AffineEnvironment.transform 22 16 env39736 = env39737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env39736 == env39737) = true)

theorem identity39737 : scanCanonicalize (H12AffineFastState.compose env39737 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound39737 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4161,32,16,41310,8192,64,439609,46157,4097,431376,41993,32,256,41340,5457,513]

theorem envBound39738 : H12AffineFastState.Bounded env39738 := by
  intro p hp
  have h : env39738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39737_39738 : H12AffineEnvironment.transform 15 33110 env39737 = env39738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env39737 == env39738) = true)

theorem identity39738 : scanCanonicalize (H12AffineFastState.compose env39738 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound39738 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env39739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,38161,262144,1024,32769,4161,32,16,41310,8192,64,270376,46157,4097,262145,41993,32,256,41340,5457,513]

theorem envBound39739 : H12AffineFastState.Bounded env39739 := by
  intro p hp
  have h : env39739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39738_39739 : H12AffineEnvironment.transform 16 38161 env39738 = env39739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env39738 == env39739) = true)

theorem identity39739 : scanCanonicalize (H12AffineFastState.compose env39739 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound39739 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env39740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,38161,43049,1024,32769,4161,32,16,41310,8192,64,34817,46157,4097,43048,41993,32,256,41340,5457,513]

theorem envBound39740 : H12AffineFastState.Bounded env39740 := by
  intro p hp
  have h : env39740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39739_39740 : H12AffineEnvironment.transform 17 43049 env39739 = env39740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env39739 == env39740) = true)

theorem identity39740 : scanCanonicalize (H12AffineFastState.compose env39740 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39740 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,13388,2420,1024,8540,4161,32,16,3,8192,64,10588,5392,4097,2421,1364,32,256,33,5457,513]

theorem envBound39741 : H12AffineFastState.Bounded env39741 := by
  intro p hp
  have h : env39741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39740_39741 : H12AffineEnvironment.transform 14 8541 env39740 = env39741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39740 == env39741) = true)

theorem identity39741 : scanCanonicalize (H12AffineFastState.compose env39741 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39741 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,263,5440,2420,1024,80,4161,32,16,3,268,64,2128,5392,4097,2421,1364,32,256,33,5457,513]

theorem envBound39742 : H12AffineFastState.Bounded env39742 := by
  intro p hp
  have h : env39742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39741_39742 : H12AffineEnvironment.transform 12 268 env39741 = env39742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39741 == env39742) = true)

theorem identity39742 : scanCanonicalize (H12AffineFastState.compose env39742 (packedSelected [1,2,3,5,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1393) := by decide +kernel

theorem selectedBound39742 : packedSelected [1,2,3,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1393,4096,268,5377,81,263,5440,1029,1024,80,4161,32,16,3,268,64,1313,5392,4097,1028,1364,32,256,33,5457,513]

theorem envBound39743 : H12AffineFastState.Bounded env39743 := by
  intro p hp
  have h : env39743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39742_39743 : H12AffineEnvironment.transform 10 1393 env39742 = env39743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1393 env39742 == env39743) = true)

theorem identity39743 : scanCanonicalize (H12AffineFastState.compose env39743 (packedSelected [4,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39743 : packedSelected [4,9,10] rootPS < 2^1333 := by decide +kernel

def env39744 : List Nat := [2,4,8,16,0,64,8,256,512,1024,1361,4096,268,5377,81,263,5440,1029,1024,80,4161,0,16,3,268,64,1281,5392,4097,1028,1364,0,256,1,5457,513]

theorem envBound39744 : H12AffineFastState.Bounded env39744 := by
  intro p hp
  have h : env39744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39743_39744 : H12AffineEnvironment.transform 4 0 env39743 = env39744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39743 == env39744) = true)

theorem identity39744 : scanCanonicalize (H12AffineFastState.compose env39744 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound39744 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env39745 : List Nat := [2,4,8,16,0,64,8,256,512,69,276,4096,268,4420,81,263,4357,64,69,80,4161,0,16,3,268,64,324,4437,4097,65,273,0,256,1,4372,513]

theorem envBound39745 : H12AffineFastState.Bounded env39745 := by
  intro p hp
  have h : env39745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39744_39745 : H12AffineEnvironment.transform 9 69 env39744 = env39745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env39744 == env39745) = true)

def env39746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,17,73736,8192,64,439608,79131,102742,431377,41992,98678,256,73771,103430,99158]

theorem envBound39746 : H12AffineFastState.Bounded env39746 := by
  intro p hp
  have h : env39746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39736_39746 : H12AffineEnvironment.transform 22 17 env39736 = env39746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env39736 == env39746) = true)

theorem identity39746 : scanCanonicalize (H12AffineFastState.compose env39746 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound39746 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102679,32,17,73736,8192,64,171281,79131,102742,179512,41992,98678,256,73771,103430,99158]

theorem envBound39747 : H12AffineFastState.Bounded env39747 := by
  intro p hp
  have h : env39747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39746_39747 : H12AffineEnvironment.transform 17 10281 env39746 = env39747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39746 == env39747) = true)

theorem identity39747 : scanCanonicalize (H12AffineFastState.compose env39747 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound39747 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,46157,10281,1024,32769,102679,32,17,73736,8192,64,10588,79131,102742,2421,41992,98678,256,73771,103430,99158]

theorem envBound39748 : H12AffineFastState.Bounded env39748 := by
  intro p hp
  have h : env39748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39747_39748 : H12AffineEnvironment.transform 16 46157 env39747 = env39748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env39747 == env39748) = true)

theorem identity39748 : scanCanonicalize (H12AffineFastState.compose env39748 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound39748 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,46157,10281,1024,32769,4161,32,17,41310,8192,64,10588,46157,4096,2421,41992,32,256,41341,5456,512]

theorem envBound39749 : H12AffineFastState.Bounded env39749 := by
  intro p hp
  have h : env39749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39748_39749 : H12AffineEnvironment.transform 15 33110 env39748 = env39749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env39748 == env39749) = true)

theorem identity39749 : scanCanonicalize (H12AffineFastState.compose env39749 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound39749 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1313,8192,32,32768,33110,41324,10281,1024,32769,1376,32,17,41310,8192,64,10588,41324,1313,2421,41992,32,256,41341,113,512]

theorem envBound39750 : H12AffineFastState.Bounded env39750 := by
  intro p hp
  have h : env39750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39749_39750 : H12AffineEnvironment.transform 11 1313 env39749 = env39750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env39749 == env39750) = true)

theorem identity39750 : scanCanonicalize (H12AffineFastState.compose env39750 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound39750 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1313,1305,32,32768,33110,33909,3376,1024,32769,1376,32,17,33863,1305,64,3141,33909,1313,2421,33041,32,256,33892,113,512]

theorem envBound39751 : H12AffineFastState.Bounded env39751 := by
  intro p hp
  have h : env39751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39750_39751 : H12AffineEnvironment.transform 12 1305 env39750 = env39751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env39750 == env39751) = true)

theorem identity39751 : scanCanonicalize (H12AffineFastState.compose env39751 (packedSelected [12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1329) := by decide +kernel

theorem selectedBound39751 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env39752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1313,1305,32,1329,1127,324,3376,1024,1328,1376,32,17,374,1305,64,3141,324,1313,2421,1056,32,256,341,113,512]

theorem envBound39752 : H12AffineFastState.Bounded env39752 := by
  intro p hp
  have h : env39752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39751_39752 : H12AffineEnvironment.transform 14 1329 env39751 = env39752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1329 env39751 == env39752) = true)

theorem identity39752 : scanCanonicalize (H12AffineFastState.compose env39752 (packedSelected [4,9,18] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound39752 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env39753 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,97,89,32,113,295,324,2160,320,112,32,32,17,374,89,64,2309,324,97,2421,352,32,256,341,113,512]

theorem envBound39753 : H12AffineFastState.Bounded env39753 := by
  intro p hp
  have h : env39753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39752_39753 : H12AffineEnvironment.transform 9 320 env39752 = env39753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39752 == env39753) = true)

theorem identity39753 : scanCanonicalize (H12AffineFastState.compose env39753 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39753 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39754 : List Nat := [2,4,8,16,32,64,8,5,512,69,2048,97,89,32,113,34,65,2160,69,112,32,32,17,115,89,64,2048,65,97,2160,101,32,5,80,113,512]

theorem envBound39754 : H12AffineFastState.Bounded env39754 := by
  intro p hp
  have h : env39754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39753_39754 : H12AffineEnvironment.transform 7 5 env39753 = env39754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39753 == env39754) = true)

theorem identity39754 : scanCanonicalize (H12AffineFastState.compose env39754 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound39754 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env39755 : List Nat := [2,4,8,16,32,64,8,5,512,69,112,97,89,32,113,34,65,0,69,112,32,32,17,115,89,64,112,65,97,0,101,32,5,80,113,512]

theorem envBound39755 : H12AffineFastState.Bounded env39755 := by
  intro p hp
  have h : env39755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39754_39755 : H12AffineEnvironment.transform 10 112 env39754 = env39755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env39754 == env39755) = true)

theorem identity39755 : scanCanonicalize (H12AffineFastState.compose env39755 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39755 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env39756 : List Nat := [2,4,8,16,32,17,8,5,512,20,33,48,8,32,32,34,16,0,20,33,32,32,17,34,8,17,33,16,48,0,52,32,5,1,32,512]

theorem envBound39756 : H12AffineFastState.Bounded env39756 := by
  intro p hp
  have h : env39756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39755_39756 : H12AffineEnvironment.transform 5 17 env39755 = env39756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39755 == env39756) = true)

theorem identity39756 : scanCanonicalize (H12AffineFastState.compose env39756 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound39756 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env39757 : List Nat := [2,4,8,16,32,17,8,5,32,20,33,48,8,32,32,34,16,0,20,33,32,32,17,34,8,17,33,16,48,0,52,32,5,1,32,32]

theorem envBound39757 : H12AffineFastState.Bounded env39757 := by
  intro p hp
  have h : env39757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39756_39757 : H12AffineEnvironment.transform 8 32 env39756 = env39757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env39756 == env39757) = true)

theorem identity39757 : scanCanonicalize (H12AffineFastState.compose env39757 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39757 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env39758 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,16,8,0,0,2,16,0,20,1,0,0,17,2,8,17,1,16,16,0,20,0,5,1,0,0]

theorem envBound39758 : H12AffineFastState.Bounded env39758 := by
  intro p hp
  have h : env39758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39757_39758 : H12AffineEnvironment.transform 4 0 env39757 = env39758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39757 == env39758) = true)

theorem identity39758 : scanCanonicalize (H12AffineFastState.compose env39758 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound39758 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39759 : List Nat := [2,4,7,16,0,17,7,5,0,20,1,16,7,0,0,2,16,0,20,1,0,0,17,2,7,17,1,16,16,0,20,0,5,1,0,0]

theorem envBound39759 : H12AffineFastState.Bounded env39759 := by
  intro p hp
  have h : env39759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39758_39759 : H12AffineEnvironment.transform 2 7 env39758 = env39759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env39758 == env39759) = true)

def env39760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,8388608,73856,8328,64,8828320,79131,8491335,8819968,8430737,98679,256,8462394,8492191,8487751]

theorem envBound39760 : H12AffineFastState.Bounded env39760 := by
  intro p hp
  have h : env39760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39734_39760 : H12AffineEnvironment.transform 21 33 env39734 = env39760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39734 == env39760) = true)

theorem identity39760 : scanCanonicalize (H12AffineFastState.compose env39760 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound39760 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,152,73856,8328,64,439608,79131,102879,431512,41993,98679,256,73890,103431,99295]

theorem envBound39761 : H12AffineFastState.Bounded env39761 := by
  intro p hp
  have h : env39761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39760_39761 : H12AffineEnvironment.transform 22 152 env39760 = env39761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env39760 == env39761) = true)

def env39762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,16,73736,8192,64,439608,79131,102743,431376,41993,98679,256,73770,103431,99159]

theorem envBound39762 : H12AffineFastState.Bounded env39762 := by
  intro p hp
  have h : env39762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39761_39762 : H12AffineEnvironment.transform 6 8 env39761 = env39762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39761 == env39762) = true)

def env39763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5392,262144,1024,32769,102679,33,16,73736,8192,64,303144,79131,102743,294912,41993,98679,256,73770,103431,99159]

theorem envBound39763 : H12AffineFastState.Bounded env39763 := by
  intro p hp
  have h : env39763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39762_39763 : H12AffineEnvironment.transform 16 5392 env39762 = env39763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env39762 == env39763) = true)

theorem identity39763 : scanCanonicalize (H12AffineFastState.compose env39763 (packedSelected [1,3,5,8,10,11,12,15,18,19,23,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound39763 : packedSelected [1,3,5,8,10,11,12,15,18,19,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env39764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5392,10281,1024,32769,102679,33,16,73736,8192,64,34817,79131,102743,43049,41993,98679,256,73770,103431,99159]

theorem envBound39764 : H12AffineFastState.Bounded env39764 := by
  intro p hp
  have h : env39764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39763_39764 : H12AffineEnvironment.transform 17 10281 env39763 = env39764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39763 == env39764) = true)

theorem identity39764 : scanCanonicalize (H12AffineFastState.compose env39764 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound39764 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env39765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,5392,10281,1024,32769,4160,33,16,41311,8192,64,34817,46156,4096,43049,41993,32,256,41341,5456,512]

theorem envBound39765 : H12AffineFastState.Bounded env39765 := by
  intro p hp
  have h : env39765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39764_39765 : H12AffineEnvironment.transform 15 33111 env39764 = env39765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env39764 == env39765) = true)

theorem identity39765 : scanCanonicalize (H12AffineFastState.compose env39765 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 13357) := by decide +kernel

theorem selectedBound39765 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,13357,13690,5392,10281,1024,13356,4160,33,16,5490,8192,64,15404,97,4096,7172,4132,32,256,5456,5456,512]

theorem envBound39766 : H12AffineFastState.Bounded env39766 := by
  intro p hp
  have h : env39766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39765_39766 : H12AffineEnvironment.transform 14 13357 env39765 = env39766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13357 env39765 == env39766) = true)

theorem identity39766 : scanCanonicalize (H12AffineFastState.compose env39766 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound39766 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3156,8192,2389,10361,10542,2372,10281,1024,10360,3092,33,16,2342,8192,64,8312,97,3156,80,3184,32,256,2308,2308,512]

theorem envBound39767 : H12AffineFastState.Bounded env39767 := by
  intro p hp
  have h : env39767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39766_39767 : H12AffineEnvironment.transform 11 3156 env39766 = env39767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env39766 == env39767) = true)

theorem identity39767 : scanCanonicalize (H12AffineFastState.compose env39767 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 1377) := by decide +kernel

theorem selectedBound39767 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1377,309,8192,1076,9496,9295,1061,9544,1024,9497,373,33,16,1095,8192,64,8312,97,309,80,273,32,256,1125,1125,512]

theorem envBound39768 : H12AffineFastState.Bounded env39768 := by
  intro p hp
  have h : env39768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39767_39768 : H12AffineEnvironment.transform 10 1377 env39767 = env39768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1377 env39767 == env39768) = true)

theorem identity39768 : scanCanonicalize (H12AffineFastState.compose env39768 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound39768 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env39769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1377,309,1085,1076,293,114,1061,373,1024,292,373,33,16,1095,1085,64,1093,97,309,80,273,32,256,1125,1125,512]

theorem envBound39769 : H12AffineFastState.Bounded env39769 := by
  intro p hp
  have h : env39769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39768_39769 : H12AffineEnvironment.transform 12 1085 env39768 = env39769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env39768 == env39769) = true)

theorem identity39769 : scanCanonicalize (H12AffineFastState.compose env39769 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39769 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env39770 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1045,65,1085,1076,81,114,1061,1,1024,80,1,33,16,1095,1085,64,1093,97,65,80,101,32,116,1125,1125,512]

theorem envBound39770 : H12AffineFastState.Bounded env39770 := by
  intro p hp
  have h : env39770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39769_39770 : H12AffineEnvironment.transform 7 116 env39769 = env39770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39769 == env39770) = true)

theorem identity39770 : scanCanonicalize (H12AffineFastState.compose env39770 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39770 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39771 : List Nat := [2,4,8,16,1,64,8,85,512,1024,1045,65,1052,1045,81,83,1028,1,1024,80,1,0,16,1095,1052,64,1093,64,65,80,68,1,85,1092,1092,512]

theorem envBound39771 : H12AffineFastState.Bounded env39771 := by
  intro p hp
  have h : env39771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39770_39771 : H12AffineEnvironment.transform 4 1 env39770 = env39771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39770 == env39771) = true)

theorem identity39771 : scanCanonicalize (H12AffineFastState.compose env39771 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39771 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39772 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1045,16,1052,1045,0,2,1028,1,1024,1,1,0,16,1046,1052,17,1044,17,16,1,21,1,4,1045,1045,512]

theorem envBound39772 : H12AffineFastState.Bounded env39772 := by
  intro p hp
  have h : env39772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39771_39772 : H12AffineEnvironment.transform 5 17 env39771 = env39772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39771 == env39772) = true)

theorem identity39772 : scanCanonicalize (H12AffineFastState.compose env39772 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound39772 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39773 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,16,9,0,0,2,17,1,21,1,1,0,16,3,9,17,1,17,16,1,21,1,4,0,0,512]

theorem envBound39773 : H12AffineFastState.Bounded env39773 := by
  intro p hp
  have h : env39773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39772_39773 : H12AffineEnvironment.transform 9 21 env39772 = env39773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39772 == env39773) = true)

theorem identity39773 : scanCanonicalize (H12AffineFastState.compose env39773 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39774 : List Nat := [2,4,8,1,1,0,8,4,512,4,0,1,9,0,0,2,0,1,4,1,1,0,1,3,9,0,1,0,1,1,4,1,4,0,0,512]

theorem envBound39774 : H12AffineFastState.Bounded env39774 := by
  intro p hp
  have h : env39774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39773_39774 : H12AffineEnvironment.transform 3 1 env39773 = env39774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39773 == env39774) = true)

theorem identity39774 : scanCanonicalize (H12AffineFastState.compose env39774 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound39774 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39775 : List Nat := [2,4,8,1,1,0,8,4,15,4,0,1,9,0,0,2,0,1,4,1,1,0,1,3,9,0,1,0,1,1,4,1,4,0,0,15]

theorem envBound39775 : H12AffineFastState.Bounded env39775 := by
  intro p hp
  have h : env39775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39774_39775 : H12AffineEnvironment.transform 8 15 env39774 = env39775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env39774 == env39775) = true)

def env39776 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,262144,1024,32769,102679,33,16,73736,8192,64,303145,79131,102743,294913,41993,98679,256,73770,103431,99159]

theorem envBound39776 : H12AffineFastState.Bounded env39776 := by
  intro p hp
  have h : env39776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39762_39776 : H12AffineEnvironment.transform 16 5393 env39762 = env39776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39762 == env39776) = true)

theorem identity39776 : scanCanonicalize (H12AffineFastState.compose env39776 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound39776 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39777 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,5393,262144,1024,32769,4161,33,16,41310,8192,64,303145,46157,4097,294913,41993,33,256,41340,5457,513]

theorem envBound39777 : H12AffineFastState.Bounded env39777 := by
  intro p hp
  have h : env39777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39776_39777 : H12AffineEnvironment.transform 15 33110 env39776 = env39777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env39776 == env39777) = true)

theorem identity39777 : scanCanonicalize (H12AffineFastState.compose env39777 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39777 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5393,262144,1024,8540,4161,33,16,3,8192,64,262516,5392,4097,270684,1364,33,256,33,5457,513]

theorem envBound39778 : H12AffineFastState.Bounded env39778 := by
  intro p hp
  have h : env39778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39777_39778 : H12AffineEnvironment.transform 14 8541 env39777 = env39778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39777 == env39778) = true)

theorem identity39778 : scanCanonicalize (H12AffineFastState.compose env39778 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39778 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,262,5393,262144,1024,81,4161,33,16,3,269,64,262516,5392,4097,262225,1364,33,256,33,5457,513]

theorem envBound39779 : H12AffineFastState.Bounded env39779 := by
  intro p hp
  have h : env39779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39778_39779 : H12AffineEnvironment.transform 12 269 env39778 = env39779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39778 == env39779) = true)

theorem identity39779 : scanCanonicalize (H12AffineFastState.compose env39779 (packedSelected [0,4,5,7,8,9,12] rootPS)) = affineNative (2^(17+1) ^^^ 6453) := by decide +kernel

theorem selectedBound39779 : packedSelected [0,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env39780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,262,5393,6453,1024,81,4161,33,16,3,269,64,6209,5392,4097,6500,1364,33,256,33,5457,513]

theorem envBound39780 : H12AffineFastState.Bounded env39780 := by
  intro p hp
  have h : env39780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39779_39780 : H12AffineEnvironment.transform 17 6453 env39779 = env39780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6453 env39779 == env39780) = true)

theorem identity39780 : scanCanonicalize (H12AffineFastState.compose env39780 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound39780 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env39781 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,65,269,1344,80,262,1360,2420,1024,81,0,33,16,3,269,64,2048,1361,64,2341,1364,33,256,33,1296,513]

theorem envBound39781 : H12AffineFastState.Bounded env39781 := by
  intro p hp
  have h : env39781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39780_39781 : H12AffineEnvironment.transform 11 65 env39780 = env39781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env39780 == env39781) = true)

theorem identity39781 : scanCanonicalize (H12AffineFastState.compose env39781 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound39781 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env39782 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,65,269,293,80,262,309,2420,101,81,0,33,16,3,269,64,2048,308,64,2341,305,33,256,33,373,513]

theorem envBound39782 : H12AffineFastState.Bounded env39782 := by
  intro p hp
  have h : env39782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39781_39782 : H12AffineEnvironment.transform 9 101 env39781 = env39782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env39781 == env39782) = true)

def env39783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,33,17,73737,8193,64,439608,79131,102742,431377,41993,98679,256,73771,103431,99158]

theorem envBound39783 : H12AffineFastState.Bounded env39783 := by
  intro p hp
  have h : env39783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39761_39783 : H12AffineEnvironment.transform 6 9 env39761 = env39783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39761 == env39783) = true)

theorem identity39783 : scanCanonicalize (H12AffineFastState.compose env39783 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound39783 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1024,32769,102679,33,17,73737,8193,64,146508,79131,102742,138341,41993,98679,256,73771,103431,99158]

theorem envBound39784 : H12AffineFastState.Bounded env39784 := by
  intro p hp
  have h : env39784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39783_39784 : H12AffineEnvironment.transform 17 35188 env39783 = env39784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env39783 == env39784) = true)

theorem identity39784 : scanCanonicalize (H12AffineFastState.compose env39784 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound39784 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,13341,35188,1024,32769,102679,33,17,73737,8193,64,2129,79131,102742,10360,41993,98679,256,73771,103431,99158]

theorem envBound39785 : H12AffineFastState.Bounded env39785 := by
  intro p hp
  have h : env39785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39784_39785 : H12AffineEnvironment.transform 16 13341 env39784 = env39785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env39784 == env39785) = true)

theorem identity39785 : scanCanonicalize (H12AffineFastState.compose env39785 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound39785 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39786 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,65536,13341,2340,1024,81,69959,33,17,73737,8193,64,2129,79131,69894,10360,9305,65831,256,73771,70743,66310]

theorem envBound39786 : H12AffineFastState.Bounded env39786 := by
  intro p hp
  have h : env39786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39785_39786 : H12AffineEnvironment.transform 14 80 env39785 = env39786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env39785 == env39786) = true)

theorem identity39786 : scanCanonicalize (H12AffineFastState.compose env39786 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39786 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env39787 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,263,13341,2340,1024,81,4160,33,17,8462,8193,64,2129,13340,4097,10360,9305,32,256,8492,5456,513]

theorem envBound39787 : H12AffineFastState.Bounded env39787 := by
  intro p hp
  have h : env39787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39786_39787 : H12AffineEnvironment.transform 15 263 env39786 = env39787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39786 == env39787) = true)

theorem identity39787 : scanCanonicalize (H12AffineFastState.compose env39787 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39787 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,80,263,5440,2340,1024,81,4160,33,17,83,348,64,2129,5441,4097,2341,1284,32,256,113,5456,513]

theorem envBound39788 : H12AffineFastState.Bounded env39788 := by
  intro p hp
  have h : env39788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39787_39788 : H12AffineEnvironment.transform 12 349 env39787 = env39788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39787 == env39788) = true)

theorem identity39788 : scanCanonicalize (H12AffineFastState.compose env39788 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound39788 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env39789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,349,3345,80,263,3408,2340,1024,81,2128,33,17,83,348,64,2129,3409,2065,2341,1284,32,256,113,3392,513]

theorem envBound39789 : H12AffineFastState.Bounded env39789 := by
  intro p hp
  have h : env39789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39788_39789 : H12AffineEnvironment.transform 11 2064 env39788 = env39789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env39788 == env39789) = true)

theorem identity39789 : scanCanonicalize (H12AffineFastState.compose env39789 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound39789 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39790 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2064,349,2049,80,263,2112,2340,272,81,2128,33,17,83,348,64,2129,2113,2065,2341,20,32,256,113,2128,513]

theorem envBound39790 : H12AffineFastState.Bounded env39790 := by
  intro p hp
  have h : env39790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39789_39790 : H12AffineEnvironment.transform 9 272 env39789 = env39790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env39789 == env39790) = true)

def env39791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265169,23160256,257,27378861,27337992,25207750]

theorem envBound39791 : H12AffineFastState.Bounded env39791 := by
  intro p hp
  have h : env39791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39566_39791 : H12AffineEnvironment.transform 18 1025 env39566 = env39791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env39566 == env39791) = true)

theorem identity39791 : scanCanonicalize (H12AffineFastState.compose env39791 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10626199) := by decide +kernel

theorem selectedBound39791 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10626199,8328,64,6677654,8626202,10507601,8830976,2334854,12796247,257,254010,197023,2262865]

theorem envBound39792 : H12AffineFastState.Bounded env39792 := by
  intro p hp
  have h : env39792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39791_39792 : H12AffineEnvironment.transform 23 10626199 env39791 = env39792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10626199 env39791 == env39792) = true)

def env39793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,156116,2114883,8328,64,6677654,115150,2241669,303572,2334854,4268163,257,254010,197023,2262865]

theorem envBound39793 : H12AffineFastState.Bounded env39793 := by
  intro p hp
  have h : env39793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39792_39793 : H12AffineEnvironment.transform 22 156116 env39792 = env39793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 156116 env39792 == env39793) = true)

def env39794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534864,156116,2114883,8328,64,215366,115150,2241669,303572,2334854,2592083,257,254010,197023,2262865]

theorem envBound39794 : H12AffineFastState.Bounded env39794 := by
  intro p hp
  have h : env39794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39793_39794 : H12AffineEnvironment.transform 21 2534864 env39793 = env39794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534864 env39793 == env39794) = true)

def env39795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156116,21763,8328,64,215366,115150,140485,303572,241862,498963,257,254010,197023,169745]

theorem envBound39795 : H12AffineFastState.Bounded env39795 := by
  intro p hp
  have h : env39795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39794_39795 : H12AffineEnvironment.transform 20 4160 env39794 = env39795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39794 == env39795) = true)

theorem identity39795 : scanCanonicalize (H12AffineFastState.compose env39795 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39795 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,441744,156116,21763,8328,64,158029,57797,140485,303572,168141,441624,257,180273,139668,169745]

theorem envBound39796 : H12AffineFastState.Bounded env39796 := by
  intro p hp
  have h : env39796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39795_39796 : H12AffineEnvironment.transform 15 8203 env39795 = env39796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39795 == env39796) = true)

theorem identity39796 : scanCanonicalize (H12AffineFastState.compose env39796 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound39796 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env39797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,4160,272512,62660,21763,8328,64,64605,57797,45525,303572,1501,272392,257,21793,46212,513]

theorem envBound39797 : H12AffineFastState.Bounded env39797 := by
  intro p hp
  have h : env39797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39796_39797 : H12AffineEnvironment.transform 16 38160 env39796 = env39797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env39796 == env39797) = true)

theorem identity39797 : scanCanonicalize (H12AffineFastState.compose env39797 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound39797 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env39798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,16401,262144,1025,21760,4160,272512,8645,21763,8328,64,10588,13508,25812,292053,1501,272392,257,21793,24965,513]

theorem envBound39798 : H12AffineFastState.Bounded env39798 := by
  intro p hp
  have h : env39798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39797_39798 : H12AffineEnvironment.transform 14 21761 env39797 = env39798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env39797 == env39798) = true)

theorem identity39798 : scanCanonicalize (H12AffineFastState.compose env39798 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound39798 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,479,16401,262144,1025,21760,4160,264532,17,21763,348,64,2184,5392,17664,283905,1501,264668,257,21793,16465,513]

theorem envBound39799 : H12AffineFastState.Bounded env39799 := by
  intro p hp
  have h : env39799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39798_39799 : H12AffineEnvironment.transform 12 468 env39798 = env39799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env39798 == env39799) = true)

theorem identity39799 : scanCanonicalize (H12AffineFastState.compose env39799 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound39799 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21761,479,16401,2557,1025,21760,4160,169,17,21763,348,64,2184,5392,17664,23804,1501,33,257,21793,16465,513]

theorem envBound39800 : H12AffineFastState.Bounded env39800 := by
  intro p hp
  have h : env39800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39799_39800 : H12AffineEnvironment.transform 17 2557 env39799 = env39800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env39799 == env39800) = true)

theorem identity39800 : scanCanonicalize (H12AffineFastState.compose env39800 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39800 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,343,16401,2421,1025,21760,4160,33,17,21763,348,64,2048,5392,17664,23668,1365,33,257,21793,16465,513]

theorem envBound39801 : H12AffineFastState.Bounded env39801 := by
  intro p hp
  have h : env39801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39800_39801 : H12AffineEnvironment.transform 6 8 env39800 = env39801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39800 == env39801) = true)

theorem identity39801 : scanCanonicalize (H12AffineFastState.compose env39801 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7284) := by decide +kernel

theorem selectedBound39801 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,7284,2421,343,7269,2421,1025,2420,4160,33,17,2423,348,64,2048,5392,6516,0,1365,33,257,2389,7205,513]

theorem envBound39802 : H12AffineFastState.Bounded env39802 := by
  intro p hp
  have h : env39802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39801_39802 : H12AffineEnvironment.transform 13 7284 env39801 = env39802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7284 env39801 == env39802) = true)

theorem identity39802 : scanCanonicalize (H12AffineFastState.compose env39802 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2318) := by decide +kernel

theorem selectedBound39802 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env39803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2318,348,1402,2421,343,1387,2421,1025,2420,2382,33,17,2423,348,64,2048,3102,122,0,1365,33,257,2389,1323,513]

end H12CloudChart0