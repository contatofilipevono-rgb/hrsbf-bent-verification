import H12CloudChart0Data132

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound33749 : H12AffineFastState.Bounded env33749 := by
  intro p hp
  have h : env33749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33453_33749 : H12AffineEnvironment.transform 26 30393345 env33453 = env33749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env33453 == env33749) = true)

def env33750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265169,23160257,256,27378861,27337993,25207751]

theorem envBound33750 : H12AffineFastState.Bounded env33750 := by
  intro p hp
  have h : env33750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33749_33750 : H12AffineEnvironment.transform 18 1024 env33749 = env33750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env33749 == env33750) = true)

theorem identity33750 : scanCanonicalize (H12AffineFastState.compose env33750 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2188635) := by decide +kernel

theorem selectedBound33750 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2188635,16777216,8328,64,23504218,18973836,77835,2598235,18932042,23160257,256,16818678,16793682,18990748]

theorem envBound33751 : H12AffineFastState.Bounded env33751 := by
  intro p hp
  have h : env33751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33750_33751 : H12AffineEnvironment.transform 22 2188635 env33750 = env33751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2188635 env33750 == env33751) = true)

def env33752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,16777216,8328,64,17227834,18973836,77835,2598235,18932042,16851105,256,16818678,16793682,18990748]

theorem envBound33752 : H12AffineFastState.Bounded env33752 := by
  intro p hp
  have h : env33752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33751_33752 : H12AffineEnvironment.transform 21 2114912 env33751 = env33752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env33751 == env33752) = true)

def env33753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,2175168,8328,64,2609402,46156,77835,2598235,119178,2101345,256,2199862,2191506,63068]

theorem envBound33753 : H12AffineFastState.Bounded env33753 := by
  intro p hp
  have h : env33753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33752_33753 : H12AffineEnvironment.transform 23 2175168 env33752 = env33753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175168 env33752 == env33753) = true)

def env33754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21792,95515,73856,8328,64,508090,46156,77835,505115,119178,33,256,98678,90322,63068]

theorem envBound33754 : H12AffineFastState.Bounded env33754 := by
  intro p hp
  have h : env33754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33753_33754 : H12AffineEnvironment.transform 20 4160 env33753 = env33754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33753 == env33754) = true)

theorem identity33754 : scanCanonicalize (H12AffineFastState.compose env33754 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound33754 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,21792,95515,73856,8328,64,472175,16537,77835,475598,75103,33,256,95651,90322,649]

theorem envBound33755 : H12AffineFastState.Bounded env33755 := by
  intro p hp
  have h : env33755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33754_33755 : H12AffineEnvironment.transform 14 29909 env33754 = env33755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env33754 == env33755) = true)

def env33756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,21792,95515,73736,8192,64,472175,16401,77835,475462,75103,33,256,95531,90202,513]

theorem envBound33756 : H12AffineFastState.Bounded env33756 := by
  intro p hp
  have h : env33756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33755_33756 : H12AffineEnvironment.transform 6 8 env33755 = env33756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33755 == env33756) = true)

theorem identity33756 : scanCanonicalize (H12AffineFastState.compose env33756 (packedSelected [0,2,3,4,6,7,9,10,11,14,15,16,18,20,21,23,24,26,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound33756 : packedSelected [0,2,3,4,6,7,9,10,11,14,15,16,18,20,21,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env33757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,2340,1024,29788,4160,21792,95515,73736,8192,64,212299,16401,77835,215138,75103,33,256,95531,90202,513]

theorem envBound33757 : H12AffineFastState.Bounded env33757 := by
  intro p hp
  have h : env33757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33756_33757 : H12AffineEnvironment.transform 17 2340 env33756 = env33757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env33756 == env33757) = true)

theorem identity33757 : scanCanonicalize (H12AffineFastState.compose env33757 (packedSelected [0,2,6,7,18,20,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33757 : packedSelected [0,2,6,7,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env33758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13340,2340,1024,29788,4160,21792,95515,73736,8192,64,67927,16401,77835,97406,75103,33,256,95531,90202,513]

theorem envBound33758 : H12AffineFastState.Bounded env33758 := by
  intro p hp
  have h : env33758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33757_33758 : H12AffineEnvironment.transform 16 13340 env33757 = env33758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env33757 == env33758) = true)

theorem identity33758 : scanCanonicalize (H12AffineFastState.compose env33758 (packedSelected [0,1,7,8,12,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33758 : packedSelected [0,1,7,8,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env33759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,5440,2340,1024,21760,4160,21792,87111,65876,348,64,67927,16401,69975,89378,66563,33,256,87159,82182,513]

theorem envBound33759 : H12AffineFastState.Bounded env33759 := by
  intro p hp
  have h : env33759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33758_33759 : H12AffineEnvironment.transform 12 348 env33758 = env33759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33758 == env33759) = true)

theorem identity33759 : scanCanonicalize (H12AffineFastState.compose env33759 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound33759 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env33760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,342,5440,2340,1024,21760,4160,21792,21777,2,348,64,2049,16401,4097,23668,1365,33,256,21793,16464,513]

theorem envBound33760 : H12AffineFastState.Bounded env33760 := by
  intro p hp
  have h : env33760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33759_33760 : H12AffineEnvironment.transform 15 342 env33759 = env33760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env33759 == env33760) = true)

theorem identity33760 : scanCanonicalize (H12AffineFastState.compose env33760 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33760 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33761 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21761,262,5392,2340,1024,21760,4112,21792,21777,2,268,16,2049,16401,4097,23588,1285,33,256,21793,16384,513]

theorem envBound33761 : H12AffineFastState.Bounded env33761 := by
  intro p hp
  have h : env33761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33760_33761 : H12AffineEnvironment.transform 5 16 env33760 = env33761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33760 == env33761) = true)

theorem identity33761 : scanCanonicalize (H12AffineFastState.compose env33761 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33761 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33762 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1024,0,4112,32,17,2,268,16,2049,5393,4097,2340,1285,33,256,33,5376,513]

theorem envBound33762 : H12AffineFastState.Bounded env33762 := by
  intro p hp
  have h : env33762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33761_33762 : H12AffineEnvironment.transform 13 5376 env33761 = env33762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33761 == env33762) = true)

theorem identity33762 : scanCanonicalize (H12AffineFastState.compose env33762 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound33762 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33763 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,277,268,1045,1,262,1029,2340,1024,0,261,32,17,2,268,16,2049,1028,276,2340,1285,33,256,33,1045,513]

theorem envBound33763 : H12AffineFastState.Bounded env33763 := by
  intro p hp
  have h : env33763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33762_33763 : H12AffineEnvironment.transform 11 277 env33762 = env33763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env33762 == env33763) = true)

theorem identity33763 : scanCanonicalize (H12AffineFastState.compose env33763 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33763 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33764 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,277,268,0,1,262,16,2340,21,0,261,32,17,2,268,16,2049,17,276,2340,272,33,256,33,0,513]

theorem envBound33764 : H12AffineFastState.Bounded env33764 := by
  intro p hp
  have h : env33764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33763_33764 : H12AffineEnvironment.transform 9 21 env33763 = env33764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33763 == env33764) = true)

theorem identity33764 : scanCanonicalize (H12AffineFastState.compose env33764 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound33764 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33765 : List Nat := [2,4,8,16,32,16,8,256,33,21,2048,277,268,0,1,262,16,2340,21,0,261,32,17,2,268,16,2049,17,276,2340,272,33,256,33,0,32]

theorem envBound33765 : H12AffineFastState.Bounded env33765 := by
  intro p hp
  have h : env33765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33764_33765 : H12AffineEnvironment.transform 8 33 env33764 = env33765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env33764 == env33765) = true)

theorem identity33765 : scanCanonicalize (H12AffineFastState.compose env33765 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound33765 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33766 : List Nat := [2,4,8,16,32,16,8,256,33,21,309,277,268,0,1,262,16,17,21,0,261,32,17,2,268,16,308,17,276,17,272,33,256,33,0,32]

theorem envBound33766 : H12AffineFastState.Bounded env33766 := by
  intro p hp
  have h : env33766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33765_33766 : H12AffineEnvironment.transform 10 309 env33765 = env33766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env33765 == env33766) = true)

theorem identity33766 : scanCanonicalize (H12AffineFastState.compose env33766 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound33766 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33767 : List Nat := [2,4,8,16,32,16,8,53,33,21,0,32,57,0,1,51,16,17,21,0,48,32,17,2,57,16,1,17,33,17,37,33,53,33,0,32]

theorem envBound33767 : H12AffineFastState.Bounded env33767 := by
  intro p hp
  have h : env33767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33766_33767 : H12AffineEnvironment.transform 7 53 env33766 = env33767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env33766 == env33767) = true)

theorem identity33767 : scanCanonicalize (H12AffineFastState.compose env33767 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33767 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33768 : List Nat := [2,4,8,16,17,16,8,4,16,21,0,17,8,0,1,2,16,17,21,0,1,17,17,2,8,16,1,17,16,17,20,16,4,16,0,17]

theorem envBound33768 : H12AffineFastState.Bounded env33768 := by
  intro p hp
  have h : env33768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33767_33768 : H12AffineEnvironment.transform 4 17 env33767 = env33768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33767 == env33768) = true)

theorem identity33768 : scanCanonicalize (H12AffineFastState.compose env33768 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33769 : List Nat := [2,4,8,0,1,0,8,4,0,5,0,1,8,0,1,2,0,1,5,0,1,1,1,2,8,0,1,1,0,1,4,0,4,0,0,1]

theorem envBound33769 : H12AffineFastState.Bounded env33769 := by
  intro p hp
  have h : env33769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33768_33769 : H12AffineEnvironment.transform 3 0 env33768 = env33769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33768 == env33769) = true)

def env33770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,21792,95515,73737,8193,64,472175,16400,77835,475463,75103,33,256,95530,90203,512]

theorem envBound33770 : H12AffineFastState.Bounded env33770 := by
  intro p hp
  have h : env33770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33755_33770 : H12AffineEnvironment.transform 6 9 env33755 = env33770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33755 == env33770) = true)

theorem identity33770 : scanCanonicalize (H12AffineFastState.compose env33770 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound33770 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env33771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,131072,262144,1024,29789,4160,21792,17,21763,8193,64,409957,16400,17665,406605,20565,33,256,32,5457,512]

theorem envBound33771 : H12AffineFastState.Bounded env33771 := by
  intro p hp
  have h : env33771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33770_33771 : H12AffineEnvironment.transform 15 29962 env33770 = env33771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env33770 == env33771) = true)

theorem identity33771 : scanCanonicalize (H12AffineFastState.compose env33771 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10588) := by decide +kernel

theorem selectedBound33771 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env33772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,131072,10588,1024,29789,4160,21792,17,21763,8193,64,157753,16400,17665,138513,20565,33,256,32,5457,512]

theorem envBound33772 : H12AffineFastState.Bounded env33772 := by
  intro p hp
  have h : env33772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33771_33772 : H12AffineEnvironment.transform 17 10588 env33771 = env33772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10588 env33771 == env33772) = true)

theorem identity33772 : scanCanonicalize (H12AffineFastState.compose env33772 (packedSelected [0,1,3,4,5,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 13640) := by decide +kernel

theorem selectedBound33772 : packedSelected [0,1,3,4,5,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env33773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,13640,10588,1024,29789,4160,21792,17,21763,8193,64,23921,16400,17665,10329,20565,33,256,32,5457,512]

theorem envBound33773 : H12AffineFastState.Bounded env33773 := by
  intro p hp
  have h : env33773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33772_33773 : H12AffineEnvironment.transform 16 13640 env33772 = env33773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13640 env33772 == env33773) = true)

theorem identity33773 : scanCanonicalize (H12AffineFastState.compose env33773 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound33773 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8232,8574,13640,10588,1024,8233,4160,340,17,375,8193,64,2309,5220,4469,10329,1057,33,256,32,5457,512]

theorem envBound33774 : H12AffineFastState.Bounded env33774 := by
  intro p hp
  have h : env33774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33773_33774 : H12AffineEnvironment.transform 13 5236 env33773 = env33774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env33773 == env33774) = true)

theorem identity33774 : scanCanonicalize (H12AffineFastState.compose env33774 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound33774 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env33775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5236,80,262,5424,2340,1024,81,4160,340,17,375,121,64,2309,5220,4469,2081,1057,33,256,32,5457,512]

theorem envBound33775 : H12AffineFastState.Bounded env33775 := by
  intro p hp
  have h : env33775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33774_33775 : H12AffineEnvironment.transform 12 120 env33774 = env33775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env33774 == env33775) = true)

theorem identity33775 : scanCanonicalize (H12AffineFastState.compose env33775 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33775 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33776 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5236,80,35,5141,2049,1024,81,4160,113,17,82,121,64,2080,5220,4176,2081,1057,33,37,32,5236,512]

theorem envBound33776 : H12AffineFastState.Bounded env33776 := by
  intro p hp
  have h : env33776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33775_33776 : H12AffineEnvironment.transform 7 37 env33775 = env33776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33775 == env33776) = true)

theorem identity33776 : scanCanonicalize (H12AffineFastState.compose env33776 (packedSelected [0,1,2,7,8,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound33776 : packedSelected [0,1,2,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33777 : List Nat := [2,4,8,16,32,64,9,37,512,68,2048,4096,120,4144,80,35,4177,2049,68,81,4160,113,17,82,121,64,2080,4128,4176,2081,101,33,37,32,4144,512]

theorem envBound33777 : H12AffineFastState.Bounded env33777 := by
  intro p hp
  have h : env33777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33776_33777 : H12AffineEnvironment.transform 9 68 env33776 = env33777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env33776 == env33777) = true)

theorem identity33777 : scanCanonicalize (H12AffineFastState.compose env33777 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound33777 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33778 : List Nat := [2,4,8,16,32,48,9,37,512,52,2048,4096,8,4144,32,35,4129,2049,52,33,4144,1,17,34,9,48,2080,4128,4128,2081,21,33,37,32,4144,512]

theorem envBound33778 : H12AffineFastState.Bounded env33778 := by
  intro p hp
  have h : env33778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33777_33778 : H12AffineEnvironment.transform 5 48 env33777 = env33778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env33777 == env33778) = true)

theorem identity33778 : scanCanonicalize (H12AffineFastState.compose env33778 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33778 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33779 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8,4112,0,3,4097,2049,20,1,4112,1,17,2,9,16,2048,4096,4096,2049,21,1,5,0,4112,512]

theorem envBound33779 : H12AffineFastState.Bounded env33779 := by
  intro p hp
  have h : env33779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33778_33779 : H12AffineEnvironment.transform 4 0 env33778 = env33779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33778 == env33779) = true)

theorem identity33779 : scanCanonicalize (H12AffineFastState.compose env33779 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33779 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33780 : List Nat := [2,0,8,16,0,16,9,1,512,16,2048,4096,8,4112,0,3,4097,2049,16,1,4112,1,17,2,9,16,2048,4096,4096,2049,17,1,1,0,4112,512]

theorem envBound33780 : H12AffineFastState.Bounded env33780 := by
  intro p hp
  have h : env33780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33779_33780 : H12AffineEnvironment.transform 1 0 env33779 = env33780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33779 == env33780) = true)

theorem identity33780 : scanCanonicalize (H12AffineFastState.compose env33780 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 25) := by decide +kernel

theorem selectedBound33780 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33781 : List Nat := [2,0,8,16,0,16,9,1,512,16,25,4096,8,4112,0,3,4097,24,16,1,4112,1,17,2,9,16,25,4096,4096,24,17,1,1,0,4112,512]

theorem envBound33781 : H12AffineFastState.Bounded env33781 := by
  intro p hp
  have h : env33781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33780_33781 : H12AffineEnvironment.transform 10 25 env33780 = env33781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 25 env33780 == env33781) = true)

def env33782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73857,8328,64,508091,46156,77835,505114,119178,32,256,98679,90323,63068]

theorem envBound33782 : H12AffineFastState.Bounded env33782 := by
  intro p hp
  have h : env33782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33753_33782 : H12AffineEnvironment.transform 20 4161 env33753 = env33782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33753 == env33782) = true)

theorem identity33782 : scanCanonicalize (H12AffineFastState.compose env33782 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33782 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,4161,21793,95514,73857,8328,64,483815,5392,77835,463942,94422,32,256,73771,90323,22272]

theorem envBound33783 : H12AffineFastState.Bounded env33783 := by
  intro p hp
  have h : env33783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33782_33783 : H12AffineEnvironment.transform 14 8540 env33782 = env33783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33782 == env33783) = true)

def env33784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1024,8541,4161,21793,95514,73857,8328,64,215367,5392,77835,212198,94422,32,256,73771,90323,22272]

theorem envBound33784 : H12AffineFastState.Bounded env33784 := by
  intro p hp
  have h : env33784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33783_33784 : H12AffineEnvironment.transform 17 10400 env33783 = env33784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33783 == env33784) = true)

theorem identity33784 : scanCanonicalize (H12AffineFastState.compose env33784 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound33784 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10400,1024,8541,4161,21793,16,21899,8328,64,146509,5392,17665,149996,1500,32,256,21793,5593,22272]

theorem envBound33785 : H12AffineFastState.Bounded env33785 := by
  intro p hp
  have h : env33785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33784_33785 : H12AffineEnvironment.transform 15 29962 env33784 = env33785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env33784 == env33785) = true)

theorem identity33785 : scanCanonicalize (H12AffineFastState.compose env33785 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound33785 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,5392,10400,1024,8541,4161,21793,16,21899,8328,64,10589,5392,17665,23804,1500,32,256,21793,5593,22272]

theorem envBound33786 : H12AffineFastState.Bounded env33786 := by
  intro p hp
  have h : env33786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33785_33786 : H12AffineEnvironment.transform 16 5392 env33785 = env33786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33785 == env33786) = true)

theorem identity33786 : scanCanonicalize (H12AffineFastState.compose env33786 (packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound33786 : packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env33787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8540,8694,5392,10400,1024,8541,4161,477,16,375,8328,64,10589,5392,4605,2048,1500,32,256,477,5593,1020]

theorem envBound33787 : H12AffineFastState.Bounded env33787 := by
  intro p hp
  have h : env33787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33786_33787 : H12AffineEnvironment.transform 13 5372 env33786 = env33787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env33786 == env33787) = true)

theorem identity33787 : scanCanonicalize (H12AffineFastState.compose env33787 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound33787 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env33788 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5372,8353,8203,5357,10400,1024,8352,4161,32,16,138,8328,64,10400,5357,4096,2048,1057,32,253,32,5156,513]

theorem envBound33788 : H12AffineFastState.Bounded env33788 := by
  intro p hp
  have h : env33788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33787_33788 : H12AffineEnvironment.transform 7 253 env33787 = env33788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env33787 == env33788) = true)

theorem identity33788 : scanCanonicalize (H12AffineFastState.compose env33788 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33788 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33789 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5293,8353,8203,5308,10400,1024,8352,4112,32,16,138,8328,17,10400,5308,4096,2048,1057,32,172,32,5156,513]

theorem envBound33789 : H12AffineFastState.Bounded env33789 := by
  intro p hp
  have h : env33789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33788_33789 : H12AffineEnvironment.transform 5 17 env33788 = env33789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33788 == env33789) = true)

theorem identity33789 : scanCanonicalize (H12AffineFastState.compose env33789 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound33789 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33790 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,161,5293,0,170,5308,2049,1024,1,4112,32,16,138,41,17,2049,5308,4096,2048,1057,32,172,32,5156,513]

theorem envBound33790 : H12AffineFastState.Bounded env33790 := by
  intro p hp
  have h : env33790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33789_33790 : H12AffineEnvironment.transform 12 161 env33789 = env33790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env33789 == env33790) = true)

theorem identity33790 : scanCanonicalize (H12AffineFastState.compose env33790 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33790 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33791 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5157,0,34,5172,2049,1024,1,4112,32,16,2,41,17,2049,5172,4096,2048,1057,32,36,32,5156,513]

theorem envBound33791 : H12AffineFastState.Bounded env33791 := by
  intro p hp
  have h : env33791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33790_33791 : H12AffineEnvironment.transform 6 8 env33790 = env33791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33790 == env33791) = true)

theorem identity33791 : scanCanonicalize (H12AffineFastState.compose env33791 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33791 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33792 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4112,0,34,4097,2049,53,1,4112,32,16,2,41,17,2049,4097,4096,2048,20,32,36,32,4113,513]

theorem envBound33792 : H12AffineFastState.Bounded env33792 := by
  intro p hp
  have h : env33792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33791_33792 : H12AffineEnvironment.transform 9 53 env33791 = env33792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33791 == env33792) = true)

theorem identity33792 : scanCanonicalize (H12AffineFastState.compose env33792 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound33792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33793 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2065,41,2049,0,34,2064,2049,53,1,2049,32,16,2,41,17,2049,2064,2065,2048,20,32,36,32,2048,513]

theorem envBound33793 : H12AffineFastState.Bounded env33793 := by
  intro p hp
  have h : env33793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33792_33793 : H12AffineEnvironment.transform 11 2065 env33792 = env33793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env33792 == env33793) = true)

theorem identity33793 : scanCanonicalize (H12AffineFastState.compose env33793 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33794 : List Nat := [2,4,8,16,32,17,8,36,42,53,2048,2065,41,2049,0,34,2064,2049,53,1,2049,32,16,2,41,17,2049,2064,2065,2048,20,32,36,32,2048,43]

theorem envBound33794 : H12AffineFastState.Bounded env33794 := by
  intro p hp
  have h : env33794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33793_33794 : H12AffineEnvironment.transform 8 42 env33793 = env33794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33793 == env33794) = true)

def env33795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10401,1024,8541,4161,21793,95514,73857,8328,64,215366,5392,77835,212199,94422,32,256,73771,90323,22272]

theorem envBound33795 : H12AffineFastState.Bounded env33795 := by
  intro p hp
  have h : env33795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33783_33795 : H12AffineEnvironment.transform 17 10401 env33783 = env33795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env33783 == env33795) = true)

def env33796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10401,1024,8541,4161,33,73754,73857,8328,64,203846,5392,77835,212199,75222,32,256,73771,79315,512]

theorem envBound33796 : H12AffineFastState.Bounded env33796 := by
  intro p hp
  have h : env33796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33795_33796 : H12AffineEnvironment.transform 13 5376 env33795 = env33796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33795 == env33796) = true)

theorem identity33796 : scanCanonicalize (H12AffineFastState.compose env33796 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 67911) := by decide +kernel

theorem selectedBound33796 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env33797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,67911,10401,1024,8541,4161,33,73754,73857,8328,64,5377,5392,77835,13728,75222,32,256,73771,79315,512]

theorem envBound33797 : H12AffineFastState.Bounded env33797 := by
  intro p hp
  have h : env33797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33796_33797 : H12AffineEnvironment.transform 16 67911 env33796 = env33797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 67911 env33796 == env33797) = true)

theorem identity33797 : scanCanonicalize (H12AffineFastState.compose env33797 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33797 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8203,10572,10401,1024,8541,4161,33,17,138,8328,64,5377,5392,4096,13728,1501,32,256,32,5592,512]

theorem envBound33798 : H12AffineFastState.Bounded env33798 := by
  intro p hp
  have h : env33798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33797_33798 : H12AffineEnvironment.transform 15 8203 env33797 = env33798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33797 == env33798) = true)

theorem identity33798 : scanCanonicalize (H12AffineFastState.compose env33798 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound33798 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33799 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,5376,8540,8203,10572,10248,1024,8541,4161,33,17,35,8225,64,5377,5392,4096,13577,1396,32,256,32,5489,512]

theorem envBound33799 : H12AffineFastState.Bounded env33799 := by
  intro p hp
  have h : env33799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33798_33799 : H12AffineEnvironment.transform 6 41 env33798 = env33799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env33798 == env33799) = true)

def env33800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10401,1024,8541,4161,32,73755,73857,8328,64,203847,5392,77835,212199,75223,32,256,73771,79314,513]

theorem envBound33800 : H12AffineFastState.Bounded env33800 := by
  intro p hp
  have h : env33800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33795_33800 : H12AffineEnvironment.transform 13 5377 env33795 = env33800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33795 == env33800) = true)

theorem identity33800 : scanCanonicalize (H12AffineFastState.compose env33800 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound33800 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env33801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,13508,10401,1024,8541,4161,32,73755,73857,8328,64,75907,5392,77835,67619,75223,32,256,73771,79314,513]

theorem envBound33801 : H12AffineFastState.Bounded env33801 := by
  intro p hp
  have h : env33801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33800_33801 : H12AffineEnvironment.transform 16 13508 env33800 = env33801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env33800 == env33801) = true)

theorem identity33801 : scanCanonicalize (H12AffineFastState.compose env33801 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound33801 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env33802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,343,13508,10401,1024,8541,4161,32,8524,8662,8328,64,10708,5392,12636,2420,9344,32,256,8572,13445,513]

theorem envBound33802 : H12AffineFastState.Bounded env33802 := by
  intro p hp
  have h : env33802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33801_33802 : H12AffineEnvironment.transform 15 343 env33801 = env33802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env33801 == env33802) = true)

theorem identity33802 : scanCanonicalize (H12AffineFastState.compose env33802 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound33802 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env33803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,80,343,5576,2477,1024,81,4161,32,64,218,388,64,2264,5392,4176,2420,1420,32,256,112,5513,513]

theorem envBound33803 : H12AffineFastState.Bounded env33803 := by
  intro p hp
  have h : env33803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33802_33803 : H12AffineEnvironment.transform 12 268 env33802 = env33803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env33802 == env33803) = true)

theorem identity33803 : scanCanonicalize (H12AffineFastState.compose env33803 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33803 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env33804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,343,5441,2340,1024,81,4161,32,64,83,269,64,2129,5392,4176,2420,1285,32,256,112,5376,513]

theorem envBound33804 : H12AffineFastState.Bounded env33804 := by
  intro p hp
  have h : env33804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33803_33804 : H12AffineEnvironment.transform 6 9 env33803 = env33804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33803 == env33804) = true)

theorem identity33804 : scanCanonicalize (H12AffineFastState.compose env33804 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3418) := by decide +kernel

theorem selectedBound33804 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3418,268,2139,80,343,2075,2340,1024,81,3355,32,64,83,269,64,2129,2122,3338,2420,1285,32,256,112,2138,513]

theorem envBound33805 : H12AffineFastState.Bounded env33805 := by
  intro p hp
  have h : env33805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33804_33805 : H12AffineEnvironment.transform 11 3418 env33804 = env33805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3418 env33804 == env33805) = true)

theorem identity33805 : scanCanonicalize (H12AffineFastState.compose env33805 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33805 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33806 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3338,268,2059,0,263,2075,2340,1024,1,3355,32,16,3,269,16,2049,2074,3338,2340,1285,32,256,32,2058,513]

theorem envBound33806 : H12AffineFastState.Bounded env33806 := by
  intro p hp
  have h : env33806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33805_33806 : H12AffineEnvironment.transform 5 16 env33805 = env33806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33805 == env33806) = true)

theorem identity33806 : scanCanonicalize (H12AffineFastState.compose env33806 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 287) := by decide +kernel

theorem selectedBound33806 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33807 : List Nat := [2,4,8,16,32,16,9,256,512,1024,287,1045,268,276,0,263,260,59,1024,1,1028,32,16,3,269,16,286,261,1045,59,1285,32,256,32,277,513]

theorem envBound33807 : H12AffineFastState.Bounded env33807 := by
  intro p hp
  have h : env33807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33806_33807 : H12AffineEnvironment.transform 10 287 env33806 = env33807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 287 env33806 == env33807) = true)

theorem identity33807 : scanCanonicalize (H12AffineFastState.compose env33807 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 816) := by decide +kernel

theorem selectedBound33807 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33808 : List Nat := [2,4,8,16,32,16,9,256,512,816,287,805,268,276,0,263,260,59,816,1,820,32,16,3,269,16,286,261,805,59,565,32,256,32,277,513]

theorem envBound33808 : H12AffineFastState.Bounded env33808 := by
  intro p hp
  have h : env33808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33807_33808 : H12AffineEnvironment.transform 9 816 env33807 = env33808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 816 env33807 == env33808) = true)

theorem identity33808 : scanCanonicalize (H12AffineFastState.compose env33808 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33808 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33809 : List Nat := [2,4,8,16,17,16,9,256,512,769,287,788,268,276,0,263,260,10,769,1,773,17,16,3,269,16,286,261,788,10,516,17,256,17,277,513]

theorem envBound33809 : H12AffineFastState.Bounded env33809 := by
  intro p hp
  have h : env33809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33808_33809 : H12AffineEnvironment.transform 4 17 env33808 = env33809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33808 == env33809) = true)

theorem identity33809 : scanCanonicalize (H12AffineFastState.compose env33809 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound33809 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33810 : List Nat := [2,4,8,16,17,16,9,256,11,266,287,287,268,276,0,263,260,10,266,1,270,17,16,3,269,16,286,261,287,10,15,17,256,17,277,10]

theorem envBound33810 : H12AffineFastState.Bounded env33810 := by
  intro p hp
  have h : env33810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33809_33810 : H12AffineEnvironment.transform 8 11 env33809 = env33810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env33809 == env33810) = true)

theorem identity33810 : scanCanonicalize (H12AffineFastState.compose env33810 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33810 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33811 : List Nat := [2,4,8,11,10,11,9,256,11,266,260,260,268,271,0,263,260,10,266,1,270,10,11,3,269,11,261,261,260,10,15,10,256,10,270,10]

theorem envBound33811 : H12AffineFastState.Bounded env33811 := by
  intro p hp
  have h : env33811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33810_33811 : H12AffineEnvironment.transform 3 11 env33810 = env33811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33810 == env33811) = true)

theorem identity33811 : scanCanonicalize (H12AffineFastState.compose env33811 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound33811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33812 : List Nat := [2,4,6,5,4,5,7,256,5,260,260,260,258,257,0,263,260,4,260,1,256,4,5,3,259,5,261,261,260,4,1,4,256,4,256,4]

theorem envBound33812 : H12AffineFastState.Bounded env33812 := by
  intro p hp
  have h : env33812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33811_33812 : H12AffineEnvironment.transform 2 6 env33811 = env33812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env33811 == env33812) = true)

theorem identity33812 : scanCanonicalize (H12AffineFastState.compose env33812 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33812 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env33813 : List Nat := [2,1,3,0,1,0,2,256,0,257,257,257,258,257,0,258,257,1,257,1,256,1,0,3,259,0,256,256,257,1,1,1,256,1,256,1]

theorem envBound33813 : H12AffineFastState.Bounded env33813 := by
  intro p hp
  have h : env33813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33812_33813 : H12AffineEnvironment.transform 1 1 env33812 = env33813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33812 == env33813) = true)

theorem identity33813 : scanCanonicalize (H12AffineFastState.compose env33813 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound33813 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33814 : List Nat := [2,1,3,0,1,0,2,2,0,3,3,3,0,3,0,0,3,1,3,1,2,1,0,3,1,0,2,2,3,1,1,1,2,1,2,1]

theorem envBound33814 : H12AffineFastState.Bounded env33814 := by
  intro p hp
  have h : env33814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33813_33814 : H12AffineEnvironment.transform 7 2 env33813 = env33814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env33813 == env33814) = true)

def env33815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,2175169,8328,64,2609403,46157,77835,2598235,119179,2101344,256,2199863,2191507,63069]

theorem envBound33815 : H12AffineFastState.Bounded env33815 := by
  intro p hp
  have h : env33815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33752_33815 : H12AffineEnvironment.transform 23 2175169 env33752 = env33815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175169 env33752 == env33815) = true)

def env33816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21792,95515,73857,8328,64,508091,46157,77835,505115,119179,32,256,98679,90323,63069]

theorem envBound33816 : H12AffineFastState.Bounded env33816 := by
  intro p hp
  have h : env33816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33815_33816 : H12AffineEnvironment.transform 20 4160 env33815 = env33816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33815 == env33816) = true)

theorem identity33816 : scanCanonicalize (H12AffineFastState.compose env33816 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33816 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73857,8328,64,497083,46157,77835,505115,99467,32,256,98679,79315,41821]

theorem envBound33817 : H12AffineFastState.Bounded env33817 := by
  intro p hp
  have h : env33817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33816_33817 : H12AffineEnvironment.transform 13 5376 env33816 = env33817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33816 == env33817) = true)

def env33818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73737,8192,64,496947,46157,77835,505115,99331,32,256,98679,79195,41821]

theorem envBound33818 : H12AffineFastState.Bounded env33818 := by
  intro p hp
  have h : env33818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33817_33818 : H12AffineEnvironment.transform 6 8 env33817 = env33818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33817 == env33818) = true)

def env33819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,4160,32,73755,73737,8192,64,245019,46157,77835,236851,99331,32,256,98679,79195,41821]

theorem envBound33819 : H12AffineFastState.Bounded env33819 := by
  intro p hp
  have h : env33819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33818_33819 : H12AffineEnvironment.transform 17 10280 env33818 = env33819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33818 == env33819) = true)

theorem identity33819 : scanCanonicalize (H12AffineFastState.compose env33819 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33819 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10280,1024,32769,4160,32,16,2,8192,64,171280,46157,4096,179512,41992,32,256,41340,5456,41821]

theorem envBound33820 : H12AffineFastState.Bounded env33820 := by
  intro p hp
  have h : env33820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33819_33820 : H12AffineEnvironment.transform 15 8203 env33819 = env33820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33819 == env33820) = true)

theorem identity33820 : scanCanonicalize (H12AffineFastState.compose env33820 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33820 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env33821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,13340,10280,1024,32769,4160,32,16,2,8192,64,43276,46157,4096,35108,41992,32,256,41340,5456,41821]

theorem envBound33821 : H12AffineFastState.Bounded env33821 := by
  intro p hp
  have h : env33821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33820_33821 : H12AffineEnvironment.transform 16 13340 env33820 = env33821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env33820 == env33821) = true)

theorem identity33821 : scanCanonicalize (H12AffineFastState.compose env33821 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound33821 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env33822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1344,8203,13340,10280,1024,1345,4160,32,16,2,8192,64,11340,12557,4096,3172,8520,32,256,9276,5456,9757]

theorem envBound33822 : H12AffineFastState.Bounded env33822 := by
  intro p hp
  have h : env33822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33821_33822 : H12AffineEnvironment.transform 14 1344 env33821 = env33822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env33821 == env33822) = true)

theorem identity33822 : scanCanonicalize (H12AffineFastState.compose env33822 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound33822 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,1344,115,5220,2128,1024,1345,4160,32,16,2,120,64,3124,4469,4096,3172,304,32,256,1092,5456,1637]

theorem envBound33823 : H12AffineFastState.Bounded env33823 := by
  intro p hp
  have h : env33823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33822_33823 : H12AffineEnvironment.transform 12 120 env33822 = env33823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env33822 == env33823) = true)

theorem identity33823 : scanCanonicalize (H12AffineFastState.compose env33823 (packedSelected [1,2,3,5,8,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33823 : packedSelected [1,2,3,5,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env33824 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5376,1297,34,5173,2049,1024,1296,4113,32,16,2,41,17,3124,4388,4096,3125,304,32,256,1045,5377,1588]

theorem envBound33824 : H12AffineFastState.Bounded env33824 := by
  intro p hp
  have h : env33824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33823_33824 : H12AffineEnvironment.transform 5 17 env33823 = env33824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33823 == env33824) = true)

theorem identity33824 : scanCanonicalize (H12AffineFastState.compose env33824 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound33824 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env33825 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,41,4113,0,34,4388,2049,273,1,4113,32,16,2,41,17,2341,4388,4096,2340,304,32,256,260,4112,805]

theorem envBound33825 : H12AffineFastState.Bounded env33825 := by
  intro p hp
  have h : env33825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33824_33825 : H12AffineEnvironment.transform 9 273 env33824 = env33825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env33824 == env33825) = true)

theorem identity33825 : scanCanonicalize (H12AffineFastState.compose env33825 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33825 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33826 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,4113,0,34,4097,2049,52,1,4113,32,16,2,41,17,2048,4097,4096,2049,21,32,37,33,4112,512]

theorem envBound33826 : H12AffineFastState.Bounded env33826 := by
  intro p hp
  have h : env33826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33825_33826 : H12AffineEnvironment.transform 7 37 env33825 = env33826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33825 == env33826) = true)

theorem identity33826 : scanCanonicalize (H12AffineFastState.compose env33826 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33826 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33827 : List Nat := [2,4,8,16,32,17,8,37,1,52,2048,4096,41,4113,0,34,4097,2049,52,1,4113,32,16,2,41,17,2048,4097,4096,2049,21,32,37,33,4112,1]

theorem envBound33827 : H12AffineFastState.Bounded env33827 := by
  intro p hp
  have h : env33827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33826_33827 : H12AffineEnvironment.transform 8 1 env33826 = env33827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33826 == env33827) = true)

theorem identity33827 : scanCanonicalize (H12AffineFastState.compose env33827 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 63) := by decide +kernel

theorem selectedBound33827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33828 : List Nat := [2,4,8,16,32,17,8,37,1,52,63,4096,41,4113,0,34,4097,62,52,1,4113,32,16,2,41,17,63,4097,4096,62,21,32,37,33,4112,1]

theorem envBound33828 : H12AffineFastState.Bounded env33828 := by
  intro p hp
  have h : env33828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33827_33828 : H12AffineEnvironment.transform 10 63 env33827 = env33828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 63 env33827 == env33828) = true)

theorem identity33828 : scanCanonicalize (H12AffineFastState.compose env33828 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33828 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33829 : List Nat := [2,4,8,16,0,17,8,5,1,20,31,4096,9,4113,0,2,4097,30,20,1,4113,0,16,2,9,17,31,4097,4096,30,21,0,5,1,4112,1]

theorem envBound33829 : H12AffineFastState.Bounded env33829 := by
  intro p hp
  have h : env33829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33828_33829 : H12AffineEnvironment.transform 4 0 env33828 = env33829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33828 == env33829) = true)

theorem identity33829 : scanCanonicalize (H12AffineFastState.compose env33829 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 15) := by decide +kernel

theorem selectedBound33829 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33830 : List Nat := [2,4,8,16,0,17,8,5,1,20,31,15,9,30,0,2,14,30,20,1,30,0,16,2,9,17,31,14,15,30,21,0,5,1,31,1]

theorem envBound33830 : H12AffineFastState.Bounded env33830 := by
  intro p hp
  have h : env33830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33829_33830 : H12AffineEnvironment.transform 11 15 env33829 = env33830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 15 env33829 == env33830) = true)

def leafEnv33830 : List Nat := [2,4,8,16,0,17,8,5,1,20,31,15,9,30,0,2,14,30,20,1,30,0,16,2,21,9,1,17,31,14,15,30,21,0,5,1,4,2,31,1,1,31,0]

def active33830 : List Nat := [0,1,2,3]

def tree33830 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33830 : H12WitnessSearch.Good tree33830 := H12GlobalWitnessIndex.good

theorem leafIdentity33830 : H12AffineFastState.composeSystem env33830 rootObs = leafEnv33830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33830 rootObs == leafEnv33830) = true)

theorem terminalChecked33830 : H12PackedTerminal.terminalCheckFast leafEnv33830 active33830 tree33830 = true := by decide +kernel

def env33831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4160,32,73755,73737,8192,64,245018,46157,77835,236850,99331,32,256,98679,79195,41821]

theorem envBound33831 : H12AffineFastState.Bounded env33831 := by
  intro p hp
  have h : env33831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33818_33831 : H12AffineEnvironment.transform 17 10281 env33818 = env33831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33818 == env33831) = true)

theorem identity33831 : scanCanonicalize (H12AffineFastState.compose env33831 (packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound33831 : packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env33832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13341,10281,1024,32769,4160,32,73755,73737,8192,64,100615,46157,77835,108847,99331,32,256,98679,79195,41821]

theorem envBound33832 : H12AffineFastState.Bounded env33832 := by
  intro p hp
  have h : env33832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33831_33832 : H12AffineEnvironment.transform 16 13341 env33831 = env33832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env33831 == env33832) = true)

theorem identity33832 : scanCanonicalize (H12AffineFastState.compose env33832 (packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33832 : packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env33833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13341,10281,1024,8541,4160,32,73755,73737,8192,64,75867,5393,77835,67699,75103,32,256,73771,79195,513]

theorem envBound33833 : H12AffineFastState.Bounded env33833 := by
  intro p hp
  have h : env33833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33832_33833 : H12AffineEnvironment.transform 14 8540 env33832 = env33833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33832 == env33833) = true)

theorem identity33833 : scanCanonicalize (H12AffineFastState.compose env33833 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33833 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33834 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,65536,13341,10281,1024,8461,4112,32,73755,73737,8192,16,75787,5393,77835,67619,75023,32,256,73771,79115,513]

theorem envBound33834 : H12AffineFastState.Bounded env33834 := by
  intro p hp
  have h : env33834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33833_33834 : H12AffineEnvironment.transform 5 16 env33833 = env33834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33833 == env33834) = true)

theorem identity33834 : scanCanonicalize (H12AffineFastState.compose env33834 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound33834 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33835 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,263,13341,10281,1024,8461,4112,32,8476,8462,8192,16,10508,5393,12556,2340,9224,32,256,8492,13324,513]

theorem envBound33835 : H12AffineFastState.Bounded env33835 := by
  intro p hp
  have h : env33835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33834_33835 : H12AffineEnvironment.transform 15 263 env33834 = env33835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env33834 == env33835) = true)

theorem identity33835 : scanCanonicalize (H12AffineFastState.compose env33835 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound33835 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33836 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5133,5376,5377,263,16,7204,1024,5376,4112,32,5393,5379,5133,16,7425,5393,1281,2340,4101,32,256,5409,1,513]

theorem envBound33836 : H12AffineFastState.Bounded env33836 := by
  intro p hp
  have h : env33836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33835_33836 : H12AffineEnvironment.transform 12 5133 env33835 = env33836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env33835 == env33836) = true)

theorem identity33836 : scanCanonicalize (H12AffineFastState.compose env33836 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound33836 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33837 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1281,268,1,0,263,16,2341,1024,1,1297,32,16,2,268,16,2048,16,1281,2340,1284,32,256,32,1,513]

theorem envBound33837 : H12AffineFastState.Bounded env33837 := by
  intro p hp
  have h : env33837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33836_33837 : H12AffineEnvironment.transform 11 1281 env33836 = env33837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env33836 == env33837) = true)

theorem identity33837 : scanCanonicalize (H12AffineFastState.compose env33837 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33837 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33838 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,1281,268,1,0,263,16,2308,1024,1,1297,1,16,2,268,16,2048,16,1281,2309,1284,1,256,1,1,513]

theorem envBound33838 : H12AffineFastState.Bounded env33838 := by
  intro p hp
  have h : env33838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33837_33838 : H12AffineEnvironment.transform 4 1 env33837 = env33838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33837 == env33838) = true)

theorem identity33838 : scanCanonicalize (H12AffineFastState.compose env33838 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound33838 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33839 : List Nat := [2,4,8,16,1,16,8,256,512,1024,513,1281,268,1,0,263,16,773,1024,1,1297,1,16,2,268,16,513,16,1281,772,1284,1,256,1,1,513]

theorem envBound33839 : H12AffineFastState.Bounded env33839 := by
  intro p hp
  have h : env33839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33838_33839 : H12AffineEnvironment.transform 10 513 env33838 = env33839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env33838 == env33839) = true)

theorem identity33839 : scanCanonicalize (H12AffineFastState.compose env33839 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33839 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33840 : List Nat := [2,4,8,0,1,0,8,256,512,1024,513,1281,268,1,0,263,0,773,1024,1,1281,1,0,2,268,0,513,0,1281,772,1284,1,256,1,1,513]

theorem envBound33840 : H12AffineFastState.Bounded env33840 := by
  intro p hp
  have h : env33840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33839_33840 : H12AffineEnvironment.transform 3 0 env33839 = env33840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33839 == env33840) = true)

theorem identity33840 : scanCanonicalize (H12AffineFastState.compose env33840 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound33840 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33841 : List Nat := [2,4,8,0,1,0,8,256,261,1024,260,1281,268,1,0,263,0,0,1024,1,1281,1,0,2,268,0,260,0,1281,1,1284,1,256,1,1,260]

theorem envBound33841 : H12AffineFastState.Bounded env33841 := by
  intro p hp
  have h : env33841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33840_33841 : H12AffineEnvironment.transform 8 261 env33840 = env33841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env33840 == env33841) = true)

def env33842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73736,8193,64,496946,46157,77835,505115,99330,32,256,98679,79194,41821]

theorem envBound33842 : H12AffineFastState.Bounded env33842 := by
  intro p hp
  have h : env33842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33817_33842 : H12AffineEnvironment.transform 6 9 env33817 = env33842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33817 == env33842) = true)

theorem identity33842 : scanCanonicalize (H12AffineFastState.compose env33842 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound33842 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env33843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,79130,262144,1024,32769,4160,32,73755,73736,8193,64,303144,46157,77835,294913,99330,32,256,98679,79194,41821]

theorem envBound33843 : H12AffineFastState.Bounded env33843 := by
  intro p hp
  have h : env33843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33842_33843 : H12AffineEnvironment.transform 16 79130 env33842 = env33843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env33842 == env33843) = true)

theorem identity33843 : scanCanonicalize (H12AffineFastState.compose env33843 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33843 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env33844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,79130,262144,1024,8541,4160,32,73755,73736,8193,64,262516,5393,77835,270685,75102,32,256,73771,79194,513]

theorem envBound33844 : H12AffineFastState.Bounded env33844 := by
  intro p hp
  have h : env33844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33843_33844 : H12AffineEnvironment.transform 14 8540 env33843 = env33844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33843 == env33844) = true)

theorem identity33844 : scanCanonicalize (H12AffineFastState.compose env33844 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound33844 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,293,65536,71011,262144,1024,292,4160,32,65634,65649,120,64,262516,5393,69746,262436,66855,32,256,65618,70947,513]

theorem envBound33845 : H12AffineFastState.Bounded env33845 := by
  intro p hp
  have h : env33845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33844_33845 : H12AffineEnvironment.transform 12 121 env33844 = env33845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env33844 == env33845) = true)

theorem identity33845 : scanCanonicalize (H12AffineFastState.compose env33845 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound33845 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,293,1378,4097,262144,1024,292,4160,32,1280,1299,120,64,262516,5393,5392,262436,69,32,256,1328,4161,513]

theorem envBound33846 : H12AffineFastState.Bounded env33846 := by
  intro p hp
  have h : env33846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33845_33846 : H12AffineEnvironment.transform 15 1378 env33845 = env33846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env33845 == env33846) = true)

theorem identity33846 : scanCanonicalize (H12AffineFastState.compose env33846 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound33846 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,293,1378,4097,2129,1024,292,4160,32,1280,1299,120,64,2341,5393,5392,2421,69,32,256,1328,4161,513]

theorem envBound33847 : H12AffineFastState.Bounded env33847 := by
  intro p hp
  have h : env33847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33846_33847 : H12AffineEnvironment.transform 17 2129 env33846 = env33847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env33846 == env33847) = true)

theorem identity33847 : scanCanonicalize (H12AffineFastState.compose env33847 (packedSelected [0,1,3,4,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33847 : packedSelected [0,1,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env33848 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,5236,81,1046,4097,2129,1024,80,4160,32,1140,1127,120,64,2129,5221,5220,2049,69,32,116,1092,4161,513]

theorem envBound33848 : H12AffineFastState.Bounded env33848 := by
  intro p hp
  have h : env33848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33847_33848 : H12AffineEnvironment.transform 7 116 env33847 = env33848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33847 == env33848) = true)

theorem identity33848 : scanCanonicalize (H12AffineFastState.compose env33848 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound33848 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33849 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,16,121,1124,81,1046,17,2129,1024,80,80,32,1140,1127,120,64,2129,1141,1140,2049,69,32,116,1092,81,513]

theorem envBound33849 : H12AffineFastState.Bounded env33849 := by
  intro p hp
  have h : env33849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33848_33849 : H12AffineEnvironment.transform 11 16 env33848 = env33849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env33848 == env33849) = true)

theorem identity33849 : scanCanonicalize (H12AffineFastState.compose env33849 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33849 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env33850 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1,16,121,1124,81,1046,17,80,1024,80,80,32,1140,1127,120,64,80,1141,1140,0,69,32,116,1092,81,513]

theorem envBound33850 : H12AffineFastState.Bounded env33850 := by
  intro p hp
  have h : env33850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33849_33850 : H12AffineEnvironment.transform 10 1 env33849 = env33850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33849 == env33850) = true)

theorem identity33850 : scanCanonicalize (H12AffineFastState.compose env33850 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 580) := by decide +kernel

theorem selectedBound33850 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env33851 : List Nat := [2,4,8,16,32,64,9,116,512,580,1,16,121,544,81,594,17,80,580,80,80,32,560,547,120,64,80,561,560,0,69,32,116,512,81,513]

theorem envBound33851 : H12AffineFastState.Bounded env33851 := by
  intro p hp
  have h : env33851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33850_33851 : H12AffineEnvironment.transform 9 580 env33850 = env33851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 580 env33850 == env33851) = true)

theorem identity33851 : scanCanonicalize (H12AffineFastState.compose env33851 (packedSelected [0,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound33851 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env33852 : List Nat := [2,4,8,16,32,64,9,116,32,100,1,16,121,0,81,114,17,80,100,80,80,32,16,3,120,64,80,17,16,0,69,32,116,32,81,33]

theorem envBound33852 : H12AffineFastState.Bounded env33852 := by
  intro p hp
  have h : env33852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33851_33852 : H12AffineEnvironment.transform 8 32 env33851 = env33852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env33851 == env33852) = true)

theorem identity33852 : scanCanonicalize (H12AffineFastState.compose env33852 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound33852 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33853 : List Nat := [2,4,8,16,16,64,9,68,16,84,1,16,73,0,81,66,17,80,84,80,80,16,16,3,72,64,80,17,16,0,69,16,68,16,81,17]

theorem envBound33853 : H12AffineFastState.Bounded env33853 := by
  intro p hp
  have h : env33853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33852_33853 : H12AffineEnvironment.transform 4 16 env33852 = env33853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env33852 == env33853) = true)

theorem identity33853 : scanCanonicalize (H12AffineFastState.compose env33853 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound33853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33854 : List Nat := [2,4,8,16,16,26,9,30,16,14,1,16,19,0,11,24,17,10,14,10,10,16,16,3,18,26,10,17,16,0,31,16,30,16,11,17]

theorem envBound33854 : H12AffineFastState.Bounded env33854 := by
  intro p hp
  have h : env33854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33853_33854 : H12AffineEnvironment.transform 5 26 env33853 = env33854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env33853 == env33854) = true)

theorem identity33854 : scanCanonicalize (H12AffineFastState.compose env33854 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33854 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33855 : List Nat := [2,4,8,10,10,0,9,4,10,14,1,10,9,0,11,2,11,10,14,10,10,10,10,3,8,0,10,11,10,0,5,10,4,10,11,11]

theorem envBound33855 : H12AffineFastState.Bounded env33855 := by
  intro p hp
  have h : env33855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33854_33855 : H12AffineEnvironment.transform 3 10 env33854 = env33855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33854 == env33855) = true)

theorem identity33855 : scanCanonicalize (H12AffineFastState.compose env33855 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33855 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33856 : List Nat := [2,4,2,0,0,0,3,4,0,4,1,0,3,0,1,2,1,0,4,0,0,0,0,3,2,0,0,1,0,0,5,0,4,0,1,1]

theorem envBound33856 : H12AffineFastState.Bounded env33856 := by
  intro p hp
  have h : env33856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33855_33856 : H12AffineEnvironment.transform 2 2 env33855 = env33856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33855 == env33856) = true)

def env33857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73856,8328,64,508090,46157,77835,505114,119179,33,256,98678,90322,63069]

theorem envBound33857 : H12AffineFastState.Bounded env33857 := by
  intro p hp
  have h : env33857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33815_33857 : H12AffineEnvironment.transform 20 4161 env33815 = env33857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33815 == env33857) = true)

theorem identity33857 : scanCanonicalize (H12AffineFastState.compose env33857 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33857 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73736,8192,64,507954,46157,77835,505114,119043,33,256,98678,90202,63069]

theorem envBound33858 : H12AffineFastState.Bounded env33858 := by
  intro p hp
  have h : env33858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33857_33858 : H12AffineEnvironment.transform 6 8 env33857 = env33858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33857 == env33858) = true)

theorem identity33858 : scanCanonicalize (H12AffineFastState.compose env33858 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound33858 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env33859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1024,32769,4161,21793,95514,73736,8192,64,203847,46157,77835,223599,119043,33,256,98678,90202,63069]

theorem envBound33859 : H12AffineFastState.Bounded env33859 := by
  intro p hp
  have h : env33859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33858_33859 : H12AffineEnvironment.transform 17 56437 env33858 = env33859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env33858 == env33859) = true)

theorem identity33859 : scanCanonicalize (H12AffineFastState.compose env33859 (packedSelected [1,5,8,19,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33859 : packedSelected [1,5,8,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env33860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1024,29789,4161,21793,95514,73736,8192,64,203847,16401,77835,223599,75103,33,256,95530,90202,513]

theorem envBound33860 : H12AffineFastState.Bounded env33860 := by
  intro p hp
  have h : env33860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33859_33860 : H12AffineEnvironment.transform 14 29788 env33859 = env33860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33859 == env33860) = true)

theorem identity33860 : scanCanonicalize (H12AffineFastState.compose env33860 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 79179) := by decide +kernel

theorem selectedBound33860 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env33861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,79179,10281,1024,29789,4161,21793,95514,73736,8192,64,10508,16401,77835,23588,75103,33,256,95530,90202,513]

theorem envBound33861 : H12AffineFastState.Bounded env33861 := by
  intro p hp
  have h : env33861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33860_33861 : H12AffineEnvironment.transform 16 79179 env33860 = env33861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79179 env33860 == env33861) = true)

theorem identity33861 : scanCanonicalize (H12AffineFastState.compose env33861 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound33861 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21591,24860,10281,1024,29789,4161,21793,8525,29791,8192,64,10508,16401,25692,23588,28936,33,256,8573,13325,513]

theorem envBound33862 : H12AffineFastState.Bounded env33862 := by
  intro p hp
  have h : env33862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33861_33862 : H12AffineEnvironment.transform 15 21591 env33861 = env33862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env33861 == env33862) = true)

theorem identity33862 : scanCanonicalize (H12AffineFastState.compose env33862 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33862 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,21591,16448,2421,1024,21761,4161,21793,17,21763,348,64,2128,16401,17664,23588,20564,33,256,33,5457,513]

theorem envBound33863 : H12AffineFastState.Bounded env33863 := by
  intro p hp
  have h : env33863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33862_33863 : H12AffineEnvironment.transform 12 348 env33862 = env33863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33862 == env33863) = true)

theorem identity33863 : scanCanonicalize (H12AffineFastState.compose env33863 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33863 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33864 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,16384,21541,21591,16448,2128,1024,21540,4161,21508,17,21542,121,64,2128,16401,17445,23588,20564,33,37,33,5236,513]

theorem envBound33864 : H12AffineFastState.Bounded env33864 := by
  intro p hp
  have h : env33864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33863_33864 : H12AffineEnvironment.transform 7 37 env33863 = env33864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33863 == env33864) = true)

theorem identity33864 : scanCanonicalize (H12AffineFastState.compose env33864 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound33864 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33865 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,3125,6160,6242,3189,2128,1024,6161,4161,6193,17,6163,121,64,2128,3108,2064,4113,7265,33,37,33,5236,513]

theorem envBound33865 : H12AffineFastState.Bounded env33865 := by
  intro p hp
  have h : env33865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33864_33865 : H12AffineEnvironment.transform 13 3125 env33864 = env33865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env33864 == env33865) = true)

def env33866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,16777216,8328,64,17227835,18973836,77835,2598235,18932042,16851104,256,16818678,16793682,18990748]

theorem envBound33866 : H12AffineFastState.Bounded env33866 := by
  intro p hp
  have h : env33866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33751_33866 : H12AffineEnvironment.transform 21 2114913 env33751 = env33866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env33751 == env33866) = true)

def env33867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,2175168,8328,64,2609403,46156,77835,2598235,119178,2101344,256,2199862,2191506,63068]

theorem envBound33867 : H12AffineFastState.Bounded env33867 := by
  intro p hp
  have h : env33867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33866_33867 : H12AffineEnvironment.transform 23 2175168 env33866 = env33867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175168 env33866 == env33867) = true)

def env33868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21793,95515,73856,8328,64,508091,46156,77835,505115,119178,32,256,98678,90322,63068]

theorem envBound33868 : H12AffineFastState.Bounded env33868 := by
  intro p hp
  have h : env33868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33867_33868 : H12AffineEnvironment.transform 20 4160 env33867 = env33868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33867 == env33868) = true)

theorem identity33868 : scanCanonicalize (H12AffineFastState.compose env33868 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound33868 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,1024,32769,4160,21793,62661,41310,8328,64,409957,46156,45525,406725,20564,32,256,168,57612,63068]

theorem envBound33869 : H12AffineFastState.Bounded env33869 := by
  intro p hp
  have h : env33869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33868_33869 : H12AffineEnvironment.transform 15 33246 env33868 = env33869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env33868 == env33869) = true)

def env33870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,10280,1024,32769,4160,21793,62661,41310,8328,64,158029,46156,45525,138477,20564,32,256,168,57612,63068]

theorem envBound33870 : H12AffineFastState.Bounded env33870 := by
  intro p hp
  have h : env33870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33869_33870 : H12AffineEnvironment.transform 17 10280 env33869 = env33870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33869 == env33870) = true)

theorem identity33870 : scanCanonicalize (H12AffineFastState.compose env33870 (packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound33870 : packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,16401,10280,1024,32769,4160,21793,62661,41310,8328,64,10588,46156,45525,23804,20564,32,256,168,57612,63068]

theorem envBound33871 : H12AffineFastState.Bounded env33871 := by
  intro p hp
  have h : env33871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33870_33871 : H12AffineEnvironment.transform 16 16401 env33870 = env33871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env33870 == env33871) = true)

theorem identity33871 : scanCanonicalize (H12AffineFastState.compose env33871 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 20632) := by decide +kernel

theorem selectedBound33871 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env33872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20632,20806,16401,10280,1024,20633,4160,21793,9309,29126,8328,64,10588,25812,24909,23804,20564,32,256,168,12692,9924]

theorem envBound33872 : H12AffineFastState.Bounded env33872 := by
  intro p hp
  have h : env33872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33871_33872 : H12AffineEnvironment.transform 14 20632 env33871 = env33872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20632 env33871 == env33872) = true)

theorem identity33872 : scanCanonicalize (H12AffineFastState.compose env33872 (packedSelected [0,3,4,5,7,10,21,22] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound33872 : packedSelected [0,3,4,5,7,10,21,22] rootPS < 2^1333 := by decide +kernel

def env33873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12621,8661,8203,12636,10280,1024,8660,4160,9324,9309,139,8328,64,10588,5529,4096,11697,8473,32,256,168,12692,9924]

theorem envBound33873 : H12AffineFastState.Bounded env33873 := by
  intro p hp
  have h : env33873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33872_33873 : H12AffineEnvironment.transform 13 12621 env33872 = env33873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env33872 == env33873) = true)

theorem identity33873 : scanCanonicalize (H12AffineFastState.compose env33873 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound33873 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env33874 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,12512,8312,8203,12529,10280,1024,8313,4160,9324,9309,139,8328,64,10481,5172,4096,11292,8372,32,173,168,12345,9924]

theorem envBound33874 : H12AffineFastState.Bounded env33874 := by
  intro p hp
  have h : env33874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33873_33874 : H12AffineEnvironment.transform 7 173 env33873 = env33874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33873 == env33874) = true)

theorem identity33874 : scanCanonicalize (H12AffineFastState.compose env33874 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound33874 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env33875 : List Nat := [2,4,8,16,32,64,128,173,512,20,2048,4096,8192,12512,8312,8203,12529,10280,20,8313,4160,8312,8265,139,8328,64,10481,4128,4096,10248,8372,32,173,168,12345,8912]

theorem envBound33875 : H12AffineFastState.Bounded env33875 := by
  intro p hp
  have h : env33875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33874_33875 : H12AffineEnvironment.transform 9 20 env33874 = env33875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env33874 == env33875) = true)

theorem identity33875 : scanCanonicalize (H12AffineFastState.compose env33875 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound33875 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33876 : List Nat := [2,4,8,16,32,64,128,173,512,20,2048,4096,120,4248,0,115,4233,2128,20,1,4160,0,49,139,240,64,2185,4128,4096,2160,204,32,173,168,4161,680]

theorem envBound33876 : H12AffineFastState.Bounded env33876 := by
  intro p hp
  have h : env33876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33875_33876 : H12AffineEnvironment.transform 12 120 env33875 = env33876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env33875 == env33876) = true)

theorem identity33876 : scanCanonicalize (H12AffineFastState.compose env33876 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33876 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env33877 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,4096,120,4113,0,115,4096,2128,20,1,4160,0,49,2,121,64,2048,4128,4096,2160,69,32,36,33,4161,545]

theorem envBound33877 : H12AffineFastState.Bounded env33877 := by
  intro p hp
  have h : env33877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33876_33877 : H12AffineEnvironment.transform 6 9 env33876 = env33877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33876 == env33877) = true)

theorem identity33877 : scanCanonicalize (H12AffineFastState.compose env33877 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound33877 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33878 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,33,120,48,0,115,33,2128,20,1,97,0,49,2,121,64,2048,1,33,2160,69,32,36,33,96,545]

theorem envBound33878 : H12AffineFastState.Bounded env33878 := by
  intro p hp
  have h : env33878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33877_33878 : H12AffineEnvironment.transform 11 33 env33877 = env33878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env33877 == env33878) = true)

theorem identity33878 : scanCanonicalize (H12AffineFastState.compose env33878 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33878 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33879 : List Nat := [2,4,8,16,1,64,9,5,512,20,2048,0,89,17,0,82,0,2128,20,1,64,0,16,2,88,64,2048,1,0,2129,69,1,5,0,65,512]

theorem envBound33879 : H12AffineFastState.Bounded env33879 := by
  intro p hp
  have h : env33879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33878_33879 : H12AffineEnvironment.transform 4 1 env33878 = env33879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33878 == env33879) = true)

theorem identity33879 : scanCanonicalize (H12AffineFastState.compose env33879 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33880 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,0,9,17,0,2,0,2048,20,1,16,0,16,2,8,16,2048,1,0,2049,21,1,5,0,17,512]

theorem envBound33880 : H12AffineFastState.Bounded env33880 := by
  intro p hp
  have h : env33880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33879_33880 : H12AffineEnvironment.transform 5 16 env33879 = env33880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33879 == env33880) = true)

theorem identity33880 : scanCanonicalize (H12AffineFastState.compose env33880 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound33880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33881 : List Nat := [2,4,8,16,1,16,9,5,4,20,2048,0,9,17,0,2,0,2048,20,1,16,0,16,2,8,16,2048,1,0,2049,21,1,5,0,17,4]

theorem envBound33881 : H12AffineFastState.Bounded env33881 := by
  intro p hp
  have h : env33881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33880_33881 : H12AffineEnvironment.transform 8 4 env33880 = env33881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env33880 == env33881) = true)

theorem identity33881 : scanCanonicalize (H12AffineFastState.compose env33881 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound33881 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33882 : List Nat := [2,4,8,16,1,16,9,5,4,20,9,0,9,17,0,2,0,9,20,1,16,0,16,2,8,16,9,1,0,8,21,1,5,0,17,4]

theorem envBound33882 : H12AffineFastState.Bounded env33882 := by
  intro p hp
  have h : env33882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33881_33882 : H12AffineEnvironment.transform 10 9 env33881 = env33882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env33881 == env33882) = true)

theorem identity33882 : scanCanonicalize (H12AffineFastState.compose env33882 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound33882 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33883 : List Nat := [2,4,8,3,1,3,9,5,4,7,9,0,9,2,0,2,0,9,7,1,3,0,3,2,8,3,9,1,0,8,6,1,5,0,2,4]

theorem envBound33883 : H12AffineFastState.Bounded env33883 := by
  intro p hp
  have h : env33883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33882_33883 : H12AffineEnvironment.transform 3 3 env33882 = env33883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env33882 == env33883) = true)

theorem identity33883 : scanCanonicalize (H12AffineFastState.compose env33883 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33883 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33884 : List Nat := [0,4,8,1,1,1,9,5,4,5,9,0,9,0,0,0,0,9,5,1,1,0,1,0,8,1,9,1,0,8,4,1,5,0,0,4]

theorem envBound33884 : H12AffineFastState.Bounded env33884 := by
  intro p hp
  have h : env33884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33883_33884 : H12AffineEnvironment.transform 0 0 env33883 = env33884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33883 == env33884) = true)

theorem identity33884 : scanCanonicalize (H12AffineFastState.compose env33884 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound33884 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33885 : List Nat := [0,4,1,1,1,1,0,5,4,5,0,0,0,0,0,0,0,0,5,1,1,0,1,0,1,1,0,1,0,1,4,1,5,0,0,4]

theorem envBound33885 : H12AffineFastState.Bounded env33885 := by
  intro p hp
  have h : env33885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33884_33885 : H12AffineEnvironment.transform 2 1 env33884 = env33885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env33884 == env33885) = true)

def env33886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,10281,1024,32769,4160,21793,62661,41310,8328,64,158028,46156,45525,138476,20564,32,256,168,57612,63068]

theorem envBound33886 : H12AffineFastState.Bounded env33886 := by
  intro p hp
  have h : env33886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33869_33886 : H12AffineEnvironment.transform 17 10281 env33869 = env33886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33869 == env33886) = true)

theorem identity33886 : scanCanonicalize (H12AffineFastState.compose env33886 (packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound33886 : packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env33887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29963,131072,10281,1024,29908,4160,21793,16,21899,8328,64,158028,16537,17664,138476,20564,32,256,168,5593,649]

theorem envBound33887 : H12AffineFastState.Bounded env33887 := by
  intro p hp
  have h : env33887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33886_33887 : H12AffineEnvironment.transform 14 29909 env33886 = env33887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env33886 == env33887) = true)

theorem identity33887 : scanCanonicalize (H12AffineFastState.compose env33887 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound33887 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env33888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,29963,13625,10281,1024,29908,4160,21793,16,21899,8328,64,23669,16537,17664,10709,20564,32,256,168,5593,649]

theorem envBound33888 : H12AffineFastState.Bounded env33888 := by
  intro p hp
  have h : env33888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33887_33888 : H12AffineEnvironment.transform 16 13625 env33887 = env33888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env33887 == env33888) = true)

theorem identity33888 : scanCanonicalize (H12AffineFastState.compose env33888 (packedSelected [1,4,6,8,9,10,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33888 : packedSelected [1,4,6,8,9,10,15,20] rootPS < 2^1333 := by decide +kernel

def env33889 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,29963,13625,10281,1024,29828,4112,21793,16,21899,8328,16,23589,16537,17664,10629,20484,32,256,168,5513,649]

theorem envBound33889 : H12AffineFastState.Bounded env33889 := by
  intro p hp
  have h : env33889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33888_33889 : H12AffineEnvironment.transform 5 16 env33888 = env33889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33888 == env33889) = true)

theorem identity33889 : scanCanonicalize (H12AffineFastState.compose env33889 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33889 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env33890 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,8203,13625,10281,1024,8580,4112,33,16,139,8328,16,2341,5529,4096,10629,1284,32,256,168,5513,649]

theorem envBound33890 : H12AffineFastState.Bounded env33890 := by
  intro p hp
  have h : env33890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33889_33890 : H12AffineEnvironment.transform 13 5376 env33889 = env33890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33889 == env33890) = true)

theorem identity33890 : scanCanonicalize (H12AffineFastState.compose env33890 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33890 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env33891 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8203,13625,10281,1024,8461,4112,33,16,2,8193,16,2341,5392,4096,10508,1284,32,256,33,5376,512]

theorem envBound33891 : H12AffineFastState.Bounded env33891 := by
  intro p hp
  have h : env33891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33890_33891 : H12AffineEnvironment.transform 6 9 env33890 = env33891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33890 == env33891) = true)

theorem identity33891 : scanCanonicalize (H12AffineFastState.compose env33891 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33891 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33892 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8192,5125,8201,8203,13372,10281,1024,8200,4112,33,16,2,8193,16,2080,5141,4096,10249,1025,32,5,33,5125,512]

theorem envBound33892 : H12AffineFastState.Bounded env33892 := by
  intro p hp
  have h : env33892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33891_33892 : H12AffineEnvironment.transform 7 5 env33891 = env33892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33891 == env33892) = true)

theorem identity33892 : scanCanonicalize (H12AffineFastState.compose env33892 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33892 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33893 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,8192,5125,8201,8203,13341,10248,1024,8200,4112,0,16,2,8193,16,2049,5141,4096,10249,1025,1,5,0,5125,512]

theorem envBound33893 : H12AffineFastState.Bounded env33893 := by
  intro p hp
  have h : env33893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33892_33893 : H12AffineEnvironment.transform 4 1 env33892 = env33893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33892 == env33893) = true)

theorem identity33893 : scanCanonicalize (H12AffineFastState.compose env33893 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33893 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33894 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,4096,8192,4112,8201,8203,12296,10248,21,8200,4112,0,16,2,8193,16,2049,4096,4096,10249,20,1,5,0,4112,512]

theorem envBound33894 : H12AffineFastState.Bounded env33894 := by
  intro p hp
  have h : env33894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33893_33894 : H12AffineEnvironment.transform 9 21 env33893 = env33894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33893 == env33894) = true)

theorem identity33894 : scanCanonicalize (H12AffineFastState.compose env33894 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound33894 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33895 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,4096,8,4112,1,3,4096,2048,21,0,4112,0,16,2,9,16,2049,4096,4096,2049,20,1,5,0,4112,512]

theorem envBound33895 : H12AffineFastState.Bounded env33895 := by
  intro p hp
  have h : env33895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33894_33895 : H12AffineEnvironment.transform 12 8 env33894 = env33895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env33894 == env33895) = true)

theorem identity33895 : scanCanonicalize (H12AffineFastState.compose env33895 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound33895 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33896 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,8,1,1,3,17,2048,21,0,1,0,16,2,9,16,2049,17,17,2049,20,1,5,0,1,512]

theorem envBound33896 : H12AffineFastState.Bounded env33896 := by
  intro p hp
  have h : env33896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33895_33896 : H12AffineEnvironment.transform 11 17 env33895 = env33896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env33895 == env33896) = true)

theorem identity33896 : scanCanonicalize (H12AffineFastState.compose env33896 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound33896 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33897 : List Nat := [2,4,8,4,1,4,9,5,512,1,2048,5,8,1,1,3,5,2048,1,0,1,0,4,2,9,4,2049,5,5,2049,0,1,5,0,1,512]

theorem envBound33897 : H12AffineFastState.Bounded env33897 := by
  intro p hp
  have h : env33897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33896_33897 : H12AffineEnvironment.transform 3 4 env33896 = env33897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env33896 == env33897) = true)

def env33898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21792,95514,73857,8328,64,508090,46156,77835,505114,119178,33,256,98679,90323,63068]

theorem envBound33898 : H12AffineFastState.Bounded env33898 := by
  intro p hp
  have h : env33898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33867_33898 : H12AffineEnvironment.transform 20 4161 env33867 = env33898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33867 == env33898) = true)

theorem identity33898 : scanCanonicalize (H12AffineFastState.compose env33898 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound33898 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,21792,41292,62679,8328,64,398572,46156,58461,418124,1500,33,256,21793,46213,63068]

theorem envBound33899 : H12AffineFastState.Bounded env33899 := by
  intro p hp
  have h : env33899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33898_33899 : H12AffineEnvironment.transform 15 54358 env33898 = env33899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env33898 == env33899) = true)

def env33900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,4161,21792,41292,62679,8328,64,146628,46156,58461,149860,1500,33,256,21793,46213,63068]

theorem envBound33900 : H12AffineFastState.Bounded env33900 := by
  intro p hp
  have h : env33900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33899_33900 : H12AffineEnvironment.transform 17 10280 env33899 = env33900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env33899 == env33900) = true)

theorem identity33900 : scanCanonicalize (H12AffineFastState.compose env33900 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33900 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,131072,10280,1024,8541,4161,21792,16,21899,8328,64,146628,5392,17665,149860,1500,33,256,21793,5593,22272]

theorem envBound33901 : H12AffineFastState.Bounded env33901 := by
  intro p hp
  have h : env33901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33900_33901 : H12AffineEnvironment.transform 14 8540 env33900 = env33901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33900 == env33901) = true)

theorem identity33901 : scanCanonicalize (H12AffineFastState.compose env33901 (packedSelected [1,2,3,4,6,11,16,22,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound33901 : packedSelected [1,2,3,4,6,11,16,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env33902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,29962,5173,10280,1024,8541,4161,21792,16,21899,8328,64,10481,5392,17665,23889,1500,33,256,21793,5593,22272]

theorem envBound33902 : H12AffineFastState.Bounded env33902 := by
  intro p hp
  have h : env33902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33901_33902 : H12AffineEnvironment.transform 16 5173 env33901 = env33902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env33901 == env33902) = true)

theorem identity33902 : scanCanonicalize (H12AffineFastState.compose env33902 (packedSelected [0,3,4,7,10,12,15,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound33902 : packedSelected [0,3,4,7,10,12,15,22,24,26] rootPS < 2^1333 := by decide +kernel

def env33903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8540,9498,5173,10280,1024,8541,4161,1328,16,1435,8328,64,10481,5392,5393,3393,1500,33,256,1329,5593,1808]

theorem envBound33903 : H12AffineFastState.Bounded env33903 := by
  intro p hp
  have h : env33903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33902_33903 : H12AffineEnvironment.transform 13 4112 env33902 = env33903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env33902 == env33903) = true)

theorem identity33903 : scanCanonicalize (H12AffineFastState.compose env33903 (packedSelected [1,3,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound33903 : packedSelected [1,3,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env33904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,4112,1345,263,5173,3125,1024,1344,4161,1328,16,1435,1173,64,3308,5392,5393,3393,1500,33,256,1329,5593,1808]

theorem envBound33904 : H12AffineFastState.Bounded env33904 := by
  intro p hp
  have h : env33904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33903_33904 : H12AffineEnvironment.transform 12 1053 env33903 = env33904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env33903 == env33904) = true)

theorem identity33904 : scanCanonicalize (H12AffineFastState.compose env33904 (packedSelected [2,4,6,12,15,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound33904 : packedSelected [2,4,6,12,15,20,22] rootPS < 2^1333 := by decide +kernel

def env33905 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,469,4112,137,263,4605,2557,456,136,4161,248,16,83,349,64,2340,4312,4313,2185,20,33,256,249,4113,728]

theorem envBound33905 : H12AffineFastState.Bounded env33905 := by
  intro p hp
  have h : env33905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33904_33905 : H12AffineEnvironment.transform 9 456 env33904 = env33905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env33904 == env33905) = true)

theorem identity33905 : scanCanonicalize (H12AffineFastState.compose env33905 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound33905 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env33906 : List Nat := [2,4,8,16,32,64,128,172,512,100,2048,4096,121,4112,137,171,4177,2129,100,136,4161,248,16,83,241,64,2184,4312,4313,2185,20,33,172,249,4113,728]

theorem envBound33906 : H12AffineFastState.Bounded env33906 := by
  intro p hp
  have h : env33906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33905_33906 : H12AffineEnvironment.transform 7 172 env33905 = env33906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33905 == env33906) = true)

theorem identity33906 : scanCanonicalize (H12AffineFastState.compose env33906 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound33906 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env33907 : List Nat := [2,4,8,16,32,64,128,172,512,100,2048,2064,121,2048,137,171,2113,2129,100,136,2129,248,16,83,241,64,2184,2248,2249,2185,20,33,172,249,2049,728]

theorem envBound33907 : H12AffineFastState.Bounded env33907 := by
  intro p hp
  have h : env33907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33906_33907 : H12AffineEnvironment.transform 11 2064 env33906 = env33907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env33906 == env33907) = true)

theorem identity33907 : scanCanonicalize (H12AffineFastState.compose env33907 (packedSelected [2,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33907 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env33908 : List Nat := [2,4,8,16,32,16,128,172,512,52,2048,2064,41,2048,137,171,2065,2049,52,136,2049,168,16,3,161,16,2184,2200,2201,2185,20,33,172,169,2049,648]

theorem envBound33908 : H12AffineFastState.Bounded env33908 := by
  intro p hp
  have h : env33908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33907_33908 : H12AffineEnvironment.transform 5 16 env33907 = env33908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33907 == env33908) = true)

theorem identity33908 : scanCanonicalize (H12AffineFastState.compose env33908 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound33908 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env33909 : List Nat := [2,4,8,16,32,16,128,172,136,52,2048,2064,41,2048,137,171,2065,2049,52,136,2049,168,16,3,161,16,2184,2200,2201,2185,20,33,172,169,2049,0]

theorem envBound33909 : H12AffineFastState.Bounded env33909 := by
  intro p hp
  have h : env33909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33908_33909 : H12AffineEnvironment.transform 8 136 env33908 = env33909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env33908 == env33909) = true)

def env33910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,4161,21792,41292,62679,8328,64,146629,46156,58461,149861,1500,33,256,21793,46213,63068]

theorem envBound33910 : H12AffineFastState.Bounded env33910 := by
  intro p hp
  have h : env33910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33899_33910 : H12AffineEnvironment.transform 17 10281 env33899 = env33910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env33899 == env33910) = true)

def env33911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,5392,10281,1024,32769,4161,21792,41292,62679,8328,64,10709,46156,58461,23669,1500,33,256,21793,46213,63068]

theorem envBound33911 : H12AffineFastState.Bounded env33911 := by
  intro p hp
  have h : env33911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33910_33911 : H12AffineEnvironment.transform 16 5392 env33910 = env33911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33910 == env33911) = true)

theorem identity33911 : scanCanonicalize (H12AffineFastState.compose env33911 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33911 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env33912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33111,5392,10281,1024,32769,4161,33,41292,41430,8328,64,10709,46156,45404,2420,1500,33,256,32,46213,41821]

theorem envBound33912 : H12AffineFastState.Bounded env33912 := by
  intro p hp
  have h : env33912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33911_33912 : H12AffineEnvironment.transform 13 5377 env33911 = env33912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33911 == env33912) = true)

theorem identity33912 : scanCanonicalize (H12AffineFastState.compose env33912 (packedSelected [5,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound33912 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env33913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8323,5392,10281,1024,8661,4161,33,152,2,8328,64,10709,5528,4232,2420,1500,33,256,32,5457,649]

theorem envBound33913 : H12AffineFastState.Bounded env33913 := by
  intro p hp
  have h : env33913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33912_33913 : H12AffineEnvironment.transform 14 8660 env33912 = env33913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env33912 == env33913) = true)

theorem identity33913 : scanCanonicalize (H12AffineFastState.compose env33913 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound33913 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env33914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5377,81,262,5392,2476,1024,80,4161,33,152,2,269,64,2128,5528,4232,2420,1500,33,256,32,5457,649]

theorem envBound33914 : H12AffineFastState.Bounded env33914 := by
  intro p hp
  have h : env33914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33913_33914 : H12AffineEnvironment.transform 12 389 env33913 = env33914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env33913 == env33914) = true)

theorem identity33914 : scanCanonicalize (H12AffineFastState.compose env33914 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33914 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,262,5392,2340,1024,80,4161,33,16,2,269,64,2128,5392,4096,2420,1364,33,256,32,5457,513]

theorem envBound33915 : H12AffineFastState.Bounded env33915 := by
  intro p hp
  have h : env33915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33914_33915 : H12AffineEnvironment.transform 6 8 env33914 = env33915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33914 == env33915) = true)

theorem identity33915 : scanCanonicalize (H12AffineFastState.compose env33915 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33915 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33916 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5237,81,114,5220,2128,1024,80,4161,33,16,2,121,64,2128,5220,4096,2048,1056,33,116,32,5157,513]

theorem envBound33916 : H12AffineFastState.Bounded env33916 := by
  intro p hp
  have h : env33916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33915_33916 : H12AffineEnvironment.transform 7 116 env33915 = env33916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33915 == env33916) = true)

theorem identity33916 : scanCanonicalize (H12AffineFastState.compose env33916 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33916 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33917 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,34,5172,2048,1024,0,4113,33,16,2,41,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound33917 : H12AffineFastState.Bounded env33917 := by
  intro p hp
  have h : env33917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33916_33917 : H12AffineEnvironment.transform 5 16 env33916 = env33917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33916 == env33917) = true)

def env33918 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,1,34,1028,2048,1024,0,33,33,16,2,41,16,2048,1028,48,2048,1056,33,36,32,1045,513]

theorem envBound33918 : H12AffineFastState.Bounded env33918 := by
  intro p hp
  have h : env33918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33917_33918 : H12AffineEnvironment.transform 11 48 env33917 = env33918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33917 == env33918) = true)

theorem identity33918 : scanCanonicalize (H12AffineFastState.compose env33918 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33918 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33919 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,48,41,1045,1,34,1028,1076,1024,0,33,33,16,2,41,16,1076,1028,48,1076,1056,33,36,32,1045,513]

theorem envBound33919 : H12AffineFastState.Bounded env33919 := by
  intro p hp
  have h : env33919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33918_33919 : H12AffineEnvironment.transform 10 1076 env33918 = env33919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env33918 == env33919) = true)

def env33920 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,48,41,33,1,34,48,0,52,0,33,33,16,2,41,16,0,48,48,0,20,33,36,32,33,513]

theorem envBound33920 : H12AffineFastState.Bounded env33920 := by
  intro p hp
  have h : env33920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33919_33920 : H12AffineEnvironment.transform 9 52 env33919 = env33920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33919 == env33920) = true)

def env33921 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,48,41,32,1,34,49,1,53,0,33,33,16,2,41,16,1,49,48,1,21,33,36,32,32,513]

theorem envBound33921 : H12AffineFastState.Bounded env33921 := by
  intro p hp
  have h : env33921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33919_33921 : H12AffineEnvironment.transform 9 53 env33919 = env33921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33919 == env33921) = true)

theorem identity33921 : scanCanonicalize (H12AffineFastState.compose env33921 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33922 : List Nat := [2,4,8,16,32,16,8,36,42,53,1,48,41,32,1,34,49,1,53,0,33,33,16,2,41,16,1,49,48,1,21,33,36,32,32,43]

theorem envBound33922 : H12AffineFastState.Bounded env33922 := by
  intro p hp
  have h : env33922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33921_33922 : H12AffineEnvironment.transform 8 42 env33921 = env33922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33921 == env33922) = true)

def leafEnv33922 : List Nat := [2,4,8,16,32,16,8,36,42,53,1,48,41,32,1,34,49,1,53,0,33,33,16,2,21,41,1,16,1,49,48,1,21,33,36,32,4,34,32,43,1,33,0]

def active33922 : List Nat := [0,1,2,3,4]

def tree33922 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33922 : H12WitnessSearch.Good tree33922 := H12GlobalWitnessIndex.good

theorem leafIdentity33922 : H12AffineFastState.composeSystem env33922 rootObs = leafEnv33922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33922 rootObs == leafEnv33922) = true)

theorem terminalChecked33922 : H12PackedTerminal.terminalCheckFast leafEnv33922 active33922 tree33922 = true := by decide +kernel

def env33923 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,1,34,1029,2048,1024,0,32,33,16,2,41,16,2048,1029,49,2048,1056,33,36,32,1044,513]

theorem envBound33923 : H12AffineFastState.Bounded env33923 := by
  intro p hp
  have h : env33923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33917_33923 : H12AffineEnvironment.transform 11 49 env33917 = env33923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env33917 == env33923) = true)

theorem identity33923 : scanCanonicalize (H12AffineFastState.compose env33923 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33923 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33924 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,49,41,1044,1,34,1029,1,1024,0,32,33,16,2,41,16,1,1029,49,1,1056,33,36,32,1044,513]

theorem envBound33924 : H12AffineFastState.Bounded env33924 := by
  intro p hp
  have h : env33924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33923_33924 : H12AffineEnvironment.transform 10 1 env33923 = env33924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33923 == env33924) = true)

def env33925 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,49,41,32,1,34,49,1,52,0,32,33,16,2,41,16,1,49,49,1,20,33,36,32,32,513]

theorem envBound33925 : H12AffineFastState.Bounded env33925 := by
  intro p hp
  have h : env33925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33924_33925 : H12AffineEnvironment.transform 9 52 env33924 = env33925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33924 == env33925) = true)

def env33926 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,41,33,1,34,48,1,53,0,32,33,16,2,41,16,1,48,49,1,21,33,36,32,33,513]

theorem envBound33926 : H12AffineFastState.Bounded env33926 := by
  intro p hp
  have h : env33926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33924_33926 : H12AffineEnvironment.transform 9 53 env33924 = env33926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33924 == env33926) = true)

theorem identity33926 : scanCanonicalize (H12AffineFastState.compose env33926 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33927 : List Nat := [2,4,8,16,32,16,8,36,42,53,1,49,41,33,1,34,48,1,53,0,32,33,16,2,41,16,1,48,49,1,21,33,36,32,33,43]

theorem envBound33927 : H12AffineFastState.Bounded env33927 := by
  intro p hp
  have h : env33927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33926_33927 : H12AffineEnvironment.transform 8 42 env33926 = env33927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33926 == env33927) = true)

def leafEnv33927 : List Nat := [2,4,8,16,32,16,8,36,42,53,1,49,41,33,1,34,48,1,53,0,32,33,16,2,21,41,1,16,1,48,49,1,21,33,36,32,4,34,33,43,1,32,0]

def active33927 : List Nat := [0,1,2,3,4]

def tree33927 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33927 : H12WitnessSearch.Good tree33927 := H12GlobalWitnessIndex.good

theorem leafIdentity33927 : H12AffineFastState.composeSystem env33927 rootObs = leafEnv33927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33927 rootObs == leafEnv33927) = true)

theorem terminalChecked33927 : H12PackedTerminal.terminalCheckFast leafEnv33927 active33927 tree33927 = true := by decide +kernel

def env33928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,5393,10281,1024,32769,4161,21792,41292,62679,8328,64,10708,46156,58461,23668,1500,33,256,21793,46213,63068]

theorem envBound33928 : H12AffineFastState.Bounded env33928 := by
  intro p hp
  have h : env33928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33910_33928 : H12AffineEnvironment.transform 16 5393 env33910 = env33928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env33910 == env33928) = true)

theorem identity33928 : scanCanonicalize (H12AffineFastState.compose env33928 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound33928 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env33929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8203,5393,10281,1024,29788,4161,21792,21777,138,8328,64,10708,16401,4096,23668,1500,33,256,21793,16600,513]

theorem envBound33929 : H12AffineFastState.Bounded env33929 := by
  intro p hp
  have h : env33929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33928_33929 : H12AffineEnvironment.transform 14 29789 env33928 = env33929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env33928 == env33929) = true)

theorem identity33929 : scanCanonicalize (H12AffineFastState.compose env33929 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound33929 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,80,8203,5393,10281,1024,81,4161,8493,8476,138,8328,64,10708,13340,4096,10361,1500,33,256,8492,13525,513]

theorem envBound33930 : H12AffineFastState.Bounded env33930 := by
  intro p hp
  have h : env33930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33929_33930 : H12AffineEnvironment.transform 13 13325 env33929 = env33930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env33929 == env33930) = true)

theorem identity33930 : scanCanonicalize (H12AffineFastState.compose env33930 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound33930 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5513,80,399,5393,2477,1024,81,4161,169,152,138,268,64,2128,5528,4096,2557,1500,33,256,168,5457,513]

theorem envBound33931 : H12AffineFastState.Bounded env33931 := by
  intro p hp
  have h : env33931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33930_33931 : H12AffineEnvironment.transform 12 388 env33930 = env33931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env33930 == env33931) = true)

theorem identity33931 : scanCanonicalize (H12AffineFastState.compose env33931 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound33931 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3108,388,2477,80,399,2357,2477,1024,81,3173,169,152,138,268,64,2128,2492,3108,2557,1500,33,256,168,2421,513]

theorem envBound33932 : H12AffineFastState.Bounded env33932 := by
  intro p hp
  have h : env33932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33931_33932 : H12AffineEnvironment.transform 11 3108 env33931 = env33932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env33931 == env33932) = true)

theorem identity33932 : scanCanonicalize (H12AffineFastState.compose env33932 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound33932 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env33933 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,3108,348,2421,80,343,2357,2421,1024,81,3173,113,64,82,268,64,2128,2404,3108,2341,1284,33,256,112,2421,513]

theorem envBound33933 : H12AffineFastState.Bounded env33933 := by
  intro p hp
  have h : env33933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33932_33933 : H12AffineEnvironment.transform 6 88 env33932 = env33933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env33932 == env33933) = true)

theorem identity33933 : scanCanonicalize (H12AffineFastState.compose env33933 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33933 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33934 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,268,2341,0,263,2357,2341,1024,1,3125,33,16,2,268,16,2048,2356,3108,2341,1284,33,256,32,2341,513]

theorem envBound33934 : H12AffineFastState.Bounded env33934 := by
  intro p hp
  have h : env33934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33933_33934 : H12AffineEnvironment.transform 5 16 env33933 = env33934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33933 == env33934) = true)

theorem identity33934 : scanCanonicalize (H12AffineFastState.compose env33934 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound33934 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33935 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1281,293,268,1060,0,263,1076,1060,1024,1,308,33,16,2,268,16,1281,1077,293,1060,1284,33,256,32,1060,513]

theorem envBound33935 : H12AffineFastState.Bounded env33935 := by
  intro p hp
  have h : env33935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33934_33935 : H12AffineEnvironment.transform 10 1281 env33934 = env33935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env33934 == env33935) = true)

theorem identity33935 : scanCanonicalize (H12AffineFastState.compose env33935 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound33935 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33936 : List Nat := [2,4,8,16,32,16,8,256,512,266,11,293,268,302,0,263,318,302,266,1,308,33,16,2,268,16,11,319,293,302,14,33,256,32,302,513]

theorem envBound33936 : H12AffineFastState.Bounded env33936 := by
  intro p hp
  have h : env33936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33935_33936 : H12AffineEnvironment.transform 9 266 env33935 = env33936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env33935 == env33936) = true)

theorem identity33936 : scanCanonicalize (H12AffineFastState.compose env33936 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound33936 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33937 : List Nat := [2,4,8,16,32,16,8,15,512,5,11,42,3,33,0,8,49,33,5,1,59,33,16,2,3,16,11,48,42,33,14,33,15,32,33,513]

theorem envBound33937 : H12AffineFastState.Bounded env33937 := by
  intro p hp
  have h : env33937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33936_33937 : H12AffineEnvironment.transform 7 15 env33936 = env33937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env33936 == env33937) = true)

def env33938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,2175169,8328,64,2609402,46157,77835,2598235,119179,2101345,256,2199863,2191507,63069]

theorem envBound33938 : H12AffineFastState.Bounded env33938 := by
  intro p hp
  have h : env33938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33866_33938 : H12AffineEnvironment.transform 23 2175169 env33866 = env33938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175169 env33866 == env33938) = true)

def env33939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21793,95515,73857,8328,64,508090,46157,77835,505115,119179,33,256,98679,90323,63069]

theorem envBound33939 : H12AffineFastState.Bounded env33939 := by
  intro p hp
  have h : env33939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33938_33939 : H12AffineEnvironment.transform 20 4160 env33938 = env33939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33938 == env33939) = true)

theorem identity33939 : scanCanonicalize (H12AffineFastState.compose env33939 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33939 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,21793,21776,138,8328,64,450737,46157,4096,431376,61824,33,256,41340,16600,63069]

theorem envBound33940 : H12AffineFastState.Bounded env33940 := by
  intro p hp
  have h : env33940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33939_33940 : H12AffineEnvironment.transform 15 8203 env33939 = env33940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33939 == env33940) = true)

def env33941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32160,1024,32769,4160,21793,21776,138,8328,64,171281,46157,4096,190640,61824,33,256,41340,16600,63069]

theorem envBound33941 : H12AffineFastState.Bounded env33941 := by
  intro p hp
  have h : env33941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33940_33941 : H12AffineEnvironment.transform 17 32160 env33940 = env33941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env33940 == env33941) = true)

theorem identity33941 : scanCanonicalize (H12AffineFastState.compose env33941 (packedSelected [3,10,16,20,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33941 : packedSelected [3,10,16,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env33942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1024,32769,4160,21793,21776,3,8193,64,171281,46157,4096,190521,61705,33,256,41340,16465,63069]

theorem envBound33942 : H12AffineFastState.Bounded env33942 := by
  intro p hp
  have h : env33942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33941_33942 : H12AffineEnvironment.transform 6 9 env33941 = env33942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33941 == env33942) = true)

theorem identity33942 : scanCanonicalize (H12AffineFastState.compose env33942 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33942 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,131072,32041,1024,8541,4160,21793,21776,3,8193,64,146509,5393,4096,149861,20565,33,256,32,16465,22273]

theorem envBound33943 : H12AffineFastState.Bounded env33943 := by
  intro p hp
  have h : env33943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33942_33943 : H12AffineEnvironment.transform 14 8540 env33942 = env33943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33942 == env33943) = true)

theorem identity33943 : scanCanonicalize (H12AffineFastState.compose env33943 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7513) := by decide +kernel

theorem selectedBound33943 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7513,16384,7173,7506,131072,16496,1024,7172,4160,21793,21776,3,7512,64,131348,5393,4096,149861,20565,33,256,32,16465,22273]

theorem envBound33944 : H12AffineFastState.Bounded env33944 := by
  intro p hp
  have h : env33944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33943_33944 : H12AffineEnvironment.transform 12 7513 env33943 = env33944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7513 env33943 == env33944) = true)

theorem identity33944 : scanCanonicalize (H12AffineFastState.compose env33944 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 113) := by decide +kernel

theorem selectedBound33944 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env33945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7513,113,7173,7506,131072,1,1024,7172,4160,5456,5473,3,7512,64,131348,5393,4096,133396,4132,33,256,32,32,6000]

theorem envBound33945 : H12AffineFastState.Bounded env33945 := by
  intro p hp
  have h : env33945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33944_33945 : H12AffineEnvironment.transform 13 113 env33944 = env33945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 113 env33944 == env33945) = true)

theorem identity33945 : scanCanonicalize (H12AffineFastState.compose env33945 (packedSelected [1,4,6,8,9,10,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound33945 : packedSelected [1,4,6,8,9,10,15,16] rootPS < 2^1333 := by decide +kernel

def env33946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,3133,113,3425,3126,131072,1,1024,3424,292,1076,1029,3,3132,64,131348,1141,356,133396,320,33,256,32,32,1556]

theorem envBound33946 : H12AffineFastState.Bounded env33946 := by
  intro p hp
  have h : env33946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33945_33946 : H12AffineEnvironment.transform 11 356 env33945 = env33946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env33945 == env33946) = true)

theorem identity33946 : scanCanonicalize (H12AffineFastState.compose env33946 (packedSelected [0,1,2,7,8,10,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33946 : packedSelected [0,1,2,7,8,10,15,18] rootPS < 2^1333 := by decide +kernel

def env33947 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,356,2056,113,2388,2051,131072,1,53,2389,292,1,48,3,2057,64,131348,64,356,133396,320,33,256,32,32,545]

theorem envBound33947 : H12AffineFastState.Bounded env33947 := by
  intro p hp
  have h : env33947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33946_33947 : H12AffineEnvironment.transform 9 53 env33946 = env33947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33946 == env33947) = true)

theorem identity33947 : scanCanonicalize (H12AffineFastState.compose env33947 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 2096) := by decide +kernel

theorem selectedBound33947 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env33948 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,356,2056,113,2388,2051,2096,1,53,2389,292,1,48,3,2057,64,2340,64,356,292,320,33,256,32,32,545]

theorem envBound33948 : H12AffineFastState.Bounded env33948 := by
  intro p hp
  have h : env33948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33947_33948 : H12AffineEnvironment.transform 16 2096 env33947 = env33948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2096 env33947 == env33948) = true)

theorem identity33948 : scanCanonicalize (H12AffineFastState.compose env33948 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33948 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env33949 : List Nat := [2,4,8,16,17,64,9,256,512,4,2048,341,2056,64,2388,2051,2049,1,4,2389,277,1,1,3,2057,64,2325,64,341,277,320,16,256,17,17,528]

theorem envBound33949 : H12AffineFastState.Bounded env33949 := by
  intro p hp
  have h : env33949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33948_33949 : H12AffineEnvironment.transform 4 17 env33948 = env33949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33948 == env33949) = true)

theorem identity33949 : scanCanonicalize (H12AffineFastState.compose env33949 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound33949 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env33950 : List Nat := [2,4,8,16,17,64,9,256,512,4,80,341,88,64,260,83,81,1,4,261,277,1,1,3,89,64,325,64,341,277,320,16,256,17,17,528]

theorem envBound33950 : H12AffineFastState.Bounded env33950 := by
  intro p hp
  have h : env33950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33949_33950 : H12AffineEnvironment.transform 10 80 env33949 = env33950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env33949 == env33950) = true)

theorem identity33950 : scanCanonicalize (H12AffineFastState.compose env33950 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound33950 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33951 : List Nat := [2,4,8,16,17,64,9,256,64,4,80,341,88,64,260,83,81,1,4,261,277,1,1,3,89,64,325,64,341,277,320,16,256,17,17,80]

theorem envBound33951 : H12AffineFastState.Bounded env33951 := by
  intro p hp
  have h : env33951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33950_33951 : H12AffineEnvironment.transform 8 64 env33950 = env33951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env33950 == env33951) = true)

def env33952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32161,1024,32769,4160,21793,21776,138,8328,64,171280,46157,4096,190641,61824,33,256,41340,16600,63069]

theorem envBound33952 : H12AffineFastState.Bounded env33952 := by
  intro p hp
  have h : env33952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33940_33952 : H12AffineEnvironment.transform 17 32161 env33940 = env33952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env33940 == env33952) = true)

theorem identity33952 : scanCanonicalize (H12AffineFastState.compose env33952 (packedSelected [3,10,16,20,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound33952 : packedSelected [3,10,16,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env33953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,32161,1024,32769,4160,21793,21776,138,8328,64,23944,46157,4096,10281,61824,33,256,41340,16600,63069]

theorem envBound33953 : H12AffineFastState.Bounded env33953 := by
  intro p hp
  have h : env33953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33952_33953 : H12AffineEnvironment.transform 16 49304 env33952 = env33953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env33952 == env33953) = true)

def env33954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,32041,1024,32769,4160,21793,21776,2,8192,64,23808,46157,4096,10281,61704,33,256,41340,16464,63069]

theorem envBound33954 : H12AffineFastState.Bounded env33954 := by
  intro p hp
  have h : env33954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33953_33954 : H12AffineEnvironment.transform 6 8 env33953 = env33954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33953 == env33954) = true)

theorem identity33954 : scanCanonicalize (H12AffineFastState.compose env33954 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33954 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,38160,10281,1024,32769,4160,33,16,2,8192,64,2048,46157,4096,10281,41992,33,256,41340,5456,41821]

theorem envBound33955 : H12AffineFastState.Bounded env33955 := by
  intro p hp
  have h : env33955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33954_33955 : H12AffineEnvironment.transform 13 5376 env33954 = env33955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33954 == env33955) = true)

theorem identity33955 : scanCanonicalize (H12AffineFastState.compose env33955 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33955 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13388,10281,1024,8541,4160,33,16,2,8192,64,2048,5393,4096,10281,1364,33,256,32,5456,513]

theorem envBound33956 : H12AffineFastState.Bounded env33956 := by
  intro p hp
  have h : env33956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33955_33956 : H12AffineEnvironment.transform 14 8540 env33955 = env33956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33955 == env33956) = true)

theorem identity33956 : scanCanonicalize (H12AffineFastState.compose env33956 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33956 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33957 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8203,13340,10281,1024,8461,4112,33,16,2,8192,16,2048,5393,4096,10281,1284,33,256,32,5376,513]

theorem envBound33957 : H12AffineFastState.Bounded env33957 := by
  intro p hp
  have h : env33957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33956_33957 : H12AffineEnvironment.transform 5 16 env33956 = env33957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33956 == env33957) = true)

theorem identity33957 : scanCanonicalize (H12AffineFastState.compose env33957 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33957 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33958 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,262,5393,2340,1024,0,4112,33,16,2,269,16,2048,5393,4096,2340,1284,33,256,32,5376,513]

theorem envBound33958 : H12AffineFastState.Bounded env33958 := by
  intro p hp
  have h : env33958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33957_33958 : H12AffineEnvironment.transform 12 269 env33957 = env33958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33957 == env33958) = true)

theorem identity33958 : scanCanonicalize (H12AffineFastState.compose env33958 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33958 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33959 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,34,5173,2048,1024,0,4112,33,16,2,41,16,2048,5173,4096,2048,1056,33,36,32,5156,513]

theorem envBound33959 : H12AffineFastState.Bounded env33959 := by
  intro p hp
  have h : env33959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33958_33959 : H12AffineEnvironment.transform 7 36 env33958 = env33959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33958 == env33959) = true)

def env33960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,32040,1024,32769,4160,21793,21776,3,8193,64,23809,46157,4096,10281,61705,33,256,41340,16465,63069]

theorem envBound33960 : H12AffineFastState.Bounded env33960 := by
  intro p hp
  have h : env33960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33953_33960 : H12AffineEnvironment.transform 6 9 env33953 = env33960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33953 == env33960) = true)

theorem identity33960 : scanCanonicalize (H12AffineFastState.compose env33960 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33960 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,13389,32040,1024,29789,4160,21793,21776,3,8193,64,23809,16401,4096,10281,1365,33,256,21792,16465,513]

theorem envBound33961 : H12AffineFastState.Bounded env33961 := by
  intro p hp
  have h : env33961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33960_33961 : H12AffineEnvironment.transform 14 29788 env33960 = env33961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33960 == env33961) = true)

theorem identity33961 : scanCanonicalize (H12AffineFastState.compose env33961 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound33961 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,21541,114,5172,23889,1024,21540,4160,21793,21776,3,120,64,23809,16401,4096,2128,1365,33,256,21792,16465,513]

theorem envBound33962 : H12AffineFastState.Bounded env33962 := by
  intro p hp
  have h : env33962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33961_33962 : H12AffineEnvironment.transform 12 121 env33961 = env33962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env33961 == env33962) = true)

def env33963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21792,95514,73856,8328,64,508091,46157,77835,505114,119179,32,256,98678,90322,63069]

theorem envBound33963 : H12AffineFastState.Bounded env33963 := by
  intro p hp
  have h : env33963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33938_33963 : H12AffineEnvironment.transform 20 4161 env33938 = env33963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33938 == env33963) = true)

theorem identity33963 : scanCanonicalize (H12AffineFastState.compose env33963 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound33963 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30082,131072,262144,1024,32769,4161,21792,152,21762,8328,64,439609,46157,17801,442520,41993,32,256,62708,5456,63069]

theorem envBound33964 : H12AffineFastState.Bounded env33964 := by
  intro p hp
  have h : env33964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33963_33964 : H12AffineEnvironment.transform 15 30082 env33963 = env33964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env33963 == env33964) = true)

def env33965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,4161,21792,16,21762,8192,64,439609,46157,17665,442384,41993,32,256,62588,5456,63069]

theorem envBound33965 : H12AffineFastState.Bounded env33965 := by
  intro p hp
  have h : env33965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33964_33965 : H12AffineEnvironment.transform 6 8 env33964 = env33965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33964 == env33965) = true)

theorem identity33965 : scanCanonicalize (H12AffineFastState.compose env33965 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33965 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env33966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,131072,262144,1024,29789,4161,21792,16,21762,8192,64,409957,16401,17665,406604,20565,32,256,32,5456,513]

theorem envBound33966 : H12AffineFastState.Bounded env33966 := by
  intro p hp
  have h : env33966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33965_33966 : H12AffineEnvironment.transform 14 29788 env33965 = env33966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33965 == env33966) = true)

theorem identity33966 : scanCanonicalize (H12AffineFastState.compose env33966 (packedSelected [0,2,6,7,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound33966 : packedSelected [0,2,6,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env33967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,131072,23669,1024,29789,4161,21792,16,21762,8192,64,138512,16401,17665,157753,20565,32,256,32,5456,513]

theorem envBound33967 : H12AffineFastState.Bounded env33967 := by
  intro p hp
  have h : env33967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33966_33967 : H12AffineEnvironment.transform 17 23669 env33966 = env33967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env33966 == env33967) = true)

theorem identity33967 : scanCanonicalize (H12AffineFastState.compose env33967 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound33967 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env33968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,343,131072,10280,1024,0,4161,8573,16,8543,8192,64,138512,13388,12636,138340,9224,32,256,32,5456,513]

theorem envBound33968 : H12AffineFastState.Bounded env33968 := by
  intro p hp
  have h : env33968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33967_33968 : H12AffineEnvironment.transform 13 13405 env33967 = env33968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env33967 == env33968) = true)

theorem identity33968 : scanCanonicalize (H12AffineFastState.compose env33968 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1133) := by decide +kernel

theorem selectedBound33968 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1133,4144,1,343,131072,3141,1024,0,4161,1296,16,1330,1133,64,138512,4129,5425,138340,101,32,256,32,5456,513]

theorem envBound33969 : H12AffineFastState.Bounded env33969 := by
  intro p hp
  have h : env33969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33968_33969 : H12AffineEnvironment.transform 12 1133 env33968 = env33969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1133 env33968 == env33969) = true)

theorem identity33969 : scanCanonicalize (H12AffineFastState.compose env33969 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 6177) := by decide +kernel

theorem selectedBound33969 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env33970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1133,4144,1,343,6177,3141,1024,0,4161,1296,16,1330,1133,64,1329,4129,5425,1093,101,32,256,32,5456,513]

theorem envBound33970 : H12AffineFastState.Bounded env33970 := by
  intro p hp
  have h : env33970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33969_33970 : H12AffineEnvironment.transform 16 6177 env33969 = env33970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6177 env33969 == env33970) = true)

theorem identity33970 : scanCanonicalize (H12AffineFastState.compose env33970 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound33970 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env33971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1133,1377,1,343,3440,3141,1024,0,1296,1296,16,1330,1133,64,1329,1392,96,1093,101,32,256,32,1,513]

theorem envBound33971 : H12AffineFastState.Bounded env33971 := by
  intro p hp
  have h : env33971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33970_33971 : H12AffineEnvironment.transform 11 1361 env33970 = env33971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env33970 == env33971) = true)

theorem identity33971 : scanCanonicalize (H12AffineFastState.compose env33971 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33971 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1361,1133,1377,1,343,1393,1092,1024,0,1296,1296,16,1330,1133,64,1329,1392,96,1093,101,32,256,32,1,513]

theorem envBound33972 : H12AffineFastState.Bounded env33972 := by
  intro p hp
  have h : env33972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33971_33972 : H12AffineEnvironment.transform 10 1 env33971 = env33972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33971 == env33972) = true)

theorem identity33972 : scanCanonicalize (H12AffineFastState.compose env33972 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 817) := by decide +kernel

theorem selectedBound33972 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env33973 : List Nat := [2,4,8,16,32,64,8,256,512,817,1,608,860,592,1,343,576,885,817,0,545,545,16,515,860,64,512,577,96,884,101,32,256,32,1,513]

theorem envBound33973 : H12AffineFastState.Bounded env33973 := by
  intro p hp
  have h : env33973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33972_33973 : H12AffineEnvironment.transform 9 817 env33972 = env33973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 817 env33972 == env33973) = true)

theorem identity33973 : scanCanonicalize (H12AffineFastState.compose env33973 (packedSelected [0,3,5,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound33973 : packedSelected [0,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env33974 : List Nat := [2,4,8,16,32,64,8,256,33,272,1,65,381,113,1,343,97,340,272,0,0,0,16,34,381,64,33,96,96,341,101,32,256,32,1,32]

theorem envBound33974 : H12AffineFastState.Bounded env33974 := by
  intro p hp
  have h : env33974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33973_33974 : H12AffineEnvironment.transform 8 33 env33973 = env33974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env33973 == env33974) = true)

theorem identity33974 : scanCanonicalize (H12AffineFastState.compose env33974 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33974 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33975 : List Nat := [2,4,8,16,32,64,8,116,33,100,1,65,9,113,1,35,97,32,100,0,0,0,16,34,9,64,33,96,96,33,101,32,116,32,1,32]

theorem envBound33975 : H12AffineFastState.Bounded env33975 := by
  intro p hp
  have h : env33975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33974_33975 : H12AffineEnvironment.transform 7 116 env33974 = env33975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33974 == env33975) = true)

theorem identity33975 : scanCanonicalize (H12AffineFastState.compose env33975 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound33975 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env33976 : List Nat := [2,4,8,16,32,49,8,5,33,21,1,48,9,0,1,35,16,32,21,0,0,0,16,34,9,49,33,17,17,33,20,32,5,32,1,32]

theorem envBound33976 : H12AffineFastState.Bounded env33976 := by
  intro p hp
  have h : env33976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33975_33976 : H12AffineEnvironment.transform 5 49 env33975 = env33976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env33975 == env33976) = true)

theorem identity33976 : scanCanonicalize (H12AffineFastState.compose env33976 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33976 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33977 : List Nat := [2,4,8,1,32,32,8,5,33,4,1,33,9,0,1,35,1,32,4,0,0,0,1,34,9,32,33,0,0,33,5,32,5,32,1,32]

theorem envBound33977 : H12AffineFastState.Bounded env33977 := by
  intro p hp
  have h : env33977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33976_33977 : H12AffineEnvironment.transform 3 1 env33976 = env33977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33976 == env33977) = true)

def env33978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,4161,21792,17,21762,8193,64,439609,46157,17664,442385,41993,32,256,62589,5456,63069]

theorem envBound33978 : H12AffineFastState.Bounded env33978 := by
  intro p hp
  have h : env33978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33964_33978 : H12AffineEnvironment.transform 6 9 env33964 = env33978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33964 == env33978) = true)

theorem identity33978 : scanCanonicalize (H12AffineFastState.compose env33978 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound33978 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,35188,1024,32769,4161,21792,17,21762,8193,64,146509,46157,17664,149861,41993,32,256,62589,5456,63069]

theorem envBound33979 : H12AffineFastState.Bounded env33979 := by
  intro p hp
  have h : env33979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33978_33979 : H12AffineEnvironment.transform 17 35188 env33978 = env33979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env33978 == env33979) = true)

theorem identity33979 : scanCanonicalize (H12AffineFastState.compose env33979 (packedSelected [0,1,5,8,9,10,18,22,23,24,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound33979 : packedSelected [0,1,5,8,9,10,18,22,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env33980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,29963,131072,32120,1024,29709,4161,21792,17,21762,8193,64,146509,16449,17664,149861,20485,32,256,113,5456,593]

theorem envBound33980 : H12AffineFastState.Bounded env33980 := by
  intro p hp
  have h : env33980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33979_33980 : H12AffineEnvironment.transform 14 29708 env33979 = env33980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env33979 == env33980) = true)

theorem identity33980 : scanCanonicalize (H12AffineFastState.compose env33980 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound33980 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env33981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,8283,131072,10280,1024,8541,4161,112,17,82,8193,64,146509,5393,4176,138293,1365,32,256,113,5456,593]

theorem envBound33981 : H12AffineFastState.Bounded env33981 := by
  intro p hp
  have h : env33981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33980_33981 : H12AffineEnvironment.transform 13 5456 env33980 = env33981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env33980 == env33981) = true)

theorem identity33981 : scanCanonicalize (H12AffineFastState.compose env33981 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 4129) := by decide +kernel

theorem selectedBound33981 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env33982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,8283,4129,10280,1024,8541,4161,112,17,82,8193,64,11372,5393,4176,3092,1365,32,256,113,5456,593]

theorem envBound33982 : H12AffineFastState.Bounded env33982 := by
  intro p hp
  have h : env33982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33981_33982 : H12AffineEnvironment.transform 16 4129 env33981 = env33982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4129 env33981 == env33982) = true)

theorem identity33982 : scanCanonicalize (H12AffineFastState.compose env33982 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound33982 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env33983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5456,292,35,4129,2128,1024,293,4161,112,17,82,121,64,3092,5393,4176,3092,1365,32,256,113,5456,593]

theorem envBound33983 : H12AffineFastState.Bounded env33983 := by
  intro p hp
  have h : env33983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33982_33983 : H12AffineEnvironment.transform 12 120 env33982 = env33983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env33982 == env33983) = true)

theorem identity33983 : scanCanonicalize (H12AffineFastState.compose env33983 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33983 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33984 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,120,5205,33,35,4129,2128,1024,32,4161,112,17,82,121,64,3092,5140,4176,3092,1104,32,5,113,5205,593]

theorem envBound33984 : H12AffineFastState.Bounded env33984 := by
  intro p hp
  have h : env33984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33983_33984 : H12AffineEnvironment.transform 7 5 env33983 = env33984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33983 == env33984) = true)

theorem identity33984 : scanCanonicalize (H12AffineFastState.compose env33984 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound33984 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33985 : List Nat := [2,4,8,16,32,64,9,5,512,69,2048,4096,120,4112,33,35,4129,2128,69,32,4161,112,17,82,121,64,2129,4177,4176,2129,21,32,5,113,4112,593]

theorem envBound33985 : H12AffineFastState.Bounded env33985 := by
  intro p hp
  have h : env33985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33984_33985 : H12AffineEnvironment.transform 9 69 env33984 = env33985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env33984 == env33985) = true)

theorem identity33985 : scanCanonicalize (H12AffineFastState.compose env33985 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound33985 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33986 : List Nat := [2,4,8,16,32,49,9,5,512,52,2048,4096,9,4112,33,35,4129,2081,52,32,4144,1,17,35,8,49,2080,4128,4129,2080,21,32,5,0,4112,544]

theorem envBound33986 : H12AffineFastState.Bounded env33986 := by
  intro p hp
  have h : env33986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33985_33986 : H12AffineEnvironment.transform 5 49 env33985 = env33986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env33985 == env33986) = true)

theorem identity33986 : scanCanonicalize (H12AffineFastState.compose env33986 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound33986 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env33987 : List Nat := [2,4,8,16,32,49,9,5,512,52,49,4096,9,4112,33,35,4129,16,52,32,4144,1,17,35,8,49,17,4128,4129,17,21,32,5,0,4112,544]

theorem envBound33987 : H12AffineFastState.Bounded env33987 := by
  intro p hp
  have h : env33987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33986_33987 : H12AffineEnvironment.transform 10 49 env33986 = env33987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env33986 == env33987) = true)

theorem identity33987 : scanCanonicalize (H12AffineFastState.compose env33987 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound33987 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env33988 : List Nat := [2,4,8,16,32,49,9,5,512,52,49,544,9,560,33,35,513,16,52,32,528,1,17,35,8,49,17,512,513,17,21,32,5,0,560,544]

theorem envBound33988 : H12AffineFastState.Bounded env33988 := by
  intro p hp
  have h : env33988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33987_33988 : H12AffineEnvironment.transform 11 544 env33987 = env33988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env33987 == env33988) = true)

theorem identity33988 : scanCanonicalize (H12AffineFastState.compose env33988 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33988 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env33989 : List Nat := [2,4,8,16,1,16,9,5,512,21,16,513,9,529,0,2,513,16,21,1,528,1,17,2,8,16,17,512,513,17,21,1,5,0,529,513]

theorem envBound33989 : H12AffineFastState.Bounded env33989 := by
  intro p hp
  have h : env33989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33988_33989 : H12AffineEnvironment.transform 4 1 env33988 = env33989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33988 == env33989) = true)

theorem identity33989 : scanCanonicalize (H12AffineFastState.compose env33989 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33989 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33990 : List Nat := [2,1,8,16,1,16,9,0,512,16,16,513,9,529,0,2,513,16,16,1,528,1,17,2,8,16,17,512,513,17,16,1,0,0,529,513]

theorem envBound33990 : H12AffineFastState.Bounded env33990 := by
  intro p hp
  have h : env33990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33989_33990 : H12AffineEnvironment.transform 1 1 env33989 = env33990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33989 == env33990) = true)

theorem identity33990 : scanCanonicalize (H12AffineFastState.compose env33990 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound33990 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33991 : List Nat := [2,1,8,2,1,2,9,0,512,2,2,513,9,515,0,2,513,2,2,1,514,1,3,2,8,2,3,512,513,3,2,1,0,0,515,513]

theorem envBound33991 : H12AffineFastState.Bounded env33991 := by
  intro p hp
  have h : env33991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33990_33991 : H12AffineEnvironment.transform 3 2 env33990 = env33991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env33990 == env33991) = true)

theorem identity33991 : scanCanonicalize (H12AffineFastState.compose env33991 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound33991 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33992 : List Nat := [2,1,8,2,1,2,9,0,8,2,2,9,9,11,0,2,9,2,2,1,10,1,3,2,8,2,3,8,9,3,2,1,0,0,11,9]

theorem envBound33992 : H12AffineFastState.Bounded env33992 := by
  intro p hp
  have h : env33992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33991_33992 : H12AffineEnvironment.transform 8 8 env33991 = env33992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env33991 == env33992) = true)

theorem identity33992 : scanCanonicalize (H12AffineFastState.compose env33992 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound33992 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env33993 : List Nat := [2,1,0,2,1,2,1,0,0,2,2,1,1,3,0,2,1,2,2,1,2,1,3,2,0,2,3,0,1,3,2,1,0,0,3,1]

theorem envBound33993 : H12AffineFastState.Bounded env33993 := by
  intro p hp
  have h : env33993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33992_33993 : H12AffineEnvironment.transform 2 0 env33992 = env33993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env33992 == env33993) = true)

def env33994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265169,23160257,257,27378860,27337993,25207750]

theorem envBound33994 : H12AffineFastState.Bounded env33994 := by
  intro p hp
  have h : env33994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33749_33994 : H12AffineEnvironment.transform 18 1025 env33749 = env33994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env33749 == env33994) = true)

theorem identity33994 : scanCanonicalize (H12AffineFastState.compose env33994 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2262490) := by decide +kernel

theorem selectedBound33994 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2262490,8328,64,15025626,196951,10507600,8830977,10682827,4448283,257,8601974,8626387,10626588]

theorem envBound33995 : H12AffineFastState.Bounded env33995 := by
  intro p hp
  have h : env33995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33994_33995 : H12AffineEnvironment.transform 23 2262490 env33994 = env33995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2262490 env33994 == env33995) = true)

def env33996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15025626,115151,10507600,8650905,10600787,4268163,257,8487406,8478795,10544772]

theorem envBound33996 : H12AffineFastState.Bounded env33996 := by
  intro p hp
  have h : env33996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33995_33996 : H12AffineEnvironment.transform 16 49304 env33995 = env33996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env33995 == env33996) = true)

def env33997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4543882,115151,17664,2363593,119043,4268163,257,2199998,2191387,63188]

theorem envBound33997 : H12AffineFastState.Bounded env33997 := by
  intro p hp
  have h : env33997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33996_33997 : H12AffineEnvironment.transform 22 2101328 env33996 = env33997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env33996 == env33997) = true)

def env33998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,97546,115151,17664,2363593,119043,329731,257,2199998,2191387,63188]

theorem envBound33998 : H12AffineFastState.Bounded env33998 := by
  intro p hp
  have h : env33998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33997_33998 : H12AffineEnvironment.transform 21 272512 env33997 = env33998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env33997 == env33998) = true)

theorem identity33998 : scanCanonicalize (H12AffineFastState.compose env33998 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33998 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,23809,57796,17664,2363593,61704,272392,257,2142645,2117648,63188]

theorem envBound33999 : H12AffineFastState.Bounded env33999 := by
  intro p hp
  have h : env33999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33998_33999 : H12AffineEnvironment.transform 15 8203 env33998 = env33999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33998 == env33999) = true)

def env34000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,2097152,272392,2101328,2114882,8192,64,23809,57676,17664,2363457,61704,272392,257,2142525,2117648,63068]

theorem envBound34000 : H12AffineFastState.Bounded env34000 := by
  intro p hp
  have h : env34000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33999_34000 : H12AffineEnvironment.transform 6 8 env33999 = env34000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33999 == env34000) = true)

def env34001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,2097152,272393,2101328,2114882,8193,64,23809,57677,17664,2363456,61704,272392,257,2142524,2117648,63069]

theorem envBound34001 : H12AffineFastState.Bounded env34001 := by
  intro p hp
  have h : env34001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33999_34001 : H12AffineEnvironment.transform 6 9 env33999 = env34001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33999 == env34001) = true)

theorem identity34001 : scanCanonicalize (H12AffineFastState.compose env34001 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound34001 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env34002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8203,46156,262144,1025,32769,2097152,272393,2101328,2109727,8193,64,10588,38160,12637,2363456,34133,272392,257,2142524,2106445,33280]

theorem envBound34002 : H12AffineFastState.Bounded env34002 := by
  intro p hp
  have h : env34002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34001_34002 : H12AffineEnvironment.transform 13 13405 env34001 = env34002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env34001 == env34002) = true)

theorem identity34002 : scanCanonicalize (H12AffineFastState.compose env34002 (packedSelected [1,3,4,5,9,10,12,14,17,19,20,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 268597) := by decide +kernel

theorem selectedBound34002 : packedSelected [1,3,4,5,9,10,12,14,17,19,20,28,31,38] rootPS < 2^1333 := by decide +kernel

def env34003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8203,46156,262144,1025,32769,268597,272393,264549,272426,8193,64,10588,38160,12637,2421,34133,272392,257,305161,277880,33280]

theorem envBound34003 : H12AffineFastState.Bounded env34003 := by
  intro p hp
  have h : env34003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34002_34003 : H12AffineEnvironment.transform 20 268597 env34002 = env34003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268597 env34002 == env34003) = true)

theorem identity34003 : scanCanonicalize (H12AffineFastState.compose env34003 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound34003 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env34004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,373,8203,13625,262144,1025,372,268597,272393,264549,272426,8193,64,10588,5221,12637,2421,1056,272392,257,272764,277880,885]

theorem envBound34004 : H12AffineFastState.Bounded env34004 := by
  intro p hp
  have h : env34004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34003_34004 : H12AffineEnvironment.transform 14 373 env34003 = env34004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env34003 == env34004) = true)

theorem identity34004 : scanCanonicalize (H12AffineFastState.compose env34004 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34004 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34005 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13405,1,8203,13389,262144,1025,0,268353,272393,264209,272426,8193,64,10280,5221,12329,2049,1056,272392,117,272392,277516,513]

end H12CloudChart0