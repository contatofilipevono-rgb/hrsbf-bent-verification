import H12CloudChart0Data157

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans40055_40056 : H12AffineEnvironment.transform 12 1305 env40055 = env40056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env40055 == env40056) = true)

def env40057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8193,64,4677966,115015,45404,442384,75102,4268042,256,98678,90202,513]

theorem envBound40057 : H12AffineFastState.Bounded env40057 := by
  intro p hp
  have h : env40057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40048_40057 : H12AffineEnvironment.transform 6 9 env40048 = env40057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40048 == env40057) = true)

def env40058 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41231,8193,16,4677918,114967,45324,442384,75022,4268042,256,98598,90122,513]

theorem envBound40058 : H12AffineFastState.Bounded env40058 := by
  intro p hp
  have h : env40058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40057_40058 : H12AffineEnvironment.transform 5 16 env40057 = env40058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40057 == env40058) = true)

def env40059 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,4194304,16,41231,8193,16,4409654,114967,45324,190520,75022,4268042,256,98598,90122,513]

theorem envBound40059 : H12AffineFastState.Bounded env40059 := by
  intro p hp
  have h : env40059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40058_40059 : H12AffineEnvironment.transform 17 10280 env40058 = env40059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40058 == env40059) = true)

theorem identity40059 : scanCanonicalize (H12AffineFastState.compose env40059 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118034) := by decide +kernel

theorem selectedBound40059 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env40060 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58397,118034,16,41231,8193,16,164900,114967,45324,190520,75022,60696,256,98598,90122,513]

theorem envBound40060 : H12AffineFastState.Bounded env40060 := by
  intro p hp
  have h : env40060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40059_40060 : H12AffineEnvironment.transform 21 118034 env40059 = env40060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118034 env40059 == env40060) = true)

theorem identity40060 : scanCanonicalize (H12AffineFastState.compose env40060 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound40060 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env40061 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58397,118034,16,41231,8193,16,123967,114967,45324,100387,75022,60696,256,98598,90122,513]

theorem envBound40061 : H12AffineFastState.Bounded env40061 := by
  intro p hp
  have h : env40061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40060_40061 : H12AffineEnvironment.transform 16 90139 env40060 = env40061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env40060 == env40061) = true)

theorem identity40061 : scanCanonicalize (H12AffineFastState.compose env40061 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 293) := by decide +kernel

theorem selectedBound40061 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40062 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,293,32768,65536,74046,10280,1024,32769,42296,101431,16,41231,8193,16,107802,98354,45324,100387,75022,44093,256,98598,74031,513]

theorem envBound40062 : H12AffineFastState.Bounded env40062 := by
  intro p hp
  have h : env40062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40061_40062 : H12AffineEnvironment.transform 13 293 env40061 = env40062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 293 env40061 == env40062) = true)

theorem identity40062 : scanCanonicalize (H12AffineFastState.compose env40062 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40062 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40063 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,293,32768,8203,309,10280,1024,32769,42296,44092,16,41231,8193,16,34065,41017,45324,43048,1285,44093,256,41261,292,513]

theorem envBound40063 : H12AffineFastState.Bounded env40063 := by
  intro p hp
  have h : env40063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40062_40063 : H12AffineEnvironment.transform 15 8203 env40062 = env40063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40062 == env40063) = true)

theorem identity40063 : scanCanonicalize (H12AffineFastState.compose env40063 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound40063 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40064 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,8192,293,32768,8203,309,10280,1024,32769,42296,44092,16,41231,8193,16,34065,41017,41017,43048,1285,44093,256,41261,292,513]

theorem envBound40064 : H12AffineFastState.Bounded env40064 := by
  intro p hp
  have h : env40064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40063_40064 : H12AffineEnvironment.transform 11 309 env40063 = env40064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env40063 == env40064) = true)

theorem identity40064 : scanCanonicalize (H12AffineFastState.compose env40064 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound40064 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env40065 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,1052,293,32768,1047,309,3124,1024,32769,33060,34848,16,34067,1053,16,34065,33829,33829,35892,1285,34849,256,34097,292,513]

theorem envBound40065 : H12AffineFastState.Bounded env40065 := by
  intro p hp
  have h : env40065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40064_40065 : H12AffineEnvironment.transform 12 1052 env40064 = env40065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env40064 == env40065) = true)

theorem identity40065 : scanCanonicalize (H12AffineFastState.compose env40065 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound40065 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env40066 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,1052,293,1076,1047,309,3124,1024,1077,1296,3092,16,295,1053,16,293,17,17,2048,1285,3093,256,261,292,513]

theorem envBound40066 : H12AffineFastState.Bounded env40066 := by
  intro p hp
  have h : env40066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40065_40066 : H12AffineEnvironment.transform 14 1076 env40065 = env40066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env40065 == env40066) = true)

theorem identity40066 : scanCanonicalize (H12AffineFastState.compose env40066 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound40066 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env40067 : List Nat := [2,4,8,16,32,16,9,256,512,257,2048,309,285,293,309,278,309,2357,257,308,17,2325,16,295,284,16,293,17,17,2048,4,2324,256,261,292,513]

theorem envBound40067 : H12AffineFastState.Bounded env40067 := by
  intro p hp
  have h : env40067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40066_40067 : H12AffineEnvironment.transform 9 257 env40066 = env40067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env40066 == env40067) = true)

theorem identity40067 : scanCanonicalize (H12AffineFastState.compose env40067 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound40067 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40068 : List Nat := [2,4,8,16,32,16,9,256,512,257,293,309,285,293,309,278,309,16,257,308,17,48,16,295,284,16,293,17,17,293,4,49,256,261,292,513]

theorem envBound40068 : H12AffineFastState.Bounded env40068 := by
  intro p hp
  have h : env40068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40067_40068 : H12AffineEnvironment.transform 10 293 env40067 = env40068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env40067 == env40068) = true)

theorem identity40068 : scanCanonicalize (H12AffineFastState.compose env40068 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound40068 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40069 : List Nat := [2,4,8,16,32,16,9,53,512,52,16,0,40,16,0,35,0,16,52,1,17,48,16,18,41,16,16,17,17,16,4,49,53,48,17,513]

theorem envBound40069 : H12AffineFastState.Bounded env40069 := by
  intro p hp
  have h : env40069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40068_40069 : H12AffineEnvironment.transform 7 53 env40068 = env40069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env40068 == env40069) = true)

theorem identity40069 : scanCanonicalize (H12AffineFastState.compose env40069 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound40069 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40070 : List Nat := [2,4,8,16,32,16,9,53,49,52,16,0,40,16,0,35,0,16,52,1,17,48,16,18,41,16,16,17,17,16,4,49,53,48,17,48]

theorem envBound40070 : H12AffineFastState.Bounded env40070 := by
  intro p hp
  have h : env40070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40069_40070 : H12AffineEnvironment.transform 8 49 env40069 = env40070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40069 == env40070) = true)

theorem identity40070 : scanCanonicalize (H12AffineFastState.compose env40070 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40070 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40071 : List Nat := [2,4,8,16,17,16,9,4,0,5,16,0,25,16,0,18,0,16,5,1,17,1,16,18,24,16,16,17,17,16,4,0,4,1,17,1]

theorem envBound40071 : H12AffineFastState.Bounded env40071 := by
  intro p hp
  have h : env40071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40070_40071 : H12AffineEnvironment.transform 4 17 env40070 = env40071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40070 == env40071) = true)

theorem identity40071 : scanCanonicalize (H12AffineFastState.compose env40071 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40071 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40072 : List Nat := [2,4,8,1,0,1,9,4,0,5,1,0,8,1,0,3,0,1,5,1,0,1,1,3,9,1,1,0,0,1,4,0,4,1,0,1]

theorem envBound40072 : H12AffineFastState.Bounded env40072 := by
  intro p hp
  have h : env40072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40071_40072 : H12AffineEnvironment.transform 3 1 env40071 = env40072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40071 == env40072) = true)

def env40073 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41231,8193,16,4409655,114967,45324,190521,75022,4268042,256,98598,90122,513]

theorem envBound40073 : H12AffineFastState.Bounded env40073 := by
  intro p hp
  have h : env40073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40058_40073 : H12AffineEnvironment.transform 17 10281 env40058 = env40073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40058 == env40073) = true)

theorem identity40073 : scanCanonicalize (H12AffineFastState.compose env40073 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound40073 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env40074 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,246070,16,41231,8193,16,34817,114967,45324,190521,75022,188732,256,98598,90122,513]

theorem envBound40074 : H12AffineFastState.Bounded env40074 := by
  intro p hp
  have h : env40074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40073_40074 : H12AffineEnvironment.transform 21 246070 env40073 = env40074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env40073 == env40074) = true)

theorem identity40074 : scanCanonicalize (H12AffineFastState.compose env40074 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40074 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env40075 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,131072,10281,1024,1,25629,213302,16,8463,8193,16,2049,82199,12556,157753,75022,155964,256,65830,90122,513]

theorem envBound40075 : H12AffineFastState.Bounded env40075 := by
  intro p hp
  have h : env40075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40074_40075 : H12AffineEnvironment.transform 14 0 env40074 = env40075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40074 == env40075) = true)

theorem identity40075 : scanCanonicalize (H12AffineFastState.compose env40075 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound40075 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40076 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,262,131072,10281,1024,1,25629,147504,16,8463,8193,16,2049,16401,12556,157753,9224,155964,256,32,24844,513]

theorem envBound40076 : H12AffineFastState.Bounded env40076 := by
  intro p hp
  have h : env40076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40075_40076 : H12AffineEnvironment.transform 15 262 env40075 = env40076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env40075 == env40076) = true)

theorem identity40076 : scanCanonicalize (H12AffineFastState.compose env40076 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound40076 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env40077 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,262,16400,10281,1024,1,25629,32,16,8463,8193,16,2049,16401,12556,10281,9224,8492,256,32,24844,513]

theorem envBound40077 : H12AffineFastState.Bounded env40077 := by
  intro p hp
  have h : env40077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40076_40077 : H12AffineEnvironment.transform 16 16400 env40076 = env40077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40076 == env40077) = true)

theorem identity40077 : scanCanonicalize (H12AffineFastState.compose env40077 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40077 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env40078 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,262,16400,2340,1024,1,17680,32,16,2,268,16,2049,16401,4097,2340,1285,33,256,32,16385,513]

theorem envBound40078 : H12AffineFastState.Bounded env40078 := by
  intro p hp
  have h : env40078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40077_40078 : H12AffineEnvironment.transform 12 269 env40077 = env40078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40077 == env40078) = true)

theorem identity40078 : scanCanonicalize (H12AffineFastState.compose env40078 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4388) := by decide +kernel

theorem selectedBound40078 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40079 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,4388,0,262,4404,2340,1024,1,5172,32,16,2,268,16,2049,4405,4097,2340,1285,33,256,32,4389,513]

theorem envBound40079 : H12AffineFastState.Bounded env40079 := by
  intro p hp
  have h : env40079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40078_40079 : H12AffineEnvironment.transform 13 4388 env40078 = env40079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4388 env40078 == env40079) = true)

theorem identity40079 : scanCanonicalize (H12AffineFastState.compose env40079 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound40079 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40080 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,513,269,805,0,262,821,2340,1024,1,1589,32,16,2,268,16,2049,820,512,2340,1285,33,256,32,804,513]

theorem envBound40080 : H12AffineFastState.Bounded env40080 := by
  intro p hp
  have h : env40080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40079_40080 : H12AffineEnvironment.transform 11 513 env40079 = env40080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env40079 == env40080) = true)

theorem identity40080 : scanCanonicalize (H12AffineFastState.compose env40080 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound40080 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40081 : List Nat := [2,4,8,16,32,16,9,256,512,768,2048,513,269,805,0,262,821,2340,768,1,309,32,16,2,268,16,2049,820,512,2340,517,33,256,32,804,513]

theorem envBound40081 : H12AffineFastState.Bounded env40081 := by
  intro p hp
  have h : env40081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40080_40081 : H12AffineEnvironment.transform 9 768 env40080 = env40081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env40080 == env40081) = true)

theorem identity40081 : scanCanonicalize (H12AffineFastState.compose env40081 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound40081 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40082 : List Nat := [2,4,8,16,32,16,9,52,512,564,2048,513,57,529,0,50,513,2064,564,1,1,32,16,2,56,16,2049,512,512,2064,517,33,52,32,528,513]

theorem envBound40082 : H12AffineFastState.Bounded env40082 := by
  intro p hp
  have h : env40082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40081_40082 : H12AffineEnvironment.transform 7 52 env40081 = env40082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env40081 == env40082) = true)

theorem identity40082 : scanCanonicalize (H12AffineFastState.compose env40082 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound40082 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40083 : List Nat := [2,4,8,16,32,16,9,52,512,564,16,513,57,529,0,50,513,0,564,1,1,32,16,2,56,16,17,512,512,0,517,33,52,32,528,513]

theorem envBound40083 : H12AffineFastState.Bounded env40083 := by
  intro p hp
  have h : env40083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40082_40083 : H12AffineEnvironment.transform 10 16 env40082 = env40083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env40082 == env40083) = true)

theorem identity40083 : scanCanonicalize (H12AffineFastState.compose env40083 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound40083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40084 : List Nat := [2,4,8,16,32,16,9,52,33,21,16,32,57,48,0,50,32,0,21,1,1,32,16,2,56,16,17,33,33,0,36,33,52,32,49,32]

theorem envBound40084 : H12AffineFastState.Bounded env40084 := by
  intro p hp
  have h : env40084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40083_40084 : H12AffineEnvironment.transform 8 33 env40083 = env40084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env40083 == env40084) = true)

def env40085 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41230,8193,17,4677919,114966,45325,442384,75023,4268042,256,98599,90123,513]

theorem envBound40085 : H12AffineFastState.Bounded env40085 := by
  intro p hp
  have h : env40085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40057_40085 : H12AffineEnvironment.transform 5 17 env40057 = env40085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40057 == env40085) = true)

theorem identity40085 : scanCanonicalize (H12AffineFastState.compose env40085 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40085 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env40086 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58397,4194304,16,41230,8193,17,4409654,114966,45325,190521,75023,4268042,256,98599,90123,513]

theorem envBound40086 : H12AffineFastState.Bounded env40086 := by
  intro p hp
  have h : env40086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40085_40086 : H12AffineEnvironment.transform 17 10281 env40085 = env40086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40085 == env40086) = true)

theorem identity40086 : scanCanonicalize (H12AffineFastState.compose env40086 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound40086 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env40087 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58397,4194304,16,41230,8193,17,4385084,24860,45325,190521,34053,4227072,256,8493,49153,513]

theorem envBound40087 : H12AffineFastState.Bounded env40087 := by
  intro p hp
  have h : env40087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40086_40087 : H12AffineEnvironment.transform 15 40970 env40086 = env40087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env40086 == env40087) = true)

theorem identity40087 : scanCanonicalize (H12AffineFastState.compose env40087 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 155965) := by decide +kernel

theorem selectedBound40087 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40088 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1024,32769,58397,155965,16,41230,8193,17,34817,24860,45325,190521,34053,188733,256,8493,49153,513]

theorem envBound40088 : H12AffineFastState.Bounded env40088 := by
  intro p hp
  have h : env40088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40087_40088 : H12AffineEnvironment.transform 21 155965 env40087 = env40088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155965 env40087 == env40088) = true)

theorem identity40088 : scanCanonicalize (H12AffineFastState.compose env40088 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound40088 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40089 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10281,1024,32769,58397,8493,16,41230,8193,17,34817,24860,45325,43049,34053,41261,256,8493,49153,513]

theorem envBound40089 : H12AffineFastState.Bounded env40089 := by
  intro p hp
  have h : env40089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40088_40089 : H12AffineEnvironment.transform 16 16400 env40088 = env40089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40088 == env40089) = true)

def env40090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58516,4194304,17,41430,8328,64,4678086,115150,45524,442385,75222,4268163,256,98814,90203,512]

theorem envBound40090 : H12AffineFastState.Bounded env40090 := by
  intro p hp
  have h : env40090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40047_40090 : H12AffineEnvironment.transform 22 17 env40047 = env40090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40047 == env40090) = true)

theorem identity40090 : scanCanonicalize (H12AffineFastState.compose env40090 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10709) := by decide +kernel

theorem selectedBound40090 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10709,1024,32769,58516,4194304,17,41430,8328,64,4409363,115150,45524,190916,75222,4268163,256,98814,90203,512]

theorem envBound40091 : H12AffineFastState.Bounded env40091 := by
  intro p hp
  have h : env40091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40090_40091 : H12AffineEnvironment.transform 17 10709 env40090 = env40091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10709 env40090 == env40091) = true)

theorem identity40091 : scanCanonicalize (H12AffineFastState.compose env40091 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62848) := by decide +kernel

theorem selectedBound40091 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10709,1024,32769,58516,62848,17,41430,8328,64,245139,115150,45524,190916,75222,120067,256,98814,90203,512]

theorem envBound40092 : H12AffineFastState.Bounded env40092 := by
  intro p hp
  have h : env40092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40091_40092 : H12AffineEnvironment.transform 21 62848 env40091 = env40092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62848 env40091 == env40092) = true)

theorem identity40092 : scanCanonicalize (H12AffineFastState.compose env40092 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound40092 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10709,1024,32769,58516,62848,17,41430,8328,64,130434,115150,45524,43477,75222,120067,256,98814,90203,512]

theorem envBound40093 : H12AffineFastState.Bounded env40093 := by
  intro p hp
  have h : env40093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40092_40093 : H12AffineEnvironment.transform 16 16401 env40092 = env40093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40092 == env40093) = true)

theorem identity40093 : scanCanonicalize (H12AffineFastState.compose env40093 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound40093 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env40094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16401,10709,1024,32769,58516,62848,17,41430,8328,64,10588,5392,45524,43477,61704,477,256,21792,46213,512]

theorem envBound40094 : H12AffineFastState.Bounded env40094 := by
  intro p hp
  have h : env40094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40093_40094 : H12AffineEnvironment.transform 15 54494 env40093 = env40094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env40093 == env40094) = true)

theorem identity40094 : scanCanonicalize (H12AffineFastState.compose env40094 (packedSelected [0,6,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound40094 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env40095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,32768,32938,5221,10709,1024,32769,45280,41460,17,41430,8328,64,10588,5392,45524,43477,42364,477,256,340,46213,512]

theorem envBound40095 : H12AffineFastState.Bounded env40095 := by
  intro p hp
  have h : env40095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40094_40095 : H12AffineEnvironment.transform 13 5236 env40094 = env40095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env40094 == env40095) = true)

theorem identity40095 : scanCanonicalize (H12AffineFastState.compose env40095 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound40095 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,261,431,5221,10709,1024,260,12773,8433,17,8403,8328,64,10588,5392,12497,10448,9337,477,256,340,13696,512]

theorem envBound40096 : H12AffineFastState.Bounded env40096 := by
  intro p hp
  have h : env40096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40095_40096 : H12AffineEnvironment.transform 14 261 env40095 = env40096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env40095 == env40096) = true)

theorem identity40096 : scanCanonicalize (H12AffineFastState.compose env40096 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound40096 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env40097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5236,261,431,5221,2161,1024,260,4161,341,17,375,300,64,2296,5392,4469,2420,1501,477,256,340,5156,512]

theorem envBound40097 : H12AffineFastState.Bounded env40097 := by
  intro p hp
  have h : env40097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40096_40097 : H12AffineEnvironment.transform 12 420 env40096 = env40097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env40096 == env40097) = true)

theorem identity40097 : scanCanonicalize (H12AffineFastState.compose env40097 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40097 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env40098 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,208,5236,113,219,5221,2161,1024,112,4161,33,17,3,88,64,2296,5220,4097,2048,1193,169,116,32,5156,512]

theorem envBound40098 : H12AffineFastState.Bounded env40098 := by
  intro p hp
  have h : env40098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40097_40098 : H12AffineEnvironment.transform 7 116 env40097 = env40098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40097 == env40098) = true)

theorem identity40098 : scanCanonicalize (H12AffineFastState.compose env40098 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound40098 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40099 : List Nat := [2,4,8,16,32,64,128,116,512,1024,81,4096,208,5236,113,219,5221,32,1024,112,4161,33,17,3,88,64,169,5220,4097,81,1193,169,116,32,5156,512]

theorem envBound40099 : H12AffineFastState.Bounded env40099 := by
  intro p hp
  have h : env40099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40098_40099 : H12AffineEnvironment.transform 10 81 env40098 = env40099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env40098 == env40099) = true)

theorem identity40099 : scanCanonicalize (H12AffineFastState.compose env40099 (packedSelected [0,1,2,5,7,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound40099 : packedSelected [0,1,2,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40100 : List Nat := [2,4,8,16,32,64,41,116,512,1024,81,4096,121,5236,113,114,5221,32,1024,112,4161,33,17,3,88,64,0,5220,4097,81,1024,0,116,32,5156,512]

theorem envBound40100 : H12AffineFastState.Bounded env40100 := by
  intro p hp
  have h : env40100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40099_40100 : H12AffineEnvironment.transform 6 41 env40099 = env40100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env40099 == env40100) = true)

theorem identity40100 : scanCanonicalize (H12AffineFastState.compose env40100 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40100 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env40101 : List Nat := [2,4,8,16,1,64,8,85,512,1024,81,4096,88,5205,80,83,5188,1,1024,81,4161,0,17,3,88,64,0,5189,4097,81,1024,0,85,1,5125,512]

theorem envBound40101 : H12AffineFastState.Bounded env40101 := by
  intro p hp
  have h : env40101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40100_40101 : H12AffineEnvironment.transform 4 1 env40100 = env40101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40100 == env40101) = true)

def env40102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,8388608,41430,8328,64,13066711,115151,8434116,8830976,8463815,4268162,256,8487406,8478795,8389137]

theorem envBound40102 : H12AffineFastState.Bounded env40102 := by
  intro p hp
  have h : env40102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40046_40102 : H12AffineEnvironment.transform 20 58517 env40046 = env40102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env40046 == env40102) = true)

def env40103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,16,41430,8328,64,4678087,115151,45524,442384,75223,4268162,256,98814,90203,513]

theorem envBound40103 : H12AffineFastState.Bounded env40103 := by
  intro p hp
  have h : env40103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40102_40103 : H12AffineEnvironment.transform 22 16 env40102 = env40103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40102 == env40103) = true)

theorem identity40103 : scanCanonicalize (H12AffineFastState.compose env40103 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40103 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58517,4194304,16,41430,8328,64,4604365,57797,45524,442384,1501,4194440,256,41460,16465,513]

theorem envBound40104 : H12AffineFastState.Bounded env40104 := by
  intro p hp
  have h : env40104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40103_40104 : H12AffineEnvironment.transform 15 8202 env40103 = env40104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40103 == env40104) = true)

theorem identity40104 : scanCanonicalize (H12AffineFastState.compose env40104 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound40104 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env40105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58517,419912,16,41430,8328,64,10629,57797,45524,442384,1501,420032,256,41460,16465,513]

theorem envBound40105 : H12AffineFastState.Bounded env40105 := by
  intro p hp
  have h : env40105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40104_40105 : H12AffineEnvironment.transform 21 419912 env40104 = env40105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env40104 == env40105) = true)

def env40106 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58397,419912,16,41310,8192,64,10509,57677,45404,442384,1365,419912,256,41340,16465,513]

theorem envBound40106 : H12AffineFastState.Bounded env40106 := by
  intro p hp
  have h : env40106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40105_40106 : H12AffineEnvironment.transform 6 8 env40105 = env40106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40105 == env40106) = true)

theorem identity40106 : scanCanonicalize (H12AffineFastState.compose env40106 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40106 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40107 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,262144,1024,8541,17729,419912,16,2,8192,64,10509,16401,4096,418124,1365,419912,256,32,16465,513]

theorem envBound40107 : H12AffineFastState.Bounded env40107 := by
  intro p hp
  have h : env40107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40106_40107 : H12AffineEnvironment.transform 14 8540 env40106 = env40107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40106 == env40107) = true)

theorem identity40107 : scanCanonicalize (H12AffineFastState.compose env40107 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound40107 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40108 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,157753,1024,8541,17729,113,16,2,8192,64,10509,16401,4096,2421,1365,113,256,32,16465,513]

theorem envBound40108 : H12AffineFastState.Bounded env40108 := by
  intro p hp
  have h : env40108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40107_40108 : H12AffineEnvironment.transform 17 157753 env40107 = env40108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env40107 == env40108) = true)

theorem identity40108 : scanCanonicalize (H12AffineFastState.compose env40108 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound40108 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,8202,131072,145448,1024,8541,5456,113,16,2,8192,64,10509,4096,4096,2421,1365,113,256,32,4160,513]

theorem envBound40109 : H12AffineFastState.Bounded env40109 := by
  intro p hp
  have h : env40109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40108_40109 : H12AffineEnvironment.transform 13 4113 env40108 = env40109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env40108 == env40109) = true)

theorem identity40109 : scanCanonicalize (H12AffineFastState.compose env40109 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound40109 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env40110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,8540,8202,4096,10280,1024,8541,5456,113,16,2,8192,64,10509,4096,4096,2421,1365,113,256,32,4160,513]

theorem envBound40110 : H12AffineFastState.Bounded env40110 := by
  intro p hp
  have h : env40110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40109_40110 : H12AffineEnvironment.transform 16 4096 env40109 = env40110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env40109 == env40110) = true)

theorem identity40110 : scanCanonicalize (H12AffineFastState.compose env40110 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound40110 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6429,4113,6209,6423,4096,4405,1024,6208,5456,113,16,2,6429,64,4112,4096,4096,2421,1365,113,256,32,4160,513]

theorem envBound40111 : H12AffineFastState.Bounded env40111 := by
  intro p hp
  have h : env40111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40110_40111 : H12AffineEnvironment.transform 12 6429 env40110 = env40111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env40110 == env40111) = true)

theorem identity40111 : scanCanonicalize (H12AffineFastState.compose env40111 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound40111 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env40112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,1337,3125,1125,1331,3108,3345,1024,1124,2420,113,16,2,1337,64,3124,3108,3108,2421,1365,113,256,32,3172,513]

theorem envBound40112 : H12AffineFastState.Bounded env40112 := by
  intro p hp
  have h : env40112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40111_40112 : H12AffineEnvironment.transform 11 3108 env40111 = env40112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env40111 == env40112) = true)

theorem identity40112 : scanCanonicalize (H12AffineFastState.compose env40112 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40112 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env40113 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2065,268,2048,80,262,2065,2340,53,81,2420,113,16,2,268,64,2049,2065,2065,2421,352,113,256,32,2129,513]

theorem envBound40113 : H12AffineFastState.Bounded env40113 := by
  intro p hp
  have h : env40113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40112_40113 : H12AffineEnvironment.transform 9 53 env40112 = env40113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40112 == env40113) = true)

theorem identity40113 : scanCanonicalize (H12AffineFastState.compose env40113 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40113 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env40114 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,2065,41,2048,80,35,2065,2049,53,81,2129,113,16,2,41,64,2049,2065,2065,2128,69,113,37,32,2129,513]

theorem envBound40114 : H12AffineFastState.Bounded env40114 := by
  intro p hp
  have h : env40114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40113_40114 : H12AffineEnvironment.transform 7 37 env40113 = env40114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40113 == env40114) = true)

theorem identity40114 : scanCanonicalize (H12AffineFastState.compose env40114 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound40114 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40115 : List Nat := [2,4,8,16,32,64,8,37,512,53,49,32,41,49,80,35,32,48,53,81,96,113,16,2,41,64,48,32,32,97,69,113,37,32,96,513]

theorem envBound40115 : H12AffineFastState.Bounded env40115 := by
  intro p hp
  have h : env40115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40114_40115 : H12AffineEnvironment.transform 10 49 env40114 = env40115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env40114 == env40115) = true)

theorem identity40115 : scanCanonicalize (H12AffineFastState.compose env40115 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40115 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40116 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,32,41,49,0,35,32,48,53,1,48,33,16,2,41,16,48,32,32,49,21,33,37,32,48,513]

theorem envBound40116 : H12AffineFastState.Bounded env40116 := by
  intro p hp
  have h : env40116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40115_40116 : H12AffineEnvironment.transform 5 16 env40115 = env40116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40115 == env40116) = true)

def leafEnv40116 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,32,41,49,0,35,32,48,53,1,48,33,16,2,21,41,1,16,48,32,32,49,21,33,37,32,4,35,48,513,1,49,0]

def active40116 : List Nat := [0,1,2,3,4,8]

def tree40116 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40116 : H12WitnessSearch.Good tree40116 := H12GlobalWitnessIndex.good

theorem leafIdentity40116 : H12AffineFastState.composeSystem env40116 rootObs = leafEnv40116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40116 rootObs == leafEnv40116) = true)

theorem terminalChecked40116 : H12PackedTerminal.terminalCheckFast leafEnv40116 active40116 tree40116 = true := by decide +kernel

def env40117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,58396,419912,16,41311,8193,64,10508,57676,45405,442384,1364,419913,256,41341,16465,513]

theorem envBound40117 : H12AffineFastState.Bounded env40117 := by
  intro p hp
  have h : env40117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40105_40117 : H12AffineEnvironment.transform 6 9 env40105 = env40117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40105 == env40117) = true)

def env40118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,262144,1024,32769,58396,272392,16,41311,8193,64,10508,57676,45405,294992,1364,272393,256,41341,16465,513]

theorem envBound40118 : H12AffineFastState.Bounded env40118 := by
  intro p hp
  have h : env40118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40117_40118 : H12AffineEnvironment.transform 16 16448 env40117 = env40118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env40117 == env40118) = true)

theorem identity40118 : scanCanonicalize (H12AffineFastState.compose env40118 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound40118 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16448,43129,1024,32769,58396,32881,16,41311,8193,64,10508,57676,45405,10281,1364,32880,256,41341,16465,513]

theorem envBound40119 : H12AffineFastState.Bounded env40119 := by
  intro p hp
  have h : env40119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40118_40119 : H12AffineEnvironment.transform 17 43129 env40118 = env40119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env40118 == env40119) = true)

theorem identity40119 : scanCanonicalize (H12AffineFastState.compose env40119 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound40119 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env40120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8202,16448,2420,1024,8460,17681,8572,16,82,8193,64,10508,16449,4176,10281,1364,8573,256,112,16465,513]

theorem envBound40120 : H12AffineFastState.Bounded env40120 := by
  intro p hp
  have h : env40120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40119_40120 : H12AffineEnvironment.transform 14 8461 env40119 = env40120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env40119 == env40120) = true)

def env40121 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,8202,16400,2340,1024,8460,17681,8492,16,2,8193,16,10508,16401,4096,10281,1284,8493,256,32,16385,513]

theorem envBound40121 : H12AffineFastState.Bounded env40121 := by
  intro p hp
  have h : env40121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40120_40121 : H12AffineEnvironment.transform 5 16 env40120 = env40121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40120 == env40121) = true)

theorem identity40121 : scanCanonicalize (H12AffineFastState.compose env40121 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound40121 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40122 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1,8192,16384,8461,8202,16400,2340,1024,8460,17681,8492,16,2,8193,16,10508,16401,1,10281,1284,8493,256,32,16385,513]

theorem envBound40122 : H12AffineFastState.Bounded env40122 := by
  intro p hp
  have h : env40122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40121_40122 : H12AffineEnvironment.transform 11 1 env40121 = env40122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env40121 == env40122) = true)

theorem identity40122 : scanCanonicalize (H12AffineFastState.compose env40122 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40122 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40123 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1,269,16384,0,263,16400,2340,1024,1,17681,33,16,2,268,16,2049,16401,1,2340,1284,32,256,32,16385,513]

theorem envBound40123 : H12AffineFastState.Bounded env40123 := by
  intro p hp
  have h : env40123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40122_40123 : H12AffineEnvironment.transform 12 269 env40122 = env40123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40122 == env40123) = true)

theorem identity40123 : scanCanonicalize (H12AffineFastState.compose env40123 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound40123 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40124 : List Nat := [2,4,8,16,32,16,9,256,512,1024,26,1,269,16384,0,263,16400,318,1024,1,17681,33,16,2,268,16,27,16401,1,318,1284,32,256,32,16385,513]

theorem envBound40124 : H12AffineFastState.Bounded env40124 := by
  intro p hp
  have h : env40124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40123_40124 : H12AffineEnvironment.transform 10 26 env40123 = env40124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env40123 == env40124) = true)

theorem identity40124 : scanCanonicalize (H12AffineFastState.compose env40124 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound40124 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40125 : List Nat := [2,4,8,16,32,16,9,256,512,20,26,1,269,16384,0,263,16400,318,20,1,16645,33,16,2,268,16,27,16401,1,318,272,32,256,32,16385,513]

theorem envBound40125 : H12AffineFastState.Bounded env40125 := by
  intro p hp
  have h : env40125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40124_40125 : H12AffineEnvironment.transform 9 20 env40124 = env40125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env40124 == env40125) = true)

theorem identity40125 : scanCanonicalize (H12AffineFastState.compose env40125 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40125 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40126 : List Nat := [2,4,8,0,32,0,9,256,512,4,10,1,269,16384,0,263,16384,302,4,1,16645,33,0,2,268,0,11,16385,1,302,256,32,256,32,16385,513]

theorem envBound40126 : H12AffineFastState.Bounded env40126 := by
  intro p hp
  have h : env40126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40125_40126 : H12AffineEnvironment.transform 3 0 env40125 = env40126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40125 == env40126) = true)

theorem identity40126 : scanCanonicalize (H12AffineFastState.compose env40126 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound40126 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40127 : List Nat := [2,4,8,0,32,0,9,14,512,4,10,1,3,16384,0,9,16384,32,4,1,16395,33,0,2,2,0,11,16385,1,32,14,32,14,32,16385,513]

theorem envBound40127 : H12AffineFastState.Bounded env40127 := by
  intro p hp
  have h : env40127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40126_40127 : H12AffineEnvironment.transform 7 14 env40126 = env40127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env40126 == env40127) = true)

theorem identity40127 : scanCanonicalize (H12AffineFastState.compose env40127 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40127 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40128 : List Nat := [2,4,8,0,0,0,9,14,512,4,10,1,3,16384,0,9,16384,0,4,1,16395,1,0,2,2,0,11,16385,1,0,14,0,14,0,16385,513]

theorem envBound40128 : H12AffineFastState.Bounded env40128 := by
  intro p hp
  have h : env40128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40127_40128 : H12AffineEnvironment.transform 4 0 env40127 = env40128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40127 == env40128) = true)

theorem identity40128 : scanCanonicalize (H12AffineFastState.compose env40128 (packedSelected [0,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40128 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env40129 : List Nat := [2,4,2,0,0,0,3,4,512,4,0,1,3,16384,0,3,16384,0,4,1,16385,1,0,2,2,0,1,16385,1,0,4,0,4,0,16385,513]

theorem envBound40129 : H12AffineFastState.Bounded env40129 := by
  intro p hp
  have h : env40129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40128_40129 : H12AffineEnvironment.transform 2 2 env40128 = env40129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40128 == env40129) = true)

theorem identity40129 : scanCanonicalize (H12AffineFastState.compose env40129 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40129 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40130 : List Nat := [2,0,2,0,0,0,3,0,512,0,0,1,3,16384,0,3,16384,0,0,1,16385,1,0,2,2,0,1,16385,1,0,0,0,0,0,16385,513]

theorem envBound40130 : H12AffineFastState.Bounded env40130 := by
  intro p hp
  have h : env40130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40129_40130 : H12AffineEnvironment.transform 1 0 env40129 = env40130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40129 == env40130) = true)

theorem identity40130 : scanCanonicalize (H12AffineFastState.compose env40130 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2) := by decide +kernel

theorem selectedBound40130 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40131 : List Nat := [2,0,2,0,0,0,3,0,512,0,0,1,3,2,0,3,2,0,0,1,3,1,0,2,2,0,1,3,1,0,0,0,0,0,3,513]

theorem envBound40131 : H12AffineFastState.Bounded env40131 := by
  intro p hp
  have h : env40131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40130_40131 : H12AffineEnvironment.transform 13 2 env40130 = env40131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2 env40130 == env40131) = true)

def env40132 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8202,16401,2341,1024,8460,17681,8493,16,3,8193,17,10508,16400,4097,10281,1285,8492,256,33,16384,513]

theorem envBound40132 : H12AffineFastState.Bounded env40132 := by
  intro p hp
  have h : env40132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40120_40132 : H12AffineEnvironment.transform 5 17 env40120 = env40132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40120 == env40132) = true)

theorem identity40132 : scanCanonicalize (H12AffineFastState.compose env40132 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound40132 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40133 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5156,8461,8202,5173,2341,1024,8460,4405,8493,16,3,8193,17,10508,5172,4097,10281,1285,8492,256,33,5156,513]

theorem envBound40133 : H12AffineFastState.Bounded env40133 := by
  intro p hp
  have h : env40133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40132_40133 : H12AffineEnvironment.transform 13 5156 env40132 = env40133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env40132 == env40133) = true)

theorem identity40133 : scanCanonicalize (H12AffineFastState.compose env40133 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40133 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40134 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5156,1,262,5173,2341,1024,0,4405,33,16,3,269,17,2048,5172,4097,2341,1285,32,256,33,5156,513]

theorem envBound40134 : H12AffineFastState.Bounded env40134 := by
  intro p hp
  have h : env40134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40133_40134 : H12AffineEnvironment.transform 12 268 env40133 = env40134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40133 == env40134) = true)

def env40135 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,268,2836,1,262,2821,2341,1024,0,3589,33,16,3,269,17,2048,2820,3889,2341,1285,32,256,33,2836,513]

theorem envBound40135 : H12AffineFastState.Bounded env40135 := by
  intro p hp
  have h : env40135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40134_40135 : H12AffineEnvironment.transform 11 3888 env40134 = env40135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env40134 == env40135) = true)

def env40136 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,268,1044,1,262,1029,1573,1024,0,261,33,16,3,269,17,1792,1028,49,1573,1285,32,256,33,1044,513]

theorem envBound40136 : H12AffineFastState.Bounded env40136 := by
  intro p hp
  have h : env40136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40135_40136 : H12AffineEnvironment.transform 10 1792 env40135 = env40136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env40135 == env40136) = true)

theorem identity40136 : scanCanonicalize (H12AffineFastState.compose env40136 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40136 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40137 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,48,40,1044,1,34,1029,1573,1024,0,33,33,16,3,41,17,1572,1028,49,1573,1057,32,36,33,1044,513]

theorem envBound40137 : H12AffineFastState.Bounded env40137 := by
  intro p hp
  have h : env40137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40136_40137 : H12AffineEnvironment.transform 7 36 env40136 = env40137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40136 == env40137) = true)

def env40138 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,40,32,1,34,49,529,52,0,33,33,16,3,41,17,528,48,49,529,21,32,36,33,32,513]

theorem envBound40138 : H12AffineFastState.Bounded env40138 := by
  intro p hp
  have h : env40138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40137_40138 : H12AffineEnvironment.transform 9 52 env40137 = env40138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40137 == env40138) = true)

theorem identity40138 : scanCanonicalize (H12AffineFastState.compose env40138 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound40138 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40139 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,48,40,32,1,34,49,58,52,0,33,33,16,3,41,17,59,48,49,58,21,32,36,33,32,42]

theorem envBound40139 : H12AffineFastState.Bounded env40139 := by
  intro p hp
  have h : env40139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40138_40139 : H12AffineEnvironment.transform 8 43 env40138 = env40139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env40138 == env40139) = true)

def leafEnv40139 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,48,40,32,1,34,49,58,52,0,33,33,16,3,21,41,1,17,59,48,49,58,21,32,36,33,4,35,32,42,1,33,0]

def active40139 : List Nat := [0,1,2,3,4]

def tree40139 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40139 : H12WitnessSearch.Good tree40139 := H12GlobalWitnessIndex.good

theorem leafIdentity40139 : H12AffineFastState.composeSystem env40139 rootObs = leafEnv40139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40139 rootObs == leafEnv40139) = true)

theorem terminalChecked40139 : H12PackedTerminal.terminalCheckFast leafEnv40139 active40139 tree40139 = true := by decide +kernel

def env40140 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,40,33,1,34,48,528,53,0,33,33,16,3,41,17,529,49,49,528,20,32,36,33,33,513]

theorem envBound40140 : H12AffineFastState.Bounded env40140 := by
  intro p hp
  have h : env40140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40137_40140 : H12AffineEnvironment.transform 9 53 env40137 = env40140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40137 == env40140) = true)

def env40141 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,268,1045,1,262,1028,1572,1024,0,260,33,16,3,269,17,1793,1029,48,1572,1285,32,256,33,1045,513]

theorem envBound40141 : H12AffineFastState.Bounded env40141 := by
  intro p hp
  have h : env40141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40135_40141 : H12AffineEnvironment.transform 10 1793 env40135 = env40141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env40135 == env40141) = true)

theorem identity40141 : scanCanonicalize (H12AffineFastState.compose env40141 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40142 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,49,268,33,1,262,48,528,52,0,260,33,16,3,269,17,821,49,48,528,305,32,256,33,33,513]

theorem envBound40142 : H12AffineFastState.Bounded env40142 := by
  intro p hp
  have h : env40142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40141_40142 : H12AffineEnvironment.transform 9 52 env40141 = env40142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40141 == env40142) = true)

theorem identity40142 : scanCanonicalize (H12AffineFastState.compose env40142 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound40142 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40143 : List Nat := [2,4,8,16,32,17,9,256,270,52,59,49,268,33,1,262,48,286,52,0,260,33,16,3,269,17,59,49,48,286,305,32,256,33,33,271]

theorem envBound40143 : H12AffineFastState.Bounded env40143 := by
  intro p hp
  have h : env40143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40142_40143 : H12AffineEnvironment.transform 8 270 env40142 = env40143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env40142 == env40143) = true)

def leafEnv40143 : List Nat := [2,4,8,16,32,17,9,256,270,52,59,49,268,33,1,262,48,286,52,0,260,33,16,3,305,269,1,17,59,49,48,286,305,32,256,33,4,263,33,271,1,260,0]

def active40143 : List Nat := [0,1,2,3,4,7]

def tree40143 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40143 : H12WitnessSearch.Good tree40143 := H12GlobalWitnessIndex.good

theorem leafIdentity40143 : H12AffineFastState.composeSystem env40143 rootObs = leafEnv40143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40143 rootObs == leafEnv40143) = true)

theorem terminalChecked40143 : H12PackedTerminal.terminalCheckFast leafEnv40143 active40143 tree40143 = true := by decide +kernel

def env40144 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,268,2837,1,262,2820,2341,1024,0,3588,33,16,3,269,17,2048,2821,3888,2341,1285,32,256,33,2837,513]

theorem envBound40144 : H12AffineFastState.Bounded env40144 := by
  intro p hp
  have h : env40144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40134_40144 : H12AffineEnvironment.transform 11 3889 env40134 = env40144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env40134 == env40144) = true)

def env40145 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,268,1045,1,262,1028,1573,1024,0,260,33,16,3,269,17,1792,1029,48,1573,1285,32,256,33,1045,513]

theorem envBound40145 : H12AffineFastState.Bounded env40145 := by
  intro p hp
  have h : env40145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40144_40145 : H12AffineEnvironment.transform 10 1792 env40144 = env40145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env40144 == env40145) = true)

theorem identity40145 : scanCanonicalize (H12AffineFastState.compose env40145 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40146 : List Nat := [2,4,8,16,32,17,9,256,512,272,528,49,268,261,1,262,276,821,272,0,260,33,16,3,269,17,528,277,48,821,21,32,256,33,261,513]

theorem envBound40146 : H12AffineFastState.Bounded env40146 := by
  intro p hp
  have h : env40146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40145_40146 : H12AffineEnvironment.transform 9 272 env40145 = env40146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40145 == env40146) = true)

def env40147 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,40,33,1,34,48,529,52,0,32,33,16,3,41,17,528,49,48,529,21,32,36,33,33,513]

theorem envBound40147 : H12AffineFastState.Bounded env40147 := by
  intro p hp
  have h : env40147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40146_40147 : H12AffineEnvironment.transform 7 36 env40146 = env40147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40146 == env40147) = true)

theorem identity40147 : scanCanonicalize (H12AffineFastState.compose env40147 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound40147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40148 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,49,40,33,1,34,48,59,52,0,32,33,16,3,41,17,58,49,48,59,21,32,36,33,33,43]

theorem envBound40148 : H12AffineFastState.Bounded env40148 := by
  intro p hp
  have h : env40148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40147_40148 : H12AffineEnvironment.transform 8 42 env40147 = env40148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env40147 == env40148) = true)

def leafEnv40148 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,49,40,33,1,34,48,59,52,0,32,33,16,3,21,41,1,17,58,49,48,59,21,32,36,33,4,35,33,43,1,32,0]

def active40148 : List Nat := [0,1,2,3,4]

def tree40148 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40148 : H12WitnessSearch.Good tree40148 := H12GlobalWitnessIndex.good

theorem leafIdentity40148 : H12AffineFastState.composeSystem env40148 rootObs = leafEnv40148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40148 rootObs == leafEnv40148) = true)

theorem terminalChecked40148 : H12PackedTerminal.terminalCheckFast leafEnv40148 active40148 tree40148 = true := by decide +kernel

def env40149 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,49,41,32,1,35,49,528,53,0,33,33,16,3,40,17,528,48,48,528,21,32,37,33,32,513]

theorem envBound40149 : H12AffineFastState.Bounded env40149 := by
  intro p hp
  have h : env40149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40146_40149 : H12AffineEnvironment.transform 7 37 env40146 = env40149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40146 == env40149) = true)

def env40150 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,268,1044,1,262,1029,1572,1024,0,261,33,16,3,269,17,1793,1028,49,1572,1285,32,256,33,1044,513]

theorem envBound40150 : H12AffineFastState.Bounded env40150 := by
  intro p hp
  have h : env40150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40144_40150 : H12AffineEnvironment.transform 10 1793 env40144 = env40150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env40144 == env40150) = true)

def env40151 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,48,268,32,1,262,49,528,52,0,261,33,16,3,269,17,821,48,49,528,305,32,256,33,32,513]

theorem envBound40151 : H12AffineFastState.Bounded env40151 := by
  intro p hp
  have h : env40151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40150_40151 : H12AffineEnvironment.transform 9 52 env40150 = env40151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40150 == env40151) = true)

theorem identity40151 : scanCanonicalize (H12AffineFastState.compose env40151 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound40151 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40152 : List Nat := [2,4,8,16,32,17,9,256,271,52,58,48,268,32,1,262,49,287,52,0,261,33,16,3,269,17,58,48,49,287,305,32,256,33,32,270]

theorem envBound40152 : H12AffineFastState.Bounded env40152 := by
  intro p hp
  have h : env40152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40151_40152 : H12AffineEnvironment.transform 8 271 env40151 = env40152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env40151 == env40152) = true)

def leafEnv40152 : List Nat := [2,4,8,16,32,17,9,256,271,52,58,48,268,32,1,262,49,287,52,0,261,33,16,3,305,269,1,17,58,48,49,287,305,32,256,33,4,263,32,270,1,261,0]

def active40152 : List Nat := [0,1,2,3,4,7]

def tree40152 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40152 : H12WitnessSearch.Good tree40152 := H12GlobalWitnessIndex.good

theorem leafIdentity40152 : H12AffineFastState.composeSystem env40152 rootObs = leafEnv40152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40152 rootObs == leafEnv40152) = true)

theorem terminalChecked40152 : H12PackedTerminal.terminalCheckFast leafEnv40152 active40152 tree40152 = true := by decide +kernel

def env40153 : List Nat := [2,4,8,16,32,17,9,256,512,53,820,48,268,33,1,262,48,529,53,0,261,33,16,3,269,17,820,49,49,529,304,32,256,33,33,513]

theorem envBound40153 : H12AffineFastState.Bounded env40153 := by
  intro p hp
  have h : env40153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40150_40153 : H12AffineEnvironment.transform 9 53 env40150 = env40153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40150 == env40153) = true)

def env40154 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,262144,1024,32769,58396,272393,16,41311,8193,64,10508,57676,45405,294993,1364,272392,256,41341,16465,513]

theorem envBound40154 : H12AffineFastState.Bounded env40154 := by
  intro p hp
  have h : env40154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40117_40154 : H12AffineEnvironment.transform 16 16449 env40117 = env40154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env40117 == env40154) = true)

theorem identity40154 : scanCanonicalize (H12AffineFastState.compose env40154 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound40154 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40155 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16449,35188,1024,32769,58396,41341,16,41311,8193,64,10508,57676,45405,2341,1364,41340,256,41341,16465,513]

theorem envBound40155 : H12AffineFastState.Bounded env40155 := by
  intro p hp
  have h : env40155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40154_40155 : H12AffineEnvironment.transform 17 35188 env40154 = env40155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env40154 == env40155) = true)

theorem identity40155 : scanCanonicalize (H12AffineFastState.compose env40155 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40155 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env40156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,343,16449,35188,1024,32769,50497,32800,16,32770,348,64,2129,49169,36864,2341,1364,32801,256,32800,16465,513]

theorem envBound40156 : H12AffineFastState.Bounded env40156 := by
  intro p hp
  have h : env40156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40155_40156 : H12AffineEnvironment.transform 12 349 env40155 = env40156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40155 == env40156) = true)

theorem identity40156 : scanCanonicalize (H12AffineFastState.compose env40156 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40156 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,343,16449,2420,1024,1,17729,32,16,2,348,64,2129,16401,4096,2341,1364,33,256,32,16465,513]

theorem envBound40157 : H12AffineFastState.Bounded env40157 := by
  intro p hp
  have h : env40157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40156_40157 : H12AffineEnvironment.transform 14 0 env40156 = env40157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40156 == env40157) = true)

theorem identity40157 : scanCanonicalize (H12AffineFastState.compose env40157 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound40157 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env40158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,0,343,4176,2420,1024,1,5456,32,16,2,348,64,2129,4096,4096,2341,1364,33,256,32,4160,513]

theorem envBound40158 : H12AffineFastState.Bounded env40158 := by
  intro p hp
  have h : env40158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40157_40158 : H12AffineEnvironment.transform 13 4113 env40157 = env40158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env40157 == env40158) = true)

theorem identity40158 : scanCanonicalize (H12AffineFastState.compose env40158 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40158 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40159 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,4113,0,263,4096,2340,1024,1,5376,32,16,2,268,16,2049,4096,4096,2341,1284,33,256,32,4112,513]

theorem envBound40159 : H12AffineFastState.Bounded env40159 := by
  intro p hp
  have h : env40159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40158_40159 : H12AffineEnvironment.transform 5 16 env40158 = env40159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40158 == env40159) = true)

theorem identity40159 : scanCanonicalize (H12AffineFastState.compose env40159 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound40159 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40160 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,4113,0,2,4096,2081,1024,1,5125,32,16,2,9,16,2049,4096,4096,2080,1025,33,5,32,4112,513]

theorem envBound40160 : H12AffineFastState.Bounded env40160 := by
  intro p hp
  have h : env40160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40159_40160 : H12AffineEnvironment.transform 7 5 env40159 = env40160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env40159 == env40160) = true)

theorem identity40160 : scanCanonicalize (H12AffineFastState.compose env40160 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3620) := by decide +kernel

theorem selectedBound40160 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40161 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,3620,8,3637,0,2,3620,2081,1024,1,2593,32,16,2,9,16,2049,3620,3620,2080,1025,33,5,32,3636,513]

theorem envBound40161 : H12AffineFastState.Bounded env40161 := by
  intro p hp
  have h : env40161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40160_40161 : H12AffineEnvironment.transform 11 3620 env40160 = env40161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3620 env40160 == env40161) = true)

theorem identity40161 : scanCanonicalize (H12AffineFastState.compose env40161 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound40161 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40162 : List Nat := [2,4,8,16,32,16,9,5,512,1024,17,1589,8,1572,0,2,1589,48,1024,1,560,32,16,2,9,16,16,1589,1589,49,1025,33,5,32,1573,513]

theorem envBound40162 : H12AffineFastState.Bounded env40162 := by
  intro p hp
  have h : env40162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40161_40162 : H12AffineEnvironment.transform 10 17 env40161 = env40162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env40161 == env40162) = true)

theorem identity40162 : scanCanonicalize (H12AffineFastState.compose env40162 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40162 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40163 : List Nat := [2,4,8,16,32,16,9,5,512,52,17,513,8,528,0,2,513,48,52,1,560,32,16,2,9,16,16,513,513,49,53,33,5,32,529,513]

theorem envBound40163 : H12AffineFastState.Bounded env40163 := by
  intro p hp
  have h : env40163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40162_40163 : H12AffineEnvironment.transform 9 52 env40162 = env40163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40162 == env40163) = true)

theorem identity40163 : scanCanonicalize (H12AffineFastState.compose env40163 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound40163 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40164 : List Nat := [2,4,8,16,32,16,9,5,16,52,17,17,8,0,0,2,17,48,52,1,32,32,16,2,9,16,16,17,17,49,53,33,5,32,1,17]

theorem envBound40164 : H12AffineFastState.Bounded env40164 := by
  intro p hp
  have h : env40164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40163_40164 : H12AffineEnvironment.transform 8 16 env40163 = env40164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env40163 == env40164) = true)

def env40165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58517,4194304,17,41430,8328,64,4678086,115151,45525,442385,75222,4268162,256,98815,90202,512]

theorem envBound40165 : H12AffineFastState.Bounded env40165 := by
  intro p hp
  have h : env40165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40102_40165 : H12AffineEnvironment.transform 22 17 env40102 = env40165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env40102 == env40165) = true)

theorem identity40165 : scanCanonicalize (H12AffineFastState.compose env40165 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10708) := by decide +kernel

theorem selectedBound40165 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10708,1024,32769,58517,4194304,17,41430,8328,64,4409362,115151,45525,190917,75222,4268162,256,98815,90202,512]

theorem envBound40166 : H12AffineFastState.Bounded env40166 := by
  intro p hp
  have h : env40166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40165_40166 : H12AffineEnvironment.transform 17 10708 env40165 = env40166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10708 env40165 == env40166) = true)

theorem identity40166 : scanCanonicalize (H12AffineFastState.compose env40166 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 120202) := by decide +kernel

theorem selectedBound40166 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10708,1024,32769,58517,120202,17,41430,8328,64,171416,115151,45525,190917,75222,62728,256,98815,90202,512]

theorem envBound40167 : H12AffineFastState.Bounded env40167 := by
  intro p hp
  have h : env40167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40166_40167 : H12AffineEnvironment.transform 21 120202 env40166 = env40167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 120202 env40166 == env40167) = true)

theorem identity40167 : scanCanonicalize (H12AffineFastState.compose env40167 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound40167 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10708,1024,32769,58517,120202,17,41430,8328,64,56713,115151,45525,43476,75222,62728,256,98815,90202,512]

theorem envBound40168 : H12AffineFastState.Bounded env40168 := by
  intro p hp
  have h : env40168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40167_40168 : H12AffineEnvironment.transform 16 16401 env40167 = env40168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40167 == env40168) = true)

theorem identity40168 : scanCanonicalize (H12AffineFastState.compose env40168 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound40168 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env40169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,16401,10708,1024,29908,4160,74079,17,21763,8328,64,10588,79130,17664,23809,75222,477,256,95530,90202,512]

theorem envBound40169 : H12AffineFastState.Bounded env40169 := by
  intro p hp
  have h : env40169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40168_40169 : H12AffineEnvironment.transform 14 29909 env40168 = env40169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env40168 == env40169) = true)

theorem identity40169 : scanCanonicalize (H12AffineFastState.compose env40169 (packedSelected [1,2,3,5,8,10,14,19,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40169 : packedSelected [1,2,3,5,8,10,14,19,23,32] rootPS < 2^1333 := by decide +kernel

def env40170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,16401,10589,1024,29789,4160,74079,17,21763,8193,64,10588,79130,17664,23809,75103,340,256,95530,90202,512]

theorem envBound40170 : H12AffineFastState.Bounded env40170 := by
  intro p hp
  have h : env40170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40169_40170 : H12AffineEnvironment.transform 6 9 env40169 = env40170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40169 == env40170) = true)

theorem identity40170 : scanCanonicalize (H12AffineFastState.compose env40170 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound40170 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40171 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29788,65536,16401,10281,1024,29789,4160,73771,17,21623,8193,64,10280,78958,17524,23669,74795,32,116,95326,90202,512]

theorem envBound40171 : H12AffineFastState.Bounded env40171 := by
  intro p hp
  have h : env40171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40170_40171 : H12AffineEnvironment.transform 7 116 env40170 = env40171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40170 == env40171) = true)

theorem identity40171 : scanCanonicalize (H12AffineFastState.compose env40171 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 21543) := by decide +kernel

theorem selectedBound40171 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40172 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29788,21543,16401,10281,1024,29789,4160,29708,17,21623,8193,64,10280,24649,17524,23669,28684,32,116,8313,13437,512]

theorem envBound40172 : H12AffineFastState.Bounded env40172 := by
  intro p hp
  have h : env40172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40171_40172 : H12AffineEnvironment.transform 15 21543 env40171 = env40172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21543 env40171 == env40172) = true)

theorem identity40172 : scanCanonicalize (H12AffineFastState.compose env40172 (packedSelected [1,2,8,10,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 6209) := by decide +kernel

theorem selectedBound40172 : packedSelected [1,2,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env40173 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,6209,11293,3174,6224,10281,1024,11292,4160,11341,17,3126,8193,64,10280,14344,7221,1076,10317,32,116,8313,13437,512]

theorem envBound40173 : H12AffineFastState.Bounded env40173 := by
  intro p hp
  have h : env40173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40172_40173 : H12AffineEnvironment.transform 13 6209 env40172 = env40173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6209 env40172 == env40173) = true)

theorem identity40173 : scanCanonicalize (H12AffineFastState.compose env40173 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1133) := by decide +kernel

theorem selectedBound40173 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env40174 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1133,6209,2160,3174,6224,3140,1024,2161,4160,2080,17,3126,1132,64,3141,7269,7221,1076,3104,32,116,1044,4112,512]

theorem envBound40174 : H12AffineFastState.Bounded env40174 := by
  intro p hp
  have h : env40174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40173_40174 : H12AffineEnvironment.transform 12 1133 env40173 = env40174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1133 env40173 == env40174) = true)

theorem identity40174 : scanCanonicalize (H12AffineFastState.compose env40174 (packedSelected [1,8,10,11,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40174 : packedSelected [1,8,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env40175 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,4096,89,6209,2160,2130,6224,2160,52,2161,4160,2080,17,2050,88,64,2161,6225,6145,0,2068,32,116,32,4112,512]

theorem envBound40175 : H12AffineFastState.Bounded env40175 := by
  intro p hp
  have h : env40175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40174_40175 : H12AffineEnvironment.transform 9 52 env40174 = env40175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40174 == env40175) = true)

theorem identity40175 : scanCanonicalize (H12AffineFastState.compose env40175 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40175 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env40176 : List Nat := [2,4,8,16,0,64,9,84,512,20,2048,4096,89,6209,2128,2130,6224,2128,20,2129,4160,2048,17,2050,88,64,2129,6225,6145,0,2068,0,84,0,4112,512]

theorem envBound40176 : H12AffineFastState.Bounded env40176 := by
  intro p hp
  have h : env40176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40175_40176 : H12AffineEnvironment.transform 4 0 env40175 = env40176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40175 == env40176) = true)

theorem identity40176 : scanCanonicalize (H12AffineFastState.compose env40176 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound40176 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env40177 : List Nat := [2,4,8,16,0,64,9,84,512,20,2048,2113,89,0,2128,2130,17,2128,20,2129,2049,2048,17,2050,88,64,2129,16,64,0,2068,0,84,0,2129,512]

theorem envBound40177 : H12AffineFastState.Bounded env40177 := by
  intro p hp
  have h : env40177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40176_40177 : H12AffineEnvironment.transform 11 2113 env40176 = env40177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env40176 == env40177) = true)

theorem identity40177 : scanCanonicalize (H12AffineFastState.compose env40177 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound40177 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env40178 : List Nat := [2,4,8,16,0,64,9,84,512,20,81,16,89,0,1,3,17,1,20,0,80,81,17,83,88,64,0,16,64,0,69,0,84,0,0,512]

theorem envBound40178 : H12AffineFastState.Bounded env40178 := by
  intro p hp
  have h : env40178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40177_40178 : H12AffineEnvironment.transform 10 81 env40177 = env40178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env40177 == env40178) = true)

def env40179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265169,23160257,257,27378860,27337992,25207750]

theorem envBound40179 : H12AffineFastState.Bounded env40179 := by
  intro p hp
  have h : env40179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40044_40179 : H12AffineEnvironment.transform 18 1025 env40044 = env40179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env40044 == env40179) = true)

theorem identity40179 : scanCanonicalize (H12AffineFastState.compose env40179 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 213334) := by decide +kernel

theorem selectedBound40179 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,213334,16777216,8328,64,21266774,18973837,2298887,360791,16958791,23160257,257,19039738,19031134,17031824]

theorem envBound40180 : H12AffineFastState.Bounded env40180 := by
  intro p hp
  have h : env40180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40179_40180 : H12AffineEnvironment.transform 22 213334 env40179 = env40180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 213334 env40179 == env40180) = true)

def env40181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,412108,213334,16777216,8328,64,16959642,18973837,2298887,360791,16958791,19344397,257,19039738,19031134,17031824]

theorem envBound40181 : H12AffineFastState.Bounded env40181 := by
  intro p hp
  have h : env40181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40180_40181 : H12AffineEnvironment.transform 21 412108 env40180 = env40181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 412108 env40180 == env40181) = true)

def env40182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412108,213334,16777216,8328,64,16959642,16974165,102879,360791,16958791,17148373,257,16777250,16834950,17031824]

theorem envBound40182 : H12AffineFastState.Bounded env40182 := by
  intro p hp
  have h : env40182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40181_40182 : H12AffineEnvironment.transform 20 165336 env40181 = env40182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env40181 == env40182) = true)

theorem identity40182 : scanCanonicalize (H12AffineFastState.compose env40182 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound40182 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env40183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115871,329867,17,16777216,8328,64,16878045,16793618,102879,360791,16876544,17148373,257,16777250,16834950,16819159]

theorem envBound40183 : H12AffineFastState.Bounded env40183 := by
  intro p hp
  have h : env40183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40182_40183 : H12AffineEnvironment.transform 16 82247 env40182 = env40183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env40182 == env40183) = true)

def env40184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115871,329867,17,95496,8328,64,64725,79130,102879,360791,61704,318685,257,95530,103566,120543]

theorem envBound40184 : H12AffineFastState.Bounded env40184 := by
  intro p hp
  have h : env40184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40183_40184 : H12AffineEnvironment.transform 23 95496 env40183 = env40184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env40183 == env40184) = true)

theorem identity40184 : scanCanonicalize (H12AffineFastState.compose env40184 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound40184 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38297,262144,1025,32769,4161,318549,17,41430,8328,64,64725,57796,17665,284041,61704,318685,257,41460,16464,513]

theorem envBound40185 : H12AffineFastState.Bounded env40185 := by
  intro p hp
  have h : env40185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40184_40185 : H12AffineEnvironment.transform 15 54494 env40184 = env40185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env40184 == env40185) = true)

def env40186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,262144,1025,32769,4161,318549,17,41310,8192,64,64605,57676,17665,283905,61704,318549,257,41340,16464,513]

theorem envBound40186 : H12AffineFastState.Bounded env40186 := by
  intro p hp
  have h : env40186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40185_40186 : H12AffineEnvironment.transform 6 8 env40185 = env40186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40185 == env40186) = true)

theorem identity40186 : scanCanonicalize (H12AffineFastState.compose env40186 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40186 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10281,1025,32769,4161,62588,17,41310,8192,64,64605,57676,17665,32040,61704,62588,257,41340,16464,513]

theorem envBound40187 : H12AffineFastState.Bounded env40187 := by
  intro p hp
  have h : env40187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40186_40187 : H12AffineEnvironment.transform 17 10281 env40186 = env40187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40186 == env40187) = true)

theorem identity40187 : scanCanonicalize (H12AffineFastState.compose env40187 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40187 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env40188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,38161,10281,1025,32769,4161,41340,17,41310,8192,64,43357,46156,4097,10280,41992,41340,257,41340,5456,513]

theorem envBound40188 : H12AffineFastState.Bounded env40188 := by
  intro p hp
  have h : env40188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40187_40188 : H12AffineEnvironment.transform 13 5376 env40187 = env40188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40187 == env40188) = true)

theorem identity40188 : scanCanonicalize (H12AffineFastState.compose env40188 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40188 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,32768,33110,38161,2049,1025,32769,4161,33108,17,33142,40,64,35189,37988,4097,2048,33824,33108,257,33108,5456,513]

theorem envBound40189 : H12AffineFastState.Bounded env40189 := by
  intro p hp
  have h : env40189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40188_40189 : H12AffineEnvironment.transform 12 40 env40188 = env40189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40188 == env40189) = true)

theorem identity40189 : scanCanonicalize (H12AffineFastState.compose env40189 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound40189 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,80,262,5441,2049,1025,81,4161,260,17,294,40,64,2341,5172,4097,2048,1136,260,257,260,5456,513]

theorem envBound40190 : H12AffineFastState.Bounded env40190 := by
  intro p hp
  have h : env40190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40189_40190 : H12AffineEnvironment.transform 14 80 env40189 = env40190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env40189 == env40190) = true)

theorem identity40190 : scanCanonicalize (H12AffineFastState.compose env40190 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40190 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env40191 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,5156,80,34,5221,2049,1025,81,4161,32,17,2,40,64,2049,5172,4097,2048,1136,32,37,32,5236,513]

theorem envBound40191 : H12AffineFastState.Bounded env40191 := by
  intro p hp
  have h : env40191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40190_40191 : H12AffineEnvironment.transform 7 36 env40190 = env40191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40190 == env40191) = true)

theorem identity40191 : scanCanonicalize (H12AffineFastState.compose env40191 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound40191 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env40192 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,40,81,80,34,16,2049,1025,81,1076,32,17,2,40,64,2049,65,1140,2048,1136,32,37,32,1,513]

theorem envBound40192 : H12AffineFastState.Bounded env40192 := by
  intro p hp
  have h : env40192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40191_40192 : H12AffineEnvironment.transform 11 1141 env40191 = env40192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env40191 == env40192) = true)

theorem identity40192 : scanCanonicalize (H12AffineFastState.compose env40192 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40192 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40193 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1060,40,0,1,34,16,2049,1025,0,1076,32,17,2,40,17,2049,16,1061,2048,1057,32,37,32,1,513]

theorem envBound40193 : H12AffineFastState.Bounded env40193 := by
  intro p hp
  have h : env40193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40192_40193 : H12AffineEnvironment.transform 5 17 env40192 = env40193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40192 == env40193) = true)

theorem identity40193 : scanCanonicalize (H12AffineFastState.compose env40193 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound40193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40194 : List Nat := [2,4,8,16,32,17,8,36,512,36,2048,0,40,0,1,34,16,2049,37,0,16,32,17,2,40,17,2049,16,1,2048,5,32,37,32,1,513]

theorem envBound40194 : H12AffineFastState.Bounded env40194 := by
  intro p hp
  have h : env40194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40193_40194 : H12AffineEnvironment.transform 9 36 env40193 = env40194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env40193 == env40194) = true)

theorem identity40194 : scanCanonicalize (H12AffineFastState.compose env40194 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound40194 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40195 : List Nat := [2,4,8,16,32,17,8,36,512,36,11,0,40,0,1,34,16,10,37,0,16,32,17,2,40,17,10,16,1,11,5,32,37,32,1,513]

theorem envBound40195 : H12AffineFastState.Bounded env40195 := by
  intro p hp
  have h : env40195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40194_40195 : H12AffineEnvironment.transform 10 11 env40194 = env40195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env40194 == env40195) = true)

theorem identity40195 : scanCanonicalize (H12AffineFastState.compose env40195 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound40195 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40196 : List Nat := [2,4,8,16,26,17,8,30,512,30,11,0,18,0,1,24,16,10,31,0,16,26,17,2,18,17,10,16,1,11,5,26,31,26,1,513]

theorem envBound40196 : H12AffineFastState.Bounded env40196 := by
  intro p hp
  have h : env40196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40195_40196 : H12AffineEnvironment.transform 4 26 env40195 = env40196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env40195 == env40196) = true)

theorem identity40196 : scanCanonicalize (H12AffineFastState.compose env40196 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40196 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40197 : List Nat := [2,4,8,11,1,10,8,5,512,5,11,0,9,0,1,3,11,10,4,0,11,1,10,2,9,10,10,11,1,11,5,1,4,1,1,513]

theorem envBound40197 : H12AffineFastState.Bounded env40197 := by
  intro p hp
  have h : env40197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40196_40197 : H12AffineEnvironment.transform 3 11 env40196 = env40197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40196 == env40197) = true)

theorem identity40197 : scanCanonicalize (H12AffineFastState.compose env40197 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound40197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40198 : List Nat := [2,4,6,5,1,4,6,5,512,5,5,0,7,0,1,3,5,4,4,0,5,1,4,2,7,4,4,5,1,5,5,1,4,1,1,513]

theorem envBound40198 : H12AffineFastState.Bounded env40198 := by
  intro p hp
  have h : env40198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40197_40198 : H12AffineEnvironment.transform 2 6 env40197 = env40198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env40197 == env40198) = true)

def env40199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,4161,318549,17,41311,8193,64,64604,57677,17665,283904,61704,318548,257,41341,16464,513]

theorem envBound40199 : H12AffineFastState.Bounded env40199 := by
  intro p hp
  have h : env40199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40185_40199 : H12AffineEnvironment.transform 6 9 env40185 = env40199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40185 == env40199) = true)

theorem identity40199 : scanCanonicalize (H12AffineFastState.compose env40199 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound40199 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,35189,1025,32769,4161,21792,17,41311,8193,64,64604,57677,17665,56437,61704,21793,257,41341,16464,513]

theorem envBound40200 : H12AffineFastState.Bounded env40200 := by
  intro p hp
  have h : env40200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40199_40200 : H12AffineEnvironment.transform 17 35189 env40199 = env40200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env40199 == env40200) = true)

theorem identity40200 : scanCanonicalize (H12AffineFastState.compose env40200 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound40200 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env40201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28699,12636,11577,1025,9293,4161,21792,17,1299,8193,64,22544,17665,17665,30777,21828,21793,257,1329,16464,513]

theorem envBound40201 : H12AffineFastState.Bounded env40201 := by
  intro p hp
  have h : env40201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40200_40201 : H12AffineEnvironment.transform 14 9292 env40200 = env40201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env40200 == env40201) = true)

theorem identity40201 : scanCanonicalize (H12AffineFastState.compose env40201 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40201 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40202 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1296,20807,4096,3173,1025,1297,4161,21792,17,1299,349,64,22544,17665,17665,22885,21828,21793,257,1329,16464,513]

theorem envBound40202 : H12AffineFastState.Bounded env40202 := by
  intro p hp
  have h : env40202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40201_40202 : H12AffineEnvironment.transform 12 348 env40201 = env40202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40201 == env40202) = true)

theorem identity40202 : scanCanonicalize (H12AffineFastState.compose env40202 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40202 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1296,1094,4096,3173,1025,1297,4161,33,17,1299,349,64,3345,4096,4096,3172,69,32,257,1329,5457,513]

theorem envBound40203 : H12AffineFastState.Bounded env40203 := by
  intro p hp
  have h : env40203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40202_40203 : H12AffineEnvironment.transform 13 5377 env40202 = env40203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40202 == env40203) = true)

theorem identity40203 : scanCanonicalize (H12AffineFastState.compose env40203 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40203 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40204 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4113,0,342,4096,2421,273,1,4161,33,17,3,349,64,2049,4096,4096,2420,69,32,257,33,4161,513]

theorem envBound40204 : H12AffineFastState.Bounded env40204 := by
  intro p hp
  have h : env40204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40203_40204 : H12AffineEnvironment.transform 9 272 env40203 = env40204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40203 == env40204) = true)

theorem identity40204 : scanCanonicalize (H12AffineFastState.compose env40204 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound40204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40205 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,308,348,293,0,342,308,2421,273,1,373,33,17,3,349,64,2049,308,308,2420,69,32,257,33,373,513]

theorem envBound40205 : H12AffineFastState.Bounded env40205 := by
  intro p hp
  have h : env40205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40204_40205 : H12AffineEnvironment.transform 11 308 env40204 = env40205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env40204 == env40205) = true)

theorem identity40205 : scanCanonicalize (H12AffineFastState.compose env40205 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40205 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40206 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,16,120,1,0,114,16,2129,53,1,81,33,17,3,121,64,2049,16,16,2128,69,32,37,33,81,513]

theorem envBound40206 : H12AffineFastState.Bounded env40206 := by
  intro p hp
  have h : env40206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40205_40206 : H12AffineEnvironment.transform 7 36 env40205 = env40206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40205 == env40206) = true)

theorem identity40206 : scanCanonicalize (H12AffineFastState.compose env40206 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40206 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40207 : List Nat := [2,4,8,16,32,64,9,36,512,52,0,16,120,1,0,114,16,81,53,1,81,33,17,3,121,64,1,16,16,80,69,32,37,33,81,513]

theorem envBound40207 : H12AffineFastState.Bounded env40207 := by
  intro p hp
  have h : env40207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40206_40207 : H12AffineEnvironment.transform 10 0 env40206 = env40207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40206 == env40207) = true)

theorem identity40207 : scanCanonicalize (H12AffineFastState.compose env40207 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40207 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40208 : List Nat := [2,4,8,16,32,16,9,36,512,52,0,16,40,1,0,34,16,1,53,1,1,33,17,3,41,16,1,16,16,0,21,32,37,33,1,513]

theorem envBound40208 : H12AffineFastState.Bounded env40208 := by
  intro p hp
  have h : env40208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40207_40208 : H12AffineEnvironment.transform 5 16 env40207 = env40208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40207 == env40208) = true)

theorem identity40208 : scanCanonicalize (H12AffineFastState.compose env40208 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound40208 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40209 : List Nat := [2,4,8,16,32,16,9,36,48,52,0,16,40,1,0,34,16,1,53,1,1,33,17,3,41,16,1,16,16,0,21,32,37,33,1,49]

theorem envBound40209 : H12AffineFastState.Bounded env40209 := by
  intro p hp
  have h : env40209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40208_40209 : H12AffineEnvironment.transform 8 48 env40208 = env40209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40208 == env40209) = true)

theorem identity40209 : scanCanonicalize (H12AffineFastState.compose env40209 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40209 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40210 : List Nat := [2,4,8,1,32,1,9,36,33,37,0,1,40,1,0,34,1,1,36,1,1,33,0,3,41,1,1,1,1,0,4,32,37,33,1,32]

theorem envBound40210 : H12AffineFastState.Bounded env40210 := by
  intro p hp
  have h : env40210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40209_40210 : H12AffineEnvironment.transform 3 1 env40209 = env40210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40209 == env40210) = true)

def env40211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115871,329867,17,95497,8328,64,64724,79131,102879,360791,61705,318684,257,95531,103567,120542]

theorem envBound40211 : H12AffineFastState.Bounded env40211 := by
  intro p hp
  have h : env40211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40183_40211 : H12AffineEnvironment.transform 23 95497 env40183 = env40211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env40183 == env40211) = true)

def env40212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115735,329731,17,95497,8192,64,64604,79131,102743,360791,61705,318548,257,95531,103431,120406]

theorem envBound40212 : H12AffineFastState.Bounded env40212 := by
  intro p hp
  have h : env40212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40211_40212 : H12AffineEnvironment.transform 6 8 env40211 = env40212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40211 == env40212) = true)

theorem identity40212 : scanCanonicalize (H12AffineFastState.compose env40212 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40212 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,115735,73770,17,95497,8192,64,64604,79131,102743,108926,61705,62589,257,95531,103431,120406]

theorem envBound40213 : H12AffineFastState.Bounded env40213 := by
  intro p hp
  have h : env40213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40212_40213 : H12AffineEnvironment.transform 17 10281 env40212 = env40213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40212 == env40213) = true)

theorem identity40213 : scanCanonicalize (H12AffineFastState.compose env40213 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound40213 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env40214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,46157,10281,1025,32769,12573,54560,17,32771,8192,64,64604,49169,25693,23668,61705,62589,257,32801,24845,9052]

theorem envBound40214 : H12AffineFastState.Bounded env40214 := by
  intro p hp
  have h : env40214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40213_40214 : H12AffineEnvironment.transform 15 62730 env40213 = env40214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env40213 == env40214) = true)

theorem identity40214 : scanCanonicalize (H12AffineFastState.compose env40214 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound40214 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8203,24908,10281,1025,21760,12573,33,17,21762,8192,64,10589,5392,25693,23668,9224,8572,257,21792,24845,9052]

theorem envBound40215 : H12AffineFastState.Bounded env40215 := by
  intro p hp
  have h : env40215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40214_40215 : H12AffineEnvironment.transform 14 21761 env40214 = env40215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env40214 == env40215) = true)

theorem identity40215 : scanCanonicalize (H12AffineFastState.compose env40215 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound40215 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env40216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,80,8203,13341,10281,1025,81,12573,33,17,83,8192,64,10589,5392,12556,2341,9224,8572,257,113,13404,9052]

theorem envBound40216 : H12AffineFastState.Bounded env40216 := by
  intro p hp
  have h : env40216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40215_40216 : H12AffineEnvironment.transform 13 5457 env40215 = env40216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env40215 == env40216) = true)

theorem identity40216 : scanCanonicalize (H12AffineFastState.compose env40216 (packedSelected [0,2,3,5,9,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40216 : packedSelected [0,2,3,5,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env40217 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5237,80,8203,13341,10281,1025,81,12345,33,17,83,8192,64,10361,5172,12328,2049,9224,8280,37,113,13404,8824]

theorem envBound40217 : H12AffineFastState.Bounded env40217 := by
  intro p hp
  have h : env40217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40216_40217 : H12AffineEnvironment.transform 7 36 env40216 = env40217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40216 == env40217) = true)

theorem identity40217 : scanCanonicalize (H12AffineFastState.compose env40217 (packedSelected [0,1,2,3,4,11] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound40217 : packedSelected [0,1,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env40218 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,2563,5237,80,2568,7710,554,1025,81,6714,33,17,83,2563,64,634,5172,6699,2049,3595,2651,37,113,7775,2171]

theorem envBound40218 : H12AffineFastState.Bounded env40218 := by
  intro p hp
  have h : env40218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40217_40218 : H12AffineEnvironment.transform 12 2563 env40217 = env40218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env40217 == env40218) = true)

theorem identity40218 : scanCanonicalize (H12AffineFastState.compose env40218 (packedSelected [12,15] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound40218 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env40219 : List Nat := [2,4,8,16,32,64,8,36,512,1024,555,4096,40,5237,80,35,5173,554,1025,81,4113,33,17,83,40,64,634,5172,4096,554,1056,112,37,113,5236,592]

theorem envBound40219 : H12AffineFastState.Bounded env40219 := by
  intro p hp
  have h : env40219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40218_40219 : H12AffineEnvironment.transform 10 555 env40218 = env40219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env40218 == env40219) = true)

def env40220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115734,329730,17,95497,8193,64,64605,79131,102742,360791,61705,318549,257,95531,103430,120407]

theorem envBound40220 : H12AffineFastState.Bounded env40220 := by
  intro p hp
  have h : env40220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40211_40220 : H12AffineEnvironment.transform 6 9 env40211 = env40220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40211 == env40220) = true)

theorem identity40220 : scanCanonicalize (H12AffineFastState.compose env40220 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound40220 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,35189,1025,32769,115734,98679,17,95497,8193,64,64605,79131,102742,67618,61705,21792,257,95531,103430,120407]

theorem envBound40221 : H12AffineFastState.Bounded env40221 := by
  intro p hp
  have h : env40221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40220_40221 : H12AffineEnvironment.transform 17 35189 env40220 = env40221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env40220 == env40221) = true)

theorem identity40221 : scanCanonicalize (H12AffineFastState.compose env40221 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound40221 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,46157,35189,1025,32769,12572,29821,17,32771,8193,64,64605,49169,25692,64808,61705,21792,257,32801,24844,9053]

theorem envBound40222 : H12AffineFastState.Bounded env40222 := by
  intro p hp
  have h : env40222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40221_40222 : H12AffineEnvironment.transform 15 62730 env40221 = env40222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env40221 == env40222) = true)

theorem identity40222 : scanCanonicalize (H12AffineFastState.compose env40222 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40222 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,40970,46157,35189,1025,32769,12572,8573,17,32771,8193,64,43357,38161,12636,43048,41993,32,257,32801,13324,9053]

theorem envBound40223 : H12AffineFastState.Bounded env40223 := by
  intro p hp
  have h : env40223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40222_40223 : H12AffineEnvironment.transform 13 5376 env40222 = env40223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40222 == env40223) = true)

theorem identity40223 : scanCanonicalize (H12AffineFastState.compose env40223 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40223 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env40224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,33110,38161,35189,1025,32769,4160,33,17,32771,349,64,34817,38161,4096,35188,34133,32,257,32801,5456,513]

theorem envBound40224 : H12AffineFastState.Bounded env40224 := by
  intro p hp
  have h : env40224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40223_40224 : H12AffineEnvironment.transform 12 348 env40223 = env40224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40223 == env40224) = true)

theorem identity40224 : scanCanonicalize (H12AffineFastState.compose env40224 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40224 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5393,2421,1025,1,4160,33,17,3,349,64,2049,5393,4096,2420,1365,32,257,33,5456,513]

theorem envBound40225 : H12AffineFastState.Bounded env40225 := by
  intro p hp
  have h : env40225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40224_40225 : H12AffineEnvironment.transform 14 0 env40224 = env40225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40224 == env40225) = true)

theorem identity40225 : scanCanonicalize (H12AffineFastState.compose env40225 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40225 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40226 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4405,0,342,4388,2421,52,1,4160,33,17,3,349,64,2049,4388,4096,2420,352,32,257,33,4453,513]

theorem envBound40226 : H12AffineFastState.Bounded env40226 := by
  intro p hp
  have h : env40226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40225_40226 : H12AffineEnvironment.transform 9 53 env40225 = env40226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40225 == env40226) = true)

def env40227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412108,213334,16777216,8328,64,16959642,16974164,102878,360791,16958791,17148372,257,16777251,16834951,17031824]

theorem envBound40227 : H12AffineFastState.Bounded env40227 := by
  intro p hp
  have h : env40227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40181_40227 : H12AffineEnvironment.transform 20 165337 env40181 = env40227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env40181 == env40227) = true)

theorem identity40227 : scanCanonicalize (H12AffineFastState.compose env40227 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 106624) := by decide +kernel

theorem selectedBound40227 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env40228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412108,213334,106624,8328,64,223258,172500,102878,360791,222663,264532,257,106659,82183,147984]

theorem envBound40228 : H12AffineFastState.Bounded env40228 := by
  intro p hp
  have h : env40228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40227_40228 : H12AffineEnvironment.transform 23 106624 env40227 = env40228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 106624 env40227 == env40228) = true)

def env40229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,50633,264668,65862,106624,8328,64,75786,57796,102878,360791,75223,264532,257,106659,82183,512]

theorem envBound40229 : H12AffineFastState.Bounded env40229 := by
  intro p hp
  have h : env40229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40228_40229 : H12AffineEnvironment.transform 16 16400 env40228 = env40229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40228 == env40229) = true)

theorem identity40229 : scanCanonicalize (H12AffineFastState.compose env40229 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound40229 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,16400,262144,1025,32769,50633,264668,62661,21763,8328,64,56713,57796,25693,292052,53332,264532,257,21792,46212,512]

theorem envBound40230 : H12AffineFastState.Bounded env40230 := by
  intro p hp
  have h : env40230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40229_40230 : H12AffineEnvironment.transform 15 62851 env40229 = env40230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env40229 == env40230) = true)

theorem identity40230 : scanCanonicalize (H12AffineFastState.compose env40230 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound40230 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env40231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,343,16400,262144,1025,29909,12573,264668,17,21763,8328,64,10589,5392,25693,292052,9344,264532,257,21792,16464,512]

theorem envBound40231 : H12AffineFastState.Bounded env40231 := by
  intro p hp
  have h : env40231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40230_40231 : H12AffineEnvironment.transform 14 29908 env40230 = env40231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env40230 == env40231) = true)

theorem identity40231 : scanCanonicalize (H12AffineFastState.compose env40231 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10708) := by decide +kernel

theorem selectedBound40231 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,343,16400,10708,1025,29909,12573,8200,17,21763,8328,64,10589,5392,25693,23808,9344,8320,257,21792,16464,512]

theorem envBound40232 : H12AffineFastState.Bounded env40232 := by
  intro p hp
  have h : env40232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40231_40232 : H12AffineEnvironment.transform 17 10708 env40231 = env40232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10708 env40231 == env40232) = true)

theorem identity40232 : scanCanonicalize (H12AffineFastState.compose env40232 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40232 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env40233 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,29908,34,16400,10401,1025,29909,12392,8200,17,21622,8328,64,10280,5221,25693,23669,9344,8320,116,21589,16464,512]

theorem envBound40233 : H12AffineFastState.Bounded env40233 := by
  intro p hp
  have h : env40233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40232_40233 : H12AffineEnvironment.transform 7 117 env40232 = env40233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40232 == env40233) = true)

theorem identity40233 : scanCanonicalize (H12AffineFastState.compose env40233 (packedSelected [0,1,7,8,10,11,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 6320) := by decide +kernel

theorem selectedBound40233 : packedSelected [0,1,7,8,10,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env40234 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,6320,16384,19556,34,16400,4113,1025,19557,2264,6328,17,21622,6200,64,4248,5221,23789,23669,7216,6192,116,21589,16464,512]

theorem envBound40234 : H12AffineFastState.Bounded env40234 := by
  intro p hp
  have h : env40234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40233_40234 : H12AffineEnvironment.transform 12 6320 env40233 = env40234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6320 env40233 == env40234) = true)

theorem identity40234 : scanCanonicalize (H12AffineFastState.compose env40234 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound40234 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env40235 : List Nat := [2,4,8,16,32,64,128,117,512,1024,112,4096,4288,16384,17428,34,16400,4113,1025,17429,168,4296,17,21622,4168,64,4248,5221,21661,21509,5184,4160,116,21589,16464,512]

theorem envBound40235 : H12AffineFastState.Bounded env40235 := by
  intro p hp
  have h : env40235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40234_40235 : H12AffineEnvironment.transform 10 112 env40234 = env40235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env40234 == env40235) = true)

theorem identity40235 : scanCanonicalize (H12AffineFastState.compose env40235 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound40235 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env40236 : List Nat := [2,4,8,16,32,64,128,117,512,1024,112,4096,4288,5205,4161,34,5189,4113,1025,4160,168,4296,17,35,4168,64,4248,5221,200,80,5184,4160,116,0,5125,512]

theorem envBound40236 : H12AffineFastState.Bounded env40236 := by
  intro p hp
  have h : env40236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40235_40236 : H12AffineEnvironment.transform 13 5205 env40235 = env40236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env40235 == env40236) = true)

theorem identity40236 : scanCanonicalize (H12AffineFastState.compose env40236 (packedSelected [0,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound40236 : packedSelected [0,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env40237 : List Nat := [2,4,8,16,32,64,128,117,512,1024,112,153,89,1228,216,34,1244,136,1025,217,168,81,17,35,209,64,1,1276,200,80,1241,217,116,0,1180,512]

theorem envBound40237 : H12AffineFastState.Bounded env40237 := by
  intro p hp
  have h : env40237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40236_40237 : H12AffineEnvironment.transform 11 153 env40236 = env40237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env40236 == env40237) = true)

theorem identity40237 : scanCanonicalize (H12AffineFastState.compose env40237 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound40237 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env40238 : List Nat := [2,4,8,16,32,64,88,117,512,1024,112,65,89,1044,0,34,1028,80,1025,1,112,81,17,35,9,64,1,1060,16,80,1025,1,116,0,1092,512]

theorem envBound40238 : H12AffineFastState.Bounded env40238 := by
  intro p hp
  have h : env40238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40237_40238 : H12AffineEnvironment.transform 6 88 env40237 = env40238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env40237 == env40238) = true)

theorem identity40238 : scanCanonicalize (H12AffineFastState.compose env40238 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound40238 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40239 : List Nat := [2,4,8,16,32,48,40,5,512,1024,0,49,41,1044,0,34,1028,32,1025,1,0,33,17,35,9,48,1,1060,16,32,1025,1,4,0,1076,512]

theorem envBound40239 : H12AffineFastState.Bounded env40239 := by
  intro p hp
  have h : env40239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40238_40239 : H12AffineEnvironment.transform 5 48 env40238 = env40239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env40238 == env40239) = true)

theorem identity40239 : scanCanonicalize (H12AffineFastState.compose env40239 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound40239 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env40240 : List Nat := [2,4,8,16,32,48,40,5,512,575,0,49,41,555,0,34,571,32,574,1,0,33,17,35,9,48,1,539,16,32,574,1,4,0,523,512]

theorem envBound40240 : H12AffineFastState.Bounded env40240 := by
  intro p hp
  have h : env40240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40239_40240 : H12AffineEnvironment.transform 9 575 env40239 = env40240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env40239 == env40240) = true)

theorem identity40240 : scanCanonicalize (H12AffineFastState.compose env40240 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound40240 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40241 : List Nat := [2,4,8,2,32,34,40,5,512,557,0,35,41,555,0,34,553,32,556,1,0,33,3,35,9,34,1,521,2,32,556,1,4,0,523,512]

theorem envBound40241 : H12AffineFastState.Bounded env40241 := by
  intro p hp
  have h : env40241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40240_40241 : H12AffineEnvironment.transform 3 2 env40240 = env40241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env40240 == env40241) = true)

def env40242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,50632,264669,65863,106624,8328,64,75787,57797,102878,360791,75222,264532,257,106659,82183,513]

theorem envBound40242 : H12AffineFastState.Bounded env40242 := by
  intro p hp
  have h : env40242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40228_40242 : H12AffineEnvironment.transform 16 16401 env40228 = env40242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40228 == env40242) = true)

theorem identity40242 : scanCanonicalize (H12AffineFastState.compose env40242 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40242 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,50632,264669,8525,32906,8328,64,2049,57797,45524,303453,1500,264532,257,32937,24845,513]

theorem envBound40243 : H12AffineFastState.Bounded env40243 := by
  intro p hp
  have h : env40243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40242_40243 : H12AffineEnvironment.transform 15 8202 env40242 = env40243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40242 == env40243) = true)

theorem identity40243 : scanCanonicalize (H12AffineFastState.compose env40243 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound40243 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env40244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10401,1025,32769,50632,8572,8525,32906,8328,64,2049,57797,45524,35324,1500,8693,257,32937,24845,513]

theorem envBound40244 : H12AffineFastState.Bounded env40244 := by
  intro p hp
  have h : env40244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40243_40244 : H12AffineEnvironment.transform 17 10401 env40243 = env40244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env40243 == env40244) = true)

theorem identity40244 : scanCanonicalize (H12AffineFastState.compose env40244 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40244 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env40245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16401,10401,1025,0,17865,8572,8525,139,8328,64,2049,25028,12757,2557,1500,8693,257,168,24845,513]

theorem envBound40245 : H12AffineFastState.Bounded env40245 := by
  intro p hp
  have h : env40245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40244_40245 : H12AffineEnvironment.transform 14 1 env40244 = env40245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40244 == env40245) = true)

theorem identity40245 : scanCanonicalize (H12AffineFastState.compose env40245 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40245 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env40246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,1,262,16401,2477,1025,0,17865,112,65,139,388,64,2049,16584,4313,2557,1500,249,257,168,16385,513]

theorem envBound40246 : H12AffineFastState.Bounded env40246 := by
  intro p hp
  have h : env40246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40245_40246 : H12AffineEnvironment.transform 12 268 env40245 = env40246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40245 == env40246) = true)

theorem identity40246 : scanCanonicalize (H12AffineFastState.compose env40246 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40246 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env40247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,1,262,16401,2340,1025,0,17728,112,65,2,269,64,2049,16449,4176,2420,1365,112,257,33,16385,513]

theorem envBound40247 : H12AffineFastState.Bounded env40247 := by
  intro p hp
  have h : env40247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40246_40247 : H12AffineEnvironment.transform 6 9 env40246 = env40247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40246 == env40247) = true)

theorem identity40247 : scanCanonicalize (H12AffineFastState.compose env40247 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40247 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40248 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,262,16401,2340,1025,0,17680,32,17,2,269,16,2049,16401,4096,2340,1285,32,257,33,16385,513]

theorem envBound40248 : H12AffineFastState.Bounded env40248 := by
  intro p hp
  have h : env40248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40247_40248 : H12AffineEnvironment.transform 5 16 env40247 = env40248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40247 == env40248) = true)

theorem identity40248 : scanCanonicalize (H12AffineFastState.compose env40248 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound40248 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40249 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,1297,1,262,1280,2340,1025,0,1,32,17,2,269,16,2049,1280,4096,2340,1285,32,257,33,1296,513]

theorem envBound40249 : H12AffineFastState.Bounded env40249 := by
  intro p hp
  have h : env40249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40248_40249 : H12AffineEnvironment.transform 13 1297 env40248 = env40249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env40248 == env40249) = true)

theorem identity40249 : scanCanonicalize (H12AffineFastState.compose env40249 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound40249 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40250 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,308,268,1297,1,262,1280,2340,1025,0,1,32,17,2,269,16,2049,1280,308,2340,1285,32,257,33,1296,513]

theorem envBound40250 : H12AffineFastState.Bounded env40250 := by
  intro p hp
  have h : env40250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40249_40250 : H12AffineEnvironment.transform 11 308 env40249 = env40250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env40249 == env40250) = true)

theorem identity40250 : scanCanonicalize (H12AffineFastState.compose env40250 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound40250 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40251 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1296,308,268,1297,1,262,1280,1076,1025,0,1,32,17,2,269,16,1297,1280,308,1076,1285,32,257,33,1296,513]

theorem envBound40251 : H12AffineFastState.Bounded env40251 := by
  intro p hp
  have h : env40251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40250_40251 : H12AffineEnvironment.transform 10 1296 env40250 = env40251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env40250 == env40251) = true)

theorem identity40251 : scanCanonicalize (H12AffineFastState.compose env40251 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40251 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env40252 : List Nat := [2,4,8,16,32,16,9,256,512,52,292,308,268,293,1,262,308,0,53,0,1,32,17,2,269,16,293,308,308,0,305,32,257,33,292,513]

theorem envBound40252 : H12AffineFastState.Bounded env40252 := by
  intro p hp
  have h : env40252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40251_40252 : H12AffineEnvironment.transform 9 52 env40251 = env40252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40251 == env40252) = true)

theorem identity40252 : scanCanonicalize (H12AffineFastState.compose env40252 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound40252 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40253 : List Nat := [2,4,8,16,32,16,9,256,261,52,292,308,268,293,1,262,308,0,53,0,1,32,17,2,269,16,293,308,308,0,305,32,257,33,292,260]

theorem envBound40253 : H12AffineFastState.Bounded env40253 := by
  intro p hp
  have h : env40253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40252_40253 : H12AffineEnvironment.transform 8 261 env40252 = env40253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env40252 == env40253) = true)

def env40254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,412109,213334,16777216,8328,64,16959643,18973837,2298887,360791,16958791,19344396,257,19039738,19031134,17031824]

theorem envBound40254 : H12AffineFastState.Bounded env40254 := by
  intro p hp
  have h : env40254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40180_40254 : H12AffineEnvironment.transform 21 412109 env40180 = env40254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 412109 env40180 == env40254) = true)

def env40255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412109,213334,16777216,8328,64,16959643,16974165,102879,360791,16958791,17148372,257,16777250,16834950,17031824]

theorem envBound40255 : H12AffineFastState.Bounded env40255 := by
  intro p hp
  have h : env40255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40254_40255 : H12AffineEnvironment.transform 20 165336 env40254 = env40255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env40254 == env40255) = true)

def env40256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412109,213334,254096,8328,64,75787,57797,102879,360791,75223,411972,257,254130,196886,512]

theorem envBound40256 : H12AffineFastState.Bounded env40256 := by
  intro p hp
  have h : env40256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40255_40256 : H12AffineEnvironment.transform 23 254096 env40255 = env40256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254096 env40255 == env40256) = true)

theorem identity40256 : scanCanonicalize (H12AffineFastState.compose env40256 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound40256 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4161,318548,120015,95497,8328,64,75787,57797,102879,360791,75223,318685,257,95531,103567,512]

theorem envBound40257 : H12AffineFastState.Bounded env40257 := by
  intro p hp
  have h : env40257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40256_40257 : H12AffineEnvironment.transform 16 38297 env40256 = env40257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env40256 == env40257) = true)

theorem identity40257 : scanCanonicalize (H12AffineFastState.compose env40257 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound40257 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env40258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,343,38297,262144,1025,32769,4161,318548,54680,29790,8328,64,10588,57797,37000,294912,9344,318685,257,29820,38360,512]

theorem envBound40258 : H12AffineFastState.Bounded env40258 := by
  intro p hp
  have h : env40258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40257_40258 : H12AffineEnvironment.transform 15 343 env40257 = env40258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env40257 == env40258) = true)

theorem identity40258 : scanCanonicalize (H12AffineFastState.compose env40258 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound40258 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env40259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,343,16401,262144,1025,21897,4161,264668,16,29790,8328,64,10588,13389,17664,284040,9344,264533,257,29820,16464,512]

theorem envBound40259 : H12AffineFastState.Bounded env40259 := by
  intro p hp
  have h : env40259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40258_40259 : H12AffineEnvironment.transform 14 21896 env40258 = env40259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env40258 == env40259) = true)

theorem identity40259 : scanCanonicalize (H12AffineFastState.compose env40259 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound40259 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,343,16401,2184,1025,21897,4161,340,16,29790,8328,64,10588,13389,17664,23808,9344,477,257,29820,16464,512]

theorem envBound40260 : H12AffineFastState.Bounded env40260 := by
  intro p hp
  have h : env40260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40259_40260 : H12AffineEnvironment.transform 17 2184 env40259 = env40260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env40259 == env40260) = true)

theorem identity40260 : scanCanonicalize (H12AffineFastState.compose env40260 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound40260 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env40261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,16384,21896,343,16401,2184,1025,21897,4161,340,16,21758,40,64,2556,5357,17664,23808,1056,477,257,21724,16464,512]

theorem envBound40261 : H12AffineFastState.Bounded env40261 := by
  intro p hp
  have h : env40261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40260_40261 : H12AffineEnvironment.transform 12 160 env40260 = env40261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env40260 == env40261) = true)

theorem identity40261 : scanCanonicalize (H12AffineFastState.compose env40261 (packedSelected [0,3,4,5,7,9,10,11,14,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 488) := by decide +kernel

theorem selectedBound40261 : packedSelected [0,3,4,5,7,9,10,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env40262 : List Nat := [2,4,8,16,32,64,128,256,512,488,2048,4096,160,16384,20576,343,16401,2184,489,20577,4161,340,16,20758,40,64,2556,4357,16616,22760,456,477,257,20788,16464,512]

theorem envBound40262 : H12AffineFastState.Bounded env40262 := by
  intro p hp
  have h : env40262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40261_40262 : H12AffineEnvironment.transform 9 488 env40261 = env40262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 488 env40261 == env40262) = true)

theorem identity40262 : scanCanonicalize (H12AffineFastState.compose env40262 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4328) := by decide +kernel

theorem selectedBound40262 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40263 : List Nat := [2,4,8,16,32,64,128,256,512,488,2048,4096,160,4328,136,343,4345,2184,489,137,4161,340,16,510,40,64,2556,4357,4096,2048,456,477,257,476,4280,512]

theorem envBound40263 : H12AffineFastState.Bounded env40263 := by
  intro p hp
  have h : env40263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40262_40263 : H12AffineEnvironment.transform 13 4328 env40262 = env40263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4328 env40262 == env40263) = true)

theorem identity40263 : scanCanonicalize (H12AffineFastState.compose env40263 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound40263 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40264 : List Nat := [2,4,8,16,32,64,128,252,512,20,2048,4096,160,4328,136,171,4345,2184,21,137,4161,168,16,2,40,64,2048,4345,4096,2048,52,33,253,32,4280,512]

theorem envBound40264 : H12AffineFastState.Bounded env40264 := by
  intro p hp
  have h : env40264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40263_40264 : H12AffineEnvironment.transform 7 252 env40263 = env40264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env40263 == env40264) = true)

theorem identity40264 : scanCanonicalize (H12AffineFastState.compose env40264 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound40264 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40265 : List Nat := [2,4,8,16,32,64,41,85,512,20,2048,4096,9,4161,33,2,4176,2081,21,32,4161,1,16,2,40,64,2048,4176,4096,2048,52,33,84,32,4113,512]

theorem envBound40265 : H12AffineFastState.Bounded env40265 := by
  intro p hp
  have h : env40265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40264_40265 : H12AffineEnvironment.transform 6 41 env40264 = env40265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env40264 == env40265) = true)

theorem identity40265 : scanCanonicalize (H12AffineFastState.compose env40265 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound40265 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env40266 : List Nat := [2,4,8,16,32,64,41,85,512,20,2048,2096,9,2161,33,2,2144,2081,21,32,2161,1,16,2,40,64,2048,2144,2096,2048,52,33,84,32,2081,512]

theorem envBound40266 : H12AffineFastState.Bounded env40266 := by
  intro p hp
  have h : env40266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40265_40266 : H12AffineEnvironment.transform 11 2096 env40265 = env40266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env40265 == env40266) = true)

theorem identity40266 : scanCanonicalize (H12AffineFastState.compose env40266 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40266 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env40267 : List Nat := [2,4,8,16,32,17,41,4,512,20,2048,2096,9,2080,33,2,2097,2081,21,32,2080,1,16,2,40,17,2048,2097,2096,2048,52,33,5,32,2081,512]

theorem envBound40267 : H12AffineFastState.Bounded env40267 := by
  intro p hp
  have h : env40267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40266_40267 : H12AffineEnvironment.transform 5 17 env40266 = env40267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40266 == env40267) = true)

theorem identity40267 : scanCanonicalize (H12AffineFastState.compose env40267 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound40267 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40268 : List Nat := [2,4,8,16,32,17,41,4,512,20,4,52,9,36,33,2,53,37,21,32,36,1,16,2,40,17,4,53,52,4,52,33,5,32,37,512]

theorem envBound40268 : H12AffineFastState.Bounded env40268 := by
  intro p hp
  have h : env40268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40267_40268 : H12AffineEnvironment.transform 10 4 env40267 = env40268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env40267 == env40268) = true)

theorem identity40268 : scanCanonicalize (H12AffineFastState.compose env40268 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40269 : List Nat := [2,4,8,16,1,17,8,4,512,20,4,21,9,5,0,2,20,4,21,1,5,1,16,2,9,17,4,20,21,4,21,0,5,1,4,512]

theorem envBound40269 : H12AffineFastState.Bounded env40269 := by
  intro p hp
  have h : env40269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40268_40269 : H12AffineEnvironment.transform 4 1 env40268 = env40269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40268 == env40269) = true)

def env40270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412109,213334,254097,8328,64,75786,57796,102879,360791,75222,411973,257,254131,196887,513]

theorem envBound40270 : H12AffineFastState.Bounded env40270 := by
  intro p hp
  have h : env40270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40255_40270 : H12AffineEnvironment.transform 23 254097 env40255 = env40270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254097 env40255 == env40270) = true)

def env40271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411973,213334,253977,8192,64,75786,57676,102743,360791,75102,411973,257,254011,196887,513]

theorem envBound40271 : H12AffineFastState.Bounded env40271 := by
  intro p hp
  have h : env40271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40270_40271 : H12AffineEnvironment.transform 6 8 env40270 = env40271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40270 == env40271) = true)

theorem identity40271 : scanCanonicalize (H12AffineFastState.compose env40271 (packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound40271 : packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env40272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,165200,180273,213334,253977,8192,64,75786,57676,102743,67619,75102,180273,257,254011,196887,513]

theorem envBound40272 : H12AffineFastState.Bounded env40272 := by
  intro p hp
  have h : env40272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40271_40272 : H12AffineEnvironment.transform 17 35188 env40271 = env40272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env40271 == env40272) = true)

theorem identity40272 : scanCanonicalize (H12AffineFastState.compose env40272 (packedSelected [0,3,4,5,7,8,9,14,16,17,18,20,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40272 : packedSelected [0,3,4,5,7,8,9,14,16,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env40273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,140301,156012,213334,213316,8192,64,75786,16401,77834,67619,75102,156012,257,213350,196887,513]

theorem envBound40273 : H12AffineFastState.Bounded env40273 := by
  intro p hp
  have h : env40273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40272_40273 : H12AffineEnvironment.transform 14 8541 env40272 = env40273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40272 == env40273) = true)

theorem identity40273 : scanCanonicalize (H12AffineFastState.compose env40273 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound40273 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10281,1025,8540,82966,65911,8525,8543,8192,64,75786,16401,77834,67619,75102,65911,257,8573,24844,513]

theorem envBound40274 : H12AffineFastState.Bounded env40274 := by
  intro p hp
  have h : env40274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40273_40274 : H12AffineEnvironment.transform 16 90139 env40273 = env40274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env40273 == env40274) = true)

theorem identity40274 : scanCanonicalize (H12AffineFastState.compose env40274 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40274 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,65536,82247,2421,1025,0,82966,65911,17,3,348,64,67926,16401,69974,67619,66562,65911,257,33,16464,513]

theorem envBound40275 : H12AffineFastState.Bounded env40275 := by
  intro p hp
  have h : env40275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40274_40275 : H12AffineEnvironment.transform 12 348 env40274 = env40275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40274 == env40275) = true)

def env40276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411972,213334,253976,8193,64,75786,57677,102742,360791,75103,411973,257,254010,196887,513]

theorem envBound40276 : H12AffineFastState.Bounded env40276 := by
  intro p hp
  have h : env40276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40270_40276 : H12AffineEnvironment.transform 6 9 env40270 = env40276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40270 == env40276) = true)

theorem identity40276 : scanCanonicalize (H12AffineFastState.compose env40276 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound40276 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,124234,338271,8525,32771,8193,64,75786,57677,102742,360791,75103,338270,257,32801,24844,513]

theorem envBound40277 : H12AffineFastState.Bounded env40277 := by
  intro p hp
  have h : env40277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40276_40277 : H12AffineEnvironment.transform 16 90139 env40276 = env40277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env40276 == env40277) = true)

theorem identity40277 : scanCanonicalize (H12AffineFastState.compose env40277 (packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 53526) := by decide +kernel

theorem selectedBound40277 : packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env40278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53526,45325,262144,1025,32769,13404,325705,8525,32771,8193,64,63772,57677,16448,282689,62537,325704,257,32801,24844,513]

theorem envBound40278 : H12AffineFastState.Bounded env40278 := by
  intro p hp
  have h : env40278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40277_40278 : H12AffineEnvironment.transform 15 53526 env40277 = env40278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53526 env40277 == env40278) = true)

theorem identity40278 : scanCanonicalize (H12AffineFastState.compose env40278 (packedSelected [0,1,3,7,8,10,15,17,18,20,23,24,38] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40278 : packedSelected [0,1,3,7,8,10,15,17,18,20,23,24,38] rootPS < 2^1333 := by decide +kernel

def env40279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,53526,36944,262144,1025,32769,5377,317716,16,32771,348,64,55361,49168,16448,282689,54548,317717,257,32801,16465,513]

theorem envBound40279 : H12AffineFastState.Bounded env40279 := by
  intro p hp
  have h : env40279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40278_40279 : H12AffineEnvironment.transform 12 349 env40278 = env40279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40278 == env40279) = true)

theorem identity40279 : scanCanonicalize (H12AffineFastState.compose env40279 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 55653) := by decide +kernel

theorem selectedBound40279 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,53526,36944,55653,1025,32769,5377,113,16,32771,348,64,55361,49168,16448,35108,54548,112,257,32801,16465,513]

theorem envBound40280 : H12AffineFastState.Bounded env40280 := by
  intro p hp
  have h : env40280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40279_40280 : H12AffineEnvironment.transform 17 55653 env40279 = env40280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 55653 env40279 == env40280) = true)

theorem identity40280 : scanCanonicalize (H12AffineFastState.compose env40280 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound40280 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,20758,4176,22885,1025,1,5377,113,16,3,348,64,22593,16400,16448,2340,21780,112,257,33,16465,513]

theorem envBound40281 : H12AffineFastState.Bounded env40281 := by
  intro p hp
  have h : env40281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40280_40281 : H12AffineEnvironment.transform 14 0 env40280 = env40281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env40280 == env40281) = true)

theorem identity40281 : scanCanonicalize (H12AffineFastState.compose env40281 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound40281 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env40282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,0,262,4176,2421,1025,1,5377,113,16,3,348,64,2129,4096,4176,2340,1284,112,257,33,4161,513]

theorem envBound40282 : H12AffineFastState.Bounded env40282 := by
  intro p hp
  have h : env40282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40281_40282 : H12AffineEnvironment.transform 13 4112 env40281 = env40282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env40281 == env40282) = true)

theorem identity40282 : scanCanonicalize (H12AffineFastState.compose env40282 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40282 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40283 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,4112,0,262,4096,2341,1025,1,5377,33,16,3,268,16,2049,4096,4096,2340,1284,32,257,33,4113,513]

theorem envBound40283 : H12AffineFastState.Bounded env40283 := by
  intro p hp
  have h : env40283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40282_40283 : H12AffineEnvironment.transform 5 16 env40282 = env40283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40282 == env40283) = true)

theorem identity40283 : scanCanonicalize (H12AffineFastState.compose env40283 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40284 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,4112,0,262,4096,2341,273,1,4113,33,16,3,268,16,2049,4096,4096,2340,20,32,257,33,4113,513]

theorem envBound40284 : H12AffineFastState.Bounded env40284 := by
  intro p hp
  have h : env40284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40283_40284 : H12AffineEnvironment.transform 9 272 env40283 = env40284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40283 == env40284) = true)

def env40285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412109,213334,16777216,8328,64,16959643,16974164,102878,360791,16958791,17148373,257,16777251,16834951,17031824]

theorem envBound40285 : H12AffineFastState.Bounded env40285 := by
  intro p hp
  have h : env40285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40254_40285 : H12AffineEnvironment.transform 20 165337 env40254 = env40285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env40254 == env40285) = true)

theorem identity40285 : scanCanonicalize (H12AffineFastState.compose env40285 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound40285 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env40286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412109,213334,188871,8328,64,10588,123027,102878,360791,9344,477202,257,188900,131136,66391]

theorem envBound40286 : H12AffineFastState.Bounded env40286 := by
  intro p hp
  have h : env40286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40285_40286 : H12AffineEnvironment.transform 23 188871 env40285 = env40286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env40285 == env40286) = true)

def env40287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4161,318549,120014,29791,8328,64,10588,123027,102878,360791,9344,384394,257,29820,38360,66391]

theorem envBound40287 : H12AffineFastState.Bounded env40287 := by
  intro p hp
  have h : env40287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40286_40287 : H12AffineEnvironment.transform 16 38296 env40286 = env40287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env40286 == env40287) = true)

theorem identity40287 : scanCanonicalize (H12AffineFastState.compose env40287 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound40287 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,38296,262144,1025,32769,4161,318549,8525,29791,8328,64,10588,5392,25693,292052,9344,272393,257,29820,38360,63188]

theorem envBound40288 : H12AffineFastState.Bounded env40288 := by
  intro p hp
  have h : env40288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40287_40288 : H12AffineEnvironment.transform 15 62851 env40287 = env40288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env40287 == env40288) = true)

def env40289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38160,262144,1025,32769,4161,318549,8525,29791,8192,64,10588,5392,25693,291932,9224,272393,257,29820,38224,63068]

theorem envBound40289 : H12AffineFastState.Bounded env40289 := by
  intro p hp
  have h : env40289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40288_40289 : H12AffineEnvironment.transform 6 8 env40288 = env40289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40288 == env40289) = true)

theorem identity40289 : scanCanonicalize (H12AffineFastState.compose env40289 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound40289 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env40290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,24909,262144,1025,29788,4161,272392,8525,29791,8192,64,10588,5392,25693,291932,9224,272393,257,29820,24845,513]

theorem envBound40290 : H12AffineFastState.Bounded env40290 := by
  intro p hp
  have h : env40290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40289_40290 : H12AffineEnvironment.transform 14 29789 env40289 = env40290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env40289 == env40290) = true)

theorem identity40290 : scanCanonicalize (H12AffineFastState.compose env40290 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound40290 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,24909,32041,1025,29788,4161,21793,8525,29791,8192,64,10588,5392,25693,2421,9224,21792,257,29820,24845,513]

theorem envBound40291 : H12AffineFastState.Bounded env40291 := by
  intro p hp
  have h : env40291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40290_40291 : H12AffineEnvironment.transform 17 32041 env40290 = env40291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env40290 == env40291) = true)

def env40292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,262144,1025,32769,4161,318549,8525,29791,8193,64,10588,5392,25693,291933,9225,272393,257,29820,38225,63069]

theorem envBound40292 : H12AffineFastState.Bounded env40292 := by
  intro p hp
  have h : env40292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40288_40292 : H12AffineEnvironment.transform 6 9 env40288 = env40292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40288 == env40292) = true)

theorem identity40292 : scanCanonicalize (H12AffineFastState.compose env40292 (packedSelected [1,10,14,19,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound40292 : packedSelected [1,10,14,19,28,35] rootPS < 2^1333 := by decide +kernel

def env40293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38161,32041,1025,32769,4161,41340,8525,29791,8193,64,10588,5392,25693,2420,9225,21792,257,29820,38225,63069]

theorem envBound40293 : H12AffineFastState.Bounded env40293 := by
  intro p hp
  have h : env40293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40292_40293 : H12AffineEnvironment.transform 17 32041 env40292 = env40293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env40292 == env40293) = true)

theorem identity40293 : scanCanonicalize (H12AffineFastState.compose env40293 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound40293 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env40294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21540,8494,16693,32041,1025,21541,4161,30040,8525,29791,8193,64,10588,5392,25693,2420,9225,21792,257,29820,16757,8825]

theorem envBound40294 : H12AffineFastState.Bounded env40294 := by
  intro p hp
  have h : env40294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40293_40294 : H12AffineEnvironment.transform 14 21540 env40293 = env40294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env40293 == env40294) = true)

theorem identity40294 : scanCanonicalize (H12AffineFastState.compose env40294 (packedSelected [16,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40294 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env40295 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,21540,8203,16400,31756,1025,21541,4161,29821,8296,29791,8193,64,10361,5173,25693,2129,9225,21509,36,29820,16464,8825]

theorem envBound40295 : H12AffineFastState.Bounded env40295 := by
  intro p hp
  have h : env40295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40294_40295 : H12AffineEnvironment.transform 7 37 env40294 = env40295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40294 == env40295) = true)

theorem identity40295 : scanCanonicalize (H12AffineFastState.compose env40295 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound40295 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env40296 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,16384,21540,115,16400,23668,1025,21541,4161,21509,16,21543,121,64,2049,5173,17445,2129,1137,21509,36,21508,16464,513]

theorem envBound40296 : H12AffineFastState.Bounded env40296 := by
  intro p hp
  have h : env40296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40295_40296 : H12AffineEnvironment.transform 12 120 env40295 = env40296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env40295 == env40296) = true)

theorem identity40296 : scanCanonicalize (H12AffineFastState.compose env40296 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound40296 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40297 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5237,81,115,5221,2049,1025,80,4161,112,16,82,121,64,2049,5173,4176,2129,1137,112,36,113,5157,513]

theorem envBound40297 : H12AffineFastState.Bounded env40297 := by
  intro p hp
  have h : env40297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40296_40297 : H12AffineEnvironment.transform 13 5237 env40296 = env40297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env40296 == env40297) = true)

theorem identity40297 : scanCanonicalize (H12AffineFastState.compose env40297 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40297 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40298 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4160,81,115,4176,2049,52,80,4161,112,16,82,121,64,2049,4096,4176,2129,68,112,36,113,4112,513]

theorem envBound40298 : H12AffineFastState.Bounded env40298 := by
  intro p hp
  have h : env40298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40297_40298 : H12AffineEnvironment.transform 9 53 env40297 = env40298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40297 == env40298) = true)

theorem identity40298 : scanCanonicalize (H12AffineFastState.compose env40298 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40298 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env40299 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4112,1,35,4096,2049,52,0,4113,32,16,2,41,16,2049,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound40299 : H12AffineFastState.Bounded env40299 := by
  intro p hp
  have h : env40299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40298_40299 : H12AffineEnvironment.transform 5 16 env40298 = env40299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40298 == env40299) = true)

theorem identity40299 : scanCanonicalize (H12AffineFastState.compose env40299 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound40299 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40300 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,513,40,529,1,35,513,2049,52,0,528,32,16,2,41,16,2049,513,513,2049,20,32,36,33,529,513]

theorem envBound40300 : H12AffineFastState.Bounded env40300 := by
  intro p hp
  have h : env40300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40299_40300 : H12AffineEnvironment.transform 11 513 env40299 = env40300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env40299 == env40300) = true)

theorem identity40300 : scanCanonicalize (H12AffineFastState.compose env40300 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound40300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40301 : List Nat := [2,4,8,16,32,16,9,37,512,53,26,513,40,529,1,35,513,27,52,0,528,32,16,2,41,16,27,513,513,27,20,32,36,33,529,513]

theorem envBound40301 : H12AffineFastState.Bounded env40301 := by
  intro p hp
  have h : env40301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40300_40301 : H12AffineEnvironment.transform 10 26 env40300 = env40301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env40300 == env40301) = true)

theorem identity40301 : scanCanonicalize (H12AffineFastState.compose env40301 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound40301 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40302 : List Nat := [2,4,8,16,32,16,9,37,16,53,26,17,40,1,1,35,17,27,52,0,0,32,16,2,41,16,27,17,17,27,20,32,36,33,1,17]

theorem envBound40302 : H12AffineFastState.Bounded env40302 := by
  intro p hp
  have h : env40302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40301_40302 : H12AffineEnvironment.transform 8 16 env40301 = env40302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env40301 == env40302) = true)

theorem identity40302 : scanCanonicalize (H12AffineFastState.compose env40302 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40302 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40303 : List Nat := [2,4,8,10,32,10,9,37,10,47,0,11,40,1,1,35,11,1,46,0,0,32,10,2,41,10,1,11,11,1,14,32,36,33,1,11]

theorem envBound40303 : H12AffineFastState.Bounded env40303 := by
  intro p hp
  have h : env40303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40302_40303 : H12AffineEnvironment.transform 3 10 env40302 = env40303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40302 == env40303) = true)

def env40304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4160,318548,120015,29790,8328,64,10588,123027,102878,360791,9344,384395,257,29821,38361,66391]

theorem envBound40304 : H12AffineFastState.Bounded env40304 := by
  intro p hp
  have h : env40304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40286_40304 : H12AffineEnvironment.transform 16 38297 env40286 = env40304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env40286 == env40304) = true)

theorem identity40304 : scanCanonicalize (H12AffineFastState.compose env40304 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound40304 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24909,262144,1025,29909,4160,272512,73755,29790,8328,64,10588,70727,91402,357763,9344,338271,257,29821,24845,66391]

theorem envBound40305 : H12AffineFastState.Bounded env40305 := by
  intro p hp
  have h : env40305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40304_40305 : H12AffineEnvironment.transform 14 29908 env40304 = env40305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env40304 == env40305) = true)

def env40306 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24909,262144,1025,29909,4160,272512,73755,29790,8328,64,10588,70727,91402,357763,9344,338271,257,29789,24845,66391]

theorem envBound40306 : H12AffineFastState.Bounded env40306 := by
  intro p hp
  have h : env40306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40305_40306 : H12AffineEnvironment.transform 4 0 env40305 = env40306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40305 == env40306) = true)

theorem identity40306 : scanCanonicalize (H12AffineFastState.compose env40306 (packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 67722) := by decide +kernel

theorem selectedBound40306 : packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS < 2^1333 := by decide +kernel

def env40307 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24909,67722,1025,29909,4160,73738,73755,29790,8328,64,10588,70727,91402,32009,9344,8661,257,29789,24845,66391]

theorem envBound40307 : H12AffineFastState.Bounded env40307 := by
  intro p hp
  have h : env40307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40306_40307 : H12AffineEnvironment.transform 17 67722 env40306 = env40307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67722 env40306 == env40307) = true)

theorem identity40307 : scanCanonicalize (H12AffineFastState.compose env40307 (packedSelected [1,3,5,8,10,11,16,17,18,19,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound40307 : packedSelected [1,3,5,8,10,11,16,17,18,19,20,23,32] rootPS < 2^1333 := by decide +kernel

def env40308 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29908,479,24909,2389,1025,29909,4160,8661,8644,29790,8328,64,10588,5528,25813,32009,9344,8661,257,29789,24845,648]

theorem envBound40308 : H12AffineFastState.Bounded env40308 := by
  intro p hp
  have h : env40308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40307_40308 : H12AffineEnvironment.transform 15 479 env40307 = env40308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env40307 == env40308) = true)

theorem identity40308 : scanCanonicalize (H12AffineFastState.compose env40308 (packedSelected [0,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 12740) := by decide +kernel

theorem selectedBound40308 : packedSelected [0,7,16,17] rootPS < 2^1333 := by decide +kernel

def env40309 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,12740,1296,479,4233,2389,1025,1297,4160,8661,8644,1434,8328,64,10588,5528,5393,3277,9344,8661,257,1433,4297,648]

theorem envBound40309 : H12AffineFastState.Bounded env40309 := by
  intro p hp
  have h : env40309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40308_40309 : H12AffineEnvironment.transform 13 12740 env40308 = env40309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12740 env40308 == env40309) = true)

theorem identity40309 : scanCanonicalize (H12AffineFastState.compose env40309 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound40309 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40310 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,1101,5513,1296,479,4233,2389,1025,1297,4160,1432,1417,1434,1221,64,3345,5528,5393,3277,205,1432,257,1433,4297,648]

theorem envBound40310 : H12AffineFastState.Bounded env40310 := by
  intro p hp
  have h : env40310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40309_40310 : H12AffineEnvironment.transform 12 1101 env40309 = env40310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env40309 == env40310) = true)

theorem identity40310 : scanCanonicalize (H12AffineFastState.compose env40310 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

end H12CloudChart0