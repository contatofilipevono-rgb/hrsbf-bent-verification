import H12CloudChart0Data085

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound21727 : H12AffineFastState.Bounded env21727 := by
  intro p hp
  have h : env21727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21726_21727 : H12AffineEnvironment.transform 15 8202 env21726 = env21727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21726 == env21727) = true)

theorem identity21727 : scanCanonicalize (H12AffineFastState.compose env21727 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound21727 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,64808,1024,32769,4161,8572,17,41311,8192,65,56576,5393,17665,32041,1364,54560,256,21793,46093,513]

theorem envBound21728 : H12AffineFastState.Bounded env21728 := by
  intro p hp
  have h : env21728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21727_21728 : H12AffineEnvironment.transform 16 16400 env21727 = env21728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env21727 == env21728) = true)

theorem identity21728 : scanCanonicalize (H12AffineFastState.compose env21728 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21728 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,23669,1024,8540,4161,8572,17,2,8192,65,31837,5393,17665,32041,1364,29821,256,21793,5456,513]

theorem envBound21729 : H12AffineFastState.Bounded env21729 := by
  intro p hp
  have h : env21729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21728_21729 : H12AffineEnvironment.transform 14 8541 env21728 = env21729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21728 == env21729) = true)

theorem identity21729 : scanCanonicalize (H12AffineFastState.compose env21729 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound21729 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8541,8202,13340,10361,1024,8540,4161,8572,17,2,8192,65,2129,5393,12557,2341,1364,113,256,8493,5456,513]

theorem envBound21730 : H12AffineFastState.Bounded env21730 := by
  intro p hp
  have h : env21730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21729_21730 : H12AffineEnvironment.transform 13 13324 env21729 = env21730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env21729 == env21730) = true)

theorem identity21730 : scanCanonicalize (H12AffineFastState.compose env21730 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21730 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,0,343,5441,2340,1024,1,4161,33,17,2,349,65,2129,5393,4176,2341,1364,113,256,112,5456,513]

theorem envBound21731 : H12AffineFastState.Bounded env21731 := by
  intro p hp
  have h : env21731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21730_21731 : H12AffineEnvironment.transform 12 349 env21730 = env21731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21730 == env21731) = true)

theorem identity21731 : scanCanonicalize (H12AffineFastState.compose env21731 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21731 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21732 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1024,1,4113,33,17,2,269,17,2049,5393,4096,2341,1284,33,256,32,5376,513]

theorem envBound21732 : H12AffineFastState.Bounded env21732 := by
  intro p hp
  have h : env21732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21731_21732 : H12AffineEnvironment.transform 5 16 env21731 = env21732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21731 == env21732) = true)

theorem identity21732 : scanCanonicalize (H12AffineFastState.compose env21732 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound21732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21733 : List Nat := [2,4,8,16,32,16,8,256,512,256,2048,4096,269,4097,0,263,4113,2340,256,1,4113,33,17,2,269,17,2049,4113,4096,2341,4,33,256,32,4096,513]

theorem envBound21733 : H12AffineFastState.Bounded env21733 := by
  intro p hp
  have h : env21733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21732_21733 : H12AffineEnvironment.transform 9 256 env21732 = env21733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env21732 == env21733) = true)

theorem identity21733 : scanCanonicalize (H12AffineFastState.compose env21733 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound21733 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21734 : List Nat := [2,4,8,16,32,16,8,256,0,256,2048,4096,269,4097,0,263,4113,2340,256,1,4113,33,17,2,269,17,2049,4113,4096,2341,4,33,256,32,4096,1]

theorem envBound21734 : H12AffineFastState.Bounded env21734 := by
  intro p hp
  have h : env21734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21733_21734 : H12AffineEnvironment.transform 8 0 env21733 = env21734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21733 == env21734) = true)

theorem identity21734 : scanCanonicalize (H12AffineFastState.compose env21734 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound21734 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21735 : List Nat := [2,4,8,16,32,16,8,256,0,256,2048,2049,269,2048,0,263,2064,2340,256,1,2064,33,17,2,269,17,2049,2064,2049,2341,4,33,256,32,2049,1]

theorem envBound21735 : H12AffineFastState.Bounded env21735 := by
  intro p hp
  have h : env21735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21734_21735 : H12AffineEnvironment.transform 11 2049 env21734 = env21735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env21734 == env21735) = true)

theorem identity21735 : scanCanonicalize (H12AffineFastState.compose env21735 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound21735 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21736 : List Nat := [2,4,8,16,32,16,8,256,0,256,292,293,269,292,0,263,308,0,256,1,308,33,17,2,269,17,293,308,293,1,4,33,256,32,293,1]

theorem envBound21736 : H12AffineFastState.Bounded env21736 := by
  intro p hp
  have h : env21736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21735_21736 : H12AffineEnvironment.transform 10 292 env21735 = env21736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env21735 == env21736) = true)

theorem identity21736 : scanCanonicalize (H12AffineFastState.compose env21736 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound21736 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21737 : List Nat := [2,4,8,16,32,16,8,52,0,52,16,17,57,16,0,51,0,0,52,1,0,33,17,2,57,17,17,0,17,1,4,33,52,32,17,1]

theorem envBound21737 : H12AffineFastState.Bounded env21737 := by
  intro p hp
  have h : env21737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21736_21737 : H12AffineEnvironment.transform 7 52 env21736 = env21737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env21736 == env21737) = true)

theorem identity21737 : scanCanonicalize (H12AffineFastState.compose env21737 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21737 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env21738 : List Nat := [2,4,8,1,32,1,8,37,0,37,1,0,40,1,0,34,0,0,37,1,0,33,0,2,40,0,0,0,0,1,4,33,37,32,0,1]

theorem envBound21738 : H12AffineFastState.Bounded env21738 := by
  intro p hp
  have h : env21738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21737_21738 : H12AffineEnvironment.transform 3 1 env21737 = env21738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21737 == env21738) = true)

theorem identity21738 : scanCanonicalize (H12AffineFastState.compose env21738 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21738 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21739 : List Nat := [2,4,3,1,32,1,3,37,0,37,1,0,35,1,0,34,0,0,37,1,0,33,0,2,35,0,0,0,0,1,4,33,37,32,0,1]

theorem envBound21739 : H12AffineFastState.Bounded env21739 := by
  intro p hp
  have h : env21739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21738_21739 : H12AffineEnvironment.transform 2 3 env21738 = env21739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21738 == env21739) = true)

def env21740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156013,17,98644,8193,65,171281,5393,17665,32040,1365,169265,256,21793,46092,74251]

theorem envBound21740 : H12AffineFastState.Bounded env21740 := by
  intro p hp
  have h : env21740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21725_21740 : H12AffineEnvironment.transform 6 9 env21725 = env21740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21725 == env21740) = true)

theorem identity21740 : scanCanonicalize (H12AffineFastState.compose env21740 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound21740 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,179513,1024,32769,4161,156013,17,3,8193,65,171281,5393,17665,32040,1365,169265,256,21793,46092,41820]

theorem envBound21741 : H12AffineFastState.Bounded env21741 := by
  intro p hp
  have h : env21741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21740_21741 : H12AffineEnvironment.transform 15 33111 env21740 = env21741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env21740 == env21741) = true)

theorem identity21741 : scanCanonicalize (H12AffineFastState.compose env21741 (packedSelected [18,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21741 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env21742 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,33030,131072,179513,1024,32769,4112,155964,17,3,8193,16,171281,5393,17665,32040,1284,169265,256,21793,46092,41741]

theorem envBound21742 : H12AffineFastState.Bounded env21742 := by
  intro p hp
  have h : env21742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21741_21742 : H12AffineEnvironment.transform 5 17 env21741 = env21742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21741 == env21742) = true)

theorem identity21742 : scanCanonicalize (H12AffineFastState.compose env21742 (packedSelected [0,1,3,7,8,9,10,12,14,15,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound21742 : packedSelected [0,1,3,7,8,9,10,12,14,15,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21743 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5157,32768,33030,131072,179513,1024,32769,4112,144665,17,3,8193,16,171281,5393,4388,10509,1284,169265,256,260,46092,41741]

theorem envBound21743 : H12AffineFastState.Bounded env21743 := by
  intro p hp
  have h : env21743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21742_21743 : H12AffineEnvironment.transform 13 5157 env21742 = env21743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env21742 == env21743) = true)

theorem identity21743 : scanCanonicalize (H12AffineFastState.compose env21743 (packedSelected [2,3,4,5,6,10,11,12,15,18,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound21743 : packedSelected [2,3,4,5,6,10,11,12,15,18,20,22] rootPS < 2^1333 := by decide +kernel

def env21744 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5157,32768,33030,38161,10280,1024,32769,4112,40968,17,3,8193,16,2048,5393,4388,10509,1284,32,256,260,46092,41741]

theorem envBound21744 : H12AffineFastState.Bounded env21744 := by
  intro p hp
  have h : env21744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21743_21744 : H12AffineEnvironment.transform 16 38161 env21743 = env21744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env21743 == env21744) = true)

theorem identity21744 : scanCanonicalize (H12AffineFastState.compose env21744 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound21744 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env21745 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5157,292,34,5173,10280,1024,293,4112,8492,17,3,8193,16,2048,5393,4388,10509,1284,32,256,260,13608,8745]

theorem envBound21745 : H12AffineFastState.Bounded env21745 := by
  intro p hp
  have h : env21745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21744_21745 : H12AffineEnvironment.transform 14 292 env21744 = env21745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env21744 == env21745) = true)

theorem identity21745 : scanCanonicalize (H12AffineFastState.compose env21745 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21745 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21746 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,5157,0,34,5173,10280,1024,1,4112,8200,17,3,8193,16,2048,5173,4096,10281,1056,32,36,32,13324,8745]

theorem envBound21746 : H12AffineFastState.Bounded env21746 := by
  intro p hp
  have h : env21746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21745_21746 : H12AffineEnvironment.transform 7 36 env21745 = env21746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21745 == env21746) = true)

theorem identity21746 : scanCanonicalize (H12AffineFastState.compose env21746 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound21746 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env21747 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,512,8192,1573,0,34,1589,10280,1024,1,528,8200,17,3,8193,16,2048,1589,512,10281,1056,32,36,32,9740,8745]

theorem envBound21747 : H12AffineFastState.Bounded env21747 := by
  intro p hp
  have h : env21747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21746_21747 : H12AffineEnvironment.transform 11 512 env21746 = env21747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env21746 == env21747) = true)

theorem identity21747 : scanCanonicalize (H12AffineFastState.compose env21747 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound21747 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env21748 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,512,8192,1573,0,34,1589,8761,1024,1,528,8200,17,3,8193,16,529,1589,512,8760,1056,32,36,32,9740,8745]

theorem envBound21748 : H12AffineFastState.Bounded env21748 := by
  intro p hp
  have h : env21748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21747_21748 : H12AffineEnvironment.transform 10 529 env21747 = env21748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env21747 == env21748) = true)

theorem identity21748 : scanCanonicalize (H12AffineFastState.compose env21748 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21748 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env21749 : List Nat := [2,4,8,16,32,17,9,36,1,1024,16,1,8192,1060,0,34,1076,8248,1024,1,17,8200,17,3,8193,16,16,1076,1,8249,1056,32,36,32,9229,8232]

theorem envBound21749 : H12AffineFastState.Bounded env21749 := by
  intro p hp
  have h : env21749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21748_21749 : H12AffineEnvironment.transform 8 1 env21748 = env21749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21748 == env21749) = true)

theorem identity21749 : scanCanonicalize (H12AffineFastState.compose env21749 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound21749 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env21750 : List Nat := [2,4,8,16,32,17,9,36,1,1024,16,1,25,1060,0,34,1076,33,1024,1,17,17,17,3,24,16,16,1076,1,32,1056,32,36,32,1044,49]

theorem envBound21750 : H12AffineFastState.Bounded env21750 := by
  intro p hp
  have h : env21750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21749_21750 : H12AffineEnvironment.transform 12 25 env21749 = env21750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env21749 == env21750) = true)

theorem identity21750 : scanCanonicalize (H12AffineFastState.compose env21750 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21750 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env21751 : List Nat := [2,4,8,16,32,17,9,36,1,20,16,1,25,48,0,34,32,33,20,1,17,17,17,3,24,16,16,32,1,32,52,32,36,32,0,49]

theorem envBound21751 : H12AffineFastState.Bounded env21751 := by
  intro p hp
  have h : env21751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21750_21751 : H12AffineEnvironment.transform 9 20 env21750 = env21751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21750 == env21751) = true)

theorem identity21751 : scanCanonicalize (H12AffineFastState.compose env21751 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21751 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21752 : List Nat := [2,4,8,16,0,17,9,4,1,20,16,1,25,16,0,2,0,1,20,1,17,17,17,3,24,16,16,0,1,0,20,0,4,0,0,17]

theorem envBound21752 : H12AffineFastState.Bounded env21752 := by
  intro p hp
  have h : env21752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21751_21752 : H12AffineEnvironment.transform 4 0 env21751 = env21752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21751 == env21752) = true)

theorem identity21752 : scanCanonicalize (H12AffineFastState.compose env21752 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21752 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env21753 : List Nat := [2,4,8,1,0,0,9,4,1,5,1,1,8,1,0,2,0,1,5,1,0,0,0,3,9,1,1,0,1,0,5,0,4,0,0,0]

theorem envBound21753 : H12AffineFastState.Bounded env21753 := by
  intro p hp
  have h : env21753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21752_21753 : H12AffineEnvironment.transform 3 1 env21752 = env21753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21752 == env21753) = true)

def env21754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,2097152,4194304,2101329,98780,8328,65,6351932,2098513,17664,2125280,2102685,6349852,256,21793,46213,2175562]

theorem envBound21754 : H12AffineFastState.Bounded env21754 := by
  intro p hp
  have h : env21754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21701_21754 : H12AffineEnvironment.transform 17 179633 env21701 = env21754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env21701 == env21754) = true)

def env21755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,4194304,17,98780,8328,65,4258940,5393,17664,32160,1501,4256860,256,21793,46213,74250]

theorem envBound21755 : H12AffineFastState.Bounded env21755 := by
  intro p hp
  have h : env21755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21754_21755 : H12AffineEnvironment.transform 20 4160 env21754 = env21755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21754 == env21755) = true)

theorem identity21755 : scanCanonicalize (H12AffineFastState.compose env21755 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169264) := by decide +kernel

theorem selectedBound21755 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,169264,17,98780,8328,65,158028,5393,17664,32160,1501,156012,256,21793,46213,74250]

theorem envBound21756 : H12AffineFastState.Bounded env21756 := by
  intro p hp
  have h : env21756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21755_21756 : H12AffineEnvironment.transform 21 169264 env21755 = env21756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env21755 == env21756) = true)

theorem identity21756 : scanCanonicalize (H12AffineFastState.compose env21756 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21756 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env21757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179633,1024,32769,4160,169264,17,41431,8328,65,158028,5393,17664,32160,1501,156012,256,21793,46213,513]

theorem envBound21757 : H12AffineFastState.Bounded env21757 := by
  intro p hp
  have h : env21757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21756_21757 : H12AffineEnvironment.transform 15 8203 env21756 = env21757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21756 == env21757) = true)

theorem identity21757 : scanCanonicalize (H12AffineFastState.compose env21757 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound21757 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,64928,1024,32769,4160,54561,17,41431,8328,65,10589,5393,17664,32160,1501,8573,256,21793,46213,513]

theorem envBound21758 : H12AffineFastState.Bounded env21758 := by
  intro p hp
  have h : env21758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21757_21758 : H12AffineEnvironment.transform 16 16401 env21757 = env21758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env21757 == env21758) = true)

theorem identity21758 : scanCanonicalize (H12AffineFastState.compose env21758 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound21758 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env21759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,16401,2477,1024,29708,4160,8492,17,21978,8328,65,10589,5393,17664,32160,1501,8573,256,21793,16520,513]

theorem envBound21759 : H12AffineFastState.Bounded env21759 := by
  intro p hp
  have h : env21759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21758_21759 : H12AffineEnvironment.transform 14 29709 env21758 = env21759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env21758 == env21759) = true)

def env21760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,16384,20925,1467,16401,2477,1024,20924,4160,1180,17,21978,1336,65,3309,5393,17664,22544,1501,1229,256,21793,16520,513]

theorem envBound21760 : H12AffineFastState.Bounded env21760 := by
  intro p hp
  have h : env21760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21759_21760 : H12AffineEnvironment.transform 12 1456 env21759 = env21760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env21759 == env21760) = true)

theorem identity21760 : scanCanonicalize (H12AffineFastState.compose env21760 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound21760 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21761 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,468,16384,20925,479,16401,2477,100,20924,4160,248,17,20926,348,65,2185,4469,16740,22544,441,169,256,20805,16520,513]

theorem envBound21761 : H12AffineFastState.Bounded env21761 := by
  intro p hp
  have h : env21761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21760_21761 : H12AffineEnvironment.transform 9 100 env21760 = env21761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env21760 == env21761) = true)

theorem identity21761 : scanCanonicalize (H12AffineFastState.compose env21761 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound21761 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21762 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,2200,468,16384,18725,479,16401,2477,100,18724,2264,248,17,18726,348,65,2185,2541,16740,16520,441,169,256,18909,16520,513]

theorem envBound21762 : H12AffineFastState.Bounded env21762 := by
  intro p hp
  have h : env21762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21761_21762 : H12AffineEnvironment.transform 11 2200 env21761 = env21762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env21761 == env21762) = true)

theorem identity21762 : scanCanonicalize (H12AffineFastState.compose env21762 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 428) := by decide +kernel

theorem selectedBound21762 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env21763 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,2200,468,428,2185,479,445,2477,100,2184,2264,248,17,2186,348,65,2185,2541,200,292,441,169,256,2161,292,513]

theorem envBound21763 : H12AffineFastState.Bounded env21763 := by
  intro p hp
  have h : env21763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21762_21763 : H12AffineEnvironment.transform 13 428 env21762 = env21763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 428 env21762 == env21763) = true)

theorem identity21763 : scanCanonicalize (H12AffineFastState.compose env21763 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound21763 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21764 : List Nat := [2,4,8,16,32,64,128,173,512,100,2048,2200,121,1,2185,114,16,2048,100,2184,2264,248,17,2186,241,65,2185,2112,200,137,20,169,173,2161,137,513]

theorem envBound21764 : H12AffineFastState.Bounded env21764 := by
  intro p hp
  have h : env21764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21763_21764 : H12AffineEnvironment.transform 7 173 env21763 = env21764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env21763 == env21764) = true)

theorem identity21764 : scanCanonicalize (H12AffineFastState.compose env21764 (packedSelected [2,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21764 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env21765 : List Nat := [2,4,8,16,32,17,128,173,512,53,2048,2200,40,1,2185,35,16,2048,53,2184,2185,169,17,2186,160,16,2185,2065,153,137,20,169,173,2080,137,513]

theorem envBound21765 : H12AffineFastState.Bounded env21765 := by
  intro p hp
  have h : env21765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21764_21765 : H12AffineEnvironment.transform 5 17 env21764 = env21765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21764 == env21765) = true)

theorem identity21765 : scanCanonicalize (H12AffineFastState.compose env21765 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21765 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21766 : List Nat := [2,4,8,16,32,17,128,173,512,53,1,153,40,1,136,35,16,1,53,137,136,169,17,139,160,16,136,16,153,137,20,169,173,33,137,513]

theorem envBound21766 : H12AffineFastState.Bounded env21766 := by
  intro p hp
  have h : env21766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21765_21766 : H12AffineEnvironment.transform 10 1 env21765 = env21766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21765 == env21766) = true)

def env21767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,16384,20924,1466,16401,2477,1024,20925,4160,1181,17,21978,1337,65,3308,5393,17664,22545,1501,1228,256,21793,16520,513]

theorem envBound21767 : H12AffineFastState.Bounded env21767 := by
  intro p hp
  have h : env21767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21759_21767 : H12AffineEnvironment.transform 12 1457 env21759 = env21767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env21759 == env21767) = true)

theorem identity21767 : scanCanonicalize (H12AffineFastState.compose env21767 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 4540) := by decide +kernel

theorem selectedBound21767 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,4540,0,1466,4525,2477,1024,1,4160,1181,17,1126,1337,65,3308,5393,5308,2477,1501,1228,256,1181,4404,513]

theorem envBound21768 : H12AffineFastState.Bounded env21768 := by
  intro p hp
  have h : env21768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21767_21768 : H12AffineEnvironment.transform 13 4540 env21767 = env21768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4540 env21767 == env21768) = true)

theorem identity21768 : scanCanonicalize (H12AffineFastState.compose env21768 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound21768 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21769 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,268,4540,0,263,4525,2477,189,1,4160,32,17,219,388,65,2129,4524,4097,2477,352,113,256,32,4404,513]

theorem envBound21769 : H12AffineFastState.Bounded env21769 := by
  intro p hp
  have h : env21769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21768_21769 : H12AffineEnvironment.transform 9 189 env21768 = env21769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env21768 == env21769) = true)

theorem identity21769 : scanCanonicalize (H12AffineFastState.compose env21769 (packedSelected [1,3,4,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound21769 : packedSelected [1,3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env21770 : List Nat := [2,4,8,16,32,64,128,256,512,189,372,4096,268,4540,0,263,4525,217,189,1,4160,32,17,219,388,65,293,4524,4097,217,352,113,256,32,4404,513]

theorem envBound21770 : H12AffineFastState.Bounded env21770 := by
  intro p hp
  have h : env21770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21769_21770 : H12AffineEnvironment.transform 10 372 env21769 = env21770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env21769 == env21770) = true)

theorem identity21770 : scanCanonicalize (H12AffineFastState.compose env21770 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21770 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env21771 : List Nat := [2,4,8,16,32,64,128,117,512,189,1,4096,121,4297,0,114,4312,217,189,1,4160,32,17,219,241,65,80,4313,4097,217,21,113,117,32,4161,513]

theorem envBound21771 : H12AffineFastState.Bounded env21771 := by
  intro p hp
  have h : env21771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21770_21771 : H12AffineEnvironment.transform 7 117 env21770 = env21771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21770 == env21771) = true)

def env21772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,4194304,16,98780,8328,65,4258941,5392,17664,32161,1500,4256861,256,21793,46213,74251]

theorem envBound21772 : H12AffineFastState.Bounded env21772 := by
  intro p hp
  have h : env21772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21754_21772 : H12AffineEnvironment.transform 20 4161 env21754 = env21772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21754 == env21772) = true)

def env21773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,4194304,16,98644,8192,65,4258941,5392,17664,32041,1364,4256861,256,21793,46093,74251]

theorem envBound21773 : H12AffineFastState.Bounded env21773 := by
  intro p hp
  have h : env21773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21772_21773 : H12AffineEnvironment.transform 6 8 env21772 = env21773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21772 == env21773) = true)

theorem identity21773 : scanCanonicalize (H12AffineFastState.compose env21773 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound21773 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,67618,1024,32769,4161,4194304,16,98644,8192,65,4258941,5392,17664,32041,1364,4256861,256,21793,46093,74251]

theorem envBound21774 : H12AffineFastState.Bounded env21774 := by
  intro p hp
  have h : env21774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21773_21774 : H12AffineEnvironment.transform 16 111899 env21773 = env21774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env21773 == env21774) = true)

theorem identity21774 : scanCanonicalize (H12AffineFastState.compose env21774 (packedSelected [0,1,2,3,4,6,8,9,10,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound21774 : packedSelected [0,1,2,3,4,6,8,9,10,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env21775 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,46156,2421,1024,32769,4161,4194304,16,32771,8192,65,4258941,5392,17664,32041,1364,4256861,256,21793,46093,9052]

theorem envBound21775 : H12AffineFastState.Bounded env21775 := by
  intro p hp
  have h : env21775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21774_21775 : H12AffineEnvironment.transform 15 343 env21774 = env21775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env21774 == env21775) = true)

theorem identity21775 : scanCanonicalize (H12AffineFastState.compose env21775 (packedSelected [0,1,4,5,7,8,18,19,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound21775 : packedSelected [0,1,4,5,7,8,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env21776 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,46156,2421,1024,32769,4161,8572,16,32771,8192,65,56577,5392,17664,32041,1364,54561,256,21793,46093,9052]

theorem envBound21776 : H12AffineFastState.Bounded env21776 := by
  intro p hp
  have h : env21776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21775_21776 : H12AffineEnvironment.transform 21 8572 env21775 = env21776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env21775 == env21776) = true)

theorem identity21776 : scanCanonicalize (H12AffineFastState.compose env21776 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21776 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env21777 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,5393,2421,1024,8540,4161,8572,16,8542,8192,65,31836,5392,17664,32041,1364,29820,256,21793,5456,9052]

theorem envBound21777 : H12AffineFastState.Bounded env21777 := by
  intro p hp
  have h : env21777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21776_21777 : H12AffineEnvironment.transform 14 8541 env21776 = env21777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21776 == env21777) = true)

theorem identity21777 : scanCanonicalize (H12AffineFastState.compose env21777 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound21777 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,16384,341,343,5393,2421,1024,340,4161,372,16,342,8,65,23636,5392,17664,23841,1364,21620,256,21793,5456,852]

theorem envBound21778 : H12AffineFastState.Bounded env21778 := by
  intro p hp
  have h : env21778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21777_21778 : H12AffineEnvironment.transform 12 8 env21777 = env21778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env21777 == env21778) = true)

theorem identity21778 : scanCanonicalize (H12AffineFastState.compose env21778 (packedSelected [1,2,8,14,19] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound21778 : packedSelected [1,2,8,14,19] rootPS < 2^1333 := by decide +kernel

def env21779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5204,341,343,5393,2421,1024,340,4161,372,16,342,8,65,2048,5392,4436,2421,1364,32,256,373,5456,852]

theorem envBound21779 : H12AffineFastState.Bounded env21779 := by
  intro p hp
  have h : env21779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21778_21779 : H12AffineEnvironment.transform 13 5204 env21778 = env21779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env21778 == env21779) = true)

theorem identity21779 : scanCanonicalize (H12AffineFastState.compose env21779 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21779 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21780 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8,5204,32,34,5220,2048,1024,33,4161,1,16,35,8,65,2048,5221,4129,2048,1057,32,117,0,5157,545]

theorem envBound21780 : H12AffineFastState.Bounded env21780 := by
  intro p hp
  have h : env21780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21779_21780 : H12AffineEnvironment.transform 7 117 env21779 = env21780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21779 == env21780) = true)

theorem identity21780 : scanCanonicalize (H12AffineFastState.compose env21780 (packedSelected [3,5,10,16] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21780 : packedSelected [3,5,10,16] rootPS < 2^1333 := by decide +kernel

def env21781 : List Nat := [2,4,8,16,0,64,8,85,512,1024,2048,4096,8,5204,0,2,5188,2048,1024,1,4161,1,16,3,8,65,2048,5189,4097,2048,1025,0,85,0,5125,513]

theorem envBound21781 : H12AffineFastState.Bounded env21781 := by
  intro p hp
  have h : env21781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21780_21781 : H12AffineEnvironment.transform 4 0 env21780 = env21781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21780 == env21781) = true)

theorem identity21781 : scanCanonicalize (H12AffineFastState.compose env21781 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound21781 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21782 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,4096,8,4113,0,2,4097,2048,69,1,4161,1,16,3,8,65,2048,4096,4097,2048,68,0,85,0,4160,513]

theorem envBound21782 : H12AffineFastState.Bounded env21782 := by
  intro p hp
  have h : env21782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21781_21782 : H12AffineEnvironment.transform 9 69 env21781 = env21782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env21781 == env21782) = true)

theorem identity21782 : scanCanonicalize (H12AffineFastState.compose env21782 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound21782 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21783 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,17,8,0,0,2,16,2048,69,1,80,1,16,3,8,65,2048,17,16,2048,68,0,85,0,81,513]

theorem envBound21783 : H12AffineFastState.Bounded env21783 := by
  intro p hp
  have h : env21783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21782_21783 : H12AffineEnvironment.transform 11 17 env21782 = env21783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21782 == env21783) = true)

theorem identity21783 : scanCanonicalize (H12AffineFastState.compose env21783 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound21783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21784 : List Nat := [2,4,8,16,0,64,8,85,512,69,65,17,8,0,0,2,16,65,69,1,80,1,16,3,8,65,65,17,16,65,68,0,85,0,81,513]

theorem envBound21784 : H12AffineFastState.Bounded env21784 := by
  intro p hp
  have h : env21784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21783_21784 : H12AffineEnvironment.transform 10 65 env21783 = env21784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env21783 == env21784) = true)

theorem identity21784 : scanCanonicalize (H12AffineFastState.compose env21784 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound21784 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21785 : List Nat := [2,4,8,16,0,64,8,85,81,69,65,17,8,0,0,2,16,65,69,1,80,1,16,3,8,65,65,17,16,65,68,0,85,0,81,80]

theorem envBound21785 : H12AffineFastState.Bounded env21785 := by
  intro p hp
  have h : env21785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21784_21785 : H12AffineEnvironment.transform 8 81 env21784 = env21785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env21784 == env21785) = true)

theorem identity21785 : scanCanonicalize (H12AffineFastState.compose env21785 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound21785 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21786 : List Nat := [2,4,8,16,0,10,8,31,27,15,11,17,8,0,0,2,16,11,15,1,26,1,16,3,8,11,11,17,16,11,14,0,31,0,27,26]

theorem envBound21786 : H12AffineFastState.Bounded env21786 := by
  intro p hp
  have h : env21786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21785_21786 : H12AffineEnvironment.transform 5 10 env21785 = env21786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env21785 == env21786) = true)

theorem identity21786 : scanCanonicalize (H12AffineFastState.compose env21786 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21786 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env21787 : List Nat := [2,4,2,16,0,0,2,21,17,5,1,17,2,0,0,2,16,1,5,1,16,1,16,3,2,1,1,17,16,1,4,0,21,0,17,16]

theorem envBound21787 : H12AffineFastState.Bounded env21787 := by
  intro p hp
  have h : env21787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21786_21787 : H12AffineEnvironment.transform 2 2 env21786 = env21787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21786 == env21787) = true)

def env21788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,4194304,16,98645,8193,65,4258941,5392,17664,32040,1365,4256861,256,21793,46092,74251]

theorem envBound21788 : H12AffineFastState.Bounded env21788 := by
  intro p hp
  have h : env21788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21772_21788 : H12AffineEnvironment.transform 6 9 env21772 = env21788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21772 == env21788) = true)

theorem identity21788 : scanCanonicalize (H12AffineFastState.compose env21788 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound21788 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,108926,1024,32769,4161,4194304,16,98645,8193,65,4258941,5392,17664,32040,1365,4256861,256,21793,46092,74251]

theorem envBound21789 : H12AffineFastState.Bounded env21789 := by
  intro p hp
  have h : env21789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21788_21789 : H12AffineEnvironment.transform 16 70726 env21788 = env21789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env21788 == env21789) = true)

theorem identity21789 : scanCanonicalize (H12AffineFastState.compose env21789 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound21789 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env21790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,70726,108926,1024,32769,4161,4194304,16,98645,8193,65,4229153,5392,12636,2420,1365,4227073,256,8573,46092,74251]

theorem envBound21790 : H12AffineFastState.Bounded env21790 := by
  intro p hp
  have h : env21790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21789_21790 : H12AffineEnvironment.transform 13 13404 env21789 = env21790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env21789 == env21790) = true)

theorem identity21790 : scanCanonicalize (H12AffineFastState.compose env21790 (packedSelected [3,4,5,9,10,11,12,14,16,18,23,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound21790 : packedSelected [3,4,5,9,10,11,12,14,16,18,23,32,38] rootPS < 2^1333 := by decide +kernel

def env21791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,372,65536,70726,75786,1024,373,4161,4194304,16,65569,8193,65,4196693,5392,12636,2420,1365,4194677,256,8573,13688,74251]

theorem envBound21791 : H12AffineFastState.Bounded env21791 := by
  intro p hp
  have h : env21791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21790_21791 : H12AffineEnvironment.transform 14 372 env21790 = env21791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env21790 == env21791) = true)

theorem identity21791 : scanCanonicalize (H12AffineFastState.compose env21791 (packedSelected [0,3,5,7,9,10,11,14,15,18,20,22,23,32,41] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound21791 : packedSelected [0,3,5,7,9,10,11,14,15,18,20,22,23,32,41] rootPS < 2^1333 := by decide +kernel

def env21792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,372,65536,70726,75786,1024,373,4161,8201,16,65569,8193,65,10588,5392,12636,2420,1365,8572,256,8573,13688,74251]

theorem envBound21792 : H12AffineFastState.Bounded env21792 := by
  intro p hp
  have h : env21792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21791_21792 : H12AffineEnvironment.transform 21 8201 env21791 = env21792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env21791 == env21792) = true)

theorem identity21792 : scanCanonicalize (H12AffineFastState.compose env21792 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound21792 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env21793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5237,372,65536,70726,67619,1024,373,4161,32,16,65569,40,65,2421,5392,4469,2420,1365,341,256,340,5457,66082]

theorem envBound21793 : H12AffineFastState.Bounded env21793 := by
  intro p hp
  have h : env21793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21792_21793 : H12AffineEnvironment.transform 12 41 env21792 = env21793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21792 == env21793) = true)

theorem identity21793 : scanCanonicalize (H12AffineFastState.compose env21793 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21793 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env21794 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,1,65536,70726,67619,1024,0,4161,32,16,65569,40,65,2048,5221,4096,2049,1056,32,117,33,5156,66082]

theorem envBound21794 : H12AffineFastState.Bounded env21794 := by
  intro p hp
  have h : env21794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21793_21794 : H12AffineEnvironment.transform 7 117 env21793 = env21794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21793 == env21794) = true)

theorem identity21794 : scanCanonicalize (H12AffineFastState.compose env21794 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound21794 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env21795 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,1,1094,4096,3173,1024,0,4161,32,16,1127,40,65,2048,5221,4096,2049,1056,32,117,33,5156,1636]

theorem envBound21795 : H12AffineFastState.Bounded env21795 := by
  intro p hp
  have h : env21795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21794_21795 : H12AffineEnvironment.transform 15 1094 env21794 = env21795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env21794 == env21795) = true)

def env21796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265168,23160256,257,27378861,27337992,25207750]

theorem envBound21796 : H12AffineFastState.Bounded env21796 := by
  intro p hp
  have h : env21796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21618_21796 : H12AffineEnvironment.transform 18 1025 env21618 = env21796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21618 == env21796) = true)

theorem identity21796 : scanCanonicalize (H12AffineFastState.compose env21796 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2444640) := by decide +kernel

theorem selectedBound21796 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2444640,8328,65,14847329,313836,10507601,8830977,10799472,4466848,257,8686029,8677480,10874534]

theorem envBound21797 : H12AffineFastState.Bounded env21797 := by
  intro p hp
  have h : env21797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21796_21797 : H12AffineEnvironment.transform 23 2444640 env21796 = env21797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444640 env21796 == env21797) = true)

def env21798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318700,2444640,8328,65,6705549,313836,2394557,138477,2102684,4466848,257,21793,46212,2175562]

theorem envBound21798 : H12AffineFastState.Bounded env21798 := by
  intro p hp
  have h : env21798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21797_21798 : H12AffineEnvironment.transform 22 318700 env21797 = env21798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318700 env21797 == env21798) = true)

def env21799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318700,466224,8328,65,4456925,313836,449005,138477,148940,4466848,257,21793,46212,221722]

theorem envBound21799 : H12AffineFastState.Bounded env21799 := by
  intro p hp
  have h : env21799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21798_21799 : H12AffineEnvironment.transform 20 151632 env21798 = env21799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env21798 == env21799) = true)

theorem identity21799 : scanCanonicalize (H12AffineFastState.compose env21799 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90258) := by decide +kernel

theorem selectedBound21799 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env21800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90258,262144,1025,32769,78018,4194304,318700,294306,8328,65,4456925,313836,375167,97407,75102,4466848,257,21793,46212,648]

theorem envBound21800 : H12AffineFastState.Bounded env21800 := by
  intro p hp
  have h : env21800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21799_21800 : H12AffineEnvironment.transform 16 90258 env21799 = env21800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90258 env21799 == env21800) = true)

def env21801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77898,4194304,318564,294186,8192,65,4456789,313700,375167,97407,75102,4466728,257,21793,46092,512]

theorem envBound21801 : H12AffineFastState.Bounded env21801 := by
  intro p hp
  have h : env21801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21800_21801 : H12AffineEnvironment.transform 6 8 env21800 = env21801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21800 == env21801) = true)

theorem identity21801 : scanCanonicalize (H12AffineFastState.compose env21801 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 130315) := by decide +kernel

theorem selectedBound21801 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,130315,1025,32769,77898,4194304,74095,98337,8192,65,4324446,78959,17524,97407,75102,4314403,257,21793,46092,512]

theorem envBound21802 : H12AffineFastState.Bounded env21802 := by
  intro p hp
  have h : env21802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21801_21802 : H12AffineEnvironment.transform 17 130315 env21801 = env21802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130315 env21801 == env21802) = true)

theorem identity21802 : scanCanonicalize (H12AffineFastState.compose env21802 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound21802 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5392,34817,1025,32769,17728,4194304,21605,62763,8192,65,4229460,16741,17524,2421,20564,4235305,257,21793,46092,512]

theorem envBound21803 : H12AffineFastState.Bounded env21803 := by
  intro p hp
  have h : env21803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21802_21803 : H12AffineEnvironment.transform 15 29962 env21802 = env21803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env21802 == env21803) = true)

theorem identity21803 : scanCanonicalize (H12AffineFastState.compose env21803 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 21761) := by decide +kernel

theorem selectedBound21803 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5392,34817,1025,32769,17728,21761,21605,62763,8192,65,56405,16741,17524,2421,20564,62760,257,21793,46092,512]

theorem envBound21804 : H12AffineFastState.Bounded env21804 := by
  intro p hp
  have h : env21804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21803_21804 : H12AffineEnvironment.transform 21 21761 env21803 = env21804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21761 env21803 == env21804) = true)

theorem identity21804 : scanCanonicalize (H12AffineFastState.compose env21804 (packedSelected [9,14,22] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound21804 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env21805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8200,29962,5392,10249,1025,8201,17728,21761,21605,21795,8192,65,31837,16741,17524,2421,20564,21792,257,21793,5124,512]

theorem envBound21805 : H12AffineFastState.Bounded env21805 := by
  intro p hp
  have h : env21805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21804_21805 : H12AffineEnvironment.transform 14 8200 env21804 = env21805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env21804 == env21805) = true)

theorem identity21805 : scanCanonicalize (H12AffineFastState.compose env21805 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound21805 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env21806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8200,8575,5392,10249,1025,8201,4405,372,16,342,8192,65,10280,5392,4097,2421,1057,341,257,340,5124,512]

theorem envBound21806 : H12AffineFastState.Bounded env21806 := by
  intro p hp
  have h : env21806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21805_21806 : H12AffineEnvironment.transform 13 5237 env21805 = env21806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env21805 == env21806) = true)

theorem identity21806 : scanCanonicalize (H12AffineFastState.compose env21806 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound21806 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5237,112,263,5392,2161,1025,113,4405,372,16,342,120,65,2128,5392,4097,2421,1057,341,257,340,5124,512]

theorem envBound21807 : H12AffineFastState.Bounded env21807 := by
  intro p hp
  have h : env21807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21806_21807 : H12AffineEnvironment.transform 12 120 env21806 = env21807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env21806 == env21807) = true)

theorem identity21807 : scanCanonicalize (H12AffineFastState.compose env21807 (packedSelected [0,1,2,4,8,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound21807 : packedSelected [0,1,2,4,8,11,14] rootPS < 2^1333 := by decide +kernel

def env21808 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,120,5237,112,82,5189,2161,1025,113,4192,33,16,3,120,65,2128,5189,4097,2080,1057,0,84,1,5124,512]

theorem envBound21808 : H12AffineFastState.Bounded env21808 := by
  intro p hp
  have h : env21808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21807_21808 : H12AffineEnvironment.transform 7 85 env21807 = env21808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env21807 == env21808) = true)

theorem identity21808 : scanCanonicalize (H12AffineFastState.compose env21808 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21808 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env21809 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,4096,89,5204,81,82,5189,2128,1025,80,4161,0,16,3,89,65,2128,5189,4097,2049,1024,0,84,1,5124,512]

theorem envBound21809 : H12AffineFastState.Bounded env21809 := by
  intro p hp
  have h : env21809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21808_21809 : H12AffineEnvironment.transform 4 1 env21808 = env21809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21808 == env21809) = true)

theorem identity21809 : scanCanonicalize (H12AffineFastState.compose env21809 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2138) := by decide +kernel

theorem selectedBound21809 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21810 : List Nat := [2,4,8,16,1,64,8,85,512,1024,2048,2138,89,3086,81,82,3103,2128,1025,80,2075,0,16,3,89,65,2128,3103,2139,2049,1024,0,84,1,3166,512]

theorem envBound21810 : H12AffineFastState.Bounded env21810 := by
  intro p hp
  have h : env21810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21809_21810 : H12AffineEnvironment.transform 11 2138 env21809 = env21810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2138 env21809 == env21810) = true)

theorem identity21810 : scanCanonicalize (H12AffineFastState.compose env21810 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21810 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env21811 : List Nat := [2,4,8,16,1,64,8,85,512,20,2048,2138,89,2074,81,82,2059,2128,21,80,2075,0,16,3,89,65,2128,2059,2139,2049,20,0,84,1,2122,512]

theorem envBound21811 : H12AffineFastState.Bounded env21811 := by
  intro p hp
  have h : env21811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21810_21811 : H12AffineEnvironment.transform 9 20 env21810 = env21811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21810 == env21811) = true)

theorem identity21811 : scanCanonicalize (H12AffineFastState.compose env21811 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound21811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21812 : List Nat := [2,0,8,16,1,64,8,81,512,16,2048,2138,89,2074,81,82,2059,2128,17,80,2075,0,16,3,89,65,2128,2059,2139,2049,16,0,80,1,2122,512]

theorem envBound21812 : H12AffineFastState.Bounded env21812 := by
  intro p hp
  have h : env21812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21811_21812 : H12AffineEnvironment.transform 1 0 env21811 = env21812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env21811 == env21812) = true)

theorem identity21812 : scanCanonicalize (H12AffineFastState.compose env21812 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound21812 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21813 : List Nat := [2,0,8,16,1,1,8,16,512,16,2048,2075,24,2074,16,19,2059,2065,17,17,2075,0,16,3,24,0,2065,2059,2074,2049,16,0,17,1,2059,512]

theorem envBound21813 : H12AffineFastState.Bounded env21813 := by
  intro p hp
  have h : env21813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21812_21813 : H12AffineEnvironment.transform 5 1 env21812 = env21813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env21812 == env21813) = true)

def env21814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,77899,4194304,318565,294187,8193,65,4456788,313701,375167,97407,75102,4466729,257,21793,46093,513]

theorem envBound21814 : H12AffineFastState.Bounded env21814 := by
  intro p hp
  have h : env21814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21800_21814 : H12AffineEnvironment.transform 6 9 env21800 = env21814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21800 == env21814) = true)

theorem identity21814 : scanCanonicalize (H12AffineFastState.compose env21814 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound21814 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,56436,1025,32769,77899,4194304,17,41311,8193,65,4250912,5393,91403,97407,75102,4256861,257,21793,46093,513]

theorem envBound21815 : H12AffineFastState.Bounded env21815 := by
  intro p hp
  have h : env21815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21814_21815 : H12AffineEnvironment.transform 17 56436 env21814 = env21815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env21814 == env21815) = true)

theorem identity21815 : scanCanonicalize (H12AffineFastState.compose env21815 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21815 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79130,35189,1025,32769,77899,4194304,17,41311,8193,65,4229153,5393,77834,76158,75102,4235612,257,32,46093,513]

theorem envBound21816 : H12AffineFastState.Bounded env21816 := by
  intro p hp
  have h : env21816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21815_21816 : H12AffineEnvironment.transform 13 5377 env21815 = env21816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21815 == env21816) = true)

theorem identity21816 : scanCanonicalize (H12AffineFastState.compose env21816 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21816 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env21817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,10280,1025,8540,77899,4194304,17,2,8193,65,4204924,5393,77834,76158,75102,4194305,257,32,5456,513]

theorem envBound21817 : H12AffineFastState.Bounded env21817 := by
  intro p hp
  have h : env21817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21816_21817 : H12AffineEnvironment.transform 14 8541 env21816 = env21817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21816 == env21817) = true)

theorem identity21817 : scanCanonicalize (H12AffineFastState.compose env21817 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21817 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,65536,70726,2420,1025,0,69911,4194304,17,2,349,65,4196384,5393,69974,67618,66562,4194305,257,32,5456,513]

theorem envBound21818 : H12AffineFastState.Bounded env21818 := by
  intro p hp
  have h : env21818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21817_21818 : H12AffineEnvironment.transform 12 348 env21817 = env21818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21817 == env21818) = true)

theorem identity21818 : scanCanonicalize (H12AffineFastState.compose env21818 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound21818 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env21819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5392,2420,1025,0,4161,4194304,17,2,349,65,4196384,5393,4096,2420,1364,4194305,257,32,5456,513]

theorem envBound21819 : H12AffineFastState.Bounded env21819 := by
  intro p hp
  have h : env21819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21818_21819 : H12AffineEnvironment.transform 15 342 env21818 = env21819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env21818 == env21819) = true)

theorem identity21819 : scanCanonicalize (H12AffineFastState.compose env21819 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound21819 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5392,2420,1025,0,4161,113,17,2,349,65,2129,5393,4096,2420,1364,112,257,32,5456,513]

theorem envBound21820 : H12AffineFastState.Bounded env21820 := by
  intro p hp
  have h : env21820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21819_21820 : H12AffineEnvironment.transform 21 113 env21819 = env21820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env21819 == env21820) = true)

def env21821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151633,4194304,318700,466225,8328,65,4456924,313836,449004,138477,148941,4466848,257,21793,46212,221723]

theorem envBound21821 : H12AffineFastState.Bounded env21821 := by
  intro p hp
  have h : env21821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21798_21821 : H12AffineEnvironment.transform 20 151633 env21798 = env21821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env21798 == env21821) = true)

theorem identity21821 : scanCanonicalize (H12AffineFastState.compose env21821 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound21821 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env21822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,77899,4194304,318700,294187,8328,65,4456924,313836,375286,97527,75223,4466848,257,21793,46212,513]

theorem envBound21822 : H12AffineFastState.Bounded env21822 := by
  intro p hp
  have h : env21822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21821_21822 : H12AffineEnvironment.transform 16 90138 env21821 = env21822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env21821 == env21822) = true)

def env21823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,262144,1025,29909,77899,4194304,272440,294187,8328,65,4456924,277816,347426,97527,75223,4466848,257,21793,16464,513]

theorem envBound21823 : H12AffineFastState.Bounded env21823 := by
  intro p hp
  have h : env21823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21822_21823 : H12AffineEnvironment.transform 14 29908 env21822 = env21823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env21822 == env21823) = true)

def env21824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,262144,1025,29909,77899,272512,272440,294187,8328,65,10588,277816,347426,97527,75223,32,257,21793,16464,513]

theorem envBound21824 : H12AffineFastState.Bounded env21824 := by
  intro p hp
  have h : env21824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21823_21824 : H12AffineEnvironment.transform 21 272512 env21823 = env21824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21823 == env21824) = true)

theorem identity21824 : scanCanonicalize (H12AffineFastState.compose env21824 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21824 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,16400,262144,1025,29909,4161,272512,272440,294187,8328,65,10588,277816,290088,23805,1501,32,257,21793,16464,513]

theorem envBound21825 : H12AffineFastState.Bounded env21825 := by
  intro p hp
  have h : env21825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21824_21825 : H12AffineEnvironment.transform 15 8202 env21824 = env21825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21824 == env21825) = true)

theorem identity21825 : scanCanonicalize (H12AffineFastState.compose env21825 (packedSelected [7,11,14,18,20,23,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound21825 : packedSelected [7,11,14,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env21826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8581,8202,5441,262144,1025,8580,4161,272512,272440,272506,8328,65,10588,277816,276601,2476,1501,32,257,112,5377,513]

theorem envBound21826 : H12AffineFastState.Bounded env21826 := by
  intro p hp
  have h : env21826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21825_21826 : H12AffineEnvironment.transform 13 5457 env21825 = env21826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env21825 == env21826) = true)

theorem identity21826 : scanCanonicalize (H12AffineFastState.compose env21826 (packedSelected [1,2,4,5,6,8,9,14,15,17,18,20,23,24,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21826 : packedSelected [1,2,4,5,6,8,9,14,15,17,18,20,23,24,38] rootPS < 2^1333 := by decide +kernel

def env21827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5457,217,342,5441,262144,1025,216,4161,264668,264548,264486,468,65,2048,269412,268581,2476,1501,32,257,112,5377,513]

theorem envBound21827 : H12AffineFastState.Bounded env21827 := by
  intro p hp
  have h : env21827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21826_21827 : H12AffineEnvironment.transform 12 348 env21826 = env21827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21826 == env21827) = true)

theorem identity21827 : scanCanonicalize (H12AffineFastState.compose env21827 (packedSelected [0,4,6,10,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound21827 : packedSelected [0,4,6,10,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env21828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2357,348,3172,217,342,3188,262144,1025,216,2420,264668,264548,264486,468,65,2048,263505,262160,2476,1501,32,257,112,3124,513]

theorem envBound21828 : H12AffineFastState.Bounded env21828 := by
  intro p hp
  have h : env21828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21827_21828 : H12AffineEnvironment.transform 11 2357 env21827 = env21828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env21827 == env21828) = true)

theorem identity21828 : scanCanonicalize (H12AffineFastState.compose env21828 (packedSelected [0,1,2,7,8,11,12,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 372) := by decide +kernel

theorem selectedBound21828 : packedSelected [0,1,2,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env21829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2357,348,3172,217,342,3188,372,1025,216,2420,2216,2064,2130,468,65,2048,1061,356,2476,1501,32,257,112,3124,513]

theorem envBound21829 : H12AffineFastState.Bounded env21829 := by
  intro p hp
  have h : env21829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21828_21829 : H12AffineEnvironment.transform 17 372 env21828 = env21829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 372 env21828 == env21829) = true)

theorem identity21829 : scanCanonicalize (H12AffineFastState.compose env21829 (packedSelected [1,4,6,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound21829 : packedSelected [1,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env21830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,509,200,348,1433,217,342,1417,372,1025,216,137,341,493,431,468,65,509,1061,356,81,1501,32,257,112,1481,513]

theorem envBound21830 : H12AffineFastState.Bounded env21830 := by
  intro p hp
  have h : env21830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21829_21830 : H12AffineEnvironment.transform 10 509 env21829 = env21830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env21829 == env21830) = true)

def env21831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,262144,1025,29909,77899,272513,272440,294187,8328,65,10589,277816,347426,97527,75223,33,257,21793,16464,513]

theorem envBound21831 : H12AffineFastState.Bounded env21831 := by
  intro p hp
  have h : env21831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21823_21831 : H12AffineEnvironment.transform 21 272513 env21823 = env21831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21823 == env21831) = true)

theorem identity21831 : scanCanonicalize (H12AffineFastState.compose env21831 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound21831 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90138,67619,1025,29909,77899,73890,73755,95496,8328,65,10589,79131,17665,97527,75223,33,257,21793,16464,513]

theorem envBound21832 : H12AffineFastState.Bounded env21832 := by
  intro p hp
  have h : env21832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21831_21832 : H12AffineEnvironment.transform 17 67619 env21831 = env21832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env21831 == env21832) = true)

def env21833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90138,67619,1025,29789,77899,73770,73755,95496,8192,65,10589,79131,17665,97407,75103,33,257,21793,16464,513]

theorem envBound21833 : H12AffineFastState.Bounded env21833 := by
  intro p hp
  have h : env21833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21832_21833 : H12AffineEnvironment.transform 6 8 env21832 = env21833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21832 == env21833) = true)

theorem identity21833 : scanCanonicalize (H12AffineFastState.compose env21833 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound21833 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5392,32041,1025,29789,17729,21792,21777,2,8192,65,10589,16401,17665,2421,20565,33,257,21793,16464,513]

theorem envBound21834 : H12AffineFastState.Bounded env21834 := by
  intro p hp
  have h : env21834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21833_21834 : H12AffineEnvironment.transform 15 29962 env21833 = env21834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env21833 == env21834) = true)

theorem identity21834 : scanCanonicalize (H12AffineFastState.compose env21834 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound21834 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8282,5392,10361,1025,8461,4113,112,65,2,8192,65,10589,5441,4177,2421,1285,33,257,113,5376,513]

theorem envBound21835 : H12AffineFastState.Bounded env21835 := by
  intro p hp
  have h : env21835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21834_21835 : H12AffineEnvironment.transform 13 5456 env21834 = env21835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env21834 == env21835) = true)

theorem identity21835 : scanCanonicalize (H12AffineFastState.compose env21835 (packedSelected [0,1,4,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound21835 : packedSelected [0,1,4,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env21836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,8192,3345,8460,8282,3409,10361,1025,8461,2128,112,65,2,8192,65,10589,3328,2064,2421,1285,33,257,113,3393,513]

theorem envBound21836 : H12AffineFastState.Bounded env21836 := by
  intro p hp
  have h : env21836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21835_21836 : H12AffineEnvironment.transform 11 2113 env21835 = env21836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env21835 == env21836) = true)

theorem identity21836 : scanCanonicalize (H12AffineFastState.compose env21836 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21836 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env21837 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2113,8192,2340,8460,8282,2404,10361,52,8461,2128,112,65,2,8192,65,10589,2357,2064,2421,304,33,257,113,2420,513]

theorem envBound21837 : H12AffineFastState.Bounded env21837 := by
  intro p hp
  have h : env21837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21836_21837 : H12AffineEnvironment.transform 9 53 env21836 = env21837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21836 == env21837) = true)

theorem identity21837 : scanCanonicalize (H12AffineFastState.compose env21837 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound21837 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env21838 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2113,120,2340,372,34,2404,2049,52,373,2128,112,65,2,120,65,2341,2357,2064,2421,304,33,257,113,2420,513]

theorem envBound21838 : H12AffineFastState.Bounded env21838 := by
  intro p hp
  have h : env21838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21837_21838 : H12AffineEnvironment.transform 12 120 env21837 = env21838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env21837 == env21838) = true)

theorem identity21838 : scanCanonicalize (H12AffineFastState.compose env21838 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound21838 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21839 : List Nat := [2,4,8,16,32,64,8,256,512,53,293,356,120,1,372,34,65,292,52,373,373,112,65,2,120,65,0,16,309,80,304,33,257,113,81,513]

theorem envBound21839 : H12AffineFastState.Bounded env21839 := by
  intro p hp
  have h : env21839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21838_21839 : H12AffineEnvironment.transform 10 293 env21838 = env21839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env21838 == env21839) = true)

theorem identity21839 : scanCanonicalize (H12AffineFastState.compose env21839 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21839 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21840 : List Nat := [2,4,8,16,32,17,8,256,512,53,293,309,41,1,293,34,16,292,52,292,292,33,16,2,41,16,0,16,309,1,304,33,257,32,0,513]

theorem envBound21840 : H12AffineFastState.Bounded env21840 := by
  intro p hp
  have h : env21840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21839_21840 : H12AffineEnvironment.transform 5 17 env21839 = env21840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21839 == env21840) = true)

theorem identity21840 : scanCanonicalize (H12AffineFastState.compose env21840 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21840 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21841 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,16,41,1,0,34,16,1,52,1,1,33,16,2,41,16,0,16,16,1,21,33,36,32,0,513]

theorem envBound21841 : H12AffineFastState.Bounded env21841 := by
  intro p hp
  have h : env21841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21840_21841 : H12AffineEnvironment.transform 7 37 env21840 = env21841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21840 == env21841) = true)

theorem identity21841 : scanCanonicalize (H12AffineFastState.compose env21841 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound21841 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21842 : List Nat := [2,4,8,16,32,17,8,37,0,53,0,16,41,1,0,34,16,1,52,1,1,33,16,2,41,16,0,16,16,1,21,33,36,32,0,1]

theorem envBound21842 : H12AffineFastState.Bounded env21842 := by
  intro p hp
  have h : env21842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21841_21842 : H12AffineEnvironment.transform 8 0 env21841 = env21842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21841 == env21842) = true)

theorem identity21842 : scanCanonicalize (H12AffineFastState.compose env21842 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound21842 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21843 : List Nat := [2,4,8,16,27,17,8,30,0,14,0,16,18,1,0,25,16,1,15,1,1,26,16,2,18,16,0,16,16,1,21,26,31,27,0,1]

theorem envBound21843 : H12AffineFastState.Bounded env21843 := by
  intro p hp
  have h : env21843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21842_21843 : H12AffineEnvironment.transform 4 27 env21842 = env21843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env21842 == env21843) = true)

def env21844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,67619,1025,29788,77899,73771,73755,95496,8193,65,10589,79131,17665,97406,75102,33,257,21793,16464,513]

theorem envBound21844 : H12AffineFastState.Bounded env21844 := by
  intro p hp
  have h : env21844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21832_21844 : H12AffineEnvironment.transform 6 9 env21832 = env21844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21832 == env21844) = true)

theorem identity21844 : scanCanonicalize (H12AffineFastState.compose env21844 (packedSelected [2,6,7,14,18,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21844 : packedSelected [2,6,7,14,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env21845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21841,65536,82198,67619,1025,21840,69959,65831,65815,87044,269,65,2129,70679,17665,89458,66642,33,257,21793,16464,513]

theorem envBound21845 : H12AffineFastState.Bounded env21845 := by
  intro p hp
  have h : env21845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21844_21845 : H12AffineEnvironment.transform 12 268 env21844 = env21845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21844 == env21845) = true)

theorem identity21845 : scanCanonicalize (H12AffineFastState.compose env21845 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound21845 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21841,262,16400,2341,1025,21840,4161,33,17,21762,269,65,2129,5393,17665,23668,1364,33,257,21793,16464,513]

theorem envBound21846 : H12AffineFastState.Bounded env21846 := by
  intro p hp
  have h : env21846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21845_21846 : H12AffineEnvironment.transform 15 262 env21845 = env21846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env21845 == env21846) = true)

theorem identity21846 : scanCanonicalize (H12AffineFastState.compose env21846 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21846 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21847 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,268,16384,20544,262,16400,2341,272,20545,4161,33,17,20499,269,65,2129,4096,16400,22885,69,33,257,20528,16464,513]

theorem envBound21847 : H12AffineFastState.Bounded env21847 := by
  intro p hp
  have h : env21847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21846_21847 : H12AffineEnvironment.transform 9 273 env21846 = env21847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21846 == env21847) = true)

theorem identity21847 : scanCanonicalize (H12AffineFastState.compose env21847 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound21847 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21848 : List Nat := [2,4,8,16,32,64,9,256,512,273,789,4096,268,16384,20544,262,16400,560,272,20545,4161,33,17,20499,269,65,836,4096,16400,21104,69,33,257,20528,16464,513]

theorem envBound21848 : H12AffineFastState.Bounded env21848 := by
  intro p hp
  have h : env21848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21847_21848 : H12AffineEnvironment.transform 10 789 env21847 = env21848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env21847 == env21848) = true)

theorem identity21848 : scanCanonicalize (H12AffineFastState.compose env21848 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21848 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21849 : List Nat := [2,4,8,16,32,64,9,117,512,100,608,4096,121,16384,20544,115,16400,560,101,20545,4161,33,17,20499,120,65,561,4096,16400,21104,69,33,116,20528,16464,513]

theorem envBound21849 : H12AffineFastState.Bounded env21849 := by
  intro p hp
  have h : env21849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21848_21849 : H12AffineEnvironment.transform 7 117 env21848 = env21849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21848 == env21849) = true)

theorem identity21849 : scanCanonicalize (H12AffineFastState.compose env21849 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4193) := by decide +kernel

theorem selectedBound21849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21850 : List Nat := [2,4,8,16,32,64,9,117,512,100,608,4096,121,4193,33,115,4209,560,101,32,4161,33,17,114,120,65,561,4096,4209,529,69,33,116,81,4145,513]

theorem envBound21850 : H12AffineFastState.Bounded env21850 := by
  intro p hp
  have h : env21850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21849_21850 : H12AffineEnvironment.transform 13 4193 env21849 = env21850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4193 env21849 == env21850) = true)

theorem identity21850 : scanCanonicalize (H12AffineFastState.compose env21850 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21850 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env21851 : List Nat := [2,4,8,16,32,17,9,36,512,53,561,4096,40,4144,33,34,4128,560,52,32,4112,33,17,35,41,16,561,4096,4128,529,20,33,37,0,4145,513]

theorem envBound21851 : H12AffineFastState.Bounded env21851 := by
  intro p hp
  have h : env21851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21850_21851 : H12AffineEnvironment.transform 5 17 env21850 = env21851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21850 == env21851) = true)

theorem identity21851 : scanCanonicalize (H12AffineFastState.compose env21851 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound21851 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env21852 : List Nat := [2,4,8,16,32,17,9,36,512,53,561,560,40,512,33,34,528,560,52,32,544,33,17,35,41,16,561,560,528,529,20,33,37,0,513,513]

theorem envBound21852 : H12AffineFastState.Bounded env21852 := by
  intro p hp
  have h : env21852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21851_21852 : H12AffineEnvironment.transform 11 560 env21851 = env21852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env21851 == env21852) = true)

theorem identity21852 : scanCanonicalize (H12AffineFastState.compose env21852 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21852 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env21853 : List Nat := [2,4,8,16,1,17,9,5,512,20,528,529,9,512,0,3,528,529,21,1,513,0,17,2,8,16,528,529,528,529,20,0,4,0,513,513]

theorem envBound21853 : H12AffineFastState.Bounded env21853 := by
  intro p hp
  have h : env21853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21852_21853 : H12AffineEnvironment.transform 4 1 env21852 = env21853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21852 == env21853) = true)

theorem identity21853 : scanCanonicalize (H12AffineFastState.compose env21853 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21854 : List Nat := [2,4,3,16,1,17,2,5,512,20,528,529,2,512,0,3,528,529,21,1,513,0,17,2,3,16,528,529,528,529,20,0,4,0,513,513]

theorem envBound21854 : H12AffineFastState.Bounded env21854 := by
  intro p hp
  have h : env21854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21853_21854 : H12AffineEnvironment.transform 2 3 env21853 = env21854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21853 == env21854) = true)

def env21855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,262144,1025,29908,77899,4194304,272441,294187,8328,65,4456924,277817,347427,97527,75223,4466848,257,21793,16465,513]

theorem envBound21855 : H12AffineFastState.Bounded env21855 := by
  intro p hp
  have h : env21855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21822_21855 : H12AffineEnvironment.transform 14 29909 env21822 = env21855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env21822 == env21855) = true)

def env21856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,262144,1025,29908,77899,272512,272441,294187,8328,65,10588,277817,347427,97527,75223,32,257,21793,16465,513]

theorem envBound21856 : H12AffineFastState.Bounded env21856 := by
  intro p hp
  have h : env21856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21855_21856 : H12AffineEnvironment.transform 21 272512 env21855 = env21856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21855 == env21856) = true)

theorem identity21856 : scanCanonicalize (H12AffineFastState.compose env21856 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21856 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,10280,1025,29908,77899,168,17,21763,8328,65,10588,5393,91403,97527,75223,32,257,21793,16465,513]

theorem envBound21857 : H12AffineFastState.Bounded env21857 := by
  intro p hp
  have h : env21857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21856_21857 : H12AffineEnvironment.transform 17 10280 env21856 = env21857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21856 == env21857) = true)

theorem identity21857 : scanCanonicalize (H12AffineFastState.compose env21857 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21857 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env21858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,65536,82246,2420,1025,21896,69911,168,17,21763,468,65,2048,5393,83031,89515,66699,32,257,21793,16465,513]

theorem envBound21858 : H12AffineFastState.Bounded env21858 := by
  intro p hp
  have h : env21858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21857_21858 : H12AffineEnvironment.transform 12 348 env21857 = env21858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21857 == env21858) = true)

theorem identity21858 : scanCanonicalize (H12AffineFastState.compose env21858 (packedSelected [0,2,4,6,9,20,23,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound21858 : packedSelected [0,2,4,6,9,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env21859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5512,1,65536,70862,2420,1025,0,69911,168,17,139,468,65,2048,5393,70111,67619,66699,32,257,169,5593,513]

theorem envBound21859 : H12AffineFastState.Bounded env21859 := by
  intro p hp
  have h : env21859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21858_21859 : H12AffineEnvironment.transform 13 5512 env21858 = env21859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env21858 == env21859) = true)

theorem identity21859 : scanCanonicalize (H12AffineFastState.compose env21859 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21859 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,65536,70727,2420,1025,0,69911,33,17,2,349,65,2048,5393,69974,67619,66562,32,257,32,5456,513]

theorem envBound21860 : H12AffineFastState.Bounded env21860 := by
  intro p hp
  have h : env21860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21859_21860 : H12AffineEnvironment.transform 6 9 env21859 = env21860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21859 == env21860) = true)

theorem identity21860 : scanCanonicalize (H12AffineFastState.compose env21860 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound21860 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env21861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5392,2420,1025,0,4160,33,17,2,349,65,2048,5393,4097,2420,1365,32,257,32,5456,513]

theorem envBound21861 : H12AffineFastState.Bounded env21861 := by
  intro p hp
  have h : env21861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21860_21861 : H12AffineEnvironment.transform 15 343 env21860 = env21861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env21860 == env21861) = true)

theorem identity21861 : scanCanonicalize (H12AffineFastState.compose env21861 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound21861 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21862 : List Nat := [2,4,8,16,32,64,9,256,512,612,2048,4096,348,4965,1,343,4980,2420,613,0,4160,33,17,2,349,65,2048,4981,4097,2420,817,32,257,32,4916,513]

theorem envBound21862 : H12AffineFastState.Bounded env21862 := by
  intro p hp
  have h : env21862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21861_21862 : H12AffineEnvironment.transform 9 612 env21861 = env21862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env21861 == env21862) = true)

def env21863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,262144,1025,29908,77899,272513,272441,294187,8328,65,10589,277817,347427,97527,75223,33,257,21793,16465,513]

theorem envBound21863 : H12AffineFastState.Bounded env21863 := by
  intro p hp
  have h : env21863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21855_21863 : H12AffineEnvironment.transform 21 272513 env21855 = env21863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21855 == env21863) = true)

def env21864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,32160,1025,29908,77899,21793,21913,139,8328,65,10589,16537,77955,97527,75223,33,257,21793,16465,513]

theorem envBound21864 : H12AffineFastState.Bounded env21864 := by
  intro p hp
  have h : env21864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21863_21864 : H12AffineEnvironment.transform 17 32160 env21863 = env21864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env21863 == env21864) = true)

theorem identity21864 : scanCanonicalize (H12AffineFastState.compose env21864 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound21864 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79131,10401,1025,8661,77899,32,152,139,8328,65,10589,5528,77955,76278,75223,33,257,32,5456,513]

theorem envBound21865 : H12AffineFastState.Bounded env21865 := by
  intro p hp
  have h : env21865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21864_21865 : H12AffineEnvironment.transform 13 5377 env21864 = env21865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21864 == env21865) = true)

theorem identity21865 : scanCanonicalize (H12AffineFastState.compose env21865 (packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21865 : packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env21866 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8581,65536,79131,10401,1025,8580,77850,32,152,139,8328,16,10508,5528,77955,76199,75142,33,257,32,5377,513]

theorem envBound21866 : H12AffineFastState.Bounded env21866 := by
  intro p hp
  have h : env21866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21865_21866 : H12AffineEnvironment.transform 5 17 env21865 = env21866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21865 == env21866) = true)

theorem identity21866 : scanCanonicalize (H12AffineFastState.compose env21866 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21866 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21867 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,137,65536,70679,2477,1025,136,69910,32,152,139,388,16,2048,5528,70031,67755,66698,33,257,32,5377,513]

theorem envBound21867 : H12AffineFastState.Bounded env21867 := by
  intro p hp
  have h : env21867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21866_21867 : H12AffineEnvironment.transform 12 268 env21866 = env21867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21866 == env21867) = true)

theorem identity21867 : scanCanonicalize (H12AffineFastState.compose env21867 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(15+1) ^^^ 1183) := by decide +kernel

theorem selectedBound21867 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env21868 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,137,1183,4232,2477,1025,136,5513,32,152,139,388,16,2048,5528,5392,3124,21,33,257,32,5377,513]

theorem envBound21868 : H12AffineFastState.Bounded env21868 := by
  intro p hp
  have h : env21868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21867_21868 : H12AffineEnvironment.transform 15 1183 env21867 = env21868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1183 env21867 == env21868) = true)

theorem identity21868 : scanCanonicalize (H12AffineFastState.compose env21868 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound21868 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env21869 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,268,4112,137,398,4232,2477,272,136,4248,32,152,139,388,16,2048,4233,4097,2341,21,33,257,32,4112,513]

theorem envBound21869 : H12AffineFastState.Bounded env21869 := by
  intro p hp
  have h : env21869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21868_21869 : H12AffineEnvironment.transform 9 273 env21868 = env21869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21868 == env21869) = true)

theorem identity21869 : scanCanonicalize (H12AffineFastState.compose env21869 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21869 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21870 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,0,263,4097,2340,272,1,4113,32,17,2,269,16,2048,4096,4097,2341,21,33,257,32,4112,513]

theorem envBound21870 : H12AffineFastState.Bounded env21870 := by
  intro p hp
  have h : env21870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21869_21870 : H12AffineEnvironment.transform 6 9 env21869 = env21870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21869 == env21870) = true)

theorem identity21870 : scanCanonicalize (H12AffineFastState.compose env21870 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound21870 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21871 : List Nat := [2,4,8,16,32,17,9,52,512,37,2048,4096,56,4112,0,51,4097,2064,36,1,4113,32,17,2,57,16,2048,4096,4097,2065,21,33,53,32,4112,513]

theorem envBound21871 : H12AffineFastState.Bounded env21871 := by
  intro p hp
  have h : env21871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21870_21871 : H12AffineEnvironment.transform 7 52 env21870 = env21871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env21870 == env21871) = true)

theorem identity21871 : scanCanonicalize (H12AffineFastState.compose env21871 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound21871 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21872 : List Nat := [2,4,8,16,32,17,9,52,512,37,2048,554,56,570,0,51,555,2064,36,1,571,32,17,2,57,16,2048,554,555,2065,21,33,53,32,570,513]

theorem envBound21872 : H12AffineFastState.Bounded env21872 := by
  intro p hp
  have h : env21872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21871_21872 : H12AffineEnvironment.transform 11 554 env21871 = env21872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env21871 == env21872) = true)

theorem identity21872 : scanCanonicalize (H12AffineFastState.compose env21872 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound21872 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21873 : List Nat := [2,4,8,16,10,17,9,30,512,15,2048,512,18,528,0,25,513,2064,14,1,529,10,17,2,19,16,2048,512,513,2065,21,11,31,10,528,513]

theorem envBound21873 : H12AffineFastState.Bounded env21873 := by
  intro p hp
  have h : env21873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21872_21873 : H12AffineEnvironment.transform 4 10 env21872 = env21873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env21872 == env21873) = true)

theorem identity21873 : scanCanonicalize (H12AffineFastState.compose env21873 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21873 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21874 : List Nat := [2,4,8,16,10,17,9,30,512,15,1,512,18,528,0,25,513,17,14,1,529,10,17,2,19,16,1,512,513,16,21,11,31,10,528,513]

theorem envBound21874 : H12AffineFastState.Bounded env21874 := by
  intro p hp
  have h : env21874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21873_21874 : H12AffineEnvironment.transform 10 1 env21873 = env21874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21873 == env21874) = true)

def env21875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,32161,1025,29908,77899,21792,21912,138,8328,65,10589,16536,77954,97527,75223,33,257,21793,16465,513]

theorem envBound21875 : H12AffineFastState.Bounded env21875 := by
  intro p hp
  have h : env21875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21863_21875 : H12AffineEnvironment.transform 17 32161 env21863 = env21875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env21863 == env21875) = true)

theorem identity21875 : scanCanonicalize (H12AffineFastState.compose env21875 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound21875 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,65536,79251,10280,1025,8541,77899,169,17,138,8328,65,10589,5393,77954,76158,75223,33,257,168,5592,513]

theorem envBound21876 : H12AffineFastState.Bounded env21876 := by
  intro p hp
  have h : env21876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21875_21876 : H12AffineEnvironment.transform 13 5513 env21875 = env21876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env21875 == env21876) = true)

theorem identity21876 : scanCanonicalize (H12AffineFastState.compose env21876 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound21876 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env21877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,478,13389,10280,1025,8541,12693,169,17,138,8328,65,10589,5393,12636,10400,9225,33,257,168,5592,513]

theorem envBound21877 : H12AffineFastState.Bounded env21877 := by
  intro p hp
  have h : env21877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21876_21877 : H12AffineEnvironment.transform 15 478 env21876 = env21877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env21876 == env21877) = true)

theorem identity21877 : scanCanonicalize (H12AffineFastState.compose env21877 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound21877 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env21878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,478,5529,2556,1025,137,4161,169,17,138,348,65,2185,5393,4232,2420,1501,33,257,168,5592,513]

theorem envBound21878 : H12AffineFastState.Bounded env21878 := by
  intro p hp
  have h : env21878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21877_21878 : H12AffineEnvironment.transform 12 468 env21877 = env21878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env21877 == env21878) = true)

theorem identity21878 : scanCanonicalize (H12AffineFastState.compose env21878 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21878 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21879 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,136,398,5529,2476,1025,137,4113,169,17,138,268,17,2185,5393,4232,2340,1421,33,257,168,5512,513]

theorem envBound21879 : H12AffineFastState.Bounded env21879 := by
  intro p hp
  have h : env21879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21878_21879 : H12AffineEnvironment.transform 5 16 env21878 = env21879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21878 == env21879) = true)

theorem identity21879 : scanCanonicalize (H12AffineFastState.compose env21879 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1165) := by decide +kernel

theorem selectedBound21879 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21880 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1165,388,260,136,398,276,2476,1025,137,1180,169,17,138,268,17,2185,412,1029,2340,1421,33,257,168,261,513]

theorem envBound21880 : H12AffineFastState.Bounded env21880 := by
  intro p hp
  have h : env21880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21879_21880 : H12AffineEnvironment.transform 11 1165 env21879 = env21880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1165 env21879 == env21880) = true)

theorem identity21880 : scanCanonicalize (H12AffineFastState.compose env21880 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1181) := by decide +kernel

theorem selectedBound21880 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env21881 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1181,1165,388,260,136,398,276,1329,1025,137,1180,169,17,138,268,17,1044,412,1029,1465,1421,33,257,168,261,513]

theorem envBound21881 : H12AffineFastState.Bounded env21881 := by
  intro p hp
  have h : env21881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21880_21881 : H12AffineEnvironment.transform 10 1181 env21880 = env21881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1181 env21880 == env21881) = true)

theorem identity21881 : scanCanonicalize (H12AffineFastState.compose env21881 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound21881 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env21882 : List Nat := [2,4,8,16,32,16,128,256,512,516,665,649,388,260,136,398,276,821,517,137,664,169,17,138,268,17,528,412,513,957,905,33,257,168,261,513]

theorem envBound21882 : H12AffineFastState.Bounded env21882 := by
  intro p hp
  have h : env21882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21881_21882 : H12AffineEnvironment.transform 9 516 env21881 = env21882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env21881 == env21882) = true)

theorem identity21882 : scanCanonicalize (H12AffineFastState.compose env21882 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21882 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env21883 : List Nat := [2,4,8,16,32,16,128,37,512,516,665,649,161,33,136,171,49,528,517,137,664,169,17,138,41,17,528,185,513,664,684,33,36,168,32,513]

theorem envBound21883 : H12AffineFastState.Bounded env21883 := by
  intro p hp
  have h : env21883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21882_21883 : H12AffineEnvironment.transform 7 37 env21882 = env21883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21882 == env21883) = true)

theorem identity21883 : scanCanonicalize (H12AffineFastState.compose env21883 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21883 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21884 : List Nat := [2,4,8,16,1,16,128,4,512,516,665,649,128,0,136,138,16,528,517,137,664,136,17,138,8,17,528,152,513,664,653,0,5,137,1,513]

theorem envBound21884 : H12AffineFastState.Bounded env21884 := by
  intro p hp
  have h : env21884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21883_21884 : H12AffineEnvironment.transform 4 1 env21883 = env21884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21883 == env21884) = true)

theorem identity21884 : scanCanonicalize (H12AffineFastState.compose env21884 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound21884 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21885 : List Nat := [2,4,8,16,1,16,128,4,0,4,153,137,128,0,136,138,16,16,5,137,152,136,17,138,8,17,16,152,1,152,141,0,5,137,1,1]

theorem envBound21885 : H12AffineFastState.Bounded env21885 := by
  intro p hp
  have h : env21885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21884_21885 : H12AffineEnvironment.transform 8 0 env21884 = env21885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21884 == env21885) = true)

def env21886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,318701,2444640,8328,65,6705548,313836,2394556,138476,2102685,4466848,257,21792,46213,2175563]

theorem envBound21886 : H12AffineFastState.Bounded env21886 := by
  intro p hp
  have h : env21886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21797_21886 : H12AffineEnvironment.transform 22 318701 env21797 = env21886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 318701 env21797 == env21886) = true)

def env21887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,4194304,318701,466224,8328,65,4456924,313836,449004,138476,148941,4466848,257,21792,46213,221723]

theorem envBound21887 : H12AffineFastState.Bounded env21887 := by
  intro p hp
  have h : env21887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21886_21887 : H12AffineEnvironment.transform 20 151632 env21886 = env21887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env21886 == env21887) = true)

def env21888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,147640,318701,466224,8328,65,409956,313836,449004,138476,148941,419864,257,21792,46213,221723]

theorem envBound21888 : H12AffineFastState.Bounded env21888 := by
  intro p hp
  have h : env21888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21887_21888 : H12AffineEnvironment.transform 21 147640 env21887 = env21888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147640 env21887 == env21888) = true)

def env21889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,168,318701,351520,8328,65,262516,313836,301564,23804,1501,272392,257,21792,46213,74251]

theorem envBound21889 : H12AffineFastState.Bounded env21889 := by
  intro p hp
  have h : env21889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21888_21889 : H12AffineEnvironment.transform 16 16400 env21888 = env21889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env21888 == env21889) = true)

def env21890 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,168,318701,351452,8328,65,262280,313360,301056,23804,1057,272392,253,21724,46213,74251]

theorem envBound21890 : H12AffineFastState.Bounded env21890 := by
  intro p hp
  have h : env21890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21889_21890 : H12AffineEnvironment.transform 7 252 env21889 = env21890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env21889 == env21890) = true)

def env21891 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,112,318517,351236,8272,65,262224,313360,301056,23588,1057,272392,37,21508,46173,74251]

theorem envBound21891 : H12AffineFastState.Bounded env21891 := by
  intro p hp
  have h : env21891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21890_21891 : H12AffineEnvironment.transform 6 88 env21890 = env21891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env21890 == env21891) = true)

theorem identity21891 : scanCanonicalize (H12AffineFastState.compose env21891 (packedSelected [0,2,5,6,11,12,14,15,17,18,19,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 67698) := by decide +kernel

theorem selectedBound21891 : packedSelected [0,2,5,6,11,12,14,15,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env21892 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,8192,16384,32768,65536,16400,67698,1025,32769,4160,112,119879,21622,8272,65,67618,114786,102514,23588,1057,73850,37,21508,46173,74251]

theorem envBound21892 : H12AffineFastState.Bounded env21892 := by
  intro p hp
  have h : env21892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21891_21892 : H12AffineEnvironment.transform 17 67698 env21891 = env21892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67698 env21891 == env21892) = true)

theorem identity21892 : scanCanonicalize (H12AffineFastState.compose env21892 (packedSelected [0,2,3,4,6,7,9,10,12,14,15,17,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 61515) := by decide +kernel

theorem selectedBound21892 : packedSelected [0,2,3,4,6,7,9,10,12,14,15,17,19,24] rootPS < 2^1333 := by decide +kernel

def env21893 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,8192,16384,32768,61515,16400,63545,1025,32769,4160,112,9228,21622,8272,65,63593,12329,24633,23588,1057,53297,37,21508,46173,53824]

theorem envBound21893 : H12AffineFastState.Bounded env21893 := by
  intro p hp
  have h : env21893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21892_21893 : H12AffineEnvironment.transform 15 61515 env21892 = env21893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61515 env21892 == env21893) = true)

theorem identity21893 : scanCanonicalize (H12AffineFastState.compose env21893 (packedSelected [0,7,9,11,14,17,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound21893 : packedSelected [0,7,9,11,14,17,20,22,23] rootPS < 2^1333 := by decide +kernel

def env21894 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,8192,16384,1077,29822,16400,31756,1025,1076,4160,112,9228,21622,8272,65,31836,12329,24633,23588,1057,21508,37,21508,12392,22133]

theorem envBound21894 : H12AffineFastState.Bounded env21894 := by
  intro p hp
  have h : env21894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21893_21894 : H12AffineEnvironment.transform 14 1077 env21893 = env21894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env21893 == env21894) = true)

theorem identity21894 : scanCanonicalize (H12AffineFastState.compose env21894 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound21894 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env21895 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,2065,8192,16384,1077,27759,16400,25629,1025,1076,2129,112,9228,19559,8272,65,25677,10296,24633,17461,1057,19477,37,19477,10361,20068]

theorem envBound21895 : H12AffineFastState.Bounded env21895 := by
  intro p hp
  have h : env21895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21894_21895 : H12AffineEnvironment.transform 11 2065 env21894 = env21895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env21894 == env21895) = true)

theorem identity21895 : scanCanonicalize (H12AffineFastState.compose env21895 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21895 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env21896 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,2065,40,16384,1077,19527,16400,17461,1025,1076,2129,112,1060,19559,120,65,17509,2064,16401,17461,1057,19477,37,19477,2129,20068]

theorem envBound21896 : H12AffineFastState.Bounded env21896 := by
  intro p hp
  have h : env21896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21895_21896 : H12AffineEnvironment.transform 12 40 env21895 = env21896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21895 == env21896) = true)

theorem identity21896 : scanCanonicalize (H12AffineFastState.compose env21896 (packedSelected [2,6,11] rootPS)) = affineNative (2^(13+1) ^^^ 81) := by decide +kernel

theorem selectedBound21896 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env21897 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,2065,40,81,1077,3094,65,1124,1025,1076,2129,112,1060,3126,120,65,1076,2064,64,1124,1057,3140,37,3140,2129,3637]

theorem envBound21897 : H12AffineFastState.Bounded env21897 := by
  intro p hp
  have h : env21897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21896_21897 : H12AffineEnvironment.transform 13 81 env21896 = env21897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 81 env21896 == env21897) = true)

theorem identity21897 : scanCanonicalize (H12AffineFastState.compose env21897 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21897 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env21898 : List Nat := [2,4,8,16,32,64,88,36,512,101,2048,2065,40,81,80,2163,65,1,100,81,2129,112,65,2131,120,65,81,2064,64,1,68,2081,37,2081,2129,2640]

theorem envBound21898 : H12AffineFastState.Bounded env21898 := by
  intro p hp
  have h : env21898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21897_21898 : H12AffineEnvironment.transform 9 101 env21897 = env21898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21897 == env21898) = true)

theorem identity21898 : scanCanonicalize (H12AffineFastState.compose env21898 (packedSelected [0,1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21898 : packedSelected [0,1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env21899 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,40,1,0,2083,17,1,52,1,2049,32,17,2051,40,17,1,2064,16,1,20,2081,37,2081,2049,2560]

theorem envBound21899 : H12AffineFastState.Bounded env21899 := by
  intro p hp
  have h : env21899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21898_21899 : H12AffineEnvironment.transform 5 16 env21898 = env21899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21898 == env21899) = true)

theorem identity21899 : scanCanonicalize (H12AffineFastState.compose env21899 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21899 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21900 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,16,40,1,0,34,17,1,52,1,0,32,17,2,40,17,1,17,16,1,20,32,37,32,0,513]

theorem envBound21900 : H12AffineFastState.Bounded env21900 := by
  intro p hp
  have h : env21900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21899_21900 : H12AffineEnvironment.transform 10 1 env21899 = env21900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21899 == env21900) = true)

theorem identity21900 : scanCanonicalize (H12AffineFastState.compose env21900 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound21900 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21901 : List Nat := [2,4,8,16,32,16,8,36,27,53,1,16,40,1,0,34,17,1,52,1,0,32,17,2,40,17,1,17,16,1,20,32,37,32,0,26]

theorem envBound21901 : H12AffineFastState.Bounded env21901 := by
  intro p hp
  have h : env21901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21900_21901 : H12AffineEnvironment.transform 8 27 env21900 = env21901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env21900 == env21901) = true)

def env21902 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,113,318516,351237,8273,65,262225,313360,301056,23589,1057,272392,36,21509,46172,74251]

theorem envBound21902 : H12AffineFastState.Bounded env21902 := by
  intro p hp
  have h : env21902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21890_21902 : H12AffineEnvironment.transform 6 89 env21890 = env21902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env21890 == env21902) = true)

theorem identity21902 : scanCanonicalize (H12AffineFastState.compose env21902 (packedSelected [0,2,5,6,11,12,14,15,17,18,19,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound21902 : packedSelected [0,2,5,6,11,12,14,15,17,18,19,24,27] rootPS < 2^1333 := by decide +kernel

def env21903 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,16384,32768,65536,16400,2048,1025,32769,4160,113,54324,87045,8273,65,2129,49168,36864,23589,1057,8200,36,21509,46172,74251]

theorem envBound21903 : H12AffineFastState.Bounded env21903 := by
  intro p hp
  have h : env21903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21902_21903 : H12AffineEnvironment.transform 17 2048 env21902 = env21903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env21902 == env21903) = true)

theorem identity21903 : scanCanonicalize (H12AffineFastState.compose env21903 (packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,19,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21903 : packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env21904 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,16384,32768,8203,16400,2048,1025,32769,4160,113,54324,29710,8273,65,2129,49168,36864,23589,1057,8200,36,21509,46172,512]

theorem envBound21904 : H12AffineFastState.Bounded env21904 := by
  intro p hp
  have h : env21904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21903_21904 : H12AffineEnvironment.transform 15 8203 env21903 = env21904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21903 == env21904) = true)

theorem identity21904 : scanCanonicalize (H12AffineFastState.compose env21904 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound21904 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21905 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,5157,32768,8203,5173,2048,1025,32769,4160,113,32785,8235,8273,65,2129,37941,36864,2048,1057,8200,36,32,46172,512]

theorem envBound21905 : H12AffineFastState.Bounded env21905 := by
  intro p hp
  have h : env21905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21904_21905 : H12AffineEnvironment.transform 13 5157 env21904 = env21905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env21904 == env21905) = true)

theorem identity21905 : scanCanonicalize (H12AffineFastState.compose env21905 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21905 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21906 : List Nat := [2,4,8,16,1,64,89,4,512,1024,2048,4096,8192,5124,32768,8203,5140,2048,1025,32769,4160,80,32785,8202,8273,65,2129,37908,36864,2048,1024,8200,5,1,46172,512]

theorem envBound21906 : H12AffineFastState.Bounded env21906 := by
  intro p hp
  have h : env21906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21905_21906 : H12AffineEnvironment.transform 4 1 env21905 = env21906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21905 == env21906) = true)

theorem identity21906 : scanCanonicalize (H12AffineFastState.compose env21906 (packedSelected [0,2,7,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21906 : packedSelected [0,2,7,14,17,20] rootPS < 2^1333 := by decide +kernel

def env21907 : List Nat := [2,4,8,16,1,64,89,4,512,1024,2048,4096,8192,5124,0,8203,5140,2048,1025,1,4160,80,17,8202,8273,65,2129,5140,4096,2048,1024,8200,5,1,13404,512]

theorem envBound21907 : H12AffineFastState.Bounded env21907 := by
  intro p hp
  have h : env21907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21906_21907 : H12AffineEnvironment.transform 14 0 env21906 = env21907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21906 == env21907) = true)

theorem identity21907 : scanCanonicalize (H12AffineFastState.compose env21907 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound21907 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21908 : List Nat := [2,4,8,16,1,64,89,4,512,1024,2048,4096,25,5124,0,18,5140,2048,1025,1,4160,80,17,19,72,65,2129,5140,4096,2048,1024,17,5,1,5189,512]

theorem envBound21908 : H12AffineFastState.Bounded env21908 := by
  intro p hp
  have h : env21908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21907_21908 : H12AffineEnvironment.transform 12 25 env21907 = env21908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env21907 == env21908) = true)

theorem identity21908 : scanCanonicalize (H12AffineFastState.compose env21908 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound21908 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env21909 : List Nat := [2,4,8,16,1,64,89,4,512,1024,593,4096,25,5124,0,18,5140,593,1025,1,4160,80,17,19,72,65,512,5140,4096,593,1024,17,5,1,5189,512]

theorem envBound21909 : H12AffineFastState.Bounded env21909 := by
  intro p hp
  have h : env21909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21908_21909 : H12AffineEnvironment.transform 10 593 env21908 = env21909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env21908 == env21909) = true)

theorem identity21909 : scanCanonicalize (H12AffineFastState.compose env21909 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 592) := by decide +kernel

theorem selectedBound21909 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21910 : List Nat := [2,4,8,16,1,64,89,4,512,1024,593,592,25,1620,0,18,1604,593,1025,1,528,80,17,19,72,65,512,1604,592,593,1024,17,5,1,1557,512]

theorem envBound21910 : H12AffineFastState.Bounded env21910 := by
  intro p hp
  have h : env21910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21909_21910 : H12AffineEnvironment.transform 11 592 env21909 = env21910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 592 env21909 == env21910) = true)

theorem identity21910 : scanCanonicalize (H12AffineFastState.compose env21910 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound21910 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env21911 : List Nat := [2,4,8,16,1,64,89,4,64,1024,17,16,25,1044,0,18,1028,17,1025,1,80,80,17,19,72,65,64,1028,16,17,1024,17,5,1,1109,64]

theorem envBound21911 : H12AffineFastState.Bounded env21911 := by
  intro p hp
  have h : env21911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21910_21911 : H12AffineEnvironment.transform 8 64 env21910 = env21911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env21910 == env21911) = true)

theorem identity21911 : scanCanonicalize (H12AffineFastState.compose env21911 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21911 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env21912 : List Nat := [2,4,8,16,1,64,89,4,64,20,17,16,25,0,0,18,16,17,21,1,80,80,17,19,72,65,64,16,16,17,20,17,5,1,65,64]

theorem envBound21912 : H12AffineFastState.Bounded env21912 := by
  intro p hp
  have h : env21912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21911_21912 : H12AffineEnvironment.transform 9 20 env21911 = env21912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21911 == env21912) = true)

theorem identity21912 : scanCanonicalize (H12AffineFastState.compose env21912 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 20) := by decide +kernel

theorem selectedBound21912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21913 : List Nat := [2,4,8,16,1,20,13,4,20,20,17,16,25,0,0,18,16,17,21,1,4,4,17,19,28,21,20,16,16,17,20,17,5,1,21,20]

theorem envBound21913 : H12AffineFastState.Bounded env21913 := by
  intro p hp
  have h : env21913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21912_21913 : H12AffineEnvironment.transform 5 20 env21912 = env21913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env21912 == env21913) = true)

theorem identity21913 : scanCanonicalize (H12AffineFastState.compose env21913 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21913 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21914 : List Nat := [2,4,8,0,1,4,13,4,4,4,1,0,9,0,0,2,0,1,5,1,4,4,1,3,12,5,4,0,0,1,4,1,5,1,5,4]

theorem envBound21914 : H12AffineFastState.Bounded env21914 := by
  intro p hp
  have h : env21914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21913_21914 : H12AffineEnvironment.transform 3 0 env21913 = env21914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21913 == env21914) = true)

theorem identity21914 : scanCanonicalize (H12AffineFastState.compose env21914 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound21914 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env21915 : List Nat := [2,1,8,0,1,1,8,1,1,1,1,0,9,0,0,2,0,1,0,1,1,1,1,3,9,0,1,0,0,1,1,1,0,1,0,1]

theorem envBound21915 : H12AffineFastState.Bounded env21915 := by
  intro p hp
  have h : env21915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21914_21915 : H12AffineEnvironment.transform 1 1 env21914 = env21915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env21914 == env21915) = true)

def env21916 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,168,318701,351453,8328,65,262281,313361,301057,23804,1056,272392,252,21725,46213,74251]

theorem envBound21916 : H12AffineFastState.Bounded env21916 := by
  intro p hp
  have h : env21916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21889_21916 : H12AffineEnvironment.transform 7 253 env21889 = env21916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env21889 == env21916) = true)

theorem identity21916 : scanCanonicalize (H12AffineFastState.compose env21916 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21916 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21917 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,168,318701,294103,8328,65,262281,313361,301057,23804,1056,272392,252,21725,46213,513]

theorem envBound21917 : H12AffineFastState.Bounded env21917 := by
  intro p hp
  have h : env21917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21916_21917 : H12AffineEnvironment.transform 15 8202 env21916 = env21917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21916 == env21917) = true)

def env21918 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,32,318565,293983,8192,65,262145,313361,301057,23668,1056,272392,116,21589,46093,513]

theorem envBound21918 : H12AffineFastState.Bounded env21918 := by
  intro p hp
  have h : env21918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21917_21918 : H12AffineEnvironment.transform 6 8 env21917 = env21918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21917 == env21918) = true)

theorem identity21918 : scanCanonicalize (H12AffineFastState.compose env21918 (packedSelected [2,4,6,9,11,14,17,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 28777) := by decide +kernel

theorem selectedBound21918 : packedSelected [2,4,6,9,11,14,17,20,23] rootPS < 2^1333 := by decide +kernel

def env21919 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,28777,8202,16400,262144,1025,28776,4160,32,273420,293983,8192,65,262145,276600,288872,23668,1056,272392,116,21589,17508,513]

theorem envBound21919 : H12AffineFastState.Bounded env21919 := by
  intro p hp
  have h : env21919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21918_21919 : H12AffineEnvironment.transform 14 28777 env21918 = env21919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28777 env21918 == env21919) = true)

theorem identity21919 : scanCanonicalize (H12AffineFastState.compose env21919 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 30824) := by decide +kernel

theorem selectedBound21919 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env21920 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,28777,8202,16400,30824,1025,28776,4160,32,21604,1079,8192,65,30825,16400,4096,23668,1056,20576,116,21589,17508,513]

theorem envBound21920 : H12AffineFastState.Bounded env21920 := by
  intro p hp
  have h : env21920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21919_21920 : H12AffineEnvironment.transform 17 30824 env21919 = env21920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30824 env21919 == env21920) = true)

theorem identity21920 : scanCanonicalize (H12AffineFastState.compose env21920 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound21920 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env21921 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13324,1125,8202,13340,3172,1025,1124,4160,32,8296,1079,8192,65,3173,13340,4096,10360,1056,9324,116,8281,12392,513]

theorem envBound21921 : H12AffineFastState.Bounded env21921 := by
  intro p hp
  have h : env21921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21920_21921 : H12AffineEnvironment.transform 13 13324 env21920 = env21921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env21920 == env21921) = true)

theorem identity21921 : scanCanonicalize (H12AffineFastState.compose env21921 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21921 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21922 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,8192,12345,80,8202,12329,2129,52,81,4160,32,8296,2,8192,65,2128,12329,4096,10360,21,8281,116,8281,12392,513]

theorem envBound21922 : H12AffineFastState.Bounded env21922 := by
  intro p hp
  have h : env21922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21921_21922 : H12AffineEnvironment.transform 9 53 env21921 = env21922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21921 == env21922) = true)

theorem identity21922 : scanCanonicalize (H12AffineFastState.compose env21922 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound21922 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env21923 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,6248,2129,80,6242,2113,2129,52,81,4160,32,6144,2,6248,65,2128,2113,4096,4112,21,6193,116,6193,2048,513]

theorem envBound21923 : H12AffineFastState.Bounded env21923 := by
  intro p hp
  have h : env21923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21922_21923 : H12AffineEnvironment.transform 12 6248 env21922 = env21923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env21922 == env21923) = true)

theorem identity21923 : scanCanonicalize (H12AffineFastState.compose env21923 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21923 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env21924 : List Nat := [2,4,8,16,32,64,8,117,512,53,1,4096,4201,80,80,4195,64,80,52,81,4160,32,4097,2,4201,65,81,64,4096,4112,21,4144,116,4144,1,513]

theorem envBound21924 : H12AffineFastState.Bounded env21924 := by
  intro p hp
  have h : env21924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21923_21924 : H12AffineEnvironment.transform 10 1 env21923 = env21924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21923 == env21924) = true)

theorem identity21924 : scanCanonicalize (H12AffineFastState.compose env21924 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound21924 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env21925 : List Nat := [2,4,8,16,32,64,8,117,512,53,1,16,121,80,80,115,64,80,52,81,80,32,17,2,121,65,81,64,16,0,21,32,116,32,1,513]

theorem envBound21925 : H12AffineFastState.Bounded env21925 := by
  intro p hp
  have h : env21925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21924_21925 : H12AffineEnvironment.transform 11 16 env21924 = env21925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env21924 == env21925) = true)

theorem identity21925 : scanCanonicalize (H12AffineFastState.compose env21925 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21925 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21926 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,16,41,0,0,35,16,0,52,1,0,32,17,2,41,17,1,16,16,0,21,32,36,32,1,513]

theorem envBound21926 : H12AffineFastState.Bounded env21926 := by
  intro p hp
  have h : env21926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21925_21926 : H12AffineEnvironment.transform 5 16 env21925 = env21926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21925 == env21926) = true)

theorem identity21926 : scanCanonicalize (H12AffineFastState.compose env21926 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound21926 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21927 : List Nat := [2,4,8,16,32,16,8,37,33,53,1,16,41,0,0,35,16,0,52,1,0,32,17,2,41,17,1,16,16,0,21,32,36,32,1,32]

theorem envBound21927 : H12AffineFastState.Bounded env21927 := by
  intro p hp
  have h : env21927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21926_21927 : H12AffineEnvironment.transform 8 33 env21926 = env21927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env21926 == env21927) = true)

theorem identity21927 : scanCanonicalize (H12AffineFastState.compose env21927 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21927 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21928 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,16,8,0,0,2,16,0,21,1,0,1,17,2,8,17,1,16,16,0,21,1,5,1,1,1]

theorem envBound21928 : H12AffineFastState.Bounded env21928 := by
  intro p hp
  have h : env21928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21927_21928 : H12AffineEnvironment.transform 4 1 env21927 = env21928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21927 == env21928) = true)

def env21929 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4160,33,318564,293982,8193,65,262144,313361,301057,23669,1056,272392,117,21588,46092,513]

theorem envBound21929 : H12AffineFastState.Bounded env21929 := by
  intro p hp
  have h : env21929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21917_21929 : H12AffineEnvironment.transform 6 9 env21917 = env21929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21917 == env21929) = true)

theorem identity21929 : scanCanonicalize (H12AffineFastState.compose env21929 (packedSelected [2,4,6,9,11,14,17,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound21929 : packedSelected [2,4,6,9,11,14,17,20,23] rootPS < 2^1333 := by decide +kernel

def env21930 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29788,8202,16400,262144,1025,29789,4160,33,272440,293982,8193,65,262144,277581,289885,23669,1056,272392,117,21588,16464,513]

theorem envBound21930 : H12AffineFastState.Bounded env21930 := by
  intro p hp
  have h : env21930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21929_21930 : H12AffineEnvironment.transform 14 29788 env21929 = env21930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env21929 == env21930) = true)

theorem identity21930 : scanCanonicalize (H12AffineFastState.compose env21930 (packedSelected [0,14,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21930 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env21931 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,29708,8202,16400,262144,1025,29709,4112,33,272440,293902,8193,17,262144,277533,289805,23589,1056,272392,37,21508,16384,513]

theorem envBound21931 : H12AffineFastState.Bounded env21931 := by
  intro p hp
  have h : env21931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21930_21931 : H12AffineEnvironment.transform 5 16 env21930 = env21931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21930 == env21931) = true)

theorem identity21931 : scanCanonicalize (H12AffineFastState.compose env21931 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21931 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env21932 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,21540,34,16400,262144,1025,21541,4112,33,264208,285734,41,17,262144,269365,281637,23589,1056,264224,37,21508,16384,513]

theorem envBound21932 : H12AffineFastState.Bounded env21932 := by
  intro p hp
  have h : env21932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21931_21932 : H12AffineEnvironment.transform 12 40 env21931 = env21932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21931 == env21932) = true)

theorem identity21932 : scanCanonicalize (H12AffineFastState.compose env21932 (packedSelected [0,2,3,4,6,8,10,11] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound21932 : packedSelected [0,2,3,4,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env21933 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,21540,34,16400,2561,1025,21541,4112,33,529,22055,41,17,2561,5684,17956,23589,1056,545,37,21508,16384,513]

theorem envBound21933 : H12AffineFastState.Bounded env21933 := by
  intro p hp
  have h : env21933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21932_21933 : H12AffineEnvironment.transform 17 2561 env21932 = env21933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env21932 == env21933) = true)

theorem identity21933 : scanCanonicalize (H12AffineFastState.compose env21933 (packedSelected [0,1,2,4,5,6,7,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 1061) := by decide +kernel

theorem selectedBound21933 : packedSelected [0,1,2,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env21934 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,1061,4097,34,1077,2561,1025,4096,4112,33,529,4610,41,17,2561,5684,513,6144,1056,545,37,4129,1061,513]

theorem envBound21934 : H12AffineFastState.Bounded env21934 := by
  intro p hp
  have h : env21934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21933_21934 : H12AffineEnvironment.transform 13 1061 env21933 = env21934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1061 env21933 == env21934) = true)

theorem identity21934 : scanCanonicalize (H12AffineFastState.compose env21934 (packedSelected [0,2,3,4,6,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21934 : packedSelected [0,2,3,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env21935 : List Nat := [2,4,8,16,32,16,9,36,1,1024,2048,4096,40,1061,4097,34,1077,2048,1025,4096,4112,33,16,4099,41,17,2048,5173,0,6144,1056,32,37,4129,1061,0]

theorem envBound21935 : H12AffineFastState.Bounded env21935 := by
  intro p hp
  have h : env21935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21934_21935 : H12AffineEnvironment.transform 8 1 env21934 = env21935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21934 == env21935) = true)

def env21936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,4161,169,318701,351521,8328,65,262517,313836,301565,23805,1500,272393,257,21792,46213,74250]

theorem envBound21936 : H12AffineFastState.Bounded env21936 := by
  intro p hp
  have h : env21936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21888_21936 : H12AffineEnvironment.transform 16 16401 env21888 = env21936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env21888 == env21936) = true)

theorem identity21936 : scanCanonicalize (H12AffineFastState.compose env21936 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound21936 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,4161,169,62661,95497,8328,65,10589,57796,45525,23805,1500,33,257,21792,46213,74250]

theorem envBound21937 : H12AffineFastState.Bounded env21937 := by
  intro p hp
  have h : env21937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21936_21937 : H12AffineEnvironment.transform 17 10280 env21936 = env21937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21936 == env21937) = true)

theorem identity21937 : scanCanonicalize (H12AffineFastState.compose env21937 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21937 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env21938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1025,32769,4161,169,62661,21762,8328,65,10589,57796,45525,23805,1500,33,257,21792,46213,513]

theorem envBound21938 : H12AffineFastState.Bounded env21938 := by
  intro p hp
  have h : env21938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21937_21938 : H12AffineEnvironment.transform 15 8203 env21937 = env21938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21937 == env21938) = true)

theorem identity21938 : scanCanonicalize (H12AffineFastState.compose env21938 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound21938 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16401,10280,1025,29909,4161,169,17,21762,8328,65,10589,5392,17665,23805,1500,33,257,21792,16465,513]

theorem envBound21939 : H12AffineFastState.Bounded env21939 := by
  intro p hp
  have h : env21939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21938_21939 : H12AffineEnvironment.transform 14 29908 env21938 = env21939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env21938 == env21939) = true)

theorem identity21939 : scanCanonicalize (H12AffineFastState.compose env21939 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound21939 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env21940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,0,8203,13509,10280,1025,1,4161,169,17,8662,8328,65,10589,5392,12757,10281,1500,33,257,8692,13445,513]

theorem envBound21940 : H12AffineFastState.Bounded env21940 := by
  intro p hp
  have h : env21940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21939_21940 : H12AffineEnvironment.transform 13 13524 env21939 = env21940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env21939 == env21940) = true)

theorem identity21940 : scanCanonicalize (H12AffineFastState.compose env21940 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound21940 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env21941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,479,5393,2556,1025,1,4161,169,17,2,348,65,2185,5392,4097,2557,1500,33,257,32,5457,513]

theorem envBound21941 : H12AffineFastState.Bounded env21941 := by
  intro p hp
  have h : env21941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21940_21941 : H12AffineEnvironment.transform 12 468 env21940 = env21941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env21940 == env21941) = true)

theorem identity21941 : scanCanonicalize (H12AffineFastState.compose env21941 (packedSelected [5,8,11,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 664) := by decide +kernel

theorem selectedBound21941 : packedSelected [5,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env21942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,664,4096,468,5376,0,479,5393,868,1025,1,4161,169,17,2,348,65,529,5392,4097,869,1500,33,257,32,5457,513]

theorem envBound21942 : H12AffineFastState.Bounded env21942 := by
  intro p hp
  have h : env21942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21941_21942 : H12AffineEnvironment.transform 10 664 env21941 = env21942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 664 env21941 == env21942) = true)

theorem identity21942 : scanCanonicalize (H12AffineFastState.compose env21942 (packedSelected [0,1,3,5,7,8,11,12,23] rootPS)) = affineNative (2^(11+1) ^^^ 868) := by decide +kernel

theorem selectedBound21942 : packedSelected [0,1,3,5,7,8,11,12,23] rootPS < 2^1333 := by decide +kernel

def env21943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,664,868,468,1636,0,479,1653,868,1025,1,805,169,17,2,348,65,529,1652,869,869,1500,33,257,32,1589,513]

theorem envBound21943 : H12AffineFastState.Bounded env21943 := by
  intro p hp
  have h : env21943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21942_21943 : H12AffineEnvironment.transform 11 868 env21942 = env21943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 868 env21942 == env21943) = true)

theorem identity21943 : scanCanonicalize (H12AffineFastState.compose env21943 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound21943 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env21944 : List Nat := [2,4,8,16,32,64,88,256,512,1024,576,868,268,1636,0,263,1653,868,1025,1,805,113,17,2,348,65,529,1652,869,869,1284,33,257,32,1589,513]

theorem envBound21944 : H12AffineFastState.Bounded env21944 := by
  intro p hp
  have h : env21944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21943_21944 : H12AffineEnvironment.transform 6 88 env21943 = env21944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env21943 == env21944) = true)

theorem identity21944 : scanCanonicalize (H12AffineFastState.compose env21944 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound21944 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21945 : List Nat := [2,4,8,16,32,64,88,256,512,36,576,868,268,576,0,263,593,868,37,1,805,113,17,2,348,65,529,592,869,869,288,33,257,32,529,513]

theorem envBound21945 : H12AffineFastState.Bounded env21945 := by
  intro p hp
  have h : env21945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21944_21945 : H12AffineEnvironment.transform 9 36 env21944 = env21945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env21944 == env21945) = true)

theorem identity21945 : scanCanonicalize (H12AffineFastState.compose env21945 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound21945 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env21946 : List Nat := [2,4,8,16,32,64,88,256,293,36,357,65,268,357,0,263,372,65,37,1,0,113,17,2,348,65,308,373,64,64,288,33,257,32,308,292]

theorem envBound21946 : H12AffineFastState.Bounded env21946 := by
  intro p hp
  have h : env21946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21945_21946 : H12AffineEnvironment.transform 8 293 env21945 = env21946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env21945 == env21946) = true)

def env21947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,151632,147641,318701,466224,8328,65,409957,313836,449004,138476,148941,419865,257,21792,46213,221723]

theorem envBound21947 : H12AffineFastState.Bounded env21947 := by
  intro p hp
  have h : env21947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21887_21947 : H12AffineEnvironment.transform 21 147641 env21887 = env21947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147641 env21887 == env21947) = true)

def env21948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,4160,169,318701,351520,8328,65,262517,313836,301564,23804,1501,272393,257,21792,46213,74251]

theorem envBound21948 : H12AffineFastState.Bounded env21948 := by
  intro p hp
  have h : env21948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21947_21948 : H12AffineEnvironment.transform 16 16400 env21947 = env21948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env21947 == env21948) = true)

theorem identity21948 : scanCanonicalize (H12AffineFastState.compose env21948 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 56572) := by decide +kernel

theorem selectedBound21948 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,56572,1025,32769,4160,169,17,98780,8328,65,56713,5392,17664,23804,1501,62709,257,21792,46213,74251]

theorem envBound21949 : H12AffineFastState.Bounded env21949 := by
  intro p hp
  have h : env21949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21948_21949 : H12AffineEnvironment.transform 17 56572 env21948 = env21949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env21948 == env21949) = true)

theorem identity21949 : scanCanonicalize (H12AffineFastState.compose env21949 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21949 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env21950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,56572,1025,32769,4160,169,17,41430,8328,65,56713,5392,17664,23804,1501,62709,257,21792,46213,513]

theorem envBound21950 : H12AffineFastState.Bounded env21950 := by
  intro p hp
  have h : env21950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21949_21950 : H12AffineEnvironment.transform 15 8202 env21949 = env21950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21949 == env21950) = true)

theorem identity21950 : scanCanonicalize (H12AffineFastState.compose env21950 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound21950 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env21951 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,16400,56357,1025,32769,4160,112,17,41231,8273,65,56656,5392,17664,23589,1284,62508,257,21792,46172,513]

theorem envBound21951 : H12AffineFastState.Bounded env21951 := by
  intro p hp
  have h : env21951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21950_21951 : H12AffineEnvironment.transform 6 89 env21950 = env21951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env21950 == env21951) = true)

theorem identity21951 : scanCanonicalize (H12AffineFastState.compose env21951 (packedSelected [2,6,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound21951 : packedSelected [2,6,17,18,23] rootPS < 2^1333 := by decide +kernel

def env21952 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29709,8202,16400,10280,1025,29708,4160,112,17,21762,8273,65,10589,5392,17664,23589,1284,33,257,21792,16465,513]

theorem envBound21952 : H12AffineFastState.Bounded env21952 := by
  intro p hp
  have h : env21952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21951_21952 : H12AffineEnvironment.transform 14 29709 env21951 = env21952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env21951 == env21952) = true)

theorem identity21952 : scanCanonicalize (H12AffineFastState.compose env21952 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound21952 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env21953 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13324,1,8202,13340,10280,1025,0,4160,112,17,8462,8273,65,10589,5392,12556,10281,1284,33,257,8492,13405,513]

theorem envBound21953 : H12AffineFastState.Bounded env21953 := by
  intro p hp
  have h : env21953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21952_21953 : H12AffineEnvironment.transform 13 13324 env21952 = env21953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env21952 == env21953) = true)

theorem identity21953 : scanCanonicalize (H12AffineFastState.compose env21953 (packedSelected [0,5,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound21953 : packedSelected [0,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env21954 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2576,8192,11804,1,8202,11788,10280,1025,0,2640,112,17,8462,8273,65,10589,3840,11036,10281,1284,33,257,8492,11853,513]

theorem envBound21954 : H12AffineFastState.Bounded env21954 := by
  intro p hp
  have h : env21954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21953_21954 : H12AffineEnvironment.transform 11 2576 env21953 = env21954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env21953 == env21954) = true)

theorem identity21954 : scanCanonicalize (H12AffineFastState.compose env21954 (packedSelected [3,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 2105) := by decide +kernel

theorem selectedBound21954 : packedSelected [3,8,12,14] rootPS < 2^1333 := by decide +kernel

def env21955 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2576,2105,1573,1,2099,1589,17,1025,0,2640,112,17,2359,2152,65,356,3840,805,16,1284,33,257,2325,1652,513]

theorem envBound21955 : H12AffineFastState.Bounded env21955 := by
  intro p hp
  have h : env21955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21954_21955 : H12AffineEnvironment.transform 12 2105 env21954 = env21955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2105 env21954 == env21955) = true)

theorem identity21955 : scanCanonicalize (H12AffineFastState.compose env21955 (packedSelected [5,6,8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound21955 : packedSelected [5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env21956 : List Nat := [2,4,8,16,32,64,89,256,512,1024,325,853,380,1573,1,374,1589,17,1025,0,789,112,17,114,301,65,356,1605,805,16,1284,33,257,80,1652,513]

theorem envBound21956 : H12AffineFastState.Bounded env21956 := by
  intro p hp
  have h : env21956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21955_21956 : H12AffineEnvironment.transform 10 325 env21955 = env21956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env21955 == env21956) = true)

theorem identity21956 : scanCanonicalize (H12AffineFastState.compose env21956 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21956 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env21957 : List Nat := [2,4,8,16,32,16,9,256,512,1024,277,773,300,1573,1,294,1589,17,1025,0,789,32,17,34,301,17,308,1557,805,16,1284,33,257,0,1572,513]

theorem envBound21957 : H12AffineFastState.Bounded env21957 := by
  intro p hp
  have h : env21957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21956_21957 : H12AffineEnvironment.transform 5 16 env21956 = env21957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21956 == env21957) = true)

def env21958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,4161,168,318701,351521,8328,65,262516,313836,301565,23805,1500,272392,257,21792,46213,74250]

theorem envBound21958 : H12AffineFastState.Bounded env21958 := by
  intro p hp
  have h : env21958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21947_21958 : H12AffineEnvironment.transform 16 16401 env21947 = env21958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env21947 == env21958) = true)

theorem identity21958 : scanCanonicalize (H12AffineFastState.compose env21958 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound21958 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,16401,262144,1025,29909,4161,168,272441,351521,8328,65,262516,277816,290089,23805,1500,272392,257,21792,16465,74250]

theorem envBound21959 : H12AffineFastState.Bounded env21959 := by
  intro p hp
  have h : env21959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21958_21959 : H12AffineEnvironment.transform 14 29908 env21958 = env21959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env21958 == env21959) = true)

def env21960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,16401,32160,1025,29909,4161,168,21913,73857,8328,65,31956,16536,4233,23805,1500,21928,257,21792,16465,74250]

theorem envBound21960 : H12AffineFastState.Bounded env21960 := by
  intro p hp
  have h : env21960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21959_21960 : H12AffineEnvironment.transform 17 32160 env21959 = env21960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env21959 == env21960) = true)

theorem identity21960 : scanCanonicalize (H12AffineFastState.compose env21960 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound21960 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30083,16401,32160,1025,29909,4161,168,21913,21762,8328,65,31956,16536,4233,23805,1500,21928,257,21792,16465,22409]

theorem envBound21961 : H12AffineFastState.Bounded env21961 := by
  intro p hp
  have h : env21961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21960_21961 : H12AffineEnvironment.transform 15 30083 env21960 = env21961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env21960 == env21961) = true)

theorem identity21961 : scanCanonicalize (H12AffineFastState.compose env21961 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound21961 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env21962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8203,5529,10280,1025,8541,4161,168,17,138,8328,65,10588,5392,4233,2421,1500,32,257,168,5593,513]

theorem envBound21962 : H12AffineFastState.Bounded env21962 := by
  intro p hp
  have h : env21962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21961_21962 : H12AffineEnvironment.transform 13 5512 env21961 = env21962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env21961 == env21962) = true)

theorem identity21962 : scanCanonicalize (H12AffineFastState.compose env21962 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21962 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10280,1025,8541,4161,32,17,2,8192,65,10588,5392,4097,2421,1364,32,257,32,5457,513]

theorem envBound21963 : H12AffineFastState.Bounded env21963 := by
  intro p hp
  have h : env21963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21962_21963 : H12AffineEnvironment.transform 6 8 env21962 = env21963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21962 == env21963) = true)

theorem identity21963 : scanCanonicalize (H12AffineFastState.compose env21963 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound21963 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5376,340,3,5393,2080,1025,341,4161,32,17,2,8,65,2388,5392,4097,2421,1364,32,257,32,5457,513]

theorem envBound21964 : H12AffineFastState.Bounded env21964 := by
  intro p hp
  have h : env21964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21963_21964 : H12AffineEnvironment.transform 12 8 env21963 = env21964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env21963 == env21964) = true)

theorem identity21964 : scanCanonicalize (H12AffineFastState.compose env21964 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound21964 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env21965 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1109,8,341,340,3,324,2080,1025,341,1044,32,17,2,8,65,2388,325,1108,2421,1364,32,257,32,260,513]

theorem envBound21965 : H12AffineFastState.Bounded env21965 := by
  intro p hp
  have h : env21965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21964_21965 : H12AffineEnvironment.transform 11 1109 env21964 = env21965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env21964 == env21965) = true)

theorem identity21965 : scanCanonicalize (H12AffineFastState.compose env21965 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound21965 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env21966 : List Nat := [2,4,8,16,32,64,8,256,512,1024,372,1109,8,341,340,3,324,340,1025,341,1044,32,17,2,8,65,32,325,1108,1,1364,32,257,32,260,513]

theorem envBound21966 : H12AffineFastState.Bounded env21966 := by
  intro p hp
  have h : env21966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21965_21966 : H12AffineEnvironment.transform 10 372 env21965 = env21966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env21965 == env21966) = true)

theorem identity21966 : scanCanonicalize (H12AffineFastState.compose env21966 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound21966 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env21967 : List Nat := [2,4,8,16,32,64,8,256,512,100,372,49,8,341,340,3,324,340,101,341,112,32,17,2,8,65,32,325,48,1,304,32,257,32,260,513]

theorem envBound21967 : H12AffineFastState.Bounded env21967 := by
  intro p hp
  have h : env21967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21966_21967 : H12AffineEnvironment.transform 9 100 env21966 = env21967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env21966 == env21967) = true)

theorem identity21967 : scanCanonicalize (H12AffineFastState.compose env21967 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21967 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env21968 : List Nat := [2,4,8,16,0,64,8,256,512,68,340,17,8,341,340,3,324,340,69,341,80,0,17,2,8,65,0,325,16,1,272,0,257,0,260,513]

theorem envBound21968 : H12AffineFastState.Bounded env21968 := by
  intro p hp
  have h : env21968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21967_21968 : H12AffineEnvironment.transform 4 0 env21967 = env21968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21967 == env21968) = true)

theorem identity21968 : scanCanonicalize (H12AffineFastState.compose env21968 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound21968 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21969 : List Nat := [2,4,8,16,0,64,8,256,276,68,340,17,8,341,340,3,324,340,69,341,80,0,17,2,8,65,0,325,16,1,272,0,257,0,260,277]

theorem envBound21969 : H12AffineFastState.Bounded env21969 := by
  intro p hp
  have h : env21969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21968_21969 : H12AffineEnvironment.transform 8 276 env21968 = env21969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env21968 == env21969) = true)

theorem identity21969 : scanCanonicalize (H12AffineFastState.compose env21969 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound21969 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env21970 : List Nat := [2,4,8,16,0,1,8,256,276,5,277,17,8,276,277,3,261,277,4,276,17,0,17,2,8,0,0,260,16,1,272,0,257,0,260,277]

theorem envBound21970 : H12AffineFastState.Bounded env21970 := by
  intro p hp
  have h : env21970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21969_21970 : H12AffineEnvironment.transform 5 1 env21969 = env21970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env21969 == env21970) = true)

theorem identity21970 : scanCanonicalize (H12AffineFastState.compose env21970 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21970 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21971 : List Nat := [2,4,8,16,0,1,8,20,0,5,1,17,8,0,1,3,17,1,4,0,17,0,17,2,8,0,0,16,16,1,4,0,21,0,16,1]

theorem envBound21971 : H12AffineFastState.Bounded env21971 := by
  intro p hp
  have h : env21971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21970_21971 : H12AffineEnvironment.transform 7 20 env21970 = env21971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21970 == env21971) = true)

theorem identity21971 : scanCanonicalize (H12AffineFastState.compose env21971 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21972 : List Nat := [2,4,8,1,0,1,8,5,0,5,1,0,8,0,1,3,0,1,4,0,0,0,0,2,8,0,0,1,1,1,4,0,4,0,1,1]

theorem envBound21972 : H12AffineFastState.Bounded env21972 := by
  intro p hp
  have h : env21972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21971_21972 : H12AffineEnvironment.transform 3 1 env21971 = env21972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21971 == env21972) = true)

def env21973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,16401,32161,1025,29909,4161,168,21912,73856,8328,65,31957,16537,4232,23805,1500,21929,257,21792,16465,74250]

theorem envBound21973 : H12AffineFastState.Bounded env21973 := by
  intro p hp
  have h : env21973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21959_21973 : H12AffineEnvironment.transform 17 32161 env21959 = env21973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env21959 == env21973) = true)

theorem identity21973 : scanCanonicalize (H12AffineFastState.compose env21973 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound21973 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29963,16401,32161,1025,29909,4161,168,21912,21899,8328,65,31957,16537,4232,23805,1500,21929,257,21792,16465,22273]

theorem envBound21974 : H12AffineFastState.Bounded env21974 := by
  intro p hp
  have h : env21974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21973_21974 : H12AffineEnvironment.transform 15 29963 env21973 = env21974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env21973 == env21974) = true)

theorem identity21974 : scanCanonicalize (H12AffineFastState.compose env21974 (packedSelected [1,8,9,10,11,15,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound21974 : packedSelected [1,8,9,10,11,15,20,22] rootPS < 2^1333 := by decide +kernel

def env21975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8580,8283,5441,10481,1025,8581,4161,168,200,219,8328,65,10629,5577,4232,2477,1500,249,257,112,5377,593]

theorem envBound21975 : H12AffineFastState.Bounded env21975 := by
  intro p hp
  have h : env21975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21974_21975 : H12AffineEnvironment.transform 13 5456 env21974 = env21975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env21974 == env21975) = true)

theorem identity21975 : scanCanonicalize (H12AffineFastState.compose env21975 (packedSelected [11,12,15,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound21975 : packedSelected [11,12,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env21976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5456,0,479,5441,2421,1025,1,4161,168,200,219,268,65,2049,5577,4232,2477,1500,249,257,112,5377,593]

theorem envBound21976 : H12AffineFastState.Bounded env21976 := by
  intro p hp
  have h : env21976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21975_21976 : H12AffineEnvironment.transform 12 388 env21975 = env21976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env21975 == env21976) = true)

theorem identity21976 : scanCanonicalize (H12AffineFastState.compose env21976 (packedSelected [0,3,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21976 : packedSelected [0,3,8,9,10] rootPS < 2^1333 := by decide +kernel

def env21977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,0,342,5441,2421,1025,1,4161,33,65,82,268,65,2049,5440,4097,2340,1365,112,257,112,5377,593]

theorem envBound21977 : H12AffineFastState.Bounded env21977 := by
  intro p hp
  have h : env21977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21976_21977 : H12AffineEnvironment.transform 6 9 env21976 = env21977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21976 == env21977) = true)

theorem identity21977 : scanCanonicalize (H12AffineFastState.compose env21977 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2821) := by decide +kernel

theorem selectedBound21977 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2821,269,3669,0,342,3652,2421,1025,1,2884,33,65,82,268,65,2049,3653,2820,2340,1365,112,257,112,3588,593]

theorem envBound21978 : H12AffineFastState.Bounded env21978 := by
  intro p hp
  have h : env21978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21977_21978 : H12AffineEnvironment.transform 11 2821 env21977 = env21978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2821 env21977 == env21978) = true)

theorem identity21978 : scanCanonicalize (H12AffineFastState.compose env21978 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21978 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env21979 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2821,269,2608,0,342,2593,2421,100,1,2884,33,65,82,268,65,2049,2592,2820,2340,304,112,257,112,2657,593]

theorem envBound21979 : H12AffineFastState.Bounded env21979 := by
  intro p hp
  have h : env21979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21978_21979 : H12AffineEnvironment.transform 9 101 env21978 = env21979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21978 == env21979) = true)

theorem identity21979 : scanCanonicalize (H12AffineFastState.compose env21979 (packedSelected [3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21979 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env21980 : List Nat := [2,4,8,16,32,64,9,5,512,101,2048,2560,8,2608,0,83,2593,2160,100,1,2625,33,65,82,9,65,2049,2592,2561,2081,53,112,4,112,2657,593]

theorem envBound21980 : H12AffineFastState.Bounded env21980 := by
  intro p hp
  have h : env21980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21979_21980 : H12AffineEnvironment.transform 7 5 env21979 = env21980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21979 == env21980) = true)

theorem identity21980 : scanCanonicalize (H12AffineFastState.compose env21980 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound21980 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21981 : List Nat := [2,4,8,16,32,64,9,5,65,101,2048,2113,8,2161,0,83,2144,2160,100,1,2048,33,65,82,9,65,2049,2145,2112,2081,53,112,4,112,2080,16]

theorem envBound21981 : H12AffineFastState.Bounded env21981 := by
  intro p hp
  have h : env21981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21980_21981 : H12AffineEnvironment.transform 8 65 env21980 = env21981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env21980 == env21981) = true)

theorem identity21981 : scanCanonicalize (H12AffineFastState.compose env21981 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound21981 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env21982 : List Nat := [2,4,8,16,32,64,9,5,65,101,32,97,8,81,0,83,64,80,100,1,32,33,65,82,9,65,33,65,96,1,53,112,4,112,0,16]

theorem envBound21982 : H12AffineFastState.Bounded env21982 := by
  intro p hp
  have h : env21982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21981_21982 : H12AffineEnvironment.transform 10 32 env21981 = env21982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env21981 == env21982) = true)

theorem identity21982 : scanCanonicalize (H12AffineFastState.compose env21982 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21982 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21983 : List Nat := [2,4,8,16,16,64,9,5,65,85,16,81,8,81,0,83,64,80,84,1,16,17,65,82,9,65,17,65,80,1,5,64,4,64,0,16]

end H12CloudChart0