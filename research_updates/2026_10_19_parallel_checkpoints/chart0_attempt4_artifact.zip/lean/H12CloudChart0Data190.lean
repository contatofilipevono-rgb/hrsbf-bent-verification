import H12CloudChart0Data189

namespace H12CloudChart0

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound48114 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48115 : List Nat := [2,4,8,16,32,59,9,14,512,21,1,0,40,26,1,35,10,1,21,0,59,32,16,3,41,58,1,11,0,1,52,32,14,32,49,513]

theorem envBound48115 : H12AffineFastState.Bounded env48115 := by
  intro p hp
  have h : env48115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48114_48115 : H12AffineEnvironment.transform 5 59 env48114 = env48115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env48114 == env48115) = true)

def env48116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,17,98781,8328,65,4237693,5393,17665,10400,1500,4256860,256,21793,46212,74251]

theorem envBound48116 : H12AffineFastState.Bounded env48116 := by
  intro p hp
  have h : env48116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48102_48116 : H12AffineEnvironment.transform 20 4161 env48102 = env48116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48102 == env48116) = true)

theorem identity48116 : scanCanonicalize (H12AffineFastState.compose env48116 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254010) := by decide +kernel

theorem selectedBound48116 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,254010,17,98781,8328,65,215367,5393,17665,10400,1500,201830,256,21793,46212,74251]

theorem envBound48117 : H12AffineFastState.Bounded env48117 := by
  intro p hp
  have h : env48117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48116_48117 : H12AffineEnvironment.transform 21 254010 env48116 = env48117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254010 env48116 == env48117) = true)

def env48118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,254010,17,98645,8192,65,215367,5393,17665,10280,1364,201830,256,21793,46092,74251]

theorem envBound48118 : H12AffineFastState.Bounded env48118 := by
  intro p hp
  have h : env48118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48117_48118 : H12AffineEnvironment.transform 6 8 env48117 = env48118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48117 == env48118) = true)

theorem identity48118 : scanCanonicalize (H12AffineFastState.compose env48118 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48118 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48119 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149861,1024,8540,4161,213351,17,73736,8192,65,215367,5393,17665,10280,1364,201830,256,21793,5457,74251]

theorem envBound48119 : H12AffineFastState.Bounded env48119 := by
  intro p hp
  have h : env48119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48118_48119 : H12AffineEnvironment.transform 14 8541 env48118 = env48119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48118 == env48119) = true)

theorem identity48119 : scanCanonicalize (H12AffineFastState.compose env48119 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48119 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,149861,1024,8540,4161,156013,17,2,8192,65,158029,5393,17665,10280,1364,144492,256,21793,5457,513]

theorem envBound48120 : H12AffineFastState.Bounded env48120 := by
  intro p hp
  have h : env48120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48119_48120 : H12AffineEnvironment.transform 15 8202 env48119 = env48120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48119 == env48120) = true)

theorem identity48120 : scanCanonicalize (H12AffineFastState.compose env48120 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48120 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48121 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,8313,8202,131072,149569,1024,8312,4161,155721,17,2,8192,65,157801,5173,17445,10280,1136,144492,36,21509,5237,513]

theorem envBound48121 : H12AffineFastState.Bounded env48121 := by
  intro p hp
  have h : env48121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48120_48121 : H12AffineEnvironment.transform 7 36 env48120 = env48121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48120 == env48121) = true)

theorem identity48121 : scanCanonicalize (H12AffineFastState.compose env48121 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound48121 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env48122 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,8313,8202,16400,2129,1024,8312,4161,8281,17,2,8192,65,10361,5173,17445,10280,1136,29820,36,21509,5237,513]

theorem envBound48122 : H12AffineFastState.Bounded env48122 := by
  intro p hp
  have h : env48122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48121_48122 : H12AffineEnvironment.transform 16 16400 env48121 = env48122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env48121 == env48122) = true)

theorem identity48122 : scanCanonicalize (H12AffineFastState.compose env48122 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound48122 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48123 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,12393,8313,8202,12409,2129,1024,8312,4161,8281,17,2,8192,65,10361,5173,13388,10280,1136,1045,36,9324,5237,513]

theorem envBound48123 : H12AffineFastState.Bounded env48123 := by
  intro p hp
  have h : env48123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48122_48123 : H12AffineEnvironment.transform 13 12393 env48122 = env48123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env48122 == env48123) = true)

def env48124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,254010,17,98644,8193,65,215367,5393,17665,10281,1365,201830,256,21793,46093,74251]

theorem envBound48124 : H12AffineFastState.Bounded env48124 := by
  intro p hp
  have h : env48124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48117_48124 : H12AffineEnvironment.transform 6 9 env48117 = env48124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48117 == env48124) = true)

theorem identity48124 : scanCanonicalize (H12AffineFastState.compose env48124 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound48124 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,65536,131072,171061,1024,32769,4161,234550,17,98644,8193,65,212299,5393,12557,10281,1365,201830,256,8493,46093,74251]

theorem envBound48125 : H12AffineFastState.Bounded env48125 := by
  intro p hp
  have h : env48125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48124_48125 : H12AffineEnvironment.transform 13 13324 env48124 = env48125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env48124 == env48125) = true)

theorem identity48125 : scanCanonicalize (H12AffineFastState.compose env48125 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound48125 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env48126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,65536,46109,10280,1024,32769,4161,73771,17,98644,8193,65,100694,5393,12557,10281,1365,106619,256,8493,46093,74251]

theorem envBound48126 : H12AffineFastState.Bounded env48126 := by
  intro p hp
  have h : env48126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48125_48126 : H12AffineEnvironment.transform 16 46109 env48125 = env48126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env48125 == env48126) = true)

theorem identity48126 : scanCanonicalize (H12AffineFastState.compose env48126 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48126 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env48127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,0,65536,13341,10280,1024,1,4161,73771,17,65876,8193,65,67926,5393,12557,10281,1365,73851,256,8493,13325,74251]

theorem envBound48127 : H12AffineFastState.Bounded env48127 := by
  intro p hp
  have h : env48127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48126_48127 : H12AffineEnvironment.transform 14 0 env48126 = env48127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48126 == env48127) = true)

theorem identity48127 : scanCanonicalize (H12AffineFastState.compose env48127 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48127 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env48128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,65536,5393,2340,1024,1,4161,65831,17,65876,269,65,67926,5393,4097,2341,1365,65911,256,33,5377,66311]

theorem envBound48128 : H12AffineFastState.Bounded env48128 := by
  intro p hp
  have h : env48128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48127_48128 : H12AffineEnvironment.transform 12 268 env48127 = env48128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48127 == env48128) = true)

theorem identity48128 : scanCanonicalize (H12AffineFastState.compose env48128 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound48128 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,263,5393,2340,1024,1,4161,32,17,83,269,65,2129,5393,4097,2341,1365,112,256,33,5377,512]

theorem envBound48129 : H12AffineFastState.Bounded env48129 := by
  intro p hp
  have h : env48129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48128_48129 : H12AffineEnvironment.transform 15 263 env48128 = env48129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env48128 == env48129) = true)

theorem identity48129 : scanCanonicalize (H12AffineFastState.compose env48129 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound48129 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env48130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,48,268,1328,0,263,1313,2340,1024,1,113,32,17,83,269,65,2129,1313,49,2341,1365,112,256,33,1329,512]

theorem envBound48130 : H12AffineFastState.Bounded env48130 := by
  intro p hp
  have h : env48130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48129_48130 : H12AffineEnvironment.transform 11 48 env48129 = env48130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48129 == env48130) = true)

theorem identity48130 : scanCanonicalize (H12AffineFastState.compose env48130 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound48130 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48131 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,48,268,1328,0,263,1313,2340,1024,1,1,32,17,35,269,49,2081,1313,49,2341,1317,0,256,33,1329,512]

theorem envBound48131 : H12AffineFastState.Bounded env48131 := by
  intro p hp
  have h : env48131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48130_48131 : H12AffineEnvironment.transform 5 48 env48130 = env48131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env48130 == env48131) = true)

theorem identity48131 : scanCanonicalize (H12AffineFastState.compose env48131 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound48131 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48132 : List Nat := [2,4,8,16,32,48,9,256,512,1024,554,48,268,1328,0,263,1313,782,1024,1,1,32,17,35,269,49,523,1313,49,783,1317,0,256,33,1329,512]

theorem envBound48132 : H12AffineFastState.Bounded env48132 := by
  intro p hp
  have h : env48132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48131_48132 : H12AffineEnvironment.transform 10 554 env48131 = env48132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env48131 == env48132) = true)

theorem identity48132 : scanCanonicalize (H12AffineFastState.compose env48132 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48132 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env48133 : List Nat := [2,4,8,16,32,48,9,37,512,1024,554,48,41,1045,0,34,1028,555,1024,1,1,32,17,35,40,49,523,1028,49,554,1024,0,37,33,1044,512]

theorem envBound48133 : H12AffineFastState.Bounded env48133 := by
  intro p hp
  have h : env48133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48132_48133 : H12AffineEnvironment.transform 7 37 env48132 = env48133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48132 == env48133) = true)

theorem identity48133 : scanCanonicalize (H12AffineFastState.compose env48133 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound48133 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48134 : List Nat := [2,4,8,16,32,48,9,37,512,543,554,48,41,522,0,34,539,555,543,1,1,32,17,35,40,49,523,539,49,554,543,0,37,33,523,512]

theorem envBound48134 : H12AffineFastState.Bounded env48134 := by
  intro p hp
  have h : env48134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48133_48134 : H12AffineEnvironment.transform 9 543 env48133 = env48134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env48133 == env48134) = true)

theorem identity48134 : scanCanonicalize (H12AffineFastState.compose env48134 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound48134 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env48135 : List Nat := [2,4,8,8,32,40,9,37,512,519,554,40,41,522,0,34,515,555,519,1,1,32,9,35,40,41,523,515,41,554,519,0,37,33,523,512]

theorem envBound48135 : H12AffineFastState.Bounded env48135 := by
  intro p hp
  have h : env48135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48134_48135 : H12AffineEnvironment.transform 3 8 env48134 = env48135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env48134 == env48135) = true)

theorem identity48135 : scanCanonicalize (H12AffineFastState.compose env48135 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48135 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48136 : List Nat := [2,4,8,8,32,40,9,37,43,44,1,40,41,33,0,34,40,0,44,1,1,32,9,35,40,41,32,40,41,1,44,0,37,33,32,43]

theorem envBound48136 : H12AffineFastState.Bounded env48136 := by
  intro p hp
  have h : env48136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48135_48136 : H12AffineEnvironment.transform 8 43 env48135 = env48136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48135 == env48136) = true)

def env48137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101329,98780,8328,65,6338877,2098513,17664,2111713,2102685,6349852,256,21793,46212,2175562]

theorem envBound48137 : H12AffineFastState.Bounded env48137 := by
  intro p hp
  have h : env48137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48101_48137 : H12AffineEnvironment.transform 17 190641 env48101 = env48137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env48101 == env48137) = true)

def env48138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,17,98780,8328,65,4237693,5393,17664,10401,1501,4256860,256,21793,46212,74250]

theorem envBound48138 : H12AffineFastState.Bounded env48138 := by
  intro p hp
  have h : env48138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48137_48138 : H12AffineEnvironment.transform 20 4160 env48137 = env48138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48137 == env48138) = true)

theorem identity48138 : scanCanonicalize (H12AffineFastState.compose env48138 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201967) := by decide +kernel

theorem selectedBound48138 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,201967,17,98780,8328,65,245138,5393,17664,10401,1501,254131,256,21793,46212,74250]

theorem envBound48139 : H12AffineFastState.Bounded env48139 := by
  intro p hp
  have h : env48139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48138_48139 : H12AffineEnvironment.transform 21 201967 env48138 = env48139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201967 env48138 == env48139) = true)

def env48140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,201831,17,98644,8192,65,245018,5393,17664,10281,1365,254011,256,21793,46092,74250]

theorem envBound48140 : H12AffineFastState.Bounded env48140 := by
  intro p hp
  have h : env48140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48139_48140 : H12AffineEnvironment.transform 6 8 env48139 = env48140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48139 == env48140) = true)

theorem identity48140 : scanCanonicalize (H12AffineFastState.compose env48140 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48140 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4160,201831,17,73737,8192,65,203847,5393,17664,10281,1365,213350,256,21793,5457,74250]

theorem envBound48141 : H12AffineFastState.Bounded env48141 := by
  intro p hp
  have h : env48141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48140_48141 : H12AffineEnvironment.transform 14 8541 env48140 = env48141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48140 == env48141) = true)

theorem identity48141 : scanCanonicalize (H12AffineFastState.compose env48141 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound48141 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48142 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,65536,131072,146793,1024,8540,4160,201831,17,73737,8192,65,203847,5393,12557,10281,1365,210283,256,8492,5457,74250]

theorem envBound48142 : H12AffineFastState.Bounded env48142 := by
  intro p hp
  have h : env48142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48141_48142 : H12AffineEnvironment.transform 13 13325 env48141 = env48142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env48141 == env48142) = true)

theorem identity48142 : scanCanonicalize (H12AffineFastState.compose env48142 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 79178) := by decide +kernel

theorem selectedBound48142 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48143 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8541,65536,79178,67619,1024,8540,4160,8493,17,73737,8192,65,10509,5393,12557,10281,1365,33,256,8492,5457,74250]

theorem envBound48143 : H12AffineFastState.Bounded env48143 := by
  intro p hp
  have h : env48143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48142_48143 : H12AffineEnvironment.transform 16 79178 env48142 = env48143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79178 env48142 == env48143) = true)

theorem identity48143 : scanCanonicalize (H12AffineFastState.compose env48143 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound48143 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48144 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,4405,1125,65536,69746,67619,1024,1124,4160,1045,17,66865,1336,65,3125,5393,5173,3345,1365,33,256,1044,5457,67378]

theorem envBound48144 : H12AffineFastState.Bounded env48144 := by
  intro p hp
  have h : env48144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48143_48144 : H12AffineEnvironment.transform 12 1336 env48143 = env48144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env48143 == env48144) = true)

theorem identity48144 : scanCanonicalize (H12AffineFastState.compose env48144 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound48144 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env48145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,1336,2421,1125,65536,67634,67619,1024,1124,2048,1045,17,66865,1336,65,3125,3409,3189,3345,1365,33,256,1044,3345,67378]

theorem envBound48145 : H12AffineFastState.Bounded env48145 := by
  intro p hp
  have h : env48145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48144_48145 : H12AffineEnvironment.transform 11 2112 env48144 = env48145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env48144 == env48145) = true)

theorem identity48145 : scanCanonicalize (H12AffineFastState.compose env48145 (packedSelected [0,1,3,5,7,8,12,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound48145 : packedSelected [0,1,3,5,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env48146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,1336,2421,1125,343,2405,2420,1024,1124,2048,1045,17,1126,1336,65,3125,3409,3189,3345,1365,33,256,1044,3345,1637]

theorem envBound48146 : H12AffineFastState.Bounded env48146 := by
  intro p hp
  have h : env48146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48145_48146 : H12AffineEnvironment.transform 15 343 env48145 = env48146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env48145 == env48146) = true)

theorem identity48146 : scanCanonicalize (H12AffineFastState.compose env48146 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound48146 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,1360,1336,1125,1125,343,1141,1124,1024,1124,1296,1045,17,1126,1336,65,293,65,357,1,1365,33,256,1044,1,1637]

theorem envBound48147 : H12AffineFastState.Bounded env48147 := by
  intro p hp
  have h : env48147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48146_48147 : H12AffineEnvironment.transform 10 1296 env48146 = env48147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env48146 == env48147) = true)

theorem identity48147 : scanCanonicalize (H12AffineFastState.compose env48147 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound48147 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env48148 : List Nat := [2,4,8,16,32,64,8,256,512,321,81,17,121,292,292,343,308,293,321,293,81,340,17,295,121,65,293,65,357,1,20,33,256,341,1,804]

theorem envBound48148 : H12AffineFastState.Bounded env48148 := by
  intro p hp
  have h : env48148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48147_48148 : H12AffineEnvironment.transform 9 321 env48147 = env48148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env48147 == env48148) = true)

theorem identity48148 : scanCanonicalize (H12AffineFastState.compose env48148 (packedSelected [0,2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound48148 : packedSelected [0,2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env48149 : List Nat := [2,4,8,16,20,64,8,256,512,321,81,17,77,272,272,343,256,273,321,273,81,340,17,275,77,65,273,65,337,1,20,21,256,341,1,784]

theorem envBound48149 : H12AffineFastState.Bounded env48149 := by
  intro p hp
  have h : env48149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48148_48149 : H12AffineEnvironment.transform 4 20 env48148 = env48149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env48148 == env48149) = true)

theorem identity48149 : scanCanonicalize (H12AffineFastState.compose env48149 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 16) := by decide +kernel

theorem selectedBound48149 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48150 : List Nat := [2,4,8,16,20,64,8,16,512,81,81,17,77,0,0,71,16,1,81,1,81,68,17,3,77,65,1,65,65,1,20,21,16,69,1,512]

theorem envBound48150 : H12AffineFastState.Bounded env48150 := by
  intro p hp
  have h : env48150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48149_48150 : H12AffineEnvironment.transform 7 16 env48149 = env48150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 16 env48149 == env48150) = true)

theorem identity48150 : scanCanonicalize (H12AffineFastState.compose env48150 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

theorem selectedBound48150 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48151 : List Nat := [2,4,8,16,20,15,8,16,512,30,30,17,2,0,0,8,16,1,30,1,30,11,17,3,2,14,1,14,14,1,20,21,16,10,1,512]

theorem envBound48151 : H12AffineFastState.Bounded env48151 := by
  intro p hp
  have h : env48151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48150_48151 : H12AffineEnvironment.transform 5 15 env48150 = env48151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env48150 == env48151) = true)

theorem identity48151 : scanCanonicalize (H12AffineFastState.compose env48151 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound48151 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env48152 : List Nat := [2,4,8,16,20,15,8,16,9,30,30,17,2,0,0,8,16,1,30,1,30,11,17,3,2,14,1,14,14,1,20,21,16,10,1,9]

theorem envBound48152 : H12AffineFastState.Bounded env48152 := by
  intro p hp
  have h : env48152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48151_48152 : H12AffineEnvironment.transform 8 9 env48151 = env48152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env48151 == env48152) = true)

theorem identity48152 : scanCanonicalize (H12AffineFastState.compose env48152 (packedSelected [0,1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48152 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env48153 : List Nat := [2,4,3,16,20,4,3,16,2,21,21,17,2,0,0,3,16,1,21,1,21,0,17,3,2,5,1,5,5,1,20,21,16,1,1,2]

theorem envBound48153 : H12AffineFastState.Bounded env48153 := by
  intro p hp
  have h : env48153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48152_48153 : H12AffineEnvironment.transform 2 3 env48152 = env48153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48152 == env48153) = true)

theorem identity48153 : scanCanonicalize (H12AffineFastState.compose env48153 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48154 : List Nat := [2,4,3,0,4,4,3,0,2,5,5,1,2,0,0,3,0,1,5,1,5,0,1,3,2,5,1,5,5,1,4,5,0,1,1,2]

theorem envBound48154 : H12AffineFastState.Bounded env48154 := by
  intro p hp
  have h : env48154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48153_48154 : H12AffineEnvironment.transform 3 0 env48153 = env48154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48153 == env48154) = true)

def env48155 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,201830,17,98645,8193,65,245019,5393,17664,10280,1364,254010,256,21793,46093,74250]

theorem envBound48155 : H12AffineFastState.Bounded env48155 := by
  intro p hp
  have h : env48155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48139_48155 : H12AffineEnvironment.transform 6 9 env48139 = env48155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48139 == env48155) = true)

theorem identity48155 : scanCanonicalize (H12AffineFastState.compose env48155 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound48155 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48156 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190520,1024,32769,4160,169265,17,2,8193,65,146508,5393,17664,10280,1364,156013,256,21793,46093,41821]

theorem envBound48156 : H12AffineFastState.Bounded env48156 := by
  intro p hp
  have h : env48156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48155_48156 : H12AffineEnvironment.transform 15 33111 env48155 = env48156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env48155 == env48156) = true)

theorem identity48156 : scanCanonicalize (H12AffineFastState.compose env48156 (packedSelected [7,8,10,12,14,15,16,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound48156 : packedSelected [7,8,10,12,14,15,16,27,28] rootPS < 2^1333 := by decide +kernel

def env48157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57676,2420,1024,32769,4160,29821,17,2,8193,65,56576,5393,17664,10280,1364,32801,256,21793,46093,41821]

theorem envBound48157 : H12AffineFastState.Bounded env48157 := by
  intro p hp
  have h : env48157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48156_48157 : H12AffineEnvironment.transform 16 57676 env48156 = env48157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env48156 == env48157) = true)

theorem identity48157 : scanCanonicalize (H12AffineFastState.compose env48157 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound48157 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env48158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,5393,2420,1024,29788,4160,29821,17,2,8193,65,10589,5393,17664,10280,1364,29820,256,21793,16464,22272]

theorem envBound48158 : H12AffineFastState.Bounded env48158 := by
  intro p hp
  have h : env48158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48157_48158 : H12AffineEnvironment.transform 14 29789 env48157 = env48158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env48157 == env48158) = true)

theorem identity48158 : scanCanonicalize (H12AffineFastState.compose env48158 (packedSelected [0,7,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 6160) := by decide +kernel

theorem selectedBound48158 : packedSelected [0,7,11,18] rootPS < 2^1333 := by decide +kernel

def env48159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,6160,11341,11546,5393,2420,1024,11340,4160,11373,17,2,8193,65,10589,5393,7440,10280,1364,11372,256,3377,6208,3856]

theorem envBound48159 : H12AffineFastState.Bounded env48159 := by
  intro p hp
  have h : env48159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48158_48159 : H12AffineEnvironment.transform 13 6160 env48158 = env48159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6160 env48158 == env48159) = true)

theorem identity48159 : scanCanonicalize (H12AffineFastState.compose env48159 (packedSelected [0,1,2,4,6,7,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1376) := by decide +kernel

theorem selectedBound48159 : packedSelected [0,1,2,4,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env48160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1376,4096,8192,5488,8493,8314,5393,1044,1024,8492,4160,8461,17,2,8193,65,9277,5393,4208,9544,1364,8460,256,81,5408,624]

theorem envBound48160 : H12AffineFastState.Bounded env48160 := by
  intro p hp
  have h : env48160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48159_48160 : H12AffineEnvironment.transform 10 1376 env48159 = env48160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1376 env48159 == env48160) = true)

theorem identity48160 : scanCanonicalize (H12AffineFastState.compose env48160 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48160 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48161 : List Nat := [2,4,8,16,0,64,9,256,512,1024,1344,4096,8192,5456,8461,8282,5393,1044,1024,8460,4160,8461,17,2,8193,65,9245,5393,4176,9544,1364,8460,256,81,5376,592]

theorem envBound48161 : H12AffineFastState.Bounded env48161 := by
  intro p hp
  have h : env48161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48160_48161 : H12AffineEnvironment.transform 4 0 env48160 = env48161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48160 == env48161) = true)

theorem identity48161 : scanCanonicalize (H12AffineFastState.compose env48161 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48161 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48162 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1296,4096,8192,5376,8461,8202,5393,1044,1024,8460,4112,8461,17,2,8193,17,9245,5393,4096,9496,1284,8460,256,1,5376,512]

theorem envBound48162 : H12AffineFastState.Bounded env48162 := by
  intro p hp
  have h : env48162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48161_48162 : H12AffineEnvironment.transform 5 16 env48161 = env48162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48161 == env48162) = true)

theorem identity48162 : scanCanonicalize (H12AffineFastState.compose env48162 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48162 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48163 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1296,4096,268,5376,1,262,5393,1044,1024,0,4112,1,17,2,269,17,1297,5393,4096,1044,1284,0,256,1,5376,512]

theorem envBound48163 : H12AffineFastState.Bounded env48163 := by
  intro p hp
  have h : env48163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48162_48163 : H12AffineEnvironment.transform 12 268 env48162 = env48163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48162 == env48163) = true)

theorem identity48163 : scanCanonicalize (H12AffineFastState.compose env48163 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound48163 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48164 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1296,276,268,1044,1,262,1029,1044,1024,0,260,1,17,2,269,17,1297,1029,276,1044,1284,0,256,1,1044,512]

theorem envBound48164 : H12AffineFastState.Bounded env48164 := by
  intro p hp
  have h : env48164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48163_48164 : H12AffineEnvironment.transform 11 276 env48163 = env48164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env48163 == env48164) = true)

theorem identity48164 : scanCanonicalize (H12AffineFastState.compose env48164 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound48164 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48165 : List Nat := [2,4,8,16,0,16,9,256,512,20,260,276,268,0,1,262,17,0,20,0,260,1,17,2,269,17,261,17,276,0,272,0,256,1,0,512]

theorem envBound48165 : H12AffineFastState.Bounded env48165 := by
  intro p hp
  have h : env48165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48164_48165 : H12AffineEnvironment.transform 9 20 env48164 = env48165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env48164 == env48165) = true)

def env48166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,16,98780,8328,65,4237692,5392,17664,10400,1500,4256861,256,21793,46212,74251]

theorem envBound48166 : H12AffineFastState.Bounded env48166 := by
  intro p hp
  have h : env48166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48137_48166 : H12AffineEnvironment.transform 20 4161 env48137 = env48166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48137 == env48166) = true)

theorem identity48166 : scanCanonicalize (H12AffineFastState.compose env48166 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound48166 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,190641,1024,32769,4161,4194304,16,21763,8328,65,4237692,5392,17664,10400,1500,4256861,256,21793,46212,63188]

theorem envBound48167 : H12AffineFastState.Bounded env48167 := by
  intro p hp
  have h : env48167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48166_48167 : H12AffineEnvironment.transform 15 54495 env48166 = env48167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env48166 == env48167) = true)

def env48168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4161,4194304,16,21763,8192,65,4237692,5392,17664,10280,1364,4256861,256,21793,46092,63068]

theorem envBound48168 : H12AffineFastState.Bounded env48168 := by
  intro p hp
  have h : env48168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48167_48168 : H12AffineEnvironment.transform 6 8 env48167 = env48168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48167 == env48168) = true)

theorem identity48168 : scanCanonicalize (H12AffineFastState.compose env48168 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound48168 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24909,35188,1024,32769,4161,4194304,16,21763,8192,65,4237692,5392,17664,10280,1364,4256861,256,21793,46092,63068]

theorem envBound48169 : H12AffineFastState.Bounded env48169 := by
  intro p hp
  have h : env48169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48168_48169 : H12AffineEnvironment.transform 16 24909 env48168 = env48169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env48168 == env48169) = true)

theorem identity48169 : scanCanonicalize (H12AffineFastState.compose env48169 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 54561) := by decide +kernel

theorem selectedBound48169 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24909,35188,1024,32769,4161,54561,16,21763,8192,65,31837,5392,17664,10280,1364,8572,256,21793,46092,63068]

theorem envBound48170 : H12AffineFastState.Bounded env48170 := by
  intro p hp
  have h : env48170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48169_48170 : H12AffineEnvironment.transform 21 54561 env48169 = env48170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54561 env48169 == env48170) = true)

theorem identity48170 : scanCanonicalize (H12AffineFastState.compose env48170 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48170 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env48171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,24909,10281,1024,8540,4161,29820,16,21763,8192,65,31837,5392,17664,10280,1364,8572,256,21793,5457,22273]

theorem envBound48171 : H12AffineFastState.Bounded env48171 := by
  intro p hp
  have h : env48171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48170_48171 : H12AffineEnvironment.transform 14 8541 env48170 = env48171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48170 == env48171) = true)

theorem identity48171 : scanCanonicalize (H12AffineFastState.compose env48171 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound48171 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48172 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,9498,12637,10281,1024,8540,4161,9324,16,1299,8192,65,11341,5392,5392,10280,1364,8572,256,1329,5457,1809]

theorem envBound48172 : H12AffineFastState.Bounded env48172 := by
  intro p hp
  have h : env48172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48171_48172 : H12AffineEnvironment.transform 13 4112 env48171 = env48172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env48171 == env48172) = true)

theorem identity48172 : scanCanonicalize (H12AffineFastState.compose env48172 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound48172 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env48173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,4112,1125,34,5221,3345,1024,1124,4161,340,16,1299,1336,65,2421,5392,5392,3344,1364,1092,256,1329,5457,1809]

theorem envBound48173 : H12AffineFastState.Bounded env48173 := by
  intro p hp
  have h : env48173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48172_48173 : H12AffineEnvironment.transform 12 1336 env48172 = env48173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env48172 == env48173) = true)

theorem identity48173 : scanCanonicalize (H12AffineFastState.compose env48173 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48173 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48174 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4112,373,34,4469,2049,272,372,4161,340,16,3,40,65,2421,4096,4096,2048,68,340,256,33,4161,513]

theorem envBound48174 : H12AffineFastState.Bounded env48174 := by
  intro p hp
  have h : env48174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48173_48174 : H12AffineEnvironment.transform 9 272 env48173 = env48174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48173 == env48174) = true)

theorem identity48174 : scanCanonicalize (H12AffineFastState.compose env48174 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48174 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48175 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,40,4112,293,34,4389,2049,272,292,4113,260,16,3,40,17,2341,4096,4096,2048,20,260,256,33,4113,513]

theorem envBound48175 : H12AffineFastState.Bounded env48175 := by
  intro p hp
  have h : env48175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48174_48175 : H12AffineEnvironment.transform 5 16 env48174 = env48175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48174 == env48175) = true)

theorem identity48175 : scanCanonicalize (H12AffineFastState.compose env48175 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound48175 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env48176 : List Nat := [2,4,8,16,32,16,8,53,512,37,2048,4096,40,4112,16,34,4112,2049,37,17,4113,49,16,3,40,17,2064,4096,4096,2048,20,49,53,33,4113,513]

theorem envBound48176 : H12AffineFastState.Bounded env48176 := by
  intro p hp
  have h : env48176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48175_48176 : H12AffineEnvironment.transform 7 53 env48175 = env48176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env48175 == env48176) = true)

def env48177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4161,4194304,16,21763,8193,65,4237692,5392,17664,10281,1365,4256861,256,21793,46093,63069]

theorem envBound48177 : H12AffineFastState.Bounded env48177 := by
  intro p hp
  have h : env48177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48167_48177 : H12AffineEnvironment.transform 6 9 env48167 = env48177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48167 == env48177) = true)

theorem identity48177 : scanCanonicalize (H12AffineFastState.compose env48177 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound48177 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,10280,1024,32769,4161,4194304,16,21763,8193,65,4237692,5392,17664,10281,1365,4256861,256,21793,46093,63069]

theorem envBound48178 : H12AffineFastState.Bounded env48178 := by
  intro p hp
  have h : env48178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48177_48178 : H12AffineEnvironment.transform 16 49168 env48177 = env48178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env48177 == env48178) = true)

theorem identity48178 : scanCanonicalize (H12AffineFastState.compose env48178 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound48178 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,21510,16448,10280,1024,81,4161,4194304,16,21763,8193,65,4204844,5392,17664,10281,1365,4224013,256,21793,13405,30221]

theorem envBound48179 : H12AffineFastState.Bounded env48179 := by
  intro p hp
  have h : env48179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48178_48179 : H12AffineEnvironment.transform 14 80 env48178 = env48179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env48178 == env48179) = true)

theorem identity48179 : scanCanonicalize (H12AffineFastState.compose env48179 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48179 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env48180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,80,21510,16448,2420,1024,81,4161,4194304,16,21763,349,65,4196464,5392,17664,2421,1365,4216145,256,21793,5377,22353]

theorem envBound48180 : H12AffineFastState.Bounded env48180 := by
  intro p hp
  have h : env48180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48179_48180 : H12AffineEnvironment.transform 12 348 env48179 = env48180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48179 == env48180) = true)

theorem identity48180 : scanCanonicalize (H12AffineFastState.compose env48180 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48180 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48181 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,21510,16400,2340,1024,1,4113,4194304,16,21763,269,17,4196384,5392,17664,2341,1285,4216065,256,21793,5377,22273]

theorem envBound48181 : H12AffineFastState.Bounded env48181 := by
  intro p hp
  have h : env48181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48180_48181 : H12AffineEnvironment.transform 5 16 env48180 = env48181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48180 == env48181) = true)

theorem identity48181 : scanCanonicalize (H12AffineFastState.compose env48181 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound48181 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48182 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,21510,16400,2340,1024,1,4113,21793,16,21763,269,17,23809,5392,17664,2341,1285,32,256,21793,5377,22273]

theorem envBound48182 : H12AffineFastState.Bounded env48182 := by
  intro p hp
  have h : env48182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48181_48182 : H12AffineEnvironment.transform 21 21793 env48181 = env48182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env48181 == env48182) = true)

theorem identity48182 : scanCanonicalize (H12AffineFastState.compose env48182 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound48182 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env48183 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,4113,0,1047,4097,2340,1024,1,4113,1328,16,1298,269,17,3344,5392,5393,2341,1285,32,256,1328,5377,1808]

theorem envBound48183 : H12AffineFastState.Bounded env48183 := by
  intro p hp
  have h : env48183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48182_48183 : H12AffineEnvironment.transform 13 4113 env48182 = env48183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env48182 == env48183) = true)

theorem identity48183 : scanCanonicalize (H12AffineFastState.compose env48183 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound48183 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env48184 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3329,268,3344,0,1047,3328,2340,1024,1,3344,1328,16,1298,269,17,3344,2065,2064,2341,1285,32,256,1328,2048,1808]

theorem envBound48184 : H12AffineFastState.Bounded env48184 := by
  intro p hp
  have h : env48184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48183_48184 : H12AffineEnvironment.transform 11 3329 env48183 = env48184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env48183 == env48184) = true)

def env48185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2554081,485741,8328,65,6705549,2551264,437680,2111712,2102684,6687917,256,21792,46213,2175563]

theorem envBound48185 : H12AffineFastState.Bounded env48185 := by
  intro p hp
  have h : env48185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48100_48185 : H12AffineEnvironment.transform 22 2554081 env48100 = env48185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2554081 env48100 == env48185) = true)

def env48186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101329,98781,8328,65,6338877,2098512,17664,2111712,2102684,6349853,256,21792,46213,2175563]

theorem envBound48186 : H12AffineFastState.Bounded env48186 := by
  intro p hp
  have h : env48186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48185_48186 : H12AffineEnvironment.transform 17 190640 env48185 = env48186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env48185 == env48186) = true)

def env48187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,17,98781,8328,65,4237693,5392,17664,10400,1500,4256861,256,21792,46213,74251]

theorem envBound48187 : H12AffineFastState.Bounded env48187 := by
  intro p hp
  have h : env48187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48186_48187 : H12AffineEnvironment.transform 20 4160 env48186 = env48187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48186 == env48187) = true)

theorem identity48187 : scanCanonicalize (H12AffineFastState.compose env48187 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180272) := by decide +kernel

theorem selectedBound48187 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,180272,17,98781,8328,65,158029,5392,17664,10400,1500,144493,256,21792,46213,74251]

theorem envBound48188 : H12AffineFastState.Bounded env48188 := by
  intro p hp
  have h : env48188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48187_48188 : H12AffineEnvironment.transform 21 180272 env48187 = env48188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env48187 == env48188) = true)

theorem identity48188 : scanCanonicalize (H12AffineFastState.compose env48188 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48188 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env48189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190640,1024,32769,4160,180272,17,41431,8328,65,158029,5392,17664,10400,1500,144493,256,21792,46213,513]

theorem envBound48189 : H12AffineFastState.Bounded env48189 := by
  intro p hp
  have h : env48189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48188_48189 : H12AffineEnvironment.transform 15 8202 env48188 = env48189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48188 == env48189) = true)

theorem identity48189 : scanCanonicalize (H12AffineFastState.compose env48189 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound48189 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43168,1024,32769,4160,32800,17,41431,8328,65,10589,5392,17664,10400,1500,29821,256,21792,46213,513]

theorem envBound48190 : H12AffineFastState.Bounded env48190 := by
  intro p hp
  have h : env48190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48189_48190 : H12AffineEnvironment.transform 16 16400 env48189 = env48190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env48189 == env48190) = true)

theorem identity48190 : scanCanonicalize (H12AffineFastState.compose env48190 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound48190 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env48191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,16400,23724,1024,29709,4160,29740,17,21979,8328,65,10589,5392,17664,10400,1500,29821,256,21792,16521,513]

theorem envBound48191 : H12AffineFastState.Bounded env48191 := by
  intro p hp
  have h : env48191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48190_48191 : H12AffineEnvironment.transform 14 29708 env48190 = env48191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env48190 == env48191) = true)

theorem identity48191 : scanCanonicalize (H12AffineFastState.compose env48191 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48191 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env48192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8202,16400,23588,1024,29709,4160,29740,17,21843,8192,65,10589,5392,17664,10280,1364,29821,256,21792,16385,513]

theorem envBound48192 : H12AffineFastState.Bounded env48192 := by
  intro p hp
  have h : env48192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48191_48192 : H12AffineEnvironment.transform 6 8 env48191 = env48192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48191 == env48192) = true)

theorem identity48192 : scanCanonicalize (H12AffineFastState.compose env48192 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound48192 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,9528,8202,4388,3344,1024,9529,4160,9496,17,1127,8192,65,10589,5392,5172,10280,1364,9545,256,1044,4405,513]

theorem envBound48193 : H12AffineFastState.Bounded env48193 := by
  intro p hp
  have h : env48193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48192_48193 : H12AffineEnvironment.transform 13 4404 env48192 = env48193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env48192 == env48193) = true)

theorem identity48193 : scanCanonicalize (H12AffineFastState.compose env48193 (packedSelected [0,4,5,6,7,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48193 : packedSelected [0,4,5,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env48194 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4161,9293,8202,4177,3173,1024,9292,4160,9325,17,1127,8192,65,10280,5221,5172,10280,1057,9276,117,1044,4160,513]

theorem envBound48194 : H12AffineFastState.Bounded env48194 := by
  intro p hp
  have h : env48194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48193_48194 : H12AffineEnvironment.transform 7 117 env48193 = env48194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48193 == env48194) = true)

theorem identity48194 : scanCanonicalize (H12AffineFastState.compose env48194 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48194 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48195 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,8192,4161,8312,8202,4177,2128,53,8313,4160,8280,17,82,8192,65,10280,4176,4097,10280,20,8201,117,33,4160,513]

theorem envBound48195 : H12AffineFastState.Bounded env48195 := by
  intro p hp
  have h : env48195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48194_48195 : H12AffineEnvironment.transform 9 53 env48194 = env48195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48194 == env48195) = true)

theorem identity48195 : scanCanonicalize (H12AffineFastState.compose env48195 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48195 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48196 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,8192,4112,8233,8202,4096,2049,53,8232,4113,8201,17,3,8192,16,10280,4097,4097,10280,20,8201,36,33,4113,513]

theorem envBound48196 : H12AffineFastState.Bounded env48196 := by
  intro p hp
  have h : env48196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48195_48196 : H12AffineEnvironment.transform 5 17 env48195 = env48196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48195 == env48196) = true)

def env48197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,16,98781,8328,65,4237692,5393,17664,10401,1501,4256860,256,21792,46213,74250]

theorem envBound48197 : H12AffineFastState.Bounded env48197 := by
  intro p hp
  have h : env48197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48186_48197 : H12AffineEnvironment.transform 20 4161 env48186 = env48197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48186 == env48197) = true)

def env48198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,98645,8192,65,4237692,5393,17664,10281,1365,4256860,256,21792,46093,74250]

theorem envBound48198 : H12AffineFastState.Bounded env48198 := by
  intro p hp
  have h : env48198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48197_48198 : H12AffineEnvironment.transform 6 8 env48197 = env48198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48197 == env48198) = true)

theorem identity48198 : scanCanonicalize (H12AffineFastState.compose env48198 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound48198 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1024,32769,4161,4194304,16,98645,8192,65,4237692,5393,17664,10281,1365,4256860,256,21792,46093,74250]

theorem envBound48199 : H12AffineFastState.Bounded env48199 := by
  intro p hp
  have h : env48199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48198_48199 : H12AffineEnvironment.transform 16 24908 env48198 = env48199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env48198 == env48199) = true)

theorem identity48199 : scanCanonicalize (H12AffineFastState.compose env48199 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 62509) := by decide +kernel

theorem selectedBound48199 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1024,32769,4161,62509,16,98645,8192,65,23889,5393,17664,10281,1365,113,256,21792,46093,74250]

theorem envBound48200 : H12AffineFastState.Bounded env48200 := by
  intro p hp
  have h : env48200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48199_48200 : H12AffineEnvironment.transform 21 62509 env48199 = env48200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62509 env48199 == env48200) = true)

theorem identity48200 : scanCanonicalize (H12AffineFastState.compose env48200 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound48200 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env48201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30042,24908,35188,1024,32769,4161,62509,16,62479,8192,65,23889,5393,17664,10281,1365,113,256,21792,46093,22352]

theorem envBound48201 : H12AffineFastState.Bounded env48201 := by
  intro p hp
  have h : env48201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48200_48201 : H12AffineEnvironment.transform 15 30042 env48200 = env48201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env48200 == env48201) = true)

theorem identity48201 : scanCanonicalize (H12AffineFastState.compose env48201 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound48201 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env48202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,30042,24908,2341,1024,80,4161,29820,16,29790,8192,65,23889,5393,17664,10281,1365,113,256,21792,13404,22352]

theorem envBound48202 : H12AffineFastState.Bounded env48202 := by
  intro p hp
  have h : env48202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48201_48202 : H12AffineEnvironment.transform 14 81 env48201 = env48202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env48201 == env48202) = true)

theorem identity48202 : scanCanonicalize (H12AffineFastState.compose env48202 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound48202 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env48203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5125,81,8543,13641,2341,1024,80,4161,8313,16,8283,8192,65,2388,5393,4357,10281,1365,113,256,293,13404,853]

theorem envBound48203 : H12AffineFastState.Bounded env48203 := by
  intro p hp
  have h : env48203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48202_48203 : H12AffineEnvironment.transform 13 5125 env48202 = env48203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env48202 == env48203) = true)

theorem identity48203 : scanCanonicalize (H12AffineFastState.compose env48203 (packedSelected [4,6,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48203 : packedSelected [4,6,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5125,81,83,5189,2341,1024,80,4161,373,16,343,268,65,2388,5393,4357,2341,1365,113,256,293,5456,853]

theorem envBound48204 : H12AffineFastState.Bounded env48204 := by
  intro p hp
  have h : env48204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48203_48204 : H12AffineEnvironment.transform 12 268 env48203 = env48204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48203 == env48204) = true)

theorem identity48204 : scanCanonicalize (H12AffineFastState.compose env48204 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48204 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48205 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,121,5125,81,83,5189,2128,1024,80,4161,0,16,34,121,65,2081,5220,4208,2128,1056,113,117,80,5157,544]

theorem envBound48205 : H12AffineFastState.Bounded env48205 := by
  intro p hp
  have h : env48205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48204_48205 : H12AffineEnvironment.transform 7 117 env48204 = env48205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48204 == env48205) = true)

theorem identity48205 : scanCanonicalize (H12AffineFastState.compose env48205 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound48205 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48206 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2065,121,3092,81,83,3156,2128,1024,80,2128,0,16,34,121,65,2081,3189,2145,2128,1056,113,117,80,3124,544]

theorem envBound48206 : H12AffineFastState.Bounded env48206 := by
  intro p hp
  have h : env48206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48205_48206 : H12AffineEnvironment.transform 11 2065 env48205 = env48206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env48205 == env48206) = true)

theorem identity48206 : scanCanonicalize (H12AffineFastState.compose env48206 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound48206 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env48207 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1092,1109,121,80,81,83,16,1044,1024,80,1044,0,16,34,121,65,1125,49,1061,1044,1056,113,117,80,112,544]

theorem envBound48207 : H12AffineFastState.Bounded env48207 := by
  intro p hp
  have h : env48207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48206_48207 : H12AffineEnvironment.transform 10 1092 env48206 = env48207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env48206 == env48207) = true)

theorem identity48207 : scanCanonicalize (H12AffineFastState.compose env48207 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound48207 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48208 : List Nat := [2,4,8,16,32,64,8,117,512,100,32,49,121,80,81,83,16,112,100,80,112,0,16,34,121,65,1,49,65,112,68,113,117,80,112,544]

theorem envBound48208 : H12AffineFastState.Bounded env48208 := by
  intro p hp
  have h : env48208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48207_48208 : H12AffineEnvironment.transform 9 100 env48207 = env48208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env48207 == env48208) = true)

theorem identity48208 : scanCanonicalize (H12AffineFastState.compose env48208 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound48208 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48209 : List Nat := [2,4,8,16,32,0,8,53,512,36,32,49,57,16,17,19,16,48,36,16,48,0,16,34,57,1,1,49,1,48,4,49,53,16,48,544]

theorem envBound48209 : H12AffineFastState.Bounded env48209 := by
  intro p hp
  have h : env48209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48208_48209 : H12AffineEnvironment.transform 5 0 env48208 = env48209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48208 == env48209) = true)

theorem identity48209 : scanCanonicalize (H12AffineFastState.compose env48209 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound48209 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env48210 : List Nat := [2,4,8,16,32,0,8,53,33,36,32,49,57,16,17,19,16,48,36,16,48,0,16,34,57,1,1,49,1,48,4,49,53,16,48,1]

theorem envBound48210 : H12AffineFastState.Bounded env48210 := by
  intro p hp
  have h : env48210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48209_48210 : H12AffineEnvironment.transform 8 33 env48209 = env48210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env48209 == env48210) = true)

theorem identity48210 : scanCanonicalize (H12AffineFastState.compose env48210 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48210 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48211 : List Nat := [2,4,8,16,0,0,8,21,1,4,0,17,25,16,17,19,16,16,4,16,16,0,16,2,25,1,1,17,1,16,4,17,21,16,16,1]

theorem envBound48211 : H12AffineFastState.Bounded env48211 := by
  intro p hp
  have h : env48211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48210_48211 : H12AffineEnvironment.transform 4 0 env48210 = env48211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48210 == env48211) = true)

def env48212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,98644,8193,65,4237692,5393,17664,10280,1364,4256860,256,21792,46092,74250]

theorem envBound48212 : H12AffineFastState.Bounded env48212 := by
  intro p hp
  have h : env48212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48197_48212 : H12AffineEnvironment.transform 6 9 env48197 = env48212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48197 == env48212) = true)

theorem identity48212 : scanCanonicalize (H12AffineFastState.compose env48212 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound48212 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,4194304,16,98644,8193,65,4237692,5393,17664,10280,1364,4256860,256,21792,46092,74250]

theorem envBound48213 : H12AffineFastState.Bounded env48213 := by
  intro p hp
  have h : env48213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48212_48213 : H12AffineEnvironment.transform 16 49169 env48212 = env48213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48212 == env48213) = true)

theorem identity48213 : scanCanonicalize (H12AffineFastState.compose env48213 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 65910) := by decide +kernel

theorem selectedBound48213 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env48214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,65910,16,98644,8193,65,108554,5393,17664,10280,1364,128298,256,21792,46092,74250]

theorem envBound48214 : H12AffineFastState.Bounded env48214 := by
  intro p hp
  have h : env48214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48213_48214 : H12AffineEnvironment.transform 21 65910 env48213 = env48214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65910 env48213 == env48214) = true)

theorem identity48214 : scanCanonicalize (H12AffineFastState.compose env48214 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48214 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env48215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10280,1024,32769,4161,8573,16,41311,8193,65,34817,5393,17664,10280,1364,54561,256,21792,46092,513]

theorem envBound48215 : H12AffineFastState.Bounded env48215 := by
  intro p hp
  have h : env48215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48214_48215 : H12AffineEnvironment.transform 15 8203 env48214 = env48215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48214 == env48215) = true)

theorem identity48215 : scanCanonicalize (H12AffineFastState.compose env48215 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48215 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48216 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,38161,10280,1024,32769,4161,8573,16,41311,8193,65,34817,5393,4096,10280,1364,32801,256,32,46092,513]

theorem envBound48216 : H12AffineFastState.Bounded env48216 := by
  intro p hp
  have h : env48216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48215_48216 : H12AffineEnvironment.transform 13 5376 env48215 = env48216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48215 == env48216) = true)

theorem identity48216 : scanCanonicalize (H12AffineFastState.compose env48216 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound48216 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,8203,5392,10280,1024,0,4161,8573,16,8542,8193,65,2048,5393,4096,10280,1364,32,256,32,13325,513]

theorem envBound48217 : H12AffineFastState.Bounded env48217 := by
  intro p hp
  have h : env48217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48216_48217 : H12AffineEnvironment.transform 14 1 env48216 = env48217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env48216 == env48217) = true)

theorem identity48217 : scanCanonicalize (H12AffineFastState.compose env48217 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 3378) := by decide +kernel

theorem selectedBound48217 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3378,5376,1,3385,5392,1306,1024,0,4161,3151,16,3180,3379,65,2048,5393,4096,1306,1364,32,256,32,6463,513]

theorem envBound48218 : H12AffineFastState.Bounded env48218 := by
  intro p hp
  have h : env48218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48217_48218 : H12AffineEnvironment.transform 12 3378 env48217 = env48218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3378 env48217 == env48218) = true)

def env48219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101328,98780,8328,65,6338876,2098513,17665,2111712,2102684,6349852,256,21792,46213,2175563]

theorem envBound48219 : H12AffineFastState.Bounded env48219 := by
  intro p hp
  have h : env48219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48185_48219 : H12AffineEnvironment.transform 17 190641 env48185 = env48219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env48185 == env48219) = true)

def env48220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,16,98780,8328,65,4237692,5393,17665,10400,1500,4256860,256,21792,46213,74251]

theorem envBound48220 : H12AffineFastState.Bounded env48220 := by
  intro p hp
  have h : env48220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48219_48220 : H12AffineEnvironment.transform 20 4160 env48219 = env48220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48219 == env48220) = true)

theorem identity48220 : scanCanonicalize (H12AffineFastState.compose env48220 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound48220 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138341,1024,29909,4160,4194304,16,95496,8328,65,4218280,5393,17665,10400,1500,4194440,256,21792,16465,74251]

theorem envBound48221 : H12AffineFastState.Bounded env48221 := by
  intro p hp
  have h : env48221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48220_48221 : H12AffineEnvironment.transform 14 29908 env48220 = env48221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env48220 == env48221) = true)

def env48222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138341,1024,8661,4160,4194304,16,73736,8328,65,4196520,5393,4097,10400,1500,4194440,256,32,5457,74251]

theorem envBound48222 : H12AffineFastState.Bounded env48222 := by
  intro p hp
  have h : env48222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48221_48222 : H12AffineEnvironment.transform 13 5376 env48221 = env48222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48221 == env48222) = true)

theorem identity48222 : scanCanonicalize (H12AffineFastState.compose env48222 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound48222 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13389,10280,1024,8661,4160,4194304,16,73736,8328,65,4196520,5393,4097,10400,1500,4194440,256,32,5457,74251]

theorem envBound48223 : H12AffineFastState.Bounded env48223 := by
  intro p hp
  have h : env48223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48222_48223 : H12AffineEnvironment.transform 16 13389 env48222 = env48223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env48222 == env48223) = true)

theorem identity48223 : scanCanonicalize (H12AffineFastState.compose env48223 (packedSelected [2,3,5,6,7,9,10,16,22,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48223 : packedSelected [2,3,5,6,7,9,10,16,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env48224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13389,10280,1024,8661,4160,4194304,16,3,8328,65,4196520,5393,4097,10400,1500,4194440,256,32,5457,512]

theorem envBound48224 : H12AffineFastState.Bounded env48224 := by
  intro p hp
  have h : env48224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48223_48224 : H12AffineEnvironment.transform 15 8203 env48223 = env48224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48223 == env48224) = true)

theorem identity48224 : scanCanonicalize (H12AffineFastState.compose env48224 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound48224 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,380,5376,168,375,5425,2388,1024,169,4160,4194304,16,3,500,65,4196520,5393,4097,2524,1500,4194440,256,32,5457,512]

theorem envBound48225 : H12AffineFastState.Bounded env48225 := by
  intro p hp
  have h : env48225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48224_48225 : H12AffineEnvironment.transform 12 380 env48224 = env48225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env48224 == env48225) = true)

theorem identity48225 : scanCanonicalize (H12AffineFastState.compose env48225 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound48225 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48226 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,160,5340,168,171,5357,2184,1024,169,4160,4194304,16,3,40,65,4196520,5325,4097,2048,1024,4194440,220,32,5261,512]

theorem envBound48226 : H12AffineFastState.Bounded env48226 := by
  intro p hp
  have h : env48226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48225_48226 : H12AffineEnvironment.transform 7 220 env48225 = env48226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env48225 == env48226) = true)

theorem identity48226 : scanCanonicalize (H12AffineFastState.compose env48226 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48226 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env48227 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,129,5340,137,138,5324,2184,1024,136,4160,4194304,16,3,9,65,4196489,5325,4097,2048,1024,4194440,220,1,5261,512]

theorem envBound48227 : H12AffineFastState.Bounded env48227 := by
  intro p hp
  have h : env48227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48226_48227 : H12AffineEnvironment.transform 4 1 env48226 = env48227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48226 == env48227) = true)

theorem identity48227 : scanCanonicalize (H12AffineFastState.compose env48227 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound48227 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48228 : List Nat := [2,4,8,16,1,64,128,220,512,1024,0,4096,129,5340,137,138,5324,136,1024,136,4160,4194304,16,3,9,65,4194441,5325,4097,0,1024,4194440,220,1,5261,512]

theorem envBound48228 : H12AffineFastState.Bounded env48228 := by
  intro p hp
  have h : env48228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48227_48228 : H12AffineEnvironment.transform 10 0 env48227 = env48228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env48227 == env48228) = true)

def env48229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138341,1024,8660,4160,4194304,16,73737,8328,65,4196521,5393,4096,10400,1500,4194440,256,33,5456,74251]

theorem envBound48229 : H12AffineFastState.Bounded env48229 := by
  intro p hp
  have h : env48229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48221_48229 : H12AffineEnvironment.transform 13 5377 env48221 = env48229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48221 == env48229) = true)

theorem identity48229 : scanCanonicalize (H12AffineFastState.compose env48229 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound48229 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13508,10401,1024,8660,4160,4194304,16,73737,8328,65,4196521,5393,4096,10400,1500,4194440,256,33,5456,74251]

theorem envBound48230 : H12AffineFastState.Bounded env48230 := by
  intro p hp
  have h : env48230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48229_48230 : H12AffineEnvironment.transform 16 13508 env48229 = env48230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env48229 == env48230) = true)

theorem identity48230 : scanCanonicalize (H12AffineFastState.compose env48230 (packedSelected [0,1,2,5,6,10,12,14,15,18,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 8612) := by decide +kernel

theorem selectedBound48230 : packedSelected [0,1,2,5,6,10,12,14,15,18,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env48231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13508,10401,1024,8660,4160,8612,16,73737,8328,65,10509,5393,4096,10400,1500,8492,256,33,5456,74251]

theorem envBound48231 : H12AffineFastState.Bounded env48231 := by
  intro p hp
  have h : env48231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48230_48231 : H12AffineEnvironment.transform 21 8612 env48230 = env48231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8612 env48230 == env48231) = true)

theorem identity48231 : scanCanonicalize (H12AffineFastState.compose env48231 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48231 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS < 2^1333 := by decide +kernel

def env48232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,217,65536,5576,2477,1024,216,4160,168,16,65797,388,65,2049,5393,4096,2476,1500,32,256,33,5456,66311]

theorem envBound48232 : H12AffineFastState.Bounded env48232 := by
  intro p hp
  have h : env48232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48231_48232 : H12AffineEnvironment.transform 12 268 env48231 = env48232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48231 == env48232) = true)

theorem identity48232 : scanCanonicalize (H12AffineFastState.compose env48232 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48232 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env48233 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,65536,5441,2340,1024,81,4160,33,16,65797,269,65,2049,5393,4096,2341,1365,32,256,33,5456,66311]

theorem envBound48233 : H12AffineFastState.Bounded env48233 := by
  intro p hp
  have h : env48233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48232_48233 : H12AffineEnvironment.transform 6 9 env48232 = env48233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48232 == env48233) = true)

def env48234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,17,98780,8328,65,4237693,5392,17665,10401,1501,4256861,256,21792,46213,74250]

theorem envBound48234 : H12AffineFastState.Bounded env48234 := by
  intro p hp
  have h : env48234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48219_48234 : H12AffineEnvironment.transform 20 4161 env48219 = env48234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48219 == env48234) = true)

theorem identity48234 : scanCanonicalize (H12AffineFastState.compose env48234 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound48234 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,144613,17,98780,8328,65,171416,5392,17665,10401,1501,180408,256,21792,46213,74250]

theorem envBound48235 : H12AffineFastState.Bounded env48235 := by
  intro p hp
  have h : env48235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48234_48235 : H12AffineEnvironment.transform 21 144613 env48234 = env48235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env48234 == env48235) = true)

def env48236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,144493,17,98644,8192,65,171280,5392,17665,10281,1365,180272,256,21792,46093,74250]

theorem envBound48236 : H12AffineFastState.Bounded env48236 := by
  intro p hp
  have h : env48236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48235_48236 : H12AffineEnvironment.transform 6 8 env48235 = env48236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48235 == env48236) = true)

theorem identity48236 : scanCanonicalize (H12AffineFastState.compose env48236 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound48236 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,149860,1024,8540,4161,144493,17,73737,8192,65,146509,5392,17665,10281,1365,156013,256,21792,5456,74250]

theorem envBound48237 : H12AffineFastState.Bounded env48237 := by
  intro p hp
  have h : env48237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48236_48237 : H12AffineEnvironment.transform 14 8541 env48236 = env48237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env48236 == env48237) = true)

theorem identity48237 : scanCanonicalize (H12AffineFastState.compose env48237 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound48237 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8541,65536,131072,146792,1024,8540,4161,144493,17,73737,8192,65,146509,5392,12557,10281,1365,136545,256,8492,5456,74250]

theorem envBound48238 : H12AffineFastState.Bounded env48238 := by
  intro p hp
  have h : env48238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48237_48238 : H12AffineEnvironment.transform 13 13324 env48237 = env48238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env48237 == env48238) = true)

theorem identity48238 : scanCanonicalize (H12AffineFastState.compose env48238 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound48238 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env48239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8541,65536,13673,2049,1024,8540,4161,260,17,73737,8192,65,2340,5392,12557,10281,1365,8200,256,8492,5456,74250]

theorem envBound48239 : H12AffineFastState.Bounded env48239 := by
  intro p hp
  have h : env48239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48238_48239 : H12AffineEnvironment.transform 16 13673 env48238 = env48239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env48238 == env48239) = true)

theorem identity48239 : scanCanonicalize (H12AffineFastState.compose env48239 (packedSelected [0,1,2,4,5,6,7,8,9,11,14,16,18,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48239 : packedSelected [0,1,2,4,5,6,7,8,9,11,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env48240 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,8461,65536,13625,2049,1024,8460,4113,260,17,73737,8192,17,2340,5392,12557,10281,1285,8200,256,8492,5376,74250]

theorem envBound48240 : H12AffineFastState.Bounded env48240 := by
  intro p hp
  have h : env48240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48239_48240 : H12AffineEnvironment.transform 5 16 env48239 = env48240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48239 == env48240) = true)

theorem identity48240 : scanCanonicalize (H12AffineFastState.compose env48240 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound48240 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48241 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,8461,8495,13625,2049,1024,8460,4113,260,17,294,8192,17,2340,5392,12557,10281,1285,8200,256,8492,5376,805]

theorem envBound48241 : H12AffineFastState.Bounded env48241 := by
  intro p hp
  have h : env48241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48240_48241 : H12AffineEnvironment.transform 15 8495 env48240 = env48241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env48240 == env48241) = true)

theorem identity48241 : scanCanonicalize (H12AffineFastState.compose env48241 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48241 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env48242 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,13324,8233,8203,13341,2049,1024,8232,4113,32,17,2,8192,17,2048,5172,12329,10281,1057,8200,36,8200,5156,513]

theorem envBound48242 : H12AffineFastState.Bounded env48242 := by
  intro p hp
  have h : env48242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48241_48242 : H12AffineEnvironment.transform 7 36 env48241 = env48242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48241 == env48242) = true)

def env48243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144492,17,98645,8193,65,171281,5392,17665,10280,1364,180273,256,21792,46092,74250]

theorem envBound48243 : H12AffineFastState.Bounded env48243 := by
  intro p hp
  have h : env48243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48235_48243 : H12AffineEnvironment.transform 6 9 env48235 = env48243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48235 == env48243) = true)

theorem identity48243 : scanCanonicalize (H12AffineFastState.compose env48243 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound48243 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190520,1024,32769,4161,144492,17,2,8193,65,171281,5392,17665,10280,1364,180273,256,21792,46092,41821]

theorem envBound48244 : H12AffineFastState.Bounded env48244 := by
  intro p hp
  have h : env48244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48243_48244 : H12AffineEnvironment.transform 15 33111 env48243 = env48244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env48243 == env48244) = true)

theorem identity48244 : scanCanonicalize (H12AffineFastState.compose env48244 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48244 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env48245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,343,131072,157752,1024,1,4161,144492,17,2,8193,65,138513,5392,17665,10280,1364,147505,256,21792,13324,9053]

theorem envBound48245 : H12AffineFastState.Bounded env48245 := by
  intro p hp
  have h : env48245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48244_48245 : H12AffineEnvironment.transform 14 0 env48244 = env48245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48244 == env48245) = true)

theorem identity48245 : scanCanonicalize (H12AffineFastState.compose env48245 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound48245 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env48246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,343,24908,2420,1024,1,4161,21792,17,2,8193,65,31837,5392,17665,10280,1364,8573,256,21792,13324,9053]

theorem envBound48246 : H12AffineFastState.Bounded env48246 := by
  intro p hp
  have h : env48246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48245_48246 : H12AffineEnvironment.transform 16 24908 env48245 = env48246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env48245 == env48246) = true)

theorem identity48246 : scanCanonicalize (H12AffineFastState.compose env48246 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48246 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env48247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,0,343,16448,2420,1024,1,4161,21792,17,2,269,65,23889,5392,17665,2340,1364,113,256,21792,5376,593]

theorem envBound48247 : H12AffineFastState.Bounded env48247 := by
  intro p hp
  have h : env48247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48246_48247 : H12AffineEnvironment.transform 12 268 env48246 = env48247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48246 == env48247) = true)

theorem identity48247 : scanCanonicalize (H12AffineFastState.compose env48247 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48247 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48248 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,263,16400,2340,1024,1,4113,21792,17,2,269,17,23809,5392,17665,2340,1284,33,256,21792,5376,513]

theorem envBound48248 : H12AffineFastState.Bounded env48248 := by
  intro p hp
  have h : env48248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48247_48248 : H12AffineEnvironment.transform 5 16 env48247 = env48248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48247 == env48248) = true)

def env48249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265168,23160256,257,27378861,27337993,25207750]

theorem envBound48249 : H12AffineFastState.Bounded env48249 := by
  intro p hp
  have h : env48249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48098_48249 : H12AffineEnvironment.transform 18 1025 env48098 = env48249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env48098 == env48249) = true)

theorem identity48249 : scanCanonicalize (H12AffineFastState.compose env48249 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 297453) := by decide +kernel

theorem selectedBound48249 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,297453,16777216,8328,65,21187053,18973836,2415804,149997,17108477,23160256,257,19221824,19246308,17050155]

theorem envBound48250 : H12AffineFastState.Bounded env48250 := by
  intro p hp
  have h : env48250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48249_48250 : H12AffineEnvironment.transform 22 297453 env48249 = env48250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297453 env48249 == env48250) = true)

def env48251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182764,1025,32769,2097152,4194304,147457,16777216,8328,65,21187053,18973836,2233680,149997,17024017,23160256,257,19104940,19096840,16966599]

theorem envBound48251 : H12AffineFastState.Bounded env48251 := by
  intro p hp
  have h : env48251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48250_48251 : H12AffineEnvironment.transform 17 182764 env48250 = env48251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182764 env48250 == env48251) = true)

def env48252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35188,1025,32769,2097152,4194304,153,16777216,8328,65,21039477,18973836,2119112,2421,16876681,23160256,257,18990132,18949520,16819039]

theorem envBound48252 : H12AffineFastState.Bounded env48252 := by
  intro p hp
  have h : env48252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48251_48252 : H12AffineEnvironment.transform 16 16536 env48251 = env48252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env48251 == env48252) = true)

theorem identity48252 : scanCanonicalize (H12AffineFastState.compose env48252 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48252 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,16777216,8192,65,21039477,18973700,2118976,2421,16876545,23160136,257,18990132,18949400,16819039]

theorem envBound48253 : H12AffineFastState.Bounded env48253 := by
  intro p hp
  have h : env48253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48252_48253 : H12AffineEnvironment.transform 6 8 env48252 = env48253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48252 == env48253) = true)

def env48254 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,16777216,8192,65,21039105,18973700,2118708,2049,16876545,23159868,117,18990132,18949228,16818731]

theorem envBound48254 : H12AffineFastState.Bounded env48254 := by
  intro p hp
  have h : env48254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48253_48254 : H12AffineEnvironment.transform 7 116 env48253 = env48254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48253 == env48254) = true)

theorem identity48254 : scanCanonicalize (H12AffineFastState.compose env48254 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound48254 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env48255 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,16777216,8192,65,21039105,16834618,77834,2049,16876545,20971522,117,16818186,16793682,16818731]

theorem envBound48255 : H12AffineFastState.Bounded env48255 := by
  intro p hp
  have h : env48255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48254_48255 : H12AffineEnvironment.transform 20 91198 env48254 = env48255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env48254 == env48255) = true)

def env48256 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,16777216,8192,17,21039105,16834618,77834,2049,16876545,20971522,37,16818186,16793602,16818731]

theorem envBound48256 : H12AffineFastState.Bounded env48256 := by
  intro p hp
  have h : env48256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48255_48256 : H12AffineEnvironment.transform 5 16 env48255 = env48256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48255 == env48256) = true)

theorem identity48256 : scanCanonicalize (H12AffineFastState.compose env48256 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4292609) := by decide +kernel

theorem selectedBound48256 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48257 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,4292609,8192,17,34816,4284475,77834,2049,4195328,98307,37,4268043,4308995,4268586]

theorem envBound48257 : H12AffineFastState.Bounded env48257 := by
  intro p hp
  have h : env48257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48256_48257 : H12AffineEnvironment.transform 23 4292609 env48256 = env48257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292609 env48256 == env48257) = true)

theorem identity48257 : scanCanonicalize (H12AffineFastState.compose env48257 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound48257 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48258 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8232,65536,16400,10280,1025,8233,91198,4194304,17,4268073,8192,17,10280,4284475,77834,2049,4195328,73771,37,4268043,4284459,4268586]

theorem envBound48258 : H12AffineFastState.Bounded env48258 := by
  intro p hp
  have h : env48258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48257_48258 : H12AffineEnvironment.transform 14 8232 env48257 = env48258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env48257 == env48258) = true)

theorem identity48258 : scanCanonicalize (H12AffineFastState.compose env48258 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(21+1) ^^^ 87047) := by decide +kernel

theorem selectedBound48258 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env48259 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8232,65536,16400,10280,1025,8233,91198,87047,17,29742,8192,17,10280,13372,77834,2049,86023,73771,37,29708,13356,30253]

theorem envBound48259 : H12AffineFastState.Bounded env48259 := by
  intro p hp
  have h : env48259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48258_48259 : H12AffineEnvironment.transform 21 87047 env48258 = env48259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87047 env48258 == env48259) = true)

theorem identity48259 : scanCanonicalize (H12AffineFastState.compose env48259 (packedSelected [2,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound48259 : packedSelected [2,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env48260 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8232,34,16400,10280,1025,8233,25628,21541,17,29742,8192,17,10280,13372,12328,2049,20517,8201,37,29708,13356,30253]

theorem envBound48260 : H12AffineFastState.Bounded env48260 := by
  intro p hp
  have h : env48260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48259_48260 : H12AffineEnvironment.transform 15 34 env48259 = env48260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env48259 == env48260) = true)

theorem identity48260 : scanCanonicalize (H12AffineFastState.compose env48260 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound48260 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48261 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,16384,1,34,16400,2049,1025,0,17461,21541,17,21511,41,17,2049,5141,4097,2049,20517,32,37,21541,5125,22020]

theorem envBound48261 : H12AffineFastState.Bounded env48261 := by
  intro p hp
  have h : env48261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48260_48261 : H12AffineEnvironment.transform 12 41 env48260 = env48261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env48260 == env48261) = true)

theorem identity48261 : scanCanonicalize (H12AffineFastState.compose env48261 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound48261 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env48262 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,16384,1,34,16400,2049,1025,0,17461,17429,17,17463,41,17,2049,1061,49,2049,16405,32,37,17429,1077,17972]

theorem envBound48262 : H12AffineFastState.Bounded env48262 := by
  intro p hp
  have h : env48262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48261_48262 : H12AffineEnvironment.transform 11 48 env48261 = env48262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48261 == env48262) = true)

theorem identity48262 : scanCanonicalize (H12AffineFastState.compose env48262 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 3093) := by decide +kernel

theorem selectedBound48262 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48263 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,3093,1,34,3077,2049,1025,0,2080,2048,17,2082,41,17,2049,1061,49,2049,3072,32,37,2048,1077,2593]

theorem envBound48263 : H12AffineFastState.Bounded env48263 := by
  intro p hp
  have h : env48263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48262_48263 : H12AffineEnvironment.transform 13 3093 env48262 = env48263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3093 env48262 == env48263) = true)

def env48264 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,16777216,8192,16,21039105,16834618,77834,2049,16876545,20971522,36,16818186,16793603,16818731]

theorem envBound48264 : H12AffineFastState.Bounded env48264 := by
  intro p hp
  have h : env48264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48255_48264 : H12AffineEnvironment.transform 5 17 env48255 = env48264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48255 == env48264) = true)

theorem identity48264 : scanCanonicalize (H12AffineFastState.compose env48264 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4235275) := by decide +kernel

theorem selectedBound48264 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48265 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,4194304,17,4235275,8192,16,108554,4210737,77834,2049,4269066,40969,36,4194305,4251656,4194848]

theorem envBound48265 : H12AffineFastState.Bounded env48265 := by
  intro p hp
  have h : env48265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48264_48265 : H12AffineEnvironment.transform 23 4235275 env48264 = env48265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4235275 env48264 == env48265) = true)

theorem identity48265 : scanCanonicalize (H12AffineFastState.compose env48265 (packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound48265 : packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env48266 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,91198,8200,17,32771,8192,16,108554,24633,77834,2049,66562,40969,36,8201,49152,8744]

theorem envBound48266 : H12AffineFastState.Bounded env48266 := by
  intro p hp
  have h : env48266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48265_48266 : H12AffineEnvironment.transform 21 8200 env48265 = env48266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env48265 == env48266) = true)

theorem identity48266 : scanCanonicalize (H12AffineFastState.compose env48266 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound48266 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env48267 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,8233,65536,16400,10281,1025,8232,91198,8200,17,8234,8192,16,67619,24633,77834,2049,66562,32,36,8201,24617,8744]

theorem envBound48267 : H12AffineFastState.Bounded env48267 := by
  intro p hp
  have h : env48267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48266_48267 : H12AffineEnvironment.transform 14 8233 env48266 = env48267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env48266 == env48267) = true)

theorem identity48267 : scanCanonicalize (H12AffineFastState.compose env48267 (packedSelected [12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48267 : packedSelected [12,15,17] rootPS < 2^1333 := by decide +kernel

def env48268 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,8192,16384,8233,65536,16400,10281,52,8232,90123,8200,17,8234,8192,16,67619,24633,77834,2049,65591,32,36,8201,24617,8744]

theorem envBound48268 : H12AffineFastState.Bounded env48268 := by
  intro p hp
  have h : env48268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48267_48268 : H12AffineEnvironment.transform 9 53 env48267 = env48268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48267 == env48268) = true)

theorem identity48268 : scanCanonicalize (H12AffineFastState.compose env48268 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound48268 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env48269 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,8192,4112,8233,65536,4096,10281,52,8232,77851,8200,17,8234,8192,16,67619,12329,77834,2049,65591,32,36,8201,12345,8744]

theorem envBound48269 : H12AffineFastState.Bounded env48269 := by
  intro p hp
  have h : env48269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48268_48269 : H12AffineEnvironment.transform 13 4112 env48268 = env48269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env48268 == env48269) = true)

theorem identity48269 : scanCanonicalize (H12AffineFastState.compose env48269 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound48269 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48270 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,4112,1,65536,4096,2049,52,0,69683,32,17,2,40,16,67619,4097,69666,2049,65591,32,36,33,4113,512]

theorem envBound48270 : H12AffineFastState.Bounded env48270 := by
  intro p hp
  have h : env48270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48269_48270 : H12AffineEnvironment.transform 12 40 env48269 = env48270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env48269 == env48270) = true)

theorem identity48270 : scanCanonicalize (H12AffineFastState.compose env48270 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound48270 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48271 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,4112,1,2,4096,2049,52,0,4145,32,17,2,40,16,2081,4097,4128,2049,53,32,36,33,4113,512]

theorem envBound48271 : H12AffineFastState.Bounded env48271 := by
  intro p hp
  have h : env48271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48270_48271 : H12AffineEnvironment.transform 15 2 env48270 = env48271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env48270 == env48271) = true)

theorem identity48271 : scanCanonicalize (H12AffineFastState.compose env48271 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48271 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48272 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,4096,9,4112,1,2,4096,2049,21,0,4112,1,17,2,9,16,2048,4097,4097,2049,20,1,5,0,4113,512]

theorem envBound48272 : H12AffineFastState.Bounded env48272 := by
  intro p hp
  have h : env48272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48271_48272 : H12AffineEnvironment.transform 4 1 env48271 = env48272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48271 == env48272) = true)

theorem identity48272 : scanCanonicalize (H12AffineFastState.compose env48272 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48273 : List Nat := [2,4,8,16,1,17,8,4,0,20,2048,4096,9,4112,1,2,4096,2049,21,0,4112,1,17,2,9,16,2048,4097,4097,2049,20,1,5,0,4113,0]

theorem envBound48273 : H12AffineFastState.Bounded env48273 := by
  intro p hp
  have h : env48273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48272_48273 : H12AffineEnvironment.transform 8 0 env48272 = env48273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48272 == env48273) = true)

theorem identity48273 : scanCanonicalize (H12AffineFastState.compose env48273 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound48273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48274 : List Nat := [2,4,8,5,1,4,8,4,0,1,2048,4096,9,4101,1,2,4096,2049,0,0,4101,1,4,2,9,5,2048,4097,4097,2049,1,1,5,0,4100,0]

theorem envBound48274 : H12AffineFastState.Bounded env48274 := by
  intro p hp
  have h : env48274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48273_48274 : H12AffineEnvironment.transform 3 5 env48273 = env48274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env48273 == env48274) = true)

theorem identity48274 : scanCanonicalize (H12AffineFastState.compose env48274 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 2052) := by decide +kernel

theorem selectedBound48274 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48275 : List Nat := [2,4,8,5,1,4,8,4,0,1,2048,2052,9,2049,1,2,2052,2049,0,0,2049,1,4,2,9,5,2048,2053,2053,2049,1,1,5,0,2048,0]

theorem envBound48275 : H12AffineFastState.Bounded env48275 := by
  intro p hp
  have h : env48275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48274_48275 : H12AffineEnvironment.transform 11 2052 env48274 = env48275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2052 env48274 == env48275) = true)

def leafEnv48275 : List Nat := [2,4,8,5,1,4,8,4,0,1,2048,2052,9,2049,1,2,2052,2049,0,0,2049,1,4,2,0,9,1,5,2048,2053,2053,2049,1,1,5,0,5,2,2048,0,1,2048,0]

def active48275 : List Nat := [0,1,2,10]

def tree48275 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48275 : H12WitnessSearch.Good tree48275 := H12GlobalWitnessIndex.good

theorem leafIdentity48275 : H12AffineFastState.composeSystem env48275 rootObs = leafEnv48275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48275 rootObs == leafEnv48275) = true)

theorem terminalChecked48275 : H12PackedTerminal.terminalCheckFast leafEnv48275 active48275 tree48275 = true := by decide +kernel

def env48276 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,16777216,8192,65,21039104,18973700,2118709,2048,16876545,23159869,116,18990132,18949229,16818730]

theorem envBound48276 : H12AffineFastState.Bounded env48276 := by
  intro p hp
  have h : env48276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48253_48276 : H12AffineEnvironment.transform 7 117 env48253 = env48276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48253 == env48276) = true)

theorem identity48276 : scanCanonicalize (H12AffineFastState.compose env48276 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2212884) := by decide +kernel

theorem selectedBound48276 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env48277 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,2212884,8192,65,6343700,16400,2118709,2048,2113557,4235305,116,32,57465,2188862]

theorem envBound48277 : H12AffineFastState.Bounded env48277 := by
  intro p hp
  have h : env48277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48276_48277 : H12AffineEnvironment.transform 23 2212884 env48276 = env48277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212884 env48276 == env48277) = true)

def env48278 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,2212884,8192,17,6343700,16400,2118709,2048,2113557,4235305,36,32,57385,2188862]

theorem envBound48278 : H12AffineFastState.Bounded env48278 := by
  intro p hp
  have h : env48278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48277_48278 : H12AffineEnvironment.transform 5 16 env48277 = env48278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48277 == env48278) = true)

theorem identity48278 : scanCanonicalize (H12AffineFastState.compose env48278 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound48278 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env48279 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8233,65536,16400,10280,1025,8232,2097152,4194304,17,2188349,8192,17,6319165,16400,2118709,2048,2113557,4194304,36,32,16384,2188862]

theorem envBound48279 : H12AffineFastState.Bounded env48279 := by
  intro p hp
  have h : env48279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48278_48279 : H12AffineEnvironment.transform 14 8233 env48278 = env48279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env48278 == env48279) = true)

theorem identity48279 : scanCanonicalize (H12AffineFastState.compose env48279 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 91199) := by decide +kernel

theorem selectedBound48279 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env48280 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8233,65536,16400,10280,1025,8232,91199,4194304,17,2,8192,17,4261890,16400,77834,2048,74794,4194304,36,32,16384,513]

theorem envBound48280 : H12AffineFastState.Bounded env48280 := by
  intro p hp
  have h : env48280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48279_48280 : H12AffineEnvironment.transform 20 91199 env48279 = env48280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91199 env48279 == env48280) = true)

theorem identity48280 : scanCanonicalize (H12AffineFastState.compose env48280 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48280 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48281 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8233,8203,16400,10280,1025,8232,17460,4194304,17,2,8192,17,4204553,16400,4097,2048,1057,4194304,36,32,16384,513]

theorem envBound48281 : H12AffineFastState.Bounded env48281 := by
  intro p hp
  have h : env48281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48280_48281 : H12AffineEnvironment.transform 15 8203 env48280 = env48281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48280 == env48281) = true)

def env48282 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,2212884,8192,16,6343700,16400,2118709,2048,2113557,4235305,37,32,57384,2188862]

theorem envBound48282 : H12AffineFastState.Bounded env48282 := by
  intro p hp
  have h : env48282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48277_48282 : H12AffineEnvironment.transform 5 17 env48277 = env48282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48277 == env48282) = true)

theorem identity48282 : scanCanonicalize (H12AffineFastState.compose env48282 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

theorem selectedBound48282 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env48283 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,65538,17,2212884,8192,16,2214934,16400,2118709,2048,2113557,106539,37,32,57384,2188862]

theorem envBound48283 : H12AffineFastState.Bounded env48283 := by
  intro p hp
  have h : env48283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48282_48283 : H12AffineEnvironment.transform 21 65538 env48282 = env48283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env48282 == env48283) = true)

theorem identity48283 : scanCanonicalize (H12AffineFastState.compose env48283 (packedSelected [0,1,3,5,7,8,9,10,14,17,18,19,20,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 123967) := by decide +kernel

theorem selectedBound48283 : packedSelected [0,1,3,5,7,8,9,10,14,17,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env48284 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,123967,65538,17,8235,8192,16,10281,16400,110602,2048,107562,106539,37,32,57384,33281]

theorem envBound48284 : H12AffineFastState.Bounded env48284 := by
  intro p hp
  have h : env48284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48283_48284 : H12AffineEnvironment.transform 20 123967 env48283 = env48284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 123967 env48283 == env48284) = true)

theorem identity48284 : scanCanonicalize (H12AffineFastState.compose env48284 (packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 29741) := by decide +kernel

theorem selectedBound48284 : packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env48285 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,29741,65536,16400,31788,1025,29740,69650,65538,17,8235,8192,16,10281,16400,82983,2048,86023,87046,37,32,5125,30252]

theorem envBound48285 : H12AffineFastState.Bounded env48285 := by
  intro p hp
  have h : env48285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48284_48285 : H12AffineEnvironment.transform 14 29741 env48284 = env48285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29741 env48284 == env48285) = true)

theorem identity48285 : scanCanonicalize (H12AffineFastState.compose env48285 (packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 21542) := by decide +kernel

theorem selectedBound48285 : packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env48286 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,29741,21542,16400,31788,1025,29740,17460,21540,17,8235,8192,16,10281,16400,4097,2048,1057,32,37,32,5125,30252]

theorem envBound48286 : H12AffineFastState.Bounded env48286 := by
  intro p hp
  have h : env48286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48285_48286 : H12AffineEnvironment.transform 15 21542 env48285 = env48286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21542 env48285 == env48286) = true)

theorem identity48286 : scanCanonicalize (H12AffineFastState.compose env48286 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound48286 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env48287 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1551,8192,16384,25122,16937,16400,27171,1025,25123,17460,16939,17,8235,8192,16,10281,16400,1550,2048,1057,32,37,32,522,24611]

theorem envBound48287 : H12AffineFastState.Bounded env48287 := by
  intro p hp
  have h : env48287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48286_48287 : H12AffineEnvironment.transform 11 1551 env48286 = env48287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env48286 == env48287) = true)

theorem identity48287 : scanCanonicalize (H12AffineFastState.compose env48287 (packedSelected [0,2,5,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound48287 : packedSelected [0,2,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48288 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1551,8192,0,8738,553,16,10787,1025,8739,1076,555,17,8235,8192,16,10281,16,1550,2048,1057,32,37,32,522,8227]

theorem envBound48288 : H12AffineFastState.Bounded env48288 := by
  intro p hp
  have h : env48288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48287_48288 : H12AffineEnvironment.transform 13 0 env48287 = env48288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env48287 == env48288) = true)

theorem identity48288 : scanCanonicalize (H12AffineFastState.compose env48288 (packedSelected [0,5,8,9,10,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1599) := by decide +kernel

theorem selectedBound48288 : packedSelected [0,5,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env48289 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1599,1551,8192,0,8738,553,16,9244,1025,8739,1076,555,17,8235,8192,16,9750,16,1550,1599,1057,32,37,32,522,8227]

theorem envBound48289 : H12AffineFastState.Bounded env48289 := by
  intro p hp
  have h : env48289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48288_48289 : H12AffineEnvironment.transform 10 1599 env48288 = env48289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1599 env48288 == env48289) = true)

theorem identity48289 : scanCanonicalize (H12AffineFastState.compose env48289 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound48289 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48290 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1599,1551,40,0,522,553,16,1076,1025,523,1076,555,17,3,40,16,1598,16,1550,1599,1057,32,37,32,522,11]

theorem envBound48290 : H12AffineFastState.Bounded env48290 := by
  intro p hp
  have h : env48290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48289_48290 : H12AffineEnvironment.transform 12 40 env48289 = env48290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env48289 == env48290) = true)

theorem identity48290 : scanCanonicalize (H12AffineFastState.compose env48290 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound48290 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48291 : List Nat := [2,4,8,16,32,17,8,36,10,1024,1077,1029,40,0,0,35,16,1076,1025,1,1076,33,17,3,40,16,1076,16,1028,1077,1057,32,37,32,0,11]

theorem envBound48291 : H12AffineFastState.Bounded env48291 := by
  intro p hp
  have h : env48291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48290_48291 : H12AffineEnvironment.transform 8 10 env48290 = env48291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env48290 == env48291) = true)

theorem identity48291 : scanCanonicalize (H12AffineFastState.compose env48291 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48292 : List Nat := [2,4,8,16,16,17,8,20,10,1024,1029,1029,24,0,0,19,16,1028,1025,1,1028,17,17,3,24,16,1028,16,1028,1029,1041,16,21,16,0,11]

theorem envBound48292 : H12AffineFastState.Bounded env48292 := by
  intro p hp
  have h : env48292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48291_48292 : H12AffineEnvironment.transform 4 16 env48291 = env48292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48291 == env48292) = true)

theorem identity48292 : scanCanonicalize (H12AffineFastState.compose env48292 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48293 : List Nat := [2,4,8,10,10,11,8,14,10,1024,1029,1029,2,0,0,9,10,1028,1025,1,1028,11,11,3,2,10,1028,10,1028,1029,1035,10,15,10,0,11]

theorem envBound48293 : H12AffineFastState.Bounded env48293 := by
  intro p hp
  have h : env48293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48292_48293 : H12AffineEnvironment.transform 3 10 env48292 = env48293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48292 == env48293) = true)

theorem identity48293 : scanCanonicalize (H12AffineFastState.compose env48293 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48293 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48294 : List Nat := [1,4,8,9,9,8,8,13,9,1024,1029,1029,1,0,0,9,9,1028,1025,1,1028,8,8,0,1,9,1028,9,1028,1029,1032,9,12,9,0,8]

theorem envBound48294 : H12AffineFastState.Bounded env48294 := by
  intro p hp
  have h : env48294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48293_48294 : H12AffineEnvironment.transform 0 1 env48293 = env48294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48293 == env48294) = true)

theorem identity48294 : scanCanonicalize (H12AffineFastState.compose env48294 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound48294 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48295 : List Nat := [1,4,0,1,1,0,0,5,1,1024,1029,1029,1,0,0,1,1,1028,1025,1,1028,0,0,0,1,1,1028,1,1028,1029,1024,1,4,1,0,0]

theorem envBound48295 : H12AffineFastState.Bounded env48295 := by
  intro p hp
  have h : env48295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48294_48295 : H12AffineEnvironment.transform 2 0 env48294 = env48295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env48294 == env48295) = true)

theorem identity48295 : scanCanonicalize (H12AffineFastState.compose env48295 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound48295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48296 : List Nat := [1,4,0,1,1,0,0,5,1,0,5,5,1,0,0,1,1,4,1,1,4,0,0,0,1,1,4,1,4,5,0,1,4,1,0,0]

theorem envBound48296 : H12AffineFastState.Bounded env48296 := by
  intro p hp
  have h : env48296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48295_48296 : H12AffineEnvironment.transform 9 0 env48295 = env48296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env48295 == env48296) = true)

def env48297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35189,1025,32769,2097152,4194304,152,16777216,8328,65,21039476,18973836,2119113,2420,16876680,23160256,257,18990133,18949521,16819038]

theorem envBound48297 : H12AffineFastState.Bounded env48297 := by
  intro p hp
  have h : env48297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48251_48297 : H12AffineEnvironment.transform 16 16537 env48251 = env48297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env48251 == env48297) = true)

theorem identity48297 : scanCanonicalize (H12AffineFastState.compose env48297 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound48297 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16537,10400,1025,8660,2097152,4194304,152,16777216,8328,65,21039476,18949465,2119113,2420,16852317,23160256,257,18965984,18949521,16777867]

theorem envBound48298 : H12AffineFastState.Bounded env48298 := by
  intro p hp
  have h : env48298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48297_48298 : H12AffineEnvironment.transform 14 8661 env48297 = env48298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env48297 == env48298) = true)

def env48299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,2097152,4194304,16,16777216,8192,65,21039476,18949465,2118977,2420,16852317,23160136,257,18965864,18949401,16777731]

theorem envBound48299 : H12AffineFastState.Bounded env48299 := by
  intro p hp
  have h : env48299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48298_48299 : H12AffineEnvironment.transform 6 8 env48298 = env48299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48298 == env48299) = true)

theorem identity48299 : scanCanonicalize (H12AffineFastState.compose env48299 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound48299 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,2097152,4194304,16,2,8192,65,4262262,2172251,2118977,2420,75103,6382922,257,2188650,2172187,513]

theorem envBound48300 : H12AffineFastState.Bounded env48300 := by
  intro p hp
  have h : env48300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48299_48300 : H12AffineEnvironment.transform 23 2 env48299 = env48300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env48299 == env48300) = true)

theorem identity48300 : scanCanonicalize (H12AffineFastState.compose env48300 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48300 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env48301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,2097152,4194304,16,2,8192,65,4204925,2098512,2118977,2420,1364,6309185,257,2114913,2098448,513]

theorem envBound48301 : H12AffineFastState.Bounded env48301 := by
  intro p hp
  have h : env48301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48300_48301 : H12AffineEnvironment.transform 15 8203 env48300 = env48301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48300 == env48301) = true)

theorem identity48301 : scanCanonicalize (H12AffineFastState.compose env48301 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound48301 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,2097152,2114913,16,2,8192,65,2124828,2098512,2118977,2420,1364,32,257,2114913,2098448,513]

theorem envBound48302 : H12AffineFastState.Bounded env48302 := by
  intro p hp
  have h : env48302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48301_48302 : H12AffineEnvironment.transform 21 2114913 env48301 = env48302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env48301 == env48302) = true)

theorem identity48302 : scanCanonicalize (H12AffineFastState.compose env48302 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound48302 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,17728,33,16,2,8192,65,10588,16400,4097,2420,1364,32,257,33,16464,513]

theorem envBound48303 : H12AffineFastState.Bounded env48303 := by
  intro p hp
  have h : env48303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48302_48303 : H12AffineEnvironment.transform 20 17728 env48302 = env48303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env48302 == env48303) = true)

theorem identity48303 : scanCanonicalize (H12AffineFastState.compose env48303 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound48303 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8541,8203,13341,10280,1025,8540,12620,33,16,2,8192,65,10588,13340,4097,2420,1364,32,257,33,13404,513]

theorem envBound48304 : H12AffineFastState.Bounded env48304 := by
  intro p hp
  have h : env48304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48303_48304 : H12AffineEnvironment.transform 13 13324 env48303 = env48304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env48303 == env48304) = true)

theorem identity48304 : scanCanonicalize (H12AffineFastState.compose env48304 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48304 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env48305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,0,342,5440,2421,1025,1,4113,33,16,2,349,65,2049,5441,4097,2420,1364,32,257,33,5377,513]

theorem envBound48305 : H12AffineFastState.Bounded env48305 := by
  intro p hp
  have h : env48305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48304_48305 : H12AffineEnvironment.transform 12 349 env48304 = env48305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48304 == env48305) = true)

theorem identity48305 : scanCanonicalize (H12AffineFastState.compose env48305 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound48305 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48306 : List Nat := [2,4,8,16,32,64,8,256,512,785,2048,4096,349,4672,0,342,4689,2421,784,1,4113,33,16,2,349,65,2049,4688,4097,2420,581,32,257,33,4624,513]

theorem envBound48306 : H12AffineFastState.Bounded env48306 := by
  intro p hp
  have h : env48306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48305_48306 : H12AffineEnvironment.transform 9 785 env48305 = env48306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env48305 == env48306) = true)

theorem identity48306 : scanCanonicalize (H12AffineFastState.compose env48306 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound48306 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48307 : List Nat := [2,4,8,16,32,64,8,256,512,785,2048,81,349,529,0,342,512,2421,784,1,64,33,16,2,349,65,2049,513,80,2420,581,32,257,33,577,513]

theorem envBound48307 : H12AffineFastState.Bounded env48307 := by
  intro p hp
  have h : env48307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48306_48307 : H12AffineEnvironment.transform 11 81 env48306 = env48307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env48306 == env48307) = true)

def env48308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,2097152,4194304,17,16777216,8193,65,21039476,18949465,2118976,2420,16852317,23160137,257,18965865,18949400,16777730]

theorem envBound48308 : H12AffineFastState.Bounded env48308 := by
  intro p hp
  have h : env48308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48298_48308 : H12AffineEnvironment.transform 6 9 env48298 = env48308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48298 == env48308) = true)

theorem identity48308 : scanCanonicalize (H12AffineFastState.compose env48308 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 73737) := by decide +kernel

theorem selectedBound48308 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10281,1025,8541,2097152,4194304,17,73737,8193,65,4204925,2098512,2118976,2420,1364,6309184,257,2114912,2098449,74251]

theorem envBound48309 : H12AffineFastState.Bounded env48309 := by
  intro p hp
  have h : env48309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48308_48309 : H12AffineEnvironment.transform 23 73737 env48308 = env48309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73737 env48308 == env48309) = true)

theorem identity48309 : scanCanonicalize (H12AffineFastState.compose env48309 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound48309 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env48310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28698,16400,10281,1025,8541,2097152,4194304,17,20499,8193,65,4204925,2098512,2118976,2420,1364,6309184,257,2114912,2098449,21009]

theorem envBound48310 : H12AffineFastState.Bounded env48310 := by
  intro p hp
  have h : env48310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48309_48310 : H12AffineEnvironment.transform 15 28698 env48309 = env48310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env48309 == env48310) = true)

theorem identity48310 : scanCanonicalize (H12AffineFastState.compose env48310 (packedSelected [0,4,7,11,17,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 9496) := by decide +kernel

theorem selectedBound48310 : packedSelected [0,4,7,11,17,18,22] rootPS < 2^1333 := by decide +kernel

def env48311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28698,16400,10281,1025,8541,2097152,9496,17,20499,8193,65,3173,2098512,2118976,2420,1364,2121816,257,2114912,2098449,21009]

theorem envBound48311 : H12AffineFastState.Bounded env48311 := by
  intro p hp
  have h : env48311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48310_48311 : H12AffineEnvironment.transform 21 9496 env48310 = env48311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9496 env48310 == env48311) = true)

theorem identity48311 : scanCanonicalize (H12AffineFastState.compose env48311 (packedSelected [3,5,10,11,23] rootPS)) = affineNative (2^(20+1) ^^^ 4452) := by decide +kernel

theorem selectedBound48311 : packedSelected [3,5,10,11,23] rootPS < 2^1333 := by decide +kernel

def env48312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28698,16400,10281,1025,8541,4452,9496,17,20499,8193,65,3173,5172,17444,2420,1364,28988,257,21508,5237,21009]

theorem envBound48312 : H12AffineFastState.Bounded env48312 := by
  intro p hp
  have h : env48312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48311_48312 : H12AffineEnvironment.transform 20 4452 env48311 = env48312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4452 env48311 == env48312) = true)

theorem identity48312 : scanCanonicalize (H12AffineFastState.compose env48312 (packedSelected [12,15,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound48312 : packedSelected [12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env48313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8540,8203,4097,10281,1025,8541,4452,9496,17,2,8193,65,3173,5172,5173,2420,1364,8493,257,1045,5237,512]

theorem envBound48313 : H12AffineFastState.Bounded env48313 := by
  intro p hp
  have h : env48313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48312_48313 : H12AffineEnvironment.transform 13 4113 env48312 = env48313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env48312 == env48313) = true)

theorem identity48313 : scanCanonicalize (H12AffineFastState.compose env48313 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound48313 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48314 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4113,8540,8203,4097,10281,272,8541,4452,8201,17,2,8193,65,2420,4389,4388,2420,69,8493,257,260,4452,512]

theorem envBound48314 : H12AffineFastState.Bounded env48314 := by
  intro p hp
  have h : env48314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48313_48314 : H12AffineEnvironment.transform 9 273 env48313 = env48314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48313 == env48314) = true)

theorem identity48314 : scanCanonicalize (H12AffineFastState.compose env48314 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound48314 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env48315 : List Nat := [2,4,8,16,32,64,9,256,512,273,113,4096,8192,4113,8540,8203,4097,8280,272,8541,4452,8201,17,2,8193,65,261,4389,4388,261,69,8493,257,260,4452,512]

theorem envBound48315 : H12AffineFastState.Bounded env48315 := by
  intro p hp
  have h : env48315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48314_48315 : H12AffineEnvironment.transform 10 113 env48314 = env48315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env48314 == env48315) = true)

theorem identity48315 : scanCanonicalize (H12AffineFastState.compose env48315 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound48315 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env48316 : List Nat := [2,4,8,16,32,64,9,256,512,273,113,4096,268,4113,80,263,4097,340,272,81,4452,261,17,2,269,65,261,4389,4388,261,69,33,257,260,4452,512]

theorem envBound48316 : H12AffineFastState.Bounded env48316 := by
  intro p hp
  have h : env48316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48315_48316 : H12AffineEnvironment.transform 12 268 env48315 = env48316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env48315 == env48316) = true)

theorem identity48316 : scanCanonicalize (H12AffineFastState.compose env48316 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48316 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48317 : List Nat := [2,4,8,16,32,64,9,4,512,21,113,4096,8,4113,80,3,4097,80,20,81,4192,1,17,2,9,65,1,4129,4128,1,69,33,5,0,4192,512]

theorem envBound48317 : H12AffineFastState.Bounded env48317 := by
  intro p hp
  have h : env48317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48316_48317 : H12AffineEnvironment.transform 7 4 env48316 = env48317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48316 == env48317) = true)

theorem identity48317 : scanCanonicalize (H12AffineFastState.compose env48317 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound48317 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48318 : List Nat := [2,4,8,16,32,48,9,4,512,21,1,4096,8,4113,32,3,4097,32,20,33,4112,1,17,2,9,49,1,4129,4128,1,53,33,5,0,4112,512]

theorem envBound48318 : H12AffineFastState.Bounded env48318 := by
  intro p hp
  have h : env48318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48317_48318 : H12AffineEnvironment.transform 5 48 env48317 = env48318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env48317 == env48318) = true)

theorem identity48318 : scanCanonicalize (H12AffineFastState.compose env48318 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound48318 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48319 : List Nat := [2,4,8,16,32,48,9,4,15,21,1,4096,8,4113,32,3,4097,32,20,33,4112,1,17,2,9,49,1,4129,4128,1,53,33,5,0,4112,15]

theorem envBound48319 : H12AffineFastState.Bounded env48319 := by
  intro p hp
  have h : env48319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48318_48319 : H12AffineEnvironment.transform 8 15 env48318 = env48319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env48318 == env48319) = true)

theorem identity48319 : scanCanonicalize (H12AffineFastState.compose env48319 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound48319 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48320 : List Nat := [2,4,8,16,32,48,9,4,15,21,1,49,8,32,32,3,48,32,20,33,33,1,17,2,9,49,1,16,17,1,53,33,5,0,33,15]

theorem envBound48320 : H12AffineFastState.Bounded env48320 := by
  intro p hp
  have h : env48320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48319_48320 : H12AffineEnvironment.transform 11 49 env48319 = env48320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48319 == env48320) = true)

def env48321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182765,1025,32769,2097152,4194304,147456,16777216,8328,65,21187053,18973836,2233681,149997,17024016,23160256,257,19104941,19096841,16966598]

theorem envBound48321 : H12AffineFastState.Bounded env48321 := by
  intro p hp
  have h : env48321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48250_48321 : H12AffineEnvironment.transform 17 182765 env48250 = env48321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182765 env48250 == env48321) = true)

theorem identity48321 : scanCanonicalize (H12AffineFastState.compose env48321 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound48321 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env48322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182765,1025,32769,2097152,4194304,147456,188871,8328,65,4302890,2319691,2233681,149997,75223,6521863,257,2188650,2196686,513]

theorem envBound48322 : H12AffineFastState.Bounded env48322 := by
  intro p hp
  have h : env48322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48321_48322 : H12AffineEnvironment.transform 23 188871 env48321 = env48322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env48321 == env48322) = true)

def env48323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35189,1025,32769,2097152,4194304,152,41311,8328,65,4302890,2172371,2119113,2421,75223,6407327,257,2188650,2196686,513]

theorem envBound48323 : H12AffineFastState.Bounded env48323 := by
  intro p hp
  have h : env48323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48322_48323 : H12AffineEnvironment.transform 16 16536 env48322 = env48323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env48322 == env48323) = true)

theorem identity48323 : scanCanonicalize (H12AffineFastState.compose env48323 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound48323 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16536,10400,1025,8660,2097152,4194304,152,138,8328,65,4262399,2172371,2119113,2421,75223,6382922,257,2188650,2172187,513]

theorem envBound48324 : H12AffineFastState.Bounded env48324 := by
  intro p hp
  have h : env48324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48323_48324 : H12AffineEnvironment.transform 14 8661 env48323 = env48324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env48323 == env48324) = true)

theorem identity48324 : scanCanonicalize (H12AffineFastState.compose env48324 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound48324 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env48325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16536,10400,1025,8660,2097152,4194304,152,138,8328,65,4204925,2098513,2119113,2421,1365,6309320,257,2115048,2098585,513]

theorem envBound48325 : H12AffineFastState.Bounded env48325 := by
  intro p hp
  have h : env48325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48324_48325 : H12AffineEnvironment.transform 15 8322 env48324 = env48325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env48324 == env48325) = true)

theorem identity48325 : scanCanonicalize (H12AffineFastState.compose env48325 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(20+1) ^^^ 17865) := by decide +kernel

theorem selectedBound48325 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env48326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16536,10400,1025,8660,17865,4194304,152,138,8328,65,4204925,16536,4096,2421,1365,4194305,257,33,16464,513]

theorem envBound48326 : H12AffineFastState.Bounded env48326 := by
  intro p hp
  have h : env48326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48325_48326 : H12AffineEnvironment.transform 20 17865 env48325 = env48326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env48325 == env48326) = true)

theorem identity48326 : scanCanonicalize (H12AffineFastState.compose env48326 (packedSelected [2,6,17] rootPS)) = affineNative (2^(21+1) ^^^ 249) := by decide +kernel

theorem selectedBound48326 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env48327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16536,10400,1025,8660,17865,249,152,138,8328,65,10628,16536,4096,2421,1365,248,257,33,16464,513]

theorem envBound48327 : H12AffineFastState.Bounded env48327 := by
  intro p hp
  have h : env48327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48326_48327 : H12AffineEnvironment.transform 21 249 env48326 = env48327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 249 env48326 == env48327) = true)

theorem identity48327 : scanCanonicalize (H12AffineFastState.compose env48327 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48327 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env48328 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8322,16536,10400,1025,8581,17816,168,152,138,8328,16,10628,16536,4096,2340,1284,169,257,33,16385,513]

theorem envBound48328 : H12AffineFastState.Bounded env48328 := by
  intro p hp
  have h : env48328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48327_48328 : H12AffineEnvironment.transform 5 17 env48327 = env48328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48327 == env48328) = true)

theorem identity48328 : scanCanonicalize (H12AffineFastState.compose env48328 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound48328 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48329 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,292,34,16536,2048,1025,293,17816,168,152,138,40,16,2340,16536,4096,2340,1284,169,257,33,16385,513]

theorem envBound48329 : H12AffineFastState.Bounded env48329 := by
  intro p hp
  have h : env48329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48328_48329 : H12AffineEnvironment.transform 12 160 env48328 = env48329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env48328 == env48329) = true)

theorem identity48329 : scanCanonicalize (H12AffineFastState.compose env48329 (packedSelected [3,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound48329 : packedSelected [3,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48330 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2065,160,16384,292,34,16536,2048,1025,293,17816,168,152,138,40,16,2340,16536,2065,2340,1284,169,257,33,16385,513]

theorem envBound48330 : H12AffineFastState.Bounded env48330 := by
  intro p hp
  have h : env48330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48329_48330 : H12AffineEnvironment.transform 11 2065 env48329 = env48330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env48329 == env48330) = true)

theorem identity48330 : scanCanonicalize (H12AffineFastState.compose env48330 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48330 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48331 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,41,16384,292,34,16401,2048,1025,293,17681,33,17,3,40,16,2340,16401,2065,2340,1284,32,257,33,16385,513]

theorem envBound48331 : H12AffineFastState.Bounded env48331 := by
  intro p hp
  have h : env48331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48330_48331 : H12AffineEnvironment.transform 6 9 env48330 = env48331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48330 == env48331) = true)

theorem identity48331 : scanCanonicalize (H12AffineFastState.compose env48331 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound48331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48332 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,41,16384,292,34,16401,2048,272,293,16384,33,17,3,40,16,2340,16401,2065,2340,21,32,257,33,16385,513]

theorem envBound48332 : H12AffineFastState.Bounded env48332 := by
  intro p hp
  have h : env48332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48331_48332 : H12AffineEnvironment.transform 9 273 env48331 = env48332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48331 == env48332) = true)

theorem identity48332 : scanCanonicalize (H12AffineFastState.compose env48332 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48332 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48333 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,41,16384,1,34,16401,2048,53,0,16384,33,17,3,40,16,2049,16401,2065,2049,21,32,36,33,16385,513]

theorem envBound48333 : H12AffineFastState.Bounded env48333 := by
  intro p hp
  have h : env48333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48332_48333 : H12AffineEnvironment.transform 7 37 env48332 = env48333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48332 == env48333) = true)

theorem identity48333 : scanCanonicalize (H12AffineFastState.compose env48333 (packedSelected [10] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound48333 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env48334 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,41,2048,1,34,2065,2048,53,0,2048,33,17,3,40,16,2049,2065,2065,2049,21,32,36,33,2049,513]

theorem envBound48334 : H12AffineFastState.Bounded env48334 := by
  intro p hp
  have h : env48334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48333_48334 : H12AffineEnvironment.transform 13 2048 env48333 = env48334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env48333 == env48334) = true)

theorem identity48334 : scanCanonicalize (H12AffineFastState.compose env48334 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound48334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48335 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,33,41,48,1,34,33,48,53,0,48,33,17,3,40,16,49,33,33,49,21,32,36,33,49,513]

theorem envBound48335 : H12AffineFastState.Bounded env48335 := by
  intro p hp
  have h : env48335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48334_48335 : H12AffineEnvironment.transform 10 48 env48334 = env48335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env48334 == env48335) = true)

def leafEnv48335 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,33,41,48,1,34,33,48,53,0,48,33,17,3,20,40,1,16,49,33,33,49,21,32,36,33,5,35,49,513,1,49,0]

def active48335 : List Nat := [0,1,2,3,4,8]

def tree48335 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48335 : H12WitnessSearch.Good tree48335 := H12GlobalWitnessIndex.good

theorem leafIdentity48335 : H12AffineFastState.composeSystem env48335 rootObs = leafEnv48335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48335 rootObs == leafEnv48335) = true)

theorem terminalChecked48335 : H12PackedTerminal.terminalCheckFast leafEnv48335 active48335 tree48335 = true := by decide +kernel

def env48336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35188,1025,32769,2097152,4194304,153,41310,8328,65,4302890,2172370,2119112,2420,75223,6407326,257,2188650,2196686,513]

theorem envBound48336 : H12AffineFastState.Bounded env48336 := by
  intro p hp
  have h : env48336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48322_48336 : H12AffineEnvironment.transform 16 16537 env48322 = env48336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env48322 == env48336) = true)

theorem identity48336 : scanCanonicalize (H12AffineFastState.compose env48336 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48336 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env48337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41310,8192,65,4302890,2172250,2118976,2420,75103,6407190,257,2188650,2196550,513]

theorem envBound48337 : H12AffineFastState.Bounded env48337 := by
  intro p hp
  have h : env48337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48336_48337 : H12AffineEnvironment.transform 6 8 env48336 = env48337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48336 == env48337) = true)

theorem identity48337 : scanCanonicalize (H12AffineFastState.compose env48337 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound48337 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48338 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115734,4194304,17,41310,8192,65,4302890,57676,102742,2420,75103,4194304,257,41340,16464,513]

theorem envBound48338 : H12AffineFastState.Bounded env48338 := by
  intro p hp
  have h : env48338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48337_48338 : H12AffineEnvironment.transform 20 115734 env48337 = env48338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env48337 == env48338) = true)

def env48339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10588,1025,8233,91198,4194304,17,374,8192,65,4261890,16740,78206,2420,75103,4194304,257,340,16464,513]

theorem envBound48339 : H12AffineFastState.Bounded env48339 := by
  intro p hp
  have h : env48339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48338_48339 : H12AffineEnvironment.transform 14 8232 env48338 = env48339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env48338 == env48339) = true)

theorem identity48339 : scanCanonicalize (H12AffineFastState.compose env48339 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound48339 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env48340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,343,16401,10588,1025,8233,25961,4194304,17,374,8192,65,4196693,16740,12329,2420,9224,4194304,257,340,16464,513]

theorem envBound48340 : H12AffineFastState.Bounded env48340 := by
  intro p hp
  have h : env48340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48339_48340 : H12AffineEnvironment.transform 15 343 env48339 = env48340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env48339 == env48340) = true)

theorem identity48340 : scanCanonicalize (H12AffineFastState.compose env48340 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound48340 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env48341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,343,16401,10588,1025,8233,25961,8201,17,374,8192,65,10588,16740,12329,2420,9224,8201,257,340,16464,513]

theorem envBound48341 : H12AffineFastState.Bounded env48341 := by
  intro p hp
  have h : env48341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48340_48341 : H12AffineEnvironment.transform 21 8201 env48340 = env48341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env48340 == env48341) = true)

theorem identity48341 : scanCanonicalize (H12AffineFastState.compose env48341 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48341 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env48342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,372,343,16401,2048,1025,373,17461,341,17,374,348,65,2048,16740,4469,2420,1364,341,257,340,16464,513]

theorem envBound48342 : H12AffineFastState.Bounded env48342 := by
  intro p hp
  have h : env48342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48341_48342 : H12AffineEnvironment.transform 12 348 env48341 = env48342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48341 == env48342) = true)

theorem identity48342 : scanCanonicalize (H12AffineFastState.compose env48342 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48342 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48343 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,292,263,16401,2048,1025,293,17461,261,17,294,268,17,2048,16692,4389,2340,1284,261,257,260,16384,513]

theorem envBound48343 : H12AffineFastState.Bounded env48343 := by
  intro p hp
  have h : env48343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48342_48343 : H12AffineEnvironment.transform 5 16 env48342 = env48343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48342 == env48343) = true)

theorem identity48343 : scanCanonicalize (H12AffineFastState.compose env48343 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48343 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48344 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,16384,0,35,16401,2048,1025,1,17461,33,17,2,40,17,2048,16400,4097,2048,1056,33,37,32,16384,513]

theorem envBound48344 : H12AffineFastState.Bounded env48344 := by
  intro p hp
  have h : env48344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48343_48344 : H12AffineEnvironment.transform 7 36 env48343 = env48344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48343 == env48344) = true)

theorem identity48344 : scanCanonicalize (H12AffineFastState.compose env48344 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound48344 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48345 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5172,2048,1025,1,4112,33,17,2,40,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound48345 : H12AffineFastState.Bounded env48345 := by
  intro p hp
  have h : env48345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48344_48345 : H12AffineEnvironment.transform 13 5157 env48344 = env48345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env48344 == env48345) = true)

def env48346 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,0,35,1028,2048,1025,1,32,33,17,2,40,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound48346 : H12AffineFastState.Bounded env48346 := by
  intro p hp
  have h : env48346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48345_48346 : H12AffineEnvironment.transform 11 48 env48345 = env48346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48345 == env48346) = true)

theorem identity48346 : scanCanonicalize (H12AffineFastState.compose env48346 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound48346 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48347 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1045,48,40,1045,0,35,1028,1045,1025,1,32,33,17,2,40,17,1045,1029,49,1045,1056,33,37,32,1045,513]

theorem envBound48347 : H12AffineFastState.Bounded env48347 := by
  intro p hp
  have h : env48347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48346_48347 : H12AffineEnvironment.transform 10 1045 env48346 = env48347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env48346 == env48347) = true)

def env48348 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,48,40,33,0,35,48,33,53,1,32,33,17,2,40,17,33,49,49,33,20,33,37,32,33,513]

theorem envBound48348 : H12AffineFastState.Bounded env48348 := by
  intro p hp
  have h : env48348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48347_48348 : H12AffineEnvironment.transform 9 52 env48347 = env48348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48347 == env48348) = true)

def env48349 : List Nat := [2,4,8,16,32,16,8,36,512,53,32,48,40,32,0,35,49,32,52,1,32,33,17,2,40,17,32,48,49,32,21,33,37,32,32,513]

theorem envBound48349 : H12AffineFastState.Bounded env48349 := by
  intro p hp
  have h : env48349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48347_48349 : H12AffineEnvironment.transform 9 53 env48347 = env48349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48347 == env48349) = true)

theorem identity48349 : scanCanonicalize (H12AffineFastState.compose env48349 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48350 : List Nat := [2,4,8,16,32,16,8,36,43,53,32,48,40,32,0,35,49,32,52,1,32,33,17,2,40,17,32,48,49,32,21,33,37,32,32,42]

theorem envBound48350 : H12AffineFastState.Bounded env48350 := by
  intro p hp
  have h : env48350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48349_48350 : H12AffineEnvironment.transform 8 43 env48349 = env48350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48349 == env48350) = true)

def leafEnv48350 : List Nat := [2,4,8,16,32,16,8,36,43,53,32,48,40,32,0,35,49,32,52,1,32,33,17,2,20,40,1,17,32,48,49,32,21,33,37,32,5,35,32,42,1,32,0]

def active48350 : List Nat := [0,1,2,3,4]

def tree48350 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48350 : H12WitnessSearch.Good tree48350 := H12GlobalWitnessIndex.good

theorem leafIdentity48350 : H12AffineFastState.composeSystem env48350 rootObs = leafEnv48350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48350 rootObs == leafEnv48350) = true)

theorem terminalChecked48350 : H12PackedTerminal.terminalCheckFast leafEnv48350 active48350 tree48350 = true := by decide +kernel

def env48351 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,0,35,1029,2048,1025,1,33,33,17,2,40,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound48351 : H12AffineFastState.Bounded env48351 := by
  intro p hp
  have h : env48351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48345_48351 : H12AffineEnvironment.transform 11 49 env48345 = env48351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48345 == env48351) = true)

theorem identity48351 : scanCanonicalize (H12AffineFastState.compose env48351 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound48351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48352 : List Nat := [2,4,8,16,32,16,8,36,512,1024,33,49,40,1044,0,35,1029,33,1025,1,33,33,17,2,40,17,33,1028,48,33,1056,33,37,32,1044,513]

theorem envBound48352 : H12AffineFastState.Bounded env48352 := by
  intro p hp
  have h : env48352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48351_48352 : H12AffineEnvironment.transform 10 33 env48351 = env48352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env48351 == env48352) = true)

def env48353 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,49,40,32,0,35,49,33,53,1,33,33,17,2,40,17,33,48,48,33,20,33,37,32,32,513]

theorem envBound48353 : H12AffineFastState.Bounded env48353 := by
  intro p hp
  have h : env48353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48352_48353 : H12AffineEnvironment.transform 9 52 env48352 = env48353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48352 == env48353) = true)

def env48354 : List Nat := [2,4,8,16,32,16,8,36,512,53,33,49,40,33,0,35,48,33,52,1,33,33,17,2,40,17,33,49,48,33,21,33,37,32,33,513]

theorem envBound48354 : H12AffineFastState.Bounded env48354 := by
  intro p hp
  have h : env48354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48352_48354 : H12AffineEnvironment.transform 9 53 env48352 = env48354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48352 == env48354) = true)

theorem identity48354 : scanCanonicalize (H12AffineFastState.compose env48354 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound48354 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48355 : List Nat := [2,4,8,16,32,16,8,36,42,53,33,49,40,33,0,35,48,33,52,1,33,33,17,2,40,17,33,49,48,33,21,33,37,32,33,43]

theorem envBound48355 : H12AffineFastState.Bounded env48355 := by
  intro p hp
  have h : env48355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48354_48355 : H12AffineEnvironment.transform 8 42 env48354 = env48355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env48354 == env48355) = true)

def leafEnv48355 : List Nat := [2,4,8,16,32,16,8,36,42,53,33,49,40,33,0,35,48,33,52,1,33,33,17,2,20,40,1,17,33,49,48,33,21,33,37,32,5,35,33,43,1,33,0]

def active48355 : List Nat := [0,1,2,3,4]

def tree48355 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48355 : H12WitnessSearch.Good tree48355 := H12GlobalWitnessIndex.good

theorem leafIdentity48355 : H12AffineFastState.composeSystem env48355 rootObs = leafEnv48355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48355 rootObs == leafEnv48355) = true)

theorem terminalChecked48355 : H12PackedTerminal.terminalCheckFast leafEnv48355 active48355 tree48355 = true := by decide +kernel

def env48356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10589,1025,8232,91199,4194304,17,375,8192,65,4261891,16741,78207,2420,75103,4194304,257,341,16464,513]

theorem envBound48356 : H12AffineFastState.Bounded env48356 := by
  intro p hp
  have h : env48356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48338_48356 : H12AffineEnvironment.transform 14 8233 env48338 = env48356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env48338 == env48356) = true)

theorem identity48356 : scanCanonicalize (H12AffineFastState.compose env48356 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound48356 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env48357 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,34,16401,10589,1025,8232,25629,4194304,17,375,8192,65,4196385,16741,12637,2420,9597,4194304,257,341,16464,513]

theorem envBound48357 : H12AffineFastState.Bounded env48357 := by
  intro p hp
  have h : env48357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48356_48357 : H12AffineEnvironment.transform 15 34 env48356 = env48357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env48356 == env48357) = true)

theorem identity48357 : scanCanonicalize (H12AffineFastState.compose env48357 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(21+1) ^^^ 8280) := by decide +kernel

theorem selectedBound48357 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env48358 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,34,16401,10589,1025,8232,25629,8280,17,375,8192,65,10361,16741,12637,2420,9597,8280,257,341,16464,513]

theorem envBound48358 : H12AffineFastState.Bounded env48358 := by
  intro p hp
  have h : env48358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48357_48358 : H12AffineEnvironment.transform 21 8280 env48357 = env48358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8280 env48357 == env48358) = true)

theorem identity48358 : scanCanonicalize (H12AffineFastState.compose env48358 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48358 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env48359 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8233,34,16401,10280,1025,8232,25629,8280,17,2,8192,65,10361,16400,12328,2049,9224,8280,116,32,16464,513]

theorem envBound48359 : H12AffineFastState.Bounded env48359 := by
  intro p hp
  have h : env48359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48358_48359 : H12AffineEnvironment.transform 7 117 env48358 = env48359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48358 == env48359) = true)

theorem identity48359 : scanCanonicalize (H12AffineFastState.compose env48359 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48359 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48360 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8233,34,16401,10280,1025,8232,25629,8200,17,2,8192,17,10281,16400,12328,2049,9224,8200,36,32,16384,513]

theorem envBound48360 : H12AffineFastState.Bounded env48360 := by
  intro p hp
  have h : env48360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48359_48360 : H12AffineEnvironment.transform 5 16 env48359 = env48360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48359 == env48360) = true)

theorem identity48360 : scanCanonicalize (H12AffineFastState.compose env48360 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound48360 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48361 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,5157,8233,34,5172,10280,1025,8232,12344,8200,17,2,8192,17,10281,5173,12328,2049,9224,8200,36,32,5157,513]

theorem envBound48361 : H12AffineFastState.Bounded env48361 := by
  intro p hp
  have h : env48361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48360_48361 : H12AffineEnvironment.transform 13 5157 env48360 = env48361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env48360 == env48361) = true)

theorem identity48361 : scanCanonicalize (H12AffineFastState.compose env48361 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound48361 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48362 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,0,34,5172,2049,1025,1,4113,33,17,2,41,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound48362 : H12AffineFastState.Bounded env48362 := by
  intro p hp
  have h : env48362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48361_48362 : H12AffineEnvironment.transform 12 41 env48361 = env48362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env48361 == env48362) = true)

def env48363 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1045,0,34,1028,2049,1025,1,33,33,17,2,41,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound48363 : H12AffineFastState.Bounded env48363 := by
  intro p hp
  have h : env48363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48362_48363 : H12AffineEnvironment.transform 11 48 env48362 = env48363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48362 == env48363) = true)

theorem identity48363 : scanCanonicalize (H12AffineFastState.compose env48363 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound48363 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48364 : List Nat := [2,4,8,16,32,16,8,37,49,1024,2048,48,41,1045,0,34,1028,2049,1025,1,33,33,17,2,41,17,2048,1029,49,2049,1057,33,36,32,1045,48]

theorem envBound48364 : H12AffineFastState.Bounded env48364 := by
  intro p hp
  have h : env48364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48363_48364 : H12AffineEnvironment.transform 8 49 env48363 = env48364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48363 == env48364) = true)

def env48365 : List Nat := [2,4,8,16,32,16,8,37,49,52,2048,48,41,33,0,34,48,2049,53,1,33,33,17,2,41,17,2048,49,49,2049,21,33,36,32,33,48]

theorem envBound48365 : H12AffineFastState.Bounded env48365 := by
  intro p hp
  have h : env48365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48364_48365 : H12AffineEnvironment.transform 9 52 env48364 = env48365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48364 == env48365) = true)

def env48366 : List Nat := [2,4,8,16,32,16,8,37,49,53,2048,48,41,32,0,34,49,2049,52,1,33,33,17,2,41,17,2048,48,49,2049,20,33,36,32,32,48]

theorem envBound48366 : H12AffineFastState.Bounded env48366 := by
  intro p hp
  have h : env48366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48364_48366 : H12AffineEnvironment.transform 9 53 env48364 = env48366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48364 == env48366) = true)

theorem identity48366 : scanCanonicalize (H12AffineFastState.compose env48366 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48366 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48367 : List Nat := [2,4,8,11,32,11,8,37,42,46,2048,43,41,32,0,34,42,2049,47,1,33,33,10,2,41,10,2048,43,42,2049,15,33,36,32,32,43]

theorem envBound48367 : H12AffineFastState.Bounded env48367 := by
  intro p hp
  have h : env48367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48366_48367 : H12AffineEnvironment.transform 3 11 env48366 = env48367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48366 == env48367) = true)

def leafEnv48367 : List Nat := [2,4,8,11,32,11,8,37,42,46,2048,43,41,32,0,34,42,2049,47,1,33,33,10,2,14,41,1,10,2048,43,42,2049,15,33,36,32,5,34,32,43,1,33,0]

def active48367 : List Nat := [0,1,2,4,10]

def tree48367 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48367 : H12WitnessSearch.Good tree48367 := H12GlobalWitnessIndex.good

theorem leafIdentity48367 : H12AffineFastState.composeSystem env48367 rootObs = leafEnv48367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48367 rootObs == leafEnv48367) = true)

theorem terminalChecked48367 : H12PackedTerminal.terminalCheckFast leafEnv48367 active48367 tree48367 = true := by decide +kernel

def env48368 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1044,0,34,1029,2049,1025,1,32,33,17,2,41,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound48368 : H12AffineFastState.Bounded env48368 := by
  intro p hp
  have h : env48368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48362_48368 : H12AffineEnvironment.transform 11 49 env48362 = env48368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48362 == env48368) = true)

theorem identity48368 : scanCanonicalize (H12AffineFastState.compose env48368 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

end H12CloudChart0